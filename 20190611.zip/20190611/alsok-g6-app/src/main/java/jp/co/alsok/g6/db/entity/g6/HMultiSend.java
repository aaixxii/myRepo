package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HMultiSend implements Serializable {
    /**
     * LN_多重配信送信履歴論理番号
     */
    private String LN_H_MULTI_SEND;

    /**
     * システム区分
     */
    private String SYS_KBN;

    /**
     * 送信先業務コード
     */
    private String DST_GYOUMU_CD;

    /**
     * 送信先ホスト番号
     */
    private String DST_HOST_NUM;

    /**
     * 発生日付
     */
    private Date HASSEI_TS;

    /**
     * 通番
     */
    private String SEQ_NUM;

    /**
     * 号機番号
     */
    private String GOUKI;

    /**
     * サブアドレス
     */
    private String DATA_SUB_ADDR;

    /**
     * LN_警備情報論理番号
     */
    private String LN_KB_INF;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * 送信電文
     */
    private String SEND_MSG;

    /**
     * H_MULTI_SEND
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_多重配信送信履歴論理番号
     * @return LN_H_MULTI_SEND LN_多重配信送信履歴論理番号
     */
    public String getLN_H_MULTI_SEND() {
        return LN_H_MULTI_SEND;
    }

    /**
     * LN_多重配信送信履歴論理番号
     * @param LN_H_MULTI_SEND LN_多重配信送信履歴論理番号
     */
    public void setLN_H_MULTI_SEND(String LN_H_MULTI_SEND) {
        this.LN_H_MULTI_SEND = LN_H_MULTI_SEND == null ? null : LN_H_MULTI_SEND.trim();
    }

    /**
     * システム区分
     * @return SYS_KBN システム区分
     */
    public String getSYS_KBN() {
        return SYS_KBN;
    }

    /**
     * システム区分
     * @param SYS_KBN システム区分
     */
    public void setSYS_KBN(String SYS_KBN) {
        this.SYS_KBN = SYS_KBN == null ? null : SYS_KBN.trim();
    }

    /**
     * 送信先業務コード
     * @return DST_GYOUMU_CD 送信先業務コード
     */
    public String getDST_GYOUMU_CD() {
        return DST_GYOUMU_CD;
    }

    /**
     * 送信先業務コード
     * @param DST_GYOUMU_CD 送信先業務コード
     */
    public void setDST_GYOUMU_CD(String DST_GYOUMU_CD) {
        this.DST_GYOUMU_CD = DST_GYOUMU_CD == null ? null : DST_GYOUMU_CD.trim();
    }

    /**
     * 送信先ホスト番号
     * @return DST_HOST_NUM 送信先ホスト番号
     */
    public String getDST_HOST_NUM() {
        return DST_HOST_NUM;
    }

    /**
     * 送信先ホスト番号
     * @param DST_HOST_NUM 送信先ホスト番号
     */
    public void setDST_HOST_NUM(String DST_HOST_NUM) {
        this.DST_HOST_NUM = DST_HOST_NUM == null ? null : DST_HOST_NUM.trim();
    }

    /**
     * 発生日付
     * @return HASSEI_TS 発生日付
     */
    public Date getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 発生日付
     * @param HASSEI_TS 発生日付
     */
    public void setHASSEI_TS(Date HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS;
    }

    /**
     * 通番
     * @return SEQ_NUM 通番
     */
    public String getSEQ_NUM() {
        return SEQ_NUM;
    }

    /**
     * 通番
     * @param SEQ_NUM 通番
     */
    public void setSEQ_NUM(String SEQ_NUM) {
        this.SEQ_NUM = SEQ_NUM == null ? null : SEQ_NUM.trim();
    }

    /**
     * 号機番号
     * @return GOUKI 号機番号
     */
    public String getGOUKI() {
        return GOUKI;
    }

    /**
     * 号機番号
     * @param GOUKI 号機番号
     */
    public void setGOUKI(String GOUKI) {
        this.GOUKI = GOUKI == null ? null : GOUKI.trim();
    }

    /**
     * サブアドレス
     * @return DATA_SUB_ADDR サブアドレス
     */
    public String getDATA_SUB_ADDR() {
        return DATA_SUB_ADDR;
    }

    /**
     * サブアドレス
     * @param DATA_SUB_ADDR サブアドレス
     */
    public void setDATA_SUB_ADDR(String DATA_SUB_ADDR) {
        this.DATA_SUB_ADDR = DATA_SUB_ADDR == null ? null : DATA_SUB_ADDR.trim();
    }

    /**
     * LN_警備情報論理番号
     * @return LN_KB_INF LN_警備情報論理番号
     */
    public String getLN_KB_INF() {
        return LN_KB_INF;
    }

    /**
     * LN_警備情報論理番号
     * @param LN_KB_INF LN_警備情報論理番号
     */
    public void setLN_KB_INF(String LN_KB_INF) {
        this.LN_KB_INF = LN_KB_INF == null ? null : LN_KB_INF.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * 送信電文
     * @return SEND_MSG 送信電文
     */
    public String getSEND_MSG() {
        return SEND_MSG;
    }

    /**
     * 送信電文
     * @param SEND_MSG 送信電文
     */
    public void setSEND_MSG(String SEND_MSG) {
        this.SEND_MSG = SEND_MSG == null ? null : SEND_MSG.trim();
    }
}