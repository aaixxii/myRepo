package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MKobetsuDanIntSts implements Serializable {
    /**
     * 個別断線監視間隔状態
     */
    private String KOBETSU_DAN_INT_STS;

    /**
     * 表示名
     */
    private String DISP_NM;

    /**
     * 表示順
     */
    private String ORDER_NUM;

    /**
     * 正常時監視間隔
     */
    private String CONN_DAN_INT;

    /**
     * 断線時監視間隔
     */
    private String DCONN_DAN_INT;

    /**
     * 断線監視実施フラグ
     */
    private String DAN_CHK_STS_FLG;

    /**
     * IP回線フラグ
     */
    private String IP_FLG;

    /**
     * 無線回線フラグ
     */
    private String WL_FLG;

    /**
     * アナログ回線フラグ
     */
    private String ANALOG_FLG;

    /**
     * M_KOBETSU_DAN_INT_STS
     */
    private static final long serialVersionUID = 1L;

    /**
     * 個別断線監視間隔状態
     * @return KOBETSU_DAN_INT_STS 個別断線監視間隔状態
     */
    public String getKOBETSU_DAN_INT_STS() {
        return KOBETSU_DAN_INT_STS;
    }

    /**
     * 個別断線監視間隔状態
     * @param KOBETSU_DAN_INT_STS 個別断線監視間隔状態
     */
    public void setKOBETSU_DAN_INT_STS(String KOBETSU_DAN_INT_STS) {
        this.KOBETSU_DAN_INT_STS = KOBETSU_DAN_INT_STS == null ? null : KOBETSU_DAN_INT_STS.trim();
    }

    /**
     * 表示名
     * @return DISP_NM 表示名
     */
    public String getDISP_NM() {
        return DISP_NM;
    }

    /**
     * 表示名
     * @param DISP_NM 表示名
     */
    public void setDISP_NM(String DISP_NM) {
        this.DISP_NM = DISP_NM == null ? null : DISP_NM.trim();
    }

    /**
     * 表示順
     * @return ORDER_NUM 表示順
     */
    public String getORDER_NUM() {
        return ORDER_NUM;
    }

    /**
     * 表示順
     * @param ORDER_NUM 表示順
     */
    public void setORDER_NUM(String ORDER_NUM) {
        this.ORDER_NUM = ORDER_NUM == null ? null : ORDER_NUM.trim();
    }

    /**
     * 正常時監視間隔
     * @return CONN_DAN_INT 正常時監視間隔
     */
    public String getCONN_DAN_INT() {
        return CONN_DAN_INT;
    }

    /**
     * 正常時監視間隔
     * @param CONN_DAN_INT 正常時監視間隔
     */
    public void setCONN_DAN_INT(String CONN_DAN_INT) {
        this.CONN_DAN_INT = CONN_DAN_INT == null ? null : CONN_DAN_INT.trim();
    }

    /**
     * 断線時監視間隔
     * @return DCONN_DAN_INT 断線時監視間隔
     */
    public String getDCONN_DAN_INT() {
        return DCONN_DAN_INT;
    }

    /**
     * 断線時監視間隔
     * @param DCONN_DAN_INT 断線時監視間隔
     */
    public void setDCONN_DAN_INT(String DCONN_DAN_INT) {
        this.DCONN_DAN_INT = DCONN_DAN_INT == null ? null : DCONN_DAN_INT.trim();
    }

    /**
     * 断線監視実施フラグ
     * @return DAN_CHK_STS_FLG 断線監視実施フラグ
     */
    public String getDAN_CHK_STS_FLG() {
        return DAN_CHK_STS_FLG;
    }

    /**
     * 断線監視実施フラグ
     * @param DAN_CHK_STS_FLG 断線監視実施フラグ
     */
    public void setDAN_CHK_STS_FLG(String DAN_CHK_STS_FLG) {
        this.DAN_CHK_STS_FLG = DAN_CHK_STS_FLG == null ? null : DAN_CHK_STS_FLG.trim();
    }

    /**
     * IP回線フラグ
     * @return IP_FLG IP回線フラグ
     */
    public String getIP_FLG() {
        return IP_FLG;
    }

    /**
     * IP回線フラグ
     * @param IP_FLG IP回線フラグ
     */
    public void setIP_FLG(String IP_FLG) {
        this.IP_FLG = IP_FLG == null ? null : IP_FLG.trim();
    }

    /**
     * 無線回線フラグ
     * @return WL_FLG 無線回線フラグ
     */
    public String getWL_FLG() {
        return WL_FLG;
    }

    /**
     * 無線回線フラグ
     * @param WL_FLG 無線回線フラグ
     */
    public void setWL_FLG(String WL_FLG) {
        this.WL_FLG = WL_FLG == null ? null : WL_FLG.trim();
    }

    /**
     * アナログ回線フラグ
     * @return ANALOG_FLG アナログ回線フラグ
     */
    public String getANALOG_FLG() {
        return ANALOG_FLG;
    }

    /**
     * アナログ回線フラグ
     * @param ANALOG_FLG アナログ回線フラグ
     */
    public void setANALOG_FLG(String ANALOG_FLG) {
        this.ANALOG_FLG = ANALOG_FLG == null ? null : ANALOG_FLG.trim();
    }
}