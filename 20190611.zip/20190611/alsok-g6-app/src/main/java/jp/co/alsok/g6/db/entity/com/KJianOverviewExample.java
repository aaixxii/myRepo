package jp.co.alsok.g6.db.entity.com;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class KJianOverviewExample {
    /**
     * K_JIAN_OVERVIEW
     */
    protected String orderByClause;

    /**
     * K_JIAN_OVERVIEW
     */
    protected boolean distinct;

    /**
     * K_JIAN_OVERVIEW
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public KJianOverviewExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * K_JIAN_OVERVIEW null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_K_JIAN_OVERVIEWIsNull() {
            addCriterion("LN_K_JIAN_OVERVIEW is null");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWIsNotNull() {
            addCriterion("LN_K_JIAN_OVERVIEW is not null");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWEqualTo(String value) {
            addCriterion("LN_K_JIAN_OVERVIEW =", value, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWNotEqualTo(String value) {
            addCriterion("LN_K_JIAN_OVERVIEW <>", value, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWGreaterThan(String value) {
            addCriterion("LN_K_JIAN_OVERVIEW >", value, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWGreaterThanOrEqualTo(String value) {
            addCriterion("LN_K_JIAN_OVERVIEW >=", value, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWLessThan(String value) {
            addCriterion("LN_K_JIAN_OVERVIEW <", value, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWLessThanOrEqualTo(String value) {
            addCriterion("LN_K_JIAN_OVERVIEW <=", value, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWLike(String value) {
            addCriterion("LN_K_JIAN_OVERVIEW like", value, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWNotLike(String value) {
            addCriterion("LN_K_JIAN_OVERVIEW not like", value, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWIn(List<String> values) {
            addCriterion("LN_K_JIAN_OVERVIEW in", values, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWNotIn(List<String> values) {
            addCriterion("LN_K_JIAN_OVERVIEW not in", values, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWBetween(String value1, String value2) {
            addCriterion("LN_K_JIAN_OVERVIEW between", value1, value2, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWNotBetween(String value1, String value2) {
            addCriterion("LN_K_JIAN_OVERVIEW not between", value1, value2, "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIsNull() {
            addCriterion("SYS_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIsNotNull() {
            addCriterion("SYS_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNEqualTo(String value) {
            addCriterion("SYS_KBN =", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotEqualTo(String value) {
            addCriterion("SYS_KBN <>", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNGreaterThan(String value) {
            addCriterion("SYS_KBN >", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SYS_KBN >=", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLessThan(String value) {
            addCriterion("SYS_KBN <", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLessThanOrEqualTo(String value) {
            addCriterion("SYS_KBN <=", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLike(String value) {
            addCriterion("SYS_KBN like", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotLike(String value) {
            addCriterion("SYS_KBN not like", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIn(List<String> values) {
            addCriterion("SYS_KBN in", values, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotIn(List<String> values) {
            addCriterion("SYS_KBN not in", values, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNBetween(String value1, String value2) {
            addCriterion("SYS_KBN between", value1, value2, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotBetween(String value1, String value2) {
            addCriterion("SYS_KBN not between", value1, value2, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNIsNull() {
            addCriterion("SINPO_HANDAN_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNIsNotNull() {
            addCriterion("SINPO_HANDAN_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNEqualTo(String value) {
            addCriterion("SINPO_HANDAN_KBN =", value, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNNotEqualTo(String value) {
            addCriterion("SINPO_HANDAN_KBN <>", value, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNGreaterThan(String value) {
            addCriterion("SINPO_HANDAN_KBN >", value, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_HANDAN_KBN >=", value, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNLessThan(String value) {
            addCriterion("SINPO_HANDAN_KBN <", value, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNLessThanOrEqualTo(String value) {
            addCriterion("SINPO_HANDAN_KBN <=", value, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNLike(String value) {
            addCriterion("SINPO_HANDAN_KBN like", value, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNNotLike(String value) {
            addCriterion("SINPO_HANDAN_KBN not like", value, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNIn(List<String> values) {
            addCriterion("SINPO_HANDAN_KBN in", values, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNNotIn(List<String> values) {
            addCriterion("SINPO_HANDAN_KBN not in", values, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNBetween(String value1, String value2) {
            addCriterion("SINPO_HANDAN_KBN between", value1, value2, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNNotBetween(String value1, String value2) {
            addCriterion("SINPO_HANDAN_KBN not between", value1, value2, "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSIsNull() {
            addCriterion("IMAGE_GET_STS is null");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSIsNotNull() {
            addCriterion("IMAGE_GET_STS is not null");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSEqualTo(String value) {
            addCriterion("IMAGE_GET_STS =", value, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSNotEqualTo(String value) {
            addCriterion("IMAGE_GET_STS <>", value, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSGreaterThan(String value) {
            addCriterion("IMAGE_GET_STS >", value, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSGreaterThanOrEqualTo(String value) {
            addCriterion("IMAGE_GET_STS >=", value, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSLessThan(String value) {
            addCriterion("IMAGE_GET_STS <", value, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSLessThanOrEqualTo(String value) {
            addCriterion("IMAGE_GET_STS <=", value, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSLike(String value) {
            addCriterion("IMAGE_GET_STS like", value, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSNotLike(String value) {
            addCriterion("IMAGE_GET_STS not like", value, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSIn(List<String> values) {
            addCriterion("IMAGE_GET_STS in", values, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSNotIn(List<String> values) {
            addCriterion("IMAGE_GET_STS not in", values, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSBetween(String value1, String value2) {
            addCriterion("IMAGE_GET_STS between", value1, value2, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSNotBetween(String value1, String value2) {
            addCriterion("IMAGE_GET_STS not between", value1, value2, "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGIsNull() {
            addCriterion("TIMEOUT_UMU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGIsNotNull() {
            addCriterion("TIMEOUT_UMU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGEqualTo(Date value) {
            addCriterion("TIMEOUT_UMU_FLG =", value, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGNotEqualTo(Date value) {
            addCriterion("TIMEOUT_UMU_FLG <>", value, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGGreaterThan(Date value) {
            addCriterion("TIMEOUT_UMU_FLG >", value, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGGreaterThanOrEqualTo(Date value) {
            addCriterion("TIMEOUT_UMU_FLG >=", value, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGLessThan(Date value) {
            addCriterion("TIMEOUT_UMU_FLG <", value, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGLessThanOrEqualTo(Date value) {
            addCriterion("TIMEOUT_UMU_FLG <=", value, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGIn(List<Date> values) {
            addCriterion("TIMEOUT_UMU_FLG in", values, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGNotIn(List<Date> values) {
            addCriterion("TIMEOUT_UMU_FLG not in", values, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGBetween(Date value1, Date value2) {
            addCriterion("TIMEOUT_UMU_FLG between", value1, value2, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_UMU_FLGNotBetween(Date value1, Date value2) {
            addCriterion("TIMEOUT_UMU_FLG not between", value1, value2, "TIMEOUT_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andJITAIIsNull() {
            addCriterion("JITAI is null");
            return (Criteria) this;
        }

        public Criteria andJITAIIsNotNull() {
            addCriterion("JITAI is not null");
            return (Criteria) this;
        }

        public Criteria andJITAIEqualTo(String value) {
            addCriterion("JITAI =", value, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAINotEqualTo(String value) {
            addCriterion("JITAI <>", value, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAIGreaterThan(String value) {
            addCriterion("JITAI >", value, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAIGreaterThanOrEqualTo(String value) {
            addCriterion("JITAI >=", value, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAILessThan(String value) {
            addCriterion("JITAI <", value, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAILessThanOrEqualTo(String value) {
            addCriterion("JITAI <=", value, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAILike(String value) {
            addCriterion("JITAI like", value, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAINotLike(String value) {
            addCriterion("JITAI not like", value, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAIIn(List<String> values) {
            addCriterion("JITAI in", values, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAINotIn(List<String> values) {
            addCriterion("JITAI not in", values, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAIBetween(String value1, String value2) {
            addCriterion("JITAI between", value1, value2, "JITAI");
            return (Criteria) this;
        }

        public Criteria andJITAINotBetween(String value1, String value2) {
            addCriterion("JITAI not between", value1, value2, "JITAI");
            return (Criteria) this;
        }

        public Criteria andGCIsNull() {
            addCriterion("GC is null");
            return (Criteria) this;
        }

        public Criteria andGCIsNotNull() {
            addCriterion("GC is not null");
            return (Criteria) this;
        }

        public Criteria andGCEqualTo(String value) {
            addCriterion("GC =", value, "GC");
            return (Criteria) this;
        }

        public Criteria andGCNotEqualTo(String value) {
            addCriterion("GC <>", value, "GC");
            return (Criteria) this;
        }

        public Criteria andGCGreaterThan(String value) {
            addCriterion("GC >", value, "GC");
            return (Criteria) this;
        }

        public Criteria andGCGreaterThanOrEqualTo(String value) {
            addCriterion("GC >=", value, "GC");
            return (Criteria) this;
        }

        public Criteria andGCLessThan(String value) {
            addCriterion("GC <", value, "GC");
            return (Criteria) this;
        }

        public Criteria andGCLessThanOrEqualTo(String value) {
            addCriterion("GC <=", value, "GC");
            return (Criteria) this;
        }

        public Criteria andGCLike(String value) {
            addCriterion("GC like", value, "GC");
            return (Criteria) this;
        }

        public Criteria andGCNotLike(String value) {
            addCriterion("GC not like", value, "GC");
            return (Criteria) this;
        }

        public Criteria andGCIn(List<String> values) {
            addCriterion("GC in", values, "GC");
            return (Criteria) this;
        }

        public Criteria andGCNotIn(List<String> values) {
            addCriterion("GC not in", values, "GC");
            return (Criteria) this;
        }

        public Criteria andGCBetween(String value1, String value2) {
            addCriterion("GC between", value1, value2, "GC");
            return (Criteria) this;
        }

        public Criteria andGCNotBetween(String value1, String value2) {
            addCriterion("GC not between", value1, value2, "GC");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKIsNull() {
            addCriterion("IMPORTANT_CUSTOMER_MARK is null");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKIsNotNull() {
            addCriterion("IMPORTANT_CUSTOMER_MARK is not null");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKEqualTo(String value) {
            addCriterion("IMPORTANT_CUSTOMER_MARK =", value, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKNotEqualTo(String value) {
            addCriterion("IMPORTANT_CUSTOMER_MARK <>", value, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKGreaterThan(String value) {
            addCriterion("IMPORTANT_CUSTOMER_MARK >", value, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKGreaterThanOrEqualTo(String value) {
            addCriterion("IMPORTANT_CUSTOMER_MARK >=", value, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKLessThan(String value) {
            addCriterion("IMPORTANT_CUSTOMER_MARK <", value, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKLessThanOrEqualTo(String value) {
            addCriterion("IMPORTANT_CUSTOMER_MARK <=", value, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKLike(String value) {
            addCriterion("IMPORTANT_CUSTOMER_MARK like", value, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKNotLike(String value) {
            addCriterion("IMPORTANT_CUSTOMER_MARK not like", value, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKIn(List<String> values) {
            addCriterion("IMPORTANT_CUSTOMER_MARK in", values, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKNotIn(List<String> values) {
            addCriterion("IMPORTANT_CUSTOMER_MARK not in", values, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKBetween(String value1, String value2) {
            addCriterion("IMPORTANT_CUSTOMER_MARK between", value1, value2, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKNotBetween(String value1, String value2) {
            addCriterion("IMPORTANT_CUSTOMER_MARK not between", value1, value2, "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMIsNull() {
            addCriterion("CUSTOMER_NUM is null");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMIsNotNull() {
            addCriterion("CUSTOMER_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMEqualTo(String value) {
            addCriterion("CUSTOMER_NUM =", value, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMNotEqualTo(String value) {
            addCriterion("CUSTOMER_NUM <>", value, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMGreaterThan(String value) {
            addCriterion("CUSTOMER_NUM >", value, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("CUSTOMER_NUM >=", value, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMLessThan(String value) {
            addCriterion("CUSTOMER_NUM <", value, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMLessThanOrEqualTo(String value) {
            addCriterion("CUSTOMER_NUM <=", value, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMLike(String value) {
            addCriterion("CUSTOMER_NUM like", value, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMNotLike(String value) {
            addCriterion("CUSTOMER_NUM not like", value, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMIn(List<String> values) {
            addCriterion("CUSTOMER_NUM in", values, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMNotIn(List<String> values) {
            addCriterion("CUSTOMER_NUM not in", values, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMBetween(String value1, String value2) {
            addCriterion("CUSTOMER_NUM between", value1, value2, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMNotBetween(String value1, String value2) {
            addCriterion("CUSTOMER_NUM not between", value1, value2, "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMIsNull() {
            addCriterion("CHIKU_NUM is null");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMIsNotNull() {
            addCriterion("CHIKU_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMEqualTo(String value) {
            addCriterion("CHIKU_NUM =", value, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMNotEqualTo(String value) {
            addCriterion("CHIKU_NUM <>", value, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMGreaterThan(String value) {
            addCriterion("CHIKU_NUM >", value, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("CHIKU_NUM >=", value, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMLessThan(String value) {
            addCriterion("CHIKU_NUM <", value, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMLessThanOrEqualTo(String value) {
            addCriterion("CHIKU_NUM <=", value, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMLike(String value) {
            addCriterion("CHIKU_NUM like", value, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMNotLike(String value) {
            addCriterion("CHIKU_NUM not like", value, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMIn(List<String> values) {
            addCriterion("CHIKU_NUM in", values, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMNotIn(List<String> values) {
            addCriterion("CHIKU_NUM not in", values, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMBetween(String value1, String value2) {
            addCriterion("CHIKU_NUM between", value1, value2, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMNotBetween(String value1, String value2) {
            addCriterion("CHIKU_NUM not between", value1, value2, "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRIsNull() {
            addCriterion("KEIBISAKI_ABBR is null");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRIsNotNull() {
            addCriterion("KEIBISAKI_ABBR is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBREqualTo(String value) {
            addCriterion("KEIBISAKI_ABBR =", value, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRNotEqualTo(String value) {
            addCriterion("KEIBISAKI_ABBR <>", value, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRGreaterThan(String value) {
            addCriterion("KEIBISAKI_ABBR >", value, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRGreaterThanOrEqualTo(String value) {
            addCriterion("KEIBISAKI_ABBR >=", value, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRLessThan(String value) {
            addCriterion("KEIBISAKI_ABBR <", value, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRLessThanOrEqualTo(String value) {
            addCriterion("KEIBISAKI_ABBR <=", value, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRLike(String value) {
            addCriterion("KEIBISAKI_ABBR like", value, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRNotLike(String value) {
            addCriterion("KEIBISAKI_ABBR not like", value, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRIn(List<String> values) {
            addCriterion("KEIBISAKI_ABBR in", values, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRNotIn(List<String> values) {
            addCriterion("KEIBISAKI_ABBR not in", values, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRBetween(String value1, String value2) {
            addCriterion("KEIBISAKI_ABBR between", value1, value2, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRNotBetween(String value1, String value2) {
            addCriterion("KEIBISAKI_ABBR not between", value1, value2, "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRIsNull() {
            addCriterion("KEIBISAKI_CHIKU_ABBR is null");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRIsNotNull() {
            addCriterion("KEIBISAKI_CHIKU_ABBR is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBREqualTo(String value) {
            addCriterion("KEIBISAKI_CHIKU_ABBR =", value, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRNotEqualTo(String value) {
            addCriterion("KEIBISAKI_CHIKU_ABBR <>", value, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRGreaterThan(String value) {
            addCriterion("KEIBISAKI_CHIKU_ABBR >", value, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRGreaterThanOrEqualTo(String value) {
            addCriterion("KEIBISAKI_CHIKU_ABBR >=", value, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRLessThan(String value) {
            addCriterion("KEIBISAKI_CHIKU_ABBR <", value, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRLessThanOrEqualTo(String value) {
            addCriterion("KEIBISAKI_CHIKU_ABBR <=", value, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRLike(String value) {
            addCriterion("KEIBISAKI_CHIKU_ABBR like", value, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRNotLike(String value) {
            addCriterion("KEIBISAKI_CHIKU_ABBR not like", value, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRIn(List<String> values) {
            addCriterion("KEIBISAKI_CHIKU_ABBR in", values, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRNotIn(List<String> values) {
            addCriterion("KEIBISAKI_CHIKU_ABBR not in", values, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRBetween(String value1, String value2) {
            addCriterion("KEIBISAKI_CHIKU_ABBR between", value1, value2, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRNotBetween(String value1, String value2) {
            addCriterion("KEIBISAKI_CHIKU_ABBR not between", value1, value2, "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOIsNull() {
            addCriterion("RECEPTION_INFO is null");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOIsNotNull() {
            addCriterion("RECEPTION_INFO is not null");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOEqualTo(String value) {
            addCriterion("RECEPTION_INFO =", value, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFONotEqualTo(String value) {
            addCriterion("RECEPTION_INFO <>", value, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOGreaterThan(String value) {
            addCriterion("RECEPTION_INFO >", value, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOGreaterThanOrEqualTo(String value) {
            addCriterion("RECEPTION_INFO >=", value, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOLessThan(String value) {
            addCriterion("RECEPTION_INFO <", value, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOLessThanOrEqualTo(String value) {
            addCriterion("RECEPTION_INFO <=", value, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOLike(String value) {
            addCriterion("RECEPTION_INFO like", value, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFONotLike(String value) {
            addCriterion("RECEPTION_INFO not like", value, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOIn(List<String> values) {
            addCriterion("RECEPTION_INFO in", values, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFONotIn(List<String> values) {
            addCriterion("RECEPTION_INFO not in", values, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOBetween(String value1, String value2) {
            addCriterion("RECEPTION_INFO between", value1, value2, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFONotBetween(String value1, String value2) {
            addCriterion("RECEPTION_INFO not between", value1, value2, "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGIsNull() {
            addCriterion("LAST_SIG is null");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGIsNotNull() {
            addCriterion("LAST_SIG is not null");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGEqualTo(String value) {
            addCriterion("LAST_SIG =", value, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGNotEqualTo(String value) {
            addCriterion("LAST_SIG <>", value, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGGreaterThan(String value) {
            addCriterion("LAST_SIG >", value, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGGreaterThanOrEqualTo(String value) {
            addCriterion("LAST_SIG >=", value, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGLessThan(String value) {
            addCriterion("LAST_SIG <", value, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGLessThanOrEqualTo(String value) {
            addCriterion("LAST_SIG <=", value, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGLike(String value) {
            addCriterion("LAST_SIG like", value, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGNotLike(String value) {
            addCriterion("LAST_SIG not like", value, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGIn(List<String> values) {
            addCriterion("LAST_SIG in", values, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGNotIn(List<String> values) {
            addCriterion("LAST_SIG not in", values, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGBetween(String value1, String value2) {
            addCriterion("LAST_SIG between", value1, value2, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGNotBetween(String value1, String value2) {
            addCriterion("LAST_SIG not between", value1, value2, "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGIsNull() {
            addCriterion("NF_SIG is null");
            return (Criteria) this;
        }

        public Criteria andNF_SIGIsNotNull() {
            addCriterion("NF_SIG is not null");
            return (Criteria) this;
        }

        public Criteria andNF_SIGEqualTo(String value) {
            addCriterion("NF_SIG =", value, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGNotEqualTo(String value) {
            addCriterion("NF_SIG <>", value, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGGreaterThan(String value) {
            addCriterion("NF_SIG >", value, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGGreaterThanOrEqualTo(String value) {
            addCriterion("NF_SIG >=", value, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGLessThan(String value) {
            addCriterion("NF_SIG <", value, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGLessThanOrEqualTo(String value) {
            addCriterion("NF_SIG <=", value, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGLike(String value) {
            addCriterion("NF_SIG like", value, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGNotLike(String value) {
            addCriterion("NF_SIG not like", value, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGIn(List<String> values) {
            addCriterion("NF_SIG in", values, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGNotIn(List<String> values) {
            addCriterion("NF_SIG not in", values, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGBetween(String value1, String value2) {
            addCriterion("NF_SIG between", value1, value2, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGNotBetween(String value1, String value2) {
            addCriterion("NF_SIG not between", value1, value2, "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGIsNull() {
            addCriterion("MEMO_UMU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGIsNotNull() {
            addCriterion("MEMO_UMU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGEqualTo(String value) {
            addCriterion("MEMO_UMU_FLG =", value, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGNotEqualTo(String value) {
            addCriterion("MEMO_UMU_FLG <>", value, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGGreaterThan(String value) {
            addCriterion("MEMO_UMU_FLG >", value, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_UMU_FLG >=", value, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGLessThan(String value) {
            addCriterion("MEMO_UMU_FLG <", value, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGLessThanOrEqualTo(String value) {
            addCriterion("MEMO_UMU_FLG <=", value, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGLike(String value) {
            addCriterion("MEMO_UMU_FLG like", value, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGNotLike(String value) {
            addCriterion("MEMO_UMU_FLG not like", value, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGIn(List<String> values) {
            addCriterion("MEMO_UMU_FLG in", values, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGNotIn(List<String> values) {
            addCriterion("MEMO_UMU_FLG not in", values, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGBetween(String value1, String value2) {
            addCriterion("MEMO_UMU_FLG between", value1, value2, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGNotBetween(String value1, String value2) {
            addCriterion("MEMO_UMU_FLG not between", value1, value2, "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOIsNull() {
            addCriterion("MEMO_INFO is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOIsNotNull() {
            addCriterion("MEMO_INFO is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOEqualTo(String value) {
            addCriterion("MEMO_INFO =", value, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFONotEqualTo(String value) {
            addCriterion("MEMO_INFO <>", value, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOGreaterThan(String value) {
            addCriterion("MEMO_INFO >", value, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOGreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_INFO >=", value, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOLessThan(String value) {
            addCriterion("MEMO_INFO <", value, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOLessThanOrEqualTo(String value) {
            addCriterion("MEMO_INFO <=", value, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOLike(String value) {
            addCriterion("MEMO_INFO like", value, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFONotLike(String value) {
            addCriterion("MEMO_INFO not like", value, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOIn(List<String> values) {
            addCriterion("MEMO_INFO in", values, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFONotIn(List<String> values) {
            addCriterion("MEMO_INFO not in", values, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOBetween(String value1, String value2) {
            addCriterion("MEMO_INFO between", value1, value2, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFONotBetween(String value1, String value2) {
            addCriterion("MEMO_INFO not between", value1, value2, "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSIsNull() {
            addCriterion("REMOTE_MAINTENANCE_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSIsNotNull() {
            addCriterion("REMOTE_MAINTENANCE_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSEqualTo(String value) {
            addCriterion("REMOTE_MAINTENANCE_STATUS =", value, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSNotEqualTo(String value) {
            addCriterion("REMOTE_MAINTENANCE_STATUS <>", value, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSGreaterThan(String value) {
            addCriterion("REMOTE_MAINTENANCE_STATUS >", value, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSGreaterThanOrEqualTo(String value) {
            addCriterion("REMOTE_MAINTENANCE_STATUS >=", value, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSLessThan(String value) {
            addCriterion("REMOTE_MAINTENANCE_STATUS <", value, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSLessThanOrEqualTo(String value) {
            addCriterion("REMOTE_MAINTENANCE_STATUS <=", value, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSLike(String value) {
            addCriterion("REMOTE_MAINTENANCE_STATUS like", value, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSNotLike(String value) {
            addCriterion("REMOTE_MAINTENANCE_STATUS not like", value, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSIn(List<String> values) {
            addCriterion("REMOTE_MAINTENANCE_STATUS in", values, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSNotIn(List<String> values) {
            addCriterion("REMOTE_MAINTENANCE_STATUS not in", values, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSBetween(String value1, String value2) {
            addCriterion("REMOTE_MAINTENANCE_STATUS between", value1, value2, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSNotBetween(String value1, String value2) {
            addCriterion("REMOTE_MAINTENANCE_STATUS not between", value1, value2, "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCIsNull() {
            addCriterion("TANTO_GC is null");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCIsNotNull() {
            addCriterion("TANTO_GC is not null");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCEqualTo(String value) {
            addCriterion("TANTO_GC =", value, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCNotEqualTo(String value) {
            addCriterion("TANTO_GC <>", value, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCGreaterThan(String value) {
            addCriterion("TANTO_GC >", value, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCGreaterThanOrEqualTo(String value) {
            addCriterion("TANTO_GC >=", value, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCLessThan(String value) {
            addCriterion("TANTO_GC <", value, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCLessThanOrEqualTo(String value) {
            addCriterion("TANTO_GC <=", value, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCLike(String value) {
            addCriterion("TANTO_GC like", value, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCNotLike(String value) {
            addCriterion("TANTO_GC not like", value, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCIn(List<String> values) {
            addCriterion("TANTO_GC in", values, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCNotIn(List<String> values) {
            addCriterion("TANTO_GC not in", values, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCBetween(String value1, String value2) {
            addCriterion("TANTO_GC between", value1, value2, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCNotBetween(String value1, String value2) {
            addCriterion("TANTO_GC not between", value1, value2, "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIsNull() {
            addCriterion("BUZZ_FLG is null");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIsNotNull() {
            addCriterion("BUZZ_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGEqualTo(String value) {
            addCriterion("BUZZ_FLG =", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotEqualTo(String value) {
            addCriterion("BUZZ_FLG <>", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGGreaterThan(String value) {
            addCriterion("BUZZ_FLG >", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("BUZZ_FLG >=", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLessThan(String value) {
            addCriterion("BUZZ_FLG <", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLessThanOrEqualTo(String value) {
            addCriterion("BUZZ_FLG <=", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLike(String value) {
            addCriterion("BUZZ_FLG like", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotLike(String value) {
            addCriterion("BUZZ_FLG not like", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIn(List<String> values) {
            addCriterion("BUZZ_FLG in", values, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotIn(List<String> values) {
            addCriterion("BUZZ_FLG not in", values, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGBetween(String value1, String value2) {
            addCriterion("BUZZ_FLG between", value1, value2, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotBetween(String value1, String value2) {
            addCriterion("BUZZ_FLG not between", value1, value2, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGIsNull() {
            addCriterion("GSHS_FLG is null");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGIsNotNull() {
            addCriterion("GSHS_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGEqualTo(String value) {
            addCriterion("GSHS_FLG =", value, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGNotEqualTo(String value) {
            addCriterion("GSHS_FLG <>", value, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGGreaterThan(String value) {
            addCriterion("GSHS_FLG >", value, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("GSHS_FLG >=", value, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGLessThan(String value) {
            addCriterion("GSHS_FLG <", value, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGLessThanOrEqualTo(String value) {
            addCriterion("GSHS_FLG <=", value, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGLike(String value) {
            addCriterion("GSHS_FLG like", value, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGNotLike(String value) {
            addCriterion("GSHS_FLG not like", value, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGIn(List<String> values) {
            addCriterion("GSHS_FLG in", values, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGNotIn(List<String> values) {
            addCriterion("GSHS_FLG not in", values, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGBetween(String value1, String value2) {
            addCriterion("GSHS_FLG between", value1, value2, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGNotBetween(String value1, String value2) {
            addCriterion("GSHS_FLG not between", value1, value2, "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_K_JIAN_OVERVIEWLikeInsensitive(String value) {
            addCriterion("upper(LN_K_JIAN_OVERVIEW) like", value.toUpperCase(), "LN_K_JIAN_OVERVIEW");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLikeInsensitive(String value) {
            addCriterion("upper(SYS_KBN) like", value.toUpperCase(), "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_KBNLikeInsensitive(String value) {
            addCriterion("upper(SINPO_HANDAN_KBN) like", value.toUpperCase(), "SINPO_HANDAN_KBN");
            return (Criteria) this;
        }

        public Criteria andIMAGE_GET_STSLikeInsensitive(String value) {
            addCriterion("upper(IMAGE_GET_STS) like", value.toUpperCase(), "IMAGE_GET_STS");
            return (Criteria) this;
        }

        public Criteria andJITAILikeInsensitive(String value) {
            addCriterion("upper(JITAI) like", value.toUpperCase(), "JITAI");
            return (Criteria) this;
        }

        public Criteria andGCLikeInsensitive(String value) {
            addCriterion("upper(GC) like", value.toUpperCase(), "GC");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_CUSTOMER_MARKLikeInsensitive(String value) {
            addCriterion("upper(IMPORTANT_CUSTOMER_MARK) like", value.toUpperCase(), "IMPORTANT_CUSTOMER_MARK");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUMLikeInsensitive(String value) {
            addCriterion("upper(CUSTOMER_NUM) like", value.toUpperCase(), "CUSTOMER_NUM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NUMLikeInsensitive(String value) {
            addCriterion("upper(CHIKU_NUM) like", value.toUpperCase(), "CHIKU_NUM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBRLikeInsensitive(String value) {
            addCriterion("upper(KEIBISAKI_ABBR) like", value.toUpperCase(), "KEIBISAKI_ABBR");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_CHIKU_ABBRLikeInsensitive(String value) {
            addCriterion("upper(KEIBISAKI_CHIKU_ABBR) like", value.toUpperCase(), "KEIBISAKI_CHIKU_ABBR");
            return (Criteria) this;
        }

        public Criteria andRECEPTION_INFOLikeInsensitive(String value) {
            addCriterion("upper(RECEPTION_INFO) like", value.toUpperCase(), "RECEPTION_INFO");
            return (Criteria) this;
        }

        public Criteria andLAST_SIGLikeInsensitive(String value) {
            addCriterion("upper(LAST_SIG) like", value.toUpperCase(), "LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andNF_SIGLikeInsensitive(String value) {
            addCriterion("upper(NF_SIG) like", value.toUpperCase(), "NF_SIG");
            return (Criteria) this;
        }

        public Criteria andMEMO_UMU_FLGLikeInsensitive(String value) {
            addCriterion("upper(MEMO_UMU_FLG) like", value.toUpperCase(), "MEMO_UMU_FLG");
            return (Criteria) this;
        }

        public Criteria andMEMO_INFOLikeInsensitive(String value) {
            addCriterion("upper(MEMO_INFO) like", value.toUpperCase(), "MEMO_INFO");
            return (Criteria) this;
        }

        public Criteria andREMOTE_MAINTENANCE_STATUSLikeInsensitive(String value) {
            addCriterion("upper(REMOTE_MAINTENANCE_STATUS) like", value.toUpperCase(), "REMOTE_MAINTENANCE_STATUS");
            return (Criteria) this;
        }

        public Criteria andTANTO_GCLikeInsensitive(String value) {
            addCriterion("upper(TANTO_GC) like", value.toUpperCase(), "TANTO_GC");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLikeInsensitive(String value) {
            addCriterion("upper(BUZZ_FLG) like", value.toUpperCase(), "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andGSHS_FLGLikeInsensitive(String value) {
            addCriterion("upper(GSHS_FLG) like", value.toUpperCase(), "GSHS_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * K_JIAN_OVERVIEW
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * K_JIAN_OVERVIEW null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}