package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MFxSmsWithBLOBs extends MFxSms implements Serializable {
    /**
     * 本文1
     */
    private String BODY1;

    /**
     * 本文2
     */
    private String BODY2;

    /**
     * 本文3
     */
    private String BODY3;

    /**
     * M_FX_SMS
     */
    private static final long serialVersionUID = 1L;

    /**
     * 本文1
     * @return BODY1 本文1
     */
    public String getBODY1() {
        return BODY1;
    }

    /**
     * 本文1
     * @param BODY1 本文1
     */
    public void setBODY1(String BODY1) {
        this.BODY1 = BODY1 == null ? null : BODY1.trim();
    }

    /**
     * 本文2
     * @return BODY2 本文2
     */
    public String getBODY2() {
        return BODY2;
    }

    /**
     * 本文2
     * @param BODY2 本文2
     */
    public void setBODY2(String BODY2) {
        this.BODY2 = BODY2 == null ? null : BODY2.trim();
    }

    /**
     * 本文3
     * @return BODY3 本文3
     */
    public String getBODY3() {
        return BODY3;
    }

    /**
     * 本文3
     * @param BODY3 本文3
     */
    public void setBODY3(String BODY3) {
        this.BODY3 = BODY3 == null ? null : BODY3.trim();
    }
}