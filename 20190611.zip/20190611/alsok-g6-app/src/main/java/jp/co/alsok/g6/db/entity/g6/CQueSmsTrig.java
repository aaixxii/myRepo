package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CQueSmsTrig implements Serializable {
    /**
     * LN_配信トリガ論理番号
     */
    private String LN_SMS_TRIG;

    /**
     * 種別
     */
    private String KIND;

    /**
     * 状態
     */
    private String STS;

    /**
     * LN_警備情報論理番号
     */
    private String LN_KB_INF;

    /**
     * 送信可能日時
     */
    private Date SEND_ABL_TS;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * LN_入居管理論理番号
     */
    private String LN_TENANT_MNG;

    /**
     * 警備先名称
     */
    private String KEIBI_NM;

    /**
     * 信号名称
     */
    private String SIG_DTL_NM;

    /**
     * 信号発生日時
     */
    private Date SIG_HASSEI_TS;

    /**
     * SD_個別名称
     */
    private String SD_KOBETU_NM;

    /**
     * 装置名称
     */
    private String DEV_NM;

    /**
     * 操作者
     */
    private String OPERATION_USER;

    /**
     * リモート種別
     */
    private String RM_KIND;

    /**
     * 見守り対象先
     */
    private String WATCH_TGT;

    /**
     * 事業所名称
     */
    private String JIGYOU_NM;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * LN_ALSOKお知らせ論理番号
     */
    private String LN_ALSOK_NOTICE;

    /**
     * ALSOKお知らせメール送信対象サービス種別
     */
    private String ALSOK_NOTICE_SEND_SVC_KIND;

    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * LN_処理対象論理番号
     */
    private String LN_SEND_TGT;

    /**
     * 宛先ファイル名
     */
    private String FILE_NM_TO;

    /**
     * 宛先取得区分
     */
    private String GET_KIND_TO;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * SD_警備エリア名称
     */
    private String SD_KB_AREA_NM;

    /**
     * C_QUE_SMS_TRIG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_配信トリガ論理番号
     * @return LN_SMS_TRIG LN_配信トリガ論理番号
     */
    public String getLN_SMS_TRIG() {
        return LN_SMS_TRIG;
    }

    /**
     * LN_配信トリガ論理番号
     * @param LN_SMS_TRIG LN_配信トリガ論理番号
     */
    public void setLN_SMS_TRIG(String LN_SMS_TRIG) {
        this.LN_SMS_TRIG = LN_SMS_TRIG == null ? null : LN_SMS_TRIG.trim();
    }

    /**
     * 種別
     * @return KIND 種別
     */
    public String getKIND() {
        return KIND;
    }

    /**
     * 種別
     * @param KIND 種別
     */
    public void setKIND(String KIND) {
        this.KIND = KIND == null ? null : KIND.trim();
    }

    /**
     * 状態
     * @return STS 状態
     */
    public String getSTS() {
        return STS;
    }

    /**
     * 状態
     * @param STS 状態
     */
    public void setSTS(String STS) {
        this.STS = STS == null ? null : STS.trim();
    }

    /**
     * LN_警備情報論理番号
     * @return LN_KB_INF LN_警備情報論理番号
     */
    public String getLN_KB_INF() {
        return LN_KB_INF;
    }

    /**
     * LN_警備情報論理番号
     * @param LN_KB_INF LN_警備情報論理番号
     */
    public void setLN_KB_INF(String LN_KB_INF) {
        this.LN_KB_INF = LN_KB_INF == null ? null : LN_KB_INF.trim();
    }

    /**
     * 送信可能日時
     * @return SEND_ABL_TS 送信可能日時
     */
    public Date getSEND_ABL_TS() {
        return SEND_ABL_TS;
    }

    /**
     * 送信可能日時
     * @param SEND_ABL_TS 送信可能日時
     */
    public void setSEND_ABL_TS(Date SEND_ABL_TS) {
        this.SEND_ABL_TS = SEND_ABL_TS;
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * LN_入居管理論理番号
     * @return LN_TENANT_MNG LN_入居管理論理番号
     */
    public String getLN_TENANT_MNG() {
        return LN_TENANT_MNG;
    }

    /**
     * LN_入居管理論理番号
     * @param LN_TENANT_MNG LN_入居管理論理番号
     */
    public void setLN_TENANT_MNG(String LN_TENANT_MNG) {
        this.LN_TENANT_MNG = LN_TENANT_MNG == null ? null : LN_TENANT_MNG.trim();
    }

    /**
     * 警備先名称
     * @return KEIBI_NM 警備先名称
     */
    public String getKEIBI_NM() {
        return KEIBI_NM;
    }

    /**
     * 警備先名称
     * @param KEIBI_NM 警備先名称
     */
    public void setKEIBI_NM(String KEIBI_NM) {
        this.KEIBI_NM = KEIBI_NM == null ? null : KEIBI_NM.trim();
    }

    /**
     * 信号名称
     * @return SIG_DTL_NM 信号名称
     */
    public String getSIG_DTL_NM() {
        return SIG_DTL_NM;
    }

    /**
     * 信号名称
     * @param SIG_DTL_NM 信号名称
     */
    public void setSIG_DTL_NM(String SIG_DTL_NM) {
        this.SIG_DTL_NM = SIG_DTL_NM == null ? null : SIG_DTL_NM.trim();
    }

    /**
     * 信号発生日時
     * @return SIG_HASSEI_TS 信号発生日時
     */
    public Date getSIG_HASSEI_TS() {
        return SIG_HASSEI_TS;
    }

    /**
     * 信号発生日時
     * @param SIG_HASSEI_TS 信号発生日時
     */
    public void setSIG_HASSEI_TS(Date SIG_HASSEI_TS) {
        this.SIG_HASSEI_TS = SIG_HASSEI_TS;
    }

    /**
     * SD_個別名称
     * @return SD_KOBETU_NM SD_個別名称
     */
    public String getSD_KOBETU_NM() {
        return SD_KOBETU_NM;
    }

    /**
     * SD_個別名称
     * @param SD_KOBETU_NM SD_個別名称
     */
    public void setSD_KOBETU_NM(String SD_KOBETU_NM) {
        this.SD_KOBETU_NM = SD_KOBETU_NM == null ? null : SD_KOBETU_NM.trim();
    }

    /**
     * 装置名称
     * @return DEV_NM 装置名称
     */
    public String getDEV_NM() {
        return DEV_NM;
    }

    /**
     * 装置名称
     * @param DEV_NM 装置名称
     */
    public void setDEV_NM(String DEV_NM) {
        this.DEV_NM = DEV_NM == null ? null : DEV_NM.trim();
    }

    /**
     * 操作者
     * @return OPERATION_USER 操作者
     */
    public String getOPERATION_USER() {
        return OPERATION_USER;
    }

    /**
     * 操作者
     * @param OPERATION_USER 操作者
     */
    public void setOPERATION_USER(String OPERATION_USER) {
        this.OPERATION_USER = OPERATION_USER == null ? null : OPERATION_USER.trim();
    }

    /**
     * リモート種別
     * @return RM_KIND リモート種別
     */
    public String getRM_KIND() {
        return RM_KIND;
    }

    /**
     * リモート種別
     * @param RM_KIND リモート種別
     */
    public void setRM_KIND(String RM_KIND) {
        this.RM_KIND = RM_KIND == null ? null : RM_KIND.trim();
    }

    /**
     * 見守り対象先
     * @return WATCH_TGT 見守り対象先
     */
    public String getWATCH_TGT() {
        return WATCH_TGT;
    }

    /**
     * 見守り対象先
     * @param WATCH_TGT 見守り対象先
     */
    public void setWATCH_TGT(String WATCH_TGT) {
        this.WATCH_TGT = WATCH_TGT == null ? null : WATCH_TGT.trim();
    }

    /**
     * 事業所名称
     * @return JIGYOU_NM 事業所名称
     */
    public String getJIGYOU_NM() {
        return JIGYOU_NM;
    }

    /**
     * 事業所名称
     * @param JIGYOU_NM 事業所名称
     */
    public void setJIGYOU_NM(String JIGYOU_NM) {
        this.JIGYOU_NM = JIGYOU_NM == null ? null : JIGYOU_NM.trim();
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * LN_ALSOKお知らせ論理番号
     * @return LN_ALSOK_NOTICE LN_ALSOKお知らせ論理番号
     */
    public String getLN_ALSOK_NOTICE() {
        return LN_ALSOK_NOTICE;
    }

    /**
     * LN_ALSOKお知らせ論理番号
     * @param LN_ALSOK_NOTICE LN_ALSOKお知らせ論理番号
     */
    public void setLN_ALSOK_NOTICE(String LN_ALSOK_NOTICE) {
        this.LN_ALSOK_NOTICE = LN_ALSOK_NOTICE == null ? null : LN_ALSOK_NOTICE.trim();
    }

    /**
     * ALSOKお知らせメール送信対象サービス種別
     * @return ALSOK_NOTICE_SEND_SVC_KIND ALSOKお知らせメール送信対象サービス種別
     */
    public String getALSOK_NOTICE_SEND_SVC_KIND() {
        return ALSOK_NOTICE_SEND_SVC_KIND;
    }

    /**
     * ALSOKお知らせメール送信対象サービス種別
     * @param ALSOK_NOTICE_SEND_SVC_KIND ALSOKお知らせメール送信対象サービス種別
     */
    public void setALSOK_NOTICE_SEND_SVC_KIND(String ALSOK_NOTICE_SEND_SVC_KIND) {
        this.ALSOK_NOTICE_SEND_SVC_KIND = ALSOK_NOTICE_SEND_SVC_KIND == null ? null : ALSOK_NOTICE_SEND_SVC_KIND.trim();
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * LN_処理対象論理番号
     * @return LN_SEND_TGT LN_処理対象論理番号
     */
    public String getLN_SEND_TGT() {
        return LN_SEND_TGT;
    }

    /**
     * LN_処理対象論理番号
     * @param LN_SEND_TGT LN_処理対象論理番号
     */
    public void setLN_SEND_TGT(String LN_SEND_TGT) {
        this.LN_SEND_TGT = LN_SEND_TGT == null ? null : LN_SEND_TGT.trim();
    }

    /**
     * 宛先ファイル名
     * @return FILE_NM_TO 宛先ファイル名
     */
    public String getFILE_NM_TO() {
        return FILE_NM_TO;
    }

    /**
     * 宛先ファイル名
     * @param FILE_NM_TO 宛先ファイル名
     */
    public void setFILE_NM_TO(String FILE_NM_TO) {
        this.FILE_NM_TO = FILE_NM_TO == null ? null : FILE_NM_TO.trim();
    }

    /**
     * 宛先取得区分
     * @return GET_KIND_TO 宛先取得区分
     */
    public String getGET_KIND_TO() {
        return GET_KIND_TO;
    }

    /**
     * 宛先取得区分
     * @param GET_KIND_TO 宛先取得区分
     */
    public void setGET_KIND_TO(String GET_KIND_TO) {
        this.GET_KIND_TO = GET_KIND_TO == null ? null : GET_KIND_TO.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * SD_警備エリア名称
     * @return SD_KB_AREA_NM SD_警備エリア名称
     */
    public String getSD_KB_AREA_NM() {
        return SD_KB_AREA_NM;
    }

    /**
     * SD_警備エリア名称
     * @param SD_KB_AREA_NM SD_警備エリア名称
     */
    public void setSD_KB_AREA_NM(String SD_KB_AREA_NM) {
        this.SD_KB_AREA_NM = SD_KB_AREA_NM == null ? null : SD_KB_AREA_NM.trim();
    }
}