package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HDenkeiUpdate implements Serializable {
    /**
     * LN_電計番号変更論理番号
     */
    private String LN_DENKEI_UPDATE;

    /**
     * LN_制御装置論理番号
     */
    private String LN_CTL_DEV;

    /**
     * 変更区分
     */
    private String UPDATE_KBN;

    /**
     * 旧電計番号
     */
    private String DENKEI_OLD;

    /**
     * 新電計番号
     */
    private String DENKEI_NEW;

    /**
     * 状態フラグ
     */
    private String STATUS_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_DENKEI_UPDATE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_電計番号変更論理番号
     * @return LN_DENKEI_UPDATE LN_電計番号変更論理番号
     */
    public String getLN_DENKEI_UPDATE() {
        return LN_DENKEI_UPDATE;
    }

    /**
     * LN_電計番号変更論理番号
     * @param LN_DENKEI_UPDATE LN_電計番号変更論理番号
     */
    public void setLN_DENKEI_UPDATE(String LN_DENKEI_UPDATE) {
        this.LN_DENKEI_UPDATE = LN_DENKEI_UPDATE == null ? null : LN_DENKEI_UPDATE.trim();
    }

    /**
     * LN_制御装置論理番号
     * @return LN_CTL_DEV LN_制御装置論理番号
     */
    public String getLN_CTL_DEV() {
        return LN_CTL_DEV;
    }

    /**
     * LN_制御装置論理番号
     * @param LN_CTL_DEV LN_制御装置論理番号
     */
    public void setLN_CTL_DEV(String LN_CTL_DEV) {
        this.LN_CTL_DEV = LN_CTL_DEV == null ? null : LN_CTL_DEV.trim();
    }

    /**
     * 変更区分
     * @return UPDATE_KBN 変更区分
     */
    public String getUPDATE_KBN() {
        return UPDATE_KBN;
    }

    /**
     * 変更区分
     * @param UPDATE_KBN 変更区分
     */
    public void setUPDATE_KBN(String UPDATE_KBN) {
        this.UPDATE_KBN = UPDATE_KBN == null ? null : UPDATE_KBN.trim();
    }

    /**
     * 旧電計番号
     * @return DENKEI_OLD 旧電計番号
     */
    public String getDENKEI_OLD() {
        return DENKEI_OLD;
    }

    /**
     * 旧電計番号
     * @param DENKEI_OLD 旧電計番号
     */
    public void setDENKEI_OLD(String DENKEI_OLD) {
        this.DENKEI_OLD = DENKEI_OLD == null ? null : DENKEI_OLD.trim();
    }

    /**
     * 新電計番号
     * @return DENKEI_NEW 新電計番号
     */
    public String getDENKEI_NEW() {
        return DENKEI_NEW;
    }

    /**
     * 新電計番号
     * @param DENKEI_NEW 新電計番号
     */
    public void setDENKEI_NEW(String DENKEI_NEW) {
        this.DENKEI_NEW = DENKEI_NEW == null ? null : DENKEI_NEW.trim();
    }

    /**
     * 状態フラグ
     * @return STATUS_FLG 状態フラグ
     */
    public String getSTATUS_FLG() {
        return STATUS_FLG;
    }

    /**
     * 状態フラグ
     * @param STATUS_FLG 状態フラグ
     */
    public void setSTATUS_FLG(String STATUS_FLG) {
        this.STATUS_FLG = STATUS_FLG == null ? null : STATUS_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}