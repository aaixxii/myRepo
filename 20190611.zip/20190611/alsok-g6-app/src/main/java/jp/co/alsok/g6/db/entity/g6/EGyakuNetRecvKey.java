package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class EGyakuNetRecvKey implements Serializable {
    /**
     * システム区分
     */
    private String SYS_KBN;

    /**
     * 送信元業務コード
     */
    private String SRC_GYOUMU_CD;

    /**
     * 送信元ホスト番号
     */
    private String SRC_HOST_NUM;

    /**
     * 受信日付
     */
    private String HASSEI_TS;

    /**
     * プログラム識別子
     */
    private String PROGRAM_ID;

    /**
     * 通番
     */
    private String SEQ_NUM;

    /**
     * E_GYAKU_NET_RECV
     */
    private static final long serialVersionUID = 1L;

    /**
     * システム区分
     * @return SYS_KBN システム区分
     */
    public String getSYS_KBN() {
        return SYS_KBN;
    }

    /**
     * システム区分
     * @param SYS_KBN システム区分
     */
    public void setSYS_KBN(String SYS_KBN) {
        this.SYS_KBN = SYS_KBN == null ? null : SYS_KBN.trim();
    }

    /**
     * 送信元業務コード
     * @return SRC_GYOUMU_CD 送信元業務コード
     */
    public String getSRC_GYOUMU_CD() {
        return SRC_GYOUMU_CD;
    }

    /**
     * 送信元業務コード
     * @param SRC_GYOUMU_CD 送信元業務コード
     */
    public void setSRC_GYOUMU_CD(String SRC_GYOUMU_CD) {
        this.SRC_GYOUMU_CD = SRC_GYOUMU_CD == null ? null : SRC_GYOUMU_CD.trim();
    }

    /**
     * 送信元ホスト番号
     * @return SRC_HOST_NUM 送信元ホスト番号
     */
    public String getSRC_HOST_NUM() {
        return SRC_HOST_NUM;
    }

    /**
     * 送信元ホスト番号
     * @param SRC_HOST_NUM 送信元ホスト番号
     */
    public void setSRC_HOST_NUM(String SRC_HOST_NUM) {
        this.SRC_HOST_NUM = SRC_HOST_NUM == null ? null : SRC_HOST_NUM.trim();
    }

    /**
     * 受信日付
     * @return HASSEI_TS 受信日付
     */
    public String getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 受信日付
     * @param HASSEI_TS 受信日付
     */
    public void setHASSEI_TS(String HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS == null ? null : HASSEI_TS.trim();
    }

    /**
     * プログラム識別子
     * @return PROGRAM_ID プログラム識別子
     */
    public String getPROGRAM_ID() {
        return PROGRAM_ID;
    }

    /**
     * プログラム識別子
     * @param PROGRAM_ID プログラム識別子
     */
    public void setPROGRAM_ID(String PROGRAM_ID) {
        this.PROGRAM_ID = PROGRAM_ID == null ? null : PROGRAM_ID.trim();
    }

    /**
     * 通番
     * @return SEQ_NUM 通番
     */
    public String getSEQ_NUM() {
        return SEQ_NUM;
    }

    /**
     * 通番
     * @param SEQ_NUM 通番
     */
    public void setSEQ_NUM(String SEQ_NUM) {
        this.SEQ_NUM = SEQ_NUM == null ? null : SEQ_NUM.trim();
    }
}