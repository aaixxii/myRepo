package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class MMlExample {
    /**
     * M_ML
     */
    protected String orderByClause;

    /**
     * M_ML
     */
    protected boolean distinct;

    /**
     * M_ML
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MMlExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_ML null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCTime(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Time(value.getTime()), property);
        }

        protected void addCriterionForJDBCTime(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Time> timeList = new ArrayList<java.sql.Time>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                timeList.add(new java.sql.Time(iter.next().getTime()));
            }
            addCriterion(condition, timeList, property);
        }

        protected void addCriterionForJDBCTime(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Time(value1.getTime()), new java.sql.Time(value2.getTime()), property);
        }

        public Criteria andKINDIsNull() {
            addCriterion("KIND is null");
            return (Criteria) this;
        }

        public Criteria andKINDIsNotNull() {
            addCriterion("KIND is not null");
            return (Criteria) this;
        }

        public Criteria andKINDEqualTo(String value) {
            addCriterion("KIND =", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotEqualTo(String value) {
            addCriterion("KIND <>", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThan(String value) {
            addCriterion("KIND >", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThanOrEqualTo(String value) {
            addCriterion("KIND >=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThan(String value) {
            addCriterion("KIND <", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThanOrEqualTo(String value) {
            addCriterion("KIND <=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLike(String value) {
            addCriterion("KIND like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotLike(String value) {
            addCriterion("KIND not like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDIn(List<String> values) {
            addCriterion("KIND in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotIn(List<String> values) {
            addCriterion("KIND not in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDBetween(String value1, String value2) {
            addCriterion("KIND between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotBetween(String value1, String value2) {
            addCriterion("KIND not between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIsNull() {
            addCriterion("PRIORITY is null");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIsNotNull() {
            addCriterion("PRIORITY is not null");
            return (Criteria) this;
        }

        public Criteria andPRIORITYEqualTo(String value) {
            addCriterion("PRIORITY =", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotEqualTo(String value) {
            addCriterion("PRIORITY <>", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYGreaterThan(String value) {
            addCriterion("PRIORITY >", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYGreaterThanOrEqualTo(String value) {
            addCriterion("PRIORITY >=", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLessThan(String value) {
            addCriterion("PRIORITY <", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLessThanOrEqualTo(String value) {
            addCriterion("PRIORITY <=", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLike(String value) {
            addCriterion("PRIORITY like", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotLike(String value) {
            addCriterion("PRIORITY not like", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIn(List<String> values) {
            addCriterion("PRIORITY in", values, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotIn(List<String> values) {
            addCriterion("PRIORITY not in", values, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYBetween(String value1, String value2) {
            addCriterion("PRIORITY between", value1, value2, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotBetween(String value1, String value2) {
            addCriterion("PRIORITY not between", value1, value2, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMIsNull() {
            addCriterion("MAX_RETRY_NUM is null");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMIsNotNull() {
            addCriterion("MAX_RETRY_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMEqualTo(String value) {
            addCriterion("MAX_RETRY_NUM =", value, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMNotEqualTo(String value) {
            addCriterion("MAX_RETRY_NUM <>", value, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMGreaterThan(String value) {
            addCriterion("MAX_RETRY_NUM >", value, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("MAX_RETRY_NUM >=", value, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMLessThan(String value) {
            addCriterion("MAX_RETRY_NUM <", value, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMLessThanOrEqualTo(String value) {
            addCriterion("MAX_RETRY_NUM <=", value, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMLike(String value) {
            addCriterion("MAX_RETRY_NUM like", value, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMNotLike(String value) {
            addCriterion("MAX_RETRY_NUM not like", value, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMIn(List<String> values) {
            addCriterion("MAX_RETRY_NUM in", values, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMNotIn(List<String> values) {
            addCriterion("MAX_RETRY_NUM not in", values, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMBetween(String value1, String value2) {
            addCriterion("MAX_RETRY_NUM between", value1, value2, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMNotBetween(String value1, String value2) {
            addCriterion("MAX_RETRY_NUM not between", value1, value2, "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTIsNull() {
            addCriterion("RETRY_INT is null");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTIsNotNull() {
            addCriterion("RETRY_INT is not null");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTEqualTo(Integer value) {
            addCriterion("RETRY_INT =", value, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTNotEqualTo(Integer value) {
            addCriterion("RETRY_INT <>", value, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTGreaterThan(Integer value) {
            addCriterion("RETRY_INT >", value, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTGreaterThanOrEqualTo(Integer value) {
            addCriterion("RETRY_INT >=", value, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTLessThan(Integer value) {
            addCriterion("RETRY_INT <", value, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTLessThanOrEqualTo(Integer value) {
            addCriterion("RETRY_INT <=", value, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTIn(List<Integer> values) {
            addCriterion("RETRY_INT in", values, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTNotIn(List<Integer> values) {
            addCriterion("RETRY_INT not in", values, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTBetween(Integer value1, Integer value2) {
            addCriterion("RETRY_INT between", value1, value2, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andRETRY_INTNotBetween(Integer value1, Integer value2) {
            addCriterion("RETRY_INT not between", value1, value2, "RETRY_INT");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMIsNull() {
            addCriterion("SEND_ABL_FROM_TM is null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMIsNotNull() {
            addCriterion("SEND_ABL_FROM_TM is not null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMEqualTo(Date value) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM =", value, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMNotEqualTo(Date value) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM <>", value, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMGreaterThan(Date value) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM >", value, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM >=", value, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMLessThan(Date value) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM <", value, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMLessThanOrEqualTo(Date value) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM <=", value, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMIn(List<Date> values) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM in", values, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMNotIn(List<Date> values) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM not in", values, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMBetween(Date value1, Date value2) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM between", value1, value2, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_FROM_TMNotBetween(Date value1, Date value2) {
            addCriterionForJDBCTime("SEND_ABL_FROM_TM not between", value1, value2, "SEND_ABL_FROM_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMIsNull() {
            addCriterion("SEND_ABL_TO_TM is null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMIsNotNull() {
            addCriterion("SEND_ABL_TO_TM is not null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMEqualTo(Date value) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM =", value, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMNotEqualTo(Date value) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM <>", value, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMGreaterThan(Date value) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM >", value, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM >=", value, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMLessThan(Date value) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM <", value, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMLessThanOrEqualTo(Date value) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM <=", value, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMIn(List<Date> values) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM in", values, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMNotIn(List<Date> values) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM not in", values, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMBetween(Date value1, Date value2) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM between", value1, value2, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TO_TMNotBetween(Date value1, Date value2) {
            addCriterionForJDBCTime("SEND_ABL_TO_TM not between", value1, value2, "SEND_ABL_TO_TM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMIsNull() {
            addCriterion("ML_ADDR_FROM is null");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMIsNotNull() {
            addCriterion("ML_ADDR_FROM is not null");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMEqualTo(String value) {
            addCriterion("ML_ADDR_FROM =", value, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMNotEqualTo(String value) {
            addCriterion("ML_ADDR_FROM <>", value, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMGreaterThan(String value) {
            addCriterion("ML_ADDR_FROM >", value, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMGreaterThanOrEqualTo(String value) {
            addCriterion("ML_ADDR_FROM >=", value, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMLessThan(String value) {
            addCriterion("ML_ADDR_FROM <", value, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMLessThanOrEqualTo(String value) {
            addCriterion("ML_ADDR_FROM <=", value, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMLike(String value) {
            addCriterion("ML_ADDR_FROM like", value, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMNotLike(String value) {
            addCriterion("ML_ADDR_FROM not like", value, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMIn(List<String> values) {
            addCriterion("ML_ADDR_FROM in", values, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMNotIn(List<String> values) {
            addCriterion("ML_ADDR_FROM not in", values, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMBetween(String value1, String value2) {
            addCriterion("ML_ADDR_FROM between", value1, value2, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMNotBetween(String value1, String value2) {
            addCriterion("ML_ADDR_FROM not between", value1, value2, "ML_ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andKINDLikeInsensitive(String value) {
            addCriterion("upper(KIND) like", value.toUpperCase(), "KIND");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLikeInsensitive(String value) {
            addCriterion("upper(PRIORITY) like", value.toUpperCase(), "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andMAX_RETRY_NUMLikeInsensitive(String value) {
            addCriterion("upper(MAX_RETRY_NUM) like", value.toUpperCase(), "MAX_RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_FROMLikeInsensitive(String value) {
            addCriterion("upper(ML_ADDR_FROM) like", value.toUpperCase(), "ML_ADDR_FROM");
            return (Criteria) this;
        }
    }

    /**
     * M_ML
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_ML null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}