package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KJianOverview extends KJianOverviewKey implements Serializable {
    /**
     * 真報判断区分
     */
    private String SINPO_HANDAN_KBN;

    /**
     * 画像取得状態
     */
    private String IMAGE_GET_STS;

    /**
     * タイムアウト有無フラグ
     */
    private Date TIMEOUT_UMU_FLG;

    /**
     * 事態
     */
    private String JITAI;

    /**
     * GC
     */
    private String GC;

    /**
     * 重要顧客マーク
     */
    private String IMPORTANT_CUSTOMER_MARK;

    /**
     * お客様番号
     */
    private String CUSTOMER_NUM;

    /**
     * 地区番号
     */
    private String CHIKU_NUM;

    /**
     * 警備先略称
     */
    private String KEIBISAKI_ABBR;

    /**
     * 警備先地区略称
     */
    private String KEIBISAKI_CHIKU_ABBR;

    /**
     * 受信情報
     */
    private String RECEPTION_INFO;

    /**
     * 最新信号
     */
    private String LAST_SIG;

    /**
     * 入退館
     */
    private String NF_SIG;

    /**
     * メモ有無フラグ
     */
    private String MEMO_UMU_FLG;

    /**
     * メモ情報
     */
    private String MEMO_INFO;

    /**
     * リモメンステータス
     */
    private String REMOTE_MAINTENANCE_STATUS;

    /**
     * 担当GC
     */
    private String TANTO_GC;

    /**
     * ブザー鳴動フラグ
     */
    private String BUZZ_FLG;

    /**
     * サービス種別
     */
    private String GSHS_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_JIAN_OVERVIEW
     */
    private static final long serialVersionUID = 1L;

    /**
     * 真報判断区分
     * @return SINPO_HANDAN_KBN 真報判断区分
     */
    public String getSINPO_HANDAN_KBN() {
        return SINPO_HANDAN_KBN;
    }

    /**
     * 真報判断区分
     * @param SINPO_HANDAN_KBN 真報判断区分
     */
    public void setSINPO_HANDAN_KBN(String SINPO_HANDAN_KBN) {
        this.SINPO_HANDAN_KBN = SINPO_HANDAN_KBN == null ? null : SINPO_HANDAN_KBN.trim();
    }

    /**
     * 画像取得状態
     * @return IMAGE_GET_STS 画像取得状態
     */
    public String getIMAGE_GET_STS() {
        return IMAGE_GET_STS;
    }

    /**
     * 画像取得状態
     * @param IMAGE_GET_STS 画像取得状態
     */
    public void setIMAGE_GET_STS(String IMAGE_GET_STS) {
        this.IMAGE_GET_STS = IMAGE_GET_STS == null ? null : IMAGE_GET_STS.trim();
    }

    /**
     * タイムアウト有無フラグ
     * @return TIMEOUT_UMU_FLG タイムアウト有無フラグ
     */
    public Date getTIMEOUT_UMU_FLG() {
        return TIMEOUT_UMU_FLG;
    }

    /**
     * タイムアウト有無フラグ
     * @param TIMEOUT_UMU_FLG タイムアウト有無フラグ
     */
    public void setTIMEOUT_UMU_FLG(Date TIMEOUT_UMU_FLG) {
        this.TIMEOUT_UMU_FLG = TIMEOUT_UMU_FLG;
    }

    /**
     * 事態
     * @return JITAI 事態
     */
    public String getJITAI() {
        return JITAI;
    }

    /**
     * 事態
     * @param JITAI 事態
     */
    public void setJITAI(String JITAI) {
        this.JITAI = JITAI == null ? null : JITAI.trim();
    }

    /**
     * GC
     * @return GC GC
     */
    public String getGC() {
        return GC;
    }

    /**
     * GC
     * @param GC GC
     */
    public void setGC(String GC) {
        this.GC = GC == null ? null : GC.trim();
    }

    /**
     * 重要顧客マーク
     * @return IMPORTANT_CUSTOMER_MARK 重要顧客マーク
     */
    public String getIMPORTANT_CUSTOMER_MARK() {
        return IMPORTANT_CUSTOMER_MARK;
    }

    /**
     * 重要顧客マーク
     * @param IMPORTANT_CUSTOMER_MARK 重要顧客マーク
     */
    public void setIMPORTANT_CUSTOMER_MARK(String IMPORTANT_CUSTOMER_MARK) {
        this.IMPORTANT_CUSTOMER_MARK = IMPORTANT_CUSTOMER_MARK == null ? null : IMPORTANT_CUSTOMER_MARK.trim();
    }

    /**
     * お客様番号
     * @return CUSTOMER_NUM お客様番号
     */
    public String getCUSTOMER_NUM() {
        return CUSTOMER_NUM;
    }

    /**
     * お客様番号
     * @param CUSTOMER_NUM お客様番号
     */
    public void setCUSTOMER_NUM(String CUSTOMER_NUM) {
        this.CUSTOMER_NUM = CUSTOMER_NUM == null ? null : CUSTOMER_NUM.trim();
    }

    /**
     * 地区番号
     * @return CHIKU_NUM 地区番号
     */
    public String getCHIKU_NUM() {
        return CHIKU_NUM;
    }

    /**
     * 地区番号
     * @param CHIKU_NUM 地区番号
     */
    public void setCHIKU_NUM(String CHIKU_NUM) {
        this.CHIKU_NUM = CHIKU_NUM == null ? null : CHIKU_NUM.trim();
    }

    /**
     * 警備先略称
     * @return KEIBISAKI_ABBR 警備先略称
     */
    public String getKEIBISAKI_ABBR() {
        return KEIBISAKI_ABBR;
    }

    /**
     * 警備先略称
     * @param KEIBISAKI_ABBR 警備先略称
     */
    public void setKEIBISAKI_ABBR(String KEIBISAKI_ABBR) {
        this.KEIBISAKI_ABBR = KEIBISAKI_ABBR == null ? null : KEIBISAKI_ABBR.trim();
    }

    /**
     * 警備先地区略称
     * @return KEIBISAKI_CHIKU_ABBR 警備先地区略称
     */
    public String getKEIBISAKI_CHIKU_ABBR() {
        return KEIBISAKI_CHIKU_ABBR;
    }

    /**
     * 警備先地区略称
     * @param KEIBISAKI_CHIKU_ABBR 警備先地区略称
     */
    public void setKEIBISAKI_CHIKU_ABBR(String KEIBISAKI_CHIKU_ABBR) {
        this.KEIBISAKI_CHIKU_ABBR = KEIBISAKI_CHIKU_ABBR == null ? null : KEIBISAKI_CHIKU_ABBR.trim();
    }

    /**
     * 受信情報
     * @return RECEPTION_INFO 受信情報
     */
    public String getRECEPTION_INFO() {
        return RECEPTION_INFO;
    }

    /**
     * 受信情報
     * @param RECEPTION_INFO 受信情報
     */
    public void setRECEPTION_INFO(String RECEPTION_INFO) {
        this.RECEPTION_INFO = RECEPTION_INFO == null ? null : RECEPTION_INFO.trim();
    }

    /**
     * 最新信号
     * @return LAST_SIG 最新信号
     */
    public String getLAST_SIG() {
        return LAST_SIG;
    }

    /**
     * 最新信号
     * @param LAST_SIG 最新信号
     */
    public void setLAST_SIG(String LAST_SIG) {
        this.LAST_SIG = LAST_SIG == null ? null : LAST_SIG.trim();
    }

    /**
     * 入退館
     * @return NF_SIG 入退館
     */
    public String getNF_SIG() {
        return NF_SIG;
    }

    /**
     * 入退館
     * @param NF_SIG 入退館
     */
    public void setNF_SIG(String NF_SIG) {
        this.NF_SIG = NF_SIG == null ? null : NF_SIG.trim();
    }

    /**
     * メモ有無フラグ
     * @return MEMO_UMU_FLG メモ有無フラグ
     */
    public String getMEMO_UMU_FLG() {
        return MEMO_UMU_FLG;
    }

    /**
     * メモ有無フラグ
     * @param MEMO_UMU_FLG メモ有無フラグ
     */
    public void setMEMO_UMU_FLG(String MEMO_UMU_FLG) {
        this.MEMO_UMU_FLG = MEMO_UMU_FLG == null ? null : MEMO_UMU_FLG.trim();
    }

    /**
     * メモ情報
     * @return MEMO_INFO メモ情報
     */
    public String getMEMO_INFO() {
        return MEMO_INFO;
    }

    /**
     * メモ情報
     * @param MEMO_INFO メモ情報
     */
    public void setMEMO_INFO(String MEMO_INFO) {
        this.MEMO_INFO = MEMO_INFO == null ? null : MEMO_INFO.trim();
    }

    /**
     * リモメンステータス
     * @return REMOTE_MAINTENANCE_STATUS リモメンステータス
     */
    public String getREMOTE_MAINTENANCE_STATUS() {
        return REMOTE_MAINTENANCE_STATUS;
    }

    /**
     * リモメンステータス
     * @param REMOTE_MAINTENANCE_STATUS リモメンステータス
     */
    public void setREMOTE_MAINTENANCE_STATUS(String REMOTE_MAINTENANCE_STATUS) {
        this.REMOTE_MAINTENANCE_STATUS = REMOTE_MAINTENANCE_STATUS == null ? null : REMOTE_MAINTENANCE_STATUS.trim();
    }

    /**
     * 担当GC
     * @return TANTO_GC 担当GC
     */
    public String getTANTO_GC() {
        return TANTO_GC;
    }

    /**
     * 担当GC
     * @param TANTO_GC 担当GC
     */
    public void setTANTO_GC(String TANTO_GC) {
        this.TANTO_GC = TANTO_GC == null ? null : TANTO_GC.trim();
    }

    /**
     * ブザー鳴動フラグ
     * @return BUZZ_FLG ブザー鳴動フラグ
     */
    public String getBUZZ_FLG() {
        return BUZZ_FLG;
    }

    /**
     * ブザー鳴動フラグ
     * @param BUZZ_FLG ブザー鳴動フラグ
     */
    public void setBUZZ_FLG(String BUZZ_FLG) {
        this.BUZZ_FLG = BUZZ_FLG == null ? null : BUZZ_FLG.trim();
    }

    /**
     * サービス種別
     * @return GSHS_FLG サービス種別
     */
    public String getGSHS_FLG() {
        return GSHS_FLG;
    }

    /**
     * サービス種別
     * @param GSHS_FLG サービス種別
     */
    public void setGSHS_FLG(String GSHS_FLG) {
        this.GSHS_FLG = GSHS_FLG == null ? null : GSHS_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}