package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;

public class KAcntUserCommonAcntUserKey implements Serializable {
    /**
     * LN_アカウント論理番号
     */
    private String LN_ACNT_USER;

    /**
     * アカウント種別
     */
    private String ACNT_KIND;

    /**
     * K_ACNT_USER_COMMON_ACNT_USER
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_アカウント論理番号
     * @return LN_ACNT_USER LN_アカウント論理番号
     */
    public String getLN_ACNT_USER() {
        return LN_ACNT_USER;
    }

    /**
     * LN_アカウント論理番号
     * @param LN_ACNT_USER LN_アカウント論理番号
     */
    public void setLN_ACNT_USER(String LN_ACNT_USER) {
        this.LN_ACNT_USER = LN_ACNT_USER == null ? null : LN_ACNT_USER.trim();
    }

    /**
     * アカウント種別
     * @return ACNT_KIND アカウント種別
     */
    public String getACNT_KIND() {
        return ACNT_KIND;
    }

    /**
     * アカウント種別
     * @param ACNT_KIND アカウント種別
     */
    public void setACNT_KIND(String ACNT_KIND) {
        this.ACNT_KIND = ACNT_KIND == null ? null : ACNT_KIND.trim();
    }
}