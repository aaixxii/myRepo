package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EV6Jian extends EV6JianKey implements Serializable {
    /**
     * 号機番号
     */
    private String GOUKI;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * サブアドレス
     */
    private String SUBADDR;

    /**
     * 契約ID
     */
    private String KEIYAKU_ID;

    /**
     * 発生ID
     */
    private String HASSEI_ID;

    /**
     * コース番号
     */
    private String COURSE_NUM;

    /**
     * 警備先名１
     */
    private String KEIBI_NM_1;

    /**
     * 警備先名２
     */
    private String KEIBI_NM_2;

    /**
     * 略称名称
     */
    private String ABBR_NM;

    /**
     * 住所コード
     */
    private String ADDR_CD;

    /**
     * 警察通報
     */
    private String KEISATU;

    /**
     * 消防通報
     */
    private String SYOUBOU_FLG;

    /**
     * 綜警ＫＢ
     */
    private String SOK_KB;

    /**
     * 出動区分
     */
    private String SYUKKIN_KBN;

    /**
     * 応援設定マーク
     */
    private String OUEN_MARK;

    /**
     * 受付席番
     */
    private String UKE_SEKI;

    /**
     * 担当席番
     */
    private String TANTOU_SEKI;

    /**
     * 事態コード
     */
    private String JITAI_CD;

    /**
     * 警報カウンタ
     */
    private String KEIHOU_CNT;

    /**
     * １_年月日時分秒
     */
    private String TS_1;

    /**
     * １_発生時分
     */
    private String HASSEI_TS_1;

    /**
     * １_社内対応コード
     */
    private String SYANAI_1_CD;

    /**
     * １_警備信号
     */
    private String KEIBI_SIG_1;

    /**
     * １_信号種別
     */
    private String SIG_KIND_1;

    /**
     * １_警報マーク
     */
    private String KEIHOU_MARK_1;

    /**
     * ２_年月日時分秒
     */
    private String TS_2;

    /**
     * ２_発生時分
     */
    private String HASSEI_TS_2;

    /**
     * ２_社内対応コード
     */
    private String SYANAI_2_CD;

    /**
     * ２_警備信号
     */
    private String KEIBI_SIG_2;

    /**
     * ２_信号種別
     */
    private String SIG_KIND_2;

    /**
     * ２_警報マーク
     */
    private String KEIHOU_MARK_2;

    /**
     * ３_年月日時分秒
     */
    private String TS_3;

    /**
     * ３_発生時分
     */
    private String HASSEI_TS_3;

    /**
     * ３_社内対応コード
     */
    private String SYANAI_3_CD;

    /**
     * ３_警備信号
     */
    private String KEIBI_SIG_3;

    /**
     * ３_信号種別
     */
    private String SIG_KIND_3;

    /**
     * ３_警報マーク
     */
    private String KEIHOU_MARK_3;

    /**
     * ４_年月日時分秒
     */
    private String TS_4;

    /**
     * ４_発生時分
     */
    private String HASSEI_TS_4;

    /**
     * ４_社内対応コード
     */
    private String SYANAI_4_CD;

    /**
     * ４_警備信号
     */
    private String KEIBI_SIG_4;

    /**
     * ４_信号種別
     */
    private String SIG_KIND_4;

    /**
     * ４_警報マーク
     */
    private String KEIHOU_MARK_4;

    /**
     * ５_年月日時分秒
     */
    private String TS_5;

    /**
     * ５_発生時分
     */
    private String HASSEI_TS_5;

    /**
     * ５_社内対応コード
     */
    private String SYANAI_5_CD;

    /**
     * ５_警備信号
     */
    private String KEIBI_SIG_5;

    /**
     * ５_信号種別
     */
    private String SIG_KIND_5;

    /**
     * ５_警報マーク
     */
    private String KEIHOU_MARK_5;

    /**
     * 信号ID
     */
    private String SIG_ID;

    /**
     * データID
     */
    private String DATA_ID;

    /**
     * 多信号情報
     */
    private String MULTI_SIG_INF;

    /**
     * NET警備情報
     */
    private String NET_KEIBI_INF;

    /**
     * 画面登録区分コード
     */
    private String GAM_KUBUN_CD;

    /**
     * 顧客コード
     */
    private String KOKYAKU_CD;

    /**
     * 補足コード
     */
    private String HOSOKU_CD;

    /**
     * 発生通番
     */
    private String HASSEI_CNT;

    /**
     * 最終通番
     */
    private String LAST_CNT;

    /**
     * 指示時間
     */
    private String SIJI_TM;

    /**
     * 直行時間
     */
    private String CHOKKOU_TM;

    /**
     * 所要時間
     */
    private String SYOYOU_TM;

    /**
     * 現着時間
     */
    private String GENCHAKU_TM;

    /**
     * 入館時間
     */
    private String NYUKAN_TM;

    /**
     * 退館時間
     */
    private String TAIKAN_TM;

    /**
     * 終了時間
     */
    private String END_TM;

    /**
     * 終了予定日時
     */
    private String END_YOTEI_TS;

    /**
     * 警察通報時間
     */
    private String POLICE_CALL_TM;

    /**
     * 警察到着時間
     */
    private String POLICE_ARRIV_TM;

    /**
     * 消防通報時間
     */
    private String FIRE_CALL_TM;

    /**
     * 消防到着時間
     */
    private String FIRE_ARRIV_TM;

    /**
     * 警察_理由コード
     */
    private String POLICE_REASON_CD;

    /**
     * 警察_通報理由
     */
    private String POLICE_CALL_REASON;

    /**
     * 警察_通報先区分
     */
    private String POLICE_CALL_KBN;

    /**
     * 警察_真報／誤報
     */
    private String POLICE_SINPO;

    /**
     * 警察_退館時間
     */
    private String POLICE_TAIKAN_TM;

    /**
     * 消防_理由コード
     */
    private String FIRE_REASON_CD;

    /**
     * 消防_通報理由
     */
    private String FIRE_CALL_REASON;

    /**
     * 消防_通報先区分
     */
    private String FIRE_CALL_KBN;

    /**
     * 消防_真報／誤報
     */
    private String FIRE_SINPO;

    /**
     * 消防_退館時間
     */
    private String FIRE_TAIKAN_TM;

    /**
     * SGS原因コード
     */
    private String SGS_GENIN_CD;

    /**
     * 原因詳細内容
     */
    private String GEN_DTL_NAIYOU;

    /**
     * 原因内容１
     */
    private String GEN_NAIYOU_1;

    /**
     * 原因内容２
     */
    private String GEN_NAIYOU_2;

    /**
     * 事案分類コード
     */
    private String JIANBNR_CD;

    /**
     * 警報分類コード
     */
    private String KEIHOBNR_CD;

    /**
     * 原因分類コード
     */
    private String GENBNR_CD;

    /**
     * ＮＥＴ原因コード
     */
    private String NET_GEN_CD;

    /**
     * ＮＥＴ原因内容
     */
    private String NET_GEN_NAIYOU;

    /**
     * センサコード
     */
    private String SENSOR_CD;

    /**
     * 直行タイマ
     */
    private String TIMER_CHOKKOU;

    /**
     * 現着タイマ
     */
    private String TIMER_GENCHAKU;

    /**
     * 所要タイマ
     */
    private String TIMER_SYOYOU;

    /**
     * 入館タイマ
     */
    private String TIMER_NYUUKAN;

    /**
     * 退館タイマ
     */
    private String TIMER_TAIKAN;

    /**
     * 終了タイマ
     */
    private String TIMER_SYUURYOU;

    /**
     * タイムオーバー
     */
    private String TIME_OVER;

    /**
     * 取消禁止タイマ
     */
    private String TIMER_NO_CANCEL_TS;

    /**
     * 電子メモ
     */
    private String e_MEMO;

    /**
     * 事業所コード
     */
    private String JIGYO_CD;

    /**
     * Ｎ０信号時刻
     */
    private String n0_TIME;

    /**
     * 再発報フラグ
     */
    private String RE_WARN_FLG;

    /**
     * ブザー鳴動フラグ
     */
    private String BUZZ_FLG;

    /**
     * 予約発生フラグ
     */
    private String RESERVE_WARN_FLG;

    /**
     * メッセージ数
     */
    private String MESSAGE_COUNT;

    /**
     * 未処置メッセージ数
     */
    private String NO_MEASURE_CNT;

    /**
     * 退館区分
     */
    private String TAIKAN_KBN;

    /**
     * 事案種類
     */
    private String JIAN_KIND;

    /**
     * 対応要否フラグ
     */
    private String TAIOU_YOUHI_FLG;

    /**
     * 事態タイマ登録時間
     */
    private String JITAI_TIMER_ENT_TM;

    /**
     * 事態タイムアウト時間
     */
    private String JITAI_TIMEOUT_TM;

    /**
     * 直行ＴＯタイマ
     */
    private String TIMER_CHOKKOU_TO;

    /**
     * 現着ＴＯタイマ
     */
    private String TIMER_GENCHAKU_TO;

    /**
     * 入館ＴＯタイマ
     */
    private String TIMER_NYUUKAN_TO;

    /**
     * 退館ＴＯタイマ
     */
    private String TIMER_TAIKAN_TO;

    /**
     * 終了ＴＯタイマ
     */
    private String TIMER_END_TO;

    /**
     * 信号優先度
     */
    private String SIG_PRIORITY;

    /**
     * 第一警報受信日付
     */
    private String SIG_1_RCV_TIME;

    /**
     * 措置変更マーク
     */
    private String SOCHI_CNG_MARK;

    /**
     * サブ監視フラグ
     */
    private String SUB_KASI_FLG;

    /**
     * 拠点落着フラグ
     */
    private String RAK_FLG;

    /**
     * 出動キャンセルマーク
     */
    private String CANCEL_MARK;

    /**
     * キャンセル通知フラグ
     */
    private String CANCEL_NTY_FLG;

    /**
     * 本人確認フラグ
     */
    private String HONNIN_FLG;

    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * 最終更新日時
     */
    private Date LASTUPD_TS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_V6_JIAN
     */
    private static final long serialVersionUID = 1L;

    /**
     * 号機番号
     * @return GOUKI 号機番号
     */
    public String getGOUKI() {
        return GOUKI;
    }

    /**
     * 号機番号
     * @param GOUKI 号機番号
     */
    public void setGOUKI(String GOUKI) {
        this.GOUKI = GOUKI == null ? null : GOUKI.trim();
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * サブアドレス
     * @return SUBADDR サブアドレス
     */
    public String getSUBADDR() {
        return SUBADDR;
    }

    /**
     * サブアドレス
     * @param SUBADDR サブアドレス
     */
    public void setSUBADDR(String SUBADDR) {
        this.SUBADDR = SUBADDR == null ? null : SUBADDR.trim();
    }

    /**
     * 契約ID
     * @return KEIYAKU_ID 契約ID
     */
    public String getKEIYAKU_ID() {
        return KEIYAKU_ID;
    }

    /**
     * 契約ID
     * @param KEIYAKU_ID 契約ID
     */
    public void setKEIYAKU_ID(String KEIYAKU_ID) {
        this.KEIYAKU_ID = KEIYAKU_ID == null ? null : KEIYAKU_ID.trim();
    }

    /**
     * 発生ID
     * @return HASSEI_ID 発生ID
     */
    public String getHASSEI_ID() {
        return HASSEI_ID;
    }

    /**
     * 発生ID
     * @param HASSEI_ID 発生ID
     */
    public void setHASSEI_ID(String HASSEI_ID) {
        this.HASSEI_ID = HASSEI_ID == null ? null : HASSEI_ID.trim();
    }

    /**
     * コース番号
     * @return COURSE_NUM コース番号
     */
    public String getCOURSE_NUM() {
        return COURSE_NUM;
    }

    /**
     * コース番号
     * @param COURSE_NUM コース番号
     */
    public void setCOURSE_NUM(String COURSE_NUM) {
        this.COURSE_NUM = COURSE_NUM == null ? null : COURSE_NUM.trim();
    }

    /**
     * 警備先名１
     * @return KEIBI_NM_1 警備先名１
     */
    public String getKEIBI_NM_1() {
        return KEIBI_NM_1;
    }

    /**
     * 警備先名１
     * @param KEIBI_NM_1 警備先名１
     */
    public void setKEIBI_NM_1(String KEIBI_NM_1) {
        this.KEIBI_NM_1 = KEIBI_NM_1 == null ? null : KEIBI_NM_1.trim();
    }

    /**
     * 警備先名２
     * @return KEIBI_NM_2 警備先名２
     */
    public String getKEIBI_NM_2() {
        return KEIBI_NM_2;
    }

    /**
     * 警備先名２
     * @param KEIBI_NM_2 警備先名２
     */
    public void setKEIBI_NM_2(String KEIBI_NM_2) {
        this.KEIBI_NM_2 = KEIBI_NM_2 == null ? null : KEIBI_NM_2.trim();
    }

    /**
     * 略称名称
     * @return ABBR_NM 略称名称
     */
    public String getABBR_NM() {
        return ABBR_NM;
    }

    /**
     * 略称名称
     * @param ABBR_NM 略称名称
     */
    public void setABBR_NM(String ABBR_NM) {
        this.ABBR_NM = ABBR_NM == null ? null : ABBR_NM.trim();
    }

    /**
     * 住所コード
     * @return ADDR_CD 住所コード
     */
    public String getADDR_CD() {
        return ADDR_CD;
    }

    /**
     * 住所コード
     * @param ADDR_CD 住所コード
     */
    public void setADDR_CD(String ADDR_CD) {
        this.ADDR_CD = ADDR_CD == null ? null : ADDR_CD.trim();
    }

    /**
     * 警察通報
     * @return KEISATU 警察通報
     */
    public String getKEISATU() {
        return KEISATU;
    }

    /**
     * 警察通報
     * @param KEISATU 警察通報
     */
    public void setKEISATU(String KEISATU) {
        this.KEISATU = KEISATU == null ? null : KEISATU.trim();
    }

    /**
     * 消防通報
     * @return SYOUBOU_FLG 消防通報
     */
    public String getSYOUBOU_FLG() {
        return SYOUBOU_FLG;
    }

    /**
     * 消防通報
     * @param SYOUBOU_FLG 消防通報
     */
    public void setSYOUBOU_FLG(String SYOUBOU_FLG) {
        this.SYOUBOU_FLG = SYOUBOU_FLG == null ? null : SYOUBOU_FLG.trim();
    }

    /**
     * 綜警ＫＢ
     * @return SOK_KB 綜警ＫＢ
     */
    public String getSOK_KB() {
        return SOK_KB;
    }

    /**
     * 綜警ＫＢ
     * @param SOK_KB 綜警ＫＢ
     */
    public void setSOK_KB(String SOK_KB) {
        this.SOK_KB = SOK_KB == null ? null : SOK_KB.trim();
    }

    /**
     * 出動区分
     * @return SYUKKIN_KBN 出動区分
     */
    public String getSYUKKIN_KBN() {
        return SYUKKIN_KBN;
    }

    /**
     * 出動区分
     * @param SYUKKIN_KBN 出動区分
     */
    public void setSYUKKIN_KBN(String SYUKKIN_KBN) {
        this.SYUKKIN_KBN = SYUKKIN_KBN == null ? null : SYUKKIN_KBN.trim();
    }

    /**
     * 応援設定マーク
     * @return OUEN_MARK 応援設定マーク
     */
    public String getOUEN_MARK() {
        return OUEN_MARK;
    }

    /**
     * 応援設定マーク
     * @param OUEN_MARK 応援設定マーク
     */
    public void setOUEN_MARK(String OUEN_MARK) {
        this.OUEN_MARK = OUEN_MARK == null ? null : OUEN_MARK.trim();
    }

    /**
     * 受付席番
     * @return UKE_SEKI 受付席番
     */
    public String getUKE_SEKI() {
        return UKE_SEKI;
    }

    /**
     * 受付席番
     * @param UKE_SEKI 受付席番
     */
    public void setUKE_SEKI(String UKE_SEKI) {
        this.UKE_SEKI = UKE_SEKI == null ? null : UKE_SEKI.trim();
    }

    /**
     * 担当席番
     * @return TANTOU_SEKI 担当席番
     */
    public String getTANTOU_SEKI() {
        return TANTOU_SEKI;
    }

    /**
     * 担当席番
     * @param TANTOU_SEKI 担当席番
     */
    public void setTANTOU_SEKI(String TANTOU_SEKI) {
        this.TANTOU_SEKI = TANTOU_SEKI == null ? null : TANTOU_SEKI.trim();
    }

    /**
     * 事態コード
     * @return JITAI_CD 事態コード
     */
    public String getJITAI_CD() {
        return JITAI_CD;
    }

    /**
     * 事態コード
     * @param JITAI_CD 事態コード
     */
    public void setJITAI_CD(String JITAI_CD) {
        this.JITAI_CD = JITAI_CD == null ? null : JITAI_CD.trim();
    }

    /**
     * 警報カウンタ
     * @return KEIHOU_CNT 警報カウンタ
     */
    public String getKEIHOU_CNT() {
        return KEIHOU_CNT;
    }

    /**
     * 警報カウンタ
     * @param KEIHOU_CNT 警報カウンタ
     */
    public void setKEIHOU_CNT(String KEIHOU_CNT) {
        this.KEIHOU_CNT = KEIHOU_CNT == null ? null : KEIHOU_CNT.trim();
    }

    /**
     * １_年月日時分秒
     * @return TS_1 １_年月日時分秒
     */
    public String getTS_1() {
        return TS_1;
    }

    /**
     * １_年月日時分秒
     * @param TS_1 １_年月日時分秒
     */
    public void setTS_1(String TS_1) {
        this.TS_1 = TS_1 == null ? null : TS_1.trim();
    }

    /**
     * １_発生時分
     * @return HASSEI_TS_1 １_発生時分
     */
    public String getHASSEI_TS_1() {
        return HASSEI_TS_1;
    }

    /**
     * １_発生時分
     * @param HASSEI_TS_1 １_発生時分
     */
    public void setHASSEI_TS_1(String HASSEI_TS_1) {
        this.HASSEI_TS_1 = HASSEI_TS_1 == null ? null : HASSEI_TS_1.trim();
    }

    /**
     * １_社内対応コード
     * @return SYANAI_1_CD １_社内対応コード
     */
    public String getSYANAI_1_CD() {
        return SYANAI_1_CD;
    }

    /**
     * １_社内対応コード
     * @param SYANAI_1_CD １_社内対応コード
     */
    public void setSYANAI_1_CD(String SYANAI_1_CD) {
        this.SYANAI_1_CD = SYANAI_1_CD == null ? null : SYANAI_1_CD.trim();
    }

    /**
     * １_警備信号
     * @return KEIBI_SIG_1 １_警備信号
     */
    public String getKEIBI_SIG_1() {
        return KEIBI_SIG_1;
    }

    /**
     * １_警備信号
     * @param KEIBI_SIG_1 １_警備信号
     */
    public void setKEIBI_SIG_1(String KEIBI_SIG_1) {
        this.KEIBI_SIG_1 = KEIBI_SIG_1 == null ? null : KEIBI_SIG_1.trim();
    }

    /**
     * １_信号種別
     * @return SIG_KIND_1 １_信号種別
     */
    public String getSIG_KIND_1() {
        return SIG_KIND_1;
    }

    /**
     * １_信号種別
     * @param SIG_KIND_1 １_信号種別
     */
    public void setSIG_KIND_1(String SIG_KIND_1) {
        this.SIG_KIND_1 = SIG_KIND_1 == null ? null : SIG_KIND_1.trim();
    }

    /**
     * １_警報マーク
     * @return KEIHOU_MARK_1 １_警報マーク
     */
    public String getKEIHOU_MARK_1() {
        return KEIHOU_MARK_1;
    }

    /**
     * １_警報マーク
     * @param KEIHOU_MARK_1 １_警報マーク
     */
    public void setKEIHOU_MARK_1(String KEIHOU_MARK_1) {
        this.KEIHOU_MARK_1 = KEIHOU_MARK_1 == null ? null : KEIHOU_MARK_1.trim();
    }

    /**
     * ２_年月日時分秒
     * @return TS_2 ２_年月日時分秒
     */
    public String getTS_2() {
        return TS_2;
    }

    /**
     * ２_年月日時分秒
     * @param TS_2 ２_年月日時分秒
     */
    public void setTS_2(String TS_2) {
        this.TS_2 = TS_2 == null ? null : TS_2.trim();
    }

    /**
     * ２_発生時分
     * @return HASSEI_TS_2 ２_発生時分
     */
    public String getHASSEI_TS_2() {
        return HASSEI_TS_2;
    }

    /**
     * ２_発生時分
     * @param HASSEI_TS_2 ２_発生時分
     */
    public void setHASSEI_TS_2(String HASSEI_TS_2) {
        this.HASSEI_TS_2 = HASSEI_TS_2 == null ? null : HASSEI_TS_2.trim();
    }

    /**
     * ２_社内対応コード
     * @return SYANAI_2_CD ２_社内対応コード
     */
    public String getSYANAI_2_CD() {
        return SYANAI_2_CD;
    }

    /**
     * ２_社内対応コード
     * @param SYANAI_2_CD ２_社内対応コード
     */
    public void setSYANAI_2_CD(String SYANAI_2_CD) {
        this.SYANAI_2_CD = SYANAI_2_CD == null ? null : SYANAI_2_CD.trim();
    }

    /**
     * ２_警備信号
     * @return KEIBI_SIG_2 ２_警備信号
     */
    public String getKEIBI_SIG_2() {
        return KEIBI_SIG_2;
    }

    /**
     * ２_警備信号
     * @param KEIBI_SIG_2 ２_警備信号
     */
    public void setKEIBI_SIG_2(String KEIBI_SIG_2) {
        this.KEIBI_SIG_2 = KEIBI_SIG_2 == null ? null : KEIBI_SIG_2.trim();
    }

    /**
     * ２_信号種別
     * @return SIG_KIND_2 ２_信号種別
     */
    public String getSIG_KIND_2() {
        return SIG_KIND_2;
    }

    /**
     * ２_信号種別
     * @param SIG_KIND_2 ２_信号種別
     */
    public void setSIG_KIND_2(String SIG_KIND_2) {
        this.SIG_KIND_2 = SIG_KIND_2 == null ? null : SIG_KIND_2.trim();
    }

    /**
     * ２_警報マーク
     * @return KEIHOU_MARK_2 ２_警報マーク
     */
    public String getKEIHOU_MARK_2() {
        return KEIHOU_MARK_2;
    }

    /**
     * ２_警報マーク
     * @param KEIHOU_MARK_2 ２_警報マーク
     */
    public void setKEIHOU_MARK_2(String KEIHOU_MARK_2) {
        this.KEIHOU_MARK_2 = KEIHOU_MARK_2 == null ? null : KEIHOU_MARK_2.trim();
    }

    /**
     * ３_年月日時分秒
     * @return TS_3 ３_年月日時分秒
     */
    public String getTS_3() {
        return TS_3;
    }

    /**
     * ３_年月日時分秒
     * @param TS_3 ３_年月日時分秒
     */
    public void setTS_3(String TS_3) {
        this.TS_3 = TS_3 == null ? null : TS_3.trim();
    }

    /**
     * ３_発生時分
     * @return HASSEI_TS_3 ３_発生時分
     */
    public String getHASSEI_TS_3() {
        return HASSEI_TS_3;
    }

    /**
     * ３_発生時分
     * @param HASSEI_TS_3 ３_発生時分
     */
    public void setHASSEI_TS_3(String HASSEI_TS_3) {
        this.HASSEI_TS_3 = HASSEI_TS_3 == null ? null : HASSEI_TS_3.trim();
    }

    /**
     * ３_社内対応コード
     * @return SYANAI_3_CD ３_社内対応コード
     */
    public String getSYANAI_3_CD() {
        return SYANAI_3_CD;
    }

    /**
     * ３_社内対応コード
     * @param SYANAI_3_CD ３_社内対応コード
     */
    public void setSYANAI_3_CD(String SYANAI_3_CD) {
        this.SYANAI_3_CD = SYANAI_3_CD == null ? null : SYANAI_3_CD.trim();
    }

    /**
     * ３_警備信号
     * @return KEIBI_SIG_3 ３_警備信号
     */
    public String getKEIBI_SIG_3() {
        return KEIBI_SIG_3;
    }

    /**
     * ３_警備信号
     * @param KEIBI_SIG_3 ３_警備信号
     */
    public void setKEIBI_SIG_3(String KEIBI_SIG_3) {
        this.KEIBI_SIG_3 = KEIBI_SIG_3 == null ? null : KEIBI_SIG_3.trim();
    }

    /**
     * ３_信号種別
     * @return SIG_KIND_3 ３_信号種別
     */
    public String getSIG_KIND_3() {
        return SIG_KIND_3;
    }

    /**
     * ３_信号種別
     * @param SIG_KIND_3 ３_信号種別
     */
    public void setSIG_KIND_3(String SIG_KIND_3) {
        this.SIG_KIND_3 = SIG_KIND_3 == null ? null : SIG_KIND_3.trim();
    }

    /**
     * ３_警報マーク
     * @return KEIHOU_MARK_3 ３_警報マーク
     */
    public String getKEIHOU_MARK_3() {
        return KEIHOU_MARK_3;
    }

    /**
     * ３_警報マーク
     * @param KEIHOU_MARK_3 ３_警報マーク
     */
    public void setKEIHOU_MARK_3(String KEIHOU_MARK_3) {
        this.KEIHOU_MARK_3 = KEIHOU_MARK_3 == null ? null : KEIHOU_MARK_3.trim();
    }

    /**
     * ４_年月日時分秒
     * @return TS_4 ４_年月日時分秒
     */
    public String getTS_4() {
        return TS_4;
    }

    /**
     * ４_年月日時分秒
     * @param TS_4 ４_年月日時分秒
     */
    public void setTS_4(String TS_4) {
        this.TS_4 = TS_4 == null ? null : TS_4.trim();
    }

    /**
     * ４_発生時分
     * @return HASSEI_TS_4 ４_発生時分
     */
    public String getHASSEI_TS_4() {
        return HASSEI_TS_4;
    }

    /**
     * ４_発生時分
     * @param HASSEI_TS_4 ４_発生時分
     */
    public void setHASSEI_TS_4(String HASSEI_TS_4) {
        this.HASSEI_TS_4 = HASSEI_TS_4 == null ? null : HASSEI_TS_4.trim();
    }

    /**
     * ４_社内対応コード
     * @return SYANAI_4_CD ４_社内対応コード
     */
    public String getSYANAI_4_CD() {
        return SYANAI_4_CD;
    }

    /**
     * ４_社内対応コード
     * @param SYANAI_4_CD ４_社内対応コード
     */
    public void setSYANAI_4_CD(String SYANAI_4_CD) {
        this.SYANAI_4_CD = SYANAI_4_CD == null ? null : SYANAI_4_CD.trim();
    }

    /**
     * ４_警備信号
     * @return KEIBI_SIG_4 ４_警備信号
     */
    public String getKEIBI_SIG_4() {
        return KEIBI_SIG_4;
    }

    /**
     * ４_警備信号
     * @param KEIBI_SIG_4 ４_警備信号
     */
    public void setKEIBI_SIG_4(String KEIBI_SIG_4) {
        this.KEIBI_SIG_4 = KEIBI_SIG_4 == null ? null : KEIBI_SIG_4.trim();
    }

    /**
     * ４_信号種別
     * @return SIG_KIND_4 ４_信号種別
     */
    public String getSIG_KIND_4() {
        return SIG_KIND_4;
    }

    /**
     * ４_信号種別
     * @param SIG_KIND_4 ４_信号種別
     */
    public void setSIG_KIND_4(String SIG_KIND_4) {
        this.SIG_KIND_4 = SIG_KIND_4 == null ? null : SIG_KIND_4.trim();
    }

    /**
     * ４_警報マーク
     * @return KEIHOU_MARK_4 ４_警報マーク
     */
    public String getKEIHOU_MARK_4() {
        return KEIHOU_MARK_4;
    }

    /**
     * ４_警報マーク
     * @param KEIHOU_MARK_4 ４_警報マーク
     */
    public void setKEIHOU_MARK_4(String KEIHOU_MARK_4) {
        this.KEIHOU_MARK_4 = KEIHOU_MARK_4 == null ? null : KEIHOU_MARK_4.trim();
    }

    /**
     * ５_年月日時分秒
     * @return TS_5 ５_年月日時分秒
     */
    public String getTS_5() {
        return TS_5;
    }

    /**
     * ５_年月日時分秒
     * @param TS_5 ５_年月日時分秒
     */
    public void setTS_5(String TS_5) {
        this.TS_5 = TS_5 == null ? null : TS_5.trim();
    }

    /**
     * ５_発生時分
     * @return HASSEI_TS_5 ５_発生時分
     */
    public String getHASSEI_TS_5() {
        return HASSEI_TS_5;
    }

    /**
     * ５_発生時分
     * @param HASSEI_TS_5 ５_発生時分
     */
    public void setHASSEI_TS_5(String HASSEI_TS_5) {
        this.HASSEI_TS_5 = HASSEI_TS_5 == null ? null : HASSEI_TS_5.trim();
    }

    /**
     * ５_社内対応コード
     * @return SYANAI_5_CD ５_社内対応コード
     */
    public String getSYANAI_5_CD() {
        return SYANAI_5_CD;
    }

    /**
     * ５_社内対応コード
     * @param SYANAI_5_CD ５_社内対応コード
     */
    public void setSYANAI_5_CD(String SYANAI_5_CD) {
        this.SYANAI_5_CD = SYANAI_5_CD == null ? null : SYANAI_5_CD.trim();
    }

    /**
     * ５_警備信号
     * @return KEIBI_SIG_5 ５_警備信号
     */
    public String getKEIBI_SIG_5() {
        return KEIBI_SIG_5;
    }

    /**
     * ５_警備信号
     * @param KEIBI_SIG_5 ５_警備信号
     */
    public void setKEIBI_SIG_5(String KEIBI_SIG_5) {
        this.KEIBI_SIG_5 = KEIBI_SIG_5 == null ? null : KEIBI_SIG_5.trim();
    }

    /**
     * ５_信号種別
     * @return SIG_KIND_5 ５_信号種別
     */
    public String getSIG_KIND_5() {
        return SIG_KIND_5;
    }

    /**
     * ５_信号種別
     * @param SIG_KIND_5 ５_信号種別
     */
    public void setSIG_KIND_5(String SIG_KIND_5) {
        this.SIG_KIND_5 = SIG_KIND_5 == null ? null : SIG_KIND_5.trim();
    }

    /**
     * ５_警報マーク
     * @return KEIHOU_MARK_5 ５_警報マーク
     */
    public String getKEIHOU_MARK_5() {
        return KEIHOU_MARK_5;
    }

    /**
     * ５_警報マーク
     * @param KEIHOU_MARK_5 ５_警報マーク
     */
    public void setKEIHOU_MARK_5(String KEIHOU_MARK_5) {
        this.KEIHOU_MARK_5 = KEIHOU_MARK_5 == null ? null : KEIHOU_MARK_5.trim();
    }

    /**
     * 信号ID
     * @return SIG_ID 信号ID
     */
    public String getSIG_ID() {
        return SIG_ID;
    }

    /**
     * 信号ID
     * @param SIG_ID 信号ID
     */
    public void setSIG_ID(String SIG_ID) {
        this.SIG_ID = SIG_ID == null ? null : SIG_ID.trim();
    }

    /**
     * データID
     * @return DATA_ID データID
     */
    public String getDATA_ID() {
        return DATA_ID;
    }

    /**
     * データID
     * @param DATA_ID データID
     */
    public void setDATA_ID(String DATA_ID) {
        this.DATA_ID = DATA_ID == null ? null : DATA_ID.trim();
    }

    /**
     * 多信号情報
     * @return MULTI_SIG_INF 多信号情報
     */
    public String getMULTI_SIG_INF() {
        return MULTI_SIG_INF;
    }

    /**
     * 多信号情報
     * @param MULTI_SIG_INF 多信号情報
     */
    public void setMULTI_SIG_INF(String MULTI_SIG_INF) {
        this.MULTI_SIG_INF = MULTI_SIG_INF == null ? null : MULTI_SIG_INF.trim();
    }

    /**
     * NET警備情報
     * @return NET_KEIBI_INF NET警備情報
     */
    public String getNET_KEIBI_INF() {
        return NET_KEIBI_INF;
    }

    /**
     * NET警備情報
     * @param NET_KEIBI_INF NET警備情報
     */
    public void setNET_KEIBI_INF(String NET_KEIBI_INF) {
        this.NET_KEIBI_INF = NET_KEIBI_INF == null ? null : NET_KEIBI_INF.trim();
    }

    /**
     * 画面登録区分コード
     * @return GAM_KUBUN_CD 画面登録区分コード
     */
    public String getGAM_KUBUN_CD() {
        return GAM_KUBUN_CD;
    }

    /**
     * 画面登録区分コード
     * @param GAM_KUBUN_CD 画面登録区分コード
     */
    public void setGAM_KUBUN_CD(String GAM_KUBUN_CD) {
        this.GAM_KUBUN_CD = GAM_KUBUN_CD == null ? null : GAM_KUBUN_CD.trim();
    }

    /**
     * 顧客コード
     * @return KOKYAKU_CD 顧客コード
     */
    public String getKOKYAKU_CD() {
        return KOKYAKU_CD;
    }

    /**
     * 顧客コード
     * @param KOKYAKU_CD 顧客コード
     */
    public void setKOKYAKU_CD(String KOKYAKU_CD) {
        this.KOKYAKU_CD = KOKYAKU_CD == null ? null : KOKYAKU_CD.trim();
    }

    /**
     * 補足コード
     * @return HOSOKU_CD 補足コード
     */
    public String getHOSOKU_CD() {
        return HOSOKU_CD;
    }

    /**
     * 補足コード
     * @param HOSOKU_CD 補足コード
     */
    public void setHOSOKU_CD(String HOSOKU_CD) {
        this.HOSOKU_CD = HOSOKU_CD == null ? null : HOSOKU_CD.trim();
    }

    /**
     * 発生通番
     * @return HASSEI_CNT 発生通番
     */
    public String getHASSEI_CNT() {
        return HASSEI_CNT;
    }

    /**
     * 発生通番
     * @param HASSEI_CNT 発生通番
     */
    public void setHASSEI_CNT(String HASSEI_CNT) {
        this.HASSEI_CNT = HASSEI_CNT == null ? null : HASSEI_CNT.trim();
    }

    /**
     * 最終通番
     * @return LAST_CNT 最終通番
     */
    public String getLAST_CNT() {
        return LAST_CNT;
    }

    /**
     * 最終通番
     * @param LAST_CNT 最終通番
     */
    public void setLAST_CNT(String LAST_CNT) {
        this.LAST_CNT = LAST_CNT == null ? null : LAST_CNT.trim();
    }

    /**
     * 指示時間
     * @return SIJI_TM 指示時間
     */
    public String getSIJI_TM() {
        return SIJI_TM;
    }

    /**
     * 指示時間
     * @param SIJI_TM 指示時間
     */
    public void setSIJI_TM(String SIJI_TM) {
        this.SIJI_TM = SIJI_TM == null ? null : SIJI_TM.trim();
    }

    /**
     * 直行時間
     * @return CHOKKOU_TM 直行時間
     */
    public String getCHOKKOU_TM() {
        return CHOKKOU_TM;
    }

    /**
     * 直行時間
     * @param CHOKKOU_TM 直行時間
     */
    public void setCHOKKOU_TM(String CHOKKOU_TM) {
        this.CHOKKOU_TM = CHOKKOU_TM == null ? null : CHOKKOU_TM.trim();
    }

    /**
     * 所要時間
     * @return SYOYOU_TM 所要時間
     */
    public String getSYOYOU_TM() {
        return SYOYOU_TM;
    }

    /**
     * 所要時間
     * @param SYOYOU_TM 所要時間
     */
    public void setSYOYOU_TM(String SYOYOU_TM) {
        this.SYOYOU_TM = SYOYOU_TM == null ? null : SYOYOU_TM.trim();
    }

    /**
     * 現着時間
     * @return GENCHAKU_TM 現着時間
     */
    public String getGENCHAKU_TM() {
        return GENCHAKU_TM;
    }

    /**
     * 現着時間
     * @param GENCHAKU_TM 現着時間
     */
    public void setGENCHAKU_TM(String GENCHAKU_TM) {
        this.GENCHAKU_TM = GENCHAKU_TM == null ? null : GENCHAKU_TM.trim();
    }

    /**
     * 入館時間
     * @return NYUKAN_TM 入館時間
     */
    public String getNYUKAN_TM() {
        return NYUKAN_TM;
    }

    /**
     * 入館時間
     * @param NYUKAN_TM 入館時間
     */
    public void setNYUKAN_TM(String NYUKAN_TM) {
        this.NYUKAN_TM = NYUKAN_TM == null ? null : NYUKAN_TM.trim();
    }

    /**
     * 退館時間
     * @return TAIKAN_TM 退館時間
     */
    public String getTAIKAN_TM() {
        return TAIKAN_TM;
    }

    /**
     * 退館時間
     * @param TAIKAN_TM 退館時間
     */
    public void setTAIKAN_TM(String TAIKAN_TM) {
        this.TAIKAN_TM = TAIKAN_TM == null ? null : TAIKAN_TM.trim();
    }

    /**
     * 終了時間
     * @return END_TM 終了時間
     */
    public String getEND_TM() {
        return END_TM;
    }

    /**
     * 終了時間
     * @param END_TM 終了時間
     */
    public void setEND_TM(String END_TM) {
        this.END_TM = END_TM == null ? null : END_TM.trim();
    }

    /**
     * 終了予定日時
     * @return END_YOTEI_TS 終了予定日時
     */
    public String getEND_YOTEI_TS() {
        return END_YOTEI_TS;
    }

    /**
     * 終了予定日時
     * @param END_YOTEI_TS 終了予定日時
     */
    public void setEND_YOTEI_TS(String END_YOTEI_TS) {
        this.END_YOTEI_TS = END_YOTEI_TS == null ? null : END_YOTEI_TS.trim();
    }

    /**
     * 警察通報時間
     * @return POLICE_CALL_TM 警察通報時間
     */
    public String getPOLICE_CALL_TM() {
        return POLICE_CALL_TM;
    }

    /**
     * 警察通報時間
     * @param POLICE_CALL_TM 警察通報時間
     */
    public void setPOLICE_CALL_TM(String POLICE_CALL_TM) {
        this.POLICE_CALL_TM = POLICE_CALL_TM == null ? null : POLICE_CALL_TM.trim();
    }

    /**
     * 警察到着時間
     * @return POLICE_ARRIV_TM 警察到着時間
     */
    public String getPOLICE_ARRIV_TM() {
        return POLICE_ARRIV_TM;
    }

    /**
     * 警察到着時間
     * @param POLICE_ARRIV_TM 警察到着時間
     */
    public void setPOLICE_ARRIV_TM(String POLICE_ARRIV_TM) {
        this.POLICE_ARRIV_TM = POLICE_ARRIV_TM == null ? null : POLICE_ARRIV_TM.trim();
    }

    /**
     * 消防通報時間
     * @return FIRE_CALL_TM 消防通報時間
     */
    public String getFIRE_CALL_TM() {
        return FIRE_CALL_TM;
    }

    /**
     * 消防通報時間
     * @param FIRE_CALL_TM 消防通報時間
     */
    public void setFIRE_CALL_TM(String FIRE_CALL_TM) {
        this.FIRE_CALL_TM = FIRE_CALL_TM == null ? null : FIRE_CALL_TM.trim();
    }

    /**
     * 消防到着時間
     * @return FIRE_ARRIV_TM 消防到着時間
     */
    public String getFIRE_ARRIV_TM() {
        return FIRE_ARRIV_TM;
    }

    /**
     * 消防到着時間
     * @param FIRE_ARRIV_TM 消防到着時間
     */
    public void setFIRE_ARRIV_TM(String FIRE_ARRIV_TM) {
        this.FIRE_ARRIV_TM = FIRE_ARRIV_TM == null ? null : FIRE_ARRIV_TM.trim();
    }

    /**
     * 警察_理由コード
     * @return POLICE_REASON_CD 警察_理由コード
     */
    public String getPOLICE_REASON_CD() {
        return POLICE_REASON_CD;
    }

    /**
     * 警察_理由コード
     * @param POLICE_REASON_CD 警察_理由コード
     */
    public void setPOLICE_REASON_CD(String POLICE_REASON_CD) {
        this.POLICE_REASON_CD = POLICE_REASON_CD == null ? null : POLICE_REASON_CD.trim();
    }

    /**
     * 警察_通報理由
     * @return POLICE_CALL_REASON 警察_通報理由
     */
    public String getPOLICE_CALL_REASON() {
        return POLICE_CALL_REASON;
    }

    /**
     * 警察_通報理由
     * @param POLICE_CALL_REASON 警察_通報理由
     */
    public void setPOLICE_CALL_REASON(String POLICE_CALL_REASON) {
        this.POLICE_CALL_REASON = POLICE_CALL_REASON == null ? null : POLICE_CALL_REASON.trim();
    }

    /**
     * 警察_通報先区分
     * @return POLICE_CALL_KBN 警察_通報先区分
     */
    public String getPOLICE_CALL_KBN() {
        return POLICE_CALL_KBN;
    }

    /**
     * 警察_通報先区分
     * @param POLICE_CALL_KBN 警察_通報先区分
     */
    public void setPOLICE_CALL_KBN(String POLICE_CALL_KBN) {
        this.POLICE_CALL_KBN = POLICE_CALL_KBN == null ? null : POLICE_CALL_KBN.trim();
    }

    /**
     * 警察_真報／誤報
     * @return POLICE_SINPO 警察_真報／誤報
     */
    public String getPOLICE_SINPO() {
        return POLICE_SINPO;
    }

    /**
     * 警察_真報／誤報
     * @param POLICE_SINPO 警察_真報／誤報
     */
    public void setPOLICE_SINPO(String POLICE_SINPO) {
        this.POLICE_SINPO = POLICE_SINPO == null ? null : POLICE_SINPO.trim();
    }

    /**
     * 警察_退館時間
     * @return POLICE_TAIKAN_TM 警察_退館時間
     */
    public String getPOLICE_TAIKAN_TM() {
        return POLICE_TAIKAN_TM;
    }

    /**
     * 警察_退館時間
     * @param POLICE_TAIKAN_TM 警察_退館時間
     */
    public void setPOLICE_TAIKAN_TM(String POLICE_TAIKAN_TM) {
        this.POLICE_TAIKAN_TM = POLICE_TAIKAN_TM == null ? null : POLICE_TAIKAN_TM.trim();
    }

    /**
     * 消防_理由コード
     * @return FIRE_REASON_CD 消防_理由コード
     */
    public String getFIRE_REASON_CD() {
        return FIRE_REASON_CD;
    }

    /**
     * 消防_理由コード
     * @param FIRE_REASON_CD 消防_理由コード
     */
    public void setFIRE_REASON_CD(String FIRE_REASON_CD) {
        this.FIRE_REASON_CD = FIRE_REASON_CD == null ? null : FIRE_REASON_CD.trim();
    }

    /**
     * 消防_通報理由
     * @return FIRE_CALL_REASON 消防_通報理由
     */
    public String getFIRE_CALL_REASON() {
        return FIRE_CALL_REASON;
    }

    /**
     * 消防_通報理由
     * @param FIRE_CALL_REASON 消防_通報理由
     */
    public void setFIRE_CALL_REASON(String FIRE_CALL_REASON) {
        this.FIRE_CALL_REASON = FIRE_CALL_REASON == null ? null : FIRE_CALL_REASON.trim();
    }

    /**
     * 消防_通報先区分
     * @return FIRE_CALL_KBN 消防_通報先区分
     */
    public String getFIRE_CALL_KBN() {
        return FIRE_CALL_KBN;
    }

    /**
     * 消防_通報先区分
     * @param FIRE_CALL_KBN 消防_通報先区分
     */
    public void setFIRE_CALL_KBN(String FIRE_CALL_KBN) {
        this.FIRE_CALL_KBN = FIRE_CALL_KBN == null ? null : FIRE_CALL_KBN.trim();
    }

    /**
     * 消防_真報／誤報
     * @return FIRE_SINPO 消防_真報／誤報
     */
    public String getFIRE_SINPO() {
        return FIRE_SINPO;
    }

    /**
     * 消防_真報／誤報
     * @param FIRE_SINPO 消防_真報／誤報
     */
    public void setFIRE_SINPO(String FIRE_SINPO) {
        this.FIRE_SINPO = FIRE_SINPO == null ? null : FIRE_SINPO.trim();
    }

    /**
     * 消防_退館時間
     * @return FIRE_TAIKAN_TM 消防_退館時間
     */
    public String getFIRE_TAIKAN_TM() {
        return FIRE_TAIKAN_TM;
    }

    /**
     * 消防_退館時間
     * @param FIRE_TAIKAN_TM 消防_退館時間
     */
    public void setFIRE_TAIKAN_TM(String FIRE_TAIKAN_TM) {
        this.FIRE_TAIKAN_TM = FIRE_TAIKAN_TM == null ? null : FIRE_TAIKAN_TM.trim();
    }

    /**
     * SGS原因コード
     * @return SGS_GENIN_CD SGS原因コード
     */
    public String getSGS_GENIN_CD() {
        return SGS_GENIN_CD;
    }

    /**
     * SGS原因コード
     * @param SGS_GENIN_CD SGS原因コード
     */
    public void setSGS_GENIN_CD(String SGS_GENIN_CD) {
        this.SGS_GENIN_CD = SGS_GENIN_CD == null ? null : SGS_GENIN_CD.trim();
    }

    /**
     * 原因詳細内容
     * @return GEN_DTL_NAIYOU 原因詳細内容
     */
    public String getGEN_DTL_NAIYOU() {
        return GEN_DTL_NAIYOU;
    }

    /**
     * 原因詳細内容
     * @param GEN_DTL_NAIYOU 原因詳細内容
     */
    public void setGEN_DTL_NAIYOU(String GEN_DTL_NAIYOU) {
        this.GEN_DTL_NAIYOU = GEN_DTL_NAIYOU == null ? null : GEN_DTL_NAIYOU.trim();
    }

    /**
     * 原因内容１
     * @return GEN_NAIYOU_1 原因内容１
     */
    public String getGEN_NAIYOU_1() {
        return GEN_NAIYOU_1;
    }

    /**
     * 原因内容１
     * @param GEN_NAIYOU_1 原因内容１
     */
    public void setGEN_NAIYOU_1(String GEN_NAIYOU_1) {
        this.GEN_NAIYOU_1 = GEN_NAIYOU_1 == null ? null : GEN_NAIYOU_1.trim();
    }

    /**
     * 原因内容２
     * @return GEN_NAIYOU_2 原因内容２
     */
    public String getGEN_NAIYOU_2() {
        return GEN_NAIYOU_2;
    }

    /**
     * 原因内容２
     * @param GEN_NAIYOU_2 原因内容２
     */
    public void setGEN_NAIYOU_2(String GEN_NAIYOU_2) {
        this.GEN_NAIYOU_2 = GEN_NAIYOU_2 == null ? null : GEN_NAIYOU_2.trim();
    }

    /**
     * 事案分類コード
     * @return JIANBNR_CD 事案分類コード
     */
    public String getJIANBNR_CD() {
        return JIANBNR_CD;
    }

    /**
     * 事案分類コード
     * @param JIANBNR_CD 事案分類コード
     */
    public void setJIANBNR_CD(String JIANBNR_CD) {
        this.JIANBNR_CD = JIANBNR_CD == null ? null : JIANBNR_CD.trim();
    }

    /**
     * 警報分類コード
     * @return KEIHOBNR_CD 警報分類コード
     */
    public String getKEIHOBNR_CD() {
        return KEIHOBNR_CD;
    }

    /**
     * 警報分類コード
     * @param KEIHOBNR_CD 警報分類コード
     */
    public void setKEIHOBNR_CD(String KEIHOBNR_CD) {
        this.KEIHOBNR_CD = KEIHOBNR_CD == null ? null : KEIHOBNR_CD.trim();
    }

    /**
     * 原因分類コード
     * @return GENBNR_CD 原因分類コード
     */
    public String getGENBNR_CD() {
        return GENBNR_CD;
    }

    /**
     * 原因分類コード
     * @param GENBNR_CD 原因分類コード
     */
    public void setGENBNR_CD(String GENBNR_CD) {
        this.GENBNR_CD = GENBNR_CD == null ? null : GENBNR_CD.trim();
    }

    /**
     * ＮＥＴ原因コード
     * @return NET_GEN_CD ＮＥＴ原因コード
     */
    public String getNET_GEN_CD() {
        return NET_GEN_CD;
    }

    /**
     * ＮＥＴ原因コード
     * @param NET_GEN_CD ＮＥＴ原因コード
     */
    public void setNET_GEN_CD(String NET_GEN_CD) {
        this.NET_GEN_CD = NET_GEN_CD == null ? null : NET_GEN_CD.trim();
    }

    /**
     * ＮＥＴ原因内容
     * @return NET_GEN_NAIYOU ＮＥＴ原因内容
     */
    public String getNET_GEN_NAIYOU() {
        return NET_GEN_NAIYOU;
    }

    /**
     * ＮＥＴ原因内容
     * @param NET_GEN_NAIYOU ＮＥＴ原因内容
     */
    public void setNET_GEN_NAIYOU(String NET_GEN_NAIYOU) {
        this.NET_GEN_NAIYOU = NET_GEN_NAIYOU == null ? null : NET_GEN_NAIYOU.trim();
    }

    /**
     * センサコード
     * @return SENSOR_CD センサコード
     */
    public String getSENSOR_CD() {
        return SENSOR_CD;
    }

    /**
     * センサコード
     * @param SENSOR_CD センサコード
     */
    public void setSENSOR_CD(String SENSOR_CD) {
        this.SENSOR_CD = SENSOR_CD == null ? null : SENSOR_CD.trim();
    }

    /**
     * 直行タイマ
     * @return TIMER_CHOKKOU 直行タイマ
     */
    public String getTIMER_CHOKKOU() {
        return TIMER_CHOKKOU;
    }

    /**
     * 直行タイマ
     * @param TIMER_CHOKKOU 直行タイマ
     */
    public void setTIMER_CHOKKOU(String TIMER_CHOKKOU) {
        this.TIMER_CHOKKOU = TIMER_CHOKKOU == null ? null : TIMER_CHOKKOU.trim();
    }

    /**
     * 現着タイマ
     * @return TIMER_GENCHAKU 現着タイマ
     */
    public String getTIMER_GENCHAKU() {
        return TIMER_GENCHAKU;
    }

    /**
     * 現着タイマ
     * @param TIMER_GENCHAKU 現着タイマ
     */
    public void setTIMER_GENCHAKU(String TIMER_GENCHAKU) {
        this.TIMER_GENCHAKU = TIMER_GENCHAKU == null ? null : TIMER_GENCHAKU.trim();
    }

    /**
     * 所要タイマ
     * @return TIMER_SYOYOU 所要タイマ
     */
    public String getTIMER_SYOYOU() {
        return TIMER_SYOYOU;
    }

    /**
     * 所要タイマ
     * @param TIMER_SYOYOU 所要タイマ
     */
    public void setTIMER_SYOYOU(String TIMER_SYOYOU) {
        this.TIMER_SYOYOU = TIMER_SYOYOU == null ? null : TIMER_SYOYOU.trim();
    }

    /**
     * 入館タイマ
     * @return TIMER_NYUUKAN 入館タイマ
     */
    public String getTIMER_NYUUKAN() {
        return TIMER_NYUUKAN;
    }

    /**
     * 入館タイマ
     * @param TIMER_NYUUKAN 入館タイマ
     */
    public void setTIMER_NYUUKAN(String TIMER_NYUUKAN) {
        this.TIMER_NYUUKAN = TIMER_NYUUKAN == null ? null : TIMER_NYUUKAN.trim();
    }

    /**
     * 退館タイマ
     * @return TIMER_TAIKAN 退館タイマ
     */
    public String getTIMER_TAIKAN() {
        return TIMER_TAIKAN;
    }

    /**
     * 退館タイマ
     * @param TIMER_TAIKAN 退館タイマ
     */
    public void setTIMER_TAIKAN(String TIMER_TAIKAN) {
        this.TIMER_TAIKAN = TIMER_TAIKAN == null ? null : TIMER_TAIKAN.trim();
    }

    /**
     * 終了タイマ
     * @return TIMER_SYUURYOU 終了タイマ
     */
    public String getTIMER_SYUURYOU() {
        return TIMER_SYUURYOU;
    }

    /**
     * 終了タイマ
     * @param TIMER_SYUURYOU 終了タイマ
     */
    public void setTIMER_SYUURYOU(String TIMER_SYUURYOU) {
        this.TIMER_SYUURYOU = TIMER_SYUURYOU == null ? null : TIMER_SYUURYOU.trim();
    }

    /**
     * タイムオーバー
     * @return TIME_OVER タイムオーバー
     */
    public String getTIME_OVER() {
        return TIME_OVER;
    }

    /**
     * タイムオーバー
     * @param TIME_OVER タイムオーバー
     */
    public void setTIME_OVER(String TIME_OVER) {
        this.TIME_OVER = TIME_OVER == null ? null : TIME_OVER.trim();
    }

    /**
     * 取消禁止タイマ
     * @return TIMER_NO_CANCEL_TS 取消禁止タイマ
     */
    public String getTIMER_NO_CANCEL_TS() {
        return TIMER_NO_CANCEL_TS;
    }

    /**
     * 取消禁止タイマ
     * @param TIMER_NO_CANCEL_TS 取消禁止タイマ
     */
    public void setTIMER_NO_CANCEL_TS(String TIMER_NO_CANCEL_TS) {
        this.TIMER_NO_CANCEL_TS = TIMER_NO_CANCEL_TS == null ? null : TIMER_NO_CANCEL_TS.trim();
    }

    /**
     * 電子メモ
     * @return E_MEMO 電子メモ
     */
    public String getE_MEMO() {
        return e_MEMO;
    }

    /**
     * 電子メモ
     * @param e_MEMO 電子メモ
     */
    public void setE_MEMO(String e_MEMO) {
        this.e_MEMO = e_MEMO == null ? null : e_MEMO.trim();
    }

    /**
     * 事業所コード
     * @return JIGYO_CD 事業所コード
     */
    public String getJIGYO_CD() {
        return JIGYO_CD;
    }

    /**
     * 事業所コード
     * @param JIGYO_CD 事業所コード
     */
    public void setJIGYO_CD(String JIGYO_CD) {
        this.JIGYO_CD = JIGYO_CD == null ? null : JIGYO_CD.trim();
    }

    /**
     * Ｎ０信号時刻
     * @return N0_TIME Ｎ０信号時刻
     */
    public String getN0_TIME() {
        return n0_TIME;
    }

    /**
     * Ｎ０信号時刻
     * @param n0_TIME Ｎ０信号時刻
     */
    public void setN0_TIME(String n0_TIME) {
        this.n0_TIME = n0_TIME == null ? null : n0_TIME.trim();
    }

    /**
     * 再発報フラグ
     * @return RE_WARN_FLG 再発報フラグ
     */
    public String getRE_WARN_FLG() {
        return RE_WARN_FLG;
    }

    /**
     * 再発報フラグ
     * @param RE_WARN_FLG 再発報フラグ
     */
    public void setRE_WARN_FLG(String RE_WARN_FLG) {
        this.RE_WARN_FLG = RE_WARN_FLG == null ? null : RE_WARN_FLG.trim();
    }

    /**
     * ブザー鳴動フラグ
     * @return BUZZ_FLG ブザー鳴動フラグ
     */
    public String getBUZZ_FLG() {
        return BUZZ_FLG;
    }

    /**
     * ブザー鳴動フラグ
     * @param BUZZ_FLG ブザー鳴動フラグ
     */
    public void setBUZZ_FLG(String BUZZ_FLG) {
        this.BUZZ_FLG = BUZZ_FLG == null ? null : BUZZ_FLG.trim();
    }

    /**
     * 予約発生フラグ
     * @return RESERVE_WARN_FLG 予約発生フラグ
     */
    public String getRESERVE_WARN_FLG() {
        return RESERVE_WARN_FLG;
    }

    /**
     * 予約発生フラグ
     * @param RESERVE_WARN_FLG 予約発生フラグ
     */
    public void setRESERVE_WARN_FLG(String RESERVE_WARN_FLG) {
        this.RESERVE_WARN_FLG = RESERVE_WARN_FLG == null ? null : RESERVE_WARN_FLG.trim();
    }

    /**
     * メッセージ数
     * @return MESSAGE_COUNT メッセージ数
     */
    public String getMESSAGE_COUNT() {
        return MESSAGE_COUNT;
    }

    /**
     * メッセージ数
     * @param MESSAGE_COUNT メッセージ数
     */
    public void setMESSAGE_COUNT(String MESSAGE_COUNT) {
        this.MESSAGE_COUNT = MESSAGE_COUNT == null ? null : MESSAGE_COUNT.trim();
    }

    /**
     * 未処置メッセージ数
     * @return NO_MEASURE_CNT 未処置メッセージ数
     */
    public String getNO_MEASURE_CNT() {
        return NO_MEASURE_CNT;
    }

    /**
     * 未処置メッセージ数
     * @param NO_MEASURE_CNT 未処置メッセージ数
     */
    public void setNO_MEASURE_CNT(String NO_MEASURE_CNT) {
        this.NO_MEASURE_CNT = NO_MEASURE_CNT == null ? null : NO_MEASURE_CNT.trim();
    }

    /**
     * 退館区分
     * @return TAIKAN_KBN 退館区分
     */
    public String getTAIKAN_KBN() {
        return TAIKAN_KBN;
    }

    /**
     * 退館区分
     * @param TAIKAN_KBN 退館区分
     */
    public void setTAIKAN_KBN(String TAIKAN_KBN) {
        this.TAIKAN_KBN = TAIKAN_KBN == null ? null : TAIKAN_KBN.trim();
    }

    /**
     * 事案種類
     * @return JIAN_KIND 事案種類
     */
    public String getJIAN_KIND() {
        return JIAN_KIND;
    }

    /**
     * 事案種類
     * @param JIAN_KIND 事案種類
     */
    public void setJIAN_KIND(String JIAN_KIND) {
        this.JIAN_KIND = JIAN_KIND == null ? null : JIAN_KIND.trim();
    }

    /**
     * 対応要否フラグ
     * @return TAIOU_YOUHI_FLG 対応要否フラグ
     */
    public String getTAIOU_YOUHI_FLG() {
        return TAIOU_YOUHI_FLG;
    }

    /**
     * 対応要否フラグ
     * @param TAIOU_YOUHI_FLG 対応要否フラグ
     */
    public void setTAIOU_YOUHI_FLG(String TAIOU_YOUHI_FLG) {
        this.TAIOU_YOUHI_FLG = TAIOU_YOUHI_FLG == null ? null : TAIOU_YOUHI_FLG.trim();
    }

    /**
     * 事態タイマ登録時間
     * @return JITAI_TIMER_ENT_TM 事態タイマ登録時間
     */
    public String getJITAI_TIMER_ENT_TM() {
        return JITAI_TIMER_ENT_TM;
    }

    /**
     * 事態タイマ登録時間
     * @param JITAI_TIMER_ENT_TM 事態タイマ登録時間
     */
    public void setJITAI_TIMER_ENT_TM(String JITAI_TIMER_ENT_TM) {
        this.JITAI_TIMER_ENT_TM = JITAI_TIMER_ENT_TM == null ? null : JITAI_TIMER_ENT_TM.trim();
    }

    /**
     * 事態タイムアウト時間
     * @return JITAI_TIMEOUT_TM 事態タイムアウト時間
     */
    public String getJITAI_TIMEOUT_TM() {
        return JITAI_TIMEOUT_TM;
    }

    /**
     * 事態タイムアウト時間
     * @param JITAI_TIMEOUT_TM 事態タイムアウト時間
     */
    public void setJITAI_TIMEOUT_TM(String JITAI_TIMEOUT_TM) {
        this.JITAI_TIMEOUT_TM = JITAI_TIMEOUT_TM == null ? null : JITAI_TIMEOUT_TM.trim();
    }

    /**
     * 直行ＴＯタイマ
     * @return TIMER_CHOKKOU_TO 直行ＴＯタイマ
     */
    public String getTIMER_CHOKKOU_TO() {
        return TIMER_CHOKKOU_TO;
    }

    /**
     * 直行ＴＯタイマ
     * @param TIMER_CHOKKOU_TO 直行ＴＯタイマ
     */
    public void setTIMER_CHOKKOU_TO(String TIMER_CHOKKOU_TO) {
        this.TIMER_CHOKKOU_TO = TIMER_CHOKKOU_TO == null ? null : TIMER_CHOKKOU_TO.trim();
    }

    /**
     * 現着ＴＯタイマ
     * @return TIMER_GENCHAKU_TO 現着ＴＯタイマ
     */
    public String getTIMER_GENCHAKU_TO() {
        return TIMER_GENCHAKU_TO;
    }

    /**
     * 現着ＴＯタイマ
     * @param TIMER_GENCHAKU_TO 現着ＴＯタイマ
     */
    public void setTIMER_GENCHAKU_TO(String TIMER_GENCHAKU_TO) {
        this.TIMER_GENCHAKU_TO = TIMER_GENCHAKU_TO == null ? null : TIMER_GENCHAKU_TO.trim();
    }

    /**
     * 入館ＴＯタイマ
     * @return TIMER_NYUUKAN_TO 入館ＴＯタイマ
     */
    public String getTIMER_NYUUKAN_TO() {
        return TIMER_NYUUKAN_TO;
    }

    /**
     * 入館ＴＯタイマ
     * @param TIMER_NYUUKAN_TO 入館ＴＯタイマ
     */
    public void setTIMER_NYUUKAN_TO(String TIMER_NYUUKAN_TO) {
        this.TIMER_NYUUKAN_TO = TIMER_NYUUKAN_TO == null ? null : TIMER_NYUUKAN_TO.trim();
    }

    /**
     * 退館ＴＯタイマ
     * @return TIMER_TAIKAN_TO 退館ＴＯタイマ
     */
    public String getTIMER_TAIKAN_TO() {
        return TIMER_TAIKAN_TO;
    }

    /**
     * 退館ＴＯタイマ
     * @param TIMER_TAIKAN_TO 退館ＴＯタイマ
     */
    public void setTIMER_TAIKAN_TO(String TIMER_TAIKAN_TO) {
        this.TIMER_TAIKAN_TO = TIMER_TAIKAN_TO == null ? null : TIMER_TAIKAN_TO.trim();
    }

    /**
     * 終了ＴＯタイマ
     * @return TIMER_END_TO 終了ＴＯタイマ
     */
    public String getTIMER_END_TO() {
        return TIMER_END_TO;
    }

    /**
     * 終了ＴＯタイマ
     * @param TIMER_END_TO 終了ＴＯタイマ
     */
    public void setTIMER_END_TO(String TIMER_END_TO) {
        this.TIMER_END_TO = TIMER_END_TO == null ? null : TIMER_END_TO.trim();
    }

    /**
     * 信号優先度
     * @return SIG_PRIORITY 信号優先度
     */
    public String getSIG_PRIORITY() {
        return SIG_PRIORITY;
    }

    /**
     * 信号優先度
     * @param SIG_PRIORITY 信号優先度
     */
    public void setSIG_PRIORITY(String SIG_PRIORITY) {
        this.SIG_PRIORITY = SIG_PRIORITY == null ? null : SIG_PRIORITY.trim();
    }

    /**
     * 第一警報受信日付
     * @return SIG_1_RCV_TIME 第一警報受信日付
     */
    public String getSIG_1_RCV_TIME() {
        return SIG_1_RCV_TIME;
    }

    /**
     * 第一警報受信日付
     * @param SIG_1_RCV_TIME 第一警報受信日付
     */
    public void setSIG_1_RCV_TIME(String SIG_1_RCV_TIME) {
        this.SIG_1_RCV_TIME = SIG_1_RCV_TIME == null ? null : SIG_1_RCV_TIME.trim();
    }

    /**
     * 措置変更マーク
     * @return SOCHI_CNG_MARK 措置変更マーク
     */
    public String getSOCHI_CNG_MARK() {
        return SOCHI_CNG_MARK;
    }

    /**
     * 措置変更マーク
     * @param SOCHI_CNG_MARK 措置変更マーク
     */
    public void setSOCHI_CNG_MARK(String SOCHI_CNG_MARK) {
        this.SOCHI_CNG_MARK = SOCHI_CNG_MARK == null ? null : SOCHI_CNG_MARK.trim();
    }

    /**
     * サブ監視フラグ
     * @return SUB_KASI_FLG サブ監視フラグ
     */
    public String getSUB_KASI_FLG() {
        return SUB_KASI_FLG;
    }

    /**
     * サブ監視フラグ
     * @param SUB_KASI_FLG サブ監視フラグ
     */
    public void setSUB_KASI_FLG(String SUB_KASI_FLG) {
        this.SUB_KASI_FLG = SUB_KASI_FLG == null ? null : SUB_KASI_FLG.trim();
    }

    /**
     * 拠点落着フラグ
     * @return RAK_FLG 拠点落着フラグ
     */
    public String getRAK_FLG() {
        return RAK_FLG;
    }

    /**
     * 拠点落着フラグ
     * @param RAK_FLG 拠点落着フラグ
     */
    public void setRAK_FLG(String RAK_FLG) {
        this.RAK_FLG = RAK_FLG == null ? null : RAK_FLG.trim();
    }

    /**
     * 出動キャンセルマーク
     * @return CANCEL_MARK 出動キャンセルマーク
     */
    public String getCANCEL_MARK() {
        return CANCEL_MARK;
    }

    /**
     * 出動キャンセルマーク
     * @param CANCEL_MARK 出動キャンセルマーク
     */
    public void setCANCEL_MARK(String CANCEL_MARK) {
        this.CANCEL_MARK = CANCEL_MARK == null ? null : CANCEL_MARK.trim();
    }

    /**
     * キャンセル通知フラグ
     * @return CANCEL_NTY_FLG キャンセル通知フラグ
     */
    public String getCANCEL_NTY_FLG() {
        return CANCEL_NTY_FLG;
    }

    /**
     * キャンセル通知フラグ
     * @param CANCEL_NTY_FLG キャンセル通知フラグ
     */
    public void setCANCEL_NTY_FLG(String CANCEL_NTY_FLG) {
        this.CANCEL_NTY_FLG = CANCEL_NTY_FLG == null ? null : CANCEL_NTY_FLG.trim();
    }

    /**
     * 本人確認フラグ
     * @return HONNIN_FLG 本人確認フラグ
     */
    public String getHONNIN_FLG() {
        return HONNIN_FLG;
    }

    /**
     * 本人確認フラグ
     * @param HONNIN_FLG 本人確認フラグ
     */
    public void setHONNIN_FLG(String HONNIN_FLG) {
        this.HONNIN_FLG = HONNIN_FLG == null ? null : HONNIN_FLG.trim();
    }

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * 最終更新日時
     * @return LASTUPD_TS 最終更新日時
     */
    public Date getLASTUPD_TS() {
        return LASTUPD_TS;
    }

    /**
     * 最終更新日時
     * @param LASTUPD_TS 最終更新日時
     */
    public void setLASTUPD_TS(Date LASTUPD_TS) {
        this.LASTUPD_TS = LASTUPD_TS;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}