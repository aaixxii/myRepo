package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HMstMntHtblExample {
    /**
     * H_MST_MNT_HTBL
     */
    protected String orderByClause;

    /**
     * H_MST_MNT_HTBL
     */
    protected boolean distinct;

    /**
     * H_MST_MNT_HTBL
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HMstMntHtblExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_MST_MNT_HTBL null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_MST_MNTIsNull() {
            addCriterion("LN_MST_MNT is null");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTIsNotNull() {
            addCriterion("LN_MST_MNT is not null");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTEqualTo(String value) {
            addCriterion("LN_MST_MNT =", value, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTNotEqualTo(String value) {
            addCriterion("LN_MST_MNT <>", value, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTGreaterThan(String value) {
            addCriterion("LN_MST_MNT >", value, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTGreaterThanOrEqualTo(String value) {
            addCriterion("LN_MST_MNT >=", value, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTLessThan(String value) {
            addCriterion("LN_MST_MNT <", value, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTLessThanOrEqualTo(String value) {
            addCriterion("LN_MST_MNT <=", value, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTLike(String value) {
            addCriterion("LN_MST_MNT like", value, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTNotLike(String value) {
            addCriterion("LN_MST_MNT not like", value, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTIn(List<String> values) {
            addCriterion("LN_MST_MNT in", values, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTNotIn(List<String> values) {
            addCriterion("LN_MST_MNT not in", values, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTBetween(String value1, String value2) {
            addCriterion("LN_MST_MNT between", value1, value2, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTNotBetween(String value1, String value2) {
            addCriterion("LN_MST_MNT not between", value1, value2, "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andKEY1IsNull() {
            addCriterion("KEY1 is null");
            return (Criteria) this;
        }

        public Criteria andKEY1IsNotNull() {
            addCriterion("KEY1 is not null");
            return (Criteria) this;
        }

        public Criteria andKEY1EqualTo(String value) {
            addCriterion("KEY1 =", value, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1NotEqualTo(String value) {
            addCriterion("KEY1 <>", value, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1GreaterThan(String value) {
            addCriterion("KEY1 >", value, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1GreaterThanOrEqualTo(String value) {
            addCriterion("KEY1 >=", value, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1LessThan(String value) {
            addCriterion("KEY1 <", value, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1LessThanOrEqualTo(String value) {
            addCriterion("KEY1 <=", value, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1Like(String value) {
            addCriterion("KEY1 like", value, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1NotLike(String value) {
            addCriterion("KEY1 not like", value, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1In(List<String> values) {
            addCriterion("KEY1 in", values, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1NotIn(List<String> values) {
            addCriterion("KEY1 not in", values, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1Between(String value1, String value2) {
            addCriterion("KEY1 between", value1, value2, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY1NotBetween(String value1, String value2) {
            addCriterion("KEY1 not between", value1, value2, "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY2IsNull() {
            addCriterion("KEY2 is null");
            return (Criteria) this;
        }

        public Criteria andKEY2IsNotNull() {
            addCriterion("KEY2 is not null");
            return (Criteria) this;
        }

        public Criteria andKEY2EqualTo(String value) {
            addCriterion("KEY2 =", value, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2NotEqualTo(String value) {
            addCriterion("KEY2 <>", value, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2GreaterThan(String value) {
            addCriterion("KEY2 >", value, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2GreaterThanOrEqualTo(String value) {
            addCriterion("KEY2 >=", value, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2LessThan(String value) {
            addCriterion("KEY2 <", value, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2LessThanOrEqualTo(String value) {
            addCriterion("KEY2 <=", value, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2Like(String value) {
            addCriterion("KEY2 like", value, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2NotLike(String value) {
            addCriterion("KEY2 not like", value, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2In(List<String> values) {
            addCriterion("KEY2 in", values, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2NotIn(List<String> values) {
            addCriterion("KEY2 not in", values, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2Between(String value1, String value2) {
            addCriterion("KEY2 between", value1, value2, "KEY2");
            return (Criteria) this;
        }

        public Criteria andKEY2NotBetween(String value1, String value2) {
            addCriterion("KEY2 not between", value1, value2, "KEY2");
            return (Criteria) this;
        }

        public Criteria andDISP_IDIsNull() {
            addCriterion("DISP_ID is null");
            return (Criteria) this;
        }

        public Criteria andDISP_IDIsNotNull() {
            addCriterion("DISP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andDISP_IDEqualTo(String value) {
            addCriterion("DISP_ID =", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDNotEqualTo(String value) {
            addCriterion("DISP_ID <>", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDGreaterThan(String value) {
            addCriterion("DISP_ID >", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDGreaterThanOrEqualTo(String value) {
            addCriterion("DISP_ID >=", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDLessThan(String value) {
            addCriterion("DISP_ID <", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDLessThanOrEqualTo(String value) {
            addCriterion("DISP_ID <=", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDLike(String value) {
            addCriterion("DISP_ID like", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDNotLike(String value) {
            addCriterion("DISP_ID not like", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDIn(List<String> values) {
            addCriterion("DISP_ID in", values, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDNotIn(List<String> values) {
            addCriterion("DISP_ID not in", values, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDBetween(String value1, String value2) {
            addCriterion("DISP_ID between", value1, value2, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDNotBetween(String value1, String value2) {
            addCriterion("DISP_ID not between", value1, value2, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDIsNull() {
            addCriterion("REASON_ID is null");
            return (Criteria) this;
        }

        public Criteria andREASON_IDIsNotNull() {
            addCriterion("REASON_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREASON_IDEqualTo(String value) {
            addCriterion("REASON_ID =", value, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDNotEqualTo(String value) {
            addCriterion("REASON_ID <>", value, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDGreaterThan(String value) {
            addCriterion("REASON_ID >", value, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REASON_ID >=", value, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDLessThan(String value) {
            addCriterion("REASON_ID <", value, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDLessThanOrEqualTo(String value) {
            addCriterion("REASON_ID <=", value, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDLike(String value) {
            addCriterion("REASON_ID like", value, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDNotLike(String value) {
            addCriterion("REASON_ID not like", value, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDIn(List<String> values) {
            addCriterion("REASON_ID in", values, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDNotIn(List<String> values) {
            addCriterion("REASON_ID not in", values, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDBetween(String value1, String value2) {
            addCriterion("REASON_ID between", value1, value2, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDNotBetween(String value1, String value2) {
            addCriterion("REASON_ID not between", value1, value2, "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUIsNull() {
            addCriterion("MST_MNT_NAIYOU is null");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUIsNotNull() {
            addCriterion("MST_MNT_NAIYOU is not null");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUEqualTo(String value) {
            addCriterion("MST_MNT_NAIYOU =", value, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUNotEqualTo(String value) {
            addCriterion("MST_MNT_NAIYOU <>", value, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUGreaterThan(String value) {
            addCriterion("MST_MNT_NAIYOU >", value, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUGreaterThanOrEqualTo(String value) {
            addCriterion("MST_MNT_NAIYOU >=", value, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOULessThan(String value) {
            addCriterion("MST_MNT_NAIYOU <", value, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOULessThanOrEqualTo(String value) {
            addCriterion("MST_MNT_NAIYOU <=", value, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOULike(String value) {
            addCriterion("MST_MNT_NAIYOU like", value, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUNotLike(String value) {
            addCriterion("MST_MNT_NAIYOU not like", value, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUIn(List<String> values) {
            addCriterion("MST_MNT_NAIYOU in", values, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUNotIn(List<String> values) {
            addCriterion("MST_MNT_NAIYOU not in", values, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUBetween(String value1, String value2) {
            addCriterion("MST_MNT_NAIYOU between", value1, value2, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOUNotBetween(String value1, String value2) {
            addCriterion("MST_MNT_NAIYOU not between", value1, value2, "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDIsNull() {
            addCriterion("ID_PROCESS_ID is null");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDIsNotNull() {
            addCriterion("ID_PROCESS_ID is not null");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDEqualTo(String value) {
            addCriterion("ID_PROCESS_ID =", value, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDNotEqualTo(String value) {
            addCriterion("ID_PROCESS_ID <>", value, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDGreaterThan(String value) {
            addCriterion("ID_PROCESS_ID >", value, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ID_PROCESS_ID >=", value, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDLessThan(String value) {
            addCriterion("ID_PROCESS_ID <", value, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDLessThanOrEqualTo(String value) {
            addCriterion("ID_PROCESS_ID <=", value, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDLike(String value) {
            addCriterion("ID_PROCESS_ID like", value, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDNotLike(String value) {
            addCriterion("ID_PROCESS_ID not like", value, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDIn(List<String> values) {
            addCriterion("ID_PROCESS_ID in", values, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDNotIn(List<String> values) {
            addCriterion("ID_PROCESS_ID not in", values, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDBetween(String value1, String value2) {
            addCriterion("ID_PROCESS_ID between", value1, value2, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDNotBetween(String value1, String value2) {
            addCriterion("ID_PROCESS_ID not between", value1, value2, "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNIsNull() {
            addCriterion("PROCESS_KBN is null");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNIsNotNull() {
            addCriterion("PROCESS_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNEqualTo(String value) {
            addCriterion("PROCESS_KBN =", value, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNNotEqualTo(String value) {
            addCriterion("PROCESS_KBN <>", value, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNGreaterThan(String value) {
            addCriterion("PROCESS_KBN >", value, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("PROCESS_KBN >=", value, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNLessThan(String value) {
            addCriterion("PROCESS_KBN <", value, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNLessThanOrEqualTo(String value) {
            addCriterion("PROCESS_KBN <=", value, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNLike(String value) {
            addCriterion("PROCESS_KBN like", value, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNNotLike(String value) {
            addCriterion("PROCESS_KBN not like", value, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNIn(List<String> values) {
            addCriterion("PROCESS_KBN in", values, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNNotIn(List<String> values) {
            addCriterion("PROCESS_KBN not in", values, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNBetween(String value1, String value2) {
            addCriterion("PROCESS_KBN between", value1, value2, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNNotBetween(String value1, String value2) {
            addCriterion("PROCESS_KBN not between", value1, value2, "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIsNull() {
            addCriterion("SYS_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIsNotNull() {
            addCriterion("SYS_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNEqualTo(String value) {
            addCriterion("SYS_KBN =", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotEqualTo(String value) {
            addCriterion("SYS_KBN <>", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNGreaterThan(String value) {
            addCriterion("SYS_KBN >", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SYS_KBN >=", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLessThan(String value) {
            addCriterion("SYS_KBN <", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLessThanOrEqualTo(String value) {
            addCriterion("SYS_KBN <=", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLike(String value) {
            addCriterion("SYS_KBN like", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotLike(String value) {
            addCriterion("SYS_KBN not like", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIn(List<String> values) {
            addCriterion("SYS_KBN in", values, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotIn(List<String> values) {
            addCriterion("SYS_KBN not in", values, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNBetween(String value1, String value2) {
            addCriterion("SYS_KBN between", value1, value2, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotBetween(String value1, String value2) {
            addCriterion("SYS_KBN not between", value1, value2, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_MST_MNTLikeInsensitive(String value) {
            addCriterion("upper(LN_MST_MNT) like", value.toUpperCase(), "LN_MST_MNT");
            return (Criteria) this;
        }

        public Criteria andKEY1LikeInsensitive(String value) {
            addCriterion("upper(KEY1) like", value.toUpperCase(), "KEY1");
            return (Criteria) this;
        }

        public Criteria andKEY2LikeInsensitive(String value) {
            addCriterion("upper(KEY2) like", value.toUpperCase(), "KEY2");
            return (Criteria) this;
        }

        public Criteria andDISP_IDLikeInsensitive(String value) {
            addCriterion("upper(DISP_ID) like", value.toUpperCase(), "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andREASON_IDLikeInsensitive(String value) {
            addCriterion("upper(REASON_ID) like", value.toUpperCase(), "REASON_ID");
            return (Criteria) this;
        }

        public Criteria andMST_MNT_NAIYOULikeInsensitive(String value) {
            addCriterion("upper(MST_MNT_NAIYOU) like", value.toUpperCase(), "MST_MNT_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andID_PROCESS_IDLikeInsensitive(String value) {
            addCriterion("upper(ID_PROCESS_ID) like", value.toUpperCase(), "ID_PROCESS_ID");
            return (Criteria) this;
        }

        public Criteria andPROCESS_KBNLikeInsensitive(String value) {
            addCriterion("upper(PROCESS_KBN) like", value.toUpperCase(), "PROCESS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLikeInsensitive(String value) {
            addCriterion("upper(SYS_KBN) like", value.toUpperCase(), "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_MST_MNT_HTBL
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_MST_MNT_HTBL null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}