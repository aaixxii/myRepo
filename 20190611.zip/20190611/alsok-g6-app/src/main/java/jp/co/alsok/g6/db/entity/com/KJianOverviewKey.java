package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;

public class KJianOverviewKey implements Serializable {
    /**
     * LN_事案概要論理番号
     */
    private String LN_K_JIAN_OVERVIEW;

    /**
     * システム区分
     */
    private String SYS_KBN;

    /**
     * K_JIAN_OVERVIEW
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事案概要論理番号
     * @return LN_K_JIAN_OVERVIEW LN_事案概要論理番号
     */
    public String getLN_K_JIAN_OVERVIEW() {
        return LN_K_JIAN_OVERVIEW;
    }

    /**
     * LN_事案概要論理番号
     * @param LN_K_JIAN_OVERVIEW LN_事案概要論理番号
     */
    public void setLN_K_JIAN_OVERVIEW(String LN_K_JIAN_OVERVIEW) {
        this.LN_K_JIAN_OVERVIEW = LN_K_JIAN_OVERVIEW == null ? null : LN_K_JIAN_OVERVIEW.trim();
    }

    /**
     * システム区分
     * @return SYS_KBN システム区分
     */
    public String getSYS_KBN() {
        return SYS_KBN;
    }

    /**
     * システム区分
     * @param SYS_KBN システム区分
     */
    public void setSYS_KBN(String SYS_KBN) {
        this.SYS_KBN = SYS_KBN == null ? null : SYS_KBN.trim();
    }
}