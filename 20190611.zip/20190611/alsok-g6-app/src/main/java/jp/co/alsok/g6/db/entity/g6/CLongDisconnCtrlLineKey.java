package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CLongDisconnCtrlLineKey implements Serializable {
    /**
     * 送信機ID
     */
    private String TRANS_ID;

    /**
     * 有線無線判別フラグ
     */
    private String WR_FLG;

    /**
     * C_LONG_DISCONN_CTRL_LINE
     */
    private static final long serialVersionUID = 1L;

    /**
     * 送信機ID
     * @return TRANS_ID 送信機ID
     */
    public String getTRANS_ID() {
        return TRANS_ID;
    }

    /**
     * 送信機ID
     * @param TRANS_ID 送信機ID
     */
    public void setTRANS_ID(String TRANS_ID) {
        this.TRANS_ID = TRANS_ID == null ? null : TRANS_ID.trim();
    }

    /**
     * 有線無線判別フラグ
     * @return WR_FLG 有線無線判別フラグ
     */
    public String getWR_FLG() {
        return WR_FLG;
    }

    /**
     * 有線無線判別フラグ
     * @param WR_FLG 有線無線判別フラグ
     */
    public void setWR_FLG(String WR_FLG) {
        this.WR_FLG = WR_FLG == null ? null : WR_FLG.trim();
    }
}