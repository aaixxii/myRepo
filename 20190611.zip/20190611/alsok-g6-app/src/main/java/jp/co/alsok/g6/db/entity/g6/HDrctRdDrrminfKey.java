package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class HDrctRdDrrminfKey implements Serializable {
    /**
     * LN_制御状態読出履歴論理番号
     */
    private String LN_DRCT_RD;

    /**
     * 制御出力情報番号
     */
    private String DRRMINF_NUM;

    /**
     * H_DRCT_RD_DRRMINF
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_制御状態読出履歴論理番号
     * @return LN_DRCT_RD LN_制御状態読出履歴論理番号
     */
    public String getLN_DRCT_RD() {
        return LN_DRCT_RD;
    }

    /**
     * LN_制御状態読出履歴論理番号
     * @param LN_DRCT_RD LN_制御状態読出履歴論理番号
     */
    public void setLN_DRCT_RD(String LN_DRCT_RD) {
        this.LN_DRCT_RD = LN_DRCT_RD == null ? null : LN_DRCT_RD.trim();
    }

    /**
     * 制御出力情報番号
     * @return DRRMINF_NUM 制御出力情報番号
     */
    public String getDRRMINF_NUM() {
        return DRRMINF_NUM;
    }

    /**
     * 制御出力情報番号
     * @param DRRMINF_NUM 制御出力情報番号
     */
    public void setDRRMINF_NUM(String DRRMINF_NUM) {
        this.DRRMINF_NUM = DRRMINF_NUM == null ? null : DRRMINF_NUM.trim();
    }
}