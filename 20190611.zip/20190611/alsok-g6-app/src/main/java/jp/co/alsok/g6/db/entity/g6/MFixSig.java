package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MFixSig implements Serializable {
    /**
     * 固定警報
     */
    private String LN_FIX_SIG;

    /**
     * 信号
     */
    private String SINGO;

    /**
     * 警報名称
     */
    private String KEIHOU_NM;

    /**
     * 備考
     */
    private String BIKOU;

    /**
     * M_FIX_SIG
     */
    private static final long serialVersionUID = 1L;

    /**
     * 固定警報
     * @return LN_FIX_SIG 固定警報
     */
    public String getLN_FIX_SIG() {
        return LN_FIX_SIG;
    }

    /**
     * 固定警報
     * @param LN_FIX_SIG 固定警報
     */
    public void setLN_FIX_SIG(String LN_FIX_SIG) {
        this.LN_FIX_SIG = LN_FIX_SIG == null ? null : LN_FIX_SIG.trim();
    }

    /**
     * 信号
     * @return SINGO 信号
     */
    public String getSINGO() {
        return SINGO;
    }

    /**
     * 信号
     * @param SINGO 信号
     */
    public void setSINGO(String SINGO) {
        this.SINGO = SINGO == null ? null : SINGO.trim();
    }

    /**
     * 警報名称
     * @return KEIHOU_NM 警報名称
     */
    public String getKEIHOU_NM() {
        return KEIHOU_NM;
    }

    /**
     * 警報名称
     * @param KEIHOU_NM 警報名称
     */
    public void setKEIHOU_NM(String KEIHOU_NM) {
        this.KEIHOU_NM = KEIHOU_NM == null ? null : KEIHOU_NM.trim();
    }

    /**
     * 備考
     * @return BIKOU 備考
     */
    public String getBIKOU() {
        return BIKOU;
    }

    /**
     * 備考
     * @param BIKOU 備考
     */
    public void setBIKOU(String BIKOU) {
        this.BIKOU = BIKOU == null ? null : BIKOU.trim();
    }
}