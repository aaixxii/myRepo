package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MAddr extends MAddrKey implements Serializable {
    /**
     * 郵便番号
     */
    private String POST_NUM;

    /**
     * 都道府県名
     */
    private String ADDR_NM1;

    /**
     * 市区町村名
     */
    private String ADDR_NM2;

    /**
     * 大字町名
     */
    private String ADDR_NM3;

    /**
     * 小字町名
     */
    private String ADDR_NM4;

    /**
     * 丁目名
     */
    private String ADDR_NM5;

    /**
     * 番地名
     */
    private String ADDR_NM6;

    /**
     * 都道府県名カナ
     */
    private String ADDR_1_KANA;

    /**
     * 市区町村名カナ
     */
    private String ADDR_2_KANA;

    /**
     * 大字町名カナ
     */
    private String ADDR_3_KANA;

    /**
     * 小字町名カナ
     */
    private String ADDR_4_KANA;

    /**
     * 丁目名カナ
     */
    private String ADDR_5_KANA;

    /**
     * 通り名フラグ
     */
    private String TOORINA_FLG;

    /**
     * 番地名カナ
     */
    private String ADDR_6_KANA;

    /**
     * M_ADDR
     */
    private static final long serialVersionUID = 1L;

    /**
     * 郵便番号
     * @return POST_NUM 郵便番号
     */
    public String getPOST_NUM() {
        return POST_NUM;
    }

    /**
     * 郵便番号
     * @param POST_NUM 郵便番号
     */
    public void setPOST_NUM(String POST_NUM) {
        this.POST_NUM = POST_NUM == null ? null : POST_NUM.trim();
    }

    /**
     * 都道府県名
     * @return ADDR_NM1 都道府県名
     */
    public String getADDR_NM1() {
        return ADDR_NM1;
    }

    /**
     * 都道府県名
     * @param ADDR_NM1 都道府県名
     */
    public void setADDR_NM1(String ADDR_NM1) {
        this.ADDR_NM1 = ADDR_NM1 == null ? null : ADDR_NM1.trim();
    }

    /**
     * 市区町村名
     * @return ADDR_NM2 市区町村名
     */
    public String getADDR_NM2() {
        return ADDR_NM2;
    }

    /**
     * 市区町村名
     * @param ADDR_NM2 市区町村名
     */
    public void setADDR_NM2(String ADDR_NM2) {
        this.ADDR_NM2 = ADDR_NM2 == null ? null : ADDR_NM2.trim();
    }

    /**
     * 大字町名
     * @return ADDR_NM3 大字町名
     */
    public String getADDR_NM3() {
        return ADDR_NM3;
    }

    /**
     * 大字町名
     * @param ADDR_NM3 大字町名
     */
    public void setADDR_NM3(String ADDR_NM3) {
        this.ADDR_NM3 = ADDR_NM3 == null ? null : ADDR_NM3.trim();
    }

    /**
     * 小字町名
     * @return ADDR_NM4 小字町名
     */
    public String getADDR_NM4() {
        return ADDR_NM4;
    }

    /**
     * 小字町名
     * @param ADDR_NM4 小字町名
     */
    public void setADDR_NM4(String ADDR_NM4) {
        this.ADDR_NM4 = ADDR_NM4 == null ? null : ADDR_NM4.trim();
    }

    /**
     * 丁目名
     * @return ADDR_NM5 丁目名
     */
    public String getADDR_NM5() {
        return ADDR_NM5;
    }

    /**
     * 丁目名
     * @param ADDR_NM5 丁目名
     */
    public void setADDR_NM5(String ADDR_NM5) {
        this.ADDR_NM5 = ADDR_NM5 == null ? null : ADDR_NM5.trim();
    }

    /**
     * 番地名
     * @return ADDR_NM6 番地名
     */
    public String getADDR_NM6() {
        return ADDR_NM6;
    }

    /**
     * 番地名
     * @param ADDR_NM6 番地名
     */
    public void setADDR_NM6(String ADDR_NM6) {
        this.ADDR_NM6 = ADDR_NM6 == null ? null : ADDR_NM6.trim();
    }

    /**
     * 都道府県名カナ
     * @return ADDR_1_KANA 都道府県名カナ
     */
    public String getADDR_1_KANA() {
        return ADDR_1_KANA;
    }

    /**
     * 都道府県名カナ
     * @param ADDR_1_KANA 都道府県名カナ
     */
    public void setADDR_1_KANA(String ADDR_1_KANA) {
        this.ADDR_1_KANA = ADDR_1_KANA == null ? null : ADDR_1_KANA.trim();
    }

    /**
     * 市区町村名カナ
     * @return ADDR_2_KANA 市区町村名カナ
     */
    public String getADDR_2_KANA() {
        return ADDR_2_KANA;
    }

    /**
     * 市区町村名カナ
     * @param ADDR_2_KANA 市区町村名カナ
     */
    public void setADDR_2_KANA(String ADDR_2_KANA) {
        this.ADDR_2_KANA = ADDR_2_KANA == null ? null : ADDR_2_KANA.trim();
    }

    /**
     * 大字町名カナ
     * @return ADDR_3_KANA 大字町名カナ
     */
    public String getADDR_3_KANA() {
        return ADDR_3_KANA;
    }

    /**
     * 大字町名カナ
     * @param ADDR_3_KANA 大字町名カナ
     */
    public void setADDR_3_KANA(String ADDR_3_KANA) {
        this.ADDR_3_KANA = ADDR_3_KANA == null ? null : ADDR_3_KANA.trim();
    }

    /**
     * 小字町名カナ
     * @return ADDR_4_KANA 小字町名カナ
     */
    public String getADDR_4_KANA() {
        return ADDR_4_KANA;
    }

    /**
     * 小字町名カナ
     * @param ADDR_4_KANA 小字町名カナ
     */
    public void setADDR_4_KANA(String ADDR_4_KANA) {
        this.ADDR_4_KANA = ADDR_4_KANA == null ? null : ADDR_4_KANA.trim();
    }

    /**
     * 丁目名カナ
     * @return ADDR_5_KANA 丁目名カナ
     */
    public String getADDR_5_KANA() {
        return ADDR_5_KANA;
    }

    /**
     * 丁目名カナ
     * @param ADDR_5_KANA 丁目名カナ
     */
    public void setADDR_5_KANA(String ADDR_5_KANA) {
        this.ADDR_5_KANA = ADDR_5_KANA == null ? null : ADDR_5_KANA.trim();
    }

    /**
     * 通り名フラグ
     * @return TOORINA_FLG 通り名フラグ
     */
    public String getTOORINA_FLG() {
        return TOORINA_FLG;
    }

    /**
     * 通り名フラグ
     * @param TOORINA_FLG 通り名フラグ
     */
    public void setTOORINA_FLG(String TOORINA_FLG) {
        this.TOORINA_FLG = TOORINA_FLG == null ? null : TOORINA_FLG.trim();
    }

    /**
     * 番地名カナ
     * @return ADDR_6_KANA 番地名カナ
     */
    public String getADDR_6_KANA() {
        return ADDR_6_KANA;
    }

    /**
     * 番地名カナ
     * @param ADDR_6_KANA 番地名カナ
     */
    public void setADDR_6_KANA(String ADDR_6_KANA) {
        this.ADDR_6_KANA = ADDR_6_KANA == null ? null : ADDR_6_KANA.trim();
    }
}