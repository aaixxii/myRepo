package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HRmckCmpDtl1 implements Serializable {
    /**
     * LN_遠隔点検結果履歴詳細1論理番号
     */
    private String LN_RMCK_CMP_DTL1;

    /**
     * LN_遠隔点検結果履歴論理番号
     */
    private String LN_RMCK_CMP;

    /**
     * カメラ番号
     */
    private String CAMR_NO;

    /**
     * 通信異常
     */
    private String CAMRE_ST;

    /**
     * カメラ異常
     */
    private String CAMRB_ST;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_RMCK_CMP_DTL1
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_遠隔点検結果履歴詳細1論理番号
     * @return LN_RMCK_CMP_DTL1 LN_遠隔点検結果履歴詳細1論理番号
     */
    public String getLN_RMCK_CMP_DTL1() {
        return LN_RMCK_CMP_DTL1;
    }

    /**
     * LN_遠隔点検結果履歴詳細1論理番号
     * @param LN_RMCK_CMP_DTL1 LN_遠隔点検結果履歴詳細1論理番号
     */
    public void setLN_RMCK_CMP_DTL1(String LN_RMCK_CMP_DTL1) {
        this.LN_RMCK_CMP_DTL1 = LN_RMCK_CMP_DTL1 == null ? null : LN_RMCK_CMP_DTL1.trim();
    }

    /**
     * LN_遠隔点検結果履歴論理番号
     * @return LN_RMCK_CMP LN_遠隔点検結果履歴論理番号
     */
    public String getLN_RMCK_CMP() {
        return LN_RMCK_CMP;
    }

    /**
     * LN_遠隔点検結果履歴論理番号
     * @param LN_RMCK_CMP LN_遠隔点検結果履歴論理番号
     */
    public void setLN_RMCK_CMP(String LN_RMCK_CMP) {
        this.LN_RMCK_CMP = LN_RMCK_CMP == null ? null : LN_RMCK_CMP.trim();
    }

    /**
     * カメラ番号
     * @return CAMR_NO カメラ番号
     */
    public String getCAMR_NO() {
        return CAMR_NO;
    }

    /**
     * カメラ番号
     * @param CAMR_NO カメラ番号
     */
    public void setCAMR_NO(String CAMR_NO) {
        this.CAMR_NO = CAMR_NO == null ? null : CAMR_NO.trim();
    }

    /**
     * 通信異常
     * @return CAMRE_ST 通信異常
     */
    public String getCAMRE_ST() {
        return CAMRE_ST;
    }

    /**
     * 通信異常
     * @param CAMRE_ST 通信異常
     */
    public void setCAMRE_ST(String CAMRE_ST) {
        this.CAMRE_ST = CAMRE_ST == null ? null : CAMRE_ST.trim();
    }

    /**
     * カメラ異常
     * @return CAMRB_ST カメラ異常
     */
    public String getCAMRB_ST() {
        return CAMRB_ST;
    }

    /**
     * カメラ異常
     * @param CAMRB_ST カメラ異常
     */
    public void setCAMRB_ST(String CAMRB_ST) {
        this.CAMRB_ST = CAMRB_ST == null ? null : CAMRB_ST.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}