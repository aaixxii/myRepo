package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HRdKbStsChiku implements Serializable {
    /**
     * LN_警備先地区ゲート関連状態読出履歴論理番号
     */
    private String LN_RD_KB_STS_CHIKU;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * ゲート関連チェックエリア番号
     */
    private String GATE_CHECK_AREA_NUM;

    /**
     * ゲート関連チェック状態
     */
    private String GATE_CHECK_STS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_RD_KB_STS_CHIKU
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_警備先地区ゲート関連状態読出履歴論理番号
     * @return LN_RD_KB_STS_CHIKU LN_警備先地区ゲート関連状態読出履歴論理番号
     */
    public String getLN_RD_KB_STS_CHIKU() {
        return LN_RD_KB_STS_CHIKU;
    }

    /**
     * LN_警備先地区ゲート関連状態読出履歴論理番号
     * @param LN_RD_KB_STS_CHIKU LN_警備先地区ゲート関連状態読出履歴論理番号
     */
    public void setLN_RD_KB_STS_CHIKU(String LN_RD_KB_STS_CHIKU) {
        this.LN_RD_KB_STS_CHIKU = LN_RD_KB_STS_CHIKU == null ? null : LN_RD_KB_STS_CHIKU.trim();
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * ゲート関連チェックエリア番号
     * @return GATE_CHECK_AREA_NUM ゲート関連チェックエリア番号
     */
    public String getGATE_CHECK_AREA_NUM() {
        return GATE_CHECK_AREA_NUM;
    }

    /**
     * ゲート関連チェックエリア番号
     * @param GATE_CHECK_AREA_NUM ゲート関連チェックエリア番号
     */
    public void setGATE_CHECK_AREA_NUM(String GATE_CHECK_AREA_NUM) {
        this.GATE_CHECK_AREA_NUM = GATE_CHECK_AREA_NUM == null ? null : GATE_CHECK_AREA_NUM.trim();
    }

    /**
     * ゲート関連チェック状態
     * @return GATE_CHECK_STS ゲート関連チェック状態
     */
    public String getGATE_CHECK_STS() {
        return GATE_CHECK_STS;
    }

    /**
     * ゲート関連チェック状態
     * @param GATE_CHECK_STS ゲート関連チェック状態
     */
    public void setGATE_CHECK_STS(String GATE_CHECK_STS) {
        this.GATE_CHECK_STS = GATE_CHECK_STS == null ? null : GATE_CHECK_STS.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}