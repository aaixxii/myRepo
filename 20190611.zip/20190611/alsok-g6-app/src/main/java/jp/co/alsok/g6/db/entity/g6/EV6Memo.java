package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EV6Memo implements Serializable {
    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * GC番号
     */
    private String GC_ID;

    /**
     * 用途ID
     */
    private String YOUTO_ID;

    /**
     * 処置区分
     */
    private String SYOCHI_KBN;

    /**
     * 開始日時
     */
    private Date ST_TS;

    /**
     * 終了日時
     */
    private Date ED_TS;

    /**
     * 終了予定日時
     */
    private Date ED_YOTEI_TS;

    /**
     * 人名
     */
    private String PEOPLE_NM;

    /**
     * 人数
     */
    private String PEOPLE_CNT;

    /**
     * 電話番号
     */
    private String TEL_NUM;

    /**
     * 内容１－１
     */
    private String MEMO_NAIYOU11;

    /**
     * 内容１－２
     */
    private String MEMO_NAIYOU12;

    /**
     * 内容１－３
     */
    private String MEMO_NAIYOU13;

    /**
     * 内容２－１
     */
    private String MEMO_NAIYOU21;

    /**
     * 内容２－２
     */
    private String MEMO_NAIYOU22;

    /**
     * 内容２－３
     */
    private String MEMO_NAIYOU23;

    /**
     * 内容２－４
     */
    private String MEMO_NAIYOU24;

    /**
     * 内容２－５
     */
    private String MEMO_NAIYOU25;

    /**
     * 一括登録フラグ
     */
    private String IKKATU_INSERT_FLG;

    /**
     * 登録元識別
     */
    private String TOUROKU_MOTO_KIND;

    /**
     * 事業所ID
     */
    private String JOGYO_ID;

    /**
     * 受付日時
     */
    private Date UKETUKE_TS;

    /**
     * 受付者ID
     */
    private String UKETUKE_ID;

    /**
     * 受付者名
     */
    private String UKETUKE_NM;

    /**
     * 落着日時
     */
    private Date RAUKCHAKU_TS;

    /**
     * 落着者ID
     */
    private String RAKUCHAKU_ID;

    /**
     * 落着者名
     */
    private String RAKUCHAKU_NM;

    /**
     * 残業フラグ
     */
    private String ZANGYO_FLG;

    /**
     * 宿泊フラグ
     */
    private String SYUKUHAKU_FLG;

    /**
     * 臨時警備フラグ
     */
    private String RINKEI_FLG;

    /**
     * 監視対象外フラグ
     */
    private String KGAI_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_V6_MEMO
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * GC番号
     * @return GC_ID GC番号
     */
    public String getGC_ID() {
        return GC_ID;
    }

    /**
     * GC番号
     * @param GC_ID GC番号
     */
    public void setGC_ID(String GC_ID) {
        this.GC_ID = GC_ID == null ? null : GC_ID.trim();
    }

    /**
     * 用途ID
     * @return YOUTO_ID 用途ID
     */
    public String getYOUTO_ID() {
        return YOUTO_ID;
    }

    /**
     * 用途ID
     * @param YOUTO_ID 用途ID
     */
    public void setYOUTO_ID(String YOUTO_ID) {
        this.YOUTO_ID = YOUTO_ID == null ? null : YOUTO_ID.trim();
    }

    /**
     * 処置区分
     * @return SYOCHI_KBN 処置区分
     */
    public String getSYOCHI_KBN() {
        return SYOCHI_KBN;
    }

    /**
     * 処置区分
     * @param SYOCHI_KBN 処置区分
     */
    public void setSYOCHI_KBN(String SYOCHI_KBN) {
        this.SYOCHI_KBN = SYOCHI_KBN == null ? null : SYOCHI_KBN.trim();
    }

    /**
     * 開始日時
     * @return ST_TS 開始日時
     */
    public Date getST_TS() {
        return ST_TS;
    }

    /**
     * 開始日時
     * @param ST_TS 開始日時
     */
    public void setST_TS(Date ST_TS) {
        this.ST_TS = ST_TS;
    }

    /**
     * 終了日時
     * @return ED_TS 終了日時
     */
    public Date getED_TS() {
        return ED_TS;
    }

    /**
     * 終了日時
     * @param ED_TS 終了日時
     */
    public void setED_TS(Date ED_TS) {
        this.ED_TS = ED_TS;
    }

    /**
     * 終了予定日時
     * @return ED_YOTEI_TS 終了予定日時
     */
    public Date getED_YOTEI_TS() {
        return ED_YOTEI_TS;
    }

    /**
     * 終了予定日時
     * @param ED_YOTEI_TS 終了予定日時
     */
    public void setED_YOTEI_TS(Date ED_YOTEI_TS) {
        this.ED_YOTEI_TS = ED_YOTEI_TS;
    }

    /**
     * 人名
     * @return PEOPLE_NM 人名
     */
    public String getPEOPLE_NM() {
        return PEOPLE_NM;
    }

    /**
     * 人名
     * @param PEOPLE_NM 人名
     */
    public void setPEOPLE_NM(String PEOPLE_NM) {
        this.PEOPLE_NM = PEOPLE_NM == null ? null : PEOPLE_NM.trim();
    }

    /**
     * 人数
     * @return PEOPLE_CNT 人数
     */
    public String getPEOPLE_CNT() {
        return PEOPLE_CNT;
    }

    /**
     * 人数
     * @param PEOPLE_CNT 人数
     */
    public void setPEOPLE_CNT(String PEOPLE_CNT) {
        this.PEOPLE_CNT = PEOPLE_CNT == null ? null : PEOPLE_CNT.trim();
    }

    /**
     * 電話番号
     * @return TEL_NUM 電話番号
     */
    public String getTEL_NUM() {
        return TEL_NUM;
    }

    /**
     * 電話番号
     * @param TEL_NUM 電話番号
     */
    public void setTEL_NUM(String TEL_NUM) {
        this.TEL_NUM = TEL_NUM == null ? null : TEL_NUM.trim();
    }

    /**
     * 内容１－１
     * @return MEMO_NAIYOU11 内容１－１
     */
    public String getMEMO_NAIYOU11() {
        return MEMO_NAIYOU11;
    }

    /**
     * 内容１－１
     * @param MEMO_NAIYOU11 内容１－１
     */
    public void setMEMO_NAIYOU11(String MEMO_NAIYOU11) {
        this.MEMO_NAIYOU11 = MEMO_NAIYOU11 == null ? null : MEMO_NAIYOU11.trim();
    }

    /**
     * 内容１－２
     * @return MEMO_NAIYOU12 内容１－２
     */
    public String getMEMO_NAIYOU12() {
        return MEMO_NAIYOU12;
    }

    /**
     * 内容１－２
     * @param MEMO_NAIYOU12 内容１－２
     */
    public void setMEMO_NAIYOU12(String MEMO_NAIYOU12) {
        this.MEMO_NAIYOU12 = MEMO_NAIYOU12 == null ? null : MEMO_NAIYOU12.trim();
    }

    /**
     * 内容１－３
     * @return MEMO_NAIYOU13 内容１－３
     */
    public String getMEMO_NAIYOU13() {
        return MEMO_NAIYOU13;
    }

    /**
     * 内容１－３
     * @param MEMO_NAIYOU13 内容１－３
     */
    public void setMEMO_NAIYOU13(String MEMO_NAIYOU13) {
        this.MEMO_NAIYOU13 = MEMO_NAIYOU13 == null ? null : MEMO_NAIYOU13.trim();
    }

    /**
     * 内容２－１
     * @return MEMO_NAIYOU21 内容２－１
     */
    public String getMEMO_NAIYOU21() {
        return MEMO_NAIYOU21;
    }

    /**
     * 内容２－１
     * @param MEMO_NAIYOU21 内容２－１
     */
    public void setMEMO_NAIYOU21(String MEMO_NAIYOU21) {
        this.MEMO_NAIYOU21 = MEMO_NAIYOU21 == null ? null : MEMO_NAIYOU21.trim();
    }

    /**
     * 内容２－２
     * @return MEMO_NAIYOU22 内容２－２
     */
    public String getMEMO_NAIYOU22() {
        return MEMO_NAIYOU22;
    }

    /**
     * 内容２－２
     * @param MEMO_NAIYOU22 内容２－２
     */
    public void setMEMO_NAIYOU22(String MEMO_NAIYOU22) {
        this.MEMO_NAIYOU22 = MEMO_NAIYOU22 == null ? null : MEMO_NAIYOU22.trim();
    }

    /**
     * 内容２－３
     * @return MEMO_NAIYOU23 内容２－３
     */
    public String getMEMO_NAIYOU23() {
        return MEMO_NAIYOU23;
    }

    /**
     * 内容２－３
     * @param MEMO_NAIYOU23 内容２－３
     */
    public void setMEMO_NAIYOU23(String MEMO_NAIYOU23) {
        this.MEMO_NAIYOU23 = MEMO_NAIYOU23 == null ? null : MEMO_NAIYOU23.trim();
    }

    /**
     * 内容２－４
     * @return MEMO_NAIYOU24 内容２－４
     */
    public String getMEMO_NAIYOU24() {
        return MEMO_NAIYOU24;
    }

    /**
     * 内容２－４
     * @param MEMO_NAIYOU24 内容２－４
     */
    public void setMEMO_NAIYOU24(String MEMO_NAIYOU24) {
        this.MEMO_NAIYOU24 = MEMO_NAIYOU24 == null ? null : MEMO_NAIYOU24.trim();
    }

    /**
     * 内容２－５
     * @return MEMO_NAIYOU25 内容２－５
     */
    public String getMEMO_NAIYOU25() {
        return MEMO_NAIYOU25;
    }

    /**
     * 内容２－５
     * @param MEMO_NAIYOU25 内容２－５
     */
    public void setMEMO_NAIYOU25(String MEMO_NAIYOU25) {
        this.MEMO_NAIYOU25 = MEMO_NAIYOU25 == null ? null : MEMO_NAIYOU25.trim();
    }

    /**
     * 一括登録フラグ
     * @return IKKATU_INSERT_FLG 一括登録フラグ
     */
    public String getIKKATU_INSERT_FLG() {
        return IKKATU_INSERT_FLG;
    }

    /**
     * 一括登録フラグ
     * @param IKKATU_INSERT_FLG 一括登録フラグ
     */
    public void setIKKATU_INSERT_FLG(String IKKATU_INSERT_FLG) {
        this.IKKATU_INSERT_FLG = IKKATU_INSERT_FLG == null ? null : IKKATU_INSERT_FLG.trim();
    }

    /**
     * 登録元識別
     * @return TOUROKU_MOTO_KIND 登録元識別
     */
    public String getTOUROKU_MOTO_KIND() {
        return TOUROKU_MOTO_KIND;
    }

    /**
     * 登録元識別
     * @param TOUROKU_MOTO_KIND 登録元識別
     */
    public void setTOUROKU_MOTO_KIND(String TOUROKU_MOTO_KIND) {
        this.TOUROKU_MOTO_KIND = TOUROKU_MOTO_KIND == null ? null : TOUROKU_MOTO_KIND.trim();
    }

    /**
     * 事業所ID
     * @return JOGYO_ID 事業所ID
     */
    public String getJOGYO_ID() {
        return JOGYO_ID;
    }

    /**
     * 事業所ID
     * @param JOGYO_ID 事業所ID
     */
    public void setJOGYO_ID(String JOGYO_ID) {
        this.JOGYO_ID = JOGYO_ID == null ? null : JOGYO_ID.trim();
    }

    /**
     * 受付日時
     * @return UKETUKE_TS 受付日時
     */
    public Date getUKETUKE_TS() {
        return UKETUKE_TS;
    }

    /**
     * 受付日時
     * @param UKETUKE_TS 受付日時
     */
    public void setUKETUKE_TS(Date UKETUKE_TS) {
        this.UKETUKE_TS = UKETUKE_TS;
    }

    /**
     * 受付者ID
     * @return UKETUKE_ID 受付者ID
     */
    public String getUKETUKE_ID() {
        return UKETUKE_ID;
    }

    /**
     * 受付者ID
     * @param UKETUKE_ID 受付者ID
     */
    public void setUKETUKE_ID(String UKETUKE_ID) {
        this.UKETUKE_ID = UKETUKE_ID == null ? null : UKETUKE_ID.trim();
    }

    /**
     * 受付者名
     * @return UKETUKE_NM 受付者名
     */
    public String getUKETUKE_NM() {
        return UKETUKE_NM;
    }

    /**
     * 受付者名
     * @param UKETUKE_NM 受付者名
     */
    public void setUKETUKE_NM(String UKETUKE_NM) {
        this.UKETUKE_NM = UKETUKE_NM == null ? null : UKETUKE_NM.trim();
    }

    /**
     * 落着日時
     * @return RAUKCHAKU_TS 落着日時
     */
    public Date getRAUKCHAKU_TS() {
        return RAUKCHAKU_TS;
    }

    /**
     * 落着日時
     * @param RAUKCHAKU_TS 落着日時
     */
    public void setRAUKCHAKU_TS(Date RAUKCHAKU_TS) {
        this.RAUKCHAKU_TS = RAUKCHAKU_TS;
    }

    /**
     * 落着者ID
     * @return RAKUCHAKU_ID 落着者ID
     */
    public String getRAKUCHAKU_ID() {
        return RAKUCHAKU_ID;
    }

    /**
     * 落着者ID
     * @param RAKUCHAKU_ID 落着者ID
     */
    public void setRAKUCHAKU_ID(String RAKUCHAKU_ID) {
        this.RAKUCHAKU_ID = RAKUCHAKU_ID == null ? null : RAKUCHAKU_ID.trim();
    }

    /**
     * 落着者名
     * @return RAKUCHAKU_NM 落着者名
     */
    public String getRAKUCHAKU_NM() {
        return RAKUCHAKU_NM;
    }

    /**
     * 落着者名
     * @param RAKUCHAKU_NM 落着者名
     */
    public void setRAKUCHAKU_NM(String RAKUCHAKU_NM) {
        this.RAKUCHAKU_NM = RAKUCHAKU_NM == null ? null : RAKUCHAKU_NM.trim();
    }

    /**
     * 残業フラグ
     * @return ZANGYO_FLG 残業フラグ
     */
    public String getZANGYO_FLG() {
        return ZANGYO_FLG;
    }

    /**
     * 残業フラグ
     * @param ZANGYO_FLG 残業フラグ
     */
    public void setZANGYO_FLG(String ZANGYO_FLG) {
        this.ZANGYO_FLG = ZANGYO_FLG == null ? null : ZANGYO_FLG.trim();
    }

    /**
     * 宿泊フラグ
     * @return SYUKUHAKU_FLG 宿泊フラグ
     */
    public String getSYUKUHAKU_FLG() {
        return SYUKUHAKU_FLG;
    }

    /**
     * 宿泊フラグ
     * @param SYUKUHAKU_FLG 宿泊フラグ
     */
    public void setSYUKUHAKU_FLG(String SYUKUHAKU_FLG) {
        this.SYUKUHAKU_FLG = SYUKUHAKU_FLG == null ? null : SYUKUHAKU_FLG.trim();
    }

    /**
     * 臨時警備フラグ
     * @return RINKEI_FLG 臨時警備フラグ
     */
    public String getRINKEI_FLG() {
        return RINKEI_FLG;
    }

    /**
     * 臨時警備フラグ
     * @param RINKEI_FLG 臨時警備フラグ
     */
    public void setRINKEI_FLG(String RINKEI_FLG) {
        this.RINKEI_FLG = RINKEI_FLG == null ? null : RINKEI_FLG.trim();
    }

    /**
     * 監視対象外フラグ
     * @return KGAI_FLG 監視対象外フラグ
     */
    public String getKGAI_FLG() {
        return KGAI_FLG;
    }

    /**
     * 監視対象外フラグ
     * @param KGAI_FLG 監視対象外フラグ
     */
    public void setKGAI_FLG(String KGAI_FLG) {
        this.KGAI_FLG = KGAI_FLG == null ? null : KGAI_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}