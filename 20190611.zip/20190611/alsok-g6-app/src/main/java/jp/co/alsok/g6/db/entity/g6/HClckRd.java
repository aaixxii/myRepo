package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HClckRd implements Serializable {
    /**
     * LN_時計情報取得履歴論理番号
     */
    private String LN_CLCK_RD;

    /**
     * 要求結果
     */
    private String RQ_RSLT;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * 現在時刻
     */
    private String CR_TIME;

    /**
     * エラーコード
     */
    private String RESULT_CD;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_CLCK_RD
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_時計情報取得履歴論理番号
     * @return LN_CLCK_RD LN_時計情報取得履歴論理番号
     */
    public String getLN_CLCK_RD() {
        return LN_CLCK_RD;
    }

    /**
     * LN_時計情報取得履歴論理番号
     * @param LN_CLCK_RD LN_時計情報取得履歴論理番号
     */
    public void setLN_CLCK_RD(String LN_CLCK_RD) {
        this.LN_CLCK_RD = LN_CLCK_RD == null ? null : LN_CLCK_RD.trim();
    }

    /**
     * 要求結果
     * @return RQ_RSLT 要求結果
     */
    public String getRQ_RSLT() {
        return RQ_RSLT;
    }

    /**
     * 要求結果
     * @param RQ_RSLT 要求結果
     */
    public void setRQ_RSLT(String RQ_RSLT) {
        this.RQ_RSLT = RQ_RSLT == null ? null : RQ_RSLT.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * 現在時刻
     * @return CR_TIME 現在時刻
     */
    public String getCR_TIME() {
        return CR_TIME;
    }

    /**
     * 現在時刻
     * @param CR_TIME 現在時刻
     */
    public void setCR_TIME(String CR_TIME) {
        this.CR_TIME = CR_TIME == null ? null : CR_TIME.trim();
    }

    /**
     * エラーコード
     * @return RESULT_CD エラーコード
     */
    public String getRESULT_CD() {
        return RESULT_CD;
    }

    /**
     * エラーコード
     * @param RESULT_CD エラーコード
     */
    public void setRESULT_CD(String RESULT_CD) {
        this.RESULT_CD = RESULT_CD == null ? null : RESULT_CD.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}