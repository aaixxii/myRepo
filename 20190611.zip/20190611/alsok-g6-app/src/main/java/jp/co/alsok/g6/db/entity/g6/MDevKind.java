package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MDevKind implements Serializable {
    /**
     * 機器種別コード
     */
    private String DEV_KIND_CD;

    /**
     * 種別コード
     */
    private String KIND_CD;

    /**
     * 型式
     */
    private String MODEL_TYPE;

    /**
     * FW有無フラグ
     */
    private String FW_FLG;

    /**
     * SD有無フラグ
     */
    private String SD_FLG;

    /**
     * アイコンリソースID
     */
    private String ID_ICON;

    /**
     * M_DEV_KIND
     */
    private static final long serialVersionUID = 1L;

    /**
     * 機器種別コード
     * @return DEV_KIND_CD 機器種別コード
     */
    public String getDEV_KIND_CD() {
        return DEV_KIND_CD;
    }

    /**
     * 機器種別コード
     * @param DEV_KIND_CD 機器種別コード
     */
    public void setDEV_KIND_CD(String DEV_KIND_CD) {
        this.DEV_KIND_CD = DEV_KIND_CD == null ? null : DEV_KIND_CD.trim();
    }

    /**
     * 種別コード
     * @return KIND_CD 種別コード
     */
    public String getKIND_CD() {
        return KIND_CD;
    }

    /**
     * 種別コード
     * @param KIND_CD 種別コード
     */
    public void setKIND_CD(String KIND_CD) {
        this.KIND_CD = KIND_CD == null ? null : KIND_CD.trim();
    }

    /**
     * 型式
     * @return MODEL_TYPE 型式
     */
    public String getMODEL_TYPE() {
        return MODEL_TYPE;
    }

    /**
     * 型式
     * @param MODEL_TYPE 型式
     */
    public void setMODEL_TYPE(String MODEL_TYPE) {
        this.MODEL_TYPE = MODEL_TYPE == null ? null : MODEL_TYPE.trim();
    }

    /**
     * FW有無フラグ
     * @return FW_FLG FW有無フラグ
     */
    public String getFW_FLG() {
        return FW_FLG;
    }

    /**
     * FW有無フラグ
     * @param FW_FLG FW有無フラグ
     */
    public void setFW_FLG(String FW_FLG) {
        this.FW_FLG = FW_FLG == null ? null : FW_FLG.trim();
    }

    /**
     * SD有無フラグ
     * @return SD_FLG SD有無フラグ
     */
    public String getSD_FLG() {
        return SD_FLG;
    }

    /**
     * SD有無フラグ
     * @param SD_FLG SD有無フラグ
     */
    public void setSD_FLG(String SD_FLG) {
        this.SD_FLG = SD_FLG == null ? null : SD_FLG.trim();
    }

    /**
     * アイコンリソースID
     * @return ID_ICON アイコンリソースID
     */
    public String getID_ICON() {
        return ID_ICON;
    }

    /**
     * アイコンリソースID
     * @param ID_ICON アイコンリソースID
     */
    public void setID_ICON(String ID_ICON) {
        this.ID_ICON = ID_ICON == null ? null : ID_ICON.trim();
    }
}