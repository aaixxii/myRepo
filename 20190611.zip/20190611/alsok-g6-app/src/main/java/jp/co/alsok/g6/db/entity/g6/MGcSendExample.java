package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MGcSendExample {
    /**
     * M_GC_SEND
     */
    protected String orderByClause;

    /**
     * M_GC_SEND
     */
    protected boolean distinct;

    /**
     * M_GC_SEND
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MGcSendExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_GC_SEND null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andKB_SERVICE_CDIsNull() {
            addCriterion("KB_SERVICE_CD is null");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDIsNotNull() {
            addCriterion("KB_SERVICE_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDEqualTo(String value) {
            addCriterion("KB_SERVICE_CD =", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDNotEqualTo(String value) {
            addCriterion("KB_SERVICE_CD <>", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDGreaterThan(String value) {
            addCriterion("KB_SERVICE_CD >", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KB_SERVICE_CD >=", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDLessThan(String value) {
            addCriterion("KB_SERVICE_CD <", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDLessThanOrEqualTo(String value) {
            addCriterion("KB_SERVICE_CD <=", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDLike(String value) {
            addCriterion("KB_SERVICE_CD like", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDNotLike(String value) {
            addCriterion("KB_SERVICE_CD not like", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDIn(List<String> values) {
            addCriterion("KB_SERVICE_CD in", values, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDNotIn(List<String> values) {
            addCriterion("KB_SERVICE_CD not in", values, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDBetween(String value1, String value2) {
            addCriterion("KB_SERVICE_CD between", value1, value2, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDNotBetween(String value1, String value2) {
            addCriterion("KB_SERVICE_CD not between", value1, value2, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1IsNull() {
            addCriterion("SIG_KIND_1 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1IsNotNull() {
            addCriterion("SIG_KIND_1 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1EqualTo(String value) {
            addCriterion("SIG_KIND_1 =", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotEqualTo(String value) {
            addCriterion("SIG_KIND_1 <>", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1GreaterThan(String value) {
            addCriterion("SIG_KIND_1 >", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_1 >=", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LessThan(String value) {
            addCriterion("SIG_KIND_1 <", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_1 <=", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1Like(String value) {
            addCriterion("SIG_KIND_1 like", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotLike(String value) {
            addCriterion("SIG_KIND_1 not like", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1In(List<String> values) {
            addCriterion("SIG_KIND_1 in", values, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotIn(List<String> values) {
            addCriterion("SIG_KIND_1 not in", values, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1Between(String value1, String value2) {
            addCriterion("SIG_KIND_1 between", value1, value2, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_1 not between", value1, value2, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2IsNull() {
            addCriterion("SIG_KIND_2 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2IsNotNull() {
            addCriterion("SIG_KIND_2 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2EqualTo(String value) {
            addCriterion("SIG_KIND_2 =", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotEqualTo(String value) {
            addCriterion("SIG_KIND_2 <>", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2GreaterThan(String value) {
            addCriterion("SIG_KIND_2 >", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_2 >=", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LessThan(String value) {
            addCriterion("SIG_KIND_2 <", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_2 <=", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2Like(String value) {
            addCriterion("SIG_KIND_2 like", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotLike(String value) {
            addCriterion("SIG_KIND_2 not like", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2In(List<String> values) {
            addCriterion("SIG_KIND_2 in", values, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotIn(List<String> values) {
            addCriterion("SIG_KIND_2 not in", values, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2Between(String value1, String value2) {
            addCriterion("SIG_KIND_2 between", value1, value2, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_2 not between", value1, value2, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGIsNull() {
            addCriterion("GC_DN0_SEND_FLG is null");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGIsNotNull() {
            addCriterion("GC_DN0_SEND_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGEqualTo(String value) {
            addCriterion("GC_DN0_SEND_FLG =", value, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGNotEqualTo(String value) {
            addCriterion("GC_DN0_SEND_FLG <>", value, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGGreaterThan(String value) {
            addCriterion("GC_DN0_SEND_FLG >", value, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("GC_DN0_SEND_FLG >=", value, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGLessThan(String value) {
            addCriterion("GC_DN0_SEND_FLG <", value, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGLessThanOrEqualTo(String value) {
            addCriterion("GC_DN0_SEND_FLG <=", value, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGLike(String value) {
            addCriterion("GC_DN0_SEND_FLG like", value, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGNotLike(String value) {
            addCriterion("GC_DN0_SEND_FLG not like", value, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGIn(List<String> values) {
            addCriterion("GC_DN0_SEND_FLG in", values, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGNotIn(List<String> values) {
            addCriterion("GC_DN0_SEND_FLG not in", values, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGBetween(String value1, String value2) {
            addCriterion("GC_DN0_SEND_FLG between", value1, value2, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGNotBetween(String value1, String value2) {
            addCriterion("GC_DN0_SEND_FLG not between", value1, value2, "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGIsNull() {
            addCriterion("GC_DF0_SEND_FLG is null");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGIsNotNull() {
            addCriterion("GC_DF0_SEND_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGEqualTo(String value) {
            addCriterion("GC_DF0_SEND_FLG =", value, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGNotEqualTo(String value) {
            addCriterion("GC_DF0_SEND_FLG <>", value, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGGreaterThan(String value) {
            addCriterion("GC_DF0_SEND_FLG >", value, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("GC_DF0_SEND_FLG >=", value, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGLessThan(String value) {
            addCriterion("GC_DF0_SEND_FLG <", value, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGLessThanOrEqualTo(String value) {
            addCriterion("GC_DF0_SEND_FLG <=", value, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGLike(String value) {
            addCriterion("GC_DF0_SEND_FLG like", value, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGNotLike(String value) {
            addCriterion("GC_DF0_SEND_FLG not like", value, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGIn(List<String> values) {
            addCriterion("GC_DF0_SEND_FLG in", values, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGNotIn(List<String> values) {
            addCriterion("GC_DF0_SEND_FLG not in", values, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGBetween(String value1, String value2) {
            addCriterion("GC_DF0_SEND_FLG between", value1, value2, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGNotBetween(String value1, String value2) {
            addCriterion("GC_DF0_SEND_FLG not between", value1, value2, "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDLikeInsensitive(String value) {
            addCriterion("upper(KB_SERVICE_CD) like", value.toUpperCase(), "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_1) like", value.toUpperCase(), "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_2) like", value.toUpperCase(), "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andGC_DN0_SEND_FLGLikeInsensitive(String value) {
            addCriterion("upper(GC_DN0_SEND_FLG) like", value.toUpperCase(), "GC_DN0_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_DF0_SEND_FLGLikeInsensitive(String value) {
            addCriterion("upper(GC_DF0_SEND_FLG) like", value.toUpperCase(), "GC_DF0_SEND_FLG");
            return (Criteria) this;
        }
    }

    /**
     * M_GC_SEND
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_GC_SEND null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}