package jp.co.alsok.g6.db.entity.com;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class KGcExample {
    /**
     * K_GC
     */
    protected String orderByClause;

    /**
     * K_GC
     */
    protected boolean distinct;

    /**
     * K_GC
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public KGcExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * K_GC null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andGC_CDIsNull() {
            addCriterion("GC_CD is null");
            return (Criteria) this;
        }

        public Criteria andGC_CDIsNotNull() {
            addCriterion("GC_CD is not null");
            return (Criteria) this;
        }

        public Criteria andGC_CDEqualTo(String value) {
            addCriterion("GC_CD =", value, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDNotEqualTo(String value) {
            addCriterion("GC_CD <>", value, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDGreaterThan(String value) {
            addCriterion("GC_CD >", value, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDGreaterThanOrEqualTo(String value) {
            addCriterion("GC_CD >=", value, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDLessThan(String value) {
            addCriterion("GC_CD <", value, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDLessThanOrEqualTo(String value) {
            addCriterion("GC_CD <=", value, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDLike(String value) {
            addCriterion("GC_CD like", value, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDNotLike(String value) {
            addCriterion("GC_CD not like", value, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDIn(List<String> values) {
            addCriterion("GC_CD in", values, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDNotIn(List<String> values) {
            addCriterion("GC_CD not in", values, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDBetween(String value1, String value2) {
            addCriterion("GC_CD between", value1, value2, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_CDNotBetween(String value1, String value2) {
            addCriterion("GC_CD not between", value1, value2, "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_NMIsNull() {
            addCriterion("GC_NM is null");
            return (Criteria) this;
        }

        public Criteria andGC_NMIsNotNull() {
            addCriterion("GC_NM is not null");
            return (Criteria) this;
        }

        public Criteria andGC_NMEqualTo(String value) {
            addCriterion("GC_NM =", value, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMNotEqualTo(String value) {
            addCriterion("GC_NM <>", value, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMGreaterThan(String value) {
            addCriterion("GC_NM >", value, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMGreaterThanOrEqualTo(String value) {
            addCriterion("GC_NM >=", value, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMLessThan(String value) {
            addCriterion("GC_NM <", value, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMLessThanOrEqualTo(String value) {
            addCriterion("GC_NM <=", value, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMLike(String value) {
            addCriterion("GC_NM like", value, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMNotLike(String value) {
            addCriterion("GC_NM not like", value, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMIn(List<String> values) {
            addCriterion("GC_NM in", values, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMNotIn(List<String> values) {
            addCriterion("GC_NM not in", values, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMBetween(String value1, String value2) {
            addCriterion("GC_NM between", value1, value2, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_NMNotBetween(String value1, String value2) {
            addCriterion("GC_NM not between", value1, value2, "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMIsNull() {
            addCriterion("GC_TEL_NUM is null");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMIsNotNull() {
            addCriterion("GC_TEL_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMEqualTo(String value) {
            addCriterion("GC_TEL_NUM =", value, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMNotEqualTo(String value) {
            addCriterion("GC_TEL_NUM <>", value, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMGreaterThan(String value) {
            addCriterion("GC_TEL_NUM >", value, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("GC_TEL_NUM >=", value, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMLessThan(String value) {
            addCriterion("GC_TEL_NUM <", value, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMLessThanOrEqualTo(String value) {
            addCriterion("GC_TEL_NUM <=", value, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMLike(String value) {
            addCriterion("GC_TEL_NUM like", value, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMNotLike(String value) {
            addCriterion("GC_TEL_NUM not like", value, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMIn(List<String> values) {
            addCriterion("GC_TEL_NUM in", values, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMNotIn(List<String> values) {
            addCriterion("GC_TEL_NUM not in", values, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMBetween(String value1, String value2) {
            addCriterion("GC_TEL_NUM between", value1, value2, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMNotBetween(String value1, String value2) {
            addCriterion("GC_TEL_NUM not between", value1, value2, "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDIsNull() {
            addCriterion("UPPER_GC_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDIsNotNull() {
            addCriterion("UPPER_GC_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDEqualTo(String value) {
            addCriterion("UPPER_GC_CD =", value, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDNotEqualTo(String value) {
            addCriterion("UPPER_GC_CD <>", value, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDGreaterThan(String value) {
            addCriterion("UPPER_GC_CD >", value, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPPER_GC_CD >=", value, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDLessThan(String value) {
            addCriterion("UPPER_GC_CD <", value, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDLessThanOrEqualTo(String value) {
            addCriterion("UPPER_GC_CD <=", value, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDLike(String value) {
            addCriterion("UPPER_GC_CD like", value, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDNotLike(String value) {
            addCriterion("UPPER_GC_CD not like", value, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDIn(List<String> values) {
            addCriterion("UPPER_GC_CD in", values, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDNotIn(List<String> values) {
            addCriterion("UPPER_GC_CD not in", values, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDBetween(String value1, String value2) {
            addCriterion("UPPER_GC_CD between", value1, value2, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDNotBetween(String value1, String value2) {
            addCriterion("UPPER_GC_CD not between", value1, value2, "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGIsNull() {
            addCriterion("SYNC_ABL_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGIsNotNull() {
            addCriterion("SYNC_ABL_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGEqualTo(String value) {
            addCriterion("SYNC_ABL_FLG =", value, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGNotEqualTo(String value) {
            addCriterion("SYNC_ABL_FLG <>", value, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGGreaterThan(String value) {
            addCriterion("SYNC_ABL_FLG >", value, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SYNC_ABL_FLG >=", value, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGLessThan(String value) {
            addCriterion("SYNC_ABL_FLG <", value, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGLessThanOrEqualTo(String value) {
            addCriterion("SYNC_ABL_FLG <=", value, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGLike(String value) {
            addCriterion("SYNC_ABL_FLG like", value, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGNotLike(String value) {
            addCriterion("SYNC_ABL_FLG not like", value, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGIn(List<String> values) {
            addCriterion("SYNC_ABL_FLG in", values, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGNotIn(List<String> values) {
            addCriterion("SYNC_ABL_FLG not in", values, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGBetween(String value1, String value2) {
            addCriterion("SYNC_ABL_FLG between", value1, value2, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGNotBetween(String value1, String value2) {
            addCriterion("SYNC_ABL_FLG not between", value1, value2, "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRIsNull() {
            addCriterion("IP_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRIsNotNull() {
            addCriterion("IP_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andIP_ADDREqualTo(String value) {
            addCriterion("IP_ADDR =", value, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRNotEqualTo(String value) {
            addCriterion("IP_ADDR <>", value, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRGreaterThan(String value) {
            addCriterion("IP_ADDR >", value, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRGreaterThanOrEqualTo(String value) {
            addCriterion("IP_ADDR >=", value, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRLessThan(String value) {
            addCriterion("IP_ADDR <", value, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRLessThanOrEqualTo(String value) {
            addCriterion("IP_ADDR <=", value, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRLike(String value) {
            addCriterion("IP_ADDR like", value, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRNotLike(String value) {
            addCriterion("IP_ADDR not like", value, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRIn(List<String> values) {
            addCriterion("IP_ADDR in", values, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRNotIn(List<String> values) {
            addCriterion("IP_ADDR not in", values, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRBetween(String value1, String value2) {
            addCriterion("IP_ADDR between", value1, value2, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRNotBetween(String value1, String value2) {
            addCriterion("IP_ADDR not between", value1, value2, "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDIsNull() {
            addCriterion("GYOUMU_CD is null");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDIsNotNull() {
            addCriterion("GYOUMU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDEqualTo(String value) {
            addCriterion("GYOUMU_CD =", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDNotEqualTo(String value) {
            addCriterion("GYOUMU_CD <>", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDGreaterThan(String value) {
            addCriterion("GYOUMU_CD >", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("GYOUMU_CD >=", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDLessThan(String value) {
            addCriterion("GYOUMU_CD <", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDLessThanOrEqualTo(String value) {
            addCriterion("GYOUMU_CD <=", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDLike(String value) {
            addCriterion("GYOUMU_CD like", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDNotLike(String value) {
            addCriterion("GYOUMU_CD not like", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDIn(List<String> values) {
            addCriterion("GYOUMU_CD in", values, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDNotIn(List<String> values) {
            addCriterion("GYOUMU_CD not in", values, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDBetween(String value1, String value2) {
            addCriterion("GYOUMU_CD between", value1, value2, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDNotBetween(String value1, String value2) {
            addCriterion("GYOUMU_CD not between", value1, value2, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDB_NMIsNull() {
            addCriterion("DB_NM is null");
            return (Criteria) this;
        }

        public Criteria andDB_NMIsNotNull() {
            addCriterion("DB_NM is not null");
            return (Criteria) this;
        }

        public Criteria andDB_NMEqualTo(String value) {
            addCriterion("DB_NM =", value, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMNotEqualTo(String value) {
            addCriterion("DB_NM <>", value, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMGreaterThan(String value) {
            addCriterion("DB_NM >", value, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMGreaterThanOrEqualTo(String value) {
            addCriterion("DB_NM >=", value, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMLessThan(String value) {
            addCriterion("DB_NM <", value, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMLessThanOrEqualTo(String value) {
            addCriterion("DB_NM <=", value, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMLike(String value) {
            addCriterion("DB_NM like", value, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMNotLike(String value) {
            addCriterion("DB_NM not like", value, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMIn(List<String> values) {
            addCriterion("DB_NM in", values, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMNotIn(List<String> values) {
            addCriterion("DB_NM not in", values, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMBetween(String value1, String value2) {
            addCriterion("DB_NM between", value1, value2, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_NMNotBetween(String value1, String value2) {
            addCriterion("DB_NM not between", value1, value2, "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_USERIsNull() {
            addCriterion("DB_USER is null");
            return (Criteria) this;
        }

        public Criteria andDB_USERIsNotNull() {
            addCriterion("DB_USER is not null");
            return (Criteria) this;
        }

        public Criteria andDB_USEREqualTo(String value) {
            addCriterion("DB_USER =", value, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERNotEqualTo(String value) {
            addCriterion("DB_USER <>", value, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERGreaterThan(String value) {
            addCriterion("DB_USER >", value, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERGreaterThanOrEqualTo(String value) {
            addCriterion("DB_USER >=", value, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERLessThan(String value) {
            addCriterion("DB_USER <", value, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERLessThanOrEqualTo(String value) {
            addCriterion("DB_USER <=", value, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERLike(String value) {
            addCriterion("DB_USER like", value, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERNotLike(String value) {
            addCriterion("DB_USER not like", value, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERIn(List<String> values) {
            addCriterion("DB_USER in", values, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERNotIn(List<String> values) {
            addCriterion("DB_USER not in", values, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERBetween(String value1, String value2) {
            addCriterion("DB_USER between", value1, value2, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_USERNotBetween(String value1, String value2) {
            addCriterion("DB_USER not between", value1, value2, "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDIsNull() {
            addCriterion("DB_PASSWD is null");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDIsNotNull() {
            addCriterion("DB_PASSWD is not null");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDEqualTo(String value) {
            addCriterion("DB_PASSWD =", value, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDNotEqualTo(String value) {
            addCriterion("DB_PASSWD <>", value, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDGreaterThan(String value) {
            addCriterion("DB_PASSWD >", value, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDGreaterThanOrEqualTo(String value) {
            addCriterion("DB_PASSWD >=", value, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDLessThan(String value) {
            addCriterion("DB_PASSWD <", value, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDLessThanOrEqualTo(String value) {
            addCriterion("DB_PASSWD <=", value, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDLike(String value) {
            addCriterion("DB_PASSWD like", value, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDNotLike(String value) {
            addCriterion("DB_PASSWD not like", value, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDIn(List<String> values) {
            addCriterion("DB_PASSWD in", values, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDNotIn(List<String> values) {
            addCriterion("DB_PASSWD not in", values, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDBetween(String value1, String value2) {
            addCriterion("DB_PASSWD between", value1, value2, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDNotBetween(String value1, String value2) {
            addCriterion("DB_PASSWD not between", value1, value2, "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andGCT_VERIsNull() {
            addCriterion("GCT_VER is null");
            return (Criteria) this;
        }

        public Criteria andGCT_VERIsNotNull() {
            addCriterion("GCT_VER is not null");
            return (Criteria) this;
        }

        public Criteria andGCT_VEREqualTo(String value) {
            addCriterion("GCT_VER =", value, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERNotEqualTo(String value) {
            addCriterion("GCT_VER <>", value, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERGreaterThan(String value) {
            addCriterion("GCT_VER >", value, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERGreaterThanOrEqualTo(String value) {
            addCriterion("GCT_VER >=", value, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERLessThan(String value) {
            addCriterion("GCT_VER <", value, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERLessThanOrEqualTo(String value) {
            addCriterion("GCT_VER <=", value, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERLike(String value) {
            addCriterion("GCT_VER like", value, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERNotLike(String value) {
            addCriterion("GCT_VER not like", value, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERIn(List<String> values) {
            addCriterion("GCT_VER in", values, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERNotIn(List<String> values) {
            addCriterion("GCT_VER not in", values, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERBetween(String value1, String value2) {
            addCriterion("GCT_VER between", value1, value2, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andGCT_VERNotBetween(String value1, String value2) {
            addCriterion("GCT_VER not between", value1, value2, "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVEIsNull() {
            addCriterion("MAX_ACTIVE is null");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVEIsNotNull() {
            addCriterion("MAX_ACTIVE is not null");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVEEqualTo(String value) {
            addCriterion("MAX_ACTIVE =", value, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVENotEqualTo(String value) {
            addCriterion("MAX_ACTIVE <>", value, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVEGreaterThan(String value) {
            addCriterion("MAX_ACTIVE >", value, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVEGreaterThanOrEqualTo(String value) {
            addCriterion("MAX_ACTIVE >=", value, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVELessThan(String value) {
            addCriterion("MAX_ACTIVE <", value, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVELessThanOrEqualTo(String value) {
            addCriterion("MAX_ACTIVE <=", value, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVELike(String value) {
            addCriterion("MAX_ACTIVE like", value, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVENotLike(String value) {
            addCriterion("MAX_ACTIVE not like", value, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVEIn(List<String> values) {
            addCriterion("MAX_ACTIVE in", values, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVENotIn(List<String> values) {
            addCriterion("MAX_ACTIVE not in", values, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVEBetween(String value1, String value2) {
            addCriterion("MAX_ACTIVE between", value1, value2, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVENotBetween(String value1, String value2) {
            addCriterion("MAX_ACTIVE not between", value1, value2, "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLEIsNull() {
            addCriterion("MAX_IDLE is null");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLEIsNotNull() {
            addCriterion("MAX_IDLE is not null");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLEEqualTo(String value) {
            addCriterion("MAX_IDLE =", value, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLENotEqualTo(String value) {
            addCriterion("MAX_IDLE <>", value, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLEGreaterThan(String value) {
            addCriterion("MAX_IDLE >", value, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLEGreaterThanOrEqualTo(String value) {
            addCriterion("MAX_IDLE >=", value, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLELessThan(String value) {
            addCriterion("MAX_IDLE <", value, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLELessThanOrEqualTo(String value) {
            addCriterion("MAX_IDLE <=", value, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLELike(String value) {
            addCriterion("MAX_IDLE like", value, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLENotLike(String value) {
            addCriterion("MAX_IDLE not like", value, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLEIn(List<String> values) {
            addCriterion("MAX_IDLE in", values, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLENotIn(List<String> values) {
            addCriterion("MAX_IDLE not in", values, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLEBetween(String value1, String value2) {
            addCriterion("MAX_IDLE between", value1, value2, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLENotBetween(String value1, String value2) {
            addCriterion("MAX_IDLE not between", value1, value2, "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMIsNull() {
            addCriterion("MAX_WAIT_TM is null");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMIsNotNull() {
            addCriterion("MAX_WAIT_TM is not null");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMEqualTo(String value) {
            addCriterion("MAX_WAIT_TM =", value, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMNotEqualTo(String value) {
            addCriterion("MAX_WAIT_TM <>", value, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMGreaterThan(String value) {
            addCriterion("MAX_WAIT_TM >", value, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMGreaterThanOrEqualTo(String value) {
            addCriterion("MAX_WAIT_TM >=", value, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMLessThan(String value) {
            addCriterion("MAX_WAIT_TM <", value, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMLessThanOrEqualTo(String value) {
            addCriterion("MAX_WAIT_TM <=", value, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMLike(String value) {
            addCriterion("MAX_WAIT_TM like", value, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMNotLike(String value) {
            addCriterion("MAX_WAIT_TM not like", value, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMIn(List<String> values) {
            addCriterion("MAX_WAIT_TM in", values, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMNotIn(List<String> values) {
            addCriterion("MAX_WAIT_TM not in", values, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMBetween(String value1, String value2) {
            addCriterion("MAX_WAIT_TM between", value1, value2, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMNotBetween(String value1, String value2) {
            addCriterion("MAX_WAIT_TM not between", value1, value2, "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andSD_FLGIsNull() {
            addCriterion("SD_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSD_FLGIsNotNull() {
            addCriterion("SD_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSD_FLGEqualTo(String value) {
            addCriterion("SD_FLG =", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGNotEqualTo(String value) {
            addCriterion("SD_FLG <>", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGGreaterThan(String value) {
            addCriterion("SD_FLG >", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SD_FLG >=", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGLessThan(String value) {
            addCriterion("SD_FLG <", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGLessThanOrEqualTo(String value) {
            addCriterion("SD_FLG <=", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGLike(String value) {
            addCriterion("SD_FLG like", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGNotLike(String value) {
            addCriterion("SD_FLG not like", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGIn(List<String> values) {
            addCriterion("SD_FLG in", values, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGNotIn(List<String> values) {
            addCriterion("SD_FLG not in", values, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGBetween(String value1, String value2) {
            addCriterion("SD_FLG between", value1, value2, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGNotBetween(String value1, String value2) {
            addCriterion("SD_FLG not between", value1, value2, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andGC_CDLikeInsensitive(String value) {
            addCriterion("upper(GC_CD) like", value.toUpperCase(), "GC_CD");
            return (Criteria) this;
        }

        public Criteria andGC_NMLikeInsensitive(String value) {
            addCriterion("upper(GC_NM) like", value.toUpperCase(), "GC_NM");
            return (Criteria) this;
        }

        public Criteria andGC_TEL_NUMLikeInsensitive(String value) {
            addCriterion("upper(GC_TEL_NUM) like", value.toUpperCase(), "GC_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andUPPER_GC_CDLikeInsensitive(String value) {
            addCriterion("upper(UPPER_GC_CD) like", value.toUpperCase(), "UPPER_GC_CD");
            return (Criteria) this;
        }

        public Criteria andSYNC_ABL_FLGLikeInsensitive(String value) {
            addCriterion("upper(SYNC_ABL_FLG) like", value.toUpperCase(), "SYNC_ABL_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRLikeInsensitive(String value) {
            addCriterion("upper(IP_ADDR) like", value.toUpperCase(), "IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDLikeInsensitive(String value) {
            addCriterion("upper(GYOUMU_CD) like", value.toUpperCase(), "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDB_NMLikeInsensitive(String value) {
            addCriterion("upper(DB_NM) like", value.toUpperCase(), "DB_NM");
            return (Criteria) this;
        }

        public Criteria andDB_USERLikeInsensitive(String value) {
            addCriterion("upper(DB_USER) like", value.toUpperCase(), "DB_USER");
            return (Criteria) this;
        }

        public Criteria andDB_PASSWDLikeInsensitive(String value) {
            addCriterion("upper(DB_PASSWD) like", value.toUpperCase(), "DB_PASSWD");
            return (Criteria) this;
        }

        public Criteria andGCT_VERLikeInsensitive(String value) {
            addCriterion("upper(GCT_VER) like", value.toUpperCase(), "GCT_VER");
            return (Criteria) this;
        }

        public Criteria andMAX_ACTIVELikeInsensitive(String value) {
            addCriterion("upper(MAX_ACTIVE) like", value.toUpperCase(), "MAX_ACTIVE");
            return (Criteria) this;
        }

        public Criteria andMAX_IDLELikeInsensitive(String value) {
            addCriterion("upper(MAX_IDLE) like", value.toUpperCase(), "MAX_IDLE");
            return (Criteria) this;
        }

        public Criteria andMAX_WAIT_TMLikeInsensitive(String value) {
            addCriterion("upper(MAX_WAIT_TM) like", value.toUpperCase(), "MAX_WAIT_TM");
            return (Criteria) this;
        }

        public Criteria andSD_FLGLikeInsensitive(String value) {
            addCriterion("upper(SD_FLG) like", value.toUpperCase(), "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * K_GC
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * K_GC null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}