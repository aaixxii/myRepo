package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class AAcntUser implements Serializable {
    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * 緊急連絡先対象フラグ
     */
    private String KNRN_FLG;

    /**
     * カード利用
     */
    private String CARD_FLG;

    /**
     * メール登録状態
     */
    private String ML_STS;

    /**
     * メール送信済みフラグ
     */
    private String ML_SEND_FLG;

    /**
     * メール登録失敗エラーコード
     */
    private String ML_ERR_CD;

    /**
     * メール通知許可状態
     */
    private String ML_SEND_STS;

    /**
     * 登録通知送付先(BCC)
     */
    private String ML_ADDR_TOUROKU;

    /**
     * 登録通知備考
     */
    private String TOUROKU_BIKOU;

    /**
     * ＡＬＳＯＫ通知備考
     */
    private String ALSOK_BIKOU;

    /**
     * 確認状態
     */
    private String CHECK_STS;

    /**
     * 前回ログイン日時
     */
    private Date LAST_LOGIN_TS;

    /**
     * 状態変更日時
     */
    private Date STS_UPD_TS;

    /**
     * WEB閲覧可否フラグ
     */
    private String WEB_ETURAN_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * A_ACNT_USER
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * 緊急連絡先対象フラグ
     * @return KNRN_FLG 緊急連絡先対象フラグ
     */
    public String getKNRN_FLG() {
        return KNRN_FLG;
    }

    /**
     * 緊急連絡先対象フラグ
     * @param KNRN_FLG 緊急連絡先対象フラグ
     */
    public void setKNRN_FLG(String KNRN_FLG) {
        this.KNRN_FLG = KNRN_FLG == null ? null : KNRN_FLG.trim();
    }

    /**
     * カード利用
     * @return CARD_FLG カード利用
     */
    public String getCARD_FLG() {
        return CARD_FLG;
    }

    /**
     * カード利用
     * @param CARD_FLG カード利用
     */
    public void setCARD_FLG(String CARD_FLG) {
        this.CARD_FLG = CARD_FLG == null ? null : CARD_FLG.trim();
    }

    /**
     * メール登録状態
     * @return ML_STS メール登録状態
     */
    public String getML_STS() {
        return ML_STS;
    }

    /**
     * メール登録状態
     * @param ML_STS メール登録状態
     */
    public void setML_STS(String ML_STS) {
        this.ML_STS = ML_STS == null ? null : ML_STS.trim();
    }

    /**
     * メール送信済みフラグ
     * @return ML_SEND_FLG メール送信済みフラグ
     */
    public String getML_SEND_FLG() {
        return ML_SEND_FLG;
    }

    /**
     * メール送信済みフラグ
     * @param ML_SEND_FLG メール送信済みフラグ
     */
    public void setML_SEND_FLG(String ML_SEND_FLG) {
        this.ML_SEND_FLG = ML_SEND_FLG == null ? null : ML_SEND_FLG.trim();
    }

    /**
     * メール登録失敗エラーコード
     * @return ML_ERR_CD メール登録失敗エラーコード
     */
    public String getML_ERR_CD() {
        return ML_ERR_CD;
    }

    /**
     * メール登録失敗エラーコード
     * @param ML_ERR_CD メール登録失敗エラーコード
     */
    public void setML_ERR_CD(String ML_ERR_CD) {
        this.ML_ERR_CD = ML_ERR_CD == null ? null : ML_ERR_CD.trim();
    }

    /**
     * メール通知許可状態
     * @return ML_SEND_STS メール通知許可状態
     */
    public String getML_SEND_STS() {
        return ML_SEND_STS;
    }

    /**
     * メール通知許可状態
     * @param ML_SEND_STS メール通知許可状態
     */
    public void setML_SEND_STS(String ML_SEND_STS) {
        this.ML_SEND_STS = ML_SEND_STS == null ? null : ML_SEND_STS.trim();
    }

    /**
     * 登録通知送付先(BCC)
     * @return ML_ADDR_TOUROKU 登録通知送付先(BCC)
     */
    public String getML_ADDR_TOUROKU() {
        return ML_ADDR_TOUROKU;
    }

    /**
     * 登録通知送付先(BCC)
     * @param ML_ADDR_TOUROKU 登録通知送付先(BCC)
     */
    public void setML_ADDR_TOUROKU(String ML_ADDR_TOUROKU) {
        this.ML_ADDR_TOUROKU = ML_ADDR_TOUROKU == null ? null : ML_ADDR_TOUROKU.trim();
    }

    /**
     * 登録通知備考
     * @return TOUROKU_BIKOU 登録通知備考
     */
    public String getTOUROKU_BIKOU() {
        return TOUROKU_BIKOU;
    }

    /**
     * 登録通知備考
     * @param TOUROKU_BIKOU 登録通知備考
     */
    public void setTOUROKU_BIKOU(String TOUROKU_BIKOU) {
        this.TOUROKU_BIKOU = TOUROKU_BIKOU == null ? null : TOUROKU_BIKOU.trim();
    }

    /**
     * ＡＬＳＯＫ通知備考
     * @return ALSOK_BIKOU ＡＬＳＯＫ通知備考
     */
    public String getALSOK_BIKOU() {
        return ALSOK_BIKOU;
    }

    /**
     * ＡＬＳＯＫ通知備考
     * @param ALSOK_BIKOU ＡＬＳＯＫ通知備考
     */
    public void setALSOK_BIKOU(String ALSOK_BIKOU) {
        this.ALSOK_BIKOU = ALSOK_BIKOU == null ? null : ALSOK_BIKOU.trim();
    }

    /**
     * 確認状態
     * @return CHECK_STS 確認状態
     */
    public String getCHECK_STS() {
        return CHECK_STS;
    }

    /**
     * 確認状態
     * @param CHECK_STS 確認状態
     */
    public void setCHECK_STS(String CHECK_STS) {
        this.CHECK_STS = CHECK_STS == null ? null : CHECK_STS.trim();
    }

    /**
     * 前回ログイン日時
     * @return LAST_LOGIN_TS 前回ログイン日時
     */
    public Date getLAST_LOGIN_TS() {
        return LAST_LOGIN_TS;
    }

    /**
     * 前回ログイン日時
     * @param LAST_LOGIN_TS 前回ログイン日時
     */
    public void setLAST_LOGIN_TS(Date LAST_LOGIN_TS) {
        this.LAST_LOGIN_TS = LAST_LOGIN_TS;
    }

    /**
     * 状態変更日時
     * @return STS_UPD_TS 状態変更日時
     */
    public Date getSTS_UPD_TS() {
        return STS_UPD_TS;
    }

    /**
     * 状態変更日時
     * @param STS_UPD_TS 状態変更日時
     */
    public void setSTS_UPD_TS(Date STS_UPD_TS) {
        this.STS_UPD_TS = STS_UPD_TS;
    }

    /**
     * WEB閲覧可否フラグ
     * @return WEB_ETURAN_FLG WEB閲覧可否フラグ
     */
    public String getWEB_ETURAN_FLG() {
        return WEB_ETURAN_FLG;
    }

    /**
     * WEB閲覧可否フラグ
     * @param WEB_ETURAN_FLG WEB閲覧可否フラグ
     */
    public void setWEB_ETURAN_FLG(String WEB_ETURAN_FLG) {
        this.WEB_ETURAN_FLG = WEB_ETURAN_FLG == null ? null : WEB_ETURAN_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}