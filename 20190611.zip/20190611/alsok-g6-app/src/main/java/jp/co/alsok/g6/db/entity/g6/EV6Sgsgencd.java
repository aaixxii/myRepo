package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EV6Sgsgencd implements Serializable {
    /**
     * V6_SGS原因コード
     */
    private String LN_V6_SGSGENINCD;

    /**
     * 原因識別コード
     */
    private String ID_GEN_SIKIBETU;

    /**
     * 原因識別詳細コード
     */
    private String ID_GEN_SIKIBETU_DTL;

    /**
     * 事案分類コード
     */
    private String ID_JIANBNR;

    /**
     * 警報分類コード
     */
    private String ID_KEIHOBNRCD;

    /**
     * 原因分類コード
     */
    private String ID_GENBNRCD;

    /**
     * NET原因コード
     */
    private String ID_NETGENCD;

    /**
     * 原因内容１
     */
    private String v6_SGSGENCD_NAIYOU1;

    /**
     * 原因内容２
     */
    private String v6_SGSGENCD_NAIYOU2;

    /**
     * データ無線原因コード
     */
    private String MUSEN_GENCD;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_V6_SGSGENCD
     */
    private static final long serialVersionUID = 1L;

    /**
     * V6_SGS原因コード
     * @return LN_V6_SGSGENINCD V6_SGS原因コード
     */
    public String getLN_V6_SGSGENINCD() {
        return LN_V6_SGSGENINCD;
    }

    /**
     * V6_SGS原因コード
     * @param LN_V6_SGSGENINCD V6_SGS原因コード
     */
    public void setLN_V6_SGSGENINCD(String LN_V6_SGSGENINCD) {
        this.LN_V6_SGSGENINCD = LN_V6_SGSGENINCD == null ? null : LN_V6_SGSGENINCD.trim();
    }

    /**
     * 原因識別コード
     * @return ID_GEN_SIKIBETU 原因識別コード
     */
    public String getID_GEN_SIKIBETU() {
        return ID_GEN_SIKIBETU;
    }

    /**
     * 原因識別コード
     * @param ID_GEN_SIKIBETU 原因識別コード
     */
    public void setID_GEN_SIKIBETU(String ID_GEN_SIKIBETU) {
        this.ID_GEN_SIKIBETU = ID_GEN_SIKIBETU == null ? null : ID_GEN_SIKIBETU.trim();
    }

    /**
     * 原因識別詳細コード
     * @return ID_GEN_SIKIBETU_DTL 原因識別詳細コード
     */
    public String getID_GEN_SIKIBETU_DTL() {
        return ID_GEN_SIKIBETU_DTL;
    }

    /**
     * 原因識別詳細コード
     * @param ID_GEN_SIKIBETU_DTL 原因識別詳細コード
     */
    public void setID_GEN_SIKIBETU_DTL(String ID_GEN_SIKIBETU_DTL) {
        this.ID_GEN_SIKIBETU_DTL = ID_GEN_SIKIBETU_DTL == null ? null : ID_GEN_SIKIBETU_DTL.trim();
    }

    /**
     * 事案分類コード
     * @return ID_JIANBNR 事案分類コード
     */
    public String getID_JIANBNR() {
        return ID_JIANBNR;
    }

    /**
     * 事案分類コード
     * @param ID_JIANBNR 事案分類コード
     */
    public void setID_JIANBNR(String ID_JIANBNR) {
        this.ID_JIANBNR = ID_JIANBNR == null ? null : ID_JIANBNR.trim();
    }

    /**
     * 警報分類コード
     * @return ID_KEIHOBNRCD 警報分類コード
     */
    public String getID_KEIHOBNRCD() {
        return ID_KEIHOBNRCD;
    }

    /**
     * 警報分類コード
     * @param ID_KEIHOBNRCD 警報分類コード
     */
    public void setID_KEIHOBNRCD(String ID_KEIHOBNRCD) {
        this.ID_KEIHOBNRCD = ID_KEIHOBNRCD == null ? null : ID_KEIHOBNRCD.trim();
    }

    /**
     * 原因分類コード
     * @return ID_GENBNRCD 原因分類コード
     */
    public String getID_GENBNRCD() {
        return ID_GENBNRCD;
    }

    /**
     * 原因分類コード
     * @param ID_GENBNRCD 原因分類コード
     */
    public void setID_GENBNRCD(String ID_GENBNRCD) {
        this.ID_GENBNRCD = ID_GENBNRCD == null ? null : ID_GENBNRCD.trim();
    }

    /**
     * NET原因コード
     * @return ID_NETGENCD NET原因コード
     */
    public String getID_NETGENCD() {
        return ID_NETGENCD;
    }

    /**
     * NET原因コード
     * @param ID_NETGENCD NET原因コード
     */
    public void setID_NETGENCD(String ID_NETGENCD) {
        this.ID_NETGENCD = ID_NETGENCD == null ? null : ID_NETGENCD.trim();
    }

    /**
     * 原因内容１
     * @return V6_SGSGENCD_NAIYOU1 原因内容１
     */
    public String getV6_SGSGENCD_NAIYOU1() {
        return v6_SGSGENCD_NAIYOU1;
    }

    /**
     * 原因内容１
     * @param v6_SGSGENCD_NAIYOU1 原因内容１
     */
    public void setV6_SGSGENCD_NAIYOU1(String v6_SGSGENCD_NAIYOU1) {
        this.v6_SGSGENCD_NAIYOU1 = v6_SGSGENCD_NAIYOU1 == null ? null : v6_SGSGENCD_NAIYOU1.trim();
    }

    /**
     * 原因内容２
     * @return V6_SGSGENCD_NAIYOU2 原因内容２
     */
    public String getV6_SGSGENCD_NAIYOU2() {
        return v6_SGSGENCD_NAIYOU2;
    }

    /**
     * 原因内容２
     * @param v6_SGSGENCD_NAIYOU2 原因内容２
     */
    public void setV6_SGSGENCD_NAIYOU2(String v6_SGSGENCD_NAIYOU2) {
        this.v6_SGSGENCD_NAIYOU2 = v6_SGSGENCD_NAIYOU2 == null ? null : v6_SGSGENCD_NAIYOU2.trim();
    }

    /**
     * データ無線原因コード
     * @return MUSEN_GENCD データ無線原因コード
     */
    public String getMUSEN_GENCD() {
        return MUSEN_GENCD;
    }

    /**
     * データ無線原因コード
     * @param MUSEN_GENCD データ無線原因コード
     */
    public void setMUSEN_GENCD(String MUSEN_GENCD) {
        this.MUSEN_GENCD = MUSEN_GENCD == null ? null : MUSEN_GENCD.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}