package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KAcntAlsok implements Serializable {
    /**
     * LN_ALSOKアカウント論理番号
     */
    private String LN_ACNT_ALSOK;

    /**
     * 事業所コード
     */
    private String JIGYOU_CD;

    /**
     * メールアドレス
     */
    private String ML_ADDR;

    /**
     * パスワード
     */
    private String PASSWD;

    /**
     * 社員名
     */
    private String USER_NM;

    /**
     * 社員番号
     */
    private String USER_NUM;

    /**
     * ログイン許可状態
     */
    private String LOGIN_STS;

    /**
     * LN_統合警備先情報論理番号
     */
    private String LN_TOGO_KEIBI;

    /**
     * アカウント区分
     */
    private String ACNT_KBN;

    /**
     * 隊員種別フラグ
     */
    private String TAIIN_KIND_FLG;

    /**
     * 範囲
     */
    private String ID_HANI;

    /**
     * 表示フラグ
     */
    private String HYOJI_FLG;

    /**
     * 新画像権限ID(新画)
     */
    private String KENGEN_ID;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_ACNT_ALSOK
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ALSOKアカウント論理番号
     * @return LN_ACNT_ALSOK LN_ALSOKアカウント論理番号
     */
    public String getLN_ACNT_ALSOK() {
        return LN_ACNT_ALSOK;
    }

    /**
     * LN_ALSOKアカウント論理番号
     * @param LN_ACNT_ALSOK LN_ALSOKアカウント論理番号
     */
    public void setLN_ACNT_ALSOK(String LN_ACNT_ALSOK) {
        this.LN_ACNT_ALSOK = LN_ACNT_ALSOK == null ? null : LN_ACNT_ALSOK.trim();
    }

    /**
     * 事業所コード
     * @return JIGYOU_CD 事業所コード
     */
    public String getJIGYOU_CD() {
        return JIGYOU_CD;
    }

    /**
     * 事業所コード
     * @param JIGYOU_CD 事業所コード
     */
    public void setJIGYOU_CD(String JIGYOU_CD) {
        this.JIGYOU_CD = JIGYOU_CD == null ? null : JIGYOU_CD.trim();
    }

    /**
     * メールアドレス
     * @return ML_ADDR メールアドレス
     */
    public String getML_ADDR() {
        return ML_ADDR;
    }

    /**
     * メールアドレス
     * @param ML_ADDR メールアドレス
     */
    public void setML_ADDR(String ML_ADDR) {
        this.ML_ADDR = ML_ADDR == null ? null : ML_ADDR.trim();
    }

    /**
     * パスワード
     * @return PASSWD パスワード
     */
    public String getPASSWD() {
        return PASSWD;
    }

    /**
     * パスワード
     * @param PASSWD パスワード
     */
    public void setPASSWD(String PASSWD) {
        this.PASSWD = PASSWD == null ? null : PASSWD.trim();
    }

    /**
     * 社員名
     * @return USER_NM 社員名
     */
    public String getUSER_NM() {
        return USER_NM;
    }

    /**
     * 社員名
     * @param USER_NM 社員名
     */
    public void setUSER_NM(String USER_NM) {
        this.USER_NM = USER_NM == null ? null : USER_NM.trim();
    }

    /**
     * 社員番号
     * @return USER_NUM 社員番号
     */
    public String getUSER_NUM() {
        return USER_NUM;
    }

    /**
     * 社員番号
     * @param USER_NUM 社員番号
     */
    public void setUSER_NUM(String USER_NUM) {
        this.USER_NUM = USER_NUM == null ? null : USER_NUM.trim();
    }

    /**
     * ログイン許可状態
     * @return LOGIN_STS ログイン許可状態
     */
    public String getLOGIN_STS() {
        return LOGIN_STS;
    }

    /**
     * ログイン許可状態
     * @param LOGIN_STS ログイン許可状態
     */
    public void setLOGIN_STS(String LOGIN_STS) {
        this.LOGIN_STS = LOGIN_STS == null ? null : LOGIN_STS.trim();
    }

    /**
     * LN_統合警備先情報論理番号
     * @return LN_TOGO_KEIBI LN_統合警備先情報論理番号
     */
    public String getLN_TOGO_KEIBI() {
        return LN_TOGO_KEIBI;
    }

    /**
     * LN_統合警備先情報論理番号
     * @param LN_TOGO_KEIBI LN_統合警備先情報論理番号
     */
    public void setLN_TOGO_KEIBI(String LN_TOGO_KEIBI) {
        this.LN_TOGO_KEIBI = LN_TOGO_KEIBI == null ? null : LN_TOGO_KEIBI.trim();
    }

    /**
     * アカウント区分
     * @return ACNT_KBN アカウント区分
     */
    public String getACNT_KBN() {
        return ACNT_KBN;
    }

    /**
     * アカウント区分
     * @param ACNT_KBN アカウント区分
     */
    public void setACNT_KBN(String ACNT_KBN) {
        this.ACNT_KBN = ACNT_KBN == null ? null : ACNT_KBN.trim();
    }

    /**
     * 隊員種別フラグ
     * @return TAIIN_KIND_FLG 隊員種別フラグ
     */
    public String getTAIIN_KIND_FLG() {
        return TAIIN_KIND_FLG;
    }

    /**
     * 隊員種別フラグ
     * @param TAIIN_KIND_FLG 隊員種別フラグ
     */
    public void setTAIIN_KIND_FLG(String TAIIN_KIND_FLG) {
        this.TAIIN_KIND_FLG = TAIIN_KIND_FLG == null ? null : TAIIN_KIND_FLG.trim();
    }

    /**
     * 範囲
     * @return ID_HANI 範囲
     */
    public String getID_HANI() {
        return ID_HANI;
    }

    /**
     * 範囲
     * @param ID_HANI 範囲
     */
    public void setID_HANI(String ID_HANI) {
        this.ID_HANI = ID_HANI == null ? null : ID_HANI.trim();
    }

    /**
     * 表示フラグ
     * @return HYOJI_FLG 表示フラグ
     */
    public String getHYOJI_FLG() {
        return HYOJI_FLG;
    }

    /**
     * 表示フラグ
     * @param HYOJI_FLG 表示フラグ
     */
    public void setHYOJI_FLG(String HYOJI_FLG) {
        this.HYOJI_FLG = HYOJI_FLG == null ? null : HYOJI_FLG.trim();
    }

    /**
     * 新画像権限ID(新画)
     * @return KENGEN_ID 新画像権限ID(新画)
     */
    public String getKENGEN_ID() {
        return KENGEN_ID;
    }

    /**
     * 新画像権限ID(新画)
     * @param KENGEN_ID 新画像権限ID(新画)
     */
    public void setKENGEN_ID(String KENGEN_ID) {
        this.KENGEN_ID = KENGEN_ID == null ? null : KENGEN_ID.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}