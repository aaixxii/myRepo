package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CQueMlTrig implements Serializable {
    /**
     * LN_配信トリガ論理番号
     */
    private String LN_ML_TRIG;

    /**
     * 種別
     */
    private String KIND;

    /**
     * 状態
     */
    private String STS;

    /**
     * LN_警備情報論理番号
     */
    private String LN_KB_INF;

    /**
     * LN_お知らせ論理番号
     */
    private String LN_NOTICE;

    /**
     * 送信可能日時
     */
    private Date SEND_ABL_TS;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * LN_入居管理論理番号
     */
    private String LN_TENANT_MNG;

    /**
     * ALSOKお知らせメール送信対象サービス種別
     */
    private String ALSOK_NOTICE_SEND_SVC_KIND;

    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * 宛先ファイル名
     */
    private String FILE_NM_TO;

    /**
     * 宛先取得区分
     */
    private String GET_KIND_TO;

    /**
     * 項目1
     */
    private String ITEM1;

    /**
     * 項目2
     */
    private String ITEM2;

    /**
     * 項目3
     */
    private String ITEM3;

    /**
     * 項目4
     */
    private String ITEM4;

    /**
     * 項目5
     */
    private String ITEM5;

    /**
     * 項目6
     */
    private String ITEM6;

    /**
     * 項目7
     */
    private String ITEM7;

    /**
     * 項目8
     */
    private String ITEM8;

    /**
     * 項目9
     */
    private String ITEM9;

    /**
     * 項目10
     */
    private String ITEM10;

    /**
     * 項目11
     */
    private String ITEM11;

    /**
     * 項目12
     */
    private String ITEM12;

    /**
     * 項目13
     */
    private String ITEM13;

    /**
     * 項目14
     */
    private String ITEM14;

    /**
     * 項目15
     */
    private String ITEM15;

    /**
     * 項目16
     */
    private String ITEM16;

    /**
     * 項目17
     */
    private String ITEM17;

    /**
     * 項目18
     */
    private String ITEM18;

    /**
     * 項目19
     */
    private String ITEM19;

    /**
     * 項目20
     */
    private String ITEM20;

    /**
     * 項目21
     */
    private String ITEM21;

    /**
     * 項目22
     */
    private String ITEM22;

    /**
     * 項目23
     */
    private String ITEM23;

    /**
     * 項目24
     */
    private String ITEM24;

    /**
     * 項目25
     */
    private String ITEM25;

    /**
     * 項目26
     */
    private String ITEM26;

    /**
     * 項目27
     */
    private String ITEM27;

    /**
     * 項目28
     */
    private String ITEM28;

    /**
     * 項目29
     */
    private String ITEM29;

    /**
     * 項目30
     */
    private String ITEM30;

    /**
     * 項目31
     */
    private String ITEM31;

    /**
     * 項目32
     */
    private String ITEM32;

    /**
     * 項目33
     */
    private String ITEM33;

    /**
     * 項目34
     */
    private String ITEM34;

    /**
     * 項目35
     */
    private String ITEM35;

    /**
     * 項目36
     */
    private String ITEM36;

    /**
     * 項目37
     */
    private String ITEM37;

    /**
     * 項目38
     */
    private String ITEM38;

    /**
     * 項目39
     */
    private String ITEM39;

    /**
     * 項目40
     */
    private String ITEM40;

    /**
     * 項目41
     */
    private String ITEM41;

    /**
     * 項目42
     */
    private String ITEM42;

    /**
     * 項目43
     */
    private String ITEM43;

    /**
     * 項目44
     */
    private String ITEM44;

    /**
     * 項目45
     */
    private String ITEM45;

    /**
     * 項目46
     */
    private String ITEM46;

    /**
     * 項目47
     */
    private String ITEM47;

    /**
     * 項目48
     */
    private String ITEM48;

    /**
     * 項目49
     */
    private String ITEM49;

    /**
     * 項目50
     */
    private String ITEM50;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_QUE_ML_TRIG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_配信トリガ論理番号
     * @return LN_ML_TRIG LN_配信トリガ論理番号
     */
    public String getLN_ML_TRIG() {
        return LN_ML_TRIG;
    }

    /**
     * LN_配信トリガ論理番号
     * @param LN_ML_TRIG LN_配信トリガ論理番号
     */
    public void setLN_ML_TRIG(String LN_ML_TRIG) {
        this.LN_ML_TRIG = LN_ML_TRIG == null ? null : LN_ML_TRIG.trim();
    }

    /**
     * 種別
     * @return KIND 種別
     */
    public String getKIND() {
        return KIND;
    }

    /**
     * 種別
     * @param KIND 種別
     */
    public void setKIND(String KIND) {
        this.KIND = KIND == null ? null : KIND.trim();
    }

    /**
     * 状態
     * @return STS 状態
     */
    public String getSTS() {
        return STS;
    }

    /**
     * 状態
     * @param STS 状態
     */
    public void setSTS(String STS) {
        this.STS = STS == null ? null : STS.trim();
    }

    /**
     * LN_警備情報論理番号
     * @return LN_KB_INF LN_警備情報論理番号
     */
    public String getLN_KB_INF() {
        return LN_KB_INF;
    }

    /**
     * LN_警備情報論理番号
     * @param LN_KB_INF LN_警備情報論理番号
     */
    public void setLN_KB_INF(String LN_KB_INF) {
        this.LN_KB_INF = LN_KB_INF == null ? null : LN_KB_INF.trim();
    }

    /**
     * LN_お知らせ論理番号
     * @return LN_NOTICE LN_お知らせ論理番号
     */
    public String getLN_NOTICE() {
        return LN_NOTICE;
    }

    /**
     * LN_お知らせ論理番号
     * @param LN_NOTICE LN_お知らせ論理番号
     */
    public void setLN_NOTICE(String LN_NOTICE) {
        this.LN_NOTICE = LN_NOTICE == null ? null : LN_NOTICE.trim();
    }

    /**
     * 送信可能日時
     * @return SEND_ABL_TS 送信可能日時
     */
    public Date getSEND_ABL_TS() {
        return SEND_ABL_TS;
    }

    /**
     * 送信可能日時
     * @param SEND_ABL_TS 送信可能日時
     */
    public void setSEND_ABL_TS(Date SEND_ABL_TS) {
        this.SEND_ABL_TS = SEND_ABL_TS;
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * LN_入居管理論理番号
     * @return LN_TENANT_MNG LN_入居管理論理番号
     */
    public String getLN_TENANT_MNG() {
        return LN_TENANT_MNG;
    }

    /**
     * LN_入居管理論理番号
     * @param LN_TENANT_MNG LN_入居管理論理番号
     */
    public void setLN_TENANT_MNG(String LN_TENANT_MNG) {
        this.LN_TENANT_MNG = LN_TENANT_MNG == null ? null : LN_TENANT_MNG.trim();
    }

    /**
     * ALSOKお知らせメール送信対象サービス種別
     * @return ALSOK_NOTICE_SEND_SVC_KIND ALSOKお知らせメール送信対象サービス種別
     */
    public String getALSOK_NOTICE_SEND_SVC_KIND() {
        return ALSOK_NOTICE_SEND_SVC_KIND;
    }

    /**
     * ALSOKお知らせメール送信対象サービス種別
     * @param ALSOK_NOTICE_SEND_SVC_KIND ALSOKお知らせメール送信対象サービス種別
     */
    public void setALSOK_NOTICE_SEND_SVC_KIND(String ALSOK_NOTICE_SEND_SVC_KIND) {
        this.ALSOK_NOTICE_SEND_SVC_KIND = ALSOK_NOTICE_SEND_SVC_KIND == null ? null : ALSOK_NOTICE_SEND_SVC_KIND.trim();
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * 宛先ファイル名
     * @return FILE_NM_TO 宛先ファイル名
     */
    public String getFILE_NM_TO() {
        return FILE_NM_TO;
    }

    /**
     * 宛先ファイル名
     * @param FILE_NM_TO 宛先ファイル名
     */
    public void setFILE_NM_TO(String FILE_NM_TO) {
        this.FILE_NM_TO = FILE_NM_TO == null ? null : FILE_NM_TO.trim();
    }

    /**
     * 宛先取得区分
     * @return GET_KIND_TO 宛先取得区分
     */
    public String getGET_KIND_TO() {
        return GET_KIND_TO;
    }

    /**
     * 宛先取得区分
     * @param GET_KIND_TO 宛先取得区分
     */
    public void setGET_KIND_TO(String GET_KIND_TO) {
        this.GET_KIND_TO = GET_KIND_TO == null ? null : GET_KIND_TO.trim();
    }

    /**
     * 項目1
     * @return ITEM1 項目1
     */
    public String getITEM1() {
        return ITEM1;
    }

    /**
     * 項目1
     * @param ITEM1 項目1
     */
    public void setITEM1(String ITEM1) {
        this.ITEM1 = ITEM1 == null ? null : ITEM1.trim();
    }

    /**
     * 項目2
     * @return ITEM2 項目2
     */
    public String getITEM2() {
        return ITEM2;
    }

    /**
     * 項目2
     * @param ITEM2 項目2
     */
    public void setITEM2(String ITEM2) {
        this.ITEM2 = ITEM2 == null ? null : ITEM2.trim();
    }

    /**
     * 項目3
     * @return ITEM3 項目3
     */
    public String getITEM3() {
        return ITEM3;
    }

    /**
     * 項目3
     * @param ITEM3 項目3
     */
    public void setITEM3(String ITEM3) {
        this.ITEM3 = ITEM3 == null ? null : ITEM3.trim();
    }

    /**
     * 項目4
     * @return ITEM4 項目4
     */
    public String getITEM4() {
        return ITEM4;
    }

    /**
     * 項目4
     * @param ITEM4 項目4
     */
    public void setITEM4(String ITEM4) {
        this.ITEM4 = ITEM4 == null ? null : ITEM4.trim();
    }

    /**
     * 項目5
     * @return ITEM5 項目5
     */
    public String getITEM5() {
        return ITEM5;
    }

    /**
     * 項目5
     * @param ITEM5 項目5
     */
    public void setITEM5(String ITEM5) {
        this.ITEM5 = ITEM5 == null ? null : ITEM5.trim();
    }

    /**
     * 項目6
     * @return ITEM6 項目6
     */
    public String getITEM6() {
        return ITEM6;
    }

    /**
     * 項目6
     * @param ITEM6 項目6
     */
    public void setITEM6(String ITEM6) {
        this.ITEM6 = ITEM6 == null ? null : ITEM6.trim();
    }

    /**
     * 項目7
     * @return ITEM7 項目7
     */
    public String getITEM7() {
        return ITEM7;
    }

    /**
     * 項目7
     * @param ITEM7 項目7
     */
    public void setITEM7(String ITEM7) {
        this.ITEM7 = ITEM7 == null ? null : ITEM7.trim();
    }

    /**
     * 項目8
     * @return ITEM8 項目8
     */
    public String getITEM8() {
        return ITEM8;
    }

    /**
     * 項目8
     * @param ITEM8 項目8
     */
    public void setITEM8(String ITEM8) {
        this.ITEM8 = ITEM8 == null ? null : ITEM8.trim();
    }

    /**
     * 項目9
     * @return ITEM9 項目9
     */
    public String getITEM9() {
        return ITEM9;
    }

    /**
     * 項目9
     * @param ITEM9 項目9
     */
    public void setITEM9(String ITEM9) {
        this.ITEM9 = ITEM9 == null ? null : ITEM9.trim();
    }

    /**
     * 項目10
     * @return ITEM10 項目10
     */
    public String getITEM10() {
        return ITEM10;
    }

    /**
     * 項目10
     * @param ITEM10 項目10
     */
    public void setITEM10(String ITEM10) {
        this.ITEM10 = ITEM10 == null ? null : ITEM10.trim();
    }

    /**
     * 項目11
     * @return ITEM11 項目11
     */
    public String getITEM11() {
        return ITEM11;
    }

    /**
     * 項目11
     * @param ITEM11 項目11
     */
    public void setITEM11(String ITEM11) {
        this.ITEM11 = ITEM11 == null ? null : ITEM11.trim();
    }

    /**
     * 項目12
     * @return ITEM12 項目12
     */
    public String getITEM12() {
        return ITEM12;
    }

    /**
     * 項目12
     * @param ITEM12 項目12
     */
    public void setITEM12(String ITEM12) {
        this.ITEM12 = ITEM12 == null ? null : ITEM12.trim();
    }

    /**
     * 項目13
     * @return ITEM13 項目13
     */
    public String getITEM13() {
        return ITEM13;
    }

    /**
     * 項目13
     * @param ITEM13 項目13
     */
    public void setITEM13(String ITEM13) {
        this.ITEM13 = ITEM13 == null ? null : ITEM13.trim();
    }

    /**
     * 項目14
     * @return ITEM14 項目14
     */
    public String getITEM14() {
        return ITEM14;
    }

    /**
     * 項目14
     * @param ITEM14 項目14
     */
    public void setITEM14(String ITEM14) {
        this.ITEM14 = ITEM14 == null ? null : ITEM14.trim();
    }

    /**
     * 項目15
     * @return ITEM15 項目15
     */
    public String getITEM15() {
        return ITEM15;
    }

    /**
     * 項目15
     * @param ITEM15 項目15
     */
    public void setITEM15(String ITEM15) {
        this.ITEM15 = ITEM15 == null ? null : ITEM15.trim();
    }

    /**
     * 項目16
     * @return ITEM16 項目16
     */
    public String getITEM16() {
        return ITEM16;
    }

    /**
     * 項目16
     * @param ITEM16 項目16
     */
    public void setITEM16(String ITEM16) {
        this.ITEM16 = ITEM16 == null ? null : ITEM16.trim();
    }

    /**
     * 項目17
     * @return ITEM17 項目17
     */
    public String getITEM17() {
        return ITEM17;
    }

    /**
     * 項目17
     * @param ITEM17 項目17
     */
    public void setITEM17(String ITEM17) {
        this.ITEM17 = ITEM17 == null ? null : ITEM17.trim();
    }

    /**
     * 項目18
     * @return ITEM18 項目18
     */
    public String getITEM18() {
        return ITEM18;
    }

    /**
     * 項目18
     * @param ITEM18 項目18
     */
    public void setITEM18(String ITEM18) {
        this.ITEM18 = ITEM18 == null ? null : ITEM18.trim();
    }

    /**
     * 項目19
     * @return ITEM19 項目19
     */
    public String getITEM19() {
        return ITEM19;
    }

    /**
     * 項目19
     * @param ITEM19 項目19
     */
    public void setITEM19(String ITEM19) {
        this.ITEM19 = ITEM19 == null ? null : ITEM19.trim();
    }

    /**
     * 項目20
     * @return ITEM20 項目20
     */
    public String getITEM20() {
        return ITEM20;
    }

    /**
     * 項目20
     * @param ITEM20 項目20
     */
    public void setITEM20(String ITEM20) {
        this.ITEM20 = ITEM20 == null ? null : ITEM20.trim();
    }

    /**
     * 項目21
     * @return ITEM21 項目21
     */
    public String getITEM21() {
        return ITEM21;
    }

    /**
     * 項目21
     * @param ITEM21 項目21
     */
    public void setITEM21(String ITEM21) {
        this.ITEM21 = ITEM21 == null ? null : ITEM21.trim();
    }

    /**
     * 項目22
     * @return ITEM22 項目22
     */
    public String getITEM22() {
        return ITEM22;
    }

    /**
     * 項目22
     * @param ITEM22 項目22
     */
    public void setITEM22(String ITEM22) {
        this.ITEM22 = ITEM22 == null ? null : ITEM22.trim();
    }

    /**
     * 項目23
     * @return ITEM23 項目23
     */
    public String getITEM23() {
        return ITEM23;
    }

    /**
     * 項目23
     * @param ITEM23 項目23
     */
    public void setITEM23(String ITEM23) {
        this.ITEM23 = ITEM23 == null ? null : ITEM23.trim();
    }

    /**
     * 項目24
     * @return ITEM24 項目24
     */
    public String getITEM24() {
        return ITEM24;
    }

    /**
     * 項目24
     * @param ITEM24 項目24
     */
    public void setITEM24(String ITEM24) {
        this.ITEM24 = ITEM24 == null ? null : ITEM24.trim();
    }

    /**
     * 項目25
     * @return ITEM25 項目25
     */
    public String getITEM25() {
        return ITEM25;
    }

    /**
     * 項目25
     * @param ITEM25 項目25
     */
    public void setITEM25(String ITEM25) {
        this.ITEM25 = ITEM25 == null ? null : ITEM25.trim();
    }

    /**
     * 項目26
     * @return ITEM26 項目26
     */
    public String getITEM26() {
        return ITEM26;
    }

    /**
     * 項目26
     * @param ITEM26 項目26
     */
    public void setITEM26(String ITEM26) {
        this.ITEM26 = ITEM26 == null ? null : ITEM26.trim();
    }

    /**
     * 項目27
     * @return ITEM27 項目27
     */
    public String getITEM27() {
        return ITEM27;
    }

    /**
     * 項目27
     * @param ITEM27 項目27
     */
    public void setITEM27(String ITEM27) {
        this.ITEM27 = ITEM27 == null ? null : ITEM27.trim();
    }

    /**
     * 項目28
     * @return ITEM28 項目28
     */
    public String getITEM28() {
        return ITEM28;
    }

    /**
     * 項目28
     * @param ITEM28 項目28
     */
    public void setITEM28(String ITEM28) {
        this.ITEM28 = ITEM28 == null ? null : ITEM28.trim();
    }

    /**
     * 項目29
     * @return ITEM29 項目29
     */
    public String getITEM29() {
        return ITEM29;
    }

    /**
     * 項目29
     * @param ITEM29 項目29
     */
    public void setITEM29(String ITEM29) {
        this.ITEM29 = ITEM29 == null ? null : ITEM29.trim();
    }

    /**
     * 項目30
     * @return ITEM30 項目30
     */
    public String getITEM30() {
        return ITEM30;
    }

    /**
     * 項目30
     * @param ITEM30 項目30
     */
    public void setITEM30(String ITEM30) {
        this.ITEM30 = ITEM30 == null ? null : ITEM30.trim();
    }

    /**
     * 項目31
     * @return ITEM31 項目31
     */
    public String getITEM31() {
        return ITEM31;
    }

    /**
     * 項目31
     * @param ITEM31 項目31
     */
    public void setITEM31(String ITEM31) {
        this.ITEM31 = ITEM31 == null ? null : ITEM31.trim();
    }

    /**
     * 項目32
     * @return ITEM32 項目32
     */
    public String getITEM32() {
        return ITEM32;
    }

    /**
     * 項目32
     * @param ITEM32 項目32
     */
    public void setITEM32(String ITEM32) {
        this.ITEM32 = ITEM32 == null ? null : ITEM32.trim();
    }

    /**
     * 項目33
     * @return ITEM33 項目33
     */
    public String getITEM33() {
        return ITEM33;
    }

    /**
     * 項目33
     * @param ITEM33 項目33
     */
    public void setITEM33(String ITEM33) {
        this.ITEM33 = ITEM33 == null ? null : ITEM33.trim();
    }

    /**
     * 項目34
     * @return ITEM34 項目34
     */
    public String getITEM34() {
        return ITEM34;
    }

    /**
     * 項目34
     * @param ITEM34 項目34
     */
    public void setITEM34(String ITEM34) {
        this.ITEM34 = ITEM34 == null ? null : ITEM34.trim();
    }

    /**
     * 項目35
     * @return ITEM35 項目35
     */
    public String getITEM35() {
        return ITEM35;
    }

    /**
     * 項目35
     * @param ITEM35 項目35
     */
    public void setITEM35(String ITEM35) {
        this.ITEM35 = ITEM35 == null ? null : ITEM35.trim();
    }

    /**
     * 項目36
     * @return ITEM36 項目36
     */
    public String getITEM36() {
        return ITEM36;
    }

    /**
     * 項目36
     * @param ITEM36 項目36
     */
    public void setITEM36(String ITEM36) {
        this.ITEM36 = ITEM36 == null ? null : ITEM36.trim();
    }

    /**
     * 項目37
     * @return ITEM37 項目37
     */
    public String getITEM37() {
        return ITEM37;
    }

    /**
     * 項目37
     * @param ITEM37 項目37
     */
    public void setITEM37(String ITEM37) {
        this.ITEM37 = ITEM37 == null ? null : ITEM37.trim();
    }

    /**
     * 項目38
     * @return ITEM38 項目38
     */
    public String getITEM38() {
        return ITEM38;
    }

    /**
     * 項目38
     * @param ITEM38 項目38
     */
    public void setITEM38(String ITEM38) {
        this.ITEM38 = ITEM38 == null ? null : ITEM38.trim();
    }

    /**
     * 項目39
     * @return ITEM39 項目39
     */
    public String getITEM39() {
        return ITEM39;
    }

    /**
     * 項目39
     * @param ITEM39 項目39
     */
    public void setITEM39(String ITEM39) {
        this.ITEM39 = ITEM39 == null ? null : ITEM39.trim();
    }

    /**
     * 項目40
     * @return ITEM40 項目40
     */
    public String getITEM40() {
        return ITEM40;
    }

    /**
     * 項目40
     * @param ITEM40 項目40
     */
    public void setITEM40(String ITEM40) {
        this.ITEM40 = ITEM40 == null ? null : ITEM40.trim();
    }

    /**
     * 項目41
     * @return ITEM41 項目41
     */
    public String getITEM41() {
        return ITEM41;
    }

    /**
     * 項目41
     * @param ITEM41 項目41
     */
    public void setITEM41(String ITEM41) {
        this.ITEM41 = ITEM41 == null ? null : ITEM41.trim();
    }

    /**
     * 項目42
     * @return ITEM42 項目42
     */
    public String getITEM42() {
        return ITEM42;
    }

    /**
     * 項目42
     * @param ITEM42 項目42
     */
    public void setITEM42(String ITEM42) {
        this.ITEM42 = ITEM42 == null ? null : ITEM42.trim();
    }

    /**
     * 項目43
     * @return ITEM43 項目43
     */
    public String getITEM43() {
        return ITEM43;
    }

    /**
     * 項目43
     * @param ITEM43 項目43
     */
    public void setITEM43(String ITEM43) {
        this.ITEM43 = ITEM43 == null ? null : ITEM43.trim();
    }

    /**
     * 項目44
     * @return ITEM44 項目44
     */
    public String getITEM44() {
        return ITEM44;
    }

    /**
     * 項目44
     * @param ITEM44 項目44
     */
    public void setITEM44(String ITEM44) {
        this.ITEM44 = ITEM44 == null ? null : ITEM44.trim();
    }

    /**
     * 項目45
     * @return ITEM45 項目45
     */
    public String getITEM45() {
        return ITEM45;
    }

    /**
     * 項目45
     * @param ITEM45 項目45
     */
    public void setITEM45(String ITEM45) {
        this.ITEM45 = ITEM45 == null ? null : ITEM45.trim();
    }

    /**
     * 項目46
     * @return ITEM46 項目46
     */
    public String getITEM46() {
        return ITEM46;
    }

    /**
     * 項目46
     * @param ITEM46 項目46
     */
    public void setITEM46(String ITEM46) {
        this.ITEM46 = ITEM46 == null ? null : ITEM46.trim();
    }

    /**
     * 項目47
     * @return ITEM47 項目47
     */
    public String getITEM47() {
        return ITEM47;
    }

    /**
     * 項目47
     * @param ITEM47 項目47
     */
    public void setITEM47(String ITEM47) {
        this.ITEM47 = ITEM47 == null ? null : ITEM47.trim();
    }

    /**
     * 項目48
     * @return ITEM48 項目48
     */
    public String getITEM48() {
        return ITEM48;
    }

    /**
     * 項目48
     * @param ITEM48 項目48
     */
    public void setITEM48(String ITEM48) {
        this.ITEM48 = ITEM48 == null ? null : ITEM48.trim();
    }

    /**
     * 項目49
     * @return ITEM49 項目49
     */
    public String getITEM49() {
        return ITEM49;
    }

    /**
     * 項目49
     * @param ITEM49 項目49
     */
    public void setITEM49(String ITEM49) {
        this.ITEM49 = ITEM49 == null ? null : ITEM49.trim();
    }

    /**
     * 項目50
     * @return ITEM50 項目50
     */
    public String getITEM50() {
        return ITEM50;
    }

    /**
     * 項目50
     * @param ITEM50 項目50
     */
    public void setITEM50(String ITEM50) {
        this.ITEM50 = ITEM50 == null ? null : ITEM50.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}