package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class EJianDevKbStblKey implements Serializable {
    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * LN_設置機器論理番号
     */
    private String LN_DEV;

    /**
     * E_JIAN_DEV_KB_STBL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * LN_設置機器論理番号
     * @return LN_DEV LN_設置機器論理番号
     */
    public String getLN_DEV() {
        return LN_DEV;
    }

    /**
     * LN_設置機器論理番号
     * @param LN_DEV LN_設置機器論理番号
     */
    public void setLN_DEV(String LN_DEV) {
        this.LN_DEV = LN_DEV == null ? null : LN_DEV.trim();
    }
}