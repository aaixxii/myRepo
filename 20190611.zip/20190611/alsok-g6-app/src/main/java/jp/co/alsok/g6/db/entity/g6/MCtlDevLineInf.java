package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MCtlDevLineInf extends MCtlDevLineInfKey implements Serializable {
    /**
     * ISP事業者名
     */
    private String ISP_NM;

    /**
     * 回線事業者名
     */
    private String LINE_CAREER_NM;

    /**
     * 回線名
     */
    private String LINE_NM;

    /**
     * 接続状況
     */
    private String CONN_FLG;

    /**
     * モデムメーカ名
     */
    private String MDM_MAKER_NM;

    /**
     * モデム名
     */
    private String MDM_NM;

    /**
     * ルータメーカ名
     */
    private String ROUTER_MAKER_NM;

    /**
     * ルータ名
     */
    private String ROUTER_NM;

    /**
     * HUBメーカ名
     */
    private String HUB_MAKER_NM;

    /**
     * HUB名
     */
    private String HUB_NM;

    /**
     * 終端装置(ONU)メーカ名
     */
    private String ONU_MAKER_NM;

    /**
     * 終端装置(ONU)名
     */
    private String ONU_NM;

    /**
     * VPN端末フラグ
     */
    private String VPN_FLG;

    /**
     * VOIP端末フラグ
     */
    private String VOIP_FLG;

    /**
     * ＰＣ接続数
     */
    private String PC_CONN_NUM;

    /**
     * その他接続フラグ
     */
    private String ETC_CONN_FLG;

    /**
     * その他接続数
     */
    private String ETC_CONN_NUM;

    /**
     * その他接続機器名
     */
    private String ETC_CONN_NM;

    /**
     * 停電対策(UPS)フラグ
     */
    private String UPS_FLG;

    /**
     * 停電対策(UPS)当社使用可否フラグ
     */
    private String UPS_PERMIT_FLG;

    /**
     * ファイアウォール有無フラグ
     */
    private String FWALL_FLG;

    /**
     * ファイアウォールVPN可否フラグ
     */
    private String FWALL_VPN_FLG;

    /**
     * ファイアウォール設定変更可否フラグ
     */
    private String FWALL_CONF_CNG_FLG;

    /**
     * プロキシサーバ有無フラグ
     */
    private String PROXY_FLG;

    /**
     * プロキシサーバVPN可否フラグ
     */
    private String PROXY_VPN_FLG;

    /**
     * プロキシサーバ設定変更可否フラグ
     */
    private String PROXY_CONF_CNG_FLG;

    /**
     * 空きLANポート有無フラグ
     */
    private String LAN_PORT_FLG;

    /**
     * ネットワーク機器フラグ
     */
    private String NETWORK_DEV_FLG;

    /**
     * モデム提供メーカ？【用途不明】
     */
    private String PROVDE_MDM_MAKER_FLG;

    /**
     * モデム製品名フラグ【用途不明】
     */
    private String MDM_NM_FLG;

    /**
     * 備考
     */
    private String BIKOU;

    /**
     * M_CTL_DEV_LINE_INF
     */
    private static final long serialVersionUID = 1L;

    /**
     * ISP事業者名
     * @return ISP_NM ISP事業者名
     */
    public String getISP_NM() {
        return ISP_NM;
    }

    /**
     * ISP事業者名
     * @param ISP_NM ISP事業者名
     */
    public void setISP_NM(String ISP_NM) {
        this.ISP_NM = ISP_NM == null ? null : ISP_NM.trim();
    }

    /**
     * 回線事業者名
     * @return LINE_CAREER_NM 回線事業者名
     */
    public String getLINE_CAREER_NM() {
        return LINE_CAREER_NM;
    }

    /**
     * 回線事業者名
     * @param LINE_CAREER_NM 回線事業者名
     */
    public void setLINE_CAREER_NM(String LINE_CAREER_NM) {
        this.LINE_CAREER_NM = LINE_CAREER_NM == null ? null : LINE_CAREER_NM.trim();
    }

    /**
     * 回線名
     * @return LINE_NM 回線名
     */
    public String getLINE_NM() {
        return LINE_NM;
    }

    /**
     * 回線名
     * @param LINE_NM 回線名
     */
    public void setLINE_NM(String LINE_NM) {
        this.LINE_NM = LINE_NM == null ? null : LINE_NM.trim();
    }

    /**
     * 接続状況
     * @return CONN_FLG 接続状況
     */
    public String getCONN_FLG() {
        return CONN_FLG;
    }

    /**
     * 接続状況
     * @param CONN_FLG 接続状況
     */
    public void setCONN_FLG(String CONN_FLG) {
        this.CONN_FLG = CONN_FLG == null ? null : CONN_FLG.trim();
    }

    /**
     * モデムメーカ名
     * @return MDM_MAKER_NM モデムメーカ名
     */
    public String getMDM_MAKER_NM() {
        return MDM_MAKER_NM;
    }

    /**
     * モデムメーカ名
     * @param MDM_MAKER_NM モデムメーカ名
     */
    public void setMDM_MAKER_NM(String MDM_MAKER_NM) {
        this.MDM_MAKER_NM = MDM_MAKER_NM == null ? null : MDM_MAKER_NM.trim();
    }

    /**
     * モデム名
     * @return MDM_NM モデム名
     */
    public String getMDM_NM() {
        return MDM_NM;
    }

    /**
     * モデム名
     * @param MDM_NM モデム名
     */
    public void setMDM_NM(String MDM_NM) {
        this.MDM_NM = MDM_NM == null ? null : MDM_NM.trim();
    }

    /**
     * ルータメーカ名
     * @return ROUTER_MAKER_NM ルータメーカ名
     */
    public String getROUTER_MAKER_NM() {
        return ROUTER_MAKER_NM;
    }

    /**
     * ルータメーカ名
     * @param ROUTER_MAKER_NM ルータメーカ名
     */
    public void setROUTER_MAKER_NM(String ROUTER_MAKER_NM) {
        this.ROUTER_MAKER_NM = ROUTER_MAKER_NM == null ? null : ROUTER_MAKER_NM.trim();
    }

    /**
     * ルータ名
     * @return ROUTER_NM ルータ名
     */
    public String getROUTER_NM() {
        return ROUTER_NM;
    }

    /**
     * ルータ名
     * @param ROUTER_NM ルータ名
     */
    public void setROUTER_NM(String ROUTER_NM) {
        this.ROUTER_NM = ROUTER_NM == null ? null : ROUTER_NM.trim();
    }

    /**
     * HUBメーカ名
     * @return HUB_MAKER_NM HUBメーカ名
     */
    public String getHUB_MAKER_NM() {
        return HUB_MAKER_NM;
    }

    /**
     * HUBメーカ名
     * @param HUB_MAKER_NM HUBメーカ名
     */
    public void setHUB_MAKER_NM(String HUB_MAKER_NM) {
        this.HUB_MAKER_NM = HUB_MAKER_NM == null ? null : HUB_MAKER_NM.trim();
    }

    /**
     * HUB名
     * @return HUB_NM HUB名
     */
    public String getHUB_NM() {
        return HUB_NM;
    }

    /**
     * HUB名
     * @param HUB_NM HUB名
     */
    public void setHUB_NM(String HUB_NM) {
        this.HUB_NM = HUB_NM == null ? null : HUB_NM.trim();
    }

    /**
     * 終端装置(ONU)メーカ名
     * @return ONU_MAKER_NM 終端装置(ONU)メーカ名
     */
    public String getONU_MAKER_NM() {
        return ONU_MAKER_NM;
    }

    /**
     * 終端装置(ONU)メーカ名
     * @param ONU_MAKER_NM 終端装置(ONU)メーカ名
     */
    public void setONU_MAKER_NM(String ONU_MAKER_NM) {
        this.ONU_MAKER_NM = ONU_MAKER_NM == null ? null : ONU_MAKER_NM.trim();
    }

    /**
     * 終端装置(ONU)名
     * @return ONU_NM 終端装置(ONU)名
     */
    public String getONU_NM() {
        return ONU_NM;
    }

    /**
     * 終端装置(ONU)名
     * @param ONU_NM 終端装置(ONU)名
     */
    public void setONU_NM(String ONU_NM) {
        this.ONU_NM = ONU_NM == null ? null : ONU_NM.trim();
    }

    /**
     * VPN端末フラグ
     * @return VPN_FLG VPN端末フラグ
     */
    public String getVPN_FLG() {
        return VPN_FLG;
    }

    /**
     * VPN端末フラグ
     * @param VPN_FLG VPN端末フラグ
     */
    public void setVPN_FLG(String VPN_FLG) {
        this.VPN_FLG = VPN_FLG == null ? null : VPN_FLG.trim();
    }

    /**
     * VOIP端末フラグ
     * @return VOIP_FLG VOIP端末フラグ
     */
    public String getVOIP_FLG() {
        return VOIP_FLG;
    }

    /**
     * VOIP端末フラグ
     * @param VOIP_FLG VOIP端末フラグ
     */
    public void setVOIP_FLG(String VOIP_FLG) {
        this.VOIP_FLG = VOIP_FLG == null ? null : VOIP_FLG.trim();
    }

    /**
     * ＰＣ接続数
     * @return PC_CONN_NUM ＰＣ接続数
     */
    public String getPC_CONN_NUM() {
        return PC_CONN_NUM;
    }

    /**
     * ＰＣ接続数
     * @param PC_CONN_NUM ＰＣ接続数
     */
    public void setPC_CONN_NUM(String PC_CONN_NUM) {
        this.PC_CONN_NUM = PC_CONN_NUM == null ? null : PC_CONN_NUM.trim();
    }

    /**
     * その他接続フラグ
     * @return ETC_CONN_FLG その他接続フラグ
     */
    public String getETC_CONN_FLG() {
        return ETC_CONN_FLG;
    }

    /**
     * その他接続フラグ
     * @param ETC_CONN_FLG その他接続フラグ
     */
    public void setETC_CONN_FLG(String ETC_CONN_FLG) {
        this.ETC_CONN_FLG = ETC_CONN_FLG == null ? null : ETC_CONN_FLG.trim();
    }

    /**
     * その他接続数
     * @return ETC_CONN_NUM その他接続数
     */
    public String getETC_CONN_NUM() {
        return ETC_CONN_NUM;
    }

    /**
     * その他接続数
     * @param ETC_CONN_NUM その他接続数
     */
    public void setETC_CONN_NUM(String ETC_CONN_NUM) {
        this.ETC_CONN_NUM = ETC_CONN_NUM == null ? null : ETC_CONN_NUM.trim();
    }

    /**
     * その他接続機器名
     * @return ETC_CONN_NM その他接続機器名
     */
    public String getETC_CONN_NM() {
        return ETC_CONN_NM;
    }

    /**
     * その他接続機器名
     * @param ETC_CONN_NM その他接続機器名
     */
    public void setETC_CONN_NM(String ETC_CONN_NM) {
        this.ETC_CONN_NM = ETC_CONN_NM == null ? null : ETC_CONN_NM.trim();
    }

    /**
     * 停電対策(UPS)フラグ
     * @return UPS_FLG 停電対策(UPS)フラグ
     */
    public String getUPS_FLG() {
        return UPS_FLG;
    }

    /**
     * 停電対策(UPS)フラグ
     * @param UPS_FLG 停電対策(UPS)フラグ
     */
    public void setUPS_FLG(String UPS_FLG) {
        this.UPS_FLG = UPS_FLG == null ? null : UPS_FLG.trim();
    }

    /**
     * 停電対策(UPS)当社使用可否フラグ
     * @return UPS_PERMIT_FLG 停電対策(UPS)当社使用可否フラグ
     */
    public String getUPS_PERMIT_FLG() {
        return UPS_PERMIT_FLG;
    }

    /**
     * 停電対策(UPS)当社使用可否フラグ
     * @param UPS_PERMIT_FLG 停電対策(UPS)当社使用可否フラグ
     */
    public void setUPS_PERMIT_FLG(String UPS_PERMIT_FLG) {
        this.UPS_PERMIT_FLG = UPS_PERMIT_FLG == null ? null : UPS_PERMIT_FLG.trim();
    }

    /**
     * ファイアウォール有無フラグ
     * @return FWALL_FLG ファイアウォール有無フラグ
     */
    public String getFWALL_FLG() {
        return FWALL_FLG;
    }

    /**
     * ファイアウォール有無フラグ
     * @param FWALL_FLG ファイアウォール有無フラグ
     */
    public void setFWALL_FLG(String FWALL_FLG) {
        this.FWALL_FLG = FWALL_FLG == null ? null : FWALL_FLG.trim();
    }

    /**
     * ファイアウォールVPN可否フラグ
     * @return FWALL_VPN_FLG ファイアウォールVPN可否フラグ
     */
    public String getFWALL_VPN_FLG() {
        return FWALL_VPN_FLG;
    }

    /**
     * ファイアウォールVPN可否フラグ
     * @param FWALL_VPN_FLG ファイアウォールVPN可否フラグ
     */
    public void setFWALL_VPN_FLG(String FWALL_VPN_FLG) {
        this.FWALL_VPN_FLG = FWALL_VPN_FLG == null ? null : FWALL_VPN_FLG.trim();
    }

    /**
     * ファイアウォール設定変更可否フラグ
     * @return FWALL_CONF_CNG_FLG ファイアウォール設定変更可否フラグ
     */
    public String getFWALL_CONF_CNG_FLG() {
        return FWALL_CONF_CNG_FLG;
    }

    /**
     * ファイアウォール設定変更可否フラグ
     * @param FWALL_CONF_CNG_FLG ファイアウォール設定変更可否フラグ
     */
    public void setFWALL_CONF_CNG_FLG(String FWALL_CONF_CNG_FLG) {
        this.FWALL_CONF_CNG_FLG = FWALL_CONF_CNG_FLG == null ? null : FWALL_CONF_CNG_FLG.trim();
    }

    /**
     * プロキシサーバ有無フラグ
     * @return PROXY_FLG プロキシサーバ有無フラグ
     */
    public String getPROXY_FLG() {
        return PROXY_FLG;
    }

    /**
     * プロキシサーバ有無フラグ
     * @param PROXY_FLG プロキシサーバ有無フラグ
     */
    public void setPROXY_FLG(String PROXY_FLG) {
        this.PROXY_FLG = PROXY_FLG == null ? null : PROXY_FLG.trim();
    }

    /**
     * プロキシサーバVPN可否フラグ
     * @return PROXY_VPN_FLG プロキシサーバVPN可否フラグ
     */
    public String getPROXY_VPN_FLG() {
        return PROXY_VPN_FLG;
    }

    /**
     * プロキシサーバVPN可否フラグ
     * @param PROXY_VPN_FLG プロキシサーバVPN可否フラグ
     */
    public void setPROXY_VPN_FLG(String PROXY_VPN_FLG) {
        this.PROXY_VPN_FLG = PROXY_VPN_FLG == null ? null : PROXY_VPN_FLG.trim();
    }

    /**
     * プロキシサーバ設定変更可否フラグ
     * @return PROXY_CONF_CNG_FLG プロキシサーバ設定変更可否フラグ
     */
    public String getPROXY_CONF_CNG_FLG() {
        return PROXY_CONF_CNG_FLG;
    }

    /**
     * プロキシサーバ設定変更可否フラグ
     * @param PROXY_CONF_CNG_FLG プロキシサーバ設定変更可否フラグ
     */
    public void setPROXY_CONF_CNG_FLG(String PROXY_CONF_CNG_FLG) {
        this.PROXY_CONF_CNG_FLG = PROXY_CONF_CNG_FLG == null ? null : PROXY_CONF_CNG_FLG.trim();
    }

    /**
     * 空きLANポート有無フラグ
     * @return LAN_PORT_FLG 空きLANポート有無フラグ
     */
    public String getLAN_PORT_FLG() {
        return LAN_PORT_FLG;
    }

    /**
     * 空きLANポート有無フラグ
     * @param LAN_PORT_FLG 空きLANポート有無フラグ
     */
    public void setLAN_PORT_FLG(String LAN_PORT_FLG) {
        this.LAN_PORT_FLG = LAN_PORT_FLG == null ? null : LAN_PORT_FLG.trim();
    }

    /**
     * ネットワーク機器フラグ
     * @return NETWORK_DEV_FLG ネットワーク機器フラグ
     */
    public String getNETWORK_DEV_FLG() {
        return NETWORK_DEV_FLG;
    }

    /**
     * ネットワーク機器フラグ
     * @param NETWORK_DEV_FLG ネットワーク機器フラグ
     */
    public void setNETWORK_DEV_FLG(String NETWORK_DEV_FLG) {
        this.NETWORK_DEV_FLG = NETWORK_DEV_FLG == null ? null : NETWORK_DEV_FLG.trim();
    }

    /**
     * モデム提供メーカ？【用途不明】
     * @return PROVDE_MDM_MAKER_FLG モデム提供メーカ？【用途不明】
     */
    public String getPROVDE_MDM_MAKER_FLG() {
        return PROVDE_MDM_MAKER_FLG;
    }

    /**
     * モデム提供メーカ？【用途不明】
     * @param PROVDE_MDM_MAKER_FLG モデム提供メーカ？【用途不明】
     */
    public void setPROVDE_MDM_MAKER_FLG(String PROVDE_MDM_MAKER_FLG) {
        this.PROVDE_MDM_MAKER_FLG = PROVDE_MDM_MAKER_FLG == null ? null : PROVDE_MDM_MAKER_FLG.trim();
    }

    /**
     * モデム製品名フラグ【用途不明】
     * @return MDM_NM_FLG モデム製品名フラグ【用途不明】
     */
    public String getMDM_NM_FLG() {
        return MDM_NM_FLG;
    }

    /**
     * モデム製品名フラグ【用途不明】
     * @param MDM_NM_FLG モデム製品名フラグ【用途不明】
     */
    public void setMDM_NM_FLG(String MDM_NM_FLG) {
        this.MDM_NM_FLG = MDM_NM_FLG == null ? null : MDM_NM_FLG.trim();
    }

    /**
     * 備考
     * @return BIKOU 備考
     */
    public String getBIKOU() {
        return BIKOU;
    }

    /**
     * 備考
     * @param BIKOU 備考
     */
    public void setBIKOU(String BIKOU) {
        this.BIKOU = BIKOU == null ? null : BIKOU.trim();
    }
}