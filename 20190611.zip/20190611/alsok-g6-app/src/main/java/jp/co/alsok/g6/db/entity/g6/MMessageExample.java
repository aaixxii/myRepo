package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MMessageExample {
    /**
     * M_MESSAGE
     */
    protected String orderByClause;

    /**
     * M_MESSAGE
     */
    protected boolean distinct;

    /**
     * M_MESSAGE
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MMessageExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_MESSAGE null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andMESSAGE_IDIsNull() {
            addCriterion("MESSAGE_ID is null");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDIsNotNull() {
            addCriterion("MESSAGE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDEqualTo(String value) {
            addCriterion("MESSAGE_ID =", value, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDNotEqualTo(String value) {
            addCriterion("MESSAGE_ID <>", value, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDGreaterThan(String value) {
            addCriterion("MESSAGE_ID >", value, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("MESSAGE_ID >=", value, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDLessThan(String value) {
            addCriterion("MESSAGE_ID <", value, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDLessThanOrEqualTo(String value) {
            addCriterion("MESSAGE_ID <=", value, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDLike(String value) {
            addCriterion("MESSAGE_ID like", value, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDNotLike(String value) {
            addCriterion("MESSAGE_ID not like", value, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDIn(List<String> values) {
            addCriterion("MESSAGE_ID in", values, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDNotIn(List<String> values) {
            addCriterion("MESSAGE_ID not in", values, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDBetween(String value1, String value2) {
            addCriterion("MESSAGE_ID between", value1, value2, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDNotBetween(String value1, String value2) {
            addCriterion("MESSAGE_ID not between", value1, value2, "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNIsNull() {
            addCriterion("SITE_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNIsNotNull() {
            addCriterion("SITE_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNEqualTo(String value) {
            addCriterion("SITE_KBN =", value, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNNotEqualTo(String value) {
            addCriterion("SITE_KBN <>", value, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNGreaterThan(String value) {
            addCriterion("SITE_KBN >", value, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SITE_KBN >=", value, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNLessThan(String value) {
            addCriterion("SITE_KBN <", value, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNLessThanOrEqualTo(String value) {
            addCriterion("SITE_KBN <=", value, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNLike(String value) {
            addCriterion("SITE_KBN like", value, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNNotLike(String value) {
            addCriterion("SITE_KBN not like", value, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNIn(List<String> values) {
            addCriterion("SITE_KBN in", values, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNNotIn(List<String> values) {
            addCriterion("SITE_KBN not in", values, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNBetween(String value1, String value2) {
            addCriterion("SITE_KBN between", value1, value2, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNNotBetween(String value1, String value2) {
            addCriterion("SITE_KBN not between", value1, value2, "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPIsNull() {
            addCriterion("MSG_NAIYOU_JP is null");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPIsNotNull() {
            addCriterion("MSG_NAIYOU_JP is not null");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPEqualTo(String value) {
            addCriterion("MSG_NAIYOU_JP =", value, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPNotEqualTo(String value) {
            addCriterion("MSG_NAIYOU_JP <>", value, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPGreaterThan(String value) {
            addCriterion("MSG_NAIYOU_JP >", value, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPGreaterThanOrEqualTo(String value) {
            addCriterion("MSG_NAIYOU_JP >=", value, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPLessThan(String value) {
            addCriterion("MSG_NAIYOU_JP <", value, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPLessThanOrEqualTo(String value) {
            addCriterion("MSG_NAIYOU_JP <=", value, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPLike(String value) {
            addCriterion("MSG_NAIYOU_JP like", value, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPNotLike(String value) {
            addCriterion("MSG_NAIYOU_JP not like", value, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPIn(List<String> values) {
            addCriterion("MSG_NAIYOU_JP in", values, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPNotIn(List<String> values) {
            addCriterion("MSG_NAIYOU_JP not in", values, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPBetween(String value1, String value2) {
            addCriterion("MSG_NAIYOU_JP between", value1, value2, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPNotBetween(String value1, String value2) {
            addCriterion("MSG_NAIYOU_JP not between", value1, value2, "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENIsNull() {
            addCriterion("MSG_NAIYOU_EN is null");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENIsNotNull() {
            addCriterion("MSG_NAIYOU_EN is not null");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENEqualTo(String value) {
            addCriterion("MSG_NAIYOU_EN =", value, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENNotEqualTo(String value) {
            addCriterion("MSG_NAIYOU_EN <>", value, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENGreaterThan(String value) {
            addCriterion("MSG_NAIYOU_EN >", value, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENGreaterThanOrEqualTo(String value) {
            addCriterion("MSG_NAIYOU_EN >=", value, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENLessThan(String value) {
            addCriterion("MSG_NAIYOU_EN <", value, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENLessThanOrEqualTo(String value) {
            addCriterion("MSG_NAIYOU_EN <=", value, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENLike(String value) {
            addCriterion("MSG_NAIYOU_EN like", value, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENNotLike(String value) {
            addCriterion("MSG_NAIYOU_EN not like", value, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENIn(List<String> values) {
            addCriterion("MSG_NAIYOU_EN in", values, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENNotIn(List<String> values) {
            addCriterion("MSG_NAIYOU_EN not in", values, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENBetween(String value1, String value2) {
            addCriterion("MSG_NAIYOU_EN between", value1, value2, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENNotBetween(String value1, String value2) {
            addCriterion("MSG_NAIYOU_EN not between", value1, value2, "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHIsNull() {
            addCriterion("MSG_NAIYOU_ZH is null");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHIsNotNull() {
            addCriterion("MSG_NAIYOU_ZH is not null");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHEqualTo(String value) {
            addCriterion("MSG_NAIYOU_ZH =", value, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHNotEqualTo(String value) {
            addCriterion("MSG_NAIYOU_ZH <>", value, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHGreaterThan(String value) {
            addCriterion("MSG_NAIYOU_ZH >", value, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHGreaterThanOrEqualTo(String value) {
            addCriterion("MSG_NAIYOU_ZH >=", value, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHLessThan(String value) {
            addCriterion("MSG_NAIYOU_ZH <", value, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHLessThanOrEqualTo(String value) {
            addCriterion("MSG_NAIYOU_ZH <=", value, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHLike(String value) {
            addCriterion("MSG_NAIYOU_ZH like", value, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHNotLike(String value) {
            addCriterion("MSG_NAIYOU_ZH not like", value, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHIn(List<String> values) {
            addCriterion("MSG_NAIYOU_ZH in", values, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHNotIn(List<String> values) {
            addCriterion("MSG_NAIYOU_ZH not in", values, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHBetween(String value1, String value2) {
            addCriterion("MSG_NAIYOU_ZH between", value1, value2, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHNotBetween(String value1, String value2) {
            addCriterion("MSG_NAIYOU_ZH not between", value1, value2, "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andBIKOUIsNull() {
            addCriterion("BIKOU is null");
            return (Criteria) this;
        }

        public Criteria andBIKOUIsNotNull() {
            addCriterion("BIKOU is not null");
            return (Criteria) this;
        }

        public Criteria andBIKOUEqualTo(String value) {
            addCriterion("BIKOU =", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotEqualTo(String value) {
            addCriterion("BIKOU <>", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUGreaterThan(String value) {
            addCriterion("BIKOU >", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUGreaterThanOrEqualTo(String value) {
            addCriterion("BIKOU >=", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULessThan(String value) {
            addCriterion("BIKOU <", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULessThanOrEqualTo(String value) {
            addCriterion("BIKOU <=", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULike(String value) {
            addCriterion("BIKOU like", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotLike(String value) {
            addCriterion("BIKOU not like", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUIn(List<String> values) {
            addCriterion("BIKOU in", values, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotIn(List<String> values) {
            addCriterion("BIKOU not in", values, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUBetween(String value1, String value2) {
            addCriterion("BIKOU between", value1, value2, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotBetween(String value1, String value2) {
            addCriterion("BIKOU not between", value1, value2, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_IDLikeInsensitive(String value) {
            addCriterion("upper(MESSAGE_ID) like", value.toUpperCase(), "MESSAGE_ID");
            return (Criteria) this;
        }

        public Criteria andSITE_KBNLikeInsensitive(String value) {
            addCriterion("upper(SITE_KBN) like", value.toUpperCase(), "SITE_KBN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_JPLikeInsensitive(String value) {
            addCriterion("upper(MSG_NAIYOU_JP) like", value.toUpperCase(), "MSG_NAIYOU_JP");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ENLikeInsensitive(String value) {
            addCriterion("upper(MSG_NAIYOU_EN) like", value.toUpperCase(), "MSG_NAIYOU_EN");
            return (Criteria) this;
        }

        public Criteria andMSG_NAIYOU_ZHLikeInsensitive(String value) {
            addCriterion("upper(MSG_NAIYOU_ZH) like", value.toUpperCase(), "MSG_NAIYOU_ZH");
            return (Criteria) this;
        }

        public Criteria andBIKOULikeInsensitive(String value) {
            addCriterion("upper(BIKOU) like", value.toUpperCase(), "BIKOU");
            return (Criteria) this;
        }
    }

    /**
     * M_MESSAGE
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_MESSAGE null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}