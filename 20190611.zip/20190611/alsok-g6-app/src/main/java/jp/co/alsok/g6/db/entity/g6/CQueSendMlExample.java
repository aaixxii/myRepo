package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CQueSendMlExample {
    /**
     * C_QUE_SEND_ML
     */
    protected String orderByClause;

    /**
     * C_QUE_SEND_ML
     */
    protected boolean distinct;

    /**
     * C_QUE_SEND_ML
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public CQueSendMlExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * C_QUE_SEND_ML null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_QUE_SEND_MLIsNull() {
            addCriterion("LN_QUE_SEND_ML is null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLIsNotNull() {
            addCriterion("LN_QUE_SEND_ML is not null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLEqualTo(String value) {
            addCriterion("LN_QUE_SEND_ML =", value, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLNotEqualTo(String value) {
            addCriterion("LN_QUE_SEND_ML <>", value, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLGreaterThan(String value) {
            addCriterion("LN_QUE_SEND_ML >", value, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLGreaterThanOrEqualTo(String value) {
            addCriterion("LN_QUE_SEND_ML >=", value, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLLessThan(String value) {
            addCriterion("LN_QUE_SEND_ML <", value, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLLessThanOrEqualTo(String value) {
            addCriterion("LN_QUE_SEND_ML <=", value, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLLike(String value) {
            addCriterion("LN_QUE_SEND_ML like", value, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLNotLike(String value) {
            addCriterion("LN_QUE_SEND_ML not like", value, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLIn(List<String> values) {
            addCriterion("LN_QUE_SEND_ML in", values, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLNotIn(List<String> values) {
            addCriterion("LN_QUE_SEND_ML not in", values, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLBetween(String value1, String value2) {
            addCriterion("LN_QUE_SEND_ML between", value1, value2, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLNotBetween(String value1, String value2) {
            addCriterion("LN_QUE_SEND_ML not between", value1, value2, "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGIsNull() {
            addCriterion("LN_QUE_ML_TRIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGIsNotNull() {
            addCriterion("LN_QUE_ML_TRIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGEqualTo(String value) {
            addCriterion("LN_QUE_ML_TRIG =", value, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGNotEqualTo(String value) {
            addCriterion("LN_QUE_ML_TRIG <>", value, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGGreaterThan(String value) {
            addCriterion("LN_QUE_ML_TRIG >", value, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_QUE_ML_TRIG >=", value, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGLessThan(String value) {
            addCriterion("LN_QUE_ML_TRIG <", value, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGLessThanOrEqualTo(String value) {
            addCriterion("LN_QUE_ML_TRIG <=", value, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGLike(String value) {
            addCriterion("LN_QUE_ML_TRIG like", value, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGNotLike(String value) {
            addCriterion("LN_QUE_ML_TRIG not like", value, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGIn(List<String> values) {
            addCriterion("LN_QUE_ML_TRIG in", values, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGNotIn(List<String> values) {
            addCriterion("LN_QUE_ML_TRIG not in", values, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGBetween(String value1, String value2) {
            addCriterion("LN_QUE_ML_TRIG between", value1, value2, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGNotBetween(String value1, String value2) {
            addCriterion("LN_QUE_ML_TRIG not between", value1, value2, "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNull() {
            addCriterion("LN_ACNT_USER_COMMON is null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNotNull() {
            addCriterion("LN_ACNT_USER_COMMON is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON =", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <>", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON >", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON >=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON <", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON not like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON not in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON not between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNull() {
            addCriterion("LN_KB_CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNotNull() {
            addCriterion("LN_KB_CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUEqualTo(String value) {
            addCriterion("LN_KB_CHIKU =", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <>", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThan(String value) {
            addCriterion("LN_KB_CHIKU >", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU >=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThan(String value) {
            addCriterion("LN_KB_CHIKU <", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULike(String value) {
            addCriterion("LN_KB_CHIKU like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotLike(String value) {
            addCriterion("LN_KB_CHIKU not like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIn(List<String> values) {
            addCriterion("LN_KB_CHIKU in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotIn(List<String> values) {
            addCriterion("LN_KB_CHIKU not in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU not between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEIsNull() {
            addCriterion("LN_NOTICE is null");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEIsNotNull() {
            addCriterion("LN_NOTICE is not null");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEEqualTo(String value) {
            addCriterion("LN_NOTICE =", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICENotEqualTo(String value) {
            addCriterion("LN_NOTICE <>", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEGreaterThan(String value) {
            addCriterion("LN_NOTICE >", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEGreaterThanOrEqualTo(String value) {
            addCriterion("LN_NOTICE >=", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICELessThan(String value) {
            addCriterion("LN_NOTICE <", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICELessThanOrEqualTo(String value) {
            addCriterion("LN_NOTICE <=", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICELike(String value) {
            addCriterion("LN_NOTICE like", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICENotLike(String value) {
            addCriterion("LN_NOTICE not like", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEIn(List<String> values) {
            addCriterion("LN_NOTICE in", values, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICENotIn(List<String> values) {
            addCriterion("LN_NOTICE not in", values, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEBetween(String value1, String value2) {
            addCriterion("LN_NOTICE between", value1, value2, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICENotBetween(String value1, String value2) {
            addCriterion("LN_NOTICE not between", value1, value2, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andKINDIsNull() {
            addCriterion("KIND is null");
            return (Criteria) this;
        }

        public Criteria andKINDIsNotNull() {
            addCriterion("KIND is not null");
            return (Criteria) this;
        }

        public Criteria andKINDEqualTo(String value) {
            addCriterion("KIND =", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotEqualTo(String value) {
            addCriterion("KIND <>", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThan(String value) {
            addCriterion("KIND >", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThanOrEqualTo(String value) {
            addCriterion("KIND >=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThan(String value) {
            addCriterion("KIND <", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThanOrEqualTo(String value) {
            addCriterion("KIND <=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLike(String value) {
            addCriterion("KIND like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotLike(String value) {
            addCriterion("KIND not like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDIn(List<String> values) {
            addCriterion("KIND in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotIn(List<String> values) {
            addCriterion("KIND not in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDBetween(String value1, String value2) {
            addCriterion("KIND between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotBetween(String value1, String value2) {
            addCriterion("KIND not between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andSTSIsNull() {
            addCriterion("STS is null");
            return (Criteria) this;
        }

        public Criteria andSTSIsNotNull() {
            addCriterion("STS is not null");
            return (Criteria) this;
        }

        public Criteria andSTSEqualTo(String value) {
            addCriterion("STS =", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotEqualTo(String value) {
            addCriterion("STS <>", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSGreaterThan(String value) {
            addCriterion("STS >", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSGreaterThanOrEqualTo(String value) {
            addCriterion("STS >=", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLessThan(String value) {
            addCriterion("STS <", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLessThanOrEqualTo(String value) {
            addCriterion("STS <=", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLike(String value) {
            addCriterion("STS like", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotLike(String value) {
            addCriterion("STS not like", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSIn(List<String> values) {
            addCriterion("STS in", values, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotIn(List<String> values) {
            addCriterion("STS not in", values, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSBetween(String value1, String value2) {
            addCriterion("STS between", value1, value2, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotBetween(String value1, String value2) {
            addCriterion("STS not between", value1, value2, "STS");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIsNull() {
            addCriterion("PRIORITY is null");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIsNotNull() {
            addCriterion("PRIORITY is not null");
            return (Criteria) this;
        }

        public Criteria andPRIORITYEqualTo(String value) {
            addCriterion("PRIORITY =", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotEqualTo(String value) {
            addCriterion("PRIORITY <>", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYGreaterThan(String value) {
            addCriterion("PRIORITY >", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYGreaterThanOrEqualTo(String value) {
            addCriterion("PRIORITY >=", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLessThan(String value) {
            addCriterion("PRIORITY <", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLessThanOrEqualTo(String value) {
            addCriterion("PRIORITY <=", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLike(String value) {
            addCriterion("PRIORITY like", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotLike(String value) {
            addCriterion("PRIORITY not like", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIn(List<String> values) {
            addCriterion("PRIORITY in", values, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotIn(List<String> values) {
            addCriterion("PRIORITY not in", values, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYBetween(String value1, String value2) {
            addCriterion("PRIORITY between", value1, value2, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotBetween(String value1, String value2) {
            addCriterion("PRIORITY not between", value1, value2, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMIsNull() {
            addCriterion("RETRY_NUM is null");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMIsNotNull() {
            addCriterion("RETRY_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMEqualTo(String value) {
            addCriterion("RETRY_NUM =", value, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMNotEqualTo(String value) {
            addCriterion("RETRY_NUM <>", value, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMGreaterThan(String value) {
            addCriterion("RETRY_NUM >", value, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("RETRY_NUM >=", value, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMLessThan(String value) {
            addCriterion("RETRY_NUM <", value, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMLessThanOrEqualTo(String value) {
            addCriterion("RETRY_NUM <=", value, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMLike(String value) {
            addCriterion("RETRY_NUM like", value, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMNotLike(String value) {
            addCriterion("RETRY_NUM not like", value, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMIn(List<String> values) {
            addCriterion("RETRY_NUM in", values, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMNotIn(List<String> values) {
            addCriterion("RETRY_NUM not in", values, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMBetween(String value1, String value2) {
            addCriterion("RETRY_NUM between", value1, value2, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMNotBetween(String value1, String value2) {
            addCriterion("RETRY_NUM not between", value1, value2, "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMIsNull() {
            addCriterion("FROM_NM is null");
            return (Criteria) this;
        }

        public Criteria andFROM_NMIsNotNull() {
            addCriterion("FROM_NM is not null");
            return (Criteria) this;
        }

        public Criteria andFROM_NMEqualTo(String value) {
            addCriterion("FROM_NM =", value, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMNotEqualTo(String value) {
            addCriterion("FROM_NM <>", value, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMGreaterThan(String value) {
            addCriterion("FROM_NM >", value, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMGreaterThanOrEqualTo(String value) {
            addCriterion("FROM_NM >=", value, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMLessThan(String value) {
            addCriterion("FROM_NM <", value, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMLessThanOrEqualTo(String value) {
            addCriterion("FROM_NM <=", value, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMLike(String value) {
            addCriterion("FROM_NM like", value, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMNotLike(String value) {
            addCriterion("FROM_NM not like", value, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMIn(List<String> values) {
            addCriterion("FROM_NM in", values, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMNotIn(List<String> values) {
            addCriterion("FROM_NM not in", values, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMBetween(String value1, String value2) {
            addCriterion("FROM_NM between", value1, value2, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMNotBetween(String value1, String value2) {
            addCriterion("FROM_NM not between", value1, value2, "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMIsNull() {
            addCriterion("ADDR_FROM is null");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMIsNotNull() {
            addCriterion("ADDR_FROM is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMEqualTo(String value) {
            addCriterion("ADDR_FROM =", value, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMNotEqualTo(String value) {
            addCriterion("ADDR_FROM <>", value, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMGreaterThan(String value) {
            addCriterion("ADDR_FROM >", value, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_FROM >=", value, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMLessThan(String value) {
            addCriterion("ADDR_FROM <", value, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMLessThanOrEqualTo(String value) {
            addCriterion("ADDR_FROM <=", value, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMLike(String value) {
            addCriterion("ADDR_FROM like", value, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMNotLike(String value) {
            addCriterion("ADDR_FROM not like", value, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMIn(List<String> values) {
            addCriterion("ADDR_FROM in", values, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMNotIn(List<String> values) {
            addCriterion("ADDR_FROM not in", values, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMBetween(String value1, String value2) {
            addCriterion("ADDR_FROM between", value1, value2, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMNotBetween(String value1, String value2) {
            addCriterion("ADDR_FROM not between", value1, value2, "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_TOIsNull() {
            addCriterion("ADDR_TO is null");
            return (Criteria) this;
        }

        public Criteria andADDR_TOIsNotNull() {
            addCriterion("ADDR_TO is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_TOEqualTo(String value) {
            addCriterion("ADDR_TO =", value, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TONotEqualTo(String value) {
            addCriterion("ADDR_TO <>", value, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TOGreaterThan(String value) {
            addCriterion("ADDR_TO >", value, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TOGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_TO >=", value, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TOLessThan(String value) {
            addCriterion("ADDR_TO <", value, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TOLessThanOrEqualTo(String value) {
            addCriterion("ADDR_TO <=", value, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TOLike(String value) {
            addCriterion("ADDR_TO like", value, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TONotLike(String value) {
            addCriterion("ADDR_TO not like", value, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TOIn(List<String> values) {
            addCriterion("ADDR_TO in", values, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TONotIn(List<String> values) {
            addCriterion("ADDR_TO not in", values, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TOBetween(String value1, String value2) {
            addCriterion("ADDR_TO between", value1, value2, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andADDR_TONotBetween(String value1, String value2) {
            addCriterion("ADDR_TO not between", value1, value2, "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andTITLEIsNull() {
            addCriterion("TITLE is null");
            return (Criteria) this;
        }

        public Criteria andTITLEIsNotNull() {
            addCriterion("TITLE is not null");
            return (Criteria) this;
        }

        public Criteria andTITLEEqualTo(String value) {
            addCriterion("TITLE =", value, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLENotEqualTo(String value) {
            addCriterion("TITLE <>", value, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLEGreaterThan(String value) {
            addCriterion("TITLE >", value, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLEGreaterThanOrEqualTo(String value) {
            addCriterion("TITLE >=", value, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLELessThan(String value) {
            addCriterion("TITLE <", value, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLELessThanOrEqualTo(String value) {
            addCriterion("TITLE <=", value, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLELike(String value) {
            addCriterion("TITLE like", value, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLENotLike(String value) {
            addCriterion("TITLE not like", value, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLEIn(List<String> values) {
            addCriterion("TITLE in", values, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLENotIn(List<String> values) {
            addCriterion("TITLE not in", values, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLEBetween(String value1, String value2) {
            addCriterion("TITLE between", value1, value2, "TITLE");
            return (Criteria) this;
        }

        public Criteria andTITLENotBetween(String value1, String value2) {
            addCriterion("TITLE not between", value1, value2, "TITLE");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIsNull() {
            addCriterion("SEND_ABL_TS is null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIsNotNull() {
            addCriterion("SEND_ABL_TS is not null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSEqualTo(Date value) {
            addCriterion("SEND_ABL_TS =", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotEqualTo(Date value) {
            addCriterion("SEND_ABL_TS <>", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSGreaterThan(Date value) {
            addCriterion("SEND_ABL_TS >", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("SEND_ABL_TS >=", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSLessThan(Date value) {
            addCriterion("SEND_ABL_TS <", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSLessThanOrEqualTo(Date value) {
            addCriterion("SEND_ABL_TS <=", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIn(List<Date> values) {
            addCriterion("SEND_ABL_TS in", values, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotIn(List<Date> values) {
            addCriterion("SEND_ABL_TS not in", values, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSBetween(Date value1, Date value2) {
            addCriterion("SEND_ABL_TS between", value1, value2, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotBetween(Date value1, Date value2) {
            addCriterion("SEND_ABL_TS not between", value1, value2, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_SEND_MLLikeInsensitive(String value) {
            addCriterion("upper(LN_QUE_SEND_ML) like", value.toUpperCase(), "LN_QUE_SEND_ML");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_ML_TRIGLikeInsensitive(String value) {
            addCriterion("upper(LN_QUE_ML_TRIG) like", value.toUpperCase(), "LN_QUE_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLikeInsensitive(String value) {
            addCriterion("upper(LN_ACNT_USER_COMMON) like", value.toUpperCase(), "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULikeInsensitive(String value) {
            addCriterion("upper(LN_KB_CHIKU) like", value.toUpperCase(), "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICELikeInsensitive(String value) {
            addCriterion("upper(LN_NOTICE) like", value.toUpperCase(), "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andKINDLikeInsensitive(String value) {
            addCriterion("upper(KIND) like", value.toUpperCase(), "KIND");
            return (Criteria) this;
        }

        public Criteria andSTSLikeInsensitive(String value) {
            addCriterion("upper(STS) like", value.toUpperCase(), "STS");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLikeInsensitive(String value) {
            addCriterion("upper(PRIORITY) like", value.toUpperCase(), "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andRETRY_NUMLikeInsensitive(String value) {
            addCriterion("upper(RETRY_NUM) like", value.toUpperCase(), "RETRY_NUM");
            return (Criteria) this;
        }

        public Criteria andFROM_NMLikeInsensitive(String value) {
            addCriterion("upper(FROM_NM) like", value.toUpperCase(), "FROM_NM");
            return (Criteria) this;
        }

        public Criteria andADDR_FROMLikeInsensitive(String value) {
            addCriterion("upper(ADDR_FROM) like", value.toUpperCase(), "ADDR_FROM");
            return (Criteria) this;
        }

        public Criteria andADDR_TOLikeInsensitive(String value) {
            addCriterion("upper(ADDR_TO) like", value.toUpperCase(), "ADDR_TO");
            return (Criteria) this;
        }

        public Criteria andTITLELikeInsensitive(String value) {
            addCriterion("upper(TITLE) like", value.toUpperCase(), "TITLE");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * C_QUE_SEND_ML
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * C_QUE_SEND_ML null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}