//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0100Form.java
//
// 【機　能　名】SZWE0100_エラー表示ＣＬ検索画面用
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.form;

import java.util.List;

import jp.co.alsok.g6.zwe.dto.SZWE0100IchiranDto;
import jp.co.alsok.g6.zwe.entity.g6.MCd;
import jp.co.alsok.g6.zwe.entity.g6.MKeiyakuCtlDev;
import jp.co.alsok.g6.zwe.web.form.common.BaseForm;

/**
 * SZWE0100フォームのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
public class SZWE0100Form extends BaseForm {

    /**
     * エラー区分.
     */
    private String errorKubun;

    /**
     * エラー区分コンボボックス内容.
     */
    private List<MCd> errorKubunList;

    /**
     * GCコード.
     */
    private String selectGcCode;

    /**
     * 一覧.
     */
    private List<SZWE0100IchiranDto> searchResultList;

    /**
     * サービス区分.
     */
    private String serviceKubun;

    /**
     * サービス区分コンボボックス内容.
     */
    private List<MKeiyakuCtlDev> serviceKubunList;

    /**
     * 発生年月日（FROM).
     */
    private String fromHasseiDate;

    /**
     * 発生年月日（FROM) 時.
     */
    private String fromHasseiDateHour;

    /**
     * 発生年月日（FROM) 分.
     */
    private String fromHasseiDateMinute;

    /**
     * 発生年月日（TO).
     */
    private String toHasseiDate;

    /**
     * 発生年月日（TO) 時.
     */
    private String toHasseiDateHour;

    /**
     * 発生年月日（TO) 分.
     */
    private String toHasseiDateMinute;

    /**
     * 検索年月日.
     */
    private String searchDate;

    /**
     * 検索年月日 時.
     */
    private String searchDateHour;

    /**
     * 検索年月日 分.
     */
    private String searchDateMinute;

    /**
     * fromHasseiDate 取得
     * @return fromHasseiDate
     */
    public String getFromHasseiDate() {
        return fromHasseiDate;
    }

    /**
     * @param fromHasseiDate 設定 fromHasseiDate
     */
    public void setFromHasseiDate(String fromHasseiDate) {
        this.fromHasseiDate = fromHasseiDate;
    }

    /**
     * fromHasseiDateHour 取得
     * @return fromHasseiDateHour
     */
    public String getFromHasseiDateHour() {
        return fromHasseiDateHour;
    }

    /**
     * @param fromHasseiDateHour 設定 fromHasseiDateHour
     */
    public void setFromHasseiDateHour(String fromHasseiDateHour) {
        this.fromHasseiDateHour = fromHasseiDateHour;
    }

    /**
     * fromHasseiDateMinute 取得
     * @return fromHasseiDateMinute
     */
    public String getFromHasseiDateMinute() {
        return fromHasseiDateMinute;
    }

    /**
     * @param fromHasseiDateMinute 設定 fromHasseiDateMinute
     */
    public void setFromHasseiDateMinute(String fromHasseiDateMinute) {
        this.fromHasseiDateMinute = fromHasseiDateMinute;
    }

    /**
     * toHasseiDate 取得
     * @return toHasseiDate
     */
    public String getToHasseiDate() {
        return toHasseiDate;
    }

    /**
     * @param toHasseiDate 設定 toHasseiDate
     */
    public void setToHasseiDate(String toHasseiDate) {
        this.toHasseiDate = toHasseiDate;
    }

    /**
     * toHasseiDateHour 取得
     * @return toHasseiDateHour
     */
    public String getToHasseiDateHour() {
        return toHasseiDateHour;
    }

    /**
     * @param toHasseiDateHour 設定 toHasseiDateHour
     */
    public void setToHasseiDateHour(String toHasseiDateHour) {
        this.toHasseiDateHour = toHasseiDateHour;
    }

    /**
     * toHasseiDateMinute 取得
     * @return toHasseiDateMinute
     */
    public String getToHasseiDateMinute() {
        return toHasseiDateMinute;
    }

    /**
     * @param toHasseiDateMinute 設定 toHasseiDateMinute
     */
    public void setToHasseiDateMinute(String toHasseiDateMinute) {
        this.toHasseiDateMinute = toHasseiDateMinute;
    }

    /**
     * searchDate 取得
     * @return searchDate
     */
    public String getSearchDate() {
        return searchDate;
    }

    /**
     * @param searchDate 設定 searchDate
     */
    public void setSearchDate(String searchDate) {
        this.searchDate = searchDate;
    }

    /**
     * searchDateHour 取得
     * @return searchDateHour
     */
    public String getSearchDateHour() {
        return searchDateHour;
    }

    /**
     * @param searchDateHour 設定 searchDateHour
     */
    public void setSearchDateHour(String searchDateHour) {
        this.searchDateHour = searchDateHour;
    }

    /**
     * searchDateMinute 取得
     * @return searchDateMinute
     */
    public String getSearchDateMinute() {
        return searchDateMinute;
    }

    /**
     * @param searchDateMinute 設定 searchDateMinute
     */
    public void setSearchDateMinute(String searchDateMinute) {
        this.searchDateMinute = searchDateMinute;
    }

    /**
     * errorKubun 取得
     * @return errorKubun
     */
    public String getErrorKubun() {
        return errorKubun;
    }

    /**
     * @param errorKubun 設定 errorKubun
     */
    public void setErrorKubun(String errorKubun) {
        this.errorKubun = errorKubun;
    }

    /**
     * errorKubunList 取得
     * @return errorKubunList
     */
    public List<MCd> getErrorKubunList() {
        return errorKubunList;
    }

    /**
     * @param errorKubunList 設定 errorKubunList
     */
    public void setErrorKubunList(List<MCd> errorKubunList) {
        this.errorKubunList = errorKubunList;
    }

    /**
     * selectGcCode 取得
     * @return selectGcCode
     */
    public String getSelectGcCode() {
        return selectGcCode;
    }

    /**
     * @param selectGcCode 設定 selectGcCode
     */
    public void setSelectGcCode(String selectGcCode) {
        this.selectGcCode = selectGcCode;
    }

    /**
     * searchResultList 取得
     * @return searchResultList
     */
    public List<SZWE0100IchiranDto> getSearchResultList() {
        return searchResultList;
    }

    /**
     * @param searchResultList 設定 searchResultList
     */
    public void setSearchResultList(List<SZWE0100IchiranDto> searchResultList) {
        this.searchResultList = searchResultList;
    }

    /**
     * serviceKubun 取得
     * @return serviceKubun
     */
    public String getServiceKubun() {
        return serviceKubun;
    }

    /**
     * @param serviceKubun 設定 serviceKubun
     */
    public void setServiceKubun(String serviceKubun) {
        this.serviceKubun = serviceKubun;
    }

    /**
     * serviceKubunList 取得
     * @return serviceKubunList
     */
    public List<MKeiyakuCtlDev> getServiceKubunList() {
        return serviceKubunList;
    }

    /**
     * @param serviceKubunList 設定 serviceKubunList
     */
    public void setServiceKubunList(List<MKeiyakuCtlDev> serviceKubunList) {
        this.serviceKubunList = serviceKubunList;
    }

}