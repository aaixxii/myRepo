//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0000Form.java
//
// 【機　能　名】SZWE0000_エラー表示ＣＬメイン画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.form;

import java.util.List;

import jp.co.alsok.g6.zwe.dto.SZWE0000IchiranDto;
import jp.co.alsok.g6.zwe.entity.g6.MCd;
import jp.co.alsok.g6.zwe.web.form.common.BaseForm;

/**
 * SZWE0000フォームのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
public class SZWE0000Form extends BaseForm {

    /**
     * エラー区分.
     */
    private String errorKubun;

    /**
     * エラー区分コンボボックス内容.
     */
    private List<MCd> errorKubunList;

    /**
     * GCコード.
     */
    private String selectGcCode;

    /**
     * エリアコード.
     */
    private String selectAreaCode;

    /**
     * 一覧.
     */
    private List<SZWE0000IchiranDto> searchResultList;

    /**
     * エラー更新間隔(秒).
     */
    private String tegetTimer;

    /**
     * ブザー鳴動.
     */
    private String buzzStatus;
    
    /**
     * 新データがあるフラグ.
     */
    private String newDataFlg;
    
    /**
     * searchResultList 取得
     * @return searchResultList
     */
    public List<SZWE0000IchiranDto> getSearchResultList() {
        return searchResultList;
    }

    /**
     * @param searchResultList 設定 searchResultList
     */
    public void setSearchResultList(List<SZWE0000IchiranDto> searchResultList) {
        this.searchResultList = searchResultList;
    }

    /**
     * errorKubunList 取得
     * @return errorKubunList
     */
    public List<MCd> getErrorKubunList() {
        return errorKubunList;
    }

    /**
     * @param errorKubunList 設定 errorKubunList
     */
    public void setErrorKubunList(List<MCd> errorKubunList) {
        this.errorKubunList = errorKubunList;
    }

    /**
     * errorKubun 取得
     * @return errorKubun
     */
    public String getErrorKubun() {
        return errorKubun;
    }

    /**
     * @param errorKubun 設定 errorKubun
     */
    public void setErrorKubun(String errorKubun) {
        this.errorKubun = errorKubun;
    }

    /**
     * selectGcCode 取得
     * @return selectGcCode
     */
    public String getSelectGcCode() {
        return selectGcCode;
    }

    /**
     * @param selectGcCode 設定 selectGcCode
     */
    public void setSelectGcCode(String selectGcCode) {
        this.selectGcCode = selectGcCode;
    }

    /**
     * tegetTimer 取得
     * @return tegetTimer
     */
    public String getTegetTimer() {
        return tegetTimer;
    }

    /**
     * @param tegetTimer 設定 tegetTimer
     */
    public void setTegetTimer(String tegetTimer) {
        this.tegetTimer = tegetTimer;
    }

    /**
     * selectAreaCode 取得
     * @return selectAreaCode
     */
    public String getSelectAreaCode() {
        return selectAreaCode;
    }

    /**
     * @param selectAreaCode 設定 selectAreaCode
     */
    public void setSelectAreaCode(String selectAreaCode) {
        this.selectAreaCode = selectAreaCode;
    }

    /**
     * ブザー鳴動を取得します.
     *
     * @return ブザー鳴動
     */
	public String getBuzzStatus() {
		return buzzStatus;
	}

    /**
     * ブザー鳴動を設定します.
     *
     * @param buzzStatus
     *            ブザー鳴動
     */
	public void setBuzzStatus(String buzzStatus) {
		this.buzzStatus = buzzStatus;
	}

    /**
     * 新データがあるフラグを取得します.
     */
	public String getNewDataFlg() {
		return newDataFlg;
	}

    /**
     * 新データがあるフラグを設定します.
     */
	public void setNewDataFlg(String newDataFlg) {
		this.newDataFlg = newDataFlg;
	}
}
