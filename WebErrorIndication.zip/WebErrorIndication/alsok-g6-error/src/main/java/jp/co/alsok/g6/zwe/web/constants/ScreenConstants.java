//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】ScreenConstants.java
//
// 【機　能　名】エラー表示サイト画面マッピングパス管理用クラス
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.constants;

/**
 *
 * エラー表示サイト画面マッピングパス管理用のクラス.<br>
 *
 */
public class ScreenConstants {

    /** エラー表示ＣＬメイン */
    public static final String SZWE0000 = "/SZWE0000";

    /** エラー表示ＣＬ検索画面 */
    public static final String SZWE0100 = "/SZWE0100";

    /** エラー表示ＣＬ詳細画面 */
    public static final String SZWE0200 = "/SZWE0200";

    public static final String SZWE0300 = "/SZWE0300";

}
