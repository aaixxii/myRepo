package jp.co.alsok.g6.zwe.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * MyBatis設定。<br>
 * 複数データソース対応。
 *
 * @author APL
 */
@Configuration
public class MyBatisConfig {

    @Autowired
    private DataSourceConfig dataSourceConfig;

    @Configuration
    @MapperScan(basePackages = {"jp.co.alsok.g6.zwe.dao.mapper.g6",
                                "jp.co.alsok.g6.zwe.dao.entitymapper.g6",
                                "jp.co.alsok.g6.common.web.dao.mapper.g6"}, sqlSessionFactoryRef = "sqlSessionFactory1")
    public class Db1Config {

        @Bean
        @Primary
        public SqlSessionFactory sqlSessionFactory1() throws Exception {
            return sqlSessionFactory(dataSourceConfig.dataSource1());
        }
    }

//    @Configuration
//    @MapperScan(basePackages = {"jp.co.alsok.g6.zwe.dao.mapper.ghs",
//                                "jp.co.alsok.g6.common.web.dao.mapper.ghs"}, sqlSessionFactoryRef = "sqlSessionFactory2")
//    public class Db2Config {
//
//        @Bean
//        public SqlSessionFactory sqlSessionFactory2() throws Exception {
//            return sqlSessionFactory(dataSourceConfig.dataSource2());
//        }
//    }

//    @Configuration
//    @MapperScan(basePackages = {"jp.co.alsok.g6.common.web.dao.mapper.g5"})
//    public class DummyConfig {
//    	// 共通部品で次期、GHS、G5を参照する部品があるためダミーで接続しないDBへのMapperScanを登録する必要がある。
//    }


    public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
        final SqlSessionFactoryBean factory = new SqlSessionFactoryBean();
        factory.setDataSource(dataSource);

        return (SqlSessionFactory)factory.getObject();
    }
}
