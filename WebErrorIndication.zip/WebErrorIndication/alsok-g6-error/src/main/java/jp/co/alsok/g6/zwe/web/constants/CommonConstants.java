//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】CommonConstants.java
//
// 【機　能　名】共通定数管理用クラス
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/01
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.constants;

public class CommonConstants {


    //--------------------------------------------------------------
    // 汎用文字列
    //--------------------------------------------------------------
    public static final String SLASH = "/";
    public static final String COLON = ":";
    public static final String REDIRECT = "redirect";
    public static final String VALID_ERR = "validationError";
    public static final String LOGOUT = "logout";

    //--------------------------------------------------------------
    // 共通
    //--------------------------------------------------------------
    // ログイン画面
    public static final String SZWO0000 = "/SZWO0000";
    // メニュー画面
    public static final String SZWO0100 = "/SZWO0100";
    // エラー画面
    public static final String SZWO9999 = "SZWO9999";

    //--------------------------------------------------------------
    // 契約先検索
    //--------------------------------------------------------------
    public static final String SZWO9500 = "/contractors/SZWO9500";
    public static final String SZWO2900 = "/contractors/SZWO2900";
    public static final String SZWO1900 = "/contractors/SZWO1900";

    //--------------------------------------------------------------
    // 警備先関連設定
    //--------------------------------------------------------------
    public static final String SZWO1700 = "/securitylocationinfo/SZWO1700";
    public static final String SZWO2600 = "/securitylocationinfo/SZWO2600";
    public static final String SZWOB200 = "/securitylocationinfo/SZWOB200";
    public static final String SZWO0300 = "/securitylocationinfo/SZWO0300";
    public static final String SZWO0400 = "/securitylocationinfo/SZWO0400";
    public static final String SZWO0500 = "/securitylocationinfo/SZWO0500";
    public static final String SZWO0700 = "/securitylocationinfo/SZWO0700";
    public static final String SZWO1400 = "/securitylocationinfo/SZWO1400";
    public static final String SZWO1500 = "/securitylocationinfo/SZWO1500";
    public static final String SZWO1600 = "/securitylocationinfo/SZWO1600";
    public static final String SZWO4800 = "/securitylocationinfo/SZWO4800";
    public static final String SZWO2610 = "/securitylocationinfo/SZWO2610";
    public static final String SZWOB300 = "/securitylocationinfo/SZWOB300";
    public static final String SZWOF300 = "/securitylocationinfo/SZWOF300";
    public static final String SZWO0200 = "/securitylocationinfo/SZWO0200";
    public static final String SZWO0800 = "/securitylocationinfo/SZWO0800";
    public static final String SZWO1100 = "/securitylocationinfo/SZWO1100";
    public static final String SZWO1300 = "/securitylocationinfo/SZWO1300";
    public static final String SZWOC000 = "/securitylocationinfo/SZWOC000";
    public static final String SZWO3700 = "/securitylocationinfo/SZWO3700";
    public static final String SZWO4000 = "/securitylocationinfo/SZWO4000";
    public static final String SZWO8800 = "/securitylocationinfo/SZWO8800";
    public static final String SZWO9B00 = "/securitylocationinfo/SZWO9B00";

    //--------------------------------------------------------------
    // 営業連携一覧
    //--------------------------------------------------------------
    public static final String SZWO4900 = "/businesscollaboration/SZWO4900";
    public static final String SZWO5100 = "/businesscollaboration/SZWO5100";

    //--------------------------------------------------------------
    // アカウント関連設定
    //--------------------------------------------------------------
    public static final String SZWO9000 = "/account/SZWO9000";
    public static final String SZWO9800 = "/account/SZWO9800";
    public static final String SZWOB500 = "/account/SZWOB500";
    public static final String SZWOB600 = "/account/SZWOB600";
    public static final String SZWOB700 = "/account/SZWOB700";

    //--------------------------------------------------------------
    // 画像関連設定
    //--------------------------------------------------------------
    public static final String SZWO2000 = "/imagesettings/SZWO2000";
    public static final String SZWO2400 = "/imagesettings/SZWO2400";
    public static final String SZWO7910 = "/imagesettings/SZWO7910";
    public static final String SZWOD200 = "/imagesettings/SZWOD200";
    public static final String SZWOD400 = "/imagesettings/SZWOD400";
    public static final String SZWOD700 = "/imagesettings/SZWOD700";
    public static final String SZWO8000 = "/imagesettings/SZWO8000";
    public static final String SZWOB900 = "/imagesettings/SZWOB900";
    public static final String SZWOE000 = "/imagesettings/SZWOE000";
    public static final String SZWO3800 = "/imagesettings/SZWO3800";
    public static final String SZWO8100 = "/imagesettings/SZWO8100";
    public static final String SZWO8300 = "/imagesettings/SZWO8300";
    public static final String SZWO8400 = "/imagesettings/SZWO8400";
    public static final String SZWO8500 = "/imagesettings/SZWO8500";
    public static final String SZWOB800 = "/imagesettings/SZWOB800";
    public static final String SZWO8900 = "/imagesettings/SZWO8900";

    //--------------------------------------------------------------
    // ユーティリティ
    //--------------------------------------------------------------

    public static final String SZWO6400 = "/usefulfunction/SZWO6400";
    public static final String SZWOB000 = "/usefulfunction/SZWOB000";

    //--------------------------------------------------------------
    // お知らせ作成
    //--------------------------------------------------------------

    public static final String SZWO6710 = "/announcement/SZWO6710";

    //--------------------------------------------------------------
    //機器状態確認
    //--------------------------------------------------------------
    public static final String SZWO2500 = "/devicestatus/SZWO2500";

    //--------------------------------------------------------------
    //機器状態確認
    //--------------------------------------------------------------

    public static final String SZWOA900 = "/codemaintenance/SZWOA900";
    public static final String SZWO6000 = "/codemaintenance/SZWO6000";
    public static final String SZWE0300 = "SZWE0300";
}
