//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0300FormValidator.java
//
// 【機　能　名】SZWE0300_担当ＧＣ選択画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/08/14
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import jp.co.alsok.g6.zwe.web.form.SZWE0300Form;

/**
 * SZWE0300フォームバリデーターのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/08/14 新規作成<br>
 */
@Component
public class SZWE0300FormValidator implements Validator {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean supports(final Class<?> clazz) {
		SZWE0300Form.class.isAssignableFrom(clazz);
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void validate(final Object target, final Errors errors) {}
}
