//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0000Service.java
//
// 【機　能　名】SZWE0000_エラー表示ＣＬメイン画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.alsok.g6.zwe.dao.mapper.g6.G6SZWE0000Mapper;
import jp.co.alsok.g6.zwe.dto.SZWE0000IchiranDto;
import jp.co.alsok.g6.zwe.entity.g6.MCd;

/**
 * SZWE0000サービスのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
@Service
public class SZWE0000Service {

	/**
	 * エラー表示ＣＬメイン一覧画面用Mapper.
	 */
	@Autowired
	private G6SZWE0000Mapper g6SZWE0000Mapper;

	/**
	 * エラー表示ＣＬメイン一覧内容取得.
	 *
	 * @param inDto 検索条件
	 * @return 一覧内容<br>
	 */
	public List<SZWE0000IchiranDto> selectErrorList(final SZWE0000IchiranDto inDto) {
		return g6SZWE0000Mapper.selectErrorList(inDto);
	}

	/**
	 * エラー表示ＣＬメイン一覧件数取得.
	 *
	 * @param inDto 検索条件
	 * @return 一覧内容<br>
	 */
	public int selectErrorListCount(final SZWE0000IchiranDto inDto) {
		return g6SZWE0000Mapper.selectErrorListCount(inDto);
	}

	/**
	 * エラー区分コンボボックス内容取得.
	 *
	 * @param inDto 検索条件
	 * @return コンボボックス内容<br>
	 */
	public List<MCd> selectErrorKubunList(final MCd inDto) {
		return g6SZWE0000Mapper.selectErrorKubun(inDto);

	}
}
