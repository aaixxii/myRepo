package jp.co.alsok.g6.zwe.web.util;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;

import jp.co.alsok.g6.zwe.web.session.SessionBean;

@Component
public class SessionUtils {

    /** セッション情報を管理するBeanクラス */
    @Autowired
    private SessionBean sessionBean;

    /**  */

    /**
     * セッション情報の設定
     *
     * @param str キー情報
     * @param obj キーに紐付く値
     */
    public void putSessionValue(@NonNull String key, Object value) {

        Map<String, Object> map = sessionBean.getSessionMap();
        map.put(key, value);
        sessionBean.setSessionMap(map);
    }

    /**
     * 設定したセッション情報の取得
     *
     * @param str キー情報
     * @return キーに紐付く情報
     */
    @SuppressWarnings("unchecked")
    public <T> T getSessionValue(@NonNull String key) {

        return (T)sessionBean.getSessionMap().get(key);
    }
}
