package jp.co.alsok.g6.zwe.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jp.co.alsok.g6.zwe.web.form.common.BaseForm;

@Controller
@RequestMapping("/modalKyoutuDialog")
public class ModalKyoutuDialogController {
    @RequestMapping("/")
    public ModelAndView index() {
        ModelAndView view = new ModelAndView();
        BaseForm form = new BaseForm();

        view.setViewName("common/modalKyoutuDialog.html");
        view.addObject("BaseForm",form);
        return view;
    }

}
