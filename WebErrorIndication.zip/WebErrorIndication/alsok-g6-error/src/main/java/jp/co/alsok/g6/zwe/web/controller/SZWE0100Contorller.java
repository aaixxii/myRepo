//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0100Contorller.java
//
// 【機　能　名】SZWE0100_エラー表示ＣＬ検索画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jp.co.alsok.g6.common.util.DateUtility;
import jp.co.alsok.g6.common.util.string.StringUtil;
import jp.co.alsok.g6.zwe.config.PropertySourceConfig;
import jp.co.alsok.g6.zwe.dto.SZWE0100IchiranDto;
import jp.co.alsok.g6.zwe.entity.g6.MCd;
import jp.co.alsok.g6.zwe.entity.g6.MKeiyakuCtlDev;
import jp.co.alsok.g6.zwe.service.SZWE0100Service;
import jp.co.alsok.g6.zwe.web.constants.ScreenConstants;
import jp.co.alsok.g6.zwe.web.form.SZWE0100Form;
import jp.co.alsok.g6.zwe.web.validator.SZWE0100FormValidator;

/**
 * SZWE0100コントローラーのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
@Controller
@RequestMapping(ScreenConstants.SZWE0100)
public class SZWE0100Contorller extends AbstractBaseContorller {

	/**
	 * エラー表示ＣＬ検索画面画面サービス.
	 */
	@Autowired
	private SZWE0100Service sZWE0100Service;

	/**
	 * エラー表示ＣＬ検索画面用バリデータクラス.
	 */
	@Autowired
	private SZWE0100FormValidator validator;

	/**
	 * プロパティファイル管理サービス.
	 */
	@Autowired
	private PropertySourceConfig propertySourceConfig;

	/**
	 * フォーム名称.
	 */
	private static final String FORM_NAME = "SZWE0100Form";

	/**
	 * エラーメッセージ.
	 */
	private static final String MESSAGE_ID_MZWE204E = "MZWE204E";

	/**
	 * エラーメッセージ.
	 */
	private static final String MESSAGE_ID_MZWE205I = "MZWE205I";

	/**
	 * 時OR分のディフォルト値.
	 */
	private static final String TIME_DEFAULT = "00";

	/**
	 * 時のディフォルト値.
	 */
	private static final String TIME_DEFAULT_HOURE_EN = "23";

	/**
	 * 分のディフォルト値.
	 */
	private static final String TIME_DEFAULT_MINUTE_END = "59";

	/**
	 * エラー区分検索キー.
	 */
	private static final String CD_ID_CD085 = "CD085";

	/**
	 * SPACEのCONST.
	 */
	private static final String CONSTSPACE = " ";

	/**
	 * COLONのCONST.
	 */
	private static final String CONSTCOLON = ":";

	/**
	 * COMMAのCONST.
	 */
	private static final String CONSTCOMMA = ",";

	/**
	 * COMMAのCONST.
	 */
	private static final String CONSTDIAGONAL = "/";

	/**
	 * バインダーを初期化し、エラー表示ＣＬ検索画面用バリデータを設定
	 *
	 * @param binder バインダー
	 */
	@InitBinder
	public void init(WebDataBinder binder) {
		binder.addValidators(validator);
	}

	/**
	 * 初期処理.
	 *
	 * @param form フォーム
	 * @param result バリデータの結果情報
	 * @param request リクエスト
	 *
	 * @return モデル<br>
	 */
	@RequestMapping("/")
	public ModelAndView index(@ModelAttribute SZWE0100Form form,
			BindingResult result,
			HttpServletRequest request) {

		// 画面のリクエスト情報を保持するModelAndViewを作成
		ModelAndView view = new ModelAndView();

		// 画面情報を設定する
		view.addObject(FORM_NAME, form);

		// 画面名を設定
		view.setViewName(ScreenConstants.SZWE0100);

		// 通知エラー区分プルダウン設定
		selectErrorKubun(form);

		// 前画面から渡したエラー区分の値を画面に移送する
		String strErrorKubun = (String) sessionUtils
				.getSessionValue("SZWE0000FromErrorKubunValue");
		form.setErrorKubun(strErrorKubun);

		// 前画面から渡したGCの値をを画面に移送する
		String strSelectGcCode = request.getParameter("selectGcCode");
		form.setSelectGcCode(strSelectGcCode);

		// サービス区分設定
		selectServiceKubun(form);

		// フォームに検索時刻設定
		setSearchDateTime(form);

		// カウントを取得する
		selectCount(form, result);

		// バリデータでエラーの場合
		if (result.hasErrors()) {

			for (ObjectError obj : result.getAllErrors()) {

				// 最大行数超える場合
				if (MESSAGE_ID_MZWE205I.equals(obj.getCode())) {

					// 検索処理を行う
					searchProcess(form);
				}

			}
			return view;
		}

		// 一覧内容検索
		searchProcess(form);

		// ブラウザにHTMLを送信する
		return view;
	}

	/**
	 * 検索押下処理.
	 *
	 * @param form フォーム
	 * @param result バリデータの結果情報
	 *
	 * @return モデル
	 */
	@RequestMapping("/search")
	public ModelAndView search(@Validated @ModelAttribute SZWE0100Form form,
			BindingResult result) {

		// 画面のリクエスト情報を保持するModelAndViewを作成
		ModelAndView view = new ModelAndView();

		// 画面情報を設定する
		view.addObject(FORM_NAME, form);

		// 画面名を設定
		view.setViewName(ScreenConstants.SZWE0100);

		// 通知エラー区分プルダウン設定
		selectErrorKubun(form);

		// サービス区分設定
		selectServiceKubun(form);

		// フォームに検索時刻設定
		setSearchDateTime(form);

		// バリデータでエラーの場合
		if (result.hasErrors()) {
			return view;
		}

		// カウントを取得する
		selectCount(form, result);

		// バリデータでエラーの場合
		if (result.hasErrors()) {

			for (ObjectError obj : result.getAllErrors()) {

				// 最大行数超える場合
				if (MESSAGE_ID_MZWE205I.equals(obj.getCode())) {

					// 検索処理を行う
					searchProcess(form);
				}

			}
			return view;
		}

		// 検索処理を行う
		searchProcess(form);

		// ブラウザにHTMLを送信する
		return view;
	}

	/**
	 *
	 * エラー区分検索処理.
	 *
	 * @param form フォーム<br>
	 *
	 */
	private void selectErrorKubun(SZWE0100Form form) {

		// 検索条件を設定する
		MCd inDto = new MCd();
		inDto.setCdId(CD_ID_CD085);

		List<MCd> errorKubunList = sZWE0100Service
				.selectErrorKubunList(inDto);
		form.setErrorKubunList(errorKubunList);

	}

	/**
	 *
	 * サービス区分検索処理.
	 *
	 * @param form フォーム<br>
	 *
	 */
	private void selectServiceKubun(SZWE0100Form form) {

		List<MKeiyakuCtlDev> serviceKubun = sZWE0100Service
				.selectServiceKubunList();

		// 先頭に”すべで”を設定
		List<MKeiyakuCtlDev> allServiceKubun = new ArrayList<MKeiyakuCtlDev>();

		MKeiyakuCtlDev mKeiyakuCtlDev = new MKeiyakuCtlDev();

		mKeiyakuCtlDev.setKeiyakuKind2Cd("");
		mKeiyakuCtlDev.setKeiyakuKind2Nm("すべて");
		allServiceKubun.add(mKeiyakuCtlDev);
		allServiceKubun.addAll(serviceKubun);

		form.setServiceKubunList(allServiceKubun);

	}

	/**
	 *
	 * 明細検索処理.
	 *
	 * @param form フォーム<br>
	 *
	 */
	private void searchProcess(SZWE0100Form form) {

		// エラー履歴一覧を取得する
		SZWE0100IchiranDto inDto = new SZWE0100IchiranDto();

		// エラーレベル
		inDto.setErrLvl(form.getErrorKubun());

		// 契約種別２（CD）
		inDto.setKeiyakuKind2Cd(form.getServiceKubun());

		// GC番号
		if (!StringUtil.isNullOrEmpty(form.getSelectGcCode())) {
			inDto.setSelectedGcNum(form.getSelectGcCode().split(CONSTCOMMA));
		}

		// 発信日時設定(FROM)
		if (!StringUtil.isNullOrEmpty(form.getFromHasseiDate())) {

			String strFromHasseiDateTime = form.getFromHasseiDate();

			// 時の設定
			if (!StringUtil.isNullOrEmpty(form.getFromHasseiDateHour())) {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTSPACE)
						.concat(String.format("%02d", Integer.parseInt(form.getFromHasseiDateHour())));
			} else {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTSPACE)
						.concat(TIME_DEFAULT);
			}

			// 秒の設定
			if (!StringUtil.isNullOrEmpty(form.getFromHasseiDateMinute())) {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTCOLON)
						.concat(String.format("%02d", Integer.parseInt(form.getFromHasseiDateMinute())));
			} else {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTCOLON)
						.concat(TIME_DEFAULT);
			}

			inDto.setHasseiTsFrom(strFromHasseiDateTime);
		}

		// 発信日時設定(TO)
		if (!StringUtil.isNullOrEmpty(form.getToHasseiDate())) {

			String strToHasseiDateTime = form.getToHasseiDate();

			// 時の設定
			if (!StringUtil.isNullOrEmpty(form.getToHasseiDateHour())) {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTSPACE)
						.concat(String.format("%02d", Integer.parseInt(form.getToHasseiDateHour())));
			} else {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTSPACE)
						.concat(TIME_DEFAULT_HOURE_EN);
			}

			// 秒の設定
			if (!StringUtil.isNullOrEmpty(form.getToHasseiDateMinute())) {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTCOLON)
						.concat(String.format("%02d", Integer.parseInt(form.getToHasseiDateMinute())));
			} else {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTCOLON)
						.concat(TIME_DEFAULT_MINUTE_END);
			}

			inDto.setHasseiTsTo(strToHasseiDateTime);
		}

		// 最大件数設定
		inDto.setLimit(propertySourceConfig.get("SearchMaxNum"));

		// エラー区分名称検索キー
		inDto.setCdId(CD_ID_CD085);

		// 一覧内容検索を行う
		List<SZWE0100IchiranDto> searchResultList = sZWE0100Service
				.selectErrorList(inDto);

		form.setSearchResultList(searchResultList);

	}

	/**
	 *
	 * 設定検索タイム処理.
	 *
	 * @param form フォーム<br>
	 *
	 */
	private void setSearchDateTime(SZWE0100Form form) {

		// 検索時間の設定
		Calendar calendar = Calendar.getInstance();

		String strYear = DateUtility.getYearFromCalendar(calendar);
		String strMonth = DateUtility.getMonthFromCalendar(calendar);
		String strDay = DateUtility.getDayFromCalendar(calendar);
		String strHour = DateUtility.getHourFromCalendar(calendar);
		String strMinute = DateUtility.getMinuteFromCalendar(calendar);

		// 画面に設定する
		form.setSearchDate(strYear + CONSTDIAGONAL + strMonth + CONSTDIAGONAL + strDay);
		form.setSearchDateHour(strHour);
		form.setSearchDateMinute(strMinute);
	}

	/**
	 *
	 * 件数取得処理.
	 *
	 * @param form フォーム
	 * @param result バリデータの結果情報<br>
	 *
	 */
	private void selectCount(SZWE0100Form form, BindingResult result) {

		// エラー履歴一覧を取得する
		SZWE0100IchiranDto inDto = new SZWE0100IchiranDto();

		// エラーレベル
		inDto.setErrLvl(form.getErrorKubun());

		// 契約種別２（CD）
		inDto.setKeiyakuKind2Cd(form.getServiceKubun());

		// GC番号
		if (!StringUtil.isNullOrEmpty(form.getSelectGcCode())) {
			inDto.setSelectedGcNum(form.getSelectGcCode().split(CONSTCOMMA));
		}

		// 発信日時設定(FROM)
		if (!StringUtil.isNullOrEmpty(form.getFromHasseiDate())) {

			String strFromHasseiDateTime = form.getFromHasseiDate();

			// 時の設定
			if (!StringUtil.isNullOrEmpty(form.getFromHasseiDateHour())) {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTSPACE)
						.concat(form.getFromHasseiDateHour());
			} else {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTSPACE)
						.concat(TIME_DEFAULT);
			}

			// 秒の設定
			if (!StringUtil.isNullOrEmpty(form.getFromHasseiDateMinute())) {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTCOLON)
						.concat(form.getFromHasseiDateMinute());
			} else {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTCOLON)
						.concat(TIME_DEFAULT);
			}

			inDto.setHasseiTsFrom(strFromHasseiDateTime);
		}

		// 発信日時設定(TO)
		if (!StringUtil.isNullOrEmpty(form.getToHasseiDate())) {

			String strToHasseiDateTime = form.getToHasseiDate();

			// 時の設定
			if (!StringUtil.isNullOrEmpty(form.getToHasseiDateHour())) {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTSPACE)
						.concat(form.getToHasseiDateHour());
			} else {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTSPACE)
						.concat(TIME_DEFAULT_HOURE_EN);
			}

			// 秒の設定
			if (!StringUtil.isNullOrEmpty(form.getToHasseiDateMinute())) {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTCOLON)
						.concat(form.getToHasseiDateMinute());
			} else {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTCOLON)
						.concat(TIME_DEFAULT_MINUTE_END);
			}

			inDto.setHasseiTsTo(strToHasseiDateTime);
		}

		// エラー区分名称取得キー
		inDto.setCdId(CD_ID_CD085);

		// 一覧件数検索を行う
		int searchResultCount = sZWE0100Service.selectErrorListCount(inDto);

		// データ存在しない場合
		if (searchResultCount == 0) {
			// メッセージキー：MZWE204E
			result.reject(MESSAGE_ID_MZWE204E);

		} else {

			// プロパティファイルから最大件数取得
			int iMaxNum = Integer
					.valueOf(propertySourceConfig.get("SearchMaxNum"));

			// 検索結果（エラー履歴）が最大表示件数以上の場合
			if (searchResultCount > iMaxNum) {
				result.reject(MESSAGE_ID_MZWE205I);
			}
		}

	}
}