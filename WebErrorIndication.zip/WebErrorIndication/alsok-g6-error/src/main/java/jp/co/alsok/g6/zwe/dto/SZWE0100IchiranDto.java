//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0100IchiranDto.java
//
// 【機　能　名】SZWE0100_エラー表示ＣＬ検索画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.dto;

import java.sql.Date;

/**
 * SZWE0100_データ保持用DTOのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
public class SZWE0100IchiranDto {

	/**
	 * サービス区分.
	 */
	private String serviceKunbun;

	/**
	 * 発生日時FROM.
	 */
	private String hasseiTsFrom;

	/**
	 * 発生日時TO.
	 */
	private String hasseiTsTo;

	/**
	 * 契約種別 CD２.
	 */
	private String keiyakuKind2Cd;

	/**
	 * LN_エラー情報履歴論理番号.
	 */
	private String lnErrInf;

	/**
	 * 発生時刻.
	 */
	private String hasseiTs;

	/**
	 * 処理ID.
	 */
	private String syoriId;

	/**
	 * 号機番号.
	 */
	private String gouki;

	/**
	 * 地区番号.
	 */
	private String chikuNum;

	/**
	 * 装置番号.
	 */
	private String devNum;

	/**
	 * 受信日時.
	 */
	private String rcvTs;

	/**
	 * GC番号.
	 */
	private String gcNum;

	/**
	 * GC名.
	 */
	private String gcNm;

	/**
	 * 電計番号.
	 */
	private String denkei;

	/**
	 * ホスト名.
	 */
	private String hostNm;

	/**
	 * エラーレベル.
	 */
	private String errLvl;

	/**
	 * エラー名称.
	 */
	private String errNm;

	/**
	 * エラー.
	 */
	private String errId;

	/**
	 * コード値.
	 */
	private String cdId;

	/**
	 * 対処名称.
	 */
	private String recoverMsgNm;

	/**
	 * 備考.
	 */
	private String bikou;

	/**
	 * 最大件数.
	 */
	private String limit;

	/**
	 * 選択したGC番号.
	 */
	private String[] selectedGcNum;

	/**
	 * 実施GC番号.
	 */
	private String jissiGcNum;

	/**
	 * エラーレベル.
	 */
	private String errLvlCd;

	/**
	 * 登録者ID.
	 */
	private String insertId;

	/**
	 * 登録者名.
	 */
	private String insertNm;

	/**
	 * 登録日時.
	 */
	private Date insertTs;

	/**
	 * 更新者ID.
	 */
	private String updateId;

	/**
	 * 更新者名.
	 */
	private String updateNm;

	/**
	 * 更新日時.
	 */
	private Date updateTs;

	/**
	 * hasseiTsFrom 取得
	 * @return hasseiTsFrom
	 */
	public String getHasseiTsFrom() {
		return hasseiTsFrom;
	}

	/**
	 * @param hasseiTsFrom 設定 hasseiTsFrom
	 */
	public void setHasseiTsFrom(String hasseiTsFrom) {
		this.hasseiTsFrom = hasseiTsFrom;
	}

	/**
	 * hasseiTsTo 取得
	 * @return hasseiTsTo
	 */
	public String getHasseiTsTo() {
		return hasseiTsTo;
	}

	/**
	 * @param hasseiTsTo 設定 hasseiTsTo
	 */
	public void setHasseiTsTo(String hasseiTsTo) {
		this.hasseiTsTo = hasseiTsTo;
	}

	/**
	 * lnErrInf 取得
	 * @return lnErrInf
	 */
	public String getLnErrInf() {
		return lnErrInf;
	}

	/**
	 * @param lnErrInf 設定 lnErrInf
	 */
	public void setLnErrInf(String lnErrInf) {
		this.lnErrInf = lnErrInf;
	}

	/**
	 * hasseiTs 取得
	 * @return hasseiTs
	 */
	public String getHasseiTs() {
		return hasseiTs;
	}

	/**
	 * @param hasseiTs 設定 hasseiTs
	 */
	public void setHasseiTs(String hasseiTs) {
		this.hasseiTs = hasseiTs;
	}

	/**
	 * syoriId 取得
	 * @return syoriId
	 */
	public String getSyoriId() {
		return syoriId;
	}

	/**
	 * @param syoriId 設定 syoriId
	 */
	public void setSyoriId(String syoriId) {
		this.syoriId = syoriId;
	}

	/**
	 * chikuNum 取得
	 * @return chikuNum
	 */
	public String getChikuNum() {
		return chikuNum;
	}

	/**
	 * @param chikuNum 設定 chikuNum
	 */
	public void setChikuNum(String chikuNum) {
		this.chikuNum = chikuNum;
	}

	/**
	 * devNum 取得
	 * @return devNum
	 */
	public String getDevNum() {
		return devNum;
	}

	/**
	 * @param devNum 設定 devNum
	 */
	public void setDevNum(String devNum) {
		this.devNum = devNum;
	}

	/**
	 * rcvTs 取得
	 * @return rcvTs
	 */
	public String getRcvTs() {
		return rcvTs;
	}

	/**
	 * @param rcvTs 設定 rcvTs
	 */
	public void setRcvTs(String rcvTs) {
		this.rcvTs = rcvTs;
	}

	/**
	 * gcNum 取得
	 * @return gcNum
	 */
	public String getGcNum() {
		return gcNum;
	}

	/**
	 * @param gcNum 設定 gcNum
	 */
	public void setGcNum(String gcNum) {
		this.gcNum = gcNum;
	}

	/**
	 * gcNm 取得
	 * @return gcNm
	 */
	public String getGcNm() {
		return gcNm;
	}

	/**
	 * @param gcNm 設定 gcNm
	 */
	public void setGcNm(String gcNm) {
		this.gcNm = gcNm;
	}

	/**
	 * hostNm 取得
	 * @return hostNm
	 */
	public String getHostNm() {
		return hostNm;
	}

	/**
	 * @param hostNm 設定 hostNm
	 */
	public void setHostNm(String hostNm) {
		this.hostNm = hostNm;
	}

	/**
	 * errLvl 取得
	 * @return errLvl
	 */
	public String getErrLvl() {
		return errLvl;
	}

	/**
	 * @param errLvl 設定 errLvl
	 */
	public void setErrLvl(String errLvl) {
		this.errLvl = errLvl;
	}

	/**
	 * errNm 取得
	 * @return errNm
	 */
	public String getErrNm() {
		return errNm;
	}

	/**
	 * @param errNm 設定 errNm
	 */
	public void setErrNm(String errNm) {
		this.errNm = errNm;
	}

	/**
	 * errId 取得
	 * @return errId
	 */
	public String getErrId() {
		return errId;
	}

	/**
	 * @param errId 設定 errId
	 */
	public void setErrId(String errId) {
		this.errId = errId;
	}

	/**
	 * cdId 取得
	 * @return cdId
	 */
	public String getCdId() {
		return cdId;
	}

	/**
	 * @param cdId 設定 cdId
	 */
	public void setCdId(String cdId) {
		this.cdId = cdId;
	}

	/**
	 * recoverMsgNm 取得
	 * @return recoverMsgNm
	 */
	public String getRecoverMsgNm() {
		return recoverMsgNm;
	}

	/**
	 * @param recoverMsgNm 設定 recoverMsgNm
	 */
	public void setRecoverMsgNm(String recoverMsgNm) {
		this.recoverMsgNm = recoverMsgNm;
	}

	/**
	 * serviceKunbun 取得
	 * @return serviceKunbun
	 */
	public String getServiceKunbun() {
		return serviceKunbun;
	}

	/**
	 * @param serviceKunbun 設定 serviceKunbun
	 */
	public void setServiceKunbun(String serviceKunbun) {
		this.serviceKunbun = serviceKunbun;
	}

	/**
	 * keiyakuKind2Cd 取得
	 * @return keiyakuKind2Cd
	 */
	public String getKeiyakuKind2Cd() {
		return keiyakuKind2Cd;
	}

	/**
	 * @param keiyakuKind2Cd 設定 keiyakuKind2Cd
	 */
	public void setKeiyakuKind2Cd(String keiyakuKind2Cd) {
		this.keiyakuKind2Cd = keiyakuKind2Cd;
	}

	/**
	 * gouki 取得
	 * @return gouki
	 */
	public String getGouki() {
		return gouki;
	}

	/**
	 * @param gouki 設定 gouki
	 */
	public void setGouki(String gouki) {
		this.gouki = gouki;
	}

	/**
	 * denkei 取得
	 * @return denkei
	 */
	public String getDenkei() {
		return denkei;
	}

	/**
	 * @param denkei 設定 denkei
	 */
	public void setDenkei(String denkei) {
		this.denkei = denkei;
	}

	/**
	 * bikou 取得
	 * @return bikou
	 */
	public String getBikou() {
		return bikou;
	}

	/**
	 * @param bikou 設定 bikou
	 */
	public void setBikou(String bikou) {
		this.bikou = bikou;
	}

	/**
	 * limit 取得
	 * @return limit
	 */
	public String getLimit() {
		return limit;
	}

	/**
	 * @param limit 設定 limit
	 */
	public void setLimit(String limit) {
		this.limit = limit;
	}

	/**
	 * selectedGcNum 取得
	 * @return selectedGcNum
	 */
	public String[] getSelectedGcNum() {
		return selectedGcNum;
	}

	/**
	 * @param selectedGcNum 設定 selectedGcNum
	 */
	public void setSelectedGcNum(String[] selectedGcNum) {
		this.selectedGcNum = selectedGcNum;
	}

	/**
	* jissiGcNum 取得
	* @return jissiGcNum
	*/
	public String getJissiGcNum() {
		return jissiGcNum;
	}

	/**
	* @param jissiGcNum 設定 jissiGcNum
	*/
	public void setJissiGcNum(String jissiGcNum) {
		this.jissiGcNum = jissiGcNum;
	}

	/**
	* errLvlCd 取得
	* @return errLvlCd
	*/
	public String getErrLvlCd() {
		return errLvlCd;
	}

	/**
	* @param errLvlCd 設定 errLvlCd
	*/
	public void setErrLvlCd(String errLvlCd) {
		this.errLvlCd = errLvlCd;
	}

	/**
	* insertId 取得
	* @return insertId
	*/
	public String getInsertId() {
		return insertId;
	}

	/**
	* @param insertId 設定 insertId
	*/
	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	/**
	* insertNm 取得
	* @return insertNm
	*/
	public String getInsertNm() {
		return insertNm;
	}

	/**
	* @param insertNm 設定 insertNm
	*/
	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	/**
	* updateId 取得
	* @return updateId
	*/
	public String getUpdateId() {
		return updateId;
	}

	/**
	* @param updateId 設定 updateId
	*/
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	/**
	* updateNm 取得
	* @return updateNm
	*/
	public String getUpdateNm() {
		return updateNm;
	}

	/**
	* @param updateNm 設定 updateNm
	*/
	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	/**
	* insertTs 取得
	* @return insertTs
	*/
	public Date getInsertTs() {
		return insertTs;
	}

	/**
	* @param insertTs 設定 insertTs
	*/
	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	/**
	* updateTs 取得
	* @return updateTs
	*/
	public Date getUpdateTs() {
		return updateTs;
	}

	/**
	* @param updateTs 設定 updateTs
	*/
	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}
}
