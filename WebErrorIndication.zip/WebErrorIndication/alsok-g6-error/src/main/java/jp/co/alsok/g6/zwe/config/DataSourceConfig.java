package jp.co.alsok.g6.zwe.config;


import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * データソース設定。
 *
 * @author APL
 */
@Configuration
public class DataSourceConfig {

    /**
     * 一つ目のDBの設定。
     *
     * @return
     */
    @ConfigurationProperties(prefix = "spring.datasource.g6")
    @Bean
    @Primary
    public DataSourceProperties datasourceProperties1() {
        return new DataSourceProperties();
    }

    /**
     * 一つ目のデータソース。
     *
     * @return
     */
    @Primary
    public DataSource dataSource1() {
        return datasourceProperties1().initializeDataSourceBuilder().build();
    }

//    /**
//     * 二つ目のDBの設定。
//     *
//     * @return
//     */
//    @ConfigurationProperties(prefix = "spring.datasource.ghs")
//    @Bean
//    public DataSourceProperties datasourceProperties2() {
//        return new DataSourceProperties();
//    }
//
//    /***
//     * 二つ目のデータソース。
//     *
//     * @return
//     */
//    @Bean(name = {"ghs"})
//    public DataSource dataSource2() {
//        return datasourceProperties2().initializeDataSourceBuilder().build();
//    }

//	/**
//	 * 三つ目のDBの設定。
//	 *
//	 * @return
//	 */
//	@ConfigurationProperties(prefix = "spring.datasource.db3")
//	@Bean
//	public DataSourceProperties datasourceProperties3() {
//		return new DataSourceProperties();
//	}
//
//	/***
//	 * 二つ目のデータソース。
//	 *
//	 * @return
//	 */
//	@Bean
//	public DataSource dataSource3() {
//		return datasourceProperties3().initializeDataSourceBuilder().build();
//	}

    // @Bean
    // public DataSourceInitializer dataSource1Initializer() {
    // DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
    // dataSourceInitializer.setDataSource(dataSource1());
    // ResourceDatabasePopulator databasePopulator = new
    // ResourceDatabasePopulator();
    // Optional.ofNullable(dataSource1().getSchema()).map(schema ->
    // context.getResource(schema))
    // .ifPresent(resource -> databasePopulator.addScript(resource));
    // Optional.ofNullable(dataSource1().getData()).map(data ->
    // context.getResource(data))
    // .ifPresent(resource -> databasePopulator.addScript(resource));
    //
    // dataSourceInitializer.setDatabasePopulator(databasePopulator);
    // dataSourceInitializer.setEnabled(true);
    //
    // return dataSourceInitializer;
    // }
}
