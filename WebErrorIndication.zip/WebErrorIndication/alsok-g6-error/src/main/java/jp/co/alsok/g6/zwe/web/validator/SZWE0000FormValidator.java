//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0000FormValidator.java
//
// 【機　能　名】SZWE0000_エラー表示ＣＬメイン画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import jp.co.alsok.g6.common.util.string.StringUtil;
import jp.co.alsok.g6.zwe.config.PropertySourceConfig;
import jp.co.alsok.g6.zwe.dto.SZWE0000IchiranDto;
import jp.co.alsok.g6.zwe.service.SZWE0000Service;
import jp.co.alsok.g6.zwe.web.form.SZWE0000Form;

/**
 * SZWE0000フォームバリデーターのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
@Component
public class SZWE0000FormValidator implements Validator {

	/**
	 * エラー表示ＣＬメイン画面用サービスクラス.
	 */
	@Autowired
	private SZWE0000Service sZWE0000Service;

	/**
	 * プロパティファイル管理サービス.
	 */
	@Autowired
	private PropertySourceConfig propertySourceConfig;

	/**
	 * メッセージID.
	 */
	private static final String MESSAGE_ID_MZWE204E = "MZWE204E";

	/**
	 * エラー区分検索キー.
	 */
	private static final String CD_ID_CD085 = "CD085";

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean supports(final Class<?> clazz) {
		SZWE0000Form.class.isAssignableFrom(clazz);
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void validate(final Object target, final Errors errors) {

		SZWE0000Form form = (SZWE0000Form) target;

		// エラー履歴一覧を取得する
		SZWE0000IchiranDto inDto = new SZWE0000IchiranDto();

		inDto.setCdId(CD_ID_CD085);

		// 初期の場合
		if (StringUtil.isNullOrEmpty(form.getErrorKubun())) {

			// デフォルトエラー表示レベル取得
			inDto.setErrLvl(propertySourceConfig.get("DispLevel"));
			inDto.setChangeFlag(false);
		} else {
			inDto.setErrLvl(form.getErrorKubun());
			inDto.setChangeFlag(true);

			if (!StringUtil.isNullOrEmpty(form.getSelectGcCode())) {
				inDto.setSelectedGcNum(form.getSelectGcCode().split(","));
			}
		}

		// 一覧件数を行う
		int resultCount = sZWE0000Service.selectErrorListCount(inDto);

		if (resultCount == 0) {
			errors.reject(MESSAGE_ID_MZWE204E, null, null);
		}
	}
}
