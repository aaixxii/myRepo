package jp.co.alsok.g6.zwe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlsokG6WebErrorApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlsokG6WebErrorApplication.class, args);
	}
}
