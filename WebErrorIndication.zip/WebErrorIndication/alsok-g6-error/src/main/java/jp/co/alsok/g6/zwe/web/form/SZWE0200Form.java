//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0200Form.java
//
// 【機　能　名】SZWE0200_エラー表示ＣＬ詳細画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.form;

import jp.co.alsok.g6.zwe.web.form.common.BaseForm;

/**
 * SZWE0200フォームのクラス．<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
public class SZWE0200Form extends BaseForm {

}
