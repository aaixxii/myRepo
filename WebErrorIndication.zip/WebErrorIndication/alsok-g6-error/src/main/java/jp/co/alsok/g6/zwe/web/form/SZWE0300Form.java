//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0300Form.java
//
// 【機　能　名】SZWE0300_担当ＧＣ選択画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/27
// 【修　正　者】
//====================================================================

package jp.co.alsok.g6.zwe.web.form;

import java.util.ArrayList;
import java.util.List;

import jp.co.alsok.g6.zwe.dto.SZWE0300KGcCheckNullDto;
import jp.co.alsok.g6.zwe.dto.SZWE0300KGcDto;
import jp.co.alsok.g6.zwe.web.form.common.BaseForm;

/**
 * SZWE0300フォームのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/27 新規作成<br>
 */
public class SZWE0300Form extends BaseForm {

    /**
     * チェックボックス.
     */
    private boolean bcheckFlg;

    /**
     * flgMessage.
     */
    private String flgMessage;

    /**
     * 警備エリア名称.
     */
    private String strAreaNm;

    /**
     * 上位GCコード.
     */
    private String strUpperGcCd;

    /**
     * GCコード.
     */
    private String strGcCd;

    /**
     * GC名称.
     */
    private String strGcNm;

    /**
     * 警備エリア名称.
     */
    private String strKbAreaNm;

    /**
     * メッセージ.
     */
    private List<String> messages = new ArrayList<>();

    /**
     * 担当ＧＣ List.
     */
    private List<SZWE0300KGcDto> listGc = new ArrayList<>();

    /**
     * 担当エリアList.
     */
    private List<SZWE0300KGcDto> listArea = new ArrayList<>();

    /**
     * 担当エリアList.
     */
    private List<SZWE0300KGcCheckNullDto> listGcCheckNull = new ArrayList<>();

    /**
     * strAreaNm 取得.
     * @return strAreaNm
     */
    public String getStrAreaNm() {
        return strAreaNm;
    }

    /**
     * 警備エリア名称 .
     * @param strAreaNm 警備エリア名称 .
     */

    public void setStrAreaNm(String strAreaNm) {
        this.strAreaNm = strAreaNm;
    }

    /**
     * strUpperGcCd 取得.
     * @return strUpperGcCd
     */
    public String getStrUpperGcCd() {
        return strUpperGcCd;
    }

    /**
     * 上位GCコード .
     * @param strUpperGcCd 上位GCコード .
     */
    public void setStrUpperGcCd(String strUpperGcCd) {
        this.strUpperGcCd = strUpperGcCd;
    }

    /**
     * strGcCd 取得.
     * @return strGcCd
     */
    public String getStrGcCd() {
        return strGcCd;
    }

    /**
     * GCコード .
     * @param strGcCd GCコード .
     */
    public void setStrGcCd(String strGcCd) {
        this.strGcCd = strGcCd;
    }

    /**
     * strGcNm 取得.
     * @return strGcNm
     */
    public String getStrGcNm() {
        return strGcNm;
    }

    /**
     * GC名称.
     * @param strGcNm GC名称.
     */
    public void setStrGcNm(String strGcNm) {
        this.strGcNm = strGcNm;
    }

    /**
     * strKbAreaNm 取得.
     * @return strKbAreaNm
     */
    public String getStrKbAreaNm() {
        return strKbAreaNm;
    }

    /**
     * 警備エリア名称 .
     * @param strKbAreaNm 警備エリア名称 .
     */
    public void setStrKbAreaNm(String strKbAreaNm) {
        this.strKbAreaNm = strKbAreaNm;
    }

    /**
     * messages 取得.
     * @return messages
     */
    public List<String> getMessages() {
        return messages;
    }

    /**
     * メッセージ .
     */
    public void setMessages(List<String> messages) {
        this.messages = messages;
    }

    /**
     * listGc 取得.
     * @return listGc
     */
    public List<SZWE0300KGcDto> getListGc() {
        return listGc;
    }

    /**
     * 担当ＧＣ List.
     * @param listGc 担当ＧＣ List.
     */
    public void setListGc(List<SZWE0300KGcDto> listGc) {
        this.listGc = listGc;
    }

    /**
     * listArea 取得.
     * @return listArea
     */
    public List<SZWE0300KGcDto> getListArea() {
        return listArea;
    }

    /**
     * 担当エリアList.
     * @param listArea 担当エリアList.
     */
    public void setListArea(List<SZWE0300KGcDto> listArea) {
        this.listArea = listArea;
    }

    /**
    * listGcCheckNull 取得
    * @return listGcCheckNull
    */
    public List<SZWE0300KGcCheckNullDto> getListGcCheckNull() {
        return listGcCheckNull;
    }

    /**
    * @param listGcCheckNull 設定 listGcCheckNull
    */
    public void setListGcCheckNull(List<SZWE0300KGcCheckNullDto> listGcCheckNull) {
        this.listGcCheckNull = listGcCheckNull;
    }

    /**
     * bcheckFlg 取得.
     * @return bcheckFlg
     */
    public boolean isBcheckFlg() {
        return bcheckFlg;
    }

    /**
     * チェックボックス.
     * @param bcheckFlg チェックボックス.
     */
    public void setBcheckFlg(boolean bcheckFlg) {
        this.bcheckFlg = bcheckFlg;
    }

    /**
    * flgMessage 取得
    * @return flgMessage
    */
    public String getFlgMessage() {
        return flgMessage;
    }

    /**
    * @param flgMessage 設定 flgMessage
    */
    public void setFlgMessage(String flgMessage) {
        this.flgMessage = flgMessage;
    }
}
