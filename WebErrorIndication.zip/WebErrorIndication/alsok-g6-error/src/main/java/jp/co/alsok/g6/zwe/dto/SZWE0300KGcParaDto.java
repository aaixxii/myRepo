//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0300KGcParaDto.java
//
// 【機　能　名】担当ＧＣ選択画面
//
//====================================================================
// 【作　成　者】日本電気株式会社         2018/06/27
// 【修　正　者】
//====================================================================

package jp.co.alsok.g6.zwe.dto;

/**
 * 担当ＧＣ選択画面.
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/27 新規作成
 */
public class SZWE0300KGcParaDto {

    /**
     * GCコードlist.
     */
    private String strGcCdList;

    /**
     * strGcCdList 取得.
     * @return strGcCdList
     */
    public String getStrGcCdList() {
        return strGcCdList;
    }

    /**
     * GCコードlist.
     * @param strGcCdList GCコードlist.
     */
    public void setStrGcCdList(String strGcCdList) {
        this.strGcCdList = strGcCdList;
    }
}
