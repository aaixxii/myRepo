//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0000Contorller.java
//
// 【機　能　名】SZWE0000_エラー表示ＣＬメイン画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.alsok.g6.common.util.string.StringUtil;
import jp.co.alsok.g6.zwe.config.PropertySourceConfig;
import jp.co.alsok.g6.zwe.dto.SZWE0000IchiranDto;
import jp.co.alsok.g6.zwe.entity.g6.MCd;
import jp.co.alsok.g6.zwe.service.SZWE0000Service;
import jp.co.alsok.g6.zwe.web.constants.ScreenConstants;
import jp.co.alsok.g6.zwe.web.form.SZWE0000Form;
import jp.co.alsok.g6.zwe.web.validator.SZWE0000FormValidator;

/**
 * SZWE0000コントローラーのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
@Controller
@RequestMapping(ScreenConstants.SZWE0000)
public class SZWE0000Contorller extends AbstractBaseContorller {

	public enum BuzzMode {
		ON("ON"),
		OFF("OFF"),;
		private final String value;

		private BuzzMode(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}

	/**
	 * エラー表示ＣＬメイン画面サービス.
	 */
	@Autowired
	private SZWE0000Service sZWE0000Service;

	/**
	 * プロパティファイル管理サービス.
	 */
	@Autowired
	private PropertySourceConfig propertySourceConfig;

	/**
	 * エラー表示ＣＬメイン画面用バリデータクラス.
	 */
	@Autowired
	private SZWE0000FormValidator validator;

	/**
	 * フォーム名称.
	 */
	private static final String FORM_NAME = "SZWE0000Form";

	/**
	 * エラー区分検索キー.
	 */
	private static final String CD_ID_CD085 = "CD085";

	/**
	 * 更新最後時間のセッションキー.
	 */
	private static final String LAST_TIME = "LASTTIME";

	/**
	 * 区分のセッションキー.
	 */
	private static final String KUBUN_VALUE = "SZWE0000FromErrorKubunValue";

	/**
	 * バインダーを初期化し、エリアコード一覧画面用バリデータを設定.
	 *
	 * @param binder
	 *            バインダー
	 */
	@InitBinder
	public void init(final WebDataBinder binder) {
		binder.addValidators(validator);
	}

	/**
	 * 初期処理.
	 * 
	 * @return モデル<br>
	 */
	@RequestMapping("/")
	public ModelAndView index() {

		// TODO TODO-SZWE0000-0007 鳴音切替え処理ボタンの処理不明（QA：194）

		// 画面のリクエスト情報を保持するModelAndViewを作成
		ModelAndView view = new ModelAndView();

		SZWE0000Form form = new SZWE0000Form();

		// エラー区分検索
		selectErrorKubun(form);

		// 検索処理を行う
		Date lastTime = fomatDate(searchProcess(form, false));

		sessionUtils.putSessionValue(LAST_TIME, lastTime);

		// ブザーモード初期化
		form.setBuzzStatus(BuzzMode.OFF.getValue());
		sessionUtils.putSessionValue(BuzzMode.class.getSimpleName(), BuzzMode.OFF.getValue());

		// 通知エラー区分初期値設定
		form.setErrorKubun(propertySourceConfig.get("DispLevel"));

		// エラー更新間隔(ミリー秒)設定
		form.setTegetTimer(
				String.valueOf(
						Integer.valueOf(propertySourceConfig.get("RegetTimer"))
								* 1000));

		// エラー区分プルダウンの値を保持する
		sessionUtils.putSessionValue(KUBUN_VALUE, nulltoSpace(form.getErrorKubun()));

		// 画面情報を設定する
		view.addObject(FORM_NAME, form);

		// 画面名を設定
		view.setViewName(ScreenConstants.SZWE0000);

		// ブラウザにHTMLを送信する
		return view;
	}

	private String nulltoSpace(String kubun) {
		return kubun == null ? "" : kubun;
	}

	/**
	 * エラー区分コンボボックスChange処理.
	 *
	 * @param form フォーム
	 * @param result バリデータの結果情報
	 *
	 * @return モデル<br>
	 */
	@RequestMapping("/changeErrorKunbun")
	public ModelAndView changeErrorKunbun(
			@Validated @ModelAttribute final SZWE0000Form form,
			final BindingResult result) {

		// 画面のリクエスト情報を保持するModelAndViewを作成
		ModelAndView view = new ModelAndView();

		// 画面情報を設定する
		view.addObject(FORM_NAME, form);

		// 画面名を設定
		view.setViewName(ScreenConstants.SZWE0000);

		boolean kubunChange = sessionUtils.getSessionValue(KUBUN_VALUE).equals(form.getErrorKubun())
				? false : true;

		// Change後のエラー区分プルダウンの値を保持する
		sessionUtils.putSessionValue(KUBUN_VALUE, nulltoSpace(form.getErrorKubun()));

		form.setBuzzStatus(sessionUtils.getSessionValue(BuzzMode.class.getSimpleName()));
		// エラー区分検索
		selectErrorKubun(form);

		// バリデータでエラーの場合
		if (result.hasErrors()) {
			return view;
		}

		// 検索処理を行う
		Date searchResultTime = fomatDate(searchProcess(form, true));
		Date lastTime = sessionUtils.getSessionValue(LAST_TIME);
		if (searchResultTime != null) {
			sessionUtils.putSessionValue(LAST_TIME, searchResultTime);

			if (kubunChange) {
				form.setNewDataFlg("0");
			} else {
				if (lastTime != null && searchResultTime.after(lastTime)) {
					form.setNewDataFlg("1");
				}
			}
		} 

		// ブラウザにHTMLを送信する
		return view;
	}

	/**
	 * DBの時間をformat処理.
	 * 時間型ではないのデータを無視する
	 * @param recentTime
	 *            DBの最新時間
	 *
	 * @return Format後のDate型<br>
	 */
	private Date fomatDate(String recentTime) {

		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date parseTime = null;
		try {
			parseTime = format.parse(recentTime);
		} catch (ParseException e) {
			return null;
		}
		return parseTime;
	}

	/**
	 * ブザー鳴動ON OFF切替処理.
	 *
	 * @param form
	 *            フォーム対象
	 * @param result
	 *            結果
	 * @return 処理結果
	 */
	@GetMapping(value = "/buzz")
	@ResponseBody
	public SZWE0000Form doBuzz(@ModelAttribute final SZWE0000Form form, final BindingResult result) {

		// ◇ブザー鳴動中(ON)の場合
		if (BuzzMode.ON.getValue().equals(form.getBuzzStatus())) {
			// ブザーの鳴動を停止する
			form.setBuzzStatus(BuzzMode.OFF.getValue());
			sessionUtils.putSessionValue(BuzzMode.class.getSimpleName(), BuzzMode.OFF.getValue());
		} else {
			// ◇ブザー鳴動停止(OFF)の場合
			form.setBuzzStatus(BuzzMode.ON.getValue());
			sessionUtils.putSessionValue(BuzzMode.class.getSimpleName(), BuzzMode.ON.getValue());
		}

		// 処理終了
		return form;
	}

	/**
	 *
	 * エラー区分検索処理.
	 *
	 * @param form フォーム<br>
	 *
	 */
	private void selectErrorKubun(final SZWE0000Form form) {

		// 検索条件を設定する
		MCd inDto = new MCd();
		inDto.setCdId(CD_ID_CD085);

		// 通知エラー区分プルダウン設定
		List<MCd> errorKubunList = sZWE0000Service
				.selectErrorKubunList(inDto);

		form.setErrorKubunList(errorKubunList);

	}

	/**
	 * 明細検索処理.
	 *
	 * @param form
	 *            フォーム.
	 * @param changeFlag
	 *            呼び出すイベントフラグ<br>
	 * @return 検索結果の最新時間
	 */
	private String searchProcess(final SZWE0000Form form, final boolean changeFlag) {
		// エラー履歴一覧を取得する
		SZWE0000IchiranDto inDto = new SZWE0000IchiranDto();
		inDto.setCdId(CD_ID_CD085);
		inDto.setSearchMaxNum(propertySourceConfig.get("MainMaxNum"));
		// 初期化の時
		if (changeFlag) {
			// エラー区分Changeの時
			inDto.setErrLvl(form.getErrorKubun());
			inDto.setChangeFlag(true);

			if (!StringUtil.isNullOrEmpty(form.getSelectGcCode())) {
				inDto.setSelectedGcNum(form.getSelectGcCode().split(","));
			}

		} else {
			// デフォルトエラー表示レベル取得
			inDto.setErrLvl(propertySourceConfig.get("DispLevel"));
			inDto.setChangeFlag(false);
		}

		// 一覧内容検索を行う
		List<SZWE0000IchiranDto> searchResultList = sZWE0000Service
				.selectErrorList(inDto);
		form.setSearchResultList(searchResultList);

		if (searchResultList != null && searchResultList.size() > 0 && searchResultList.get(0) != null) {
			return searchResultList.get(0).getRcvTs();
		} else {
			return "";
		}
	}
}