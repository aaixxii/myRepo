//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0100Service.java
//
// 【機　能　名】SZWE0100_エラー表示ＣＬ検索画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.alsok.g6.zwe.dao.mapper.g6.G6SZWE0100Mapper;
import jp.co.alsok.g6.zwe.dto.SZWE0100IchiranDto;
import jp.co.alsok.g6.zwe.entity.g6.MCd;
import jp.co.alsok.g6.zwe.entity.g6.MKeiyakuCtlDev;

/**
 * SZWE0100サービスのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
@Service
public class SZWE0100Service {

	/**
	 * エラー表示ＣＬ検索画面Mapper.
	 */
	@Autowired
	private G6SZWE0100Mapper g6SZWE0100Mapper;

	/**
	 * エラー表示ＣＬ詳細一覧内容取得.
	 *
	 * @param inDto 検索条件
	 * @return 一覧内容<br>
	 */
	public List<SZWE0100IchiranDto> selectErrorList(SZWE0100IchiranDto inDto) {
		return g6SZWE0100Mapper.selectErrorList(inDto);
	}

	/**
	 * エラー表示ＣＬ詳細一覧内容取得.
	 *
	 * @param inDto 検索条件
	 * @return 検索件数<br>
	 */
	public int selectErrorListCount(SZWE0100IchiranDto inDto) {
		return g6SZWE0100Mapper.selectErrorListCount(inDto);

	}

	/**
	 * サービス区分コンボボックス内容取得.
	 *
	 * @return コンボボックス内容<br>
	 */
	public List<MKeiyakuCtlDev> selectServiceKubunList() {

		return g6SZWE0100Mapper.selectServiceKubun();
	}

	/**
	 *
	 * エラー区分コンボボックス内容取得.
	 *
	 * @return コンボボックス内容<br>
	 */
	public List<MCd> selectErrorKubunList(MCd inDto) {
		return g6SZWE0100Mapper.selectErrorKubun(inDto);

	}
}
