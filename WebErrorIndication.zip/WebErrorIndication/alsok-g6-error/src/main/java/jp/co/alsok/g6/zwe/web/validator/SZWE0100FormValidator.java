//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0100FormValidator.java
//
// 【機　能　名】SZWE0100_エラー表示ＣＬ検索画面用のFormValidator
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.validator;

import java.text.ParseException;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import jp.co.alsok.g6.common.util.string.StringUtil;
import jp.co.alsok.g6.zwe.web.form.SZWE0100Form;
import jp.co.alsok.g6.zzw.util.check.DateValidationUtil;

/**
 * SZWE0100フォームバリデーターのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
@Component
public class SZWE0100FormValidator implements Validator {

	/**
	 * エラーメッセージ.
	 */
	private static final String MESSAGE_ID_MZWE206E = "MZWE206E";

	/**
	 * SPACEのCONST.
	 */
	private static final String CONSTSPACE = " ";

	/**
	 * COLONのCONST.
	 */
	private static final String CONSTCOLON = ":";

	/**
	 * 時OR分のディフォルト値.
	 */
	private static final String TIME_DEFAULT = "00";

	/**
	 * 時のディフォルト値.
	 */
	private static final String TIME_DEFAULT_HOURE_EN = "23";

	/**
	 * 分のディフォルト値.
	 */
	private static final String TIME_DEFAULT_MINUTE_END = "59";

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean supports(final Class<?> clazz) {
		SZWE0100Form.class.isAssignableFrom(clazz);
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void validate(final Object target, final Errors errors) {

		SZWE0100Form form = (SZWE0100Form) target;

		// 発生年月日（FROM)が空ではない場合
		if (!StringUtil.isNullOrEmpty(form.getFromHasseiDate())) {
			// 日付として不正な値の場合
			if (!DateValidationUtil.validDateFormat(form.getFromHasseiDate(),
					DateValidationUtil.FORMAT_YYYYMMDD_SLASH)) {
				errors.reject(MESSAGE_ID_MZWE206E, null, null);
			}

			// 発生時間（FROM) が空ではない場合
			if (!StringUtil.isNullOrEmpty(form.getFromHasseiDateHour())
					|| !StringUtil.isNullOrEmpty(form.getFromHasseiDateMinute())) {
				// 時間として不正な値の場合
				if (!DateValidationUtil.validDateFormat(
						form.getFromHasseiDateHour() + ":" + form.getFromHasseiDateMinute(),
						DateValidationUtil.FORMAT_HHMM_COLON)) {
					errors.reject(MESSAGE_ID_MZWE206E, null, null);
				}
			}

		} else {

			// 発生年月日（FROM)が空の場合
			if (!StringUtil.isNullOrEmpty(form.getFromHasseiDateHour())
					|| !StringUtil.isNullOrEmpty(form.getFromHasseiDateMinute())) {
				// 発生時間（FROM) が空ではない場合
				errors.reject(MESSAGE_ID_MZWE206E, null, null);
			}

		}

		// 発生年月日（TO)が空ではない場合
		if (!StringUtil.isNullOrEmpty(form.getToHasseiDate())) {
			// 日付として不正な値の場合
			if (!DateValidationUtil.validDateFormat(form.getToHasseiDate(),
					DateValidationUtil.FORMAT_YYYYMMDD_SLASH)) {
				errors.reject(MESSAGE_ID_MZWE206E, null, null);
			}
			// 発生時間（TO) が空ではない場合
			if (!StringUtil.isNullOrEmpty(form.getToHasseiDateHour())
					|| !StringUtil.isNullOrEmpty(form.getToHasseiDateMinute())) {
				// 時間として不正な値の場合
				if (!DateValidationUtil.validDateFormat(
						form.getToHasseiDateHour() + ":" + form.getToHasseiDateMinute(),
						DateValidationUtil.FORMAT_HHMM_COLON)) {
					errors.reject(MESSAGE_ID_MZWE206E, null, null);
				}
			}
		} else {
			// 発生年月日（TO)が空の場合
			if (!StringUtil.isNullOrEmpty(form.getToHasseiDateHour())
					|| !StringUtil.isNullOrEmpty(form.getToHasseiDateMinute())) {
				// 発生時間（TO) が空ではない場合
				errors.reject(MESSAGE_ID_MZWE206E, null, null);
			}
		}

		// 単純エラー発生する場合は、先にエラーmessage表示
		if (errors.hasErrors()) {
			return;
		}

		// （From 年月日／To 年月日共に、入力されている場合）From 年月日より後の日付である
		if (!StringUtil.isNullOrEmpty(form.getFromHasseiDate())
				&& !StringUtil.isNullOrEmpty(form.getToHasseiDate())) {

			// 発信日時設定(FROM)
			String strFromHasseiDateTime = form.getFromHasseiDate();

			// 時の設定
			if (!StringUtil.isNullOrEmpty(form.getFromHasseiDateHour())) {

				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTSPACE).concat(
						String.format("%02d", Integer.parseInt(form.getFromHasseiDateHour())));
			} else {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTSPACE)
						.concat(TIME_DEFAULT);
			}

			// 秒の設定
			if (!StringUtil.isNullOrEmpty(form.getFromHasseiDateMinute())) {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTCOLON).concat(
						String.format("%02d", Integer.parseInt(form.getFromHasseiDateMinute())));
			} else {
				strFromHasseiDateTime = strFromHasseiDateTime.concat(CONSTCOLON)
						.concat(TIME_DEFAULT);
			}

			String strToHasseiDateTime = form.getToHasseiDate();

			// 時の設定
			if (!StringUtil.isNullOrEmpty(form.getToHasseiDateHour())) {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTSPACE)
						.concat(String.format("%02d", Integer.parseInt(form.getToHasseiDateHour())));
			} else {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTSPACE)
						.concat(TIME_DEFAULT_HOURE_EN);
			}

			// 秒の設定
			if (!StringUtil.isNullOrEmpty(form.getToHasseiDateMinute())) {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTCOLON).concat(
						String.format("%02d", Integer.parseInt(form.getToHasseiDateMinute())));
			} else {
				strToHasseiDateTime = strToHasseiDateTime.concat(CONSTCOLON)
						.concat(TIME_DEFAULT_MINUTE_END);
			}

			try {
				if (DateValidationUtil.compareToDate(
						strFromHasseiDateTime.concat(CONSTCOLON).concat(TIME_DEFAULT),
						strToHasseiDateTime.concat(CONSTCOLON).concat(TIME_DEFAULT),
						DateValidationUtil.FORMAT_YYYYMMDD_HHMMSS_SLASH_COLON) > 0) {
					errors.reject(MESSAGE_ID_MZWE206E, null, null);
				}
			} catch(ParseException e) {
				errors.reject(MESSAGE_ID_MZWE206E, null, null);
			}

		}

	}
}
