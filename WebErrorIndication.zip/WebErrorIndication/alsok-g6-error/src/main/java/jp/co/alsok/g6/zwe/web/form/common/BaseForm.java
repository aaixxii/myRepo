package jp.co.alsok.g6.zwe.web.form.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BaseForm  implements Serializable {

    //--- サンプル用↓ -------
    private String hederChangeFlg;

    public String getHederChangeFlg() {
        return hederChangeFlg;
    }

    public void setHederChangeFlg(String hederChangeFlg) {
        this.hederChangeFlg = hederChangeFlg;
    }
  //--- サンプル用↑ -------

    //--------------------------------------
    //メッセージ退避用
    //--------------------------------------
    /**
     * エラーメッセージ
     */
    private List<String> messages = new ArrayList<>();

    /**
    * messages 取得
    * @return messages
    */
    public List<String> getMessages() {
        return messages;
    }

    /**
    * @param messages 設定 messages
    */
    public void setMessages(List<String> messages) {
        this.messages = messages;
    }



}
