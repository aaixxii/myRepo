//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】G6SZWE0000Mapper.java
//
// 【機　能　名】SZWE0000_エラー表示ＣＬメイン画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.dao.mapper.g6;

import java.util.List;

import jp.co.alsok.g6.zwe.dto.SZWE0000IchiranDto;
import jp.co.alsok.g6.zwe.entity.g6.MCd;

/**
 * SZWE0000マップのクラス．<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
public interface G6SZWE0000Mapper {

    /**
     * エラー表示ＣＬメイン一覧内容取得.
     *
     * @param inDto 検索条件
     * @return 一覧内容<br>
     */
    List<SZWE0000IchiranDto> selectErrorList(SZWE0000IchiranDto inDto);

    /**
     * エラー表示ＣＬメイン一覧件数取得.
     *
     * @param inDto 検索条件
     * @return 検索件数<br>
     */
    int selectErrorListCount(SZWE0000IchiranDto inDto);

    /**
     * エラー区分プルダウン取得.
     *
     * @param inMCd 検索条件
     * @return エラー区分コンボボックス内容<br>
     */
    List<MCd> selectErrorKubun(MCd inMCd);

}