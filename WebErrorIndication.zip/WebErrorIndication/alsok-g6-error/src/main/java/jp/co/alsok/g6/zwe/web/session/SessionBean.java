package jp.co.alsok.g6.zwe.web.session;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

@Component
@Scope(value= "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SessionBean implements Serializable {

    private static final long serialVersionUID = 1L;

    //------------------------------------------
    //遷移情報
    //------------------------------------------
    /** 遷移の際の情報保持用 */
    private Map<String, Object> sessionMap;

    /**
    * sessionMap 取得
    * @return sessionMap
    */
    public Map<String, Object> getSessionMap() {
        if (sessionMap == null) {
            sessionMap = new HashMap<String, Object>();
        }
        return sessionMap;
    }

    /**
    * @param sessionMap 設定 sessionMap
    */
    public void setSessionMap(Map<String, Object> sessionMap) {
        this.sessionMap = sessionMap;
    }

}
