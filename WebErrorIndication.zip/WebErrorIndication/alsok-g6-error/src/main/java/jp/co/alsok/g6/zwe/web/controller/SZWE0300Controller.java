//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0300Controller.java
//
// 【機　能　名】SZWE0300_担当ＧＣ選択画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/27
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import jp.co.alsok.g6.common.util.string.StringUtil;
import jp.co.alsok.g6.zwe.dto.SZWE0300KGcCheckNullDto;
import jp.co.alsok.g6.zwe.dto.SZWE0300KGcDto;
import jp.co.alsok.g6.zwe.dto.SZWE0300KGcParaDto;
import jp.co.alsok.g6.zwe.dto.SZWE0300UpperCdDto;
import jp.co.alsok.g6.zwe.service.SZWE0300Service;
import jp.co.alsok.g6.zwe.web.constants.ScreenConstants;
import jp.co.alsok.g6.zwe.web.form.SZWE0300Form;
import jp.co.alsok.g6.zwe.web.validator.SZWE0300FormValidator;

/**
 * SZWE0300コントローラーのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/27 新規作成<br>
 */
@Controller
@RequestMapping(ScreenConstants.SZWE0300)
public class SZWE0300Controller extends AbstractBaseContorller {

    /**
     * 担当ＧＣ選択画面用service.
     */
    @Autowired
    private SZWE0300Service service;

    /**
     * エラー表示ＣＬメイン画面用バリデータクラス.
     */
    @Autowired
    private SZWE0300FormValidator validator;

    /**
     * コンマコード.
     */
    private static final String CONSTCOMMA = ",";

    /**
     * 検索結果が０件ですを設定.
     */
    private static final String MESSAGE_FLG = "1";

    /**
     * バインダーを初期化し、エリアコード一覧画面用バリデータを設定.
     *
     * @param binder バインダー
     */
    @InitBinder
    public void init(final WebDataBinder binder) {
        binder.addValidators(validator);
    }

    /**
     * index初期化処理.
     *
     * @param form SZWE0300Form.
     * @return 担当ＧＣ<br>
     */
    @RequestMapping("/")
    public String index(@ModelAttribute final SZWE0300Form form) {

        // データ取得
        List<SZWE0300KGcCheckNullDto> listGcCheckNull = service
                .selectAllCheckNull();

        // 一覧件数判定を行う
        if (listGcCheckNull == null || listGcCheckNull.size() == 0) {
            form.setFlgMessage(MESSAGE_FLG);
        } else {
            form.setListGcCheckNull(listGcCheckNull);
        }

        // 一覧件数判定を行う
        if (listGcCheckNull == null || listGcCheckNull.size() == 0) {
            form.setFlgMessage(MESSAGE_FLG);
        }

        // 担当ＧＣデータ取得する
        List<SZWE0300KGcDto> listGc = service.selectAll();

        form.setListGc(listGc);
        for (int i = 0; i < listGc.size(); i++) {
            SZWE0300KGcDto dtoSZWE0300KGc = listGc.get(i);
            if (StringUtil.isNullOrEmpty(dtoSZWE0300KGc.getStrUpperGcCd())) {
                dtoSZWE0300KGc.setStrUpperGcCd(dtoSZWE0300KGc.getStrGcCd());
            }
        }

        // ブラウザにHTMLを送信する
        return ScreenConstants.SZWE0300;
    }

    /**
     * チェックボックス押下処理.
     *
     * @param pstrGcCd GCコード
     * @return map<br>
     */
    @ResponseBody
    @RequestMapping(
            value = "confirm",
            method = {RequestMethod.POST})
    public Map<String, Object> comfirm(
            @RequestParam("pstrGcCd")
            final String pstrGcCd) {

        Map<String, Object> map = new HashMap<String, Object>();

        // ＧＣコード分解する
        String[] gcCdArrays = pstrGcCd.split(CONSTCOMMA);

        List<SZWE0300KGcDto> listArea = new ArrayList<SZWE0300KGcDto>();

        List<SZWE0300KGcDto> listAreaResult = new ArrayList<SZWE0300KGcDto>();

        SZWE0300KGcParaDto dto = new SZWE0300KGcParaDto();

        // データ取得する
        for (int i = 0; i < gcCdArrays.length; i++) {

            dto.setStrGcCdList(gcCdArrays[i]);

            // 警備エリア情報の取得
            if (!StringUtil.isNullOrEmpty(pstrGcCd)) {

                SZWE0300UpperCdDto listUpperCd = service.selectByUpperCd(dto);
                if (!listUpperCd.getStrGcCd()
                        .equals(listUpperCd.getStrUpperGcCd())) {
                    listArea = service.selectByGcCd(dto);
                    listAreaResult.addAll(listArea);
                }
            } else {
                listArea = service.selectByGcCd(dto);
                listAreaResult.addAll(listArea);
            }
        }

        map.put("listArea", listAreaResult);

        // ブラウザにHTMLを送信する
        return map;
    }
}