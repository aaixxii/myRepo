//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0200Controller.java
//
// 【機　能　名】SZWE0200_エラー表示ＣＬ詳細画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================
package jp.co.alsok.g6.zwe.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jp.co.alsok.g6.zwe.web.constants.ScreenConstants;
import jp.co.alsok.g6.zwe.web.form.SZWE0200Form;

/**
 * SZWE0200コントローラーのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/21 新規作成<br>
 */
@Controller
@RequestMapping(ScreenConstants.SZWE0200)
public class SZWE0200Controller extends AbstractBaseContorller {

	/**
	 * フォーム名称.
	 */
	private static final String FORM_NAME = "SZWE0200Form";

	/**
	 * 初期処理.
	 * @return モデル<br>
	 */
	@RequestMapping("/")
	public ModelAndView index() {

		// 画面のリクエスト情報を保持するModelAndViewを作成
		ModelAndView view = new ModelAndView();
		SZWE0200Form form = new SZWE0200Form();

		// 画面情報を設定する
		view.addObject(FORM_NAME, form);

		// 画面名を設定
		view.setViewName(ScreenConstants.SZWE0200);

		// ブラウザにHTMLを送信する
		return view;
	}
}
