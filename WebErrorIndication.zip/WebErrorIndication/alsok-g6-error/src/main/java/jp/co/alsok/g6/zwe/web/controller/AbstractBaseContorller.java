package jp.co.alsok.g6.zwe.web.controller;

import org.springframework.beans.factory.annotation.Autowired;

import jp.co.alsok.g6.zwe.web.util.SessionUtils;

public abstract class AbstractBaseContorller {

    /** セッション共通部品ラッパークラス */
    @Autowired
    protected SessionUtils sessionUtils;

}
