//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
//【ファイル名】SZWE0300KGcCheckNullDto.java
//
//【機　能　名】SZWE0300_担当ＧＣ選択画面
//
//====================================================================
//【作　成　者】日本電気株式会社　　2018/08/14
//【修　正　者】
//====================================================================

package jp.co.alsok.g6.zwe.dto;

import java.util.Date;

/**
 * SZWE0300_担当ＧＣ選択画面用DTOのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/08/14 新規作成<br>
 */
public class SZWE0300KGcCheckNullDto {

    /**
     * 設定状態Flg.
     */
    private boolean bcheckFlg;

    /**
     * GCコード .
     */
    private String strGcCd;

    /**
     * GC名称.
     */
    private String strGcNm;

    /**
     * GC電話番号.
     */
    private String strGcTelNum;

    /**
     * 上位GCコード .
     */
    private String strUpperGcCd;

    /**
     * 同期有効フラグ.
     */
    private String strSyncAblFlg;

    /**
     * IPアドレス .
     */
    private String strIpAddr;

    /**
     * 業務コード .
     */
    private String strGyoumuCd;

    /**
     * DB名称 .
     */
    private String strDbNm;

    /**
     * DBユーザー.
     */
    private String strDbUser;

    /**
     * DBパスワード.
     */
    private String strDbPasswd;

    /**
     * GCTバージョン .
     */
    private String strGctVer;

    /**
     * 最大接続数 .
     */
    private String strMaxActive;

    /**
     * 保持最大数 .
     */
    private String strMaxIdle;

    /**
     * 最大待機時間.
     */
    private String strMaxWaitTm;

    /**
     * SD連携フラグ .
     */
    private String strSdFlg;

    /**
     * 登録者ID.
     */
    private String insertId;

    /**
     * 登録者名.
     */
    private String insertNm;

    /**
     * 登録日時 .
     */
    private Date insertTs;

    /**
     * 更新者ID.
     */
    private String updateId;

    /**
     * 更新者名.
     */
    private String updateNm;

    /**
     * 更新日時 .
     */
    private Date updateTs;

    /**
     * bcheckFlg 取得.
     * @return bcheckFlg
     */
    public boolean isBcheckFlg() {
        return bcheckFlg;
    }

    /**
     * 設定状態Flg.
     * @param bcheckFlg 設定 bcheckFlg
     */
    public void setBcheckFlg(boolean bcheckFlg) {
        this.bcheckFlg = bcheckFlg;
    }

    /**
     * strGcCd 取得.
     * @return strGcCd
     */
    public String getStrGcCd() {
        return strGcCd;
    }

    /**
     * GCコード .
     * @param strGcCd GCコード .
     */
    public void setStrGcCd(String strGcCd) {
        this.strGcCd = strGcCd;
    }

    /**
     * strGcNm 取得.
     * @return strGcNm
     */
    public String getStrGcNm() {
        return strGcNm;
    }

    /**
     * GC名称.
     * @param strGcNm GC名称.
     */
    public void setStrGcNm(String strGcNm) {
        this.strGcNm = strGcNm;
    }

    /**
     * strGcTelNum 取得.
     * @return strGcTelNum
     */
    public String getStrGcTelNum() {
        return strGcTelNum;
    }

    /**
     * GC電話番号.
     * @param strGcTelNum GC電話番号.
     */
    public void setStrGcTelNum(String strGcTelNum) {
        this.strGcTelNum = strGcTelNum;
    }

    /**
     * strUpperGcCd 取得.
     * @return strUpperGcCd
     */
    public String getStrUpperGcCd() {
        return strUpperGcCd;
    }

    /**
     * 上位GCコード .
     * @param strUpperGcCd 上位GCコード .
     */
    public void setStrUpperGcCd(String strUpperGcCd) {
        this.strUpperGcCd = strUpperGcCd;
    }

    /**
     * strSyncAblFlg 取得.
     * @return strSyncAblFlg
     */
    public String getStrSyncAblFlg() {
        return strSyncAblFlg;
    }

    /**
     * 同期有効フラグ.
     * @param strSyncAblFlg 同期有効フラグ.
     */
    public void setStrSyncAblFlg(String strSyncAblFlg) {
        this.strSyncAblFlg = strSyncAblFlg;
    }

    /**
     * strIpAddr 取得.
     * @return strIpAddr
     */
    public String getStrIpAddr() {
        return strIpAddr;
    }

    /**
     * IPアドレス .
     * @param strIpAddr IPアドレス .
     */
    public void setStrIpAddr(String strIpAddr) {
        this.strIpAddr = strIpAddr;
    }

    /**
     * strGyoumuCd 取得.
     * @return strGyoumuCd
     */
    public String getStrGyoumuCd() {
        return strGyoumuCd;
    }

    /**
     * 業務コード .
     * @param strGyoumuCd 業務コード .
     */
    public void setStrGyoumuCd(String strGyoumuCd) {
        this.strGyoumuCd = strGyoumuCd;
    }

    /**
     * strDbNm 取得.
     * @return strDbNm
     */
    public String getStrDbNm() {
        return strDbNm;
    }

    /**
     * DB名称 .
     * @param strDbNm DB名称 .
     */
    public void setStrDbNm(String strDbNm) {
        this.strDbNm = strDbNm;
    }

    /**
     * strDbUser 取得.
     * @return strDbUser
     */
    public String getStrDbUser() {
        return strDbUser;
    }

    /**
     * DBユーザー.
     * @param strDbUser DBユーザー.
     */
    public void setStrDbUser(String strDbUser) {
        this.strDbUser = strDbUser;
    }

    /**
     * strDbPasswd 取得.
     * @return strDbPasswd
     */
    public String getStrDbPasswd() {
        return strDbPasswd;
    }

    /**
     * DBパスワード.
     * @param strDbPasswd DBパスワード.
     */
    public void setStrDbPasswd(String strDbPasswd) {
        this.strDbPasswd = strDbPasswd;
    }

    /**
     * strGctVer 取得.
     * @return strGctVer
     */
    public String getStrGctVer() {
        return strGctVer;
    }

    /**
     * GCTバージョン .
     * @param strGctVer GCTバージョン .
     */
    public void setStrGctVer(String strGctVer) {
        this.strGctVer = strGctVer;
    }

    /**
     * strMaxActive 取得.
     * @return strMaxActive
     */
    public String getStrMaxActive() {
        return strMaxActive;
    }

    /**
     * 最大接続数 .
     * @param strMaxActive 最大接続数 .
     */
    public void setStrMaxActive(String strMaxActive) {
        this.strMaxActive = strMaxActive;
    }

    /**
     * strMaxIdle 取得.
     * @return strMaxIdle
     */
    public String getStrMaxIdle() {
        return strMaxIdle;
    }

    /**
     * 保持最大数 .
     * @param strMaxIdle 保持最大数 .
     */
    public void setStrMaxIdle(String strMaxIdle) {
        this.strMaxIdle = strMaxIdle;
    }

    /**
     * strMaxWaitTm 取得.
     * @return strMaxWaitTm
     */
    public String getStrMaxWaitTm() {
        return strMaxWaitTm;
    }

    /**
     * 最大待機時間.
     * @param strMaxWaitTm 最大待機時間.
     */
    public void setStrMaxWaitTm(String strMaxWaitTm) {
        this.strMaxWaitTm = strMaxWaitTm;
    }

    /**
     * strSdFlg 取得.
     * @return strSdFlg
     */
    public String getStrSdFlg() {
        return strSdFlg;
    }

    /**
     * SD連携フラグ .
     * @param strSdFlg SD連携フラグ .
     */
    public void setStrSdFlg(String strSdFlg) {
        this.strSdFlg = strSdFlg;
    }

    /**
     * insertId 取得.
     * @return insertId
     */
    public String getInsertId() {
        return insertId;
    }

    /**
     * 登録者ID.
     * @param insertId 登録者ID.
     */
    public void setInsertId(String insertId) {
        this.insertId = insertId;
    }

    /**
     * insertNm 取得.
     * @return insertNm
     */
    public String getInsertNm() {
        return insertNm;
    }

    /**
     * 登録者名.
     * @param insertNm 登録者名.
     */
    public void setInsertNm(String insertNm) {
        this.insertNm = insertNm;
    }

    /**
     * insertTs 取得.
     * @return insertTs
     */
    public Date getInsertTs() {
        return insertTs;
    }

    /**
     * 登録日時 .
     * @param insertTs 登録日時 .
     */
    public void setInsertTs(Date insertTs) {
        this.insertTs = insertTs;
    }

    /**
     * updateId 取得.
     * @return updateId
     */
    public String getUpdateId() {
        return updateId;
    }

    /**
     * 更新者ID.
     * @param updateId 更新者ID.
     */
    public void setUpdateId(String updateId) {
        this.updateId = updateId;
    }

    /**
     * updateNm 取得.
     * @return updateNm
     */
    public String getUpdateNm() {
        return updateNm;
    }

    /**
     * 更新者名.
     * @param updateNm 更新者名.
     */
    public void setUpdateNm(String updateNm) {
        this.updateNm = updateNm;
    }

    /**
     * updateTs 取得.
     * @return updateTs
     */
    public Date getUpdateTs() {
        return updateTs;
    }

    /**
     * 更新日時 .
     * @param updateTs 更新日時 .
     */
    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }
}
