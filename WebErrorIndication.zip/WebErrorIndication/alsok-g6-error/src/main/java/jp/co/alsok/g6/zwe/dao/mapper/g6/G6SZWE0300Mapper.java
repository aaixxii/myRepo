//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】G6SZWE0300Mapper.java
//
// 【機　能　名】SZWE0300_担当ＧＣ選択画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/27
// 【修　正　者】
//====================================================================

package jp.co.alsok.g6.zwe.dao.mapper.g6;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import jp.co.alsok.g6.zwe.dto.SZWE0300KGcCheckNullDto;
import jp.co.alsok.g6.zwe.dto.SZWE0300KGcDto;
import jp.co.alsok.g6.zwe.dto.SZWE0300KGcParaDto;
import jp.co.alsok.g6.zwe.dto.SZWE0300UpperCdDto;

/**
 * SZWE0300マップのクラス.<br>
 *
 * @author NEC Corporation
 * @version 1.0.0 2018/06/27 新規作成<br>
 */
@Mapper
public interface G6SZWE0300Mapper {

  /**
   * 担当ＧＣ情報の取得.
   *
   * @return 取得結果
   */
  List<SZWE0300KGcDto> selectAll();

  /**
   * 担当エリア情報の取得.
   * @param dto 担当ＧＣ選択画面
   * @return 取得結果
   */
  List<SZWE0300KGcDto> selectByGcCd(SZWE0300KGcParaDto dto);

  /**
   * 担当エリア情報の取得.
   * @param dto 担当ＧＣ選択画面
   * @return 取得結果
   */
  SZWE0300UpperCdDto selectByUpperCd(SZWE0300KGcParaDto dto);

  /**
   * 担当ＧＣ情報の取得.
   *
   * @return 取得結果
   */
  List<SZWE0300KGcCheckNullDto> selectAllCheckNull();
}
