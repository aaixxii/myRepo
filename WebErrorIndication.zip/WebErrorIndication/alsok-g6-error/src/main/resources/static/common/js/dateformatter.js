$(function() {
  $("input[type='text'].slashedit").focus(function() {
    var obj = $(this);
    if (typeof(obj) != 'undefined') {
      releaseSlash(obj);
    }
  });

  $("input[type='text'].slashedit").blur(function() {
    var obj = $(this);
    if (typeof(obj) != 'undefined') {
      addSlash(obj);
    }
  });
});
/**************************
 * スラッシュ編集(追加)
 **************************/
function addSlash(obj){
  if(new RegExp(/^[0-9]{8}$/).test(obj.val())){
    var str = obj.val().trim();
    var y = str.substr(0,4);
    var m = str.substr(4,2);
    var d = str.substr(6,2);
    obj.val(y + "/" + m + "/" + d);
  }
}

/**************************
 * スラッシュ編集(解除)
 **************************/
function releaseSlash(obj){
  var reg = new RegExp("/", "g");
  var chgVal = obj.val().replace(reg, "");
  if(!isNaN(chgVal)){
    obj.val(chgVal);
    obj.select();
  }
}