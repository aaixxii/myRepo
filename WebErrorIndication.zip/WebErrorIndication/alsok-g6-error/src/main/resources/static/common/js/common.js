function agentCheck() {

	var explorer = navigator.userAgent;

	if (explorer.indexOf("MSIE") >= 0 || window.ActiveXobject
			|| "ActiveXObject" in window) {
		return true;
	} else if (explorer.indexOf("Chrome") >= 0) {
		return false;
	}
}