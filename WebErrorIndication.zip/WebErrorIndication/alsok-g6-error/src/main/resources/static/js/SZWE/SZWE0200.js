﻿//========================================================================
//            COPYRIGHT  (C)  2015-2016  NEC  CORPORATION
//               NEC  CONFIDENTIAL  AND  PROPRIETARY
//========================================================================
//  【ファイル名】    SZWE0200.js
//
//  【機能名】       SZWE0200_エラー表示ＣＬ詳細画面
//
//========================================================================
//  【作成者】       日本電気株式会社        2018/06/26
//  【修正名】
//========================================================================

/**
 * 初期化処理.
 */
function init() {

    var query;
    if (agentCheck()) {
        // 前画面からデータを設定する
        query = window.dialogArguments["query"];
    } else {
        // 前画面からデータを設定する
        query = parent.window.dialogArguments["query"];
    }
    document.getElementById("rcvTs").value = query["rcvTs"];
    document.getElementById("hasseiTs").value = query["hasseiTs"];
    document.getElementById("gcNum").value = query["gcNum"];
    document.getElementById("gcNm").value = query["gcNm"];
    document.getElementById("hostNm").value = query["hostNm"];
    document.getElementById("syoriId").value = query["syoriId"];
    document.getElementById("errId").value = query["errId"];
    var strDenkei = query["denkei"].split("-");
    document.getElementById("denkei1").value = strDenkei[0];
    document.getElementById("denkei2").value = strDenkei[1];
    document.getElementById("denkei3").value = strDenkei[2];
    var strGuki = query["gouki"].split("-");
    document.getElementById("gouki1").value = strGuki[0];
    document.getElementById("gouki2").value = strGuki[1];
    document.getElementById("gouki3").value = strGuki[2];
    document.getElementById("chikuNum").value = query["chikuNum"];
    document.getElementById("devNum").value = query["devNum"];
    document.getElementById("errLvl").value = query["errLvl"];
    document.getElementById("errNm").value = query["errNm"];
    document.getElementById("recoverMsgNm").value = query["recoverMsgNm"];
    document.getElementById("bikou").value = query["bikou"];
}

/**
 * 閉じる処理.
 */
function clickClose() {
    if (agentCheck()) {
        window.close();
        return false;
    } else {
        chromeDialogClose();
    }
}
