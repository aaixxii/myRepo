//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】G6SZWE0300.js
//
// 【機　能　名】SZWE0300_担当ＧＣ選択画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/27
// 【修　正　者】
//====================================================================

/**
 * 画面初期処理.
 */
$(function() {

    // 検索結果が０件です
    if (flgMessage == "1") {
        $('#msg1 > li').remove();
        $('#msg1 > div').remove();
        var li = document.createElement("li");
        li.innerText = '検索結果が０件です';
        $('#msg1').append(li);
        $.each($('#msg1 > li'), function() {
            $(this).addClass('fielderrMsg');
        });
    }
    for (var i = 0; i < listGcCheckNull.length; i++) {
        if (listGcCheckNull[i].strUpperGcCd == '0000') {
            $('#msg1 > li').remove();
            $('#msg1 > div').remove();
            var li = document.createElement("li");
            li.innerText = '上位GCコードのデータが誤っている';
            $('#msg1').append(li);
            $.each($('#msg1 > li'), function() {
                $(this).addClass('fielderrMsg');
            });
        }
    }

    // 前画面の退避情報を取得
    var strGcCd = "";
    var strAreaCd = "";
    
    if (agentCheck()) {
        strGcCd = window.dialogArguments["selectGcCode"];
        strAreaCd = window.dialogArguments["selectAreaCode"];
     } else {
        strGcCd = parent.$('#selectGcCode').val();
        strAreaCd = parent.$('#selectAreaCode').val();
    }

    // 退避情報を取得できた場合
    if (strGcCd != "") {
        // 担当ＧＣチェックボックスを取得
        var gcCheck = document.getElementsByName("gcCheck");
        // 退避情報により、担当ＧＣチェックボックスのチェック状態を設定
        var gcCdArrays = strGcCd.split(",");
        for (var i = 0; i < gcCdArrays.length; i++) {
            for (var j = 0; j < gcCheck.length; j++) {
                if (listGc[j].strGcCd == gcCdArrays[i]) {
                    gcCheck[j].checked = true;
                }
            }
        }
        for (var i = 0; i < gcCheck.length; i++) {
            if (gcCheck[i].checked) {
                $("#confimBtn").attr("disabled", false);
            }
        }
        // AjaxのJsonパラメータを設定
        var results = "";
        for (var j = 0; j < gcCheck.length; j++) {
            if (gcCheck[j].checked) {
                // チェックボックス選択する行
                var row = gcCheck[j].parentElement.parentElement.rowIndex;
                if (results == "") {
                    // チェックボックス選択する行のＧＣコード
                    results += listGc[row].strGcCd;
                } else {
                    results += "," + listGc[row].strGcCd;
                }
            }
        }
        // 退避情報により、担当エリアチェックボックスのチェック状態を設定
        $('#areCheckedPrent').val(strAreaCd);
        $
                .ajax({
                    url : purl,
                    type : "POST",
                    datetype : "json",
                    data : {
                        pstrGcCd : results
                    },
                    success : function(data) {

                        // 明細クリア
                        $("#areaTable tr").remove();
                        // 全担当/全取消を設定
                        if (data.listArea.length == 0) {
                            $("#areaCheckAll").attr("disabled", true);
                            $("#areaCheckOff").attr("disabled", true);
                        } else {
                            $("#areaCheckAll").attr("disabled", false);
                            $("#areaCheckOff").attr("disabled", false);
                        }
                        // 担当エリアのチェック状態を設定
                        var checkedFlg = $('#areCheckedPrent').val();
                        var checkedPrentList = checkedFlg.split(',');
                        var checked = false;
                        for (var i = 0; i < data.listArea.length; i++) {
                            checked = false;
                            for (var j = 0; j < checkedPrentList.length; j++) {
                                if (checkedPrentList[j] == data.listArea[i].strGcCd
                                        + '_' + data.listArea[i].strAreaId) {
                                    checked = true;
                                    break;
                                }
                            }
                            // 担当エリアの明細情報を追加
                            if (checked) {
                                // チェックするレコードを追加
                                var tr =
                                        "<tr>"
                                                + "<td class='text-center' style='width: 50px;'>"
                                                + "<input type='checkbox' checked='true' class='checkitemArea' name='areaCheck'"
                                                + " id='checkitemArea' tabindex='8' prent='"
                                                + data.listArea[i].strGcCd
                                                + '_'
                                                + data.listArea[i].strAreaId
                                                + "'/></td>" + "<td>"
                                                + data.listArea[i].strGcNm
                                                + "</td>" + "<td>"
                                                + data.listArea[i].strAreaNm
                                                + "</td>"
                                "</tr>";
                            } else {
                                // チェックしないレコードを追加
                                var tr =
                                        "<tr>"
                                                + "<td class='text-center' style='width: 50px;'>"
                                                + "<input type='checkbox' class='checkitemArea' name='areaCheck'"
                                                + " id='checkitemArea' tabindex='8' prent='"
                                                + data.listArea[i].strGcCd
                                                + '_'
                                                + data.listArea[i].strAreaId
                                                + "'/></td>" + "<td>"
                                                + data.listArea[i].strGcNm
                                                + "</td>" + "<td>"
                                                + data.listArea[i].strAreaNm
                                                + "</td>"
                                "</tr>";
                            }
                            $("#areaTable").append(tr);
                        }
                    }
                });
    }
});

/**
 * 担当ＧＣの全担当ボタン押下処理.
 */
function gcCheckAll() {

    var checkbox = $(".checkitemGc");
    for (var i = 0; i < checkbox.length; i++) {
        checkbox[i].checked = true;
        this.selectByGcCd(i);
    }
}

/**
 * 担当ＧＣの全取消ボタン押下処理.
 */
function gcCheckOff() {

     var checkbox = $(".checkitemGc");
     for (var i = 0; i < checkbox.length; i++) {
     checkbox[i].checked = false;
     this.selectByGcCd(i);
     }
}

/**
 * 担当エリアの全担当ボタン押下処理.
 */
function areaAllCheck() {

    var checkbox = $(".checkitemArea");
    for (var i = 0; i < checkbox.length; i++) {
        checkbox[i].checked = true;
    }
}

/**
 * 担当エリアの全取消ボタン押下処理.
 */
function areaOffCheck() {

    var checkbox = $(".checkitemArea");
    for (var i = 0; i < checkbox.length; i++) {
        checkbox[i].checked = false;
    }
}

/**
 * 確認ボタン押下処理.
 */
function confirm() {

	if (agentCheck()) {

	    // 担当ＧＣチェックボックス情報を取得
	    var gcCheck = document.getElementsByName("gcCheck");

	    // 担当エリアチェックボックス情報を取得
	    var areaCheck = document.getElementsByName("areaCheck");

	    // 呼び出し元画面の退避情報(担当GC)を作成
	    var gcResults = "";
	    for (var i = 0; i < gcCheck.length; i++) {
	        if (gcCheck[i].checked) {
	            // チェックボックス選択する行
	            var row = gcCheck[i].parentElement.parentElement.rowIndex;
	            if (gcResults == '') {
	                // チェックボックス選択する行のＧＣコード
	                gcResults += listGc[row].strGcCd;
	            } else {
	                gcResults += "," + listGc[row].strGcCd;
	            }
	        }
	    }

	    // 呼び出し元画面の退避情報(担当エリア)を作成
	    var areaResults = "";
	    for (var j = 0; j < areaCheck.length; j++) {
	        if (areaCheck[j].checked) {
	            if (areaResults == '') {
	                // チェックボックス選択する行のコード
	                areaResults += $(areaCheck[j]).attr("prent");
	            } else {
	                areaResults += "," + $(areaCheck[j]).attr("prent");
	            }
	        }
	    }

	    // 作るデータを戻す
	    var retMap = {
	        gcResults : gcResults,
	        areaResults : areaResults
	    };
	    window.returnValue = retMap;

	    // ダイアログを閉じる
	    window.close();
	} else {

		// 担当ＧＣチェックボックス情報を取得
	    var gcCheck = document.getElementsByName("gcCheck");

	    // 担当エリアチェックボックス情報を取得
	    var areaCheck = document.getElementsByName("areaCheck");

	    // 呼び出し元画面の退避情報(担当GC)を作成
	    var gcResults = "";
	    for (var i = 0; i < gcCheck.length; i++) {
	        if (gcCheck[i].checked) {
	            // チェックボックス選択する行
	            var row = gcCheck[i].parentElement.parentElement.rowIndex;
	            if (gcResults == '') {
	                // チェックボックス選択する行のＧＣコード
	                gcResults += listGc[row].strGcCd;
	            } else {
	                gcResults += "," + listGc[row].strGcCd;
	            }
	        }
	    }

	    // 呼び出し元画面の退避情報(担当エリア)を作成
	    var areaResults = "";
	    for (var j = 0; j < areaCheck.length; j++) {
	        if (areaCheck[j].checked) {
	            if (areaResults == '') {
	                // チェックボックス選択する行のコード
	                areaResults += $(areaCheck[j]).attr("prent");
	            } else {
	                areaResults += "," + $(areaCheck[j]).attr("prent");
	            }
	        }
	    }

	    callBackCheck();
	
	    // 作るデータを戻す
	    var rtn = {
	  			selectGcCode : gcResults,
	  			selectAreaCode : areaResults
	 	};
	 	chromeDialogKakutei(rtn, "1");
	}
    return true;
}

/**
 * チェックボックスのクリック処理.
 */
function selectByGcCd(gcFlag) {
	$('#msg2 > li').remove();
	$('#msg2 > div').remove();

    // 担当エリアチェックボックス情報を取得
    var areaCheck = document.getElementsByName("areaCheck");
    var areaResults = "";
    for (var i = 0; i < areaCheck.length; i++) {
        if (areaCheck[i].checked) {
            if (areaResults == '') {
                // チェックボックス選択する行のコード
                areaResults += $(areaCheck[i]).attr("prent");
            } else {
                areaResults += "," + $(areaCheck[i]).attr("prent");
            }
        }
    }
    $('#areCheckedPrent').val(areaResults);

    // 親子チェックボックスの関係を設定
    var gcCheck = document.getElementsByName("gcCheck");
    var checkItem = document.getElementById("checkitem");
    var results = "";
    var sRows = $("input[id='checkitem']");

    // 全部の子チェックボックスを選択された場合、親チェックボックスの状態を確認してほしいです。
    if (sRows[gcFlag].checked) {

        if (listGc[gcFlag].strUpperGcCd == listGc[gcFlag].strGcCd) {
            for (var j = 0; j < listGc.length; j++) {
                if (listGc[gcFlag].strGcCd == listGc[j].strUpperGcCd) {
                    sRows[j].checked = true;
                }
            }
        }
    } else {
        $('#msg2 > li').remove();
        $('#msg2 > div').remove();
        if (listGc[gcFlag].strUpperGcCd == listGc[gcFlag].strGcCd) {
            for (var j = 0; j < listGc.length; j++) {
                if (listGc[gcFlag].strGcCd == listGc[j].strUpperGcCd) {
                    sRows[j].checked = false;
                }
            }
        } else {
            for (var j = 0; j < listGc.length; j++) {
                if (listGc[gcFlag].strUpperGcCd == listGc[j].strGcCd) {
                    sRows[j].checked = false;
                }
            }
        }
    }

    var parent = $("input[parentId='" + listGc[gcFlag].strUpperGcCd + "']");
    var child = $("input[rowId='" + listGc[gcFlag].strUpperGcCd + "']");

    var size = 0;
    $.each(child, function() {

        if (this.checked) {
            size++;
        }
    });

    if (size == child.length && size != 0 && child.length != 0) {
        for (var j = 0; j < listGc.length; j++) {
            if (listGc[gcFlag].strUpperGcCd == listGc[j].strGcCd) {
                sRows[j].checked = true;
            }
        }
    } else if (size != child.length) {
        for (var j = 0; j < listGc.length; j++) {
            if (listGc[gcFlag].strUpperGcCd == listGc[j].strGcCd) {
                sRows[j].checked = false;
            }
        }
    }

    var confimBtnDisabled = false;
    for (var j = 0; j < listGc.length; j++) {
        if (sRows[j].checked) {
            confimBtnDisabled = true;
            break;
        }
    }

    if (confimBtnDisabled) {
        $("#confimBtn").attr("disabled", false);
    } else {
        $("#confimBtn").attr("disabled", true);
    }

    // Jsonパラメータを設定
    for (var i = 0; i < gcCheck.length; i++) {
        if (gcCheck[i].checked) {
            // チェックボックス選択する行
            var row = gcCheck[i].parentElement.parentElement.rowIndex;
            if (results == "") {
                // チェックボックス選択する行のＧＣコード
                results += listGc[row].strGcCd;
            } else {
                results += "," + listGc[row].strGcCd;
            }
        }
    }

    // 担当エリアチェックボックスのチェック状態を設定
    $.ajax({
        url : purl,
        type : "POST",
        datetype : "json",
        data : {
            pstrGcCd : results
        },
        success : function(data) {

            for (var j = 0; j < listGc.length; j++) {
                if (sRows[j].checked == true) {
                    if (data.listArea == null || data.listArea == "") {
                        $('#msg2 > li').remove();
                        $('#msg2 > div').remove();
                        var li = document.createElement("li");
                        li.innerText = '検索結果が０件です';
                        $('#msg2').append(li);
                        $.each($('#msg2 > li'), function() {

                            $(this).addClass('fielderrMsg');
                        });
                    }
                }
            }
            // 明細クリア
            $("#areaTable tr").remove();
            // 全担当/全取消を設定
            if (data.listArea.length == 0) {
                $("#areaCheckAll").attr("disabled", true);
                $("#areaCheckOff").attr("disabled", true);
            } else {
                $("#areaCheckAll").attr("disabled", false);
                $("#areaCheckOff").attr("disabled", false);
            }
            // 担当エリアのチェック状態を設定
            var checkedFlg = $('#areCheckedPrent').val();
            var checkedPrentList = checkedFlg.split(',');
            var checked = false;
            for (var i = 0; i < data.listArea.length; i++) {
                checked = false;
                for (var j = 0; j < checkedPrentList.length; j++) {
                    if (checkedPrentList[j] == data.listArea[i].strGcCd
                            + '_' + data.listArea[i].strAreaId) {
                        checked = true;
                        break;
                    }
                }
                // 担当エリアの明細情報を追加
                if (checked) {
                    // チェックするレコードを追加
                    var tr =
                            "<tr>"
                                    + "<td class='text-center' style='width: 50px;'>"
                                    + "<input type='checkbox' checked='true' class='checkitemArea' name='areaCheck' "
                                    + "id='checkitemArea' tabindex='8' prent='"
                                    + data.listArea[i].strGcCd + '_'
                                    + data.listArea[i].strAreaId
                                    + "'/></td>" + "<td>"
                                    + data.listArea[i].strGcNm
                                    + "</td>" + "<td>"
                                    + data.listArea[i].strAreaNm
                                    + "</td>"
                    "</tr>";
                } else {
                    // チェックしないレコードを追加
                    var tr =
                            "<tr>"
                                    + "<td class='text-center' style='width: 50px;'>"
                                    + "<input type='checkbox' class='checkitemArea' name='areaCheck' "
                                    + "id='checkitemArea' tabindex='8' prent='"
                                    + data.listArea[i].strGcCd + '_'
                                    + data.listArea[i].strAreaId
                                    + "'/></td>" + "<td>"
                                    + data.listArea[i].strGcNm
                                    + "</td>" + "<td>"
                                    + data.listArea[i].strAreaNm
                                    + "</td>"
                    "</tr>";
                }
                $("#areaTable").append(tr);
            }
        }
    });
}

/**
 * 閉じる処理.
 */
function clickClose() {
	if (agentCheck()) {
		window.close();
		return false;
	} else {
		chromeDialogClose();
	}
}