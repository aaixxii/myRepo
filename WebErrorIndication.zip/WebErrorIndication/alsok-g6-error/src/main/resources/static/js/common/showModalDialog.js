/**
 * @fileoverview Chromeでダイアログ画面呼び出す共通処理.
 */
(function() {
	
	function unScroll(){
		var top = $(document).scrollTop();
		$(document).on("scroll.unble",function() {
			$(document).scrollTop(top);
		})
	}
	
	function removeUnScroll(){
		$(document).unbind("scroll.unble");
	}
	

	window.showModalDialog = window.showModalDialog || function(url, arg, opt, callback) {
		
        var top = window.top;
        
        var dialogId = "";
        var iframeId = "";
        var dialogMaxId = findMaxDialog();
        
        if (dialogMaxId == "") {
        	dialogId = "dialog0";
        	iframeId = "dialog-body0";
        } else {
        	var idIndex = dialogMaxId.replace(/dialog/gi, '');
        	var index = parseInt(idIndex) + 1;
        	
        	dialogId = "dialog" + String(index);
        	iframeId = "dialog-body" + String(index);
        }
        
        var urlDemo = url || '';
        var argDemo = arg || null;
        var optDemo = opt || 'height=300px; width=960px;';

        optDemo = opt.replace(/dialogHeight\s*:\s*/gi, '').replace(/dialogWidth\s*:\s*/gi, '').replace(/center:\s*1\s*;\s*/gi, '').replace(/:\s*/gi, '').replace(/px/gi, '');

        var size = optDemo.split(';');

        var dialog = top.document.body.appendChild(document.createElement('div'));
        dialog.setAttribute('id', dialogId);
        dialog.setAttribute('name', 'dialog');
        dialog.setAttribute('style', 'padding:1px;overflow:hidden;');

        parent.$('#' + dialogId).dialog({
        	title:'',
        	height:parseInt(size[0]),
        	width:parseInt(size[1]),
            modal: true,
            closeOnEscape: false,
            open : function() {
            	unScroll();
            	parent.$('#' + dialogId).append("<iframe id='" + iframeId + "' src='" + url + "' style='border: 0; width: 100%; height: 100%;'></iframe>");
            	parent.document.getElementById(iframeId).contentWindow.dialogArguments = arg;
            	parent.window.dialogArguments = arg;
            },
            close: function(event, ui) {
            	parent.$('#' + dialogId).remove();
            	
            	var iframeMaeId = findGenIframe();
            	var checkCallBackFlg = "";
            	
            	if (iframeMaeId != "") {
            		checkCallBackFlg = $(parent.$('#' + iframeMaeId).contents()).find('#callBackFlg').val();
            	} else {
            		checkCallBackFlg = $('#callBackFlg').val();
            	}
            	
            	if (typeof callback === 'function' && checkCallBackFlg == "1") {
            		parent.$('#callBackFlg').val("");
            		callback();
            	}
            	removeUnScroll();
            }
        });
        
        parent.$('#' + iframeId).on('load',function() {
        	$(top.document).find("div[aria-describedby=" + dialogId + "]").find('span[class=ui-dialog-title]').html(parent.$('#' + iframeId).contents().attr("title"));
        });

	};

})();

function chromeDialogClose() {
	var dialogMaxId = findMaxDialog();
	parent.$('#' + dialogMaxId).dialog("close");
	$(window.parent.document.getElementById(dialogMaxId)).remove();
}


function chromeDialogKakutei(returnValue, closeKbn) {

	var dailogMaxId = findMaxDialog();
	
	if (dailogMaxId == "dialog0") {
		for (var rtn in returnValue) {
			var setLab = parent.$('#'+rtn);
			if (typeof setLab !== "undefined") {
				$(setLab).val(returnValue[rtn]);
			}
		}
	} else {
        var iframeId = findMaeIframe();
		
        if (iframeId != "") {
    		for (var rtn in returnValue) {
    			var setLab = $(parent.$('#' + iframeId).contents()).find("#"+rtn);
    			
    			if (typeof setLab !== "undefined") {
    				$(setLab).val(returnValue[rtn]);
    			}
    		}
        } else {
        	for (var rtn in returnValue) {
        		var setLab = parent.$('#'+rtn);
        		if (typeof setLab !== "undefined") {
        			$(setLab).val(returnValue[rtn]);
        		}
        	}
        }
	}

	if (closeKbn == "1") {
		var dialogMaxId = findMaxDialog();
		parent.$('#' + dialogMaxId).dialog("close");
		$(window.parent.document.getElementById(dialogMaxId)).remove();
	}
}

function callBackCheck() {
	var iframeId = findMaeIframe();
	
	if (iframeId != "") {
		$(parent.$('#' + iframeId).contents()).find('#callBackFlg').val('1');
	} else {
		parent.$('#callBackFlg').val('1');
	}
}

function findMaxDialog() {
	var top = window.top;
	var dialogList = $(top.document.body).find('div[name=dialog]');
	
	var dialogId = "";
	
	if (dialogList != null && typeof dialogList !== "undefined") {
		$(dialogList).each(function() {
			if (dialogId == "") {
				dialogId = $(this).attr('id');
				return;
			}
			
			var idIndex1 = dialogId.replace(/dialog/gi, '');
			var idIndex2 = $(this).attr('id').replace(/dialog/gi, '');
			
			if (idIndex2 > idIndex1) {
				dialogId = $(this).attr('id');
			}
		});
	}
	return dialogId;
}

function findMaeIframe() {
    var dialogMaxId = findMaxDialog();
    var iframeId = "";
    
    if (dialogMaxId != "dialog0") {
        var idIndex = dialogMaxId.replace(/dialog/gi, '');
        var index = parseInt(idIndex) - 1;
        
        var iframeId = "dialog-body" + String(index);
    }
    return iframeId
}

function findGenIframe() {
    var dialogMaxId = findMaxDialog();
    var iframeId = "";
    
    if (dialogMaxId != "") {
        var idIndex = dialogMaxId.replace(/dialog/gi, '');
        var index = parseInt(idIndex);
        
        iframeId = "dialog-body" + String(index);
    }
    
    return iframeId;
}