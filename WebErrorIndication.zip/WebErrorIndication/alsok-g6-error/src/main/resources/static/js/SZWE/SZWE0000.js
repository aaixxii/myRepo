﻿//====================================================================
//              COPYRIGHT (C) 2015-2016  NEC CORPORATION
//                 NEC  CONFIDENTIAL AND PROPRIETARY
//====================================================================
// 【ファイル名】SZWE0000.js
//
// 【機　能　名】SZWE0000_エラー表示ＣＬメイン画面
//
//====================================================================
// 【作　成　者】日本電気株式会社　　2018/06/21
// 【修　正　者】
//====================================================================

/**
 * コンボボックスChangeイベント処理.
 */
function selChange() {
	if (typeof $('.ui-widget-overlay')[0] === 'undefined') {
	    var form = $("form").attr("method", "post").attr("action", changeErrorKunbunUrl);
	    form.submit();
	}
}

/**
 * GC絞込ボタンクリックイベント処理.
 */
function callTantoGcFrame() {

	// 移送先画面のURL設定
	var params = new Array;
	params["url"] = dialogSubmitUrl300;
	params["selectGcCode"] = document.getElementById("selectGcCode").value;
	params["selectAreaCode"] = document.getElementById("selectAreaCode").value;

	if (agentCheck()) {
		var rtn = window.showModalDialog(dialogUrl, params,
		"dialogHeight: 600px; dialogWidth: 960px; center: 1;");
		
		if (rtn != null || typeof rtn !== 'undefined') {

			document.getElementById("selectGcCode").value = rtn.gcResults;
			document.getElementById("selectAreaCode").value = rtn.areaResults;

			var form = $("form").attr("method", "post").attr("action", changeErrorKunbunUrl);
			form.submit();
		}
	} else {
		$('#callBackFlg').val("1");
		window.showModalDialog(dialogUrl, params, "dialogHeight: 600px; dialogWidth: 960px; center: 1;",
				callTantoGcFrameCallBack);
	}
	playBeep(true);
}

function callTantoGcFrameCallBack() {
	
	var callBackFlg = $('#callBackFlg').val();
	
	if (callBackFlg == "1") {
		init();
	} else {
		var form = $("form").attr("method", "post").attr("action", changeErrorKunbunUrl);
		form.submit();
	}
}

/**
 * 明細クリックイベントイベント処理.
 */
$(function() {

    // 一覧クリックダブルクリック
    $('#errorList tr').dblclick(function() {

        // 選択行のコードと名称をパラメータ設定
        var row = $(this)[0].rowIndex;

        var params = new Array;
        var query = new Array;

        // 移送先画面にパラメータの移送
        // 受信日時
        query["rcvTs"] = list[row].rcvTs;

        // 発生時刻
        query["hasseiTs"] = list[row].hasseiTs;

        // GC番号
        query["gcNum"] = list[row].gcNum;

        // GC名
        query["gcNm"] = list[row].gcNm;

        // ホスト名
        query["hostNm"] = list[row].hostNm;

        // 処理ID
        query["syoriId"] = list[row].syoriId;

        // エラーID
        query["errId"] = list[row].errId;

        // 電計番号
        query["denkei"] = list[row].denkei;

        // 号機番号
        query["gouki"] = list[row].gouki;

        // 地区番号 */
        query["chikuNum"] = list[row].chikuNum;

        // 装置番号
        query["devNum"] = list[row].devNum;

        // エラーレベル
        query["errLvl"] = list[row].errLvl;

        // エラー名称
        query["errNm"] = list[row].errNm;

        // 対処名称
        query["recoverMsgNm"] = list[row].recoverMsgNm;

        // 備考
        query["bikou"] = list[row].bikou;

        params["query"] = query;

        // 移送先画面のURL設定
        params["url"] = dialogSubmitUrl200;

        if (agentCheck()) {
            window.showModalDialog(dialogUrl, params,
            "dialogHeight: 500px; dialogWidth: 960px; center: 1;");
        } else {
        	$('#callBackFlg').val("1");
            window.showModalDialog(dialogUrl, params,
            "dialogHeight: 500px; dialogWidth: 960px; center: 1;", init);
        }

    });
});

/**
 * 検索ボタンクリック処理.
 */
function callErrorSearchFrame() {

    var params = new Array;
    var query = new Array;

    // GCコードを移送する
    query["selectGcCode"] = document.getElementById("selectGcCode").value;
    params["query"] = query;

    // 移送先画面のURL設定
    params["url"] = dialogSubmitUrl100;

    if (agentCheck()) {
        window.showModalDialog(dialogUrl, params,
            "dialogHeight: 600px; dialogWidth: 960px; center: 1;");
    } else {
        $('#callBackFlg').val("1");
        window.showModalDialog(dialogUrl, params,
            "dialogHeight: 600px; dialogWidth: 960px; center: 1;", init);
    }
}

/**
 * 初期化処理.
 */
function init() {
	var buzzStatus = $('#buzzStatus').val();

	if (buzzStatus && buzzStatus == "ON"){
		$("#btnBuzz").removeClass("text-danger");
		if ( $('#newDataFlg').val() == "1"){
			playBeep(false);
		}
	} else {
		$("#btnBuzz").addClass("text-danger");
		playBeep(true);
	}
    window.setTimeout("selChange()", $('#tegetTimer').val());
}

/**
 * 閉じる処理.
 */
function clickClose() {
	
	if (agentCheck()) {
		window.close();
		return false;
	} else {
		window.open('about:blank', '_parent', '');
	}
}

/**
 * ブザーの鳴動実行
 * 
 * @param stop
 *            実行フラグ
 */
function playBeep(stop) {
	//var auBeep = $("#auBeep");
	var auBeep = document.getElementById("auBeep");
	if (stop) {
		auBeep.pause();
	} else {
		auBeep.play();
	}
}

/**
 * URI取得
 * @param openUri uri
 * @return 編集後URI
 * */
function getUrl(openUri) {
	var contextPath = $('meta[name=context-path]').attr("content");
	openUri = contextPath.substr(0, contextPath.length - 1) + openUri;
	return openUri;
}

/**
 * ブザーの鳴動ON/OFF制御
 * 
 * @param result
 *            制御結果
 */
function doBuzz() {

	var requestConf = {};
	var data = {};
	requestConf.type = 'GET';
	requestConf.url = getUrl('/SZWE0000/buzz');
	requestConf.dataType = 'json';
	var buzzStatus = $('#buzzStatus').val();
	if (buzzStatus) {
		data = {"buzzStatus":buzzStatus};
	} else {
		data = {"buzzStatus":"OFF"};
	}

	requestConf.data = data;
	$.ajax(requestConf).done(function(result, textStatus, jqXHR) {
		// ブザー鳴動チェック
		if (result.buzzStatus == "OFF") {
			buzzStatus = "OFF";
			
			// 設定ボタンの文字色を赤色に設定する
			$("#btnBuzz").addClass("text-danger");
			$('#newDataFlg').val("0")
			playBeep(true);
		} else {
			buzzStatus = "ON";
			$("#btnBuzz").removeClass("text-danger");

		}
		$('#buzzStatus').val(buzzStatus) ;
		//ブザー鳴動実装
		//playBeep(stop);
	})
}