jQuery(function($){
	$.datepicker.regional['ja'] = {
		closeText: '閉じる',
		prevText: '&#x3c;前',
		nextText: '次&#x3e;',
		currentText: '今日',
		monthNames: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'],
		monthNamesShort: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'],
		dayNames: ['日曜日','月曜日','火曜日','水曜日','木曜日','金曜日','土曜日'],
		dayNamesShort: ['日','月','火','水','木','金','土'],
		dayNamesMin: ['日','月','火','水','木','金','土'],
		dateFormat: 'yy/mm/dd',
		firstDay: 0,
		isRTL: false,
		yearSuffix: '年',
		showMonthAfterYear: true
	};
	$.datepicker.setDefaults($.datepicker.regional['ja']);
});

$( function(){

	//Datepickerの初期設定はデフォルト
    $.datepicker.setDefaults( $.datepicker.regional[ "ja" ] );
    
    //Datepickerの設定
    $(".datepicker").datepicker(
        {   showOn: "button"           //カレンダ表示イベント｢ focus：テキスト選択時 ｣｢ button：アイコンクリック時 ｣｢ both：両方 ｣
        ,   duration: 100              //カレンダーの表示タイミング、ミリ秒指定、または｢ Fast ｣｢ slow ｣｢ normal ｣
        ,   buttonImageOnly: true      //画像表示設定｢ true：画像のみ ｣｢ false：ボタン上に画像表示 ｣
        ,   buttonImage: "../img/date.png"   //カレンダアイコン画像設定、相対パス
        ,   beforeShow: function() {
                $("#ui-datepicker-div").css( "font-size", "80%" );
            }
        ,   onClose : function(date) {              //クローズ時に、別テキストに設定
                $("#datepicker_getVal_getFormat").val( "" );
                if ( date.length > 0 ) {
                    $("#datepicker_getVal_getFormat").val( date + " , " + $(".datepicker").datepicker( "option", "dateFormat" ) );
                    $(this).focus();
                }
            }
        }
    );
});
