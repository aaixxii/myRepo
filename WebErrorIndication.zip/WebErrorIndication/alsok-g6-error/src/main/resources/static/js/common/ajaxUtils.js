/**
 * @fileoverview 画面項目のfocus制御に係る共通処理.
 */

/**
 * 画面項目のfocus制御に係る共通処理.
 */
;(function (global) {

var ajaxUtils = {}; // ajaxユーティリティオブジェクト

/**
 * コードを基に、名称テキストボックスに値を設定する.
 * @param {Object} data リクエストデータ
 * @param {String} url リクエスト先
 * @param {Object} [ids] 検索結果の名所を設定する要素IDの連想配列{id: jsonプロパティ}
 * @param {String} [errMsg] 検索結果が0件または異常終了時の表示メッセージ
 * @param {function} [doneCallback] ajax正常終了時callback関数
 * @param {function} [failCallback] ajax異常終了時callback関数
 * @param {function} [alwaysCallback] ajax了時のcallback関数(正常、異常共通)
 */
ajaxUtils.searchWithCode = function (data, url, ids, errMsg, doneCallback, failCallback, alwaysCallback) {
	var requestConf = {};
	requestConf.type = 'POST';
	requestConf.url = url;
	requestConf.dataType = 'json';
	requestConf.data = data || {};


	// 取得前に値をクリア
	Object.keys(ids).forEach(function (key) {
		$('#' + key).val('');
	});

	$.ajax(
		requestConf
	).done(function (json, textStatus, jqXHR) {
		if (typeof doneCallback === 'function') {
			doneCallback(json, textStatus, jqXHR)
		} else {
			// 検索結果エラー処理
			if (json.status.toLowerCase() !== 'success') {
				if (errMsg && 0 < errMsg.length) {
					alert(errMsg);
				}
				return;
			}

			// 正常処理
			Object.keys(ids).forEach(function (key) {
				$('#' + key).val(json.data[ids[key]]);
			});
		}

	}).fail(function (jqXHR, textStatus, errorThrown) {
		// エラー処理
		if (typeof failCallback === 'function') {
			failCallback(jqXHR, textStatus, errorThrown);
		}

	}).always(function () {
		// エラー処理
		if (typeof alwaysCallback === 'function') {
			alwaysCallback(arguments[0], arguments[1], arguments[2]);
		}
	});
}



if (global === window) {
	global.ajaxUtils = ajaxUtils;
}

return ajaxUtils;

})( typeof window !== "undefined" ? window : this);

