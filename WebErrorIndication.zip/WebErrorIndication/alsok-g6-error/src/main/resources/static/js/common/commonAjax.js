/**
 * Formのデータをまとめて送信
 *
 * @param 対象FormのID
 * @param Form以外の追加データ
 * @param 非同期通信フラグ
 */
function sendFormAjax(formId, successFunc, jsonData, flg) {
	var sendData = ($(formId).serializeArray());
	if (typeof jsonData !== 'undefined') {
		sendData = sendData.concat(jsonData);
	}

	// 特に指定の無い場合は非同期通信に設定
	if (flg !== false)
		flg = true;
	$.ajax({
		type : 'POST',
		url : $(formId).attr("action"),
		async : flg,
		cache : false,
		dataType : 'json',
		data : sendData,
		success : function(httpObj, dataType) {
			successFunc(httpObj, dataType);
		},

		error : function(httpObj, dataType) {
			alert("通信エラーが発生しました");
		}
	});
}