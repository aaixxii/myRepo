
// 初期処理
// 要素内のクリックされた位置を取得するグローバル変数
var x;
var y;

// drop先の位置
var moveX;
var moveY;

// 回転角度(初期表示時0)
var chgAngle = 0;

// 初期表示時のみtrue(親ID判定時に使用する)
var onloadFlg = true;

/**
 * 画面ロード時に各種イベントリスナーを設定する。
 *
 */

$(function imgMove(){

  // イベントリスナ設定処理を呼び出す。
  setEventDragAndDrop();

});

/**
 * 各種イベントリスナーを設定する処理。
 *
 */

function setEventDragAndDrop(){

  // 読み込み処理フラグをONにする
  onloadFlg = true;

  // 編集領域(canvas)と移動可能画像格納領域(layerlist)を取得
  var canvas = document.getElementById("canvas");
  var layerlist = document.getElementById("layerlist");

  //要素の取得
  var elements = document.getElementsByClassName("movelayer");

  // iconの移動イベントの契機をクリックかタッチに指定
  $(document).on("mousedown", ".movelayer", checkClickBtn);

  //canvas内で行う画像移動処理の設定
  $(document).on("dragstart", ".movelayer", function(evt) {

    // つかんでいる要素にclass"drag"を設定
    $(evt.currentTarget).addClass("dragnow");

    x = evt.offsetX ;
    y = evt.offsetY ;

  });

  //dragendイベントのリスナーを設定
  $(document).on("dragend", ".movelayer", function(evt) {

    // つかんでいる要素からclass"drag"を除去
    $(evt.currentTarget).removeClass("dragnow");

  });

  // 画像回転処理を行う
  for(var i = 0; i < elements.length; i++) {

      elements[i].draggable = true;

      // 初期表示時にアイコン回転
      // roteteをclassに追加
      $(elements[i]).addClass("rotate");
      imgRotate(elements[i]);
  }

  // dropイベントのリスナーを設定
  canvas.addEventListener('drop', function(evt) {

    var target = document.getElementsByClassName("dragnow")[0];

    // 取得できない場合は処理終了
    if(!target) return false;

    var labelname = target.getElementsByClassName("labelname")[0];

    var cureentTarget = document.getElementById("layer0").getBoundingClientRect();

    // 【機能拡張】画像合成領域を取得
    var canvascapture = document.getElementById("canvascapture");

    var parentFlg = checkElementId(target.parentNode);

    // parentFlgがtrueならcanvas=>canvasの移動。falseならlayerlist=>canvasの移動。
    // undefinedなら関係ないところからの移動なので処理しない。
    if(parentFlg == true){
        // 落とした位置情報をセットしてドロップ要素を配置
        target.style.left = evt.clientX - cureentTarget.left - x + "px";
        target.style.top = evt.clientY - cureentTarget.top - labelname.clientHeight - y + "px";
    } else if(parentFlg == false) {
        // 落とした位置情報をセットしてドロップ要素をcanvasかcanvascaptureに追加
        target.style.left = evt.clientX - cureentTarget.left - x + "px";
        target.style.top = evt.clientY - cureentTarget.top - labelname.clientHeight - y + "px";

        if(canvascapture){
        	// canvascaptureがある場合、canvascaptureに追加
        	canvascapture.appendChild(target);
        } else {
        	// canvascaptureがない場合はcanvasに追加
        	canvas.appendChild(target);
        }


    }

    evt.preventDefault();


  }, false);

  // canvasとlayerlistに相互間で画像を移動するためのイベントリスナーを設定
  // 基本動作抑制のイベントリスナーを設定
  canvas.addEventListener('dragover', function(evt) {
      //drop処理の基本動作を抑制
      evt.preventDefault();
  }, false)
  layerlist.addEventListener('dragover', function(evt) {
      //drop処理の基本動作を抑制
      evt.preventDefault();
  }, false)

  // 画面上に表示されているmovelayerをcanvas<=>layerlist間で移動できるようにする。
  layerlist.addEventListener('drop', function(evt) {
     var target = document.getElementsByClassName("dragnow")[0];

     var canvasFlg = checkElementId(target.parentNode);

     // 移動中の要素の親が"canvas"のときだけ移動する。
     if(canvasFlg){
         // layerlistに追加する前にclass"rotate"を追加
         $(target).addClass("rotate");
         //dragのHTMLをlayerlistに追加
         layerlist.appendChild(target);
         // layerlistに追加した後に回転角度をリセット
         imgRotate(target);
     }

  }, false);


  // 画面のhidden項目から回転角度を取得
  var addAngle = document.getElementById("addangle");
  // 回転角度を設定。
  chgAngle = Number(addAngle.textContent);

  // onloadFlgをfalseに切り替える。
  onloadFlg = false;

}

/**
 * マウスが押された際に右クリックかどうかを判定するメソッド
 *
 * 画像回転処理:checkClickBtnメソッド => imgRotateメソッド
 *
 * @param {Element} e 発火元要素
 *
 */
function checkClickBtn(e) {

    // 右クリックか判定
    if(e.button == 2){
        // 右クリックの場合、画像回転処理を開始
        $(this).addClass("rotate");
        imgRotate(e);
    }
}

/**
 * 画像回転処理
 *
 * 発火元要素の親要素のID"canvas"の場合、画像回転処理を行う。
 *
 * メソッドを呼ぶ直前に対象の要素にclass"rotate"を追加している。
 * 回転処理が終わるとclass"rotate"は除去される。
 *
 * ロード中はcanvas領域以外も回転するが、canvas領域以外のアングルは0になっている想定。
 *
 * @param {Element} e 発火元要素
 */
function imgRotate(e) {

	if(!onloadFlg){
        // 画面のhidden項目から回転角度を取得
        addAngle = document.getElementById("addangle");
        chgAngle = Number(addAngle.textContent);

	}
    // class"rotate"を追加した要素を取得
    var rotate = document.getElementsByClassName("rotate")[0];

    // 親要素ID判定(ロード中は親要素を取得できないため判定を行わない。)
    var parentFlg = onloadFlg ? true : checkElementId(rotate.parentNode);

    var img = rotate.getElementsByClassName("layerimg")[0];

    // hidden項目を取得
    var angleDiv = rotate.getElementsByClassName("angle")[0];

    // hidden項目から現在の回転角度を取得
    var angle = Number(angleDiv.textContent);

    // 読み込み時どうか判定して、読み込み時でないなら角度加算処理を行う
    if(!onloadFlg) {
      // プロパティから取得した回転角度を現在の回転角度に加算
      angle = angle + chgAngle;
    }

    // 1回転した場合か親要素がcanvasでないなら、回転角度をリセット
    if(angle == 360 || !parentFlg){
        angle = 0;
    }

    // transformの値を変更。主要系OSのtransformプロパティにも同値を設定。
    img.style.webkitTransform = "rotate("+ angle +"deg)";
    img.style.mozTransform = "rotate("+ angle +"deg)";
    img.style.msTransform = "rotate("+ angle +"deg)";
    img.style.transform = "rotate("+ angle +"deg)";

    //hidden項目の値を更新
    angleDiv.innerText = angle;

    // 発生元の右クリック時に出るメニューの出現を抑制(要件には特に指定なし。要らないなら消す。)
    rotate.oncontextmenu = function () { return false; };

    //クラス名 .rotate も消す
    $(rotate).removeClass("rotate");

}

/**
 * 要素ID判定
 *
 * 要素のIDが"canvas"か"layerlist"かを判定する。
 * 関係のないIDだとコンソールにメッセージを出す。
 *
 * @param {Element.parentNode} parent 判定を行いたい要素
 * @return {boolean} true:#canvas, #canvascapture; false:#layerlist;
 * @return {undefined} undefined 要素のIDが想定していない値の時に返す。
 */
function checkElementId(parent) {

    // 発火元の親要素からIDを取得
    var parentId = parent.id;

    // 親要素IDに対応したbooleanを返す。想定していないIDの場合、undefinedを返す。
    switch(parentId) {

        case "canvas":
        console.log("canvas");
        return true;
        break;

        case "canvascapture":
        console.log("canvascapture");
        return true;
        break;

        case "layerlist":
        console.log("layerlist");
        return false;
        break;

        default:
        console.log("関係ない。");
        return void 0;// どちらでもないときは未定義で返す。
        break;

    }

}

/* 拡大縮小処理関係 */

// 拡大縮小比率(初期値:1)
var scale = 1;

// 等倍時の縦幅、横幅を退避する変数
var imgWidth = 0;
var imgHeight = 0;

/**
 * 拡大縮小処理(判定部分)
 * 引数として送られてきたid属性で拡大縮小を判定する。
 * buttonのonclickから呼び出す。
 *
 * @param {String} onclick側のid要素
 * @return {boolean} 拡大縮小を行わない場合にreturnの値としてfalseを返す。
 */
function imgScaling(id) {

    // 最下層レイヤーのdivとimgを取得
    var targetDiv = document.getElementById("layer0");
    var targetImg = document.getElementById("layerbase");

    // キャプチャ用divを取得
    var targetCap = document.getElementById("canvascapture");

    // 初回呼び出し時に拡大比率等倍時の値を退避
    // サイズはimgから取得する(ブラウザによって自動でmarginやpaddingが発生する場合があるため)
    if(imgWidth == 0 && imgHeight == 0) {
        imgWidth = targetImg.clientWidth;
        imgHeight = targetImg.clientHeight;
    }

    // onclickされた要素のIDで処理終了とscaleの加減の判定を行う
    if(id == 'scaleup'){

        // 拡大で倍率が2の場合、処理終了
        if(scale == 2) {
             return false;
        }

        // 倍率+25%
        scale = scale + 0.25;

    } else if (id == 'scaledown') {

        // 縮小で倍率が0.5の場合、処理終了
        if(scale == 0.5) {
             return false;
        }

        // 倍率-25%
        scale = scale - 0.25;

    }

    // 退避させた等倍時の幅と高さにscaleを掛けた値を設定
    var changeWidthPx = (imgWidth * scale) + "px";
    var changeHeightPx = (imgHeight * scale) + "px";

    // キャプチャ用divと下地格納divとimgのwidthとheightを変更

    targetCap.style.width = changeWidthPx;
    targetCap.style.height = changeHeightPx;

    targetDiv.style.width = changeWidthPx;
    targetDiv.style.height = changeHeightPx;

    targetImg.style.width = changeWidthPx;
    targetImg.style.height = changeHeightPx;

}

/* ラベル名表示／非表示切り替え処理関係 */

// 非表示フラグ(true:非表示、false:表示)
var hiddenFlg = false;
// visibilityの設定値(初期値:表示)
var proparty = 'visible';

/**
 * ラベル名の表示切替
 * class"labelname"のvisibility属性を切り替える
 *
 * @param なし
 */
function imgLabelChangeHidden() {
    // class属性"labelname"の要素をすべて取得
    var elements = document.getElementsByClassName("labelname");

    // hiddenFlgの状態を切り替える
    if(hiddenFlg){
       hiddenFlg = false;
       proparty = 'visible';
    } else {
       hiddenFlg = true;
       proparty = 'hidden';
    }

    for(var i = 0; i < elements.length; i++) {
        // visibilityの変更
        elements[i].style.visibility = proparty;
    }

}

/* 編集データを加工しやすいようにまとめる処理 */

/**
 * canvas上に乗っているlayerデータを収集する
 * 取得するのは画面上の位置(x軸/y軸)、設置機器情報、回転角度の値の4つ
 *
 * @param なし
 * @return {JSON} editData JSON形式の配列 positionX(X軸)、positionY(Y軸)、lnDev(LN_設置機器論理番号)、angle(アングル)
 */
function getImgEditData() {

	var movelayers = canvas.getElementsByClassName("movelayer");

	// 配列が格納される変数
	var editData = [];

	// 格納される配列用の変数
	var setData = {};

	// 配列にセットする変数
	var xPx;
	var x;
	var yPx;
	var y;
	var hiddenData;
	var inDev;
	var angleDiv;
	var angle;

    // canvas上のmovelayerの各種データで配列を生成
    for(var i = 0; i < movelayers.length; i++) {

    	// x軸とy軸の値(DBに入る値がintのため四捨五入)
    	xPx = movelayers[i].style.left;
    	xPx = xPx.replace("px", "");
    	x = Number(xPx);
    	x = Math.round(x);

    	yPx = movelayers[i].style.top;
    	yPx = yPx.replace("px", "");
    	y = Number(yPx);
    	y = Math.round(y);

    	hiddenData = movelayers[i].getElementsByClassName("hidden00")[0];
    	inDev = hiddenData.textContent;

        // hidden項目を取得
        angleDiv = movelayers[i].getElementsByClassName("angle")[0];

        // hidden項目から現在の回転角度を取得
        angle = Number(angleDiv.textContent);

        setData = { positionX : x , positionY : y , lnDev : inDev , angle : angle };

        editData.push(setData);


    }

    return editData;

}
