//========================================================================
//            COPYRIGHT  (C)  2015-2016  NEC  CORPORATION
//               NEC  CONFIDENTIAL  AND  PROPRIETARY
//========================================================================
//  【ファイル名】    SZWE0100.js
//
//  【機能名】       SZWE0100_エラー表示ＣＬ検索画面
//
//========================================================================
//  【作成者】       日本電気株式会社        2018/06/26
//  【修正名】
//========================================================================

/**
 * 明細ダブルクリック処理.
 */
$(function() {

    // 一覧クリックダブルクリック
    $('#errorList tr').dblclick(function() {

        // 選択行のコードと名称を、hideenに設定
        var row = $(this)[0].rowIndex;

        var params = new Array;
        var query = new Array;

        // 移送先画面にパラメータの移送
        // 受信日時
        query["rcvTs"] = list[row].rcvTs;

        // 発生時刻
        query["hasseiTs"] = list[row].hasseiTs;

        // GC番号
        query["gcNum"] = list[row].gcNum;

        // GC名
        query["gcNm"] = list[row].gcNm;

        // ホスト名
        query["hostNm"] = list[row].hostNm;

        // 処理ID
        query["syoriId"] = list[row].syoriId;

        // エラーID
        query["errId"] = list[row].errId;

        // 電計番号
        query["denkei"] = list[row].denkei;

        // 号機番号
        query["gouki"] = list[row].gouki;

        // 地区番号 */
        query["chikuNum"] = list[row].chikuNum;

        // 装置番号
        query["devNum"] = list[row].devNum;

        // エラーレベル
        query["errLvl"] = list[row].errLvl;

        // エラー名称
        query["errNm"] = list[row].errNm;

        // 対処名称
        query["recoverMsgNm"] = list[row].recoverMsgNm;

        // 備考
        query["bikou"] = list[row].bikou;

        params["query"] = query;

        // 移送先画面のURL設定
        params["url"] = dialogSubmitUrl200;

        window.showModalDialog(dialogUrl, params,
                "dialogHeight: 500px; dialogWidth: 960px; center: 1;");
    });
});

/**
 * 検索ボタン押下処理.
 */
function onSearch() {
    var form = $("form").attr("method", "post").attr("action",
            searchUrl);

    form.submit();
}

/**
 * 閉じる処理.
 */
function clickClose() {
	if (agentCheck()) {
		window.close();
		return false;
	} else {
		chromeDialogClose();
	}
}
