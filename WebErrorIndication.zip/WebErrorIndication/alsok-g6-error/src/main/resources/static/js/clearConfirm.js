function clearConfirm(){
    var result = confirm("警備先管理者情報の初期化を行います。よろしいですか？");

    if (result) {
        location.href='GAP-03-011_GS_警備先詳細情報画面(初期化).html';
    }
}
