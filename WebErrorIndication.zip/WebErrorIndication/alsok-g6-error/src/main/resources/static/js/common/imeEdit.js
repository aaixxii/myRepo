/**
 * @fileoverview ChromeでIME共通処理.
 */
(function(global) {

	if (!agentCheck()) {
		var ImeEdit = {};
		
		var numVal = "";
		
		var beforeVal = "";
		
		var startIndex = 0;
		
		var selection = "";
		
		var enterkeycode = "";
		
		ImeEdit.editValue = function() {
			
			$('.inputMode_ime_disabled').each(function() {
				
				var reg = new RegExp(/[^ -~｡-ﾟ]+/);
				var type = $(this).attr('type') || "text";
				
				if (type.toUpperCase() != "NUMBER") {
					
					$(this).keydown(function() {
						startIndex = this.selectionStart || 0;
						selection = document.getSelection().toString() || "";
						numVal = "";
						enterkeycode = "";
						if (global.event.keyCode == "229") {
								numVal = $(this).val();
								enterkeycode = "229";
						}
						beforeVal = $(this).val();
					});
					
					$(this).mouseup(function() {
						startIndex = this.selectionStart || 0;
						selection = document.getSelection().toString() || "";
					});
					$(this).mouseout(function() {
						startIndex = this.selectionStart || 0;
						selection = document.getSelection().toString() || "";
					});
					
					$(this).bind('input', function() {
						var maxLength = $(this).attr('maxlength');
						if (maxLength != "-1") {
							if (selection.length == 0) {
								if(global.event.data != null && beforeVal.length >= maxLength){
									$(this).val(beforeVal);
									if (window.FocusControl) {
										
										window.FocusControl.keyPressed = true;
										window.FocusControl.nextFocus(global.event);
									}
									return;
							    }
							}
						}
						
						var val = "";
						
						if ((global.event.data != null && reg.test(global.event.data))
								|| (global.event.data != null && enterkeycode == "229")) {
							
							var hankakuSuji = toHankakuSuji(global.event.data);
							if (hankakuSuji != "") {
								var damiStrMae = numVal.substr(0, startIndex);
								var damiStrGo = numVal.substr(startIndex + selection.length, numVal.length - 1);
								
								val = damiStrMae + toHankakuSuji(global.event.data) + damiStrGo;
							} else {
								val = numVal;
							}
							
							if (maxLength != "-1") {
								if(val.length > maxLength){
									val = val.substring(0,maxLength);
							    }
							}
							$(this).val("");
							$(this).val(val.replace(reg , ''));
							
							if (hankakuSuji != "") {
								this.setSelectionRange(startIndex + 1, startIndex + 1);
							} else {
								this.setSelectionRange(startIndex, startIndex);
							}
							
						}
						if (window.FocusControl) {
							window.FocusControl.keyPressed = true;
							window.FocusControl.nextFocus(global.event);
						}
					});
				} else {
					$(this).keydown(function() {
						enterkeycode = "";
						if (global.event.keyCode == "8") {
							enterkeycode = "8";
							return;
						}
						if (global.event.keyCode == "38"
							|| global.event.keyCode == "40") {
							
							global.event.returnValue = false;
							return;
						}
						numVal = "";
						
						var numreg = new RegExp(/\d+/);
						if (global.event.keyCode == "229"
							|| !numreg.test(global.event.data)) {
								numVal = $(this).val();
								enterkeycode = "229";
						}
						beforeVal = $(this).val();
						selection = document.getSelection().toString() || "";
					});
					
					$(this).mouseup(function() {
						selection = document.getSelection().toString() || "";
					});
					$(this).mouseout(function() {
						selection = document.getSelection().toString() || "";
					});
					
					$(this).bind('input', function() {
						if (enterkeycode == "8") {
							return;
						}
						
						var maxLength = $(this).attr('maxlength');
						if (maxLength != "-1") {
							if (selection.length == 0) {
								if(global.event.data != null && beforeVal.length >= maxLength){
									$(this).val(beforeVal);
									
									if (window.FocusControl) {
										window.FocusControl.keyPressed = true;
										window.FocusControl.nextFocus(global.event);
									}

									return;
							    }
							}
						}
						
						var maxLength = $(this).attr('maxlength');
						
						if (maxLength == numVal.length) {
							$(this).val("");
							numVal = "";
						}
						
						var val = "";
						var numreg = new RegExp(/\d+/);
						if (global.event.data != null && !numreg.test(global.event.data)
								|| (global.event.data != null && enterkeycode == "229")) {
							
							val = numVal + toHankakuSuji(global.event.data);
							
							if (maxLength != "-1") {
								if(val.length > maxLength){
									val = val.substring(0,maxLength);
							    }
							}
							$(this).val("");
							$(this).val(val.replace(reg , ''));
							
						}
						if (window.FocusControl) {
							window.FocusControl.keyPressed = true;
							window.FocusControl.nextFocus(global.event);
						}

					});
				}
			});
		};
		
		if (global === window) {
			  global.ImeEdit = ImeEdit;
		}
		
		function toHankakuSuji(str) {
			var hankakuSuji = "";
			for (var i = 0; i < str.length; i++) {
				if (str.charCodeAt(i) > 65248 && str.charCodeAt(i) < 65375) {
					hankakuSuji += String.fromCharCode(str.charCodeAt(i) - 65248);
				} else {
					hankakuSuji += String.fromCharCode(str.charCodeAt(i));
				}
			}
			var numreg = new RegExp(/\d+/);
			if (!numreg.test(hankakuSuji)) {
				hankakuSuji = "";
			}
			return hankakuSuji;
		}

		return ImeEdit;
	}
	
})(typeof window !== "undefined" ? window : this);

if (!agentCheck()) {
	document.addEventListener( 'DOMContentLoaded', ImeEdit.editValue, false );
}


