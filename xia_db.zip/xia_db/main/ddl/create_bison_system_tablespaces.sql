
spool create_tablespaces.log

prompt
prompt Creating tablespaces for BISON_SYSTEM_DATA...

CREATE  TABLESPACE BISON_SYSTEM_DATA
    DATAFILE
    '&&bison_ssdgroup' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_SEGMENTS_DATA...

CREATE  TABLESPACE BISON_SEGMENTS_DATA
    DATAFILE 
    '&&bison_ssdgroup' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_LOG_DATA...

CREATE  TABLESPACE BISON_LOG_DATA
    DATAFILE 
    '&&bison_ssdgroup' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

---------------------------------------
-- For ENROLL_JOB
---------------------------------------
prompt
prompt Creating tablespaces for BISON_ENROLL_BJ_DATA...

CREATE  TABLESPACE BISON_ENROLL_BJ_DATA
    DATAFILE 
    '&&bison_ssdgroup' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_ENROLL_TLJ_DATA...

CREATE  TABLESPACE BISON_ENROLL_TLJ_DATA
    DATAFILE 
    '&&bison_ssdgroup' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_ENROLL_TLJ_LOB_DATA...

CREATE  TABLESPACE BISON_ENROLL_TLJ_LOB_DATA
    DATAFILE 
    '&&bison_ssdgroup' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

---------------------------------------
-- For IDENTIFY_JOB
---------------------------------------
prompt
prompt Creating tablespaces for BISON_IDENTIFY_BJ_DATA...

CREATE  TABLESPACE BISON_IDENTIFY_BJ_DATA
    DATAFILE 
    '&&bison_ssdgroup' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_IDENTIFY_TLJ_DATA...

CREATE  TABLESPACE BISON_IDENTIFY_TLJ_DATA
    DATAFILE 
    '&&bison_ssdgroup' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_IDENTIFY_TLJ_LOB_DATA...

CREATE  TABLESPACE BISON_IDENTIFY_TLJ_LOB_DATA
    DATAFILE 
    '&&bison_ssdgroup' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

