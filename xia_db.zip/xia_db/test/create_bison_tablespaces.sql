
spool create_tablespaces.log

--WHENEVER OSERROR  EXIT FAILURE;
--WHENEVER SQLERROR EXIT SQL.SQLCODE;

accept aim_bison_data_dir char   prompt 'Enter a full path for BISON tablespaces (no trailing slashes):';

prompt
prompt Creating tablespaces for BISON_SYSTEM_DATA...

CREATE  TABLESPACE BISON_SYSTEM_DATA
    DATAFILE
    '&&aim_bison_data_dir/bison_system_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_SEGMENTS_DATA...

CREATE  TABLESPACE BISON_SEGMENTS_DATA
    DATAFILE
    '&&aim_bison_data_dir/bison_segments_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


prompt
prompt Creating tablespaces for BISON_LOG_DATA...

CREATE  TABLESPACE BISON_LOG_DATA
    DATAFILE
    '&&aim_bison_data_dir/bison_log_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

---------------------------------------
-- For ENROLL_JOB
---------------------------------------
prompt
prompt Creating tablespaces for BISON_ENROLL_BJ_DATA...

CREATE  TABLESPACE BISON_ENROLL_BJ_DATA
    DATAFILE
    '&&aim_bison_data_dir/bison_enroll_bj_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_ENROLL_TLJ_DATA...

CREATE  TABLESPACE BISON_ENROLL_TLJ_DATA
    DATAFILE 
    '&&aim_bison_data_dir/bison_enroll_tlj_data01.dbf' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_ENROLL_TLJ_LOB_DATA...

CREATE  TABLESPACE BISON_ENROLL_TLJ_LOB_DATA
    DATAFILE 
    '&&aim_bison_data_dir/bison_enroll_tlj_lob_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

---------------------------------------
-- For IDENTIFY_JOB
---------------------------------------
prompt
prompt Creating tablespaces for BISON_IDENTIFY_BJ_DATA...

CREATE  TABLESPACE BISON_IDENTIFY_BJ_DATA
    DATAFILE
    '&&aim_bison_data_dir/bison_identify_bj_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_IDENTIFY_TLJ_DATA...

CREATE  TABLESPACE BISON_IDENTIFY_TLJ_DATA
    DATAFILE 
    '&&aim_bison_data_dir/bison_identify_tlj_data01.dbf' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

prompt
prompt Creating tablespaces for BISON_IDENTIFY_TLJ_LOB_DATA...

CREATE  TABLESPACE BISON_IDENTIFY_TLJ_LOB_DATA
    DATAFILE 
    '&&aim_bison_data_dir/bison_identify_tlj_lob_data01.dbf' SIZE 1G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;

---------------------------------------
-- For PERSON_BIOMETRICS_DATA
---------------------------------------

prompt Creating tablespaces BISON_BIOMETRICS_REFID_INDEX_001

CREATE  TABLESPACE BISON_BIOMETRICS_REFID_IDX_001
DATAFILE
'&&aim_bison_data_dir/bison_biometrics_idx_data001.dbf' SIZE 1M  REUSE  AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED;


prompt Creating tablespaces BISON_BIOMETRICS_REFID_INDEX_002

CREATE  TABLESPACE BISON_BIOMETRICS_REFID_IDX_002
DATAFILE
'&&aim_bison_data_dir/bison_biometrics_idx_data002.dbf' SIZE 1M  REUSE  AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED;



prompt Creating tablespaces BISON_BIOMETRICS_DATA_001

CREATE  TABLESPACE  BISON_BIOMETRICS_DATA_001
DATAFILE
'&&aim_bison_data_dir/bison_biometrics_data001.dbf' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 128M MAXSIZE UNLIMITED;

prompt Creating tablespaces BISON_BIOMETRICS_LOB_DATA_001

CREATE  TABLESPACE BISON_BIOMETRICS_LOB_DATA_001
    DATAFILE
    '&&aim_bison_data_dir/bison_biometrics_lob_data001.dbf' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


prompt Creating tablespaces BISON_BIOMETRICS_DATA_002

CREATE  TABLESPACE  BISON_BIOMETRICS_DATA_002
DATAFILE
'&&aim_bison_data_dir/bison_biometrics_data002.dbf' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 128M MAXSIZE UNLIMITED;

prompt Creating tablespaces BISON_BIOMETRICS_LOB_DATA_002

CREATE  TABLESPACE BISON_BIOMETRICS_LOB_DATA_002
    DATAFILE
    '&&aim_bison_data_dir/bison_biometrics_lob_data002.dbf' SIZE 2G  REUSE  AUTOEXTEND ON NEXT 1G MAXSIZE UNLIMITED;


exit success;
