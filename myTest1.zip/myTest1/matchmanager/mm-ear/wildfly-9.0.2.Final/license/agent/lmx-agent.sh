#!/bin/sh

#***********************************************************
#                readme:
#    su - root        
#    cd to path of lmx-agent tool
#    unzip lmx-agent.zip
#    chown -R usrid:groupid path to lmx-agent tool
#    chmod 775 lmx-agent.sh 
#    sh ./lmx-agent.sh port feature major
#****************************************************************

# sample for start LmxAgent: sh ./lmx_agent.sh 8888 AFIS 5
# sample comand:java -jar -Djava.library.path=/license/lmx/linux_x64  -Djava.lmx.license.path=@192.168.21.119 lmx-agent.jar 8888 AFIS 5

#export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH

#export LMX_LIB_PATH="/license/lmx/linux_x64"
#export JAVA_OPTS="$JAVA_OPTS -Djava.library.path=$LMX_LIB_PATH":$JAVA_OPTS


echo ""
echo " lmx agent starting..."
echo ""

if test  $# != 3 ; then
	echo Usage: sh ./lmx_agent.sh port featurename majorversion
	exit
fi


port=$1
feature=$2
major=$3

if [ ! -e log ]; then
        mkdir log
fi

java -jar -Djava.library.path=$LMX_LIB_PATH  -Djava.lmx.license.path=${LMX_LICENSE_PATH} lmx-agent.jar $port $feature $major


