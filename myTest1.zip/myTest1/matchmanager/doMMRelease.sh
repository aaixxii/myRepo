#!/bin/sh

# ----------------------------------------------------------------------
# Checking   paramters  all are correctly!
# 1. aim_release_version
# 2. currently_aim_branches_version
# 3. mm_developing_version
# exsample : ./doMMRelease.sh 5.4.0 5.4 5.4.0
# ----------------------------------------------------------------------

#check zip file is changed or not
function checkZipContentDiff(){
	if [ !$1 -o !$2 ]; then		
		 return 1
	fi
    local zip_1=$1
    local zip_2=$2
    mkdir -p tmp/$zip_1 tmp/$zip_2
    unzip -o -d tmp/$zip_1 $zip_1 > /dev/null
    unzip -o -d tmp/$zip_2 $zip_2 > /dev/null
    local checkNum=`diff -r tmp/$zip_1 tmp/$zip_2|wc -l`
    rm -rf tmp
    return $checkNum
}

# Begin
# CHECK Args of doMMRelease()
if test  $# != 3 ; then
	echo Usage : ./doMMRelease.sh  aim_release_version  currently_aim_branches_version   mm_developing_version
	exit
fi
RELEASE_VER=$1
DEV_VER=$2
MM_VER=$3
WSDL_COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-$RELEASE_VER/AIM-$RELEASE_VER-DOC/WSDL/MM/
DB_SCRIPT_COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-$RELEASE_VER/AIM-$RELEASE_VER-ENV/mm-db/
RPM_COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-$RELEASE_VER/AIM-$RELEASE_VER-PKG/AIM-$RELEASE_VER-BASIC/AIMInstaller/pkgs/

RPM_NAME=aim-mm-$MM_VER-0.x86_64.rpm
MM_TAG_DIR=http://dev01a/svn/tags/MatchingManager/$RELEASE_VER/
MM_RELEASE_TAG_DIR=http://dev01a/svn/tags/Release/AIM-$RELEASE_VER/MatchManager/
count=0
SVN_USER=s-konno
SVN_PWD=s-konno
mkdir release
cd release
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Release MM to shipment
#  PACKAGE_TYPE=rpm:
# 1. Copy MM wsdl to http://dev01a/shipment/branches/Release/AIM-${releaseVer}/AIM-${releaseVer}-DOC/WSDL/MM/
# 2. Copy MM schema to http://dev01a/shipment/branches/Release/AIM-${releaseVer}/AIM-${releaseVer}-DOC/XSDSchema/
# 3. Copy MM db script to http://dev01a/shipment/branches/Release/AIM-{releaseVer}/AIM-{releaseVer}-ENV/mm-db/
# 4. Copy mm rpm to http://dev01a/shipment/branches/Release/AIM-{releaseVer}/AIM-{releaseVer}-PKG/AIM-{releaseVer}-BASIC/AIMInstaller/pkgs/
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


# CHECKOUT  SHIPMENT DIRECTORY OF WSDL
svn ls --username $SVN_USER --password $SVN_PWD $WSDL_COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $WSDL_COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $WSDL_COPY_TO_DIR
else	
	svn co --username $SVN_USER --password $SVN_PWD $WSDL_COPY_TO_DIR
fi

cp -p -f ../mm-ejb/target/generated/wsdl/* MM/
cd MM
svn add *
svn commit --username $SVN_USER --password $SVN_PWD --message "Update By $SVN_USER"
COMMIT_RESULT=$?
if test $COMMIT_RESULT -ne 0 ; then
	echo “svn commit for shipment was failed!! ”
	count=`expr $count + 1`	 
fi

cd ..
# CHECKOUT  SHIPMENT DIRECTORY OF DB_SCRIPT
svn ls --username $SVN_USER --password $SVN_PWD $DB_SCRIPT_COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $DB_SCRIPT_COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $DB_SCRIPT_COPY_TO_DIR
else
	svn co --username $SVN_USER --password $SVN_PWD $DB_SCRIPT_COPY_TO_DIR
fi

checkZipContentDiff mm-db/sqlscript-mm.zip ../db/target/sqlscript-mm.zip
if test $? != 0 ; then
	cp -p -f ../db/target/sqlscript-mm.zip  mm-db/
	cd  mm-db
	svn add *
	svn commit --username $SVN_USER --password $SVN_PWD --message "Update By $SVN_USER"
	COMMIT_RESULT=$?
	if test $COMMIT_RESULT -eq 0 ; then	
		count=`expr $count + 1`	 
	fi
	cd ..
else
	echo "--------------------------------------------------------------------------------------------"
	echo "NO EXIST DIFF. SKIP $DB_SCRIPT_COPY_TO_DIR/sqlscript-mm.zip  UPDATE"
	echo "---------------------------------------------------------------------------------------------"
	count=`expr $count + 1`	 
fi

# CHECKOUT  SHIPMENT DIRECTORY OF MM RPM
svn ls --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $RPM_COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR
else
	svn co --username $SVN_USER --password $SVN_PWD --depth=empty $RPM_COPY_TO_DIR
	svn ls --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR/$RPM_NAME	
	if test $? = 0 ; then
		svn up --username $SVN_USER --password $SVN_PWD --depth=files pkgs/$RPM_NAME
	fi
fi
cp -p -f ../mm-ear/target/rpm/aim-mm/RPMS/x86_64/$RPM_NAME  pkgs/
cd  pkgs
svn add *
svn commit --username $SVN_USER --password $SVN_PWD --message "Update By $SVN_USER"
COMMIT_RESULT=$?
if test $COMMIT_RESULT -eq 0 ; then	
	count=`expr $count + 1`	 
fi
cd ../../
rm -rf release

# ----------------------------------------------------------------------------------------------------------------------------------------
# Create Tag  for  MM
# 1. Copy MM sources form branche to http://dev01a/svn/tags/Release/AIM-${releaseVer}/MatchManager
# 2. Copy MM sources from branche to http://dev01a/svn/tags/MatchingManager/${releaseVer}
# -----------------------------------------------------------------------------------------------------------------------------------------

echo "--------------------------------------------------------------------------------"
echo "CREATE MM TAG TO http://dev01a/svn/tags/Release/..."
echo "--------------------------------------------------------------------------------"

if test $count -eq 0 ; then 
	echo "There are commit failed. exit without make TAG."
	exit
fi

# CHECK IF TAG IS ALREADY CREATED OR NOT
svn ls --username $SVN_USER --password $SVN_PWD $MM_RELEASE_TAG_DIR > /dev/null
if test $? = 0 ; then
	svn delete --username $SVN_USER --password $SVN_PWD --message "Delete Tag by xia" $MM_RELEASE_TAG_DIR
else
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By xia" $MM_RELEASE_TAG_DIR
fi

# CREATE SOURCE CODE TAG
svn copy --username $SVN_USER --password $SVN_PWD --message "Create Source Code Tag by xia"　 --parents http://dev01a/svn/branches/AIM-$DEV_VER/MatchManager $MM_RELEASE_TAG_DIR

echo "--------------------------------------------------------------------------------------------"
echo "CREATE MM TAG TO http://dev01a/svn/tags/MatchingManager/.. "
echo "---------------------------------------------------------------------------------------------"

# CHECK IF TAG IS ALREADY CREATED OR NOT
svn ls --username $SVN_USER --password $SVN_PWD $MM_TAG_DIR > /dev/null
if test $? = 0 ; then
	svn delete --username $SVN_USER --password $SVN_PWD --message "Delete Tag by xia" $MM_TAG_DIR
else
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By xia" $MM_TAG_DIR
fi

# CREATE SOURCE CODE TAG
svn copy --username $SVN_USER --password $SVN_PWD --message "Create Source Code Tag by xia"  --parents http://dev01a/svn/branches/AIM-$DEV_VER/MatchManager --parents $MM_TAG_DIR

# ----------------------------------------------------------------------------------------------------------------------------------------
# if create external id do as flow:
#MM_RELEASE_TAG_DIR=http://dev01a/svn/tags/Release/AIM-$RELEASE_VER/MatchManager/
# mkdir mmReleaseTag
# cd mmReleaseTag
#  svn co {MM_RELEASE_TAG_DIR}
#  cd MatchManager
#  svn propset svn:externals "http://dev01a/svn/branches/AIM-${RELEASE_VER}/MatchManager/mm-develop/ MatchManager" .
#  svn commit --depth empty -m "create exteral propery by xia"
# -----------------------------------------------------------------------------------------------------------------------------------------


echo "Completed ......Done!"
