package jp.co.nec.aim.mm.util;

import java.sql.SQLException;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.exception.ExceptionHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Erik Vandekieft
 */
public class OpLockHelper {
	private static Logger log = LoggerFactory.getLogger(OpLockHelper.class);
	private int i;
	private int limit;
	private String functionName;
	private static final int OPTIMISTIC_LOCK_SQL_CODE = 20005;
	private ExceptionHelper exception;

	// timer firings
	private static final int OPTIMISTIC_LOCK_RETRY = 20;

	public OpLockHelper(String functionName, DataSource dataSource) {
		i = 1;
		limit = OPTIMISTIC_LOCK_RETRY;
		this.functionName = functionName;
		this.exception = new ExceptionHelper(new DateDao(dataSource));
	}

	public boolean hasNext() {
		return i <= limit;
	}

	public void next() {
		++i;
	}

	public void checkException(SQLException e, AimError error) {
		if (e.getErrorCode() == OPTIMISTIC_LOCK_SQL_CODE) {
			if (i < limit) {
				log.warn("Caught Optimistic Locking SQL Exception during "
						+ functionName + "(), retrying... (retry # " + i + ")");
			} else {
				exception
						.throwDBException(
								AimError.SYSTEM_DB_BUSY_ERROR,
								e,
								"Tried calling "
										+ functionName
										+ " ("
										+ i
										+ ") times, but got optimistic locking exceptions each time. Giving up... system is too busy, try again later.");

			}
		} else {
			exception.throwOracleException(e, error);
		}
	}
}
