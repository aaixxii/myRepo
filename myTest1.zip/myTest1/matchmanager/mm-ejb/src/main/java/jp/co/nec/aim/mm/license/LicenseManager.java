package jp.co.nec.aim.mm.license;

import java.io.InputStream;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Throwables;
import com.xformation.lmx.Lmx;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxHostidType;
import com.xformation.lmx.LmxSettings;

import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.license.LicenseComponent;
import jp.co.nec.aim.license.LicenseManagementException;
import jp.co.nec.aim.license.LicenseValidation;
import jp.co.nec.aim.license.LicenseValidationException;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.exception.LicenseException;
import jp.co.nec.aim_xm.license.broker.LicenseBroker;
import jp.co.nec.aim_xm.license.exception.InvalidFloatingLicenseException;
import jp.co.nec.aim_xm.license.floating.FloatingLicenseManager;

/**
 * the manage class of license
 * 
 * @author liuyq
 * 
 */

public class LicenseManager {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(LicenseManager.class);
	private LicenseValidation validator;
	private InputStream is = null;
	private Lmx lmx;
	private boolean floating ;
	LicenseBroker licenseBroker;
	FloatingLicenseManager floatingLicenseManager;
	
	static String FLOATING_LICENSE_MAJOR_VERSION = "5";	
	
	public LicenseManager() {	
		init();
	}	
	
	public void setLicenseBroker(LicenseBroker licenseBroker) {
		this.licenseBroker = licenseBroker;
	}

	public void setFloatingLicenseManager(FloatingLicenseManager floatingLicenseManager) {
		this.floatingLicenseManager = floatingLicenseManager;
	}

	/**
	 * Validate the MM inquiry workFlow with the specified function and current
	 * date
	 * 
	 * @param function
	 *            the function name
	 * @param now
	 *            the current time
	 */
	public void check(String function, Date now) {
		AfisLowLevelFunctionEnum functionEnum = AfisLowLevelFunctionEnum.valueOf(function);
		String modality = functionEnum.getFunction().name();
		try {
			if (floating) {
				checkFloatingLicense(modality);
			} else {
				validator.validate(functionEnum, now, LicenseComponent.MM);
			}
		} catch (LicenseValidationException e) {
			log.error("LicenseValidationException occurred" + " when validate the function name: " + function + "..",
					e);
			throwLicenseException(function, now, e);
		} catch (LicenseManagementException e) {
			log.error("LicenseManagementException occurred" + " when validate the function name: " + function + "..",
					e);
			throwLicenseException(function, now, e);
		} catch (Exception e) {
			log.error("Exception occurred" + " when check the License with the function name: " + function + "..", e);
			throwLicenseException(function, now, e);
		}
	}

	private void checkFloatingLicense(String featureId) throws LicenseValidationException {
		try {

			floatingLicenseManager.checkLicense("", featureId);
		} catch (InvalidFloatingLicenseException ex) {
			if (!floatingLicenseManager.isValid()) {
				throw new LicenseValidationException("License is not enabled for featureId: " + featureId
						+ ", errorCode: " + ex.getCode() + ", errorMessage: " + ex.getMessage());
			} else {
				throw new LicenseValidationException(ex.getMessage());
			}
		}
	}

	/**
	 * throw license exception with function name, current date and exception
	 * instance
	 * 
	 * @param function
	 *            function name
	 * @param now
	 *            current date
	 * @param e
	 *            the instance of excption
	 */
	private void throwLicenseException(String function, Date now, Throwable e) {
		final AimError aimError = AimError.LICENSE_ERROR;
		final String message = String.format(aimError.getMessage(), function,
				StringUtils.isBlank(e.getMessage()) ? "Unknow Exception" : e.getMessage());
		throw new LicenseException(aimError.getErrorCode(), message, String.valueOf(now.getTime()));
	}

	/**
	 * SingletonHolder class
	 * 
	 * @author liuyq
	 * 
	 */
	static class SingletonHolder {
		public static final LicenseManager LICENSEMANAGER = new LicenseManager();
	}

	/**
	 * get Singleton instance
	 * 
	 * @return
	 */
	public static LicenseManager getInstance() {
		return SingletonHolder.LICENSEMANAGER;
	}	
	
	
	public void destroy() throws Exception {
		log.debug("called destroy.");
		lmx.free();
	}

	
	private void init() {
		validator = LicenseValidation.getInstance();
		this.is = this.getClass().getClassLoader()
				.getResourceAsStream("license.xml");		
		if (is != null)	 {
			floating = false;
		} else {
			try {
				if (!Objects.isNull(System.getenv("LMX_LICENSE_PATH"))) {
					lmx = new Lmx();
					lmx.init();					
					lmx.setOption(LmxSettings.LMX_OPT_HOSTID_DISABLED, LmxHostidType.LMX_HOSTID_ALL);
					licenseBroker.init(FLOATING_LICENSE_MAJOR_VERSION);
					floating = true;
				}
			} catch (LmxException ex) {
				log.error(Throwables.getRootCause(ex).getMessage());
			}
		}		
	}
}
