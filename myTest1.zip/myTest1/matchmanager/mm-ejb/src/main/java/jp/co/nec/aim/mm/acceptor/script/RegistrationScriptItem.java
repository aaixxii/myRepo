package jp.co.nec.aim.mm.acceptor.script;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "registration-script-item", propOrder = { "id",
		"templateFormat", "fingerPrint", "position", "containerSpec" })
public class RegistrationScriptItem {
	@XmlElement(required = true)
	protected String id;
	@XmlElement(required = true)
	protected String templateFormat;
	@XmlElement
	protected String fingerPrint;
	@XmlElement
	protected String position;
	@XmlElement(required = true)
	protected RegistrationContainerSpec containerSpec;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTemplateFormat() {
		return templateFormat;
	}

	public void setTemplateFormat(String templateFormat) {
		this.templateFormat = templateFormat;
	}

	public String getFingerPrint() {
		return fingerPrint;
	}

	public void setFingerPrint(String fingerPrint) {
		this.fingerPrint = fingerPrint;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	/**
	 * Gets the value of the containerSpec property.
	 * 
	 * @return possible object is {@link RegistrationContainerSpec }
	 * 
	 */
	public RegistrationContainerSpec getContainerSpec() {
		return containerSpec;
	}

	/**
	 * Sets the value of the containerSpec property.
	 * 
	 * @param value
	 *            allowed object is {@link RegistrationContainerSpec }
	 * 
	 */
	public void setContainerSpec(RegistrationContainerSpec value) {
		this.containerSpec = value;
	}

}
