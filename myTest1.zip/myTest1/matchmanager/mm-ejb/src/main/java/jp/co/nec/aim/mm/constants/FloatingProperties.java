package jp.co.nec.aim.mm.constants;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import jp.co.nec.aim.mm.exception.AimRuntimeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FloatingProperties {
	private static Logger log = LoggerFactory.getLogger(ConfigProperties.class);
	private static final String PROPERTIES_FILE = "floating.license.server.properties";
	private static final FloatingProperties instance = new FloatingProperties();
	private Properties props;

	public static FloatingProperties getInstance() {
		return instance;
	}

	private FloatingProperties() {
		load();
	}

	private void load() {
		try {
			InputStream in = this.getClass().getClassLoader()
					.getResourceAsStream(PROPERTIES_FILE);
			props = new Properties();
			props.load(in);
			log.debug("Loaded MM Config Properties: "
					+ props.entrySet().toString());
		} catch (IOException e) {
			log.error(e.getMessage(), e);
		}
	}

	public String getPropertyValue(ConfigPropertyNames name) {
		return getPropertyValue(name, false);
	}

	private String getPropertyValue(ConfigPropertyNames name, boolean mustExist) {
		if (props != null) {
			String val = props.getProperty(name.name());
			if (mustExist && val == null)
				throw new AimRuntimeException("Property " + name
						+ " not set in properties file.");
			return val;
		} else {
			return null;
		}
	}

	/**
	 * return boolean value.
	 * 
	 * If key is not found in the property, this method return false.
	 * 
	 * @param name
	 * @return
	 */
	public boolean isPropertyValue(ConfigPropertyNames name) {
		String value = getPropertyValue(name);
		return Boolean.valueOf(value);
	}
}
