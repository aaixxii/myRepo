package jp.co.nec.aim.mm.acceptor.script;

import java.io.StringReader;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
import jp.co.nec.aim.mm.acceptor.script.AimScript.DeletionScript;
import jp.co.nec.aim.mm.acceptor.script.AimScript.RegistrationScript;
import jp.co.nec.aim.mm.acceptor.script.AimScript.SearchScript;
import jp.co.nec.aim.mm.constants.ScriptType;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.ScopeUtil;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

/**
 * <li>
 * <tt>The Script Management <tt>
 * 
 * <li>
 * Save the Script XML into memory map by function synchronously, Look up the
 * insert, delete, inquiry container information With the specified format type,
 * position and printType
 * 
 * <li>
 * thread safe must be considering due to ScriptManager is Singleton
 * ConcurrentMap avoid to thread unsafe issue..</li>
 * 
 * @author liuyq
 * 
 */
public final class ScriptManager {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(ScriptManager.class);

	/** Used for save each script information **/
	// thread safe must be considering due to ScriptManager is Singleton
	// ConcurrentMap avoid to thread unsafe issue..
	private final Map<Key, Value> inqScriptMap = Maps.newConcurrentMap();
	private final Map<Key, Value> delScriptMap = Maps.newConcurrentMap();
	private final Map<Key, Value> regScriptMap = Maps.newConcurrentMap();
	private final Map<ScriptFunction, String> layoutMap = Maps
			.newConcurrentMap();

	/**
	 * private ScriptManager constructor
	 */
	private ScriptManager() {
	}

	/**
	 * getBySearchKey
	 * 
	 * @param key
	 *            the instance of search key
	 * @return the instance of Search Value
	 */
	public SearchValue getBySearchKey(SearchKey key) {
		if (key == null) {
			throw new IllegalArgumentException(
					"Search key is null when get Search value..");
		}
		return (SearchValue) inqScriptMap.get(key);
	}

	/**
	 * check is Exist Function in layoutMap
	 * 
	 * @param function
	 *            the instance of ScriptFunction
	 * @return is exist function in layoutMap
	 */
	public boolean isExistFunction(ScriptFunction function) {
		if (function == null) {
			throw new AimRuntimeException("argument function is null..");
		}
		return layoutMap.containsKey(function);
	}

	/**
	 * add the script XML into specified map once function request is received
	 * from the client
	 * 
	 * <ol>
	 * <li>first add the XML into layoutMap.</li>
	 * <li>secondly merger the XML into inqScriptMap</li>
	 * </ol>
	 * 
	 * @param function
	 *            the instance of ScriptFunction
	 * @param xml
	 *            script XML
	 */
	public void addScriptXml(ScriptFunction function, String xml) {
		if (function == null) {
			throw new AimRuntimeException("argument function is null..");
		}

		if (StringUtils.isBlank(xml)) {
			throw new AimRuntimeException("function " + function.name()
					+ " layout script XML is empty.");
		}

		if (layoutMap.containsKey(function)) {
			log.debug("layoutMap already exist this function {},",
					function.name());
			return;
		}

		try {
			switch (function) {
			case REGISTRATION:
				final RegistrationScript rs = jaxbConvert(xml,
						RegistrationScript.class);
				if (rs == null || CollectionsUtil.isEmpty(rs.getScriptItem())) {
					throw new AimRuntimeException(
							"Registration Script element can not be found, function:"
									+ function.name());
				}
				// first add the XML into layoutMap
				layoutMap.put(function, xml);

				// secondly save RS into regScriptMap
				saveToRegMap(rs);
				if (log.isDebugEnabled()) {
					log.debug("Save into regScriptMap successfully..");
				}
				break;
			case DELETION:
				final DeletionScript ds = jaxbConvert(xml, DeletionScript.class);
				if (ds == null || CollectionsUtil.isEmpty(ds.getScriptItem())) {
					throw new AimRuntimeException(
							"Deletion Script element can not be found, function:"
									+ function.name());
				}

				// first add the XML into layoutMap
				layoutMap.put(function, xml);

				// save RS into regScriptMap
				saveToDeleteMap(ds);
				if (log.isDebugEnabled()) {
					log.debug("Save into delScriptMap successfully..");
				}
				break;
			default:
				// Other is inquiry function
				final SearchScript sr = jaxbConvert(xml, SearchScript.class);
				if (sr == null || CollectionsUtil.isEmpty(sr.getScriptItem())) {
					throw new AimRuntimeException(
							"Search Script element can not be found, function:"
									+ function.name());
				}

				// first add the XML into layoutMap
				layoutMap.put(function, xml);

				saveToSearchMap(sr, function);
				if (log.isDebugEnabled()) {
					log.debug("Save into inqScriptMap successfully..");
				}
				break;
			}
		} catch (Exception ex) {
			// unknown exception(maybe invalid XML) occurred, must rollBack
			// the layoutMap, let the next request to replace
			if (layoutMap.containsKey(function)) {
				layoutMap.remove(function);
			}

			throw new AimRuntimeException("Exception occurred when add "
					+ "layout script XML into each map..", ex);
		}
	}

	/**
	 * findInqContainerIds
	 * 
	 * @param function
	 *            InquiryFuncionType instance
	 * @param kTemplate
	 *            PBKeyedTemplate instance
	 * @param scope
	 *            PBInquiryScopeOptions instance
	 * @return ScriptValue ScriptValue instance
	 */
	public ScriptValue findInqContainerIds(InquiryFunctionType function,
			PBKeyedTemplate kTemplate, PBInquiryScopeOptions scopesOptions) {
		final ScriptFunction f = ScriptFunction.valueOf(function.name());
		final TemplateFormatType formatType = kTemplate.getKey();
		final FingerPrintType printTypeS = confirmSPrintType(kTemplate);
		final List<FingerPrintType> printTypeFs = confirmFPrintType(scopesOptions);

		final boolean isScopeSpec = (scopesOptions == null) ? false
				: CollectionsUtil.isNotEmpty(scopesOptions.getScopeList());

		final ScriptValue ret = new ScriptValue();
		for (final FingerPrintType printTypeF : printTypeFs) {
			SearchValue value = findInquiryResultByKey(f, formatType,
					printTypeS, printTypeF);
			if (value == null || value.getContainerId() == null) {
				final String error = String
						.format("Can not find inquiry container id with "
								+ "functionName:%s, formatType:%s,"
								+ " Search side printType:%s,File side printType:%s..",
								f.name(),
								(formatType == null) ? "null" : formatType
										.name(),
								(printTypeS == null) ? "null" : printTypeS
										.name(), (printTypeF == null) ? "null"
										: printTypeF.name());
				log.error(error);
				throw new AimRuntimeException(error);
			}

			// add container id with specified scopes
			ret.addContainerIds(isScopeSpec ? ScopeUtil.getRealContainerId(
					value.getContainerId(), scopesOptions.getScopeList())
					: ScopeUtil.getRealContainerId(value.getContainerId(),
							value.getScope()));

			// add default fusion weight
			ret.put(value.getFwList());
		}
		return ret;
	}

	/**
	 * Find Register ContainerId list <br>
	 * 
	 * @param kTemplate
	 *            the instance of PBKeyedTemplate
	 * @param scope
	 *            scope(maybe null)
	 * @return container id set
	 */
	public Set<Integer> findRegContainerIds(PBKeyedTemplate kTemplate,
			Integer scope) {
		final TemplateFormatType formatType = kTemplate.getKey();
		FingerPrintType printType = null;
		String position = null;
		if (kTemplate.hasIndexer()) {
			PBKeyedTemplateIndexer indexr = kTemplate.getIndexer();
			printType = indexr.hasFingerPrintType() ? indexr
					.getFingerPrintType() : null;
			position = indexr.hasPosition() ? indexr.getPosition().name()
					: ((indexr.hasIndex()) ? String.valueOf(indexr.getIndex())
							: null);
		}

		final Value value = findResultByKey(formatType, printType, position,
				ScriptType.REGISTER);
		if (value == null) {
			final String error = String.format(
					"Can not find Register container id with "
							+ "formatType:%s, printType:%s, position:%s..",
					(formatType == null) ? "null" : formatType.name(),
					(printType == null) ? "null" : printType.name(),
					(Strings.isNullOrEmpty(position)) ? "null" : position);
			log.error(error);
			throw new IllegalArgumentException(error);
		}
		// find the real container id
		return ScopeUtil.getRealContainerId(value.getContainerIds(),
				(scope == null) ? value.getScope() : scope);
	}

	/**
	 * find deletion container id with specified delete payLoad
	 * 
	 * @param delPayload
	 *            the instance of PBSyncDeletePayload
	 * @return deletion container id set
	 */
	public Set<Integer> findDelContainerIds(PBSyncDeletePayload delPayload) {
		Set<Integer> ret = Sets.newTreeSet();
		if (delPayload == null) {
			log.info("DelPayload is null when find the deletion container ids..");
			findAllDelContainerIds(ret, null);
		} else if (delPayload.getKeyedTemplateCount() <= 0) {
			log.info("DelPayload.KeyedTemplateList is null "
					+ "or empty when find the deletion container ids..");
			findAllDelContainerIds(ret, delPayload.getScopesList());
		} else {

			List<Integer> scopesClient = delPayload.getScopesList();
			boolean isScopeSpec = CollectionsUtil.isNotEmpty(scopesClient);

			List<PBKeyedTemplate> templates = delPayload.getKeyedTemplateList();
			for (final PBKeyedTemplate t : templates) {
				final TemplateFormatType formatKey = t.getKey();
				final PBKeyedTemplateIndexer indexr = t.getIndexer();
				if (t.hasKey() && t.hasIndexer()) {
					FingerPrintType printType = indexr.hasFingerPrintType() ? indexr
							.getFingerPrintType() : null;
					Value value = findResultByKey(formatKey, printType, null,
							ScriptType.DELETE);
					if (value == null) {
						log.warn(
								"Can not find deletion container id with {}, {}..",
								formatKey.name(), printType);
						return ret;
					}

					ret.addAll(isScopeSpec ? ScopeUtil.getRealContainerId(
							value.getContainerIds(), scopesClient) : ScopeUtil
							.getRealContainerId(value.getContainerIds(),
									value.getScope()));
				} else if (t.hasKey() && !t.hasIndexer()) {
					findDelCIdsByFormatKey(ret, formatKey, scopesClient);
				}
			}
		}
		return ret;
	}

	/**
	 * Confirm FingerPrintType with specified scope information
	 * 
	 * @param scopes
	 *            scope information
	 * @return FingerPrintType list
	 */
	public FingerPrintType confirmSPrintType(PBKeyedTemplate template) {
		if (template.hasIndexer()) {
			PBKeyedTemplateIndexer indexer = template.getIndexer();

			if (indexer.hasFingerPrintType()) {
				return indexer.getFingerPrintType();
			}
		}
		// return null without any finger print information
		return null;
	}

	/**
	 * confirmFPrintType
	 * 
	 * @param scopes
	 *            the instance of PBInquiryScopeOptions
	 * @return file side FingerPrintType
	 */
	public List<FingerPrintType> confirmFPrintType(PBInquiryScopeOptions scopes) {
		if (scopes != null && scopes.getTargetFingerPrintCount() > 0) {
			return scopes.getTargetFingerPrintList();
		}

		// return null list without any finger print information
		List<FingerPrintType> nothing = Lists.newArrayList();
		nothing.add(null);
		return nothing;
	}

	/**
	 * Save each deletion script into delete map
	 * 
	 * @param ds
	 *            the instance of DeletionScript
	 */
	private void saveToDeleteMap(DeletionScript ds) {
		List<DeletionScriptItem> scriptItems = ds.getScriptItem();
		for (final DeletionScriptItem item : scriptItems) {
			ScriptKey key = new ScriptKey(item.getTemplateFormat(),
					item.getFingerPrint(), item.getPosition());
			ContainerSpec spec = item.getContainerSpec();
			if (spec == null || CollectionsUtil.isEmpty(spec.getContainerId())) {
				throw new AimRuntimeException(
						"DeletionContainerSpec can not be found..");
			}
			delScriptMap.put(key,
					new ScriptValue(Sets.newTreeSet(spec.getContainerId()),
							spec.getScope()));
		}
	}

	/**
	 * save each search script into inquiry map
	 * 
	 * @param sr
	 *            SearchScript instance
	 */
	private void saveToSearchMap(SearchScript sr, ScriptFunction function) {
		List<SearchScriptItem> scriptItems = sr.getScriptItem();

		// ScriptItems is read from DB layout
		for (final SearchScriptItem item : scriptItems) {
			final TemplateFormatType templateFmt = TemplateFormatType
					.valueOf(item.getTemplateFormat()); // template key

			// Confirm search side FingerPrintType
			// If search side finger print is
			// null or empty set to null
			final String sFinPrintStr = item.getFingerPrint();
			FingerPrintType sFinPrint = null; // search side finger print
			if (StringUtils.isBlank(sFinPrintStr)) {
				sFinPrint = null;
			} else {
				sFinPrint = FingerPrintType.valueOf(sFinPrintStr);
			}

			ContainerSpec spec = item.getContainerSpec();
			List<Integer> cIds = spec.getContainerId();
			final Integer containerIdR = spec.getContainerIdRolled();
			final Integer containerIdS = spec.getContainerIdSlap();

			// Confirm file side FingerPrintType
			Map<FingerPrintType, Integer> ctIdMap = Maps.newHashMap();
			if (CollectionsUtil.isNotEmpty(cIds)) {
				ctIdMap.put(null, CollectionsUtil.getFirst(cIds));
			} else {
				if (containerIdR != null) {
					ctIdMap.put(FingerPrintType.FINGER_PRINT_ROLLED,
							containerIdR);
				}
				if (containerIdS != null) {
					ctIdMap.put(FingerPrintType.FINGER_PRINT_SLAP, containerIdS);
				}
			}

			for (final FingerPrintType fFinPrint : ctIdMap.keySet()) {
				SearchKey key = new SearchKey(function, templateFmt, sFinPrint,
						fFinPrint);

				Integer containerId = ctIdMap.get(fFinPrint);
				Integer scope = spec.getScope();
				List<PBInquiryFusionWeight> pbFwList = Lists.newArrayList();
				List<FusionWeight> fwList = item.getFusionWeight();
				if (CollectionsUtil.isNotEmpty(fwList)) {
					for (FusionWeight fw : fwList) {
						pbFwList.add(PBInquiryFusionWeight
								.newBuilder()
								.setInquirySet(
										FingerSetType.valueOf(fw
												.getInquirySet().toUpperCase()))
								.setWeight(fw.getValue()).build());
					}
				}
				SearchValue value = new SearchValue(pbFwList, containerId,
						scope);
				inqScriptMap.put(key, value);
			}
		}
	}

	/**
	 * save each Registration Script into Registration map
	 * 
	 * @param rs
	 *            the instance of RegistrationScript
	 */
	private void saveToRegMap(RegistrationScript rs) {
		List<RegistrationScriptItem> scriptItems = rs.getScriptItem();
		for (final RegistrationScriptItem item : scriptItems) {
			ScriptKey key = new ScriptKey(item.getTemplateFormat(),
					item.getFingerPrint(), item.getPosition());
			RegistrationContainerSpec spec = item.getContainerSpec();
			if (spec == null || spec.getContainerId() == null) {
				throw new AimRuntimeException(
						"RegistrationContainerSpec can not be found..");
			}

			regScriptMap.put(key,
					new ScriptValue(spec.getContainerId(), spec.getScope()));
		}
	}

	/**
	 * Convert the XML into RegistrationScript,SearchScript,DeletionScript
	 * instance using JAXB
	 * 
	 * @param xml
	 *            script XML
	 * @return T instance
	 * @throws JAXBException
	 *             JAXBException
	 */
	private <T> T jaxbConvert(String xml, Class<T> clazz) throws JAXBException {
		final JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
		final Unmarshaller un = jaxbContext.createUnmarshaller();

		try (StringReader reader = new StringReader(xml)) {
			@SuppressWarnings("unchecked")
			final T script = (T) un.unmarshal(reader);
			if (script == null) {
				throw new AimRuntimeException(clazz.getSimpleName()
						+ " instance is null after unmarshal..");
			}
			return script;
		}
	}

	/**
	 * findResultByKey with following element <br>
	 * 1.TemplateFormatType <br>
	 * 2.FingerPrintType 3.position 4.ScriptType <br>
	 * 
	 * @param formatType
	 *            (TEMPLATE_TI, TEMPLATE_TIM..)
	 * @param printType
	 *            (FINGER_PRINT_ROLLED, FINGER_PRINT_SLAP)
	 * @param position
	 *            position
	 * @param type
	 *            (INQUIRY, DELETE, REGISTER)
	 * @return ScriptValue instance
	 */
	private Value findResultByKey(TemplateFormatType formatType,
			FingerPrintType printType, String position, ScriptType type) {
		String formatTypeStr = (formatType == null) ? null : formatType.name();
		String printTypeStr = (printType == null) ? null : printType.name();
		String positionStr = StringUtils.isBlank(position) ? null : position;
		return findResultByKey(new ScriptKey(formatTypeStr, printTypeStr,
				positionStr), type);
	}

	/**
	 * findInquiryResultByKey
	 * 
	 * @param function
	 *            the eNum of ScriptFunction
	 * @param formatType
	 *            the instance of TemplateFormatType
	 * @param printTypeS
	 *            search side FingerPrintType
	 * @param printTypeF
	 *            file side FingerPrintType
	 * @return
	 */
	private SearchValue findInquiryResultByKey(ScriptFunction function,
			TemplateFormatType formatType, FingerPrintType printTypeS,
			FingerPrintType printTypeF) {
		return (SearchValue) findResultByKey(new SearchKey(function,
				formatType, printTypeS, printTypeF), ScriptType.INQUIRY);
	}

	/**
	 * findResultByKey
	 * 
	 * @param key
	 *            ScriptKey instance
	 * @param type
	 *            ScriptType instance
	 * @return ScriptValue instance
	 */
	public Value findResultByKey(Key key, ScriptType type) {
		Value value = null;
		switch (type) {
		case INQUIRY:
			value = inqScriptMap.get(key);
			break;
		case DELETE:
			value = delScriptMap.get(key);
			break;
		case REGISTER:
			value = regScriptMap.get(key);
			break;
		default:
			throw new AimRuntimeException("The ScriptType:" + type.name()
					+ " is not support..");
		}
		return value;
	}

	/**
	 * findAllDelContainerIds
	 * 
	 * @param conatinerIds
	 */
	private void findDelCIdsByFormatKey(Set<Integer> conatinerIds,
			final TemplateFormatType formatKey, List<Integer> scopesClient) {
		boolean isScopeSpec = CollectionsUtil.isNotEmpty(scopesClient);
		final Collection<Key> keys = delScriptMap.keySet();
		for (final Key k : keys) {
			String formatType = k.getFormatType();
			if (StringUtils.isBlank(formatType)) {
				log.warn("format type is null or empty when find by FormatKey");
				continue;
			}

			if (formatKey.name().equalsIgnoreCase(formatType)) {
				Value v = delScriptMap.get(k);
				conatinerIds.addAll(isScopeSpec ? ScopeUtil.getRealContainerId(
						v.getContainerIds(), scopesClient) : ScopeUtil
						.getRealContainerId(v.getContainerIds(), v.getScope()));
			}
		}
	}

	/**
	 * find All Deletion ContainerIds
	 * 
	 * @param conatinerIds
	 *            the set of containerId
	 */
	private void findAllDelContainerIds(Set<Integer> containerIds,
			List<Integer> scopesClient) {
		final Collection<Value> values = delScriptMap.values();
		boolean isScopeSpec = CollectionsUtil.isNotEmpty(scopesClient);

		for (final Value v : values) {
			Set<Integer> cIds = v.getContainerIds();
			Integer defaultScope = v.getScope();
			if (CollectionsUtil.isNotEmpty(cIds)) {
				// if scope from client is not specified
				// use default scope from script
				containerIds.addAll(isScopeSpec ? ScopeUtil.getRealContainerId(
						cIds, scopesClient) : ScopeUtil.getRealContainerId(
						cIds, defaultScope));
			} else {
				log.warn("Container Id(s) is null or empty..");
			}
		}
	}

	/**
	 * ScriptFunction mapping to HIGH_LEVEL_SERVICE_LAYOUTS(name)
	 * 
	 * @author liuyq
	 * 
	 */
	public static enum ScriptFunction {
		REGISTRATION, DELETION, TI, LI, LIS, LLI, LLIS, TLI, TLIS, LIP, TLIP, LLIP, TIM, LIM, FI, TLIM, LLIM, LIX, TLIX, LLIX, II
	}

	/**
	 * SingletonHolder
	 * 
	 * @author liuyq
	 * 
	 */
	static class SingletonHolder {
		public static final ScriptManager SCRIPTMANAGER = new ScriptManager();
	}

	public static ScriptManager getInstance() {
		return SingletonHolder.SCRIPTMANAGER;
	}

	public void clear() {

		inqScriptMap.clear();
		delScriptMap.clear();
		regScriptMap.clear();
		layoutMap.clear();
	}

	/**
	 * Print the InquiryMap
	 */
	public void printInquiryMap() {
		for (Key key : inqScriptMap.keySet()) {
			log.info("=================key: {} ===============", key.toString());
			Value value = inqScriptMap.get(key);
			log.info("=================value: {} ===============",
					value.toString());
		}
	}
}
