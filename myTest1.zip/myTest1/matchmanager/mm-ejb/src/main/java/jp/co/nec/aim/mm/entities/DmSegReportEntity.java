package jp.co.nec.aim.mm.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the DM_SEG_REPORTS database table.
 * 
 */
@Entity
@IdClass(jp.co.nec.aim.mm.entities.DmSegReportPK.class)
@Table(name = "DM_SEG_REPORTS")
public class DmSegReportEntity implements UnitSegReport {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4050210388523931293L;
	private long dmId;
	private long segmentId;
	private Long version;
	private Long queuedVersion;
	private int status;

	@Id
	@Column(name = "DM_ID")
	public long getDmId() {
		return dmId;
	}

	public void setDmId(long dmId) {
		this.dmId = dmId;
	}

	@Id
	@Column(name = "SEGMENT_ID")
	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	@Column(name = "STATUS")
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	private boolean versionMatches(Long otherVersion) {
		if (version == null)
			return otherVersion == null;
		return version.equals(otherVersion);
	}

	private boolean queuedVersionMatches(Long otherQueuedVersion) {
		if (queuedVersion == null)
			return otherQueuedVersion == null;
		return queuedVersion.equals(otherQueuedVersion);
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof MuSegReportEntity) {
			MuSegReportEntity other = (MuSegReportEntity) o;
			return versionMatches(other.getVersion())
					&& queuedVersionMatches(other.getQueuedVersion())
					&& new Integer(status).equals(other.getStatus());
		}
		return false;
	}

	@Override
	public int hashCode() {
		int result = 17;
		if (version != null) {
			long val = version.longValue();
			result = 37 * result + (int) (val ^ (val >>> 32));
		}
		if (queuedVersion != null) {
			long val = queuedVersion.longValue();
			result = 37 * result + (int) (val ^ (val >>> 32));
		}
		result = 37 * result + status;
		return result;
	}

	public String toString() {
		return "{ " + dmId + " => seg " + segmentId + " (v." + version + ", q."
				+ queuedVersion + ") [" + status + "] }";
	}

	@Column(name = "SEGMENT_VERSION")
	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

	@Transient
	@Override
	public long getUnitId() {
		return this.dmId;
	}

	@Transient
	@Override
	public Long getQueuedVersion() {
		return this.version;
	}

	@Transient
	@Override
	public void setQueuedVersion(Long queuedVersion) {
		// do nothing
	}

	@Override
	public void setUnitId(long unitId) {
		this.dmId = unitId;
	}

}