package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class JobPurgerDaoTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private DateDao dateDao;
	private long curTime;
	private JobPurgerDao dao;

	@Before
	public void setUp() throws Exception {
		clearDB();

		dateDao = new DateDao(dataSource);
		curTime = dateDao.getCurrentTimeMS();
		intsertInquiryJob();
		insertFeJob();

		jdbcTemplate.execute("insert into system_config values(1,"
				+ " 'PURGE_JOB_QUEUE.PERIOD_HOUR', '10')");
		jdbcTemplate.update("commit");

		entityManager.flush();

		dao = new JobPurgerDao(entityManager);
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from system_config");
		jdbcTemplate.execute("commit");
	}

	private void intsertInquiryJob() {
		String jqSQL = "insert into JOB_QUEUE(JOB_ID, PRIORITY, JOB_STATE,"
				+ " SUBMISSION_TS, ASSIGNED_TS, CALLBACK_STYLE, TIMEOUTS,"
				+ " FAILURE_COUNT, REMAIN_JOBS, FAMILY_ID, RESULT_TS)"
				+ " values(?, 5, ?, 1421206612748, ?, 0, 900000, ?, ?, ?, ?)";

		for (int jobId = 1; jobId <= 3; jobId++) {
			jdbcTemplate.update(jqSQL, new Object[] { jobId, 2,
					curTime - 10000, 0, 4, jobId, curTime });
		}
	}

	private void insertFeJob() {

		String fejSQL = "insert into FE_JOB_QUEUE(JOB_ID, LOT_JOB_ID, PRIORITY,"
				+ " FUNCTION_ID, JOB_STATE, SUBMISSION_TS, ASSIGNED_TS, RESULT_TS,"
				+ " CALLBACK_STYLE, CALLBACK_URL, FAILURE_COUNT) values(?, null,"
				+ "  5,17, ?, 1421206612748, ?, ?, 1, 'test Url', ?)";

		for (int fejId = 1; fejId <= 3; fejId++) {
			jdbcTemplate.update(fejSQL, new Object[] { fejId, 2,
					curTime - 10000, curTime, 0 });
		}
	}

	@Test
	public void test_purgeByResultTs() {

		int count = dao.purgeByResultTs();
		assertEquals(0, count);

		jdbcTemplate.update("update FE_JOB_QUEUE set RESULT_TS = 110000");
		jdbcTemplate.update("update JOB_QUEUE set RESULT_TS = 110000");
		jdbcTemplate.update("commit");

		count = dao.purgeByResultTs();
		assertEquals(6, count);
	}
}
