package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class NodeStorageManager {
	Integer nsmId;
	String url;
	String status;// 'PENDING', 'WORKING', 'EXIT', 'INSPECTION', 'DETACHED'
	Timestamp updateTs;
	String mailFlag;
}
