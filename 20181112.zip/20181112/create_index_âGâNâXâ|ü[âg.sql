--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-12-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function CREATE_SEG_BK_INDEX
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "UFTEST"."CREATE_SEG_BK_INDEX" 
(
  PROCCSS_SIZE IN NUMBER,
  skip_count IN NUMBER
) RETURN VARCHAR2  AUTHID CURRENT_USER IS 
  v_json  VARCHAR2(4096);  
  l_back_log_path VARCHAR2(128 BYTE);
  l_back_log_file_name VARCHAR2(36);
  l_hour  VARCHAR2(2);
  l_bin_id NUMBER;
  l_segment_id NUMBER;
  l_segment_version NUMBER;
  
   t_out_file   UTL_FILE.file_type;
   t_buffer     VARCHAR2(32767);
   t_amount     BINARY_INTEGER := 1000;
   t_pos        INTEGER := 1;
   t_clob_len   INTEGER;
   P_DATA CLOB;

  l_file    utl_file.file_type;
  l_amt     NUMBER := 32000;
  l_offset  NUMBER := 1;  
  l_buffer LONG RAW;
  l_file_buffer_size   INTEGER := 32000;
  l_totalsize NUMBER;

BEGIN
    SELECT JSON_OBJECT (
            KEY 'BIOMETRIC_ID' VALUE e.BIOMETRIC_ID,
            KEY 'EXTERNAL_ID' VALUE e.EXTERNAL_ID,
            KEY 'EVENT_ID' VALUE e.EVENT_ID ,
            KEY 'BIN_ID' VALUE e.BIN_ID,
            KEY 'STATUS' VALUE e.STATUS,
            KEY 'PHASE' VALUE e.PHASE,
            KEY 'CREATE_DATETIME' VALUE e.CREATE_DATETIME,
            KEY 'UPDATE_DATETIME' VALUE e.UPDATE_DATETIME,
            KEY 'TEMPLATE_DATA_KEY' VALUE e.TEMPLATE_DATA_KEY,
            KEY 'TEMPLATE_SIZE' VALUE e.TEMPLATE_SIZE,
            KEY 'DATA_VERSION' VALUE e.DATA_VERSION,
            KEY 'ASSIGNED_SEGMENT_ID' VALUE e.ASSIGNED_SEGMENT_ID,
            KEY  'SITE_ID' VALUE e.SITE_ID) INTO v_json 
    FROM BIO_EVENT_INFO e
    WHERE rownum > skip_count and rownum <= PROCCSS_SIZE
    ORDER BY e.BIOMETRIC_ID; 
    SELECT BIN_ID ,ASSIGNED_SEGMENT_ID ,DATA_VERSION INTO l_bin_id, l_segment_id, l_segment_version FROM BIO_EVENT_INFO WHERE rownum > skip_count and rownum <= PROCCSS_SIZE; 
    SELECT value INTO l_back_log_path FROM BIO_PARAMETERS WHERE name ='SEGMENT_CHANGE_SET_STORAGE_PATH';
    l_back_log_path := l_back_log_path  || '/' || l_bin_id || '/' || l_segment_id || '/' || l_hour;
    l_back_log_file_name := TO_CHAR(l_segment_id) || '_' || l_segment_version || '.idx';
    
    P_DATA :=v_json;
   t_clob_len := DBMS_LOB.GetLength(P_DATA);
   t_out_file := UTL_FILE.fOpen('BLOBS',l_back_log_file_name, 'W', 32767);
      WHILE t_pos < t_clob_len LOOP  
      DBMS_LOB.Read(p_data, t_amount, t_pos, t_buffer);
      UTL_FILE.Put(t_out_file, t_buffer);
      UTL_FILE.fflush(t_out_file);      
      t_pos := t_pos + t_amount;
   END LOOP;
  RETURN  'SUCCESS'; 
  EXCEPTION
    WHEN OTHERS THEN   
     IF UTL_FILE.is_open(l_file) THEN
          UTL_FILE.fclose(l_file);
    END IF;
    RETURN 'FAILD';
END CREATE_SEG_BK_INDEX;

/
