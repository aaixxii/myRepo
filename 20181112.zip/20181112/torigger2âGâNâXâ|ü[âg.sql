--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-12-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Trigger BIO_EVENT_INSERTED
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "UFTEST"."BIO_EVENT_INSERTED" 
AFTER INSERT ON BIO_EVENT_INFO 
 DECLARE
  l_result  VARCHAR2(20); 
BEGIN
   l_result := CREATE_SEG_BK_INDEX(1,0);
END;
/
ALTER TRIGGER "UFTEST"."BIO_EVENT_INSERTED" ENABLE;
