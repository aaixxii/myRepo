--------------------------------------------------------
--  ファイルを作成しました - 日曜日-11月-11-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure SAVE_IMAGES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UFTEST"."SAVE_IMAGES" (start_biometric_id VARCHAR2,
                                        bin_id             IN NUMBER,
                                        segminet_id        IN NUMBER)
authid current_user
IS
  l_id                 VARCHAR2(60 byte);
  v_blob_locater       BLOB;
  v_offset             INTEGER := 1;
  v_buffer             LONG RAW;
  l_hour               VARCHAR2(2);
  l_back_log_file_name VARCHAR2(36);
  v_file_buffer_size   INTEGER := 32000;
  v_amount             INTEGER := 32000;
  v_totalsize          INTEGER;
  v_filetype           utl_file.file_type;
  v_openmode           VARCHAR2(2) := 'wb';
  l_count              NUMBER;
BEGIN
    FOR rec IN (SELECT *
                FROM   bio_template_data_info where TEMPLATE_DATA_ID <> start_biometric_id) LOOP
         v_offset :=1;
         v_buffer := null;
        l_id := rec.template_data_id;
        v_blob_locater := rec.template_data;
        v_totalsize := dbms_lob.Getlength(v_blob_locater);
        SELECT To_char(systimestamp, 'HH24')
        INTO   l_hour
        FROM   dual;
        -- l_back_log_path:= l_back_log_path  || '/' || BIN_ID || '/' || SEGMINET_ID || '/' || l_hour;
        l_back_log_file_name := segminet_id
                                || '_'
                                || bin_id
                                || '_'
                                || l_id
                                || '.bmp';

        v_totalsize := dbms_lob.Getlength(rec.template_data);

        v_filetype := utl_file.Fopen('BLOBS', l_back_log_file_name, v_openmode,
                      v_file_buffer_size);
        WHILE v_offset < v_totalsize LOOP
            IF v_offset + v_amount > v_totalsize THEN
              v_amount := v_totalsize - v_offset + 1;
            END IF;
            dbms_lob.READ(rec.template_data, v_amount, v_offset, v_buffer);
            utl_file.Put_raw(v_filetype, v_buffer, TRUE);
            v_offset := v_offset + v_amount;
        -- dbms_output.put_line ( 'Offset : ' || v_offset );
        END LOOP;
        utl_file.Fflush(v_filetype);
        utl_file.Fclose(v_filetype);
    END LOOP;
END save_images;

/
