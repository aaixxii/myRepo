--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-12-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure INSERTBLOB
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UFTEST"."INSERTBLOB" (id varchar2,imgFile varchar2)
is
  img_file    bfile;
  img_blob    blob;
  lob_len     number;
begin 
  
  insert into BIO_TEMPLATE_DATA_INFO(TEMPLATE_DATA_ID, TEMPLATE_DATA,CREATE_DATETIME,UPDATE_DATETIME ) values(id, empty_blob(), sysdate, sysdate);
  select TEMPLATE_DATA into img_blob from BIO_TEMPLATE_DATA_INFO where TEMPLATE_DATA_ID=id;  
  img_file :=bfilename('PHOTO',imgFile);
  dbms_lob.open(img_file);  
  lob_len :=dbms_lob.getlength(img_file);  
  dbms_lob.loadfromfile(img_blob,img_file,lob_len);
  dbms_lob.close(img_file);
  commit;
end;

/
