--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-12-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure SAVE_SEG_BACK_LOG
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UFTEST"."SAVE_SEG_BACK_LOG" 
(
  START_BIOMETRIC_ID IN VARCHAR2,
  BIN_ID IN NUMBER,
  SEGMINET_ID IN NUMBER
) AUTHID CURRENT_USER IS 
    l_file      UTL_FILE.FILE_TYPE;
    l_buffer    RAW(3200);
    l_file_buffer_size	integer := 32000;
    l_amount    integer := 32000;
    l_pos       INTEGER := 1;
    v_buffer		long raw;	
	
    l_blob      BLOB;
    l_blob_len  INTEGER; 
    l_sql       VARCHAR2(50);
    l_back_log_path VARCHAR2(128 BYTE);
    l_back_log_file_name VARCHAR2(36);
    l_hour  VARCHAR2(2);
    --l_count NUMBER;
    l_index NUMBER :=1;
    CURSOR C1 IS
      SELECT TEMPLATE_DATA FROM BIO_TEMPLATE_DATA_INFO; 
      rec C1%rowtype;

BEGIN  
  -- SELECT count(TEMPLATE_DATA_ID) INTO l_count FROM BIO_TEMPLATE_DATA_INFO;
   OPEN C1;   
   LOOP
      FETCH C1 INTO rec;
        EXIT WHEN C1%NOTFOUND;
          l_blob := rec.TEMPLATE_DATA;
          l_blob_len := DBMS_LOB.getlength(l_blob); 
          SELECT TO_CHAR(systimestamp, 'HH24') INTO l_hour FROM dual;
         -- l_back_log_path:= l_back_log_path  || '/' || BIN_ID || '/' || SEGMINET_ID || '/' || l_hour;  
          l_back_log_file_name := SEGMINET_ID || '_' || l_index || '.bmp';  
          l_file := UTL_FILE.fopen('PHOTO',  l_back_log_file_name, 'wb', 32000);          
          WHILE l_pos <= l_blob_len LOOP
          		if l_pos + l_amount > l_blob_len then
		            	l_amount := l_blob_len - l_pos + 1;
		          end if;
              		dbms_lob.read(l_blob, l_amount, l_pos, l_buffer);
		             utl_file.put_raw(l_file,l_buffer,true);
              		--dbms_lob.read(l_blob,v_amount, 1,	v_buffer);
             -- DBMS_LOB.read(l_blob, l_amount, l_pos, l_buffer);
             -- UTL_FILE.put_raw(l_file, l_buffer, TRUE);
              l_pos := l_pos + l_amount;
         END LOOP;      
      utl_file.fflush(l_file);
      UTL_FILE.fclose(l_file);
  l_index:=l_index +1;
  END LOOP;
    EXCEPTION
      WHEN OTHERS THEN   
        IF UTL_FILE.is_open(l_file) THEN
           UTL_FILE.fclose(l_file);
        END IF;
      
END SAVE_SEG_BACK_LOG;

/
