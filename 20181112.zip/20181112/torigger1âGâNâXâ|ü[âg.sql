--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-12-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Trigger TEMPLATE_INSERTED_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE TRIGGER "UFTEST"."TEMPLATE_INSERTED_TRIGGER" AFTER
  INSERT ON BIO_TEMPLATE_DATA_INFO FOR EACH row   
  DECLARE
  l_segment_id           NUMBER;
  l_bin_id               NUMBER :=35;
  l_start_bio_id         VARCHAR2(20);  
  BEGIN
    dbms_output.put_line('TEMPLATE_INSERTED_TRIGGER is running');
    SELECT MAX(to_number(TEMPLATE_DATA_ID)) -50
    INTO l_start_bio_id
    FROM BIO_TEMPLATE_DATA_INFO;
    SELECT SEGMENT_ID
    INTO l_segment_id
    FROM BIO_IDENTIFIER_INFO
    WHERE BIN_ID  =l_bin_id
    AND SEGMENT_ID=
      (SELECT MAX(SEGMENT_ID) FROM BIO_IDENTIFIER_INFO
      );
    SAVE_SEG_BACK_LOG(l_start_bio_id,l_bin_id,l_segment_id);   
  END;
/
ALTER TRIGGER "UFTEST"."TEMPLATE_INSERTED_TRIGGER" ENABLE;
