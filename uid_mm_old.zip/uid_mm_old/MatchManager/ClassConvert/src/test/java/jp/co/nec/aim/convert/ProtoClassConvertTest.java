package jp.co.nec.aim.convert;

import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assume.*;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jp.co.nec.aim.clientapi.CommonOptions;
import jp.co.nec.aim.clientapi.afis.AfisDeletionFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisRegistrationFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisUpdateFunctionEnum;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.DivideFeTypesWith_String_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToListBasicImageEnhanceType_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBAimFormatWith_AimFormats_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBAimFormatWith_Latent_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBAimFormatWith_TenprintInput_ListOfPBExtractInputImages_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBBasicImageEnhanceOptionsWith_ImageEnhance_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBBasicImageEnhanceOptionsWith_LatentInput2Enhancements_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBBasicImageEnhanceOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBChechkExternalIdRequest_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBCmlafExtractParam_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBCmlafOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBCmlOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBCropPoint_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractCmlafOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractCommonOptionTenprint_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractFaceInput_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractFeTypeEventWith_FeTypeLatent_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractFeTypeEventWith_LatentInput2Images_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractFeTypeWith_FeTypeLatent_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractFeTypeWith_FeTypeTenprint_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractFeTypeWith_String_FingerPrintType_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputFaceDetection_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputFaceExtraction_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputImageWith_FaceInputImage_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputImageWith_LatentInput2Images_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputImageWith_TenprintInput2Images;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputImage_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputIrisExtraction_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputMarkUp_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputMinutiaLatent_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractInputMinutiaTenprint_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractIrisInput_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractJobBinaryRequest_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractJobRequest_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractLatentInput_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBExtractTenprintInput_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFace13Points_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFace2Points_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFaceDetectionParams_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFaceExtractionParam_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFingerCropCoordinateWith_ListOfSegInfos_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFisCore_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFisData_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFisMinutiaNo_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBFisQuality_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInputMinutiaData_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInquiryFusionWeight_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInquiryFusionWeight_Helper.ExceptionParameter;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInquiryJobInfo_Help;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInquiryJobRequestWith_AfisLowLevelFunctionEnum_AfisTemplateSet_CommonOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInquiryJobRequestWith_ListOfSearchRequest_CommonOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInquiryPayload_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBInquiryScopeOptionsWith_KeyedTemplate_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBIrisOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBKeyedTemplateDataWith_KeyedTemplate_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBKeyedTemplateDataWith_SearchRequest_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBKeyedTemplateDataWith_String_byteArray_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBKeyedTemplateIndexer_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBKeyedTemplateReference_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBKeyedTemplate_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBLeOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBLfmlOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBMatchableFingersThresholds_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBMetaInfoCommonWith_MetaCommon_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBMetaInfoLatentWith_MetaLatent_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBMetaInfoTenprintWith_MetaTenprint_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBMetaInfo_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBPalmOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBPc2Options_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBPoint_FacePoint_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBPoint_Point_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBPrefilterOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBPreselectionOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBQualityCheckOptions_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncDeletePayloadWith_AfisUpdateFunctionEnum_Integer_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncDeletePayload_ListOfInteger_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncInsertPayloadWith_AfisUpdateFunctionEnum_AfisTemplateSet_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncJobRequestWith_AfisDeletionFunctionEnum_String_Integer_Integer_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncJobRequestWith_AfisRegistrationFunctionEnum_String_int_AfisTemplateSet_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncJobRequestWith_AfisUpdateFunctionEnum_String_Integer_int_Integer_AfisTemplateSet_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncJobRequestWith_String_Integer_ListOfInteger_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBSyncJobRequestWith_String_int_ListOfRegistrationRequest_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToPBUsePrefilterInfo_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ToString_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.UpdateGenderAndYob_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ValidateFunctionToKey_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ValidateNumAfisGroupId_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ValidationContaineridOnFunction_Helper;
import jp.co.nec.aim.helper.ProtoClassConvertTestHelper.ValidationContaineridOnFunction_Helper.Parameter;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.GenderType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateReference;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfo;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoCommon;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoLatent;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoTenprint;
import jp.co.nec.aim.message.proto.CommonPayloads.PBPrefilterOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBUsePrefilterInfo;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.BasicImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBAimFormat;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBBasicImageEnhanceOptions;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBCMLaFExtractParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBCropPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCMLaFOptions;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCommonOptionTenprint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeTypeEvent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputFaceDetection;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputFaceExtraction;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputImage;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputIrisExtraction;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMarkUp;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMinutiaLatent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMinutiaTenprint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace13Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace2Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceDetectionParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceExtractionParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerCropCoordinate;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisCore;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisMinutiaNo;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisQuality;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBInputMinutiaData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOptions;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryRequest;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLaFMatchableFingerThreshold;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLaFOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryPayload;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBIrisOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBLfmlOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBLeOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBPc2Options;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBPreselectionOptions;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusRequest;
import jp.co.nec.aim.message.proto.ManageService.PBCallbackRequest;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdRequest;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncInsertPayload;
import jp.co.nec.aim.mm.jaxb.AfisTemplateSet;
import jp.co.nec.aim.mm.jaxb.AimFormats;
import jp.co.nec.aim.mm.jaxb.CmlafTiOptions;
import jp.co.nec.aim.mm.jaxb.CmlOptions;
import jp.co.nec.aim.mm.jaxb.CropInfo;
import jp.co.nec.aim.mm.jaxb.DynamicXml;
import jp.co.nec.aim.mm.jaxb.EnhType;
import jp.co.nec.aim.mm.jaxb.ExtractResultReference;
import jp.co.nec.aim.mm.jaxb.ExtractionInputs;
import jp.co.nec.aim.mm.jaxb.ExtractionInputsPayload;
import jp.co.nec.aim.mm.jaxb.FaceInput;
import jp.co.nec.aim.mm.jaxb.FaceInputDetection;
import jp.co.nec.aim.mm.jaxb.FaceInputExtraction;
import jp.co.nec.aim.mm.jaxb.FaceInputExtraction13Points;
import jp.co.nec.aim.mm.jaxb.FaceInputImage;
import jp.co.nec.aim.mm.jaxb.FacePoint;
import jp.co.nec.aim.mm.jaxb.FeTypeLatent;
import jp.co.nec.aim.mm.jaxb.FeTypeTenprint;
import jp.co.nec.aim.mm.jaxb.FusionWeight;
import jp.co.nec.aim.mm.jaxb.ImageEnhance;
import jp.co.nec.aim.mm.jaxb.IrisInput;
import jp.co.nec.aim.mm.jaxb.IrisInputExtraction;
import jp.co.nec.aim.mm.jaxb.IrisOptions;
import jp.co.nec.aim.mm.jaxb.KeyedTemplate;
import jp.co.nec.aim.mm.jaxb.LatentInput;
import jp.co.nec.aim.mm.jaxb.LeOptions;
import jp.co.nec.aim.mm.jaxb.LfmlOptions;
import jp.co.nec.aim.mm.jaxb.MarkUp;
import jp.co.nec.aim.mm.jaxb.MatchableFingersThresholds;
import jp.co.nec.aim.mm.jaxb.MetaInfo;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaCommon;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaLatent;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaTenprint;
import jp.co.nec.aim.mm.jaxb.PalmOptions;
import jp.co.nec.aim.mm.jaxb.Pc2Options;
import jp.co.nec.aim.mm.jaxb.Point;
import jp.co.nec.aim.mm.jaxb.PrefilterOptions;
import jp.co.nec.aim.mm.jaxb.PreselectionOptions;
import jp.co.nec.aim.mm.jaxb.QcInput;
import jp.co.nec.aim.mm.jaxb.Record;
import jp.co.nec.aim.mm.jaxb.RegistrationRequest;
import jp.co.nec.aim.mm.jaxb.SearchInputsPayload;
import jp.co.nec.aim.mm.jaxb.SearchOptions;
import jp.co.nec.aim.mm.jaxb.SearchRequest;
import jp.co.nec.aim.mm.jaxb.TemplateMetadata;
import jp.co.nec.aim.mm.jaxb.TenprintInput;
import jp.co.nec.aim.mm.jaxb.TenprintInput.CmlafExtOptions;
import jp.co.nec.aim.mm.jaxb.TenprintInput.InputMinutia.InputMinutiaData;
import jp.co.nec.aim.mm.jaxb.UsePrefilterInfo;
import mockit.Mock;
import mockit.MockUp;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import com.google.common.base.Throwables;
import com.google.protobuf.Message;

@RunWith(Enclosed.class)
public class ProtoClassConvertTest {
	/**
	 * test buildClass(Message.Builder)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class BuildClassWith_Message2Builder {
		public static ToPBMetaInfoCommonWith_MetaCommon_Helper.Fixture fixture =
			ToPBMetaInfoCommonWith_MetaCommon_Helper.build("full setr");

		@Test
		public void testBuild()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("buildClass",
					Message.Builder.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.expected.toBuilder());

			// verify
			assertThat(actual, is(notNullValue()));
		}
	}

	/***
	 * test nullToList(List<E>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class NullToListWith_List {
		@SuppressWarnings("boxing")
		@Test
		public void testNUllToList()
			throws Exception {
			// setup
			List<MetaInfo> parameter = null;

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("nullToList", List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<MetaInfo> actual = (List<MetaInfo>)sut.invoke(null, parameter);

			// verify
			assertThat(actual.size(), is(0));
		}
	}

	/**
	 * test toPBMetaInfoCommon(MetaCommon)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBMetaInfoCommonWith_MetaCommon {
		@DataPoints
		public static ToPBMetaInfoCommonWith_MetaCommon_Helper.Fixture[] getFixtures() {
			return ToPBMetaInfoCommonWith_MetaCommon_Helper.fixtures;
		};

		@Theory
		public void testReturnGender(
			ToPBMetaInfoCommonWith_MetaCommon_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoCommon",
					MetaCommon.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getGender(), is(fixture.expected.getGender()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnYob(ToPBMetaInfoCommonWith_MetaCommon_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoCommon",
					MetaCommon.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getYob(), is(fixture.expected.getYob()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnYobRange(
			ToPBMetaInfoCommonWith_MetaCommon_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoCommon",
					MetaCommon.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getYobRange(), is(fixture.expected.getYobRange()));
		}

		@Theory
		public void testReturnRace(
			ToPBMetaInfoCommonWith_MetaCommon_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoCommon",
					MetaCommon.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRace(), is(fixture.expected.getRace()));
		}

		@Theory
		public void testReturnRegion(
			ToPBMetaInfoCommonWith_MetaCommon_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoCommon",
					MetaCommon.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRegionList(), is(fixture.expected.getRegionList()));
		}
	}

	/**
	 * test toPBMetaInfoTenprint(MetaTenprint)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBMetaInfoTenprintWith_MetaTenprint {
		@DataPoints
		public static ToPBMetaInfoTenprintWith_MetaTenprint_Helper.Fixture[] getFixtures() {
			return ToPBMetaInfoTenprintWith_MetaTenprint_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnPrimaryPattern(
			ToPBMetaInfoTenprintWith_MetaTenprint_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoTenprint",
					MetaTenprint.class);
			sut.setAccessible(true);
			PBMetaInfoTenprint actual =
				(PBMetaInfoTenprint)sut.invoke(null, fixture.parameter);

			// verify
			if (fixture.mode.equals("not empty")) {
				assertThat(actual.getPrimaryPatternsList(), is(fixture.expected
					.getPrimaryPatternsList()));
			} else if (fixture.mode.equals("empty") || fixture.mode.equals("null")) {
				assertThat(actual.getPrimaryPatternsCount(), is(0));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnReferencePattern(
			ToPBMetaInfoTenprintWith_MetaTenprint_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoTenprint",
					MetaTenprint.class);
			sut.setAccessible(true);
			PBMetaInfoTenprint actual =
				(PBMetaInfoTenprint)sut.invoke(null, fixture.parameter);

			// verify
			if (fixture.mode.equals("not empty")) {
				assertThat(actual.getReferencePatternsList(), is(fixture.expected
					.getReferencePatternsList()));
			} else if (fixture.mode.equals("empty") || fixture.mode.equals("null")) {
				assertThat(actual.getPrimaryPatternsCount(), is(0));
			}
		}
	}

	/**
	 * test toPBMetaInfoLatent(MetaLatent)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBMetaInfoLatentWith_MetaLatent {
		public static ToPBMetaInfoLatentWith_MetaLatent_Helper.Fixture fixture =
			ToPBMetaInfoLatentWith_MetaLatent_Helper.build();

		@Test
		public void testReturnSelectFingers()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoLatent",
					MetaLatent.class);
			sut.setAccessible(true);
			PBMetaInfoLatent actual =
				(PBMetaInfoLatent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSelectFingersList(), is(fixture.expected
				.getSelectFingersList()));
		}

		@Test
		public void testReturnSelectParts()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoLatent",
					MetaLatent.class);
			sut.setAccessible(true);
			PBMetaInfoLatent actual =
				(PBMetaInfoLatent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSelectPartsList(), is(fixture.expected
				.getSelectPartsList()));
		}

		@Test
		public void testReturnLatentPatterns()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoLatent",
					MetaLatent.class);
			sut.setAccessible(true);
			PBMetaInfoLatent actual =
				(PBMetaInfoLatent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLatentPatternsList(), is(fixture.expected
				.getLatentPatternsList()));
		}

		@Test
		public void testReturnPrimaryAdjacentPattern()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoLatent",
					MetaLatent.class);
			sut.setAccessible(true);
			PBMetaInfoLatent actual =
				(PBMetaInfoLatent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPrimaryAdjacentPatternsList(), is(fixture.expected
				.getPrimaryAdjacentPatternsList()));
		}

		@Test
		public void testReturnReferenceAdjacentPattern()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfoLatent",
					MetaLatent.class);
			sut.setAccessible(true);
			PBMetaInfoLatent actual =
				(PBMetaInfoLatent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getReferenceAdjacentPatternsList(), is(fixture.expected
				.getReferenceAdjacentPatternsList()));
		}
	}

	/**
	 * test toPBMetaInfo(MetaInfo)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBMetaInfoWith_MetaInfo {
		public static ToPBMetaInfo_Helper.Fixture fixture = ToPBMetaInfo_Helper.build();

		@Test
		public void testHasCommon()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfo", MetaInfo.class);
			sut.setAccessible(true);
			PBMetaInfo actual = (PBMetaInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCommon(), is(notNullValue()));
		}

		@Test
		public void testHasTenprint()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfo", MetaInfo.class);
			sut.setAccessible(true);
			PBMetaInfo actual = (PBMetaInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTenprint(), is(notNullValue()));
		}

		@Test
		public void testHasLatent()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBMetaInfo", MetaInfo.class);
			sut.setAccessible(true);
			PBMetaInfo actual = (PBMetaInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLatent(), is(notNullValue()));
		}
	}

	/**
	 * test toPBExtractInputImage( List<InputImage>, List<PBExtractInputImage>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages {
		public static ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
			ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
				.build("C", "C");

		@Before
		public void setUp() {
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnPosition()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getPosition(), is(fixture.expected
					.get(index).getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoReturnPositionIfPositionIsZero()
			throws Exception {
			// setup
			fixture.parameter.get(0).setPos("0");
			fixture.expected.get(0).toBuilder().clearPosition();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			assertThat(actual.get(0).getPosition(), is(fixture.expected.get(0)
				.getPosition()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoReturnPositionIfPositionIsTwenty()
			throws Exception {
			// setup
			fixture.parameter.get(0).setPos("20");
			fixture.expected.get(0).toBuilder().clearPosition();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			assertThat(actual.get(0).getPosition(), is(fixture.expected.get(0)
				.getPosition()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getType(), is(fixture.expected.get(index)
					.getType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnVerticalScale()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getVertScale(), is(fixture.expected.get(
					index).getVertScale()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnDpi()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getDpi(), is(fixture.expected.get(index)
					.getDpi()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnWidth()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getWidth(), is(fixture.expected.get(index)
					.getWidth()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeight()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getHeight(), is(fixture.expected.get(index)
					.getHeight()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnWhiteBlackLevel()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getWhiteBlackType(), is(fixture.expected
					.get(index).getWhiteBlackType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnUrl()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getUrl(), is(fixture.expected.get(index)
					.getUrl()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnData()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getData(), is(fixture.expected.get(index)
					.getData()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasCropCoordinate()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class, List.class);
			sut.setAccessible(true);
			List<PBExtractInputImage> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getCropCoordinateCount(),
					is(fixture.expected.get(index).getCropCoordinateCount()));
			}
		}
	}

	/**
	 * test toPBPoint(Point pbPoint)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBPointWith_Point {
		public static ToPBPoint_Point_Helper.Fixture fixture = ToPBPoint_Point_Helper
			.build(1, 2);

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnX()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPoint", Point.class);
			sut.setAccessible(true);
			PBPoint actual = (PBPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getX(), is(fixture.expected.getX()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnY()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPoint", Point.class);
			sut.setAccessible(true);
			PBPoint actual = (PBPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getY(), is(fixture.expected.getY()));
		}
	}

	/**
	 * test toPBCropPoint(CropInfo)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBCropPointWith_PBCropPoint {
		public static ToPBCropPoint_Helper.Fixture fixture = ToPBCropPoint_Helper.build();

		@Test
		public void testHasCenter()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class
					.getDeclaredMethod("toPBCropPoint", CropInfo.class);
			sut.setAccessible(true);
			PBCropPoint actual = (PBCropPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCenter(), is(notNullValue()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnAngle()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class
					.getDeclaredMethod("toPBCropPoint", CropInfo.class);
			sut.setAccessible(true);
			PBCropPoint actual = (PBCropPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(new Double(actual.getAngle()), is(closeTo(new Double(
				fixture.expected.getAngle()), 0.01f)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPoints()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class
					.getDeclaredMethod("toPBCropPoint", CropInfo.class);
			sut.setAccessible(true);
			PBCropPoint actual = (PBCropPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPointsCount(), is(not(0)));
			assertThat(actual.getPointsCount(), is(fixture.expected.getPointsCount()));
		}
	}

	/**
	 * test toPBFingerCropCoordinate(List<SegInfo>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFingerCropCoordinateWith_ListOfSegInfos {
		public static ToPBFingerCropCoordinateWith_ListOfSegInfos_Helper.Fixture fixture =
			ToPBFingerCropCoordinateWith_ListOfSegInfos_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasPosition()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFingerCropCoordinate",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFingerCropCoordinate> actual =
				(List<PBFingerCropCoordinate>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getPosition(), is(fixture.expected
					.get(index).getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasAmputated()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFingerCropCoordinate",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFingerCropCoordinate> actual =
				(List<PBFingerCropCoordinate>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getAmputated(), is(fixture.expected.get(
					index).getAmputated()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasCropPoints()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFingerCropCoordinate",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFingerCropCoordinate> actual =
				(List<PBFingerCropCoordinate>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getCropPoints(), is(notNullValue()));
			}
		}
	}

	/**
	 * test toPBExtractInputImage(TenprintInput.Images)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputImageWith_TenprintInput$Images {
		public static ToPBExtractInputImageWith_TenprintInput2Images.Fixture fixture =
			ToPBExtractInputImageWith_TenprintInput2Images.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnObject()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					TenprintInput.Images.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputImage> actual =
				(List<PBExtractInputImage>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
		}
	}

	/**
	 * test toPBExtractFeType( String, FingerPrintType)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractFeTypeWith_String_FingerPrintType {
		public static ToPBExtractFeTypeWith_String_FingerPrintType_Helper.Fixture fixture =
			ToPBExtractFeTypeWith_String_FingerPrintType_Helper.build();

		@Test
		public void testReturnFingerType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeType",
					String.class, FingerPrintType.class);
			sut.setAccessible(true);
			PBExtractFeType actual =
				(PBExtractFeType)sut.invoke(null, fixture.parameter.feType,
					fixture.parameter.fingerPrintType);

			// verify
			assertThat(actual.getFingerType(), is(fixture.expected.getFingerType()));
		}

		@Test
		public void testReturnFisType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeType",
					String.class, FingerPrintType.class);
			sut.setAccessible(true);
			PBExtractFeType actual =
				(PBExtractFeType)sut.invoke(null, fixture.parameter.feType,
					fixture.parameter.fingerPrintType);

			// verify
			assertThat(actual.getFisType(), is(fixture.expected.getFisType()));
		}
	}

	/**
	 * test toPBExtractFeType(FeTypeTenprint)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractFeTypeWith_FeTypeTenprint {
		public static ToPBExtractFeTypeWith_FeTypeTenprint_Helper.Fixture fixture =
			ToPBExtractFeTypeWith_FeTypeTenprint_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFingerType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeType",
					FeTypeTenprint.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeType> actual =
				(List<PBExtractFeType>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFingerType(), is(fixture.expected.get(
					index).getFingerType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMinutiaType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeType",
					FeTypeTenprint.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeType> actual =
				(List<PBExtractFeType>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getMinutiaType(), is(fixture.expected.get(
					index).getMinutiaType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFisType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeType",
					FeTypeTenprint.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeType> actual =
				(List<PBExtractFeType>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFisType(), is(fixture.expected.get(index)
					.getFisType()));
			}
		}
	}

	/**
	 * test toPBExtractFeTypeEvent(List<FeTypeTenprint>)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints {
		@DataPoints
		public static ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints_Helper.Fixture[] getFixtures() {
			return ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnEvent(
			ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeTypeEvent> actual =
				(List<PBExtractFeTypeEvent>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getEvent(), is(fixture.expected.get(index)
					.getEvent()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasFteTypes(
			ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeTypeEvent> actual =
				(List<PBExtractFeTypeEvent>)sut.invoke(null, fixture.parameter);
			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFeTypesCount(), is(fixture.expected.get(
					index).getFeTypesCount()));
			}
		}
	}

	@RunWith(Theories.class)
	public static class DivideFeTypes_String {
		@DataPoints
		public static DivideFeTypesWith_String_Helper.Fixture[] getFixtures() {
			// setup
			return DivideFeTypesWith_String_Helper.fixtures;
		};

		@Theory
		public void testDivide(DivideFeTypesWith_String_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("divideFeTypes", String.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<String> actual = (List<String>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.toArray(new String[actual.size()]), is(fixture.expected));
		}
	}

	/**
	 * test List<PBExtractFeTypeEvent> toPBExtractFeTypeEvent( List<InputImage>,
	 * List<PBExtractInputImage>)
	 * 
	 * @author kawamura
	 * 
	 */
	@SuppressWarnings("boxing")
	@RunWith(Theories.class)
	public static class ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage {
		@DataPoints
		public static ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper.Fixture[] getFixtures() {
			return ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper.fixtures;
		}

		@Theory
		public void testReturnEvent(
			ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper.Fixture fixture)
			throws Exception {

			assumeTrue(!fixture.parameter.mode.equals("no fe-type"));

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					List.class, List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeTypeEvent> actual =
				(List<PBExtractFeTypeEvent>)sut.invoke(null,
					fixture.parameter.inputImageList,
					fixture.parameter.pbExtractInputImageList);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int i = 0; i < fixture.expected.size(); i++) {
				assertThat(actual.get(i).getEvent(), is(fixture.expected.get(i)
					.getEvent()));
			}
		}

		@Theory
		public void testHasFeTypes(
			ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(!fixture.parameter.mode.equals("no fe-type"));

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					List.class, List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeTypeEvent> actual =
				(List<PBExtractFeTypeEvent>)sut.invoke(null,
					fixture.parameter.inputImageList,
					fixture.parameter.pbExtractInputImageList);

			// verify
			for (int i = 0; i < fixture.expected.size(); i++) {
				assertThat(actual.get(i).getFeTypesCount(), is(not(0)));
				assertThat(actual.get(i).getFeTypesCount(), is(fixture.expected.get(i)
					.getFeTypesCount()));
				for (int index = 0; index < fixture.expected.get(i).getFeTypesCount(); index++) {
					assertThat(actual.get(i).getFeTypes(index), is(fixture.expected
						.get(i).getFeTypes(index)));
				}
			}

		}

		@Theory
		public void testHasNotPBExtractFeTypeEvent(
			ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.parameter.mode.equals("no fe-type"));

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					List.class, List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeTypeEvent> actual =
				(List<PBExtractFeTypeEvent>)sut.invoke(null,
					fixture.parameter.inputImageList,
					fixture.parameter.pbExtractInputImageList);

			// verify
			assertThat(actual.size(), is(0));
		}
	}

	/**
	 * test List<PBExtractFeTypeEvent> toPBExtractFeTypeEvent(LatentInput.Images
	 * )
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBExtractFeTypeEventWith_LatentInput2Images {
		@DataPoints
		public static ToPBExtractFeTypeEventWith_LatentInput2Images_Helper.Fixture[] getFixtures() {
			return ToPBExtractFeTypeEventWith_LatentInput2Images_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnEvent(
			ToPBExtractFeTypeEventWith_LatentInput2Images_Helper.Fixture fixture)
			throws Exception {

			assumeTrue(!fixture.parameter.mode.equals("no fe-type"));

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					LatentInput.Images.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeTypeEvent> actual =
				(List<PBExtractFeTypeEvent>)sut.invoke(null, fixture.parameter.images);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int i = 0; i < fixture.expected.size(); i++) {
				assertThat(actual.get(i).getEvent(), is(fixture.expected.get(i)
					.getEvent()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasFeTypes(
			ToPBExtractFeTypeEventWith_LatentInput2Images_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(!fixture.parameter.mode.equals("no fe-type"));

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					LatentInput.Images.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeTypeEvent> actual =
				(List<PBExtractFeTypeEvent>)sut.invoke(null, fixture.parameter.images);

			// verify
			for (int i = 0; i < fixture.expected.size(); i++) {
				assertThat(actual.get(i).getFeTypesCount(), is(not(0)));
				assertThat(actual.get(i).getFeTypesCount(), is(fixture.expected.get(i)
					.getFeTypesCount()));
				for (int index = 0; index < fixture.expected.get(i).getFeTypesCount(); index++) {
					assertThat(actual.get(i).getFeTypes(index), is(fixture.expected
						.get(i).getFeTypes(index)));
				}
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasNotPBExtractFeTypeEvent(
			ToPBExtractFeTypeEventWith_LatentInput2Images_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.parameter.mode.equals("no fe-type"));

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					LatentInput.Images.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeTypeEvent> actual =
				(List<PBExtractFeTypeEvent>)sut.invoke(null, fixture.parameter.images);

			// verify
			assertThat(actual.size(), is(0));
		}
	}

	/**
	 * test toPBAimFormat(TenprintInput, List<PBExtractInputImage>)
	 * 
	 * @author kawamura
	 * 
	 */

	public static class ToPBAimFormatWith_TenprintInput_ListOfPBExtractInputImages {
		public static ToPBAimFormatWith_TenprintInput_ListOfPBExtractInputImages_Helper.Fixture fixture =
			ToPBAimFormatWith_TenprintInput_ListOfPBExtractInputImages_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFormat()
			throws Exception { // exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBAimFormat",
					TenprintInput.class, List.class);
			sut.setAccessible(true);

			@SuppressWarnings("unchecked")
			List<PBAimFormat> actual =
				(List<PBAimFormat>)sut.invoke(null, fixture.parameter.tenprintInput,
					fixture.parameter.extractInputImageList);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFormat(), is(fixture.expected.get(index)
					.getFormat()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFeTypes()
			throws Exception { // exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBAimFormat",
					TenprintInput.class, List.class);
			sut.setAccessible(true);

			@SuppressWarnings("unchecked")
			List<PBAimFormat> actual =
				(List<PBAimFormat>)sut.invoke(null, fixture.parameter.tenprintInput,
					fixture.parameter.extractInputImageList);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				String message =
					"When format is  " + actual.get(index).getFormat().name();
				assertThat(message, actual.get(index).getFeTypeEventsCount(),
					is(fixture.expected.get(index).getFeTypeEventsCount()));
			}
		}
	}

	/**
	 * test toPBFisData(TenprintInput.InputMinutia.InputMinutiaData.Core)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBFisCoreWith_TenprintInput2InputMinutia2InputMinutiaData2Core {
		public static ToPBFisCore_Helper.Fixture fixture = ToPBFisCore_Helper.build();

		@Test
		public void testReturnA()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getA(), is(fixture.expected.getA()));
		}

		@Test
		public void testReturnF()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getF(), is(fixture.expected.getF()));
		}

		@Test
		public void testReturnCC()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCC(), is(fixture.expected.getCC()));
		}

		@Test
		public void testReturnQP()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQP(), is(fixture.expected.getQP()));
		}

		@Test
		public void testReturnQD()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQD(), is(fixture.expected.getQD()));
		}

		@Test
		public void testReturnQQ()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQQ(), is(fixture.expected.getQQ()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnX()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getX(), is(fixture.expected.getX()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnY()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getY(), is(fixture.expected.getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnD()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisCore",
					TenprintInput.InputMinutia.InputMinutiaData.Core.class);
			sut.setAccessible(true);
			PBFisCore actual = (PBFisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getD(), is(fixture.expected.getD()));
		}
	}

	/**
	 * test toPBFisQuality( TenprintInput.InputMinutia.InputMinutiaData.Quality)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBFisQualityWith_TenprintInput2InputMinutia2InputMinutiaData2Quality {
		public static ToPBFisQuality_Helper.Fixture fixture = ToPBFisQuality_Helper
			.build();

		@Test
		public void testReturnVA()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisQuality",
					TenprintInput.InputMinutia.InputMinutiaData.Quality.class);
			sut.setAccessible(true);
			PBFisQuality actual = (PBFisQuality)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getVA(), is(fixture.expected.getVA()));
		}

		@Test
		public void testReturnVB()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisQuality",
					TenprintInput.InputMinutia.InputMinutiaData.Quality.class);
			sut.setAccessible(true);
			PBFisQuality actual = (PBFisQuality)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getVB(), is(fixture.expected.getVB()));
		}

		@Test
		public void testReturnVC()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisQuality",
					TenprintInput.InputMinutia.InputMinutiaData.Quality.class);
			sut.setAccessible(true);
			PBFisQuality actual = (PBFisQuality)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getVC(), is(fixture.expected.getVC()));
		}

		@Test
		public void testReturnS()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisQuality",
					TenprintInput.InputMinutia.InputMinutiaData.Quality.class);
			sut.setAccessible(true);
			PBFisQuality actual = (PBFisQuality)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getS(), is(fixture.expected.getS()));
		}

	}

	/**
	 * test toPBFisMinutiaNo(
	 * TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBFisQualityWith_TenprintInput2InputMinutia2InputMinutiaData2MinutiaNo {
		public static ToPBFisMinutiaNo_Helper.Fixture fixture = ToPBFisMinutiaNo_Helper
			.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnDB()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisMinutiaNo",
					TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo.class);
			sut.setAccessible(true);
			PBFisMinutiaNo actual = (PBFisMinutiaNo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDB(), is(fixture.expected.getDB()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMB()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisMinutiaNo",
					TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo.class);
			sut.setAccessible(true);
			PBFisMinutiaNo actual = (PBFisMinutiaNo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMB(), is(fixture.expected.getMB()));
		}
	}

	/**
	 * test toPBFisData(InputMinutiaData)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBFisData_InputMinutiaData {
		public static ToPBFisData_Helper.Fixture fixture = ToPBFisData_Helper.build();

		@Test
		public void testReturnMinutia()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisData",
					InputMinutiaData.class);
			sut.setAccessible(true);
			PBFisData actual = (PBFisData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutia(), is(fixture.expected.getMinutia()));
		}

		@Test
		public void testReturnZone()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisData",
					InputMinutiaData.class);
			sut.setAccessible(true);
			PBFisData actual = (PBFisData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getZone(), is(fixture.expected.getZone()));
		}

		@Test
		public void testReturnSkeleton()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisData",
					InputMinutiaData.class);
			sut.setAccessible(true);
			PBFisData actual = (PBFisData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSkeleton(), is(fixture.expected.getSkeleton()));
		}

		@Test
		public void testHasFisCore()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisData",
					InputMinutiaData.class);
			sut.setAccessible(true);
			PBFisData actual = (PBFisData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFisCore(), is(notNullValue()));
		}

		@Test
		public void testHasFisQuality()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisData",
					InputMinutiaData.class);
			sut.setAccessible(true);
			PBFisData actual = (PBFisData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFisQuality(), is(notNullValue()));
		}

		@Test
		public void testHasFisMinutiaNo()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFisData",
					InputMinutiaData.class);
			sut.setAccessible(true);
			PBFisData actual = (PBFisData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFisMinutiaNo(), is(notNullValue()));
		}
	}

	/**
	 * test toPBInputMinutiaData(
	 * List<TenprintInput.InputMinutia.InputMinutiaData> )
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBInputMinutiaData_ListOfTenprintInput2InputMinutia2InputMinutiaData {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnPosition()
			throws Exception {
			// setup
			ToPBInputMinutiaData_Helper.Fixture fixture =
				ToPBInputMinutiaData_Helper.build("fis");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInputMinutiaData",
					MinutiaType.class, List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBInputMinutiaData> actual =
				(List<PBInputMinutiaData>)sut.invoke(null, fixture.parameter.minutiaType,
					fixture.parameter.inputMinutiaData);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getPosition(), is(fixture.expected
					.get(index).getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnData()
			throws Exception {
			// setup
			ToPBInputMinutiaData_Helper.Fixture fixture =
				ToPBInputMinutiaData_Helper.build("binary");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInputMinutiaData",
					MinutiaType.class, List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBInputMinutiaData> actual =
				(List<PBInputMinutiaData>)sut.invoke(null, fixture.parameter.minutiaType,
					fixture.parameter.inputMinutiaData);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getData(), is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFisData()
			throws Exception {
			// setup
			ToPBInputMinutiaData_Helper.Fixture fixture =
				ToPBInputMinutiaData_Helper.build("fis");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInputMinutiaData",
					MinutiaType.class, List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBInputMinutiaData> actual =
				(List<PBInputMinutiaData>)sut.invoke(null, fixture.parameter.minutiaType,
					fixture.parameter.inputMinutiaData);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFisData(), is(notNullValue()));
			}
		}
	}

	/**
	 * test toPBExtractInputMinutiaTenprint( List<TenprintInput.InputMinutia> )
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputMinutiaTenprintWith_ListOfTenprintInput2InputMinutia {
		public static ToPBExtractInputMinutiaTenprint_Helper.Fixture fixture =
			ToPBExtractInputMinutiaTenprint_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMinutiaType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputMinutiaTenprint", List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputMinutiaTenprint> actual =
				(List<PBExtractInputMinutiaTenprint>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getMinutiaType(), is(fixture.expected.get(
					index).getMinutiaType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnDbType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputMinutiaTenprint", List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputMinutiaTenprint> actual =
				(List<PBExtractInputMinutiaTenprint>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getDbType(), is(fixture.expected.get(index)
					.getDbType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasMinutiaData()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputMinutiaTenprint", List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputMinutiaTenprint> actual =
				(List<PBExtractInputMinutiaTenprint>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getMinutiaDataCount(), is(fixture.expected
					.get(index).getMinutiaDataCount()));
			}
		}
	}

	/**
	 * test toPBPrefilterOptions( PrefilterOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBPrefilterOptionsWith_PrefilterOptions {
		@DataPoints
		public static ToPBPrefilterOptions_Helper.Fixture[] getFixtures() {
			return ToPBPrefilterOptions_Helper.fixtures;
		};

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnUpdatePrefilter(ToPBPrefilterOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPrefilterOptions",
					PrefilterOptions.class);
			sut.setAccessible(true);
			PBPrefilterOptions actual =
				(PBPrefilterOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getUpdatePrefilter(), is(fixture.expected
				.getUpdatePrefilter()));
		}

		@Theory
		public void testReturnYobMethod(ToPBPrefilterOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPrefilterOptions",
					PrefilterOptions.class);
			sut.setAccessible(true);
			PBPrefilterOptions actual =
				(PBPrefilterOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getYobMethod(), is(fixture.expected.getYobMethod()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnUseYobFRange(ToPBPrefilterOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPrefilterOptions",
					PrefilterOptions.class);
			sut.setAccessible(true);
			PBPrefilterOptions actual =
				(PBPrefilterOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getUseYobFRange(), is(fixture.expected.getUseYobFRange()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasUsePrefilterInfo(ToPBPrefilterOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPrefilterOptions",
					PrefilterOptions.class);
			sut.setAccessible(true);
			PBPrefilterOptions actual =
				(PBPrefilterOptions)sut.invoke(null, fixture.parameter);

			// verify
			if (fixture.mode.equals("true")) {
				assertThat(actual.hasUsePrefilterInfo(), is(true));
			} else if (fixture.mode.equals("null")) {
				assertThat(actual.hasUsePrefilterInfo(), is(false));
			} else {
				org.junit.Assert.fail();
			}
		}
	}

	/**
	 * test toListBasicImageEnhanceType( List<EnhType>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToListBasicImageEnhanceTypeWith_ListOfEnhTypes {
		public static ToListBasicImageEnhanceType_Helper.Fixture fixture =
			ToListBasicImageEnhanceType_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnBasicImageEnhanceType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toListBasicImageEnhanceType",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<BasicImageEnhanceType> actual =
				(List<BasicImageEnhanceType>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index), is(fixture.expected.get(index)));
			}
		}
	}

	/**
	 * test toPBBasicImageEnhanceOptions( ImageEnhance)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBBasicImageEnhanceOptionsWith_ImageEnhance {
		public static ToPBBasicImageEnhanceOptionsWith_ImageEnhance_Helper.Fixture fixture =
			ToPBBasicImageEnhanceOptionsWith_ImageEnhance_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEnhancements()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBBasicImageEnhanceOptions",
					ImageEnhance.class);
			sut.setAccessible(true);
			PBBasicImageEnhanceOptions actual =
				(PBBasicImageEnhanceOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getEnhancementsCount(), is(not(0)));
			assertThat(actual.getEnhancementsCount(), is(fixture.expected
				.getEnhancementsCount()));
		}
	}

	/**
	 * test toPBQualityCheckOptions(QcInput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBQualityCheckOptionsWith_QcInput {
		public static ToPBQualityCheckOptions_Helper.Fixture fixture =
			ToPBQualityCheckOptions_Helper.build();

		@Test
		public void testReturnQcMode()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBQualityCheckOptions",
					QcInput.class);
			sut.setAccessible(true);
			PBQualityCheckOptions actual =
				(PBQualityCheckOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQcMode(), is(fixture.expected.getQcMode()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnDuplicateCheckThreshold()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBQualityCheckOptions",
					QcInput.class);
			sut.setAccessible(true);
			PBQualityCheckOptions actual =
				(PBQualityCheckOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDuplicateCheckThreshold(), is(fixture.expected
				.getDuplicateCheckThreshold()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSlapConfidenceThreshold()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBQualityCheckOptions",
					QcInput.class);
			sut.setAccessible(true);
			PBQualityCheckOptions actual =
				(PBQualityCheckOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSlapConfidenceThreshold(), is(fixture.expected
				.getSlapConfidenceThreshold()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSlapHandConfidenceThreshold()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBQualityCheckOptions",
					QcInput.class);
			sut.setAccessible(true);
			PBQualityCheckOptions actual =
				(PBQualityCheckOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSlapHandConfidenceThreshold(), is(fixture.expected
				.getSlapHandConfidenceThreshold()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSequenceCheckThreshold()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBQualityCheckOptions",
					QcInput.class);
			sut.setAccessible(true);
			PBQualityCheckOptions actual =
				(PBQualityCheckOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSequenceCheckThreshold(), is(fixture.expected
				.getSequenceCheckThreshold()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSequenceCheckThresholdLittle()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBQualityCheckOptions",
					QcInput.class);
			sut.setAccessible(true);
			PBQualityCheckOptions actual =
				(PBQualityCheckOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSequenceCheckThresholdLittle(), is(fixture.expected
				.getSequenceCheckThresholdLittle()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnRolledQualityThreshold()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBQualityCheckOptions",
					QcInput.class);
			sut.setAccessible(true);
			PBQualityCheckOptions actual =
				(PBQualityCheckOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRolledQualityThreshold(), is(fixture.expected
				.getRolledQualityThreshold()));
		}
	}

	/**
	 * test toPBCMLaFExtractParam(
	 * List<TenprintInput.CmlafExtOptions.TemplateParam>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBCMLaFExtractParamWith_ListOfTenprintInput2CmlafExtOptions2TemplateParam {
		public static ToPBCmlafExtractParam_Helper.Fixture fixture =
			ToPBCmlafExtractParam_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnTemplateNum()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFExtractParam",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFExtractParam> actual =
				(List<PBCMLaFExtractParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getTemplateNum(), is(fixture.expected.get(
					index).getTemplateNum()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFeType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFExtractParam",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFExtractParam> actual =
				(List<PBCMLaFExtractParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFeType(), is(fixture.expected.get(index)
					.getFeType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnLimitOfMinutiaCount()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFExtractParam",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFExtractParam> actual =
				(List<PBCMLaFExtractParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getLimitOfMinutiaCount(),
					is(fixture.expected.get(index).getLimitOfMinutiaCount()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEnhancements()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFExtractParam",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFExtractParam> actual =
				(List<PBCMLaFExtractParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getEnhancements(0), is(fixture.expected.get(
					index).getEnhancements(0)));
			}
		}
	}

	/**
	 * test toPBExtractCMLaFOptions( CmlafExtOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractCmlafOptionsWith_CmlafExtOptions {
		public static ToPBExtractCmlafOptions_Helper.Fixture fixture =
			ToPBExtractCmlafOptions_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMultiplicity()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractCMLaFOptions",
					CmlafExtOptions.class);
			sut.setAccessible(true);
			PBExtractCMLaFOptions actual =
				(PBExtractCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMultiplicity(), is(fixture.expected.getMultiplicity()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasParams()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractCMLaFOptions",
					CmlafExtOptions.class);
			sut.setAccessible(true);
			PBExtractCMLaFOptions actual =
				(PBExtractCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getParamsCount(), is(not(0)));
			assertThat(actual.getParamsCount(), is(fixture.expected.getMultiplicity()));
		}
	}

	/**
	 * test toPBExtractCommonOptionTenprint(TenprintInput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractCommonOptionTenprint_TenprintInput {
		public static ToPBExtractCommonOptionTenprint_Helper.Fixture fixture =
			ToPBExtractCommonOptionTenprint_Helper.build();

		@Test
		public void testReturnOutputMode()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractCommonOptionTenprint", TenprintInput.class);
			sut.setAccessible(true);
			PBExtractCommonOptionTenprint actual =
				(PBExtractCommonOptionTenprint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getOutputMode(), is(fixture.expected.getOutputMode()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnReExtract()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractCommonOptionTenprint", TenprintInput.class);
			sut.setAccessible(true);
			PBExtractCommonOptionTenprint actual =
				(PBExtractCommonOptionTenprint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getReExtract(), is(fixture.expected.getReExtract()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnReturnCroppedImages()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractCommonOptionTenprint", TenprintInput.class);
			sut.setAccessible(true);
			PBExtractCommonOptionTenprint actual =
				(PBExtractCommonOptionTenprint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getReturnCroppedImages(), is(fixture.expected
				.getReturnCroppedImages()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnReturnLowResolutionImages()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractCommonOptionTenprint", TenprintInput.class);
			sut.setAccessible(true);
			PBExtractCommonOptionTenprint actual =
				(PBExtractCommonOptionTenprint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getReturnLowResolutionImages(), is(fixture.expected
				.getReturnLowResolutionImages()));
		}
	}

	/**
	 * test toPBExtractTenprintInput(TenprintInput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractTenprintInputWith_TenprintInput {
		public static ToPBExtractTenprintInput_Helper.Fixture fixture =
			ToPBExtractTenprintInput_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasAimFormats()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getAimFormatsCount(), is(not(0)));
			assertThat(actual.getAimFormatsCount(), is(fixture.expected
				.getAimFormatsCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasImages()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getImagesCount(), is(not(0)));
			assertThat(actual.getImagesCount(), is(fixture.expected.getImagesCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasMinutiaCount()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutiaCount(), is(not(0)));
			assertThat(actual.getMinutiaCount(), is(fixture.expected.getMinutiaCount()));
		}

		@Test
		public void testHasMetaIfo()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMetaInfo(), is(notNullValue()));
		}

		@Test
		public void testHasPrefilterOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPrefilterOptions(), is(notNullValue()));
		}

		@Test
		public void testHasBasicEnhanceOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getBasicEnhanceOptions(), is(notNullValue()));
		}

		@Test
		public void testHasQualityCheckOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQualityCheckOptions(), is(notNullValue()));
		}

		@Test
		public void testHasCmalfOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCmalfOptions(), is(notNullValue()));
		}

		@Test
		public void testHasCmlOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCmlOptions(), is(notNullValue()));
		}

		@Test
		public void testHasCommonOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractTenprintInput",
					TenprintInput.class);

			sut.setAccessible(true);
			PBExtractTenprintInput actual =
				(PBExtractTenprintInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCommonOptions(), is(notNullValue()));
		}
	}

	/**
	 * test toPBExtractFeType(FeTypeLatent)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractFeTypeWith_FeTypeLatent {
		public static ToPBExtractFeTypeWith_FeTypeLatent_Helper.Fixture fixture =
			ToPBExtractFeTypeWith_FeTypeLatent_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMinutiaType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeType",
					FeTypeLatent.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeType> actual =
				(List<PBExtractFeType>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getMinutiaType(), is(fixture.expected.get(
					index).getMinutiaType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFisType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeType",
					FeTypeLatent.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractFeType> actual =
				(List<PBExtractFeType>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFisType(), is(fixture.expected.get(index)
					.getFisType()));
			}
		}
	}

	/**
	 * test toPBExtractFeTypeEvent(FeTypeLatent)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractFeTypeEventWith_FeTypeLatent {
		public static ToPBExtractFeTypeEventWith_FeTypeLatent_Helper.Fixture fixture =
			ToPBExtractFeTypeEventWith_FeTypeLatent_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEvent()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					FeTypeLatent.class);
			sut.setAccessible(true);
			PBExtractFeTypeEvent actual =
				(PBExtractFeTypeEvent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getEvent(), is(fixture.expected.getEvent()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFeTypes()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFeTypeEvent",
					FeTypeLatent.class);
			sut.setAccessible(true);
			PBExtractFeTypeEvent actual =
				(PBExtractFeTypeEvent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFeTypesCount(), is(fixture.expected.getFeTypesCount()));
		}
	}

	/**
	 * test toPBExtractInputImage(LatentInput.Images)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputImageWith_LatentInput$Images {
		public static ToPBExtractInputImageWith_LatentInput2Images_Helper.Fixture fixture =
			ToPBExtractInputImageWith_LatentInput2Images_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnObject()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					LatentInput.Images.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputImage> actual =
				(List<PBExtractInputImage>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
		}
	}

	/**
	 * test toPBAimFormat(LatentInput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBAimFormatWith_LatentInput {
		public static ToPBAimFormatWith_Latent_Helper.Fixture fixture =
			ToPBAimFormatWith_Latent_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFormat()
			throws Exception { // exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBAimFormat",
					LatentInput.class);
			sut.setAccessible(true);

			@SuppressWarnings("unchecked")
			List<PBAimFormat> actual =
				(List<PBAimFormat>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFormat(), is(fixture.expected.get(index)
					.getFormat()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFeTypes()
			throws Exception { // exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBAimFormat",
					LatentInput.class);
			sut.setAccessible(true);

			@SuppressWarnings("unchecked")
			List<PBAimFormat> actual =
				(List<PBAimFormat>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int i = 0; i < actual.size(); i++) {
				if (actual.get(i).getFormat() == TemplateFormatType.TEMPLATE_PLDB) {
					continue;
				}

				String message = "When format is  " + actual.get(i).getFormat().name();
				assertThat(message, actual.get(i).getFeTypeEventsCount(), is(not(0)));
				assertThat(message, actual.get(i).getFeTypeEventsCount(),
					is(fixture.expected.get(i).getFeTypeEventsCount()));
			}
		}
	}

	/**
	 * test toPBExtractInputMinutiaLatent(jp.co.nec.nhm.mm.jaxb.MinutiaType)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputMinutiaLatentWith_MinutiaType {
		public static ToPBExtractInputMinutiaLatent_Helper.Fixture fixture =
			ToPBExtractInputMinutiaLatent_Helper.build();

		@Test
		public void testReturnType()
			throws Exception { // exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputMinutiaLatent",
					jp.co.nec.aim.mm.jaxb.MinutiaType.class);
			sut.setAccessible(true);

			PBExtractInputMinutiaLatent actual =
				(PBExtractInputMinutiaLatent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getType(), is(fixture.expected.getType()));
		}

		@Test
		public void testReturnMinutiaData()
			throws Exception { // exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputMinutiaLatent",
					jp.co.nec.aim.mm.jaxb.MinutiaType.class);
			sut.setAccessible(true);

			PBExtractInputMinutiaLatent actual =
				(PBExtractInputMinutiaLatent)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutiaData(), is(fixture.expected.getMinutiaData()));
		}
	}

	/**
	 * test toPBExtractInputMarkUp(MarkUp)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputMarkUpWith_MarkUp {
		public static ToPBExtractInputMarkUp_Helper.Fixture fixture =
			ToPBExtractInputMarkUp_Helper.build();

		@Test
		public void testReturnMinutiaData()
			throws Exception { // exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputMarkUp",
					MarkUp.class);
			sut.setAccessible(true);
			PBExtractInputMarkUp actual =
				(PBExtractInputMarkUp)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMarkUpData(), is(fixture.expected.getMarkUpData()));
		}
	}

	/**
	 * test toPBBasicImageEnhanceOptions( LatentInput.Enhancements)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBBasicImageEnhanceOptionsWith_LatentInput2Enhancements {
		public static ToPBBasicImageEnhanceOptionsWith_LatentInput2Enhancements_Helper.Fixture fixture =
			ToPBBasicImageEnhanceOptionsWith_LatentInput2Enhancements_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEnhancements()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBBasicImageEnhanceOptions",
					LatentInput.Enhancements.class);
			sut.setAccessible(true);
			PBBasicImageEnhanceOptions actual =
				(PBBasicImageEnhanceOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getEnhancementsCount(), is(not(0)));
			assertThat(actual.getEnhancementsCount(), is(fixture.expected
				.getEnhancementsCount()));
		}
	}

	/**
	 * test toPBExtractLatentInput(LatentInput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractLatentInputWith_LatentInput {
		public static ToPBExtractLatentInput_Helper.Fixture fixture =
			ToPBExtractLatentInput_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasAimFormats()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractLatentInput",
					LatentInput.class);
			sut.setAccessible(true);
			PBExtractLatentInput actual =
				(PBExtractLatentInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getAimFormatsCount(), is(not(0)));
			assertThat(actual.getAimFormatsCount(), is(fixture.expected
				.getAimFormatsCount()));
		}

		@Test
		public void testHasImage()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractLatentInput",
					LatentInput.class);
			sut.setAccessible(true);
			PBExtractLatentInput actual =
				(PBExtractLatentInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getImage(), is(notNullValue()));
		}

		@Test
		public void testHasMinutia()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractLatentInput",
					LatentInput.class);
			sut.setAccessible(true);
			PBExtractLatentInput actual =
				(PBExtractLatentInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutia(), is(notNullValue()));
		}

		@Test
		public void testHasMarkUp()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractLatentInput",
					LatentInput.class);
			sut.setAccessible(true);
			PBExtractLatentInput actual =
				(PBExtractLatentInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMarkUp(), is(notNullValue()));
		}

		@Test
		public void testHasMetaInfo()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractLatentInput",
					LatentInput.class);
			sut.setAccessible(true);
			PBExtractLatentInput actual =
				(PBExtractLatentInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMetaInfo(), is(notNullValue()));
		}

		@Test
		public void testHasPrefilterOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractLatentInput",
					LatentInput.class);
			sut.setAccessible(true);
			PBExtractLatentInput actual =
				(PBExtractLatentInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPrefilterOptions(), is(notNullValue()));
		}

		@Test
		public void testHasBasicEnhanceOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractLatentInput",
					LatentInput.class);
			sut.setAccessible(true);
			PBExtractLatentInput actual =
				(PBExtractLatentInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getBasicEnhanceOptions(), is(notNullValue()));
		}

		@Test
		public void testReturnOoutputMode()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractLatentInput",
					LatentInput.class);
			sut.setAccessible(true);
			PBExtractLatentInput actual =
				(PBExtractLatentInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCommonOptions().getOutputMode(), is(fixture.expected
				.getCommonOptions().getOutputMode()));
		}
	}

	/**
	 * test toPBPoint(FacePoint)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBPointWith_FacePoint {
		public static ToPBPoint_FacePoint_Helper.Fixture fixture =
			ToPBPoint_FacePoint_Helper.build(1, 2);

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testThrowExcpetion()
			throws Exception {
			// setup
			expectedException.expect(NoInitializedException.class);
			Point parameter = null;

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBPoint",
						FacePoint.class);
				sut.setAccessible(true);
				sut.invoke(null, parameter);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof NoInitializedException) {
					throw new NoInitializedException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnX()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPoint", FacePoint.class);
			sut.setAccessible(true);
			PBPoint actual = (PBPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getX(), is(fixture.expected.getX()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnY()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPoint", FacePoint.class);
			sut.setAccessible(true);
			PBPoint actual = (PBPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getY(), is(fixture.expected.getY()));
		}
	}

	/**
	 * test toPBFace13Points(FaceInputExtraction13Points)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBFace13PointsWith_FaceInputExtraction13Points {
		public static ToPBFace13Points_Helper.Fixture fixture = ToPBFace13Points_Helper
			.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnRightEyeCenter()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightEyeCenter().getX(), is(fixture.expected
				.getRightEyeCenter().getX()));
			assertThat(actual.getRightEyeCenter().getY(), is(fixture.expected
				.getRightEyeCenter().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnLeftEyeCenter()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftEyeCenter().getX(), is(fixture.expected
				.getLeftEyeCenter().getX()));
			assertThat(actual.getLeftEyeCenter().getY(), is(fixture.expected
				.getLeftEyeCenter().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnRightEyeInnerCorner()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightEyeInnerCorner().getX(), is(fixture.expected
				.getRightEyeInnerCorner().getX()));
			assertThat(actual.getRightEyeInnerCorner().getY(), is(fixture.expected
				.getRightEyeInnerCorner().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnLeftEyeInnerCorner()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftEyeInnerCorner().getX(), is(fixture.expected
				.getLeftEyeInnerCorner().getX()));
			assertThat(actual.getLeftEyeInnerCorner().getY(), is(fixture.expected
				.getLeftEyeInnerCorner().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnRightEyeOuterCorner()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightEyeOuterCorner().getX(), is(fixture.expected
				.getRightEyeOuterCorner().getX()));
			assertThat(actual.getRightEyeOuterCorner().getY(), is(fixture.expected
				.getRightEyeOuterCorner().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnLeftEyeOuterCorner()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftEyeOuterCorner().getX(), is(fixture.expected
				.getLeftEyeOuterCorner().getX()));
			assertThat(actual.getLeftEyeOuterCorner().getY(), is(fixture.expected
				.getLeftEyeOuterCorner().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnCenterBelowNose()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCenterBelowNose().getX(), is(fixture.expected
				.getCenterBelowNose().getX()));
			assertThat(actual.getCenterBelowNose().getY(), is(fixture.expected
				.getCenterBelowNose().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnRightSideNose()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightSideNose().getX(), is(fixture.expected
				.getRightSideNose().getX()));
			assertThat(actual.getRightSideNose().getY(), is(fixture.expected
				.getRightSideNose().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnLeftSideNose()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftSideNose().getX(), is(fixture.expected
				.getLeftSideNose().getX()));
			assertThat(actual.getLeftSideNose().getY(), is(fixture.expected
				.getLeftSideNose().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnRightCornerMouth()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightCornerMouth().getX(), is(fixture.expected
				.getRightCornerMouth().getX()));
			assertThat(actual.getRightCornerMouth().getY(), is(fixture.expected
				.getRightCornerMouth().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnLeftCornerMouth()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftCornerMouth().getX(), is(fixture.expected
				.getLeftCornerMouth().getX()));
			assertThat(actual.getLeftCornerMouth().getY(), is(fixture.expected
				.getLeftCornerMouth().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnTopCenterUpperLip()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTopCenterUpperLip().getX(), is(fixture.expected
				.getTopCenterUpperLip().getX()));
			assertThat(actual.getTopCenterUpperLip().getY(), is(fixture.expected
				.getTopCenterUpperLip().getY()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnBottomCenterUpperLip()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace13Points",
					FaceInputExtraction13Points.class);
			sut.setAccessible(true);
			PBFace13Points actual = (PBFace13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getBottomCenterUpperLip().getX(), is(fixture.expected
				.getBottomCenterUpperLip().getX()));
			assertThat(actual.getBottomCenterUpperLip().getY(), is(fixture.expected
				.getBottomCenterUpperLip().getY()));
		}
	}

	/**
	 * test toPBFaceExtractionParam( List<FaceInputExtraction13Points>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBPBFaceExtractionParamWith_ListOfFaceInputExtraction13Points {
		public static ToPBFaceExtractionParam_Helper.Fixture fixture =
			ToPBFaceExtractionParam_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFaceNum()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceExtractionParam",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceExtractionParam> actual =
				(List<PBFaceExtractionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFaceNumber(), is(fixture.expected.get(
					index).getFaceNumber()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasMetaInfo()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceExtractionParam",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceExtractionParam> actual =
				(List<PBFaceExtractionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getMetaInfo(), is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPrefilterOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceExtractionParam",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceExtractionParam> actual =
				(List<PBFaceExtractionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getPrefilterOptions(), is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFace13Points()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceExtractionParam",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceExtractionParam> actual =
				(List<PBFaceExtractionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFace13Points(), is(notNullValue()));
			}
		}
	}

	/**
	 * test toPBExtractInputFaceExtraction( FaceInputExtraction)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputFaceExtractionWith_FaceInputExtraction {
		public static ToPBExtractInputFaceExtraction_Helper.Fixture fixture =
			ToPBExtractInputFaceExtraction_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasExtractionParam()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceExtraction", FaceInputExtraction.class);
			sut.setAccessible(true);
			PBExtractInputFaceExtraction actual =
				(PBExtractInputFaceExtraction)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getExtractionParamCount(), is(not(0)));
			assertThat(actual.getExtractionParamCount(), is(fixture.expected
				.getExtractionParamCount()));
		}
	}

	/**
	 * test toPBFaceDetectionParams(List<FaceInputParams>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBFaceDetectionParamsWith_ListOfFaceInputParamss {
		public static ToPBFaceDetectionParams_Helper.Fixture fixture =
			ToPBFaceDetectionParams_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnAttemptNumber()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceDetectionParams",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceDetectionParam> actual =
				(List<PBFaceDetectionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getAttempt(), is(fixture.expected.get(index)
					.getAttempt()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnAlgorithm()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceDetectionParams",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceDetectionParam> actual =
				(List<PBFaceDetectionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getAlgorithm(), is(fixture.expected.get(
					index).getAlgorithm()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnReliability()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceDetectionParams",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceDetectionParam> actual =
				(List<PBFaceDetectionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getReliability(), is(closeTo(
					fixture.expected.get(index).getReliability(), 0.01)));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEyeMin()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceDetectionParams",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceDetectionParam> actual =
				(List<PBFaceDetectionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getEyeMin(), is(closeTo(fixture.expected
					.get(index).getEyeMin(), 0.01)));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEyeMax()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceDetectionParams",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceDetectionParam> actual =
				(List<PBFaceDetectionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getEyeMax(), is(closeTo(fixture.expected
					.get(index).getEyeMax(), 0.01)));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEyeRotation()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceDetectionParams",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceDetectionParam> actual =
				(List<PBFaceDetectionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getEyeRotation(), is(fixture.expected.get(
					index).getEyeRotation()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFaceRotation()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceDetectionParams",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceDetectionParam> actual =
				(List<PBFaceDetectionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getRotationList(), is(fixture.expected.get(
					index).getRotationList()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnShrinkFactor()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFaceDetectionParams",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFaceDetectionParam> actual =
				(List<PBFaceDetectionParam>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getShrinkFactor(), is(fixture.expected.get(
					index).getShrinkFactor()));
			}
		}
	}

	/**
	 * test toPBFace2Points(List<Face2Points>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBFace2PointsWith_ListOfFace2Pointss {
		public static ToPBFace2Points_Helper.Fixture fixture = ToPBFace2Points_Helper
			.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFaceNumber()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace2Points", List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFace2Points> actual =
				(List<PBFace2Points>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFaceNumber(), is(fixture.expected.get(
					index).getFaceNumber()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasRightEyeCenter()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace2Points", List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFace2Points> actual =
				(List<PBFace2Points>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getRightEyeCenter(), is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasLeftEyeCenter()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBFace2Points", List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBFace2Points> actual =
				(List<PBFace2Points>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getLeftEyeCenter(), is(notNullValue()));
			}
		}
	}

	/**
	 * test toPBExtractInputFaceDetection(FaceInputDetection)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputFaceDetectionWith_FaceInputDetection {
		public static ToPBExtractInputFaceDetection_Helper.Fixture fixture =
			ToPBExtractInputFaceDetection_Helper.build();

		@Test
		public void testReturnMode()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceDetection", FaceInputDetection.class);
			sut.setAccessible(true);
			PBExtractInputFaceDetection actual =
				(PBExtractInputFaceDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMode(), is(fixture.expected.getMode()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFaceMaxNum()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceDetection", FaceInputDetection.class);
			sut.setAccessible(true);
			PBExtractInputFaceDetection actual =
				(PBExtractInputFaceDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFaceMaxNum(), is(fixture.expected.getFaceMaxNum()));
		}

		@Test
		public void testReturnSortingOrder()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceDetection", FaceInputDetection.class);
			sut.setAccessible(true);
			PBExtractInputFaceDetection actual =
				(PBExtractInputFaceDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSortingOrder(), is(fixture.expected.getSortingOrder()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnImageAnalysis()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceDetection", FaceInputDetection.class);
			sut.setAccessible(true);
			PBExtractInputFaceDetection actual =
				(PBExtractInputFaceDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getImageAnalysis(), is(fixture.expected.getImageAnalysis()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasDetectionParam()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceDetection", FaceInputDetection.class);
			sut.setAccessible(true);
			PBExtractInputFaceDetection actual =
				(PBExtractInputFaceDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDetectionParamCount(), is(not(0)));
			assertThat(actual.getDetectionParamCount(), is(fixture.expected
				.getDetectionParamCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFace2Points()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceDetection", FaceInputDetection.class);
			sut.setAccessible(true);
			PBExtractInputFaceDetection actual =
				(PBExtractInputFaceDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFace2PointsCount(), is(not(0)));
			assertThat(actual.getFace2PointsCount(), is(fixture.expected
				.getFace2PointsCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFaceQualityThreshold()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceDetection", FaceInputDetection.class);
			sut.setAccessible(true);
			PBExtractInputFaceDetection actual =
				(PBExtractInputFaceDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getNegativeDetectionParam().getQualityThreshold(),
				is(fixture.expected.getNegativeDetectionParam().getQualityThreshold()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMatchingScoreThreshold()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputFaceDetection", FaceInputDetection.class);
			sut.setAccessible(true);
			PBExtractInputFaceDetection actual =
				(PBExtractInputFaceDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getNegativeDetectionParam().getMatchingScoreThreshold(),
				is(fixture.expected.getNegativeDetectionParam()
					.getMatchingScoreThreshold()));
		}

	}

	/**
	 * test toPBAimFormat(AimFormats)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBAimFormatWith_AimFormats {
		public static ToPBAimFormatWith_AimFormats_Helper.Fixture fixture =
			ToPBAimFormatWith_AimFormats_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFormat()
			throws Exception { // exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBAimFormat",
					AimFormats.class);
			sut.setAccessible(true);

			@SuppressWarnings("unchecked")
			List<PBAimFormat> actual =
				(List<PBAimFormat>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFormat(), is(fixture.expected.get(index)
					.getFormat()));
			}
		}
	}

	/**
	 * test toPBExtractInputImage(FaceInputImage)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputImageWith_FaceInputImage {
		@Test
		public void testReturnType()
			throws Exception {
			// setup
			ToPBExtractInputImageWith_FaceInputImage_Helper.Fixture fixture =
				ToPBExtractInputImageWith_FaceInputImage_Helper.build("data");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					FaceInputImage.class);
			sut.setAccessible(true);
			PBExtractInputImage actual =
				(PBExtractInputImage)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getType(), is(fixture.expected.getType()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnWidth()
			throws Exception {
			// setup
			ToPBExtractInputImageWith_FaceInputImage_Helper.Fixture fixture =
				ToPBExtractInputImageWith_FaceInputImage_Helper.build("data");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					FaceInputImage.class);
			sut.setAccessible(true);
			PBExtractInputImage actual =
				(PBExtractInputImage)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getWidth(), is(fixture.expected.getWidth()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeight()
			throws Exception {
			// setup
			ToPBExtractInputImageWith_FaceInputImage_Helper.Fixture fixture =
				ToPBExtractInputImageWith_FaceInputImage_Helper.build("data");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					FaceInputImage.class);
			sut.setAccessible(true);
			PBExtractInputImage actual =
				(PBExtractInputImage)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getHeight(), is(fixture.expected.getHeight()));
		}

		@Test
		public void testReturnData()
			throws Exception {
			// setup
			ToPBExtractInputImageWith_FaceInputImage_Helper.Fixture fixture =
				ToPBExtractInputImageWith_FaceInputImage_Helper.build("data");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					FaceInputImage.class);
			sut.setAccessible(true);
			PBExtractInputImage actual =
				(PBExtractInputImage)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getData(), is(fixture.expected.getData()));
		}

		@Test
		public void testReturnUrl()
			throws Exception {
			// setup
			ToPBExtractInputImageWith_FaceInputImage_Helper.Fixture fixture =
				ToPBExtractInputImageWith_FaceInputImage_Helper.build("url");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					FaceInputImage.class);
			sut.setAccessible(true);
			PBExtractInputImage actual =
				(PBExtractInputImage)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getUrl(), is(notNullValue()));
			assertThat(actual.getUrl(), is(fixture.expected.getUrl()));
		}
	}

	/**
	 * test toPBExtractFaceInput(FaceInput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractFaceInputWith_FaceInputImage {
		public static ToPBExtractFaceInput_Helper.Fixture fixture =
			ToPBExtractFaceInput_Helper.build();

		@Test
		public void testReturnProcess()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFaceInput",
					FaceInput.class);
			sut.setAccessible(true);
			PBExtractFaceInput actual =
				(PBExtractFaceInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getProcess(), is(fixture.expected.getProcess()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasAimFormats()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFaceInput",
					FaceInput.class);
			sut.setAccessible(true);
			PBExtractFaceInput actual =
				(PBExtractFaceInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getAimFormatsCount(), is(fixture.expected
				.getAimFormatsCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasMetaInfo()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFaceInput",
					FaceInput.class);
			sut.setAccessible(true);
			PBExtractFaceInput actual =
				(PBExtractFaceInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasMetaInfo(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPrefilterOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFaceInput",
					FaceInput.class);
			sut.setAccessible(true);
			PBExtractFaceInput actual =
				(PBExtractFaceInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasPrefilterOptions(), is(true));
		}

		@Test
		public void testHasImage()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFaceInput",
					FaceInput.class);
			sut.setAccessible(true);
			PBExtractFaceInput actual =
				(PBExtractFaceInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getImage(), is(notNullValue()));
		}

		@Test
		public void testHasDetection()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFaceInput",
					FaceInput.class);
			sut.setAccessible(true);
			PBExtractFaceInput actual =
				(PBExtractFaceInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDetection(), is(notNullValue()));
		}

		@Test
		public void testHasExtraction()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractFaceInput",
					FaceInput.class);
			sut.setAccessible(true);
			PBExtractFaceInput actual =
				(PBExtractFaceInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getExtraction(), is(notNullValue()));
		}
	}

	/**
	 * test toString(DynamicXml)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToStringWith_DynamicXml {
		public static ToString_Helper.Fixture fixture = ToString_Helper.build("tenprint");

		@Test
		public void testReturnString()
			throws Exception {
			// setup
			DynamicXml parameter = null;
			Method setUpObject =
				ProtoClassConvert.class.getDeclaredMethod("toDynamicXml",
					ExtractionInputsPayload.class);
			setUpObject.setAccessible(true);
			parameter = (DynamicXml)setUpObject.invoke(null, fixture.parameter);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toString", DynamicXml.class);
			sut.setAccessible(true);
			String actual = (String)sut.invoke(null, parameter);

			// verify
			assertThat(actual, is(notNullValue()));
		}
		// TODO exception
	}

	/**
	 * test toPBExtractInputPayload( ExtractionInputs)
	 * 
	 * @author kawamura
	 * 
	 */
	@SuppressWarnings("boxing")
	public static class ToPBExtractInputPayload_ExtractionInputs {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testHasTenprintInput()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("extract-request.xml");
			String payload = IOUtils.toString(is, "utf-8");

			Method setUpObject =
				ProtoClassConvert.class.getDeclaredMethod("toDynamicXml", String.class);
			setUpObject.setAccessible(true);
			DynamicXml dom = (DynamicXml)setUpObject.invoke(null, payload);
			ExtractionInputs parameter = new ExtractionInputs();
			parameter.setExtractionInputsPayload(dom);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputPayload",
					ExtractionInputs.class);
			sut.setAccessible(true);
			PBExtractInputPayload actual =
				(PBExtractInputPayload)sut.invoke(new ProtoClassConvert(), parameter);

			// verify
			assertThat(actual.hasTenprintInput(), is(true));
		}

		@Test
		public void testHasLatent()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream(
					"latent-input_in_extraction_inputs_payload_2.xml");
			String payload = IOUtils.toString(is, "utf-8");

			Method setUpObject =
				ProtoClassConvert.class.getDeclaredMethod("toDynamicXml", String.class);
			setUpObject.setAccessible(true);
			DynamicXml dom = (DynamicXml)setUpObject.invoke(null, payload);
			ExtractionInputs parameter = new ExtractionInputs();
			parameter.setExtractionInputsPayload(dom);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputPayload",
					ExtractionInputs.class);
			sut.setAccessible(true);
			PBExtractInputPayload actual =
				(PBExtractInputPayload)sut.invoke(new ProtoClassConvert(), parameter);

			// verify
			assertThat(actual.hasLatentInput(), is(true));
		}

		@Test
		public void testHasFace()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream(
					"face-input_in_extraction_inputs_payload_1.xml");
			String payload = IOUtils.toString(is, "utf-8");

			Method setUpObject =
				ProtoClassConvert.class.getDeclaredMethod("toDynamicXml", String.class);
			setUpObject.setAccessible(true);
			DynamicXml dom = (DynamicXml)setUpObject.invoke(null, payload);
			ExtractionInputs parameter = new ExtractionInputs();
			parameter.setExtractionInputsPayload(dom);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputPayload",
					ExtractionInputs.class);
			sut.setAccessible(true);
			PBExtractInputPayload actual =
				(PBExtractInputPayload)sut.invoke(new ProtoClassConvert(), parameter);

			// verify
			assertThat(actual.hasFaceInput(), is(true));
		}

		@Test
		public void testHasIris()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream(
					"iris-input_in_extraction_inputs_payload.xml");
			String payload = IOUtils.toString(is, "utf-8");

			Method setUpObject =
				ProtoClassConvert.class.getDeclaredMethod("toDynamicXml", String.class);
			setUpObject.setAccessible(true);
			DynamicXml dom = (DynamicXml)setUpObject.invoke(null, payload);
			ExtractionInputs parameter = new ExtractionInputs();
			parameter.setExtractionInputsPayload(dom);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputPayload",
					ExtractionInputs.class);
			sut.setAccessible(true);
			PBExtractInputPayload actual =
				(PBExtractInputPayload)sut.invoke(new ProtoClassConvert(), parameter);

			// verify
			assertThat(actual.hasIrisInput(), is(true));
		}

		@Test
		public void testThrowUnmarshalException_DetectionAlgorithmIsInvalidValue()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream(
					"validation with schema/invalid-extract-request-1.xml");
			String payload = IOUtils.toString(is, "utf-8");

			Method setUpObject =
				ProtoClassConvert.class.getDeclaredMethod("toDynamicXml", String.class);
			setUpObject.setAccessible(true);
			DynamicXml dom = (DynamicXml)setUpObject.invoke(null, payload);
			ExtractionInputs parameter = new ExtractionInputs();
			parameter.setExtractionInputsPayload(dom);

			expectedException.expect(UnmarshalException.class);			
			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputPayload",
						ExtractionInputs.class);
				sut.setAccessible(true);
				sut.invoke(new ProtoClassConvert(), parameter);
			} catch (InvocationTargetException e) {
				// verify
				Throwable t = e.getCause();
				if (t instanceof UnmarshalException) {
					throw new UnmarshalException(Throwables.getRootCause(e).getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBExtractJobRequest(ExtractionInputs)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractJobRequest_ExtractionInputs {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnPriority()
			throws Exception {
			// setup
			DynamicXml dom = null;
			{
				InputStream is =
					getClass().getClassLoader().getResourceAsStream(
						"latent-input_in_extraction_inputs_payload_1.xml");
				String payload = IOUtils.toString(is, "utf-8");

				Method setUpObject =
					ProtoClassConvert.class.getDeclaredMethod("toDynamicXml",
						String.class);
				setUpObject.setAccessible(true);
				dom = (DynamicXml)setUpObject.invoke(null, payload);
			}

			ToPBExtractJobRequest_Helper.Fixture fixture =
				ToPBExtractJobRequest_Helper.build();
			fixture.parameter.setExtractionInputsPayload(dom);

			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBExtractJobRequest actual = sut.toPBExtractJobRequest(fixture.parameter);

			// verify
			assertThat(actual.getPriority(), is(fixture.expected.getPriority()));
		}

		@Test
		public void testReturnCallbackURL()
			throws Exception {
			// setup
			DynamicXml dom = null;
			{
				InputStream is =
					getClass().getClassLoader().getResourceAsStream(
						"latent-input_in_extraction_inputs_payload_1.xml");
				String payload = IOUtils.toString(is, "utf-8");

				Method setUpObject =
					ProtoClassConvert.class.getDeclaredMethod("toDynamicXml",
						String.class);
				setUpObject.setAccessible(true);
				dom = (DynamicXml)setUpObject.invoke(null, payload);
			}

			ToPBExtractJobRequest_Helper.Fixture fixture =
				ToPBExtractJobRequest_Helper.build();
			fixture.parameter.setExtractionInputsPayload(dom);

			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBExtractJobRequest actual = sut.toPBExtractJobRequest(fixture.parameter);

			// verify
			assertThat(actual.getCallBackUrl(), is(fixture.expected.getCallBackUrl()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasInputPayload()
			throws Exception {
			// setup
			DynamicXml dom = null;
			{
				InputStream is =
					getClass().getClassLoader().getResourceAsStream(
						"latent-input_in_extraction_inputs_payload_1.xml");
				String payload = IOUtils.toString(is, "utf-8");

				Method setUpObject =
					ProtoClassConvert.class.getDeclaredMethod("toDynamicXml",
						String.class);
				setUpObject.setAccessible(true);
				dom = (DynamicXml)setUpObject.invoke(null, payload);
			}

			ToPBExtractJobRequest_Helper.Fixture fixture =
				ToPBExtractJobRequest_Helper.build();
			fixture.parameter.setExtractionInputsPayload(dom);

			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBExtractJobRequest actual = sut.toPBExtractJobRequest(fixture.parameter);

			// verify
			assertThat(actual.hasInputPayload(), is(true));
		}

		@Test
		public void testThrowConvertExcpxetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};

			DynamicXml dom = null;
			{
				InputStream is =
					getClass().getClassLoader().getResourceAsStream(
						"latent-input_in_extraction_inputs_payload_1.xml");
				String payload = IOUtils.toString(is, "utf-8");

				Method setUpObject =
					ProtoClassConvert.class.getDeclaredMethod("toDynamicXml",
						String.class);
				setUpObject.setAccessible(true);
				dom = (DynamicXml)setUpObject.invoke(null, payload);
			}

			ToPBExtractJobRequest_Helper.Fixture fixture =
				ToPBExtractJobRequest_Helper.build();
			fixture.parameter.setExtractionInputsPayload(dom);

			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBExtractJobRequest(fixture.parameter);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBPreselectionOptions( PreselectionOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBPreselectionOptionsWith_PreselectionOptions {
		@SuppressWarnings("boxing")
		@Test
		public void testReturnCardQualityThreshold()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.getCardQualityThreshold(), is(fixture.expected.options
				.getCardQualityThreshold()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnUsePsr8FingerSlap()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.getUsePsr8FingerSlap(), is(fixture.expected.options
				.getUsePsr8FingerSlap()));
		}

		@Test
		public void testReturnFilterMode()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.getFilterMode(), is(fixture.expected.options
				.getFilterMode()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdatePatternThreshold_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.hasPatternThreshold(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdatePatternThreshold_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.hasPatternThreshold(), is(true));
			assertThat(new Double(actual.getPatternThreshold()), is(closeTo(
				fixture.expected.options.getPatternThreshold(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdateYobThreshold_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.hasYobThreshold(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateYobThreshold_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.hasYobThreshold(), is(true));
			assertThat(new Double(actual.getYobThreshold()), is(closeTo(
				fixture.expected.options.getYobThreshold(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdateFingerSelectionMode_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.hasFingerSelectionMode(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateFingerSelectionMode_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.hasFingerSelectionMode(), is(true));
			assertThat(actual.getFingerSelectionMode(), is(fixture.expected.options
				.getFingerSelectionMode()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnCandidateVerification()
			throws Exception {
			// setup
			ToPBPreselectionOptions_Helper.Fixture fixture =
				ToPBPreselectionOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPreselectionOptions",
					PreselectionOptions.class);
			sut.setAccessible(true);
			PBPreselectionOptions actual =
				(PBPreselectionOptions)sut.invoke(null,
					fixture.parameter.preselectionOptions);

			// verify
			assertThat(actual.getCandidateVerificationThreshold(),
				is(fixture.expected.options.getCandidateVerificationThreshold()));
		}
	}

	/**
	 * test toPBUsePrefilterInfo( UsePrefilterInfo)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBUsePrefilterInfoWith_UsePrefilterInfo {
		@DataPoints
		public static ToPBUsePrefilterInfo_Helper.Fixture[] getFixtures() {
			return ToPBUsePrefilterInfo_Helper.fixtures;
		};

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnFingerNo(ToPBUsePrefilterInfo_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBUsePrefilterInfo",
					UsePrefilterInfo.class);
			sut.setAccessible(true);
			PBUsePrefilterInfo actual =
				(PBUsePrefilterInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFingerNo(), is(fixture.expected.getFingerNo()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnGender(ToPBUsePrefilterInfo_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBUsePrefilterInfo",
					UsePrefilterInfo.class);
			sut.setAccessible(true);
			PBUsePrefilterInfo actual =
				(PBUsePrefilterInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getGender(), is(fixture.expected.getGender()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnPartNo(ToPBUsePrefilterInfo_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBUsePrefilterInfo",
					UsePrefilterInfo.class);
			sut.setAccessible(true);
			PBUsePrefilterInfo actual =
				(PBUsePrefilterInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPartNo(), is(fixture.expected.getPartNo()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnPattern(ToPBUsePrefilterInfo_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBUsePrefilterInfo",
					UsePrefilterInfo.class);
			sut.setAccessible(true);
			PBUsePrefilterInfo actual =
				(PBUsePrefilterInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPattern(), is(fixture.expected.getPattern()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnRegion(ToPBUsePrefilterInfo_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBUsePrefilterInfo",
					UsePrefilterInfo.class);
			sut.setAccessible(true);
			PBUsePrefilterInfo actual =
				(PBUsePrefilterInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRegion(), is(fixture.expected.getRegion()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnRace(ToPBUsePrefilterInfo_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBUsePrefilterInfo",
					UsePrefilterInfo.class);
			sut.setAccessible(true);
			PBUsePrefilterInfo actual =
				(PBUsePrefilterInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRace(), is(fixture.expected.getRace()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnYob(ToPBUsePrefilterInfo_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBUsePrefilterInfo",
					UsePrefilterInfo.class);
			sut.setAccessible(true);
			PBUsePrefilterInfo actual =
				(PBUsePrefilterInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getYob(), is(fixture.expected.getYob()));
		}
	}

	/**
	 * test toPBPc2Options(Pc2Options)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBPc2OptionsWith_Pc2Options {
		@DataPoints
		public static ToPBPc2Options_Helper.Fixture[] getFxFixtures() {
			return ToPBPc2Options_Helper.fixtures;
		};

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnSpeedLevel(ToPBPc2Options_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPc2Options",
					Pc2Options.class);
			sut.setAccessible(true);
			PBPc2Options actual = (PBPc2Options)sut.invoke(null, fixture.parameter);

			// verify
			if (fixture.apply.equals("null")) {
				assertThat(actual.hasSpeedLevel(), is(false));
			} else {
				assertThat(actual.getSpeedLevel(), is(fixture.expected.getSpeedLevel()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnRotationLimit(ToPBPc2Options_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPc2Options",
					Pc2Options.class);
			sut.setAccessible(true);
			PBPc2Options actual = (PBPc2Options)sut.invoke(null, fixture.parameter);

			// verify
			if (fixture.apply.equals("null")) {
				assertThat(actual.hasRotationLimit(), is(false));
			} else {
				assertThat(actual.getRotationLimit(), is(fixture.expected
					.getRotationLimit()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnDistortionLevel(ToPBPc2Options_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPc2Options",
					Pc2Options.class);
			sut.setAccessible(true);
			PBPc2Options actual = (PBPc2Options)sut.invoke(null, fixture.parameter);

			// verify
			if (fixture.apply.equals("null")) {
				assertThat(actual.hasDistortionLevel(), is(false));
			} else {
				assertThat(actual.getDistortionLevel(), is(fixture.expected
					.getDistortionLevel()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnRotationByAxis(ToPBPc2Options_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPc2Options",
					Pc2Options.class);
			sut.setAccessible(true);
			PBPc2Options actual = (PBPc2Options)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRotationByAxis(), is(fixture.expected
				.getRotationByAxis()));
		}
	}

	/**
	 * test toPBLeOptions(LeOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBLeOptionsWith_LeOptions {
		@Test
		public void testReturnRotationLimit()
			throws Exception {
			// setup
			ToPBLeOptions_Helper.Fixture fixture = ToPBLeOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLeOptions",
					LeOptions.class);
			sut.setAccessible(true);
			PBLeOptions actual = (PBLeOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRotationLimit(), is(fixture.expected
				.getRotationLimit()));
		}

		@Test
		public void testReturnCorePosition()
			throws Exception {
			// setup
			ToPBLeOptions_Helper.Fixture fixture = ToPBLeOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLeOptions",
					LeOptions.class);
			sut.setAccessible(true);
			PBLeOptions actual = (PBLeOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCorePosition(), is(fixture.expected
				.getCorePosition()));
		}

		@Test
		public void testReturnAlgorithm()
			throws Exception {
			// setup
			ToPBLeOptions_Helper.Fixture fixture = ToPBLeOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLeOptions",
					LeOptions.class);
			sut.setAccessible(true);
			PBLeOptions actual = (PBLeOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getAlgorithm(), is(fixture.expected
				.getAlgorithm()));
		}

	}

	/**
	 * test toPBPalmOptions(PalmOptions, PBInquiryPayload.Builder)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBPalmOptionsWith_PalmOptions_PBInquiryPayload2Builder {
		public static ToPBPalmOptions_Helper.Fixture fixture = ToPBPalmOptions_Helper
			.build(true);

		@SuppressWarnings("boxing")
		@Test
		public void testNoApply()
			throws Exception {
			// setup
			ToPBPalmOptions_Helper.Fixture localFixture =
				ToPBPalmOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPalmOptions",
					PalmOptions.class, PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			sut.invoke(null, localFixture.parameter, actual);

			// verify
			assertThat(actual.hasPalmOptions(), is(false));
		}

		@Test
		public void testReturnRotationLimit()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPalmOptions",
					PalmOptions.class, PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getPalmOptions().getRotationLimit(), is(fixture.expected
				.getRotationLimit()));
		}

		@Test
		public void testReturnSpeedLevelPrimary()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPalmOptions",
					PalmOptions.class, PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getPalmOptions().getSpeedLevelPrimary(),
				is(fixture.expected.getSpeedLevelPrimary()));
		}

		@Test
		public void testReturnSpeedLevelSecondary()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPalmOptions",
					PalmOptions.class, PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getPalmOptions().getSpeedLevelSecondary(),
				is(fixture.expected.getSpeedLevelSecondary()));
		}

		@Test
		public void testReturnDistortionLevelPrimary()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPalmOptions",
					PalmOptions.class, PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getPalmOptions().getDistortionLevelPrimary(),
				is(fixture.expected.getDistortionLevelPrimary()));
		}

		@Test
		public void testReturnDistortionLevelSecondary()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBPalmOptions",
					PalmOptions.class, PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getPalmOptions().getDistortionLevelSecondary(),
				is(fixture.expected.getDistortionLevelSecondary()));
		}
	}

	/**
	 * test toPBLfmlOptions(LfmlOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBLfmlOptionsWith_LfmlOptions {
		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdateSearchLevel_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasSearchLevel(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateSearchLevel_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasSearchLevel(), is(true));
			assertThat(actual.getSearchLevel(), is(fixture.expected.getSearchLevel()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdateRotationLimit_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasRotationLimit(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateRotationLimit_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasRotationLimit(), is(true));
			assertThat(actual.getRotationLimit(), is(fixture.expected.getRotationLimit()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdateSpeedLevelPrimary_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasSpeedLevelPrimary(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateSpeedLevelPrimary_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasSpeedLevelPrimary(), is(true));
			assertThat(actual.getSpeedLevelPrimary(), is(fixture.expected
				.getSpeedLevelPrimary()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdateSpeedLevelSecondary_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasSpeedLevelSecondary(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateSpeedLevelSecondary_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasSpeedLevelSecondary(), is(true));
			assertThat(actual.getSpeedLevelSecondary(), is(fixture.expected
				.getSpeedLevelSecondary()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdateDistortionLevelPrimary_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasDistortionLevelPrimary(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateDistortionLevelPrimary_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasDistortionLevelPrimary(), is(true));
			assertThat(actual.getDistortionLevelPrimary(), is(fixture.expected
				.getDistortionLevelPrimary()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoUpdateDistortionLevelSecondary_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasDistortionLevelSecondary(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateDistortionLevelSecondary_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasDistortionLevelSecondary(), is(true));
			assertThat(actual.getDistortionLevelSecondary(), is(fixture.expected
				.getDistortionLevelSecondary()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testNoUpdateLeOptions_IfApplyHasFalse()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasLeOptions(), is(false));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testUpdateLeOptions_IfApplyHasTrue()
			throws Exception {
			// setup
			ToPBLfmlOptions_Helper.Fixture fixture = ToPBLfmlOptions_Helper.build(true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBLfmlOptions",
					LfmlOptions.class);
			sut.setAccessible(true);
			PBLfmlOptions actual = (PBLfmlOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasLeOptions(), is(true));
		}

	}

	/**
	 * test toPBCMLaFMatchableFingerThreshold( MatchableFingersThresholds)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBMatchableFingersThresholdsWith_MatchableFingersThresholds {
		@DataPoints
		public static ToPBMatchableFingersThresholds_Helper.Fixture[] getFixtures() {
			return ToPBMatchableFingersThresholds_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnFingerNumber(
			ToPBMatchableFingersThresholds_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBCMLaFMatchableFingerThreshold",
					MatchableFingersThresholds.class,
					ProtoClassConvert.CMLaFParameter.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFMatchableFingerThreshold> actual =
				(List<PBCMLaFMatchableFingerThreshold>)sut.invoke(null,
					fixture.parameter, fixture.cmlafParameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; 0 < index; index++) {
				assertThat(actual.get(index).getFingerNumber(), is(fixture.expected.get(
					index).getFingerNumber()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnPatternThreshold(
			ToPBMatchableFingersThresholds_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBCMLaFMatchableFingerThreshold",
					MatchableFingersThresholds.class,
					ProtoClassConvert.CMLaFParameter.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFMatchableFingerThreshold> actual =
				(List<PBCMLaFMatchableFingerThreshold>)sut.invoke(null,
					fixture.parameter, fixture.cmlafParameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; 0 < index; index++) {
				assertThat(actual.get(index).getPatternThreshold(), is(fixture.expected
					.get(index).getPatternThreshold()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnCardScoreThreshold(
			ToPBMatchableFingersThresholds_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBCMLaFMatchableFingerThreshold",
					MatchableFingersThresholds.class,
					ProtoClassConvert.CMLaFParameter.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFMatchableFingerThreshold> actual =
				(List<PBCMLaFMatchableFingerThreshold>)sut.invoke(null,
					fixture.parameter, fixture.cmlafParameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; 0 < index; index++) {
				assertThat(actual.get(index).getCardScoreThreshold(), is(fixture.expected
					.get(index).getCardScoreThreshold()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnMateProbabilityThreshold(
			ToPBMatchableFingersThresholds_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBCMLaFMatchableFingerThreshold",
					MatchableFingersThresholds.class,
					ProtoClassConvert.CMLaFParameter.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFMatchableFingerThreshold> actual =
				(List<PBCMLaFMatchableFingerThreshold>)sut.invoke(null,
					fixture.parameter, fixture.cmlafParameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; 0 < index; index++) {
				assertThat(new Double(actual.get(index).getMateProbabilityThreshold()),
					is(closeTo(fixture.expected.get(index).getMateProbabilityThreshold(),
						0.01)));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnSpeedLevel(
			ToPBMatchableFingersThresholds_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBCMLaFMatchableFingerThreshold",
					MatchableFingersThresholds.class,
					ProtoClassConvert.CMLaFParameter.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFMatchableFingerThreshold> actual =
				(List<PBCMLaFMatchableFingerThreshold>)sut.invoke(null,
					fixture.parameter, fixture.cmlafParameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; 0 < index; index++) {
				assertThat(actual.get(index).getSpeedLevel(), is(fixture.expected.get(
					index).getSpeedLevel()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testFinalScoreThreshold(
			ToPBMatchableFingersThresholds_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBCMLaFMatchableFingerThreshold",
					MatchableFingersThresholds.class,
					ProtoClassConvert.CMLaFParameter.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBCMLaFMatchableFingerThreshold> actual =
				(List<PBCMLaFMatchableFingerThreshold>)sut.invoke(null,
					fixture.parameter, fixture.cmlafParameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; 0 < index; index++) {
				assertThat(actual.get(index).getFinalScoreThreshold(),
					is(fixture.expected.get(index).getFinalScoreThreshold()));
			}
		}
	}

	/**
	 * test toPBCMLaFOptions(CmlafTiOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBCmlafOptions_CmlafTiOptions {
		@DataPoints
		public static ToPBCmlafOptions_Helper.Fixture[] getFixtures() {
			return ToPBCmlafOptions_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testUpdatePatternThreshold(ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMatchableFingerThresholdsCount(), is(not(0)));
			assertThat(actual.getMatchableFingerThresholdsCount(), is(fixture.expected
				.getMatchableFingerThresholdsCount()));
			assertThat(fixture.expected.getMatchableFingerThresholdsCount(), is(not(0)));
			for (int index = 0; index < fixture.expected
				.getMatchableFingerThresholdsCount(); index++) {
				assertThat(new Double(actual.getMatchableFingerThresholds(index)
					.getPatternThreshold()), is(closeTo(fixture.expected
					.getMatchableFingerThresholds(index).getPatternThreshold(), 0.01)));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testNoUpdateYobThreshold_IfApplyhasFalse(
			ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			assumeFalse(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasYobThreshold(), is(false));
		}

		@Theory
		public void testUpdateYobThreshold_IfApplyhasTrue(
			ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(new Double(actual.getYobThreshold()), is(closeTo(fixture.expected
				.getYobThreshold(), 0.01)));
		}

		@Theory
		public void testReturnFilterMode(ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFilterMode(), is(fixture.expected.getFilterMode()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testUpdateCardScoreThreshold(ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMatchableFingerThresholdsCount(), is(not(0)));
			assertThat(actual.getMatchableFingerThresholdsCount(), is(fixture.expected
				.getMatchableFingerThresholdsCount()));
			for (int index = 0; index < fixture.expected
				.getMatchableFingerThresholdsCount(); index++) {
				assertThat(actual.getMatchableFingerThresholds(index)
					.getCardScoreThreshold(), is(fixture.expected
					.getMatchableFingerThresholds(index).getCardScoreThreshold()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testUpdateMateProbabilityThreshold(
			ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMatchableFingerThresholdsCount(), is(not(0)));
			assertThat(actual.getMatchableFingerThresholdsCount(), is(fixture.expected
				.getMatchableFingerThresholdsCount()));
			for (int index = 0; index < fixture.expected
				.getMatchableFingerThresholdsCount(); index++) {
				assertThat(new Double(actual.getMatchableFingerThresholds(index)
					.getMateProbabilityThreshold()), is(closeTo(fixture.expected
					.getMatchableFingerThresholds(index).getMateProbabilityThreshold(),
					0.01)));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testUpdateFinalScoreThreshold(ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMatchableFingerThresholdsCount(), is(not(0)));
			assertThat(actual.getMatchableFingerThresholdsCount(), is(fixture.expected
				.getMatchableFingerThresholdsCount()));
			for (int index = 0; index < fixture.expected
				.getMatchableFingerThresholdsCount(); index++) {
				assertThat(actual.getMatchableFingerThresholds(index)
					.getFinalScoreThreshold(), is(fixture.expected
					.getMatchableFingerThresholds(index).getFinalScoreThreshold()));
			}
		}

		@Theory
		public void testReturnSearchMode(ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSearchMode(), is(fixture.expected.getSearchMode()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testUpdateSpeedLevel(ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMatchableFingerThresholdsCount(), is(not(0)));
			assertThat(actual.getMatchableFingerThresholdsCount(), is(fixture.expected
				.getMatchableFingerThresholdsCount()));
			for (int index = 0; index < fixture.expected
				.getMatchableFingerThresholdsCount(); index++) {
				assertThat(actual.getMatchableFingerThresholds(index).getSpeedLevel(),
					is(fixture.expected.getMatchableFingerThresholds(index)
						.getSpeedLevel()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testNoUpdateRotationLimit_IfApplyhasFalse(
			ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			assumeFalse(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasRotationLimit(), is(false));
		}

		@Theory
		public void testUpdateRotationLimit_IfApplyhasTrue(
			ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRotationLimit(), is(fixture.expected.getRotationLimit()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testNoUpdateDistortionLevel_IfApplyhasFalse(
			ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			assumeFalse(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasDistortionLevel(), is(false));
		}

		@Theory
		public void testUpdateDistortionLevel_IfApplyhasTrue(
			ToPBCmlafOptions_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLaFOptions",
					CmlafTiOptions.class);
			sut.setAccessible(true);
			PBCMLaFOptions actual = (PBCMLaFOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDistortionLevel(), is(fixture.expected
				.getDistortionLevel()));
		}
	}

	/**
	 * test toPBCMLOptions(CmlOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBCmlOptions_CmlOptions {
		@DataPoints
		public static ToPBCmlOptions_Helper.Fixture[] getFixtures() {
			return ToPBCmlOptions_Helper.fixtures;
		}

		@Theory
		public void testNoUpdateYobThreshold_IfApplyhasFalse(
			ToPBCmlOptions_Helper.Fixture fixture)
			throws Exception {
			assumeFalse(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLOptions",
					CmlOptions.class);
			sut.setAccessible(true);
			PBCMLOptions actual = (PBCMLOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasYobThreshold(), is(false));
		}

		@Theory
		public void testUpdateYobThreshold_IfApplyhasTrue(
			ToPBCmlOptions_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLOptions",
					CmlOptions.class);
			sut.setAccessible(true);
			PBCMLOptions actual = (PBCMLOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(new Double(actual.getYobThreshold()), is(closeTo(fixture.expected
				.getYobThreshold(), 0.01)));
		}

		@Theory
		public void testReturnFilterMode(ToPBCmlOptions_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLOptions",
					CmlOptions.class);
			sut.setAccessible(true);
			PBCMLOptions actual = (PBCMLOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFilterMode(), is(fixture.expected.getFilterMode()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testNoUpdateRotationLimit_IfApplyhasFalse(
			ToPBCmlOptions_Helper.Fixture fixture)
			throws Exception {
			assumeFalse(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLOptions",
					CmlOptions.class);
			sut.setAccessible(true);
			PBCMLOptions actual = (PBCMLOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasRotationLimit(), is(false));
		}

		@Theory
		public void testUpdateRotationLimit_IfApplyhasTrue(
			ToPBCmlOptions_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLOptions",
					CmlOptions.class);
			sut.setAccessible(true);
			PBCMLOptions actual = (PBCMLOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRotationLimit(), is(fixture.expected.getRotationLimit()));
		}

		@Theory
		public void testNoUpdateParameterId_IfApplyhasFalse(
			ToPBCmlOptions_Helper.Fixture fixture)
			throws Exception {
			assumeFalse(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLOptions",
					CmlOptions.class);
			sut.setAccessible(true);
			PBCMLOptions actual = (PBCMLOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasParameterId(), is(false));
		}

		@Theory
		public void testUpdateParameterId_IfApplyhasTrue(
			ToPBCmlOptions_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.apply);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBCMLOptions",
					CmlOptions.class);
			sut.setAccessible(true);
			PBCMLOptions actual = (PBCMLOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasParameterId(), is(true));
		}
	}


	@RunWith(Theories.class)
	public static class UpdateGenderAndYob_boolean_boolean_MetaInfo_PBMetaInfoCommon {
		@DataPoints
		public static UpdateGenderAndYob_Helper.Fixture[] getFixtures() {
			// setup
			return UpdateGenderAndYob_Helper.fixtures;
		};

		@SuppressWarnings("boxing")
		@Theory
		public void testUpdateGender(UpdateGenderAndYob_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("updateYobAndGender",
					boolean.class, boolean.class, MetaInfo.class,
					PBMetaInfoCommon.Builder.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter.applyYob,
					fixture.parameter.applyGender, fixture.parameter.metaInfo,
					PBMetaInfoCommon.newBuilder());

			// verify
			assertThat(actual.getGender(), is(fixture.expected.pbMetaInfoCommon
				.getGender()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testUpdateYob(UpdateGenderAndYob_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("updateYobAndGender",
					boolean.class, boolean.class, MetaInfo.class,
					PBMetaInfoCommon.Builder.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter.applyYob,
					fixture.parameter.applyGender, fixture.parameter.metaInfo,
					PBMetaInfoCommon.newBuilder());

			// verify
			assertThat(actual.getYob(), is(fixture.expected.pbMetaInfoCommon.getYob()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasGender(UpdateGenderAndYob_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("updateYobAndGender",
					boolean.class, boolean.class, MetaInfo.class,
					PBMetaInfoCommon.Builder.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter.applyYob,
					fixture.parameter.applyGender, fixture.parameter.metaInfo,
					PBMetaInfoCommon.newBuilder());

			// verify
			assertThat(actual.hasGender(), is(fixture.expected.hasGenderFlag));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasYob(UpdateGenderAndYob_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("updateYobAndGender",
					boolean.class, boolean.class, MetaInfo.class,
					PBMetaInfoCommon.Builder.class);
			sut.setAccessible(true);
			PBMetaInfoCommon actual =
				(PBMetaInfoCommon)sut.invoke(null, fixture.parameter.applyYob,
					fixture.parameter.applyGender, fixture.parameter.metaInfo,
					PBMetaInfoCommon.newBuilder());

			// verify
			assertThat(actual.hasYob(), is(fixture.expected.hasYobFlag));
		}
	}

	/**
	 * test toPBInquiryPayload(InquiryFunctionType, SearchInputsPayload,
	 * PBInquiryPayload.Builder builder)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBSearchInputPayload_InquiryFunctionType_SearchInputsPayload_PBInquiryPayload2Builder {
		@SuppressWarnings("boxing")
		@Test
		public void testHasMetaInfo()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasMetaInfo(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateGenderByPreselection_IfFunctionIsTI()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getGender(),
				is(GenderType.GENDER_UNKNOWN));
			assertThat(actual.getMetaInfo().getCommon().hasGender(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateGenderByPreselection_IfFunctionIsNotTI()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.LI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getGender(),
				is(GenderType.GENDER_MALE));
			assertThat(actual.getMetaInfo().getCommon().hasGender(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateYobByPreselection_IfFunctionIsTI()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getYob(), is(-1));
			assertThat(actual.getMetaInfo().getCommon().hasYob(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateYobByPreselection_IfFunctionIsNotTI()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.LI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getYob(), is(1));
			assertThat(actual.getMetaInfo().getCommon().hasYob(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateGenderByPreselection_IfFunctionIsTIM()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getGender(),
				is(GenderType.GENDER_UNKNOWN));
			assertThat(actual.getMetaInfo().getCommon().hasGender(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateGenderByPreselection_IfFunctionIsNotTIM()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.LI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getGender(),
				is(GenderType.GENDER_MALE));
			assertThat(actual.getMetaInfo().getCommon().hasGender(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateYobByPreselection_IfFunctionIsTIM()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getYob(), is(-1));
			assertThat(actual.getMetaInfo().getCommon().hasYob(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testUpdateYobByPreselection_IfFunctionIsNotTIM()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.LI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getYob(), is(1));
			assertThat(actual.getMetaInfo().getCommon().hasYob(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPreselectionOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("preselection", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasPreselectionOptions(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasNotPreselectionOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("preselection", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasPreselectionOptions(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasUpdateYobByPreselectionOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("preselection", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			actual.getMetaInfo().getCommon().toBuilder().setYob(1);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getYob(), is(-1));
		}

		@Test
		public void testHasUpdateGenderByPreselectionOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("preselection", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			actual.getMetaInfo().getCommon().toBuilder().setGender(
				GenderType.GENDER_FEMALE);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getGender(),
				is(GenderType.GENDER_UNKNOWN));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPrefilterOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TLI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasPrefilterOptions(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPc2Options()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TLI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasPc2Options(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasLeOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TLI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasLeOptions(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasNotLeOp0tions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", false);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TLI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasLeOptions(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPalmOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TLIP,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasPalmOptions(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasNotPalmOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", false);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TLIP,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasPalmOptions(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasCmlafOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("cmlaf", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasCmlafOptions(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasNotCmlafOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("cmlaf", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasCmlafOptions(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasUpdateYobByCmlafOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("cmlaf", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			actual.getMetaInfo().getCommon().toBuilder().setYob(1);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getYob(), is(-1));
		}

		@Test
		public void testHasUpdateGenderByCmlafOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("cmlaf", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			actual.getMetaInfo().getCommon().toBuilder().setGender(
				GenderType.GENDER_FEMALE);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getGender(),
				is(GenderType.GENDER_UNKNOWN));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasCmlOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("cml", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasCmlOptions(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasNoCmlOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("cml", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TI,
				fixture.parameter, actual);

			// verify
			assertThat(actual.hasCmlOptions(), is(false));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasUpdateYobByCmlOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("cml", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			actual.getMetaInfo().getCommon().toBuilder().setYob(1);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getYob(), is(-1));
		}

		@Test
		public void testHasUpdateGenderByCmlOptions()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("cml", true);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();
			actual.getMetaInfo().getCommon().toBuilder().setGender(
				GenderType.GENDER_FEMALE);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchInputsPayload.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM,
				fixture.parameter, actual);

			// verify
			assertThat(actual.getMetaInfo().getCommon().getGender(),
				is(GenderType.GENDER_UNKNOWN));
		}
	}

	/**
	 * test toPBInquiryPayload( SearchOptions, PBInquiryPayload.Builder builder)
	 * 
	 * @author kawamura
	 * 
	 */
	@SuppressWarnings("boxing")
	public static class ToPBSearchInputPayload_SearchOptions_PBInquiryPayload2Builder {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testUpdateBuilder()
			throws Exception {
			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			SearchOptions parameter = new SearchOptions();
			Method setUpObject =
				ProtoClassConvert.class.getDeclaredMethod("toDynamicXml",
					SearchInputsPayload.class);
			setUpObject.setAccessible(true);
			DynamicXml dom = (DynamicXml)setUpObject.invoke(null, fixture.parameter);
			parameter.setSearchInputsPayload(dom);

			PBInquiryPayload.Builder actual = PBInquiryPayload.newBuilder();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, SearchOptions.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM, parameter,
				actual);

			// verify
			assertThat(actual.hasMetaInfo(), is(true));
		}

		@Test
		public void testThrowException_SomethingIsNotAllowedToAppearInElement()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream(
					"validation with schema/invalid-tim-1.xml");
			String payload = IOUtils.toString(is, "utf-8");

			Method setUpObject =
				ProtoClassConvert.class.getDeclaredMethod("toDynamicXml", String.class);
			setUpObject.setAccessible(true);
			DynamicXml dom = (DynamicXml)setUpObject.invoke(null, payload);

			SearchOptions parameter = new SearchOptions();
			parameter.setSearchInputsPayload(dom);

			expectedException.expect(UnmarshalException.class);
			expectedException
				.expectMessage("cvc-complex-type.3.2.2: Attribute 'applyMatchableFingersThresholds' is not allowed to appear in element 'cmlaf-ti-options'.");

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
						InquiryFunctionType.class, SearchOptions.class,
						PBInquiryPayload.Builder.class);
				sut.setAccessible(true);
				sut.invoke(new ProtoClassConvert(), InquiryFunctionType.TIM, parameter,
					PBInquiryPayload.newBuilder());
			} catch (InvocationTargetException e) {
				// verify
				Throwable t = e.getCause();
				if (t instanceof UnmarshalException) {
					throw new UnmarshalException("cvc-complex-type.3.2.2: Attribute 'applyMatchableFingersThresholds' is not allowed to appear in element 'cmlaf-ti-options'.");
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBChechkExternalIdRequest( String externalId, List<Integer>
	 * eventIds, List<Integer> containerIds)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBChechkExternalIdRequestWith_String_ListOfInteger_ListOfInteger {
		public static ToPBChechkExternalIdRequest_Helper.Fixture fixture =
			ToPBChechkExternalIdRequest_Helper.build();

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnExternalId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBCheckExternalIdRequest actual =
				sut.toPBChechkExternalIdRequest(fixture.parameter.externalId,
					fixture.parameter.eventIds, fixture.parameter.containerIds);

			// verify
			assertThat(actual.getExternalId(), is(fixture.expected.getExternalId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEventIds()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBCheckExternalIdRequest actual =
				sut.toPBChechkExternalIdRequest(fixture.parameter.externalId,
					fixture.parameter.eventIds, fixture.parameter.containerIds);

			// verify
			assertThat(actual.getEventIdsCount(), is(not(0)));
			assertThat(actual.getEventIdsList(), is(fixture.expected.getEventIdsList()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnContainerIds()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBCheckExternalIdRequest actual =
				sut.toPBChechkExternalIdRequest(fixture.parameter.externalId,
					fixture.parameter.containerIds, fixture.parameter.containerIds);

			// verify
			assertThat(actual.getContainerIdsCount(), is(not(0)));
			assertThat(actual.getContainerIdsList(), is(fixture.expected
				.getContainerIdsList()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNoThrowExcpetion_eventId_containerId_are_null()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBCheckExternalIdRequest actual =
				sut.toPBChechkExternalIdRequest(fixture.parameter.externalId, null, null);

			// verify
			assertThat(actual.getExternalId(), is(fixture.expected.getExternalId()));
			assertThat(actual.getEventIdsCount(), is(0));
			assertThat(actual.getContainerIdsCount(), is(0));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<PBCheckExternalIdRequest.Builder> mockUp =
				new MockUp<PBCheckExternalIdRequest.Builder>() {
					@Mock
					public PBCheckExternalIdRequest build() {
						throw new NullPointerException("unit test");
					}
				};

			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBChechkExternalIdRequest(fixture.parameter.externalId,
					fixture.parameter.containerIds, fixture.parameter.containerIds);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}

		@Test
		public void throwInvalidParameterException_IDsOverlap()
			throws Exception {
			// setup
			List<Integer> parameter = new ArrayList<>();
			{
				parameter.add(Integer.valueOf(1));
				parameter.add(Integer.valueOf(1));
			}
			;

			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: container IDs overlap.");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBChechkExternalIdRequest(fixture.parameter.externalId,
					fixture.parameter.containerIds, parameter);
			} catch (InvalidParameterException e) {
				throw new InvalidParameterException(Throwables.getRootCause(e)
					.getMessage());
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBCallbackRequest(String callbackURL, String body)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBCallbackRequestWith_String_String {
		@Test
		public void testReturnCallbackURL()
			throws Exception {
			// setup
			String callbackURL = "test";
			String body = "xyz";

			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBCallbackRequest actual = sut.toPBCallbackRequest(callbackURL, body);

			// verify
			assertThat(actual.getCallbackURL(), is(callbackURL));
		}

		@Test
		public void testReturnTestString()
			throws Exception {
			// setup
			String callbackURL = "test";
			String body = "xyz";

			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBCallbackRequest actual = sut.toPBCallbackRequest(callbackURL, body);

			// verify
			assertThat(actual.getTestString(), is(body));
		}
	}

	/**
	 * test toPBSyncJobRequest( String, Integer, List<Integer>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBSyncJobRequestWith_String_Integer_ListOfInteger {
		public static ToPBSyncJobRequestWith_String_Integer_ListOfInteger_Helper.Fixture fixture =
			ToPBSyncJobRequestWith_String_Integer_ListOfInteger_Helper.build();

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnFunction()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.containerIds);

			// verify
			assertThat(actual.getFunction(), is(fixture.expected.getFunction()));
		}

		@Test
		public void testReturnExternalId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.containerIds);

			// verify
			assertThat(actual.getExternalId(), is(fixture.expected.getExternalId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEventId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.containerIds);

			// verify
			assertThat(actual.getEventId(), is(fixture.expected.getEventId()));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.containerIds);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}

		@Test
		public void throwInvalidParameterException_IDsOverlap()
			throws Exception {
			// setup
			List<Integer> parameter = new ArrayList<>();
			{
				parameter.add(Integer.valueOf(2));
				parameter.add(Integer.valueOf(2));
			}

			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: container IDs overlap.");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, parameter);
			} catch (InvalidParameterException e) {
				throw new InvalidParameterException(Throwables.getRootCause(e)
					.getMessage());
			}
			org.junit.Assert.fail();
		}
		
		
		@Test
		public void testHasPBSyncJobRequest()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.containerIds);

			// verify
			assertThat(actual.hasDeletePayload(), is(true));
		}

		
		@SuppressWarnings("boxing")
		@Test
		public void testReturnPBSyncJobRequest_containerIds_is_null()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest("test", 0, null);

			// verify
			assertThat(actual, is(notNullValue()));
			assertThat(actual.hasDeletePayload(), is(false));
		}

	}

	/**
	 * test toPBSyncDeletePayload(List<Integer>)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBSyncDeletePayloadWith_ListOfInteger {
		@DataPoints
		public static ToPBSyncDeletePayload_ListOfInteger_Helper.Fixture[] getFixtures() {
			// setup
			return ToPBSyncDeletePayload_ListOfInteger_Helper.fixtures;
		};

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnScope(
			ToPBSyncDeletePayload_ListOfInteger_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncDeletePayload",
					List.class);
			sut.setAccessible(true);
			PBSyncDeletePayload actual =
				(PBSyncDeletePayload)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getScopesCount(), is(not(0)));
			assertThat(actual.getScopesList(), is(fixture.expected.getScopesList()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnKey(
			ToPBSyncDeletePayload_ListOfInteger_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncDeletePayload",
					List.class);
			sut.setAccessible(true);
			PBSyncDeletePayload actual =
				(PBSyncDeletePayload)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getKeyedTemplateCount(), is(not(0)));
			for (int index = 0; index < actual.getKeyedTemplateCount(); index++) {
				assertThat(actual.getKeyedTemplate(index).getKey(), is(fixture.expected
					.getKeyedTemplate(index).getKey()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnFfingerPrintType(
			ToPBSyncDeletePayload_ListOfInteger_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncDeletePayload",
					List.class);
			sut.setAccessible(true);
			PBSyncDeletePayload actual =
				(PBSyncDeletePayload)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getKeyedTemplateCount(), is(not(0)));
			assertThat(actual.getKeyedTemplateCount(), is(fixture.expected
				.getKeyedTemplateCount()));
			for (int index = 0; index < actual.getKeyedTemplateCount(); index++) {
				String message = "When container ID is " + fixture.parameter.get(index);
				assertThat(message, actual.getKeyedTemplate(index).getIndexer()
					.getFingerPrintType(), is(fixture.expected.getKeyedTemplate(index)
					.getIndexer().getFingerPrintType()));
			}
		}
	}

	/**
	 * test toPBDeleteJobRequest(long)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBDeleteJobRequestWith_long {
		@SuppressWarnings("boxing")
		@Test
		public void testReturnJobId()
			throws Exception {
			// setup
			long parameter = 1;
			long expected = parameter;

			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBDeleteJobRequest actual = sut.toPBDeleteJobRequest(parameter);

			// verify
			assertThat(actual.getJobId(), is(expected));
		}
	}

	/**
	 * test toPBJobResultRequest(long)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBJobResultRequestWith_long {
		@SuppressWarnings("boxing")
		@Test
		public void testReturnJobId()
			throws Exception {
			// setup
			long parameter = 1;
			long expected = parameter;

			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBJobResultRequest actual = sut.toPBJobResultRequest(parameter);

			// verify
			assertThat(actual.getJobId(), is(expected));
		}
	}

	/**
	 * test toPBJobStatusRequest(long)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBJobStatusRequestWith_long {
		@SuppressWarnings("boxing")
		@Test
		public void testReturnJobId()
			throws Exception {
			// setup
			long parameter = 1;
			long expected = parameter;

			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBJobStatusRequest actual = sut.toPBJobStatusRequest(parameter);

			// verify
			assertThat(actual.getJobId(), is(expected));
		}
	}

	/**
	 * test toPBKeyedTemplate( byte[], TemplateFormatType ,
	 * PBKeyedTemplateIndexer)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class toPBKeyedTemplateWith_byteArray_TemplateFormatType_PBKeyedTemplateIndexer {
		public static ToPBKeyedTemplate_Helper.Fixture fixture = ToPBKeyedTemplate_Helper
			.build();

		@Test
		public void testReturnTemplateBinary()
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplate",
					byte[].class, TemplateFormatType.class, PBKeyedTemplateIndexer.class);
			sut.setAccessible(true);
			PBKeyedTemplate actual =
				(PBKeyedTemplate)sut.invoke(null, fixture.parameter.template,
					fixture.parameter.templateFormatType, fixture.parameter.indexer);

			// verify
			assertThat(actual.getTemplateBinary(), is(fixture.expected
				.getTemplateBinary()));
		}

		@Test
		public void testReturnKey()
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplate",
					byte[].class, TemplateFormatType.class, PBKeyedTemplateIndexer.class);
			sut.setAccessible(true);
			PBKeyedTemplate actual =
				(PBKeyedTemplate)sut.invoke(null, fixture.parameter.template,
					fixture.parameter.templateFormatType, fixture.parameter.indexer);

			// verify
			assertThat(actual.getKey(), is(fixture.expected.getKey()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnIndexer()
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplate",
					byte[].class, TemplateFormatType.class, PBKeyedTemplateIndexer.class);
			sut.setAccessible(true);
			PBKeyedTemplate actual =
				(PBKeyedTemplate)sut.invoke(null, fixture.parameter.template,
					fixture.parameter.templateFormatType, fixture.parameter.indexer);

			// verify
			assertThat(actual.hasIndexer(), is(true));
		}
	}

	/**
	 * test toPBKeyedTemplateIndexer( String, TemplateFormatType )
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBKeyedTemplateWith_String_TemplateFormatType {
		@DataPoints
		public static ToPBKeyedTemplateIndexer_Helper.Fixture[] getFixtures() {
			// setup
			return ToPBKeyedTemplateIndexer_Helper.fixtures;
		};

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnPosition(ToPBKeyedTemplateIndexer_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateIndexer",
					String.class, TemplateFormatType.class);
			sut.setAccessible(true);
			PBKeyedTemplateIndexer actual =
				(PBKeyedTemplateIndexer)sut.invoke(null, fixture.parameter.key,
					fixture.parameter.templateFormatType);

			// verify
			String message = "When a key is " + fixture.parameter.key;
			assertThat(message, actual.hasPosition(), is(fixture.expected.hasPosition()));
			assertThat(message, actual.getPosition(), is(fixture.expected.getPosition()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnFingerPrintType(
			ToPBKeyedTemplateIndexer_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateIndexer",
					String.class, TemplateFormatType.class);
			sut.setAccessible(true);
			PBKeyedTemplateIndexer actual =
				(PBKeyedTemplateIndexer)sut.invoke(null, fixture.parameter.key,
					fixture.parameter.templateFormatType);

			// verify
			String message = "When a key is " + fixture.parameter.key;
			assertThat(message, actual.hasFingerPrintType(), is(fixture.expected
				.hasFingerPrintType()));
			assertThat(message, actual.getFingerPrintType(), is(fixture.expected
				.getFingerPrintType()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnIndex(ToPBKeyedTemplateIndexer_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateIndexer",
					String.class, TemplateFormatType.class);
			sut.setAccessible(true);
			PBKeyedTemplateIndexer actual =
				(PBKeyedTemplateIndexer)sut.invoke(null, fixture.parameter.key,
					fixture.parameter.templateFormatType);

			// verify
			String message = "When a key is " + fixture.parameter.key;
			assertThat(message, actual.hasIndex(), is(fixture.expected.hasIndex()));
			assertThat(message, actual.getIndex(), is(fixture.expected.getIndex()));
		}
	}

	/**
	 * test toPBExtractJobBinaryRequest(long, String)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBExtractJobBinaryRequestWith_long_String {
		@DataPoints
		public static ToPBExtractJobBinaryRequest_Helper.Fixture[] getFixtures() {
			return ToPBExtractJobBinaryRequest_Helper.fixtures;
		}

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnJobId(ToPBExtractJobBinaryRequest_Helper.Fixture fixture)
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBExtractJobBinaryRequest actual =
				sut.toPBExtractJobBinaryRequest(fixture.parameter.jobId,
					fixture.parameter.key);

			// verify
			String message = "When the key is " + fixture.parameter.key;
			assertThat(message, actual.getJobId(), is(fixture.expected.getJobId()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasKeyedTemplate(
			ToPBExtractJobBinaryRequest_Helper.Fixture fixture)
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBExtractJobBinaryRequest actual =
				sut.toPBExtractJobBinaryRequest(fixture.parameter.jobId,
					fixture.parameter.key);

			// verify
			String message = "When the key is " + fixture.parameter.key;
			assertThat(message, actual.getKeyedTemplateCount(), is(not(0)));
			assertThat(message, actual.getKeyedTemplateCount(), is(fixture.expected
				.getKeyedTemplateCount()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasIndexer(ToPBExtractJobBinaryRequest_Helper.Fixture fixture)
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBExtractJobBinaryRequest actual =
				sut.toPBExtractJobBinaryRequest(fixture.parameter.jobId,
					fixture.parameter.key);

			// verify
			String message = "When the key is " + fixture.parameter.key;
			for (int index = 0; index < actual.getKeyedTemplateCount(); index++) {
				if (actual.getKeyedTemplate(index).getKey() != TemplateFormatType.TEMPLATE_II
					&& actual.getKeyedTemplate(index).getKey() != TemplateFormatType.TEMPLATE_IDB) {
					assertThat(message, actual.getKeyedTemplate(index).hasIndexer(),
						is(true));
				} else {
					assertThat(message, actual.getKeyedTemplate(index).hasIndexer(),
						is(false));
				}
			}
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBExtractJobBinaryRequest(getFixtures()[0].parameter.jobId,
					getFixtures()[0].parameter.key);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBKeyedTemplateReference( ExtractResultReference)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBKeyedTemplateReferenceWith_ExtractResultReference {
		public static ToPBKeyedTemplateReference_Helper.Fixture fixture =
			ToPBKeyedTemplateReference_Helper.build(true);

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnJobId()
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateReference",
					String.class, ExtractResultReference.class);
			sut.setAccessible(true);
			PBKeyedTemplateReference actual =
				(PBKeyedTemplateReference)sut.invoke(null, fixture.containerIdToKey,
					fixture.parameter);

			// verify
			assertThat(actual.getJobId(), is(fixture.expected.getJobId()));
		}

		@Test
		public void testReturnKey()
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateReference",
					String.class, ExtractResultReference.class);
			sut.setAccessible(true);
			PBKeyedTemplateReference actual =
				(PBKeyedTemplateReference)sut.invoke(null, fixture.containerIdToKey,
					fixture.parameter);

			// verify
			assertThat(actual.getKey(), is(fixture.expected.getKey()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasIndexer()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateReference",
					String.class, ExtractResultReference.class);
			sut.setAccessible(true);
			PBKeyedTemplateReference actual =
				(PBKeyedTemplateReference)sut.invoke(null, fixture.containerIdToKey,
					fixture.parameter);

			// verify
			assertThat(actual.hasIndexer(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasNotIndexer()
			throws Exception {
			ToPBKeyedTemplateReference_Helper.Fixture fixture =
				ToPBKeyedTemplateReference_Helper.build(false);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateReference",
					String.class, ExtractResultReference.class);
			sut.setAccessible(true);
			PBKeyedTemplateReference actual =
				(PBKeyedTemplateReference)sut.invoke(null, fixture.containerIdToKey,
					fixture.parameter);

			// verify
			assertThat(actual.hasIndexer(), is(false));
		}

		@Test
		public void testThrowInvalidParameterException_Invlaid_containerIdAndKey()
			throws Exception {
			// setup
			ExtractResultReference parameter = new ExtractResultReference();
			parameter.setJobId(2346);
			parameter.setKey("RDBT");
			String containerIdToKey = "SDBT";

			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: a combination of container ID and key.");

			try {
				// exercise
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod(
						"toPBKeyedTemplateReference", String.class,
						ExtractResultReference.class);
				sut.setAccessible(true);
				sut.invoke(null, containerIdToKey, parameter);
			} catch (InvocationTargetException e) {
				Throwable t = Throwables.getRootCause(e);
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBKeyedTemplateData( RegistrationRequest, Map<Integer, Integer>)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBKeyedTemplateDataWith_RegistrationRequest_Map {
		@DataPoints
		public static ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.Fixture[] getFixtures() {
			// setup
			return ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.fixtures;
		};

		@SuppressWarnings("boxing")
		@Theory
		public void testHasKeyedReferenece(
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					RegistrationRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null,
					fixture.parameter.registrationRequest, fixture.parameter.index);

			// verify
			if (!fixture.expected.hasKeyedReferenece()) {
				return;
			}
			assertThat(actual.hasKeyedReferenece(), is(true));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnTemplateBinary(
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					RegistrationRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null,
					fixture.parameter.registrationRequest, fixture.parameter.index);

			// verify
			if (!fixture.expected.hasKeyedTemplate()) {
				return;
			}
			assertThat(actual.getKeyedTemplate().getTemplateBinary().size(), is(not(0)));
			assertThat(actual.getKeyedTemplate().getTemplateBinary(), is(fixture.expected
				.getKeyedTemplate().getTemplateBinary()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnKey(
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					RegistrationRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null,
					fixture.parameter.registrationRequest, fixture.parameter.index);

			// verify
			if (!fixture.expected.hasKeyedTemplate()) {
				return;
			}
			assertThat(actual.getKeyedTemplate().hasKey(), is(true));
			assertThat(actual.getKeyedTemplate().getKey(), is(fixture.expected
				.getKeyedTemplate().getKey()));
		}

		@Theory
		public void testHasPosition(
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					RegistrationRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null,
					fixture.parameter.registrationRequest, fixture.parameter.index);

			// verify
			if (!fixture.expected.hasKeyedTemplate()) {
				return;
			}
			if (!fixture.expected.getKeyedTemplate().getIndexer().hasPosition()) {
				return;
			}

			String message =
				"When container ID is "
					+ fixture.parameter.registrationRequest.getDestinationContainer();
			assertThat(message, actual.getKeyedTemplate().getIndexer().getPosition(),
				is(fixture.expected.getKeyedTemplate().getIndexer().getPosition()));
		}

		@Theory
		public void testHasFingerPrintType(
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					RegistrationRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null,
					fixture.parameter.registrationRequest, fixture.parameter.index);

			// verify
			if (!fixture.expected.hasKeyedTemplate()) {
				return;
			}
			if (!fixture.expected.getKeyedTemplate().getIndexer().hasFingerPrintType()) {
				return;
			}

			String message =
				"When container ID is "
					+ fixture.parameter.registrationRequest.getDestinationContainer();
			assertThat(message, actual.getKeyedTemplate().getIndexer()
				.getFingerPrintType(), is(fixture.expected.getKeyedTemplate()
				.getIndexer().getFingerPrintType()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasIndex(
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					RegistrationRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null,
					fixture.parameter.registrationRequest, fixture.parameter.index);

			// verify
			if (!fixture.expected.hasKeyedTemplate()) {
				return;
			}
			if (!fixture.expected.getKeyedTemplate().getIndexer().hasIndex()) {
				return;
			}

			String message =
				"When container ID is "
					+ fixture.parameter.registrationRequest.getDestinationContainer();
			assertThat(message, actual.getKeyedTemplate().getIndexer().getIndex(),
				is(fixture.expected.getKeyedTemplate().getIndexer().getIndex()));
		}
	}

	/**
	 * test toPBSyncInsertPayload( List<RegistrationRequest>)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBSyncInsertPayloadWith_ListOfRegistrationRequests {
		@DataPoints
		public static ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper.Fixture[] getFixtures() {
			// setup
			return ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper.fixtures;
		};

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnScope(
			ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
					List.class);
			sut.setAccessible(true);
			PBSyncInsertPayload actual =
				(PBSyncInsertPayload)sut.invoke(null,
					fixture.parameter.registrationRequest);

			// verify
			for (int index = 0; index < fixture.expected.getKeyedTemplateDataCount(); index++) {
				String message =
					"When container ID is "
						+ fixture.parameter.registrationRequest.get(index);
				assertThat(message, actual.hasScope(), is(true));
				assertThat(message, actual.getScope(), is(fixture.expected.getScope()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasKeyedTemplateData(
			ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
					List.class);
			sut.setAccessible(true);
			PBSyncInsertPayload actual =
				(PBSyncInsertPayload)sut.invoke(null,
					fixture.parameter.registrationRequest);

			// verify
			String message =
				"When container ID is "
					+ fixture.parameter.registrationRequest.get(0)
						.getDestinationContainer();
			assertThat(message, actual.getKeyedTemplateDataCount(), is(not(0)));
			assertThat(message, actual.getKeyedTemplateDataCount(), is(fixture.expected
				.getKeyedTemplateDataCount()));
		}

		@Theory
		public void testIncrementPosition(
			ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
					List.class);
			sut.setAccessible(true);
			PBSyncInsertPayload actual =
				(PBSyncInsertPayload)sut.invoke(null,
					fixture.parameter.registrationRequest);

			// verify
			for (int index = 0; index < fixture.expected.getKeyedTemplateDataCount(); index++) {
				TemplateFormatType key =
					actual.getKeyedTemplateData(index).getKeyedTemplate().getKey();
				if (key != TemplateFormatType.TEMPLATE_RDBL
					&& key != TemplateFormatType.TEMPLATE_RDBLS
					&& key != TemplateFormatType.TEMPLATE_RDBLM
					&& key != TemplateFormatType.TEMPLATE_PDB) {
					continue;
				}
				String message =
					"When container ID is "
						+ fixture.parameter.registrationRequest.get(index)
							.getDestinationContainer();
				assertThat(message, actual.getKeyedTemplateData(index).getKeyedTemplate()
					.getIndexer().getPosition(), is(fixture.expected
					.getKeyedTemplateData(index).getKeyedTemplate().getIndexer()
					.getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testIncrementIndex(
			ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
					List.class);
			sut.setAccessible(true);
			PBSyncInsertPayload actual =
				(PBSyncInsertPayload)sut.invoke(null,
					fixture.parameter.registrationRequest);

			// verify
			for (int index = 0; index < fixture.expected.getKeyedTemplateDataCount(); index++) {
				TemplateFormatType key =
					actual.getKeyedTemplateData(index).getKeyedTemplate().getKey();
				if (key != TemplateFormatType.TEMPLATE_FDB) {
					continue;
				}
				String message =
					"When container ID is "
						+ fixture.parameter.registrationRequest.get(index);
				assertThat(message, actual.getKeyedTemplateData(index).getKeyedTemplate()
					.getIndexer().getIndex(), is(fixture.expected.getKeyedTemplateData(
					index).getKeyedTemplate().getIndexer().getIndex()));
			}
		}

		@Test
		public void testThrowExcpetion()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: there is a invalid container ID.");

			List<RegistrationRequest> parameter = new ArrayList<>();
			{
				parameter.add(new RegistrationRequest() {
					{
						destinationContainer = 1;
						record = new Record() {
							{
								binary = RandomStringUtils.randomAscii(32).getBytes();
							}
						};
					}
				});
			}
			{
				parameter.add(new RegistrationRequest() {
					{
						destinationContainer = 1003;
						record = new Record() {
							{
								binary = RandomStringUtils.randomAscii(32).getBytes();
							}
						};
					}
				});
			}

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
						List.class);
				sut.setAccessible(true);
				sut.invoke(null, parameter);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBSyncJobRequest( String, int, List<RegistrationRequest>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBSyncJobRequestWith_String_int_ListOfRegistrationRequest {
		public static ToPBSyncJobRequestWith_String_int_ListOfRegistrationRequest_Helper.Fixture fixture =
			ToPBSyncJobRequestWith_String_int_ListOfRegistrationRequest_Helper.build();

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnFunction()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.registrationRequestList);

			// verify
			assertThat(actual.getFunction(), is(fixture.expected.getFunction()));
		}

		@Test
		public void testReturExternalId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.registrationRequestList);

			// verify
			assertThat(actual.getExternalId(), is(fixture.expected.getExternalId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturEventId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.registrationRequestList);

			// verify
			assertThat(actual.getEventId(), is(fixture.expected.getEventId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasInsertPayload()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.registrationRequestList);

			// verify
			assertThat(actual.hasInsertPayload(), is(true));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBSyncJobRequest(fixture.parameter.externalId,
					fixture.parameter.eventId, fixture.parameter.registrationRequestList);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBSyncJobRequest( String, int, List<RegistrationRequest>,
	 * List<Integer>)
	 * 
	 * @author kawamura
	 * 
	 */
	@SuppressWarnings("boxing")
	public static class ToPBSyncJobRequestWith_String_int_ListOfRegistrationRequest_ListOfInteger {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		// setup
		String parameter1 = "test";
		int parameter2 = 1;
		List<RegistrationRequest> parameter3 = new ArrayList<>();
		{
			parameter3.add(new RegistrationRequest() {
				{
					destinationContainer = 1;
					record = new Record() {
						{
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			});
		}
		List<Integer> parameter4 = new ArrayList<>();
		{
			parameter4.add(3);
		}

		String expectedExternalId = parameter1;
		int expectedEventId = parameter2;

		@Test
		public void testReturFunction()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(parameter1, parameter2, parameter3, parameter4);

			// verify
			assertThat(actual.getFunction(), is(SyncFunctionType.UPDATE));
		}

		@Test
		public void testReturExternalId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(parameter1, parameter2, parameter3, parameter4);

			// verify
			assertThat(actual.getExternalId(), is(expectedExternalId));
		}

		@Test
		public void testReturEventId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(parameter1, parameter2, parameter3, parameter4);

			// verify
			assertThat(actual.getEventId(), is(expectedEventId));
		}

		@Test
		public void testHasInsertPayload()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(parameter1, parameter2, parameter3, parameter4);

			// verify
			assertThat(actual.hasInsertPayload(), is(true));
		}

		@Test
		public void testDeletePayload()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(parameter1, parameter2, parameter3, parameter4);

			// verify
			assertThat(actual.hasDeletePayload(), is(true));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBSyncJobRequest(parameter1, parameter2, parameter3, parameter4);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}

		@Test
		public void throwInvalidParameterException_IDsOverlap()
			throws Exception {
			// setup
			List<Integer> parameter4 = new ArrayList<>();
			{
				parameter4.add(2);
				parameter4.add(2);
			}

			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: container IDs overlap.");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBSyncJobRequest(parameter1, parameter2, parameter3, parameter4);
			} catch (InvalidParameterException e) {
				throw new InvalidParameterException(Throwables.getRootCause(e)
					.getMessage());
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test validateFunctionToKey( AfisRegistrationFunctionEnum,
	 * AfisTemplateSet)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ValidateFunctionToKeyWith_AfisRegistrationFunctionEnum_AfisTemplateSet {
		@DataPoints
		public static ValidateFunctionToKey_Helper.Fixture[] getFixtures() {
			return ValidateFunctionToKey_Helper.fixtures;
		}

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Theory
		public void testNoThrowException(ValidateFunctionToKey_Helper.Fixture fixture)
			throws Exception {
			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("validateFunctionToKey",
						AfisRegistrationFunctionEnum.class, AfisTemplateSet.class);
				sut.setAccessible(true);
				sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisTemplateSet);
			} catch (InvocationTargetException e) {
				org.junit.Assert.fail();
			}
		}

		@Test
		public void testThrowException()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: there is a invalid key as IDB.");

			AfisTemplateSet parameter = new AfisTemplateSet() {
				{
					template = new ArrayList<>();
					template.add(new KeyedTemplate() {
						{
							key = "IDB";
						}
					});
				}
			};

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("validateFunctionToKey",
						AfisRegistrationFunctionEnum.class, AfisTemplateSet.class);
				sut.setAccessible(true);
				sut.invoke(null, AfisRegistrationFunctionEnum.FR, parameter);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBIrisOprions(IrisOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBIrisOptionsWith_IrisOptions {
		public static ToPBIrisOptions_Helper.Fixture fixture = ToPBIrisOptions_Helper
			.build();

		@Test
		public void testReturnSearchMode()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBIrisOptions",
					IrisOptions.class);
			sut.setAccessible(true);
			PBIrisOptions actual = (PBIrisOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSearchMode(), is(fixture.expected.getSearchMode()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnRotationLimit()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBIrisOptions",
					IrisOptions.class);
			sut.setAccessible(true);
			PBIrisOptions actual = (PBIrisOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRotationLimit(), is(fixture.expected.getRotationLimit()));
		}
	}

	/**
	 * test toPBExtractInputIrisDetection(IrisInputDetection)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputIrisExtractionWith_IrisInputExtraction {
		public static ToPBExtractInputIrisExtraction_Helper.Fixture fixture =
			ToPBExtractInputIrisExtraction_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnExtractionMode()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod(
					"toPBExtractInputIrisExtraction", IrisInputExtraction.class);
			sut.setAccessible(true);
			PBExtractInputIrisExtraction actual =
				(PBExtractInputIrisExtraction)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMode(), is(fixture.expected
				.getMode()));
		}
	}

	/**
	 * test toPBBasicImageEnhanceOptions(EnhType)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBBasicImageEnhanceOptionsWith_EnhType {
		public static ToPBBasicImageEnhanceOptions_Helper.Fixture fixture =
			ToPBBasicImageEnhanceOptions_Helper.build();

		@Test
		public void testReturnBasicImageEnhanceType()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBBasicImageEnhanceOptions",
					EnhType.class);
			sut.setAccessible(true);
			PBBasicImageEnhanceOptions actual =
				(PBBasicImageEnhanceOptions)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getEnhancements(0), is(fixture.expected.getEnhancements(0)));
		}
	}

	/**
	 * test toPBExtractInputImage( List<IrisInputImage>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputImageWith_ListOfIrisInputImage {
		@SuppressWarnings("boxing")
		@Test
		public void testReturnBinary()
			throws Exception {
			// setup
			ToPBExtractInputImage_Helper.Fixture fixture =
				ToPBExtractInputImage_Helper.build("binary");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputImage> actual =
				(List<PBExtractInputImage>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getData().toByteArray(), is(fixture.expected
					.get(index).getData().toByteArray()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnUrl()
			throws Exception {
			// setup
			ToPBExtractInputImage_Helper.Fixture fixture =
				ToPBExtractInputImage_Helper.build("url");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputImage> actual =
				(List<PBExtractInputImage>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getUrl(), is(fixture.expected.get(index)
					.getUrl()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnPosition()
			throws Exception {
			// setup
			ToPBExtractInputImage_Helper.Fixture fixture =
				ToPBExtractInputImage_Helper.build("url");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputImage> actual =
				(List<PBExtractInputImage>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPosition(), is(fixture.expected
					.get(index).getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnWidth()
			throws Exception {
			//setup
			ToPBExtractInputImage_Helper.Fixture fixture =
				ToPBExtractInputImage_Helper.build("url");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputImage> actual =
				(List<PBExtractInputImage>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getWidth(), is(fixture.expected
					.get(index).getWidth()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeight()
			throws Exception {
			//setup
			ToPBExtractInputImage_Helper.Fixture fixture =
				ToPBExtractInputImage_Helper.build("url");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputImage> actual =
				(List<PBExtractInputImage>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getHeight(), is(fixture.expected
					.get(index).getHeight()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnType()
			throws Exception {
			// setup
			ToPBExtractInputImage_Helper.Fixture fixture =
				ToPBExtractInputImage_Helper.build("url");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputImage",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBExtractInputImage> actual =
				(List<PBExtractInputImage>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getType(), is(fixture.expected.get(index)
					.getType()));
			}
		}
	}

	/**
	 * test toPBExtractIrisInput(IrisInput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractIrisInputWith_IrisInput {
		public static ToPBExtractIrisInput_Helper.Fixture fixture =
			ToPBExtractIrisInput_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasAimFomrats()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractIrisInput",
					IrisInput.class);
			sut.setAccessible(true);
			PBExtractIrisInput actual =
				(PBExtractIrisInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getAimFormatsCount(), is(not(0)));
			assertThat(actual.getAimFormatsCount(), is(fixture.expected
				.getAimFormatsCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasImage()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractIrisInput",
					IrisInput.class);
			sut.setAccessible(true);
			PBExtractIrisInput actual =
				(PBExtractIrisInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getImageCount(), is(not(0)));
			assertThat(actual.getImageCount(), is(fixture.expected.getImageCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasBasicEnhanceOptions()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractIrisInput",
					IrisInput.class);
			sut.setAccessible(true);
			PBExtractIrisInput actual =
				(PBExtractIrisInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasBasicEnhanceOptions(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasMetaInfo()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractIrisInput",
					IrisInput.class);
			sut.setAccessible(true);
			PBExtractIrisInput actual =
				(PBExtractIrisInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasMetaInfo(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasExtraction()
			throws Exception {
			// exercise
			Method sut = 
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractIrisInput",
					IrisInput.class);
			sut.setAccessible(true);
			PBExtractIrisInput actual =
				(PBExtractIrisInput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.hasExtraction(), is(true));
		}
	}

	/**
	 * test validateNumAfisGroupId(TemplateMetadata)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ValidateNumAfisGroupIdWith_TemplateMetadata {
		@DataPoints
		public static ValidateNumAfisGroupId_Helper.Fixture[] getFixtures() {
			return ValidateNumAfisGroupId_Helper.fixtures;
		}

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Theory
		public void testNoThrowException(ValidateNumAfisGroupId_Helper.Fixture fixture)
			throws Exception {
			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("validateNumAfisGroupId",
						TemplateMetadata.class);
				sut.setAccessible(true);
				sut.invoke(null, fixture.parameter.templateMetadata);
			} catch (InvocationTargetException e) {
				org.junit.Assert.fail();
			}
		}

		@Test
		public void testThrowException()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: the number of afis group IDs.");

			@SuppressWarnings("boxing")
			TemplateMetadata parameter = new TemplateMetadata() {
				{
					afisGroupId = new ArrayList<>();
					afisGroupId.add(1);
					afisGroupId.add(2);
				}
			};

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("validateNumAfisGroupId",
						TemplateMetadata.class);
				sut.setAccessible(true);
				sut.invoke(null, parameter);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBKeyedTemplateData(KeyedTemplate)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBKeyedTemplateDataWith_KeyedTemplate {
		@DataPoints
		public static ToPBKeyedTemplateDataWith_KeyedTemplate_Helper.Fixture[] getFixtures() {
			// setup
			return ToPBKeyedTemplateDataWith_KeyedTemplate_Helper.fixtures;
		};

		@SuppressWarnings("boxing")
		@Theory
		public void testHasKeyedTemplate(
			ToPBKeyedTemplateDataWith_KeyedTemplate_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					KeyedTemplate.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.keyedTemplate);

			// verify
			assertThat(actual.hasKeyedTemplate(), is(true));
		}

		@Theory
		public void testReturnKeyOfPBKeyedTemplate(
			ToPBKeyedTemplateDataWith_KeyedTemplate_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					KeyedTemplate.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.keyedTemplate);

			// verify
			assertThat(actual.getKeyedTemplate().getKey(), is(fixture.expected
				.getKeyedTemplate().getKey()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasIndexerOfPBKeyetdTemplate(
			ToPBKeyedTemplateDataWith_KeyedTemplate_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					KeyedTemplate.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.keyedTemplate);

			// verify
			if (actual.getKeyedTemplate().getKey() == TemplateFormatType.TEMPLATE_LDBX) {
				assertThat(actual.getKeyedTemplate().hasIndexer(), is(false));
			} else {
				assertThat(actual.getKeyedTemplate().hasIndexer(), is(true));
			}
		}
	}

	/**
	 * test toPBSyncInsertPayload(AfisRegistrationFunctionEnum, AfisTemplateSet)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet {
		@DataPoints
		public static ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.Fixture[] getFixtures() {
			// setup
			return ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.fixtures;
		};

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnScope(
			ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
					AfisRegistrationFunctionEnum.class, AfisTemplateSet.class);
			sut.setAccessible(true);
			PBSyncInsertPayload actual =
				(PBSyncInsertPayload)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisTemplateSet);

			// verify
			for (int index = 0; index < fixture.expected.getKeyedTemplateDataCount(); index++) {
				String message =
					"When container ID is "
						+ fixture.parameter.afisTemplateSet.getTemplate().get(index)
							.getKey();
				assertThat(message, actual.getScope(), is(fixture.expected.getScope()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasKeyedTemplateData(
			ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
					AfisRegistrationFunctionEnum.class, AfisTemplateSet.class);
			sut.setAccessible(true);
			PBSyncInsertPayload actual =
				(PBSyncInsertPayload)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.getKeyedTemplateDataCount(), is(not(0)));
			assertThat(actual.getKeyedTemplateDataCount(), is(fixture.expected
				.getKeyedTemplateDataCount()));
		}

		@Test
		public void testThrowExceptionWithDifferentScopes()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: there is a invalid group ID.");

			@SuppressWarnings("boxing")
			AfisTemplateSet afisTemplateSet = new AfisTemplateSet() {
				{
					template = new ArrayList<>();
					template.add(new KeyedTemplate() {
						{
							key = "RDBT";
							metadata = new TemplateMetadata() {
								{
									afisGroupId = new ArrayList<>();
									afisGroupId.add(1);
								}

							};
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					});
					template.add(new KeyedTemplate() {
						{
							key = "SDBTM";
							metadata = new TemplateMetadata() {
								{
									afisGroupId = new ArrayList<>();
									afisGroupId.add(2);
								}

							};
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					});
				}
			};

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
						AfisRegistrationFunctionEnum.class, AfisTemplateSet.class);
				sut.setAccessible(true);
				sut.invoke(null, AfisRegistrationFunctionEnum.TR, afisTemplateSet);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}

		@Test
		public void testThrowExceptionWithScopesATemplateMetadata()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: the number of afis group IDs.");

			@SuppressWarnings("boxing")
			AfisTemplateSet afisTemplateSet = new AfisTemplateSet() {
				{
					template = new ArrayList<>();
					template.add(new KeyedTemplate() {
						{
							key = "RDBT";
							metadata = new TemplateMetadata() {
								{
									afisGroupId = new ArrayList<>();
									afisGroupId.add(1);
									afisGroupId.add(2);
								}

							};
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					});
				}
			};

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
						AfisRegistrationFunctionEnum.class, AfisTemplateSet.class);
				sut.setAccessible(true);
				sut.invoke(null, AfisRegistrationFunctionEnum.TR, afisTemplateSet);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBSyncJobRequest( AfisRegistrationFunctionEnum, String, int,
	 * AfisTemplateSet)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBSyncJobRequestWith_AfisRegistrationFunctionEnum_String_intr_AfisTemplateSet {
		public static ToPBSyncJobRequestWith_AfisRegistrationFunctionEnum_String_int_AfisTemplateSet_Helper.Fixture fixture =
			ToPBSyncJobRequestWith_AfisRegistrationFunctionEnum_String_int_AfisTemplateSet_Helper
				.build();
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnFunction()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.getFunction(), is(fixture.expected.getFunction()));
		}

		@Test
		public void testReturnExternalId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(AfisRegistrationFunctionEnum.TR,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.getExternalId(), is(fixture.expected.getExternalId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEventId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(AfisRegistrationFunctionEnum.TR,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.getEventId(), is(fixture.expected.getEventId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasInsertPayltoad()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(AfisRegistrationFunctionEnum.TR,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.hasInsertPayload(), is(true));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBSyncJobRequest(AfisRegistrationFunctionEnum.TR,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisTemplateSet);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBSyncDeletePayload(AfisDeletionFunctionEnum, Integer)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer {
		@DataPoints
		public static ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.Fixture[] getFixtures() {
			return ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.fixtures;
		}

		@Theory
		public void testReturnScopes(
			ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncDeletePayload",
					AfisDeletionFunctionEnum.class, Integer.class);
			sut.setAccessible(true);
			PBSyncDeletePayload actual =
				(PBSyncDeletePayload)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisGroupId);

			// verify
			assertThat(actual.getScopesList(), is(fixture.expected.getScopesList()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnKey(
			ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncDeletePayload",
					AfisDeletionFunctionEnum.class, Integer.class);
			sut.setAccessible(true);
			PBSyncDeletePayload actual =
				(PBSyncDeletePayload)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisGroupId);

			// verify
			assertThat(actual.getKeyedTemplateCount(), is(not(0)));
			for (int index = 0; index < fixture.expected.getKeyedTemplateCount(); index++) {
				assertThat(actual.getKeyedTemplate(index).getKey(), is(fixture.expected
					.getKeyedTemplate(index).getKey()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnFingerPrintType(
			ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncDeletePayload",
					AfisDeletionFunctionEnum.class, Integer.class);
			sut.setAccessible(true);
			PBSyncDeletePayload actual =
				(PBSyncDeletePayload)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisGroupId);

			// verify
			assertThat(actual.getKeyedTemplateCount(), is(not(0)));
			for (int index = 0; index < fixture.expected.getKeyedTemplateCount(); index++) {
				if (!actual.getKeyedTemplate(index).getIndexer().hasFingerPrintType()) {
					continue;
				}

				assertThat(actual.getKeyedTemplate(index).getIndexer()
					.getFingerPrintType(), is(fixture.expected.getKeyedTemplate(index)
					.getIndexer().getFingerPrintType()));
			}
		}
	}

	/**
	 * test toPBSyncJobRequest( AfisDeletionFunctionEnum, String, Integer,
	 * Integer)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBSyncJobRequestWith_AfisDeletionFunctionEnum_String_Integer_Integer {
		public static ToPBSyncJobRequestWith_AfisDeletionFunctionEnum_String_Integer_Integer_Helper.Fixture fixture =
			ToPBSyncJobRequestWith_AfisDeletionFunctionEnum_String_Integer_Integer_Helper
				.build();
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnFunction()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId);

			// verify
			assertThat(actual.getFunction(), is(fixture.expected.getFunction()));
		}

		@Test
		public void testReturnExternalId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId);

			// verify
			assertThat(actual.getExternalId(), is(fixture.expected.getExternalId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEventlId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId);

			// verify
			assertThat(actual.getEventId(), is(fixture.expected.getEventId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasDeletePayload()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId);

			// verify
			assertThat(actual.hasDeletePayload(), is(true));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId);

			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBSyncInsertPayload( AfisUpdateFunctionEnum, AfisTemplateSet )
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBSyncInsertPayloadWith_AfisUpdateFunctionEnum_AfisTemplateSet {
		@DataPoints
		public static ToPBSyncInsertPayloadWith_AfisUpdateFunctionEnum_AfisTemplateSet_Helper.Fixture[] getFfixtures() {
			return ToPBSyncInsertPayloadWith_AfisUpdateFunctionEnum_AfisTemplateSet_Helper.fixtures;
		}

		@Theory
		public void testHasInsertPayload(
			ToPBSyncInsertPayloadWith_AfisUpdateFunctionEnum_AfisTemplateSet_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncInsertPayload",
					AfisUpdateFunctionEnum.class, AfisTemplateSet.class);
			sut.setAccessible(true);
			PBSyncInsertPayload actual =
				(PBSyncInsertPayload)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisTemplateSet);

			// verify
			for (int index = 0; index < fixture.expected.getKeyedTemplateDataCount(); index++) {
				assertThat(
					actual.getKeyedTemplateData(index).getKeyedTemplate().getKey(),
					is(fixture.expected.getKeyedTemplateData(index).getKeyedTemplate()
						.getKey()));
			}
		}
	}

	/**
	 * tedt toPBSyncDeletePayload( AfisUpdateFunctionEnum, Integer)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBSyncDeletePayloadWith_AfisUpdateFunctionEnum_Integer {
		@DataPoints
		public static ToPBSyncDeletePayloadWith_AfisUpdateFunctionEnum_Integer_Helper.Fixture[] getFfixtures() {
			return ToPBSyncDeletePayloadWith_AfisUpdateFunctionEnum_Integer_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasDeletePayload(
			ToPBSyncDeletePayloadWith_AfisUpdateFunctionEnum_Integer_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBSyncDeletePayload",
					AfisUpdateFunctionEnum.class, Integer.class);
			sut.setAccessible(true);
			PBSyncDeletePayload actual =
				(PBSyncDeletePayload)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisGroupId);

			// verify
			for (int index = 0; index < fixture.expected.getKeyedTemplateCount(); index++) {
				assertThat(actual.getKeyedTemplateCount(), is(not(0)));
				assertThat(actual.getKeyedTemplate(index).getKey(), is(fixture.expected
					.getKeyedTemplate(index).getKey()));
			}
		}
	}

	/**
	 * test toPBSyncJobRequest(AfisUpdateFunctionEnum, String , int, Integer,
	 * AfisTemplateSet)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBSyncJobRequestWith_AfisUpdateFunctionEnum_String_int_Integer_AfisTemplateSet {
		public static ToPBSyncJobRequestWith_AfisUpdateFunctionEnum_String_Integer_int_Integer_AfisTemplateSet_Helper.Fixture fixture =
			ToPBSyncJobRequestWith_AfisUpdateFunctionEnum_String_Integer_int_Integer_AfisTemplateSet_Helper
				.build();
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnFunction()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId, fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.getFunction(), is(fixture.expected.getFunction()));
		}

		@Test
		public void testReturnExternalId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId, fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.getExternalId(), is(fixture.expected.getExternalId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEventlId()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId, fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.getEventId(), is(fixture.expected.getEventId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasDeletePayload()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBSyncJobRequest actual =
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId, fixture.parameter.afisTemplateSet);

			// verify
			assertThat(actual.hasDeletePayload(), is(true));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBSyncJobRequest(fixture.parameter.function,
					fixture.parameter.externalId, fixture.parameter.eventId,
					fixture.parameter.afisGroupId, fixture.parameter.afisTemplateSet);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBKeyedTemplateData( SearchRequest, Map<TemplateFormatType,
	 * Integer>)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBKeyedTemplateDataWith_SearchRequest_Map {
		@DataPoints
		public static ToPBKeyedTemplateDataWith_SearchRequest_Helper.Fixture[] getFixtures() {
			return ToPBKeyedTemplateDataWith_SearchRequest_Helper.binaryFixtures;
		}

		@DataPoints
		public static ToPBKeyedTemplateDataWith_SearchRequest_Helper.ReferenceFixture[] getReferenceFixtures() {
			return ToPBKeyedTemplateDataWith_SearchRequest_Helper.referenceFixtures;
		}

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Theory
		public void testHasKeyedTemplate(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			assertThat(actual.hasKeyedTemplate(), is(true));
		}

		@Theory
		public void testHasReturnTemplateBinary(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			assertThat(actual.getKeyedTemplate().getTemplateBinary(), is(fixture.expected
				.getKeyedTemplate().getTemplateBinary()));
		}

		@Theory
		public void testReturnKey(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			assertThat(actual.getKeyedTemplate().getKey(), is(fixture.expected
				.getKeyedTemplate().getKey()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasIndexer(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			if (actual.getKeyedTemplate().getKey() == TemplateFormatType.TEMPLATE_LIP) {
				return;
			}

			assertThat(actual.getKeyedTemplate().hasIndexer(), is(true));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasNotIndexer(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			if (actual.getKeyedTemplate().getKey() != TemplateFormatType.TEMPLATE_LIP) {
				return;
			}

			assertThat(actual.getKeyedTemplate().hasIndexer(), is(false));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasIncrementIndex(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			if (actual.getKeyedTemplate().getKey() == TemplateFormatType.TEMPLATE_LIP) {
				return;
			}

			Integer index =
				ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap
					.get(actual.getKeyedTemplate().getKey());
			assertThat(index, is(2));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasKeyedReference(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.ReferenceFixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			assertThat(actual.hasKeyedReferenece(), is(true));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnJobIdFromReference(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.ReferenceFixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			assertThat(actual.getKeyedReferenece().getJobId(), is(fixture.expected
				.getKeyedReferenece().getJobId()));
		}

		@Theory
		public void testReturnKeyFromReference(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.ReferenceFixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			assertThat(actual.getKeyedReferenece().getKey(), is(fixture.expected
				.getKeyedReferenece().getKey()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasIndexerInReference(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.ReferenceFixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			if (actual.getKeyedReferenece().getKey() == TemplateFormatType.TEMPLATE_II) {
				return;
			}

			assertThat(actual.getKeyedReferenece().hasIndexer(), is(true));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasNotIndexerInReference(
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.ReferenceFixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					SearchRequest.class, Map.class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);

			// verify
			if (actual.getKeyedReferenece().getKey() != TemplateFormatType.TEMPLATE_II) {
				return;
			}

			assertThat(actual.getKeyedReferenece().hasIndexer(), is(false));
		}

		@Test
		public void testThrowExcpetionWithNoBinaryAndNoReference()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: there are binary and reference data.");

			SearchRequest searchRequest = new SearchRequest() {
				{
					functionName = "FI";
					record = new Record() {
						{
							binary = RandomStringUtils.randomAscii(32).getBytes();
							reference = new ExtractResultReference() {
								{
									jobId = 1;
									key = "FI_3";
								}
							};
						}
					};
				}
			};

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
						SearchRequest.class, Map.class);
				sut.setAccessible(true);
				sut.invoke(null, searchRequest,
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.fingerPrintTypeMap);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBKeyedTemplateData(String, byte[])
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBKeyedTemplateDataWith_String_byteArray {
		@DataPoints
		public static ToPBKeyedTemplateDataWith_String_byteArray_Helper.Fixture[] getFixtures() {
			return ToPBKeyedTemplateDataWith_String_byteArray_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasKeyedTemplate(
			ToPBKeyedTemplateDataWith_String_byteArray_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					String.class, byte[].class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.keyedTemplate
					.getKey(), fixture.parameter.keyedTemplate.getBinary());

			// verify
			assertThat(actual.hasKeyedTemplate(), is(true));
		}

		@Theory
		public void testHasReturnTemplateBinary(
			ToPBKeyedTemplateDataWith_String_byteArray_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					String.class, byte[].class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.keyedTemplate
					.getKey(), fixture.parameter.keyedTemplate.getBinary());

			// verify
			assertThat(actual.getKeyedTemplate().getTemplateBinary(), is(fixture.expected
				.getKeyedTemplate().getTemplateBinary()));
		}

		@Theory
		public void testReturnKey(
			ToPBKeyedTemplateDataWith_String_byteArray_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					String.class, byte[].class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.keyedTemplate
					.getKey(), fixture.parameter.keyedTemplate.getBinary());

			// verify
			assertThat(actual.getKeyedTemplate().getKey(), is(fixture.expected
				.getKeyedTemplate().getKey()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasIndexer(
			ToPBKeyedTemplateDataWith_String_byteArray_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBKeyedTemplateDataWith_SearchRequest_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					String.class, byte[].class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.keyedTemplate
					.getKey(), fixture.parameter.keyedTemplate.getBinary());

			// verify
			if (actual.getKeyedTemplate().getKey() == TemplateFormatType.TEMPLATE_LLIX) {
				return;
			}
			assertThat(actual.getKeyedTemplate().hasIndexer(), is(true));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testHasNotIndexer(
			ToPBKeyedTemplateDataWith_String_byteArray_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBKeyedTemplateData",
					String.class, byte[].class);
			sut.setAccessible(true);
			PBKeyedTemplateData actual =
				(PBKeyedTemplateData)sut.invoke(null, fixture.parameter.keyedTemplate
					.getKey(), fixture.parameter.keyedTemplate.getBinary());

			// verify
			if (actual.getKeyedTemplate().getKey() != TemplateFormatType.TEMPLATE_LLIX) {
				return;
			}
			assertThat(actual.getKeyedTemplate().hasIndexer(), is(false));
		}
	}

	/**
	 * test toPBInquiryJobInfo( InquiryFunctionType, CommonOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBInquiryJobInfoWith_toPBInquiryJobInfo_CommonOptions {
		public static ToPBInquiryJobInfo_Help.Fixture fixture = ToPBInquiryJobInfo_Help
			.build();

		@Test
		public void testReturnFunction()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryJobInfo",
					InquiryFunctionType.class, CommonOptions.class);
			sut.setAccessible(true);
			PBInquiryJobInfo actual =
				(PBInquiryJobInfo)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFunction(), is(fixture.expected.getFunction()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnPriority()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryJobInfo",
					InquiryFunctionType.class, CommonOptions.class);
			sut.setAccessible(true);
			PBInquiryJobInfo actual =
				(PBInquiryJobInfo)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getPriority(), is(fixture.expected.getPriority()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMaxCandidate()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryJobInfo",
					InquiryFunctionType.class, CommonOptions.class);
			sut.setAccessible(true);
			PBInquiryJobInfo actual =
				(PBInquiryJobInfo)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getMaxCandidate(), is(fixture.expected.getMaxCandidate()));
		}

		@Test
		public void testReturnCallBackUrl()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryJobInfo",
					InquiryFunctionType.class, CommonOptions.class);
			sut.setAccessible(true);
			PBInquiryJobInfo actual =
				(PBInquiryJobInfo)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getCallBackUrl(), is(fixture.expected.getCallBackUrl()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnDynThreshHitThreshold()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryJobInfo",
					InquiryFunctionType.class, CommonOptions.class);
			sut.setAccessible(true);
			PBInquiryJobInfo actual =
				(PBInquiryJobInfo)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getDynThreshHitThreshold(), is(fixture.expected
				.getDynThreshHitThreshold()));
		}

		@Test
		public void testReturnDynThreshPercentagePoint()
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryJobInfo",
					InquiryFunctionType.class, CommonOptions.class);
			sut.setAccessible(true);
			PBInquiryJobInfo actual =
				(PBInquiryJobInfo)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.commonOptions);

			// verify
			assertThat(new Double(actual.getDynThreshPercentagePoint()), is(closeTo(
				fixture.expected.getDynThreshPercentagePoint(), 0.01)));
		}
	}

	/**
	 * test toPBInquiryFusionWeight(InquiryFunctionType, TemplateFormatType,
	 * List<FusionWeight>, Map<InquiryFunctionType, Integer>, FingerPrintType
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBInquiryFusionWeightWith_InquiryFunctionType_TemplateFormatType_ListOfFusionWeight_Map_FingerPrintType {
		@DataPoints
		public static ToPBInquiryFusionWeight_Helper.Fixture[] getFixtures() {
			return ToPBInquiryFusionWeight_Helper.fixtures;
		}

		@DataPoints
		public static ToPBInquiryFusionWeight_Helper.ExceptionFixture[] getExceptionFixtures() {
			return ToPBInquiryFusionWeight_Helper.exceptionFixtures;
		}

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Theory
		public void testThrowException(
			ToPBInquiryFusionWeight_Helper.ExceptionFixture fixture)
			throws Exception {
			// setup
			expectedException.expect(fixture.expectedClazz);
			expectedException.expectMessage(fixture.expectedMessage);

			ToPBInquiryFusionWeight_Helper.clearIndex();

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBInquiryFusionWeight",
						InquiryFunctionType.class, TemplateFormatType.class, List.class,
						Map.class, FingerPrintType.class);
				sut.setAccessible(true);
				sut.invoke(null, fixture.parameter.function, fixture.parameter.key,
					fixture.parameter.fusionWeightList,
					ToPBInquiryFusionWeight_Helper.inquirySetMap, null);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t.getClass() == fixture.expectedClazz) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}

		@Test
		public void testThrowExceptionOnTli()
			throws Exception {
			// setup
			ToPBInquiryFusionWeight_Helper.ExceptionFixture fixture =
				new ToPBInquiryFusionWeight_Helper.ExceptionFixture(
					new ExceptionParameter() {
						{
							function = InquiryFunctionType.TLI;
							key = TemplateFormatType.TEMPLATE_TLI;
							fusionWeightList = new ArrayList<>();
							fusionWeightList.add(new FusionWeight() {
								{
									value = 1;
									fusionWeightList = new ArrayList<>();
									fusionWeightList.add(new FusionWeight() {
										{
											value = 1;
										}
									});
								}
							});
						}
					}, jp.co.nec.aim.convert.InvalidParameterException.class,
					"An invalid parameter: the number of TLI templates or TLIS templates.");

			expectedException.expect(fixture.expectedClazz);
			expectedException.expectMessage(fixture.expectedMessage);

			ToPBInquiryFusionWeight_Helper.setIndexForExceptionOccurring();

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("toPBInquiryFusionWeight",
						InquiryFunctionType.class, TemplateFormatType.class, List.class,
						Map.class, FingerPrintType.class);
				sut.setAccessible(true);
				sut.invoke(null, fixture.parameter.function, fixture.parameter.key,
					fixture.parameter.fusionWeightList,
					ToPBInquiryFusionWeight_Helper.inquirySetMap, null);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t.getClass() == fixture.expectedClazz) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnInquirySet(ToPBInquiryFusionWeight_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBInquiryFusionWeight_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryFusionWeight",
					InquiryFunctionType.class, TemplateFormatType.class, List.class,
					Map.class, FingerPrintType.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBInquiryFusionWeight> actual =
				(List<PBInquiryFusionWeight>)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.key, fixture.parameter.fusionWeightList,
					ToPBInquiryFusionWeight_Helper.inquirySetMap,
					fixture.parameter.fingerPrintType);

			// verify
			assumeThat(actual.size(), is(0));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getInquirySet(), is(fixture.expected.get(
					index).getInquirySet()));
			}

		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnWeight(ToPBInquiryFusionWeight_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBInquiryFusionWeight_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryFusionWeight",
					InquiryFunctionType.class, TemplateFormatType.class, List.class,
					Map.class, FingerPrintType.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<PBInquiryFusionWeight> actual =
				(List<PBInquiryFusionWeight>)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.key, fixture.parameter.fusionWeightList,
					ToPBInquiryFusionWeight_Helper.inquirySetMap, null);

			// verify
			assumeThat(actual.size(), is(0));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getWeight(), is(fixture.expected.get(index)
					.getWeight()));
			}
		}

		@Theory
		public void testIncrementInquirySetIndex(
			ToPBInquiryFusionWeight_Helper.Fixture fixture)
			throws Exception {
			// setup
			ToPBInquiryFusionWeight_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryFusionWeight",
					InquiryFunctionType.class, TemplateFormatType.class, List.class,
					Map.class, FingerPrintType.class);
			sut.setAccessible(true);
			sut.invoke(null, fixture.parameter.function, fixture.parameter.key,
				fixture.parameter.fusionWeightList,
				ToPBInquiryFusionWeight_Helper.inquirySetMap, null);
			@SuppressWarnings("unchecked")
			List<PBInquiryFusionWeight> actual =
				(List<PBInquiryFusionWeight>)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.key, fixture.parameter.fusionWeightList,
					ToPBInquiryFusionWeight_Helper.inquirySetMap, null);

			// verify
			if (fixture.parameter.key == TemplateFormatType.TEMPLATE_TI
				&& fixture.parameter.key == TemplateFormatType.TEMPLATE_TIM
				&& fixture.parameter.key == TemplateFormatType.TEMPLATE_TLIS
				&& fixture.parameter.key == TemplateFormatType.TEMPLATE_TLIM) {
				for (int index = 0; index < fixture.expected.size(); index++) {
					assertThat(actual.get(index).getInquirySet(),
						is(FingerSetType.PC2_SLAP));
				}
			} else if (fixture.parameter.key == TemplateFormatType.TEMPLATE_TLI) {
				for (int index = 0; index < fixture.expected.size(); index++) {
					assertThat(actual.get(index).getInquirySet(),
						is(FingerSetType.FMP5_SLAP));
				}
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testIncremtentInquirySetIndex_omissionWeight(
			ToPBInquiryFusionWeight_Helper.Fixture fixture)
			throws Exception {
			assumeTrue(fixture.parameter.function == InquiryFunctionType.TI
				|| fixture.parameter.function == InquiryFunctionType.TLI
				|| fixture.parameter.function == InquiryFunctionType.TIM
				|| fixture.parameter.function == InquiryFunctionType.TLIM);

			// setup
			ToPBInquiryFusionWeight_Helper.clearIndex();

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryFusionWeight",
					InquiryFunctionType.class, TemplateFormatType.class, List.class,
					Map.class, FingerPrintType.class);
			sut.setAccessible(true);
			sut.invoke(null, fixture.parameter.function, fixture.parameter.key,
				fixture.parameter.fusionWeightList,
				ToPBInquiryFusionWeight_Helper.inquirySetMap, null);

			// verify
			assertThat(ToPBInquiryFusionWeight_Helper.inquirySetMap
				.get(fixture.parameter.key), is(fixture.expectedInquirySetIndex));
		}
	}

	/**
	 * test toPBInquiryScopeOptions( InquiryFunctionType, List<Integer>)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger {
		@DataPoints
		public static ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper.Fixture[] getFixtures() {
			return ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnScope(
			ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryScopeOptions",
					InquiryFunctionType.class, List.class);
			sut.setAccessible(true);
			PBInquiryScopeOptions actual =
				(PBInquiryScopeOptions)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisCcopeIdList);

			// verify
			assertThat(actual.getScopeCount(), is(not(0)));
			assertThat(actual.getScopeList(), is(fixture.expected.getScopeList()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnTargetFingerPrint(
			ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryScopeOptions",
					InquiryFunctionType.class, List.class);
			sut.setAccessible(true);
			PBInquiryScopeOptions actual =
				(PBInquiryScopeOptions)sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisCcopeIdList);

			// verify
			if (fixture.parameter.function == InquiryFunctionType.LIX) {
				return;
			}
			assertThat(actual.getTargetFingerPrintCount(), is(not(0)));
			assertThat(actual.getTargetFingerPrintList(), is(fixture.expected
				.getTargetFingerPrintList()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testSkipToSetTargetFingerPrint()
			throws Exception {
			// setup
			ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper.Parameter parameter =
				new ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper.Parameter() {
					{
						function = InquiryFunctionType.LIX;
						afisCcopeIdList = new ArrayList<>();
						afisCcopeIdList.add(1341);
					}
				};

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryScopeOptions",
					InquiryFunctionType.class, List.class);
			sut.setAccessible(true);
			PBInquiryScopeOptions actual =
				(PBInquiryScopeOptions)sut.invoke(null, parameter.function,
					parameter.afisCcopeIdList);

			// verify
			assertThat(actual.getTargetFingerPrintCount(), is(0));
		}

	}

	/**
	 * test toPBInquiryJobRequest( List<SearchRequest>, CommonOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	@SuppressWarnings("boxing")
	@RunWith(Theories.class)
	public static class ToPBInquiryJobRequestWith_ListOfSearchRequest_CommonOptions {
		public static ToPBInquiryJobRequestWith_ListOfSearchRequest_CommonOptions_Helper.Fixture fixture =
			ToPBInquiryJobRequestWith_ListOfSearchRequest_CommonOptions_Helper.build("");
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testHasJotbInfo()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.searchRequestList,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.hasJobInfo(), is(true));
		}

		@Test
		public void testHasScope()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.searchRequestList,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInput(0).hasScopes(), is(true));
		}

		@Test
		public void testHasKeyedTemplateData()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.searchRequestList,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInput(0).hasKeyedTemplateData(), is(true));
		}

		@Test
		public void testHasInquiryPayload()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.searchRequestList,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInput(0).getInquiryOptions()
				.hasInquiryPayload(), is(true));
		}

		@Test
		public void testHasFusionWeight()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.searchRequestList,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInput(0).getInquiryOptions()
				.getFusionWeightCount(), is(not(0)));
		}

		@Test
		public void testReturnMinScore()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.searchRequestList,
					fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInput(0).getInquiryOptions().getMinScore(),
				is(fixture.expected.getFusionJobInput(0).getInquiryOptions()
					.getMinScore()));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBInquiryJobRequest(fixture.parameter.searchRequestList,
					fixture.parameter.commonOptions);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}

		@Test
		public void throwInvalidParameterException_IDsOverlap()
			throws Exception {
			// setup
			ToPBInquiryJobRequestWith_ListOfSearchRequest_CommonOptions_Helper.Fixture fixture =
				ToPBInquiryJobRequestWith_ListOfSearchRequest_CommonOptions_Helper
					.build("container IDs overlap");

			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: container IDs overlap.");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBInquiryJobRequest(fixture.parameter.searchRequestList,
					fixture.parameter.commonOptions);
			} catch (InvalidParameterException e) {
				throw new InvalidParameterException(Throwables.getRootCause(e)
					.getMessage());
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test validationContainerIdToFunction( List<Integer>, List<Integer>)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ValidationContainerIdToFunctionWith_ListOfInteger_ListOfInteger {
		@DataPoints
		public static ValidationContaineridOnFunction_Helper.Fixture[] getFixtures() {
			return ValidationContaineridOnFunction_Helper.fixtures;
		}

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Theory
		public void testNoThrowException(
			ValidationContaineridOnFunction_Helper.Fixture fixture)
			throws Exception {
			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod(
						"validationContainerIdToFunction", List.class, List.class);
				sut.setAccessible(true);
				sut.invoke(null, fixture.parameter.searchContainerList,
					fixture.parameter.expectedIdList);
			} catch (InvocationTargetException e) {
				org.junit.Assert.fail();
			}
		}

		@Test
		public void testThrowException_InvalidContainerId()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: there is a invalid container ID.");

			@SuppressWarnings("boxing")
			ValidationContaineridOnFunction_Helper.Parameter parameter = new Parameter() {
				{
					searchContainerList.add(0);
					expectedIdList.add(1);
					expectedIdList.add(2);
				}
			};

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod(
						"validationContainerIdToFunction", List.class, List.class);
				sut.setAccessible(true);
				sut.invoke(null, parameter.searchContainerList, parameter.expectedIdList);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}

		@Test
		public void testThrowException_ThereIsNotAnyContainerId()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: there is not any container ID.");

			ValidationContaineridOnFunction_Helper.Parameter parameter = new Parameter();

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod(
						"validationContainerIdToFunction", List.class, List.class);
				sut.setAccessible(true);
				sut.invoke(null, parameter.searchContainerList, parameter.expectedIdList);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBInquiryScopeOptions(KeyedTemplate)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToPBInquiryScopeOptionsWith_KeyedTemplate {
		@DataPoints
		public static ToPBInquiryScopeOptionsWith_KeyedTemplate_Helper.Fixture[] getFixtures() {
			return ToPBInquiryScopeOptionsWith_KeyedTemplate_Helper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnScope(
			ToPBInquiryScopeOptionsWith_KeyedTemplate_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryScopeOptions",
					KeyedTemplate.class);
			sut.setAccessible(true);
			PBInquiryScopeOptions actual =
				(PBInquiryScopeOptions)sut.invoke(null, fixture.parameter.keyedTemplate);

			// verify
			assertThat(actual.getScopeCount(), is(not(0)));
			assertThat(actual.getScopeList(), is(fixture.expected.getScopeList()));
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnTargetFingerPrint(
			ToPBInquiryScopeOptionsWith_KeyedTemplate_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryScopeOptions",
					KeyedTemplate.class);
			sut.setAccessible(true);
			PBInquiryScopeOptions actual =
				(PBInquiryScopeOptions)sut.invoke(null, fixture.parameter.keyedTemplate);

			// verify
			assertThat(actual.getTargetFingerPrintCount(), is(not(0)));
			assertThat(actual.getTargetFingerPrintList(), is(fixture.expected
				.getTargetFingerPrintList()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasEmpty()
			throws Exception {
			// setup
			KeyedTemplate keyedTemplate = new KeyedTemplate() {
				{
				}
			};

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryScopeOptions",
					KeyedTemplate.class);
			sut.setAccessible(true);
			PBInquiryScopeOptions actual =
				(PBInquiryScopeOptions)sut.invoke(null, keyedTemplate);

			// verify
			assertThat(actual.getScopeCount(), is(0));
			assertThat(actual.getTargetFingerPrintCount(), is(0));
		}
	}

	/**
	 * test validateFunctionToKey( AfisLowLevelFunctionEnumn, AfisTemplateSet)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet {
		@DataPoints
		public static ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet_Helper.Fixture[] getFixtures() {
			return ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet_Helper.fixtures;
		}

		@DataPoints
		public static ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet_Helper.ExceptionFixture[] getExceptionFixtures() {
			return ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet_Helper.exceptionFixtures;
		}

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Theory
		public void testNoThrowException(
			ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet_Helper.Fixture fixture)
			throws Exception {
			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("validateFunctionToKey",
					AfisLowLevelFunctionEnum.class, AfisTemplateSet.class);
			sut.setAccessible(true);
			sut.invoke(null, fixture.parameter.function,
				fixture.parameter.afisTemplateSet);

			// verify
			// Exception was not throwed.
		}

		@Theory
		public void testThrowException(
			ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet_Helper.ExceptionFixture fixture)
			throws Exception {
			// setup
			expectedException.expect(fixture.expectedClazz);
			expectedException.expectMessage(fixture.expectedMessage);

			// exercise
			try {
				Method sut =
					ProtoClassConvert.class.getDeclaredMethod("validateFunctionToKey",
						AfisLowLevelFunctionEnum.class, AfisTemplateSet.class);
				sut.setAccessible(true);
				sut.invoke(null, fixture.parameter.function,
					fixture.parameter.afisTemplateSet);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof InvalidParameterException) {
					throw new InvalidParameterException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toPBInquiryJobRequest( AfisLowLevelFunctionEnum, AfisTemplateSet,
	 * CommonOptions)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBInquiryJobRequestWith_AfisLowLevelFunctionEnum_AfisTemplateSet_CommonOptions {
		public static ToPBInquiryJobRequestWith_AfisLowLevelFunctionEnum_AfisTemplateSet_CommonOptions_Helper.Fixture fixture =
			ToPBInquiryJobRequestWith_AfisLowLevelFunctionEnum_AfisTemplateSet_CommonOptions_Helper
				.build();

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnFunction()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.function,
					fixture.parameter.afisTemplateSet, fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getJobInfo().getFunction(), is(fixture.expected
				.getJobInfo().getFunction()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasJobInfo()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.function,
					fixture.parameter.afisTemplateSet, fixture.parameter.commonOptions);

			// verify
			assertThat(actual.hasJobInfo(), is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFusionJobInput()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.function,
					fixture.parameter.afisTemplateSet, fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInputCount(), is(1));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasScopeInFusionJobInput()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.function,
					fixture.parameter.afisTemplateSet, fixture.parameter.commonOptions);

			// verify
			for (int index = 0; index < fixture.expected.getFusionJobInputCount(); index++) {
				assertThat(actual.getFusionJobInput(index).hasScopes(), is(true));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasKeyedTemplateDataInFusionJobInput()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.function,
					fixture.parameter.afisTemplateSet, fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInputCount(), is(not(0)));
			for (int index = 0; index < fixture.expected.getFusionJobInputCount(); index++) {
				assertThat(actual.getFusionJobInput(index).hasKeyedTemplateData(),
					is(true));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasInquiryPayloadInInquiryOptions()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.function,
					fixture.parameter.afisTemplateSet, fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInputCount(), is(not(0)));
			for (int index = 0; index < fixture.expected.getFusionJobInputCount(); index++) {
				assertThat(actual.getFusionJobInput(index).getInquiryOptions()
					.hasInquiryPayload(), is(true));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasMinScoreInInquiryOptions()
			throws Exception {
			// exercise
			ProtoClassConvert sut = new ProtoClassConvert();
			PBInquiryJobRequest actual =
				sut.toPBInquiryJobRequest(fixture.parameter.function,
					fixture.parameter.afisTemplateSet, fixture.parameter.commonOptions);

			// verify
			assertThat(actual.getFusionJobInputCount(), is(not(0)));
			for (int index = 0; index < fixture.expected.getFusionJobInputCount(); index++) {
				assertThat(actual.getFusionJobInput(index).getInquiryOptions()
					.getMinScore(), is(fixture.expected.getFusionJobInput(index)
					.getInquiryOptions().getMinScore()));
			}
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<ProtoClassConvert> mockUp = new MockUp<ProtoClassConvert>() {
				@Mock
				private <E> E buildClass(Message.Builder builder) {
					throw new NullPointerException("unit test");
				}
			};

			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				ProtoClassConvert sut = new ProtoClassConvert();
				sut.toPBInquiryJobRequest(fixture.parameter.function,
					fixture.parameter.afisTemplateSet, fixture.parameter.commonOptions);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * unmarshalling test
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBInquiryJobRequestWith_String_PBInquiryPayload2Builder {
		@Test
		public void testUnmarshall()
			throws Exception {

			// setup
			PBInquiryPayload.Builder builder = PBInquiryPayload.newBuilder();
			InputStream is =
				getClass().getClassLoader().getResourceAsStream(
					"search_input_payload_1_with_namespace.xml");
			String xml = IOUtils.toString(is, "utf-8");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBInquiryPayload",
					InquiryFunctionType.class, String.class,
					PBInquiryPayload.Builder.class);
			sut.setAccessible(true);
			SearchInputsPayload actual =
				(SearchInputsPayload)sut.invoke(new ProtoClassConvert(),
					InquiryFunctionType.TI, xml, builder);

			assertThat(actual, is(notNullValue()));
		}
	}

	/**
	 * marshalling test
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToXmlWith_SearchInputsPayload {
		@Test
		public void testMarshall()
			throws Exception {

			// setup
			ToPBInquiryPayload_Helper.Fixture fixture =
				ToPBInquiryPayload_Helper.build("", true);

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toXml",
					SearchInputsPayload.class);
			sut.setAccessible(true);
			String actual =
				(String)sut.invoke(new ProtoClassConvert(), fixture.parameter);

			// verify
			assertThat(actual, is(notNullValue()));
		}
	}

	/**
	 * for unit test
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPBExtractInputPayloadWith_String {

		@Before
		public void setup() {
		}

		@Test
		public void testUnmarshall()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream(
					"tenprint-input_in_extraction_inputs_payload.xml");
			String payload = IOUtils.toString(is, "utf-8");

			// exercise
			Method sut =
				ProtoClassConvert.class.getDeclaredMethod("toPBExtractInputPayload",
					String.class);
			sut.setAccessible(true);
			PBExtractInputPayload actual =
				(PBExtractInputPayload)sut.invoke(new ProtoClassConvert(), payload);

			// verify
			assertThat(actual, is(notNullValue()));
		}
	}

	/**
	 * test overlap(List<Integer>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class OverlapWith_ListInteger {
		@SuppressWarnings("boxing")
		@Test
		public void testOverlap()
			throws Exception {
			// setup
			List<Integer> parameter = new ArrayList<>();
			parameter.add(1);
			parameter.add(2);
			parameter.add(331);
			parameter.add(332);
			parameter.add(2);

			// exercise
			Method sut = ProtoClassConvert.class.getDeclaredMethod("overlap", List.class);
			sut.setAccessible(true);
			boolean actual = (boolean)sut.invoke(new ProtoClassConvert(), parameter);

			// verify
			assertThat(actual, is(true));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testNotOverlap()
			throws Exception {
			// setup
			List<Integer> parameter = new ArrayList<>();
			parameter.add(1);
			parameter.add(2);
			parameter.add(331);
			parameter.add(332);
			parameter.add(4);

			// exercise
			Method sut = ProtoClassConvert.class.getDeclaredMethod("overlap", List.class);
			sut.setAccessible(true);
			boolean actual = (boolean)sut.invoke(new ProtoClassConvert(), parameter);

			// verify
			assertThat(actual, is(false));
		}
	}
}
