package jp.co.nec.aim.convert;

import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.SetImageDataWith_PBImageData_FingerOutput_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.SetImageDataWith_PBImageData_PalmOutput_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToCandidateHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToCandidateHelper_MinusScore;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToCandidateTemplateHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToCandidateTemplateHelper_MinusScore;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToCheckResultHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToCheckResultsHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToContainerResultHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToCropInfoHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToDynamicXmlHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToExtOutputHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToExtractJobErrorHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToExtractJobResultHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFace13PointsHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFaceOutputDetectionHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFaceOutputHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFacePointHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFaceRectHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFingerOutputWith_ListOfBExtractTenprintFingerOutputs_ListOfFingerOutputs_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFingerOutputWith_PBExtractLatentFingerOutput_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFisCoreHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFisDataHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFisMinutiaNoHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFisPatternTypeHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFisQualityHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToFusionIndexeHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToHeadRectHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToHistoryHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToImageAnalysisHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper_MinusScore;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper_MinusSearchPosition;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToIrisOutputPoints_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToIrisOutput_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToIrisPoint_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper_MinusScore;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToJobStausHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToLatentOutputHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaDatas_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToMinutiaDataWith_PBMinutiaData_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToPaextDataHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToPalmOutputHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToPointHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToPrefilterOutputWith_ListOfPBPrefilterDataTenprintFingers_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToPsrDataHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToPsrOutputHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToQcOutputWith_PBFingerQualityCheckOutputAdvanced_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToQcOutputWith_PBFingerQualityCheckOutputStandard_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToQcOutputWith_PBFingerQualityCheckOutput_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToQcSequenceHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToQcStatusHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToQrDataWith_PBFingerQrDataOutput_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper_MinusScore;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToSearchJobErrorHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToSearchJobResultHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToSearchOutputsPayloadHelper;
import jp.co.nec.aim.helper.WebServiceClassConvertTestHelper.ToTenprintOutputHelper;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentFingerOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentPalmOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace13Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceImageAnalysis;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceRectPoints;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerCropCoordinate;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPrelsectionDataOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPsrData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQrDataOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutputAdvanced;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutputStandard;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisCore;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisMinutiaNo;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisPatternType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisQuality;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBImageData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBMinutiaData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPaExtData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOutputAdvancedSequence;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateList;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResponse;
import jp.co.nec.aim.mm.jaxb.Candidate;
import jp.co.nec.aim.mm.jaxb.CandidateTemplate;
import jp.co.nec.aim.mm.jaxb.CheckResult;
import jp.co.nec.aim.mm.jaxb.CheckResults;
import jp.co.nec.aim.mm.jaxb.ContainerResult;
import jp.co.nec.aim.mm.jaxb.CropInfo;
import jp.co.nec.aim.mm.jaxb.DynamicXml;
import jp.co.nec.aim.mm.jaxb.ExtOutput;
import jp.co.nec.aim.mm.jaxb.ExtractJobError;
import jp.co.nec.aim.mm.jaxb.ExtractJobResult;
import jp.co.nec.aim.mm.jaxb.Face13Points;
import jp.co.nec.aim.mm.jaxb.FaceOutput;
import jp.co.nec.aim.mm.jaxb.FaceOutputDetection;
import jp.co.nec.aim.mm.jaxb.FacePoint;
import jp.co.nec.aim.mm.jaxb.FaceRect;
import jp.co.nec.aim.mm.jaxb.FingerOutput;
import jp.co.nec.aim.mm.jaxb.FisData;
import jp.co.nec.aim.mm.jaxb.FusionIndexer;
import jp.co.nec.aim.mm.jaxb.HeadRect;
import jp.co.nec.aim.mm.jaxb.ImageAnalysis;
import jp.co.nec.aim.mm.jaxb.IndividualScore;
import jp.co.nec.aim.mm.jaxb.IrisOutput;
import jp.co.nec.aim.mm.jaxb.IrisOutputPoints;
import jp.co.nec.aim.mm.jaxb.IrisPoint;
import jp.co.nec.aim.mm.jaxb.IrisScore;
import jp.co.nec.aim.mm.jaxb.JobStatus;
import jp.co.nec.aim.mm.jaxb.KeyedBinary;
import jp.co.nec.aim.mm.jaxb.LatentOutput;
import jp.co.nec.aim.mm.jaxb.MinutiaData;
import jp.co.nec.aim.mm.jaxb.PaextData;
import jp.co.nec.aim.mm.jaxb.PalmOutput;
import jp.co.nec.aim.mm.jaxb.Point;
import jp.co.nec.aim.mm.jaxb.PrefilterOutput;
import jp.co.nec.aim.mm.jaxb.PsrData;
import jp.co.nec.aim.mm.jaxb.PsrOutput;
import jp.co.nec.aim.mm.jaxb.QcOutput;
import jp.co.nec.aim.mm.jaxb.QcSequence;
import jp.co.nec.aim.mm.jaxb.QcStatus;
import jp.co.nec.aim.mm.jaxb.QrOutput;
import jp.co.nec.aim.mm.jaxb.RawScore;
import jp.co.nec.aim.mm.jaxb.SearchJobError;
import jp.co.nec.aim.mm.jaxb.SearchJobResult;
import jp.co.nec.aim.mm.jaxb.SearchOutputsPayload;
import jp.co.nec.aim.mm.jaxb.TenprintOutput;
import mockit.Mock;
import mockit.MockUp;

import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import com.google.common.base.Throwables;

@RunWith(Enclosed.class)
public class WebServiceClassConvertTest {
	/**
	 * test throwInvalidParameterException method
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ThrowInvalidParameterException {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnSettingMessage()
			throws Exception {
			expectedException.expect(InvalidParameterException.class);
			expectedException.expectMessage("An invalid parameter: test.");

			try {
				Method sut =
					WebServiceClassConvert.class.getDeclaredMethod(
						"throwInvalidParameterException", String.class);
				sut.setAccessible(true);
				sut.invoke(null, "test.");
			} catch (InvocationTargetException e) {
				throw new InvalidParameterException(Throwables.getRootCause(e)
					.getMessage());
			}
		}
	}

	/**
	 * test toFacePoint(PBPoint pbPoint)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFacePointWith_PBPoint {
		public static ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(1, 2);

		@Test
		public void testReturnX()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFacePoint",
					PBPoint.class);
			sut.setAccessible(true);
			FacePoint actual = (FacePoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getX(), is(fixture.expected.getX()));
		}

		@Test
		public void testReturnY()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFacePoint",
					PBPoint.class);
			sut.setAccessible(true);
			FacePoint actual = (FacePoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getY(), is(fixture.expected.getY()));
		}
	}

	/**
	 * test toImageAnalysis(PBFaceImageAnalysis pbImageAnalysis)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToImageAnalysisWith_PBFaceImageAnalysis {
		public static ToImageAnalysisHelper.Fixture fixture = ToImageAnalysisHelper
			.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnImageSize()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getImageSize().getValue(), is(closeTo(fixture.expected
				.getImageSize().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnWidthHeightRatio()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getWidthHeightRatio().getValue(), is(closeTo(
				fixture.expected.getWidthHeightRatio().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEyeDistance()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getEyeDistance().getValue(), is(closeTo(fixture.expected
				.getEyeDistance().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEyeWidth()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getEyeWidth().getValue(), is(closeTo(fixture.expected
				.getEyeWidth().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnColorProfile()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getColorProfile().getValue(), is(closeTo(fixture.expected
				.getColorProfile().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeadRotationHorizontal()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getHeadRotationHorizontal().getValue(), is(closeTo(
				fixture.expected.getHeadRotationHorizontal().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeadRotationVertical()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getHeadRotationVertical().getValue(), is(closeTo(
				fixture.expected.getHeadRotationVertical().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeadPositionHorizontal()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getHeadPositionHorizontal().getValue(), is(closeTo(
				fixture.expected.getHeadPositionHorizontal().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeadPositionVertical()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getHeadPositionVertical().getValue(), is(closeTo(
				fixture.expected.getHeadPositionVertical().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeadWidth()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getHeadWidth().getValue(), is(closeTo(fixture.expected
				.getHeadWidth().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHeadLength()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getHeadLength().getValue(), is(closeTo(fixture.expected
				.getHeadLength().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnColorBrightness()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getColorBrightness().getValue(), is(closeTo(
				fixture.expected.getColorBrightness().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnColorContrast()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getColorContrast().getValue(), is(closeTo(fixture.expected
				.getColorContrast().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnColorCast()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getColorCast().getValue(), is(closeTo(fixture.expected
				.getColorCast().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnBlockyArtifacts()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getBlockyArtifacts().getValue(), is(closeTo(
				fixture.expected.getBlockyArtifacts().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnImageSharpness()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getImageSharpness().getValue(), is(closeTo(fixture.expected
				.getImageSharpness().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnRedEyes()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRedEyes().getValue(), is(closeTo(fixture.expected
				.getRedEyes().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFaceShadow()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFaceShadow().getValue(), is(closeTo(fixture.expected
				.getFaceShadow().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnInterferingBackground()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getInterferingBackground().getValue(), is(closeTo(
				fixture.expected.getInterferingBackground().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnGreyValueBackground()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getGreyValueBackground().getValue(), is(closeTo(
				fixture.expected.getGreyValueBackground().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnColorVariationBackground()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getColorVariationBackground().getValue(), is(closeTo(
				fixture.expected.getColorVariationBackground().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnGlassesCoverageSunglasses()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getGlassesCoverageSunglasses().getValue(), is(closeTo(
				fixture.expected.getGlassesCoverageSunglasses().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnGlassesCoverageReflection()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getGlassesCoverageReflection().getValue(), is(closeTo(
				fixture.expected.getGlassesCoverageReflection().getValue(), 0.01)));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnGlassesCoverageHeavyFrame()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toImageAnalysis",
					PBFaceImageAnalysis.class);
			sut.setAccessible(true);
			ImageAnalysis actual = (ImageAnalysis)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getGlassesCoverageHeavyFrame().getValue(), is(closeTo(
				fixture.expected.getGlassesCoverageHeavyFrame().getValue(), 0.01)));
		}
	}

	/**
	 * 
	 * test toHeadRect(PBFaceRectPoints pbRect)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToHeadRectWith_PBFaceRectPoints {
		public static ToHeadRectHelper.Fixture fixture = ToHeadRectHelper.build();

		@Test
		public void testReturnUpperLeft()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toHeadRect",
					PBFaceRectPoints.class);
			sut.setAccessible(true);
			HeadRect actual = (HeadRect)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getUpperLeft().getX(), is(fixture.expected.getUpperLeft()
				.getX()));
			assertThat(actual.getUpperLeft().getY(), is(fixture.expected.getUpperLeft()
				.getY()));
		}

		@Test
		public void testReturnUpperRight()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toHeadRect",
					PBFaceRectPoints.class);
			sut.setAccessible(true);
			HeadRect actual = (HeadRect)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getUpperRight().getX(), is(fixture.expected.getUpperRight()
				.getX()));
			assertThat(actual.getUpperRight().getY(), is(fixture.expected.getUpperRight()
				.getY()));
		}

		@Test
		public void testReturnLowerLeft()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toHeadRect",
					PBFaceRectPoints.class);
			sut.setAccessible(true);
			HeadRect actual = (HeadRect)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLowerLeft().getX(), is(fixture.expected.getLowerLeft()
				.getX()));
			assertThat(actual.getLowerLeft().getY(), is(fixture.expected.getLowerLeft()
				.getY()));
		}

		@Test
		public void testReturnLowerRight()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toHeadRect",
					PBFaceRectPoints.class);
			sut.setAccessible(true);
			HeadRect actual = (HeadRect)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLowerRight().getX(), is(fixture.expected.getLowerRight()
				.getX()));
			assertThat(actual.getLowerRight().getY(), is(fixture.expected.getLowerRight()
				.getY()));
		}
	}

	/**
	 * test toFaceRect(PBFaceRectPoints pbRect)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFaceRectWith_PBFaceRectPoints {
		public static ToFaceRectHelper.Fixture fixture = ToFaceRectHelper.build();

		@Test
		public void testReturnUpperLeft()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceRect",
					PBFaceRectPoints.class);
			sut.setAccessible(true);
			FaceRect actual = (FaceRect)sut.invoke(null, fixture.parameter);
			
			// verify
			assertThat(actual.getUpperLeft().getX(), is(fixture.expected.getUpperLeft()
				.getX()));
			assertThat(actual.getUpperLeft().getY(), is(fixture.expected.getUpperLeft()
				.getY()));
		}

		@Test
		public void testReturnUpperRight()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceRect",
					PBFaceRectPoints.class);
			sut.setAccessible(true);
			FaceRect actual = (FaceRect)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getUpperRight().getX(), is(fixture.expected.getUpperRight()
				.getX()));
			assertThat(actual.getUpperRight().getY(), is(fixture.expected.getUpperRight()
				.getY()));
		}

		@Test
		public void testReturnLowerLeft()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceRect",
					PBFaceRectPoints.class);
			sut.setAccessible(true);
			FaceRect actual = (FaceRect)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLowerLeft().getX(), is(fixture.expected.getLowerLeft()
				.getX()));
			assertThat(actual.getLowerLeft().getY(), is(fixture.expected.getLowerLeft()
				.getY()));
		}

		@Test
		public void testReturnLowerRight()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceRect",
					PBFaceRectPoints.class);
			sut.setAccessible(true);
			FaceRect actual = (FaceRect)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLowerRight().getX(), is(fixture.expected.getLowerRight()
				.getX()));
			assertThat(actual.getLowerRight().getY(), is(fixture.expected.getLowerRight()
				.getY()));
		}
	}

	/**
	 * test toFace13Points(PBFace13Points pbFace13Points)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFace13PointsWith_PBFace13Points {
		public static ToFace13PointsHelper.Fixture fixture = ToFace13PointsHelper.build();

		@Test
		public void testReturnRightEyeCenter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightEyeCenter().getX(), is(fixture.expected
				.getRightEyeCenter().getX()));
			assertThat(actual.getRightEyeCenter().getY(), is(fixture.expected
				.getRightEyeCenter().getY()));
		}

		@Test
		public void testReturnLeftEyeCenter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftEyeCenter().getX(), is(fixture.expected
				.getLeftEyeCenter().getX()));
			assertThat(actual.getLeftEyeCenter().getY(), is(fixture.expected
				.getLeftEyeCenter().getY()));
		}

		@Test
		public void testReturnRightEyeInnerCorner()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightEyeInnerCorner().getX(), is(fixture.expected
				.getRightEyeInnerCorner().getX()));
			assertThat(actual.getRightEyeInnerCorner().getY(), is(fixture.expected
				.getRightEyeInnerCorner().getY()));
		}

		@Test
		public void testReturnLeftEyeInnerCorner()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftEyeInnerCorner().getX(), is(fixture.expected
				.getLeftEyeInnerCorner().getX()));
			assertThat(actual.getLeftEyeInnerCorner().getY(), is(fixture.expected
				.getLeftEyeInnerCorner().getY()));
		}

		@Test
		public void testReturnRightEyeOuterCorner()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightEyeOuterCorner().getX(), is(fixture.expected
				.getRightEyeOuterCorner().getX()));
			assertThat(actual.getRightEyeOuterCorner().getY(), is(fixture.expected
				.getRightEyeOuterCorner().getY()));
		}

		@Test
		public void testReturnLeftEyeOuterCorner()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftEyeOuterCorner().getX(), is(fixture.expected
				.getLeftEyeOuterCorner().getX()));
			assertThat(actual.getLeftEyeOuterCorner().getY(), is(fixture.expected
				.getLeftEyeOuterCorner().getY()));
		}

		@Test
		public void testReturnCenterBelowNose()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCenterBelowNose().getX(), is(fixture.expected
				.getCenterBelowNose().getX()));
			assertThat(actual.getCenterBelowNose().getY(), is(fixture.expected
				.getCenterBelowNose().getY()));
		}

		@Test
		public void testReturnRightSideNose()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightSideNose().getX(), is(fixture.expected
				.getRightSideNose().getX()));
			assertThat(actual.getRightSideNose().getY(), is(fixture.expected
				.getRightSideNose().getY()));
		}

		@Test
		public void testReturnLeftSideNose()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftSideNose().getX(), is(fixture.expected
				.getLeftSideNose().getX()));
			assertThat(actual.getLeftSideNose().getY(), is(fixture.expected
				.getLeftSideNose().getY()));
		}

		@Test
		public void testReturnRightCornerMouth()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRightCornerMouth().getX(), is(fixture.expected
				.getRightCornerMouth().getX()));
			assertThat(actual.getRightCornerMouth().getY(), is(fixture.expected
				.getRightCornerMouth().getY()));
		}

		@Test
		public void testReturnLeftCornerMouth()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLeftCornerMouth().getX(), is(fixture.expected
				.getLeftCornerMouth().getX()));
			assertThat(actual.getLeftCornerMouth().getY(), is(fixture.expected
				.getLeftCornerMouth().getY()));
		}

		@Test
		public void testReturnTopCenterUpperLip()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTopCenterUpperLip().getX(), is(fixture.expected
				.getTopCenterUpperLip().getX()));
			assertThat(actual.getTopCenterUpperLip().getY(), is(fixture.expected
				.getTopCenterUpperLip().getY()));
		}

		@Test
		public void testReturnBottomCenterUpperLip()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFace13Points",
					PBFace13Points.class);
			sut.setAccessible(true);
			Face13Points actual = (Face13Points)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getBottomCenterUpperLip().getX(), is(fixture.expected
				.getBottomCenterUpperLip().getX()));
			assertThat(actual.getBottomCenterUpperLip().getY(), is(fixture.expected
				.getBottomCenterUpperLip().getY()));
		}
	}

	/**
	 * test toFaceOutputDetection(List<PBExtractFaceDetectionOutput>
	 * pbDetectionOutputList)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFaceOutputDetectionWith_ListOfPBExtractFaceDetectionOutputs {
		public static ToFaceOutputDetectionHelper.Fixture fixture =
			ToFaceOutputDetectionHelper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnDetectedFaces()
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDetectedFaces(), is(fixture.expected.getDetectedFaces()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPoints()
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPoints().size(), is(not(0)));
			assertThat(actual.getPoints().size(), is(fixture.expected.getPoints().size()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFace13Points()
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPoints().size(), is(not(0)));
			assertThat(actual.getPoints().size(), is(fixture.expected.getPoints().size()));
			for (int index = 0; index < fixture.expected.getPoints().size(); index++) {
				assertThat(actual.getPoints().get(index).getBase(), is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFaceRect()
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPoints().size(), is(not(0)));
			assertThat(actual.getPoints().size(), is(fixture.expected.getPoints().size()));
			for (int index = 0; index < fixture.expected.getPoints().size(); index++) {
				assertThat(actual.getPoints().get(index).getFaceRect(),
					is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasHeadRect()
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPoints().size(), is(not(0)));
			assertThat(actual.getPoints().size(), is(fixture.expected.getPoints().size()));
			for (int index = 0; index < fixture.expected.getPoints().size(); index++) {
				assertThat(actual.getPoints().get(index).getHeadRect(),
					is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasImageAnalysis()
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPoints().size(), is(not(0)));
			assertThat(actual.getPoints().size(), is(fixture.expected.getPoints().size()));
			for (int index = 0; index < fixture.expected.getPoints().size(); index++) {
				assertThat(actual.getPoints().get(index).getImageAnalysis(),
					is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFaceNumber()
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPoints().size(), is(not(0)));
			for (int index = 0; index < fixture.expected.getPoints().size(); index++) {
				assertThat(actual.getPoints().get(index).getNum(), is(fixture.expected
					.getPoints().get(index).getNum()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnDetectionScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPoints().size(), is(not(0)));
			for (int index = 0; index < fixture.expected.getPoints().size(); index++) {
				assertThat(Double.valueOf(actual.getPoints().get(index)
					.getDetectionScore()), is(closeTo(fixture.expected.getPoints().get(
					index).getDetectionScore(), 0.01)));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnPossibilityNegativeDetection()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutputDetection",
					List.class);
			sut.setAccessible(true);
			FaceOutputDetection actual =
				(FaceOutputDetection)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPoints().size(), is(not(0)));
			for (int index = 0; index < fixture.expected.getPoints().size(); index++) {
				assertThat(actual.getPoints().get(index).isPossiblityNegativeDetection(),
					is(fixture.expected.getPoints().get(index)
						.isPossiblityNegativeDetection()));
			}
		}
	}

	/**
	 * test toFaceOutput(PBExtractFaceOutput pbExtractFaceOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFaceOutputWith_PBExtractFaceOutput {
		public static ToFaceOutputHelper.Fixture fixture = ToFaceOutputHelper.build();

		@Test
		public void testHasFaceOutputDetection()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFaceOutput",
					PBExtractFaceOutput.class);
			sut.setAccessible(true);
			FaceOutput actual = (FaceOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDetection(), is(notNullValue()));
		}
	}

	/**
	 * test toPalmOutput(PBExtractLatentPalmOutput pbPalmOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPaextDataWith_PBPaExtData {
		public static ToPaextDataHelper.Fixture fixture = ToPaextDataHelper.build();

		@Test
		public void testReturnMinutiaData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPaextData",
					PBPaExtData.class);
			sut.setAccessible(true);
			PaextData actual = (PaextData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutiaData(), is(fixture.expected.getMinutiaData()));
		}

		@Test
		public void testReturnSkeleton()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPaextData",
					PBPaExtData.class);
			sut.setAccessible(true);
			PaextData actual = (PaextData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSkeleton(), is(fixture.expected.getSkeleton()));
		}
	}

	/**
	 * test toPrefilterOutput(List<PBPrefilterData> pbPrefilterList,
	 * PrefilterOutput prefilterOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput {
		public static ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper.Fixture fixture =
			ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper.build();

		@Test
		public void testReturnLdbPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLdbPrefilter(), is(fixture.expected.getLdbPrefilter()));
		}

		@Test
		public void testReturnLiPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLiPrefilter(), is(fixture.expected.getLiPrefilter()));
		}

		@Test
		public void testReturnLliPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLliPrefilter(), is(fixture.expected.getLliPrefilter()));
		}

		@Test
		public void testReturnPdbPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getPdbPrefilter(), is(fixture.expected.getPdbPrefilter()));
		}

		@Test
		public void testReturnPldbPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getPldbPrefilter(), is(fixture.expected.getPldbPrefilter()));
		}

		@Test
		public void testReturnLipPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLipPrefilter(), is(fixture.expected.getLipPrefilter()));
		}

		@Test
		public void testReturnTlipPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getTlipPrefilter(), is(fixture.expected.getTlipPrefilter()));
		}

		@Test
		public void testReturnLlipPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLlipPrefilter(), is(fixture.expected.getLlipPrefilter()));
		}

		@Test
		public void testReturnLimPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLimPrefilter(), is(fixture.expected.getLimPrefilter()));
		}

		@Test
		public void testReturnTlimPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getTlimPrefilter(), is(fixture.expected.getTlimPrefilter()));
		}

		@Test
		public void testReturnLlimPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLlimPrefilter(), is(fixture.expected.getLlimPrefilter()));
		}

		@Test
		public void testReturnLdbmPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLdbmPrefilter(), is(fixture.expected.getLdbmPrefilter()));
		}

		@Test
		public void testReturnTlixPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getTlixPrefilter(), is(fixture.expected.getTlixPrefilter()));
		}

		@Test
		public void testReturnXdblPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getXdblPrefilter(), is(fixture.expected.getXdblPrefilter()));
		}

		@Test
		public void testReturnLixPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLixPrefilter(), is(fixture.expected.getLixPrefilter()));
		}

		@Test
		public void testReturnLlixPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLlixPrefilter(), is(fixture.expected.getLlixPrefilter()));
		}

		@Test
		public void testReturnLdbxPrefilter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class, PrefilterOutput.class);
			sut.setAccessible(true);
			PrefilterOutput actual = new PrefilterOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLdbxPrefilter(), is(fixture.expected.getLdbxPrefilter()));
		}
	}

	/**
	 * test toMinutiaData(PBMinutiaData pbMinutiaData)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToMinutiaDataWith_PBMinutiaData {
		public static ToMinutiaDataWith_PBMinutiaData_Helper.Fixture fixture =
			ToMinutiaDataWith_PBMinutiaData_Helper.build();

		@Test
		public void testReturnBinary()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					PBMinutiaData.class);
			sut.setAccessible(true);
			MinutiaData actual = (MinutiaData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getBinary(), is(fixture.expected.getBinary()));
		}

		@Test
		public void testReturnMinutiaType()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					PBMinutiaData.class);
			sut.setAccessible(true);
			MinutiaData actual = (MinutiaData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutiaType(), is(fixture.expected.getMinutiaType()));
		}

		@Test
		public void testReturnFisType()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					PBMinutiaData.class);
			sut.setAccessible(true);
			MinutiaData actual = (MinutiaData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFisType(), is(fixture.expected.getFisType()));
		}

		@Test
		public void testReturnMinutiaCount()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					PBMinutiaData.class);
			sut.setAccessible(true);
			MinutiaData actual = (MinutiaData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutiaCount(), is(fixture.expected.getMinutiaCount()));
		}
	}

	/**
	 * test toPalmOutput(PBExtractLatentPalmOutput pbPalmOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPalmOutputWith_PBExtractLatentPalmOutput {
		public static ToPalmOutputHelper.Fixture fixture = ToPalmOutputHelper
			.buildForLatent();

		@Test
		public void testHasMinutiaData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPalmOutput",
					PBExtractLatentPalmOutput.class);
			sut.setAccessible(true);
			PalmOutput actual = (PalmOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutiaData(), is(notNullValue()));
		}

		@Test
		public void testHasPrefilterOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPalmOutput",
					PBExtractLatentPalmOutput.class);
			sut.setAccessible(true);
			PalmOutput actual = (PalmOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPrefilterOutput(), is(notNullValue()));
		}

		@Test
		public void testHasPaextData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPalmOutput",
					PBExtractLatentPalmOutput.class);
			sut.setAccessible(true);
			PalmOutput actual = (PalmOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPaextData(), is(notNullValue()));
		}

	}

	/**
	 * test toFisPatternType( PBFisPatternType pbFisPatternType)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFisPatternTypeWith_PBFisPatternType {
		public static ToFisPatternTypeHelper.Fixture fixture = ToFisPatternTypeHelper
			.build();

		@Test
		public void testReturnType1()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisPatternType",
					PBFisPatternType.class);
			sut.setAccessible(true);
			FisData.FisPatternType actual =
				(FisData.FisPatternType)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTYPE1(), is(fixture.expected.getTYPE1()));
		}

		@Test
		public void testReturnRfu1()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisPatternType",
					PBFisPatternType.class);
			sut.setAccessible(true);
			FisData.FisPatternType actual =
				(FisData.FisPatternType)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRFU1(), is(fixture.expected.getRFU1()));
		}

		@Test
		public void testReturnType2()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisPatternType",
					PBFisPatternType.class);
			sut.setAccessible(true);
			FisData.FisPatternType actual =
				(FisData.FisPatternType)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTYPE2(), is(fixture.expected.getTYPE2()));
		}

		@Test
		public void testReturnRfu2()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisPatternType",
					PBFisPatternType.class);
			sut.setAccessible(true);
			FisData.FisPatternType actual =
				(FisData.FisPatternType)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRFU2(), is(fixture.expected.getRFU2()));
		}
	}

	/**
	 * test toFisMinutiaNo(PBFisMinutiaNo pbFisMinutiaNo)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFisMinutiaNoWith_PBFisMinutiaNo {
		public static ToFisMinutiaNoHelper.Fixture fixture = ToFisMinutiaNoHelper.build();

		@Test
		public void testReturnDB()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisMinutiaNo",
					PBFisMinutiaNo.class);
			sut.setAccessible(true);
			FisData.FisMinutiaNo actual =
				(FisData.FisMinutiaNo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDB(), is(fixture.expected.getDB()));
		}

		@Test
		public void testReturnMB()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisMinutiaNo",
					PBFisMinutiaNo.class);
			sut.setAccessible(true);
			FisData.FisMinutiaNo actual =
				(FisData.FisMinutiaNo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMB(), is(fixture.expected.getMB()));
		}

	}

	/**
	 * test toFisQuality(PBFisQuality pbFisQuality)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFisQualityWith_PBFisQuality {
		public static ToFisQualityHelper.Fixture fixture = ToFisQualityHelper.build();

		@Test
		public void testReturnVA()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisQuality",
					PBFisQuality.class);
			sut.setAccessible(true);
			FisData.FisQuality actual =
				(FisData.FisQuality)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getVA(), is(fixture.expected.getVA()));
		}

		@Test
		public void testReturnVB()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisQuality",
					PBFisQuality.class);
			sut.setAccessible(true);
			FisData.FisQuality actual =
				(FisData.FisQuality)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getVB(), is(fixture.expected.getVB()));
		}

		@Test
		public void testReturnVC()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisQuality",
					PBFisQuality.class);
			sut.setAccessible(true);
			FisData.FisQuality actual =
				(FisData.FisQuality)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getVC(), is(fixture.expected.getVC()));
		}

		@Test
		public void testReturnS()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisQuality",
					PBFisQuality.class);
			sut.setAccessible(true);
			FisData.FisQuality actual =
				(FisData.FisQuality)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getS(), is(fixture.expected.getS()));
		}

	}

	/**
	 * test toFisCore(PBFisCore pbFisCore)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFisCoreWith_PBFisCore {
		public static ToFisCoreHelper.Fixture fixture = ToFisCoreHelper.build();

		@Test
		public void testReturnA()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getA(), is(fixture.expected.getA()));
		}

		@Test
		public void testReturnF()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getF(), is(fixture.expected.getF()));
		}

		@Test
		public void testReturnCC()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCC(), is(fixture.expected.getCC()));
		}

		@Test
		public void testReturnQP()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQP(), is(fixture.expected.getQP()));
		}

		@Test
		public void testReturnQD()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQD(), is(fixture.expected.getQD()));
		}

		@Test
		public void testReturnQQ()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQQ(), is(fixture.expected.getQQ()));
		}

		@Test
		public void testReturnX()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getX(), is(fixture.expected.getX()));
		}

		@Test
		public void testReturnY()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getY(), is(fixture.expected.getY()));
		}

		@Test
		public void testReturnD()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisCore",
					PBFisCore.class);
			sut.setAccessible(true);
			FisData.FisCore actual = (FisData.FisCore)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getD(), is(fixture.expected.getD()));
		}

	}

	/**
	 * test toFisData(List<PBFisData> pbFisDataList, List<FisData> fisDataList)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFisDataWith_ListOfPBFisDatas_ListOfFisDatas {
		public static ToFisDataHelper.Fixture fixture = ToFisDataHelper.build();

		@Test
		public void testHasFisCore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getFisCore(), is(notNullValue()));
			}
		}

		@Test
		public void testHasFisQuality()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getFisQuality(), is(notNullValue()));
			}
		}

		@Test
		public void testHasFisMinutiaNo()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getFisMinutiaNo(), is(notNullValue()));
			}
		}

		@Test
		public void testHasFisPatternType()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getFisPatternType(), is(notNullValue()));
			}
		}

		@Test
		public void testReturnMinutiaData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getMinutiaData(), is(fixture.expected
					.get(index).getMinutiaData()));
			}
		}

		@Test
		public void testReturnZone()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getZone(), is(fixture.expected
					.get(index).getZone()));
			}
		}

		@Test
		public void testReturnSkeleton()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getSkeleton(), is(fixture.expected.get(
					index).getSkeleton()));
			}
		}

		@Test
		public void testReturnFisType()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getFisType(), is(fixture.expected.get(
					index).getFisType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFusionIndexer()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFisData", List.class,
					List.class);
			sut.setAccessible(true);
			List<FisData> actualList = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actualList);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actualList.get(index).getFusionIndexer().size(), is(not(0)));
				assertThat(actualList.get(index).getFusionIndexer().size(),
					is(fixture.expected.get(index).getFusionIndexer().size()));
			}
		}
	}

	/**
	 * test toFingerOutput( PBExtractLatentFingerOutput pbLatentFingerOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFingerOutputWith_PBExtractLatentFingerOutput {
		public static ToFingerOutputWith_PBExtractLatentFingerOutput_Helper.Fixture fixture =
			ToFingerOutputWith_PBExtractLatentFingerOutput_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasMinutiaData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					PBExtractLatentFingerOutput.class);
			sut.setAccessible(true);
			FingerOutput actual = (FingerOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMinutiaData().size(), is(not(0)));
			assertThat(actual.getMinutiaData().size(), is(fixture.expected
				.getMinutiaData().size()));
		}

		@Test
		public void testHasPrefilterOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					PBExtractLatentFingerOutput.class);
			sut.setAccessible(true);
			FingerOutput actual = (FingerOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPrefilterOutput(), is(notNullValue()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFisData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					PBExtractLatentFingerOutput.class);
			sut.setAccessible(true);
			FingerOutput actual = (FingerOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFisData().size(), is(not(0)));
			assertThat(actual.getFisData().size(), is(fixture.expected.getFisData()
				.size()));
		}
	}

	/**
	 * test toLatentOutput(PBExtractLatentOutput pbLatentOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToLatentOutputWith_PBExtractLatentOutput {
		@Test
		public void testHasFingerOutput()
			throws Exception {
			// setup
			ToLatentOutputHelper.Fixture fixture = ToLatentOutputHelper.build("finger");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toLatentOutput",
					PBExtractLatentOutput.class);
			sut.setAccessible(true);
			LatentOutput actual = (LatentOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFingerOutput(), is(notNullValue()));
		}

		@Test
		public void testHasPalmOutput()
			throws Exception {
			// setup
			ToLatentOutputHelper.Fixture fixture = ToLatentOutputHelper.build("palm");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toLatentOutput",
					PBExtractLatentOutput.class);
			sut.setAccessible(true);
			LatentOutput actual = (LatentOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPalmOutput(), is(notNullValue()));
		}

		@Test
		public void testHaveAllOutput()
			throws Exception {
			// setup
			ToLatentOutputHelper.Fixture fixture = ToLatentOutputHelper.build("all");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toLatentOutput",
					PBExtractLatentOutput.class);
			sut.setAccessible(true);
			LatentOutput actual = (LatentOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFingerOutput(), is(notNullValue()));
			assertThat(actual.getPalmOutput(), is(notNullValue()));
		}

		@Test
		public void testHasNotFingerOutput()
			throws Exception {
			// setup
			ToLatentOutputHelper.Fixture fixture = ToLatentOutputHelper.build("palm");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toLatentOutput",
					PBExtractLatentOutput.class);
			sut.setAccessible(true);
			LatentOutput actual = (LatentOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFingerOutput(), is(nullValue()));
		}

		@Test
		public void testHasNotPalmOutput()
			throws Exception {
			// setup
			ToLatentOutputHelper.Fixture fixture = ToLatentOutputHelper.build("finger");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toLatentOutput",
					PBExtractLatentOutput.class);
			sut.setAccessible(true);
			LatentOutput actual = (LatentOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPalmOutput(), is(nullValue()));
		}
	}

	/**
	 * test setImageData(PBImageData , FingerOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class SetImageDataWith_PBImageData_FingerOutput {
		public static SetImageDataWith_PBImageData_FingerOutput_Helper.Fixture fixture =
			SetImageDataWith_PBImageData_FingerOutput_Helper.build();

		@Test
		public void testReturnCroppedImage()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("setImageData",
					PBImageData.class, FingerOutput.class);
			sut.setAccessible(true);
			FingerOutput actual = new FingerOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getCroppedImage(), is(fixture.expected.getCroppedImage()));
		}

		@Test
		public void testReturnLowResImage()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("setImageData",
					PBImageData.class, FingerOutput.class);
			sut.setAccessible(true);
			FingerOutput actual = new FingerOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLowResImage(), is(fixture.expected.getLowResImage()));
		}
	}

	/**
	 * test setImageData(PBImageData , PalmOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class SetImageDataWith_PBImageData_PalmOutput {
		public static SetImageDataWith_PBImageData_PalmOutput_Helper.Fixture fixture =
			SetImageDataWith_PBImageData_PalmOutput_Helper.build();

		@Test
		public void testReturnLowResImage()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("setImageData",
					PBImageData.class, PalmOutput.class);
			sut.setAccessible(true);
			PalmOutput actual = new PalmOutput();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.getLowResImage(), is(fixture.expected.getLowResImage()));
		}
	}

	/**
	 * test toPrefilterOutput( List<PBPrefilterDataTenprintFinger>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPrefilterOutputWith_ListOfPBPrefilterDataTenprintFinger {
		public static ToPrefilterOutputWith_ListOfPBPrefilterDataTenprintFingers_Helper.Fixture fixture =
			ToPrefilterOutputWith_ListOfPBPrefilterDataTenprintFingers_Helper.build();

		@Test
		public void testReturnRolledPrefilterOfRdbl()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRdblPrefilter().getRollPrefilter(), is(fixture.expected
				.getRdblPrefilter().getRollPrefilter()));
		}

		@Test
		public void testReturnSlapPrefilterOfRdbl()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRdblPrefilter().getSlapPrefilter(), is(fixture.expected
				.getRdblPrefilter().getSlapPrefilter()));
		}

		@Test
		public void testReturnRolledPrefilterOfTli()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTliPrefilter().getRollPrefilter(), is(fixture.expected
				.getTliPrefilter().getRollPrefilter()));
		}

		@Test
		public void testReturnSlapPrefilterOfTli()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTliPrefilter().getSlapPrefilter(), is(fixture.expected
				.getTliPrefilter().getSlapPrefilter()));
		}

		@Test
		public void testReturnRolledPrefilterOfRdblm()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRdblmPrefilter().getRollPrefilter(), is(fixture.expected
				.getRdblmPrefilter().getRollPrefilter()));
		}

		@Test
		public void testReturnSlapPrefilterOfRdblm()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRdblmPrefilter().getSlapPrefilter(), is(fixture.expected
				.getRdblmPrefilter().getSlapPrefilter()));
		}

		@Test
		public void testReturnRolledPrefilterOfTlim()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTlimPrefilter().getRollPrefilter(), is(fixture.expected
				.getTlimPrefilter().getRollPrefilter()));
		}

		@Test
		public void testReturnSlapPrefilterOfTlim()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTlimPrefilter().getSlapPrefilter(), is(fixture.expected
				.getTlimPrefilter().getSlapPrefilter()));
		}

		@Test
		public void testReturnRolledPrefilterOfTlix()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTlixPrefilter().getRollPrefilter(), is(fixture.expected
				.getTlixPrefilter().getRollPrefilter()));
		}

		@Test
		public void testReturnSlapPrefilterOfTlix()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTlixPrefilter().getSlapPrefilter(), is(fixture.expected
				.getTlixPrefilter().getSlapPrefilter()));
		}

		@Test
		public void testReturnRolledPrefilterOfXdbl()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getXdblPrefilter().getRollPrefilter(), is(fixture.expected
				.getXdblPrefilter().getRollPrefilter()));
		}

		@Test
		public void testReturnSlapPrefilterOfXdbl()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPrefilterOutput",
					List.class);
			sut.setAccessible(true);
			PrefilterOutput actual = (PrefilterOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getXdblPrefilter().getSlapPrefilter(), is(fixture.expected
				.getXdblPrefilter().getSlapPrefilter()));
		}
	}

	/**
	 * test toMinutiaData(List<PBMinutiaData>, List<MinutiaData> )
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaData {
		public static ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaDatas_Helper.Fixture fixture =
			ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaDatas_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMinutiaType()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					List.class, List.class);
			sut.setAccessible(true);
			List<MinutiaData> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getMinutiaType(), is(fixture.expected.get(
					index).getMinutiaType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFisType()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					List.class, List.class);
			sut.setAccessible(true);
			List<MinutiaData> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFisType(), is(fixture.expected.get(index)
					.getFisType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMinutiaCount()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					List.class, List.class);
			sut.setAccessible(true);
			List<MinutiaData> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getMinutiaCount(), is(fixture.expected.get(
					index).getMinutiaCount()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFormat()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					List.class, List.class);
			sut.setAccessible(true);
			List<MinutiaData> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFormat(), is(fixture.expected.get(index)
					.getFormat()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnDbType()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					List.class, List.class);
			sut.setAccessible(true);
			List<MinutiaData> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getDbType(), is(fixture.expected.get(index)
					.getDbType()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFusionId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toMinutiaData",
					List.class, List.class);
			sut.setAccessible(true);
			List<MinutiaData> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFusionId(), is(fixture.expected
					.get(index).getFusionId()));
			}
		}
	}

	/**
	 * test toPalmOutput( List<PBExtractPalmOutput>, List<PalmOutput>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPalmOutputWith_ListOfPBExtractPalmOutputs_ListOfPalmOutput {
		public static ToPalmOutputHelper.Fixture fixture = ToPalmOutputHelper.build();

		@Test
		public void testHasMinutiaData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPalmOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<PalmOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameterList, actual);

			// verify
			for (int index = 0; index < fixture.expectedList.size(); index++) {
				assertThat(actual.get(index).getMinutiaData(), is(notNullValue()));
			}
		}

		@Test
		public void testHasPrefilterOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPalmOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<PalmOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameterList, actual);

			// verify
			for (int index = 0; index < fixture.expectedList.size(); index++) {
				assertThat(actual.get(index).getPrefilterOutput(), is(notNullValue()));
			}
		}

		@Test
		public void testHasPaextData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPalmOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<PalmOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameterList, actual);

			// verify
			for (int index = 0; index < fixture.expectedList.size(); index++) {
				assertThat(actual.get(index).getPaextData(), is(notNullValue()));
			}
		}

		@Test
		public void testReturnLowResImage()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPalmOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<PalmOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameterList, actual);

			// verify
			for (int index = 0; index < fixture.expectedList.size(); index++) {
				assertThat(actual.get(index).getLowResImage(), is(fixture.expectedList
					.get(index).getLowResImage()));
			}
		}

		@Test
		public void testReturnPos()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPalmOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<PalmOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameterList, actual);

			// verify
			for (int index = 0; index < fixture.expectedList.size(); index++) {
				assertThat(actual.get(index).getPos(), is(fixture.expectedList.get(index)
					.getPos()));
			}
		}

	}

	/**
	 * test toPoint(PBPoint)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPointWith_PBPoint {
		public static ToPointHelper.Fixture fixture = ToPointHelper.build(1, 2);

		@Test
		public void testReturnX()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPoint", PBPoint.class);
			sut.setAccessible(true);
			Point actual = (Point)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getX(), is(fixture.expected.getX()));
		}

		@Test
		public void testReturnY()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPoint", PBPoint.class);
			sut.setAccessible(true);
			Point actual = (Point)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getY(), is(fixture.expected.getY()));
		}
	}

	/**
	 * test toCropInfo(PBFingerCropCoordinate)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToCropInfoWith_PBFingerCropCoordinate {
		public static ToCropInfoHelper.Fixture fixture = ToCropInfoHelper.build();

		@Test
		public void testHasCenter()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCropInfo",
					PBFingerCropCoordinate.class);
			sut.setAccessible(true);
			CropInfo actual = (CropInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCenter(), is(notNullValue()));
		}

		@Test
		public void testHasNotAngle()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCropInfo",
					PBFingerCropCoordinate.class);
			sut.setAccessible(true);
			CropInfo actual = (CropInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCenter().getAngle(), is(nullValue()));
		}

		@Test
		public void testHasCropPoints()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCropInfo",
					PBFingerCropCoordinate.class);
			sut.setAccessible(true);
			CropInfo actual = (CropInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCropPoints(), is(notNullValue()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPoints()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCropInfo",
					PBFingerCropCoordinate.class);
			sut.setAccessible(true);
			CropInfo actual = (CropInfo)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCropPoints().getPoints().size(), is(not(0)));
			assertThat(actual.getCropPoints().getPoints().size(), is(fixture.expected
				.getCropPoints().getPoints().size()));
		}
	}

	/**
	 * test toFingerOutput( List<PBExtractTenprintFingerOutput>,
	 * List<FingerOutput>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFingerOutputWith_ListOfBExtractTenprintFingerOutputs_ListOfFingerOutputs {
		public static ToFingerOutputWith_ListOfBExtractTenprintFingerOutputs_ListOfFingerOutputs_Helper.Fixture fixture =
			ToFingerOutputWith_ListOfBExtractTenprintFingerOutputs_ListOfFingerOutputs_Helper
				.build();

		@Test
		public void testHasCropInfo()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getCropInfo(), is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasMinutiaData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getMinutiaData().size(), is(not(0)));
				assertThat(actual.get(index).getMinutiaData().size(), is(fixture.expected
					.get(index).getMinutiaData().size()));
			}
		}

		@Test
		public void testHasPrefilterOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPrefilterOutput(), is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFisData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFisData().size(), is(not(0)));
				assertThat(actual.get(index).getFisData().size(), is(fixture.expected
					.get(index).getFisData().size()));
			}
		}

		@Test
		public void testReturnCroppedImage()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getCroppedImage(), is(fixture.expected.get(
					index).getCroppedImage()));
			}
		}

		@Test
		public void testReturnLowResImage()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getLowResImage(), is(fixture.expected.get(
					index).getLowResImage()));
			}
		}

		@Test
		public void testReturnPos()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPos(), is(fixture.expected.get(index)
					.getPos()));
			}
		}

		@Test
		public void testReturnQuality()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getQuality(), is(fixture.expected.get(index)
					.getQuality()));
			}
		}

		@Test
		public void testReturnAngle()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getAngle(), is(fixture.expected.get(index)
					.getAngle()));
			}
		}

		@Test
		public void testReturnFingerConfidence()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFingerConfidence(), is(fixture.expected
					.get(index).getFingerConfidence()));
			}
		}

		@Test
		public void testReturnPatternPrimary()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPatternPrimary(), is(fixture.expected
					.get(index).getPatternPrimary()));
			}
		}

		@Test
		public void testReturnPatternReference()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPatternReference(), is(fixture.expected
					.get(index).getPatternReference()));
			}
		}

		@Test
		public void testReturnNfiqQuality()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFingerOutput",
					List.class, List.class);
			sut.setAccessible(true);
			List<FingerOutput> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getNfiqQuality(), is(fixture.expected.get(
					index).getNfiqQuality()));
			}
		}
	}

	/**
	 * test toQrData(PBFingerQrDataOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToQrDataWith_PBFingerQrDataOutput {
		public static ToQrDataWith_PBFingerQrDataOutput_Helper.Fixture fixture =
			ToQrDataWith_PBFingerQrDataOutput_Helper.build();

		@Test
		public void testReturnRolledOfQrS()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQrData",
					PBFingerQrDataOutput.class);
			sut.setAccessible(true);
			QrOutput actual = (QrOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQrS().getRollQr().getValue(), is(fixture.expected
				.getQrS().getRollQr().getValue()));
		}

		@Test
		public void testReturnSlapOfQrS()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQrData",
					PBFingerQrDataOutput.class);
			sut.setAccessible(true);
			QrOutput actual = (QrOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQrS().getRollQr().getValue(), is(fixture.expected
				.getQrS().getRollQr().getValue()));
		}

		@Test
		public void testReturnRolledOfQrF()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQrData",
					PBFingerQrDataOutput.class);
			sut.setAccessible(true);
			QrOutput actual = (QrOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQrF().getRollQr().getValue(), is(fixture.expected
				.getQrF().getRollQr().getValue()));
		}

		@Test
		public void testReturnSlapOfQrF()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQrData",
					PBFingerQrDataOutput.class);
			sut.setAccessible(true);
			QrOutput actual = (QrOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQrF().getRollQr().getValue(), is(fixture.expected
				.getQrF().getRollQr().getValue()));
		}

	}

	/**
	 * test toPsrData(PBFingerPsrData)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPsrDataWith_PBFingerPsrData {
		public static ToPsrDataHelper.Fixture fixture = ToPsrDataHelper.build(1,
			PsrType.PSR_AC, jp.co.nec.aim.mm.jaxb.PsrType.AC);

		@Test
		public void testReturnFusionId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPsrData",
					PBFingerPsrData.class);
			sut.setAccessible(true);
			PsrData actual = (PsrData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFusionId(), is(fixture.expected.getFusionId()));
		}

		@Test
		public void testReturnType()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPsrData",
					PBFingerPsrData.class);
			sut.setAccessible(true);
			PsrData actual = (PsrData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getType(), is(fixture.expected.getType()));
		}

		@Test
		public void testReturnValuie()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPsrData",
					PBFingerPsrData.class);
			sut.setAccessible(true);
			PsrData actual = (PsrData)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getValue(), is(fixture.expected.getValue()));
		}
	}

	/**
	 * test toPsrOutput(PBFingerPrelsectionDataOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToPsrOutputWith_PBFingerPrelsectionDataOutput {
		public static ToPsrOutputHelper.Fixture fixture = ToPsrOutputHelper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasRolled10Psr()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPsrOutput",
					PBFingerPrelsectionDataOutput.class);
			sut.setAccessible(true);
			PsrOutput actual = (PsrOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRolled10Psr().size(), is(not(0)));
			assertThat(actual.getRolled10Psr().size(), is(fixture.expected
				.getRolled10Psr().size()));
		}

		@Test
		public void testHasRolled8Psr()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPsrOutput",
					PBFingerPrelsectionDataOutput.class);
			sut.setAccessible(true);
			PsrOutput actual = (PsrOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRolled8Psr(), is(notNullValue()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasSlapPsr()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toPsrOutput",
					PBFingerPrelsectionDataOutput.class);
			sut.setAccessible(true);
			PsrOutput actual = (PsrOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSlapPsr().size(), is(not(0)));
			assertThat(actual.getSlapPsr().size(), is(fixture.expected.getSlapPsr()
				.size()));
		}
	}

	/**
	 * test toQcStatus(List<PBQualityCheckOutputStandardStatus>, List<QcStatus>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToQcStatusWith_PBQualityCheckOutputStandardStatus {
		public static ToQcStatusHelper.Fixture fixture = ToQcStatusHelper.build(
			FingerPositionType.ROLLED_RIGHT_THUMB, 1, 2);

		@Test
		public void testReturnPos()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcStatus", List.class,
					List.class);
			sut.setAccessible(true);
			List<QcStatus> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFinger().getPos(), is(fixture.expected
					.get(index).getFinger().getPos()));
			}
		}

		@Test
		public void testReturnStatus()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcStatus", List.class,
					List.class);
			sut.setAccessible(true);
			List<QcStatus> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFinger().getStatus(), is(fixture.expected
					.get(index).getFinger().getStatus()));
			}
		}
	}

	/**
	 * test toQcOutput(PBFingerQualityCheckOutputStandard)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToQcOutputWith_PBFingerQualityCheckOutputStandard {
		public static ToQcOutputWith_PBFingerQualityCheckOutputStandard_Helper.Fixture fixture =
			ToQcOutputWith_PBFingerQualityCheckOutputStandard_Helper.build();

		@Test
		public void testReturnTotal()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcOutput",
					PBFingerQualityCheckOutputStandard.class);
			sut.setAccessible(true);
			QcOutput actual = (QcOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTotal(), is(fixture.expected.getTotal()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasRolledStatus()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcOutput",
					PBFingerQualityCheckOutputStandard.class);
			sut.setAccessible(true);
			QcOutput actual = (QcOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRollStatus().size(), is(not(0)));
			assertThat(actual.getRollStatus().size(), is(fixture.expected.getRollStatus()
				.size()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasSlapStatus()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcOutput",
					PBFingerQualityCheckOutputStandard.class);
			sut.setAccessible(true);
			QcOutput actual = (QcOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSlapStatus().size(), is(not(0)));
			assertThat(actual.getSlapStatus().size(), is(fixture.expected.getSlapStatus()
				.size()));
		}
	}

	/**
	 * test toQcSequence(PBQualityCheckOutputAdvancedSequence)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ToQcSequenceWith_PBQualityCheckOutputAdvancedSequence {
		@DataPoints
		public static ToQcSequenceHelper.Fixture[] getFixtures() {
			return ToQcSequenceHelper.fixtures;
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testtReturnRolledFingers(ToQcSequenceHelper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcSequence",
					PBQualityCheckOutputAdvancedSequence.class);
			sut.setAccessible(true);
			QcSequence actual = (QcSequence)sut.invoke(null, fixture.parameter);

			// verify
			if (!fixture.mode.equals("only slap")) {
				assertThat(actual.getRolledFingers(), is(fixture.expected
					.getRolledFingers()));
			} else {
				assertThat(actual.getRolledFingers(), is(nullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Theory
		public void testReturnSlapFingers(ToQcSequenceHelper.Fixture fixture)
			throws Exception {

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcSequence",
					PBQualityCheckOutputAdvancedSequence.class);
			sut.setAccessible(true);
			QcSequence actual = (QcSequence)sut.invoke(null, fixture.parameter);

			// verify
			if (!fixture.mode.equals("only rolled")) {
				assertThat(actual.getSlapFingers(), is(fixture.expected.getSlapFingers()));
			} else {
				assertThat(actual.getSlapFingers(), is(nullValue()));
			}
		}
	}

	/**
	 * test toHistory(List<PBQualityCheckOutputAdvancedHistory>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToHistoryWith_ListOfPBQualityCheckOutputAdvancedHistorys {
		public static ToHistoryHelper.Fixture fixture = ToHistoryHelper.build();

		@Test
		public void testReturnActivity()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toHistory", List.class);
			sut.setAccessible(true);
			QcOutput.History actual =
				(QcOutput.History)sut.invoke(null, fixture.parameter);

			// verify
			for (int index = 0; index < fixture.expected.getItem().size(); index++) {
				assertThat(actual.getItem().get(index).getActivity(), is(fixture.expected
					.getItem().get(index).getActivity()));
			}
		}

		@Test
		public void testReturnStatus()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toHistory", List.class);
			sut.setAccessible(true);
			QcOutput.History actual =
				(QcOutput.History)sut.invoke(null, fixture.parameter);

			// verify
			for (int index = 0; index < fixture.expected.getItem().size(); index++) {
				assertThat(actual.getItem().get(index).getStatus(), is(fixture.expected
					.getItem().get(index).getStatus()));
			}
		}

		@Test
		public void testReturnData()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toHistory", List.class);
			sut.setAccessible(true);
			QcOutput.History actual =
				(QcOutput.History)sut.invoke(null, fixture.parameter);

			// verify
			for (int index = 0; index < fixture.expected.getItem().size(); index++) {
				assertThat(actual.getItem().get(index).getData(), is(fixture.expected
					.getItem().get(index).getData()));
			}
		}
	}

	/**
	 * test toQcOutput(PBFingerQualityCheckOutputAdvanced)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToQcOutputWith_PBFingerQualityCheckOutputAdvanced {
		public static ToQcOutputWith_PBFingerQualityCheckOutputAdvanced_Helper.Fixture fixture =
			ToQcOutputWith_PBFingerQualityCheckOutputAdvanced_Helper.build();

		@Test
		public void testHasSequence()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcOutput",
					PBFingerQualityCheckOutputAdvanced.class);
			sut.setAccessible(true);
			QcOutput actual = (QcOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getSequence(), is(notNullValue()));
		}

		@Test
		public void testHasHistory()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcOutput",
					PBFingerQualityCheckOutputAdvanced.class);
			sut.setAccessible(true);
			QcOutput actual = (QcOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getHistory(), is(notNullValue()));
		}

		@Test
		public void testReturnStatus()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcOutput",
					PBFingerQualityCheckOutputAdvanced.class);
			sut.setAccessible(true);
			QcOutput actual = (QcOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getStatus(), is(fixture.expected.getStatus()));
		}
	}

	/**
	 * test toQcOutput(PBFingerQualityCheckOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToQcOutputWith_PBFingerQualityCheckOutput {
		@Test
		public void testReturnQcOutputInStandard()
			throws Exception {
			// setup
			ToQcOutputWith_PBFingerQualityCheckOutput_Helper.Fixture fixture =
				ToQcOutputWith_PBFingerQualityCheckOutput_Helper.build("standard");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcOutput",
					PBFingerQualityCheckOutput.class);
			sut.setAccessible(true);
			QcOutput actual = (QcOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual, is(notNullValue()));
		}

		@Test
		public void testReturnQcOutputInAdvanced()
			throws Exception {
			// setup
			ToQcOutputWith_PBFingerQualityCheckOutput_Helper.Fixture fixture =
				ToQcOutputWith_PBFingerQualityCheckOutput_Helper.build("advanced");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toQcOutput",
					PBFingerQualityCheckOutput.class);
			sut.setAccessible(true);
			QcOutput actual = (QcOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual, is(notNullValue()));
		}
	}

	/**
	 * test toTenprintOutput( PBExtractTenprintOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToTenprintOutputWith_PBExtractTenprintOutput {
		public static ToTenprintOutputHelper.Fixture fixture = ToTenprintOutputHelper
			.build();

		@Test
		public void testHasQcOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toTenprintOutput",
					PBExtractTenprintOutput.class);
			sut.setAccessible(true);
			TenprintOutput actual = (TenprintOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQcOutput(), is(notNullValue()));
		}

		@Test
		public void testHasPsrOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toTenprintOutput",
					PBExtractTenprintOutput.class);
			sut.setAccessible(true);
			TenprintOutput actual = (TenprintOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPsrOutput(), is(notNullValue()));
		}

		@Test
		public void testHasQrOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toTenprintOutput",
					PBExtractTenprintOutput.class);
			sut.setAccessible(true);
			TenprintOutput actual = (TenprintOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQrOutput(), is(notNullValue()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasFingerOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toTenprintOutput",
					PBExtractTenprintOutput.class);
			sut.setAccessible(true);
			TenprintOutput actual = (TenprintOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFingerOutput().size(), is(not(0)));
			assertThat(actual.getFingerOutput().size(), is(fixture.expected
				.getFingerOutput().size()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasPalmOutput()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toTenprintOutput",
					PBExtractTenprintOutput.class);
			sut.setAccessible(true);
			TenprintOutput actual = (TenprintOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getPalmOutput().size(), is(not(0)));
			assertThat(actual.getPalmOutput().size(), is(fixture.expected.getPalmOutput()
				.size()));
		}

		@Test
		public void testREturnQualityRolled()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toTenprintOutput",
					PBExtractTenprintOutput.class);
			sut.setAccessible(true);
			TenprintOutput actual = (TenprintOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQualityRolled(), is(fixture.expected.getQualityRolled()));
		}

		@Test
		public void testREturnQualitySlap()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toTenprintOutput",
					PBExtractTenprintOutput.class);
			sut.setAccessible(true);
			TenprintOutput actual = (TenprintOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getQualitySlap(), is(fixture.expected.getQualitySlap()));
		}
	}

	/**
	 * test toExtOutput(PBExtractOutputPayload)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToExtOutputWith_PBExtractOutputPayload {
		@Test
		public void testHasTenprintOutput()
			throws Exception {
			// setup
			ToExtOutputHelper.Fixture fixture = ToExtOutputHelper.build("tenprint");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toExtOutput",
					PBExtractOutputPayload.class);
			sut.setAccessible(true);
			ExtOutput actual = (ExtOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTenprintOutput(), is(notNullValue()));
		}

		@Test
		public void testHasLatentOutput()
			throws Exception {
			// setup
			ToExtOutputHelper.Fixture fixture = ToExtOutputHelper.build("latent");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toExtOutput",
					PBExtractOutputPayload.class);
			sut.setAccessible(true);
			ExtOutput actual = (ExtOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getLatentOutput(), is(notNullValue()));
		}

		@Test
		public void testHasFaceOutput()
			throws Exception {
			// setup
			ToExtOutputHelper.Fixture fixture = ToExtOutputHelper.build("face");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toExtOutput",
					PBExtractOutputPayload.class);
			sut.setAccessible(true);
			ExtOutput actual = (ExtOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getFaceOutput(), is(notNullValue()));
		}
	}

	/**
	 * tetst oJobStaus(PBJobStatusResponse)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToJobStatuWith_PBJobStatusResponse {
		public static ToJobStausHelper.Fixture fixture = ToJobStausHelper.build();

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnJobId()
			throws Exception {
			// exercise
			JobStatus actual = new WebServiceClassConvert().toJobStatus(fixture.parameter);

			// verify
			assertThat(actual.getJobId(), is(fixture.expected.getJobId()));
		}

		@Test
		public void testReturnState()
			throws Exception {
			// exercise
			JobStatus actual = new WebServiceClassConvert().toJobStatus(fixture.parameter);

			// verify
			assertThat(actual.getState(), is(fixture.expected.getState()));
		}

		@Test
		public void testReturnFailed()
			throws Exception {
			// exercise
			JobStatus actual = new WebServiceClassConvert().toJobStatus(fixture.parameter);

			// verify
			assertThat(actual.isFailed(), is(fixture.expected.isFailed()));
		}

		@Test
		public void testThrowConvertExcpetion()
			throws Exception {
			// setup
			MockUp<PBJobStatusResponse> mockUp = new MockUp<PBJobStatusResponse>() {
				@Mock
				public long getJobId() {
					throw new NullPointerException("unit test");
				}
			};

			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				new WebServiceClassConvert().toJobStatus(fixture.parameter);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * 
	 * test toContainerResult(List<PBCheckExternalIdResultDetail>,
	 * List<ContainerResult>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToContainerResultWith_ListOfPBCheckExternalIdResultDetails_ListOfContainerResults {
		public static ToContainerResultHelper.Fixture fixture = ToContainerResultHelper
			.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnContainerId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toContainerResult",
					List.class, List.class);
			sut.setAccessible(true);
			List<ContainerResult> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getContainerId(), is(fixture.expected.get(
					index).getContainerId()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnNumOfValid()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toContainerResult",
					List.class, List.class);
			sut.setAccessible(true);
			List<ContainerResult> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getNumOfValid(), is(fixture.expected.get(
					index).getNumOfValid()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnNumOfCorrupted()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toContainerResult",
					List.class, List.class);
			sut.setAccessible(true);
			List<ContainerResult> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getNumOfCorrupted(), is(fixture.expected
					.get(index).getNumOfCorrupted()));
			}
		}
	}

	/**
	 * test toCheckResult( List<PBCheckExternalIdResult>, List<CheckResult>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToCheckResultWith_ListOfPBCheckExternalIdResults_ListOsCheckResults {
		public static ToCheckResultHelper.Fixture fixture = ToCheckResultHelper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasContainerResult()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCheckResult",
					List.class, List.class);
			sut.setAccessible(true);
			List<CheckResult> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getContainerResult().size(), is(not(0)));
				assertThat(actual.get(index).getContainerResult().size(),
					is(fixture.expected.get(index).getContainerResult().size()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEventId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCheckResult",
					List.class, List.class);
			sut.setAccessible(true);
			List<CheckResult> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getEventId(), is(fixture.expected.get(index)
					.getEventId()));
			}
		}
	}

	/**
	 * test toCheckResults( PBCheckExternalIdResponse)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToCheckResultsWith_PBCheckExternalIdResponse {
		public static ToCheckResultsHelper.Fixture fixture = ToCheckResultsHelper.build();

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Test
		public void testHasCheckResult()
			throws Exception {
			// exercise
			CheckResults actual =
				new WebServiceClassConvert().toCheckResults(fixture.parameter);

			// verify
			assertThat(actual.getCheckResult().size(), is(not(0)));
			assertThat(actual.getCheckResult().size(), is(fixture.expected
				.getCheckResult().size()));
		}

		@Test
		public void testReturnExternalId()
			throws Exception {
			// exercise
			CheckResults actual =
				new WebServiceClassConvert().toCheckResults(fixture.parameter);

			// verify
			assertThat(actual.getExternalId(), is(fixture.expected.getExternalId()));
		}

		@Test
		public void throwConvertExcpetion()
			throws Exception {
			// setup
			MockUp<PBCheckExternalIdResponse> mockUp =
				new MockUp<PBCheckExternalIdResponse>() {
					@Mock
					public String getExternalId() {
						throw new NullPointerException("unit test");
					}
				};
			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			try {
				// exercise
				new WebServiceClassConvert().toCheckResults(fixture.parameter);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}

			org.junit.Assert.fail();
		}
	}

	/**
	 * test toDynamicXml(ExtOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToDynamicXmlWith_ExtOutput {
		public static ToDynamicXmlHelper.Fixture fixture = ToDynamicXmlHelper.build();

		@Test
		public void testReturnAny()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toDynamicXml",
					ExtOutput.class);
			sut.setAccessible(true);
			DynamicXml actual =
				(DynamicXml)sut.invoke(new WebServiceClassConvert(), fixture.parameter);

			// verify
			assertThat(actual.getAny(), is(notNullValue()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasNotExtOutputElement()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toDynamicXml",
					ExtOutput.class);
			sut.setAccessible(true);
			DynamicXml actual =
				(DynamicXml)sut.invoke(new WebServiceClassConvert(), fixture.parameter);

			sut =
				WebServiceClassConvert.class.getDeclaredMethod("toString",
					DynamicXml.class);
			sut.setAccessible(true);
			String payload = (String)sut.invoke(null, actual);
			// verify
			assertThat(Integer.valueOf(payload.indexOf("ext-output")), is(-1));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasNotXmlDeclaration()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toDynamicXml",
					ExtOutput.class);
			sut.setAccessible(true);
			DynamicXml actual =
				(DynamicXml)sut.invoke(new WebServiceClassConvert(), fixture.parameter);

			sut =
				WebServiceClassConvert.class.getDeclaredMethod("toString",
					DynamicXml.class);
			sut.setAccessible(true);
			String payload = (String)sut.invoke(null, actual);
			// verify
			assertThat(Integer.valueOf(payload.indexOf("?xml")), is(-1));
		}
	}

	/**
	 * test toExtractJobError(PBServiceStateReason)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToExtractJobErrorWith_PBServiceStateReason {
		public static ToExtractJobErrorHelper.Fixture fixture = ToExtractJobErrorHelper
			.build();

		@Test
		public void testReturnCode()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toExtractJobError",
					PBServiceStateReason.class);
			sut.setAccessible(true);
			ExtractJobError actual = (ExtractJobError)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCode(), is(fixture.expected.getCode()));
		}

		@Test
		public void testReturnMessage()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toExtractJobError",
					PBServiceStateReason.class);
			sut.setAccessible(true);
			ExtractJobError actual = (ExtractJobError)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMessage(), is(fixture.expected.getMessage()));
		}

		@Test
		public void testReturnTime()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toExtractJobError",
					PBServiceStateReason.class);
			sut.setAccessible(true);
			ExtractJobError actual = (ExtractJobError)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTime(), is(fixture.expected.getTime()));
		}
	}

	/**
	 * test toExtractJobResult(PBExtractJobResult)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToExtractJobResultWith_PBExtractJobResult {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Test
		public void testHasExtractJobError()
			throws Exception {
			// setup
			ToExtractJobResultHelper.Fixture fixture =
				ToExtractJobResultHelper.build("error");

			// exercise
			ExtractJobResult actual =
				new WebServiceClassConvert().toExtractJobResult(fixture.parameter);

			// verify
			assertThat(actual.getError().size(), is(not(0)));
			assertThat(actual.getError().size(), is(fixture.expected.getError().size()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasKeyedBinary()
			throws Exception {
			// setup
			ToExtractJobResultHelper.Fixture fixture =
				ToExtractJobResultHelper.build("success");

			// exercise
			ExtractJobResult actual =
				new WebServiceClassConvert().toExtractJobResult(fixture.parameter);

			// verify
			assertThat(actual.getKeyedBinary().size(), is(1));
		}

		@Test
		public void testHasExtractionOutputsPayload()
			throws Exception {
			// setup
			ToExtractJobResultHelper.Fixture fixture =
				ToExtractJobResultHelper.build("success");

			// exercise
			ExtractJobResult actual =
				new WebServiceClassConvert().toExtractJobResult(fixture.parameter);

			// verify
			assertThat(actual.getExtractionOutputsPayload(), is(notNullValue()));
		}

		@Test
		public void testHasNotExtractionOutputsPayload()
			throws Exception {
			// setup
			ToExtractJobResultHelper.Fixture fixture =
				ToExtractJobResultHelper.build("has not outputPayload");

			// exercise
			ExtractJobResult actual =
				new WebServiceClassConvert().toExtractJobResult(fixture.parameter);

			// verify
			assertThat(actual.getExtractionOutputsPayload(), is(nullValue()));
		}

		@Test
		public void testThrowConvertExcpxetion()
			throws Exception {
			// setup
			MockUp<PBServiceState> mockUp = new MockUp<PBServiceState>() {
				@Mock
				public ServiceStateType getState() {
					throw new NullPointerException("unit test");
				}
			};

			ToExtractJobResultHelper.Fixture fixture =
				ToExtractJobResultHelper.build("success");

			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				new WebServiceClassConvert().toExtractJobResult(fixture.parameter);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test toKeyedBinary( List<PBKeyedTemplate>, List<KeyedBinary>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys {
		@Test
		public void testMakeKeyFromRolledPosition()
			throws Exception {
			// setup
			ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
				ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
					.build("rolled_position");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toKeyedBinary",
					List.class, List.class);
			sut.setAccessible(true);
			List<KeyedBinary> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getKey(), is(fixture.expected.get(index)
					.getKey()));
			}
		}

		@Test
		public void testMakeKeyFromSlapPosition()
			throws Exception {
			// setup
			ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
				ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
					.build("slap_position");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toKeyedBinary",
					List.class, List.class);
			sut.setAccessible(true);
			List<KeyedBinary> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getKey(), is(fixture.expected.get(index)
					.getKey()));
			}
		}

		@Test
		public void testMakeKeyFromRolledFingerprint()
			throws Exception {
			// setup
			ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
				ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
					.build("rolled_fingerprint");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toKeyedBinary",
					List.class, List.class);
			sut.setAccessible(true);
			List<KeyedBinary> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getKey(), is(fixture.expected.get(index)
					.getKey()));
			}
		}

		@Test
		public void testMakeKeyFromSlapFingerprint()
			throws Exception {
			// setup
			ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
				ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
					.build("slap_fingerprint");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toKeyedBinary",
					List.class, List.class);
			sut.setAccessible(true);
			List<KeyedBinary> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getKey(), is(fixture.expected.get(index)
					.getKey()));
			}
		}

		@Test
		public void testMakeKeyFromgIndexWithFDB()
			throws Exception {
			// setup
			ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
				ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
					.build("index FDB");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toKeyedBinary",
					List.class, List.class);
			sut.setAccessible(true);
			List<KeyedBinary> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getKey(), is(fixture.expected.get(index)
					.getKey()));
			}
		}

		@Test
		public void testMakeKeyFromgIndexWithFI()
			throws Exception {
			// setup
			ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
				ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
					.build("index FI");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toKeyedBinary",
					List.class, List.class);
			sut.setAccessible(true);
			List<KeyedBinary> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getKey(), is(fixture.expected.get(index)
					.getKey()));
			}
		}

		@Test
		public void testMakeKeyWithNoIndexer()
			throws Exception {
			// setup
			ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
				ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
					.build("no_indexer");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toKeyedBinary",
					List.class, List.class);
			sut.setAccessible(true);
			List<KeyedBinary> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getKey(), is(fixture.expected.get(index)
					.getKey()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasEmptyBinary()
			throws Exception {
			// setup
			ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
				ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
					.build("index");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toKeyedBinary",
					List.class, List.class);
			sut.setAccessible(true);
			List<KeyedBinary> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getBinary().length, is(0));
			}
		}
	}

	/**
	 * test toRawScore(List<PBFlexibleScoreLFML>, List<RawScore>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores {
		public static ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper.Fixture fixture =
			ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper.build();

		@Test
		public void testReturnValue()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toRawScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<RawScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getValue(), is(fixture.expected.get(index)
					.getValue()));
			}
		}

		@Test
		public void testReturnSearchIndex()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toRawScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<RawScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchIndex(), is(fixture.expected.get(
					index).getSearchIndex()));
			}
		}

		@Test
		public void testReturnFileIndex()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toRawScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<RawScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFileIndex(), is(fixture.expected.get(
					index).getFileIndex()));
			}
		}
	}

	/**
	 * test toRawScore(List<PBFlexibleScoreLFML>, List<RawScore>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores2 {
		public static ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper_MinusScore.Fixture fixture =
			ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper_MinusScore.build();

		@Test
		public void testReturnValue()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toRawScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<RawScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getValue(), is(fixture.expected.get(index)
					.getValue()));
			}
		}

		@Test
		public void testReturnSearchIndex()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toRawScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<RawScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchIndex(), is(fixture.expected.get(
					index).getSearchIndex()));
			}
		}

		@Test
		public void testReturnFileIndex()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toRawScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<RawScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFileIndex(), is(fixture.expected.get(
					index).getFileIndex()));
			}
		}
	}

	/**
	 * test toSearchOutputsPayload( PBFlexibleScore)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToSearchOutputsPayloadWith_PBFlexibleScore {
		public static ToSearchOutputsPayloadHelper.Fixture fixture =
			ToSearchOutputsPayloadHelper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasRowScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toSearchOutputsPayload",
					PBFlexibleScore.class);
			sut.setAccessible(true);
			SearchOutputsPayload actual =
				(SearchOutputsPayload)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRawScores().getRawScore().size(), is(not(0)));
			assertThat(actual.getRawScores().getRawScore().size(), is(fixture.expected
				.getRawScores().getRawScore().size()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasIrisScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toSearchOutputsPayload",
					PBFlexibleScore.class);
			sut.setAccessible(true);
			SearchOutputsPayload actual =
				(SearchOutputsPayload)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getRawScores().getIrisScore().size(), is(not(0)));
			assertThat(actual.getRawScores().getIrisScore().size(), is(fixture.expected
				.getRawScores().getIrisScore().size()));
		}
	}

	/**
	 * test toIndividualScore(List<PBInquiryCandidateIndividualScore>,
	 * List<IndividualScore>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores {
		public static ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper.Fixture fixture =
			ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper
				.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasSearchOutputsPayload()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchOutputsPayload(),
					is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnValue()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getValue(), is(fixture.expected.get(index)
					.getValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSearchFingerNumber()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchPosition(), is(fixture.expected
					.get(index).getSearchPosition()));
			}
		}
		
		
		@SuppressWarnings("boxing")
		@Test
		public void testReturnFingerNumber()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPosition(), is(fixture.expected
					.get(index).getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnAxis()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getAxis(), is(fixture.expected.get(index)
					.getAxis()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnInquirySet()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getInquirySet(), is(fixture.expected.get(index)
					.getInquirySet()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFusionWeight()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFusionWeight(), is(fixture.expected.get(index)
					.getFusionWeight()));
			}
		}
	}

	/**
	 * test toIndividualScore(List<PBInquiryCandidateIndividualScore>,
	 * List<IndividualScore>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores2 {
		public static ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper_MinusScore.Fixture fixture =
			ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper_MinusScore
				.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasSearchOutputsPayload()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchOutputsPayload(),
					is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnValue()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getValue(), is(fixture.expected.get(index)
					.getValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSearchFingerNumber()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchPosition(), is(fixture.expected
					.get(index).getSearchPosition()));
			}
		}
		
		@SuppressWarnings("boxing")
		@Test
		public void testReturnFingerNumber()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPosition(), is(fixture.expected
					.get(index).getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnAxis()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getAxis(), is(fixture.expected.get(index)
					.getAxis()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnInquirySet()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getInquirySet(), is(fixture.expected.get(index)
					.getInquirySet()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFusionWeight()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFusionWeight(), is(fixture.expected.get(index)
					.getFusionWeight()));
			}
		}
	}

	/**
	 * test toIndividualScore(List<PBInquiryCandidateIndividualScore>,
	 * List<IndividualScore>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores3 {
		public static ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper_MinusSearchPosition.Fixture fixture =
			ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper_MinusSearchPosition
				.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasSearchOutputsPayload()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchOutputsPayload(),
					is(notNullValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnValue()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getValue(), is(fixture.expected.get(index)
					.getValue()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSearchFingerNumber()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchPosition(), is(fixture.expected
					.get(index).getSearchPosition()));
			}
		}
		
		@SuppressWarnings("boxing")
		@Test
		public void testReturnFingerNumber()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPosition(), is(fixture.expected
					.get(index).getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnAxis()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getAxis(), is(fixture.expected.get(index)
					.getAxis()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnInquirySet()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getInquirySet(), is(fixture.expected.get(index)
					.getInquirySet()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFusionWeight()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIndividualScore",
					List.class, List.class);
			sut.setAccessible(true);
			List<IndividualScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFusionWeight(), is(fixture.expected.get(index)
					.getFusionWeight()));
			}
		}
	}
	
	
	/**
	 * test toCandidateTemplate( List<PBInquiryCandidateTemplate>,
	 * List<CandidateTemplate>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToCandidateTemplateWith_ListOfPBInquiryCandidateTemplates_ListOfCandidateTemplates {
		public static ToCandidateTemplateHelper.Fixture fixture =
			ToCandidateTemplateHelper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnContainerId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getContainerId(), is(fixture.expected.get(
					index).getContainerId()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEventId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getEventId(), is(fixture.expected.get(index)
					.getEventId()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSearchRequestIndex()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchRequestIndex(), is(fixture.expected
					.get(index).getSearchRequestIndex()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnCompositeScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getCompositeScore(), is(fixture.expected
					.get(index).getCompositeScore()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasIndividualScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getIndividualScore().size(), is(not(0)));
				assertThat(actual.get(index).getIndividualScore().size(),
					is(fixture.expected.get(index).getIndividualScore().size()));
			}
		}

	}

	/**
	 * test toCandidateTemplate( List<PBInquiryCandidateTemplate>,
	 * List<CandidateTemplate>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToCandidateTemplateWith_ListOfPBInquiryCandidateTemplates_ListOfCandidateTemplates2 {
		public static ToCandidateTemplateHelper_MinusScore.Fixture fixture =
			ToCandidateTemplateHelper_MinusScore.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnContainerId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getContainerId(), is(fixture.expected.get(
					index).getContainerId()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnEventId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getEventId(), is(fixture.expected.get(index)
					.getEventId()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnSearchRequestIndex()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getSearchRequestIndex(), is(fixture.expected
					.get(index).getSearchRequestIndex()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnCompositeScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getCompositeScore(), is(fixture.expected
					.get(index).getCompositeScore()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasIndividualScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidateTemplate",
					List.class, List.class);
			sut.setAccessible(true);
			List<CandidateTemplate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getIndividualScore().size(), is(not(0)));
				assertThat(actual.get(index).getIndividualScore().size(),
					is(fixture.expected.get(index).getIndividualScore().size()));
			}
		}

	}

	/**
	 * test toCandidate( PBInquiryCandidateList, List<Candidate>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToCandidateWith_PBInquiryCandidateList_ListOfCandidates {
		public static ToCandidateHelper.Fixture fixture = ToCandidateHelper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnExternalId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidate",
					PBInquiryCandidateList.class, List.class);
			sut.setAccessible(true);
			List<Candidate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getExternalId(), is(fixture.expected.get(
					index).getExternalId()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFusionScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidate",
					PBInquiryCandidateList.class, List.class);
			sut.setAccessible(true);
			List<Candidate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFusionScore(), is(fixture.expected.get(
					index).getFusionScore()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasCandidateTemplate()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidate",
					PBInquiryCandidateList.class, List.class);
			sut.setAccessible(true);
			List<Candidate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getCandidateTemplate().size(), is(not(0)));
				assertThat(actual.get(index).getCandidateTemplate().size(),
					is(fixture.expected.get(index).getCandidateTemplate().size()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnHit()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toCandidate",
					PBInquiryCandidateList.class, List.class);
			sut.setAccessible(true);
			List<Candidate> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).isHit(), is(fixture.expected.get(index)
					.isHit()));
			}
		}
	}

	/**
	 * test toSearchJobError(PBServiceStateReason)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToSearchJobErrorWith_PBServiceStateReason {
		public static ToSearchJobErrorHelper.Fixture fixture = ToSearchJobErrorHelper
			.build();

		@Test
		public void testReturnCode()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toSearchJobError",
					PBServiceStateReason.class);
			sut.setAccessible(true);
			SearchJobError actual = (SearchJobError)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getCode(), is(fixture.expected.getCode()));
		}

		@Test
		public void testReturnMessage()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toSearchJobError",
					PBServiceStateReason.class);
			sut.setAccessible(true);
			SearchJobError actual = (SearchJobError)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getMessage(), is(fixture.expected.getMessage()));
		}

		@Test
		public void testReturnTime()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toSearchJobError",
					PBServiceStateReason.class);
			sut.setAccessible(true);
			SearchJobError actual = (SearchJobError)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getTime(), is(fixture.expected.getTime()));
		}
	}

	/**
	 * test toSearchJobResult(PBInquiryJobResult)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToSearchJobResultWith_PBInquiryJobResult {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@SuppressWarnings("boxing")
		@Test
		public void testHasSearchJobError()
			throws Exception {
			// setup
			ToSearchJobResultHelper.Fixture fixture =
				ToSearchJobResultHelper.build("error");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toSearchJobResult",
					PBInquiryJobResult.class);
			sut.setAccessible(true);
			SearchJobResult actual =
				(SearchJobResult)sut.invoke(new WebServiceClassConvert(),
					fixture.parameter);

			// verify
			assertThat(actual.getError().size(), is(not(0)));
			assertThat(actual.getError().size(), is(fixture.expected.getError().size()));
		}

		@Test
		public void testReturnJobId()
			throws Exception {
			// setup
			ToSearchJobResultHelper.Fixture fixture =
				ToSearchJobResultHelper.build("error");

			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toSearchJobResult",
					PBInquiryJobResult.class);
			sut.setAccessible(true);
			SearchJobResult actual =
				(SearchJobResult)sut.invoke(new WebServiceClassConvert(),
					fixture.parameter);

			// verify
			assertThat(actual.getJobId(), is(fixture.expected.getJobId()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnReadCount()
			throws Exception {
			// setup
			ToSearchJobResultHelper.Fixture fixture =
				ToSearchJobResultHelper.build("success");

			// exercise
			SearchJobResult actual =
				new WebServiceClassConvert().toSearchJobResult(fixture.parameter);

			// verify
			assertThat(actual.getStatistics().getReadCount(), is(fixture.expected
				.getStatistics().getReadCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnMatchCount()
			throws Exception {
			// setup
			ToSearchJobResultHelper.Fixture fixture =
				ToSearchJobResultHelper.build("success");

			// exercise
			SearchJobResult actual =
				new WebServiceClassConvert().toSearchJobResult(fixture.parameter);

			// verify
			assertThat(actual.getStatistics().getMatchCount(), is(fixture.expected
				.getStatistics().getMatchCount()));
		}

		@SuppressWarnings("boxing")
		@Test
		public void testHasCandidate()
			throws Exception {
			// setup
			ToSearchJobResultHelper.Fixture fixture =
				ToSearchJobResultHelper.build("success");

			// exercise
			SearchJobResult actual =
				new WebServiceClassConvert().toSearchJobResult(fixture.parameter);

			// verify
			assertThat(actual.getCandidate().size(), is(not(0)));
			assertThat(actual.getCandidate().size(), is(fixture.expected.getCandidate()
				.size()));
		}

		@Test
		public void testThrowConvertException()
			throws Exception {
			// setup
			MockUp<PBInquiryJobResult> mockUp = new MockUp<PBInquiryJobResult>() {
				@Mock
				public long getJobId() {
					throw new NullPointerException("unit test");
				}
			};

			ToSearchJobResultHelper.Fixture fixture =
				ToSearchJobResultHelper.build("success");

			expectedException.expect(ConvertException.class);
			expectedException.expectMessage("unit test");

			// exercise
			try {
				new WebServiceClassConvert().toSearchJobResult(fixture.parameter);
			} catch (Exception e) {
				mockUp.tearDown();
				Throwables.propagateIfInstanceOf(e, ConvertException.class);
			}
			org.junit.Assert.fail();
		}
	}

	/**
	 * test
	 * 
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToFusionIndexer_FusionIndexer_ListOfPBFusionIndexers_ListOfFusionIndexer {
		public static ToFusionIndexeHelper.Fixture fixture = ToFusionIndexeHelper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFormat()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFusionIndexer",
					List.class, List.class);
			sut.setAccessible(true);
			List<FusionIndexer> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFormat(), is(fixture.expected.get(index)
					.getFormat()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnFusionId()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toFusionIndexer",
					List.class, List.class);
			sut.setAccessible(true);
			List<FusionIndexer> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			assertThat(actual.size(), is(not(0)));
			assertThat(actual.size(), is(fixture.expected.size()));
			for (int index = 0; index < actual.size(); index++) {
				assertThat(actual.get(index).getFusionId(), is(contains(fixture.expected
					.get(index).getFusionId().toArray())));
			}
		}
	}

	/**
	 * test toIrisScore(List<PBFlexibleScoreIris>, List<IrisScore>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToIrisScoreWith_List {
		public static ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper.Fixture fixture =
			ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper.build();

		@Test
		public void testReturnScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<IrisScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getScore(), is(fixture.expected.get(index)
					.getScore()));
			}
		}

		@Test
		public void testReturnFilePosition()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<IrisScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFilePosition(), is(fixture.expected.get(
					index).getFilePosition()));
			}
		}
	}

	/**
	 * test toIrisScore(List<PBFlexibleScoreIris>, List<IrisScore>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToIrisScoreWith_List2 {
		public static ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper_MinusScore.Fixture fixture =
			ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper_MinusScore.build();

		@Test
		public void testReturnScore()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<IrisScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getScore(), is(fixture.expected.get(index)
					.getScore()));
			}
		}

		@Test
		public void testReturnFilePosition()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisScore", List.class,
					List.class);
			sut.setAccessible(true);
			List<IrisScore> actual = new ArrayList<>();
			sut.invoke(null, fixture.parameter, actual);

			// verify
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getFilePosition(), is(fixture.expected.get(
					index).getFilePosition()));
			}
		}
	}

	/**
	 * test toIrisPoint(PBPoint pbPoint)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToIrisPointWith_PBPoint {
		public static ToIrisPoint_Helper.Fixture fixture = ToIrisPoint_Helper.build(1, 2);

		@Test
		public void testReturnX()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisPoint",
					PBPoint.class);
			sut.setAccessible(true);
			IrisPoint actual = (IrisPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getX(), is(fixture.expected.getX()));
		}

		@Test
		public void testReturnY()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisPoint",
					PBPoint.class);
			sut.setAccessible(true);
			IrisPoint actual = (IrisPoint)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getY(), is(fixture.expected.getY()));
		}
	}

	/**
	 * test toIrisOutputPoints( List<PBExtractIrisDetectionOutput>)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToIrisOutputPointsWith_ListOfPBExtractIrisDetectionOutput {
		public static ToIrisOutputPoints_Helper.Fixture fixture =
			ToIrisOutputPoints_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testReturnIrisPoints()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisOutputPoints",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<IrisOutputPoints> actual =
				(List<IrisOutputPoints>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getIrisPoints().getPoints().size(),
					is(not(0)));
				assertThat(actual.get(index).getIrisPoints().getPoints().size(),
					is(fixture.expected.get(index).getIrisPoints().getPoints().size()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnPupilPoints()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisOutputPoints",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<IrisOutputPoints> actual =
				(List<IrisOutputPoints>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPupilPoints().getPoints().size(),
					is(not(0)));
				assertThat(actual.get(index).getPupilPoints().getPoints().size(),
					is(fixture.expected.get(index).getPupilPoints().getPoints().size()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnPosition()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisOutputPoints",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<IrisOutputPoints> actual =
				(List<IrisOutputPoints>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getPosition(), is(fixture.expected
					.get(index).getPosition()));
			}
		}

		@SuppressWarnings("boxing")
		@Test
		public void testReturnQuality()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisOutputPoints",
					List.class);
			sut.setAccessible(true);
			@SuppressWarnings("unchecked")
			List<IrisOutputPoints> actual =
				(List<IrisOutputPoints>)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.size(), is(not(0)));
			for (int index = 0; index < fixture.expected.size(); index++) {
				assertThat(actual.get(index).getQuality(), is(fixture.expected.get(index)
					.getQuality()));
			}
		}
	}

	/**
	 * test toIrisOutput(PBExtractIrisOutput)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToIrisOutputWith_PBExtractIrisOutput {
		public static ToIrisOutput_Helper.Fixture fixture = ToIrisOutput_Helper.build();

		@SuppressWarnings("boxing")
		@Test
		public void testHasIrisOutputPoints()
			throws Exception {
			// exercise
			Method sut =
				WebServiceClassConvert.class.getDeclaredMethod("toIrisOutput",
					PBExtractIrisOutput.class);
			sut.setAccessible(true);
			IrisOutput actual = (IrisOutput)sut.invoke(null, fixture.parameter);

			// verify
			assertThat(actual.getDetection().getPoints().size(), is(not(0)));
			assertThat(actual.getDetection().getPoints().size(), is(fixture.expected
				.getDetection().getPoints().size()));
		}
	}
}
