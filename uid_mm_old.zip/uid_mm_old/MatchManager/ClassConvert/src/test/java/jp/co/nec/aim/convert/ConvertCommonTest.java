package jp.co.nec.aim.convert;

import static jp.co.nec.aim.convert.ConvertCommon.*;
import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;

import java.lang.reflect.Method;
import java.util.List;

import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedAfisLowLevelFunctionEnumToInquiryFuncionTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedByteToFingerPatternTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedByteToPalmPositionTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedByteToRegionCodeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedCmlafEnhTypeToCmlafImageEnhganceTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedDetectionAlgorithmToFaceDetectionAlgorithmTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedDetectionModeToFaceDetectionModeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedEnhTypeToBasicImageEnhganceTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedExtInfoModeFormatToExtractOutputModeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedExtractionFormatsToTemplateFormatTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedFaceProcessModeToFaceExtractProcessTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedFaceRotationToListFaceDetectionRotationTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedFingerAxisTypeToAxisEnumHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedFingerPatternTypeToStringHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedFingerPositionTypeToStringHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedFingerSetTypeToInquirySetEnumHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedFisTypeTypeToStringHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedFunctionNameToTemplateFormatTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedGenderEnumToGenderTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedImageFormatToImageFormatTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedImagePositionTypeToIntKeyHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedImagePositionTypeToIntPositionHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedInquirySetEnumToFingerSetTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedIntToCmlafFeTypeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedIntToFingerPositionBaseTypeForSelectFingerHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedIntToFingerPositionBaseTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedIntToFingerPrintTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedIntToStringHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedIntToTemplateFormatTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedIrisExtractionModeToIrisExtractionModeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedIrisSearchModeToIrisSearchModeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedJobStateTypeToJobStateEnumHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedLfmlDistortionLevelToPc2DistortionLevelTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedLfmlRotationLimitToPc2RotationLimitTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedLfmlSearchLevelToLfmlSearchLevelTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedLfmlSpeedLevelToPc2SpeedLevelTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedMinutiaDbTypeToStringHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedMinutiaTypeToStringHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedPosToImagePositionTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedProtoPsrTypeToJaxbPsrTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedQcModeToQualityCheckModeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedQualityCheckAdvancedActivityTypeToQcActivityHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedQualityCheckAdvancedStateTypeToQcDetailStatusHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedShrinkFactorToFaceDetectionShrinkFactorTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedSortingOrderToFaceDetectionSortingOrderTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringSearchTemplateToTemplateFormatTypeForGetBinaryHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToTimPc2RotationLimitTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToCmlafSearchModeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToFilterModeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToFingerPrintTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToFingerSelectionModeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToFisTypeTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToImagePositionTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToInquiryFunctionTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToIntHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToLeAlgorithmTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToLeCorePositionTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToLeRotationLimitTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToListIntHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToMinutiaDbTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToMinutiaTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToPalmRotationLimitTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToPc2DistortionLevelTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToPc2RotationLimitTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToPc2SpeedLevelTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToRaceTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToTemplateFormatTypeForGetBinaryHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToTemplateFormatTypeForInquiryHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToTemplateFormatTypeForInsertHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToTemplateFormatTypeForRegistrationHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedStringToYobMethodTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedTemplateFormatTypeToListStringHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedTemplateFormatTypeToStringDbTypeHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedTemplateFormatTypeToStringNameHelper;
import jp.co.nec.aim.helper.CovertCommonTestHelper.InitializedWhiteBlackLevelToImageWhiteBlackLevelTypeHelper;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerAxisType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPatternType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionBaseType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.GenderType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.PalmPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.PrefilterYobMethodType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.RaceType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.RegionCodeType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.BasicImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.CMLaFFeTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.CMLaFImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.ExtractOutputModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionAlgorithmType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionRotationType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionShrinkFactorType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionSortingOrderType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceExtractProcessType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FisTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.ImageWhiteBlackLevelType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.IrisExtractionModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaDbType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.CMLaFSearchModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.FilterModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.FingerSelectionModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.IrisSearchModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeAlgorithmType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeCorePositionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeRotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LfmlSearchLevelType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.PalmRotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2DistortionLevelType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2RotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2SpeedLevelType;
import jp.co.nec.aim.mm.jaxb.AxisEnum;
import jp.co.nec.aim.mm.jaxb.GenderEnum;
import jp.co.nec.aim.mm.jaxb.InquirySetEnum;
import jp.co.nec.aim.mm.jaxb.JobStateEnum;
import jp.co.nec.aim.mm.jaxb.QcActivity;
import jp.co.nec.aim.mm.jaxb.QcDetailStatus;

import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;

import com.google.common.collect.Iterables;

@RunWith(Enclosed.class)
public class ConvertCommonTest {
	/**
	 * getValue method
	 * 
	 * @author kawamura
	 * 
	 */
	public static class GetValue {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testStaticInitialize()
			throws Exception {

			// exercise
			ConvertCommon.getValue("RDBL_1", stringToImagePositionType);
		}

		@Test
		public void testReturnValue()
			throws Exception {
			// setup
			TemplateFormatType expected = TemplateFormatType.TEMPLATE_RDBT;

			// exercise
			TemplateFormatType actual =
				ConvertCommon.getValue("RDBT", stringToTemplateFormatTypeForRegistration);

			// verfy
			assertThat(actual, is(expected));
		}

		@Test
		public void testThrowInvalidParameterException_WithTheKeyHavingNull()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException.expectMessage("An invalid parameter: source is null.");

			// exercise
			ConvertCommon.getValue(null, stringToTemplateFormatTypeForRegistration);
		}

		@Test
		public void testThrowInvalidParameterException_withInvalidKey()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException
				.expectMessage("An invalid parameter: couldn't get a value with XYZ.");

			// exercise
			ConvertCommon.getValue("XYZ", stringToTemplateFormatTypeForRegistration);
		}

		@Test
		public void testThrowInvalidParameterException_withEmptyString()
			throws Exception {
			// setup
			expectedException.expect(InvalidParameterException.class);
			expectedException.expectMessage("An invalid parameter: value is empty.");

			// exercise
			ConvertCommon.getValue("", stringToTemplateFormatTypeForRegistration);
		}
	}

	/**
	 * table 1<br>
	 * initialize stringToImagePositionType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToImagePositionType {
		@DataPoints
		public static InitializedStringToImagePositionTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToImagePositionTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToImagePositionTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			ImagePositionType actual = getValue(fixture.key, stringToImagePositionType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 2<br>
	 * initialize fileTemplateKeyToTemplateFormatTypeForRegistration in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToTemplateFormatTypeForRegistration {
		@DataPoints
		public static InitializedStringToTemplateFormatTypeForRegistrationHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToTemplateFormatTypeForRegistrationHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToTemplateFormatTypeForRegistrationHelper.Fixture fixture)
			throws Exception {
			// exercise
			TemplateFormatType actual =
				getValue(fixture.key, stringToTemplateFormatTypeForRegistration);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 3<br>
	 * initialize stringToFingerPrintType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToFingerPrintType {
		@DataPoints
		public static InitializedStringToFingerPrintTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToFingerPrintTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToFingerPrintTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FingerPrintType actual = getValue(fixture.key, stringToFingerPrintType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 4<br>
	 * initialize functionNameToTemplateFormatType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedFunctionNameToTemplateFormatType {
		@DataPoints
		public static InitializedFunctionNameToTemplateFormatTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedFunctionNameToTemplateFormatTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedFunctionNameToTemplateFormatTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			TemplateFormatType actual =
				getValue(fixture.key, functionNameToTemplateFormatType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 5<br>
	 * initialize stringToInquiryFuncionType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToInquiryFuncionType {
		@DataPoints
		public static InitializedStringToInquiryFunctionTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToInquiryFunctionTypeHelper.fixtures;
		};

		@Theory
		public void testItnitialize(
			InitializedStringToInquiryFunctionTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			InquiryFunctionType actual =
				getValue(fixture.key, stringToInquiryFuncionType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 6<br>
	 * initialize afisLowLevelFunctionEnumToInquiryFuncionType by static
	 * initializer
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedAfisLowLevelFunctionEnumToInquiryFuncionType {
		@DataPoints
		public static InitializedAfisLowLevelFunctionEnumToInquiryFuncionTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedAfisLowLevelFunctionEnumToInquiryFuncionTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedAfisLowLevelFunctionEnumToInquiryFuncionTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			InquiryFunctionType actual =
				getValue(fixture.key, afisLowLevelFunctionEnumToInquiryFuncionType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 7<br>
	 * initialize templateFormatTypeToListString in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedTemplateFormatTypeToListString {
		@DataPoints
		public static InitializedTemplateFormatTypeToListStringHelper.Fixture[] getFixtures() {
			// setup
			return InitializedTemplateFormatTypeToListStringHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedTemplateFormatTypeToListStringHelper.Fixture fixture)
			throws Exception {
			// exercise
			List<String> actual = getValue(fixture.key, templateFormatTypeToListString);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, Iterables.toArray(actual, String.class),
				arrayContaining(fixture.expected));
		}
	}

	/**
	 * table 8<br>
	 * initialize intToTemplateFormatType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedIntToTemplateFormatType {
		@DataPoints
		public static InitializedIntToTemplateFormatTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedIntToTemplateFormatTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedIntToTemplateFormatTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			TemplateFormatType actual = getValue(fixture.key, intToTemplateFormatType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 9<br>
	 * initialize intToFingerPrintType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedIntToFingerPrintType {
		@DataPoints
		public static InitializedIntToFingerPrintTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedIntToFingerPrintTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedIntToFingerPrintTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FingerPrintType actual = getValue(fixture.key, intToFingerPrintType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 10<br>
	 * initialize intToFingerPrintType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToInt {
		@DataPoints
		public static InitializedStringToIntHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToIntHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedStringToIntHelper.Fixture fixture)
			throws Exception {
			// exercise
			Integer actual = getValue(fixture.key, stringToIntIndex);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 11<br>
	 * initialize genderEnumToGenderType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedGenderEnumToGenderType {
		@DataPoints
		public static InitializedGenderEnumToGenderTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedGenderEnumToGenderTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedGenderEnumToGenderTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			GenderType actual = getValue(fixture.key, genderEnumToGenderType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 12<br>
	 * initialize stringToRaceType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToRaceType {
		@DataPoints
		public static InitializedStringToRaceTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToRaceTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedStringToRaceTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			RaceType actual = getValue(fixture.key, stringToRaceType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 13<br>
	 * initialize stringToRaceType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedByteToRegionCodeType {
		@DataPoints
		public static InitializedByteToRegionCodeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedByteToRegionCodeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedByteToRegionCodeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			RegionCodeType actual = getValue(fixture.key, byteToRegionCodeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 14<br>
	 * initialize stringToRaceType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedByteToFingerPatternType {
		@DataPoints
		public static InitializedByteToFingerPatternTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedByteToFingerPatternTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedByteToFingerPatternTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FingerPatternType actual = getValue(fixture.key, byteToFingerPatternType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 15<br>
	 * initialize stringToRaceType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedIntToFingerPositionBaseType {
		@DataPoints
		public static InitializedIntToFingerPositionBaseTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedIntToFingerPositionBaseTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedIntToFingerPositionBaseTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FingerPositionBaseType actual =
				getValue(fixture.key, intToFingerPositionBaseType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 16<br>
	 * initialize byteToPalmPositionType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedByteToPalmPositionType {
		@DataPoints
		public static InitializedByteToPalmPositionTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedByteToPalmPositionTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedByteToPalmPositionTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			PalmPositionType actual = getValue(fixture.key, byteToPalmPositionType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 17<br>
	 * initialize stringToFilterModeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToFilterModeType {
		@DataPoints
		public static InitializedStringToFilterModeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToFilterModeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedStringToFilterModeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FilterModeType actual = getValue(fixture.key, stringToFilterModeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 18<br>
	 * initialize stringToFingerSelectionModeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToFingerSelectionModeType {
		@DataPoints
		public static InitializedStringToFingerSelectionModeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToFingerSelectionModeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToFingerSelectionModeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FingerSelectionModeType actual =
				getValue(fixture.key, stringToFingerSelectionModeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 19<br>
	 * initialize stringToYobMethodType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToYobMethodType {
		@DataPoints
		public static InitializedStringToYobMethodTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToYobMethodTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedStringToYobMethodTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			PrefilterYobMethodType actual = getValue(fixture.key, stringToYobMethodType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 20<br>
	 * initialize stringToPc2SpeedLevelType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToPc2SpeedLevelType {
		@DataPoints
		public static InitializedStringToPc2SpeedLevelTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToPc2SpeedLevelTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToPc2SpeedLevelTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			Pc2SpeedLevelType actual = getValue(fixture.key, stringToPc2SpeedLevelType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 21<br>
	 * initialize stringToPc2RotationLimitType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToPc2RotationLimitType {
		@DataPoints
		public static InitializedStringToPc2RotationLimitTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToPc2RotationLimitTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToPc2RotationLimitTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			Pc2RotationLimitType actual =
				getValue(fixture.key, stringToPc2RotationLimitType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 22<br>
	 * initialize stringToPc2DistortionLevelType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToPc2DistortionLevelType {
		@DataPoints
		public static InitializedStringToPc2DistortionLevelTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToPc2DistortionLevelTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToPc2DistortionLevelTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			Pc2DistortionLevelType actual =
				getValue(fixture.key, stringToPc2DistortionLevelType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 23<br>
	 * initialize stringToLeAlgorithmType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToLeAlgorithmType {
		@DataPoints
		public static InitializedStringToLeAlgorithmTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToLeAlgorithmTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToLeAlgorithmTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			LeAlgorithmType actual = getValue(fixture.key, stringToLeAlgorithmType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 24<br>
	 * initialize stringToLeRotationLimitType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToLeRotationLimitType {
		@DataPoints
		public static InitializedStringToLeRotationLimitTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToLeRotationLimitTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToLeRotationLimitTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			LeRotationLimitType actual =
				getValue(fixture.key, stringToLeRotationLimitType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 25<br>
	 * initialize stringToLeCorePositionType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToLeCorePositionType {
		@DataPoints
		public static InitializedStringToLeCorePositionTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToLeCorePositionTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToLeCorePositionTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			LeCorePositionType actual = getValue(fixture.key, stringToLeCorePositionType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 26<br>
	 * initialize stringToPalmRotationLimitType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToPalmRotationLimitType {
		@DataPoints
		public static InitializedStringToPalmRotationLimitTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToPalmRotationLimitTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToPalmRotationLimitTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			PalmRotationLimitType actual =
				getValue(fixture.key, stringToPalmRotationLimitType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 27<br>
	 * initialize stringToCmlafSearchModeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToCmlafSearchModeType {
		@DataPoints
		public static InitializedStringToCmlafSearchModeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToCmlafSearchModeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToCmlafSearchModeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			CMLaFSearchModeType actual =
				getValue(fixture.key, stringToCmlafSearchModeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 28<br>
	 * initialize stringToTimPc2RotationLimitType in static initialization
	 * 
	 * @author kim
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToTimPc2RotationLimitType {
		@DataPoints
		public static InitializedStringToTimPc2RotationLimitTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToTimPc2RotationLimitTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToTimPc2RotationLimitTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			Pc2RotationLimitType actual =
				getValue(fixture.key, stringToTimPc2RotationLimitType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 29<br>
	 * initialize lfmlSearchLevelToLfmlSearchLevelType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedLfmlSearchLevelToLfmlSearchLevelType {
		@DataPoints
		public static InitializedLfmlSearchLevelToLfmlSearchLevelTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedLfmlSearchLevelToLfmlSearchLevelTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedLfmlSearchLevelToLfmlSearchLevelTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			LfmlSearchLevelType actual =
				getValue(fixture.key, lfmlSearchLevelToLfmlSearchLevelType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 30 <br>
	 * initialize jobStateTypeToJobStateEnum in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedJobStateTypeToJobStateEnum {
		@DataPoints
		public static InitializedJobStateTypeToJobStateEnumHelper.Fixture[] getFixtures() {
			// setup
			return InitializedJobStateTypeToJobStateEnumHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedJobStateTypeToJobStateEnumHelper.Fixture fixture)
			throws Exception {
			// exercise
			JobStateEnum actual = getValue(fixture.key, jobStateTypeToJobStateEnum);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 31 <br>
	 * initialize fingerAxisTypeToAxisEnum in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedFingerAxisTypeToAxisEnum {
		@DataPoints
		public static InitializedFingerAxisTypeToAxisEnumHelper.Fixture[] getFixtures() {
			// setup
			return InitializedFingerAxisTypeToAxisEnumHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedFingerAxisTypeToAxisEnumHelper.Fixture fixture)
			throws Exception {
			// exercise
			AxisEnum actual = getValue(fixture.key, fingerAxisTypeToAxisEnum);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 32 <br>
	 * initialize fingerSetTypeToInquirySetEnum in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedFingerSetTypeToInquirySetEnum {
		@DataPoints
		public static InitializedFingerSetTypeToInquirySetEnumHelper.Fixture[] getFixtures() {
			// setup
			return InitializedFingerSetTypeToInquirySetEnumHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedFingerSetTypeToInquirySetEnumHelper.Fixture fixture)
			throws Exception {
			// exercise
			InquirySetEnum actual = getValue(fixture.key, fingerSetTypeToInquirySetEnum);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 33 <br>
	 * initialize extractionFormatsToTemplateFormatType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedExtractionFormatsToTemplateFormatType {
		@DataPoints
		public static InitializedExtractionFormatsToTemplateFormatTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedExtractionFormatsToTemplateFormatTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedExtractionFormatsToTemplateFormatTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			TemplateFormatType actual =
				getValue(fixture.key, extractionFormatsToTemplateFormatType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 34 <br>
	 * initialize stringToFisTypeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToFisTypeType {
		@DataPoints
		public static InitializedStringToFisTypeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToFisTypeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedStringToFisTypeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FisTypeType actual = getValue(fixture.key, stringToFisTypeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 35 <br>
	 * initialize posToImagePositionType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedPosToImagePositionType {
		@DataPoints
		public static InitializedPosToImagePositionTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedPosToImagePositionTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedPosToImagePositionTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			ImagePositionType actual = getValue(fixture.key, posToImagePositionType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 36 <br>
	 * initialize imageFormatToImageFormatType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedImageFormatToImageFormatType {
		@DataPoints
		public static InitializedImageFormatToImageFormatTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedImageFormatToImageFormatTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedImageFormatToImageFormatTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			ImageFormatType actual = getValue(fixture.key, imageFormatToImageFormatType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 37 <br>
	 * initialize whiteBlackLevelToImageWhiteBlackLevelType by static
	 * initializer
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedWhiteBlackLevelToImageWhiteBlackLevelType {
		@DataPoints
		public static InitializedWhiteBlackLevelToImageWhiteBlackLevelTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedWhiteBlackLevelToImageWhiteBlackLevelTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedWhiteBlackLevelToImageWhiteBlackLevelTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			ImageWhiteBlackLevelType actual =
				getValue(fixture.key, whiteBlackLevelToImageWhiteBlackLevelType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 38 <br>
	 * initialize stringToMinutiaDbType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToMinutiaDbType {
		@DataPoints
		public static InitializedStringToMinutiaDbTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToMinutiaDbTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedStringToMinutiaDbTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			MinutiaDbType actual = getValue(fixture.key, stringToMinutiaDbType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 39 <br>
	 * initialize stringToMinutiaType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToMinutiaType {
		@DataPoints
		public static InitializedStringToMinutiaTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToMinutiaTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedStringToMinutiaTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			MinutiaType actual = getValue(fixture.key, stringToMinutiaType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 40 <br>
	 * initialize enhTypeToBasicImageEnhganceType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedEnhTypeToBasicImageEnhganceType {
		@DataPoints
		public static InitializedEnhTypeToBasicImageEnhganceTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedEnhTypeToBasicImageEnhganceTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedEnhTypeToBasicImageEnhganceTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			BasicImageEnhanceType actual =
				getValue(fixture.key, enhTypeToBasicImageEnhganceType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 41 <br>
	 * initialize qcModeToQualityCheckModeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedQcModeToQualityCheckModeType {
		@DataPoints
		public static InitializedQcModeToQualityCheckModeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedQcModeToQualityCheckModeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedQcModeToQualityCheckModeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			QualityCheckModeType actual =
				getValue(fixture.key, qcModeToQualityCheckModeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 42 <br>
	 * initialize intToCmlafFeTypeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedIntToCmlafFeTypeType {
		@DataPoints
		public static InitializedIntToCmlafFeTypeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedIntToCmlafFeTypeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedIntToCmlafFeTypeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			CMLaFFeTypeType actual = getValue(fixture.key, intToCmlafFeTypeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 43 <br>
	 * initialize intToCmlafFeTypeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedCmlafEnhTypeToCmlafImageEnhganceType {
		@DataPoints
		public static InitializedCmlafEnhTypeToCmlafImageEnhganceTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedCmlafEnhTypeToCmlafImageEnhganceTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedCmlafEnhTypeToCmlafImageEnhganceTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			CMLaFImageEnhanceType actual =
				getValue(fixture.key, cmlafEnhTypeToCmlafImageEnhganceType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 44 <br>
	 * initialize extInfoModeFormatToExtractOutputModeType in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedExtInfoModeFormatToExtractOutputModeType {
		@DataPoints
		public static InitializedExtInfoModeFormatToExtractOutputModeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedExtInfoModeFormatToExtractOutputModeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedExtInfoModeFormatToExtractOutputModeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			ExtractOutputModeType actual =
				getValue(fixture.key, extInfoModeFormatToExtractOutputModeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 45 <br>
	 * initialize faceProcessModeToFaceExtractProcessType in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedFaceProcessModeToFaceExtractProcessType {
		@DataPoints
		public static InitializedFaceProcessModeToFaceExtractProcessTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedFaceProcessModeToFaceExtractProcessTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedFaceProcessModeToFaceExtractProcessTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FaceExtractProcessType actual =
				getValue(fixture.key, faceProcessModeToFaceExtractProcessType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 46 <br>
	 * initialize detectionModeToFaceDetectionModeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedDetectionModeToFaceDetectionModeType {
		@DataPoints
		public static InitializedDetectionModeToFaceDetectionModeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedDetectionModeToFaceDetectionModeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedDetectionModeToFaceDetectionModeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FaceDetectionModeType actual =
				getValue(fixture.key, detectionModeToFaceDetectionModeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 47 <br>
	 * initialize sortingOrderToFaceDetectionSortingOrderType by static
	 * initializer
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedSortingOrderToFaceDetectionSortingOrderType {
		@DataPoints
		public static InitializedSortingOrderToFaceDetectionSortingOrderTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedSortingOrderToFaceDetectionSortingOrderTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedSortingOrderToFaceDetectionSortingOrderTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FaceDetectionSortingOrderType actual =
				getValue(fixture.key, sortingOrderToFaceDetectionSortingOrderType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 48 <br>
	 * initialize detectionAlgorithmToFaceDetectionAlgorithmType by static
	 * initializer
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedDetectionAlgorithmToFaceDetectionAlgorithmType {
		@DataPoints
		public static InitializedDetectionAlgorithmToFaceDetectionAlgorithmTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedDetectionAlgorithmToFaceDetectionAlgorithmTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedDetectionAlgorithmToFaceDetectionAlgorithmTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FaceDetectionAlgorithmType actual =
				getValue(fixture.key, detectionAlgorithmToFaceDetectionAlgorithmType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 49 <br>
	 * initialize faceRotationToListFaceDetectionRotationType in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedFaceRotationToListFaceDetectionRotationType {
		@DataPoints
		public static InitializedFaceRotationToListFaceDetectionRotationTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedFaceRotationToListFaceDetectionRotationTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedFaceRotationToListFaceDetectionRotationTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			List<FaceDetectionRotationType> actual =
				getValue(fixture.key, faceRotationToListFaceDetectionRotationType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 50 <br>
	 * initialize shrinkFactorToFaceDetectionShrinkFactorType by static
	 * initializer
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedShrinkFactorToFaceDetectionShrinkFactorType {
		@DataPoints
		public static InitializedShrinkFactorToFaceDetectionShrinkFactorTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedShrinkFactorToFaceDetectionShrinkFactorTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedShrinkFactorToFaceDetectionShrinkFactorTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FaceDetectionShrinkFactorType actual =
				getValue(fixture.key, shrinkFactorToFaceDetectionShrinkFactorType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 52 <br>
	 * initialize imagePositionTypeToIntKey in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedImagePositionTypeToIntKey {
		@DataPoints
		public static InitializedImagePositionTypeToIntKeyHelper.Fixture[] getFixtures() {
			// setup
			return InitializedImagePositionTypeToIntKeyHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedImagePositionTypeToIntKeyHelper.Fixture fixture)
			throws Exception {
			// exercise
			Integer actual = getValue(fixture.key, imagePositionTypeToIntKey);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 53 <br>
	 * initialize fingerPositionTypeToString in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedFingerPositionTypeToString {
		@DataPoints
		public static InitializedFingerPositionTypeToStringHelper.Fixture[] getFixtures() {
			// setup
			return InitializedFingerPositionTypeToStringHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedFingerPositionTypeToStringHelper.Fixture fixture)
			throws Exception {
			// exercise
			String actual = getValue(fixture.key, fingerPositionTypeToString);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 54 <br>
	 * initialize qualityCheckAdvancedActivityTypeToQcActivity in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedQualityCheckAdvancedActivityTypeToQcActivity {
		@DataPoints
		public static InitializedQualityCheckAdvancedActivityTypeToQcActivityHelper.Fixture[] getFixtures() {
			// setup
			return InitializedQualityCheckAdvancedActivityTypeToQcActivityHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedQualityCheckAdvancedActivityTypeToQcActivityHelper.Fixture fixture)
			throws Exception {
			// exercise
			QcActivity actual =
				getValue(fixture.key, qualityCheckAdvancedActivityTypeToQcActivity);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 55 <br>
	 * initialize qualityCheckAdvancedActivityTypeToQcActivity in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedQualityCheckAdvancedStateTypeToQcDetailStatus {
		@DataPoints
		public static InitializedQualityCheckAdvancedStateTypeToQcDetailStatusHelper.Fixture[] getFixtures() {
			// setup
			return InitializedQualityCheckAdvancedStateTypeToQcDetailStatusHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedQualityCheckAdvancedStateTypeToQcDetailStatusHelper.Fixture fixture)
			throws Exception {
			// exercise
			QcDetailStatus actual =
				getValue(fixture.key, qualityCheckAdvancedStateTypeToQcDetailStatus);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 56 <br>
	 * initialize protoPsrTypeToJaxbPsrType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedProtoPsrTypeToJaxbPsrType {
		@DataPoints
		public static InitializedProtoPsrTypeToJaxbPsrTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedProtoPsrTypeToJaxbPsrTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedProtoPsrTypeToJaxbPsrTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			jp.co.nec.aim.mm.jaxb.PsrType actual =
				getValue(fixture.key, protoPsrTypeToJaxbPsrType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 57 <br>
	 * initialize imagePositionTypeToIntPosition in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedImagePositionTypeToIntPosition {
		@DataPoints
		public static InitializedImagePositionTypeToIntPositionHelper.Fixture[] getFixtures() {
			// setup
			return InitializedImagePositionTypeToIntPositionHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedImagePositionTypeToIntPositionHelper.Fixture fixture)
			throws Exception {
			// exercise
			Integer actual = getValue(fixture.key, imagePositionTypeToIntPosition);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 58 <br>
	 * initialize fingerPatternTypeToString in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedFingerPatternTypeToString {
		@DataPoints
		public static InitializedFingerPatternTypeToStringHelper.Fixture[] getFixtures() {
			// setup
			return InitializedFingerPatternTypeToStringHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedFingerPatternTypeToStringHelper.Fixture fixture)
			throws Exception {
			// exercise
			String actual = getValue(fixture.key, fingerPatternTypeToString);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 59 <br>
	 * initialize fingerPatternTypeToString in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedMinutiaTypeToString {
		@DataPoints
		public static InitializedMinutiaTypeToStringHelper.Fixture[] getFixtures() {
			// setup
			return InitializedMinutiaTypeToStringHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedMinutiaTypeToStringHelper.Fixture fixture)
			throws Exception {
			// exercise
			String actual = getValue(fixture.key, minutiaTypeToString);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 60 <br>
	 * initialize in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedMinutiaDbTypeToString {
		@DataPoints
		public static InitializedMinutiaDbTypeToStringHelper.Fixture[] getFixtures() {
			// setup
			return InitializedMinutiaDbTypeToStringHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedMinutiaDbTypeToStringHelper.Fixture fixture)
			throws Exception {
			// exercise
			String actual = getValue(fixture.key, minutiaDbTypeToString);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 61 <br>
	 * initialize fisTypeTypeToString in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedFisTypeTypeToString {
		@DataPoints
		public static InitializedFisTypeTypeToStringHelper.Fixture[] getFixtures() {
			// setup
			return InitializedFisTypeTypeToStringHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedFisTypeTypeToStringHelper.Fixture fixture)
			throws Exception {
			// exercise
			String actual = getValue(fixture.key, fisTypeTypeToString);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 62 <br>
	 * initialize stringToListInt in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToListInt {
		@DataPoints
		public static InitializedStringToListIntHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToListIntHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedStringToListIntHelper.Fixture fixture)
			throws Exception {
			// exercise
			List<Integer> actual = getValue(fixture.key, stringToListInt);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, Iterables.toArray(actual, Integer.class),
				arrayContaining(fixture.expected));
		}
	}

	/**
	 * table 63 <br>
	 * initialize inquirySetEnumToFingerSetType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedInquirySetEnumToFingerSetType {
		@DataPoints
		public static InitializedInquirySetEnumToFingerSetTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedInquirySetEnumToFingerSetTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedInquirySetEnumToFingerSetTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			FingerSetType actual = getValue(fixture.key, inquirySetEnumToFingerSetType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 64 <br>
	 * initialize intToFingerPositionBaseTypeForSelectFinger in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedIntToFingerPositionBaseTypeForSelectFinger {
		@DataPoints
		public static InitializedIntToFingerPositionBaseTypeForSelectFingerHelper.Fixture[] getFixtures() {
			// setup
			return InitializedIntToFingerPositionBaseTypeForSelectFingerHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedIntToFingerPositionBaseTypeForSelectFingerHelper.Fixture fixture)
			throws Exception {
			// exercise
			FingerPositionBaseType actual =
				getValue(fixture.key, intToFingerPositionBaseTypeForSelectFinger);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 65 <br>
	 * initialize intToFingerPositionBaseTypeForSelectFinger in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedtringToTemplateFormatType {
		@DataPoints
		public static InitializedStringToTemplateFormatTypeForInquiryHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToTemplateFormatTypeForInquiryHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToTemplateFormatTypeForInquiryHelper.Fixture fixture)
			throws Exception {
			// exercise
			TemplateFormatType actual =
				getValue(fixture.key, stringToTemplateFormatTypeForInquiry);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 66 <br>
	 * initialize intToString in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedIntToString {
		@DataPoints
		public static InitializedIntToStringHelper.Fixture[] getFixtures() {
			// setup
			return InitializedIntToStringHelper.fixtures;
		};

		@Theory
		public void testInitialize(InitializedIntToStringHelper.Fixture fixture)
			throws Exception {
			// exercise
			String actual = getValue(fixture.key, intContainerIdToString);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 67 <br>
	 * initialize lfmlRotationLimitToPc2RotationLimitType in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedLfmlRotationLimitToPc2RotationLimitType {
		@DataPoints
		public static InitializedLfmlRotationLimitToPc2RotationLimitTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedLfmlRotationLimitToPc2RotationLimitTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedLfmlRotationLimitToPc2RotationLimitTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			Pc2RotationLimitType actual =
				getValue(fixture.key, lfmlRotationLimitToPc2RotationLimitType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 68 <br>
	 * initialize lfmlSpeedLevelToPc2SpeedLevelType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedLfmlSpeedLevelToPc2SpeedLevelType {
		@DataPoints
		public static InitializedLfmlSpeedLevelToPc2SpeedLevelTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedLfmlSpeedLevelToPc2SpeedLevelTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedLfmlSpeedLevelToPc2SpeedLevelTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			Pc2SpeedLevelType actual =
				getValue(fixture.key, lfmlSpeedLevelToPc2SpeedLevelType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 69 <br>
	 * initialize lfmlDistortionLevelToPc2DistortionLevelType in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedLfmlDistortionLevelToPc2DistortionLevelType {
		@DataPoints
		public static InitializedLfmlDistortionLevelToPc2DistortionLevelTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedLfmlDistortionLevelToPc2DistortionLevelTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedLfmlDistortionLevelToPc2DistortionLevelTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			Pc2DistortionLevelType actual =
				getValue(fixture.key, lfmlDistortionLevelToPc2DistortionLevelType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 70 <br>
	 * initialize templateFormatTypeToStringName in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedTemplateFormatTypeToStringName {
		@DataPoints
		public static InitializedTemplateFormatTypeToStringNameHelper.Fixture[] getFixtures() {
			// setup
			return InitializedTemplateFormatTypeToStringNameHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedTemplateFormatTypeToStringNameHelper.Fixture fixture)
			throws Exception {
			// exercise
			String actual = getValue(fixture.key, templateFormatTypeToStringName);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 71 <br>
	 * initialize templateFormatTypeToStringDbType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedTemplateFormatTypeToStringDbType {
		@DataPoints
		public static InitializedTemplateFormatTypeToStringDbTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedTemplateFormatTypeToStringDbTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedTemplateFormatTypeToStringDbTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			String actual = getValue(fixture.key, templateFormatTypeToStringDbType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 72 <br>
	 * initialize irisSearchModeToIrisSearchModeType in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedIrisSearchModeToIrisSearchModeType {
		@DataPoints
		public static InitializedIrisSearchModeToIrisSearchModeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedIrisSearchModeToIrisSearchModeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedIrisSearchModeToIrisSearchModeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			IrisSearchModeType actual =
				getValue(fixture.key, irisSearchModeToIrisSearchModeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 73<br>
	 * initialize stringToTemplateFormatTypeForGetBinary in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToTemplateFormatTypeForGetBinary {
		@DataPoints
		public static InitializedStringToTemplateFormatTypeForGetBinaryHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToTemplateFormatTypeForGetBinaryHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToTemplateFormatTypeForGetBinaryHelper.Fixture fixture)
			throws Exception {
			// exercise
			TemplateFormatType actual =
				getValue(fixture.key, stringToTemplateFormatTypeForGetBinary);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 74<br>
	 * initialize stringSearchTemplateToTemplateFormatTypeForGetBinary in static
	 * initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringSearchTempalteToTemplateFormatTypeForGetBinary {
		@DataPoints
		public static InitializedStringSearchTemplateToTemplateFormatTypeForGetBinaryHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringSearchTemplateToTemplateFormatTypeForGetBinaryHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringSearchTemplateToTemplateFormatTypeForGetBinaryHelper.Fixture fixture)
			throws Exception {
			// exercise
			TemplateFormatType actual =
				getValue(fixture.key,
					stringSearchTemplateToTemplateFormatTypeForGetBinary);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 75<br>
	 * initialize stringToTemplateFormatTypeForInsert in static initialization
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedStringToTemplateFormatTypeForInsert {
		@DataPoints
		public static InitializedStringToTemplateFormatTypeForInsertHelper.Fixture[] getFixtures() {
			// setup
			return InitializedStringToTemplateFormatTypeForInsertHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedStringToTemplateFormatTypeForInsertHelper.Fixture fixture)
			throws Exception {
			// exercise
			TemplateFormatType actual =
				getValue(fixture.key, stringToTemplateFormatTypeForInsert);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * table 76 <br>
	 * initialize irisExtractionModeToIrisExtractionModeType in static initialization
	 * 
	 * @author kim
	 * 
	 */
	@RunWith(Theories.class)
	public static class InitializedIrisExtractionModeToIrisExtractionModeType {
		@DataPoints
		public static InitializedIrisExtractionModeToIrisExtractionModeTypeHelper.Fixture[] getFixtures() {
			// setup
			return InitializedIrisExtractionModeToIrisExtractionModeTypeHelper.fixtures;
		};

		@Theory
		public void testInitialize(
			InitializedIrisExtractionModeToIrisExtractionModeTypeHelper.Fixture fixture)
			throws Exception {
			// exercise
			IrisExtractionModeType actual =
				getValue(fixture.key, irisExtractionModeToIrisExtractionModeType);

			// verify
			String reason = "When a key is " + fixture.key;
			assertThat(reason, actual, is(fixture.expected));
		}
	}

	/**
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ToString {
		@Test
		public void testWithString()
			throws Exception {
			// exercise
			Method sut = ConvertCommon.class.getDeclaredMethod("toString", Object.class);
			sut.setAccessible(true);
			String actual = (String)sut.invoke(null, "test");

			// verify
			assertThat(actual, is("test"));
		}

		@Test
		public void testWithSchemaEnum()
			throws Exception {
			// exercise
			Method sut = ConvertCommon.class.getDeclaredMethod("toString", Object.class);
			sut.setAccessible(true);
			String actual = (String)sut.invoke(null, GenderEnum.F);

			// verify
			assertThat(actual, is("F"));
		}

		@Test
		public void testWithProtoEnum()
			throws Exception {
			// exercise
			Method sut = ConvertCommon.class.getDeclaredMethod("toString", Object.class);
			sut.setAccessible(true);
			String actual = (String)sut.invoke(null, FingerAxisType.FINGER_AXIS_A);

			// verify
			assertThat(actual, is("FINGER_AXIS_A"));
		}

		@Test
		public void testWithInteger()
			throws Exception {
			// exercise
			Method sut = ConvertCommon.class.getDeclaredMethod("toString", Object.class);
			sut.setAccessible(true);
			String actual = (String)sut.invoke(null, Integer.valueOf(1));

			// verify
			assertThat(actual, is("1"));
		}

		@Test
		public void testWithCharacter()
			throws Exception {
			// exercise
			Method sut = ConvertCommon.class.getDeclaredMethod("toString", Object.class);
			sut.setAccessible(true);
			String actual = (String)sut.invoke(null, Character.valueOf('A'));

			// verify
			assertThat(actual, is("A"));
		}
	}
}
