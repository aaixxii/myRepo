package jp.co.nec.aim.helper;

import java.util.Arrays;
import java.util.List;

import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerAxisType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPatternType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionBaseType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.GenderType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.PalmPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.PrefilterYobMethodType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.RaceType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.RegionCodeType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.BasicImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.CMLaFFeTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.CMLaFImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.ExtractOutputModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionAlgorithmType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionRotationType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionShrinkFactorType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionSortingOrderType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceExtractProcessType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FisTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.ImageWhiteBlackLevelType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.IrisExtractionModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaDbType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckAdvancedActivityType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckAdvancedStateType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.CMLaFSearchModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.FilterModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.FingerSelectionModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.IrisSearchModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeAlgorithmType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeCorePositionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeRotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LfmlSearchLevelType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.PalmRotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2DistortionLevelType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2RotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2SpeedLevelType;
import jp.co.nec.aim.mm.jaxb.AxisEnum;
import jp.co.nec.aim.mm.jaxb.CmlafEnhType;
import jp.co.nec.aim.mm.jaxb.DetectionAlgorithm;
import jp.co.nec.aim.mm.jaxb.DetectionMode;
import jp.co.nec.aim.mm.jaxb.EnhType;
import jp.co.nec.aim.mm.jaxb.ExtInfoModeFormat;
import jp.co.nec.aim.mm.jaxb.ExtractionFormats;
import jp.co.nec.aim.mm.jaxb.FaceProcessMode;
import jp.co.nec.aim.mm.jaxb.FaceRotation;
import jp.co.nec.aim.mm.jaxb.GenderEnum;
import jp.co.nec.aim.mm.jaxb.ImageFormat;
import jp.co.nec.aim.mm.jaxb.InquirySetEnum;
import jp.co.nec.aim.mm.jaxb.IrisSearchMode;
import jp.co.nec.aim.mm.jaxb.IrisExtractionMode;
import jp.co.nec.aim.mm.jaxb.JobStateEnum;
import jp.co.nec.aim.mm.jaxb.LfmlDistortionLevel;
import jp.co.nec.aim.mm.jaxb.LfmlRotationLimit;
import jp.co.nec.aim.mm.jaxb.LfmlSearchLevel;
import jp.co.nec.aim.mm.jaxb.LfmlSpeedLevel;
import jp.co.nec.aim.mm.jaxb.QcActivity;
import jp.co.nec.aim.mm.jaxb.QcDetailStatus;
import jp.co.nec.aim.mm.jaxb.QcMode;
import jp.co.nec.aim.mm.jaxb.ShrinkFactor;
import jp.co.nec.aim.mm.jaxb.SortingOrder;
import jp.co.nec.aim.mm.jaxb.WhiteBlackLevel;

public class CovertCommonTestHelper {
	public static class InitializedStringToImagePositionTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("RDBL_1", ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB),
			new Fixture("RDBL_2", ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX),
			new Fixture("RDBL_3", ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE),
			new Fixture("RDBL_4", ImagePositionType.IMAGE_ROLLED_RIGHT_RING),
			new Fixture("RDBL_5", ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE),
			new Fixture("RDBL_6", ImagePositionType.IMAGE_ROLLED_LEFT_THUMB),
			new Fixture("RDBL_7", ImagePositionType.IMAGE_ROLLED_LEFT_INDEX),
			new Fixture("RDBL_8", ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE),
			new Fixture("RDBL_9", ImagePositionType.IMAGE_ROLLED_LEFT_RING),
			new Fixture("RDBL_10", ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE),
			new Fixture("RDBLS_1", ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB),
			new Fixture("RDBLS_2", ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX),
			new Fixture("RDBLS_3", ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE),
			new Fixture("RDBLS_4", ImagePositionType.IMAGE_ROLLED_RIGHT_RING),
			new Fixture("RDBLS_5", ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE),
			new Fixture("RDBLS_6", ImagePositionType.IMAGE_ROLLED_LEFT_THUMB),
			new Fixture("RDBLS_7", ImagePositionType.IMAGE_ROLLED_LEFT_INDEX),
			new Fixture("RDBLS_8", ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE),
			new Fixture("RDBLS_9", ImagePositionType.IMAGE_ROLLED_LEFT_RING),
			new Fixture("RDBLS_10", ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE),
			new Fixture("RDBLM_1", ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB),
			new Fixture("RDBLM_2", ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX),
			new Fixture("RDBLM_3", ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE),
			new Fixture("RDBLM_4", ImagePositionType.IMAGE_ROLLED_RIGHT_RING),
			new Fixture("RDBLM_5", ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE),
			new Fixture("RDBLM_6", ImagePositionType.IMAGE_ROLLED_LEFT_THUMB),
			new Fixture("RDBLM_7", ImagePositionType.IMAGE_ROLLED_LEFT_INDEX),
			new Fixture("RDBLM_8", ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE),
			new Fixture("RDBLM_9", ImagePositionType.IMAGE_ROLLED_LEFT_RING),
			new Fixture("RDBLM_10", ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE),
			new Fixture("SDBL_1", ImagePositionType.IMAGE_SLAP_RIGHT_THUMB),
			new Fixture("SDBL_2", ImagePositionType.IMAGE_SLAP_RIGHT_INDEX),
			new Fixture("SDBL_3", ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE),
			new Fixture("SDBL_4", ImagePositionType.IMAGE_SLAP_RIGHT_RING),
			new Fixture("SDBL_5", ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE),
			new Fixture("SDBL_6", ImagePositionType.IMAGE_SLAP_LEFT_THUMB),
			new Fixture("SDBL_7", ImagePositionType.IMAGE_SLAP_LEFT_INDEX),
			new Fixture("SDBL_8", ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE),
			new Fixture("SDBL_9", ImagePositionType.IMAGE_SLAP_LEFT_RING),
			new Fixture("SDBL_10", ImagePositionType.IMAGE_SLAP_LEFT_LITTLE),
			new Fixture("SDBLS_1", ImagePositionType.IMAGE_SLAP_RIGHT_THUMB),
			new Fixture("SDBLS_2", ImagePositionType.IMAGE_SLAP_RIGHT_INDEX),
			new Fixture("SDBLS_3", ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE),
			new Fixture("SDBLS_4", ImagePositionType.IMAGE_SLAP_RIGHT_RING),
			new Fixture("SDBLS_5", ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE),
			new Fixture("SDBLS_6", ImagePositionType.IMAGE_SLAP_LEFT_THUMB),
			new Fixture("SDBLS_7", ImagePositionType.IMAGE_SLAP_LEFT_INDEX),
			new Fixture("SDBLS_8", ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE),
			new Fixture("SDBLS_9", ImagePositionType.IMAGE_SLAP_LEFT_RING),
			new Fixture("SDBLS_10", ImagePositionType.IMAGE_SLAP_LEFT_LITTLE),
			new Fixture("SDBLM_1", ImagePositionType.IMAGE_SLAP_RIGHT_THUMB),
			new Fixture("SDBLM_2", ImagePositionType.IMAGE_SLAP_RIGHT_INDEX),
			new Fixture("SDBLM_3", ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE),
			new Fixture("SDBLM_4", ImagePositionType.IMAGE_SLAP_RIGHT_RING),
			new Fixture("SDBLM_5", ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE),
			new Fixture("SDBLM_6", ImagePositionType.IMAGE_SLAP_LEFT_THUMB),
			new Fixture("SDBLM_7", ImagePositionType.IMAGE_SLAP_LEFT_INDEX),
			new Fixture("SDBLM_8", ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE),
			new Fixture("SDBLM_9", ImagePositionType.IMAGE_SLAP_LEFT_RING),
			new Fixture("SDBLM_10", ImagePositionType.IMAGE_SLAP_LEFT_LITTLE),
			new Fixture("PDB_1", ImagePositionType.IMAGE_PALM_RIGHT_FULL),
			new Fixture("PDB_2", ImagePositionType.IMAGE_PALM_RIGHT_WRITER),
			new Fixture("PDB_3", ImagePositionType.IMAGE_PALM_LEFT_FULL),
			new Fixture("PDB_4", ImagePositionType.IMAGE_PALM_LEFT_WRITER),
			new Fixture("PDB_5", ImagePositionType.IMAGE_PALM_RIGHT_LOWER),
			new Fixture("PDB_6", ImagePositionType.IMAGE_PALM_RIGHT_UPPER),
			new Fixture("PDB_7", ImagePositionType.IMAGE_PALM_LEFT_LOWER),
			new Fixture("PDB_8", ImagePositionType.IMAGE_PALM_LEFT_UPPER),
			new Fixture("PDB_9", ImagePositionType.IMAGE_PALM_RIGHT_OTHER),
			new Fixture("PDB_10", ImagePositionType.IMAGE_PALM_LEFT_OTHER),
			new Fixture("PDB_11", ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL),
			new Fixture("PDB_12", ImagePositionType.IMAGE_PALM_RIGHT_THENAR),
			new Fixture("PDB_13", ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR),
			new Fixture("PDB_14", ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL),
			new Fixture("PDB_15", ImagePositionType.IMAGE_PALM_LEFT_THENAR),
			new Fixture("PDB_16", ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR),
		};

		public static class Fixture {
			public String key;
			public ImagePositionType expected;

			Fixture(String key, ImagePositionType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToTemplateFormatTypeForRegistrationHelper {
		public static Fixture[] fixtures = {
			new Fixture("RDBT", TemplateFormatType.TEMPLATE_RDBT),
			new Fixture("SDBT", TemplateFormatType.TEMPLATE_RDBT),
			new Fixture("RDBTM", TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture("SDBTM", TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture("XDBL", TemplateFormatType.TEMPLATE_RDBLX),
			new Fixture("LR", TemplateFormatType.TEMPLATE_LDB),
			new Fixture("LRP", TemplateFormatType.TEMPLATE_PLDB),
			new Fixture("LRS", TemplateFormatType.TEMPLATE_LDBS),
			new Fixture("LRM", TemplateFormatType.TEMPLATE_LDBM),
			new Fixture("LRX", TemplateFormatType.TEMPLATE_LDBX),
			new Fixture("RDBL_1", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_2", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_3", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_4", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_5", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_6", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_7", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_8", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_9", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_10", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBLS_1", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_2", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_3", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_4", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_5", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_6", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_7", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_8", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_9", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_10", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLM_1", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_2", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_3", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_4", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_5", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_6", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_7", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_8", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_9", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_10", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBL_1", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_2", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_3", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_4", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_5", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_6", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_7", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_8", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_9", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_10", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBLS_1", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_2", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_3", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_4", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_5", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_6", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_7", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_8", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_9", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_10", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLM_1", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_2", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_3", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_4", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_5", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_6", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_7", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_8", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_9", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_10", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("PDB_1", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_2", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_3", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_4", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_5", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_6", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_7", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_8", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_9", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_10", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_11", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_12", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_13", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_14", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_15", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_16", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("FDB_1", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_2", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_3", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_4", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_5", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_6", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_7", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_8", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_9", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_10", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("IDB", TemplateFormatType.TEMPLATE_IDB),
		};

		public static class Fixture {
			public String key;
			public TemplateFormatType expected;

			Fixture(String key, TemplateFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToFingerPrintTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("RDBT", FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture("SDBT", FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture("RDBTM", FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture("SDBTM", FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture("TI_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture("TI_SLAP", FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture("TIM_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture("TIM_SLAP", FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture("TLI_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture("TLI_SLAP", FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture("TLIS_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture("TLIS_SLAP", FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture("TLIM_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture("TLIM_SLAP", FingerPrintType.FINGER_PRINT_SLAP),
		};

		public static class Fixture {
			public String key;
			public FingerPrintType expected;

			Fixture(String key, FingerPrintType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFunctionNameToTemplateFormatTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("TI", TemplateFormatType.TEMPLATE_TI),
			new Fixture("TI-M", TemplateFormatType.TEMPLATE_TIM),
			new Fixture("TLI", TemplateFormatType.TEMPLATE_TLI),
			new Fixture("TLI-S", TemplateFormatType.TEMPLATE_TLIS),
			new Fixture("TLI-M", TemplateFormatType.TEMPLATE_TLIM),
			new Fixture("TLI-X", TemplateFormatType.TEMPLATE_TLIX),
			new Fixture("LI", TemplateFormatType.TEMPLATE_LI),
			new Fixture("LI-S", TemplateFormatType.TEMPLATE_LIS),
			new Fixture("LI-M", TemplateFormatType.TEMPLATE_LIM),
			new Fixture("LLI", TemplateFormatType.TEMPLATE_LLI),
			new Fixture("LLI-S", TemplateFormatType.TEMPLATE_LLIS),
			new Fixture("LLI-M", TemplateFormatType.TEMPLATE_LLIM),
			new Fixture("LLI-X", TemplateFormatType.TEMPLATE_LLIX),
			new Fixture("LI-P", TemplateFormatType.TEMPLATE_LIP),
			new Fixture("LLI-P", TemplateFormatType.TEMPLATE_LLIP),
			new Fixture("TLI-P", TemplateFormatType.TEMPLATE_TLIP),
			new Fixture("FI", TemplateFormatType.TEMPLATE_FI),
			new Fixture("II", TemplateFormatType.TEMPLATE_II),
		};

		public static class Fixture {
			public String key;
			public TemplateFormatType expected;

			Fixture(String key, TemplateFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToInquiryFunctionTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("TI", InquiryFunctionType.TI),
			new Fixture("TI-M", InquiryFunctionType.TIM),
			new Fixture("TLI", InquiryFunctionType.TLI),
			new Fixture("TLI-S", InquiryFunctionType.TLI),
			new Fixture("TLI-M", InquiryFunctionType.TLIM),
			new Fixture("LI", InquiryFunctionType.LI),
			new Fixture("LI-S", InquiryFunctionType.LI),
			new Fixture("LI-M", InquiryFunctionType.LIM),
			new Fixture("LI-X", InquiryFunctionType.LIX),
			new Fixture("LLI", InquiryFunctionType.LLI),
			new Fixture("LLI-S", InquiryFunctionType.LLI),
			new Fixture("LLI-M", InquiryFunctionType.LLIM),
			new Fixture("LLI-X", InquiryFunctionType.LLIX),
			new Fixture("LI-P", InquiryFunctionType.LIP),
			new Fixture("LLI-P", InquiryFunctionType.LLIP),
			new Fixture("TLI-P", InquiryFunctionType.TLIP),
			new Fixture("FI", InquiryFunctionType.FI),
			new Fixture("II", InquiryFunctionType.II),
		};

		public static class Fixture {
			public String key;
			public InquiryFunctionType expected;

			Fixture(String key, InquiryFunctionType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedAfisLowLevelFunctionEnumToInquiryFuncionTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(AfisLowLevelFunctionEnum.TI, InquiryFunctionType.TI),
			new Fixture(AfisLowLevelFunctionEnum.TIM, InquiryFunctionType.TIM),
			new Fixture(AfisLowLevelFunctionEnum.TLI, InquiryFunctionType.TLI),
			new Fixture(AfisLowLevelFunctionEnum.TLIM, InquiryFunctionType.TLIM),
			new Fixture(AfisLowLevelFunctionEnum.TLIX, InquiryFunctionType.TLIX),
			new Fixture(AfisLowLevelFunctionEnum.LI, InquiryFunctionType.LI),
			new Fixture(AfisLowLevelFunctionEnum.LIM, InquiryFunctionType.LIM),
			new Fixture(AfisLowLevelFunctionEnum.LIX, InquiryFunctionType.LIX),
			new Fixture(AfisLowLevelFunctionEnum.LLI, InquiryFunctionType.LLI),
			new Fixture(AfisLowLevelFunctionEnum.LLIM, InquiryFunctionType.LLIM),
			new Fixture(AfisLowLevelFunctionEnum.LLIX, InquiryFunctionType.LLIX),
			new Fixture(AfisLowLevelFunctionEnum.LIP, InquiryFunctionType.LIP),
			new Fixture(AfisLowLevelFunctionEnum.LLIP, InquiryFunctionType.LLIP),
			new Fixture(AfisLowLevelFunctionEnum.TLIP, InquiryFunctionType.TLIP),
			new Fixture(AfisLowLevelFunctionEnum.FI, InquiryFunctionType.FI),
		};

		public static class Fixture {
			public AfisLowLevelFunctionEnum key;
			public InquiryFunctionType expected;

			Fixture(AfisLowLevelFunctionEnum key, InquiryFunctionType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedTemplateFormatTypeToListStringHelper {
		public static Fixture[] fixtures = {
			new Fixture(TemplateFormatType.TEMPLATE_RDBT, new String[] {
				"RDBT", "SDBT"
			}), new Fixture(TemplateFormatType.TEMPLATE_RDBTM, new String[] {
				"RDBTM", "SDBTM"
			}), new Fixture(TemplateFormatType.TEMPLATE_RDBLX, new String[] {
				"XDBL"
			}), new Fixture(TemplateFormatType.TEMPLATE_LDB, new String[] {
				"LDB"
			}), new Fixture(TemplateFormatType.TEMPLATE_PLDB, new String[] {
				"PLDB"
			}), new Fixture(TemplateFormatType.TEMPLATE_LDBS, new String[] {
				"LDBS"
			}), new Fixture(TemplateFormatType.TEMPLATE_LDBM, new String[] {
				"LDBM"
			}), new Fixture(TemplateFormatType.TEMPLATE_LDBX, new String[] {
				"LDBX"
			}), new Fixture(TemplateFormatType.TEMPLATE_RDBL, new String[] {
				"RDBL_", "SDBL_"
			}), new Fixture(TemplateFormatType.TEMPLATE_RDBLS, new String[] {
				"RDBLS_", "SDBLS_"
			}), new Fixture(TemplateFormatType.TEMPLATE_RDBLM, new String[] {
				"RDBLM_", "SDBLM_"
			}), new Fixture(TemplateFormatType.TEMPLATE_PDB, new String[] {
				"PDB_"
			}), new Fixture(TemplateFormatType.TEMPLATE_FDB, new String[] {
				"FDB_"
			}), new Fixture(TemplateFormatType.TEMPLATE_IDB, new String[] {
				"IDB"
			}), new Fixture(TemplateFormatType.TEMPLATE_TI, new String[] {
				"TI_ROLLED", "TI_SLAP"
			}), new Fixture(TemplateFormatType.TEMPLATE_TIM, new String[] {
				"TIM_ROLLED", "TIM_SLAP"
			}), new Fixture(TemplateFormatType.TEMPLATE_TLI, new String[] {
				"TLI_ROLLED", "TLI_SLAP"
			}), new Fixture(TemplateFormatType.TEMPLATE_TLIS, new String[] {
				"TLIS_ROLLED", "TLIS_SLAP"
			}), new Fixture(TemplateFormatType.TEMPLATE_TLIM, new String[] {
				"TLIM_ROLLED", "TLIM_SLAP"
			}), new Fixture(TemplateFormatType.TEMPLATE_TLIX, new String[] {
				"TLIX"
			}), new Fixture(TemplateFormatType.TEMPLATE_LI, new String[] {
				"LI"
			}), new Fixture(TemplateFormatType.TEMPLATE_LIS, new String[] {
				"LIS"
			}), new Fixture(TemplateFormatType.TEMPLATE_LIM, new String[] {
				"LIM"
			}), new Fixture(TemplateFormatType.TEMPLATE_LIX, new String[] {
				"LIX"
			}), new Fixture(TemplateFormatType.TEMPLATE_LLI, new String[] {
				"LLI"
			}), new Fixture(TemplateFormatType.TEMPLATE_LLIS, new String[] {
				"LLIS"
			}), new Fixture(TemplateFormatType.TEMPLATE_LLIM, new String[] {
				"LLIM"
			}), new Fixture(TemplateFormatType.TEMPLATE_LLIX, new String[] {
				"LLIX"
			}), new Fixture(TemplateFormatType.TEMPLATE_LIP, new String[] {
				"LIP"
			}), new Fixture(TemplateFormatType.TEMPLATE_LLIP, new String[] {
				"LLIP"
			}), new Fixture(TemplateFormatType.TEMPLATE_TLIP, new String[] {
				"TLIP"
			}), new Fixture(TemplateFormatType.TEMPLATE_FI, new String[] {
				"FI_"
			}), new Fixture(TemplateFormatType.TEMPLATE_II, new String[] {
				"II"
			}),
		};

		public static class Fixture {
			public TemplateFormatType key;
			public String[] expected;

			Fixture(TemplateFormatType key, String[] expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedIntToTemplateFormatTypeHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(1, TemplateFormatType.TEMPLATE_RDBT),
			new Fixture(2, TemplateFormatType.TEMPLATE_RDBT),
			new Fixture(331, TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture(332, TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture(3, TemplateFormatType.TEMPLATE_RDBL),
			new Fixture(4, TemplateFormatType.TEMPLATE_RDBL),
			new Fixture(323, TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture(324, TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture(333, TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture(334, TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture(341, TemplateFormatType.TEMPLATE_RDBLX),
			new Fixture(5, TemplateFormatType.TEMPLATE_PDB),
			new Fixture(335, TemplateFormatType.TEMPLATE_FDB),
			new Fixture(321, TemplateFormatType.TEMPLATE_LDB),
			new Fixture(322, TemplateFormatType.TEMPLATE_PLDB),
			new Fixture(326, TemplateFormatType.TEMPLATE_LDBS),
			new Fixture(336, TemplateFormatType.TEMPLATE_LDBM),
			new Fixture(342, TemplateFormatType.TEMPLATE_LDBX),
		};

		public static class Fixture {
			public Integer key;
			public TemplateFormatType expected;

			Fixture(Integer key, TemplateFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedIntToFingerPrintTypeHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(1, FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture(2, FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture(331, FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture(332, FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture(3, FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture(4, FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture(323, FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture(324, FingerPrintType.FINGER_PRINT_SLAP),
			new Fixture(333, FingerPrintType.FINGER_PRINT_ROLLED),
			new Fixture(334, FingerPrintType.FINGER_PRINT_SLAP),
		};

		public static class Fixture {
			public Integer key;
			public FingerPrintType expected;

			Fixture(Integer key, FingerPrintType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToIntHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture("FDB_1", 1), new Fixture("FDB_2", 2), new Fixture("FDB_3", 3),
			new Fixture("FDB_4", 4), new Fixture("FDB_5", 5), new Fixture("FDB_6", 6),
			new Fixture("FDB_7", 7), new Fixture("FDB_8", 8), new Fixture("FDB_9", 9),
			new Fixture("FDB_10", 10), new Fixture("FI_1", 1), new Fixture("FI_2", 2),
			new Fixture("FI_3", 3), new Fixture("FI_4", 4), new Fixture("FI_5", 5),
			new Fixture("FI_6", 6), new Fixture("FI_7", 7), new Fixture("FI_8", 8),
			new Fixture("FI_9", 9), new Fixture("FI_10", 10),
		};

		public static class Fixture {
			public String key;
			public Integer expected;

			Fixture(String key, Integer expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedGenderEnumToGenderTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(GenderEnum.M, GenderType.GENDER_MALE),
			new Fixture(GenderEnum.F, GenderType.GENDER_FEMALE),
			new Fixture(GenderEnum.U, GenderType.GENDER_UNKNOWN),
		};

		public static class Fixture {
			public GenderEnum key;
			public GenderType expected;

			Fixture(GenderEnum key, GenderType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToRaceTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", RaceType.RACE_WHITE), new Fixture("2", RaceType.RACE_BLACK),
			new Fixture("4", RaceType.RACE_AMERICAN_INDIAN),
			new Fixture("8", RaceType.RACE_ASIAN),
			new Fixture("-1", RaceType.RACE_UNKNOWN),
		};

		public static class Fixture {
			public String key;
			public RaceType expected;

			Fixture(String key, RaceType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedByteToRegionCodeTypeHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture('1', RegionCodeType.REGION_CODE_1),
			new Fixture('2', RegionCodeType.REGION_CODE_2),
			new Fixture('3', RegionCodeType.REGION_CODE_3),
			new Fixture('4', RegionCodeType.REGION_CODE_4),
			new Fixture('5', RegionCodeType.REGION_CODE_5),
			new Fixture('6', RegionCodeType.REGION_CODE_6),
			new Fixture('7', RegionCodeType.REGION_CODE_7),
			new Fixture('8', RegionCodeType.REGION_CODE_8),
			new Fixture('9', RegionCodeType.REGION_CODE_9),
			new Fixture('A', RegionCodeType.REGION_CODE_A),
			new Fixture('B', RegionCodeType.REGION_CODE_B),
			new Fixture('C', RegionCodeType.REGION_CODE_C),
			new Fixture('D', RegionCodeType.REGION_CODE_D),
			new Fixture('E', RegionCodeType.REGION_CODE_E),
			new Fixture('F', RegionCodeType.REGION_CODE_F),
			new Fixture('U', RegionCodeType.REGION_CODE_UNKNOWN),
		};

		public static class Fixture {
			public Character key;
			public RegionCodeType expected;

			Fixture(Character key, RegionCodeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedByteToFingerPatternTypeHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture('A', FingerPatternType.FINGER_PATTERN_ARCH),
			new Fixture('L', FingerPatternType.FINGER_PATTERN_LEFTLOOP),
			new Fixture('R', FingerPatternType.FINGER_PATTERN_RIGHTLOOP),
			new Fixture('W', FingerPatternType.FINGER_PATTERN_WHORL),
			new Fixture('S', FingerPatternType.FINGER_PATTERN_SCAR),
			new Fixture('U', FingerPatternType.FINGER_PATTERN_UNKNOWN),
			new Fixture('*', FingerPatternType.FINGER_PATTERN_NONE),
		};

		public static class Fixture {
			public Character key;
			public FingerPatternType expected;

			Fixture(Character key, FingerPatternType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedIntToFingerPositionBaseTypeHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(1, FingerPositionBaseType.RIGHT_THUMB),
			new Fixture(2, FingerPositionBaseType.RIGHT_INDEX),
			new Fixture(3, FingerPositionBaseType.RIGHT_MIDDLE),
			new Fixture(4, FingerPositionBaseType.RIGHT_RING),
			new Fixture(5, FingerPositionBaseType.RIGHT_LITTLE),
			new Fixture(6, FingerPositionBaseType.LEFT_THUMB),
			new Fixture(7, FingerPositionBaseType.LEFT_INDEX),
			new Fixture(8, FingerPositionBaseType.LEFT_MIDDLE),
			new Fixture(9, FingerPositionBaseType.LEFT_RING),
			new Fixture(10, FingerPositionBaseType.LEFT_LITTLE),
		};

		public static class Fixture {
			public Integer key;
			public FingerPositionBaseType expected;

			Fixture(Integer key, FingerPositionBaseType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedByteToPalmPositionTypeHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture('0', PalmPositionType.PALM_UNKNOWN),
			new Fixture('1', PalmPositionType.PALM_RIGHT_FULL),
			new Fixture('2', PalmPositionType.PALM_RIGHT_WRITER),
			new Fixture('3', PalmPositionType.PALM_LEFT_FULL),
			new Fixture('4', PalmPositionType.PALM_LEFT_WRITER),
			new Fixture('5', PalmPositionType.PALM_RIGHT_LOWER),
			new Fixture('6', PalmPositionType.PALM_RIGHT_UPPER),
			new Fixture('7', PalmPositionType.PALM_LEFT_LOWER),
			new Fixture('8', PalmPositionType.PALM_LEFT_UPPER),
			new Fixture('9', PalmPositionType.PALM_RIGHT_OTHER),
			new Fixture('A', PalmPositionType.PALM_LEFT_OTHER),
			new Fixture('B', PalmPositionType.PALM_RIGHT_INTERDIGITAL),
			new Fixture('C', PalmPositionType.PALM_RIGHT_THENAR),
			new Fixture('D', PalmPositionType.PALM_RIGHT_HYPOTHENAR),
			new Fixture('E', PalmPositionType.PALM_LEFT_INTERDIGITAL),
			new Fixture('F', PalmPositionType.PALM_LEFT_THENAR),
			new Fixture('G', PalmPositionType.PALM_LEFT_HYPOTHENAR),
		};

		public static class Fixture {
			public Character key;
			public PalmPositionType expected;

			Fixture(Character key, PalmPositionType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToFilterModeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("0", FilterModeType.NO_FILTER),
			new Fixture("1", FilterModeType.PATTERN_ONLY),
			new Fixture("2", FilterModeType.GENDER_ONLY),
			new Fixture("3", FilterModeType.PATTERN_GENDER),
			new Fixture("4", FilterModeType.YOB_ONLY),
			new Fixture("5", FilterModeType.PATTERN_YOB),
			new Fixture("6", FilterModeType.GENDER_YOB),
			new Fixture("7", FilterModeType.PATTERN_GENDER_YOB),
		};

		public static class Fixture {
			public String key;
			public FilterModeType expected;

			Fixture(String key, FilterModeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToFingerSelectionModeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", FingerSelectionModeType.FIXED_1_FINGER),
			new Fixture("2", FingerSelectionModeType.FIXED_2_FINGERS),
			new Fixture("3", FingerSelectionModeType.FIXED_3_FINGERS),
			new Fixture("19", FingerSelectionModeType.FIXED_4_FINGERS),
			new Fixture("20", FingerSelectionModeType.FIXED_5_FINGERS),
			new Fixture("21", FingerSelectionModeType.FIXED_6_FINGERS),
			new Fixture("27", FingerSelectionModeType.FIXED_7_FINGERS),
			new Fixture("28", FingerSelectionModeType.FIXED_8_FINGERS),
			new Fixture("29", FingerSelectionModeType.FIXED_9_FINGERS),
			new Fixture("4", FingerSelectionModeType.AVG_1_2_FINGERS),
			new Fixture("5", FingerSelectionModeType.AVG_1_5_FINGERS),
			new Fixture("6", FingerSelectionModeType.AVG_1_8_FINGERS),
			new Fixture("7", FingerSelectionModeType.AVG_2_0_FINGERS),
			new Fixture("8", FingerSelectionModeType.AVG_2_2_FINGERS),
			new Fixture("9", FingerSelectionModeType.AVG_2_5_FINGERS),
			new Fixture("10", FingerSelectionModeType.AVG_2_6_FINGERS),
			new Fixture("11", FingerSelectionModeType.AVG_2_8_FINGERS),
			new Fixture("12", FingerSelectionModeType.AVG_3_0_FINGERS),
			new Fixture("13", FingerSelectionModeType.AVG_3_5_FINGERS),
			new Fixture("22", FingerSelectionModeType.AVG_4_0_FINGERS),
			new Fixture("23", FingerSelectionModeType.AVG_4_5_FINGERS),
			new Fixture("24", FingerSelectionModeType.AVG_5_0_FINGERS),
			new Fixture("25", FingerSelectionModeType.AVG_5_5_FINGERS),
			new Fixture("26", FingerSelectionModeType.AVG_6_0_FINGERS),
			new Fixture("30", FingerSelectionModeType.AVG_7_0_FINGERS),
			new Fixture("31", FingerSelectionModeType.AVG_8_0_FINGERS),
			new Fixture("32", FingerSelectionModeType.AVG_9_0_FINGERS),
			new Fixture("15", FingerSelectionModeType.PRIORITY_1_6),
			new Fixture("16", FingerSelectionModeType.DIFFERENT_HAND_SAME_FINGER),
			new Fixture("17", FingerSelectionModeType.SAME_HAND_DIFFERENT_FINGER),
			new Fixture("18", FingerSelectionModeType.DIFFERENT_HAND_DIFFERENT_FINGER),
			new Fixture("14", FingerSelectionModeType.COLD_SEARCH),
		};

		public static class Fixture {
			public String key;
			public FingerSelectionModeType expected;

			Fixture(String key, FingerSelectionModeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToYobMethodTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("0", PrefilterYobMethodType.YOB_METHOD_RANGE),
			new Fixture("1", PrefilterYobMethodType.YOB_METHOD_THRESHOLD),
		};

		public static class Fixture {
			public String key;
			public PrefilterYobMethodType expected;

			Fixture(String key, PrefilterYobMethodType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToPc2SpeedLevelTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", Pc2SpeedLevelType.PC2_SPEED_LEVEL_1),
			new Fixture("2", Pc2SpeedLevelType.PC2_SPEED_LEVEL_2),
			new Fixture("3", Pc2SpeedLevelType.PC2_SPEED_LEVEL_3),
			new Fixture("4", Pc2SpeedLevelType.PC2_SPEED_LEVEL_4),
			new Fixture("5", Pc2SpeedLevelType.PC2_SPEED_LEVEL_5),
			new Fixture("6", Pc2SpeedLevelType.PC2_SPEED_LEVEL_6),
			new Fixture("7", Pc2SpeedLevelType.PC2_SPEED_LEVEL_7),
			new Fixture("8", Pc2SpeedLevelType.PC2_SPEED_LEVEL_8),
			new Fixture("9", Pc2SpeedLevelType.PC2_SPEED_LEVEL_9),
		};

		public static class Fixture {
			public String key;
			public Pc2SpeedLevelType expected;

			Fixture(String key, Pc2SpeedLevelType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToPc2RotationLimitTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", Pc2RotationLimitType.PC2_ROTATION_DEGREE_15),
			new Fixture("2", Pc2RotationLimitType.PC2_ROTATION_DEGREE_30),
			new Fixture("3", Pc2RotationLimitType.PC2_ROTATION_DEGREE_60),
			new Fixture("4", Pc2RotationLimitType.PC2_ROTATION_DEGREE_180),
		};

		public static class Fixture {
			public String key;
			public Pc2RotationLimitType expected;

			Fixture(String key, Pc2RotationLimitType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToPc2DistortionLevelTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_1),
			new Fixture("2", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_2),
			new Fixture("3", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_3),
			new Fixture("4", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_4),
			new Fixture("5", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_5),
			new Fixture("6", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_6),
		};

		public static class Fixture {
			public String key;
			public Pc2DistortionLevelType expected;

			Fixture(String key, Pc2DistortionLevelType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToLeAlgorithmTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", LeAlgorithmType.LE_ALGORITHM_STANDARD),
			new Fixture("2", LeAlgorithmType.LE_ALGORITHM_ELMA_A),
			new Fixture("3", LeAlgorithmType.LE_ALGORITHM_ELMA_B),
		};

		public static class Fixture {
			public String key;
			public LeAlgorithmType expected;

			Fixture(String key, LeAlgorithmType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToLeRotationLimitTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", LeRotationLimitType.LE_ROTATION_DEGREE_15),
			new Fixture("2", LeRotationLimitType.LE_ROTATION_DEGREE_30),
			new Fixture("3", LeRotationLimitType.LE_ROTATION_DEGREE_45),
			new Fixture("4", LeRotationLimitType.LE_ROTATION_DEGREE_NO_LIMIT),
		};

		public static class Fixture {
			public String key;
			public LeRotationLimitType expected;

			Fixture(String key, LeRotationLimitType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToLeCorePositionTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", LeCorePositionType.LE_CORE_POSITION_STANDARD),
			new Fixture("2", LeCorePositionType.LE_CORE_POSITION_SEMI_LOOSE),
			new Fixture("3", LeCorePositionType.LE_CORE_POSITION_LOOSE),
			new Fixture("4", LeCorePositionType.LE_CORE_POSITION_NO_CORE),
		};

		public static class Fixture {
			public String key;
			public LeCorePositionType expected;

			Fixture(String key, LeCorePositionType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToPalmRotationLimitTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", PalmRotationLimitType.PALM_ROTATION_DEGREE_30),
			new Fixture("2", PalmRotationLimitType.PALM_ROTATION_DEGREE_60),
			new Fixture("3", PalmRotationLimitType.PALM_ROTATION_DEGREE_90),
			new Fixture("4", PalmRotationLimitType.PALM_ROTATION_DEGREE_180),
		};

		public static class Fixture {
			public String key;
			public PalmRotationLimitType expected;

			Fixture(String key, PalmRotationLimitType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToCmlafSearchModeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", CMLaFSearchModeType.NORMAL_MODE),
			new Fixture("2", CMLaFSearchModeType.SPEED_MODE),
			new Fixture("3", CMLaFSearchModeType.ACCURATE_MODE),
		};

		public static class Fixture {
			public String key;
			public CMLaFSearchModeType expected;

			Fixture(String key, CMLaFSearchModeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToTimPc2RotationLimitTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", Pc2RotationLimitType.PC2_ROTATION_DEGREE_15),
			new Fixture("2", Pc2RotationLimitType.PC2_ROTATION_DEGREE_30),
			new Fixture("3", Pc2RotationLimitType.PC2_ROTATION_DEGREE_45),
			new Fixture("4", Pc2RotationLimitType.PC2_ROTATION_DEGREE_60),
			new Fixture("5", Pc2RotationLimitType.PC2_ROTATION_DEGREE_180),
		};

		public static class Fixture {
			public String key;
			public Pc2RotationLimitType expected;

			Fixture(String key, Pc2RotationLimitType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedLfmlSearchLevelToLfmlSearchLevelTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(LfmlSearchLevel.SEARCH_LEVEL_1,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_1),
			new Fixture(LfmlSearchLevel.SEARCH_LEVEL_2,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_2),
			new Fixture(LfmlSearchLevel.SEARCH_LEVEL_3,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_3),
			new Fixture(LfmlSearchLevel.SEARCH_LEVEL_4,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_4),
			new Fixture(LfmlSearchLevel.SEARCH_LEVEL_5,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_5),
		};

		public static class Fixture {
			public LfmlSearchLevel key;
			public LfmlSearchLevelType expected;

			Fixture(LfmlSearchLevel key, LfmlSearchLevelType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedJobStateTypeToJobStateEnumHelper {
		public static Fixture[] fixtures = {
			new Fixture(JobStateType.JOB_STATE_QUEUED, JobStateEnum.QUEUED),
			new Fixture(JobStateType.JOB_STATE_WORKING, JobStateEnum.WORKING),
			new Fixture(JobStateType.JOB_STATE_DONE, JobStateEnum.DONE),
		};

		public static class Fixture {
			public JobStateType key;
			public JobStateEnum expected;

			Fixture(JobStateType key, JobStateEnum expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFingerAxisTypeToAxisEnumHelper {
		public static Fixture[] fixtures = {
			new Fixture(FingerAxisType.FINGER_AXIS_A, AxisEnum.A),
			new Fixture(FingerAxisType.FINGER_AXIS_B, AxisEnum.B),
			new Fixture(FingerAxisType.FINGER_AXIS_C, AxisEnum.C),
			new Fixture(FingerAxisType.FINGER_AXIS_D, AxisEnum.D),
		};

		public static class Fixture {
			public FingerAxisType key;
			public AxisEnum expected;

			Fixture(FingerAxisType key, AxisEnum expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFingerSetTypeToInquirySetEnumHelper {
		public static Fixture[] fixtures = {
			new Fixture(FingerSetType.PC2_ROLLED, InquirySetEnum.PC_2_ROLLED),
			new Fixture(FingerSetType.PC2_SLAP, InquirySetEnum.PC_2_SLAP),
			new Fixture(FingerSetType.PC2_LATENT, InquirySetEnum.PC_2_LATENT),
			new Fixture(FingerSetType.FMP5_ROLLED, InquirySetEnum.FMP_5_ROLLED),
			new Fixture(FingerSetType.FMP5_SLAP, InquirySetEnum.FMP_5_SLAP),
			new Fixture(FingerSetType.FMP5_LATENT, InquirySetEnum.FMP_5_LATENT),
		};

		public static class Fixture {
			public FingerSetType key;
			public InquirySetEnum expected;

			Fixture(FingerSetType key, InquirySetEnum expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedExtractionFormatsToTemplateFormatTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(ExtractionFormats.TR_RDBT, TemplateFormatType.TEMPLATE_RDBT),
			new Fixture(ExtractionFormats.TR_RDBT_M, TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture(ExtractionFormats.TR_XDBL, TemplateFormatType.TEMPLATE_RDBLX),
			new Fixture(ExtractionFormats.LR, TemplateFormatType.TEMPLATE_LDB),
			new Fixture(ExtractionFormats.LR_P, TemplateFormatType.TEMPLATE_PLDB),
			new Fixture(ExtractionFormats.LR_S, TemplateFormatType.TEMPLATE_LDBS),
			new Fixture(ExtractionFormats.LR_M, TemplateFormatType.TEMPLATE_LDBM),
			new Fixture(ExtractionFormats.LR_X, TemplateFormatType.TEMPLATE_LDBX),
			new Fixture(ExtractionFormats.TR_RDBL, TemplateFormatType.TEMPLATE_RDBL),
			new Fixture(ExtractionFormats.TR_RDBL_S, TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture(ExtractionFormats.TR_RDBL_M, TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture(ExtractionFormats.TR_P, TemplateFormatType.TEMPLATE_PDB),
			new Fixture(ExtractionFormats.FR_FDB, TemplateFormatType.TEMPLATE_FDB),
			new Fixture(ExtractionFormats.TI, TemplateFormatType.TEMPLATE_TI),
			new Fixture(ExtractionFormats.TI_M, TemplateFormatType.TEMPLATE_TIM),
			new Fixture(ExtractionFormats.TLI, TemplateFormatType.TEMPLATE_TLI),
			new Fixture(ExtractionFormats.TLI_S, TemplateFormatType.TEMPLATE_TLIS),
			new Fixture(ExtractionFormats.TLI_M, TemplateFormatType.TEMPLATE_TLIM),
			new Fixture(ExtractionFormats.TLI_X, TemplateFormatType.TEMPLATE_TLIX),
			new Fixture(ExtractionFormats.LI, TemplateFormatType.TEMPLATE_LI),
			new Fixture(ExtractionFormats.LI_S, TemplateFormatType.TEMPLATE_LIS),
			new Fixture(ExtractionFormats.LI_M, TemplateFormatType.TEMPLATE_LIM),
			new Fixture(ExtractionFormats.LI_X, TemplateFormatType.TEMPLATE_LIX),
			new Fixture(ExtractionFormats.LLI, TemplateFormatType.TEMPLATE_LLI),
			new Fixture(ExtractionFormats.LLI_S, TemplateFormatType.TEMPLATE_LLIS),
			new Fixture(ExtractionFormats.LLI_M, TemplateFormatType.TEMPLATE_LLIM),
			new Fixture(ExtractionFormats.LLI_X, TemplateFormatType.TEMPLATE_LLIX),
			new Fixture(ExtractionFormats.LI_P, TemplateFormatType.TEMPLATE_LIP),
			new Fixture(ExtractionFormats.LLI_P, TemplateFormatType.TEMPLATE_LLIP),
			new Fixture(ExtractionFormats.TLI_P, TemplateFormatType.TEMPLATE_TLIP),
			new Fixture(ExtractionFormats.FI, TemplateFormatType.TEMPLATE_FI),
			new Fixture(ExtractionFormats.II, TemplateFormatType.TEMPLATE_II),
			new Fixture(ExtractionFormats.IR_IDB, TemplateFormatType.TEMPLATE_IDB),
		};

		public static class Fixture {
			public ExtractionFormats key;
			public TemplateFormatType expected;

			Fixture(ExtractionFormats key, TemplateFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToFisTypeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("A", FisTypeType.FIS_TYPE_A),
			new Fixture("B", FisTypeType.FIS_TYPE_B),
			new Fixture("C", FisTypeType.FIS_TYPE_C),
			// new Fixture("D", FisTypeType.FIS_TYPE_D),
			new Fixture("E", FisTypeType.FIS_TYPE_E),
			new Fixture("F", FisTypeType.FIS_TYPE_F),
			new Fixture("P", FisTypeType.FIS_TYPE_P),
		};

		public static class Fixture {
			public String key;
			public FisTypeType expected;

			Fixture(String key, FisTypeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedPosToImagePositionTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("1", ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB),
			new Fixture("2", ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX),
			new Fixture("3", ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE),
			new Fixture("4", ImagePositionType.IMAGE_ROLLED_RIGHT_RING),
			new Fixture("5", ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE),
			new Fixture("6", ImagePositionType.IMAGE_ROLLED_LEFT_THUMB),
			new Fixture("7", ImagePositionType.IMAGE_ROLLED_LEFT_INDEX),
			new Fixture("8", ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE),
			new Fixture("9", ImagePositionType.IMAGE_ROLLED_LEFT_RING),
			new Fixture("10", ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE),
			new Fixture("11", ImagePositionType.IMAGE_SLAP_RIGHT_THUMB),
			new Fixture("40", ImagePositionType.IMAGE_SLAP_RIGHT_INDEX),
			new Fixture("41", ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE),
			new Fixture("42", ImagePositionType.IMAGE_SLAP_RIGHT_RING),
			new Fixture("43", ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE),
			new Fixture("12", ImagePositionType.IMAGE_SLAP_LEFT_THUMB),
			new Fixture("44", ImagePositionType.IMAGE_SLAP_LEFT_INDEX),
			new Fixture("45", ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE),
			new Fixture("46", ImagePositionType.IMAGE_SLAP_LEFT_RING),
			new Fixture("47", ImagePositionType.IMAGE_SLAP_LEFT_LITTLE),
			new Fixture("13", ImagePositionType.IMAGE_SLAP_RIGHT_FOUR),
			new Fixture("14", ImagePositionType.IMAGE_SLAP_LEFT_FOUR),
			new Fixture("15", ImagePositionType.IMAGE_SLAP_THUMBS),
			new Fixture("21", ImagePositionType.IMAGE_PALM_RIGHT_FULL),
			new Fixture("22", ImagePositionType.IMAGE_PALM_RIGHT_WRITER),
			new Fixture("23", ImagePositionType.IMAGE_PALM_LEFT_FULL),
			new Fixture("24", ImagePositionType.IMAGE_PALM_LEFT_WRITER),
			new Fixture("25", ImagePositionType.IMAGE_PALM_RIGHT_LOWER),
			new Fixture("26", ImagePositionType.IMAGE_PALM_RIGHT_UPPER),
			new Fixture("27", ImagePositionType.IMAGE_PALM_LEFT_LOWER),
			new Fixture("28", ImagePositionType.IMAGE_PALM_LEFT_UPPER),
			new Fixture("29", ImagePositionType.IMAGE_PALM_RIGHT_OTHER),
			new Fixture("30", ImagePositionType.IMAGE_PALM_LEFT_OTHER),
			new Fixture("31", ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL),
			new Fixture("32", ImagePositionType.IMAGE_PALM_RIGHT_THENAR),
			new Fixture("33", ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR),
			new Fixture("34", ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL),
			new Fixture("35", ImagePositionType.IMAGE_PALM_LEFT_THENAR),
			new Fixture("36", ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR),
			new Fixture("15", ImagePositionType.IMAGE_SLAP_THUMBS),
			new Fixture("60", ImagePositionType.IMAGE_IRIS_RIGHT),
			new Fixture("61", ImagePositionType.IMAGE_IRIS_LEFT),
		};

		public static class Fixture {
			public String key;
			public ImagePositionType expected;

			Fixture(String key, ImagePositionType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedImageFormatToImageFormatTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(ImageFormat.RAW, ImageFormatType.RAW),
			new Fixture(ImageFormat.WSQ, ImageFormatType.WSQ),
			new Fixture(ImageFormat.JPEG2000, ImageFormatType.JPEG2000),
			new Fixture(ImageFormat.JPEG, ImageFormatType.JPEG),
			new Fixture(ImageFormat.BMP, ImageFormatType.BMP),
			new Fixture(ImageFormat.PNG, ImageFormatType.PNG),
			new Fixture(ImageFormat.NECGRAY4, ImageFormatType.NECGRAY4),
			new Fixture(ImageFormat.WSQ4, ImageFormatType.WSQ4),
		};

		public static class Fixture {
			public ImageFormat key;
			public ImageFormatType expected;

			Fixture(ImageFormat key, ImageFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedWhiteBlackLevelToImageWhiteBlackLevelTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(WhiteBlackLevel.WHITELEVEL,
				ImageWhiteBlackLevelType.IMAGE_LEVEL_WHITE),
			new Fixture(WhiteBlackLevel.BLACKLEVEL,
				ImageWhiteBlackLevelType.IMAGE_LEVEL_BLACK),
		};

		public static class Fixture {
			public WhiteBlackLevel key;
			public ImageWhiteBlackLevelType expected;

			Fixture(WhiteBlackLevel key, ImageWhiteBlackLevelType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToMinutiaDbTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("RDBTM", MinutiaDbType.MINUTIA_DB_RDBTM),
			new Fixture("RDBLM", MinutiaDbType.MINUTIA_DB_RDBLM),
		};

		public static class Fixture {
			public String key;
			public MinutiaDbType expected;

			Fixture(String key, MinutiaDbType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToMinutiaTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture("FIS", MinutiaType.MINUTIA_FIS),
			new Fixture("PC2", MinutiaType.MINUTIA_PC2),
			new Fixture("BT5", MinutiaType.MINUTIA_BT5),
		};

		public static class Fixture {
			public String key;
			public MinutiaType expected;

			Fixture(String key, MinutiaType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedEnhTypeToBasicImageEnhganceTypeHelper {
		public static Fixture[] fixtures =
			{
				new Fixture(EnhType.ENH_SMOOTH,
					BasicImageEnhanceType.IMAGE_ENHANCE_SMOOTH),
				new Fixture(EnhType.ENH_AGC, BasicImageEnhanceType.IMAGE_ENHANCE_AGC),
				new Fixture(EnhType.ENH_HISTOGRAM,
					BasicImageEnhanceType.IMAGE_ENHANCE_HISTOGRAM),
				new Fixture(EnhType.ENH_VRP_TEN,
					BasicImageEnhanceType.IMAGE_ENHANCE_VRP_TENPRINT),
				new Fixture(EnhType.ENH_VRP_LAT,
					BasicImageEnhanceType.IMAGE_ENHANCE_VRP_LATENT),
				new Fixture(EnhType.ENH_ENHANCE,
					BasicImageEnhanceType.IMAGE_ENHANCE_ENHANCE),
				new Fixture(EnhType.ENH_DEINTERLACE,
					BasicImageEnhanceType.IMAGE_ENHANCE_DEINTERLACE),
			};

		public static class Fixture {
			public EnhType key;
			public BasicImageEnhanceType expected;

			Fixture(EnhType key, BasicImageEnhanceType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedQcModeToQualityCheckModeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(QcMode.QC_MODE_OFF, QualityCheckModeType.QC_MODE_OFF),
			new Fixture(QcMode.QC_MODE_NORMAL, QualityCheckModeType.QC_MODE_STANDARD),
			new Fixture(QcMode.QC_MODE_ADVANCED, QualityCheckModeType.QC_MODE_ADVANCED),
		};

		public static class Fixture {
			public QcMode key;
			public QualityCheckModeType expected;

			Fixture(QcMode key, QualityCheckModeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedIntToCmlafFeTypeTypeHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(2, CMLaFFeTypeType.CMLAF_FE_TYPE_B),
			new Fixture(3, CMLaFFeTypeType.CMLAF_FE_TYPE_E),
			new Fixture(9, CMLaFFeTypeType.CMLAF_FE_TYPE_FE),
		};

		public static class Fixture {
			public Integer key;
			public CMLaFFeTypeType expected;

			Fixture(Integer key, CMLaFFeTypeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedCmlafEnhTypeToCmlafImageEnhganceTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(CmlafEnhType.CMLaF_ENH_G,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_G),
			new Fixture(CmlafEnhType.CMLaF_ENH_R,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_R),
			new Fixture(CmlafEnhType.CMLaF_ENH_C,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_C),
			new Fixture(CmlafEnhType.CMLaF_ENH_C2,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_C2),
			new Fixture(CmlafEnhType.CMLaF_ENH_L,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_L),
			new Fixture(CmlafEnhType.CMLaF_ENH_L2,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_L2),
			new Fixture(CmlafEnhType.CMLaF_ENH_H,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_H),
			new Fixture(CmlafEnhType.CMLaF_ENH_E,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_E),
			new Fixture(CmlafEnhType.CMLaF_ENH_A,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_A),
			new Fixture(CmlafEnhType.CMLaF_ENH_NO,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_NO),
		};

		public static class Fixture {
			public CmlafEnhType key;
			public CMLaFImageEnhanceType expected;

			Fixture(CmlafEnhType key, CMLaFImageEnhanceType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedExtInfoModeFormatToExtractOutputModeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(ExtInfoModeFormat.EXTINFO_TEMPLATE_AND_RESULTINFO,
				ExtractOutputModeType.EXTRACT_OUTPUT_MODE_ALL),
			new Fixture(ExtInfoModeFormat.EXTINFO_TEMPLATE,
				ExtractOutputModeType.EXTRACT_OUTPUT_MODE_TEMPLATE),
			new Fixture(ExtInfoModeFormat.EXTINFO_RESULTINFO,
				ExtractOutputModeType.EXTRACT_OUTPUT_MODE_INFO),
		};

		public static class Fixture {
			public ExtInfoModeFormat key;
			public ExtractOutputModeType expected;

			Fixture(ExtInfoModeFormat key, ExtractOutputModeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFaceProcessModeToFaceExtractProcessTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(FaceProcessMode.DETECTION,
				FaceExtractProcessType.FACE_EXTRACT_PROCESS_DETECTION),
			new Fixture(FaceProcessMode.DETECTION_EXTRACTION,
				FaceExtractProcessType.FACE_EXTRACT_PROCESS_DETECTION_EXTRACTION),
			new Fixture(FaceProcessMode.EXTRACTION,
				FaceExtractProcessType.FACE_EXTRACT_PROCESS_EXTRATION),
		};

		public static class Fixture {
			public FaceProcessMode key;
			public FaceExtractProcessType expected;

			Fixture(FaceProcessMode key, FaceExtractProcessType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedDetectionModeToFaceDetectionModeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(DetectionMode.REPEAT,
				FaceDetectionModeType.FACE_DETECTION_MODE_REPEAT),
			new Fixture(DetectionMode.NO, FaceDetectionModeType.FACE_DETECTION_MODE_NO),
		};

		public static class Fixture {
			public DetectionMode key;
			public FaceDetectionModeType expected;

			Fixture(DetectionMode key, FaceDetectionModeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedSortingOrderToFaceDetectionSortingOrderTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(SortingOrder.DETECTION_SCORE,
				FaceDetectionSortingOrderType.FACE_DETECTION_SORTING_ORDER_SCORE),
			new Fixture(SortingOrder.FACE_SIZE,
				FaceDetectionSortingOrderType.FACE_DETECTION_SORTING_ORDER_SIZE),
		};

		public static class Fixture {
			public SortingOrder key;
			public FaceDetectionSortingOrderType expected;

			Fixture(SortingOrder key, FaceDetectionSortingOrderType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedDetectionAlgorithmToFaceDetectionAlgorithmTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(DetectionAlgorithm.D3,
				FaceDetectionAlgorithmType.FACE_DETECTION_ALGORITHM_D3),
			new Fixture(DetectionAlgorithm.D4,
				FaceDetectionAlgorithmType.FACE_DETECTION_ALGORITHM_D4),
			new Fixture(DetectionAlgorithm.D8,
				FaceDetectionAlgorithmType.FACE_DETECTION_ALGORITHM_D8),
		};

		public static class Fixture {
			public DetectionAlgorithm key;
			public FaceDetectionAlgorithmType expected;

			Fixture(DetectionAlgorithm key, FaceDetectionAlgorithmType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFaceRotationToListFaceDetectionRotationTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(FaceRotation.DEGREE_0, Arrays
				.asList(FaceDetectionRotationType.FACE_DETECTION_ROTATION_0)),
			new Fixture(FaceRotation.DEGREE_90, Arrays
				.asList(FaceDetectionRotationType.FACE_DETECTION_ROTATION_90)),
			new Fixture(FaceRotation.DEGREE_0_90, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_90)),
			new Fixture(FaceRotation.DEGREE_180, Arrays
				.asList(FaceDetectionRotationType.FACE_DETECTION_ROTATION_180)),
			new Fixture(FaceRotation.DEGREE_0_180, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_180)),
			new Fixture(FaceRotation.DEGREE_90_180, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_180)),
			new Fixture(FaceRotation.DEGREE_0_90_180, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_180)),
			new Fixture(FaceRotation.DEGREE_270, Arrays
				.asList(FaceDetectionRotationType.FACE_DETECTION_ROTATION_270)),
			new Fixture(FaceRotation.DEGREE_0_270, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_270)),
			new Fixture(FaceRotation.DEGREE_90_270, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_270)),
			new Fixture(FaceRotation.DEGREE_0_90_270, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_270)),
			new Fixture(FaceRotation.DEGREE_180_270, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_180,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_270)),
			new Fixture(FaceRotation.DEGREE_0_180_270, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_180,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_270)),
			new Fixture(FaceRotation.DEGREE_90_180_270, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_180,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_270)),
			new Fixture(FaceRotation.DEGREE_0_90_180_270, Arrays.asList(
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_180,
				FaceDetectionRotationType.FACE_DETECTION_ROTATION_270)),
		};

		public static class Fixture {
			public FaceRotation key;
			public List<FaceDetectionRotationType> expected;

			Fixture(FaceRotation key, List<FaceDetectionRotationType> expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedShrinkFactorToFaceDetectionShrinkFactorTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(ShrinkFactor.NO_SHRINK,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_ORIGINAL),
			new Fixture(ShrinkFactor.A_HALF,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_HALF),
			new Fixture(ShrinkFactor.A_QUARTER,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_ONE_4TH),
			new Fixture(ShrinkFactor.A_EIGHTHS,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_ONE_8TH),
			new Fixture(ShrinkFactor.A_SIXTEENTHS,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_ONE_16TH),
		};

		public static class Fixture {
			public ShrinkFactor key;
			public FaceDetectionShrinkFactorType expected;

			Fixture(ShrinkFactor key, FaceDetectionShrinkFactorType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedImagePositionTypeToIntKeyHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB, 1),
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX, 2),
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE, 3),
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_RING, 4),
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE, 5),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_THUMB, 6),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_INDEX, 7),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE, 8),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_RING, 9),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE, 10),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB, 1),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_INDEX, 2),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE, 3),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_RING, 4),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE, 5),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_THUMB, 6),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_INDEX, 7),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE, 8),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_RING, 9),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_LITTLE, 10),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_FULL, 1),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_WRITER, 2),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_FULL, 3),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_WRITER, 4),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_LOWER, 5),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_UPPER, 6),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_LOWER, 7),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_UPPER, 8),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_OTHER, 9),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_OTHER, 10),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL, 11),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_THENAR, 12),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR, 13),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL, 14),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_THENAR, 15),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR, 16),
		};

		public static class Fixture {
			public ImagePositionType key;
			public Integer expected;

			Fixture(ImagePositionType key, Integer expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFingerPositionTypeToIntHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(FingerPositionType.ROLLED_RIGHT_THUMB, 1),
			new Fixture(FingerPositionType.ROLLED_RIGHT_INDEX, 2),
			new Fixture(FingerPositionType.ROLLED_RIGHT_MIDDLE, 3),
			new Fixture(FingerPositionType.ROLLED_RIGHT_RING, 4),
			new Fixture(FingerPositionType.ROLLED_RIGHT_LITTLE, 5),
			new Fixture(FingerPositionType.ROLLED_LEFT_THUMB, 6),
			new Fixture(FingerPositionType.ROLLED_LEFT_INDEX, 7),
			new Fixture(FingerPositionType.ROLLED_LEFT_MIDDLE, 8),
			new Fixture(FingerPositionType.ROLLED_LEFT_RING, 9),
			new Fixture(FingerPositionType.ROLLED_LEFT_LITTLE, 10),
			new Fixture(FingerPositionType.SLAP_RIGHT_THUMB, 11),
			new Fixture(FingerPositionType.SLAP_RIGHT_INDEX, 40),
			new Fixture(FingerPositionType.SLAP_RIGHT_MIDDLE, 41),
			new Fixture(FingerPositionType.SLAP_RIGHT_RING, 42),
			new Fixture(FingerPositionType.SLAP_RIGHT_LITTLE, 43),
			new Fixture(FingerPositionType.SLAP_LEFT_THUMB, 12),
			new Fixture(FingerPositionType.SLAP_LEFT_INDEX, 44),
			new Fixture(FingerPositionType.SLAP_LEFT_MIDDLE, 45),
			new Fixture(FingerPositionType.SLAP_LEFT_RING, 46),
			new Fixture(FingerPositionType.SLAP_LEFT_LITTLE, 47),
		};

		public static class Fixture {
			public FingerPositionType key;
			public Integer expected;

			Fixture(FingerPositionType key, Integer expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFingerPositionTypeToStringHelper {
		public static Fixture[] fixtures = {
			new Fixture(FingerPositionType.ROLLED_RIGHT_THUMB, "1"),
			new Fixture(FingerPositionType.ROLLED_RIGHT_INDEX, "2"),
			new Fixture(FingerPositionType.ROLLED_RIGHT_MIDDLE, "3"),
			new Fixture(FingerPositionType.ROLLED_RIGHT_RING, "4"),
			new Fixture(FingerPositionType.ROLLED_RIGHT_LITTLE, "5"),
			new Fixture(FingerPositionType.ROLLED_LEFT_THUMB, "6"),
			new Fixture(FingerPositionType.ROLLED_LEFT_INDEX, "7"),
			new Fixture(FingerPositionType.ROLLED_LEFT_MIDDLE, "8"),
			new Fixture(FingerPositionType.ROLLED_LEFT_RING, "9"),
			new Fixture(FingerPositionType.ROLLED_LEFT_LITTLE, "10"),
			new Fixture(FingerPositionType.SLAP_RIGHT_THUMB, "11"),
			new Fixture(FingerPositionType.SLAP_RIGHT_INDEX, "12"),
			new Fixture(FingerPositionType.SLAP_RIGHT_MIDDLE, "13"),
			new Fixture(FingerPositionType.SLAP_RIGHT_RING, "14"),
			new Fixture(FingerPositionType.SLAP_RIGHT_LITTLE, "15"),
			new Fixture(FingerPositionType.SLAP_LEFT_THUMB, "16"),
			new Fixture(FingerPositionType.SLAP_LEFT_INDEX, "17"),
			new Fixture(FingerPositionType.SLAP_LEFT_MIDDLE, "18"),
			new Fixture(FingerPositionType.SLAP_LEFT_RING, "19"),
			new Fixture(FingerPositionType.SLAP_LEFT_LITTLE, "20"),
			new Fixture(FingerPositionType.FINGER_AMPUTATED, "*"),
			new Fixture(FingerPositionType.FINGER_UNKNOWN, "?"),
		};

		public static class Fixture {
			public FingerPositionType key;
			public String expected;

			Fixture(FingerPositionType key, String expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedQualityCheckAdvancedActivityTypeToQcActivityHelper {
		public static Fixture[] fixtures =
			{
				new Fixture(
					QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_DUPLICATE,
					QcActivity.SLAP_DUPLICATE),
				new Fixture(
					QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_RIGHT_4FINGERS,
					QcActivity.SLAP_RIGHT_4_FINGERS),
				new Fixture(
					QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_RIGHT_4CONFIDENCE,
					QcActivity.SLAP_RIGHT_4_CONFIDENCE),
				new Fixture(
					QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_LEFT_4FINGERS,
					QcActivity.SLAP_LEFT_4_FINGERS),
				new Fixture(
					QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_LEFT_4CONFIDENCE,
					QcActivity.SLAP_LEFT_4_CONFIDENCE),
				new Fixture(
					QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_ROLLED_DUPLICATE,
					QcActivity.ROLLED_DUPLICATE),
				new Fixture(
					QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_ROLLED_SEQUENCE,
					QcActivity.ROLLED_SEQUENCE),
				new Fixture(
					QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_ROLLED_QUALITY,
					QcActivity.ROLLED_QUALITY),
			};

		public static class Fixture {
			public QualityCheckAdvancedActivityType key;
			public QcActivity expected;

			Fixture(QualityCheckAdvancedActivityType key, QcActivity expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedQualityCheckAdvancedStateTypeToQcDetailStatusHelper {
		public static Fixture[] fixtures = {
			new Fixture(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NOT_AVAILABLE,
				QcDetailStatus.QC_STATE_NOT_AVAILABLE),
			new Fixture(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_OK,
				QcDetailStatus.QC_STATE_OK),
			new Fixture(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NG,
				QcDetailStatus.QC_STATE_NG),
			new Fixture(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NG_CORRECTED,
				QcDetailStatus.QC_STATE_NG_CORRECTED),
			new Fixture(
				QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NG_CORRECT_IMPOSSIBLE,
				QcDetailStatus.QC_STATE_NG_CORRECT_IMPOSSIBLE),
			new Fixture(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_UNKNOWN,
				QcDetailStatus.QC_STATE_UNKNOWN),
		};

		public static class Fixture {
			public QualityCheckAdvancedStateType key;
			public QcDetailStatus expected;

			Fixture(QualityCheckAdvancedStateType key, QcDetailStatus expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedProtoPsrTypeToJaxbPsrTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType.PSR_AC,
				jp.co.nec.aim.mm.jaxb.PsrType.AC),
			new Fixture(jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType.PSR_CMLaF,
				jp.co.nec.aim.mm.jaxb.PsrType.CM_LA_F),
		};

		public static class Fixture {
			public jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType key;
			public jp.co.nec.aim.mm.jaxb.PsrType expected;

			Fixture(jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType key,
				jp.co.nec.aim.mm.jaxb.PsrType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedImagePositionTypeToIntPositionHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB, 1),
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX, 2),
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE, 3),
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_RING, 4),
			new Fixture(ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE, 5),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_THUMB, 6),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_INDEX, 7),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE, 8),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_RING, 9),
			new Fixture(ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE, 10),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB, 11),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_INDEX, 40),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE, 41),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_RING, 42),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE, 43),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_THUMB, 12),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_INDEX, 44),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE, 45),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_RING, 46),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_LITTLE, 47),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_FULL, 21),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_WRITER, 22),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_FULL, 23),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_WRITER, 24),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_LOWER, 25),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_UPPER, 26),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_LOWER, 27),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_UPPER, 28),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_OTHER, 29),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_OTHER, 30),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL, 31),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_THENAR, 32),
			new Fixture(ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR, 33),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL, 34),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_THENAR, 35),
			new Fixture(ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR, 36),
			new Fixture(ImagePositionType.IMAGE_IRIS_RIGHT, 60),
			new Fixture(ImagePositionType.IMAGE_IRIS_LEFT, 61),
			new Fixture(ImagePositionType.IMAGE_SLAP_RIGHT_FOUR, 13),
			new Fixture(ImagePositionType.IMAGE_SLAP_LEFT_FOUR, 14),
			new Fixture(ImagePositionType.IMAGE_SLAP_THUMBS, 15),
		};

		public static class Fixture {
			public ImagePositionType key;
			public Integer expected;

			Fixture(ImagePositionType key, Integer expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFingerPatternTypeToStringHelper {
		public static Fixture[] fixtures = {
			new Fixture(FingerPatternType.FINGER_PATTERN_ARCH, "A"),
			new Fixture(FingerPatternType.FINGER_PATTERN_LEFTLOOP, "L"),
			new Fixture(FingerPatternType.FINGER_PATTERN_RIGHTLOOP, "R"),
			new Fixture(FingerPatternType.FINGER_PATTERN_WHORL, "W"),
			new Fixture(FingerPatternType.FINGER_PATTERN_SCAR, "S"),
			new Fixture(FingerPatternType.FINGER_PATTERN_UNKNOWN, "U"),
			new Fixture(FingerPatternType.FINGER_PATTERN_NONE, " "),
		};

		public static class Fixture {
			public FingerPatternType key;
			public String expected;

			Fixture(FingerPatternType key, String expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedMinutiaTypeToStringHelper {
		public static Fixture[] fixtures = {
			new Fixture(MinutiaType.MINUTIA_FIS, "FIS"),
			new Fixture(MinutiaType.MINUTIA_PC2, "PC2"),
			new Fixture(MinutiaType.MINUTIA_BT5, "BT5"),
			new Fixture(MinutiaType.MINUTIA_FMP5, "FMP5"),
			new Fixture(MinutiaType.MINUTIA_PZIP, "PZIP"),
			new Fixture(MinutiaType.MINUTIA_PC3R, "PC3R"),
		};

		public static class Fixture {
			public MinutiaType key;
			public String expected;

			Fixture(MinutiaType key, String expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedMinutiaDbTypeToStringHelper {
		public static Fixture[] fixtures = {
			new Fixture(MinutiaDbType.MINUTIA_DB_RDBT, "RDBT"),
			new Fixture(MinutiaDbType.MINUTIA_DB_RDBTM, "RDBTM"),
			new Fixture(MinutiaDbType.MINUTIA_DB_RDBL, "RDBL"),
			new Fixture(MinutiaDbType.MINUTIA_DB_RDBLS, "RDBLS"),
			new Fixture(MinutiaDbType.MINUTIA_DB_RDBLM, "RDBLM"),
			new Fixture(MinutiaDbType.MINUTIA_DB_LDB, "LDB"),
			new Fixture(MinutiaDbType.MINUTIA_DB_LDBS, "LDBS"),
			new Fixture(MinutiaDbType.MINUTIA_DB_PDB, "PDB"),
			new Fixture(MinutiaDbType.MINUTIA_DB_PLDB, "PLDB"),
		};

		public static class Fixture {
			public MinutiaDbType key;
			public String expected;

			Fixture(MinutiaDbType key, String expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedFisTypeTypeToStringHelper {
		public static Fixture[] fixtures = {
			new Fixture(FisTypeType.FIS_TYPE_A, "TYPE_A"),
			new Fixture(FisTypeType.FIS_TYPE_B, "TYPE_B"),
			new Fixture(FisTypeType.FIS_TYPE_C, "TYPE_C"),
			// new Fixture(FisTypeType.FIS_TYPE_D, "TYPE_D"),
			new Fixture(FisTypeType.FIS_TYPE_E, "TYPE_E"),
			new Fixture(FisTypeType.FIS_TYPE_F, "TYPE_F"),
			new Fixture(FisTypeType.FIS_TYPE_P, "TYPE_P"),
			new Fixture(FisTypeType.FIS_TYPE_CMLaF, "TYPE_CMLaF"),
			new Fixture(FisTypeType.FIS_TYPE_LFML, "TYPE_LFML"),
		};

		public static class Fixture {
			public FisTypeType key;
			public String expected;

			Fixture(FisTypeType key, String expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToListIntHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture("TI", new Integer[] {
				1, 2
			}), new Fixture("TI-M", new Integer[] {
				331, 332
			}), new Fixture("TLI", new Integer[] {
				321
			}), new Fixture("TLI-S", new Integer[] {
				326
			}), new Fixture("TLI-M", new Integer[] {
				336
			}), new Fixture("TLI-X", new Integer[] {
				342
			}), new Fixture("LI", new Integer[] {
				3, 4
			}), new Fixture("LI-S", new Integer[] {
				323, 324
			}), new Fixture("LI-M", new Integer[] {
				333, 334
			}), new Fixture("LI-X", new Integer[] {
				341
			}), new Fixture("LLI", new Integer[] {
				321
			}), new Fixture("LLI-S", new Integer[] {
				326
			}), new Fixture("LLI-M", new Integer[] {
				336
			}), new Fixture("LLI-X", new Integer[] {
				342
			}), new Fixture("LI-P", new Integer[] {
				5
			}), new Fixture("LLI-P", new Integer[] {
				322
			}), new Fixture("TLI-P", new Integer[] {
				322
			}), new Fixture("FI", new Integer[] {
				335
			}), new Fixture("II", new Integer[] {
				343
			}),
		};

		public static class Fixture {
			public String key;
			public Integer[] expected;

			Fixture(String key, Integer[] expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedInquirySetEnumToFingerSetTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(InquirySetEnum.PC_2_ROLLED, FingerSetType.PC2_ROLLED),
			new Fixture(InquirySetEnum.PC_2_SLAP, FingerSetType.PC2_SLAP),
			new Fixture(InquirySetEnum.PC_2_LATENT, FingerSetType.PC2_LATENT),
			new Fixture(InquirySetEnum.FMP_5_ROLLED, FingerSetType.FMP5_ROLLED),
			new Fixture(InquirySetEnum.FMP_5_SLAP, FingerSetType.FMP5_SLAP),
			new Fixture(InquirySetEnum.FMP_5_LATENT, FingerSetType.FMP5_LATENT),
		};

		public static class Fixture {
			public InquirySetEnum key;
			public FingerSetType expected;

			Fixture(InquirySetEnum key, FingerSetType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedIntToFingerPositionBaseTypeForSelectFingerHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(0, FingerPositionBaseType.RIGHT_THUMB),
			new Fixture(1, FingerPositionBaseType.RIGHT_INDEX),
			new Fixture(2, FingerPositionBaseType.RIGHT_MIDDLE),
			new Fixture(3, FingerPositionBaseType.RIGHT_RING),
			new Fixture(4, FingerPositionBaseType.RIGHT_LITTLE),
			new Fixture(5, FingerPositionBaseType.LEFT_THUMB),
			new Fixture(6, FingerPositionBaseType.LEFT_INDEX),
			new Fixture(7, FingerPositionBaseType.LEFT_MIDDLE),
			new Fixture(8, FingerPositionBaseType.LEFT_RING),
			new Fixture(9, FingerPositionBaseType.LEFT_LITTLE),

		};

		public static class Fixture {
			public Integer key;
			public FingerPositionBaseType expected;

			Fixture(Integer key, FingerPositionBaseType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToTemplateFormatTypeForInquiryHelper {
		public static Fixture[] fixtures = {
			new Fixture("TI_ROLLED", TemplateFormatType.TEMPLATE_TI),
			new Fixture("TI_SLAP", TemplateFormatType.TEMPLATE_TI),
			new Fixture("TIM_ROLLED", TemplateFormatType.TEMPLATE_TIM),
			new Fixture("TIM_SLAP", TemplateFormatType.TEMPLATE_TIM),
			new Fixture("TLI_ROLLED", TemplateFormatType.TEMPLATE_TLI),
			new Fixture("TLI_SLAP", TemplateFormatType.TEMPLATE_TLI),
			new Fixture("TLIS_ROLLED", TemplateFormatType.TEMPLATE_TLIS),
			new Fixture("TLIS_SLAP", TemplateFormatType.TEMPLATE_TLIS),
			new Fixture("TLIM_ROLLED", TemplateFormatType.TEMPLATE_TLIM),
			new Fixture("TLIM_SLAP", TemplateFormatType.TEMPLATE_TLIM),
			new Fixture("TLIX", TemplateFormatType.TEMPLATE_TLIX),
			new Fixture("LI", TemplateFormatType.TEMPLATE_LI),
			new Fixture("LIS", TemplateFormatType.TEMPLATE_LIS),
			new Fixture("LIM", TemplateFormatType.TEMPLATE_LIM),
			new Fixture("LIX", TemplateFormatType.TEMPLATE_LIX),
			new Fixture("LLI", TemplateFormatType.TEMPLATE_LLI),
			new Fixture("LLIS", TemplateFormatType.TEMPLATE_LLIS),
			new Fixture("LLIM", TemplateFormatType.TEMPLATE_LLIM),
			new Fixture("LLIX", TemplateFormatType.TEMPLATE_LLIX),
			new Fixture("LIP", TemplateFormatType.TEMPLATE_LIP),
			new Fixture("LLIP", TemplateFormatType.TEMPLATE_LLIP),
			new Fixture("TLIP", TemplateFormatType.TEMPLATE_TLIP),
			new Fixture("FI", TemplateFormatType.TEMPLATE_FI),
			new Fixture("II", TemplateFormatType.TEMPLATE_II),
		};

		public static class Fixture {
			public String key;
			public TemplateFormatType expected;

			Fixture(String key, TemplateFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedIntToStringHelper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			new Fixture(1, "RDBT"), new Fixture(2, "SDBT"), new Fixture(331, "RDBTM"),
			new Fixture(332, "SDBTM"), new Fixture(3, "RDBL_"), new Fixture(4, "SDBL_"),
			new Fixture(323, "RDBLS_"), new Fixture(324, "SDBLS_"),
			new Fixture(333, "RDBLM_"), new Fixture(334, "SDBLM_"),
			new Fixture(341, "XDBL"), new Fixture(5, "PDB_"), new Fixture(335, "FDB_"),
			new Fixture(321, "LDB"), new Fixture(322, "PLDB"), new Fixture(326, "LDBS"),
			new Fixture(336, "LDBM"), new Fixture(342, "LDBX"), new Fixture(343, "IDB"),
		};

		public static class Fixture {
			public Integer key;
			public String expected;

			Fixture(Integer key, String expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedLfmlRotationLimitToPc2RotationLimitTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(LfmlRotationLimit.ROTATION_DEGREE_15,
				Pc2RotationLimitType.PC2_ROTATION_DEGREE_15),
			new Fixture(LfmlRotationLimit.ROTATION_DEGREE_30,
				Pc2RotationLimitType.PC2_ROTATION_DEGREE_30),
			new Fixture(LfmlRotationLimit.ROTATION_DEGREE_60,
				Pc2RotationLimitType.PC2_ROTATION_DEGREE_60),
			new Fixture(LfmlRotationLimit.ROTATION_DEGREE_180,
				Pc2RotationLimitType.PC2_ROTATION_DEGREE_180),
		};

		public static class Fixture {
			public LfmlRotationLimit key;
			public Pc2RotationLimitType expected;

			Fixture(LfmlRotationLimit key, Pc2RotationLimitType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedLfmlSpeedLevelToPc2SpeedLevelTypeHelper {
		public static Fixture[] fixtures =
			{
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_1,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_1),
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_2,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_2),
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_3,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_3),
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_4,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_4),
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_5,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_5),
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_6,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_6),
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_7,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_7),
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_8,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_8),
				new Fixture(LfmlSpeedLevel.SPEED_LEVEL_9,
					Pc2SpeedLevelType.PC2_SPEED_LEVEL_9),
			};

		public static class Fixture {
			public LfmlSpeedLevel key;
			public Pc2SpeedLevelType expected;

			Fixture(LfmlSpeedLevel key, Pc2SpeedLevelType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedLfmlDistortionLevelToPc2DistortionLevelTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(LfmlDistortionLevel.DISTORTION_LEVEL_1,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_1),
			new Fixture(LfmlDistortionLevel.DISTORTION_LEVEL_2,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_2),
			new Fixture(LfmlDistortionLevel.DISTORTION_LEVEL_3,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_3),
			new Fixture(LfmlDistortionLevel.DISTORTION_LEVEL_4,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_4),
			new Fixture(LfmlDistortionLevel.DISTORTION_LEVEL_5,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_5),
		};

		public static class Fixture {
			public LfmlDistortionLevel key;
			public Pc2DistortionLevelType expected;

			Fixture(LfmlDistortionLevel key, Pc2DistortionLevelType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedTemplateFormatTypeToStringNameHelper {
		public static Fixture[] fixtures = {
			new Fixture(TemplateFormatType.TEMPLATE_RDBT, "RDBT"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBTM, "RDBTM"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBLX, "XDBL"),
			new Fixture(TemplateFormatType.TEMPLATE_LDB, "LDB"),
			new Fixture(TemplateFormatType.TEMPLATE_PLDB, ""),
			new Fixture(TemplateFormatType.TEMPLATE_LDBS, "LDBS"),
			new Fixture(TemplateFormatType.TEMPLATE_LDBM, "LDBM"),
			new Fixture(TemplateFormatType.TEMPLATE_LDBX, "LDBX"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBL, "RDBL"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBLS, "RDBLS"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBLM, "RDBLM"),
			new Fixture(TemplateFormatType.TEMPLATE_PDB, ""),
			new Fixture(TemplateFormatType.TEMPLATE_FDB, ""),
			new Fixture(TemplateFormatType.TEMPLATE_TI, "TI"),
			new Fixture(TemplateFormatType.TEMPLATE_TIM, "TIM"),
			new Fixture(TemplateFormatType.TEMPLATE_TLI, "TLI"),
			new Fixture(TemplateFormatType.TEMPLATE_TLIS, "TLIS"),
			new Fixture(TemplateFormatType.TEMPLATE_TLIM, "TLIM"),
			new Fixture(TemplateFormatType.TEMPLATE_TLIX, "TLIX"),
			new Fixture(TemplateFormatType.TEMPLATE_LI, "LI"),
			new Fixture(TemplateFormatType.TEMPLATE_LIS, "LIS"),
			new Fixture(TemplateFormatType.TEMPLATE_LIM, "LIM"),
			new Fixture(TemplateFormatType.TEMPLATE_LIX, "LIX"),
			new Fixture(TemplateFormatType.TEMPLATE_LLI, "LLI"),
			new Fixture(TemplateFormatType.TEMPLATE_LLIS, "LLIS"),
			new Fixture(TemplateFormatType.TEMPLATE_LLIM, "LLIM"),
			new Fixture(TemplateFormatType.TEMPLATE_LLIX, "LLIX"),
			new Fixture(TemplateFormatType.TEMPLATE_LIP, "LIP"),
			new Fixture(TemplateFormatType.TEMPLATE_TLIP, "TLIP"),
			new Fixture(TemplateFormatType.TEMPLATE_FI, ""),
		};

		public static class Fixture {
			public TemplateFormatType key;
			public String expected;

			Fixture(TemplateFormatType key, String expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedTemplateFormatTypeToStringDbTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(TemplateFormatType.TEMPLATE_RDBT, "RDBT"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBTM, "RDBTM"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBLX, "RDBLX"),
			new Fixture(TemplateFormatType.TEMPLATE_LDB, "LDB"),
			new Fixture(TemplateFormatType.TEMPLATE_LDBS, "LDBS"),
			new Fixture(TemplateFormatType.TEMPLATE_LDBM, "LDBM"),
			new Fixture(TemplateFormatType.TEMPLATE_LDBX, "LDBX"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBL, "RDBL"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBLS, "RDBLS"),
			new Fixture(TemplateFormatType.TEMPLATE_RDBLM, "RDBLM"),
			new Fixture(TemplateFormatType.TEMPLATE_TI, "RDBT"),
			new Fixture(TemplateFormatType.TEMPLATE_TIM, "RDBTM"),
			new Fixture(TemplateFormatType.TEMPLATE_TLI, "RDBL"),
			new Fixture(TemplateFormatType.TEMPLATE_TLIS, "RDBLS"),
			new Fixture(TemplateFormatType.TEMPLATE_TLIM, "RDBLM"),
			new Fixture(TemplateFormatType.TEMPLATE_TLIX, "RDBLX"),
			new Fixture(TemplateFormatType.TEMPLATE_LI, "LDB"),
			new Fixture(TemplateFormatType.TEMPLATE_LIS, "LDBS"),
			new Fixture(TemplateFormatType.TEMPLATE_LIM, "LDBM"),
			new Fixture(TemplateFormatType.TEMPLATE_LIX, "LDBX"),
			new Fixture(TemplateFormatType.TEMPLATE_LLI, "LDB"),
			new Fixture(TemplateFormatType.TEMPLATE_LLIS, "LDBS"),
			new Fixture(TemplateFormatType.TEMPLATE_LLIM, "LDBM"),
			new Fixture(TemplateFormatType.TEMPLATE_LLIX, "LDBX"),
		};

		public static class Fixture {
			public TemplateFormatType key;
			public String expected;

			Fixture(TemplateFormatType key, String expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedIrisSearchModeToIrisSearchModeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(IrisSearchMode.IRIS_SEARCH_MODE_ACCURACY,
				IrisSearchModeType.IRIS_SEARCH_MODE_ACCURACY),
			new Fixture(IrisSearchMode.IRIS_SEARCH_MODE_STANDARD,
				IrisSearchModeType.IRIS_SEARCH_MODE_STANDARD),
			new Fixture(IrisSearchMode.IRIS_SEARCH_MODE_PERFORMANCE,
				IrisSearchModeType.IRIS_SEARCH_MODE_PERFORMANCE),
		};

		public static class Fixture {
			public IrisSearchMode key;
			public IrisSearchModeType expected;

			Fixture(IrisSearchMode key, IrisSearchModeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToTemplateFormatTypeForGetBinaryHelper {
		public static Fixture[] fixtures = {
			new Fixture("RDBT", TemplateFormatType.TEMPLATE_RDBT),
			new Fixture("SDBT", TemplateFormatType.TEMPLATE_RDBT),
			new Fixture("RDBTM", TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture("SDBTM", TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture("XDBL", TemplateFormatType.TEMPLATE_RDBLX),
			new Fixture("LDB", TemplateFormatType.TEMPLATE_LDB),
			new Fixture("PLDB", TemplateFormatType.TEMPLATE_PLDB),
			new Fixture("LDB_S", TemplateFormatType.TEMPLATE_LDBS),
			new Fixture("LDBM", TemplateFormatType.TEMPLATE_LDBM),
			new Fixture("LDBX", TemplateFormatType.TEMPLATE_LDBX),
			new Fixture("RDBL_1", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_2", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_3", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_4", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_5", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_6", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_7", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_8", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_9", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_10", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBLS_1", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_2", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_3", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_4", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_5", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_6", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_7", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_8", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_9", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_10", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLM_1", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_2", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_3", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_4", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_5", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_6", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_7", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_8", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_9", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_10", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBL_1", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_2", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_3", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_4", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_5", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_6", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_7", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_8", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_9", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_10", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBLS_1", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_2", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_3", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_4", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_5", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_6", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_7", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_8", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_9", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_10", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLM_1", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_2", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_3", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_4", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_5", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_6", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_7", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_8", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_9", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_10", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("PDB_1", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_2", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_3", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_4", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_5", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_6", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_7", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_8", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_9", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_10", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_11", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_12", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_13", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_14", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_15", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_16", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("FDB_1", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_2", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_3", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_4", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_5", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_6", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_7", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_8", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_9", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_10", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("IDB", TemplateFormatType.TEMPLATE_IDB),
			new Fixture("TI_ROLLED", TemplateFormatType.TEMPLATE_TI),
			new Fixture("TI_SLAP", TemplateFormatType.TEMPLATE_TI),
			new Fixture("TIM_ROLLED", TemplateFormatType.TEMPLATE_TIM),
			new Fixture("TIM_SLAP", TemplateFormatType.TEMPLATE_TIM),
			new Fixture("TLI_ROLLED", TemplateFormatType.TEMPLATE_TLI),
			new Fixture("TLI_SLAP", TemplateFormatType.TEMPLATE_TLI),
			new Fixture("TLIS_ROLLED", TemplateFormatType.TEMPLATE_TLIS),
			new Fixture("TLIS_SLAP", TemplateFormatType.TEMPLATE_TLIS),
			new Fixture("TLIM_ROLLED", TemplateFormatType.TEMPLATE_TLIM),
			new Fixture("TLIM_SLAP", TemplateFormatType.TEMPLATE_TLIM),
			new Fixture("TLIX", TemplateFormatType.TEMPLATE_TLIX),
			new Fixture("LI", TemplateFormatType.TEMPLATE_LI),
			new Fixture("LI_S", TemplateFormatType.TEMPLATE_LIS),
			new Fixture("LIM", TemplateFormatType.TEMPLATE_LIM),
			new Fixture("LIX", TemplateFormatType.TEMPLATE_LIX),
			new Fixture("LLI", TemplateFormatType.TEMPLATE_LLI),
			new Fixture("LLI_S", TemplateFormatType.TEMPLATE_LLIS),
			new Fixture("LLIM", TemplateFormatType.TEMPLATE_LLIM),
			new Fixture("LLIX", TemplateFormatType.TEMPLATE_LLIX),
			new Fixture("LIP", TemplateFormatType.TEMPLATE_LIP),
			new Fixture("LLIP", TemplateFormatType.TEMPLATE_LLIP),
			new Fixture("TLIP", TemplateFormatType.TEMPLATE_TLIP),
			new Fixture("FI_1", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_2", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_3", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_4", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_5", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_6", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_7", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_8", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_9", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_10", TemplateFormatType.TEMPLATE_FI),
			new Fixture("II", TemplateFormatType.TEMPLATE_II),
		};

		public static class Fixture {
			public String key;
			public TemplateFormatType expected;

			Fixture(String key, TemplateFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringSearchTemplateToTemplateFormatTypeForGetBinaryHelper {
		public static Fixture[] fixtures = {
			new Fixture("TI_ROLLED", TemplateFormatType.TEMPLATE_TI),
			new Fixture("TI_SLAP", TemplateFormatType.TEMPLATE_TI),
			new Fixture("TIM_ROLLED", TemplateFormatType.TEMPLATE_TIM),
			new Fixture("TIM_SLAP", TemplateFormatType.TEMPLATE_TIM),
			new Fixture("TLI_ROLLED", TemplateFormatType.TEMPLATE_TLI),
			new Fixture("TLI_SLAP", TemplateFormatType.TEMPLATE_TLI),
			new Fixture("TLIS_ROLLED", TemplateFormatType.TEMPLATE_TLIS),
			new Fixture("TLIS_SLAP", TemplateFormatType.TEMPLATE_TLIS),
			new Fixture("TLIM_ROLLED", TemplateFormatType.TEMPLATE_TLIM),
			new Fixture("TLIM_SLAP", TemplateFormatType.TEMPLATE_TLIM),
			new Fixture("TLIX", TemplateFormatType.TEMPLATE_TLIX),
			new Fixture("LI", TemplateFormatType.TEMPLATE_LI),
			new Fixture("LI_S", TemplateFormatType.TEMPLATE_LIS),
			new Fixture("LIM", TemplateFormatType.TEMPLATE_LIM),
			new Fixture("LIX", TemplateFormatType.TEMPLATE_LIX),
			new Fixture("LLI", TemplateFormatType.TEMPLATE_LLI),
			new Fixture("LLI_S", TemplateFormatType.TEMPLATE_LLIS),
			new Fixture("LLIM", TemplateFormatType.TEMPLATE_LLIM),
			new Fixture("LLIX", TemplateFormatType.TEMPLATE_LLIX),
			new Fixture("LIP", TemplateFormatType.TEMPLATE_LIP),
			new Fixture("LLIP", TemplateFormatType.TEMPLATE_LLIP),
			new Fixture("TLIP", TemplateFormatType.TEMPLATE_TLIP),
			new Fixture("FI_1", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_2", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_3", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_4", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_5", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_6", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_7", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_8", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_9", TemplateFormatType.TEMPLATE_FI),
			new Fixture("FI_10", TemplateFormatType.TEMPLATE_FI),
			new Fixture("II", TemplateFormatType.TEMPLATE_II),
		};

		public static class Fixture {
			public String key;
			public TemplateFormatType expected;

			Fixture(String key, TemplateFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedStringToTemplateFormatTypeForInsertHelper {
		public static Fixture[] fixtures = {
			new Fixture("RDBT", TemplateFormatType.TEMPLATE_RDBT),
			new Fixture("SDBT", TemplateFormatType.TEMPLATE_RDBT),
			new Fixture("RDBTM", TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture("SDBTM", TemplateFormatType.TEMPLATE_RDBTM),
			new Fixture("XDBL", TemplateFormatType.TEMPLATE_RDBLX),
			new Fixture("LDB", TemplateFormatType.TEMPLATE_LDB),
			new Fixture("PLDB", TemplateFormatType.TEMPLATE_PLDB),
			new Fixture("LDBS", TemplateFormatType.TEMPLATE_LDBS),
			new Fixture("LDBM", TemplateFormatType.TEMPLATE_LDBM),
			new Fixture("LDBX", TemplateFormatType.TEMPLATE_LDBX),
			new Fixture("RDBL_1", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_2", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_3", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_4", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_5", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_6", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_7", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_8", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_9", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBL_10", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("RDBLS_1", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_2", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_3", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_4", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_5", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_6", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_7", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_8", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_9", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLS_10", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("RDBLM_1", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_2", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_3", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_4", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_5", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_6", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_7", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_8", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_9", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("RDBLM_10", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBL_1", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_2", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_3", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_4", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_5", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_6", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_7", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_8", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_9", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBL_10", TemplateFormatType.TEMPLATE_RDBL),
			new Fixture("SDBLS_1", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_2", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_3", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_4", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_5", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_6", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_7", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_8", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_9", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLS_10", TemplateFormatType.TEMPLATE_RDBLS),
			new Fixture("SDBLM_1", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_2", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_3", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_4", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_5", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_6", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_7", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_8", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_9", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("SDBLM_10", TemplateFormatType.TEMPLATE_RDBLM),
			new Fixture("PDB_1", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_2", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_3", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_4", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_5", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_6", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_7", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_8", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_9", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_10", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_11", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_12", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_13", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_14", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_15", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("PDB_16", TemplateFormatType.TEMPLATE_PDB),
			new Fixture("FDB_1", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_2", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_3", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_4", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_5", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_6", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_7", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_8", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_9", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("FDB_10", TemplateFormatType.TEMPLATE_FDB),
			new Fixture("IDB", TemplateFormatType.TEMPLATE_IDB),
		};

		public static class Fixture {
			public String key;
			public TemplateFormatType expected;

			Fixture(String key, TemplateFormatType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}

	public static class InitializedIrisExtractionModeToIrisExtractionModeTypeHelper {
		public static Fixture[] fixtures = {
			new Fixture(IrisExtractionMode.IRIS_EXTRACT_MODE_ACCURACY,
				IrisExtractionModeType.IRIS_EXTRACTION_MODE_ACCURACY),
			new Fixture(IrisExtractionMode.IRIS_EXTRACT_MODE_PERFORMANCE,
				IrisExtractionModeType.IRIS_EXTRACTION_MODE_PERFORMANCE),
		};

		public static class Fixture {
			public IrisExtractionMode key;
			public IrisExtractionModeType expected;

			Fixture(IrisExtractionMode key, IrisExtractionModeType expected) {
				this.key = key;
				this.expected = expected;
			}
		}
	}
}
