package jp.co.nec.aim.helper;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.aim.clientapi.CommonOptions;
import jp.co.nec.aim.clientapi.afis.AfisDeletionFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisRegistrationFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisUpdateFunctionEnum;
import jp.co.nec.aim.convert.InvalidParameterException;
import jp.co.nec.aim.convert.ProtoClassConvert;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPatternType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionBaseType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.GenderType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.PalmPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.PrefilterYobMethodType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.RaceType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.RegionCodeType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateReference;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfo;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoCommon;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoLatent;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoTenprint;
import jp.co.nec.aim.message.proto.CommonPayloads.PBPrefilterOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBUsePrefilterInfo;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.BasicImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.CMLaFFeTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.CMLaFImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.ExtractOutputModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionAlgorithmType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionRotationType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionShrinkFactorType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionSortingOrderType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceExtractProcessType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FisTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.ImageWhiteBlackLevelType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.IrisExtractionModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaDbType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckModeType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBAimFormat;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBBasicImageEnhanceOptions;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBCMLaFExtractParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBCropPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCMLaFOptions;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCMLOptions;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCommonOptionLatent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCommonOptionTenprint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeTypeEvent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputFaceDetection;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputFaceExtraction;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputImage;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputIrisExtraction;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMarkUp;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMinutiaLatent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMinutiaTenprint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace13Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace2Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceDetectionParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceExtractionParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerCropCoordinate;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisCore;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisMinutiaNo;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisQuality;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBInputMinutiaData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOptions;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryRequest;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.CMLaFSearchModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.FilterModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.FingerSelectionModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.IrisSearchModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeAlgorithmType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeCorePositionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeRotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LfmlSearchLevelType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.PalmRotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2DistortionLevelType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2RotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2SpeedLevelType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLaFMatchableFingerThreshold;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLaFOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryPayload;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBIrisOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBLeOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBLfmlOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBPalmOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBPc2Options;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBPreselectionOptions;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdRequest;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncInsertPayload;
import jp.co.nec.aim.mm.jaxb.AfisTemplateSet;
import jp.co.nec.aim.mm.jaxb.AimFormats;
import jp.co.nec.aim.mm.jaxb.CmlafEnhType;
import jp.co.nec.aim.mm.jaxb.CmlafTiOptions;
import jp.co.nec.aim.mm.jaxb.CmlExtOptions;
import jp.co.nec.aim.mm.jaxb.CmlOptions;
import jp.co.nec.aim.mm.jaxb.CropInfo;
import jp.co.nec.aim.mm.jaxb.DetectionAlgorithm;
import jp.co.nec.aim.mm.jaxb.DetectionMode;
import jp.co.nec.aim.mm.jaxb.DynamicXml;
import jp.co.nec.aim.mm.jaxb.EnhType;
import jp.co.nec.aim.mm.jaxb.ExtInfoModeFormat;
import jp.co.nec.aim.mm.jaxb.ExtInput;
import jp.co.nec.aim.mm.jaxb.ExtractResultReference;
import jp.co.nec.aim.mm.jaxb.ExtractionFormats;
import jp.co.nec.aim.mm.jaxb.ExtractionInputs;
import jp.co.nec.aim.mm.jaxb.ExtractionInputsPayload;
import jp.co.nec.aim.mm.jaxb.Face2Points;
import jp.co.nec.aim.mm.jaxb.FaceInput;
import jp.co.nec.aim.mm.jaxb.FaceInputDetection;
import jp.co.nec.aim.mm.jaxb.FaceInputExtraction;
import jp.co.nec.aim.mm.jaxb.FaceInputExtraction13Points;
import jp.co.nec.aim.mm.jaxb.FaceInputImage;
import jp.co.nec.aim.mm.jaxb.FaceInputParams;
import jp.co.nec.aim.mm.jaxb.FaceNegativeDetectionParams;
import jp.co.nec.aim.mm.jaxb.FacePoint;
import jp.co.nec.aim.mm.jaxb.FaceProcessMode;
import jp.co.nec.aim.mm.jaxb.FaceRotation;
import jp.co.nec.aim.mm.jaxb.FeTypeLatent;
import jp.co.nec.aim.mm.jaxb.FeTypeTenprint;
import jp.co.nec.aim.mm.jaxb.FeTypes;
import jp.co.nec.aim.mm.jaxb.FingerSetEnum;
import jp.co.nec.aim.mm.jaxb.FingersThresholds;
import jp.co.nec.aim.mm.jaxb.FusionWeight;
import jp.co.nec.aim.mm.jaxb.GenderEnum;
import jp.co.nec.aim.mm.jaxb.ImageEnhance;
import jp.co.nec.aim.mm.jaxb.ImageFormat;
import jp.co.nec.aim.mm.jaxb.InputImage;
import jp.co.nec.aim.mm.jaxb.InquirySetEnum;
import jp.co.nec.aim.mm.jaxb.IrisInput;
import jp.co.nec.aim.mm.jaxb.IrisInputExtraction;
import jp.co.nec.aim.mm.jaxb.IrisInputImage;
import jp.co.nec.aim.mm.jaxb.IrisInputImages;
import jp.co.nec.aim.mm.jaxb.IrisOptions;
import jp.co.nec.aim.mm.jaxb.IrisSearchMode;
import jp.co.nec.aim.mm.jaxb.IrisExtractionMode;
import jp.co.nec.aim.mm.jaxb.KeyedTemplate;
import jp.co.nec.aim.mm.jaxb.LatentInput;
import jp.co.nec.aim.mm.jaxb.LeOptions;
import jp.co.nec.aim.mm.jaxb.LfmlDistortionLevel;
import jp.co.nec.aim.mm.jaxb.LfmlOptions;
import jp.co.nec.aim.mm.jaxb.LfmlRotationLimit;
import jp.co.nec.aim.mm.jaxb.LfmlSearchLevel;
import jp.co.nec.aim.mm.jaxb.LfmlSpeedLevel;
import jp.co.nec.aim.mm.jaxb.MarkUp;
import jp.co.nec.aim.mm.jaxb.MatchableFingersThresholds;
import jp.co.nec.aim.mm.jaxb.MetaInfo;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaCommon;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaLatent;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaTenprint;
import jp.co.nec.aim.mm.jaxb.PalmOptions;
import jp.co.nec.aim.mm.jaxb.Pc2Options;
import jp.co.nec.aim.mm.jaxb.Point;
import jp.co.nec.aim.mm.jaxb.PointCenter;
import jp.co.nec.aim.mm.jaxb.PrefilterOptions;
import jp.co.nec.aim.mm.jaxb.PreselectionOptions;
import jp.co.nec.aim.mm.jaxb.QcInput;
import jp.co.nec.aim.mm.jaxb.QcMode;
import jp.co.nec.aim.mm.jaxb.Record;
import jp.co.nec.aim.mm.jaxb.RegistrationRequest;
import jp.co.nec.aim.mm.jaxb.SearchInputsPayload;
import jp.co.nec.aim.mm.jaxb.SearchOptions;
import jp.co.nec.aim.mm.jaxb.SearchRequest;
import jp.co.nec.aim.mm.jaxb.SegInfo;
import jp.co.nec.aim.mm.jaxb.ShrinkFactor;
import jp.co.nec.aim.mm.jaxb.SortingOrder;
import jp.co.nec.aim.mm.jaxb.TemplateMetadata;
import jp.co.nec.aim.mm.jaxb.TenprintInput;
import jp.co.nec.aim.mm.jaxb.TenprintInput.CmlafExtOptions;
import jp.co.nec.aim.mm.jaxb.UsePrefilterInfo;
import jp.co.nec.aim.mm.jaxb.WhiteBlackLevel;
import jp.co.nec.aim.mm.jaxb.XTemplateFmp5;
import jp.co.nec.aim.mm.jaxb.XTemplateLatent;
import jp.co.nec.aim.mm.jaxb.XTemplatePc2;
import jp.co.nec.aim.mm.jaxb.XTemplateRolled;
import jp.co.nec.aim.mm.jaxb.XTemplateSlap;

import org.apache.commons.lang3.RandomStringUtils;

import com.google.protobuf.ByteString;

public class ProtoClassConvertTestHelper {
	public static class ToPBMetaInfoCommonWith_MetaCommon_Helper {
		public static Fixture[] fixtures = {
			build("full set"), build("null"),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(String mode) {
			MetaCommon parameter = new MetaCommon();
			PBMetaInfoCommon.Builder builder = PBMetaInfoCommon.newBuilder();

			if (mode.equals("full set")) {
				parameter.setGender(GenderEnum.M);
				builder.setGender(GenderType.GENDER_MALE);

				parameter.setYob(1);
				builder.setYob(1);

				parameter.setYobRange(2);
				builder.setYobRange(2);

				parameter.setRace("8");
				builder.setRace(RaceType.RACE_ASIAN);

				parameter.setRegion("12EF");
				builder.addRegion(RegionCodeType.REGION_CODE_1).addRegion(
					RegionCodeType.REGION_CODE_2).addRegion(RegionCodeType.REGION_CODE_E)
					.addRegion(RegionCodeType.REGION_CODE_F);
			} else if (mode.equals("null")) {
				// no data
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public MetaCommon parameter;
			public PBMetaInfoCommon expected;

			Fixture(MetaCommon parameter, PBMetaInfoCommon expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBMetaInfoTenprintWith_MetaTenprint_Helper {
		public static Fixture[] fixtures = {
			build("not empty"), build("empty"), build("null"),
		};

		public static Fixture build(String mode) {
			MetaTenprint parameter = new MetaTenprint();
			PBMetaInfoTenprint.Builder builder = PBMetaInfoTenprint.newBuilder();

			if (mode.equals("not empty")) {
				parameter.setPrimaryPatterns("ALSSSWSSRS");
				builder.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_ARCH)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_LEFTLOOP)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_SCAR)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_SCAR)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_SCAR)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_WHORL)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_SCAR)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_SCAR)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_RIGHTLOOP)
					.addPrimaryPatterns(FingerPatternType.FINGER_PATTERN_SCAR);

				parameter.setReferencePatterns("WUAUUULURS");
				builder.addReferencePatterns(FingerPatternType.FINGER_PATTERN_WHORL)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_UNKNOWN)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_ARCH)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_UNKNOWN)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_UNKNOWN)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_UNKNOWN)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_LEFTLOOP)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_UNKNOWN)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_RIGHTLOOP)
					.addReferencePatterns(FingerPatternType.FINGER_PATTERN_SCAR);

			} else if (mode.equals("empty")) {
				parameter.setPrimaryPatterns("");
				parameter.setReferencePatterns("");
			}
			return new Fixture(parameter, builder.build(), mode);
		}

		public static class Fixture {
			public MetaTenprint parameter;
			public PBMetaInfoTenprint expected;
			public String mode;

			Fixture(MetaTenprint parameter, PBMetaInfoTenprint expected, String mode) {
				this.parameter = parameter;
				this.expected = expected;
				this.mode = mode;
			}
		}
	}

	public static class ToPBMetaInfoLatentWith_MetaLatent_Helper {
		public static Fixture build() {
			MetaLatent parameter = new MetaLatent();
			PBMetaInfoLatent.Builder builder = PBMetaInfoLatent.newBuilder();

			parameter.setSelectFingers("0189");
			builder.addSelectFingers(FingerPositionBaseType.RIGHT_THUMB)
				.addSelectFingers(FingerPositionBaseType.RIGHT_INDEX).addSelectFingers(
					FingerPositionBaseType.LEFT_RING).addSelectFingers(
					FingerPositionBaseType.LEFT_LITTLE);

			parameter.setLatentPatterns("ALW");
			builder.addLatentPatterns(FingerPatternType.FINGER_PATTERN_ARCH)
				.addLatentPatterns(FingerPatternType.FINGER_PATTERN_LEFTLOOP)
				.addLatentPatterns(FingerPatternType.FINGER_PATTERN_WHORL);

			parameter.setPrimaryAdjacentPatterns("ALSRS*WA");
			builder.addPrimaryAdjacentPatterns(FingerPatternType.FINGER_PATTERN_ARCH)
				.addPrimaryAdjacentPatterns(FingerPatternType.FINGER_PATTERN_LEFTLOOP)
				.addPrimaryAdjacentPatterns(FingerPatternType.FINGER_PATTERN_SCAR)
				.addPrimaryAdjacentPatterns(FingerPatternType.FINGER_PATTERN_RIGHTLOOP)
				.addPrimaryAdjacentPatterns(FingerPatternType.FINGER_PATTERN_SCAR)
				.addPrimaryAdjacentPatterns(FingerPatternType.FINGER_PATTERN_NONE)
				.addPrimaryAdjacentPatterns(FingerPatternType.FINGER_PATTERN_WHORL)
				.addPrimaryAdjacentPatterns(FingerPatternType.FINGER_PATTERN_ARCH);

			parameter.setReferenceAdjacentPatterns("ALWRS*L*");
			builder.addReferenceAdjacentPatterns(FingerPatternType.FINGER_PATTERN_ARCH)
				.addReferenceAdjacentPatterns(FingerPatternType.FINGER_PATTERN_LEFTLOOP)
				.addReferenceAdjacentPatterns(FingerPatternType.FINGER_PATTERN_WHORL)
				.addReferenceAdjacentPatterns(FingerPatternType.FINGER_PATTERN_RIGHTLOOP)
				.addReferenceAdjacentPatterns(FingerPatternType.FINGER_PATTERN_SCAR)
				.addReferenceAdjacentPatterns(FingerPatternType.FINGER_PATTERN_NONE)
				.addReferenceAdjacentPatterns(FingerPatternType.FINGER_PATTERN_LEFTLOOP)
				.addReferenceAdjacentPatterns(FingerPatternType.FINGER_PATTERN_NONE);

			parameter.setSelectParts("17GAB");
			builder.addSelectParts(PalmPositionType.PALM_RIGHT_FULL).addSelectParts(
				PalmPositionType.PALM_LEFT_LOWER).addSelectParts(
				PalmPositionType.PALM_LEFT_HYPOTHENAR).addSelectParts(
				PalmPositionType.PALM_LEFT_OTHER).addSelectParts(
				PalmPositionType.PALM_RIGHT_INTERDIGITAL);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public MetaLatent parameter;
			public PBMetaInfoLatent expected;

			Fixture(MetaLatent parameter, PBMetaInfoLatent expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBMetaInfo_Helper {
		public static Fixture build() {
			MetaInfo parameter = new MetaInfo();
			PBMetaInfo.Builder builder = PBMetaInfo.newBuilder();

			{
				ToPBMetaInfoCommonWith_MetaCommon_Helper.Fixture fixture =
					ToPBMetaInfoCommonWith_MetaCommon_Helper.build("full set");
				parameter.setMetaCommon(fixture.parameter);
				builder.setCommon(fixture.expected);
			}
			{
				ToPBMetaInfoTenprintWith_MetaTenprint_Helper.Fixture fixture =
					ToPBMetaInfoTenprintWith_MetaTenprint_Helper.build("no empty");
				parameter.setMetaTenprint(fixture.parameter);
				builder.setTenprint(fixture.expected);
			}
			{
				ToPBMetaInfoLatentWith_MetaLatent_Helper.Fixture fixture =
					ToPBMetaInfoLatentWith_MetaLatent_Helper.build();
				parameter.setMetaLatent(fixture.parameter);
				builder.setLatent(fixture.expected);
			}
			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public MetaInfo parameter;
			public PBMetaInfo expected;

			Fixture(MetaInfo parameter, PBMetaInfo expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper {
		public static Fixture build(String rolledFeType, String slapFeType) {
			PBExtractInputImage.Builder builder = PBExtractInputImage.newBuilder();
			List<InputImage> parameterList = new ArrayList<>();
			List<PBExtractInputImage> expectedLsit = new ArrayList<>();

			InputImage parameter = null;
			parameter = build(1);
			if (!rolledFeType.equals("")) {
				parameter.setFeType(rolledFeType);
			}
			{
				ToPBFingerCropCoordinateWith_ListOfSegInfos_Helper.Fixture fixture =
					ToPBFingerCropCoordinateWith_ListOfSegInfos_Helper.build();
				parameter.getSegInfo().addAll(fixture.parameter);
			}

			builder.setPosition(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
			builder.setType(ImageFormatType.RAW);
			builder.setVertScale(2);
			builder.setHorizScale(3);
			builder.setDpi(4);
			builder.setWidth(5);
			builder.setHeight(6);
			builder.setWhiteBlackType(ImageWhiteBlackLevelType.IMAGE_LEVEL_BLACK);
			builder.setUrl("test");
			builder.setData(ByteString.copyFrom(parameter.getData()));
			{
				ToPBFingerCropCoordinateWith_ListOfSegInfos_Helper.Fixture fixture =
					ToPBFingerCropCoordinateWith_ListOfSegInfos_Helper.build();
				builder.addAllCropCoordinate(fixture.expected);
			}

			parameterList.add(parameter);
			expectedLsit.add(builder.build());

			builder.clear();
			parameter = build(11);
			if (!slapFeType.equals("")) {
				parameter.setFeType(slapFeType);
			}

			builder.setPosition(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
			builder.setType(ImageFormatType.RAW);
			builder.setVertScale(2);
			builder.setHorizScale(3);
			builder.setDpi(4);
			builder.setWidth(5);
			builder.setHeight(6);
			builder.setWhiteBlackType(ImageWhiteBlackLevelType.IMAGE_LEVEL_BLACK);
			builder.setUrl("test");
			builder.setData(ByteString.copyFrom(parameter.getData()));
			parameterList.add(parameter);
			expectedLsit.add(builder.build());

			return new Fixture(parameterList, expectedLsit);
		}

		private static InputImage build(int fingerNumber) {
			InputImage parameter = new InputImage();

			parameter.setPos(String.valueOf(fingerNumber));
			parameter.setType(ImageFormat.RAW);
			parameter.setVertScale(Integer.valueOf(2));
			parameter.setHorizScale(Integer.valueOf(3));
			parameter.setDpi(Integer.valueOf(4));
			parameter.setWidth(Integer.valueOf(5));
			parameter.setHeight(Integer.valueOf(6));
			parameter.setWhiteBlackLevel(WhiteBlackLevel.BLACKLEVEL);
			parameter.setUrl("test");

			byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
			parameter.setData(binary);
			return parameter;
		}

		public static class Fixture {
			public List<InputImage> parameter;
			public List<PBExtractInputImage> expected;

			Fixture(List<InputImage> parameter, List<PBExtractInputImage> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputImageWith_TenprintInput2Images {
		public static Fixture build() {
			TenprintInput.Images parameter = new TenprintInput.Images();

			ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
				ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
					.build("C", "C");
			parameter.getImage().addAll(fixture.parameter);

			List<PBExtractInputImage> expectedList = new ArrayList<>();
			expectedList.addAll(fixture.expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public TenprintInput.Images parameter;
			public List<PBExtractInputImage> expected;

			Fixture(TenprintInput.Images parameter, List<PBExtractInputImage> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBPoint_Point_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(int x, int y) {
			PBPoint.Builder builder = PBPoint.newBuilder();
			builder.setX(x);
			builder.setY(y);

			Point parameter = new Point();
			parameter.setX(x);
			parameter.setY(y);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public Point parameter;
			public PBPoint expected;

			Fixture(Point parameter, PBPoint expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBCropPoint_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBCropPoint.Builder builder = PBCropPoint.newBuilder();
			CropInfo parameter = new CropInfo();

			{
				ToPBPoint_Point_Helper.Fixture fixture =
					ToPBPoint_Point_Helper.build(1, 2);
				PointCenter center = new PointCenter();
				center.setX(fixture.parameter.getX());
				center.setY(fixture.parameter.getY());
				parameter.setCenter(center);
				builder.setCenter(fixture.expected);

				center.setAngle(3.0f);
				builder.setAngle(3.0f);
			}
			{
				ToPBPoint_Point_Helper.Fixture fixture =
					ToPBPoint_Point_Helper.build(3, 4);
				CropInfo.CropPoints points = new CropInfo.CropPoints();
				points.getPoints().add(fixture.parameter);
				parameter.setCropPoints(points);
				builder.addPoints(fixture.expected);
			}
			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public CropInfo parameter;
			public PBCropPoint expected;

			Fixture(CropInfo parameter, PBCropPoint expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFingerCropCoordinateWith_ListOfSegInfos_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			SegInfo parameter = new SegInfo();
			PBFingerCropCoordinate.Builder builder = PBFingerCropCoordinate.newBuilder();

			ToPBCropPoint_Helper.Fixture fixture = ToPBCropPoint_Helper.build();
			parameter.setCropInfo(fixture.parameter);
			builder.setCropPoints(fixture.expected);

			parameter.setPos(1);
			builder.setPosition(FingerPositionBaseType.RIGHT_THUMB);

			parameter.setAmp(true);
			builder.setAmputated(true);

			List<SegInfo> parameterList = new ArrayList<>();
			parameterList.add(parameter);
			List<PBFingerCropCoordinate> expectedList = new ArrayList<>();
			expectedList.add(builder.build());
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<SegInfo> parameter;
			public List<PBFingerCropCoordinate> expected;

			Fixture(List<SegInfo> parameter, List<PBFingerCropCoordinate> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractFeTypeWith_String_FingerPrintType_Helper {
		public static Fixture build() {
			Parameter parameter = new Parameter();
			parameter.feType = "C";
			parameter.fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;

			PBExtractFeType.Builder builder = PBExtractFeType.newBuilder();
			builder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
			builder.setFisType(FisTypeType.FIS_TYPE_C);
			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public String feType;
			public FingerPrintType fingerPrintType;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBExtractFeType expected;

			Fixture(Parameter parameter, PBExtractFeType expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractFeTypeWith_FeTypeTenprint_Helper {
		public static Fixture build() {
			FeTypeTenprint parameter = new FeTypeTenprint();
			PBExtractFeType.Builder builder = PBExtractFeType.newBuilder();
			List<PBExtractFeType> expectedList = new ArrayList<>();

			XTemplateRolled rolled = new XTemplateRolled();
			{
				XTemplatePc2 pc2 = new XTemplatePc2();
				pc2.setFeType("B");
				rolled.setPc2(pc2);
				builder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.setFisType(FisTypeType.FIS_TYPE_B);
				builder.setMinutiaType(MinutiaType.MINUTIA_PC2);
				expectedList.add(builder.build());

				XTemplateFmp5 fmp5 = new XTemplateFmp5();
				fmp5.setFeType("C");
				rolled.setFmp5(fmp5);
				builder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.setFisType(FisTypeType.FIS_TYPE_C);
				builder.setMinutiaType(MinutiaType.MINUTIA_FMP5);
				expectedList.add(builder.build());

				parameter.setRolled(rolled);
			}
			XTemplateSlap slap = new XTemplateSlap();
			{
				XTemplatePc2 pc2 = new XTemplatePc2();
				pc2.setFeType("E");
				slap.setPc2(pc2);
				builder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
				builder.setFisType(FisTypeType.FIS_TYPE_E);
				builder.setMinutiaType(MinutiaType.MINUTIA_PC2);
				expectedList.add(builder.build());

				XTemplateFmp5 fmp5 = new XTemplateFmp5();
				fmp5.setFeType("F");
				slap.setFmp5(fmp5);
				builder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
				builder.setFisType(FisTypeType.FIS_TYPE_F);
				builder.setMinutiaType(MinutiaType.MINUTIA_FMP5);
				expectedList.add(builder.build());

				parameter.setSlap(slap);
			}

			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public FeTypeTenprint parameter;
			public List<PBExtractFeType> expected;

			Fixture(FeTypeTenprint parameter, List<PBExtractFeType> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints_Helper {
		public static Fixture[] fixtures = {
			build("case1"), build("case2"), build("case3"),
		};

		public static Fixture build(String mode) {
			List<FeTypeTenprint> parameterList = new ArrayList<>();
			List<PBExtractFeTypeEvent> expectedList = new ArrayList<>();
			PBExtractFeTypeEvent.Builder builder = PBExtractFeTypeEvent.newBuilder();

			if (mode.equals("case1")) {
				ToPBExtractFeTypeWith_FeTypeTenprint_Helper.Fixture fixture =
					ToPBExtractFeTypeWith_FeTypeTenprint_Helper.build();

				FeTypeTenprint parameter = new FeTypeTenprint();
				parameter.setRolled(fixture.parameter.getRolled());
				parameter.setSlap(fixture.parameter.getSlap());
				parameterList.add(parameter);
				parameterList.add(parameter);

				builder.setEvent(1);
				builder.addFeTypes(fixture.expected.get(0));
				builder.addFeTypes(fixture.expected.get(1));
				builder.addFeTypes(fixture.expected.get(2));
				builder.addFeTypes(fixture.expected.get(3));
				expectedList.add(builder.build());
				builder.clear();

				builder.setEvent(2);
				builder.addFeTypes(fixture.expected.get(0));
				builder.addFeTypes(fixture.expected.get(1));
				builder.addFeTypes(fixture.expected.get(2));
				builder.addFeTypes(fixture.expected.get(3));
				expectedList.add(builder.build());
				builder.clear();
			} else if (mode.equals("case2")) {
				{
					FeTypeTenprint parameter = new FeTypeTenprint();
					parameter.setRolled(new XTemplateRolled() {
						{
							pc2 = new XTemplatePc2() {
								{
									feType = "B";
								}
							};
						}
					});
					parameterList.add(parameter);
				}
				{
					FeTypeTenprint parameter = new FeTypeTenprint();
					parameter.setSlap(new XTemplateSlap() {
						{
							pc2 = new XTemplatePc2() {
								{
									feType = "C";
								}
							};
						}
					});
					parameterList.add(parameter);
				}

				{
					builder.clear();
					PBExtractFeType.Builder feTypeBuilder =
						PBExtractFeType.newBuilder().setFingerType(
							FingerPrintType.FINGER_PRINT_ROLLED).setMinutiaType(
							MinutiaType.MINUTIA_PC2).setFisType(FisTypeType.FIS_TYPE_B);
					builder.addFeTypes(feTypeBuilder);
					builder.setEvent(1);
					expectedList.add(builder.build());
				}
				{
					builder.clear();
					PBExtractFeType.Builder feTypeBuilder =
						PBExtractFeType.newBuilder().setFingerType(
							FingerPrintType.FINGER_PRINT_SLAP).setMinutiaType(
							MinutiaType.MINUTIA_PC2).setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder);
					builder.setEvent(2);
					expectedList.add(builder.build());
				}
			} else if (mode.equals("case3")) {
				{
					FeTypeTenprint parameter = new FeTypeTenprint();
					parameter.setRolled(new XTemplateRolled() {
						{
							pc2 = new XTemplatePc2() {
								{
									feType = "B";
								}
							};
						}
					});
					parameterList.add(parameter);
				}
				{
					FeTypeTenprint parameter = new FeTypeTenprint();
					parameter.setSlap(new XTemplateSlap() {
						{
							pc2 = new XTemplatePc2() {
								{
									feType = "C";
								}
							};
						}
					});
					parameterList.add(parameter);
				}
				{
					FeTypeTenprint parameter = new FeTypeTenprint();
					parameter.setRolled(new XTemplateRolled() {
						{
							fmp5 = new XTemplateFmp5() {
								{
									feType = "E";
								}
							};
						}
					});
					parameterList.add(parameter);
				}
				{
					FeTypeTenprint parameter = new FeTypeTenprint();
					parameter.setSlap(new XTemplateSlap() {
						{
							fmp5 = new XTemplateFmp5() {
								{
									feType = "P";
								}
							};
						}
					});
					parameterList.add(parameter);
				}

				{
					builder.clear();
					PBExtractFeType.Builder feTypeBuilder =
						PBExtractFeType.newBuilder().setFingerType(
							FingerPrintType.FINGER_PRINT_ROLLED).setMinutiaType(
							MinutiaType.MINUTIA_PC2).setFisType(FisTypeType.FIS_TYPE_B);
					builder.addFeTypes(feTypeBuilder);
					builder.setEvent(1);
					expectedList.add(builder.build());
				}
				{
					builder.clear();
					PBExtractFeType.Builder feTypeBuilder =
						PBExtractFeType.newBuilder().setFingerType(
							FingerPrintType.FINGER_PRINT_SLAP).setMinutiaType(
							MinutiaType.MINUTIA_PC2).setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder);
					builder.setEvent(2);
					expectedList.add(builder.build());
				}
				{
					builder.clear();
					PBExtractFeType.Builder feTypeBuilder =
						PBExtractFeType.newBuilder().setFingerType(
							FingerPrintType.FINGER_PRINT_ROLLED).setMinutiaType(
							MinutiaType.MINUTIA_FMP5).setFisType(FisTypeType.FIS_TYPE_E);
					builder.addFeTypes(feTypeBuilder);
					builder.setEvent(3);
					expectedList.add(builder.build());
				}
				{
					builder.clear();
					PBExtractFeType.Builder feTypeBuilder =
						PBExtractFeType.newBuilder().setFingerType(
							FingerPrintType.FINGER_PRINT_SLAP).setMinutiaType(
							MinutiaType.MINUTIA_FMP5).setFisType(FisTypeType.FIS_TYPE_P);
					builder.addFeTypes(feTypeBuilder);
					builder.setEvent(4);
					expectedList.add(builder.build());
				}
			}
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<FeTypeTenprint> parameter;
			public List<PBExtractFeTypeEvent> expected;

			Fixture(List<FeTypeTenprint> parameter, List<PBExtractFeTypeEvent> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper {
		public static Fixture[] fixtures = {
			build("fe-type"), build("no fe-type"), build("multi-fe case1"),
			build("multi-fe case2"), build("multi-fe case3"), build("only rolled"),
			build("only slap"),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(String mode) {
			Parameter parameter = new Parameter();
			PBExtractFeTypeEvent.Builder builder = PBExtractFeTypeEvent.newBuilder();
			List<PBExtractFeTypeEvent> expected = new ArrayList<>();

			if (mode.equals("fe-type")) {
				{
					// added two rolled and slap images
					// fe-type = C
					ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
						ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
							.build("C", "C");
					parameter.inputImageList = fixture.parameter;
					parameter.pbExtractInputImageList = fixture.expected;
				}

				{
					// added two rolled and slap image fe-type
					PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.setEvent(1);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());
				}
			} else if (mode.equals("no fe-type")) {
				{
					ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
						ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
							.build("", "");
					parameter.inputImageList = fixture.parameter;
					parameter.pbExtractInputImageList = fixture.expected;
				}
			} else if (mode.equals("multi-fe case1")) {
				{
					// added two rolled and slap images
					// rolled "MULTI-FE:C,B,P,E"
					// slap "MULTI-FE:E,P,B,C"
					ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
						ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
							.build("MULTI-FE:C,B,P,E", "MULTI-FE:E,P,B,C");
					parameter.inputImageList = fixture.parameter;
					parameter.pbExtractInputImageList = fixture.expected;
				}

				{
					// added two rolled and slap image fe-type
					PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
					builder.setEvent(1);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_E);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(2);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_B);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_P);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(3);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_P);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_B);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(4);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_E);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());
				}
			} else if (mode.equals("multi-fe case2")) {
				{
					// added two rolled and slap images
					// rolled "MULTI-FE:C,B,P,E"
					// slap "MULTI-FE:E,P"
					ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
						ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
							.build("MULTI-FE:C,B,P,E", "MULTI-FE:E,P");
					parameter.inputImageList = fixture.parameter;
					parameter.pbExtractInputImageList = fixture.expected;
				}

				{
					// added two rolled and slap image fe-type
					PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
					builder.setEvent(1);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_E);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(2);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_B);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_P);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(3);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_P);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(4);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_E);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());
				}
			} else if (mode.equals("multi-fe case3")) {
				{
					// added two rolled and slap images
					// rolled "MULTI-FE:C,B"
					// slap "MULTI-FE:E,P,B,C"
					ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
						ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
							.build("MULTI-FE:C,B", "MULTI-FE:E,P,B,C");
					parameter.inputImageList = fixture.parameter;
					parameter.pbExtractInputImageList = fixture.expected;
				}

				{
					// added two rolled and slap image fe-type
					PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
					builder.setEvent(1);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_E);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(2);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_B);
					builder.addFeTypes(feTypeBuilder.build());
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_P);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(3);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_B);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					builder.clear();
					builder.setEvent(4);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());
				}
			} else if (mode.equals("only rolled")) {
				{
					// added one rolled image
					// rolled "B"
					InputImage inputParameter = new InputImage();
					inputParameter.setPos("1");
					inputParameter.setType(ImageFormat.RAW);
					inputParameter.setVertScale(2);
					inputParameter.setHorizScale(3);
					inputParameter.setDpi(4);
					inputParameter.setWidth(5);
					inputParameter.setHeight(6);
					inputParameter.setWhiteBlackLevel(WhiteBlackLevel.BLACKLEVEL);
					inputParameter.setUrl("test");
					inputParameter.setFeType("B");
					parameter.inputImageList = new ArrayList<>();
					parameter.inputImageList.add(inputParameter);

					PBExtractInputImage.Builder imageBuilder =
						PBExtractInputImage.newBuilder();
					imageBuilder.setPosition(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
					imageBuilder.setType(ImageFormatType.RAW);
					imageBuilder.setVertScale(2);
					imageBuilder.setHorizScale(3);
					imageBuilder.setDpi(4);
					imageBuilder.setWidth(5);
					imageBuilder.setHeight(6);
					imageBuilder
						.setWhiteBlackType(ImageWhiteBlackLevelType.IMAGE_LEVEL_BLACK);
					imageBuilder.setUrl("test");
					parameter.pbExtractInputImageList = new ArrayList<>();
					parameter.pbExtractInputImageList.add(imageBuilder.build());
				}
				{
					// added one rolled iamge and fe-type
					PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
					builder.setEvent(1);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_B);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());
				}
			} else if (mode.equals("only slap")) {
				{
					// added one slap image
					// rolled "C"
					InputImage inputParameter = new InputImage();
					inputParameter.setPos("11");
					inputParameter.setType(ImageFormat.RAW);
					inputParameter.setVertScale(2);
					inputParameter.setHorizScale(3);
					inputParameter.setDpi(4);
					inputParameter.setWidth(5);
					inputParameter.setHeight(6);
					inputParameter.setWhiteBlackLevel(WhiteBlackLevel.BLACKLEVEL);
					inputParameter.setUrl("test");
					inputParameter.setFeType("C");
					parameter.inputImageList = new ArrayList<>();
					parameter.inputImageList.add(inputParameter);

					PBExtractInputImage.Builder imageBuilder =
						PBExtractInputImage.newBuilder();
					imageBuilder.setPosition(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
					imageBuilder.setType(ImageFormatType.RAW);
					imageBuilder.setVertScale(2);
					imageBuilder.setHorizScale(3);
					imageBuilder.setDpi(4);
					imageBuilder.setWidth(5);
					imageBuilder.setHeight(6);
					imageBuilder
						.setWhiteBlackType(ImageWhiteBlackLevelType.IMAGE_LEVEL_BLACK);
					imageBuilder.setUrl("test");
					parameter.pbExtractInputImageList = new ArrayList<>();
					parameter.pbExtractInputImageList.add(imageBuilder.build());
				}
				{
					// added one rolled and fe-type
					PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
					builder.setEvent(1);
					feTypeBuilder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());
				}
			}
			parameter.mode = mode;

			return new Fixture(parameter, expected);
		}

		public static class Parameter {
			public List<InputImage> inputImageList;
			public List<PBExtractInputImage> pbExtractInputImageList;
			public String mode;
		}

		public static class Fixture {
			public Parameter parameter;
			public List<PBExtractFeTypeEvent> expected;

			Fixture(Parameter parameter, List<PBExtractFeTypeEvent> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractFeTypeEventWith_LatentInput2Images_Helper {
		public static Fixture[] fixtures = {
			build("fe-type"), build("no fe-type"), build("multi-fe"),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(String mode) {
			Parameter parameter = new Parameter();
			PBExtractFeTypeEvent.Builder builder = PBExtractFeTypeEvent.newBuilder();
			List<PBExtractFeTypeEvent> expected = new ArrayList<>();

			if (mode.equals("fe-type")) {
				{
					// fe-type = C
					InputImage inputImage = new InputImage();
					inputImage.setType(ImageFormat.RAW);
					inputImage.setVertScale(2);
					inputImage.setHorizScale(3);
					inputImage.setDpi(4);
					inputImage.setWidth(5);
					inputImage.setHeight(6);
					inputImage.setWhiteBlackLevel(WhiteBlackLevel.BLACKLEVEL);
					inputImage.setUrl("test");
					inputImage.setFeType("C");

					parameter.images.setImage(inputImage);
				}

				{
					// added two rolled and slap image fe-type
					PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.setEvent(1);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());
				}
			} else if (mode.equals("no fe-type")) {
				{
					InputImage inputImage = new InputImage();
					inputImage.setType(ImageFormat.RAW);
					inputImage.setVertScale(2);
					inputImage.setHorizScale(3);
					inputImage.setDpi(4);
					inputImage.setWidth(5);
					inputImage.setHeight(6);
					inputImage.setWhiteBlackLevel(WhiteBlackLevel.BLACKLEVEL);
					inputImage.setUrl("test");

					parameter.images.setImage(inputImage);
				}
			} else if (mode.equals("multi-fe")) {
				{
					// fe-type = C
					InputImage inputImage = new InputImage();
					inputImage.setType(ImageFormat.RAW);
					inputImage.setVertScale(2);
					inputImage.setHorizScale(3);
					inputImage.setDpi(4);
					inputImage.setWidth(5);
					inputImage.setHeight(6);
					inputImage.setWhiteBlackLevel(WhiteBlackLevel.BLACKLEVEL);
					inputImage.setUrl("test");
					inputImage.setFeType("MULTI-FE:C,B,P,E");

					parameter.images.setImage(inputImage);
				}

				{
					// added two rolled and slap image fe-type
					PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
					builder.clear();
					builder.setEvent(1);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_B);
					builder.clear();
					builder.setEvent(2);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_P);
					builder.clear();
					builder.setEvent(3);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());

					feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_E);
					builder.clear();
					builder.setEvent(4);
					builder.addFeTypes(feTypeBuilder.build());
					expected.add(builder.build());
				}
			}
			parameter.mode = mode;

			return new Fixture(parameter, expected);
		}

		public static class Parameter {
			public LatentInput.Images images = new LatentInput.Images();
			public List<PBExtractInputImage> pbExtractInputImageList;
			public String mode;
		}

		public static class Fixture {
			public Parameter parameter;
			public List<PBExtractFeTypeEvent> expected;

			Fixture(Parameter parameter, List<PBExtractFeTypeEvent> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBAimFormatWith_TenprintInput_ListOfPBExtractInputImages_Helper {
		public static Fixture build() {
			Parameter parameter = new Parameter();
			parameter.tenprintInput = new TenprintInput();
			PBAimFormat.Builder builder = PBAimFormat.newBuilder();

			AimFormats aimFormats = new AimFormats();
			aimFormats.getFmt().add(ExtractionFormats.TR_XDBL);
			aimFormats.getFmt().add(ExtractionFormats.TLI_X);
			aimFormats.getFmt().add(ExtractionFormats.TR_RDBL);
			aimFormats.getFmt().add(ExtractionFormats.TR_RDBL_S);
			aimFormats.getFmt().add(ExtractionFormats.TR_RDBT_M);
			parameter.tenprintInput.setAimformats(aimFormats);

			{
				ToPBExtractFeTypeWith_FeTypeTenprint_Helper.Fixture fixture =
					ToPBExtractFeTypeWith_FeTypeTenprint_Helper.build();

				FeTypes feTypes = new FeTypes();
				feTypes.getXdbl().add(fixture.parameter);
				feTypes.setTlix(fixture.parameter);
				parameter.tenprintInput.setFeTypes(feTypes);
			}
			{
				ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
					ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
						.build("C", "C");
				parameter.extractInputImageList = fixture.expected;

				TenprintInput.Images images = new TenprintInput.Images();
				images.getImage().addAll(fixture.parameter);
				parameter.tenprintInput.setImages(images);
			}

			List<PBAimFormat> expectedList = new ArrayList<>();

			{
				ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints_Helper.Fixture fixture =
					ToPBExtractFeTypeEventWith_ListOfFeTypeTenprints_Helper
						.build("case1");
				builder.setFormat(TemplateFormatType.TEMPLATE_RDBLX);
				builder.addFeTypeEvents(fixture.expected.get(0));
				expectedList.add(builder.build());

				builder.clearFeTypeEvents();
				builder.setFormat(TemplateFormatType.TEMPLATE_TLIX);
				builder.addFeTypeEvents(fixture.expected.get(0));
				expectedList.add(builder.build());
			}

			{
				ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper.Fixture fixture =
					ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper
						.build("fe-type");
				builder.clearFeTypeEvents();
				builder.setFormat(TemplateFormatType.TEMPLATE_RDBL);
				builder.addAllFeTypeEvents(fixture.expected);
				expectedList.add(builder.build());

				builder.clearFeTypeEvents();
				builder.setFormat(TemplateFormatType.TEMPLATE_RDBLS);
				builder.addAllFeTypeEvents(fixture.expected);
				expectedList.add(builder.build());
			}
			{
				ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper.Fixture fixture =
					ToPBExtractFeTypeEventWith_ListOfInputImage_ListOfPBExtractInputImage_Helper
						.build("fe-type");
				builder.clearFeTypeEvents();
				builder.setFormat(TemplateFormatType.TEMPLATE_RDBTM);
				builder.addAllFeTypeEvents(fixture.expected);
				expectedList.add(builder.build());
			}

			return new Fixture(parameter, expectedList);
		}

		public static class Parameter {
			public TenprintInput tenprintInput;
			public List<PBExtractInputImage> extractInputImageList;
		}

		public static class Fixture {
			public Parameter parameter;
			public List<PBAimFormat> expected;

			Fixture(Parameter parameter, List<PBAimFormat> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class DivideFeTypesWith_String_Helper {
		public static Fixture[] fixtures = {
			build("C", new String[] {
				"C"
			}), build("MULTI-FE:C", new String[] {
				"C"
			}), build("MULTI-FE:C,B", new String[] {
				"C", "B"
			}), build("MULTI-FE:C,B,E", new String[] {
				"C", "B", "E"
			}), build("MULTI-FE:C,B,E,F", new String[] {
				"C", "B", "E", "F"
			}),
		};

		public static Fixture build(String feTypes, String[] divideTypes) {
			return new Fixture(feTypes, divideTypes);
		}

		public static class Fixture {
			public String parameter;
			public String[] expected;

			Fixture(String parameter, String[] expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFisCore_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			TenprintInput.InputMinutia.InputMinutiaData.Core parameter =
				new TenprintInput.InputMinutia.InputMinutiaData.Core();
			PBFisCore.Builder builder = PBFisCore.newBuilder();

			parameter.setA((short)1);
			builder.setA("1");

			parameter.setF((short)2);
			builder.setF("2");

			parameter.setCC((short)3);
			builder.setCC("3");

			parameter.setQP("4");
			builder.setQP("4");

			parameter.setQD((short)5);
			builder.setQD("5");

			parameter.setQQ((short)6);
			builder.setQQ("6");

			parameter.setX(7);
			builder.setX(7);

			parameter.setY(8);
			builder.setY(8);

			parameter.setD(9);
			builder.setD(9);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public TenprintInput.InputMinutia.InputMinutiaData.Core parameter;
			public PBFisCore expected;

			Fixture(TenprintInput.InputMinutia.InputMinutiaData.Core parameter,
				PBFisCore expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFisQuality_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			TenprintInput.InputMinutia.InputMinutiaData.Quality parameter =
				new TenprintInput.InputMinutia.InputMinutiaData.Quality();
			PBFisQuality.Builder builder = PBFisQuality.newBuilder();

			parameter.setVA((short)10);
			builder.setVA("10");

			parameter.setVB((short)20);
			builder.setVB("20");

			parameter.setVC((short)30);
			builder.setVC("30");

			parameter.setS("40");
			builder.setS("40");

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public TenprintInput.InputMinutia.InputMinutiaData.Quality parameter;
			public PBFisQuality expected;

			Fixture(TenprintInput.InputMinutia.InputMinutiaData.Quality parameter,
				PBFisQuality expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFisMinutiaNo_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo parameter =
				new TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo();
			PBFisMinutiaNo.Builder builder = PBFisMinutiaNo.newBuilder();

			parameter.setDB(10);
			builder.setDB(10);

			parameter.setMB(20);
			builder.setMB(20);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo parameter;
			public PBFisMinutiaNo expected;

			Fixture(TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo parameter,
				PBFisMinutiaNo expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFisData_Helper {
		public static ToPBFisData_Helper.Fixture build() {
			TenprintInput.InputMinutia.InputMinutiaData parameter =
				new TenprintInput.InputMinutia.InputMinutiaData();
			PBFisData.Builder builder = PBFisData.newBuilder();

			{
				ToPBFisCore_Helper.Fixture fixture = ToPBFisCore_Helper.build();
				parameter.setCore(fixture.parameter);
				builder.setFisCore(fixture.expected);
			}
			{
				ToPBFisQuality_Helper.Fixture fixture = ToPBFisQuality_Helper.build();
				parameter.setQuality(fixture.parameter);
				builder.setFisQuality(fixture.expected);
			}
			{
				ToPBFisMinutiaNo_Helper.Fixture fixture = ToPBFisMinutiaNo_Helper.build();
				parameter.setMinutiaNo(fixture.parameter);
				builder.setFisMinutiaNo(fixture.expected);
			}

			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				parameter.setMinutiaData(binary);
				builder.setMinutia(ByteString.copyFrom(binary));
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				parameter.setZone(binary);
				builder.setZone(ByteString.copyFrom(binary));
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				parameter.setSkeleton(binary);
				builder.setSkeleton(ByteString.copyFrom(binary));
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public TenprintInput.InputMinutia.InputMinutiaData parameter;
			public PBFisData expected;

			Fixture(TenprintInput.InputMinutia.InputMinutiaData parameter,
				PBFisData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBInputMinutiaData_Helper {
		public static Fixture build(String type) {
			PBInputMinutiaData.Builder builder = PBInputMinutiaData.newBuilder();
			Parameter parameter = new Parameter();
			parameter.inputMinutiaData = new ArrayList<>();
			List<PBInputMinutiaData> expectedList = new ArrayList<>();

			if (type.equals("fis")) {
				ToPBFisData_Helper.Fixture fixture = ToPBFisData_Helper.build();
				fixture.parameter.setPos("1");
				parameter.inputMinutiaData.add(fixture.parameter);
				parameter.minutiaType = MinutiaType.MINUTIA_FIS;

				builder.setFisData(fixture.expected);
				builder.setPosition(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
				expectedList.add(builder.build());
			} else if (type.equals("binary")) {
				TenprintInput.InputMinutia.InputMinutiaData inputMinutia =
					new TenprintInput.InputMinutia.InputMinutiaData();
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				inputMinutia.setMinutiaData(binary);
				builder.setData(ByteString.copyFrom(binary));

				inputMinutia.setPos("1");
				parameter.inputMinutiaData.add(inputMinutia);
				parameter.minutiaType = MinutiaType.MINUTIA_PC2;

				builder.setPosition(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
				expectedList.add(builder.build());
			}
			return new Fixture(parameter, expectedList);
		}

		public static class Parameter {
			public MinutiaType minutiaType;
			public List<TenprintInput.InputMinutia.InputMinutiaData> inputMinutiaData;
		}

		public static class Fixture {
			public Parameter parameter;
			public List<PBInputMinutiaData> expected;

			Fixture(Parameter parameter, List<PBInputMinutiaData> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputMinutiaTenprint_Helper {
		public static Fixture build() {
			TenprintInput.InputMinutia parameter = new TenprintInput.InputMinutia();
			PBExtractInputMinutiaTenprint.Builder builder =
				PBExtractInputMinutiaTenprint.newBuilder();

			parameter.setDbType("RDBTM");
			builder.setDbType(MinutiaDbType.MINUTIA_DB_RDBTM);

			parameter.setMinutiaType("PC2");
			builder.setMinutiaType(MinutiaType.MINUTIA_PC2);

			ToPBInputMinutiaData_Helper.Fixture fixture =
				ToPBInputMinutiaData_Helper.build("binary");
			parameter.getInputMinutiaData().addAll(fixture.parameter.inputMinutiaData);
			builder.addAllMinutiaData(fixture.expected);

			List<TenprintInput.InputMinutia> parameterList = new ArrayList<>();
			parameterList.add(parameter);
			List<PBExtractInputMinutiaTenprint> expectedList = new ArrayList<>();
			expectedList.add(builder.build());
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<TenprintInput.InputMinutia> parameter;
			public List<PBExtractInputMinutiaTenprint> expected;

			Fixture(List<TenprintInput.InputMinutia> parameter,
				List<PBExtractInputMinutiaTenprint> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBPrefilterOptions_Helper {
		public static Fixture[] fixtures = {
			build("true"), build("null"),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(String mode) {
			PrefilterOptions parameter = new PrefilterOptions();
			PBPrefilterOptions.Builder builder = PBPrefilterOptions.newBuilder();

			if (mode.equals("true")) {
				parameter.setUpdatePrefilter(true);
				builder.setUpdatePrefilter(true);

				parameter.setYobMethod("1");
				builder.setYobMethod(PrefilterYobMethodType.YOB_METHOD_THRESHOLD);

				parameter.setUseYobFRange(true);
				builder.setUseYobFRange(true);

				ToPBUsePrefilterInfo_Helper.Fixture fixture =
					ToPBUsePrefilterInfo_Helper.build("true");
				parameter.setUsePrefilterInfo(fixture.parameter);
			} else if (mode.equals("null")) {
				builder.setUpdatePrefilter(false);
				builder.setUseYobFRange(false);
			}

			return new Fixture(parameter, builder.build(), mode);
		}

		public static class Fixture {
			public PrefilterOptions parameter;
			public PBPrefilterOptions expected;
			public String mode;

			Fixture(PrefilterOptions parameter, PBPrefilterOptions expected, String mode) {
				this.parameter = parameter;
				this.expected = expected;
				this.mode = mode;
			}
		}
	}

	public static class ToPBBasicImageEnhanceOptionsWith_ImageEnhance_Helper {
		public static Fixture build() {
			ImageEnhance parameter = new ImageEnhance();
			PBBasicImageEnhanceOptions.Builder builder =
				PBBasicImageEnhanceOptions.newBuilder();

			ToListBasicImageEnhanceType_Helper.Fixture fixture =
				ToListBasicImageEnhanceType_Helper.build();
			parameter.getEnhType().addAll(fixture.parameter);
			builder.addAllEnhancements(fixture.expected);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public ImageEnhance parameter;
			public PBBasicImageEnhanceOptions expected;

			Fixture(ImageEnhance parameter, PBBasicImageEnhanceOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToListBasicImageEnhanceType_Helper {
		public static Fixture build() {
			List<EnhType> parameterList = new ArrayList<>();
			parameterList.add(EnhType.ENH_AGC);

			List<BasicImageEnhanceType> expectedList = new ArrayList<>();
			expectedList.add(BasicImageEnhanceType.IMAGE_ENHANCE_AGC);
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<EnhType> parameter;
			public List<BasicImageEnhanceType> expected;

			Fixture(List<EnhType> parameter, List<BasicImageEnhanceType> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBQualityCheckOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			QcInput parameter = new QcInput();
			PBQualityCheckOptions.Builder builder = PBQualityCheckOptions.newBuilder();

			parameter.setQcMode(QcMode.QC_MODE_ADVANCED);
			builder.setQcMode(QualityCheckModeType.QC_MODE_ADVANCED);

			parameter.setDuplicateCheckThreshold(1);
			builder.setDuplicateCheckThreshold(1);

			parameter.setSlapConfidenceThreshold(2);
			builder.setSlapConfidenceThreshold(2);

			parameter.setSlapHandConfidenceThreshold(3);
			builder.setSlapHandConfidenceThreshold(3);

			parameter.setSequenceCheckThreshold(4);
			builder.setSequenceCheckThreshold(4);

			parameter.setSequenceCheckThresholdLittle(5);
			builder.setSequenceCheckThresholdLittle(5);

			parameter.setRolledQualityThreshold(6);
			builder.setRolledQualityThreshold(6);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public QcInput parameter;
			public PBQualityCheckOptions expected;

			Fixture(QcInput parameter, PBQualityCheckOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBCmlafExtractParam_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			List<TenprintInput.CmlafExtOptions.TemplateParam> parameterList =
				new ArrayList<>();
			List<PBCMLaFExtractParam> expectedList = new ArrayList<>();
			PBCMLaFExtractParam.Builder builder = PBCMLaFExtractParam.newBuilder();
			{
				TenprintInput.CmlafExtOptions.TemplateParam parameter =
					new TenprintInput.CmlafExtOptions.TemplateParam();

				parameter.setFetype(9);
				builder.setFeType(CMLaFFeTypeType.CMLAF_FE_TYPE_FE);

				parameter.setLimitofminutiacount(1);
				builder.setLimitOfMinutiaCount(1);

				TenprintInput.CmlafExtOptions.TemplateParam.Enhancements enhancements =
					new TenprintInput.CmlafExtOptions.TemplateParam.Enhancements();
				enhancements.getEnhType().add(CmlafEnhType.CMLaF_ENH_C2);
				parameter.setEnhancements(enhancements);
				builder.addEnhancements(CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_C2);

				parameter.setTemplatenum(1);
				parameterList.add(parameter);

				builder.setTemplateNum(1);
				expectedList.add(builder.build());
			}
			{
				TenprintInput.CmlafExtOptions.TemplateParam parameter =
					new TenprintInput.CmlafExtOptions.TemplateParam();

				parameter.setFetype(9);
				builder.setFeType(CMLaFFeTypeType.CMLAF_FE_TYPE_FE);

				parameter.setLimitofminutiacount(1);
				builder.setLimitOfMinutiaCount(1);

				TenprintInput.CmlafExtOptions.TemplateParam.Enhancements enhancements =
					new TenprintInput.CmlafExtOptions.TemplateParam.Enhancements();
				enhancements.getEnhType().add(CmlafEnhType.CMLaF_ENH_C2);
				parameter.setEnhancements(enhancements);
				builder.addEnhancements(CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_C2);

				parameter.setTemplatenum(3);
				parameterList.add(parameter);

				builder.setTemplateNum(3);
				expectedList.add(builder.build());
			}

			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<TenprintInput.CmlafExtOptions.TemplateParam> parameter;
			public List<PBCMLaFExtractParam> expected;

			Fixture(List<TenprintInput.CmlafExtOptions.TemplateParam> parameter,
				List<PBCMLaFExtractParam> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractCmlafOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			CmlafExtOptions parameter = new CmlafExtOptions();
			PBExtractCMLaFOptions.Builder builder = PBExtractCMLaFOptions.newBuilder();

			ToPBCmlafExtractParam_Helper.Fixture fixture =
				ToPBCmlafExtractParam_Helper.build();

			parameter.setMultiplicity(2);
			builder.setMultiplicity(2);

			parameter.getTemplateParam().addAll(fixture.parameter);
			builder.addAllParams(fixture.expected);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public CmlafExtOptions parameter;
			public PBExtractCMLaFOptions expected;

			Fixture(CmlafExtOptions parameter, PBExtractCMLaFOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractCmlOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			CmlExtOptions parameter = new CmlExtOptions();
			PBExtractCMLOptions.Builder builder = PBExtractCMLOptions.newBuilder();

			parameter.setParameterId(2);
			builder.setParameterId(2);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public CmlExtOptions parameter;
			public PBExtractCMLOptions expected;

			Fixture(CmlExtOptions parameter, PBExtractCMLOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractCommonOptionTenprint_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			TenprintInput parameter = new TenprintInput();
			PBExtractCommonOptionTenprint.Builder builder =
				PBExtractCommonOptionTenprint.newBuilder();

			parameter.setExtInfoMode(ExtInfoModeFormat.EXTINFO_RESULTINFO);
			builder.setOutputMode(ExtractOutputModeType.EXTRACT_OUTPUT_MODE_INFO);

			parameter.setReExtract(true);
			builder.setReExtract(true);

			parameter.setReturnCroppedImages(true);
			builder.setReturnCroppedImages(true);

			parameter.setReturnLowResImages(true);
			builder.setReturnLowResolutionImages(true);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public TenprintInput parameter;
			public PBExtractCommonOptionTenprint expected;

			Fixture(TenprintInput parameter, PBExtractCommonOptionTenprint expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractTenprintInput_Helper {
		public static Fixture build() {
			TenprintInput parameter = new TenprintInput();
			PBExtractTenprintInput.Builder builder = PBExtractTenprintInput.newBuilder();

			{
				ToPBAimFormatWith_TenprintInput_ListOfPBExtractInputImages_Helper.Fixture fixture =
					ToPBAimFormatWith_TenprintInput_ListOfPBExtractInputImages_Helper
						.build();
				parameter.setAimformats(fixture.parameter.tenprintInput.getAimformats());
				parameter.setFeTypes(fixture.parameter.tenprintInput.getFeTypes());
				builder.addAllAimFormats(fixture.expected);
			}
			{
				ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper.Fixture fixture =
					ToPBExtractInputImageWith_ListOfInputImages_ListOfPBExtractInputImages_Helper
						.build("C", "C");

				TenprintInput.Images images = new TenprintInput.Images();
				images.getImage().addAll(fixture.parameter);
				parameter.setImages(images);
				builder.addAllImages(fixture.expected);
			}
			{
				ToPBExtractInputMinutiaTenprint_Helper.Fixture fixture =
					ToPBExtractInputMinutiaTenprint_Helper.build();
				parameter.getInputMinutia().addAll(fixture.parameter);
				builder.addAllMinutia(fixture.expected);
			}
			{
				ToPBMetaInfo_Helper.Fixture fixture = ToPBMetaInfo_Helper.build();
				parameter.setMetaInfo(fixture.parameter);
				builder.setMetaInfo(fixture.expected);
			}
			{
				ToPBPrefilterOptions_Helper.Fixture fixture =
					ToPBPrefilterOptions_Helper.build("true");
				parameter.setPrefilterOptions(fixture.parameter);
				builder.setPrefilterOptions(fixture.expected);
			}
			{
				ToPBBasicImageEnhanceOptionsWith_ImageEnhance_Helper.Fixture fixture =
					ToPBBasicImageEnhanceOptionsWith_ImageEnhance_Helper.build();
				parameter.setEnhancements(fixture.parameter);
				builder.setBasicEnhanceOptions(fixture.expected);
			}
			{
				ToPBQualityCheckOptions_Helper.Fixture fixture =
					ToPBQualityCheckOptions_Helper.build();
				parameter.setQcInput(fixture.parameter);
				builder.setQualityCheckOptions(fixture.expected);
			}
			{
				ToPBExtractCmlafOptions_Helper.Fixture fixture =
					ToPBExtractCmlafOptions_Helper.build();
				parameter.setCmlafExtOptions(fixture.parameter);
				builder.setCmalfOptions(fixture.expected);
			}
			{
				ToPBExtractCmlOptions_Helper.Fixture fixture =
					ToPBExtractCmlOptions_Helper.build();
				parameter.setCmlExtOptions(fixture.parameter);
				builder.setCmlOptions(fixture.expected);
			}
			{
				ToPBExtractCommonOptionTenprint_Helper.Fixture fixture =
					ToPBExtractCommonOptionTenprint_Helper.build();
				parameter.setExtInfoMode(fixture.parameter.getExtInfoMode());
				parameter.setReExtract(fixture.parameter.isReExtract());
				parameter.setReturnCroppedImages(fixture.parameter
					.isReturnCroppedImages());
				parameter.setReturnLowResImages(fixture.parameter.isReturnLowResImages());
				builder.setCommonOptions(fixture.expected);
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public TenprintInput parameter;
			public PBExtractTenprintInput expected;

			Fixture(TenprintInput parameter, PBExtractTenprintInput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBAimFormatWith_Latent_Helper {
		public static Fixture build() {
			// parameter
			LatentInput parameter = new LatentInput();
			PBAimFormat.Builder builder = PBAimFormat.newBuilder();

			AimFormats aimFormats = new AimFormats();
			aimFormats.getFmt().add(ExtractionFormats.LR_X);
			aimFormats.getFmt().add(ExtractionFormats.LI_X);
			aimFormats.getFmt().add(ExtractionFormats.LLI_X);
			aimFormats.getFmt().add(ExtractionFormats.LR_P);
			aimFormats.getFmt().add(ExtractionFormats.LI);
			aimFormats.getFmt().add(ExtractionFormats.LLI);
			aimFormats.getFmt().add(ExtractionFormats.LR);
			aimFormats.getFmt().add(ExtractionFormats.LI_S);
			aimFormats.getFmt().add(ExtractionFormats.LLI_S);
			aimFormats.getFmt().add(ExtractionFormats.LR_S);
			parameter.setAimformats(aimFormats);
			{
				ToPBExtractFeTypeWith_FeTypeLatent_Helper.Fixture fixture =
					ToPBExtractFeTypeWith_FeTypeLatent_Helper.build();

				FeTypes feTypes = new FeTypes();
				feTypes.setLdbx(fixture.parameter);
				feTypes.setLix(fixture.parameter);
				feTypes.setLlix(fixture.parameter);
				parameter.setFeTypes(feTypes);
			}
			{
				ToPBExtractInputImageWith_LatentInput2Images_Helper.Fixture fixture =
					ToPBExtractInputImageWith_LatentInput2Images_Helper.build();

				parameter.setImages(fixture.parameter);
			}
			{
				ToPBExtractFeTypeEventWith_LatentInput2Images_Helper.Fixture fixture =
					ToPBExtractFeTypeEventWith_LatentInput2Images_Helper.build("fe-type");
				parameter.getImages().getImage().setFeType(
					fixture.parameter.images.getImage().getFeType());
			}

			// expected
			List<PBAimFormat> expectedList = new ArrayList<>();
			{
				ToPBExtractFeTypeEventWith_FeTypeLatent_Helper.Fixture fixture =
					ToPBExtractFeTypeEventWith_FeTypeLatent_Helper.build();
				builder.setFormat(TemplateFormatType.TEMPLATE_LDBX);
				builder.addFeTypeEvents(fixture.expected);
				expectedList.add(builder.build());

				builder.clearFeTypeEvents();
				builder.setFormat(TemplateFormatType.TEMPLATE_LIX);
				builder.addFeTypeEvents(fixture.expected);
				expectedList.add(builder.build());

				builder.clearFeTypeEvents();
				builder.setFormat(TemplateFormatType.TEMPLATE_LLIX);
				builder.addFeTypeEvents(fixture.expected);
				expectedList.add(builder.build());
			}
			{
				builder.clearFeTypeEvents();
				builder.setFormat(TemplateFormatType.TEMPLATE_PLDB);
				expectedList.add(builder.build());
			}
			{
				builder.setFormat(TemplateFormatType.TEMPLATE_LI);
				PBExtractFeTypeEvent.Builder eventBuilder =
					PBExtractFeTypeEvent.newBuilder();
				PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
				feTypeBuilder.setFisType(FisTypeType.FIS_TYPE_C);
				eventBuilder.setEvent(1);
				eventBuilder.addFeTypes(feTypeBuilder.build());
				eventBuilder.addFeTypes(feTypeBuilder);
				builder.addFeTypeEvents(eventBuilder);
				expectedList.add(builder.build());

				builder.setFormat(TemplateFormatType.TEMPLATE_LLI);
				expectedList.add(builder.build());

				builder.setFormat(TemplateFormatType.TEMPLATE_LDB);
				expectedList.add(builder.build());

				builder.setFormat(TemplateFormatType.TEMPLATE_LIS);
				expectedList.add(builder.build());

				builder.setFormat(TemplateFormatType.TEMPLATE_LLIS);
				expectedList.add(builder.build());

				builder.setFormat(TemplateFormatType.TEMPLATE_LDBS);
				expectedList.add(builder.build());
			}

			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public LatentInput parameter;
			public List<PBAimFormat> expected;

			Fixture(LatentInput parameter, List<PBAimFormat> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractFeTypeEventWith_FeTypeLatent_Helper {
		public static Fixture build() {
			PBExtractFeTypeEvent.Builder builder = PBExtractFeTypeEvent.newBuilder();

			ToPBExtractFeTypeWith_FeTypeLatent_Helper.Fixture fixture =
				ToPBExtractFeTypeWith_FeTypeLatent_Helper.build();

			builder.setEvent(1);
			builder.addFeTypes(fixture.expected.get(0));
			builder.addFeTypes(fixture.expected.get(1));

			return new Fixture(fixture.parameter, builder.build());
		}

		public static class Fixture {
			public FeTypeLatent parameter;
			public PBExtractFeTypeEvent expected;

			Fixture(FeTypeLatent parameter, PBExtractFeTypeEvent expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractFeTypeWith_FeTypeLatent_Helper {
		public static Fixture build() {
			FeTypeLatent parameter = new FeTypeLatent();
			PBExtractFeType.Builder builder = PBExtractFeType.newBuilder();
			List<PBExtractFeType> expectedList = new ArrayList<>();

			XTemplateLatent latent = new XTemplateLatent();
			{
				XTemplatePc2 pc2 = new XTemplatePc2();
				pc2.setFeType("B");
				latent.setPc2(pc2);
				builder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.setFisType(FisTypeType.FIS_TYPE_B);
				builder.setMinutiaType(MinutiaType.MINUTIA_PC2);
				expectedList.add(builder.build());

				XTemplateFmp5 fmp5 = new XTemplateFmp5();
				fmp5.setFeType("C");
				latent.setFmp5(fmp5);
				builder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.setFisType(FisTypeType.FIS_TYPE_C);
				builder.setMinutiaType(MinutiaType.MINUTIA_FMP5);
				expectedList.add(builder.build());

				parameter.setLatent(latent);
			}

			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public FeTypeLatent parameter;
			public List<PBExtractFeType> expected;

			Fixture(FeTypeLatent parameter, List<PBExtractFeType> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputImageWith_LatentInput2Images_Helper {
		public static Fixture build() {
			LatentInput.Images parameter = new LatentInput.Images();

			InputImage inputImage = new InputImage();
			inputImage.setType(ImageFormat.RAW);
			inputImage.setVertScale(Integer.valueOf(2));
			inputImage.setHorizScale(Integer.valueOf(3));
			inputImage.setDpi(Integer.valueOf(4));
			inputImage.setWidth(Integer.valueOf(5));
			inputImage.setHeight(Integer.valueOf(6));
			inputImage.setWhiteBlackLevel(WhiteBlackLevel.BLACKLEVEL);
			inputImage.setUrl("test");
			parameter.setImage(inputImage);

			PBExtractInputImage.Builder builder = PBExtractInputImage.newBuilder();
			builder.setType(ImageFormatType.RAW);
			builder.setVertScale(2);
			builder.setHorizScale(3);
			builder.setDpi(4);
			builder.setWidth(5);
			builder.setHeight(6);
			builder.setWhiteBlackType(ImageWhiteBlackLevelType.IMAGE_LEVEL_BLACK);
			builder.setUrl("test");

			List<PBExtractInputImage> expectedList = new ArrayList<>();
			expectedList.add(builder.build());
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public LatentInput.Images parameter;
			public List<PBExtractInputImage> expected;

			Fixture(LatentInput.Images parameter, List<PBExtractInputImage> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputMinutiaLatent_Helper {
		public static Fixture build() {
			jp.co.nec.aim.mm.jaxb.MinutiaType parameter =
				new jp.co.nec.aim.mm.jaxb.MinutiaType();
			PBExtractInputMinutiaLatent.Builder builder =
				PBExtractInputMinutiaLatent.newBuilder();

			parameter.setMinutiaType("PC2");
			builder.setType(MinutiaType.MINUTIA_PC2);

			byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
			parameter.setData(binary);
			builder.setMinutiaData(ByteString.copyFrom(binary));

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public jp.co.nec.aim.mm.jaxb.MinutiaType parameter;
			public PBExtractInputMinutiaLatent expected;

			Fixture(jp.co.nec.aim.mm.jaxb.MinutiaType parameter,
				PBExtractInputMinutiaLatent expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputMarkUp_Helper {
		public static Fixture build() {
			MarkUp parameter = new MarkUp();
			PBExtractInputMarkUp.Builder builder = PBExtractInputMarkUp.newBuilder();

			byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
			parameter.setData(binary);
			builder.setMarkUpData(ByteString.copyFrom(binary));

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public MarkUp parameter;
			public PBExtractInputMarkUp expected;

			Fixture(MarkUp parameter, PBExtractInputMarkUp expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractLatentInput_Helper {
		public static Fixture build() {
			LatentInput parameter = new LatentInput();
			PBExtractLatentInput.Builder builder = PBExtractLatentInput.newBuilder();

			{
				ToPBAimFormatWith_Latent_Helper.Fixture fixture =
					ToPBAimFormatWith_Latent_Helper.build();
				parameter.setAimformats(fixture.parameter.getAimformats());
				parameter.setFeTypes(fixture.parameter.getFeTypes());
				builder.addAllAimFormats(fixture.expected);
			}
			{
				ToPBExtractInputImageWith_LatentInput2Images_Helper.Fixture fixture =
					ToPBExtractInputImageWith_LatentInput2Images_Helper.build();
				parameter.setImages(fixture.parameter);
				builder.setImage(fixture.expected.get(0));
			}
			{
				ToPBExtractInputMinutiaLatent_Helper.Fixture fixture =
					ToPBExtractInputMinutiaLatent_Helper.build();
				parameter.setMinutia(fixture.parameter);
				builder.setMinutia(fixture.expected);
			}
			{
				ToPBExtractInputMarkUp_Helper.Fixture fixture =
					ToPBExtractInputMarkUp_Helper.build();
				parameter.setMarkUp(fixture.parameter);
				builder.setMarkUp(fixture.expected);
			}
			{
				ToPBMetaInfo_Helper.Fixture fixture = ToPBMetaInfo_Helper.build();
				parameter.setMetaInfo(fixture.parameter);
				builder.setMetaInfo(fixture.expected);
			}
			{
				ToPBPrefilterOptions_Helper.Fixture fixture =
					ToPBPrefilterOptions_Helper.build("true");
				parameter.setPrefilterOptions(fixture.parameter);
				builder.setPrefilterOptions(fixture.expected);
			}
			{
				ToPBBasicImageEnhanceOptionsWith_LatentInput2Enhancements_Helper.Fixture fixture =
					ToPBBasicImageEnhanceOptionsWith_LatentInput2Enhancements_Helper
						.build();
				parameter.setEnhancements(fixture.parameter);
				builder.setBasicEnhanceOptions(fixture.expected);
			}

			parameter.setExtInfoMode(ExtInfoModeFormat.EXTINFO_TEMPLATE);
			PBExtractCommonOptionLatent.Builder optionBuilder =
				PBExtractCommonOptionLatent.newBuilder();
			optionBuilder
				.setOutputMode(ExtractOutputModeType.EXTRACT_OUTPUT_MODE_TEMPLATE);
			builder.setCommonOptions(optionBuilder);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public LatentInput parameter;
			public PBExtractLatentInput expected;

			Fixture(LatentInput parameter, PBExtractLatentInput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBBasicImageEnhanceOptionsWith_LatentInput2Enhancements_Helper {
		public static Fixture build() {
			LatentInput.Enhancements parameter = new LatentInput.Enhancements();
			PBBasicImageEnhanceOptions.Builder builder =
				PBBasicImageEnhanceOptions.newBuilder();

			ToListBasicImageEnhanceType_Helper.Fixture fixture =
				ToListBasicImageEnhanceType_Helper.build();
			parameter.getEnhType().addAll(fixture.parameter);
			builder.addAllEnhancements(fixture.expected);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public LatentInput.Enhancements parameter;
			public PBBasicImageEnhanceOptions expected;

			Fixture(LatentInput.Enhancements parameter,
				PBBasicImageEnhanceOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBPoint_FacePoint_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(int x, int y) {
			PBPoint.Builder builder = PBPoint.newBuilder();
			builder.setX(x);
			builder.setY(y);

			FacePoint parameter = new FacePoint();
			parameter.setX(x);
			parameter.setY(y);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public FacePoint parameter;
			public PBPoint expected;

			Fixture(FacePoint parameter, PBPoint expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFace13Points_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			FaceInputExtraction13Points parameter = new FaceInputExtraction13Points();
			FacePoint point = null;
			PBFace13Points.Builder builder = PBFace13Points.newBuilder();
			PBPoint.Builder pointBuilder = PBPoint.newBuilder();

			point = new FacePoint();
			point.setX(1);
			point.setY(2);
			parameter.setRightEyeCenter(point);
			pointBuilder.setX(1);
			pointBuilder.setY(2);
			builder.setRightEyeCenter(pointBuilder.build());

			point = new FacePoint();
			point.setX(3);
			point.setY(4);
			parameter.setLeftEyeCenter(point);
			pointBuilder.setX(3);
			pointBuilder.setY(4);
			builder.setLeftEyeCenter(pointBuilder.build());

			point = new FacePoint();
			point.setX(5);
			point.setY(6);
			parameter.setRightEyeInnerCorner(point);
			pointBuilder.setX(5);
			pointBuilder.setY(6);
			builder.setRightEyeInnerCorner(pointBuilder.build());

			point = new FacePoint();
			point.setX(7);
			point.setY(8);
			parameter.setLeftEyeInnerCorner(point);
			pointBuilder.setX(7);
			pointBuilder.setY(8);
			builder.setLeftEyeInnerCorner(pointBuilder.build());

			point = new FacePoint();
			point.setX(9);
			point.setY(10);
			parameter.setRightEyeOuterCorner(point);
			pointBuilder.setX(9);
			pointBuilder.setY(10);
			builder.setRightEyeOuterCorner(pointBuilder.build());

			point = new FacePoint();
			point.setX(11);
			point.setY(12);
			parameter.setLeftEyeOuterCorner(point);
			pointBuilder.setX(11);
			pointBuilder.setY(12);
			builder.setLeftEyeOuterCorner(pointBuilder.build());

			point = new FacePoint();
			point.setX(13);
			point.setY(14);
			parameter.setCenterBelowNose(point);
			pointBuilder.setX(13);
			pointBuilder.setY(14);
			builder.setCenterBelowNose(pointBuilder.build());

			point = new FacePoint();
			point.setX(15);
			point.setY(16);
			parameter.setRightSideNose(point);
			pointBuilder.setX(15);
			pointBuilder.setY(16);
			builder.setRightSideNose(pointBuilder.build());

			point = new FacePoint();
			point.setX(17);
			point.setY(18);
			parameter.setLeftSideNose(point);
			pointBuilder.setX(17);
			pointBuilder.setY(18);
			builder.setLeftSideNose(pointBuilder.build());

			point = new FacePoint();
			point.setX(19);
			point.setY(20);
			parameter.setRightCornerMouth(point);
			pointBuilder.setX(19);
			pointBuilder.setY(20);
			builder.setRightCornerMouth(pointBuilder.build());

			point = new FacePoint();
			point.setX(21);
			point.setY(22);
			parameter.setLeftCornerMouth(point);
			pointBuilder.setX(21);
			pointBuilder.setY(22);
			builder.setLeftCornerMouth(pointBuilder.build());

			point = new FacePoint();
			point.setX(23);
			point.setY(24);
			parameter.setTopCenterUpperLip(point);
			pointBuilder.setX(23);
			pointBuilder.setY(24);
			builder.setTopCenterUpperLip(pointBuilder.build());

			point = new FacePoint();
			point.setX(25);
			point.setY(26);
			parameter.setBottomCenterUpperLip(point);
			pointBuilder.setX(25);
			pointBuilder.setY(26);
			builder.setBottomCenterUpperLip(pointBuilder.build());

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public FaceInputExtraction13Points parameter;
			public PBFace13Points expected;

			Fixture(FaceInputExtraction13Points parameter, PBFace13Points expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFaceExtractionParam_Helper {
		public static Fixture build() {
			FaceInputExtraction13Points parameter = null;
			PBFaceExtractionParam.Builder builder = PBFaceExtractionParam.newBuilder();
			{
				ToPBFace13Points_Helper.Fixture fixture = ToPBFace13Points_Helper.build();
				parameter = fixture.parameter;
				parameter.setNum(1);
				builder.setFaceNumber(1);
				builder.setFace13Points(fixture.expected);
			}
			{
				ToPBMetaInfo_Helper.Fixture fixture = ToPBMetaInfo_Helper.build();
				parameter.setMetaInfo(fixture.parameter);
				builder.setMetaInfo(fixture.expected);
			}
			{
				ToPBPrefilterOptions_Helper.Fixture fixture =
					ToPBPrefilterOptions_Helper.build("true");
				parameter.setPrefilterOptions(fixture.parameter);
				builder.setPrefilterOptions(fixture.expected);
			}

			List<FaceInputExtraction13Points> parameterList = new ArrayList<>();
			parameterList.add(parameter);
			List<PBFaceExtractionParam> expectedList = new ArrayList<>();
			expectedList.add(builder.build());
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<FaceInputExtraction13Points> parameter;
			public List<PBFaceExtractionParam> expected;

			Fixture(List<FaceInputExtraction13Points> parameter,
				List<PBFaceExtractionParam> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFaceDetectionParams_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			FaceInputParams parameter = new FaceInputParams();
			PBFaceDetectionParam.Builder builder = PBFaceDetectionParam.newBuilder();

			parameter.setNum(1);
			builder.setAttempt(1);

			parameter.setAlgorithm(DetectionAlgorithm.D4);
			builder.setAlgorithm(FaceDetectionAlgorithmType.FACE_DETECTION_ALGORITHM_D4);

			parameter.setReliability(2.0);
			builder.setReliability(2.0);

			parameter.setEyeMin(3.0);
			builder.setEyeMin(3.0);

			parameter.setEyeMax(4.0);
			builder.setEyeMax(4.0);

			parameter.setEyeRotation(5);
			builder.setEyeRotation(5);

			parameter.setFaceRotation(FaceRotation.DEGREE_0_90_180_270);
			builder.addRotation(FaceDetectionRotationType.FACE_DETECTION_ROTATION_0);
			builder.addRotation(FaceDetectionRotationType.FACE_DETECTION_ROTATION_90);
			builder.addRotation(FaceDetectionRotationType.FACE_DETECTION_ROTATION_180);
			builder.addRotation(FaceDetectionRotationType.FACE_DETECTION_ROTATION_270);

			parameter.setShrinkFactor(ShrinkFactor.A_HALF);
			builder
				.setShrinkFactor(FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_HALF);

			List<FaceInputParams> parameterList = new ArrayList<>();
			parameterList.add(parameter);
			List<PBFaceDetectionParam> expectedList = new ArrayList<>();
			expectedList.add(builder.build());
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<FaceInputParams> parameter;
			public List<PBFaceDetectionParam> expected;

			Fixture(List<FaceInputParams> parameter, List<PBFaceDetectionParam> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputFaceExtraction_Helper {
		public static Fixture build() {
			FaceInputExtraction parameter = new FaceInputExtraction();
			PBExtractInputFaceExtraction.Builder builder =
				PBExtractInputFaceExtraction.newBuilder();

			ToPBFaceExtractionParam_Helper.Fixture fixture =
				ToPBFaceExtractionParam_Helper.build();
			parameter.getPoints().addAll(fixture.parameter);
			builder.addAllExtractionParam(fixture.expected);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public FaceInputExtraction parameter;
			public PBExtractInputFaceExtraction expected;

			Fixture(FaceInputExtraction parameter, PBExtractInputFaceExtraction expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBFace2Points_Helper {
		public static Fixture build() {
			Face2Points parameter = new Face2Points();
			PBFace2Points.Builder builder = PBFace2Points.newBuilder();

			parameter.setNum(1);
			builder.setFaceNumber(1);
			{
				ToPBPoint_FacePoint_Helper.Fixture fixture =
					ToPBPoint_FacePoint_Helper.build(1, 2);
				parameter.setRightEyeCenter(fixture.parameter);
				builder.setRightEyeCenter(fixture.expected);
			}
			{
				ToPBPoint_FacePoint_Helper.Fixture fixture =
					ToPBPoint_FacePoint_Helper.build(3, 4);
				parameter.setLeftEyeCenter(fixture.parameter);
				builder.setLeftEyeCenter(fixture.expected);
			}

			List<Face2Points> parameterList = new ArrayList<>();
			parameterList.add(parameter);
			List<PBFace2Points> expectedList = new ArrayList<>();
			expectedList.add(builder.build());
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<Face2Points> parameter;
			public List<PBFace2Points> expected;

			Fixture(List<Face2Points> parameter, List<PBFace2Points> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputFaceDetection_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			FaceInputDetection parameter = new FaceInputDetection();
			PBExtractInputFaceDetection.Builder builder =
				PBExtractInputFaceDetection.newBuilder();

			parameter.setMode(DetectionMode.REPEAT);
			builder.setMode(FaceDetectionModeType.FACE_DETECTION_MODE_REPEAT);

			parameter.setFaceMaxNum(1);
			builder.setFaceMaxNum(1);

			parameter.setSortingOrder(SortingOrder.FACE_SIZE);
			builder
				.setSortingOrder(FaceDetectionSortingOrderType.FACE_DETECTION_SORTING_ORDER_SIZE);

			parameter.setImageAnalysis(true);
			builder.setImageAnalysis(true);

			{
				ToPBFaceDetectionParams_Helper.Fixture fixture =
					ToPBFaceDetectionParams_Helper.build();
				parameter.getParams().addAll(fixture.parameter);
				builder.addAllDetectionParam(fixture.expected);
			}
			{
				ToPBFace2Points_Helper.Fixture fixture = ToPBFace2Points_Helper.build();
				parameter.getPoints().addAll(fixture.parameter);
				builder.addAllFace2Points(fixture.expected);
			}

			FaceNegativeDetectionParams negative = new FaceNegativeDetectionParams();
			negative.setQualityThreshold(1.0);
			negative.setMatchingScoreThreshold(2);
			parameter.setNegativeDetectionParams(negative);
			builder.getNegativeDetectionParamBuilder().setQualityThreshold(1.0);
			builder.getNegativeDetectionParamBuilder().setMatchingScoreThreshold(2);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public FaceInputDetection parameter;
			public PBExtractInputFaceDetection expected;

			Fixture(FaceInputDetection parameter, PBExtractInputFaceDetection expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractFaceInput_Helper {
		public static Fixture build() {
			FaceInput parameter = new FaceInput();
			PBExtractFaceInput.Builder builder = PBExtractFaceInput.newBuilder();

			parameter.setProcessMode(FaceProcessMode.EXTRACTION);
			builder.setProcess(FaceExtractProcessType.FACE_EXTRACT_PROCESS_EXTRATION);

			{
				ToPBAimFormatWith_AimFormats_Helper.Fixture fixture =
					ToPBAimFormatWith_AimFormats_Helper.build();
				parameter.setAimformats(fixture.parameter);
				builder.addAllAimFormats(fixture.expected);
			}
			{
				ToPBMetaInfo_Helper.Fixture fixture = ToPBMetaInfo_Helper.build();
				parameter.setMetaInfo(fixture.parameter);
				builder.setMetaInfo(fixture.expected);
			}
			{
				ToPBPrefilterOptions_Helper.Fixture fixture =
					ToPBPrefilterOptions_Helper.build("true");
				parameter.setPrefilterOptions(fixture.parameter);
				builder.setPrefilterOptions(fixture.expected);
			}
			{
				ToPBExtractInputImageWith_FaceInputImage_Helper.Fixture fixture =
					ToPBExtractInputImageWith_FaceInputImage_Helper.build("data");
				parameter.setImage(fixture.parameter);
				builder.setImage(fixture.expected);
			}
			{
				ToPBExtractInputFaceDetection_Helper.Fixture fixture =
					ToPBExtractInputFaceDetection_Helper.build();
				parameter.setDetection(fixture.parameter);
				builder.setDetection(fixture.expected);
			}
			{
				ToPBExtractInputFaceExtraction_Helper.Fixture fixture =
					ToPBExtractInputFaceExtraction_Helper.build();
				parameter.setExtraction(fixture.parameter);
				builder.setExtraction(fixture.expected);
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public FaceInput parameter;
			public PBExtractFaceInput expected;

			Fixture(FaceInput parameter, PBExtractFaceInput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBAimFormatWith_AimFormats_Helper {
		public static Fixture build() {
			AimFormats parameter = new AimFormats();
			PBAimFormat.Builder builder = PBAimFormat.newBuilder();

			parameter.getFmt().add(ExtractionFormats.FI);
			parameter.getFmt().add(ExtractionFormats.FR_FDB);
			parameter.getFmt().add(ExtractionFormats.II);
			parameter.getFmt().add(ExtractionFormats.IR_IDB);
			parameter.getFmt().add(ExtractionFormats.TLI_M);

			List<PBAimFormat> expectedList = new ArrayList<>();
			builder.setFormat(TemplateFormatType.TEMPLATE_FI);
			expectedList.add(builder.build());
			builder.setFormat(TemplateFormatType.TEMPLATE_FDB);
			expectedList.add(builder.build());
			builder.setFormat(TemplateFormatType.TEMPLATE_II);
			expectedList.add(builder.build());
			builder.setFormat(TemplateFormatType.TEMPLATE_IDB);
			expectedList.add(builder.build());
			builder.setFormat(TemplateFormatType.TEMPLATE_TLIM);
			expectedList.add(builder.build());

			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public AimFormats parameter;
			public List<PBAimFormat> expected;

			Fixture(AimFormats parameter, List<PBAimFormat> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputImageWith_FaceInputImage_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(String mode) {
			FaceInputImage parameter = new FaceInputImage();
			PBExtractInputImage.Builder builder = PBExtractInputImage.newBuilder();

			if (mode.equals("url")) {
				parameter.setUrl("test");
				builder.setUrl("test");
			} else if (mode.equals("data")) {
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				parameter.setData(binary);
				builder.setData(ByteString.copyFrom(binary));
			}

			parameter.setWidth(1);
			builder.setWidth(1);

			parameter.setHeight(2);
			builder.setHeight(2);

			parameter.setType(ImageFormat.JPEG);
			builder.setType(ImageFormatType.JPEG);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public FaceInputImage parameter;
			public PBExtractInputImage expected;

			Fixture(FaceInputImage parameter, PBExtractInputImage expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToString_Helper {
		public static Fixture build(String type) {
			ExtInput input = new ExtInput();
			if (type.equals("tenprint")) {
				ToPBExtractTenprintInput_Helper.Fixture fixture =
					ToPBExtractTenprintInput_Helper.build();
				input.setTenprintInput(fixture.parameter);
			} else if (type.equals("latent")) {
				ToPBExtractLatentInput_Helper.Fixture fixture =
					ToPBExtractLatentInput_Helper.build();
				input.setLatentInput(fixture.parameter);
			} else if (type.equals("face")) {
				ToPBExtractFaceInput_Helper.Fixture fixture =
					ToPBExtractFaceInput_Helper.build();
				input.setFaceInput(fixture.parameter);
			} else if (type.equals("iris")) {
				ToPBExtractIrisInput_Helper.Fixture fixture =
					ToPBExtractIrisInput_Helper.build();
				input.setIrisInput(fixture.parameter);
			}

			ExtractionInputsPayload payload = new ExtractionInputsPayload();
			payload.setExtInput(input);
			return new Fixture(payload);
		}

		public static class Fixture {
			public ExtractionInputsPayload parameter;

			Fixture(ExtractionInputsPayload parameter) {
				this.parameter = parameter;
			}
		}
	}

	public static class ToPBExtractJobRequest_Helper {
		public static Fixture build() {
			ExtractionInputs parameter = new ExtractionInputs();
			PBExtractJobRequest.Builder builder = PBExtractJobRequest.newBuilder();

			parameter.setPriority(1);
			builder.setPriority(1);

			parameter.setCallbackURL("test");
			builder.setCallBackUrl("test");

			PBExtractInputPayload.Builder payloadBuilder =
				PBExtractInputPayload.newBuilder();
			{
				ToPBExtractFaceInput_Helper.Fixture fixture =
					ToPBExtractFaceInput_Helper.build();
				payloadBuilder.setFaceInput(fixture.expected);
				builder.setInputPayload(payloadBuilder);
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public ExtractionInputs parameter;
			public PBExtractJobRequest expected;

			Fixture(ExtractionInputs parameter, PBExtractJobRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBPreselectionOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(boolean apply) {
			Parameter parameter = new Parameter();
			PBPreselectionOptions.Builder builder = PBPreselectionOptions.newBuilder();

			parameter.preselectionOptions = new PreselectionOptions();
			parameter.preselectionOptions.setCardQualityThreshold((short)1);
			builder.setCardQualityThreshold(1);

			parameter.preselectionOptions.setUsePSR8FingerSlap(true);
			builder.setUsePsr8FingerSlap(true);

			parameter.preselectionOptions.setFilterMode("2");
			builder.setFilterMode(FilterModeType.GENDER_ONLY);

			parameter.preselectionOptions.setApplyPatternThreshold(apply);
			parameter.preselectionOptions.setPatternThreshold(3.0f);
			if (apply) {
				builder.setPatternThreshold(3.0f);
			}

			parameter.preselectionOptions.setApplyYob(apply);
			parameter.preselectionOptions.setApplyGender(apply);

			parameter.preselectionOptions.setApplyYobThreshold(apply);
			parameter.preselectionOptions.setYobThreshold((short)4);
			if (apply) {
				builder.setYobThreshold(4);
			}

			parameter.preselectionOptions.setApplyFingerSelectionMode(apply);
			parameter.preselectionOptions.setFingerSelectionMode("14");
			if (apply) {
				builder.setFingerSelectionMode(FingerSelectionModeType.COLD_SEARCH);
			}

			parameter.preselectionOptions.setCandidateVerificationThreshold(5);
			builder.setCandidateVerificationThreshold(5);

			parameter.pbMetaInfo = PBMetaInfo.newBuilder().build();

			Expected expected = new Expected();
			expected.options = builder.build();
			expected.pbMetaInfo = PBMetaInfo.newBuilder().build();
			if (apply) {
				expected.pbMetaInfo.getCommon().toBuilder().setYob(-1);
				expected.pbMetaInfo.getCommon().toBuilder().setGender(
					GenderType.GENDER_UNKNOWN);
			}

			return new Fixture(parameter, expected);
		}

		public static class Parameter {
			public PreselectionOptions preselectionOptions;
			public MetaInfo metaInfo;
			public PBMetaInfo pbMetaInfo;
		}

		public static class Expected {
			public PBPreselectionOptions options;
			public PBMetaInfo pbMetaInfo;
		}

		public static class Fixture {
			public Parameter parameter;
			public Expected expected;

			Fixture(Parameter parameter, Expected expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBUsePrefilterInfo_Helper {
		public static Fixture[] fixtures = {
			build("true"), build("false"), build("null"),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(String mode) {
			UsePrefilterInfo parameter = new UsePrefilterInfo();
			PBUsePrefilterInfo.Builder builder = PBUsePrefilterInfo.newBuilder();

			if (mode.equals("true")) {
				parameter.setUseFingerNo(true);
				builder.setFingerNo(true);

				parameter.setUseGender(true);
				builder.setGender(true);

				parameter.setUsePartNo(true);
				builder.setPartNo(true);

				parameter.setUseRace(true);
				builder.setRace(true);

				parameter.setUseRegion(true);
				builder.setRegion(true);
			} else if (mode.equals("false")) {
				parameter.setUseFingerNo(false);
				builder.setFingerNo(false);

				parameter.setUseGender(false);
				builder.setGender(false);

				parameter.setUsePartNo(false);
				builder.setPartNo(false);

				parameter.setUseRace(false);
				builder.setRace(false);

				parameter.setUseRegion(false);
				builder.setRegion(false);
			} else if (mode.equals("false")) {
				builder.setFingerNo(false);
				builder.setGender(false);
				builder.setPartNo(false);
				builder.setRace(false);
				builder.setRegion(false);
			}

			return new Fixture(parameter, builder.build(), mode);
		}

		public static class Fixture {
			public UsePrefilterInfo parameter;
			public PBUsePrefilterInfo expected;
			public String mode;

			Fixture(UsePrefilterInfo parameter, PBUsePrefilterInfo expected, String mode) {
				this.parameter = parameter;
				this.expected = expected;
				this.mode = mode;
			}
		}
	}

	public static class ToPBPc2Options_Helper {
		public static Fixture[] fixtures = {
			build("true"), build("false"), build("null"),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(String apply) {
			Pc2Options parameter = new Pc2Options();
			PBPc2Options.Builder builder = PBPc2Options.newBuilder();

			if (apply.equals("true")) {
				parameter.setApplySpeedLevel(true);
				parameter.setSpeedLevel("1");
				builder.setSpeedLevel(Pc2SpeedLevelType.PC2_SPEED_LEVEL_1);

				parameter.setApplyRotationLimit(true);
				parameter.setRotationLimit("2");
				builder.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_30);

				parameter.setApplyDistortionLevel(true);
				parameter.setDistortionLevel("6");
				builder.setDistortionLevel(Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_6);

				parameter.setRotationByAxis(true);
				builder.setRotationByAxis(true);
			} else if (apply.equals("false")) {
				parameter.setApplySpeedLevel(false);
				parameter.setSpeedLevel("1");

				parameter.setApplyRotationLimit(false);
				parameter.setRotationLimit("2");

				parameter.setApplyDistortionLevel(false);
				parameter.setDistortionLevel("3");

				parameter.setRotationByAxis(false);
				builder.setRotationByAxis(false);
			} else if (apply.equals("null")) {
				// no data
			}

			return new Fixture(parameter, builder.build(), apply);
		}

		public static class Fixture {
			public Pc2Options parameter;
			public PBPc2Options expected;
			public String apply;

			Fixture(Pc2Options parameter, PBPc2Options expected, String apply) {
				this.parameter = parameter;
				this.expected = expected;
				this.apply = apply;
			}
		}
	}

	public static class ToPBLeOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(boolean apply) {
			LeOptions parameter = new LeOptions();
			PBLeOptions.Builder builder = PBLeOptions.newBuilder();

			parameter.setApplyLeOptions(apply);

			parameter.setAlgorithm("1");
			builder.setAlgorithm(LeAlgorithmType.LE_ALGORITHM_STANDARD);

			parameter.setRotationLimit("2");
			builder.setRotationLimit(LeRotationLimitType.LE_ROTATION_DEGREE_30);

			parameter.setCorePosition("3");
			builder.setCorePosition(LeCorePositionType.LE_CORE_POSITION_LOOSE);
			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public LeOptions parameter;
			public PBLeOptions expected;

			Fixture(LeOptions parameter, PBLeOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBPalmOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(boolean apply) {
			PalmOptions parameter = new PalmOptions();
			PBPalmOptions.Builder builder = PBPalmOptions.newBuilder();

			parameter.setApplyPalmOptions(apply);

			parameter.setRotationLimit("1");
			builder.setRotationLimit(PalmRotationLimitType.PALM_ROTATION_DEGREE_30);

			parameter.setSpeedLevelPrimary("2");
			builder.setSpeedLevelPrimary(Pc2SpeedLevelType.PC2_SPEED_LEVEL_2);

			parameter.setSpeedLevelSecondary("3");
			builder.setSpeedLevelSecondary(Pc2SpeedLevelType.PC2_SPEED_LEVEL_3);

			parameter.setDistortionLevelPrimary("4");
			builder
				.setDistortionLevelPrimary(Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_4);

			parameter.setDistortionLevelSecondary("5");
			builder
				.setDistortionLevelSecondary(Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_5);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public PalmOptions parameter;
			public PBPalmOptions expected;

			Fixture(PalmOptions parameter, PBPalmOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBLfmlOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(boolean apply) {
			LfmlOptions parameter = new LfmlOptions();
			PBLfmlOptions.Builder builder = PBLfmlOptions.newBuilder();

			parameter.setSearchLevel(LfmlSearchLevel.SEARCH_LEVEL_1);
			parameter.setApplySearchLevel(apply);
			if (apply) {
				builder.setSearchLevel(LfmlSearchLevelType.LFML_SEARCH_LEVEL_1);
			}

			parameter.setRotationLimit(LfmlRotationLimit.ROTATION_DEGREE_60);
			parameter.setApplyRotationLimit(apply);
			if (apply) {
				builder.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_60);
			}

			parameter.setSpeedLevelPrimary(LfmlSpeedLevel.SPEED_LEVEL_5);
			parameter.setApplySpeedLevelPrimary(apply);
			if (apply) {
				builder.setSpeedLevelPrimary(Pc2SpeedLevelType.PC2_SPEED_LEVEL_5);
			}

			parameter.setSpeedLevelSecondary(LfmlSpeedLevel.SPEED_LEVEL_8);
			parameter.setApplySpeedLevelSecondary(apply);
			if (apply) {
				builder.setSpeedLevelSecondary(Pc2SpeedLevelType.PC2_SPEED_LEVEL_8);
			}

			parameter.setDistortionLevelPrimary(LfmlDistortionLevel.DISTORTION_LEVEL_1);
			parameter.setApplyDistortionLevelPrimary(apply);
			if (apply) {
				builder
					.setDistortionLevelPrimary(Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_1);
			}

			parameter.setDistortionLevelSecondary(LfmlDistortionLevel.DISTORTION_LEVEL_5);
			parameter.setApplyDistortionLevelSecondary(apply);
			if (apply) {
				builder
					.setDistortionLevelSecondary(Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_5);
			}

			ToPBLeOptions_Helper.Fixture fixture =
				ToPBLeOptions_Helper.build(apply);
			parameter.setLeOptions(fixture.parameter);
			builder.setLeOptions(fixture.expected);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public LfmlOptions parameter;
			public PBLfmlOptions expected;

			Fixture(LfmlOptions parameter, PBLfmlOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBMatchableFingersThresholds_Helper {
		public static Fixture[] fixtures = {
			build(true), build(false),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(boolean apply) {
			MatchableFingersThresholds parameter = new MatchableFingersThresholds();
			PBCMLaFMatchableFingerThreshold.Builder builder =
				PBCMLaFMatchableFingerThreshold.newBuilder();
			List<PBCMLaFMatchableFingerThreshold> expectedList = new ArrayList<>();

			parameter.setApplyMatchableFingersThresholds(apply);

			FingersThresholds fingersThresholds = new FingersThresholds();
			ProtoClassConvert.CMLaFParameter cmlafParameter =
				new ProtoClassConvert.CMLaFParameter();
			if (apply) {
				fingersThresholds.setFingerNumber((short)1);
				fingersThresholds.setPatternThreshold(2.0f);
				fingersThresholds.setCardScoreThreshold((short)3);
				fingersThresholds.setMateProbabilityThreshold(4.0f);
				fingersThresholds.setSpeedLevel("5");
				fingersThresholds.setFinalScoreThreshold((short)6);
				parameter.getFingersThresholds().add(fingersThresholds);

				fingersThresholds.setFingerNumber((short)2);
				fingersThresholds.setPatternThreshold(3.0f);
				fingersThresholds.setCardScoreThreshold((short)4);
				fingersThresholds.setMateProbabilityThreshold(5.0f);
				fingersThresholds.setSpeedLevel("6");
				fingersThresholds.setFinalScoreThreshold((short)7);
				parameter.getFingersThresholds().add(fingersThresholds);

				builder.setFingerNumber(1);
				builder.setPatternThreshold(2.0f);
				builder.setCardScoreThreshold(3);
				builder.setMateProbabilityThreshold(4.0f);
				builder.setSpeedLevel(Pc2SpeedLevelType.PC2_SPEED_LEVEL_5);
				builder.setFinalScoreThreshold(6);
				expectedList.add(builder.build());

				builder.setFingerNumber(2);
				builder.setPatternThreshold(3.0f);
				builder.setCardScoreThreshold(4);
				builder.setMateProbabilityThreshold(5.0f);
				builder.setSpeedLevel(Pc2SpeedLevelType.PC2_SPEED_LEVEL_6);
				builder.setFinalScoreThreshold(7);
				expectedList.add(builder.build());
			} else {
				fingersThresholds.setFingerNumber((short)1);
				fingersThresholds.setPatternThreshold(2.0f);
				fingersThresholds.setCardScoreThreshold((short)3);
				fingersThresholds.setMateProbabilityThreshold(4.0f);
				fingersThresholds.setSpeedLevel("5");
				fingersThresholds.setFinalScoreThreshold((short)7);
				parameter.getFingersThresholds().add(fingersThresholds);

				fingersThresholds.setFingerNumber((short)2);
				fingersThresholds.setPatternThreshold(3.0f);
				fingersThresholds.setCardScoreThreshold((short)4);
				fingersThresholds.setMateProbabilityThreshold(5.0f);
				fingersThresholds.setSpeedLevel("6");
				fingersThresholds.setFinalScoreThreshold((short)7);
				parameter.getFingersThresholds().add(fingersThresholds);

				cmlafParameter.setPatternThreshold(10.0f);
				cmlafParameter.setCardScoreThreshold(11);
				cmlafParameter.setMateProbabilityThreshold(12.0f);
				cmlafParameter.setFinalScoreThreshold(13);
				cmlafParameter.setSpeedLevel(Pc2SpeedLevelType.PC2_SPEED_LEVEL_9);

				for (int fingerNumber = 1; fingerNumber < 11; fingerNumber++) {
					builder.setFingerNumber(fingerNumber);
					builder.setPatternThreshold(10.0f);
					builder.setCardScoreThreshold(11);
					builder.setMateProbabilityThreshold(12.0f);
					builder.setFinalScoreThreshold(13);
					builder.setSpeedLevel(Pc2SpeedLevelType.PC2_SPEED_LEVEL_9);
					expectedList.add(builder.build());
				}
			}
			return new Fixture(parameter, cmlafParameter, expectedList);
		}

		public static class Fixture {
			public MatchableFingersThresholds parameter;
			public ProtoClassConvert.CMLaFParameter cmlafParameter;
			public List<PBCMLaFMatchableFingerThreshold> expected;

			Fixture(MatchableFingersThresholds parameter,
				ProtoClassConvert.CMLaFParameter cmlafParameter,
				List<PBCMLaFMatchableFingerThreshold> expected) {
				this.parameter = parameter;
				this.cmlafParameter = cmlafParameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBCmlafOptions_Helper {
		public static Fixture[] fixtures = {
			build(true), build(false),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(boolean apply) {
			CmlafTiOptions parameter = new CmlafTiOptions();
			MatchableFingersThresholds matchableParameter =
				new MatchableFingersThresholds();
			matchableParameter.setApplyMatchableFingersThresholds(apply);
			FingersThresholds fingersThresholds = new FingersThresholds();
			fingersThresholds.setFingerNumber((short)1);

			PBCMLaFOptions.Builder builder = PBCMLaFOptions.newBuilder();
			PBCMLaFMatchableFingerThreshold.Builder fingerThresholdBuilder =
				PBCMLaFMatchableFingerThreshold.newBuilder();
			fingerThresholdBuilder.setFingerNumber(1);

			parameter.setApplyPatternThreshold(true);
			parameter.setPatternThreshold(10.0f);
			if (apply) {
				fingersThresholds.setPatternThreshold(1.0f);
				fingerThresholdBuilder.setPatternThreshold(1.0f);
			} else {
				fingerThresholdBuilder.setPatternThreshold(10.0f);
			}

			parameter.setApplyYobThreshold(apply);
			parameter.setYobThreshold((short)2);
			if (apply) {
				builder.setYobThreshold(2);
			}

			parameter.setFilterMode("3");
			builder.setFilterMode(FilterModeType.PATTERN_GENDER);

			parameter.setApplyCardScoreThreshold(true);
			parameter.setCardScoreThreshold((short)11);
			if (apply) {
				fingersThresholds.setCardScoreThreshold((short)2);
				fingerThresholdBuilder.setCardScoreThreshold(2);
			} else {
				fingerThresholdBuilder.setCardScoreThreshold(11);
			}

			parameter.setApplyMateProbabilityThreshold(true);
			parameter.setMateProbabilityThreshold(12.0f);
			if (apply) {
				fingersThresholds.setMateProbabilityThreshold(3.0f);
				fingerThresholdBuilder.setMateProbabilityThreshold(3.0f);
			} else {
				fingerThresholdBuilder.setMateProbabilityThreshold(12.0f);
			}

			parameter.setApplyFinalScoreThreshold(true);
			parameter.setFinalScoreThreshold((short)13);
			if (apply) {
				fingersThresholds.setFinalScoreThreshold((short)4);
				fingerThresholdBuilder.setFinalScoreThreshold(4);
			} else {
				fingerThresholdBuilder.setFinalScoreThreshold(13);
			}

			parameter.setSearchMode("3");
			builder.setSearchMode(CMLaFSearchModeType.ACCURATE_MODE);

			parameter.setApplySpeedLevel(true);
			parameter.setSpeedLevel("9");
			if (apply) {
				fingersThresholds.setSpeedLevel("5");
				fingerThresholdBuilder.setSpeedLevel(Pc2SpeedLevelType.PC2_SPEED_LEVEL_5);
			} else {
				fingerThresholdBuilder.setSpeedLevel(Pc2SpeedLevelType.PC2_SPEED_LEVEL_9);
			}

			parameter.setApplyRotationLimit(apply);
			parameter.setRotationLimit("1");
			if (apply) {
				builder.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
			}

			parameter.setApplyDistortionLevel(apply);
			parameter.setDistortionLevel("6");
			if (apply) {
				builder.setDistortionLevel(Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_6);
			}

			matchableParameter.getFingersThresholds().add(fingersThresholds);
			parameter.setMatchableFingersThresholds(matchableParameter);

			if (apply) {
				builder.addMatchableFingerThresholds(fingerThresholdBuilder);
			} else {
				for (int fingerNumber = 1; fingerNumber < 11; fingerNumber++) {
					fingerThresholdBuilder.setFingerNumber(fingerNumber);
					builder.addMatchableFingerThresholds(fingerThresholdBuilder.build());
				}
			}
			return new Fixture(parameter, builder.build(), apply);
		}

		public static class Fixture {
			public CmlafTiOptions parameter;
			public PBCMLaFOptions expected;
			public boolean apply;

			Fixture(CmlafTiOptions parameter, PBCMLaFOptions expected, boolean apply) {
				this.parameter = parameter;
				this.expected = expected;
				this.apply = apply;
			}
		}
	}

	public static class ToPBCmlOptions_Helper {
		public static Fixture[] fixtures = {
			build(true), build(false),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(boolean apply) {
			CmlOptions parameter = new CmlOptions();

			PBCMLOptions.Builder builder = PBCMLOptions.newBuilder();

			parameter.setApplyYobThreshold(apply);
			parameter.setYobThreshold((short)2);
			if (apply) {
				builder.setYobThreshold(2);
			}

			parameter.setFilterMode("3");
			builder.setFilterMode(FilterModeType.PATTERN_GENDER);

			parameter.setApplyParameterId(apply);
			parameter.setParameterId(1);
			if (apply) {
				builder.setParameterId(1);
			}

			parameter.setApplyRotationLimit(apply);
			parameter.setRotationLimit("2");
			if (apply) {
				builder.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_30);
			}

			return new Fixture(parameter, builder.build(), apply);
		}

		public static class Fixture {
			public CmlOptions parameter;
			public PBCMLOptions expected;
			public boolean apply;

			Fixture(CmlOptions parameter, PBCMLOptions expected, boolean apply) {
				this.parameter = parameter;
				this.expected = expected;
				this.apply = apply;
			}
		}
	}

	public static class UpdateGenderAndYob_Helper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			build(false, false, null, 1), build(true, false, null, 2),
			build(false, true, null, 3), build(true, true, null, 4),
			build(false, false, new MetaInfo(), 5),
			build(true, false, new MetaInfo(), 6), build(false, true, new MetaInfo(), 7),
			build(true, true, new MetaInfo(), 8), build(false, false, new MetaInfo() {
				{
					metaCommon = new MetaCommon();
				}
			}, 9), build(true, false, new MetaInfo() {
				{
					metaCommon = new MetaCommon();
				}
			}, 10), build(false, true, new MetaInfo() {
				{
					metaCommon = new MetaCommon();
				}
			}, 11), build(true, true, new MetaInfo() {
				{
					metaCommon = new MetaCommon();
				}
			}, 12), build(false, false, new MetaInfo() {
				{
					metaCommon = new MetaCommon() {
						{
							yob = 1;
						}
					};
				}
			}, 13), build(false, false, new MetaInfo() {
				{
					metaCommon = new MetaCommon() {
						{
							gender = GenderEnum.F;
						}
					};
				}
			}, 14),
		};

		public static Fixture build(
			boolean applyYob,
			boolean applyGender,
			MetaInfo metaInfo,
			int testNumber) {
			Parameter parameter = new Parameter();
			PBMetaInfoCommon.Builder builder = PBMetaInfoCommon.newBuilder();

			parameter.applyYob = applyYob;
			parameter.applyGender = applyGender;
			parameter.metaInfo = metaInfo;

			Expected expected = new Expected();
			expected.hasYobFlag = false;
			expected.hasGenderFlag = false;

			if (testNumber == 13) {
				builder.clearYob();
			} else if (testNumber == 14) {
				builder.clearGender();
			} else {
				if (testNumber == 2) {
					expected.hasYobFlag = true;
				} else if (testNumber == 3) {
					expected.hasGenderFlag = true;
				} else if (testNumber == 4) {
					expected.hasYobFlag = true;
					expected.hasGenderFlag = true;
				}
				if (testNumber == 6) {
					expected.hasYobFlag = true;
				} else if (testNumber == 7) {
					expected.hasGenderFlag = true;
				} else if (testNumber == 8) {
					expected.hasYobFlag = true;
					expected.hasGenderFlag = true;
				} else if (testNumber == 10) {
					builder.setYob(-1);
					expected.hasYobFlag = true;
				} else if (testNumber == 11) {
					builder.setGender(GenderType.GENDER_UNKNOWN);
					expected.hasGenderFlag = true;
				} else if (testNumber == 12) {
					builder.setYob(-1);
					expected.hasYobFlag = true;
					builder.setGender(GenderType.GENDER_UNKNOWN);
					expected.hasGenderFlag = true;
				}

				if (metaInfo == null || metaInfo.getMetaCommon() == null) {
					if (applyYob) {
						builder.setYob(-1);
					}
					if (applyGender) {
						builder.setGender(GenderType.GENDER_UNKNOWN);
					}
				}
			}

			expected.pbMetaInfoCommon = builder.build();
			return new Fixture(parameter, expected);
		}

		public static class Parameter {
			public boolean applyYob;
			public boolean applyGender;
			public MetaInfo metaInfo;
		}

		public static class Expected {
			public PBMetaInfoCommon pbMetaInfoCommon;
			public boolean hasGenderFlag;
			public boolean hasYobFlag;
		}

		public static class Fixture {
			public Parameter parameter;
			public Expected expected;

			Fixture(Parameter parameter, Expected expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBInquiryPayload_Helper {
		public static Fixture build(String updateYobAndGender, boolean apply) {
			SearchInputsPayload parameter = new SearchInputsPayload();
			PBInquiryPayload.Builder builder = PBInquiryPayload.newBuilder();

			{
				if (updateYobAndGender.length() == 0) {
					ToPBMetaInfo_Helper.Fixture fixture = ToPBMetaInfo_Helper.build();
					parameter.setMetaInfo(fixture.parameter);
					builder.setMetaInfo(fixture.expected);
				}
			}
			{
				ToPBPreselectionOptions_Helper.Fixture fixture =
					ToPBPreselectionOptions_Helper.build(updateYobAndGender
						.equals("preselection"));
				parameter.setPreselectionOptions(fixture.parameter.preselectionOptions);
				builder.setPreselectionOptions(fixture.expected.options);
			}
			{
				ToPBPrefilterOptions_Helper.Fixture fixture =
					ToPBPrefilterOptions_Helper.build("true");
				parameter.setPrefilterOptions(fixture.parameter);
				builder.setPrefilterOptions(fixture.expected);
			}
			{
				ToPBPc2Options_Helper.Fixture fixture =
					ToPBPc2Options_Helper.build("true");
				parameter.setPc2Options(fixture.parameter);
				builder.setPc2Options(fixture.expected);
			}
			{
				ToPBLeOptions_Helper.Fixture fixture = ToPBLeOptions_Helper.build(apply);
				parameter.setLeOptions(fixture.parameter);
				builder.setLeOptions(fixture.expected);
			}
			{
				ToPBPalmOptions_Helper.Fixture fixture =
					ToPBPalmOptions_Helper.build(apply);
				parameter.setPalmOptions(fixture.parameter);
				builder.setPalmOptions(fixture.expected);
			}
			{
				ToPBCmlafOptions_Helper.Fixture fixture =
					ToPBCmlafOptions_Helper.build(apply);
				parameter.setCmlafTiOptions(fixture.parameter);
				builder.setCmlafOptions(fixture.expected);
			}
			{
				ToPBCmlOptions_Helper.Fixture fixture =
					ToPBCmlOptions_Helper.build(apply);
				parameter.setCmlOptions(fixture.parameter);
				builder.setCmlOptions(fixture.expected);
			}
			{
				ToPBLfmlOptions_Helper.Fixture fixture =
					ToPBLfmlOptions_Helper.build(apply);
				parameter.setLfmlOptions(fixture.parameter);
				builder.setLfmlOptions(fixture.expected);
			}
			{
				ToPBIrisOptions_Helper.Fixture fixture =
					ToPBIrisOptions_Helper.build();
				parameter.setIrisOptions(fixture.parameter);
				builder.setIrisOptions(fixture.expected);
			}

			return new Fixture(parameter, builder);
		}

		public static class Fixture {
			public SearchInputsPayload parameter;
			public PBInquiryPayload.Builder expected;

			Fixture(SearchInputsPayload parameter, PBInquiryPayload.Builder expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBChechkExternalIdRequest_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			Parameter parameter = new Parameter();
			PBCheckExternalIdRequest.Builder builder =
				PBCheckExternalIdRequest.newBuilder();

			parameter.externalId = "test";
			builder.setExternalId("test");

			parameter.eventIds = new ArrayList<>();
			parameter.eventIds.add(1);
			builder.addEventIds(1);

			parameter.containerIds = new ArrayList<>();
			parameter.containerIds.add(2);
			builder.addContainerIds(2);

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public String externalId;
			public List<Integer> eventIds;
			public List<Integer> containerIds;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBCheckExternalIdRequest expected;

			Fixture(Parameter parameter, PBCheckExternalIdRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncJobRequestWith_String_Integer_ListOfInteger_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			Parameter parameter = new Parameter();
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();

			builder.setFunction(SyncFunctionType.DELETE);

			parameter.externalId = "test";
			builder.setExternalId("test");

			parameter.eventId = 1;
			builder.setEventId(1);

			parameter.containerIds = new ArrayList<>();
			parameter.containerIds.add(2);
			builder.getDeletePayload().toBuilder().addScopes(2);

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public String externalId;
			public Integer eventId;
			public List<Integer> containerIds;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncJobRequest expected;

			Fixture(Parameter parameter, PBSyncJobRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	@SuppressWarnings("boxing")
	public static class ToPBSyncDeletePayload_ListOfInteger_Helper {
		public static Fixture[] fixtures = {
			build(new Integer[] {
				1, 2
			}, new Expected() {
				{
					number = 1;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBT);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_ROLLED);
					fingerPrint.add(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}), build(new Integer[] {
				2, 1002
			}, new Expected() {
				{
					number = 2;
					scope = new ArrayList<>();
					scope.add(1);
					scope.add(2);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBT);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}), build(new Integer[] {
				331, 1331, 2331,
			}, new Expected() {
				{
					number = 3;
					scope = new ArrayList<>();
					scope.add(1);
					scope.add(2);
					scope.add(3);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBTM);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_ROLLED);
				}
			}), build(new Integer[] {
				332, 1332
			}, new Expected() {
				{
					number = 4;
					scope = new ArrayList<>();
					scope.add(1);
					scope.add(2);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBTM);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}), build(new Integer[] {
				3, 1003, 4, 1004
			}, new Expected() {
				{
					number = 5;
					scope = new ArrayList<>();
					scope.add(1);
					scope.add(2);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBL);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_ROLLED);
					fingerPrint.add(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}), build(new Integer[] {
				4
			}, new Expected() {
				{
					number = 6;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBL);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}), build(new Integer[] {
				323
			}, new Expected() {
				{
					number = 7;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBLS);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_ROLLED);
				}
			}), build(new Integer[] {
				324
			}, new Expected() {
				{
					number = 8;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBLS);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}), build(new Integer[] {
				333, 334
			}, new Expected() {
				{
					number = 9;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBLM);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_ROLLED);
					fingerPrint.add(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}), build(new Integer[] {
				334
			}, new Expected() {
				{
					number = 10;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBLM);
					fingerPrint = new ArrayList<>();
					fingerPrint.add(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}), build(new Integer[] {
				341
			}, new Expected() {
				{
					number = 11;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_RDBLX);
				}
			}), build(new Integer[] {
				5
			}, new Expected() {
				{
					number = 12;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_PDB);
				}
			}), build(new Integer[] {
				335
			}, new Expected() {
				{
					number = 13;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_FDB);
				}
			}), build(new Integer[] {
				321, 326
			}, new Expected() {
				{
					number = 14;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_LDB);
					templateFormat.add(TemplateFormatType.TEMPLATE_LDBS);
				}
			}), build(new Integer[] {
				322
			}, new Expected() {
				{
					number = 15;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_PLDB);
				}
			}), build(new Integer[] {
				326
			}, new Expected() {
				{
					number = 16;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_LDBS);
				}
			}), build(new Integer[] {
				336
			}, new Expected() {
				{
					number = 17;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_LDBM);
				}
			}), build(new Integer[] {
				342
			}, new Expected() {
				{
					number = 18;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_LDBX);
				}
			}), build(new Integer[] {
				343
			}, new Expected() {
				{
					number = 19;
					scope = new ArrayList<>();
					scope.add(1);
					templateFormat = new ArrayList<>();
					templateFormat.add(TemplateFormatType.TEMPLATE_IDB);
				}
			}),
		};

		public static Fixture build(Integer[] containerId, Expected expected) {
			PBSyncDeletePayload.Builder builder = PBSyncDeletePayload.newBuilder();

			builder.addAllScopes(expected.scope);

			PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
			if (expected.number == 1) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 2) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 3) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 4) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 5) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 6) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 7) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 8) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 9) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 10) {
				for (int index = 0; index < expected.fingerPrint.size(); index++) {
					templateBuilder.setKey(expected.templateFormat.get(0));
					PBKeyedTemplateIndexer.Builder indexerBuilder =
						PBKeyedTemplateIndexer.newBuilder();
					indexerBuilder.setFingerPrintType(expected.fingerPrint.get(index));
					templateBuilder.setIndexer(indexerBuilder);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 11) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
			} else if (expected.number == 12) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
			} else if (expected.number == 13) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
			} else if (expected.number == 14) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
				templateBuilder.setKey(expected.templateFormat.get(1));
				builder.addKeyedTemplate(templateBuilder);
			} else if (expected.number == 15) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
			} else if (expected.number == 16) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
			} else if (expected.number == 17) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
			} else if (expected.number == 18) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
			} else if (expected.number == 19) {
				templateBuilder.setKey(expected.templateFormat.get(0));
				builder.addKeyedTemplate(templateBuilder);
			}

			/*
			 * if (expected.fingerPrint == null) {
			 * templateBuilder.setKey(expected.templateFormat.get(0));
			 * builder.addKeyedTemplate(templateBuilder);
			 * 
			 * PBKeyedTemplateIndexer.Builder indexerBuilder =
			 * PBKeyedTemplateIndexer.newBuilder(); for (int index = 0; index <
			 * expected.fingerPrint.size(); index++) { indexerBuilder.clear();
			 * indexerBuilder
			 * .setFingerPrintType(expected.fingerPrint.get(index));
			 * templateBuilder.setIndexer(indexerBuilder); } }
			 * 
			 * for (int i = 0; i < expected.templateFormat.size(); i++) {
			 * templateBuilder.clear();
			 * templateBuilder.setKey(expected.templateFormat.get(i));
			 * builder.addKeyedTemplate(templateBuilder); } if
			 * (expected.fingerPrint != null) { PBKeyedTemplateIndexer.Builder
			 * indexerBuilder = PBKeyedTemplateIndexer.newBuilder(); for (int
			 * index = 0; index < expected.fingerPrint.size(); index++) {
			 * indexerBuilder.clear(); indexerBuilder
			 * .setFingerPrintType(expected.fingerPrint.get(index));
			 * templateBuilder.setIndexer(indexerBuilder); } }
			 * builder.addKeyedTemplate(templateBuilder); }
			 */
			List<Integer> containerIdList = new ArrayList<>();
			containerIdList.addAll(Arrays.asList(containerId));
			return new Fixture(containerIdList, builder.build());
		}

		public static class Expected {
			public int number;
			public List<Integer> scope;
			public List<TemplateFormatType> templateFormat;
			public List<FingerPrintType> fingerPrint;
		}

		public static class Fixture {
			public List<Integer> parameter;
			public PBSyncDeletePayload expected;

			Fixture(List<Integer> parameter, PBSyncDeletePayload expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBKeyedTemplate_Helper {
		public static Fixture build() {
			Parameter parameter = new Parameter();
			PBKeyedTemplate.Builder builder = PBKeyedTemplate.newBuilder();

			parameter.template = RandomStringUtils.randomAscii(32).getBytes();

			builder.setTemplateBinary(ByteString.copyFrom(parameter.template));

			parameter.templateFormatType = TemplateFormatType.TEMPLATE_FDB;
			builder.setKey(TemplateFormatType.TEMPLATE_FDB);

			parameter.indexer = PBKeyedTemplateIndexer.newBuilder().build();
			builder.setIndexer(PBKeyedTemplateIndexer.newBuilder().build());

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public byte[] template;
			public TemplateFormatType templateFormatType;
			public PBKeyedTemplateIndexer indexer;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBKeyedTemplate expected;

			Fixture(Parameter parameter, PBKeyedTemplate expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBKeyedTemplateIndexer_Helper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					key = "RDBT";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBT;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_ROLLED;
				}
			}), build(new Parameter() {
				{
					key = "SDBT";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBT;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}), build(new Parameter() {
				{
					key = "RDBTM";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBTM;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_ROLLED;
				}
			}), build(new Parameter() {
				{
					key = "SDBTM";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBTM;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}), build(new Parameter() {
				{
					key = "RDBL_1";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBL;
				}
			}, new Expected() {
				{
					position = ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB;
				}
			}), build(new Parameter() {
				{
					key = "SDBL_10";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBL;
				}
			}, new Expected() {
				{
					position = ImagePositionType.IMAGE_SLAP_LEFT_LITTLE;
				}
			}), build(new Parameter() {
				{
					key = "RDBLS_1";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBLS;
				}
			}, new Expected() {
				{
					position = ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB;
				}
			}), build(new Parameter() {
				{
					key = "SDBLS_10";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBLS;
				}
			}, new Expected() {
				{
					position = ImagePositionType.IMAGE_SLAP_LEFT_LITTLE;
				}
			}), build(new Parameter() {
				{
					key = "RDBLM_1";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBLM;
				}
			}, new Expected() {
				{
					position = ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB;
				}
			}), build(new Parameter() {
				{
					key = "SDBLM_10";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBLM;
				}
			}, new Expected() {
				{
					position = ImagePositionType.IMAGE_SLAP_LEFT_LITTLE;
				}
			}), build(new Parameter() {
				{
					key = "XDBL";
					templateFormatType = TemplateFormatType.TEMPLATE_RDBLX;
				}
			}, new Expected() {
				{
				}
			}), build(new Parameter() {
				{
					key = "PDB_3";
					templateFormatType = TemplateFormatType.TEMPLATE_PDB;
				}
			}, new Expected() {
				{
					position = ImagePositionType.IMAGE_PALM_LEFT_FULL;
				}
			}), build(new Parameter() {
				{
					key = "FDB_10";
					templateFormatType = TemplateFormatType.TEMPLATE_FDB;
				}
			}, new Expected() {
				{
					index = 10;
				}
			}), build(new Parameter() {
				{
					key = "LDB";
					templateFormatType = TemplateFormatType.TEMPLATE_LDB;
				}
			}, new Expected() {
			}), build(new Parameter() {
				{
					key = "PLDB";
					templateFormatType = TemplateFormatType.TEMPLATE_PLDB;
				}
			}, new Expected() {
			}), build(new Parameter() {
				{
					key = "LDBS";
					templateFormatType = TemplateFormatType.TEMPLATE_LDBS;
				}
			}, new Expected() {
			}), build(new Parameter() {
				{
					key = "LDBM";
					templateFormatType = TemplateFormatType.TEMPLATE_LDBM;
				}
			}, new Expected() {
			}), build(new Parameter() {
				{
					key = "LDBX";
					templateFormatType = TemplateFormatType.TEMPLATE_LDBX;
				}
			}, new Expected() {
			}), build(new Parameter() {
				{
					key = "FI_2";
					templateFormatType = TemplateFormatType.TEMPLATE_FI;
				}
			}, new Expected() {
				{
					index = 2;
				}
			}), build(new Parameter() {
				{
					key = "TI_SLAP";
					templateFormatType = TemplateFormatType.TEMPLATE_TI;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}), build(new Parameter() {
				{
					key = "TIM_ROLLED";
					templateFormatType = TemplateFormatType.TEMPLATE_TIM;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_ROLLED;
				}
			}), build(new Parameter() {
				{
					key = "TLI_ROLLED";
					templateFormatType = TemplateFormatType.TEMPLATE_TLI;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_ROLLED;
				}
			}), build(new Parameter() {
				{
					key = "TLIS_SLAP";
					templateFormatType = TemplateFormatType.TEMPLATE_TLIS;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}), build(new Parameter() {
				{
					key = "TLIM_SLAP";
					templateFormatType = TemplateFormatType.TEMPLATE_TLIM;
				}
			}, new Expected() {
				{
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(Parameter parameter, Expected expected) {
			PBKeyedTemplateIndexer.Builder builder = PBKeyedTemplateIndexer.newBuilder();

			if (expected.position != null) {
				builder.setPosition(expected.position);
			}
			if (expected.fingerPrintType != null) {
				builder.setFingerPrintType(expected.fingerPrintType);
			}
			if (expected.index != null) {
				builder.setIndex(expected.index);
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public String key;
			public TemplateFormatType templateFormatType;
		}

		public static class Expected {
			public ImagePositionType position;
			public FingerPrintType fingerPrintType;
			public Integer index;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBKeyedTemplateIndexer expected;

			Fixture(Parameter parameter, PBKeyedTemplateIndexer expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBKeyedTemplateReference_Helper {
		public static Fixture build(boolean indexer) {
			ExtractResultReference parameter = new ExtractResultReference();
			PBKeyedTemplateReference.Builder builder =
				PBKeyedTemplateReference.newBuilder();

			parameter.setJobId(1);
			builder.setJobId(1);
			String containerIdToKey = null;

			if (indexer) {
				containerIdToKey = "FDB";
				parameter.setKey("FDB_1");
				builder.setKey(TemplateFormatType.TEMPLATE_FDB);

				builder.setIndexer(PBKeyedTemplateIndexer.newBuilder());
			} else {
				containerIdToKey = "IDB";
				parameter.setKey("IDB");
				builder.setKey(TemplateFormatType.TEMPLATE_IDB);
			}

			return new Fixture(parameter, builder.build(), containerIdToKey);
		}

		public static class Fixture {
			public ExtractResultReference parameter;
			public PBKeyedTemplateReference expected;
			public String containerIdToKey;

			Fixture(ExtractResultReference parameter, PBKeyedTemplateReference expected,
				String containerIdToKey) {
				this.parameter = parameter;
				this.expected = expected;
				this.containerIdToKey = containerIdToKey;
			}
		}
	}

	public static class ToPBKeyedTemplateDataWith_RegistrationRequest_Map_Helper {
		static final Integer RDBT_CONTAINER_ID = Integer.valueOf(1);
		static final Integer SDBT_CONTAINER_ID = Integer.valueOf(2);
		static final Integer RDBTM_CONTAINER_ID = new Integer(331);
		static final Integer SDBTM_CONTAINER_ID = new Integer(332);
		static final Integer RDBL_CONTAINER_ID = Integer.valueOf(3);
		static final Integer SDBL_CONTAINER_ID = Integer.valueOf(4);
		static final Integer RDBLS_CONTAINER_ID = new Integer(323);
		static final Integer SDBLS_CONTAINER_ID = new Integer(324);
		static final Integer RDBLM_CONTAINER_ID = new Integer(333);
		static final Integer SDBLM_CONTAINER_ID = new Integer(334);
		static final Integer XDBL_CONTAINER_ID = new Integer(341);
		static final Integer PDB_CONTAINER_ID = Integer.valueOf(5);
		static final Integer FDB_CONTAINER_ID = new Integer(335);
		static final Integer LDB_CONTAINER_ID = new Integer(321);
		static final Integer PLDB_CONTAINER_ID = new Integer(322);
		static final Integer LDBS_CONTAINER_ID = new Integer(326);
		static final Integer LDBM_CONTAINER_ID = new Integer(336);
		static final Integer LDBX_CONTAINER_ID = new Integer(342);
		static final Integer IDB_CONTAINER_ID = new Integer(343);

		static final Map<Integer, Integer> index = new HashMap<>();

		public static void clearIndex() {
			index.clear();
			index.put(RDBL_CONTAINER_ID, Integer.valueOf(1));
			index.put(RDBLS_CONTAINER_ID, Integer.valueOf(1));
			index.put(RDBLM_CONTAINER_ID, Integer.valueOf(1));
			index.put(SDBL_CONTAINER_ID, Integer.valueOf(1));
			index.put(SDBLS_CONTAINER_ID, Integer.valueOf(1));
			index.put(SDBLM_CONTAINER_ID, Integer.valueOf(1));
			index.put(PDB_CONTAINER_ID, Integer.valueOf(1));
			index.put(FDB_CONTAINER_ID, Integer.valueOf(1));
			index.put(IDB_CONTAINER_ID, Integer.valueOf(1));
		}

		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 331;
							record = new Record() {
								{
									reference = new ExtractResultReference() {
										{
											jobId = 1;
											key = "RDBTM";
										}
									};
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 1;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 332;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 3;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 341;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 324;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 333;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 7;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 5;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 8;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 335;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 9;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new RegistrationRequest() {
						{
							destinationContainer = 343;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 10;
				}
			}),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(Parameter parameter, Expected expected) {
			parameter.index = index;

			PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();

			if (expected.number == 1) {
				builder.getKeyedRefereneceBuilder().setJobId(1);
				builder.getKeyedRefereneceBuilder().setKey(
					TemplateFormatType.TEMPLATE_FDB);
				builder.getKeyedRefereneceBuilder().setIndexer(
					PBKeyedTemplateIndexer.newBuilder().build());
			} else if (expected.number == 2) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBT);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);

				parameter.index = new HashMap<>(RDBT_CONTAINER_ID, 1);
			} else if (expected.number == 3) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBTM);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 4) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBL);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
			} else if (expected.number == 5) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLX);
			} else if (expected.number == 6) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLS);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
			} else if (expected.number == 7) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLM);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
			} else if (expected.number == 8) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_PDB);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_PALM_RIGHT_FULL);
			} else if (expected.number == 9) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_FDB);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setIndex(1);
			} else if (expected.number == 10) {
				byte[] binary = parameter.registrationRequest.getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_IDB);
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public RegistrationRequest registrationRequest;
			public Map<Integer, Integer> index;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBKeyedTemplateData expected;

			Fixture(Parameter parameter, PBKeyedTemplateData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper {
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 1;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 2;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 332;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 3;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 3;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 3;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 4;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 4;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 4;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 5;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 324;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 324;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 6;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 333;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 333;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 7;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 5;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 5;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 8;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 335;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 335;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 9;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 323;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 323;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 10;
					scope = 1;
				}
			}), build(new Parameter() {
				{
					registrationRequest = new ArrayList<>();
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 334;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
					registrationRequest.add(new RegistrationRequest() {
						{
							destinationContainer = 334;
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					});
				}
			}, new Expected() {
				{
					number = 11;
					scope = 1;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			PBSyncInsertPayload.Builder payloadBuilder = PBSyncInsertPayload.newBuilder();
			PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();

			if (expected.number == 2) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBT);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);

				payloadBuilder.addKeyedTemplateData(builder);
				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 3) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBTM);

				builder.getKeyedTemplateBuilder().getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_SLAP);

				payloadBuilder.addKeyedTemplateData(builder);
				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 4) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBL);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
				payloadBuilder.addKeyedTemplateData(builder.build());

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBL);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX);
				payloadBuilder.addKeyedTemplateData(builder.build());

				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 5) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBL);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
				payloadBuilder.addKeyedTemplateData(builder.build());

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBL);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_SLAP_RIGHT_INDEX);
				payloadBuilder.addKeyedTemplateData(builder.build());

				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 6) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLS);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
				payloadBuilder.addKeyedTemplateData(builder.build());

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLS);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_SLAP_RIGHT_INDEX);
				payloadBuilder.addKeyedTemplateData(builder.build());

				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 7) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLM);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
				payloadBuilder.addKeyedTemplateData(builder.build());

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLM);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX);
				payloadBuilder.addKeyedTemplateData(builder.build());

				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 8) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_PDB);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_PALM_RIGHT_FULL);
				payloadBuilder.addKeyedTemplateData(builder.build());

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_PDB);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_PALM_RIGHT_WRITER);
				payloadBuilder.addKeyedTemplateData(builder.build());

				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 9) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_FDB);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setIndex(1);
				payloadBuilder.addKeyedTemplateData(builder.build());

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_FDB);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setIndex(2);
				payloadBuilder.addKeyedTemplateData(builder.build());

				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 10) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLS);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
				payloadBuilder.addKeyedTemplateData(builder.build());

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLS);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX);
				payloadBuilder.addKeyedTemplateData(builder.build());

				payloadBuilder.setScope(expected.scope);
			} else if (expected.number == 11) {
				byte[] binary =
					parameter.registrationRequest.get(0).getRecord().getBinary();

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLM);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
				payloadBuilder.addKeyedTemplateData(builder.build());

				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(binary));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLM);
				builder.getKeyedTemplateBuilder().getIndexerBuilder().setPosition(
					ImagePositionType.IMAGE_SLAP_RIGHT_INDEX);
				payloadBuilder.addKeyedTemplateData(builder.build());

				payloadBuilder.setScope(expected.scope);
			}

			return new Fixture(parameter, payloadBuilder.build());
		}

		public static class Parameter {
			public List<RegistrationRequest> registrationRequest;
		}

		public static class Expected {
			public int number;
			public int scope;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncInsertPayload expected;

			Fixture(Parameter parameter, PBSyncInsertPayload expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ValidateFunctionToKey_Helper {
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.TR;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "RDBT";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBT";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBTM";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBTM";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_1";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_2";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_3";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_4";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_5";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_6";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_7";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_8";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_9";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBL_10";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_1";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_2";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_3";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_4";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_5";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_6";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_7";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_8";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_9";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBL_10";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_1";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_2";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_3";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_4";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_5";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_6";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_7";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_8";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_9";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLS_10";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_1";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_2";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_3";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_4";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_5";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_6";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_7";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_8";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_9";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLS_10";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_1";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_2";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_3";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_4";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_5";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_6";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_7";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_8";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_9";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "RDBLM_10";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_1";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_2";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_3";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_4";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_5";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_6";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_7";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_8";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_9";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBLM_10";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "XDBL";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_1";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_2";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_3";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_4";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_5";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_6";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_7";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_8";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_9";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_10";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_11";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_12";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_13";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_14";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_15";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "PDB_16";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LR;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LR";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LRS;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LRS";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LRM;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LRM";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LRP;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LRP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LRX;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LRX";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.FR;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "FDB_1";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_2";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_3";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_4";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_5";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_6";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_7";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_8";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_9";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "FDB_10";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.IR;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "IDB";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}),

		};

		public static Fixture build(Parameter parameter, Expected expected) {
			return new Fixture(parameter);
		}

		public static class Parameter {
			public AfisRegistrationFunctionEnum function;
			public AfisTemplateSet afisTemplateSet;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public String message;

			Fixture(Parameter parameter) {
				this.parameter = parameter;
			}
		}
	}

	public static class ToPBIrisOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			IrisOptions parameter = new IrisOptions();
			PBIrisOptions.Builder builder = PBIrisOptions.newBuilder();

			parameter.setSearchMode(IrisSearchMode.IRIS_SEARCH_MODE_STANDARD);
			builder.setSearchMode(IrisSearchModeType.IRIS_SEARCH_MODE_STANDARD);

			parameter.setRotationLimit(2);
			builder.setRotationLimit(2);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public IrisOptions parameter;
			public PBIrisOptions expected;

			Fixture(IrisOptions parameter, PBIrisOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}


	public static class ToPBExtractInputIrisExtraction_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			IrisInputExtraction parameter = new IrisInputExtraction();
			PBExtractInputIrisExtraction.Builder builder =
				PBExtractInputIrisExtraction.newBuilder();

			parameter.setMode(IrisExtractionMode.IRIS_EXTRACT_MODE_PERFORMANCE);
			builder.setMode(IrisExtractionModeType.IRIS_EXTRACTION_MODE_PERFORMANCE);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public IrisInputExtraction parameter;
			public PBExtractInputIrisExtraction expected;

			Fixture(IrisInputExtraction parameter, PBExtractInputIrisExtraction expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBBasicImageEnhanceOptions_Helper {
		public static Fixture build() {
			PBBasicImageEnhanceOptions.Builder builder =
				PBBasicImageEnhanceOptions.newBuilder();

			EnhType parameter = EnhType.ENH_HISTOGRAM;
			builder.addEnhancements(BasicImageEnhanceType.IMAGE_ENHANCE_HISTOGRAM);

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public EnhType parameter;
			public PBBasicImageEnhanceOptions expected;

			Fixture(EnhType parameter, PBBasicImageEnhanceOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractInputImage_Helper {
		public static Fixture build(String type) {
			IrisInputImage parameter = new IrisInputImage();
			PBExtractInputImage.Builder builder = PBExtractInputImage.newBuilder();

			if (type.equals("binary")) {
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				parameter.setData(binary);
				builder.setData(ByteString.copyFrom(binary));
			} else if (type.equals("url")) {
				parameter.setUrl("test");
				builder.setUrl("test");
			}

			parameter.setPos("60");
			builder.setPosition(ImagePositionType.IMAGE_IRIS_RIGHT);

			parameter.setType(ImageFormat.RAW);
			builder.setType(ImageFormatType.RAW);

			parameter.setWidth(320);
			builder.setWidth(320);

			parameter.setHeight(256);
			builder.setHeight(256);

			List<IrisInputImage> parameterList = new ArrayList<>();
			parameterList.add(parameter);
			List<PBExtractInputImage> expectedList = new ArrayList<>();
			expectedList.add(builder.build());
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<IrisInputImage> parameter;
			public List<PBExtractInputImage> expected;

			Fixture(List<IrisInputImage> parameter, List<PBExtractInputImage> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractIrisInput_Helper {
		public static Fixture build() {
			IrisInput parameter = new IrisInput();
			PBExtractIrisInput.Builder builder = PBExtractIrisInput.newBuilder();

			{
				ToPBAimFormatWith_AimFormats_Helper.Fixture fixture =
					ToPBAimFormatWith_AimFormats_Helper.build();
				parameter.setAimformats(fixture.parameter);
				builder.addAllAimFormats(fixture.expected);
			}
			{
				ToPBExtractInputImage_Helper.Fixture fixture =
					ToPBExtractInputImage_Helper.build("url");
				parameter.setImages(new IrisInputImages());
				parameter.getImages().getImage().addAll(fixture.parameter);
				builder.addAllImage(fixture.expected);
			}
			{
				ToPBMetaInfo_Helper.Fixture fixture = ToPBMetaInfo_Helper.build();
				parameter.setMetaInfo(fixture.parameter);
				builder.setMetaInfo(fixture.expected);
			}
			{
				ToPBPrefilterOptions_Helper.Fixture fixture =
					ToPBPrefilterOptions_Helper.build("true");
				parameter.setPrefilterOptions(fixture.parameter);
				builder.setPrefilterOptions(fixture.expected);
			}
			{
				parameter.setEnhType(EnhType.ENH_ENHANCE);
				builder.getBasicEnhanceOptions().toBuilder().addEnhancements(
					BasicImageEnhanceType.IMAGE_ENHANCE_ENHANCE);
			}

			{
				ToPBExtractInputIrisExtraction_Helper.Fixture fixture =
					ToPBExtractInputIrisExtraction_Helper.build();
				parameter.setExtraction(fixture.parameter);
				builder.setExtraction(fixture.expected);
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Fixture {
			public IrisInput parameter;
			public PBExtractIrisInput expected;

			Fixture(IrisInput parameter, PBExtractIrisInput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBExtractJobBinaryRequest_Helper {
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					jobId = 1;
					key = "FDB_1";
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "FI_1";
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "II";
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "IDB";
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "TI_ROLLED";
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "SDBTM";
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "LI_S";
				}
			}, new Expected() {
				{
					number = 7;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "RDBLM_10";
				}
			}, new Expected() {
				{
					number = 8;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "LLIP";
				}
			}, new Expected() {
				{
					number = 9;
				}
			}), build(new Parameter() {
				{
					jobId = 1;
					key = "PDB_5";
				}
			}, new Expected() {
				{
					number = 10;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected eXpected) {
			PBExtractJobBinaryRequest.Builder builder =
				PBExtractJobBinaryRequest.newBuilder();

			builder.setJobId(parameter.jobId);
			if (eXpected.number == 1) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_FDB));
			} else if (eXpected.number == 2) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_FI));
			} else if (eXpected.number == 3) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_II));
			} else if (eXpected.number == 4) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_IDB));
			} else if (eXpected.number == 5) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_TI));
			} else if (eXpected.number == 6) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBTM));
			} else if (eXpected.number == 7) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_LIS));
			} else if (eXpected.number == 8) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLM));
			} else if (eXpected.number == 9) {
				builder.setJobId(parameter.jobId);
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_LLIP));
			} else if (eXpected.number == 10) {
				builder.addKeyedTemplate(PBKeyedTemplate.newBuilder().setKey(
					TemplateFormatType.TEMPLATE_PDB));
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public long jobId;
			public String key;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBExtractJobBinaryRequest expected;

			Fixture(Parameter parameter, PBExtractJobBinaryRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ValidateNumAfisGroupId_Helper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					templateMetadata = new TemplateMetadata() {
						{
							afisGroupId = new ArrayList<>();
							afisGroupId.add(1);
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}),

		};

		public static Fixture build(Parameter parameter, Expected expected) {
			return new Fixture(parameter);
		}

		public static class Parameter {
			public TemplateMetadata templateMetadata;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public String message;

			Fixture(Parameter parameter) {
				this.parameter = parameter;
			}
		}
	}

	public static class ToPBKeyedTemplateDataWith_KeyedTemplate_Helper {
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "RDBT";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "SDBTM";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "RDBL_3";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "SDBLS_10";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "PDB_15";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "FDB_1";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "LRX";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 7;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();

			if (expected.number == 1) {
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(parameter.keyedTemplate.getBinary()));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBT);
				builder.getKeyedTemplateBuilder().setIndexer(
					PBKeyedTemplateIndexer.newBuilder().build());
			} else if (expected.number == 2) {
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(parameter.keyedTemplate.getBinary()));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBTM);
				builder.getKeyedTemplateBuilder().setIndexer(
					PBKeyedTemplateIndexer.newBuilder().build());
			} else if (expected.number == 3) {
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(parameter.keyedTemplate.getBinary()));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_RDBL);
				builder.getKeyedTemplateBuilder().setIndexer(
					PBKeyedTemplateIndexer.newBuilder().build());
			} else if (expected.number == 4) {
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(parameter.keyedTemplate.getBinary()));
				builder.getKeyedTemplateBuilder().setKey(
					TemplateFormatType.TEMPLATE_RDBLS);
				builder.getKeyedTemplateBuilder().setIndexer(
					PBKeyedTemplateIndexer.newBuilder().build());
			} else if (expected.number == 5) {
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(parameter.keyedTemplate.getBinary()));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_PDB);
				builder.getKeyedTemplateBuilder().setIndexer(
					PBKeyedTemplateIndexer.newBuilder().build());
			} else if (expected.number == 6) {
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(parameter.keyedTemplate.getBinary()));
				builder.getKeyedTemplateBuilder().setKey(TemplateFormatType.TEMPLATE_FDB);
				builder.getKeyedTemplateBuilder().setIndexer(
					PBKeyedTemplateIndexer.newBuilder().build());
			} else if (expected.number == 7) {
				builder.getKeyedTemplateBuilder().setTemplateBinary(
					ByteString.copyFrom(parameter.keyedTemplate.getBinary()));
				builder.getKeyedTemplateBuilder()
					.setKey(TemplateFormatType.TEMPLATE_LDBX);
			}
			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public KeyedTemplate keyedTemplate;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBKeyedTemplateData expected;

			Fixture(Parameter parameter, PBKeyedTemplateData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.TR;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "RDBT";
									metadata = new TemplateMetadata() {
										{
											afisGroupId = new ArrayList<>();
											afisGroupId.add(1);
										}

									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "SDBTM";
									metadata = new TemplateMetadata() {
										{
											afisGroupId = new ArrayList<>();
											afisGroupId.add(1);
										}

									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LR;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LR";
									metadata = new TemplateMetadata() {
									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LRS;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LRS";
									metadata = new TemplateMetadata() {
									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LRM;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LRM";
									metadata = new TemplateMetadata() {
									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LRP;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LRP";
									metadata = new TemplateMetadata() {
									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.LRX;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LRX";
									metadata = new TemplateMetadata() {
									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.FR;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "FDB_5";
									metadata = new TemplateMetadata() {
									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 7;
				}
			}), build(new Parameter() {
				{
					function = AfisRegistrationFunctionEnum.IR;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "IDB";
									metadata = new TemplateMetadata() {
									};
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 8;
				}
			}),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(Parameter parameter, Expected expected) {
			PBSyncInsertPayload.Builder builder = PBSyncInsertPayload.newBuilder();

			if (expected.number == 1) {
				{
					PBKeyedTemplateData.Builder templateBuilder =
						PBKeyedTemplateData.newBuilder().setKeyedTemplate(
							PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBT).build());
					builder.addKeyedTemplateData(templateBuilder);
				}
				{
					PBKeyedTemplateData.Builder templateBuilder =
						PBKeyedTemplateData.newBuilder().setKeyedTemplate(
							PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBTM).build());
					builder.addKeyedTemplateData(templateBuilder);
				}

				builder.setScope(parameter.afisTemplateSet.getTemplate().get(0)
					.getMetadata().getAfisGroupId().get(0));
				builder.setScope(parameter.afisTemplateSet.getTemplate().get(1)
					.getMetadata().getAfisGroupId().get(0));
			} else if (expected.number == 2) {
				PBKeyedTemplateData.Builder templateBuilder =
					PBKeyedTemplateData.newBuilder().setKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
							TemplateFormatType.TEMPLATE_LDB).build());
				builder.addKeyedTemplateData(templateBuilder);
			} else if (expected.number == 3) {
				PBKeyedTemplateData.Builder templateBuilder =
					PBKeyedTemplateData.newBuilder().setKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
							TemplateFormatType.TEMPLATE_LDBS).build());
				builder.addKeyedTemplateData(templateBuilder);
			} else if (expected.number == 4) {
				PBKeyedTemplateData.Builder templateBuilder =
					PBKeyedTemplateData.newBuilder().setKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
							TemplateFormatType.TEMPLATE_LDBM).build());
				builder.addKeyedTemplateData(templateBuilder);
			} else if (expected.number == 5) {
				PBKeyedTemplateData.Builder templateBuilder =
					PBKeyedTemplateData.newBuilder().setKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
							TemplateFormatType.TEMPLATE_PLDB).build());
				builder.addKeyedTemplateData(templateBuilder);
			} else if (expected.number == 6) {
				PBKeyedTemplateData.Builder templateBuilder =
					PBKeyedTemplateData.newBuilder().setKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
							TemplateFormatType.TEMPLATE_LDBX).build());
				builder.addKeyedTemplateData(templateBuilder);
			} else if (expected.number == 7) {
				PBKeyedTemplateData.Builder templateBuilder =
					PBKeyedTemplateData.newBuilder().setKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
							TemplateFormatType.TEMPLATE_FDB).build());
				builder.addKeyedTemplateData(templateBuilder);
			} else if (expected.number == 8) {
				PBKeyedTemplateData.Builder templateBuilder =
					PBKeyedTemplateData.newBuilder().setKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
							TemplateFormatType.TEMPLATE_IDB).build());
				builder.addKeyedTemplateData(templateBuilder);
			}
			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public AfisRegistrationFunctionEnum function;
			public AfisTemplateSet afisTemplateSet;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncInsertPayload expected;

			Fixture(Parameter parameter, PBSyncInsertPayload expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncJobRequestWith_AfisRegistrationFunctionEnum_String_int_AfisTemplateSet_Helper {
		public static Fixture build() {
			Parameter parameter = new Parameter();
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.Fixture[] fixture =
				ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.fixtures;

			parameter.function = AfisRegistrationFunctionEnum.TR;
			builder.setFunction(SyncFunctionType.INSERT);

			parameter.externalId = "test";
			builder.setExternalId("test");

			parameter.eventId = 1;
			builder.setEventId(1);

			parameter.afisTemplateSet = fixture[0].parameter.afisTemplateSet;
			builder.setInsertPayload(fixture[0].expected);

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public AfisRegistrationFunctionEnum function;
			public String externalId;
			public int eventId;
			public AfisTemplateSet afisTemplateSet;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncJobRequest expected;

			Fixture(Parameter parameter, PBSyncJobRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncJobRequestWith_String_int_ListOfRegistrationRequest_Helper {
		public static Fixture build() {
			Parameter parameter = new Parameter();
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper.Fixture[] fixture =
				ToPBSyncInsertPayloadWith_ListOfRegistrationRequest_Helper.fixtures;

			builder.setFunction(SyncFunctionType.INSERT);

			parameter.externalId = "test";
			builder.setExternalId("test");

			parameter.eventId = 1;
			builder.setEventId(1);

			parameter.registrationRequestList = fixture[0].parameter.registrationRequest;
			builder.setInsertPayload(fixture[0].expected);

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public String externalId;
			public int eventId;
			public List<RegistrationRequest> registrationRequestList;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncJobRequest expected;

			Fixture(Parameter parameter, PBSyncJobRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					function = AfisDeletionFunctionEnum.TD;
					afisGroupId = 1;
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					function = AfisDeletionFunctionEnum.LD;
					afisGroupId = 2;
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					function = AfisDeletionFunctionEnum.LDS;
					afisGroupId = null;
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisDeletionFunctionEnum.LDM;
					afisGroupId = 1;
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					function = AfisDeletionFunctionEnum.LDP;
					afisGroupId = 1;
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					function = AfisDeletionFunctionEnum.LDX;
					afisGroupId = 1;
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), build(new Parameter() {
				{
					function = AfisDeletionFunctionEnum.FD;
					afisGroupId = 1;
				}
			}, new Expected() {
				{
					number = 7;
				}
			}), build(new Parameter() {
				{
					function = AfisDeletionFunctionEnum.ID;
					afisGroupId = 1;
				}
			}, new Expected() {
				{
					number = 8;
				}
			}),
		};

		@SuppressWarnings("boxing")
		public static Fixture build(Parameter parameter, Expected expected) {
			PBSyncDeletePayload.Builder builder = PBSyncDeletePayload.newBuilder();

			if (parameter.afisGroupId != null) {
				builder.addScopes(parameter.afisGroupId);
			}
			if (expected.number == 1) {
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBT);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBT);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBTM);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBTM);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBL);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBL);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBLS);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBLS);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBLM);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBLM);
					templateBuilder.getIndexerBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_RDBLX);
					builder.addKeyedTemplate(templateBuilder.build());
				}
				{
					PBKeyedTemplate.Builder templateBuilder =
						PBKeyedTemplate.newBuilder();
					templateBuilder.setKey(TemplateFormatType.TEMPLATE_PDB);
					builder.addKeyedTemplate(templateBuilder.build());
				}
			} else if (expected.number == 2) {
				PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_LDB);
				builder.addKeyedTemplate(templateBuilder.build());
			} else if (expected.number == 3) {
				PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_LDBS);
				builder.addKeyedTemplate(templateBuilder.build());
			} else if (expected.number == 4) {
				PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_LDBM);
				builder.addKeyedTemplate(templateBuilder.build());
			} else if (expected.number == 5) {
				PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_PLDB);
				builder.addKeyedTemplate(templateBuilder.build());
			} else if (expected.number == 6) {
				PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_LDBX);
				builder.addKeyedTemplate(templateBuilder.build());
			} else if (expected.number == 7) {
				PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_FDB);
				builder.addKeyedTemplate(templateBuilder.build());
			} else if (expected.number == 8) {
				PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_IDB);
				builder.addKeyedTemplate(templateBuilder.build());
			}
			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public AfisDeletionFunctionEnum function;
			public Integer afisGroupId;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncDeletePayload expected;

			Fixture(Parameter parameter, PBSyncDeletePayload expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncJobRequestWith_AfisDeletionFunctionEnum_String_Integer_Integer_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			Parameter parameter = new Parameter();
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.Fixture[] fixtures =
				ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.fixtures;

			parameter.function = AfisDeletionFunctionEnum.TD;
			builder.setFunction(SyncFunctionType.DELETE);

			parameter.externalId = "test";
			builder.setExternalId("test");

			parameter.eventId = 1;
			builder.setEventId(1);

			parameter.afisGroupId = 1;
			builder.setDeletePayload(fixtures[0].expected);

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public AfisDeletionFunctionEnum function;
			public String externalId;
			public Integer eventId;
			public Integer afisGroupId;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncJobRequest expected;

			Fixture(Parameter parameter, PBSyncJobRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncInsertPayloadWith_AfisUpdateFunctionEnum_AfisTemplateSet_Helper {
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.TU;
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LU;
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LUS;
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LUM;
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LUP;
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LUX;
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.FU;
				}
			}, new Expected() {
				{
					number = 7;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.IU;
				}
			}, new Expected() {
				{
					number = 8;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.Fixture[] fixture =
				ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.fixtures;

			parameter.afisTemplateSet =
				fixture[expected.number - 1].parameter.afisTemplateSet;
			PBSyncInsertPayload payload = fixture[expected.number - 1].expected;

			return new Fixture(parameter, payload);
		}

		public static class Parameter {
			public AfisUpdateFunctionEnum function;
			public AfisTemplateSet afisTemplateSet;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncInsertPayload expected;

			Fixture(Parameter parameter, PBSyncInsertPayload expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncDeletePayloadWith_AfisUpdateFunctionEnum_Integer_Helper {
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.TU;
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LU;
					afisGroupId = null;
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LUS;
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LUM;
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LUP;
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.LUX;
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.FU;
				}
			}, new Expected() {
				{
					number = 7;
				}
			}), build(new Parameter() {
				{
					function = AfisUpdateFunctionEnum.IU;
				}
			}, new Expected() {
				{
					number = 8;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.Fixture[] fixtures =
				ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.fixtures;

			PBSyncDeletePayload payload = fixtures[expected.number - 1].expected;

			return new Fixture(parameter, payload);
		}

		public static class Parameter {
			public AfisUpdateFunctionEnum function;
			public Integer afisGroupId;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncDeletePayload expected;

			Fixture(Parameter parameter, PBSyncDeletePayload expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBSyncJobRequestWith_AfisUpdateFunctionEnum_String_Integer_int_Integer_AfisTemplateSet_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			Parameter parameter = new Parameter();
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();

			parameter.function = AfisUpdateFunctionEnum.TU;
			builder.setFunction(SyncFunctionType.UPDATE);

			parameter.externalId = "test";
			builder.setExternalId("test");

			parameter.eventId = 1;
			builder.setEventId(1);

			parameter.afisGroupId = 1;

			{
				ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.Fixture[] fixtures =
					ToPBSyncInsertPayloadWith_AfisRegistrationFunctionEnum_AfisTemplateSet_Helper.fixtures;
				parameter.afisTemplateSet = fixtures[0].parameter.afisTemplateSet;
				builder.setInsertPayload(fixtures[0].expected);
			}
			{
				ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.Fixture[] fixtures =
					ToPBSyncDeletePayload_AfisDeletionFunctionEnum_Integer_Helper.fixtures;
				builder.setDeletePayload(fixtures[0].expected);
			}

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public AfisUpdateFunctionEnum function;
			public String externalId;
			public int eventId;
			public Integer afisGroupId;
			public AfisTemplateSet afisTemplateSet;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBSyncJobRequest expected;

			Fixture(Parameter parameter, PBSyncJobRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBKeyedTemplateDataWith_SearchRequest_Helper {
		public static Map<TemplateFormatType, Integer> fingerPrintTypeMap =
			new HashMap<>();

		public static void clearIndex() {
			fingerPrintTypeMap.clear();
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TI, Integer.valueOf(1));
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TIM, Integer.valueOf(1));
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TLI, Integer.valueOf(1));
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TLIS, Integer.valueOf(1));
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TLIM, Integer.valueOf(1));
		}

		public static ReferenceFixture[] referenceFixtures = {
			buildReference(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TI";
							record = new Record() {
								{
									reference = new ExtractResultReference() {
										{
											jobId = 1;
											key = "TI_ROLLED";
										}
									};
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), buildReference(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TI-M";
							record = new Record() {
								{
									reference = new ExtractResultReference() {
										{
											jobId = 1;
											key = "TIM_SLAP";
										}
									};
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), buildReference(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TLI";
							record = new Record() {
								{
									reference = new ExtractResultReference() {
										{
											jobId = 1;
											key = "TLI_SLAP";
										}
									};
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), buildReference(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TIL-S";
							record = new Record() {
								{
									reference = new ExtractResultReference() {
										{
											jobId = 1;
											key = "TLIS_ROLLED";
										}
									};
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), buildReference(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TLI-M";
							record = new Record() {
								{
									reference = new ExtractResultReference() {
										{
											jobId = 1;
											key = "TLIM_SLAP";
										}
									};
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), buildReference(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "FI";
							record = new Record() {
								{
									reference = new ExtractResultReference() {
										{
											jobId = 1;
											key = "FI_3";
										}
									};
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), buildReference(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "II";
							record = new Record() {
								{
									reference = new ExtractResultReference() {
										{
											jobId = 1;
											key = "II";
										}
									};
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 7;
				}
			}),

		};

		public static Fixture[] binaryFixtures = {
			build(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TI";
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}),

			build(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TI-M";
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TLI";
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TLI-S";
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "TLI-M";
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					searchRequest = new SearchRequest() {
						{
							functionName = "LI-P";
							record = new Record() {
								{
									binary = RandomStringUtils.randomAscii(32).getBytes();
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 6;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();
			PBKeyedTemplate.Builder templateBuilder = null;

			if (expected.number == 1) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.searchRequest.getRecord().getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TI);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 2) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.searchRequest.getRecord().getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TIM);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 3) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.searchRequest.getRecord().getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TLI);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 4) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.searchRequest.getRecord().getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TLIS);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 5) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.searchRequest.getRecord().getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TLIM);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 6) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.searchRequest.getRecord().getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_LIP);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			}
			builder.setKeyedTemplate(templateBuilder);
			return new Fixture(parameter, builder.build());
		}

		public static ReferenceFixture buildReference(
			Parameter parameter,
			Expected expected) {
			PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();
			PBKeyedTemplateReference.Builder referenceBuilder = null;
			if (expected.number == 1) {
				referenceBuilder = PBKeyedTemplateReference.newBuilder();
				referenceBuilder.setJobId(parameter.searchRequest.getRecord()
					.getReference().getJobId());
				referenceBuilder.setKey(TemplateFormatType.TEMPLATE_TI);
				referenceBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 2) {
				referenceBuilder = PBKeyedTemplateReference.newBuilder();
				referenceBuilder.setJobId(parameter.searchRequest.getRecord()
					.getReference().getJobId());
				referenceBuilder.setKey(TemplateFormatType.TEMPLATE_TIM);
				referenceBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 3) {
				referenceBuilder = PBKeyedTemplateReference.newBuilder();
				referenceBuilder.setJobId(parameter.searchRequest.getRecord()
					.getReference().getJobId());
				referenceBuilder.setKey(TemplateFormatType.TEMPLATE_TLI);
				referenceBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 4) {
				referenceBuilder = PBKeyedTemplateReference.newBuilder();
				referenceBuilder.setJobId(parameter.searchRequest.getRecord()
					.getReference().getJobId());
				referenceBuilder.setKey(TemplateFormatType.TEMPLATE_TLIS);
				referenceBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 5) {
				referenceBuilder = PBKeyedTemplateReference.newBuilder();
				referenceBuilder.setJobId(parameter.searchRequest.getRecord()
					.getReference().getJobId());
				referenceBuilder.setKey(TemplateFormatType.TEMPLATE_TLIM);
				referenceBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 6) {
				referenceBuilder = PBKeyedTemplateReference.newBuilder();
				referenceBuilder.setJobId(parameter.searchRequest.getRecord()
					.getReference().getJobId());
				referenceBuilder.setKey(TemplateFormatType.TEMPLATE_FI);
				referenceBuilder.getIndexerBuilder().setIndex(3);
			} else if (expected.number == 7) {
				referenceBuilder = PBKeyedTemplateReference.newBuilder();
				referenceBuilder.setJobId(parameter.searchRequest.getRecord()
					.getReference().getJobId());
				referenceBuilder.setKey(TemplateFormatType.TEMPLATE_II);
			}

			builder.setKeyedReferenece(referenceBuilder);
			return new ReferenceFixture(parameter, builder.build());
		}

		public static class Parameter {
			public SearchRequest searchRequest;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBKeyedTemplateData expected;

			Fixture(Parameter parameter, PBKeyedTemplateData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}

		public static class ReferenceFixture {
			public Parameter parameter;
			public PBKeyedTemplateData expected;

			ReferenceFixture(Parameter parameter, PBKeyedTemplateData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBKeyedTemplateDataWith_String_byteArray_Helper {
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "TI_ROLLED";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "TIM_SLAP";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "TLI_ROLLED";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "TLIS_SLAP";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 4;
				}
			}),

			build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "TLIM_SLAP";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							key = "LLIX";
							binary = RandomStringUtils.randomAscii(32).getBytes();
						}
					};
				}
			}, new Expected() {
				{
					number = 6;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();
			PBKeyedTemplate.Builder templateBuilder = null;

			if (expected.number == 1) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.keyedTemplate.getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TI);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 2) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.keyedTemplate.getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TIM);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 3) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.keyedTemplate.getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TLI);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 4) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.keyedTemplate.getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TLIS);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 5) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.keyedTemplate.getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_TLIM);
				templateBuilder.getIndexerBuilder().setFingerPrintType(
					FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 6) {
				templateBuilder = PBKeyedTemplate.newBuilder();
				templateBuilder.setTemplateBinary(ByteString
					.copyFrom(parameter.keyedTemplate.getBinary()));
				templateBuilder.setKey(TemplateFormatType.TEMPLATE_LLIX);
			}
			builder.setKeyedTemplate(templateBuilder);

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public KeyedTemplate keyedTemplate;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBKeyedTemplateData expected;

			Fixture(Parameter parameter, PBKeyedTemplateData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBInquiryJobInfo_Help {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			Parameter parameter = new Parameter();
			PBInquiryJobInfo.Builder builder = PBInquiryJobInfo.newBuilder();

			parameter.function = InquiryFunctionType.TI;
			builder.setFunction(InquiryFunctionType.TI);

			parameter.commonOptions = new CommonOptions();
			parameter.commonOptions.setCallbackURL("test");
			builder.setCallBackUrl("test");

			parameter.commonOptions.setDynThreshHitThreshold(1);
			builder.setDynThreshHitThreshold(1);

			parameter.commonOptions.setDynThreshPercentagePoint(2.0);
			builder.setDynThreshPercentagePoint(2.0f);

			parameter.commonOptions.setMaxCandidates(3);
			builder.setMaxCandidate(3);

			parameter.commonOptions.setPriority(4);
			builder.setPriority(4);

			parameter.commonOptions.setMinScore(5);

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public InquiryFunctionType function;
			public CommonOptions commonOptions;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBInquiryJobInfo expected;

			Fixture(Parameter parameter, PBInquiryJobInfo expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBInquiryFusionWeight_Helper {
		public static Map<TemplateFormatType, Integer> inquirySetMap = new HashMap<>();

		public static void clearIndex() {
			inquirySetMap.clear();
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TI, Integer.valueOf(1));
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TIM, Integer.valueOf(1));
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TLIM, Integer.valueOf(1));
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TLI, Integer.valueOf(1));
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TLIS, Integer.valueOf(1));
		}

		public static void setIndexForExceptionOccurring() {
			inquirySetMap.clear();
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TLI, Integer.valueOf(3));
		}

		public static ExceptionFixture[] exceptionFixtures = {
			build(new ExceptionParameter() {
				{
					function = InquiryFunctionType.TI;
					key = TemplateFormatType.TEMPLATE_TI;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
							fusionWeightList = new ArrayList<>();
							fusionWeightList.add(new FusionWeight() {
								{
									value = 1;
									inquirySet = InquirySetEnum.PC_2_SLAP;
								}
							});
						}
					});
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new ExceptionParameter() {
				{
					function = InquiryFunctionType.TLIX;
					key = TemplateFormatType.TEMPLATE_TLIX;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
							fusionWeightList = new ArrayList<>();
							fusionWeightList.add(new FusionWeight() {
								{
									value = 1;
								}
							});
						}
					});
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new ExceptionParameter() {
				{
					function = InquiryFunctionType.LIX;
					key = TemplateFormatType.TEMPLATE_LIX;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
							fusionWeightList = new ArrayList<>();
							fusionWeightList.add(new FusionWeight() {
								{
									value = 1;
								}
							});
						}
					});
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new ExceptionParameter() {
				{
					function = InquiryFunctionType.LLIX;
					key = TemplateFormatType.TEMPLATE_LLIX;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
							fusionWeightList = new ArrayList<>();
							fusionWeightList.add(new FusionWeight() {
								{
									value = 1;
								}
							});
						}
					});
				}
			}, new Expected() {
				{
					number = 4;
				}
			}),
		};

		public static ExceptionFixture build(
			ExceptionParameter parameter,
			Expected expected) {
			String message = null;
			Class<? extends Throwable> clazz = null;

			if (expected.number == 1) {
				clazz = InvalidParameterException.class;
				message =
					"An invalid parameter: there is a inquirySet of a fusion-weight element.";
			} else if (expected.number == 2 || expected.number == 3
				|| expected.number == 4) {
				clazz = jp.co.nec.aim.convert.InvalidParameterException.class;
				message =
					"An invalid parameter: a inquirySet of a fusion-weight element has null.";
			}

			return new ExceptionFixture(parameter, clazz, message);
		}

		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					function = InquiryFunctionType.TI;
					key = TemplateFormatType.TEMPLATE_TI;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 1;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TIM;
					key = TemplateFormatType.TEMPLATE_TIM;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 2;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TLIM;
					key = TemplateFormatType.TEMPLATE_TLIM;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 3;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TLI;
					key = TemplateFormatType.TEMPLATE_TLI;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 4;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TLI;
					key = TemplateFormatType.TEMPLATE_TLIS;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 5;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LIM;
					key = TemplateFormatType.TEMPLATE_LIM;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 6;
					inquirySetIndex = 0;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LLIM;
					key = TemplateFormatType.TEMPLATE_LLIM;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 7;
					inquirySetIndex = 0;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TLIX;
					key = TemplateFormatType.TEMPLATE_TLIX;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
							inquirySet = InquirySetEnum.PC_2_ROLLED;
						}
					});
					fusionWeightList.add(new FusionWeight() {
						{
							value = 2;
							inquirySet = InquirySetEnum.FMP_5_SLAP;
						}
					});
				}
			}, new Expected() {
				{
					number = 8;
					inquirySetIndex = 0;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LIX;
					key = TemplateFormatType.TEMPLATE_LIX;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
							inquirySet = InquirySetEnum.PC_2_SLAP;
						}
					});
					fusionWeightList.add(new FusionWeight() {
						{
							value = 2;
							inquirySet = InquirySetEnum.FMP_5_ROLLED;
						}
					});
					fusionWeightList.add(new FusionWeight() {
						{
							value = 3;
							inquirySet = InquirySetEnum.PC_2_ROLLED;
						}
					});
					fusionWeightList.add(new FusionWeight() {
						{
							value = 4;
							inquirySet = InquirySetEnum.FMP_5_SLAP;
						}
					});
				}
			}, new Expected() {
				{
					number = 9;
					inquirySetIndex = 0;
				}
			}),

			build(new Parameter() {
				{
					function = InquiryFunctionType.LI;
					key = TemplateFormatType.TEMPLATE_LI;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 10;
					inquirySetIndex = 0;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LI;
					key = TemplateFormatType.TEMPLATE_LIS;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 11;
					inquirySetIndex = 0;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LLI;
					key = TemplateFormatType.TEMPLATE_LLI;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 12;
					inquirySetIndex = 0;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LLI;
					key = TemplateFormatType.TEMPLATE_LLIS;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
				}
			}, new Expected() {
				{
					number = 13;
					inquirySetIndex = 0;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LLIX;
					key = TemplateFormatType.TEMPLATE_LLIX;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
							inquirySet = InquirySetEnum.FMP_5_LATENT;
						}
					});
				}
			}, new Expected() {
				{
					number = 14;
					inquirySetIndex = 0;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TLI;
					key = TemplateFormatType.TEMPLATE_TLI;
					fusionWeightList = new ArrayList<>();
				}
			}, new Expected() {
				{
					number = 15;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TI;
					key = TemplateFormatType.TEMPLATE_TI;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}, new Expected() {
				{
					number = 16;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TIM;
					key = TemplateFormatType.TEMPLATE_TIM;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}, new Expected() {
				{
					number = 17;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TLIM;
					key = TemplateFormatType.TEMPLATE_TLIM;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}, new Expected() {
				{
					number = 18;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TLI;
					key = TemplateFormatType.TEMPLATE_TLI;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}, new Expected() {
				{
					number = 19;
					inquirySetIndex = 2;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TLI;
					key = TemplateFormatType.TEMPLATE_TLIS;
					fusionWeightList = new ArrayList<>();
					fusionWeightList.add(new FusionWeight() {
						{
							value = 1;
						}
					});
					fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
				}
			}, new Expected() {
				{
					number = 20;
					inquirySetIndex = 2;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			List<PBInquiryFusionWeight> expectedList = new ArrayList<>();

			if (expected.number == 1) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_ROLLED);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 2) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_ROLLED);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 3) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_ROLLED);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 4) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.FMP5_ROLLED);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 5) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_ROLLED);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 6) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_LATENT);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 7) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_LATENT);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 8) {
				{
					PBInquiryFusionWeight.Builder builder =
						PBInquiryFusionWeight.newBuilder();
					builder.setInquirySet(FingerSetType.PC2_ROLLED);
					builder.setWeight(1);

					expectedList.add(builder.build());
				}
				{
					PBInquiryFusionWeight.Builder builder =
						PBInquiryFusionWeight.newBuilder();
					builder.setInquirySet(FingerSetType.FMP5_SLAP);
					builder.setWeight(2);

					expectedList.add(builder.build());
				}
			} else if (expected.number == 9) {
				{
					PBInquiryFusionWeight.Builder builder =
						PBInquiryFusionWeight.newBuilder();
					builder.setInquirySet(FingerSetType.PC2_SLAP);
					builder.setWeight(1);

					expectedList.add(builder.build());
				}
				{
					PBInquiryFusionWeight.Builder builder =
						PBInquiryFusionWeight.newBuilder();
					builder.setInquirySet(FingerSetType.FMP5_ROLLED);
					builder.setWeight(2);

					expectedList.add(builder.build());
				}
				{
					PBInquiryFusionWeight.Builder builder =
						PBInquiryFusionWeight.newBuilder();
					builder.setInquirySet(FingerSetType.PC2_ROLLED);
					builder.setWeight(3);

					expectedList.add(builder.build());
				}
				{
					PBInquiryFusionWeight.Builder builder =
						PBInquiryFusionWeight.newBuilder();
					builder.setInquirySet(FingerSetType.FMP5_SLAP);
					builder.setWeight(4);

					expectedList.add(builder.build());
				}
			} else if (expected.number == 10 || expected.number == 12) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.FMP5_LATENT);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 11 || expected.number == 13) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_LATENT);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 14) {
				{
					PBInquiryFusionWeight.Builder builder =
						PBInquiryFusionWeight.newBuilder();
					builder.setInquirySet(FingerSetType.FMP5_LATENT);
					builder.setWeight(1);

					expectedList.add(builder.build());
				}
			} else if (expected.number == 15) {
				{
				}
			} else if (expected.number == 16) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_SLAP);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 2) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_SLAP);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 3) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_SLAP);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 4) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.FMP5_SLAP);
				builder.setWeight(1);

				expectedList.add(builder.build());
			} else if (expected.number == 5) {
				PBInquiryFusionWeight.Builder builder =
					PBInquiryFusionWeight.newBuilder();
				builder.setInquirySet(FingerSetType.PC2_SLAP);
				builder.setWeight(1);

				expectedList.add(builder.build());
			}
			return new Fixture(parameter, expectedList, expected.inquirySetIndex);
		}

		public static class Parameter {
			public InquiryFunctionType function;
			public TemplateFormatType key;
			public List<FusionWeight> fusionWeightList;
			public FingerPrintType fingerPrintType;
		}

		public static class ExceptionParameter extends Parameter {
		}

		public static class Expected {
			public int number;
			public int inquirySetIndex;
		}

		public static class Fixture {
			public Parameter parameter;
			public List<PBInquiryFusionWeight> expected;
			public int expectedInquirySetIndex;

			Fixture(Parameter parameter, List<PBInquiryFusionWeight> expected,
				int inquirySetIndex) {
				this.parameter = parameter;
				this.expected = expected;
				this.expectedInquirySetIndex = inquirySetIndex;
			}

			Fixture() {
			}
		}

		public static class ExceptionFixture {
			public ExceptionParameter parameter;
			public Class<? extends Throwable> expectedClazz;
			public String expectedMessage;

			public ExceptionFixture(ExceptionParameter parameter,
				Class<? extends Throwable> clazz, String expectedMessage) {
				this.parameter = parameter;
				this.expectedClazz = clazz;
				this.expectedMessage = expectedMessage;
			}
		}
	}

	public static class ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					function = InquiryFunctionType.TI;
					afisCcopeIdList = new ArrayList<>();
					afisCcopeIdList.add(1);
					afisCcopeIdList.add(1002);
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TIM;
					afisCcopeIdList = new ArrayList<>();
					afisCcopeIdList.add(332);
				}
			}, new Expected() {
				{
					number = 2;
				}
			}),

			build(new Parameter() {
				{
					function = InquiryFunctionType.LI;
					afisCcopeIdList = new ArrayList<>();
					afisCcopeIdList.add(2004);
					afisCcopeIdList.add(3);
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LI;
					afisCcopeIdList = new ArrayList<>();
					afisCcopeIdList.add(324);
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LIM;
					afisCcopeIdList = new ArrayList<>();
					afisCcopeIdList.add(1333);
					afisCcopeIdList.add(1334);
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LIX;
					afisCcopeIdList = new ArrayList<>();
					afisCcopeIdList.add(341);
				}
			}, new Expected() {
				{
					number = 6;
				}

			}), build(new Parameter() {
				{
					function = InquiryFunctionType.TIM;
					afisCcopeIdList = new ArrayList<>();
					afisCcopeIdList.add(331);
					afisCcopeIdList.add(332);
				}
			}, new Expected() {
				{
					number = 7;
				}
			}), build(new Parameter() {
				{
					function = InquiryFunctionType.LI;
					afisCcopeIdList = new ArrayList<>();
					afisCcopeIdList.add(323);
					afisCcopeIdList.add(324);
					afisCcopeIdList.add(2323);
					afisCcopeIdList.add(2324);
				}
			}, new Expected() {
				{
					number = 8;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			PBInquiryScopeOptions.Builder builder = PBInquiryScopeOptions.newBuilder();

			if (expected.number == 1) {
				builder.addScope(1).addScope(2);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 2) {
				builder.addScope(1);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 3) {
				builder.addScope(3).addScope(1);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
			} else if (expected.number == 4) {
				builder.addScope(1);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 5) {
				builder.addScope(2);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 6) {
				builder.addScope(1);
			} else if (expected.number == 7) {
				builder.addScope(1);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
			} else if (expected.number == 8) {
				builder.addScope(1);
				builder.addScope(3);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
			}
			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public InquiryFunctionType function;
			public List<Integer> afisCcopeIdList;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBInquiryScopeOptions expected;

			Fixture(Parameter parameter, PBInquiryScopeOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBInquiryJobRequestWith_ListOfSearchRequest_CommonOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(String type) {
			Parameter parameter = new Parameter();
			SearchRequest searchRequest = new SearchRequest();
			PBInquiryJobRequest.Builder builder = PBInquiryJobRequest.newBuilder();
			PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput.newBuilder();

			if (type.equals("")) {
				{
					ToPBInquiryJobInfo_Help.Fixture fixture =
						ToPBInquiryJobInfo_Help.build();
					parameter.commonOptions = fixture.parameter.commonOptions;
					builder.setJobInfo(fixture.expected);
				}
				{
					ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper.Fixture fixture =
						ToPBInquiryScopeOptionsWith_InquiryFunctionType_ListOfInteger_Helper.fixtures[0];
					searchRequest.getSearchContainer().addAll(
						fixture.parameter.afisCcopeIdList);
					fusionJobBuilder.setScopes(fixture.expected);
				}
				{
					ToPBKeyedTemplateDataWith_SearchRequest_Helper.Fixture fixture =
						ToPBKeyedTemplateDataWith_SearchRequest_Helper.binaryFixtures[0];
					searchRequest.setFunctionName(fixture.parameter.searchRequest
						.getFunctionName());
					searchRequest.setRecord(fixture.parameter.searchRequest.getRecord());
					fusionJobBuilder.setKeyedTemplateData(fixture.expected);
				}
				{
					ToPBInquiryFusionWeight_Helper.Fixture fixture =
						ToPBInquiryFusionWeight_Helper.fixtures[0];
					searchRequest.getFusionWeight().addAll(
						fixture.parameter.fusionWeightList);
				}
				{
					ToPBInquiryPayload_Helper.Fixture fixture =
						ToPBInquiryPayload_Helper.build("", true);
					DynamicXml dom = null;
					try {
						Method setUpObject =
							ProtoClassConvert.class.getDeclaredMethod("toDynamicXml",
								SearchInputsPayload.class);
						setUpObject.setAccessible(true);
						dom = (DynamicXml)setUpObject.invoke(null, fixture.parameter);
					} catch (Exception e) {

					}
					SearchOptions options = new SearchOptions();
					options.setSearchInputsPayload(dom);
					searchRequest.setSearchOptions(options);
				}

				parameter.commonOptions.setMinScore(6);
				fusionJobBuilder.getInquiryOptionsBuilder().setMinScore(6);

				builder.addFusionJobInput(fusionJobBuilder);

				parameter.searchRequestList.add(searchRequest);
			} else if (type.equals("container IDs overlap")) {
				{
					ToPBInquiryJobInfo_Help.Fixture fixture =
						ToPBInquiryJobInfo_Help.build();
					parameter.commonOptions = fixture.parameter.commonOptions;
					builder.setJobInfo(fixture.expected);
				}
				{
					searchRequest.getSearchContainer().add(1);
					searchRequest.getSearchContainer().add(1);
				}
				parameter.searchRequestList.add(searchRequest);
			}
			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public List<SearchRequest> searchRequestList = new ArrayList<>();
			public CommonOptions commonOptions;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBInquiryJobRequest expected;

			Fixture(Parameter parameter, PBInquiryJobRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ValidationContaineridOnFunction_Helper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					searchContainerList.add(1);
					searchContainerList.add(1002);
					expectedIdList.add(1);
					expectedIdList.add(2);
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					searchContainerList.add(1);
					expectedIdList.add(1);
					expectedIdList.add(2);
				}
			}, new Expected() {
				{
					number = 1;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			return new Fixture(parameter, expected);
		}

		public static class Parameter {
			public List<Integer> searchContainerList = new ArrayList<>();
			public List<Integer> expectedIdList = new ArrayList<>();
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public Expected expected;

			Fixture(Parameter parameter, Expected expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPBInquiryScopeOptionsWith_KeyedTemplate_Helper {
		@SuppressWarnings("boxing")
		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					keyedTemplate = new KeyedTemplate() {
						{
							metadata = new TemplateMetadata() {
								{
									afisGroupId = new ArrayList<>();
									afisGroupId.add(0);
									afisGroupId.add(1);
									fingerSet = new ArrayList<>();
									fingerSet.add(FingerSetEnum.ROLL);
									fingerSet.add(FingerSetEnum.SLAP);
								}
							};
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			PBInquiryScopeOptions.Builder builder = PBInquiryScopeOptions.newBuilder();

			if (expected.number == 1) {
				builder.addScope(0).addScope(1);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
			}
			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public KeyedTemplate keyedTemplate;
		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBInquiryScopeOptions expected;

			Fixture(Parameter parameter, PBInquiryScopeOptions expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ValidateFunctionToKeyWith_AfisLowLevelFunctionEnum_AfisTemplateSet_Helper {

		public static ExceptionFixture[] exceptionFixtures = {
			build(new ExceptionParameter() {
				{
					function = AfisLowLevelFunctionEnum.TLIS;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "TLIS_ROLLED";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new ExceptionParameter() {
				{
					function = AfisLowLevelFunctionEnum.TI;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "TI_ROLLED";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "TLI_SLAP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new ExceptionParameter() {
				{
					function = AfisLowLevelFunctionEnum.TI;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "FI_1";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}),
		};

		public static ExceptionFixture build(
			ExceptionParameter parameter,
			Expected expected) {
			String message = null;
			Class<? extends Throwable> clazz = null;

			if (expected.number == 1) {
				clazz = jp.co.nec.aim.convert.InvalidParameterException.class;
				message = "An invalid parameter: there is a invalid key.";
			} else if (expected.number == 2) {
				clazz = jp.co.nec.aim.convert.InvalidParameterException.class;
				message = "An invalid parameter: there is a invalid key.";
			} else if (expected.number == 3) {
				clazz = jp.co.nec.aim.convert.InvalidParameterException.class;
				message = "An invalid parameter: there is a invalid key.";
			}
			return new ExceptionFixture(parameter, clazz, message);
		}

		public static Fixture[] fixtures = {
			build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.TI;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "TI_ROLLED";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "TI_SLAP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 1;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.TIM;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "TIM_ROLLED";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "TIM_SLAP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 2;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.LI;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LI";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "LIS";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 3;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.LIM;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LIM";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 4;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.TLI;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "TLI_ROLLED";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "TLI_SLAP";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "TLIS_ROLLED";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "TLIS_SLAP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 5;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.TLIM;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "TLIM_ROLLED";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "TLIM_SLAP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 6;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.LLI;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LLI";
								}
							});
							template.add(new KeyedTemplate() {
								{
									key = "LLIS";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 7;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.LLIM;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LLIM";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 8;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.LIP;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LIP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 9;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.TLIP;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "TLIP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 10;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.LLIP;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LLIP";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 11;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.LIX;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LIX";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 12;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.TLIX;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "TLIX";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 13;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.LLIX;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "LLIX";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 14;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.FI;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "FI";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 15;
				}
			}), build(new Parameter() {
				{
					function = AfisLowLevelFunctionEnum.II;
					afisTemplateSet = new AfisTemplateSet() {
						{
							template = new ArrayList<>();
							template.add(new KeyedTemplate() {
								{
									key = "II";
								}
							});
						}
					};
				}
			}, new Expected() {
				{
					number = 16;
				}
			}),
		};

		public static Fixture build(Parameter parameter, Expected expected) {
			return new Fixture(parameter);
		}

		public static class Parameter {
			public AfisLowLevelFunctionEnum function;
			public AfisTemplateSet afisTemplateSet;
		}

		public static class ExceptionParameter extends Parameter {

		}

		public static class Expected {
			public int number;
		}

		public static class Fixture {
			public Parameter parameter;
			public String message;

			Fixture(Parameter parameter) {
				this.parameter = parameter;
			}
		}

		public static class ExceptionFixture {
			public ExceptionParameter parameter;
			public Class<? extends Throwable> expectedClazz;
			public String expectedMessage;

			public ExceptionFixture(ExceptionParameter parameter,
				Class<? extends Throwable> clazz, String expectedMessage) {
				this.parameter = parameter;
				this.expectedClazz = clazz;
				this.expectedMessage = expectedMessage;
			}
		}
	}

	public static class ToPBInquiryJobRequestWith_AfisLowLevelFunctionEnum_AfisTemplateSet_CommonOptions_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			Parameter parameter = new Parameter();
			parameter.function = AfisLowLevelFunctionEnum.TI;
			AfisTemplateSet afisTemplateSet = new AfisTemplateSet();

			PBInquiryJobRequest.Builder builder = PBInquiryJobRequest.newBuilder();
			PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput.newBuilder();

			{
				ToPBInquiryJobInfo_Help.Fixture fixture = ToPBInquiryJobInfo_Help.build();
				parameter.commonOptions = fixture.parameter.commonOptions;
				builder.setJobInfo(fixture.expected);
			}
			{
				ToPBInquiryScopeOptionsWith_KeyedTemplate_Helper.Fixture fixture =
					ToPBInquiryScopeOptionsWith_KeyedTemplate_Helper.fixtures[0];
				fusionJobBuilder.setScopes(fixture.expected);
			}
			{
				ToPBKeyedTemplateDataWith_String_byteArray_Helper.Fixture fixture =
					ToPBKeyedTemplateDataWith_String_byteArray_Helper.fixtures[0];
				afisTemplateSet.getTemplate().add(fixture.parameter.keyedTemplate);
				fusionJobBuilder.setKeyedTemplateData(fixture.expected);
			}
			{
				ToPBInquiryPayload_Helper.Fixture fixture =
					ToPBInquiryPayload_Helper.build("", true);
				DynamicXml dom = null;
				try {
					Method setUpObject =
						ProtoClassConvert.class.getDeclaredMethod("toDynamicXml",
							SearchInputsPayload.class);
					setUpObject.setAccessible(true);
					dom = (DynamicXml)setUpObject.invoke(null, fixture.parameter);
				} catch (Exception e) {

				}
				SearchOptions options = new SearchOptions();
				options.setSearchInputsPayload(dom);
				afisTemplateSet.getTemplate().get(0).setSearchOptions(options);
			}

			parameter.afisTemplateSet = afisTemplateSet;
			parameter.commonOptions.setMinScore(6);
			fusionJobBuilder.getInquiryOptionsBuilder().setMinScore(6);

			builder.addFusionJobInput(fusionJobBuilder);

			return new Fixture(parameter, builder.build());
		}

		public static class Parameter {
			public AfisLowLevelFunctionEnum function;
			public AfisTemplateSet afisTemplateSet;
			public CommonOptions commonOptions;
		}

		public static class Fixture {
			public Parameter parameter;
			public PBInquiryJobRequest expected;

			Fixture(Parameter parameter, PBInquiryJobRequest expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	// public static class To {
	// public static Fixture build() {
	// return new Fixture(parameter, builder.build());
	// }
	//
	// public static class Fixture {
	// public parameter;
	// public expected;
	//
	// Fixture( parameter, expected) {
	// this.parameter = parameter;
	// this.expected = expected;
	// }
	// }
	// }

}
