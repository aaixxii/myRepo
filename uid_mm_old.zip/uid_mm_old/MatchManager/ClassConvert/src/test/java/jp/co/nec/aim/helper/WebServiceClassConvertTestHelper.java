package jp.co.nec.aim.helper;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerAxisType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPatternType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FisTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckAdvancedActivityType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckAdvancedStateType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBCropPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceDetectionOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisDetectionOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentFingerOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentPalmOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractPalmOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintFingerOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace13Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceImageAnalysis;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceRectPoints;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceReliability;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerCropCoordinate;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPatterns;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPrelsectionDataOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPsrData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQrData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQrDataOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualities;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutputAdvanced;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutputStandard;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisCore;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisMinutiaNo;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisPatternType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisQuality;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFusionIndexer;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBImageData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBIrisDetectionPoints;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBMinutiaData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPaExtData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPrefilterData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPrefilterDataTenprintFinger;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOutputAdvancedHistory;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOutputAdvancedSequence;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOutputStandardStatus;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBTenprintFingerQualitySummary;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore.PBFlexibleScoreIris;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore.PBFlexibleScoreLFML;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidate;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateIndividualScore;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateList;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateTemplate;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatistics;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatisticsAMR;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResponse;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResult;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResultDetail;
import jp.co.nec.aim.mm.jaxb.AxisEnum;
import jp.co.nec.aim.mm.jaxb.Candidate;
import jp.co.nec.aim.mm.jaxb.CandidateTemplate;
import jp.co.nec.aim.mm.jaxb.CheckResult;
import jp.co.nec.aim.mm.jaxb.CheckResults;
import jp.co.nec.aim.mm.jaxb.ContainerResult;
import jp.co.nec.aim.mm.jaxb.CropInfo;
import jp.co.nec.aim.mm.jaxb.ExtOutput;
import jp.co.nec.aim.mm.jaxb.ExtractJobError;
import jp.co.nec.aim.mm.jaxb.ExtractJobResult;
import jp.co.nec.aim.mm.jaxb.Face13Points;
import jp.co.nec.aim.mm.jaxb.FaceAnalysisOutput;
import jp.co.nec.aim.mm.jaxb.FaceOutput;
import jp.co.nec.aim.mm.jaxb.FaceOutputDetection;
import jp.co.nec.aim.mm.jaxb.FaceOutputPoints;
import jp.co.nec.aim.mm.jaxb.FacePoint;
import jp.co.nec.aim.mm.jaxb.FaceRect;
import jp.co.nec.aim.mm.jaxb.Finger;
import jp.co.nec.aim.mm.jaxb.FingerOutput;
import jp.co.nec.aim.mm.jaxb.FisData;
import jp.co.nec.aim.mm.jaxb.FusionIndexer;
import jp.co.nec.aim.mm.jaxb.HeadRect;
import jp.co.nec.aim.mm.jaxb.ImageAnalysis;
import jp.co.nec.aim.mm.jaxb.IndividualScore;
import jp.co.nec.aim.mm.jaxb.InquirySetEnum;
import jp.co.nec.aim.mm.jaxb.IrisOutput;
import jp.co.nec.aim.mm.jaxb.IrisOutputDetection;
import jp.co.nec.aim.mm.jaxb.IrisOutputPoints;
import jp.co.nec.aim.mm.jaxb.IrisPoint;
import jp.co.nec.aim.mm.jaxb.IrisPoints;
import jp.co.nec.aim.mm.jaxb.IrisScore;
import jp.co.nec.aim.mm.jaxb.JobStateEnum;
import jp.co.nec.aim.mm.jaxb.JobStatus;
import jp.co.nec.aim.mm.jaxb.KeyedBinary;
import jp.co.nec.aim.mm.jaxb.LatentOutput;
import jp.co.nec.aim.mm.jaxb.MinutiaData;
import jp.co.nec.aim.mm.jaxb.PaextData;
import jp.co.nec.aim.mm.jaxb.PalmOutput;
import jp.co.nec.aim.mm.jaxb.Point;
import jp.co.nec.aim.mm.jaxb.PointCenter;
import jp.co.nec.aim.mm.jaxb.PrefilterOutput;
import jp.co.nec.aim.mm.jaxb.PsrData;
import jp.co.nec.aim.mm.jaxb.PsrOutput;
import jp.co.nec.aim.mm.jaxb.PupilPoints;
import jp.co.nec.aim.mm.jaxb.QcActivity;
import jp.co.nec.aim.mm.jaxb.QcDetailStatus;
import jp.co.nec.aim.mm.jaxb.QcHistory;
import jp.co.nec.aim.mm.jaxb.QcOutput;
import jp.co.nec.aim.mm.jaxb.QcSequence;
import jp.co.nec.aim.mm.jaxb.QcStatus;
import jp.co.nec.aim.mm.jaxb.QrData;
import jp.co.nec.aim.mm.jaxb.QrOutput;
import jp.co.nec.aim.mm.jaxb.RawScore;
import jp.co.nec.aim.mm.jaxb.RawScores;
import jp.co.nec.aim.mm.jaxb.SearchJobError;
import jp.co.nec.aim.mm.jaxb.SearchJobResult;
import jp.co.nec.aim.mm.jaxb.SearchOutputsPayload;
import jp.co.nec.aim.mm.jaxb.SearchStatistics;
import jp.co.nec.aim.mm.jaxb.TenprintOutput;

import org.apache.commons.lang3.RandomStringUtils;

import com.google.protobuf.ByteString;

public class WebServiceClassConvertTestHelper {

	public static class ToFace13PointsHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFace13Points.Builder face13PointsBuilder = PBFace13Points.newBuilder();
			PBPoint.Builder pointBuilder = PBPoint.newBuilder();

			pointBuilder.setX(1);
			pointBuilder.setY(2);
			face13PointsBuilder.setRightEyeCenter(pointBuilder.build());

			pointBuilder.setX(3);
			pointBuilder.setY(4);
			face13PointsBuilder.setLeftEyeCenter(pointBuilder.build());

			pointBuilder.setX(5);
			pointBuilder.setY(6);
			face13PointsBuilder.setRightEyeInnerCorner(pointBuilder.build());

			pointBuilder.setX(7);
			pointBuilder.setY(8);
			face13PointsBuilder.setLeftEyeInnerCorner(pointBuilder.build());

			pointBuilder.setX(9);
			pointBuilder.setY(10);
			face13PointsBuilder.setRightEyeOuterCorner(pointBuilder.build());

			pointBuilder.setX(11);
			pointBuilder.setY(12);
			face13PointsBuilder.setLeftEyeOuterCorner(pointBuilder.build());

			pointBuilder.setX(13);
			pointBuilder.setY(14);
			face13PointsBuilder.setCenterBelowNose(pointBuilder.build());

			pointBuilder.setX(15);
			pointBuilder.setY(16);
			face13PointsBuilder.setRightSideNose(pointBuilder.build());

			pointBuilder.setX(17);
			pointBuilder.setY(18);
			face13PointsBuilder.setLeftSideNose(pointBuilder.build());

			pointBuilder.setX(19);
			pointBuilder.setY(20);
			face13PointsBuilder.setRightCornerMouth(pointBuilder.build());

			pointBuilder.setX(21);
			pointBuilder.setY(22);
			face13PointsBuilder.setLeftCornerMouth(pointBuilder.build());

			pointBuilder.setX(23);
			pointBuilder.setY(24);
			face13PointsBuilder.setTopCenterUpperLip(pointBuilder.build());

			pointBuilder.setX(25);
			pointBuilder.setY(26);
			face13PointsBuilder.setBottomCenterUpperLip(pointBuilder.build());

			Face13Points expected = new Face13Points();
			FacePoint facePoint = null;
			facePoint = new FacePoint();
			facePoint.setX(1);
			facePoint.setY(2);
			expected.setRightEyeCenter(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(3);
			facePoint.setY(4);
			expected.setLeftEyeCenter(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(5);
			facePoint.setY(6);
			expected.setRightEyeInnerCorner(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(7);
			facePoint.setY(8);
			expected.setLeftEyeInnerCorner(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(9);
			facePoint.setY(10);
			expected.setRightEyeOuterCorner(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(11);
			facePoint.setY(12);
			expected.setLeftEyeOuterCorner(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(13);
			facePoint.setY(14);
			expected.setCenterBelowNose(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(15);
			facePoint.setY(16);
			expected.setRightSideNose(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(17);
			facePoint.setY(18);
			expected.setLeftSideNose(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(19);
			facePoint.setY(20);
			expected.setRightCornerMouth(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(21);
			facePoint.setY(22);
			expected.setLeftCornerMouth(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(23);
			facePoint.setY(24);
			expected.setTopCenterUpperLip(facePoint);

			facePoint = new FacePoint();
			facePoint.setX(25);
			facePoint.setY(26);
			expected.setBottomCenterUpperLip(facePoint);

			return new Fixture(face13PointsBuilder.build(), expected);
		}

		public static class Fixture {
			public PBFace13Points parameter;
			public Face13Points expected;

			Fixture(PBFace13Points parameter, Face13Points expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFacePointHelper {
		@SuppressWarnings("boxing")
		public static Fixture build(int x, int y) {
			PBPoint.Builder builder = PBPoint.newBuilder();
			builder.setX(x);
			builder.setY(y);

			FacePoint expected = new FacePoint();
			expected.setX(x);
			expected.setY(y);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBPoint parameter;
			public FacePoint expected;

			Fixture(PBPoint parameter, FacePoint expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToHeadRectHelper {
		public static Fixture build() {
			PBFaceRectPoints.Builder builder = PBFaceRectPoints.newBuilder();
			HeadRect expected = new HeadRect();
			{
				ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(1, 2);
				builder.setUpperLeft(fixture.parameter);
				expected.setUpperLeft(fixture.expected);
			}
			{
				ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(3, 4);
				builder.setUpperRight(fixture.parameter);
				expected.setUpperRight(fixture.expected);
			}
			{
				ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(5, 6);
				builder.setLowerLeft(fixture.parameter);
				expected.setLowerLeft(fixture.expected);
			}
			{
				ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(7, 8);
				builder.setLowerRight(fixture.parameter);
				expected.setLowerRight(fixture.expected);
			}
			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFaceRectPoints parameter;
			public HeadRect expected;

			Fixture(PBFaceRectPoints parameter, HeadRect expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFaceRectHelper {
		public static Fixture build() {
			PBFaceRectPoints.Builder builder = PBFaceRectPoints.newBuilder();
			FaceRect expected = new FaceRect();
			{
				ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(1, 2);
				builder.setUpperLeft(fixture.parameter);
				expected.setUpperLeft(fixture.expected);
			}
			{
				ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(3, 4);
				builder.setUpperRight(fixture.parameter);
				expected.setUpperRight(fixture.expected);
			}
			{
				ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(5, 6);
				builder.setLowerLeft(fixture.parameter);
				expected.setLowerLeft(fixture.expected);
			}
			{
				ToFacePointHelper.Fixture fixture = ToFacePointHelper.build(7, 8);
				builder.setLowerRight(fixture.parameter);
				expected.setLowerRight(fixture.expected);
			}
			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFaceRectPoints parameter;
			public FaceRect expected;

			Fixture(PBFaceRectPoints parameter, FaceRect expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToImageAnalysisHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFaceImageAnalysis.Builder analysisBuilder =
				PBFaceImageAnalysis.newBuilder();

			analysisBuilder.setImageSize(1.0);
			analysisBuilder.setWidthHeightRatio(2.0);
			analysisBuilder.setEyeDistance(3.0);
			analysisBuilder.setEyeWidth(4.0);
			analysisBuilder.setColorProfile(5.0);
			analysisBuilder.setHeadRotationHorizontal(6.0);
			analysisBuilder.setHeadRotationVertical(7.0);
			analysisBuilder.setHeadPositionHorizontal(8.0);
			analysisBuilder.setHeadPositionVertical(9.0);
			analysisBuilder.setHeadWidth(10.0);
			analysisBuilder.setHeadLength(11.0);
			analysisBuilder.setColorBrightness(12.0);
			analysisBuilder.setColorContrast(13.0);
			analysisBuilder.setColorCast(14.0);
			analysisBuilder.setBlockyArtifacts(15.0);
			analysisBuilder.setImageSharpness(16.0);
			analysisBuilder.setRedEyes(17.0);
			analysisBuilder.setFaceShadow(18.0);
			analysisBuilder.setInterferingBackground(19.0);
			analysisBuilder.setGreyValueBackground(20.0);
			analysisBuilder.setColorVariationBackground(21.0);
			analysisBuilder.setGlassesCoverageSunglasses(22.0);
			analysisBuilder.setGlassesCoverageReflection(23.0);
			analysisBuilder.setGlassesCoverageHeavyFrame(24.0);

			ImageAnalysis expected = new ImageAnalysis();
			FaceAnalysisOutput analysisOutput = null;

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(1.0);
			expected.setImageSize(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(2.0);
			expected.setWidthHeightRatio(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(3.0);
			expected.setEyeDistance(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(4.0);
			expected.setEyeWidth(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(5.0);
			expected.setColorProfile(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(6.0);
			expected.setHeadRotationHorizontal(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(7.0);
			expected.setHeadRotationVertical(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(8.0);
			expected.setHeadPositionHorizontal(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(9.0);
			expected.setHeadPositionVertical(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(10.0);
			expected.setHeadWidth(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(11.0);
			expected.setHeadLength(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(12.0);
			expected.setColorBrightness(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(13.0);
			expected.setColorContrast(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(14.0);
			expected.setColorCast(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(15.0);
			expected.setBlockyArtifacts(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(16.0);
			expected.setImageSharpness(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(17.0);
			expected.setRedEyes(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(18.0);
			expected.setFaceShadow(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(19.0);
			expected.setInterferingBackground(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(20.0);
			expected.setGreyValueBackground(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(21.0);
			expected.setColorVariationBackground(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(22.0);
			expected.setGlassesCoverageSunglasses(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(23.0);
			expected.setGlassesCoverageReflection(analysisOutput);

			analysisOutput = new FaceAnalysisOutput();
			analysisOutput.setValue(24.0);
			expected.setGlassesCoverageHeavyFrame(analysisOutput);

			return new Fixture(analysisBuilder.build(), expected);
		}

		public static class Fixture {
			public PBFaceImageAnalysis parameter;
			public ImageAnalysis expected;

			Fixture(PBFaceImageAnalysis parameter, ImageAnalysis expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}

	}

	public static class ToFaceOutputDetectionHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBExtractFaceDetectionOutput.Builder builder =
				PBExtractFaceDetectionOutput.newBuilder();
			List<PBExtractFaceDetectionOutput> detectionOutputList =
				new ArrayList<PBExtractFaceDetectionOutput>();
			FaceOutputDetection expected = new FaceOutputDetection();

			for (int i = 0; i < 10; i++) {
				FaceOutputPoints faceOutputPoints = new FaceOutputPoints();

				builder.setFaceNumber(i + 1);
				faceOutputPoints.setNum(i + 1);
				{
					builder.setFaceReliability(PBFaceReliability.newBuilder());
					builder.getFaceReliabilityBuilder().setDetectionScore(1.0f);
					builder.getFaceReliabilityBuilder().setPossibilityNegativeDetection(
						true);

					faceOutputPoints.setDetectionScore(1.0f);
					faceOutputPoints.setPossiblityNegativeDetection(true);
				}
				{
					ToFace13PointsHelper.Fixture fixture = ToFace13PointsHelper.build();
					builder.setFace13Points(fixture.parameter);
					faceOutputPoints.setBase(fixture.expected);
				}
				{
					ToFaceRectHelper.Fixture fixture = ToFaceRectHelper.build();
					builder.setFaceRectPoints(ToFaceRectHelper.build().parameter);
					faceOutputPoints.setFaceRect(fixture.expected);
				}
				{
					ToHeadRectHelper.Fixture fixture = ToHeadRectHelper.build();
					builder.setHeadRectPoints(fixture.parameter);
					faceOutputPoints.setHeadRect(fixture.expected);
				}
				{
					ToImageAnalysisHelper.Fixture fixture = ToImageAnalysisHelper.build();
					builder.setImageAnalysis(fixture.parameter);
					faceOutputPoints.setImageAnalysis(fixture.expected);
				}
				detectionOutputList.add(builder.build());
				expected.getPoints().add(faceOutputPoints);
			}

			expected.setDetectedFaces(detectionOutputList.size());

			return new Fixture(detectionOutputList, expected);
		}

		public static class Fixture {
			public List<PBExtractFaceDetectionOutput> parameter;
			public FaceOutputDetection expected;

			Fixture(List<PBExtractFaceDetectionOutput> parameter,
				FaceOutputDetection expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFaceOutputHelper {
		public static Fixture build() {
			PBExtractFaceOutput.Builder builder = PBExtractFaceOutput.newBuilder();
			FaceOutput expected = new FaceOutput();
			ToFaceOutputDetectionHelper.Fixture fixture =
				ToFaceOutputDetectionHelper.build();
			builder.addAllDetectionOutput(fixture.parameter);
			expected.setDetection(fixture.expected);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBExtractFaceOutput parameter;
			public FaceOutput expected;

			Fixture(PBExtractFaceOutput parameter, FaceOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPaextDataHelper {
		public static Fixture build() {
			PBPaExtData.Builder builder = PBPaExtData.newBuilder();
			PaextData expected = new PaextData();
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setMinutia(ByteString.copyFrom(binary));
				expected.setMinutiaData(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setSkeleton(ByteString.copyFrom(binary));
				expected.setSkeleton(binary);
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBPaExtData parameter;
			public PaextData expected;

			Fixture(PBPaExtData parameter, PaextData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper {
		public static Fixture build() {
			List<PBPrefilterData> parameter = new ArrayList<>();
			PrefilterOutput expected = new PrefilterOutput();

			PBPrefilterData.Builder builder = PBPrefilterData.newBuilder();
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LDB);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLdbPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LI);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLiPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LLI);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLliPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_PDB);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setPdbPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_PLDB);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setPldbPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LIP);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLipPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_TLIP);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setTlipPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LLIP);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLlipPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LIM);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLimPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LLIM);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLlimPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LDBM);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLdbmPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LIX);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLixPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LLIX);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLlixPrefilter(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_LDBX);
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());
				expected.setLdbxPrefilter(binary);
			}

			return new Fixture(parameter, expected);
		}

		public static class Fixture {
			public List<PBPrefilterData> parameter;
			public PrefilterOutput expected;

			Fixture(List<PBPrefilterData> parameter, PrefilterOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToMinutiaDataWith_PBMinutiaData_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBMinutiaData.Builder builder = PBMinutiaData.newBuilder();
			MinutiaData expected = new MinutiaData();

			byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
			builder.setData(ByteString.copyFrom(binary));
			expected.setBinary(binary);

			builder.setMinutiaType(MinutiaType.MINUTIA_PC2);
			expected.setMinutiaType("PC2");

			builder.setFisType(FisTypeType.FIS_TYPE_B);
			expected.setFisType("TYPE_B");

			builder.setMinutiaCount(10);
			expected.setMinutiaCount(10);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBMinutiaData parameter;
			public MinutiaData expected;

			Fixture(PBMinutiaData parameter, MinutiaData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPalmOutputHelper {

		public static Fixture buildForLatent() {
			PBExtractLatentPalmOutput.Builder builder =
				PBExtractLatentPalmOutput.newBuilder();
			PalmOutput expected = new PalmOutput();

			{
				ToMinutiaDataWith_PBMinutiaData_Helper.Fixture fixtrue =
					ToMinutiaDataWith_PBMinutiaData_Helper.build();
				builder.setMinutiaData(fixtrue.parameter);
				expected.setMinutiaData(fixtrue.expected);
			}
			{
				ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper.Fixture fixtrue =
					ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper
						.build();
				builder.addAllPrefilterData(fixtrue.parameter);
				expected.setPrefilterOutput(fixtrue.expected);
			}
			{
				ToPaextDataHelper.Fixture fixtrue = ToPaextDataHelper.build();
				builder.setPaExtData(fixtrue.parameter);
				expected.setPaextData(fixtrue.expected);
			}

			return new Fixture(builder.build(), expected);
		}

		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBExtractPalmOutput.Builder builder = PBExtractPalmOutput.newBuilder();
			PalmOutput expected = new PalmOutput();
			{
				ToMinutiaDataWith_PBMinutiaData_Helper.Fixture fixture =
					ToMinutiaDataWith_PBMinutiaData_Helper.build();
				builder.setMinutiaData(fixture.parameter);
				expected.setMinutiaData(fixture.expected);
			}
			{
				ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper.Fixture fixture =
					ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper
						.build();
				builder.addAllPrefilterData(fixture.parameter);
				expected.setPrefilterOutput(fixture.expected);
			}
			{
				ToPaextDataHelper.Fixture fixture = ToPaextDataHelper.build();
				builder.setPaExtData(fixture.parameter);
				expected.setPaextData(fixture.expected);
			}

			SetImageDataWith_PBImageData_PalmOutput_Helper.Fixture fixture =
				SetImageDataWith_PBImageData_PalmOutput_Helper.build();
			builder.setImageData(fixture.parameter);
			expected.setLowResImage(fixture.expected.getLowResImage());

			builder.setPosition(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
			expected.setPos(1);

			List<PBExtractPalmOutput> parameterList = new ArrayList<>();
			List<PalmOutput> expectedList = new ArrayList<>();
			parameterList.add(builder.build());
			expectedList.add(expected);
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public PBExtractLatentPalmOutput parameter;
			public PalmOutput expected;
			public List<PBExtractPalmOutput> parameterList;
			public List<PalmOutput> expectedList;

			Fixture(PBExtractLatentPalmOutput parameter, PalmOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}

			Fixture(List<PBExtractPalmOutput> parameter, List<PalmOutput> expected) {
				this.parameterList = parameter;
				this.expectedList = expected;
			}
		}
	}

	public static class ToFisPatternTypeHelper {
		public static Fixture build() {
			PBFisPatternType.Builder builder = PBFisPatternType.newBuilder();
			FisData.FisPatternType expected = new FisData.FisPatternType();

			builder.setTYPE1("W");
			expected.setTYPE1("W");

			builder.setRFU1("10");
			expected.setRFU1("10");

			builder.setTYPE2("R");
			expected.setTYPE2("R");

			builder.setRFU2("20");
			expected.setRFU2("20");

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFisPatternType parameter;
			public FisData.FisPatternType expected;

			Fixture(PBFisPatternType parameter, FisData.FisPatternType expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFisMinutiaNoHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFisMinutiaNo.Builder builder = PBFisMinutiaNo.newBuilder();
			FisData.FisMinutiaNo expected = new FisData.FisMinutiaNo();

			builder.setDB(10);
			expected.setDB(10);

			builder.setMB(20);
			expected.setMB(20);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFisMinutiaNo parameter;
			public FisData.FisMinutiaNo expected;

			Fixture(PBFisMinutiaNo parameter, FisData.FisMinutiaNo expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFisQualityHelper {
		public static Fixture build() {
			PBFisQuality.Builder builder = PBFisQuality.newBuilder();
			FisData.FisQuality expected = new FisData.FisQuality();

			builder.setVA("10");
			expected.setVA("10");

			builder.setVB("20");
			expected.setVB("20");

			builder.setVC("30");
			expected.setVC("30");

			builder.setS("40");
			expected.setS("40");

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFisQuality parameter;
			public FisData.FisQuality expected;

			Fixture(PBFisQuality parameter, FisData.FisQuality expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFisCoreHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFisCore.Builder builder = PBFisCore.newBuilder();
			FisData.FisCore expected = new FisData.FisCore();

			builder.setA("1");
			expected.setA("1");

			builder.setF("2");
			expected.setF("2");

			builder.setCC("3");
			expected.setCC("3");

			builder.setQP("4");
			expected.setQP("4");

			builder.setQD("5");
			expected.setQD("5");

			builder.setQQ("6");
			expected.setQQ("6");

			builder.setX(7);
			expected.setX(7);

			builder.setY(8);
			expected.setY(8);

			builder.setD(9);
			expected.setD(9);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFisCore parameter;
			public FisData.FisCore expected;

			Fixture(PBFisCore parameter, FisData.FisCore expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFisDataHelper {
		public static ToFisDataHelper.Fixture build() {
			List<PBFisData> parameter = new ArrayList<>();
			List<FisData> expected = new ArrayList<>();

			for (int i = 0; i < 2; i++) {
				PBFisData.Builder builder = PBFisData.newBuilder();
				FisData fisData = new FisData();
				{
					ToFisCoreHelper.Fixture fixture = ToFisCoreHelper.build();
					builder.setFisCore(fixture.parameter);
					fisData.setFisCore(fixture.expected);
				}
				{
					ToFisQualityHelper.Fixture fixture = ToFisQualityHelper.build();
					builder.setFisQuality(fixture.parameter);
					fisData.setFisQuality(fixture.expected);
				}
				{
					ToFisMinutiaNoHelper.Fixture fixture = ToFisMinutiaNoHelper.build();
					builder.setFisMinutiaNo(fixture.parameter);
					fisData.setFisMinutiaNo(fixture.expected);
				}
				{
					ToFisPatternTypeHelper.Fixture fixture =
						ToFisPatternTypeHelper.build();
					builder.setFisPatternType(fixture.parameter);
					fisData.setFisPatternType(fixture.expected);
				}

				{
					byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
					builder.setMinutia(ByteString.copyFrom(binary));
					fisData.setMinutiaData(binary);
				}
				{
					byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
					builder.setZone(ByteString.copyFrom(binary));
					fisData.setZone(binary);
				}
				{
					byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
					builder.setSkeleton(ByteString.copyFrom(binary));
					fisData.setSkeleton(binary);
				}

				builder.setFisType(FisTypeType.FIS_TYPE_A);
				fisData.setFisType("TYPE_A");

				{
					ToFusionIndexeHelper.Fixture fixture = ToFusionIndexeHelper.build();
					builder.addAllFusionIndexer(fixture.parameter);
					fisData.getFusionIndexer().addAll(fixture.expected);
				}

				parameter.add(builder.build());
				expected.add(fisData);
			}

			return new Fixture(parameter, expected);
		}

		public static class Fixture {
			public List<PBFisData> parameter;
			public List<FisData> expected;

			Fixture(List<PBFisData> parameter, List<FisData> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFingerOutputWith_PBExtractLatentFingerOutput_Helper {
		public static Fixture build() {
			PBExtractLatentFingerOutput.Builder builder =
				PBExtractLatentFingerOutput.newBuilder();
			FingerOutput expected = new FingerOutput();

			{
				ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaDatas_Helper.Fixture fixture =
					ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaDatas_Helper
						.build();
				// ToMinutiaDataWith_PBMinutiaData_Helper.Fixture fixture =
				// ToMinutiaDataWith_PBMinutiaData_Helper.build();
				builder.addAllMinutiaData(fixture.parameter);
				expected.getMinutiaData().addAll(fixture.expected);
			}
			{
				ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper.Fixture fixture =
					ToPrefilterOutputWith_ListOfPBPrefilterDatas_PrefilterOutput_Helper
						.build();
				builder.addAllPrefilterData(fixture.parameter);
				expected.setPrefilterOutput(fixture.expected);
			}
			{
				ToFisDataHelper.Fixture fixture = ToFisDataHelper.build();
				builder.addAllFisData(fixture.parameter);
				expected.getFisData().addAll(fixture.expected);
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBExtractLatentFingerOutput parameter;
			public FingerOutput expected;

			Fixture(PBExtractLatentFingerOutput parameter, FingerOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToLatentOutputHelper {
		public static Fixture build(String type) {
			PBExtractLatentOutput.Builder builder = PBExtractLatentOutput.newBuilder();
			LatentOutput expected = new LatentOutput();
			if (type.equals("finger") || type.equals("all")) {
				{
					ToFingerOutputWith_PBExtractLatentFingerOutput_Helper.Fixture fixture =
						ToFingerOutputWith_PBExtractLatentFingerOutput_Helper.build();
					builder.setFingerOutput(fixture.parameter);
					expected.setFingerOutput(fixture.expected);
				}
			}
			if (type.equals("palm") || type.equals("all")) {
				{
					ToPalmOutputHelper.Fixture fixture =
						ToPalmOutputHelper.buildForLatent();
					builder.setPalmOutput(fixture.parameter);
					expected.setPalmOutput(fixture.expected);
				}
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBExtractLatentOutput parameter;
			public LatentOutput expected;

			Fixture(PBExtractLatentOutput parameter, LatentOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class SetImageDataWith_PBImageData_FingerOutput_Helper {
		public static Fixture build() {
			PBImageData.Builder builder = PBImageData.newBuilder();
			FingerOutput expected = new FingerOutput();

			builder.setFormat(ImageFormatType.BMP);
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setCroppedImage(ByteString.copyFrom(binary));
				expected.setCroppedImage(binary);
			}
			{
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setLowResolutionImage(ByteString.copyFrom(binary));
				expected.setLowResImage(binary);
			}
			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBImageData parameter;
			public FingerOutput expected;

			Fixture(PBImageData parameter, FingerOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class SetImageDataWith_PBImageData_PalmOutput_Helper {
		public static Fixture build() {
			PBImageData.Builder builder = PBImageData.newBuilder();
			PalmOutput expected = new PalmOutput();

			byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
			builder.setFormat(ImageFormatType.BMP);
			builder.setLowResolutionImage(ByteString.copyFrom(binary));
			expected.setLowResImage(binary);
			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBImageData parameter;
			public PalmOutput expected;

			Fixture(PBImageData parameter, PalmOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPrefilterOutputWith_ListOfPBPrefilterDataTenprintFingers_Helper {
		public static Fixture build() {
			List<PBPrefilterDataTenprintFinger> parameter = new ArrayList<>();
			PrefilterOutput expected = new PrefilterOutput();

			PBPrefilterDataTenprintFinger.Builder builder =
				PBPrefilterDataTenprintFinger.newBuilder();
			{
				PrefilterOutput.RdblPrefilter rdblExpected =
					new PrefilterOutput.RdblPrefilter();
				byte[] rolledBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_RDBL);
				builder.setRolled(ByteString.copyFrom(rolledBinary));
				rdblExpected.setRollPrefilter(rolledBinary);

				byte[] slapBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setSlap(ByteString.copyFrom(slapBinary));
				rdblExpected.setSlapPrefilter(slapBinary);

				parameter.add(builder.build());
				expected.setRdblPrefilter(rdblExpected);
			}
			{
				PrefilterOutput.TliPrefilter tliExpected =
					new PrefilterOutput.TliPrefilter();
				byte[] rolledBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_TLI);
				builder.setRolled(ByteString.copyFrom(rolledBinary));
				tliExpected.setRollPrefilter(rolledBinary);

				byte[] slapBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setSlap(ByteString.copyFrom(slapBinary));
				tliExpected.setSlapPrefilter(slapBinary);

				parameter.add(builder.build());
				expected.setTliPrefilter(tliExpected);
			}
			{
				PrefilterOutput.RdblmPrefilter rdblmExpected =
					new PrefilterOutput.RdblmPrefilter();
				byte[] rolledBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_RDBLM);
				builder.setRolled(ByteString.copyFrom(rolledBinary));
				rdblmExpected.setRollPrefilter(rolledBinary);

				byte[] slapBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setSlap(ByteString.copyFrom(slapBinary));
				rdblmExpected.setSlapPrefilter(slapBinary);

				parameter.add(builder.build());
				expected.setRdblmPrefilter(rdblmExpected);
			}
			{
				PrefilterOutput.TlimPrefilter tliExpected =
					new PrefilterOutput.TlimPrefilter();
				byte[] rolledBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_TLIM);
				builder.setRolled(ByteString.copyFrom(rolledBinary));
				tliExpected.setRollPrefilter(rolledBinary);

				byte[] slapBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setSlap(ByteString.copyFrom(slapBinary));
				tliExpected.setSlapPrefilter(slapBinary);

				parameter.add(builder.build());
				expected.setTlimPrefilter(tliExpected);
			}
			{
				PrefilterOutput.TlixPrefilter tliExpected =
					new PrefilterOutput.TlixPrefilter();
				byte[] rolledBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_TLIX);
				builder.setRolled(ByteString.copyFrom(rolledBinary));
				tliExpected.setRollPrefilter(rolledBinary);

				byte[] slapBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setSlap(ByteString.copyFrom(slapBinary));
				tliExpected.setSlapPrefilter(slapBinary);

				parameter.add(builder.build());
				expected.setTlixPrefilter(tliExpected);
			}
			{
				PrefilterOutput.XdblPrefilter xdblExpected =
					new PrefilterOutput.XdblPrefilter();
				byte[] rolledBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setTemplateFormat(TemplateFormatType.TEMPLATE_RDBLX);
				builder.setRolled(ByteString.copyFrom(rolledBinary));
				xdblExpected.setRollPrefilter(rolledBinary);

				byte[] slapBinary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setSlap(ByteString.copyFrom(slapBinary));
				xdblExpected.setSlapPrefilter(slapBinary);

				parameter.add(builder.build());
				expected.setXdblPrefilter(xdblExpected);
			}

			return new Fixture(parameter, expected);
		}

		public static class Fixture {
			public List<PBPrefilterDataTenprintFinger> parameter;
			public PrefilterOutput expected;

			Fixture(List<PBPrefilterDataTenprintFinger> parameter,
				PrefilterOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaDatas_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			List<PBMinutiaData> parameter = new ArrayList<>();
			List<MinutiaData> expectedList = new ArrayList<>();

			{
				ToMinutiaDataWith_PBMinutiaData_Helper.Fixture fixture =
					ToMinutiaDataWith_PBMinutiaData_Helper.build();
				PBMinutiaData.Builder builder = fixture.parameter.toBuilder();

				PBFusionIndexer.Builder indexerBuilder = PBFusionIndexer.newBuilder();
				indexerBuilder.setFormat(TemplateFormatType.TEMPLATE_LLIX);
				indexerBuilder.addFusionId(0).addFusionId(1).addFusionId(3);
				builder.addFusionIndexer(indexerBuilder.build());
				parameter.add(builder.build());

				fixture.expected.setDbType("LDBX");
				fixture.expected.setFormat("LLIX");
				fixture.expected.setMultiFeIndex("0,1,3");
				expectedList.add(fixture.expected);
			}
			{
				// RDBL
				PBMinutiaData.Builder builder = PBMinutiaData.newBuilder();
				builder.setMinutiaType(MinutiaType.MINUTIA_FMP5);

				PBFusionIndexer.Builder indexerBuilder = PBFusionIndexer.newBuilder();
				indexerBuilder.setFormat(TemplateFormatType.TEMPLATE_RDBL);
				indexerBuilder.addFusionId(0);
				builder.addFusionIndexer(indexerBuilder.build());

				builder.setFisType(FisTypeType.FIS_TYPE_B);
				builder.setMinutiaCount(1);
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());

				MinutiaData expected = new MinutiaData();
				expected.setBinary(binary);
				expected.setMinutiaType("FMP5");
				expected.setDbType("RDBL");
				expected.setFisType("TYPE_B");
				expected.setFusionId(0);
				expected.setMinutiaCount(1);
				expected.setFormat("RDBL");
				expectedList.add(expected);
			}
			{
				// RDBTM
				PBMinutiaData.Builder builder = PBMinutiaData.newBuilder();
				builder.setMinutiaType(MinutiaType.MINUTIA_PC2);

				PBFusionIndexer.Builder indexerBuilder = PBFusionIndexer.newBuilder();
				indexerBuilder.setFormat(TemplateFormatType.TEMPLATE_TIM);
				indexerBuilder.addFusionId(0);
				builder.addFusionIndexer(indexerBuilder.build());

				builder.setFisType(FisTypeType.FIS_TYPE_CMLaF);
				builder.setMinutiaCount(2);
				byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
				builder.setData(ByteString.copyFrom(binary));
				parameter.add(builder.build());

				MinutiaData expected = new MinutiaData();
				expected.setBinary(binary);
				expected.setMinutiaType("PC2");
				expected.setDbType("RDBTM");
				expected.setFisType("TYPE_CMLaF");
				expected.setFusionId(0);
				expected.setMinutiaCount(2);
				expected.setFormat("TIM");
				expectedList.add(expected);
			}

			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBMinutiaData> parameter;
			public List<MinutiaData> expected;

			Fixture(List<PBMinutiaData> parameter, List<MinutiaData> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToCropInfoHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFingerCropCoordinate.Builder builder = PBFingerCropCoordinate.newBuilder();
			CropInfo expected = new CropInfo();

			PBCropPoint.Builder cropBuilder = PBCropPoint.newBuilder();
			{
				ToPointHelper.Fixture fixture = ToPointHelper.build(1, 2);
				cropBuilder.setCenter(fixture.parameter);
				PointCenter center = new PointCenter();
				center.setX(fixture.expected.getX());
				center.setY(fixture.expected.getY());
				expected.setCenter(center);

				cropBuilder.setAngle(3.0f);
				center.setAngle(3.0f);
			}
			{
				ToPointHelper.Fixture fixture = ToPointHelper.build(3, 4);
				cropBuilder.addPoints(fixture.parameter);
				CropInfo.CropPoints points = new CropInfo.CropPoints();
				points.getPoints().add(fixture.expected);
				expected.setCropPoints(points);
			}
			builder.setCropPoints(cropBuilder);
			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFingerCropCoordinate parameter;
			public CropInfo expected;

			Fixture(PBFingerCropCoordinate parameter, CropInfo expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPointHelper {
		@SuppressWarnings("boxing")
		public static Fixture build(int x, int y) {
			PBPoint.Builder builder = PBPoint.newBuilder();
			builder.setX(x);
			builder.setY(y);

			Point expected = new Point();
			expected.setX(x);
			expected.setY(y);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBPoint parameter;
			public Point expected;

			Fixture(PBPoint parameter, Point expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFingerOutputWith_ListOfBExtractTenprintFingerOutputs_ListOfFingerOutputs_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBExtractTenprintFingerOutput.Builder builder =
				PBExtractTenprintFingerOutput.newBuilder();
			FingerOutput output = new FingerOutput();

			{
				ToCropInfoHelper.Fixture fixture = ToCropInfoHelper.build();
				builder.setCropInfo(fixture.parameter);
				output.setCropInfo(fixture.expected);
			}
			{
				ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaDatas_Helper.Fixture fixture =
					ToMinutiaDataWith_ListOfPBMinutiaDatas_ListOfMinutiaDatas_Helper
						.build();

				// ToMinutiaDataWith_PBMinutiaData_Helper.Fixture fixture =
				// ToMinutiaDataWith_PBMinutiaData_Helper.build();
				builder.addAllMinutiaData(fixture.parameter);
				output.getMinutiaData().addAll(fixture.expected);
			}
			{
				ToPrefilterOutputWith_ListOfPBPrefilterDataTenprintFingers_Helper.Fixture fixture =
					ToPrefilterOutputWith_ListOfPBPrefilterDataTenprintFingers_Helper
						.build();
				builder.addAllPrefilterData(fixture.parameter);
				output.setPrefilterOutput(fixture.expected);
			}
			{
				ToFisDataHelper.Fixture fixture = ToFisDataHelper.build();
				builder.addAllFisData(fixture.parameter);
				output.getFisData().addAll(fixture.expected);
			}
			{
				SetImageDataWith_PBImageData_FingerOutput_Helper.Fixture fixture =
					SetImageDataWith_PBImageData_FingerOutput_Helper.build();
				builder.setImageData(fixture.parameter);
				output.setCroppedImage(fixture.expected.getCroppedImage());

				output.setLowResImage(fixture.expected.getLowResImage());
			}

			builder.setPosition(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
			output.setPos(1);

			PBFingerQualities.Builder qualitiBuilder = PBFingerQualities.newBuilder();
			qualitiBuilder.setIql(10);
			output.setQuality(10);
			qualitiBuilder.setNfiq(20);
			output.setNfiqQuality(20);
			builder.setQualityInfo(qualitiBuilder);

			builder.setAngle(4.0f);
			output.setAngle(4.0f);

			builder.setConfidence(100);
			output.setFingerConfidence(100);

			PBFingerPatterns.Builder patternBuilder = PBFingerPatterns.newBuilder();
			patternBuilder.setPrimary(FingerPatternType.FINGER_PATTERN_ARCH);
			patternBuilder.setReference(FingerPatternType.FINGER_PATTERN_WHORL);
			builder.setPattern(patternBuilder);
			output.setPatternPrimary("A");
			output.setPatternReference("W");

			List<PBExtractTenprintFingerOutput> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<FingerOutput> expected = new ArrayList<>();
			expected.add(output);
			return new Fixture(parameter, expected);
		}

		public static class Fixture {
			public List<PBExtractTenprintFingerOutput> parameter;
			public List<FingerOutput> expected;

			Fixture(List<PBExtractTenprintFingerOutput> parameter,
				List<FingerOutput> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToQrDataWith_PBFingerQrDataOutput_Helper {
		public static Fixture build() {
			PBFingerQrDataOutput.Builder builder = PBFingerQrDataOutput.newBuilder();

			PBFingerQrData.Builder qrBuilder = PBFingerQrData.newBuilder();
			QrOutput expected = new QrOutput();
			{
				QrOutput.QrS qrs = new QrOutput.QrS();
				{
					byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
					qrBuilder.setRolled(ByteString.copyFrom(binary));
					QrData qrData = new QrData();
					qrData.setValue(binary);
					qrs.setRollQr(qrData);
				}
				{
					byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
					qrBuilder.setSlap(ByteString.copyFrom(binary));
					QrData qrData = new QrData();
					qrData.setValue(binary);
					qrs.setSlapQr(qrData);
				}
				builder.setQrS(qrBuilder).build();
				expected.setQrS(qrs);
			}
			{
				QrOutput.QrF qrf = new QrOutput.QrF();
				{
					byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
					qrBuilder.setRolled(ByteString.copyFrom(binary));
					QrData qrData = new QrData();
					qrData.setValue(binary);
					qrf.setRollQr(qrData);
				}
				{
					byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
					qrBuilder.setSlap(ByteString.copyFrom(binary));
					QrData qrData = new QrData();
					qrData.setValue(binary);
					qrf.setSlapQr(qrData);
				}
				builder.setQrF(qrBuilder).build();
				expected.setQrF(qrf);
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFingerQrDataOutput parameter;
			public QrOutput expected;

			Fixture(PBFingerQrDataOutput parameter, QrOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPsrDataHelper {
		@SuppressWarnings("boxing")
		public static Fixture build(
			int fudionId,
			PsrType typeProtol,
			jp.co.nec.aim.mm.jaxb.PsrType typeJaxb) {
			PBFingerPsrData.Builder builder = PBFingerPsrData.newBuilder();
			PsrData expected = new PsrData();

			builder.setFusionId(fudionId);
			expected.setFusionId(fudionId);

			builder.setType(typeProtol);
			expected.setType(typeJaxb);

			byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
			builder.setData(ByteString.copyFrom(binary));
			expected.setValue(binary);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFingerPsrData parameter;
			public PsrData expected;

			Fixture(PBFingerPsrData parameter, PsrData expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToPsrOutputHelper {
		public static Fixture build() {
			PBFingerPrelsectionDataOutput.Builder builder =
				PBFingerPrelsectionDataOutput.newBuilder();
			PsrOutput expected = new PsrOutput();

			{
				ToPsrDataHelper.Fixture fixture =
					ToPsrDataHelper.build(1, PsrType.PSR_AC,
						jp.co.nec.aim.mm.jaxb.PsrType.AC);
				builder.addRolled10(fixture.parameter);
				expected.getRolled10Psr().add(fixture.expected);
			}
			{
				ToPsrDataHelper.Fixture fixture =
					ToPsrDataHelper.build(2, PsrType.PSR_CMLaF,
						jp.co.nec.aim.mm.jaxb.PsrType.CM_LA_F);
				builder.addSlap(fixture.parameter);
				expected.getSlapPsr().add(fixture.expected);
			}
			{
				ToPsrDataHelper.Fixture fixture =
					ToPsrDataHelper.build(3, PsrType.PSR_CMLaF,
						jp.co.nec.aim.mm.jaxb.PsrType.CM_LA_F);
				builder.addRolled8(fixture.parameter);
				expected.setRolled8Psr(fixture.expected);
			}
			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFingerPrelsectionDataOutput parameter;
			public PsrOutput expected;

			Fixture(PBFingerPrelsectionDataOutput parameter, PsrOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToQcOutputWith_PBFingerQualityCheckOutputStandard_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFingerQualityCheckOutputStandard.Builder builder =
				PBFingerQualityCheckOutputStandard.newBuilder();
			QcOutput expected = new QcOutput();

			{
				ToQcStatusHelper.Fixture fixture =
					ToQcStatusHelper.build(FingerPositionType.ROLLED_RIGHT_THUMB, 1, 2);
				builder.addAllRolledStatus(fixture.parameter);
				expected.getRollStatus().addAll(fixture.expected);
			}
			{
				ToQcStatusHelper.Fixture fixture =
					ToQcStatusHelper.build(FingerPositionType.SLAP_RIGHT_THUMB, 6, 3);
				builder.addAllSlapStatus(fixture.parameter);
				expected.getSlapStatus().addAll(fixture.expected);
			}

			builder.setTotalStatus(4);
			expected.setTotal(4);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFingerQualityCheckOutputStandard parameter;
			public QcOutput expected;

			Fixture(PBFingerQualityCheckOutputStandard parameter, QcOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToQcStatusHelper {
		@SuppressWarnings("boxing")
		public static Fixture build(FingerPositionType type, int pos, int status) {
			PBQualityCheckOutputStandardStatus.Builder builder =
				PBQualityCheckOutputStandardStatus.newBuilder();
			QcStatus expected = new QcStatus();

			builder.setPosition(type);
			Finger finger = new Finger();
			finger.setPos(pos);

			builder.setStatus(status);
			finger.setStatus(status);

			expected.setFinger(finger);

			List<PBQualityCheckOutputStandardStatus> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<QcStatus> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBQualityCheckOutputStandardStatus> parameter;
			public List<QcStatus> expected;

			Fixture(List<PBQualityCheckOutputStandardStatus> parameter,
				List<QcStatus> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToQcSequenceHelper {
		public static Fixture fixtures[] = {
			build("rolled and slap"), build("only rolled"), build("only slap"),
		};

		public static Fixture build(String mode) {
			PBQualityCheckOutputAdvancedSequence.Builder builder =
				PBQualityCheckOutputAdvancedSequence.newBuilder();
			QcSequence expected = new QcSequence();

			if (mode.equals("rolled and slap")) {
				builder.addRolledStatus(FingerPositionType.ROLLED_RIGHT_THUMB);
				builder.addRolledStatus(FingerPositionType.FINGER_AMPUTATED);
				builder.addRolledStatus(FingerPositionType.ROLLED_LEFT_LITTLE);
				expected.setRolledFingers("1:*:10");

				builder.addSlapStatus(FingerPositionType.SLAP_RIGHT_THUMB);
				builder.addSlapStatus(FingerPositionType.FINGER_UNKNOWN);
				builder.addSlapStatus(FingerPositionType.SLAP_LEFT_LITTLE);
				expected.setSlapFingers("11:?:20");
			} else if (mode.equals("only rolled")) {
				builder.addRolledStatus(FingerPositionType.ROLLED_RIGHT_THUMB);
				builder.addRolledStatus(FingerPositionType.FINGER_AMPUTATED);
				builder.addRolledStatus(FingerPositionType.ROLLED_LEFT_LITTLE);
				expected.setRolledFingers("1:*:10");
			} else if (mode.equals("only slap")) {
				builder.addSlapStatus(FingerPositionType.SLAP_RIGHT_THUMB);
				builder.addSlapStatus(FingerPositionType.FINGER_UNKNOWN);
				builder.addSlapStatus(FingerPositionType.SLAP_LEFT_LITTLE);
				expected.setSlapFingers("11:?:20");
			}
			return new Fixture(builder.build(), expected, mode);
		}

		public static class Fixture {
			public PBQualityCheckOutputAdvancedSequence parameter;
			public QcSequence expected;
			public String mode;

			Fixture(PBQualityCheckOutputAdvancedSequence parameter, QcSequence expected,
				String mode) {
				this.parameter = parameter;
				this.expected = expected;
				this.mode = mode;
			}
		}
	}

	public static class ToHistoryHelper {
		public static Fixture build() {
			PBQualityCheckOutputAdvancedHistory.Builder builder =
				PBQualityCheckOutputAdvancedHistory.newBuilder();
			QcOutput.History expected = new QcOutput.History();
			QcHistory history = new QcHistory();

			builder
				.setActivity(QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_ROLLED_DUPLICATE);
			history.setActivity(QcActivity.ROLLED_DUPLICATE);

			builder.setStatus(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NG);
			history.setStatus(QcDetailStatus.QC_STATE_NG);

			builder.setData("TEST");
			history.setData("TEST");

			expected.getItem().add(history);

			List<PBQualityCheckOutputAdvancedHistory> parameter = new ArrayList<>();
			parameter.add(builder.build());
			return new Fixture(parameter, expected);
		}

		public static class Fixture {
			public List<PBQualityCheckOutputAdvancedHistory> parameter;
			public QcOutput.History expected;

			Fixture(List<PBQualityCheckOutputAdvancedHistory> parameter,
				QcOutput.History expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToQcOutputWith_PBFingerQualityCheckOutputAdvanced_Helper {
		public static Fixture build() {
			PBFingerQualityCheckOutputAdvanced.Builder builder =
				PBFingerQualityCheckOutputAdvanced.newBuilder();
			QcOutput expected = new QcOutput();

			{
				ToQcSequenceHelper.Fixture fixture =
					ToQcSequenceHelper.build("rolled and slap");
				builder.setSequence(fixture.parameter);
				expected.setSequence(fixture.expected);
			}
			{
				ToHistoryHelper.Fixture fixture = ToHistoryHelper.build();
				builder.addAllHistories(fixture.parameter);
				expected.setHistory(fixture.expected);
			}
			builder
				.setTotalStatus(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_UNKNOWN);
			expected.setStatus(QcDetailStatus.QC_STATE_UNKNOWN);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFingerQualityCheckOutputAdvanced parameter;
			public QcOutput expected;

			Fixture(PBFingerQualityCheckOutputAdvanced parameter, QcOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToQcOutputWith_PBFingerQualityCheckOutput_Helper {
		public static Fixture build(String mode) {
			PBFingerQualityCheckOutput.Builder builder =
				PBFingerQualityCheckOutput.newBuilder();
			QcOutput expected = null;

			if (mode.equals("standard")) {
				ToQcOutputWith_PBFingerQualityCheckOutputStandard_Helper.Fixture fixtrue =
					ToQcOutputWith_PBFingerQualityCheckOutputStandard_Helper.build();
				builder.setStandard(fixtrue.parameter);
				expected = fixtrue.expected;
			} else if (mode.equals("advanced")) {
				ToQcOutputWith_PBFingerQualityCheckOutputAdvanced_Helper.Fixture fixtrue =
					ToQcOutputWith_PBFingerQualityCheckOutputAdvanced_Helper.build();
				builder.setAdvanced(fixtrue.parameter);
				expected = fixtrue.expected;
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFingerQualityCheckOutput parameter;
			public QcOutput expected;

			Fixture(PBFingerQualityCheckOutput parameter, QcOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToTenprintOutputHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBExtractTenprintOutput.Builder builder =
				PBExtractTenprintOutput.newBuilder();
			TenprintOutput expected = new TenprintOutput();

			{
				ToQcOutputWith_PBFingerQualityCheckOutput_Helper.Fixture fixture =
					ToQcOutputWith_PBFingerQualityCheckOutput_Helper.build("advanced");
				builder.setQcOutput(fixture.parameter);
				expected.setQcOutput(fixture.expected);
			}
			{
				ToPsrOutputHelper.Fixture fixture = ToPsrOutputHelper.build();
				builder.setPsrData(fixture.parameter);
				expected.setPsrOutput(fixture.expected);
			}
			{
				ToQrDataWith_PBFingerQrDataOutput_Helper.Fixture fixture =
					ToQrDataWith_PBFingerQrDataOutput_Helper.build();
				builder.setQrData(fixture.parameter);
				expected.setQrOutput(fixture.expected);
			}
			{
				ToFingerOutputWith_ListOfBExtractTenprintFingerOutputs_ListOfFingerOutputs_Helper.Fixture fixture =
					ToFingerOutputWith_ListOfBExtractTenprintFingerOutputs_ListOfFingerOutputs_Helper
						.build();
				builder.addAllFingerOutput(fixture.parameter);
				expected.getFingerOutput().addAll(fixture.expected);
			}
			{
				ToPalmOutputHelper.Fixture fixture = ToPalmOutputHelper.build();
				builder.addAllPalmOutput(fixture.parameterList);
				expected.getPalmOutput().addAll(fixture.expectedList);
			}

			PBTenprintFingerQualitySummary.Builder qualityBuilder =
				PBTenprintFingerQualitySummary.newBuilder();
			qualityBuilder.setRolled(1);
			expected.setQualityRolled(1);
			qualityBuilder.setSlap(2);
			expected.setQualitySlap(2);
			builder.setFingerQualitySummary(qualityBuilder);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBExtractTenprintOutput parameter;
			public TenprintOutput expected;

			Fixture(PBExtractTenprintOutput parameter, TenprintOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToExtOutputHelper {
		public static Fixture build(String type) {
			PBExtractOutputPayload.Builder builder = PBExtractOutputPayload.newBuilder();
			ExtOutput expected = new ExtOutput();

			if (type.equals("tenprint")) {
				ToTenprintOutputHelper.Fixture fixture = ToTenprintOutputHelper.build();
				builder.setTenprintOutput(fixture.parameter);
				expected.setTenprintOutput(fixture.expected);
			} else if (type.equals("latent")) {
				ToLatentOutputHelper.Fixture fixture = ToLatentOutputHelper.build("all");
				builder.setLatentOutput(fixture.parameter);
				expected.setLatentOutput(fixture.expected);
			} else if (type.equals("face")) {
				ToFaceOutputHelper.Fixture fixture = ToFaceOutputHelper.build();
				builder.setFaceOutput(fixture.parameter);
				expected.setFaceOutput(fixture.expected);
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBExtractOutputPayload parameter;
			public ExtOutput expected;

			Fixture(PBExtractOutputPayload parameter, ExtOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToJobStausHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBJobStatusResponse.Builder builder = PBJobStatusResponse.newBuilder();
			JobStatus expected = new JobStatus();

			PBServiceState.Builder stateBuilder = PBServiceState.newBuilder();
			stateBuilder.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
			builder.setServiceState(stateBuilder);

			builder.setJobId(1);
			expected.setJobId(1);

			builder.setJobState(JobStateType.JOB_STATE_DONE);
			expected.setState(JobStateEnum.DONE);

			builder.setJobFailed(true);
			expected.setFailed(true);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBJobStatusResponse parameter;
			public JobStatus expected;

			Fixture(PBJobStatusResponse parameter, JobStatus expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToContainerResultHelper {
		public static Fixture build() {
			PBCheckExternalIdResultDetail.Builder builder =
				PBCheckExternalIdResultDetail.newBuilder();
			ContainerResult expected = new ContainerResult();

			builder.setContainerId(1);
			expected.setContainerId(1);

			builder.setNumOfValid(2);
			expected.setNumOfValid(2);

			builder.setNumOfCorrupted(3);
			expected.setNumOfCorrupted(3);

			List<PBCheckExternalIdResultDetail> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<ContainerResult> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBCheckExternalIdResultDetail> parameter;
			public List<ContainerResult> expected;

			Fixture(List<PBCheckExternalIdResultDetail> parameter,
				List<ContainerResult> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToCheckResultHelper {
		public static Fixture build() {
			PBCheckExternalIdResult.Builder builder =
				PBCheckExternalIdResult.newBuilder();
			CheckResult expected = new CheckResult();

			builder.setEventId(1);
			expected.setEventId(1);

			{
				ToContainerResultHelper.Fixture fixture = ToContainerResultHelper.build();
				builder.addAllContainerResult(fixture.parameter);
				expected.getContainerResult().addAll(fixture.expected);
			}

			List<PBCheckExternalIdResult> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<CheckResult> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBCheckExternalIdResult> parameter;
			public List<CheckResult> expected;

			Fixture(List<PBCheckExternalIdResult> parameter, List<CheckResult> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToCheckResultsHelper {
		public static Fixture build() {
			PBCheckExternalIdResponse.Builder builder =
				PBCheckExternalIdResponse.newBuilder();
			CheckResults expected = new CheckResults();

			PBServiceState.Builder stateBuilder = PBServiceState.newBuilder();
			stateBuilder.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
			builder.setServiceState(stateBuilder);

			ToCheckResultHelper.Fixture fixture = ToCheckResultHelper.build();
			builder.addAllCheckResult(fixture.parameter);
			expected.getCheckResult().addAll(fixture.expected);

			builder.setExternalId("test");
			expected.setExternalId("test");

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBCheckExternalIdResponse parameter;
			public CheckResults expected;

			Fixture(PBCheckExternalIdResponse parameter, CheckResults expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToExtractJobResultHelper {
		public static Fixture build(String condition) {
			PBExtractJobResult.Builder builder = PBExtractJobResult.newBuilder();
			ExtractJobResult expected = new ExtractJobResult();

			builder.setJobId(1);

			PBServiceState.Builder stateBuilder = PBServiceState.newBuilder();
			if (condition.equals("error")) {
				stateBuilder.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);

				ToExtractJobErrorHelper.Fixture fixture = ToExtractJobErrorHelper.build();
				stateBuilder.setReason(fixture.parameter);
				expected.getError().add(fixture.expected);

				builder.setServiceState(stateBuilder);

			} else if (condition.equals("success")) {
				stateBuilder.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
				builder.setServiceState(stateBuilder);
				{
					ToExtOutputHelper.Fixture fixture = ToExtOutputHelper.build("face");
					builder.setOutputPayload(fixture.parameter);
				}
				{
					ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
						ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
							.build("index");
					builder.addAllKeyedTemplate(fixture.parameter);
					expected.getKeyedBinary().addAll(fixture.expected);
				}
			} else if (condition.equals("has not outputPayload")) {
				stateBuilder.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
				builder.setServiceState(stateBuilder);
				{
					ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper.Fixture fixture =
						ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper
							.build("index");
					builder.addAllKeyedTemplate(fixture.parameter);
					expected.getKeyedBinary().addAll(fixture.expected);
				}
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBExtractJobResult parameter;
			public ExtractJobResult expected;

			Fixture(PBExtractJobResult parameter, ExtractJobResult expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToDynamicXmlHelper {
		public static Fixture build() {
			ToExtOutputHelper.Fixture fixture = ToExtOutputHelper.build("tenprint");
			return new Fixture(fixture.expected);
		}

		public static class Fixture {
			public ExtOutput parameter;

			Fixture(ExtOutput parameter) {
				this.parameter = parameter;
			}
		}
	}

	public static class ToExtractJobErrorHelper {
		public static Fixture build() {
			PBServiceStateReason.Builder builder = PBServiceStateReason.newBuilder();
			ExtractJobError expected = new ExtractJobError();

			builder.setCode("test1");
			expected.setCode("test1");

			builder.setDescription("test2");
			expected.setMessage("test2");

			builder.setTime("test3");
			expected.setTime("test3");

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBServiceStateReason parameter;
			public ExtractJobError expected;

			Fixture(PBServiceStateReason parameter, ExtractJobError expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToKeyedBinaryWith_ListOfPBKeyedTemplates_ListOfKeyedBinarys_Helper {
		public static Fixture build(String type) {
			PBKeyedTemplate.Builder builder = PBKeyedTemplate.newBuilder();
			KeyedBinary expected = new KeyedBinary();

			byte[] binary = RandomStringUtils.randomAscii(32).getBytes();
			builder.setTemplateBinary(ByteString.copyFrom(binary));
			expected.setBinary(binary);

			PBKeyedTemplateIndexer.Builder indexerrBuilder =
				PBKeyedTemplateIndexer.newBuilder();
			if (type.equals("rolled_position")) {
				indexerrBuilder.setPosition(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
				builder.setKey(TemplateFormatType.TEMPLATE_RDBL);

				expected.setKey("RDBL_1");
			} else if (type.equals("slap_position")) {
				indexerrBuilder.setPosition(ImagePositionType.IMAGE_SLAP_LEFT_LITTLE);
				builder.setKey(TemplateFormatType.TEMPLATE_RDBLS);

				expected.setKey("SDBLS_10");
			} else if (type.equals("rolled_fingerprint")) {
				indexerrBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_ROLLED);
				builder.setKey(TemplateFormatType.TEMPLATE_RDBTM);

				expected.setKey("RDBTM");
			} else if (type.equals("slap_fingerprint")) {
				indexerrBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_SLAP);
				builder.setKey(TemplateFormatType.TEMPLATE_TLI);

				expected.setKey("TLI_SLAP");
			} else if (type.equals("index FDB")) {
				indexerrBuilder.setIndex(1);
				builder.setKey(TemplateFormatType.TEMPLATE_FDB);

				expected.setKey("FDB_1");
			} else if (type.equals("index FI")) {
				indexerrBuilder.setIndex(1);
				builder.setKey(TemplateFormatType.TEMPLATE_FI);

				expected.setKey("FI_1");
			} else if (type.equals("no_indexer")) {
				builder.setKey(TemplateFormatType.TEMPLATE_IDB);

				expected.setKey("IDB");
			}

			if (indexerrBuilder.hasPosition() || indexerrBuilder.hasFingerPrintType()
				|| indexerrBuilder.hasIndex()) {
				builder.setIndexer(indexerrBuilder);
			}

			List<PBKeyedTemplate> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<KeyedBinary> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBKeyedTemplate> parameter;
			public List<KeyedBinary> expected;

			Fixture(List<PBKeyedTemplate> parameter, List<KeyedBinary> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFlexibleScoreLFML.Builder builder = PBFlexibleScoreLFML.newBuilder();
			RawScore expected = new RawScore();

			builder.setSearchIndex(1);
			expected.setSearchIndex(1);

			builder.setFileIndex(2);
			expected.setFileIndex(2);

			builder.setRawScore(3);
			expected.setValue(3);

			List<PBFlexibleScoreLFML> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<RawScore> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBFlexibleScoreLFML> parameter;
			public List<RawScore> expected;

			Fixture(List<PBFlexibleScoreLFML> parameter, List<RawScore> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper_MinusScore {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFlexibleScoreLFML.Builder builder = PBFlexibleScoreLFML.newBuilder();
			RawScore expected = new RawScore();

			builder.setSearchIndex(1);
			expected.setSearchIndex(1);

			builder.setFileIndex(2);
			expected.setFileIndex(2);

			builder.setRawScore(-5);
			expected.setValue(-5);

			List<PBFlexibleScoreLFML> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<RawScore> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBFlexibleScoreLFML> parameter;
			public List<RawScore> expected;

			Fixture(List<PBFlexibleScoreLFML> parameter, List<RawScore> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFlexibleScoreIris.Builder builder = PBFlexibleScoreIris.newBuilder();
			IrisScore expected = new IrisScore();

			builder.setFilePosition(1);
			expected.setFilePosition(1);

			builder.setScore(2);
			expected.setScore(2);

			List<PBFlexibleScoreIris> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<IrisScore> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBFlexibleScoreIris> parameter;
			public List<IrisScore> expected;

			Fixture(List<PBFlexibleScoreIris> parameter, List<IrisScore> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper_MinusScore {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFlexibleScoreIris.Builder builder = PBFlexibleScoreIris.newBuilder();
			IrisScore expected = new IrisScore();

			builder.setFilePosition(1);
			expected.setFilePosition(1);

			builder.setScore(-10);
			expected.setScore(-10);

			List<PBFlexibleScoreIris> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<IrisScore> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBFlexibleScoreIris> parameter;
			public List<IrisScore> expected;

			Fixture(List<PBFlexibleScoreIris> parameter, List<IrisScore> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToSearchOutputsPayloadHelper {
		public static Fixture build() {
			PBFlexibleScore.Builder builder = PBFlexibleScore.newBuilder();
			SearchOutputsPayload expected = new SearchOutputsPayload();

			RawScores scores = new RawScores();
			{
				ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper.Fixture fixture =
					ToRawScoreWith_ListOfPBFlexibleScoreLFMLs_ListOfRawScores_Helper
						.build();
				builder.addAllLfml(fixture.parameter);

				scores.getRawScore().addAll(fixture.expected);
				expected.setRawScores(scores);
			}
			{
				ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper.Fixture fixture =
					ToIrisScoreWith_ListOfPBFlexibleScoreIris_ListOfIrisScore_Helper
						.build();
				builder.addAllIris(fixture.parameter);

				scores.getIrisScore().addAll(fixture.expected);
				expected.setRawScores(scores);
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBFlexibleScore parameter;
			public SearchOutputsPayload expected;

			Fixture(PBFlexibleScore parameter, SearchOutputsPayload expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBInquiryCandidateIndividualScore.Builder builder =
				PBInquiryCandidateIndividualScore.newBuilder();
			IndividualScore expected = new IndividualScore();

			{
				ToSearchOutputsPayloadHelper.Fixture fixture =
					ToSearchOutputsPayloadHelper.build();
				builder.setFlexibleScore(fixture.parameter);
				expected.setSearchOutputsPayload(fixture.expected);
			}

			builder.setScore(1);
			expected.setValue(1);
			
			builder.setSearchPosition(4);
			expected.setSearchPosition(4);

			builder.setPosition(2);
			expected.setPosition(2);

			builder.setFingerAxis(FingerAxisType.FINGER_AXIS_B);
			expected.setAxis(AxisEnum.B);

			PBInquiryFusionWeight.Builder weightBuilder =
				PBInquiryFusionWeight.newBuilder();
			weightBuilder.setInquirySet(FingerSetType.FMP5_ROLLED);
			weightBuilder.setWeight(3);
			builder.setFusionWeight(weightBuilder);
			expected.setInquirySet(InquirySetEnum.FMP_5_ROLLED);
			expected.setFusionWeight(3);

			List<PBInquiryCandidateIndividualScore> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<IndividualScore> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBInquiryCandidateIndividualScore> parameter;
			public List<IndividualScore> expected;

			Fixture(List<PBInquiryCandidateIndividualScore> parameter,
				List<IndividualScore> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper_MinusScore {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBInquiryCandidateIndividualScore.Builder builder =
				PBInquiryCandidateIndividualScore.newBuilder();
			IndividualScore expected = new IndividualScore();

			{
				ToSearchOutputsPayloadHelper.Fixture fixture =
					ToSearchOutputsPayloadHelper.build();
				builder.setFlexibleScore(fixture.parameter);
				expected.setSearchOutputsPayload(fixture.expected);
			}

			builder.setScore(-3);
			expected.setValue(-3);

			builder.setPosition(2);
			expected.setPosition(2);

			builder.setFingerAxis(FingerAxisType.FINGER_AXIS_B);
			expected.setAxis(AxisEnum.B);

			PBInquiryFusionWeight.Builder weightBuilder =
				PBInquiryFusionWeight.newBuilder();
			weightBuilder.setInquirySet(FingerSetType.FMP5_ROLLED);
			weightBuilder.setWeight(3);
			builder.setFusionWeight(weightBuilder);
			expected.setInquirySet(InquirySetEnum.FMP_5_ROLLED);
			expected.setFusionWeight(3);

			List<PBInquiryCandidateIndividualScore> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<IndividualScore> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBInquiryCandidateIndividualScore> parameter;
			public List<IndividualScore> expected;

			Fixture(List<PBInquiryCandidateIndividualScore> parameter,
				List<IndividualScore> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper_MinusSearchPosition {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBInquiryCandidateIndividualScore.Builder builder =
				PBInquiryCandidateIndividualScore.newBuilder();
			IndividualScore expected = new IndividualScore();

			{
				ToSearchOutputsPayloadHelper.Fixture fixture =
					ToSearchOutputsPayloadHelper.build();
				builder.setFlexibleScore(fixture.parameter);
				expected.setSearchOutputsPayload(fixture.expected);
			}

			builder.setScore(1);
			expected.setValue(1);

			builder.setSearchPosition(-1);
			expected.setSearchPosition(-1);
			
			builder.setPosition(2);
			expected.setPosition(2);

			builder.setFingerAxis(FingerAxisType.FINGER_AXIS_B);
			expected.setAxis(AxisEnum.B);

			PBInquiryFusionWeight.Builder weightBuilder =
				PBInquiryFusionWeight.newBuilder();
			weightBuilder.setInquirySet(FingerSetType.FMP5_ROLLED);
			weightBuilder.setWeight(3);
			builder.setFusionWeight(weightBuilder);
			expected.setInquirySet(InquirySetEnum.FMP_5_ROLLED);
			expected.setFusionWeight(3);

			List<PBInquiryCandidateIndividualScore> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<IndividualScore> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBInquiryCandidateIndividualScore> parameter;
			public List<IndividualScore> expected;

			Fixture(List<PBInquiryCandidateIndividualScore> parameter,
				List<IndividualScore> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}
	
	
	public static class ToCandidateTemplateHelper {
		public static Fixture build() {
			PBInquiryCandidateTemplate.Builder builder =
				PBInquiryCandidateTemplate.newBuilder();
			CandidateTemplate expected = new CandidateTemplate();

			builder.setContainerId(1);
			expected.setContainerId(1);

			builder.setEventId(2);
			expected.setEventId(2);

			builder.setInquiryRequestIndex(3);
			expected.setSearchRequestIndex(3);

			builder.setCompositScore(4);
			expected.setCompositeScore(4);

			{
				ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper.Fixture fixture =
					ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper
						.build();
				builder.addAllIndividualScore(fixture.parameter);
				expected.getIndividualScore().addAll(fixture.expected);
			}

			List<PBInquiryCandidateTemplate> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<CandidateTemplate> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBInquiryCandidateTemplate> parameter;
			public List<CandidateTemplate> expected;

			Fixture(List<PBInquiryCandidateTemplate> parameter,
				List<CandidateTemplate> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToCandidateTemplateHelper_MinusScore {
		public static Fixture build() {
			PBInquiryCandidateTemplate.Builder builder =
				PBInquiryCandidateTemplate.newBuilder();
			CandidateTemplate expected = new CandidateTemplate();

			builder.setContainerId(1);
			expected.setContainerId(1);

			builder.setEventId(2);
			expected.setEventId(2);

			builder.setInquiryRequestIndex(3);
			expected.setSearchRequestIndex(3);

			builder.setCompositScore(-8);
			expected.setCompositeScore(-8);

			{
				ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper.Fixture fixture =
					ToIndividualScoreWith_ListOfPBInquiryCandidateIndividualScores_ListOfIndividualScores_Helper
						.build();
				builder.addAllIndividualScore(fixture.parameter);
				expected.getIndividualScore().addAll(fixture.expected);
			}

			List<PBInquiryCandidateTemplate> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<CandidateTemplate> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBInquiryCandidateTemplate> parameter;
			public List<CandidateTemplate> expected;

			Fixture(List<PBInquiryCandidateTemplate> parameter,
				List<CandidateTemplate> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToCandidateHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBInquiryCandidateList.Builder builder = PBInquiryCandidateList.newBuilder();
			PBInquiryCandidate.Builder candidateBuilder = PBInquiryCandidate.newBuilder();
			Candidate expected = new Candidate();

			candidateBuilder.setExternalId("1");
			expected.setExternalId("1");

			candidateBuilder.setFusionScore(2);
			expected.setFusionScore(2);

			{
				ToCandidateTemplateHelper.Fixture fixture =
					ToCandidateTemplateHelper.build();
				candidateBuilder.addAllCandidateTemplate(fixture.parameter);
				expected.getCandidateTemplate().addAll(fixture.expected);
			}

			candidateBuilder.setHitFlag(true);
			expected.setHit(true);

			List<PBInquiryCandidate> parameter = new ArrayList<>();
			parameter.add(candidateBuilder.build());
			builder.addAllCandidate(parameter);

			List<Candidate> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(builder.build(), expectedList);
		}

		public static class Fixture {
			public PBInquiryCandidateList parameter;
			public List<Candidate> expected;

			Fixture(PBInquiryCandidateList parameter, List<Candidate> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToCandidateHelper_MinusScore {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBInquiryCandidateList.Builder builder = PBInquiryCandidateList.newBuilder();
			PBInquiryCandidate.Builder candidateBuilder = PBInquiryCandidate.newBuilder();
			Candidate expected = new Candidate();

			candidateBuilder.setExternalId("1");
			expected.setExternalId("1");

			candidateBuilder.setFusionScore(-15);
			expected.setFusionScore(-15);

			{
				ToCandidateTemplateHelper.Fixture fixture =
					ToCandidateTemplateHelper.build();
				candidateBuilder.addAllCandidateTemplate(fixture.parameter);
				expected.getCandidateTemplate().addAll(fixture.expected);
			}

			candidateBuilder.setHitFlag(true);
			expected.setHit(true);

			List<PBInquiryCandidate> parameter = new ArrayList<>();
			parameter.add(candidateBuilder.build());
			builder.addAllCandidate(parameter);

			List<Candidate> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(builder.build(), expectedList);
		}

		public static class Fixture {
			public PBInquiryCandidateList parameter;
			public List<Candidate> expected;

			Fixture(PBInquiryCandidateList parameter, List<Candidate> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToSearchJobResultHelper {
		@SuppressWarnings("boxing")
		public static Fixture build(String condition) {
			PBInquiryJobResult.Builder builder = PBInquiryJobResult.newBuilder();
			SearchJobResult expected = new SearchJobResult();

			builder.setJobId(1);
			expected.setJobId(1);

			PBServiceState.Builder stateBuilder = PBServiceState.newBuilder();
			if (condition.equals("error")) {
				stateBuilder.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);

				ToSearchJobErrorHelper.Fixture fixture = ToSearchJobErrorHelper.build();
				stateBuilder.setReason(fixture.parameter);
				expected.getError().add(fixture.expected);

				builder.setServiceState(stateBuilder);
			} else if (condition.equals("success")) {
				stateBuilder.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
				builder.setServiceState(stateBuilder);

				PBInquiryResultStatistics.Builder statisticsBuilder =
					PBInquiryResultStatistics.newBuilder();
				PBInquiryResultStatisticsAMR.Builder amrBuilder =
					PBInquiryResultStatisticsAMR.newBuilder();
				amrBuilder.setReadCount(2);
				amrBuilder.setMatchCount(3);
				statisticsBuilder.setAmr(amrBuilder);
				builder.setStatistics(statisticsBuilder);

				SearchStatistics searchStatistics = new SearchStatistics();
				searchStatistics.setReadCount(2);
				searchStatistics.setMatchCount(3);
				expected.setStatistics(searchStatistics);

				{
					ToCandidateHelper.Fixture fixture = ToCandidateHelper.build();
					builder.setCandidateList(fixture.parameter);
					expected.getCandidate().addAll(fixture.expected);
				}
			}

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBInquiryJobResult parameter;
			public SearchJobResult expected;

			Fixture(PBInquiryJobResult parameter, SearchJobResult expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToSearchJobErrorHelper {
		public static Fixture build() {
			PBServiceStateReason.Builder builder = PBServiceStateReason.newBuilder();
			SearchJobError expected = new SearchJobError();

			builder.setCode("test1");
			expected.setCode("test1");

			builder.setDescription("test2");
			expected.setMessage("test2");

			builder.setTime("test3");
			expected.setTime("test3");

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBServiceStateReason parameter;
			public SearchJobError expected;

			Fixture(PBServiceStateReason parameter, SearchJobError expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToFusionIndexeHelper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBFusionIndexer.Builder builder = PBFusionIndexer.newBuilder();
			FusionIndexer expected = new FusionIndexer();

			builder.setFormat(TemplateFormatType.TEMPLATE_LDBM);
			expected.setFormat("LDBM");

			builder.addFusionId(1);
			builder.addFusionId(2);
			builder.addFusionId(3);
			builder.addFusionId(4);

			expected.getFusionId().add(1);
			expected.getFusionId().add(2);
			expected.getFusionId().add(3);
			expected.getFusionId().add(4);

			List<PBFusionIndexer> parameter = new ArrayList<>();
			parameter.add(builder.build());
			List<FusionIndexer> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameter, expectedList);
		}

		public static class Fixture {
			public List<PBFusionIndexer> parameter;
			public List<FusionIndexer> expected;

			Fixture(List<PBFusionIndexer> parameter, List<FusionIndexer> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToIrisPoint_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build(int x, int y) {
			PBPoint.Builder builder = PBPoint.newBuilder();
			builder.setX(x);
			builder.setY(y);

			IrisPoint expected = new IrisPoint();
			expected.setX(x);
			expected.setY(y);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBPoint parameter;
			public IrisPoint expected;

			Fixture(PBPoint parameter, IrisPoint expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToIrisOutputPoints_Helper {
		@SuppressWarnings("boxing")
		public static Fixture build() {
			PBExtractIrisDetectionOutput.Builder builder =
				PBExtractIrisDetectionOutput.newBuilder();
			IrisOutputPoints expected = new IrisOutputPoints();

			builder.setPosition(ImagePositionType.IMAGE_IRIS_LEFT);
			expected.setPosition("61");

			builder.setQuality(1);
			expected.setQuality(1);

			PBIrisDetectionPoints.Builder pointBuilder =
				PBIrisDetectionPoints.newBuilder();
			{
				ToIrisPoint_Helper.Fixture fixture = ToIrisPoint_Helper.build(1, 2);
				pointBuilder.addIris(fixture.parameter);

				IrisPoints irisPoints = new IrisPoints();
				irisPoints.getPoints().add(fixture.expected);
				expected.setIrisPoints(irisPoints);
			}
			{
				ToIrisPoint_Helper.Fixture fixture = ToIrisPoint_Helper.build(3, 4);
				pointBuilder.addPupil(fixture.parameter);

				PupilPoints pupilPoints = new PupilPoints();
				pupilPoints.getPoints().add(fixture.expected);
				expected.setPupilPoints(pupilPoints);
			}
			builder.setDetectionPoints(pointBuilder.build());

			List<PBExtractIrisDetectionOutput> parameterList = new ArrayList<>();
			parameterList.add(builder.build());
			List<IrisOutputPoints> expectedList = new ArrayList<>();
			expectedList.add(expected);
			return new Fixture(parameterList, expectedList);
		}

		public static class Fixture {
			public List<PBExtractIrisDetectionOutput> parameter;
			public List<IrisOutputPoints> expected;

			Fixture(List<PBExtractIrisDetectionOutput> parameter,
				List<IrisOutputPoints> expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	public static class ToIrisOutput_Helper {
		public static Fixture build() {
			PBExtractIrisOutput.Builder builder = PBExtractIrisOutput.newBuilder();
			IrisOutput expected = new IrisOutput();

			ToIrisOutputPoints_Helper.Fixture fixture = ToIrisOutputPoints_Helper.build();
			builder.addAllDetectionOutput(fixture.parameter);

			IrisOutputDetection detection = new IrisOutputDetection();
			detection.getPoints().addAll(fixture.expected);
			expected.setDetection(detection);

			return new Fixture(builder.build(), expected);
		}

		public static class Fixture {
			public PBExtractIrisOutput parameter;
			public IrisOutput expected;

			Fixture(PBExtractIrisOutput parameter, IrisOutput expected) {
				this.parameter = parameter;
				this.expected = expected;
			}
		}
	}

	// public static class To {
	// public static Fixture build() {
	// return new Fixture(builder.build(), expected);
	// }
	//
	// public static class Fixture {
	// public parameter;
	// public expected;
	//
	// Fixture( parameter, expected) {
	// this.parameter = parameter;
	// this.expected = expected;
	// }
	// }
	// }
}
