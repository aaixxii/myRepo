package jp.co.nec.aim.convert;

public class MarshalException extends ConvertException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4326550311175574673L;

	public MarshalException() {
		super();
	}

	public MarshalException(String message, Throwable cause,
		boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public MarshalException(String message, Throwable cause) {
		super(message, cause);
	}

	public MarshalException(String message) {
		super(message);
	}

	public MarshalException(Throwable cause) {
		super(cause);
	}
}
