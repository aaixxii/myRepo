package jp.co.nec.aim.convert;

import static jp.co.nec.aim.convert.ConvertCommon.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import jp.co.nec.aim.clientapi.CommonOptions;
import jp.co.nec.aim.clientapi.afis.AfisDeletionFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisRegistrationFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisUpdateFunctionEnum;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.GenderType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateReference;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfo;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoCommon;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoLatent;
import jp.co.nec.aim.message.proto.CommonPayloads.PBMetaInfoTenprint;
import jp.co.nec.aim.message.proto.CommonPayloads.PBPrefilterOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBUsePrefilterInfo;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.BasicImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBAimFormat;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBBasicImageEnhanceOptions;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBCMLaFExtractParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBCropPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCMLaFOptions;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCMLOptions;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCommonOptionLatent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractCommonOptionTenprint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeTypeEvent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputFaceDetection;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputFaceExtraction;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputImage;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputIrisExtraction;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMarkUp;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMinutiaLatent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputMinutiaTenprint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace13Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace2Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceDetectionParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceExtractionParam;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerCropCoordinate;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisCore;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisMinutiaNo;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisQuality;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBInputMinutiaData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOptions;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryRequest;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2SpeedLevelType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLaFMatchableFingerThreshold;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLaFOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryPayload;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBIrisOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBLeOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBLfmlOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBPalmOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBPc2Options;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBPreselectionOptions;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusRequest;
import jp.co.nec.aim.message.proto.ManageService;
import jp.co.nec.aim.message.proto.ManageService.PBCallbackRequest;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdRequest;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncInsertPayload;
import jp.co.nec.aim.mm.jaxb.AfisTemplateSet;
import jp.co.nec.aim.mm.jaxb.AimFormats;
import jp.co.nec.aim.mm.jaxb.CmlafEnhType;
import jp.co.nec.aim.mm.jaxb.CmlafTiOptions;
import jp.co.nec.aim.mm.jaxb.CmlOptions;
import jp.co.nec.aim.mm.jaxb.CmlExtOptions;
import jp.co.nec.aim.mm.jaxb.CropInfo;
import jp.co.nec.aim.mm.jaxb.DynamicXml;
import jp.co.nec.aim.mm.jaxb.EnhType;
import jp.co.nec.aim.mm.jaxb.ExtractResultReference;
import jp.co.nec.aim.mm.jaxb.ExtractionFormats;
import jp.co.nec.aim.mm.jaxb.ExtractionInputs;
import jp.co.nec.aim.mm.jaxb.ExtractionInputsPayload;
import jp.co.nec.aim.mm.jaxb.Face2Points;
import jp.co.nec.aim.mm.jaxb.FaceInput;
import jp.co.nec.aim.mm.jaxb.FaceInputDetection;
import jp.co.nec.aim.mm.jaxb.FaceInputExtraction;
import jp.co.nec.aim.mm.jaxb.FaceInputExtraction13Points;
import jp.co.nec.aim.mm.jaxb.FaceInputImage;
import jp.co.nec.aim.mm.jaxb.FaceInputParams;
import jp.co.nec.aim.mm.jaxb.FacePoint;
import jp.co.nec.aim.mm.jaxb.FeTypeLatent;
import jp.co.nec.aim.mm.jaxb.FeTypeTenprint;
import jp.co.nec.aim.mm.jaxb.FeTypes;
import jp.co.nec.aim.mm.jaxb.FingerSetEnum;
import jp.co.nec.aim.mm.jaxb.FingersThresholds;
import jp.co.nec.aim.mm.jaxb.FusionWeight;
import jp.co.nec.aim.mm.jaxb.ImageEnhance;
import jp.co.nec.aim.mm.jaxb.InputImage;
import jp.co.nec.aim.mm.jaxb.IrisInput;
import jp.co.nec.aim.mm.jaxb.IrisInputExtraction;
import jp.co.nec.aim.mm.jaxb.IrisInputImage;
import jp.co.nec.aim.mm.jaxb.IrisOptions;
import jp.co.nec.aim.mm.jaxb.KeyedTemplate;
import jp.co.nec.aim.mm.jaxb.LatentInput;
import jp.co.nec.aim.mm.jaxb.LeOptions;
import jp.co.nec.aim.mm.jaxb.LfmlOptions;
import jp.co.nec.aim.mm.jaxb.MarkUp;
import jp.co.nec.aim.mm.jaxb.MatchableFingersThresholds;
import jp.co.nec.aim.mm.jaxb.MetaInfo;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaCommon;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaLatent;
import jp.co.nec.aim.mm.jaxb.MetaInfo.MetaTenprint;
import jp.co.nec.aim.mm.jaxb.PalmOptions;
import jp.co.nec.aim.mm.jaxb.Pc2Options;
import jp.co.nec.aim.mm.jaxb.Point;
import jp.co.nec.aim.mm.jaxb.PrefilterOptions;
import jp.co.nec.aim.mm.jaxb.PreselectionOptions;
import jp.co.nec.aim.mm.jaxb.QcInput;
import jp.co.nec.aim.mm.jaxb.Record;
import jp.co.nec.aim.mm.jaxb.RegistrationRequest;
import jp.co.nec.aim.mm.jaxb.SearchInputsPayload;
import jp.co.nec.aim.mm.jaxb.SearchOptions;
import jp.co.nec.aim.mm.jaxb.SearchRequest;
import jp.co.nec.aim.mm.jaxb.SegInfo;
import jp.co.nec.aim.mm.jaxb.TemplateMetadata;
import jp.co.nec.aim.mm.jaxb.TenprintInput;
import jp.co.nec.aim.mm.jaxb.TenprintInput.CmlafExtOptions;
import jp.co.nec.aim.mm.jaxb.TenprintInput.InputMinutia.InputMinutiaData;
import jp.co.nec.aim.mm.jaxb.UsePrefilterInfo;
import jp.co.nec.aim.mm.jaxb.XTemplateFmp5;
import jp.co.nec.aim.mm.jaxb.XTemplatePc2;
import jp.co.nec.aim.mm.schema.validation.PayloadValidation;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import com.google.common.base.Throwables;
import com.google.common.collect.Iterables;
import com.google.protobuf.ByteString;
import com.google.protobuf.Message;
import com.google.protobuf.UninitializedMessageException;

/**
 * convert parameters of web methods to a class that was generated by protocol
 * bufffers.
 * 
 * @author kawamura
 * 
 */
public final class ProtoClassConvert {
	private static final JAXBContext jaxbContext = ConvertCommon.getJaxbContext();

	private static final ThreadLocal<Unmarshaller> unmarshallerHolder =
		new ThreadLocal<Unmarshaller>() {
			@Override
			public Unmarshaller initialValue() {
				try {
					Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
					return unmarshaller;
				} catch (JAXBException e) {
					// Wrapped RuntimeException
					Throwables.propagate(e);
				}
				// added it for resolution build error.
				return null;
			}
		};

	private static final String EXTRACTION_INPUTS_PAYLOAD_START =
		"<ns2:extraction-inputs-payload xmlns:ns2=\"urn:nec:aim\">";

	private static final String EXTRACTION_INPUTS_PAYLOAD_END = "</ns2:extraction-inputs-payload>";

	private static final String EXT_INPUT = "<ext-input>";

	private static final String MULTI_FE = "MULTI-FE:";

	private static final List<String> compareKeysOnTr = new ArrayList<>();
	private static final List<String> compareKeysOnFr = new ArrayList<>();
	static {
		String keys[] = {
			"RDBT", "SDBT", "RDBTM", "SDBTM", "XDBL",
		};
		compareKeysOnTr.addAll(Arrays.asList(keys));
		for (int i = 1; i < 11; i++) {
			compareKeysOnTr.add(new StringBuilder("RDBL_").append(i).toString());
			compareKeysOnTr.add(new StringBuilder("SDBL_").append(i).toString());
			compareKeysOnTr.add(new StringBuilder("RDBLS_").append(i).toString());
			compareKeysOnTr.add(new StringBuilder("SDBLS_").append(i).toString());
			compareKeysOnTr.add(new StringBuilder("RDBLM_").append(i).toString());
			compareKeysOnTr.add(new StringBuilder("SDBLM_").append(i).toString());
		}
		for (int i = 1; i < 17; i++) {
			compareKeysOnTr.add(new StringBuilder("PDB_").append(i).toString());
		}
		for (int i = 1; i < 11; i++) {
			compareKeysOnFr.add(new StringBuilder("FDB_").append(i).toString());
		}
	}

	/**
	 * convert the parameters of a xR method to PBSyncJobRequest.
	 * 
	 * @param function
	 * @param externalId
	 * @param eventId
	 * @param afisTemplateSet
	 * @return
	 */
	public PBSyncJobRequest toPBSyncJobRequest(
		AfisRegistrationFunctionEnum function,
		String externalId,
		int eventId,
		AfisTemplateSet afisTemplateSet)
		throws NoInitializedException, InvalidParameterException, ConvertException {
		PBSyncJobRequest pbSyncJobRequest = null;
		try {
			validateFunctionToKey(function, afisTemplateSet);

			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			builder.setFunction(SyncFunctionType.INSERT);
			builder.setExternalId(Strings.nullToEmpty(externalId));
			builder.setEventId(eventId);
			builder.setInsertPayload(toPBSyncInsertPayload(function, afisTemplateSet));
			pbSyncJobRequest = (PBSyncJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbSyncJobRequest;
	}

	/**
	 * convert the parameters of a xU method to PBSyncJobRequest.
	 * 
	 * @param function
	 * @param externalId
	 * @param eventId
	 * @param afisGroupId
	 * @param afisTemplateSet
	 * @return
	 */
	public PBSyncJobRequest toPBSyncJobRequest(
		AfisUpdateFunctionEnum function,
		String externalId,
		int eventId,
		Integer afisGroupId,
		AfisTemplateSet afisTemplateSet)
		throws NoInitializedException, InvalidParameterException, ConvertException {
		PBSyncJobRequest pbSyncJobRequest = null;
		try {
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			builder.setFunction(SyncFunctionType.UPDATE);
			builder.setExternalId(Strings.nullToEmpty(externalId));
			builder.setEventId(eventId);
			builder.setInsertPayload(toPBSyncInsertPayload(function, afisTemplateSet));
			builder.setDeletePayload(toPBSyncDeletePayload(function, afisGroupId));
			pbSyncJobRequest = (PBSyncJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbSyncJobRequest;
	}

	/**
	 * convert the parameters of a xD method to PBSyncJobRequest.
	 * 
	 * @param function
	 * @param externalId
	 * @param eventId
	 * @param afisGroupId
	 * @return
	 */
	public PBSyncJobRequest toPBSyncJobRequest(
		AfisDeletionFunctionEnum function,
		String externalId,
		Integer eventId,
		Integer afisGroupId)
		throws NoInitializedException, InvalidParameterException, ConvertException {
		PBSyncJobRequest pbSyncJobRequest = null;
		try {
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			builder.setFunction(SyncFunctionType.DELETE);
			builder.setExternalId(Strings.nullToEmpty(externalId));
			if (eventId != null) {
				builder.setEventId(eventId.intValue());
			}
			builder.setDeletePayload(toPBSyncDeletePayload(function, afisGroupId));
			pbSyncJobRequest = (PBSyncJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbSyncJobRequest;
	}

	/**
	 * convert the parameters of a xI method to PBSyncJobRequest.
	 * 
	 * @param function
	 * @param afisTemplateSet
	 * @param commonOptions
	 * @return
	 */
	public PBInquiryJobRequest toPBInquiryJobRequest(
		AfisLowLevelFunctionEnum function,
		AfisTemplateSet afisTemplateSet,
		CommonOptions commonOptions)
		throws NoInitializedException, InvalidPayloadException, InvalidParameterException,
		UnmarshalException, ConvertException {
		PBInquiryJobRequest pbInquiryJobRequest = null;
		try {
			PBInquiryJobRequest.Builder builder = PBInquiryJobRequest.newBuilder();

			InquiryFunctionType functionType = getValue(function,
				afisLowLevelFunctionEnumToInquiryFuncionType);
			builder.setJobInfo(toPBInquiryJobInfo(functionType, commonOptions));

			for (KeyedTemplate keyedTemplate : nullToList(afisTemplateSet.getTemplate())) {
				validateFunctionToKey(function, afisTemplateSet);

				PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput.newBuilder();

				fusionJobBuilder.setScopes(toPBInquiryScopeOptions(keyedTemplate));

				fusionJobBuilder.setKeyedTemplateData(toPBKeyedTemplateData(keyedTemplate.getKey(),
					keyedTemplate.getBinary()));

				if (keyedTemplate.getSearchOptions() != null) {
					toPBInquiryPayload(functionType, keyedTemplate.getSearchOptions(),
						fusionJobBuilder.getInquiryOptionsBuilder().getInquiryPayloadBuilder());
				}

				if (commonOptions.getMinScore() != null) {
					fusionJobBuilder.getInquiryOptionsBuilder().setMinScore(commonOptions
						.getMinScore().intValue());
				}

				builder.addFusionJobInput(fusionJobBuilder);
			}
			pbInquiryJobRequest = (PBInquiryJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbInquiryJobRequest;
	}

	/**
	 * 
	 * @param functionType
	 * @param searchOptions
	 * @param payload
	 */
	private void toPBInquiryPayload(
		InquiryFunctionType functionType,
		SearchOptions searchOptions,
		PBInquiryPayload.Builder builder)
		throws NoInitializedException, InvalidPayloadException, InvalidParameterException,
		UnmarshalException {
		if (searchOptions.getSearchInputsPayload() == null || searchOptions.getSearchInputsPayload()
			.getAny() == null) {
			return;
		}
		if (!searchOptions.getSearchInputsPayload().getAny().hasChildNodes()) {
			return;
		}

		String strPayload = toString(searchOptions.getSearchInputsPayload());
		try {
			new PayloadValidation().validateSearchPayload(strPayload);
		} catch (SAXException | IOException e) {
			if (StringUtils.isEmpty(e.getMessage())) {
				throw new UnmarshalException(Throwables.getStackTraceAsString(e));
			} else {
				throw new UnmarshalException(e.getMessage());
			}
		}

		SearchInputsPayload searchPayload = null;
		try {
			searchPayload = (SearchInputsPayload)unmarshallerHolder.get().unmarshal(
				new StringReader(strPayload));
		} catch (JAXBException e) {
			throw new UnmarshalException(Throwables.getStackTraceAsString(e));
		}
		toPBInquiryPayload(functionType, searchPayload, builder);
	}

	/**
	 * 
	 * 
	 * @param searchPayload
	 * @param builder
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private void toPBInquiryPayload(
		InquiryFunctionType functionType,
		SearchInputsPayload searchPayload,
		PBInquiryPayload.Builder builder)
		throws NoInitializedException, InvalidParameterException {
		MetaInfo metaInfo = searchPayload.getMetaInfo();
		builder.clearMetaInfo();
		if (metaInfo != null) {
			builder.setMetaInfo(toPBMetaInfo(metaInfo));
		}

		if (functionType == InquiryFunctionType.TI && (searchPayload
			.getPreselectionOptions() != null)) {
			builder.clearPreselectionOptions();

			PreselectionOptions preselection = searchPayload.getPreselectionOptions();
			builder.setPreselectionOptions(toPBPreselectionOptions(preselection));

			PBMetaInfo.Builder infoBuilder = builder.getMetaInfo().toBuilder();
			infoBuilder.setCommon(updateYobAndGender(BooleanUtils.isTrue(preselection.isApplyYob()),
				BooleanUtils.isTrue(preselection.isApplyGender()), metaInfo, builder.getMetaInfo()
					.getCommon().toBuilder()));
			builder.setMetaInfo(infoBuilder);
		}

		if (searchPayload.getPrefilterOptions() != null) {
			builder.clearPrefilterOptions();
			builder.setPrefilterOptions(toPBPrefilterOptions(searchPayload.getPrefilterOptions()));
		}

		if (searchPayload.getPc2Options() != null) {
			builder.clearPc2Options();
			builder.setPc2Options(toPBPc2Options(searchPayload.getPc2Options()));
		}

		if (searchPayload.getLeOptions() != null) {
			if (BooleanUtils.isTrue(searchPayload.getLeOptions().isApplyLeOptions())) {
				builder.setLeOptions(toPBLeOptions(searchPayload.getLeOptions()));
			}
		}

		if (searchPayload.getPalmOptions() != null) {
			toPBPalmOptions(searchPayload.getPalmOptions(), builder);
		}

		if (functionType == InquiryFunctionType.TIM) {
			if (searchPayload.getCmlafTiOptions() != null) {
				builder.clearCmlafOptions();
				builder.setCmlafOptions(toPBCMLaFOptions(searchPayload.getCmlafTiOptions()));

				PBMetaInfo.Builder infoBuilder = builder.getMetaInfo().toBuilder();
				CmlafTiOptions cmlaf = searchPayload.getCmlafTiOptions();
				infoBuilder.setCommon(updateYobAndGender(BooleanUtils.isTrue(cmlaf.isApplyYob()),
					BooleanUtils.isTrue(cmlaf.isApplyGender()), metaInfo, builder.getMetaInfo()
						.getCommon().toBuilder()));
				builder.setMetaInfo(infoBuilder);
			}

			if (searchPayload.getCmlOptions() != null) {
				builder.clearCmlOptions();
				builder.setCmlOptions(toPBCMLOptions(searchPayload.getCmlOptions()));

				PBMetaInfo.Builder infoBuilder = builder.getMetaInfo().toBuilder();
				CmlOptions cml = searchPayload.getCmlOptions();
				infoBuilder.setCommon(updateYobAndGender(BooleanUtils.isTrue(cml.isApplyYob()),
					BooleanUtils.isTrue(cml.isApplyGender()), metaInfo, builder.getMetaInfo()
						.getCommon().toBuilder()));
				builder.setMetaInfo(infoBuilder);
			}
		}

		if (searchPayload.getLfmlOptions() != null) {
			builder.clearLfmlOptions();
			builder.setLfmlOptions(toPBLfmlOptions(searchPayload.getLfmlOptions()));
		}

		if (searchPayload.getIrisOptions() != null) {
			builder.clearIrisOptions();
			builder.setIrisOptions(toPBIrisOptions(searchPayload.getIrisOptions()));
		}
	}

	/**
	 * convert the parameter of deleteJob method to PBDeleteJobRequest.
	 * 
	 * @param jobId
	 * @return
	 */
	public PBDeleteJobRequest toPBDeleteJobRequest(long jobId) {
		return JobCommonService.PBDeleteJobRequest.newBuilder().setJobId(jobId).build();
	}

	/**
	 * convert the parameter of a getXXXJobResult method to PBJobResultRequest.
	 * 
	 * @param jobId
	 * @return
	 */
	public PBJobResultRequest toPBJobResultRequest(long jobId) {
		return JobCommonService.PBJobResultRequest.newBuilder().setJobId(jobId).build();
	}

	/**
	 * convert the job id of parameters of the getJobStatus method to
	 * PBJobStatusRequest.
	 * 
	 * @param jobId
	 * @return
	 */
	public PBJobStatusRequest toPBJobStatusRequest(long jobId) {
		return JobCommonService.PBJobStatusRequest.newBuilder().setJobId(jobId).build();
	}

	/**
	 * 
	 * @param extractInputs
	 * @return
	 */
	public PBExtractJobRequest toPBExtractJobRequest(ExtractionInputs extractInputs)
		throws NoInitializedException, InvalidParameterException, InvalidPayloadException,
		UnmarshalException, ConvertException {
		PBExtractJobRequest pbExtractJobRequest = null;
		try {
			PBExtractJobRequest.Builder builder = PBExtractJobRequest.newBuilder();
			builder.setPriority(extractInputs.getPriority());
			builder.setCallBackUrl(extractInputs.getCallbackURL());
			builder.setInputPayload(toPBExtractInputPayload(extractInputs));
			pbExtractJobRequest = (PBExtractJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbExtractJobRequest;
	}

	/**
	 * 
	 * @param extractionInput
	 * @return
	 */
	private PBExtractInputPayload toPBExtractInputPayload(ExtractionInputs extractionInput)
		throws NoInitializedException, InvalidPayloadException, InvalidParameterException,
		UnmarshalException {
		String strPayload = toString(extractionInput.getExtractionInputsPayload());
		int index = strPayload.indexOf(EXT_INPUT);
		StringBuilder sb = new StringBuilder().append(EXTRACTION_INPUTS_PAYLOAD_START).append(
			strPayload.substring(index)).append(EXTRACTION_INPUTS_PAYLOAD_END);

		try {
			new PayloadValidation().validateExtractPayload(sb.toString());
		} catch (SAXException | IOException e) {
			if (StringUtils.isEmpty(e.getMessage())) {
				throw new UnmarshalException(Throwables.getStackTraceAsString(e));
			} else {
				throw new UnmarshalException(e.getMessage());
			}
		}

		ExtractionInputsPayload payload = null;
		try {
			payload = (ExtractionInputsPayload)unmarshallerHolder.get().unmarshal(new StringReader(
				sb.toString()));
		} catch (JAXBException e) {
			throw new UnmarshalException(Throwables.getStackTraceAsString(e));
		}

		PBExtractInputPayload.Builder builder = PBExtractInputPayload.newBuilder();
		if (payload.getExtInput().getTenprintInput() != null) {
			builder.setTenprintInput(toPBExtractTenprintInput(payload.getExtInput()
				.getTenprintInput()));
		} else if (payload.getExtInput().getLatentInput() != null) {
			builder.setLatentInput(toPBExtractLatentInput(payload.getExtInput().getLatentInput()));
		} else if (payload.getExtInput().getFaceInput() != null) {
			builder.setFaceInput(toPBExtractFaceInput(payload.getExtInput().getFaceInput()));
		} else if (payload.getExtInput().getIrisInput() != null) {
			builder.setIrisInput(toPBExtractIrisInput(payload.getExtInput().getIrisInput()));
		}
		return (PBExtractInputPayload)buildClass(builder);
	}

	/**
	 * 
	 * @param jobId
	 * @param key
	 * @return
	 */
	public PBExtractJobBinaryRequest toPBExtractJobBinaryRequest(long jobId, String key)
		throws NoInitializedException, InvalidParameterException, ConvertException {
		TemplateFormatType templateFormatType = getValue(Strings.nullToEmpty(key),
			stringToTemplateFormatTypeForGetBinary);

		PBExtractJobBinaryRequest pbExtractJobBinaryRequest = null;
		try {
			PBKeyedTemplate keyedTemplate = null;
			if (templateFormatType != TemplateFormatType.TEMPLATE_II
				&& templateFormatType != TemplateFormatType.TEMPLATE_IDB) {
				PBKeyedTemplateIndexer keyedTemplateIndexer = toPBKeyedTemplateIndexer(key,
					templateFormatType);
				keyedTemplate = toPBKeyedTemplate(null, templateFormatType, keyedTemplateIndexer);
			} else {
				keyedTemplate = toPBKeyedTemplate(null, templateFormatType, null);
			}

			PBExtractJobBinaryRequest.Builder builder = PBExtractJobBinaryRequest.newBuilder();
			builder.setJobId(jobId);
			builder.addKeyedTemplate(keyedTemplate);

			pbExtractJobBinaryRequest = (PBExtractJobBinaryRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbExtractJobBinaryRequest;
	}

	/**
	 * convert the parameters of the insert method to a PBSyncJobRequest.
	 * 
	 * @param externalId
	 * @param eventId
	 * @param reqs
	 * @return
	 */
	public PBSyncJobRequest toPBSyncJobRequest(
		String externalId,
		int eventId,
		List<RegistrationRequest> registrationRequests)
		throws NoInitializedException, InvalidParameterException, ConvertException {
		PBSyncJobRequest pbSyncJobRequest = null;
		try {
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			builder.setFunction(SyncFunctionType.INSERT);
			builder.setExternalId(Strings.nullToEmpty(externalId));
			builder.setEventId(eventId);
			builder.setInsertPayload(toPBSyncInsertPayload(registrationRequests));
			pbSyncJobRequest = (PBSyncJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbSyncJobRequest;
	}

	/**
	 * convert the parameters of the update method to a PBSyncJobRequest.
	 * 
	 * @param externalId
	 * @param eventId
	 * @param reqs
	 * @param containerIds
	 * @return
	 */
	public PBSyncJobRequest toPBSyncJobRequest(
		String externalId,
		int eventId,
		List<RegistrationRequest> registrationRequests,
		List<Integer> containerIds)
		throws NoInitializedException, InvalidParameterException, ConvertException {
		PBSyncJobRequest pbSyncJobRequest = null;
		try {
			if (overlap(containerIds)) {
				throw new InvalidParameterException("An invalid parameter: container IDs overlap.");
			}

			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			builder.setFunction(SyncFunctionType.UPDATE);
			builder.setExternalId(Strings.nullToEmpty(externalId));
			builder.setEventId(eventId);
			builder.setInsertPayload(toPBSyncInsertPayload(registrationRequests));
			builder.setDeletePayload(toPBSyncDeletePayload(containerIds));
			pbSyncJobRequest = (PBSyncJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbSyncJobRequest;
	}

	/**
	 * convert the parameters of the delete method to a PBSyncJobRequest.
	 * 
	 * @param externalId
	 * @param eventId
	 * @param containerIds
	 * @return
	 */
	public PBSyncJobRequest toPBSyncJobRequest(
		String externalId,
		Integer eventId,
		List<Integer> containerIds)
		throws NoInitializedException, InvalidParameterException, ConvertException {
		PBSyncJobRequest pbSyncJobRequest = null;
		try {
			PBSyncJobRequest.Builder builder = PBSyncJobRequest.newBuilder();
			builder.setFunction(SyncFunctionType.DELETE);
			builder.setExternalId(Strings.nullToEmpty(externalId));
			if (eventId != null) {
				builder.setEventId(eventId.intValue());
			}
			
			if (containerIds != null) {
				if (overlap(containerIds)) {
					throw new InvalidParameterException(
						"An invalid parameter: container IDs overlap.");
				}
				builder.setDeletePayload(toPBSyncDeletePayload(containerIds));
			}
			
			pbSyncJobRequest = (PBSyncJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbSyncJobRequest;
	}

	/**
	 * convert the parameters of the search method to a PBInquiryJobRequest.
	 * 
	 * @param searchRequestList
	 * @param commonOptions
	 * @return
	 */
	public PBInquiryJobRequest toPBInquiryJobRequest(
		List<SearchRequest> searchRequestList,
		CommonOptions commonOptions)
		throws NoInitializedException, InvalidPayloadException, InvalidParameterException,
		UnmarshalException, ConvertException {
		PBInquiryJobRequest pbInquiryJobRequest = null;
		try {
			PBInquiryJobRequest.Builder builder = PBInquiryJobRequest.newBuilder();

			Map<TemplateFormatType, Integer> fingerPrintTypeMap = new HashMap<>();
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TI, Integer.valueOf(1));
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TIM, Integer.valueOf(1));
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TLI, Integer.valueOf(1));
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TLIS, Integer.valueOf(1));
			fingerPrintTypeMap.put(TemplateFormatType.TEMPLATE_TLIM, Integer.valueOf(1));

			Map<TemplateFormatType, Integer> inquirySetMap = new HashMap<>();
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TI, Integer.valueOf(1));
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TIM, Integer.valueOf(1));
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TLIM, Integer.valueOf(1));
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TLI, Integer.valueOf(1));
			inquirySetMap.put(TemplateFormatType.TEMPLATE_TLIS, Integer.valueOf(1));

			List<Integer> expectedIdList = null;
			InquiryFunctionType function = null;
			for (SearchRequest searchRequest : searchRequestList) {
				if (overlap(searchRequest.getSearchContainer())) {
					throw new InvalidParameterException(
						"An invalid parameter: container IDs overlap.");
				}

				expectedIdList = getValue(Strings.nullToEmpty(searchRequest.getFunctionName()),
					stringToListInt);

				validationContainerIdToFunction(searchRequest.getSearchContainer(), expectedIdList);

				function = getValue(searchRequest.getFunctionName(), stringToInquiryFuncionType);

				if (function == InquiryFunctionType.TI || function == InquiryFunctionType.TIM
					|| function == InquiryFunctionType.TLIM) {
					if (3 <= searchRequestList.size()) {
						throw new InvalidParameterException(
							"An invalid parameter: the number of search-request elements.");
					}
				} else if (function == InquiryFunctionType.TLIX
					|| function == InquiryFunctionType.LIX || function == InquiryFunctionType.LLIX
					|| function == InquiryFunctionType.LIM
					|| function == InquiryFunctionType.LLIM) {
					if (2 <= searchRequestList.size()) {
						throw new InvalidParameterException(
							"An invalid parameter: the number of search-request elements.");
					}
				} else if (function == InquiryFunctionType.TLI) {
					if (5 <= searchRequestList.size()) {
						throw new InvalidParameterException(
							"An invalid parameter: the number of search-request elements.");
					}
				} else if (function == InquiryFunctionType.LI
					|| function == InquiryFunctionType.LLI) {
					if (3 <= searchRequestList.size()) {
						throw new InvalidParameterException(
							"An invalid parameter: the number of search-request elements.");
					}
				}

				PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput.newBuilder();

				fusionJobBuilder.setScopes(toPBInquiryScopeOptions(function, searchRequest
					.getSearchContainer()));

				fusionJobBuilder.setKeyedTemplateData(toPBKeyedTemplateData(searchRequest,
					fingerPrintTypeMap));

				if (searchRequest.getSearchOptions() != null) {
					toPBInquiryPayload(function, searchRequest.getSearchOptions(), fusionJobBuilder
						.getInquiryOptionsBuilder().getInquiryPayloadBuilder());
				}

				TemplateFormatType key = null;
				FingerPrintType fingerPrintType = null;
				if (fusionJobBuilder.getKeyedTemplateData().hasKeyedTemplate()) {
					key = fusionJobBuilder.getKeyedTemplateData().getKeyedTemplate().getKey();
				} else {
					key = fusionJobBuilder.getKeyedTemplateData().getKeyedReferenece().getKey();
					if (fusionJobBuilder.getKeyedTemplateData().getKeyedReferenece().getIndexer()
						.hasFingerPrintType()) {
						fingerPrintType = fusionJobBuilder.getKeyedTemplateData()
							.getKeyedReferenece().getIndexer().getFingerPrintType();
					}
				}

				if (function != InquiryFunctionType.LIP && function != InquiryFunctionType.TLIP
					&& function != InquiryFunctionType.LLIP && function != InquiryFunctionType.FI
					&& function != InquiryFunctionType.II) {
					fusionJobBuilder.getInquiryOptionsBuilder().addAllFusionWeight(
						toPBInquiryFusionWeight(function, key, searchRequest.getFusionWeight(),
							inquirySetMap, fingerPrintType));
				}

				if (commonOptions.getMinScore() != null) {
					fusionJobBuilder.getInquiryOptionsBuilder().setMinScore(commonOptions
						.getMinScore().intValue());
				}

				builder.addFusionJobInput(fusionJobBuilder);

				builder.setJobInfo(toPBInquiryJobInfo(function, commonOptions));
			}
			pbInquiryJobRequest = (PBInquiryJobRequest)buildClass(builder);
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbInquiryJobRequest;
	}

	/**
	 * convert the parameters of the callbackTest to a PBCallbackRequest.
	 * 
	 * @param callbackURL
	 * @param body
	 * @return
	 */
	public PBCallbackRequest toPBCallbackRequest(String callbackURL, String body) {
		return ManageService.PBCallbackRequest.newBuilder().setCallbackURL(Strings.nullToEmpty(
			callbackURL)).setTestString(Strings.nullToEmpty(body)).build();
	}

	/**
	 * convert the parameters of the checkExternalId method to a
	 * PBCheckExternalIdRequest.
	 * 
	 * @param externalId
	 * @param eventIds
	 * @param containerIds
	 * @return
	 */
	public PBCheckExternalIdRequest toPBChechkExternalIdRequest(
		String externalId,
		List<Integer> eventIds,
		List<Integer> containerIds)
		throws NoInitializedException, ConvertException {
		PBCheckExternalIdRequest pbCheckExternalIdRequest = null;
		if (overlap(nullToList(containerIds))) {
			throw new InvalidParameterException("An invalid parameter: container IDs overlap.");
		}

		try {
			PBCheckExternalIdRequest.Builder builder = PBCheckExternalIdRequest.newBuilder();
			builder.setExternalId(Strings.nullToEmpty(externalId));
			for (int eventId : nullToList(eventIds)) {
				builder.addEventIds(eventId);
			}
			for (int containertId : nullToList(containerIds)) {
				builder.addContainerIds(containertId);
			}
			pbCheckExternalIdRequest = builder.build();
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return pbCheckExternalIdRequest;
	}

	/**
	 * 
	 * @throws NoInitializedException
	 */
	@SuppressWarnings("unchecked")
	private static <E> E buildClass(Message.Builder builder)
		throws NoInitializedException {
		try {
			return (E)builder.build();
		} catch (UninitializedMessageException e) {
			throw new NoInitializedException(Joiner.on(". ").join(e.getMissingFields()));
		}
	}

	/**
	 * 
	 * @return
	 */
	private static <E> List<E> nullToList(List<E> list) {
		if (list == null) {
			return Collections.<E> emptyList();
		}
		return list;
	}

	/**
	 * 
	 * @param template
	 * @param templateFormatType
	 * @param indexer
	 * @return
	 */
	private static PBKeyedTemplate toPBKeyedTemplate(
		byte[] template,
		TemplateFormatType templateFormatType,
		PBKeyedTemplateIndexer indexer)
		throws NoInitializedException {
		PBKeyedTemplate.Builder builder = PBKeyedTemplate.newBuilder();
		if (template != null) {
			builder.setTemplateBinary(ByteString.copyFrom(template));
		}
		if (templateFormatType != null) {
			builder.setKey(templateFormatType);
		}
		if (indexer != null) {
			builder.setIndexer(indexer);
		}
		return (PBKeyedTemplate)buildClass(builder);
	}

	/**
	 * 
	 * @param key
	 * @param templateFormatType
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBKeyedTemplateIndexer toPBKeyedTemplateIndexer(
		String key,
		TemplateFormatType templateFormatType)
		throws NoInitializedException, InvalidParameterException {
		ImagePositionType position = null;
		FingerPrintType fingerPrintType = null;
		Integer index = null;
		if (templateFormatType == TemplateFormatType.TEMPLATE_RDBL
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBLS
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBLM
			|| templateFormatType == TemplateFormatType.TEMPLATE_PDB) {
			position = getValue(key, stringToImagePositionType);
		} else if (templateFormatType == TemplateFormatType.TEMPLATE_RDBT
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBTM) {
			if (key.equals("RDBT") || key.equals("RDBTM")) {
				fingerPrintType = FingerPrintType.FINGER_PRINT_ROLLED;
			} else if (key.equals("SDBT") || key.equals("SDBTM")) {
				fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
			}
		} else if (templateFormatType == TemplateFormatType.TEMPLATE_FDB
			|| templateFormatType == TemplateFormatType.TEMPLATE_FI) {
			index = getValue(key, stringToIntIndex);
		} else if (templateFormatType == TemplateFormatType.TEMPLATE_TI
			|| templateFormatType == TemplateFormatType.TEMPLATE_TIM
			|| templateFormatType == TemplateFormatType.TEMPLATE_TLI
			|| templateFormatType == TemplateFormatType.TEMPLATE_TLIS
			|| templateFormatType == TemplateFormatType.TEMPLATE_TLIM) {
			if (key.contains("ROLLED")) {
				fingerPrintType = FingerPrintType.FINGER_PRINT_ROLLED;
			} else if (key.contains("SLAP")) {
				fingerPrintType = FingerPrintType.FINGER_PRINT_SLAP;
			}
		}

		PBKeyedTemplateIndexer.Builder builder = PBKeyedTemplateIndexer.newBuilder();
		if (position != null) {
			builder.setPosition(position);
		} else if (fingerPrintType != null) {
			builder.setFingerPrintType(fingerPrintType);
		} else if (index != null) {
			builder.setIndex(index.intValue());
		}
		return (PBKeyedTemplateIndexer)buildClass(builder);
	}

	/**
	 * 
	 * @param containerIds
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBSyncDeletePayload toPBSyncDeletePayload(List<Integer> containerIds)
		throws NoInitializedException, InvalidParameterException {
		int quotient = 0;
		Integer remainder = null;
		List<PBKeyedTemplate> keyedTemplates = new ArrayList<>();
		PBSyncDeletePayload.Builder builder = PBSyncDeletePayload.newBuilder();
		HashSet<Integer> scopeSet = new HashSet<>();
		HashSet<Integer> containerSet = new HashSet<>();

		for (int scope : nullToList(containerIds)) {
			quotient = scope / 1000;
			remainder = Integer.valueOf(scope % 1000);
			if (!scopeSet.contains(Integer.valueOf(quotient + 1))) {
				scopeSet.add(Integer.valueOf(quotient + 1));
				builder.addScopes(quotient + 1);
			}

			if (containerSet.contains(remainder)) {
				continue;
			}
			containerSet.add(remainder);

			TemplateFormatType templateFormatType = getValue(remainder, intToTemplateFormatType);

			if (templateFormatType == TemplateFormatType.TEMPLATE_RDBT
				|| templateFormatType == TemplateFormatType.TEMPLATE_RDBTM
				|| templateFormatType == TemplateFormatType.TEMPLATE_RDBL
				|| templateFormatType == TemplateFormatType.TEMPLATE_RDBLS
				|| templateFormatType == TemplateFormatType.TEMPLATE_RDBLM) {
				PBKeyedTemplateIndexer.Builder indexerBuilder = PBKeyedTemplateIndexer.newBuilder();

				if (remainder.equals(RDBT_CONTAINER_ID) || remainder.equals(RDBTM_CONTAINER_ID)
					|| remainder.equals(RDBL_CONTAINER_ID) || remainder.equals(RDBLS_CONTAINER_ID)
					|| remainder.equals(RDBLM_CONTAINER_ID)) {
					indexerBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_ROLLED);
				} else if (remainder.equals(SDBT_CONTAINER_ID) || remainder.equals(
					SDBTM_CONTAINER_ID) || remainder.equals(SDBL_CONTAINER_ID) || remainder.equals(
						SDBLS_CONTAINER_ID) || remainder.equals(SDBLM_CONTAINER_ID)) {
					indexerBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_SLAP);
				}
				keyedTemplates.add(toPBKeyedTemplate(null, templateFormatType, indexerBuilder
					.build()));
			} else {
				keyedTemplates.add(toPBKeyedTemplate(null, templateFormatType, null));
			}
		}
		for (PBKeyedTemplate keyedTemplate : keyedTemplates) {
			builder.addKeyedTemplate(keyedTemplate);
		}
		return (PBSyncDeletePayload)buildClass(builder);
	}

	/**
	 * 
	 * @param function
	 * @param afisGroupId
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBSyncDeletePayload toPBSyncDeletePayload(
		AfisDeletionFunctionEnum function,
		Integer afisGroupId)
		throws NoInitializedException, InvalidParameterException {
		List<PBKeyedTemplate> keyedTemplates = new ArrayList<>();
		if (function == AfisDeletionFunctionEnum.TD) {
			Integer[] containerIds = {
				RDBT_CONTAINER_ID, SDBT_CONTAINER_ID, RDBTM_CONTAINER_ID, SDBTM_CONTAINER_ID,
				RDBL_CONTAINER_ID, SDBL_CONTAINER_ID, RDBLS_CONTAINER_ID, SDBLS_CONTAINER_ID,
				RDBLM_CONTAINER_ID, SDBLM_CONTAINER_ID, XDBL_CONTAINER_ID, PDB_CONTAINER_ID
			};

			for (Integer containerId : containerIds) {
				TemplateFormatType templateFormatType = getValue(containerId,
					intToTemplateFormatType);
				PBKeyedTemplateIndexer keyedTemplateIndexer = null;
				if (containerId.equals(RDBT_CONTAINER_ID) || containerId.equals(RDBTM_CONTAINER_ID)
					|| containerId.equals(RDBL_CONTAINER_ID) || containerId.equals(
						RDBLS_CONTAINER_ID) || containerId.equals(RDBLM_CONTAINER_ID)) {
					PBKeyedTemplateIndexer.Builder indexerBuilder = PBKeyedTemplateIndexer
						.newBuilder();
					indexerBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_ROLLED);
					keyedTemplateIndexer = buildClass(indexerBuilder);
				} else if (containerId.equals(SDBTM_CONTAINER_ID) || containerId.equals(
					SDBT_CONTAINER_ID) || containerId.equals(SDBL_CONTAINER_ID) || containerId
						.equals(SDBLS_CONTAINER_ID) || containerId.equals(SDBLM_CONTAINER_ID)) {
					PBKeyedTemplateIndexer.Builder indexerBuilder = PBKeyedTemplateIndexer
						.newBuilder();
					indexerBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_SLAP);
					keyedTemplateIndexer = buildClass(indexerBuilder);
				}
				keyedTemplates.add(toPBKeyedTemplate(null, templateFormatType,
					keyedTemplateIndexer));
			}
		} else if (function == AfisDeletionFunctionEnum.LD) {
			keyedTemplates.add(toPBKeyedTemplate(function, LDB_CONTAINER_ID));
		} else if (function == AfisDeletionFunctionEnum.LDS) {
			keyedTemplates.add(toPBKeyedTemplate(function, LDBS_CONTAINER_ID));
		} else if (function == AfisDeletionFunctionEnum.LDM) {
			keyedTemplates.add(toPBKeyedTemplate(function, LDBM_CONTAINER_ID));
		} else if (function == AfisDeletionFunctionEnum.LDP) {
			keyedTemplates.add(toPBKeyedTemplate(function, PLDB_CONTAINER_ID));
		} else if (function == AfisDeletionFunctionEnum.LDX) {
			keyedTemplates.add(toPBKeyedTemplate(function, LDBX_CONTAINER_ID));
		} else if (function == AfisDeletionFunctionEnum.FD) {
			keyedTemplates.add(toPBKeyedTemplate(function, FDB_CONTAINER_ID));
		} else if (function == AfisDeletionFunctionEnum.ID) {
			keyedTemplates.add(toPBKeyedTemplate(function, IDB_CONTAINER_ID));
		}

		PBSyncDeletePayload.Builder builder = PBSyncDeletePayload.newBuilder();
		if (afisGroupId != null) {
			builder.addScopes(afisGroupId.intValue());
		}
		for (PBKeyedTemplate keyedTemplatek : keyedTemplates) {
			builder.addKeyedTemplate(keyedTemplatek);
		}
		return (PBSyncDeletePayload)buildClass(builder);
	}

	/**
	 * convert the parameter of xU methods to PBSyncDeletePayload.
	 * 
	 * @param function
	 * @param afisGroupId
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBSyncDeletePayload toPBSyncDeletePayload(
		AfisUpdateFunctionEnum function,
		Integer afisGroupId)
		throws NoInitializedException, InvalidParameterException {
		if (function == AfisUpdateFunctionEnum.TU) {
			return toPBSyncDeletePayload(AfisDeletionFunctionEnum.TD, afisGroupId);
		} else if (function == AfisUpdateFunctionEnum.LU) {
			return toPBSyncDeletePayload(AfisDeletionFunctionEnum.LD, afisGroupId);
		} else if (function == AfisUpdateFunctionEnum.LUS) {
			return toPBSyncDeletePayload(AfisDeletionFunctionEnum.LDS, afisGroupId);
		} else if (function == AfisUpdateFunctionEnum.LUM) {
			return toPBSyncDeletePayload(AfisDeletionFunctionEnum.LDM, afisGroupId);
		} else if (function == AfisUpdateFunctionEnum.LUP) {
			return toPBSyncDeletePayload(AfisDeletionFunctionEnum.LDP, afisGroupId);
		} else if (function == AfisUpdateFunctionEnum.LUX) {
			return toPBSyncDeletePayload(AfisDeletionFunctionEnum.LDX, afisGroupId);
		} else if (function == AfisUpdateFunctionEnum.FU) {
			return toPBSyncDeletePayload(AfisDeletionFunctionEnum.FD, afisGroupId);
		} else if (function == AfisUpdateFunctionEnum.IU) {
			return toPBSyncDeletePayload(AfisDeletionFunctionEnum.ID, afisGroupId);
		}
		// never come here.
		return null;
	}

	/**
	 * 
	 * @param registrationRequests
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBSyncInsertPayload toPBSyncInsertPayload(
		List<RegistrationRequest> registrationRequests)
		throws NoInitializedException, InvalidParameterException {
		// for index of PBKeyedTemplateIndexer
		Map<Integer, Integer> index = new HashMap<>();
		index.put(RDBL_CONTAINER_ID, Integer.valueOf(1));
		index.put(RDBLS_CONTAINER_ID, Integer.valueOf(1));
		index.put(RDBLM_CONTAINER_ID, Integer.valueOf(1));
		index.put(SDBL_CONTAINER_ID, Integer.valueOf(1));
		index.put(SDBLS_CONTAINER_ID, Integer.valueOf(1));
		index.put(SDBLM_CONTAINER_ID, Integer.valueOf(1));
		index.put(PDB_CONTAINER_ID, Integer.valueOf(1));
		index.put(FDB_CONTAINER_ID, Integer.valueOf(1));

		List<PBKeyedTemplateData> keyedTemplateDataList = new ArrayList<>();
		PBSyncInsertPayload.Builder builder = PBSyncInsertPayload.newBuilder();
		int quotient = 0;
		int firstScope = -1;
		for (RegistrationRequest registrationRequest : nullToList(registrationRequests)) {
			quotient = registrationRequest.getDestinationContainer() / 1000;
			if (firstScope == -1) {
				firstScope = quotient + 1;
			} else if (firstScope != (quotient + 1)) {
				throw new InvalidParameterException(
					"An invalid parameter: there is a invalid container ID.");
			}
			builder.setScope(quotient + 1);

			PBKeyedTemplateData keyedTemplateData = toPBKeyedTemplateData(registrationRequest,
				index);
			keyedTemplateDataList.add(keyedTemplateData);
		}
		builder.addAllKeyedTemplateData(keyedTemplateDataList);
		return (PBSyncInsertPayload)buildClass(builder);
	}

	/**
	 * 
	 * @param function
	 * @param afisTemplateSet
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBSyncInsertPayload toPBSyncInsertPayload(
		AfisRegistrationFunctionEnum function,
		AfisTemplateSet afisTemplateSet)
		throws NoInitializedException, InvalidParameterException {
		List<PBKeyedTemplateData> keyedTemplateDataList = new ArrayList<>();
		Integer afisGroupId = null;
		int firstScope = -1;
		for (KeyedTemplate keyedTemplate : nullToList(afisTemplateSet.getTemplate())) {
			TemplateMetadata metadata = keyedTemplate.getMetadata();
			validateNumAfisGroupId(metadata);

			if (0 < keyedTemplate.getMetadata().getAfisGroupId().size()) {
				afisGroupId = keyedTemplate.getMetadata().getAfisGroupId().get(0);
				if (firstScope == -1) {
					firstScope = afisGroupId.intValue();
				} else if (firstScope != afisGroupId.intValue()) {
					throw new InvalidParameterException(
						"An invalid parameter: there is a invalid group ID.");
				}
			}

			PBKeyedTemplateData keyedTemplateData = toPBKeyedTemplateData(keyedTemplate);
			keyedTemplateDataList.add(keyedTemplateData);
		}
		PBSyncInsertPayload.Builder builder = PBSyncInsertPayload.newBuilder();
		if (afisGroupId != null) {
			builder.setScope(afisGroupId.intValue());
		}
		builder.addAllKeyedTemplateData(keyedTemplateDataList);
		return (PBSyncInsertPayload)buildClass(builder);
	}

	/**
	 * convert the parameter of xU methods to a PBSyncInsertPayload.
	 * 
	 * @param function
	 * @param afisTemplateSet
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBSyncInsertPayload toPBSyncInsertPayload(
		AfisUpdateFunctionEnum function,
		AfisTemplateSet afisTemplateSet)
		throws NoInitializedException, InvalidParameterException {
		if (function == AfisUpdateFunctionEnum.TU) {
			validateFunctionToKey(AfisRegistrationFunctionEnum.TR, afisTemplateSet);
			return toPBSyncInsertPayload(AfisRegistrationFunctionEnum.TR, afisTemplateSet);
		} else if (function == AfisUpdateFunctionEnum.LU) {
			validateFunctionToKey(AfisRegistrationFunctionEnum.LR, afisTemplateSet);
			return toPBSyncInsertPayload(AfisRegistrationFunctionEnum.LR, afisTemplateSet);
		} else if (function == AfisUpdateFunctionEnum.LUS) {
			validateFunctionToKey(AfisRegistrationFunctionEnum.LRS, afisTemplateSet);
			return toPBSyncInsertPayload(AfisRegistrationFunctionEnum.LRS, afisTemplateSet);
		} else if (function == AfisUpdateFunctionEnum.LUM) {
			validateFunctionToKey(AfisRegistrationFunctionEnum.LRM, afisTemplateSet);
			return toPBSyncInsertPayload(AfisRegistrationFunctionEnum.LRM, afisTemplateSet);
		} else if (function == AfisUpdateFunctionEnum.LUP) {
			validateFunctionToKey(AfisRegistrationFunctionEnum.LRP, afisTemplateSet);
			return toPBSyncInsertPayload(AfisRegistrationFunctionEnum.LRP, afisTemplateSet);
		} else if (function == AfisUpdateFunctionEnum.LUX) {
			validateFunctionToKey(AfisRegistrationFunctionEnum.LRX, afisTemplateSet);
			return toPBSyncInsertPayload(AfisRegistrationFunctionEnum.LRX, afisTemplateSet);
		} else if (function == AfisUpdateFunctionEnum.FU) {
			validateFunctionToKey(AfisRegistrationFunctionEnum.FR, afisTemplateSet);
			return toPBSyncInsertPayload(AfisRegistrationFunctionEnum.FR, afisTemplateSet);
		} else if (function == AfisUpdateFunctionEnum.IU) {
			validateFunctionToKey(AfisRegistrationFunctionEnum.IR, afisTemplateSet);
			return toPBSyncInsertPayload(AfisRegistrationFunctionEnum.IR, afisTemplateSet);
		}
		// never come in.
		return null;
	}

	/**
	 * 
	 * @param record
	 * @param templateFormatType
	 * @param index
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBKeyedTemplateData toPBKeyedTemplateData(
		RegistrationRequest registrationRequest,
		Map<Integer, Integer> index)
		throws NoInitializedException, InvalidParameterException {
		Record record = registrationRequest.getRecord();
		if (record.getReference() == null && record.getBinary() == null) {
			throw new InvalidParameterException(
				"An invalid parameter: there are binary and reference data.");
		}

		int remainder = registrationRequest.getDestinationContainer() % 1000;
		TemplateFormatType templateFormatType = getValue(Integer.valueOf(remainder),
			intToTemplateFormatType);
		String containerIdToKey = getValue(Integer.valueOf(remainder), intContainerIdToString);

		PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();
		if (record.getReference() != null) {
			builder.setKeyedReferenece(toPBKeyedTemplateReference(containerIdToKey, record
				.getReference()));
			return (PBKeyedTemplateData)buildClass(builder);
		}

		PBKeyedTemplate.Builder keyedTemplateBuilder = PBKeyedTemplate.newBuilder();

		PBKeyedTemplateIndexer indexer = null;
		if (templateFormatType == TemplateFormatType.TEMPLATE_RDBL
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBLS
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBLM
			|| templateFormatType == TemplateFormatType.TEMPLATE_PDB
			|| templateFormatType == TemplateFormatType.TEMPLATE_FDB) {

			Integer number = index.get(Integer.valueOf(remainder));
			index.put(Integer.valueOf(remainder), Integer.valueOf(number.intValue() + 1));
			indexer = toPBKeyedTemplateIndexer(new StringBuilder(containerIdToKey).append(number)
				.toString(), templateFormatType);
			keyedTemplateBuilder.setIndexer(indexer);
		} else {
			indexer = toPBKeyedTemplateIndexer(containerIdToKey, templateFormatType);
			keyedTemplateBuilder.setIndexer(indexer);
		}

		builder.setKeyedTemplate(toPBKeyedTemplate(record.getBinary(), templateFormatType,
			indexer));
		return (PBKeyedTemplateData)buildClass(builder);
	}

	/**
	 * 
	 * @param keyedTemplate
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBKeyedTemplateData toPBKeyedTemplateData(KeyedTemplate keyedTemplate)
		throws NoInitializedException, InvalidParameterException {
		PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();
		TemplateFormatType templateFormatType = getValue(keyedTemplate.getKey(),
			stringToTemplateFormatTypeForRegistration);

		PBKeyedTemplate.Builder keyedTemplateBuilder = PBKeyedTemplate.newBuilder();
		PBKeyedTemplateIndexer indexer = null;
		if (templateFormatType == TemplateFormatType.TEMPLATE_RDBT
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBTM
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBL
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBLS
			|| templateFormatType == TemplateFormatType.TEMPLATE_RDBLM
			|| templateFormatType == TemplateFormatType.TEMPLATE_PDB
			|| templateFormatType == TemplateFormatType.TEMPLATE_FDB) {
			indexer = toPBKeyedTemplateIndexer(keyedTemplate.getKey(), templateFormatType);
			keyedTemplateBuilder.setIndexer(indexer);
		}
		builder.setKeyedTemplate(toPBKeyedTemplate(keyedTemplate.getBinary(), templateFormatType,
			indexer));
		return (PBKeyedTemplateData)buildClass(builder);
	}

	/**
	 * 
	 * @param searchRequest
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBKeyedTemplateData toPBKeyedTemplateData(
		SearchRequest searchRequest,
		Map<TemplateFormatType, Integer> fingerPrintTypeMap)
		throws NoInitializedException, InvalidParameterException {
		PBKeyedTemplateData.Builder dataBuilder = PBKeyedTemplateData.newBuilder();
		if (searchRequest.getRecord() == null) {
			throw new InvalidParameterException(
				"An invalid parameter: there are binary and reference data.");
		}
		Record record = searchRequest.getRecord();
		if (record.getReference() != null) {
			if (record.getBinary() != null) {
				throw new InvalidParameterException(
					"An invalid parameter: there are binary and reference data.");
			}
			PBKeyedTemplateReference.Builder referenceBuilder = PBKeyedTemplateReference
				.newBuilder();
			referenceBuilder.setJobId(record.getReference().getJobId());

			String key = record.getReference().getKey();
			TemplateFormatType templateFormatType = getValue(key,
				stringSearchTemplateToTemplateFormatTypeForGetBinary);
			referenceBuilder.setKey(templateFormatType);

			if (templateFormatType == TemplateFormatType.TEMPLATE_TI
				|| templateFormatType == TemplateFormatType.TEMPLATE_TIM
				|| templateFormatType == TemplateFormatType.TEMPLATE_TLI
				|| templateFormatType == TemplateFormatType.TEMPLATE_TLIS
				|| templateFormatType == TemplateFormatType.TEMPLATE_TLIM
				|| templateFormatType == TemplateFormatType.TEMPLATE_FI) {
				referenceBuilder.setIndexer(toPBKeyedTemplateIndexer(key, templateFormatType));
			}

			dataBuilder.setKeyedReferenece(referenceBuilder);
		} else {
			PBKeyedTemplate.Builder templateBuilder = PBKeyedTemplate.newBuilder();
			templateBuilder.setKey(getValue(Strings.nullToEmpty(searchRequest.getFunctionName()),
				functionNameToTemplateFormatType));
			if (record.getBinary() != null) {
				templateBuilder.setTemplateBinary(ByteString.copyFrom(record.getBinary()));
			}

			if (templateBuilder.getKey() == TemplateFormatType.TEMPLATE_TI || templateBuilder
				.getKey() == TemplateFormatType.TEMPLATE_TIM || templateBuilder
					.getKey() == TemplateFormatType.TEMPLATE_TLI || templateBuilder
						.getKey() == TemplateFormatType.TEMPLATE_TLIS || templateBuilder
							.getKey() == TemplateFormatType.TEMPLATE_TLIM) {
				Integer index = fingerPrintTypeMap.get(templateBuilder.getKey());
				FingerPrintType type = index.intValue() == 1 ? FingerPrintType.FINGER_PRINT_ROLLED
					: FingerPrintType.FINGER_PRINT_SLAP;
				fingerPrintTypeMap.put(templateBuilder.getKey(), Integer.valueOf(index.intValue()
					+ 1));

				PBKeyedTemplateIndexer.Builder indexBuilder = PBKeyedTemplateIndexer.newBuilder();
				templateBuilder.setIndexer(indexBuilder.setFingerPrintType(type));
			}
			dataBuilder.setKeyedTemplate(templateBuilder);
		}
		return (PBKeyedTemplateData)buildClass(dataBuilder);
	}

	/**
	 * 
	 * @param reference
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBKeyedTemplateReference toPBKeyedTemplateReference(
		String containerIdToKey,
		ExtractResultReference reference)
		throws NoInitializedException, InvalidParameterException {
		PBKeyedTemplateReference.Builder builder = PBKeyedTemplateReference.newBuilder();
		builder.setJobId(reference.getJobId());
		TemplateFormatType templateFormatType = getValue(reference.getKey(),
			stringToTemplateFormatTypeForInsert);

		if (!reference.getKey().startsWith(containerIdToKey)) {
			throw new InvalidParameterException(
				"An invalid parameter: a combination of container ID and key.");
		}

		builder.setKey(templateFormatType);
		if (templateFormatType != TemplateFormatType.TEMPLATE_IDB) {
			builder.setIndexer(toPBKeyedTemplateIndexer(reference.getKey(), templateFormatType));
		}
		return builder.build();
	}

	/**
	 * 
	 * @param function
	 * @param afisTemplateSet
	 * @throws InvalidParameterException
	 */
	private static void validateFunctionToKey(
		AfisRegistrationFunctionEnum function,
		AfisTemplateSet afisTemplateSet)
		throws InvalidParameterException {
		if (function == AfisRegistrationFunctionEnum.TR) {
			List<KeyedTemplate> keyedTemplates = nullToList(afisTemplateSet.getTemplate());
			boolean match = false;
			for (KeyedTemplate keyedTemplate : keyedTemplates) {
				for (String key : compareKeysOnTr) {
					if (keyedTemplate.getKey().equals(key)) {
						match = true;
						break;
					}
				}
				if (!match) {
					throw new InvalidParameterException(new StringBuilder(
						"An invalid parameter: there is a invalid key as ").append(keyedTemplate
							.getKey()).append(".").toString());
				}
				match = false;
			}
			return;
		}

		if (function == AfisRegistrationFunctionEnum.FR) {
			List<KeyedTemplate> keyedTemplates = nullToList(afisTemplateSet.getTemplate());
			boolean match = false;
			for (KeyedTemplate keyedTemplate : keyedTemplates) {
				for (String key : compareKeysOnFr) {
					if (keyedTemplate.getKey().equals(key)) {
						match = true;
						break;
					}
				}
				if (!match) {
					throw new InvalidParameterException(new StringBuilder(
						"An invalid parameter: there is a invalid key as ").append(keyedTemplate
							.getKey()).append(".").toString());
				}
				match = false;
			}
			return;
		}

		List<String> compareKeys = new ArrayList<>();
		if (function == AfisRegistrationFunctionEnum.LR) {
			compareKeys.add("LR");
		} else if (function == AfisRegistrationFunctionEnum.LRS) {
			compareKeys.add("LRS");
		} else if (function == AfisRegistrationFunctionEnum.LRM) {
			compareKeys.add("LRM");
		} else if (function == AfisRegistrationFunctionEnum.LRP) {
			compareKeys.add("LRP");
		} else if (function == AfisRegistrationFunctionEnum.LRX) {
			compareKeys.add("LRX");
		} else if (function == AfisRegistrationFunctionEnum.IR) {
			compareKeys.add("IDB");
		}
		List<KeyedTemplate> keyedTemplates = nullToList(afisTemplateSet.getTemplate());
		boolean match = false;
		for (KeyedTemplate keyedTemplate : keyedTemplates) {
			for (String key : compareKeys) {
				if (keyedTemplate.getKey().equals(key)) {
					match = true;
					break;
				}
			}
			if (!match) {
				throw new InvalidParameterException(new StringBuilder(
					"An invalid parameter: there is a invalid key as ").append(keyedTemplate
						.getKey()).append(".").toString());
			}
			match = false;
		}
	}

	/**
	 * 
	 * @param metadata
	 * @throws InvalidParameterException
	 */
	private static void validateNumAfisGroupId(TemplateMetadata metadata)
		throws InvalidParameterException {
		if (metadata == null) {
			return;
		}
		if (1 < nullToList(metadata.getAfisGroupId()).size()) {
			throw new InvalidParameterException(
				"An invalid parameter: the number of afis group IDs.");
		}
	}

	/**
	 * DynamicXML to String
	 * 
	 * @param dynamicXML
	 * @return
	 */
	private static String toString(DynamicXml dynamicXML)
		throws UnmarshalException {
		try {
			StringWriter sw = new StringWriter();
			Transformer trans = TransformerFactory.newInstance().newTransformer();
			trans.transform(new DOMSource(dynamicXML.getAny()), new StreamResult(sw));
			return sw.toString();
		} catch (TransformerException e) {
			throw new UnmarshalException(Throwables.getStackTraceAsString(e));
		}
	}

	/**
	 * 
	 * @param tenprintInput
	 * @return
	 * @throws InvalidPayloadException
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractTenprintInput toPBExtractTenprintInput(TenprintInput tenprintInput)
		throws InvalidPayloadException, NoInitializedException, InvalidParameterException {
		PBExtractTenprintInput.Builder builder = PBExtractTenprintInput.newBuilder();
		// At first, call toPBExtractInputImage for RDBL or RDBLS multi-FE.
		if (tenprintInput.getImages() != null) {
			builder.addAllImages(toPBExtractInputImage(tenprintInput.getImages()));
		}
		builder.addAllAimFormats(toPBAimFormat(tenprintInput, builder.getImagesList()));
		builder.addAllMinutia(toPBExtractInputMinutiaTenprint(tenprintInput.getInputMinutia()));
		if (tenprintInput.getMetaInfo() != null) {
			builder.setMetaInfo(toPBMetaInfo(tenprintInput.getMetaInfo()));
		}
		if (tenprintInput.getPrefilterOptions() != null) {
			builder.setPrefilterOptions(toPBPrefilterOptions(tenprintInput.getPrefilterOptions()));
		}
		if (tenprintInput.getEnhancements() != null) {
			builder.setBasicEnhanceOptions(toPBBasicImageEnhanceOptions(tenprintInput
				.getEnhancements()));
		}
		if (tenprintInput.getQcInput() != null) {
			builder.setQualityCheckOptions(toPBQualityCheckOptions(tenprintInput.getQcInput()));
		}
		if (tenprintInput.getCmlafExtOptions() != null) {
			builder.setCmalfOptions(toPBExtractCMLaFOptions(tenprintInput.getCmlafExtOptions()));
		}
		if (tenprintInput.getCmlExtOptions() != null) {
			builder.setCmlOptions(toPBExtractCMLOptions(tenprintInput.getCmlExtOptions()));
		}

		builder.setCommonOptions(toPBExtractCommonOptionTenprint(tenprintInput));
		return (PBExtractTenprintInput)buildClass(builder);
	}

	/**
	 * 
	 * @param aimFormats
	 * @return
	 * @throws InvalidPayloadException
	 * @throws NoInitializedException
	 */
	private static List<PBAimFormat> toPBAimFormat(
		TenprintInput tenprintInput,
		List<PBExtractInputImage> extractInputImageList)
		throws InvalidPayloadException, NoInitializedException, InvalidParameterException {
		List<PBAimFormat> aimFormatsList = new ArrayList<>();
		if (tenprintInput.getAimformats() == null || tenprintInput.getImages() == null) {
			return aimFormatsList;
		}

		FeTypes feTypes = tenprintInput.getFeTypes();
		for (ExtractionFormats extractionFormat : nullToList(tenprintInput.getAimformats()
			.getFmt())) {
			PBAimFormat.Builder builder = PBAimFormat.newBuilder();
			builder.setFormat(getValue(extractionFormat, extractionFormatsToTemplateFormatType));
			if (builder.getFormat() == TemplateFormatType.TEMPLATE_RDBLX && feTypes != null) {
				builder.addAllFeTypeEvents(toPBExtractFeTypeEvent(feTypes.getXdbl()));
			} else if (builder.getFormat() == TemplateFormatType.TEMPLATE_TLIX && feTypes != null) {
				if (feTypes.getTlix() != null) {
					List<FeTypeTenprint> feTypeTenprintList = new ArrayList<>();
					feTypeTenprintList.add(feTypes.getTlix());
					builder.addAllFeTypeEvents(toPBExtractFeTypeEvent(feTypeTenprintList));
				}
			} else {
				builder.addAllFeTypeEvents(toPBExtractFeTypeEvent(tenprintInput.getImages()
					.getImage(), extractInputImageList));
			}
			aimFormatsList.add((PBAimFormat)buildClass(builder));
		}
		return aimFormatsList;
	}

	/**
	 * 
	 * @param feTypeTenprint
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractFeType> toPBExtractFeType(FeTypeTenprint feTypeTenprint)
		throws NoInitializedException, InvalidParameterException {
		List<PBExtractFeType> extractFeTypeList = new ArrayList<>();
		if (feTypeTenprint.getRolled() != null) {
			PBExtractFeType.Builder builder = PBExtractFeType.newBuilder();
			builder.setFingerType(FingerPrintType.FINGER_PRINT_ROLLED);

			XTemplatePc2 pc2 = feTypeTenprint.getRolled().getPc2();
			if (pc2 != null) {
				builder.setMinutiaType(MinutiaType.MINUTIA_PC2);
				builder.setFisType(getValue(Strings.nullToEmpty(pc2.getFeType()),
					stringToFisTypeType));
				extractFeTypeList.add((PBExtractFeType)buildClass(builder));
			}

			XTemplateFmp5 fmp5 = feTypeTenprint.getRolled().getFmp5();
			if (fmp5 != null) {
				builder.setMinutiaType(MinutiaType.MINUTIA_FMP5);
				builder.setFisType(getValue(Strings.nullToEmpty(fmp5.getFeType()),
					stringToFisTypeType));
				extractFeTypeList.add((PBExtractFeType)buildClass(builder));
			}
		}
		if (feTypeTenprint.getSlap() != null) {
			PBExtractFeType.Builder builder = PBExtractFeType.newBuilder();
			builder.setFingerType(FingerPrintType.FINGER_PRINT_SLAP);

			XTemplatePc2 pc2 = feTypeTenprint.getSlap().getPc2();
			if (pc2 != null) {
				builder.setMinutiaType(MinutiaType.MINUTIA_PC2);
				builder.setFisType(getValue(Strings.nullToEmpty(pc2.getFeType()),
					stringToFisTypeType));
				extractFeTypeList.add((PBExtractFeType)buildClass(builder));
			}

			XTemplateFmp5 fmp5 = feTypeTenprint.getSlap().getFmp5();
			if (fmp5 != null) {
				builder.setMinutiaType(MinutiaType.MINUTIA_FMP5);
				builder.setFisType(getValue(Strings.nullToEmpty(fmp5.getFeType()),
					stringToFisTypeType));
				extractFeTypeList.add((PBExtractFeType)buildClass(builder));
			}
		}
		return extractFeTypeList;
	}

	/**
	 * 
	 * @param feTypeLatent
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractFeType> toPBExtractFeType(FeTypeLatent feTypeLatent)
		throws NoInitializedException, InvalidParameterException {
		List<PBExtractFeType> extractFeTypeList = new ArrayList<>();
		if (feTypeLatent.getLatent() != null) {
			PBExtractFeType.Builder builder = PBExtractFeType.newBuilder();

			XTemplatePc2 pc2 = feTypeLatent.getLatent().getPc2();
			if (pc2 != null) {
				builder.setMinutiaType(MinutiaType.MINUTIA_PC2);
				builder.setFisType(getValue(Strings.nullToEmpty(pc2.getFeType()),
					stringToFisTypeType));
				extractFeTypeList.add((PBExtractFeType)buildClass(builder));
			}

			XTemplateFmp5 fmp5 = feTypeLatent.getLatent().getFmp5();
			if (fmp5 != null) {
				builder.setMinutiaType(MinutiaType.MINUTIA_FMP5);
				builder.setFisType(getValue(Strings.nullToEmpty(fmp5.getFeType()),
					stringToFisTypeType));
				extractFeTypeList.add((PBExtractFeType)buildClass(builder));
			}
		}
		return extractFeTypeList;
	}

	/**
	 * 
	 * @param feType
	 * @param pbExtractInputImage
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractFeType toPBExtractFeType(String feType, FingerPrintType fingerPrintType)
		throws NoInitializedException, InvalidParameterException {
		PBExtractFeType.Builder builder = PBExtractFeType.newBuilder();
		builder.setFingerType(fingerPrintType);
		builder.setFisType(getValue(Strings.nullToEmpty(feType), stringToFisTypeType));
		return (PBExtractFeType)buildClass(builder);
	}

	/**
	 * 
	 * @param feTypeTenprintList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractFeTypeEvent> toPBExtractFeTypeEvent(
		List<FeTypeTenprint> feTypeTenprintList)
		throws NoInitializedException, InvalidParameterException {
		List<PBExtractFeTypeEvent> extractFeTypeEventList = new ArrayList<>();
		PBExtractFeTypeEvent.Builder builder = PBExtractFeTypeEvent.newBuilder();
		int event = 1;
		for (FeTypeTenprint feTypeTenprint : nullToList(feTypeTenprintList)) {
			builder.addAllFeTypes(toPBExtractFeType(feTypeTenprint));
			builder.setEvent(event++);
			extractFeTypeEventList.add((PBExtractFeTypeEvent)buildClass(builder));
			builder.clear();
		}
		return extractFeTypeEventList;
	}

	/**
	 * 
	 * @param feTypeLatent
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractFeTypeEvent toPBExtractFeTypeEvent(FeTypeLatent feTypeLatent)
		throws NoInitializedException, InvalidParameterException {
		PBExtractFeTypeEvent.Builder builder = PBExtractFeTypeEvent.newBuilder();
		List<PBExtractFeType> extractFeTypeList = toPBExtractFeType(feTypeLatent);
		builder.addAllFeTypes(extractFeTypeList);
		builder.setEvent(1);
		return (PBExtractFeTypeEvent)buildClass(builder);
	}

	/**
	 * 
	 * @param inputImageList
	 * @param pbExtractInputImageList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractFeTypeEvent> toPBExtractFeTypeEvent(
		List<InputImage> inputImageList,
		List<PBExtractInputImage> pbExtractInputImageList)
		throws NoInitializedException, InvalidParameterException {
		String rolledFeType = null;
		String slapFeType = null;
		for (int i = 0; i < pbExtractInputImageList.size(); i++) {
			PBExtractInputImage pbExtractInputImage = pbExtractInputImageList.get(i);
			if (pbExtractInputImage.getPosition().name().contains("ROLLED")) {
				rolledFeType = inputImageList.get(i).getFeType();
			} else if (pbExtractInputImage.getPosition().name().contains("SLAP")) {
				slapFeType = inputImageList.get(i).getFeType();
			}
		}

		List<PBExtractFeTypeEvent> pbExtractFeTypeEventList = new ArrayList<>();
		if (rolledFeType == null && slapFeType == null) {
			return pbExtractFeTypeEventList;
		}

		PBExtractFeTypeEvent.Builder builder = PBExtractFeTypeEvent.newBuilder();
		int eventID = 1;
		List<String> rolledFeTypeList = divideFeTypes(rolledFeType);
		List<String> slapFeTypeList = divideFeTypes(slapFeType);
		int feTypeCount = rolledFeTypeList.size();
		if (feTypeCount < slapFeTypeList.size()) {
			feTypeCount = slapFeTypeList.size();
		}
		for (int i = 0; i < feTypeCount; i++) {
			builder.clear();
			builder.setEvent(eventID++);
			if ((i + 1) <= rolledFeTypeList.size()) {
				builder.addFeTypes(toPBExtractFeType(rolledFeTypeList.get(i),
					FingerPrintType.FINGER_PRINT_ROLLED));
			}

			if ((i + 1) <= slapFeTypeList.size()) {
				builder.addFeTypes(toPBExtractFeType(slapFeTypeList.get(i),
					FingerPrintType.FINGER_PRINT_SLAP));
			}
			pbExtractFeTypeEventList.add((PBExtractFeTypeEvent)buildClass(builder));
		}
		return pbExtractFeTypeEventList;
	}

	/**
	 * 
	 * @param image
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractFeTypeEvent> toPBExtractFeTypeEvent(LatentInput.Images image)
		throws NoInitializedException, InvalidParameterException {
		List<PBExtractFeTypeEvent> pbExtractFeTypeEventList = new ArrayList<>();
		PBExtractFeTypeEvent.Builder builder = PBExtractFeTypeEvent.newBuilder();
		if (image.getImage() == null) {
			return pbExtractFeTypeEventList;
		}
		String feType = image.getImage().getFeType();
		if (feType == null) {
			return pbExtractFeTypeEventList;
		}

		int eventID = 1;
		List<String> feTypeList = divideFeTypes(feType);
		PBExtractFeType.Builder feTypeBuilder = PBExtractFeType.newBuilder();
		for (int i = 0; i < feTypeList.size(); i++) {
			builder.clear();
			feTypeBuilder.clear();

			builder.setEvent(eventID++);

			feTypeBuilder.setFisType(getValue(feTypeList.get(i), stringToFisTypeType));
			builder.addFeTypes(feTypeBuilder);
			pbExtractFeTypeEventList.add((PBExtractFeTypeEvent)buildClass(builder));
		}
		return pbExtractFeTypeEventList;
	}

	/**
	 * 
	 * @param images
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractInputImage> toPBExtractInputImage(TenprintInput.Images images)
		throws NoInitializedException, InvalidParameterException {
		List<PBExtractInputImage> extractInputImageList = new ArrayList<>();
		return toPBExtractInputImage(images.getImage(), extractInputImageList);
	}

	/**
	 * 
	 * @param inputImageList
	 * @param extractInputImageList
	 * @return
	 */
	private static List<PBExtractInputImage> toPBExtractInputImage(
		List<InputImage> inputImageList,
		List<PBExtractInputImage> extractInputImageList)
		throws NoInitializedException, InvalidParameterException {
		PBExtractInputImage.Builder builder = PBExtractInputImage.newBuilder();
		for (InputImage inputImage : nullToList(inputImageList)) {
			String pos = inputImage.getPos();
			if (pos != null && !pos.equals("0") && !pos.equals("20")) {
				builder.setPosition(getValue(pos, posToImagePositionType));
			}
			builder.setType(getValue(inputImage.getType(), imageFormatToImageFormatType));
			if (inputImage.getVertScale() != null) {
				builder.setVertScale(inputImage.getVertScale().intValue());
			}
			if (inputImage.getHorizScale() != null) {
				builder.setHorizScale(inputImage.getHorizScale().intValue());
			}
			if (inputImage.getDpi() != null) {
				builder.setDpi(inputImage.getDpi().intValue());
			}
			if (inputImage.getWidth() != null) {
				builder.setWidth(inputImage.getWidth().intValue());
			}
			if (inputImage.getHeight() != null) {
				builder.setHeight(inputImage.getHeight().intValue());
			}
			if (inputImage.getWhiteBlackLevel() != null) {
				builder.setWhiteBlackType(getValue(inputImage.getWhiteBlackLevel(),
					whiteBlackLevelToImageWhiteBlackLevelType));
			}
			if (inputImage.getUrl() != null) {
				builder.setUrl(inputImage.getUrl());
			}
			if (inputImage.getData() != null) {
				builder.setData(ByteString.copyFrom(inputImage.getData()));
			}
			builder.addAllCropCoordinate(toPBFingerCropCoordinate(inputImage.getSegInfo()));
			extractInputImageList.add((PBExtractInputImage)buildClass(builder));
			builder.clear();
		}
		return extractInputImageList;
	}

	/**
	 * 
	 * @param segInfoList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBFingerCropCoordinate> toPBFingerCropCoordinate(List<SegInfo> segInfoList)
		throws NoInitializedException, InvalidParameterException {
		List<PBFingerCropCoordinate> fingerCropCoordinateList = new ArrayList<>();
		for (SegInfo segInfo : segInfoList) {
			PBFingerCropCoordinate.Builder builder = PBFingerCropCoordinate.newBuilder();
			builder.setPosition(getValue(segInfo.getPos(), intToFingerPositionBaseType));

			if (segInfo.isAmp() != null) {
				builder.setAmputated(segInfo.isAmp().booleanValue());
			}

			if (segInfo.getCropInfo() != null) {
				builder.setCropPoints(toPBCropPoint(segInfo.getCropInfo()));
			}
			fingerCropCoordinateList.add((PBFingerCropCoordinate)buildClass(builder));
		}
		return fingerCropCoordinateList;
	}

	/**
	 * 
	 * @param cropInfo
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBCropPoint toPBCropPoint(CropInfo cropInfo)
		throws NoInitializedException, InvalidParameterException {
		PBCropPoint.Builder builder = PBCropPoint.newBuilder();
		if (cropInfo.getCenter() != null) {
			builder.setCenter(toPBPoint(cropInfo.getCenter()));
			if (cropInfo.getCenter().getAngle() != null) {
				builder.setAngle(cropInfo.getCenter().getAngle().floatValue());
			}
		}

		if (cropInfo.getCropPoints() != null) {
			List<PBPoint> pointList = new ArrayList<>();
			for (Point point : nullToList(cropInfo.getCropPoints().getPoints())) {
				pointList.add(toPBPoint(point));
			}
			builder.addAllPoints(pointList);
		}
		return (PBCropPoint)buildClass(builder);
	}

	/**
	 * 
	 * @param point
	 * @return
	 * @throws NoInitializedException
	 */
	private static PBPoint toPBPoint(Point point)
		throws NoInitializedException {
		PBPoint.Builder builder = PBPoint.newBuilder();
		if (point.getX() != null) {
			builder.setX(point.getX().intValue());
		}
		if (point.getY() != null) {
			builder.setY(point.getY().intValue());
		}
		return (PBPoint)buildClass(builder);
	}

	/**
	 * 
	 * @param feType
	 * @return
	 */
	private static List<String> divideFeTypes(String feType) {
		List<String> stringList = new ArrayList<>();
		if (feType == null) {
			return stringList;
		}
		if (!feType.startsWith(MULTI_FE)) {
			stringList.add(feType);
			return stringList;
		}
		int index = feType.indexOf(":");
		return Arrays.asList(Iterables.toArray(Splitter.on(",").split(feType.substring(index + 1)),
			String.class));
	}

	/**
	 * 
	 * @param inputMinutia
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractInputMinutiaTenprint> toPBExtractInputMinutiaTenprint(
		List<TenprintInput.InputMinutia> inputMinutiaList)
		throws NoInitializedException, InvalidParameterException {
		List<PBExtractInputMinutiaTenprint> pbExtractInputMinutiaTenprintList = new ArrayList<>();
		for (TenprintInput.InputMinutia inputMinutia : nullToList(inputMinutiaList)) {
			List<TenprintInput.InputMinutia.InputMinutiaData> inputMinutiaDataList = nullToList(
				inputMinutia.getInputMinutiaData());
			PBExtractInputMinutiaTenprint.Builder tenprintBuilder = PBExtractInputMinutiaTenprint
				.newBuilder();

			tenprintBuilder.setMinutiaType(getValue(inputMinutia.getMinutiaType(),
				stringToMinutiaType));
			tenprintBuilder.setDbType(getValue(inputMinutia.getDbType(), stringToMinutiaDbType));
			tenprintBuilder.addAllMinutiaData(toPBInputMinutiaData(tenprintBuilder.getMinutiaType(),
				inputMinutiaDataList));
			pbExtractInputMinutiaTenprintList.add((PBExtractInputMinutiaTenprint)buildClass(
				tenprintBuilder));
		}
		return pbExtractInputMinutiaTenprintList;
	}

	/**
	 * 
	 * @param inputMinutiaDataList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBInputMinutiaData> toPBInputMinutiaData(
		MinutiaType minutiaType,
		List<TenprintInput.InputMinutia.InputMinutiaData> inputMinutiaDataList)
		throws NoInitializedException, InvalidParameterException {
		List<PBInputMinutiaData> pbInputMinutiaDataList = new ArrayList<>();
		for (TenprintInput.InputMinutia.InputMinutiaData inputMinutiaData : nullToList(
			inputMinutiaDataList)) {
			PBInputMinutiaData.Builder builder = PBInputMinutiaData.newBuilder();
			builder.setPosition(getValue(Strings.nullToEmpty(inputMinutiaData.getPos()),
				posToImagePositionType));
			if (inputMinutiaData.getMinutiaData() != null) {
				builder.setData(ByteString.copyFrom(inputMinutiaData.getMinutiaData()));
			}
			if (minutiaType == MinutiaType.MINUTIA_FIS) {
				builder.setFisData(toPBFisData(inputMinutiaData));
			}
			pbInputMinutiaDataList.add((PBInputMinutiaData)buildClass(builder));
		}
		return pbInputMinutiaDataList;
	}

	/**
	 * 
	 * @param inputMinutiaData
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBFisData toPBFisData(InputMinutiaData inputMinutiaData)
		throws NoInitializedException, InvalidParameterException {
		PBFisData.Builder fisBuilder = PBFisData.newBuilder();
		if (inputMinutiaData.getMinutiaData() != null) {
			fisBuilder.setMinutia(ByteString.copyFrom(inputMinutiaData.getMinutiaData()));
		}
		if (inputMinutiaData.getZone() != null) {
			fisBuilder.setZone((ByteString.copyFrom(inputMinutiaData.getZone())));
		}
		if (inputMinutiaData.getSkeleton() != null) {
			fisBuilder.setSkeleton((ByteString.copyFrom(inputMinutiaData.getSkeleton())));
		}

		TenprintInput.InputMinutia.InputMinutiaData.Core core = inputMinutiaData.getCore();
		if (core == null) {
			// for throwing NoInitializedException
			core = new TenprintInput.InputMinutia.InputMinutiaData.Core();
		}
		fisBuilder.setFisCore(toPBFisCore(core));

		TenprintInput.InputMinutia.InputMinutiaData.Quality quality = inputMinutiaData.getQuality();
		if (quality == null) {
			// for throwing NoInitializedException
			quality = new TenprintInput.InputMinutia.InputMinutiaData.Quality();
		}
		fisBuilder.setFisQuality(toPBFisQuality(quality));

		TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo minutiaNo = inputMinutiaData
			.getMinutiaNo();
		if (minutiaNo == null) {
			// for throwing NoInitializedException
			minutiaNo = new TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo();
		}
		fisBuilder.setFisMinutiaNo(toPBFisMinutiaNo(minutiaNo));

		return (PBFisData)buildClass(fisBuilder);
	}

	/**
	 * 
	 * @param metaInfo
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBMetaInfo toPBMetaInfo(MetaInfo metaInfo)
		throws NoInitializedException, InvalidParameterException {
		PBMetaInfo.Builder builder = PBMetaInfo.newBuilder();
		if (metaInfo.getMetaCommon() != null) {
			builder.setCommon(toPBMetaInfoCommon(metaInfo.getMetaCommon()));
		}
		if (metaInfo.getMetaTenprint() != null) {
			builder.setTenprint(toPBMetaInfoTenprint(metaInfo.getMetaTenprint()));
		}
		if (metaInfo.getMetaLatent() != null) {
			builder.setLatent(toPBMetaInfoLatent(metaInfo.getMetaLatent()));
		}
		return (PBMetaInfo)buildClass(builder);
	}

	/**
	 * 
	 * @param metaCommon
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBMetaInfoCommon toPBMetaInfoCommon(MetaCommon metaCommon)
		throws NoInitializedException, InvalidParameterException {
		PBMetaInfoCommon.Builder builder = PBMetaInfoCommon.newBuilder();
		if (metaCommon.getGender() != null) {
			builder.setGender(getValue(metaCommon.getGender(), genderEnumToGenderType));
		}
		if (metaCommon.getYob() != null) {
			builder.setYob(metaCommon.getYob().intValue());
		}
		if (metaCommon.getYobRange() != null) {
			builder.setYobRange(metaCommon.getYobRange().intValue());
		}
		if (metaCommon.getRace() != null) {
			builder.setRace(getValue(metaCommon.getRace(), stringToRaceType));
		}
		for (char region : Strings.nullToEmpty(metaCommon.getRegion()).toCharArray()) {
			if (region == ',') {
				continue;
			}
			builder.addRegion(getValue(Character.valueOf(region), byteToRegionCodeType));
		}
		return (PBMetaInfoCommon)buildClass(builder);
	}

	/**
	 * 
	 * @param metaTenprint
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBMetaInfoTenprint toPBMetaInfoTenprint(MetaTenprint metaTenprint)
		throws NoInitializedException, InvalidParameterException {
		PBMetaInfoTenprint.Builder builder = PBMetaInfoTenprint.newBuilder();
		for (char pattern : Strings.nullToEmpty(metaTenprint.getPrimaryPatterns()).toCharArray()) {
			builder.addPrimaryPatterns(getValue(Character.valueOf(pattern),
				byteToFingerPatternType));
		}
		for (char pattern : Strings.nullToEmpty(metaTenprint.getReferencePatterns())
			.toCharArray()) {
			builder.addReferencePatterns(getValue(Character.valueOf(pattern),
				byteToFingerPatternType));
		}
		return (PBMetaInfoTenprint)buildClass(builder);
	}

	/**
	 * 
	 * @param metaLatent
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBMetaInfoLatent toPBMetaInfoLatent(MetaLatent metaLatent)
		throws NoInitializedException, InvalidParameterException {
		PBMetaInfoLatent.Builder builder = PBMetaInfoLatent.newBuilder();
		for (char fingerNumber : Strings.nullToEmpty(metaLatent.getSelectFingers()).toCharArray()) {
			int number = Integer.parseInt(new StringBuilder("").append(fingerNumber).toString());
			builder.addSelectFingers(getValue(Integer.valueOf(number),
				intToFingerPositionBaseTypeForSelectFinger));
		}
		for (char part : Strings.nullToEmpty(metaLatent.getSelectParts()).toCharArray()) {
			builder.addSelectParts(getValue(Character.valueOf(part), byteToPalmPositionType));
		}
		for (char pattern : Strings.nullToEmpty(metaLatent.getLatentPatterns()).toCharArray()) {
			builder.addLatentPatterns(getValue(Character.valueOf(pattern),
				byteToFingerPatternType));
		}
		for (char pattern : Strings.nullToEmpty(metaLatent.getPrimaryAdjacentPatterns())
			.toCharArray()) {
			builder.addPrimaryAdjacentPatterns(getValue(Character.valueOf(pattern),
				byteToFingerPatternType));
		}
		for (char pattern : Strings.nullToEmpty(metaLatent.getReferenceAdjacentPatterns())
			.toCharArray()) {
			builder.addReferenceAdjacentPatterns(getValue(Character.valueOf(pattern),
				byteToFingerPatternType));
		}
		return (PBMetaInfoLatent)buildClass(builder);
	}

	/**
	 * 
	 * @param prefilterOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBPrefilterOptions toPBPrefilterOptions(PrefilterOptions prefilterOptions)
		throws NoInitializedException, InvalidParameterException {
		PBPrefilterOptions.Builder builder = PBPrefilterOptions.newBuilder();

		if (prefilterOptions.isUpdatePrefilter() != null) {
			builder.setUpdatePrefilter(prefilterOptions.isUpdatePrefilter().booleanValue());
		}
		if (prefilterOptions.getYobMethod() != null) {
			builder.setYobMethod(getValue(prefilterOptions.getYobMethod(), stringToYobMethodType));
		}
		if (prefilterOptions.isUseYobFRange() != null) {
			builder.setUseYobFRange(prefilterOptions.isUseYobFRange().booleanValue());
		}
		if (prefilterOptions.getUsePrefilterInfo() != null) {
			builder.setUsePrefilterInfo(toPBUsePrefilterInfo(prefilterOptions
				.getUsePrefilterInfo()));
		}
		return (PBPrefilterOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param usePrefilterInfo
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBUsePrefilterInfo toPBUsePrefilterInfo(UsePrefilterInfo usePrefilterInfo)
		throws NoInitializedException, InvalidParameterException {
		PBUsePrefilterInfo.Builder builder = PBUsePrefilterInfo.newBuilder();

		if (usePrefilterInfo.isUseFingerNo() != null) {
			builder.setFingerNo(usePrefilterInfo.isUseFingerNo().booleanValue());
		}
		if (usePrefilterInfo.isUseGender() != null) {
			builder.setGender(usePrefilterInfo.isUseGender().booleanValue());
		}
		if (usePrefilterInfo.isUsePartNo() != null) {
			builder.setPartNo(usePrefilterInfo.isUsePartNo().booleanValue());
		}
		if (usePrefilterInfo.isUsePattern() != null) {
			builder.setPattern(usePrefilterInfo.isUsePattern().booleanValue());
		}
		if (usePrefilterInfo.isUseRace() != null) {
			builder.setRace(usePrefilterInfo.isUseRace().booleanValue());
		}
		if (usePrefilterInfo.isUseRegion() != null) {
			builder.setRegion(usePrefilterInfo.isUseRegion().booleanValue());
		}
		if (usePrefilterInfo.isUseYob() != null) {
			builder.setYob(usePrefilterInfo.isUseYob().booleanValue());
		}
		return (PBUsePrefilterInfo)buildClass(builder);
	}

	/**
	 * 
	 * @param imageEnhance
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBBasicImageEnhanceOptions toPBBasicImageEnhanceOptions(
		ImageEnhance imageEnhance)
		throws NoInitializedException, InvalidParameterException {
		PBBasicImageEnhanceOptions.Builder builder = PBBasicImageEnhanceOptions.newBuilder();
		builder.addAllEnhancements(toListBasicImageEnhanceType(imageEnhance.getEnhType()));
		return (PBBasicImageEnhanceOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param enhancements
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBBasicImageEnhanceOptions toPBBasicImageEnhanceOptions(
		LatentInput.Enhancements enhancements)
		throws NoInitializedException, InvalidParameterException {
		PBBasicImageEnhanceOptions.Builder builder = PBBasicImageEnhanceOptions.newBuilder();
		builder.addAllEnhancements(toListBasicImageEnhanceType(enhancements.getEnhType()));
		return (PBBasicImageEnhanceOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param enhTypeList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<BasicImageEnhanceType> toListBasicImageEnhanceType(
		List<EnhType> enhTypeList)
		throws NoInitializedException, InvalidParameterException {
		List<BasicImageEnhanceType> basicImageEnhanceTypeList = new ArrayList<>();
		for (EnhType enhType : enhTypeList) {
			basicImageEnhanceTypeList.add(getValue(enhType, enhTypeToBasicImageEnhganceType));
		}
		return basicImageEnhanceTypeList;
	}

	/**
	 * 
	 * @param qcInput
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBQualityCheckOptions toPBQualityCheckOptions(QcInput qcInput)
		throws NoInitializedException, InvalidParameterException {
		PBQualityCheckOptions.Builder builder = PBQualityCheckOptions.newBuilder();
		if (qcInput.getQcMode() != null) {
			builder.setQcMode(getValue(qcInput.getQcMode(), qcModeToQualityCheckModeType));
		}
		if (qcInput.getDuplicateCheckThreshold() != null) {
			builder.setDuplicateCheckThreshold(qcInput.getDuplicateCheckThreshold().intValue());
		}
		if (qcInput.getSlapConfidenceThreshold() != null) {
			builder.setSlapConfidenceThreshold(qcInput.getSlapConfidenceThreshold().intValue());
		}
		if (qcInput.getSlapHandConfidenceThreshold() != null) {
			builder.setSlapHandConfidenceThreshold(qcInput.getSlapHandConfidenceThreshold()
				.intValue());
		}
		if (qcInput.getSequenceCheckThreshold() != null) {
			builder.setSequenceCheckThreshold(qcInput.getSequenceCheckThreshold().intValue());
		}
		if (qcInput.getSequenceCheckThresholdLittle() != null) {
			builder.setSequenceCheckThresholdLittle(qcInput.getSequenceCheckThresholdLittle()
				.intValue());
		}
		if (qcInput.getRolledQualityThreshold() != null) {
			builder.setRolledQualityThreshold(qcInput.getRolledQualityThreshold().intValue());
		}
		builder.getSlapHandConfidenceThreshold();
		return (PBQualityCheckOptions)buildClass(builder);
	}

	/**
	 * @param cmlExtOptions
	 * @return
	 * @throws NoInitializedException
	 */
	private static PBExtractCMLOptions toPBExtractCMLOptions(CmlExtOptions cmlExtOptions)
		throws NoInitializedException {
		PBExtractCMLOptions.Builder builder = PBExtractCMLOptions.newBuilder();
		if (cmlExtOptions.getParameterId() != null) {
			builder.setParameterId(cmlExtOptions.getParameterId().intValue());
		}
		return (PBExtractCMLOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param cmlafExtOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractCMLaFOptions toPBExtractCMLaFOptions(CmlafExtOptions cmlafExtOptions)
		throws NoInitializedException, InvalidParameterException {
		PBExtractCMLaFOptions.Builder builder = PBExtractCMLaFOptions.newBuilder();
		builder.setMultiplicity(cmlafExtOptions.getMultiplicity().intValue());
		builder.addAllParams(toPBCMLaFExtractParam(cmlafExtOptions.getTemplateParam()));
		return (PBExtractCMLaFOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param templateParamList
	 * @return
	 * @throws NoInitializedException
	 *             * @throws InvalidParameterException
	 */
	private static List<PBCMLaFExtractParam> toPBCMLaFExtractParam(
		List<TenprintInput.CmlafExtOptions.TemplateParam> templateParamList)
		throws NoInitializedException, InvalidParameterException {
		List<PBCMLaFExtractParam> pbCmlafExtractParamList = new ArrayList<>();
		for (TenprintInput.CmlafExtOptions.TemplateParam templateParam : nullToList(
			templateParamList)) {
			PBCMLaFExtractParam.Builder builder = PBCMLaFExtractParam.newBuilder();
			if (templateParam.getTemplatenum() != null) {
				builder.setTemplateNum(templateParam.getTemplatenum().intValue());
			}
			if (templateParam.getFetype() != null) {
				builder.setFeType(getValue(templateParam.getFetype(), intToCmlafFeTypeType));
			}
			if (templateParam.getLimitofminutiacount() != null) {
				builder.setLimitOfMinutiaCount(templateParam.getLimitofminutiacount().intValue());
			}
			if (templateParam.getEnhancements() != null) {
				for (CmlafEnhType cmlafEnhType : nullToList(templateParam.getEnhancements()
					.getEnhType())) {
					builder.addEnhancements(getValue(cmlafEnhType,
						cmlafEnhTypeToCmlafImageEnhganceType));
				}
			}
			pbCmlafExtractParamList.add((PBCMLaFExtractParam)buildClass(builder));
		}
		return pbCmlafExtractParamList;
	}

	/**
	 * 
	 * @param tenprintInput
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractCommonOptionTenprint toPBExtractCommonOptionTenprint(
		TenprintInput tenprintInput)
		throws NoInitializedException, InvalidParameterException {
		PBExtractCommonOptionTenprint.Builder builder = PBExtractCommonOptionTenprint.newBuilder();
		if (tenprintInput.getExtInfoMode() != null) {
			builder.setOutputMode(getValue(tenprintInput.getExtInfoMode(),
				extInfoModeFormatToExtractOutputModeType));
		}
		if (tenprintInput.isReExtract() != null) {
			builder.setReExtract(tenprintInput.isReExtract().booleanValue());
		}
		if (tenprintInput.isReturnCroppedImages() != null) {
			builder.setReturnCroppedImages(tenprintInput.isReturnCroppedImages().booleanValue());
		}
		if (tenprintInput.isReturnLowResImages() != null) {
			builder.setReturnLowResolutionImages(tenprintInput.isReturnLowResImages()
				.booleanValue());
		}
		return (PBExtractCommonOptionTenprint)buildClass(builder);
	}

	/**
	 * 
	 * @param latentInput
	 * @return
	 * @throws InvalidPayloadException
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractLatentInput toPBExtractLatentInput(LatentInput latentInput)
		throws InvalidPayloadException, NoInitializedException, InvalidParameterException {
		PBExtractLatentInput.Builder builder = PBExtractLatentInput.newBuilder();
		builder.addAllAimFormats(toPBAimFormat(latentInput));
		if (latentInput.getImages() != null && latentInput.getImages().getImage() != null) {
			builder.setImage(toPBExtractInputImage(latentInput.getImages()).get(0));
		}

		if (latentInput.getMinutia() != null) {
			builder.setMinutia(toPBExtractInputMinutiaLatent(latentInput.getMinutia()));
		}
		if (latentInput.getMetaInfo() != null) {
			builder.setMetaInfo(toPBMetaInfo(latentInput.getMetaInfo()));
		}
		if (latentInput.getPrefilterOptions() != null) {
			builder.setPrefilterOptions(toPBPrefilterOptions(latentInput.getPrefilterOptions()));
		}
		if (latentInput.getEnhancements() != null) {
			builder.setBasicEnhanceOptions(toPBBasicImageEnhanceOptions(latentInput
				.getEnhancements()));
		}

		if (latentInput.getExtInfoMode() != null) {
			builder.setCommonOptions(PBExtractCommonOptionLatent.newBuilder().setOutputMode(
				getValue(latentInput.getExtInfoMode(), extInfoModeFormatToExtractOutputModeType)));
		}

		if (latentInput.getMarkUp() != null) {
			builder.setMarkUp(toPBExtractInputMarkUp(latentInput.getMarkUp()));
		}
		return (PBExtractLatentInput)buildClass(builder);
	}

	/**
	 * 
	 * @param latentInput
	 * @return
	 * @throws InvalidPayloadException
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBAimFormat> toPBAimFormat(LatentInput latentInput)
		throws InvalidPayloadException, NoInitializedException, InvalidParameterException {
		List<PBAimFormat> aimFormatsList = new ArrayList<>();
		if (latentInput.getAimformats() == null) {
			return aimFormatsList;
		}
		FeTypes feTypes = latentInput.getFeTypes();
		for (ExtractionFormats extractionFormat : nullToList(latentInput.getAimformats()
			.getFmt())) {
			PBAimFormat.Builder builder = PBAimFormat.newBuilder();
			builder.setFormat(getValue(extractionFormat, extractionFormatsToTemplateFormatType));
			if (builder.getFormat() == TemplateFormatType.TEMPLATE_LDBX) {
				if (feTypes != null && feTypes.getLdbx() != null) {
					builder.addFeTypeEvents(toPBExtractFeTypeEvent(feTypes.getLdbx()));
				}
			} else if (builder.getFormat() == TemplateFormatType.TEMPLATE_LIX) {
				if (feTypes != null && feTypes.getLix() != null) {
					builder.addFeTypeEvents(toPBExtractFeTypeEvent(feTypes.getLix()));
				}
			} else if (builder.getFormat() == TemplateFormatType.TEMPLATE_LLIX) {
				if (feTypes != null && feTypes.getLlix() != null) {
					builder.addFeTypeEvents(toPBExtractFeTypeEvent(feTypes.getLlix()));
				}
			} else {
				if (latentInput.getImages() != null) {
					builder.addAllFeTypeEvents(toPBExtractFeTypeEvent(latentInput.getImages()));
				}
			}
			aimFormatsList.add((PBAimFormat)buildClass(builder));
		}
		return aimFormatsList;
	}

	/**
	 * 
	 * @param facetInput
	 * @return
	 * @throws InvalidPayloadException
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBAimFormat> toPBAimFormat(AimFormats aimFormats)
		throws NoInitializedException, InvalidParameterException {
		List<PBAimFormat> aimFormatsList = new ArrayList<>();
		for (ExtractionFormats extractionFormats : nullToList(aimFormats.getFmt())) {
			PBAimFormat.Builder builder = PBAimFormat.newBuilder();
			aimFormatsList.add((PBAimFormat)buildClass(builder.setFormat(getValue(extractionFormats,
				extractionFormatsToTemplateFormatType))));
		}
		return aimFormatsList;
	}

	/**
	 * 
	 * @param images
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractInputImage> toPBExtractInputImage(LatentInput.Images images)
		throws NoInitializedException, InvalidParameterException {
		List<PBExtractInputImage> extractInputImageList = new ArrayList<>();
		List<InputImage> inputImageList = new ArrayList<>();
		inputImageList.add(images.getImage());
		return toPBExtractInputImage(inputImageList, extractInputImageList);
	}

	/**
	 * 
	 * @param minutiaType
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractInputMinutiaLatent toPBExtractInputMinutiaLatent(
		jp.co.nec.aim.mm.jaxb.MinutiaType minutiaType)
		throws NoInitializedException, InvalidParameterException {
		PBExtractInputMinutiaLatent.Builder builder = PBExtractInputMinutiaLatent.newBuilder();
		builder.setType(getValue(Strings.nullToEmpty(minutiaType.getMinutiaType()),
			stringToMinutiaType));
		if (minutiaType.getData() != null) {
			builder.setMinutiaData(ByteString.copyFrom(minutiaType.getData()));
		}
		return (PBExtractInputMinutiaLatent)buildClass(builder);
	}

	/**
	 * 
	 * @param markUp
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractInputMarkUp toPBExtractInputMarkUp(MarkUp markUp)
		throws NoInitializedException, InvalidParameterException {
		PBExtractInputMarkUp.Builder builder = PBExtractInputMarkUp.newBuilder();
		if (markUp.getData() != null) {
			builder.setMarkUpData(ByteString.copyFrom(markUp.getData()));
		}
		return (PBExtractInputMarkUp)buildClass(builder);
	}

	/**
	 * 
	 * @param faceInput
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractFaceInput toPBExtractFaceInput(FaceInput faceInput)
		throws NoInitializedException, InvalidParameterException {
		PBExtractFaceInput.Builder builder = PBExtractFaceInput.newBuilder();
		if (faceInput.getProcessMode() != null) {
			builder.setProcess(getValue(faceInput.getProcessMode(),
				faceProcessModeToFaceExtractProcessType));
		}
		if (faceInput.getAimformats() != null) {
			builder.addAllAimFormats(toPBAimFormat(faceInput.getAimformats()));
		}
		if (faceInput.getMetaInfo() != null) {
			builder.setMetaInfo(toPBMetaInfo(faceInput.getMetaInfo()));
		}
		if (faceInput.getPrefilterOptions() != null) {
			builder.setPrefilterOptions(toPBPrefilterOptions(faceInput.getPrefilterOptions()));
		}
		if (faceInput.getImage() != null) {
			builder.setImage(toPBExtractInputImage(faceInput.getImage()));
		}
		if (faceInput.getDetection() != null) {
			builder.setDetection(toPBExtractInputFaceDetection(faceInput.getDetection()));
		}
		if (faceInput.getExtraction() != null) {
			builder.setExtraction(toPBExtractInputFaceExtraction(faceInput.getExtraction()));
		}

		return (PBExtractFaceInput)buildClass(builder);
	}

	/**
	 * 
	 * @param image
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractInputImage toPBExtractInputImage(FaceInputImage image)
		throws NoInitializedException, InvalidParameterException {
		PBExtractInputImage.Builder builder = PBExtractInputImage.newBuilder();
		builder.setType(getValue(image.getType(), imageFormatToImageFormatType));
		if (image.getWidth() != null) {
			builder.setWidth(image.getWidth().intValue());
		}
		if (image.getHeight() != null) {
			builder.setHeight(image.getHeight().intValue());
		}
		if (image.getUrl() != null) {
			builder.setUrl(image.getUrl());
		}
		if (image.getData() != null) {
			builder.setData(ByteString.copyFrom(image.getData()));
		}
		return (PBExtractInputImage)buildClass(builder);
	}

	/**
	 * 
	 * @param faceInputDetection
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractInputFaceDetection toPBExtractInputFaceDetection(
		FaceInputDetection faceInputDetection)
		throws NoInitializedException, InvalidParameterException {
		PBExtractInputFaceDetection.Builder builder = PBExtractInputFaceDetection.newBuilder();
		if (faceInputDetection.getMode() != null) {
			builder.setMode(getValue(faceInputDetection.getMode(),
				detectionModeToFaceDetectionModeType));
		}
		if (faceInputDetection.getFaceMaxNum() != null) {
			builder.setFaceMaxNum(faceInputDetection.getFaceMaxNum().intValue());
		}
		if (faceInputDetection.getSortingOrder() != null) {
			builder.setSortingOrder(getValue(faceInputDetection.getSortingOrder(),
				sortingOrderToFaceDetectionSortingOrderType));
		}
		if (faceInputDetection.isImageAnalysis() != null) {
			builder.setImageAnalysis(faceInputDetection.isImageAnalysis().booleanValue());
		}
		builder.addAllDetectionParam(toPBFaceDetectionParams(faceInputDetection.getParams()));
		builder.addAllFace2Points(toPBFace2Points(faceInputDetection.getPoints()));

		if (faceInputDetection.getNegativeDetectionParams() != null) {
			builder.getNegativeDetectionParamBuilder().setQualityThreshold(faceInputDetection
				.getNegativeDetectionParams().getQualityThreshold());
			builder.getNegativeDetectionParamBuilder().setMatchingScoreThreshold(faceInputDetection
				.getNegativeDetectionParams().getMatchingScoreThreshold());
		}

		return (PBExtractInputFaceDetection)buildClass(builder);
	}

	/**
	 * 
	 * @param paramsList
	 * @return
	 */
	private static List<PBFaceDetectionParam> toPBFaceDetectionParams(
		List<FaceInputParams> paramsList)
		throws NoInitializedException, InvalidParameterException {
		List<PBFaceDetectionParam> pbFaceDetectionParamList = new ArrayList<>();
		for (FaceInputParams faceInputParams : paramsList) {
			PBFaceDetectionParam.Builder builder = PBFaceDetectionParam.newBuilder();
			builder.setAttempt(faceInputParams.getNum());
			if (faceInputParams.getAlgorithm() != null) {
				builder.setAlgorithm(getValue(faceInputParams.getAlgorithm(),
					detectionAlgorithmToFaceDetectionAlgorithmType));
			}
			if (faceInputParams.getReliability() != null) {
				builder.setReliability(faceInputParams.getReliability().doubleValue());
			}
			if (faceInputParams.getEyeMin() != null) {
				builder.setEyeMin(faceInputParams.getEyeMin().doubleValue());
			}
			if (faceInputParams.getEyeMax() != null) {
				builder.setEyeMax(faceInputParams.getEyeMax().doubleValue());
			}
			if (faceInputParams.getEyeRotation() != null) {
				builder.setEyeRotation(faceInputParams.getEyeRotation().intValue());
			}
			if (faceInputParams.getFaceRotation() != null) {
				builder.addAllRotation(getValue(faceInputParams.getFaceRotation(),
					faceRotationToListFaceDetectionRotationType));
			}
			if (faceInputParams.getShrinkFactor() != null) {
				builder.setShrinkFactor(getValue(faceInputParams.getShrinkFactor(),
					shrinkFactorToFaceDetectionShrinkFactorType));
			}
			pbFaceDetectionParamList.add((PBFaceDetectionParam)buildClass(builder));
		}
		return pbFaceDetectionParamList;
	}

	/**
	 * 
	 * @param pointsList
	 * @return
	 * @throws NoInitializedException
	 */
	private static List<PBFace2Points> toPBFace2Points(List<Face2Points> pointsList)
		throws NoInitializedException {
		List<PBFace2Points> pbFace2PointsList = new ArrayList<>();
		for (Face2Points face2Points : pointsList) {
			PBFace2Points.Builder builder = PBFace2Points.newBuilder();
			builder.setFaceNumber(face2Points.getNum());
			builder.setRightEyeCenter(toPBPoint(face2Points.getRightEyeCenter()));
			builder.setLeftEyeCenter(toPBPoint(face2Points.getLeftEyeCenter()));
			pbFace2PointsList.add((PBFace2Points)buildClass(builder));
		}
		return pbFace2PointsList;
	}

	/**
	 * 
	 * @param point
	 * @return
	 * @throws NoInitializedException
	 */
	private static PBPoint toPBPoint(FacePoint point)
		throws NoInitializedException {
		PBPoint.Builder builder = PBPoint.newBuilder();
		if (point == null) {
			// for throwing NoInitializedException
			point = new FacePoint();
		}
		if (point.getX() != null) {
			builder.setX(point.getX().intValue());
		}
		if (point.getY() != null) {
			builder.setY(point.getY().intValue());
		}
		return (PBPoint)buildClass(builder);
	}

	/**
	 * 
	 * @param extraction
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractInputFaceExtraction toPBExtractInputFaceExtraction(
		FaceInputExtraction extraction)
		throws NoInitializedException, InvalidParameterException {
		PBExtractInputFaceExtraction.Builder builder = PBExtractInputFaceExtraction.newBuilder();
		builder.addAllExtractionParam(toPBFaceExtractionParam(extraction.getPoints()));
		return (PBExtractInputFaceExtraction)buildClass(builder);
	}

	/**
	 * 
	 * @param pointsList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBFaceExtractionParam> toPBFaceExtractionParam(
		List<FaceInputExtraction13Points> pointsList)
		throws NoInitializedException, InvalidParameterException {
		List<PBFaceExtractionParam> pbFaceExtractionParamList = new ArrayList<>();
		for (FaceInputExtraction13Points points : pointsList) {
			PBFaceExtractionParam.Builder builder = PBFaceExtractionParam.newBuilder();
			builder.setFaceNumber(points.getNum());
			if (points.getMetaInfo() != null) {
				builder.setMetaInfo(toPBMetaInfo(points.getMetaInfo()));
			}
			if (points.getPrefilterOptions() != null) {
				builder.setPrefilterOptions(toPBPrefilterOptions(points.getPrefilterOptions()));
			}
			builder.setFace13Points(toPBFace13Points(points));
			pbFaceExtractionParamList.add((PBFaceExtractionParam)buildClass(builder));
		}
		return pbFaceExtractionParamList;
	}

	/**
	 * 
	 * @param points
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBFace13Points toPBFace13Points(FaceInputExtraction13Points points)
		throws NoInitializedException, InvalidParameterException {
		PBFace13Points.Builder builder = PBFace13Points.newBuilder();
		if (points.getRightEyeCenter() != null) {
			builder.setRightEyeCenter(toPBPoint(points.getRightEyeCenter()));
		}
		if (points.getLeftEyeCenter() != null) {
			builder.setLeftEyeCenter(toPBPoint(points.getLeftEyeCenter()));
		}
		if (points.getRightEyeInnerCorner() != null) {
			builder.setRightEyeInnerCorner(toPBPoint(points.getRightEyeInnerCorner()));
		}
		if (points.getLeftEyeInnerCorner() != null) {
			builder.setLeftEyeInnerCorner(toPBPoint(points.getLeftEyeInnerCorner()));
		}
		if (points.getRightEyeOuterCorner() != null) {
			builder.setRightEyeOuterCorner(toPBPoint(points.getRightEyeOuterCorner()));
		}
		if (points.getLeftEyeOuterCorner() != null) {
			builder.setLeftEyeOuterCorner(toPBPoint(points.getLeftEyeOuterCorner()));
		}
		if (points.getCenterBelowNose() != null) {
			builder.setCenterBelowNose(toPBPoint(points.getCenterBelowNose()));
		}
		if (points.getRightSideNose() != null) {
			builder.setRightSideNose(toPBPoint(points.getRightSideNose()));
		}
		if (points.getLeftSideNose() != null) {
			builder.setLeftSideNose(toPBPoint(points.getLeftSideNose()));
		}
		if (points.getRightCornerMouth() != null) {
			builder.setRightCornerMouth(toPBPoint(points.getRightCornerMouth()));
		}
		if (points.getLeftCornerMouth() != null) {
			builder.setLeftCornerMouth(toPBPoint(points.getLeftCornerMouth()));
		}
		if (points.getTopCenterUpperLip() != null) {
			builder.setTopCenterUpperLip(toPBPoint(points.getTopCenterUpperLip()));
		}
		if (points.getBottomCenterUpperLip() != null) {
			builder.setBottomCenterUpperLip(toPBPoint(points.getBottomCenterUpperLip()));
		}
		return (PBFace13Points)buildClass(builder);
	}

	/**
	 * 
	 * @param preselectionOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBPreselectionOptions toPBPreselectionOptions(
		PreselectionOptions preselectionOptions)
		throws NoInitializedException, InvalidParameterException {
		PBPreselectionOptions.Builder builder = PBPreselectionOptions.newBuilder();
		if (preselectionOptions.getCardQualityThreshold() != null) {
			builder.setCardQualityThreshold(preselectionOptions.getCardQualityThreshold()
				.shortValue());
		}
		if (preselectionOptions.isUsePSR8FingerSlap() != null) {
			builder.setUsePsr8FingerSlap(preselectionOptions.isUsePSR8FingerSlap().booleanValue());
		}
		if (preselectionOptions.getFilterMode() != null) {
			builder.setFilterMode(getValue(preselectionOptions.getFilterMode(),
				stringToFilterModeType));
		}
		if (BooleanUtils.isTrue(preselectionOptions.isApplyPatternThreshold())) {
			if (preselectionOptions.getPatternThreshold() != null) {
				builder.setPatternThreshold(preselectionOptions.getPatternThreshold().floatValue());
			}
		}
		if (BooleanUtils.isTrue(preselectionOptions.isApplyYobThreshold())) {
			if (preselectionOptions.getYobThreshold() != null) {
				builder.setYobThreshold(preselectionOptions.getYobThreshold().shortValue());
			}
		}
		if (BooleanUtils.isTrue(preselectionOptions.isApplyFingerSelectionMode())) {
			if (preselectionOptions.getFingerSelectionMode() != null) {
				builder.setFingerSelectionMode(getValue(preselectionOptions
					.getFingerSelectionMode(), stringToFingerSelectionModeType));
			}
		}
		if (preselectionOptions.getCandidateVerificationThreshold() != null) {
			builder.setCandidateVerificationThreshold(preselectionOptions
				.getCandidateVerificationThreshold().shortValue());
		}
		return (PBPreselectionOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param pc2Options
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBPc2Options toPBPc2Options(Pc2Options pc2Options)
		throws NoInitializedException, InvalidParameterException {
		PBPc2Options.Builder builder = PBPc2Options.newBuilder();
		if (BooleanUtils.isTrue(pc2Options.isApplySpeedLevel())) {
			if (pc2Options.getSpeedLevel() != null) {
				builder.setSpeedLevel(getValue(pc2Options.getSpeedLevel(),
					stringToPc2SpeedLevelType));
			}
		}
		if (BooleanUtils.isTrue(pc2Options.isApplyRotationLimit())) {
			if (pc2Options.getRotationLimit() != null) {
				builder.setRotationLimit(ConvertCommon.getValue(pc2Options.getRotationLimit(),
					stringToPc2RotationLimitType));
			}
		}
		if (BooleanUtils.isTrue(pc2Options.isApplyDistortionLevel())) {
			if (pc2Options.getDistortionLevel() != null) {
				builder.setDistortionLevel(getValue(pc2Options.getDistortionLevel(),
					stringToPc2DistortionLevelType));
			}
		}
		if (pc2Options.isRotationByAxis() != null) {
			builder.setRotationByAxis(pc2Options.isRotationByAxis().booleanValue());
		}
		return (PBPc2Options)buildClass(builder);
	}

	/**
	 * 
	 * @param leOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBLeOptions toPBLeOptions(LeOptions leOptions)
		throws NoInitializedException, InvalidParameterException {
		PBLeOptions.Builder builder = PBLeOptions.newBuilder();

		if (leOptions.getAlgorithm() != null) {
			builder.setAlgorithm(getValue(leOptions.getAlgorithm(), stringToLeAlgorithmType));
		}
		if (leOptions.getRotationLimit() != null) {
			builder.setRotationLimit(getValue(leOptions.getRotationLimit(),
				stringToLeRotationLimitType));
		}
		if (leOptions.getCorePosition() != null) {
			builder.setCorePosition(getValue(leOptions.getCorePosition(),
				stringToLeCorePositionType));
		}
		return (PBLeOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param palmOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static void toPBPalmOptions(
		PalmOptions palmOptions,
		PBInquiryPayload.Builder payloadBuilder)
		throws NoInitializedException, InvalidParameterException {
		if (!BooleanUtils.isTrue(palmOptions.isApplyPalmOptions())) {
			return;
		}
		payloadBuilder.clearPalmOptions();
		PBPalmOptions.Builder builder = payloadBuilder.getPalmOptionsBuilder();

		if (palmOptions.getRotationLimit() != null) {
			builder.setRotationLimit(getValue(palmOptions.getRotationLimit(),
				stringToPalmRotationLimitType));
		}
		if (palmOptions.getSpeedLevelPrimary() != null) {
			builder.setSpeedLevelPrimary(getValue(palmOptions.getSpeedLevelPrimary(),
				stringToPc2SpeedLevelType));
		}
		if (palmOptions.getSpeedLevelSecondary() != null) {
			builder.setSpeedLevelSecondary(getValue(palmOptions.getSpeedLevelSecondary(),
				stringToPc2SpeedLevelType));
		}
		if (palmOptions.getDistortionLevelPrimary() != null) {
			builder.setDistortionLevelPrimary(getValue(palmOptions.getDistortionLevelPrimary(),
				stringToPc2DistortionLevelType));
		}
		if (palmOptions.getDistortionLevelSecondary() != null) {
			builder.setDistortionLevelSecondary(getValue(palmOptions.getDistortionLevelSecondary(),
				stringToPc2DistortionLevelType));
		}
	}

	/**
	 * 
	 * @param lfmlOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBLfmlOptions toPBLfmlOptions(LfmlOptions lfmlOptions)
		throws NoInitializedException, InvalidParameterException {
		PBLfmlOptions.Builder builder = PBLfmlOptions.newBuilder();

		if (BooleanUtils.isTrue(lfmlOptions.isApplySearchLevel())) {
			if (lfmlOptions.getSearchLevel() != null) {
				builder.setSearchLevel(getValue(lfmlOptions.getSearchLevel(),
					lfmlSearchLevelToLfmlSearchLevelType));
			}
		}
		if (BooleanUtils.isTrue(lfmlOptions.isApplyRotationLimit())) {
			if (lfmlOptions.getRotationLimit() != null) {
				builder.setRotationLimit(getValue(lfmlOptions.getRotationLimit(),
					lfmlRotationLimitToPc2RotationLimitType));
			}
		}
		if (BooleanUtils.isTrue(lfmlOptions.isApplySpeedLevelPrimary())) {
			if (lfmlOptions.getSpeedLevelPrimary() != null) {
				builder.setSpeedLevelPrimary(getValue(lfmlOptions.getSpeedLevelPrimary(),
					lfmlSpeedLevelToPc2SpeedLevelType));
			}
		}
		if (BooleanUtils.isTrue(lfmlOptions.isApplySpeedLevelSecondary())) {
			if (lfmlOptions.getSpeedLevelSecondary() != null) {
				builder.setSpeedLevelSecondary(getValue(lfmlOptions.getSpeedLevelSecondary(),
					lfmlSpeedLevelToPc2SpeedLevelType));
			}
		}
		if (BooleanUtils.isTrue(lfmlOptions.isApplyDistortionLevelPrimary())) {
			if (lfmlOptions.getDistortionLevelPrimary() != null) {
				builder.setDistortionLevelPrimary(getValue(lfmlOptions.getDistortionLevelPrimary(),
					lfmlDistortionLevelToPc2DistortionLevelType));
			}
		}
		if (BooleanUtils.isTrue(lfmlOptions.isApplyDistortionLevelSecondary())) {
			if (lfmlOptions.getDistortionLevelSecondary() != null) {
				builder.setDistortionLevelSecondary(getValue(lfmlOptions
					.getDistortionLevelSecondary(), lfmlDistortionLevelToPc2DistortionLevelType));
			}
		}
		if (lfmlOptions.getLeOptions() != null) {
			if (BooleanUtils.isTrue(lfmlOptions.getLeOptions().isApplyLeOptions())) {
				builder.setLeOptions(toPBLeOptions(lfmlOptions.getLeOptions()));
			}
		}

		return (PBLfmlOptions)buildClass(builder);
	}

	/**
	 * for updating PBCMLaFMatchableFingerThreshold
	 * 
	 * @author kawamura
	 * 
	 */
	public static class CMLaFParameter {
		Float patternThreshold;
		Integer cardScoreThreshold;
		Float mateProbabilityThreshold;
		Integer finalScoreThreshold;
		Pc2SpeedLevelType speedLevel;

		public Float getPatternThreshold() {
			return patternThreshold;
		}

		public void setPatternThreshold(Float patternThreshold) {
			this.patternThreshold = patternThreshold;
		}

		public Integer getCardScoreThreshold() {
			return cardScoreThreshold;
		}

		public void setCardScoreThreshold(Integer cardScoreThreshold) {
			this.cardScoreThreshold = cardScoreThreshold;
		}

		public Float getMateProbabilityThreshold() {
			return mateProbabilityThreshold;
		}

		public void setMateProbabilityThreshold(Float mateProbabilityThreshold) {
			this.mateProbabilityThreshold = mateProbabilityThreshold;
		}

		public Integer getFinalScoreThreshold() {
			return finalScoreThreshold;
		}

		public void setFinalScoreThreshold(Integer finalScoreThreshold) {
			this.finalScoreThreshold = finalScoreThreshold;
		}

		public Pc2SpeedLevelType getSpeedLevel() {
			return speedLevel;
		}

		public void setSpeedLevel(Pc2SpeedLevelType speedLevel) {
			this.speedLevel = speedLevel;
		}
	}

	/**
	 *
	 * @param cmlOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBCMLOptions toPBCMLOptions(CmlOptions cmlOptions)
		throws NoInitializedException, InvalidParameterException {
		PBCMLOptions.Builder builder = PBCMLOptions.newBuilder();

		if (cmlOptions.getFilterMode() != null) {
			builder.setFilterMode(getValue(cmlOptions.getFilterMode(), stringToFilterModeType));
		}
		if (BooleanUtils.isTrue(cmlOptions.isApplyYobThreshold())) {
			if (cmlOptions.getYobThreshold() != null) {
				builder.setYobThreshold(cmlOptions.getYobThreshold().intValue());
			}
		}
		if (BooleanUtils.isTrue(cmlOptions.isApplyParameterId())) {
			if (cmlOptions.getParameterId() != null) {
				builder.setParameterId(cmlOptions.getParameterId().intValue());
			}
		}
		if (BooleanUtils.isTrue(cmlOptions.isApplyRotationLimit())) {
			if (cmlOptions.getRotationLimit() != null) {
				builder.setRotationLimit(getValue(cmlOptions.getRotationLimit(),
					stringToTimPc2RotationLimitType));
			}
		}
		return (PBCMLOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param cmlafTiOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBCMLaFOptions toPBCMLaFOptions(CmlafTiOptions cmlafTiOptions)
		throws NoInitializedException, InvalidParameterException {
		PBCMLaFOptions.Builder builder = PBCMLaFOptions.newBuilder();
		CMLaFParameter cmlafParameter = new ProtoClassConvert.CMLaFParameter();

		if (cmlafTiOptions.getFilterMode() != null) {
			builder.setFilterMode(getValue(cmlafTiOptions.getFilterMode(), stringToFilterModeType));
		}
		if (BooleanUtils.isTrue(cmlafTiOptions.isApplyPatternThreshold())) {
			if (cmlafTiOptions.getPatternThreshold() != null) {
				cmlafParameter.setPatternThreshold(Float.valueOf(cmlafTiOptions
					.getPatternThreshold().floatValue()));
			}
		}
		if (BooleanUtils.isTrue(cmlafTiOptions.isApplyYobThreshold())) {
			if (cmlafTiOptions.getYobThreshold() != null) {
				builder.setYobThreshold(cmlafTiOptions.getYobThreshold().intValue());
			}
		}
		if (BooleanUtils.isTrue(cmlafTiOptions.isApplyCardScoreThreshold())) {
			if (cmlafTiOptions.getCardScoreThreshold() != null) {
				cmlafParameter.setCardScoreThreshold(Integer.valueOf(cmlafTiOptions
					.getCardScoreThreshold().intValue()));
			}
		}
		if (BooleanUtils.isTrue(cmlafTiOptions.isApplyMateProbabilityThreshold())) {
			if (cmlafTiOptions.getMateProbabilityThreshold() != null) {
				cmlafParameter.setMateProbabilityThreshold(Float.valueOf(cmlafTiOptions
					.getMateProbabilityThreshold().floatValue()));
			}
		}
		if (BooleanUtils.isTrue(cmlafTiOptions.isApplyFinalScoreThreshold())) {
			if (cmlafTiOptions.getFinalScoreThreshold() != null) {
				cmlafParameter.setFinalScoreThreshold(Integer.valueOf(cmlafTiOptions
					.getFinalScoreThreshold().intValue()));
			}
		}
		if (cmlafTiOptions.getSearchMode() != null) {
			builder.setSearchMode(getValue(cmlafTiOptions.getSearchMode(),
				stringToCmlafSearchModeType));
		}
		if (BooleanUtils.isTrue(cmlafTiOptions.isApplySpeedLevel())) {
			if (cmlafTiOptions.getSpeedLevel() != null) {
				cmlafParameter.setSpeedLevel(getValue(cmlafTiOptions.getSpeedLevel(),
					stringToPc2SpeedLevelType));
			}
		}
		if (BooleanUtils.isTrue(cmlafTiOptions.isApplyRotationLimit())) {
			if (cmlafTiOptions.getRotationLimit() != null) {
				builder.setRotationLimit(getValue(cmlafTiOptions.getRotationLimit(),
					stringToTimPc2RotationLimitType));
			}
		}
		if (BooleanUtils.isTrue(cmlafTiOptions.isApplyDistortionLevel())) {
			if (cmlafTiOptions.getDistortionLevel() != null) {
				builder.setDistortionLevel(getValue(cmlafTiOptions.getDistortionLevel(),
					stringToPc2DistortionLevelType));
			}
		}

		if (cmlafTiOptions.getMatchableFingersThresholds() != null) {
			List<PBCMLaFMatchableFingerThreshold> thresholdsList =
				toPBCMLaFMatchableFingerThreshold(cmlafTiOptions.getMatchableFingersThresholds(),
					cmlafParameter);
			builder.addAllMatchableFingerThresholds(thresholdsList);
		}
		return (PBCMLaFOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param matchableFingersThresholds
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBCMLaFMatchableFingerThreshold> toPBCMLaFMatchableFingerThreshold(
		MatchableFingersThresholds matchableFingersThresholds,
		CMLaFParameter parameter)
		throws NoInitializedException, InvalidParameterException {
		List<PBCMLaFMatchableFingerThreshold> pbMatchableFingersThresholdsList = new ArrayList<>();
		boolean updateParameter = BooleanUtils.isTrue(matchableFingersThresholds
			.isApplyMatchableFingersThresholds());

		PBCMLaFMatchableFingerThreshold.Builder builder = PBCMLaFMatchableFingerThreshold
			.newBuilder();
		if (updateParameter) {
			for (FingersThresholds fingersThresholds : nullToList(matchableFingersThresholds
				.getFingersThresholds())) {
				builder.setFingerNumber(fingersThresholds.getFingerNumber());
				builder.setPatternThreshold(fingersThresholds.getPatternThreshold());
				builder.setCardScoreThreshold(fingersThresholds.getCardScoreThreshold());
				builder.setMateProbabilityThreshold(fingersThresholds
					.getMateProbabilityThreshold());
				builder.setSpeedLevel(getValue(Strings.nullToEmpty(fingersThresholds
					.getSpeedLevel()), stringToPc2SpeedLevelType));
				builder.setFinalScoreThreshold(fingersThresholds.getFinalScoreThreshold());
				pbMatchableFingersThresholdsList.add((PBCMLaFMatchableFingerThreshold)buildClass(
					builder));
			}
		} else {
			for (int fingerNumber = 1; fingerNumber < 11; fingerNumber++) {
				builder.clear();
				builder.setFingerNumber(fingerNumber);
				if (parameter.getPatternThreshold() != null) {
					builder.setPatternThreshold(parameter.getPatternThreshold().floatValue());
				}
				if (parameter.getCardScoreThreshold() != null) {
					builder.setCardScoreThreshold(parameter.getCardScoreThreshold().intValue());
				}
				if (parameter.getMateProbabilityThreshold() != null) {
					builder.setMateProbabilityThreshold(parameter.getMateProbabilityThreshold()
						.floatValue());
				}
				if (parameter.getSpeedLevel() != null) {
					builder.setSpeedLevel(parameter.getSpeedLevel());
				}
				if (parameter.getFinalScoreThreshold() != null) {
					builder.setFinalScoreThreshold(parameter.getFinalScoreThreshold().intValue());
				}
				pbMatchableFingersThresholdsList.add((PBCMLaFMatchableFingerThreshold)buildClass(
					builder));
			}
		}
		return pbMatchableFingersThresholdsList;
	}

	/**
	 * 
	 * @param function
	 * @param afisTemplateSet
	 * @throws InvalidParameterException
	 */
	private static void validateFunctionToKey(
		AfisLowLevelFunctionEnum function,
		AfisTemplateSet afisTemplateSet)
		throws InvalidParameterException {
		List<String> compareKeys = null;
		if (function == AfisLowLevelFunctionEnum.TI) {
			String keys[] = {
				"TI_ROLLED", "TI_SLAP",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.TIM) {
			String keys[] = {
				"TIM_ROLLED", "TIM_SLAP",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.LI) {
			String keys[] = {
				"LI", "LIS",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.LIM) {
			String keys[] = {
				"LIM",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.TLI) {
			String keys[] = {
				"TLI_ROLLED", "TLI_SLAP", "TLIS_ROLLED", "TLIS_SLAP",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.TLIM) {
			String keys[] = {
				"TLIM_ROLLED", "TLIM_SLAP",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.LLI) {
			String keys[] = {
				"LLI", "LLIS",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.LLIM) {
			String keys[] = {
				"LLIM",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.LIP) {
			String keys[] = {
				"LIP",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.TLIP) {
			String keys[] = {
				"TLIP",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.LLIP) {
			String keys[] = {
				"LLIP",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.LIX) {
			String keys[] = {
				"LIX",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.TLIX) {
			String keys[] = {
				"TLIX",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.LLIX) {
			String keys[] = {
				"LLIX",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.FI) {
			String keys[] = {
				"FI",
			};
			compareKeys = Arrays.asList(keys);
		} else if (function == AfisLowLevelFunctionEnum.II) {
			String keys[] = {
				"II",
			};
			compareKeys = Arrays.asList(keys);
		} else {
			throw new InvalidParameterException("An invalid parameter: there is a invalid key.");
		}

		List<KeyedTemplate> keyedTemplates = nullToList(afisTemplateSet.getTemplate());
		for (KeyedTemplate keyedTemplate : keyedTemplates) {
			boolean invalid = true;
			for (String key : compareKeys) {
				if (keyedTemplate.getKey().equals(key)) {
					invalid = false;
					break;
				}
			}
			if (invalid) {
				throw new InvalidParameterException(
					"An invalid parameter: there is a invalid key.");
			}
		}
	}

	/**
	 * 
	 * @param templateList
	 * @return
	 * @throws NoInitializedException
	 */
	private static PBInquiryScopeOptions toPBInquiryScopeOptions(KeyedTemplate keyedTemplate)
		throws NoInitializedException {
		PBInquiryScopeOptions.Builder builder = PBInquiryScopeOptions.newBuilder();
		if (keyedTemplate.getMetadata() != null) {
			if (keyedTemplate.getMetadata().getAfisGroupId() != null) {
				builder.addAllScope(keyedTemplate.getMetadata().getAfisGroupId());
			}
			for (FingerSetEnum fingerSetEnum : nullToList(keyedTemplate.getMetadata()
				.getFingerSet())) {
				if (fingerSetEnum == FingerSetEnum.ROLL) {
					builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
				} else if (fingerSetEnum == FingerSetEnum.SLAP) {
					builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
				}
			}
		}
		return (PBInquiryScopeOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param function
	 * @param afisCcopeIdList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBInquiryScopeOptions toPBInquiryScopeOptions(
		InquiryFunctionType function,
		List<Integer> afisCcopeIdList)
		throws NoInitializedException, InvalidParameterException {
		PBInquiryScopeOptions.Builder builder = PBInquiryScopeOptions.newBuilder();
		HashSet<Integer> scopeSet = new HashSet<>();
		HashSet<FingerPrintType> targetFingerPrintSet = new HashSet<>();
		int scope;
		for (Integer afisScopeId : afisCcopeIdList) {
			scope = afisScopeId.intValue() / 1000 + 1;
			if (!scopeSet.contains(Integer.valueOf(scope))) {
				scopeSet.add(Integer.valueOf(scope));
				builder.addScope(scope);
			}

			if (function == InquiryFunctionType.TI || function == InquiryFunctionType.TIM
				|| function == InquiryFunctionType.LI || function == InquiryFunctionType.LIM) {
				FingerPrintType fingerPrintType = getValue(Integer.valueOf(afisScopeId.intValue()
					% 1000), intToFingerPrintType);
				if (!targetFingerPrintSet.contains(fingerPrintType)) {
					targetFingerPrintSet.add(fingerPrintType);
					builder.addTargetFingerPrint(fingerPrintType);
				}
			}
		}
		return (PBInquiryScopeOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param keyedTemplateList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBKeyedTemplateData toPBKeyedTemplateData(String key, byte[] template)
		throws NoInitializedException, InvalidParameterException {
		PBKeyedTemplateData.Builder builder = PBKeyedTemplateData.newBuilder();
		TemplateFormatType formatType = getValue(key, stringToTemplateFormatTypeForInquiry);

		PBKeyedTemplateIndexer indexer = null;
		if (formatType == TemplateFormatType.TEMPLATE_TI
			|| formatType == TemplateFormatType.TEMPLATE_TIM
			|| formatType == TemplateFormatType.TEMPLATE_TLI
			|| formatType == TemplateFormatType.TEMPLATE_TLIS
			|| formatType == TemplateFormatType.TEMPLATE_TLIM) {
			FingerPrintType type = getValue(key, stringToFingerPrintType);
			PBKeyedTemplateIndexer.Builder indexBuilder = PBKeyedTemplateIndexer.newBuilder()
				.setFingerPrintType(type);
			indexer = (PBKeyedTemplateIndexer)buildClass(indexBuilder);
		}

		builder.setKeyedTemplate(toPBKeyedTemplate(template, formatType, indexer));
		return (PBKeyedTemplateData)buildClass(builder);
	}

	/**
	 * 
	 * @param function
	 * @param fusionWeightList
	 * @param searchRequestIndex
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBInquiryFusionWeight> toPBInquiryFusionWeight(
		InquiryFunctionType function,
		TemplateFormatType key,
		List<FusionWeight> fusionWeightList,
		Map<TemplateFormatType, Integer> inquirySetIndexMap,
		FingerPrintType fingerPrintType)
		throws NoInitializedException, InvalidParameterException {
		validateNumberFusionWeight(key, fusionWeightList);
		List<PBInquiryFusionWeight> pbInquiryFusionWeightList = new ArrayList<>();

		if (fusionWeightList.size() == 0) {
			if (function == InquiryFunctionType.TI || function == InquiryFunctionType.TLI
				|| function == InquiryFunctionType.TIM || function == InquiryFunctionType.TLIM) {
				Integer index = inquirySetIndexMap.get(key);
				inquirySetIndexMap.put(key, Integer.valueOf(index.intValue() + 1));
			}
			return pbInquiryFusionWeightList;
		}

		for (FusionWeight fusionWeight : fusionWeightList) {
			PBInquiryFusionWeight.Builder builder = PBInquiryFusionWeight.newBuilder();

			if (function != InquiryFunctionType.TLIX && function != InquiryFunctionType.LIX
				&& function != InquiryFunctionType.LLIX) {
				if (fusionWeight.getInquirySet() != null) {
					throw new InvalidParameterException(new StringBuffer(
						"An invalid parameter: there is a inquirySet of a fusion-weight element.")
							.toString());
				}
			}
			if (function == InquiryFunctionType.TLIX || function == InquiryFunctionType.LIX
				|| function == InquiryFunctionType.LLIX) {
				if (fusionWeight.getInquirySet() == null) {
					throw new InvalidParameterException(new StringBuffer(
						"An invalid parameter: a inquirySet of a fusion-weight element has null.")
							.toString());
				}
				builder.setInquirySet(getValue(fusionWeight.getInquirySet(),
					inquirySetEnumToFingerSetType));
			}

			builder.setWeight(fusionWeight.getValue());

			if (function == InquiryFunctionType.TI || function == InquiryFunctionType.TLI
				|| function == InquiryFunctionType.TIM || function == InquiryFunctionType.TLIM) {
				Integer index = inquirySetIndexMap.get(key);
				inquirySetIndexMap.put(key, Integer.valueOf(index.intValue() + 1));

				if (fingerPrintType != null) {
					if (fingerPrintType == FingerPrintType.FINGER_PRINT_ROLLED) {
						if (key == TemplateFormatType.TEMPLATE_TLI) {
							builder.setInquirySet(FingerSetType.FMP5_ROLLED);
						} else {
							builder.setInquirySet(FingerSetType.PC2_ROLLED);
						}
					} else if (fingerPrintType == FingerPrintType.FINGER_PRINT_SLAP) {
						if (key == TemplateFormatType.TEMPLATE_TLI) {
							builder.setInquirySet(FingerSetType.FMP5_SLAP);
						} else {
							builder.setInquirySet(FingerSetType.PC2_SLAP);
						}
					}
				} else {
					if (index.intValue() == 1) {
						if (key == TemplateFormatType.TEMPLATE_TLI) {
							builder.setInquirySet(FingerSetType.FMP5_ROLLED);
						} else {
							builder.setInquirySet(FingerSetType.PC2_ROLLED);
						}
					} else if (index.intValue() == 2) {
						if (key == TemplateFormatType.TEMPLATE_TLI) {
							builder.setInquirySet(FingerSetType.FMP5_SLAP);
						} else {
							builder.setInquirySet(FingerSetType.PC2_SLAP);
						}
					} else {
						throw new InvalidParameterException(new StringBuffer(
							"An invalid parameter: the number of TLI templates or TLIS templates.")
								.toString());
					}
				}
			} else if (function == InquiryFunctionType.LIM
				|| function == InquiryFunctionType.LLIM) {
				builder.setInquirySet(FingerSetType.PC2_LATENT);
			} else if (function == InquiryFunctionType.LI || function == InquiryFunctionType.LLI) {
				if (key == TemplateFormatType.TEMPLATE_LI
					|| key == TemplateFormatType.TEMPLATE_LLI) {
					builder.setInquirySet(FingerSetType.FMP5_LATENT);
				} else if (key == TemplateFormatType.TEMPLATE_LIS
					|| key == TemplateFormatType.TEMPLATE_LLIS) {
					builder.setInquirySet(FingerSetType.PC2_LATENT);
				}
			}
			pbInquiryFusionWeightList.add((PBInquiryFusionWeight)buildClass(builder));
		}
		return pbInquiryFusionWeightList;
	}

	/**
	 * 
	 * 
	 * @param function
	 * @param containerId
	 * @return
	 * @throws InvalidParameterException
	 * @throws NoInitializedException
	 */
	private static PBKeyedTemplate toPBKeyedTemplate(
		AfisDeletionFunctionEnum function,
		Integer containerId)
		throws InvalidParameterException, NoInitializedException {
		TemplateFormatType templateFormatType = getValue(containerId, intToTemplateFormatType);
		return toPBKeyedTemplate(null, templateFormatType, null);
	}

	/**
	 * 
	 * @param key
	 * @param fusionWeightList
	 * @throws InvalidParameterException
	 */
	private static void validateNumberFusionWeight(
		TemplateFormatType key,
		List<FusionWeight> fusionWeightList)
		throws InvalidParameterException {
		if (key == TemplateFormatType.TEMPLATE_TLIX || key == TemplateFormatType.TEMPLATE_LIX) {
			if (fusionWeightList.size() <= 4) {
				return;
			}
		} else if (key == TemplateFormatType.TEMPLATE_LLIX) {
			if (fusionWeightList.size() <= 2) {
				return;
			}
		} else {
			if (fusionWeightList.size() <= 1) {
				return;
			}
		}

		throw new InvalidParameterException(new StringBuffer(
			"An invalid parameter: the number of fusionWeights.").toString());
	}

	/**
	 * 
	 * @param core
	 * @return
	 * @throws NoInitializedException
	 */
	private static PBFisCore toPBFisCore(TenprintInput.InputMinutia.InputMinutiaData.Core core)
		throws NoInitializedException {
		PBFisCore.Builder builder = PBFisCore.newBuilder();
		if (core.getA() != null) {
			builder.setA(String.valueOf(core.getA()));
		}
		if (core.getF() != null) {
			builder.setF(String.valueOf(core.getF()));
		}
		if (core.getCC() != null) {
			builder.setCC(String.valueOf(core.getCC()));
		}
		builder.setQP(Strings.nullToEmpty(core.getQP()));
		if (core.getQD() != null) {
			builder.setQD(String.valueOf(core.getQD()));
		}
		if (core.getQQ() != null) {
			builder.setQQ(String.valueOf(core.getQQ()));
		}
		if (core.getX() != null) {
			builder.setX(core.getX().intValue());
		}
		if (core.getY() != null) {
			builder.setY(core.getY().intValue());
		}
		if (core.getD() != null) {
			builder.setD(core.getD().intValue());
		}
		return (PBFisCore)buildClass(builder);
	}

	/**
	 * 
	 * @param quality
	 * @return
	 * @throws NoInitializedException
	 */
	private static PBFisQuality toPBFisQuality(
		TenprintInput.InputMinutia.InputMinutiaData.Quality quality)
		throws NoInitializedException {

		PBFisQuality.Builder builder = PBFisQuality.newBuilder();
		if (quality.getVA() != null) {
			builder.setVA(String.valueOf(quality.getVA()));
		}
		if (quality.getVB() != null) {
			builder.setVB(String.valueOf(quality.getVB()));
		}
		if (quality.getVC() != null) {
			builder.setVC(String.valueOf(quality.getVC()));
		}
		builder.setS(Strings.nullToEmpty(quality.getS()));
		return (PBFisQuality)buildClass(builder);
	}

	/**
	 * 
	 * @param minutiaNo
	 * @return
	 * @throws NoInitializedException
	 */
	private static PBFisMinutiaNo toPBFisMinutiaNo(
		TenprintInput.InputMinutia.InputMinutiaData.MinutiaNo minutiaNo)
		throws NoInitializedException {

		PBFisMinutiaNo.Builder builder = PBFisMinutiaNo.newBuilder();
		if (minutiaNo.getDB() != null) {
			builder.setDB(minutiaNo.getDB().intValue());
		}
		if (minutiaNo.getMB() != null) {
			builder.setMB(minutiaNo.getMB().intValue());
		}
		return (PBFisMinutiaNo)buildClass(builder);
	}

	/**
	 * for unit test.
	 * 
	 * @param input
	 * @return
	 * @throws MarshalException
	 */
	@SuppressWarnings("unused")
	private static DynamicXml toDynamicXml(ExtractionInputsPayload input)
		throws MarshalException {
		DynamicXml dynamicXml = new DynamicXml();
		try {
			JAXBContext context = JAXBContext.newInstance("jp.co.nec.aim.mm.jaxb");
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty("jaxb.encoding", "UTF-8");
			marshaller.setProperty("jaxb.formatted.output", Boolean.TRUE);
			StringWriter sw = new StringWriter();
			marshaller.marshal(input, sw);

			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			ByteArrayInputStream bais = new ByteArrayInputStream(sw.toString().getBytes("UTF-8"));
			Document document = builder.parse(bais);
			dynamicXml.setAny(document.getDocumentElement());
		} catch (ParserConfigurationException | IOException | SAXException | JAXBException e) {
			throw new MarshalException(Throwables.getStackTraceAsString(e));
		}
		return dynamicXml;
	}

	/**
	 * for unit test
	 * 
	 * @param input
	 * @return
	 * @throws MarshalException
	 */
	@SuppressWarnings("unused")
	private static DynamicXml toDynamicXml(String payload)
		throws MarshalException {
		DynamicXml dynamicXml = new DynamicXml();
		try {
			StringWriter sw = new StringWriter();
			sw.write(payload);
			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			ByteArrayInputStream bais = new ByteArrayInputStream(sw.toString().getBytes("UTF-8"));
			Document document = builder.parse(bais);
			dynamicXml.setAny(document.getDocumentElement());
		} catch (ParserConfigurationException | IOException | SAXException e) {
			throw new MarshalException(Throwables.getStackTraceAsString(e));
		}
		return dynamicXml;
	}

	/**
	 * for unit test.
	 * 
	 * @param input
	 * @return
	 * @throws MarshalException
	 */
	@SuppressWarnings("unused")
	private static DynamicXml toDynamicXml(SearchInputsPayload input)
		throws MarshalException {
		DynamicXml dynamicXml = new DynamicXml();
		try {
			JAXBContext context = JAXBContext.newInstance("jp.co.nec.aim.mm.jaxb");
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty("jaxb.encoding", "UTF-8");
			marshaller.setProperty("jaxb.formatted.output", Boolean.TRUE);
			StringWriter sw = new StringWriter();
			marshaller.marshal(input, sw);

			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			ByteArrayInputStream bais = new ByteArrayInputStream(sw.toString().getBytes("UTF-8"));
			Document document = builder.parse(bais);
			dynamicXml.setAny(document.getDocumentElement());
		} catch (ParserConfigurationException | IOException | SAXException | JAXBException e) {
			throw new MarshalException(Throwables.getStackTraceAsString(e));
		}
		return dynamicXml;
	}

	/**
	 * 
	 * 
	 * @param applyYob
	 * @param applyGender
	 * @param builder
	 */
	private static PBMetaInfoCommon updateYobAndGender(
		boolean applyYob,
		boolean applyGender,
		MetaInfo metaInfo,
		PBMetaInfoCommon.Builder builder)
		throws NoInitializedException, InvalidParameterException {
		if (applyYob) {
			if ((metaInfo == null) || (metaInfo.getMetaCommon() == null || metaInfo.getMetaCommon()
				.getYob() == null)) {
				builder.setYob(-1);
			}
		} else {
			builder.clearYob();
		}

		if (applyGender) {
			if ((metaInfo == null) || (metaInfo.getMetaCommon() == null || metaInfo.getMetaCommon()
				.getGender() == null)) {
				builder.setGender(GenderType.GENDER_UNKNOWN);
			}
		} else {
			builder.clearGender();
		}
		return (PBMetaInfoCommon)buildClass(builder);
	}

	/**
	 * 
	 * @param irisOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBIrisOptions toPBIrisOptions(IrisOptions irisOptions)
		throws NoInitializedException, InvalidParameterException {
		PBIrisOptions.Builder builder = PBIrisOptions.newBuilder();
		if (irisOptions.getSearchMode() != null) {
			builder.setSearchMode(getValue(irisOptions.getSearchMode(),
				irisSearchModeToIrisSearchModeType));
		}
		if (irisOptions.getRotationLimit() != null) {
			builder.setRotationLimit(irisOptions.getRotationLimit().intValue());
		}
		return (PBIrisOptions)buildClass(builder);
	}

	/**
	 *
	 *
	 * @param inputExtraction
	 * @return
	 */
	private static PBExtractInputIrisExtraction toPBExtractInputIrisExtraction(
		IrisInputExtraction inputExtraction)
		throws NoInitializedException, InvalidParameterException {
		PBExtractInputIrisExtraction.Builder builder = PBExtractInputIrisExtraction.newBuilder();

		if (inputExtraction.getMode() != null) {
			builder.setMode(getValue(inputExtraction.getMode(),
				irisExtractionModeToIrisExtractionModeType));
		}
		return (PBExtractInputIrisExtraction)buildClass(builder);
	}

	/**
	 * 
	 * @param irisInput
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBExtractIrisInput toPBExtractIrisInput(IrisInput irisInput)
		throws NoInitializedException, InvalidParameterException {
		PBExtractIrisInput.Builder builder = PBExtractIrisInput.newBuilder();

		if (irisInput.getAimformats() != null) {
			builder.addAllAimFormats(toPBAimFormat(irisInput.getAimformats()));
		}

		builder.addAllImage(toPBExtractInputImage(irisInput.getImages().getImage()));

		if (irisInput.getEnhType() != null) {
			builder.setBasicEnhanceOptions(toPBBasicImageEnhanceOptions(irisInput.getEnhType()));
		}

		if (irisInput.getMetaInfo() != null) {
			builder.setMetaInfo(toPBMetaInfo(irisInput.getMetaInfo()));
		}

		if (irisInput.getPrefilterOptions() != null) {
			builder.setPrefilterOptions(toPBPrefilterOptions(irisInput.getPrefilterOptions()));
		}

		if (irisInput.getExtraction() != null) {
			builder.setExtraction(toPBExtractInputIrisExtraction(irisInput.getExtraction()));
		}

		return (PBExtractIrisInput)buildClass(builder);
	}

	/**
	 * 
	 * @param enhType
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static PBBasicImageEnhanceOptions toPBBasicImageEnhanceOptions(EnhType enhType)
		throws NoInitializedException, InvalidParameterException {
		PBBasicImageEnhanceOptions.Builder builder = PBBasicImageEnhanceOptions.newBuilder();

		builder.addEnhancements(getValue(enhType, enhTypeToBasicImageEnhganceType));
		return (PBBasicImageEnhanceOptions)buildClass(builder);
	}

	/**
	 * 
	 * @param imageList
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidParameterException
	 */
	private static List<PBExtractInputImage> toPBExtractInputImage(List<IrisInputImage> imageList)
		throws NoInitializedException, InvalidParameterException {
		List<PBExtractInputImage> pbImageList = new ArrayList<>();
		for (IrisInputImage irisInputImage : imageList) {
			PBExtractInputImage.Builder builder = PBExtractInputImage.newBuilder();

			if (irisInputImage.getData() != null) {
				builder.setData(ByteString.copyFrom(irisInputImage.getData()));
			}

			if (irisInputImage.getUrl() != null) {
				builder.setUrl(irisInputImage.getUrl());
			}

			if (irisInputImage.getWidth() != null) {
				builder.setWidth(irisInputImage.getWidth().intValue());
			}

			if (irisInputImage.getHeight() != null) {
				builder.setHeight(irisInputImage.getHeight().intValue());
			}

			if (irisInputImage.getPos() != null) {
				builder.setPosition(getValue(irisInputImage.getPos(), posToImagePositionType));
			}

			builder.setType(getValue(irisInputImage.getType(), imageFormatToImageFormatType));

			pbImageList.add((PBExtractInputImage)buildClass(builder));
		}
		return pbImageList;
	}

	/**
	 * 
	 * @param function
	 * @param commonOptions
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidPayloadException
	 * @throws InvalidParameterException
	 * @throws UnmarshalException
	 */
	private static PBInquiryJobInfo toPBInquiryJobInfo(
		InquiryFunctionType function,
		CommonOptions commonOptions)
		throws NoInitializedException, InvalidPayloadException, InvalidParameterException {
		PBInquiryJobInfo.Builder builder = PBInquiryJobInfo.newBuilder();

		builder.setFunction(function);

		if (commonOptions.getPriority() != null) {
			builder.setPriority(commonOptions.getPriority().intValue());
		}

		if (commonOptions.getMaxCandidates() != null) {
			builder.setMaxCandidate(commonOptions.getMaxCandidates().intValue());
		}

		if (commonOptions.getCallbackURL() != null) {
			builder.setCallBackUrl(commonOptions.getCallbackURL());
		}

		if (commonOptions.getDynThreshHitThreshold() != null) {
			builder.setDynThreshHitThreshold(commonOptions.getDynThreshHitThreshold().intValue());
		}

		if (commonOptions.getDynThreshPercentagePoint() != null) {
			builder.setDynThreshPercentagePoint(commonOptions.getDynThreshPercentagePoint()
				.floatValue());
		}

		return (PBInquiryJobInfo)buildClass(builder);
	}

	/**
	 * 
	 * @param searchContainerList
	 * @param expectedIdList
	 * @throws InvalidParameterException
	 */
	private static void validationContainerIdToFunction(
		List<Integer> searchContainerList,
		List<Integer> expectedIdList)
		throws InvalidParameterException {
		if (searchContainerList == null || searchContainerList.size() == 0) {
			throw new InvalidParameterException(
				"An invalid parameter: there is not any container ID.");
		}

		for (Integer searchContainerId : searchContainerList) {
			boolean invalidId = true;
			int remainder = searchContainerId.intValue() % 1000;
			for (Integer expectedId : expectedIdList) {
				if (remainder == expectedId.intValue()) {
					invalidId = false;
					break;
				}
			}

			if (invalidId) {
				throw new InvalidParameterException(
					"An invalid parameter: there is a invalid container ID.");
			}
		}
	}

	/**
	 * unmarshaling test
	 * 
	 * @param strPayload
	 * @param builder
	 * @throws NoInitializedException
	 * @throws InvalidPayloadException
	 * @throws InvalidParameterException
	 * @throws UnmarshalException
	 */
	@SuppressWarnings("unused")
	private SearchInputsPayload toPBInquiryPayload(
		InquiryFunctionType functionType,
		String strPayload,
		PBInquiryPayload.Builder builder)
		throws NoInitializedException, InvalidPayloadException, InvalidParameterException,
		UnmarshalException {
		SearchInputsPayload searchPayload = null;
		try {
			searchPayload = (SearchInputsPayload)unmarshallerHolder.get().unmarshal(
				new StringReader(strPayload));
		} catch (JAXBException e) {
			throw new UnmarshalException(Throwables.getStackTraceAsString(e));
		}
		toPBInquiryPayload(functionType, searchPayload, builder);
		return searchPayload;
	}

	/**
	 * marshaling test
	 * 
	 * @param input
	 * @return
	 * @throws MarshalException
	 */
	@SuppressWarnings("unused")
	private static String toXml(SearchInputsPayload input)
		throws MarshalException {
		DynamicXml dynamicXml = new DynamicXml();
		String xml = null;
		try {
			JAXBContext context = JAXBContext.newInstance("jp.co.nec.aim.mm.jaxb");
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty("jaxb.encoding", "UTF-8");
			marshaller.setProperty("jaxb.formatted.output", Boolean.TRUE);
			StringWriter sw = new StringWriter();
			marshaller.marshal(input, sw);
			xml = sw.toString();

			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			ByteArrayInputStream bais = new ByteArrayInputStream(sw.toString().getBytes("UTF-8"));
			Document document = builder.parse(bais);
			dynamicXml.setAny(document.getDocumentElement());
		} catch (ParserConfigurationException | IOException | SAXException | JAXBException e) {
			throw new MarshalException(Throwables.getStackTraceAsString(e));
		}
		return xml;
	}

	/**
	 * for unit test
	 * 
	 * @param extractPayload
	 * @return
	 * @throws NoInitializedException
	 * @throws InvalidPayloadException
	 * @throws InvalidParameterException
	 * @throws UnmarshalException
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings("unused")
	private static PBExtractInputPayload toPBExtractInputPayload(String extractPayload)
		throws NoInitializedException, InvalidPayloadException, InvalidParameterException,
		UnmarshalException, UnsupportedEncodingException {

		int index = extractPayload.indexOf(EXT_INPUT);
		StringBuilder sb = new StringBuilder().append(EXTRACTION_INPUTS_PAYLOAD_START).append(
			extractPayload.substring(index)).append(EXTRACTION_INPUTS_PAYLOAD_END);

		try {
			new PayloadValidation().validateExtractPayload(sb.toString());
		} catch (Exception e) {
			throw new UnmarshalException(Throwables.getStackTraceAsString(e));
		}

		ExtractionInputsPayload payload = null;
		long processStart = System.currentTimeMillis();
		try {

			payload = (ExtractionInputsPayload)unmarshallerHolder.get().unmarshal(new StringReader(
				sb.toString()));
		} catch (JAXBException e) {
			throw new UnmarshalException(Throwables.getStackTraceAsString(e));
		}
		long processTime = System.currentTimeMillis() - processStart;

		long processStart2 = System.currentTimeMillis();
		PBExtractInputPayload.Builder builder = PBExtractInputPayload.newBuilder();
		if (payload.getExtInput().getTenprintInput() != null) {
			builder.setTenprintInput(toPBExtractTenprintInput(payload.getExtInput()
				.getTenprintInput()));
		} else if (payload.getExtInput().getLatentInput() != null) {
			builder.setLatentInput(toPBExtractLatentInput(payload.getExtInput().getLatentInput()));
		} else if (payload.getExtInput().getFaceInput() != null) {
			builder.setFaceInput(toPBExtractFaceInput(payload.getExtInput().getFaceInput()));
		} else if (payload.getExtInput().getIrisInput() != null) {
			builder.setIrisInput(toPBExtractIrisInput(payload.getExtInput().getIrisInput()));
		}

		PBExtractInputPayload test = (PBExtractInputPayload)buildClass(builder);
		long processTime2 = System.currentTimeMillis() - processStart2;
		return test;
	}

	/**
	 * 
	 * @param containerIdList
	 * @return
	 */
	private static boolean overlap(List<Integer> containerIdList) {
		HashSet<Integer> hs = new HashSet<>();
		for (Integer containerid : containerIdList) {
			if (hs.contains(containerid)) {
				return true;
			} else {
				hs.add(containerid);
			}
		}
		return false;
	}
}
