package jp.co.nec.aim.convert;

public class ConvertException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8782368392100136458L;

	/**
	 * 
	 */
	public ConvertException() {
		super();
	}

	/**
	 * 
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public ConvertException(String message, Throwable cause,
		boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/**
	 * 
	 * @param message
	 * @param cause
	 */
	public ConvertException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * 
	 * @param message
	 */
	public ConvertException(String message) {
		super(message);
	}

	/**
	 * 
	 * @param cause
	 */
	public ConvertException(Throwable cause) {
		super(cause);
	}
}
