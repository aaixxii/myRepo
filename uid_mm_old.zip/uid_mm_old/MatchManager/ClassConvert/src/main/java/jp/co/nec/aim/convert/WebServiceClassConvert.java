package jp.co.nec.aim.convert;

import static jp.co.nec.aim.convert.ConvertCommon.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceDetectionOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisDetectionOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentFingerOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentPalmOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractPalmOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintFingerOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFace13Points;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceImageAnalysis;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFaceRectPoints;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerCropCoordinate;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPrelsectionDataOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerPsrData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQrData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQrDataOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutputAdvanced;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFingerQualityCheckOutputStandard;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisCore;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisMinutiaNo;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisPatternType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFisQuality;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBFusionIndexer;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBImageData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBMinutiaData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPaExtData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPoint;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPrefilterData;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBPrefilterDataTenprintFinger;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOutputAdvancedHistory;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOutputAdvancedSequence;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBQualityCheckOutputStandardStatus;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore.PBFlexibleScoreIris;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFlexibleScore.PBFlexibleScoreLFML;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidate;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateIndividualScore;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateList;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateTemplate;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResponse;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResult;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResultDetail;
import jp.co.nec.aim.mm.jaxb.Candidate;
import jp.co.nec.aim.mm.jaxb.CandidateTemplate;
import jp.co.nec.aim.mm.jaxb.CheckResult;
import jp.co.nec.aim.mm.jaxb.CheckResults;
import jp.co.nec.aim.mm.jaxb.ContainerResult;
import jp.co.nec.aim.mm.jaxb.CropInfo;
import jp.co.nec.aim.mm.jaxb.DynamicXml;
import jp.co.nec.aim.mm.jaxb.ExtOutput;
import jp.co.nec.aim.mm.jaxb.ExtractJobError;
import jp.co.nec.aim.mm.jaxb.ExtractJobResult;
import jp.co.nec.aim.mm.jaxb.Face13Points;
import jp.co.nec.aim.mm.jaxb.FaceAnalysisOutput;
import jp.co.nec.aim.mm.jaxb.FaceOutput;
import jp.co.nec.aim.mm.jaxb.FaceOutputDetection;
import jp.co.nec.aim.mm.jaxb.FaceOutputPoints;
import jp.co.nec.aim.mm.jaxb.FacePoint;
import jp.co.nec.aim.mm.jaxb.FaceRect;
import jp.co.nec.aim.mm.jaxb.Finger;
import jp.co.nec.aim.mm.jaxb.FingerOutput;
import jp.co.nec.aim.mm.jaxb.FisData;
import jp.co.nec.aim.mm.jaxb.FusionIndexer;
import jp.co.nec.aim.mm.jaxb.HeadRect;
import jp.co.nec.aim.mm.jaxb.ImageAnalysis;
import jp.co.nec.aim.mm.jaxb.IndividualScore;
import jp.co.nec.aim.mm.jaxb.IrisOutput;
import jp.co.nec.aim.mm.jaxb.IrisOutputDetection;
import jp.co.nec.aim.mm.jaxb.IrisOutputPoints;
import jp.co.nec.aim.mm.jaxb.IrisPoint;
import jp.co.nec.aim.mm.jaxb.IrisPoints;
import jp.co.nec.aim.mm.jaxb.IrisScore;
import jp.co.nec.aim.mm.jaxb.JobStatus;
import jp.co.nec.aim.mm.jaxb.KeyedBinary;
import jp.co.nec.aim.mm.jaxb.LatentOutput;
import jp.co.nec.aim.mm.jaxb.MinutiaData;
import jp.co.nec.aim.mm.jaxb.PaextData;
import jp.co.nec.aim.mm.jaxb.PalmOutput;
import jp.co.nec.aim.mm.jaxb.Point;
import jp.co.nec.aim.mm.jaxb.PointCenter;
import jp.co.nec.aim.mm.jaxb.PrefilterOutput;
import jp.co.nec.aim.mm.jaxb.PsrData;
import jp.co.nec.aim.mm.jaxb.PsrOutput;
import jp.co.nec.aim.mm.jaxb.PupilPoints;
import jp.co.nec.aim.mm.jaxb.QcHistory;
import jp.co.nec.aim.mm.jaxb.QcOutput;
import jp.co.nec.aim.mm.jaxb.QcSequence;
import jp.co.nec.aim.mm.jaxb.QcStatus;
import jp.co.nec.aim.mm.jaxb.QrData;
import jp.co.nec.aim.mm.jaxb.QrOutput;
import jp.co.nec.aim.mm.jaxb.QrOutput.QrF;
import jp.co.nec.aim.mm.jaxb.QrOutput.QrS;
import jp.co.nec.aim.mm.jaxb.RawScore;
import jp.co.nec.aim.mm.jaxb.RawScores;
import jp.co.nec.aim.mm.jaxb.SearchJobError;
import jp.co.nec.aim.mm.jaxb.SearchJobResult;
import jp.co.nec.aim.mm.jaxb.SearchOutputsPayload;
import jp.co.nec.aim.mm.jaxb.SearchStatistics;
import jp.co.nec.aim.mm.jaxb.TenprintOutput;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.google.common.base.Joiner;
import com.google.common.base.Throwables;

public class WebServiceClassConvert {
	private static final JAXBContext jaxbContext = ConvertCommon.getJaxbContext();

	private static final ThreadLocal<Marshaller> marshallerHolder =
		new ThreadLocal<Marshaller>() {
			@Override
			public Marshaller initialValue() {
				try {
					return jaxbContext.createMarshaller();
				} catch (JAXBException e) {
					// Wrapped RuntimeException
					Throwables.propagate(e);
				}
				// added it for resolution build error.
				return null;
			}
		};

	/**
	 * convert a PBInquiryJobResult to a SearchJobResult.
	 * 
	 * @param pbJobResult
	 * @return
	 * @throws InvalidParameterException
	 */
	public SearchJobResult toSearchJobResult(PBInquiryJobResult pbJobResult)
		throws InvalidParameterException, ConvertException {
		SearchJobResult searchJobResult = null;
		try {
			searchJobResult = new SearchJobResult();
			searchJobResult.setJobId(Integer.valueOf(((int)pbJobResult.getJobId())));

			PBServiceState pbServiceState = pbJobResult.getServiceState();
			if (pbServiceState.getState() != ServiceStateType.SERVICE_STATE_SUCCESS) {
				if (pbServiceState.hasReason()) {
					searchJobResult.getError().add(
						toSearchJobError(pbServiceState.getReason()));
				}
				return searchJobResult;
			}

			if (pbJobResult.hasStatistics()) {
				SearchStatistics statistics = new SearchStatistics();
				statistics.setReadCount((int)pbJobResult.getStatistics().getAmr()
					.getReadCount());
				statistics.setMatchCount((int)pbJobResult.getStatistics().getAmr()
					.getMatchCount());
				searchJobResult.setStatistics(statistics);
			}

			if (pbJobResult.hasCandidateList()) {
				toCandidate(pbJobResult.getCandidateList(), searchJobResult
					.getCandidate());
			}
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}

		return searchJobResult;
	}

	/**
	 * convert a PBJobStatusResponse to a JobStatus
	 * 
	 * @param pbJobStatusResponse
	 * @return
	 * @throws InvalidParameterException
	 */
	public JobStatus toJobStatus(PBJobStatusResponse pbJobStatusResponse)
		throws InvalidParameterException, ConvertException {
		JobStatus jobStatus = null;
		try {
			jobStatus = new JobStatus();
			jobStatus.setJobId(pbJobStatusResponse.getJobId());
			jobStatus.setState(getValue(pbJobStatusResponse.getJobState(),
				jobStateTypeToJobStateEnum));
			jobStatus.setFailed(Boolean.valueOf(pbJobStatusResponse.getJobFailed()));
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return jobStatus;
	}

	/**
	 * convert a PBExtractJobResult to a ExtractJobResult
	 * 
	 * @param pbJobResult
	 * @return
	 * @throws InvalidParameterException
	 */
	public ExtractJobResult toExtractJobResult(PBExtractJobResult pbJobResult)
		throws InvalidParameterException, MarshalException, ConvertException {
		ExtractJobResult extractJobResult = null;
		try {
			extractJobResult = new ExtractJobResult();
			PBServiceState pbServiceState = pbJobResult.getServiceState();
			if (pbServiceState.getState() != ServiceStateType.SERVICE_STATE_SUCCESS) {
				if (pbServiceState.hasReason()) {
					extractJobResult.getError().add(
						toExtractJobError(pbServiceState.getReason()));
				}
				return extractJobResult;
			}

			toKeyedBinary(pbJobResult.getKeyedTemplateList(), extractJobResult
				.getKeyedBinary());

			if (pbJobResult.hasOutputPayload()) {
				ExtOutput extOuput = toExtOutput(pbJobResult.getOutputPayload());
				extractJobResult.setExtractionOutputsPayload(toDynamicXml(extOuput));
			}
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}

		return extractJobResult;
	}

	/**
	 * convert a PBCheckExternalIdResponse to a CheckResults
	 * 
	 * @param pbCheckExternalIdResponse
	 * @return
	 * @throws InvalidParameterException
	 */
	public CheckResults toCheckResults(PBCheckExternalIdResponse pbCheckExternalIdResponse)
		throws InvalidParameterException, ConvertException {
		CheckResults checkResults = null;
		try {
			checkResults = new CheckResults();
			checkResults.setExternalId(pbCheckExternalIdResponse.getExternalId());
			toCheckResult(pbCheckExternalIdResponse.getCheckResultList(), checkResults
				.getCheckResult());
		} catch (RuntimeException e) {
			throw new ConvertException(Throwables.getRootCause(e).getMessage());
		}
		return checkResults;
	}

	/**
	 * 
	 * @param pbCandidateList
	 * @param candidateList
	 * @throws InvalidParameterException
	 */
	private static void toCandidate(
		PBInquiryCandidateList pbCandidateList,
		List<Candidate> candidateList)
		throws InvalidParameterException {
		for (PBInquiryCandidate pbCandidate : pbCandidateList.getCandidateList()) {
			Candidate candidate = new Candidate();
			candidate.setExternalId(pbCandidate.getExternalId());
			candidate.setFusionScore(pbCandidate.getFusionScore());
			candidate.setHit(Boolean.valueOf(pbCandidate.getHitFlag()));
			toCandidateTemplate(pbCandidate.getCandidateTemplateList(), candidate
				.getCandidateTemplate());

			candidateList.add(candidate);
		}
	}

	/**
	 * 
	 * @param pbCandidateTemplateList
	 * @param candidateTemplateList
	 */
	private static void toCandidateTemplate(
		List<PBInquiryCandidateTemplate> pbCandidateTemplateList,
		List<CandidateTemplate> candidateTemplateList)
		throws InvalidParameterException {
		for (PBInquiryCandidateTemplate pbCandidateTemplate : pbCandidateTemplateList) {
			CandidateTemplate candidateTemplate = new CandidateTemplate();
			candidateTemplate.setEventId(pbCandidateTemplate.getEventId());
			candidateTemplate.setContainerId(pbCandidateTemplate.getContainerId());
			candidateTemplate.setSearchRequestIndex(pbCandidateTemplate
				.getInquiryRequestIndex());
			candidateTemplate.setCompositeScore(pbCandidateTemplate.getCompositScore());
			toIndividualScore(pbCandidateTemplate.getIndividualScoreList(),
				candidateTemplate.getIndividualScore());

			candidateTemplateList.add(candidateTemplate);
		}
	}

	/**
	 * 
	 * @param pbIndividualScore
	 * @param individualScoreList
	 */
	private static void toIndividualScore(
		List<PBInquiryCandidateIndividualScore> pbIndividualScoreList,
		List<IndividualScore> individualScoreList)
		throws InvalidParameterException {
		for (PBInquiryCandidateIndividualScore pbIndividualScore : pbIndividualScoreList) {
			IndividualScore individualScore = new IndividualScore();
			individualScore.setValue(pbIndividualScore.getScore());
			if (pbIndividualScore.hasSearchPosition()) {
				individualScore.setSearchPosition(Integer.valueOf(pbIndividualScore
					.getSearchPosition()));
			}
			if (pbIndividualScore.hasPosition()) {
				individualScore.setPosition(Integer.valueOf(pbIndividualScore
					.getPosition()));
			}
			if (pbIndividualScore.hasFingerAxis()) {
				individualScore.setAxis(getValue(pbIndividualScore.getFingerAxis(),
					fingerAxisTypeToAxisEnum));
			}
			if (pbIndividualScore.hasFusionWeight()) {
				individualScore.setInquirySet(getValue(pbIndividualScore
					.getFusionWeight().getInquirySet(), fingerSetTypeToInquirySetEnum));
				individualScore.setFusionWeight(Integer.valueOf(pbIndividualScore
					.getFusionWeight().getWeight()));
			}
			if (pbIndividualScore.hasFlexibleScore()) {
				individualScore
					.setSearchOutputsPayload(toSearchOutputsPayload(pbIndividualScore
						.getFlexibleScore()));
			}
			individualScoreList.add(individualScore);
		}
	}

	/**
	 * 
	 * @param pbFlexibleScore
	 * @return
	 */
	private static SearchOutputsPayload toSearchOutputsPayload(
		PBFlexibleScore pbFlexibleScore) {
		SearchOutputsPayload outputPayload = new SearchOutputsPayload();
		RawScores rawScores = new RawScores();
		if (0 < pbFlexibleScore.getLfmlCount()) {
			toRawScore(pbFlexibleScore.getLfmlList(), rawScores.getRawScore());
		}
		if (0 < pbFlexibleScore.getIrisCount()) {
			toIrisScore(pbFlexibleScore.getIrisList(), rawScores.getIrisScore());
		}
		outputPayload.setRawScores(rawScores);
		return outputPayload;
	}

	/**
	 * 
	 * @param pbFlexibleScoreLfmlList
	 * @param rawScoreList
	 */
	private static void toRawScore(
		List<PBFlexibleScoreLFML> pbFlexibleScoreLfmlList,
		List<RawScore> rawScoreList) {
		for (PBFlexibleScoreLFML pbFlexibleScoreLFML : pbFlexibleScoreLfmlList) {
			RawScore rawScore = new RawScore();
			int searchIndex = pbFlexibleScoreLFML.getSearchIndex();
			rawScore.setSearchIndex(Integer.valueOf(searchIndex));
			int fileIndex = pbFlexibleScoreLFML.getFileIndex();
			rawScore.setFileIndex(Integer.valueOf(fileIndex));
			rawScore.setValue(Integer.valueOf(pbFlexibleScoreLFML.getRawScore()));
			rawScoreList.add(rawScore);
		}
	}

	/**
	 * 
	 * @param pbFlexibleScoreLfmlList
	 * @param irisScoreList
	 */
	private static void toIrisScore(
		List<PBFlexibleScoreIris> pbFlexibleScoreIrisList,
		List<IrisScore> irisScoreList) {
		for (PBFlexibleScoreIris pbFlexibleScoreIris : pbFlexibleScoreIrisList) {
			IrisScore rawScore = new IrisScore();
			int fileIndex = pbFlexibleScoreIris.getFilePosition();
			rawScore.setFilePosition(Integer.valueOf(fileIndex));
			rawScore.setScore(Integer.valueOf(pbFlexibleScoreIris.getScore()));
			irisScoreList.add(rawScore);
		}
	}

	/**
	 * 
	 * @param pbKeyedTemplateList
	 * @param keyedBinaryList
	 * @throws InvalidParameterException
	 */
	private static void toKeyedBinary(
		List<PBKeyedTemplate> pbKeyedTemplateList,
		List<KeyedBinary> keyedBinaryList)
		throws InvalidParameterException {
		for (PBKeyedTemplate pbKeyedTemplate : pbKeyedTemplateList) {
			List<String> keyList =
				getValue(pbKeyedTemplate.getKey(), templateFormatTypeToListString);
			KeyedBinary keyedBinary = new KeyedBinary();
			PBKeyedTemplateIndexer indexer = pbKeyedTemplate.getIndexer();
			if (indexer.hasFingerPrintType()) {
				FingerPrintType fingerPrintType = indexer.getFingerPrintType();
				if (fingerPrintType == FingerPrintType.FINGER_PRINT_ROLLED) {
					keyedBinary.setKey(keyList.get(0));
				} else if (fingerPrintType == FingerPrintType.FINGER_PRINT_SLAP) {
					keyedBinary.setKey(keyList.get(1));
				} else {
					// never come in
					throwInvalidParameterException("an invalid FingerPrintType.");
				}
			} else if (indexer.hasPosition()) {
				int index = 0;
				if (indexer.getPosition().name().contains("SLAP")) {
					index = 1;
				}
				String key =
					new StringBuilder(keyList.get(index)).append(
						getValue(indexer.getPosition(), imagePositionTypeToIntKey))
						.toString();
				keyedBinary.setKey(key);
			} else if (indexer.hasIndex()) {
				String key =
					new StringBuilder(keyList.get(0)).append(indexer.getIndex())
						.toString();
				keyedBinary.setKey(key);
			} else {
				keyedBinary.setKey(keyList.get(0));
			}
			keyedBinary.setBinary(new byte[0]);
			keyedBinaryList.add(keyedBinary);
		}
	}

	/**
	 * 
	 * @param pbOutputputPayload
	 * @return
	 */
	private static ExtOutput toExtOutput(PBExtractOutputPayload pbOutputputPayload)
		throws InvalidParameterException {
		ExtOutput extOutput = new ExtOutput();
		if (pbOutputputPayload.hasTenprintOutput()) {
			extOutput.setTenprintOutput(toTenprintOutput(pbOutputputPayload
				.getTenprintOutput()));
		} else if (pbOutputputPayload.hasLatentOutput()) {
			extOutput
				.setLatentOutput(toLatentOutput(pbOutputputPayload.getLatentOutput()));
		} else if (pbOutputputPayload.hasFaceOutput()) {
			extOutput.setFaceOutput(toFaceOutput(pbOutputputPayload.getFaceOutput()));
		} else if (pbOutputputPayload.hasIrisOutput()) {
			extOutput.setIrisOutput(toIrisOutput(pbOutputputPayload.getIrisOutput()));
		}
		return extOutput;
	}

	/**
	 * 
	 * @param pbTenprintOutput
	 * @return
	 */
	private static TenprintOutput toTenprintOutput(
		PBExtractTenprintOutput pbTenprintOutput)
		throws InvalidParameterException {
		TenprintOutput tenprintOutput = new TenprintOutput();

		if (pbTenprintOutput.hasFingerQualitySummary()) {
			tenprintOutput.setQualityRolled(Integer.valueOf(pbTenprintOutput
				.getFingerQualitySummary().getRolled()));
			tenprintOutput.setQualitySlap(Integer.valueOf(pbTenprintOutput
				.getFingerQualitySummary().getSlap()));
		}
		if (pbTenprintOutput.hasQcOutput()) {
			tenprintOutput.setQcOutput(toQcOutput(pbTenprintOutput.getQcOutput()));
		}
		if (pbTenprintOutput.hasPsrData()) {
			tenprintOutput.setPsrOutput(toPsrOutput(pbTenprintOutput.getPsrData()));
		}
		if (pbTenprintOutput.hasQrData()) {
			tenprintOutput.setQrOutput(toQrData(pbTenprintOutput.getQrData()));
		}
		if (0 < pbTenprintOutput.getFingerOutputCount()) {
			toFingerOutput(pbTenprintOutput.getFingerOutputList(), tenprintOutput
				.getFingerOutput());
		}
		if (0 < pbTenprintOutput.getPalmOutputCount()) {
			toPalmOutput(pbTenprintOutput.getPalmOutputList(), tenprintOutput
				.getPalmOutput());
		}
		return tenprintOutput;
	}

	/**
	 * 
	 * @param qualityCheckOutput
	 * @return
	 */
	private static QcOutput toQcOutput(PBFingerQualityCheckOutput qualityCheckOutput)
		throws InvalidParameterException {
		if (qualityCheckOutput.hasStandard()) {
			return toQcOutput(qualityCheckOutput.getStandard());
		} else if (qualityCheckOutput.hasAdvanced()) {
			return toQcOutput(qualityCheckOutput.getAdvanced());
		}
		return new QcOutput();
	}

	/**
	 * 
	 * @param pbStandard
	 * @return
	 * @throws InvalidParameterException
	 */
	private static QcOutput toQcOutput(PBFingerQualityCheckOutputStandard pbStandard)
		throws InvalidParameterException {
		QcOutput qcOutput = new QcOutput();
		qcOutput.setTotal(Integer.valueOf(pbStandard.getTotalStatus()));
		if (0 < pbStandard.getRolledStatusCount()) {
			toQcStatus(pbStandard.getRolledStatusList(), qcOutput.getRollStatus());
		}
		if (0 < pbStandard.getSlapStatusCount()) {
			toQcStatus(pbStandard.getSlapStatusList(), qcOutput.getSlapStatus());
		}
		return qcOutput;
	}

	/**
	 * 
	 * @param pbStatusList
	 * @param statusList
	 * @throws InvalidParameterException
	 */
	private static void toQcStatus(
		List<PBQualityCheckOutputStandardStatus> pbStatusList,
		List<QcStatus> statusList)
		throws InvalidParameterException {
		for (PBQualityCheckOutputStandardStatus status : pbStatusList) {
			Finger finger = new Finger();
			finger.setPos(getValue(status.getPosition(), fingerPositionTypeToInt));
			finger.setStatus(Integer.valueOf(status.getStatus()));
			QcStatus qcStatus = new QcStatus();
			qcStatus.setFinger(finger);
			statusList.add(qcStatus);
		}
	}

	/**
	 * 
	 * @param advanced
	 * @return
	 * @throws InvalidParameterException
	 */
	private static QcOutput toQcOutput(PBFingerQualityCheckOutputAdvanced advanced)
		throws InvalidParameterException {
		QcOutput qcOutput = new QcOutput();
		qcOutput.setStatus(getValue(advanced.getTotalStatus(),
			qualityCheckAdvancedStateTypeToQcDetailStatus));
		if (advanced.hasSequence()) {
			qcOutput.setSequence(toQcSequence(advanced.getSequence()));
		}
		if (0 < advanced.getHistoriesCount()) {
			qcOutput.setHistory(toHistory(advanced.getHistoriesList()));
		}
		return qcOutput;
	}

	/**
	 * 
	 * @param sequence
	 * @return
	 */
	private static QcSequence toQcSequence(PBQualityCheckOutputAdvancedSequence sequence)
		throws InvalidParameterException {
		List<String> rolledList = new ArrayList<>();
		for (FingerPositionType status : sequence.getRolledStatusList()) {
			rolledList.add(getValue(status, fingerPositionTypeToString));
		}
		List<String> slapList = new ArrayList<>();
		for (FingerPositionType status : sequence.getSlapStatusList()) {
			slapList.add(getValue(status, fingerPositionTypeToString));
		}
		QcSequence qcSequence = new QcSequence();
		if (sequence.getRolledStatusCount() != 0) {
			qcSequence.setRolledFingers(Joiner.on(":").join(rolledList.toArray()));
		}
		if (sequence.getSlapStatusCount() != 0) {
			qcSequence.setSlapFingers(Joiner.on(":").join(slapList.toArray()));
		}
		return qcSequence;
	}

	/**
	 * 
	 * @param pbHistory
	 * @return
	 */
	private static QcOutput.History toHistory(
		List<PBQualityCheckOutputAdvancedHistory> pbHistoryList)
		throws InvalidParameterException {
		QcOutput.History history = new QcOutput.History();
		for (PBQualityCheckOutputAdvancedHistory pbHistory : pbHistoryList) {
			QcHistory qcHistory = new QcHistory();
			qcHistory.setActivity(getValue(pbHistory.getActivity(),
				qualityCheckAdvancedActivityTypeToQcActivity));
			qcHistory.setStatus(getValue(pbHistory.getStatus(),
				qualityCheckAdvancedStateTypeToQcDetailStatus));
			qcHistory.setData(pbHistory.getData());
			history.getItem().add(qcHistory);
		}
		return history;
	}

	/**
	 * 
	 * @param pbOutput
	 * @return
	 */
	private static PsrOutput toPsrOutput(PBFingerPrelsectionDataOutput pbOutput)
		throws InvalidParameterException {
		PsrOutput psrOutput = new PsrOutput();
		if (0 < pbOutput.getRolled10Count()) {
			for (PBFingerPsrData pbPsrData : pbOutput.getRolled10List()) {
				psrOutput.getRolled10Psr().add(toPsrData(pbPsrData));
			}
		}
		if (0 < pbOutput.getRolled8Count()) {
			for (PBFingerPsrData pbPsrData : pbOutput.getRolled8List()) {
				psrOutput.setRolled8Psr(toPsrData(pbPsrData));
			}
		}
		if (0 < pbOutput.getSlapCount()) {
			for (PBFingerPsrData pbPsrData : pbOutput.getSlapList()) {
				psrOutput.getSlapPsr().add(toPsrData(pbPsrData));
			}
		}
		return psrOutput;
	}

	/**
	 * 
	 * @param qrDataOutput
	 * @return
	 */
	private static QrOutput toQrData(PBFingerQrDataOutput qrDataOutput) {
		QrOutput qrOutput = new QrOutput();
		if (qrDataOutput.hasQrS()) {
			QrS qrs = new QrS();
			PBFingerQrData pbQrData = qrDataOutput.getQrS();
			if (pbQrData.hasRolled()) {
				QrData qrData = new QrData();
				qrData.setValue(pbQrData.getRolled().toByteArray());
				qrs.setRollQr(qrData);
			}
			if (pbQrData.hasSlap()) {
				QrData qrData = new QrData();
				qrData.setValue(pbQrData.getSlap().toByteArray());
				qrs.setSlapQr(qrData);
			}
			qrOutput.setQrS(qrs);
		}
		if (qrDataOutput.hasQrF()) {
			QrF qrs = new QrF();
			PBFingerQrData pbQrData = qrDataOutput.getQrF();
			if (pbQrData.hasRolled()) {
				QrData qrData = new QrData();
				qrData.setValue(pbQrData.getRolled().toByteArray());
				qrs.setRollQr(qrData);
			}
			if (pbQrData.hasSlap()) {
				QrData qrData = new QrData();
				qrData.setValue(pbQrData.getSlap().toByteArray());
				qrs.setSlapQr(qrData);
			}
			qrOutput.setQrF(qrs);
		}
		return qrOutput;
	}

	/**
	 * 
	 * @param pbOutputList
	 * @param fingerOutputList
	 */
	private static void toFingerOutput(
		List<PBExtractTenprintFingerOutput> pbOutputList,
		List<FingerOutput> fingerOutputList)
		throws InvalidParameterException {
		for (PBExtractTenprintFingerOutput pbFingerOutput : pbOutputList) {
			FingerOutput fingerOutput = new FingerOutput();
			fingerOutput.setPos(getValue(pbFingerOutput.getPosition(),
				imagePositionTypeToIntPosition));
			fingerOutput.setAngle(Float.valueOf(pbFingerOutput.getAngle()));
			fingerOutput.setFingerConfidence(Integer.valueOf(pbFingerOutput
				.getConfidence()));
			fingerOutput.setPatternPrimary(getValue(pbFingerOutput.getPattern()
				.getPrimary(), fingerPatternTypeToString));
			fingerOutput.setPatternReference(getValue(pbFingerOutput.getPattern()
				.getReference(), fingerPatternTypeToString));
			fingerOutput.setQuality(Integer.valueOf(pbFingerOutput.getQualityInfo()
				.getIql()));
			fingerOutput.setNfiqQuality(Integer.valueOf(pbFingerOutput.getQualityInfo()
				.getNfiq()));
			if (pbFingerOutput.hasCropInfo()) {
				fingerOutput.setCropInfo(toCropInfo(pbFingerOutput.getCropInfo()));
			}

			if (0 < pbFingerOutput.getMinutiaDataCount()) {
				toMinutiaData(pbFingerOutput.getMinutiaDataList(), fingerOutput
					.getMinutiaData());
			}

			if (0 < pbFingerOutput.getPrefilterDataCount()) {
				fingerOutput.setPrefilterOutput(toPrefilterOutput(pbFingerOutput
					.getPrefilterDataList()));
			}

			if (0 < pbFingerOutput.getFisDataCount()) {
				toFisData(pbFingerOutput.getFisDataList(), fingerOutput.getFisData());
			}

			if (pbFingerOutput.hasImageData()) {
				setImageData(pbFingerOutput.getImageData(), fingerOutput);
			}
			fingerOutputList.add(fingerOutput);
		}
	}

	/**
	 * 
	 * @param cropCoordinate
	 * @return
	 */
	private static CropInfo toCropInfo(PBFingerCropCoordinate cropCoordinate) {
		CropInfo cropInfo = new CropInfo();
		if (cropCoordinate.hasCropPoints()) {
			PointCenter pointCenter = new PointCenter();
			pointCenter.setX(Integer.valueOf(cropCoordinate.getCropPoints().getCenter()
				.getX()));
			pointCenter.setY(Integer.valueOf(cropCoordinate.getCropPoints().getCenter()
				.getY()));
			cropInfo.setCenter(pointCenter);

			if (0 < cropCoordinate.getCropPoints().getPointsCount()) {
				CropInfo.CropPoints cropPoints = new CropInfo.CropPoints();
				for (PBPoint pbPoint : cropCoordinate.getCropPoints().getPointsList()) {
					cropPoints.getPoints().add(toPoint(pbPoint));
				}
				cropInfo.setCropPoints(cropPoints);
			}
		}
		return cropInfo;
	}

	/**
	 * 
	 * @param pbMinutiaDataList
	 * @param minutiaDataList
	 * @throws InvalidParameterException
	 */
	private static void toMinutiaData(
		List<PBMinutiaData> pbMinutiaDataList,
		List<MinutiaData> minutiaDataList)
		throws InvalidParameterException {
		for (PBMinutiaData pbMinutiaData : pbMinutiaDataList) {
			MinutiaData minutiaData = new MinutiaData();
			minutiaData.setBinary(pbMinutiaData.getData().toByteArray());
			minutiaData.setMinutiaType(getValue(pbMinutiaData.getMinutiaType(),
				minutiaTypeToString));
			if (pbMinutiaData.hasFisType()) {
				minutiaData.setFisType(getValue(pbMinutiaData.getFisType(),
					fisTypeTypeToString));
			}
			minutiaData.setMinutiaCount(Integer.valueOf(pbMinutiaData
				.getMinutiaCount()));

			for (PBFusionIndexer pbIndexer : pbMinutiaData.getFusionIndexerList()) {
				minutiaData.setDbType(getValue(pbIndexer.getFormat(),
					templateFormatTypeToStringDbType));

				minutiaData.setFormat(getValue(pbIndexer.getFormat(),
					templateFormatTypeToStringName));

				if (pbIndexer.getFusionIdCount() == 1) {
					minutiaData.setFusionId(Integer.valueOf(pbIndexer.getFusionId(0)));
				} else if (1 < pbIndexer.getFusionIdCount()) {
					minutiaData.setMultiFeIndex(Joiner.on(",").join(
						pbIndexer.getFusionIdList()));
				}
			}
			minutiaDataList.add(minutiaData);
		}
	}

	/**
	 * 
	 * @param pbMinutiaData
	 * @return
	 * @throws InvalidParameterException
	 */
	private static MinutiaData toMinutiaData(PBMinutiaData pbMinutiaData)
		throws InvalidParameterException {
		MinutiaData minutiaData = new MinutiaData();
		minutiaData.setMinutiaType(getValue(pbMinutiaData.getMinutiaType(),
			minutiaTypeToString));

		if (pbMinutiaData.hasFisType()) {
			minutiaData.setFisType(getValue(pbMinutiaData.getFisType(),
				fisTypeTypeToString));
		}

		minutiaData.setMinutiaCount(Integer.valueOf(pbMinutiaData.getMinutiaCount()));
		minutiaData.setBinary(pbMinutiaData.getData().toByteArray());

		return minutiaData;
	}

	/**
	 * 
	 * @param pbPrifilter
	 */
	private static PrefilterOutput toPrefilterOutput(
		List<PBPrefilterDataTenprintFinger> pbPrefilterList) {
		PrefilterOutput prefilterOutput = new PrefilterOutput();
		for (PBPrefilterDataTenprintFinger pbPrefilter : pbPrefilterList) {
			TemplateFormatType formatType = pbPrefilter.getTemplateFormat();
			if (formatType == TemplateFormatType.TEMPLATE_RDBL
				|| formatType == TemplateFormatType.TEMPLATE_RDBLS) {
				PrefilterOutput.RdblPrefilter rdblPrefilter =
					new PrefilterOutput.RdblPrefilter();
				if (pbPrefilter.hasRolled()) {
					rdblPrefilter.setRollPrefilter(pbPrefilter.getRolled().toByteArray());
				}
				if (pbPrefilter.hasSlap()) {
					rdblPrefilter.setSlapPrefilter(pbPrefilter.getSlap().toByteArray());
				}
				prefilterOutput.setRdblPrefilter(rdblPrefilter);
			} else if (formatType == TemplateFormatType.TEMPLATE_TLI
				|| formatType == TemplateFormatType.TEMPLATE_TLIS) {
				PrefilterOutput.TliPrefilter tliPrefilter =
					new PrefilterOutput.TliPrefilter();
				if (pbPrefilter.hasRolled()) {
					tliPrefilter.setRollPrefilter(pbPrefilter.getRolled().toByteArray());
				}
				if (pbPrefilter.hasSlap()) {
					tliPrefilter.setSlapPrefilter(pbPrefilter.getSlap().toByteArray());
				}
				prefilterOutput.setTliPrefilter(tliPrefilter);
			} else if (formatType == TemplateFormatType.TEMPLATE_RDBLM) {
				PrefilterOutput.RdblmPrefilter rdblmPrefilter =
					new PrefilterOutput.RdblmPrefilter();
				if (pbPrefilter.hasRolled()) {
					byte[] prefilter = pbPrefilter.getRolled().toByteArray();
					rdblmPrefilter.setRollPrefilter(prefilter);
				}
				if (pbPrefilter.hasSlap()) {
					rdblmPrefilter.setSlapPrefilter(pbPrefilter.getSlap().toByteArray());
				}
				prefilterOutput.setRdblmPrefilter(rdblmPrefilter);
			} else if (formatType == TemplateFormatType.TEMPLATE_TLIM) {
				PrefilterOutput.TlimPrefilter tlimPrefilter =
					new PrefilterOutput.TlimPrefilter();
				if (pbPrefilter.hasRolled()) {
					tlimPrefilter.setRollPrefilter(pbPrefilter.getRolled().toByteArray());
				}
				if (pbPrefilter.hasSlap()) {
					tlimPrefilter.setSlapPrefilter(pbPrefilter.getSlap().toByteArray());
				}
				prefilterOutput.setTlimPrefilter(tlimPrefilter);
			} else if (formatType == TemplateFormatType.TEMPLATE_TLIX) {
				PrefilterOutput.TlixPrefilter tlixPrefilter =
					new PrefilterOutput.TlixPrefilter();
				if (pbPrefilter.hasRolled()) {
					tlixPrefilter.setRollPrefilter(pbPrefilter.getRolled().toByteArray());
				}
				if (pbPrefilter.hasSlap()) {
					tlixPrefilter.setSlapPrefilter(pbPrefilter.getSlap().toByteArray());
				}
				prefilterOutput.setTlixPrefilter(tlixPrefilter);
			} else if (formatType == TemplateFormatType.TEMPLATE_RDBLX) {
				PrefilterOutput.XdblPrefilter xdblPrefilter =
					new PrefilterOutput.XdblPrefilter();
				if (pbPrefilter.hasRolled()) {
					xdblPrefilter.setRollPrefilter(pbPrefilter.getRolled().toByteArray());
				}
				if (pbPrefilter.hasSlap()) {
					xdblPrefilter.setSlapPrefilter(pbPrefilter.getSlap().toByteArray());
				}
				prefilterOutput.setXdblPrefilter(xdblPrefilter);
			}
		}
		return prefilterOutput;
	}

	/**
	 * 
	 * @param pbPrifilter
	 * @return
	 */
	private static void toPrefilterOutput(
		List<PBPrefilterData> pbPrefilterList,
		PrefilterOutput prefilterOutput) {
		for (PBPrefilterData pbPrefilter : pbPrefilterList) {
			TemplateFormatType formatType = pbPrefilter.getTemplateFormat();
			if (formatType == TemplateFormatType.TEMPLATE_LDB
				|| formatType == TemplateFormatType.TEMPLATE_LDBS) {
				prefilterOutput.setLdbPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LI
				|| formatType == TemplateFormatType.TEMPLATE_LIS) {
				prefilterOutput.setLiPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LLI
				|| formatType == TemplateFormatType.TEMPLATE_LLIS) {
				prefilterOutput.setLliPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_PDB) {
				prefilterOutput.setPdbPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_PLDB) {
				prefilterOutput.setPldbPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LIP) {
				prefilterOutput.setLipPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_TLIP) {
				prefilterOutput.setTlipPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LLIP) {
				prefilterOutput.setLlipPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LIM) {
				prefilterOutput.setLimPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LLIM) {
				prefilterOutput.setLlimPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LDBM) {
				prefilterOutput.setLdbmPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LIX) {
				prefilterOutput.setLixPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LLIX) {
				prefilterOutput.setLlixPrefilter(pbPrefilter.getData().toByteArray());
			} else if (formatType == TemplateFormatType.TEMPLATE_LDBX) {
				prefilterOutput.setLdbxPrefilter(pbPrefilter.getData().toByteArray());
			}
		}
	}

	/**
	 * 
	 * @param pbFisData
	 * @param fisDataList
	 */
	private static void toFisData(List<PBFisData> pbFisDataList, List<FisData> fisDataList)
		throws InvalidParameterException {
		for (PBFisData pbFisData : pbFisDataList) {
			FisData fisData = new FisData();
			if (pbFisData.hasFisType()) {
				fisData.setFisType(getValue(pbFisData.getFisType(), fisTypeTypeToString));
			}
			fisData.setFisCore(toFisCore(pbFisData.getFisCore()));
			fisData.setFisQuality(toFisQuality(pbFisData.getFisQuality()));
			fisData.setFisMinutiaNo(toFisMinutiaNo(pbFisData.getFisMinutiaNo()));

			if (pbFisData.hasFisPatternType()) {
				PBFisPatternType pattern = pbFisData.getFisPatternType();
				fisData.setFisPatternType(toFisPatternType(pattern));
			}
			fisData.setMinutiaData(pbFisData.getMinutia().toByteArray());
			fisData.setZone(pbFisData.getZone().toByteArray());
			fisData.setSkeleton(pbFisData.getSkeleton().toByteArray());
			if (0 < pbFisData.getFusionIndexerCount()) {
				toFusionIndexer(pbFisData.getFusionIndexerList(), fisData
					.getFusionIndexer());
			}
			fisDataList.add(fisData);
		}
	}

	/**
	 * 
	 * @param pbFisCore
	 * @return
	 */
	private static FisData.FisCore toFisCore(PBFisCore pbFisCore) {
		FisData.FisCore fisCore = new FisData.FisCore();
		fisCore.setA(pbFisCore.getA());
		fisCore.setF(pbFisCore.getF());
		fisCore.setCC(pbFisCore.getCC());
		fisCore.setQP(pbFisCore.getQP());
		fisCore.setQD(pbFisCore.getQD());
		fisCore.setQQ(pbFisCore.getQQ());
		fisCore.setX(Integer.valueOf(pbFisCore.getX()));
		fisCore.setY(Integer.valueOf(pbFisCore.getY()));
		fisCore.setD(Integer.valueOf(pbFisCore.getD()));
		return fisCore;
	}

	/**
	 * 
	 * @param pbFisQuality
	 * @return
	 */
	private static FisData.FisQuality toFisQuality(PBFisQuality pbFisQuality) {
		FisData.FisQuality fisQuality = new FisData.FisQuality();
		fisQuality.setS(pbFisQuality.getS());
		fisQuality.setVA(pbFisQuality.getVA());
		fisQuality.setVB(pbFisQuality.getVB());
		fisQuality.setVC(pbFisQuality.getVC());
		return fisQuality;
	}

	/**
	 * 
	 * @param pbFisMinutiaNo
	 * @return
	 */
	private static FisData.FisMinutiaNo toFisMinutiaNo(PBFisMinutiaNo pbFisMinutiaNo) {
		FisData.FisMinutiaNo fisMinutiaNo = new FisData.FisMinutiaNo();
		fisMinutiaNo.setDB(Integer.valueOf(pbFisMinutiaNo.getDB()));
		fisMinutiaNo.setMB(Integer.valueOf(pbFisMinutiaNo.getMB()));
		return fisMinutiaNo;
	}

	/**
	 * 
	 * @param pbFisPatternType
	 * @return
	 * @throws InvalidParameterException
	 */
	private static FisData.FisPatternType toFisPatternType(
		PBFisPatternType pbFisPatternType)
		throws InvalidParameterException {
		FisData.FisPatternType fisPatternType = new FisData.FisPatternType();
		fisPatternType.setTYPE1(pbFisPatternType.getTYPE1());
		fisPatternType.setRFU1(pbFisPatternType.getRFU1());
		fisPatternType.setTYPE2(pbFisPatternType.getTYPE2());
		fisPatternType.setRFU2(pbFisPatternType.getRFU2());
		return fisPatternType;
	}

	/**
	 * 
	 * @param pbPalmOutputList
	 * @param palmOutputList
	 */
	private static void toPalmOutput(
		List<PBExtractPalmOutput> pbPalmOutputList,
		List<PalmOutput> palmOutputList)
		throws InvalidParameterException {
		for (PBExtractPalmOutput pbPalmOutput : pbPalmOutputList) {
			PalmOutput palmOutput = new PalmOutput();
			palmOutput.setPos(getValue(pbPalmOutput.getPosition(),
				imagePositionTypeToIntPosition));
			palmOutput.setMinutiaData(toMinutiaData(pbPalmOutput.getMinutiaData()));
			if (0 < pbPalmOutput.getPrefilterDataCount()) {
				PrefilterOutput prefilterOutput = new PrefilterOutput();
				toPrefilterOutput(pbPalmOutput.getPrefilterDataList(), prefilterOutput);
				palmOutput.setPrefilterOutput(prefilterOutput);
			}
			palmOutput.setPaextData(toPaextData(pbPalmOutput.getPaExtData()));
			setImageData(pbPalmOutput.getImageData(), palmOutput);
			palmOutputList.add(palmOutput);
		}
	}

	/**
	 * 
	 * @param pbPalmOutput
	 * @return
	 * @throws InvalidParameterException
	 */
	private static PalmOutput toPalmOutput(PBExtractLatentPalmOutput pbPalmOutput)
		throws InvalidParameterException {
		PalmOutput palmOutput = new PalmOutput();
		palmOutput.setMinutiaData(toMinutiaData(pbPalmOutput.getMinutiaData()));
		if (0 < pbPalmOutput.getPrefilterDataCount()) {
			PrefilterOutput prefilterOutput = new PrefilterOutput();
			toPrefilterOutput(pbPalmOutput.getPrefilterDataList(), prefilterOutput);
			palmOutput.setPrefilterOutput(prefilterOutput);
		}
		if (pbPalmOutput.hasPaExtData()) {
			palmOutput.setPaextData(toPaextData(pbPalmOutput.getPaExtData()));
		}
		return palmOutput;
	}

	/**
	 * 
	 * @param pbPaExtData
	 * @return
	 */
	private static PaextData toPaextData(PBPaExtData pbPaExtData) {
		PaextData paextData = new PaextData();
		paextData.setMinutiaData(pbPaExtData.getMinutia().toByteArray());
		paextData.setSkeleton(pbPaExtData.getSkeleton().toByteArray());
		return paextData;
	}

	/**
	 * 
	 * @param pbLatentOutput
	 * @return
	 * @throws InvalidParameterException
	 */
	private static LatentOutput toLatentOutput(PBExtractLatentOutput pbLatentOutput)
		throws InvalidParameterException {
		LatentOutput latentOutput = new LatentOutput();
		if (pbLatentOutput.hasFingerOutput()) {
			latentOutput
				.setFingerOutput(toFingerOutput(pbLatentOutput.getFingerOutput()));
		}
		if (pbLatentOutput.hasPalmOutput()) {
			latentOutput.setPalmOutput(toPalmOutput(pbLatentOutput.getPalmOutput()));
		}
		return latentOutput;
	}

	/**
	 * 
	 * @param pbLatentFingerOutput
	 * @return
	 * @throws InvalidParameterException
	 */
	private static FingerOutput toFingerOutput(
		PBExtractLatentFingerOutput pbLatentFingerOutput)
		throws InvalidParameterException {
		FingerOutput fingerOutput = new FingerOutput();
		if (0 < pbLatentFingerOutput.getMinutiaDataCount()) {
			toMinutiaData(pbLatentFingerOutput.getMinutiaDataList(), fingerOutput
				.getMinutiaData());
		}

		if (0 < pbLatentFingerOutput.getPrefilterDataCount()) {
			PrefilterOutput prefilterOutput = new PrefilterOutput();
			toPrefilterOutput(pbLatentFingerOutput.getPrefilterDataList(),
				prefilterOutput);
			fingerOutput.setPrefilterOutput(prefilterOutput);
		}

		if (0 < pbLatentFingerOutput.getFisDataCount()) {
			toFisData(pbLatentFingerOutput.getFisDataList(), fingerOutput.getFisData());
		}
		return fingerOutput;
	}

	/**
	 * 
	 * @param pbExtractFaceOutput
	 * @return
	 */
	private static FaceOutput toFaceOutput(PBExtractFaceOutput pbExtractFaceOutput) {
		FaceOutput faceOutput = new FaceOutput();
		faceOutput.setDetection(toFaceOutputDetection(pbExtractFaceOutput
			.getDetectionOutputList()));
		return faceOutput;
	}

	/**
	 * 
	 * @param pbDetectionOutputList
	 * @return
	 */
	private static FaceOutputDetection toFaceOutputDetection(
		List<PBExtractFaceDetectionOutput> pbDetectionOutputList) {
		FaceOutputDetection outputDetection = new FaceOutputDetection();
		outputDetection.setDetectedFaces(pbDetectionOutputList.size());
		for (PBExtractFaceDetectionOutput pbDetectionOutput : pbDetectionOutputList) {
			FaceOutputPoints outputPoints = new FaceOutputPoints();
			outputPoints.setBase(toFace13Points(pbDetectionOutput.getFace13Points()));
			outputPoints.setFaceRect(toFaceRect(pbDetectionOutput.getFaceRectPoints()));
			outputPoints.setHeadRect(toHeadRect(pbDetectionOutput.getHeadRectPoints()));
			if (pbDetectionOutput.hasImageAnalysis()) {
				outputPoints.setImageAnalysis(toImageAnalysis(pbDetectionOutput
					.getImageAnalysis()));
			}
			outputPoints.setNum(pbDetectionOutput.getFaceNumber());
			if (pbDetectionOutput.hasFaceReliability()) {
				if (pbDetectionOutput.getFaceReliability().hasDetectionScore()) {
					outputPoints.setDetectionScore(Float.valueOf(pbDetectionOutput
						.getFaceReliability().getDetectionScore()));
				}
				if (pbDetectionOutput.getFaceReliability()
					.hasPossibilityNegativeDetection()) {
					outputPoints.setPossiblityNegativeDetection(Boolean
						.valueOf(pbDetectionOutput.getFaceReliability()
							.getPossibilityNegativeDetection()));
				}
			}
			outputDetection.getPoints().add(outputPoints);
		}
		return outputDetection;
	}

	/**
	 * 
	 * @param pbFace13Points
	 * @return
	 */
	private static Face13Points toFace13Points(PBFace13Points pbFace13Points) {
		Face13Points face13Points = new Face13Points();
		face13Points.setRightEyeCenter(toFacePoint(pbFace13Points.getRightEyeCenter()));
		face13Points.setLeftEyeCenter(toFacePoint(pbFace13Points.getLeftEyeCenter()));
		face13Points.setRightEyeInnerCorner(toFacePoint(pbFace13Points
			.getRightEyeInnerCorner()));
		face13Points.setLeftEyeInnerCorner(toFacePoint(pbFace13Points
			.getLeftEyeInnerCorner()));
		face13Points.setRightEyeOuterCorner(toFacePoint(pbFace13Points
			.getRightEyeOuterCorner()));
		face13Points.setLeftEyeOuterCorner(toFacePoint(pbFace13Points
			.getLeftEyeOuterCorner()));
		face13Points.setCenterBelowNose(toFacePoint(pbFace13Points.getCenterBelowNose()));
		face13Points.setRightSideNose(toFacePoint(pbFace13Points.getRightSideNose()));
		face13Points.setLeftSideNose(toFacePoint(pbFace13Points.getLeftSideNose()));
		face13Points
			.setRightCornerMouth(toFacePoint(pbFace13Points.getRightCornerMouth()));
		face13Points.setLeftCornerMouth(toFacePoint(pbFace13Points.getLeftCornerMouth()));
		face13Points.setTopCenterUpperLip(toFacePoint(pbFace13Points
			.getTopCenterUpperLip()));
		face13Points.setBottomCenterUpperLip(toFacePoint(pbFace13Points
			.getBottomCenterUpperLip()));

		return face13Points;
	}

	/**
	 * 
	 * @param pbRect
	 * @return
	 */
	private static FaceRect toFaceRect(PBFaceRectPoints pbRect) {
		FaceRect faceRect = new FaceRect();
		faceRect.setUpperLeft(toFacePoint(pbRect.getUpperLeft()));
		faceRect.setUpperRight(toFacePoint(pbRect.getUpperRight()));
		faceRect.setLowerLeft(toFacePoint(pbRect.getLowerLeft()));
		faceRect.setLowerRight(toFacePoint(pbRect.getLowerRight()));
		return faceRect;
	}

	/**
	 * 
	 * @param pbRect
	 * @return
	 */
	private static HeadRect toHeadRect(PBFaceRectPoints pbRect) {
		HeadRect headRect = new HeadRect();
		headRect.setUpperLeft(toFacePoint(pbRect.getUpperLeft()));
		headRect.setUpperRight(toFacePoint(pbRect.getUpperRight()));
		headRect.setLowerLeft(toFacePoint(pbRect.getLowerLeft()));
		headRect.setLowerRight(toFacePoint(pbRect.getLowerRight()));
		return headRect;
	}

	/**
	 * 
	 * @param pbImageAnalysis
	 * @return
	 */
	private static ImageAnalysis toImageAnalysis(PBFaceImageAnalysis pbImageAnalysis) {
		ImageAnalysis imageAnalysis = new ImageAnalysis();
		FaceAnalysisOutput output = null;
		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getImageSize()));
		imageAnalysis.setImageSize(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getWidthHeightRatio()));
		imageAnalysis.setWidthHeightRatio(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getEyeDistance()));
		imageAnalysis.setEyeDistance(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getEyeWidth()));
		imageAnalysis.setEyeWidth(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getColorProfile()));
		imageAnalysis.setColorProfile(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getHeadRotationHorizontal()));
		imageAnalysis.setHeadRotationHorizontal(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getHeadRotationVertical()));
		imageAnalysis.setHeadRotationVertical(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getHeadPositionHorizontal()));
		imageAnalysis.setHeadPositionHorizontal(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getHeadPositionVertical()));
		imageAnalysis.setHeadPositionVertical(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getHeadWidth()));
		imageAnalysis.setHeadWidth(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getHeadLength()));
		imageAnalysis.setHeadLength(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getColorBrightness()));
		imageAnalysis.setColorBrightness(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getColorContrast()));
		imageAnalysis.setColorContrast(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getColorCast()));
		imageAnalysis.setColorCast(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getBlockyArtifacts()));
		imageAnalysis.setBlockyArtifacts(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getImageSharpness()));
		imageAnalysis.setImageSharpness(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getRedEyes()));
		imageAnalysis.setRedEyes(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getFaceShadow()));
		imageAnalysis.setFaceShadow(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getInterferingBackground()));
		imageAnalysis.setInterferingBackground(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getGreyValueBackground()));
		imageAnalysis.setGreyValueBackground(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getColorVariationBackground()));
		imageAnalysis.setColorVariationBackground(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getGlassesCoverageSunglasses()));
		imageAnalysis.setGlassesCoverageSunglasses(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getGlassesCoverageReflection()));
		imageAnalysis.setGlassesCoverageReflection(output);

		output = new FaceAnalysisOutput();
		output.setValue(Double.valueOf(pbImageAnalysis.getGlassesCoverageHeavyFrame()));
		imageAnalysis.setGlassesCoverageHeavyFrame(output);

		return imageAnalysis;
	}

	/**
	 * 
	 * @param pbPoint
	 * @return
	 */
	private static FacePoint toFacePoint(PBPoint pbPoint) {
		FacePoint facePoint = new FacePoint();
		facePoint.setX(Integer.valueOf(pbPoint.getX()));
		facePoint.setY(Integer.valueOf(pbPoint.getY()));
		return facePoint;
	}

	/**
	 * 
	 * @param extOutput
	 * @return
	 * @throws MarshalException
	 */
	private DynamicXml toDynamicXml(ExtOutput extOutput)
		throws MarshalException {
		DynamicXml dynamicXml = new DynamicXml();
		try {
			Marshaller marshaller = marshallerHolder.get();
			marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
			StringWriter sw = new StringWriter();
			marshaller.marshal(extOutput, sw);

			DocumentBuilder builder =
				DocumentBuilderFactory.newInstance().newDocumentBuilder();
			ByteArrayInputStream bais =
				new ByteArrayInputStream(sw.toString().getBytes("UTF-8"));
			Document document = builder.parse(bais);
			// ExtOutput has a tenprint or a face or a latent or a iris output.
			int length = document.getFirstChild().getChildNodes().getLength();
			Node node = null;
			for (int i = 0; i < length; i++) {
				if (document.getFirstChild().getChildNodes().item(i).getNodeType() == Node.ELEMENT_NODE) {
					node = document.getFirstChild().getChildNodes().item(1);
				}
			}
			if (node == null) {
				throw new SAXException("There is no output element.");
			}
			dynamicXml.setAny((Element)node);
		} catch (ParserConfigurationException | IOException | SAXException
			| JAXBException e) {
			throw new MarshalException(Throwables.getStackTraceAsString(e));
		}
		return dynamicXml;
	}

	/**
	 * 
	 * @param message
	 * @throws InvalidParameterException
	 */
	private static void throwInvalidParameterException(String message)
		throws InvalidParameterException {
		throw new InvalidParameterException(new StringBuffer("An invalid parameter: ")
			.append(message).toString());
	}

	/**
	 * 
	 * @param pbPsrData
	 * @return
	 * @throws InvalidParameterException
	 */
	private static PsrData toPsrData(PBFingerPsrData pbPsrData)
		throws InvalidParameterException {
		PsrData psrData = new PsrData();
		if (pbPsrData.hasFusionId()) {
			psrData.setFusionId(Integer.valueOf(pbPsrData.getFusionId()));
		}
		psrData.setType(getValue(pbPsrData.getType(), protoPsrTypeToJaxbPsrType));
		psrData.setValue(pbPsrData.getData().toByteArray());
		return psrData;
	}

	/**
	 * 
	 * @param pbFingerOutput
	 * @param fingerOutput
	 */
	private static void setImageData(PBImageData pbImageData, FingerOutput fingerOutput) {
		if (pbImageData.hasCroppedImage()) {
			fingerOutput.setCroppedImage(pbImageData.getCroppedImage().toByteArray());
		}
		if (pbImageData.hasLowResolutionImage()) {
			byte[] image = pbImageData.getLowResolutionImage().toByteArray();
			fingerOutput.setLowResImage(image);
		}
	}

	/**
	 * 
	 * @param pbImageData
	 * @param palmOutput
	 */
	private static void setImageData(PBImageData pbImageData, PalmOutput palmOutput) {
		if (pbImageData.hasLowResolutionImage()) {
			palmOutput.setLowResImage(pbImageData.getLowResolutionImage().toByteArray());
		}
	}

	/**
	 * 
	 * @param pbPoint
	 * @return
	 */
	private static Point toPoint(PBPoint pbPoint) {
		Point Point = new Point();
		Point.setX(Integer.valueOf(pbPoint.getX()));
		Point.setY(Integer.valueOf(pbPoint.getY()));
		return Point;
	}

	/**
	 * 
	 * @param detailList
	 * @param resultList
	 */
	private static void toContainerResult(
		List<PBCheckExternalIdResultDetail> detailList,
		List<ContainerResult> resultList) {
		for (PBCheckExternalIdResultDetail detail : detailList) {
			ContainerResult containerResult = new ContainerResult();
			containerResult.setContainerId(detail.getContainerId());
			containerResult.setNumOfValid(detail.getNumOfValid());
			containerResult.setNumOfCorrupted(detail.getNumOfCorrupted());
			resultList.add(containerResult);
		}
	}

	/**
	 * 
	 * @param pbResultList
	 * @param resultList
	 */
	private static void toCheckResult(
		List<PBCheckExternalIdResult> pbResultList,
		List<CheckResult> resultList) {
		for (PBCheckExternalIdResult result : pbResultList) {
			CheckResult checkResult = new CheckResult();
			checkResult.setEventId(result.getEventId());
			toContainerResult(result.getContainerResultList(), checkResult
				.getContainerResult());
			resultList.add(checkResult);
		}
	}

	/**
	 * 
	 * @param state
	 * @return
	 */
	private static ExtractJobError toExtractJobError(PBServiceStateReason reason) {
		ExtractJobError jobError = new ExtractJobError();
		jobError.setCode(reason.getCode());
		jobError.setMessage(reason.getDescription());
		jobError.setTime(reason.getTime());
		return jobError;
	}

	/**
	 * 
	 * @param state
	 * @return
	 */
	private static SearchJobError toSearchJobError(PBServiceStateReason reason) {
		SearchJobError jobError = new SearchJobError();
		jobError.setCode(reason.getCode());
		jobError.setMessage(reason.getDescription());
		jobError.setTime(reason.getTime());
		return jobError;
	}

	/**
	 * 
	 * @param pbIndexerList
	 * @param output
	 * @throws InvalidParameterException
	 */
	private static void toFusionIndexer(
		List<PBFusionIndexer> pbIndexerList,
		List<FusionIndexer> output)
		throws InvalidParameterException {
		for (PBFusionIndexer pbIndexer : pbIndexerList) {
			FusionIndexer indexer = new FusionIndexer();
			indexer.setFormat(getValue(pbIndexer.getFormat(),
				templateFormatTypeToStringName));
			indexer.getFusionId().addAll(pbIndexer.getFusionIdList());
			output.add(indexer);
		}
	}

	/**
	 * 
	 * @param pbPoint
	 * @return
	 */
	private static IrisPoint toIrisPoint(PBPoint pbPoint) {
		IrisPoint point = new IrisPoint();
		point.setX(Integer.valueOf(pbPoint.getX()));
		point.setY(Integer.valueOf(pbPoint.getY()));
		return point;
	}

	/**
	 * 
	 * @param detectionOutputList
	 * @return
	 * @throws InvalidParameterException
	 */
	private static List<IrisOutputPoints> toIrisOutputPoints(
		List<PBExtractIrisDetectionOutput> detectionOutputList)
		throws InvalidParameterException {
		List<IrisOutputPoints> outputPointsList = new ArrayList<>();

		for (PBExtractIrisDetectionOutput pbDetectionOutputnput : detectionOutputList) {
			IrisOutputPoints output = new IrisOutputPoints();

			output.setPosition(getValue(pbDetectionOutputnput.getPosition(),
				imagePositionTypeToIntPosition).toString());

			output.setQuality(pbDetectionOutputnput.getQuality());

			if (0 < pbDetectionOutputnput.getDetectionPoints().getIrisCount()) {
				IrisPoints irisPoints = new IrisPoints();
				for (PBPoint point : pbDetectionOutputnput.getDetectionPoints()
					.getIrisList()) {
					irisPoints.getPoints().add(toIrisPoint(point));
				}
				output.setIrisPoints(irisPoints);
			}
			if (0 < pbDetectionOutputnput.getDetectionPoints().getPupilCount()) {
				PupilPoints pupilPoints = new PupilPoints();
				for (PBPoint point : pbDetectionOutputnput.getDetectionPoints()
					.getPupilList()) {
					pupilPoints.getPoints().add(toIrisPoint(point));
				}
				output.setPupilPoints(pupilPoints);
			}
			outputPointsList.add(output);
		}
		return outputPointsList;
	}

	/**
	 * 
	 * 
	 * @param pbIrisOutput
	 * @return
	 * @throws InvalidParameterException
	 */
	private static IrisOutput toIrisOutput(PBExtractIrisOutput pbIrisOutput)
		throws InvalidParameterException {
		IrisOutputDetection detection = new IrisOutputDetection();
		detection.getPoints().addAll(
			toIrisOutputPoints(pbIrisOutput.getDetectionOutputList()));
		IrisOutput irisOutput = new IrisOutput();
		irisOutput.setDetection(detection);

		return irisOutput;
	}

	/**
	 * for test
	 * 
	 * @param dynamicXML
	 * @return
	 * @throws UnmarshalException
	 */
	@SuppressWarnings("unused")
	private static String toString(DynamicXml dynamicXML)
		throws UnmarshalException {
		try {
			StringWriter sw = new StringWriter();
			Transformer trans = TransformerFactory.newInstance().newTransformer();
			trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			trans.transform(new DOMSource(dynamicXML.getAny()), new StreamResult(sw));
			// System.out.println(sw.toString());
			return sw.toString();
		} catch (TransformerException e) {
			throw new UnmarshalException(Throwables.getStackTraceAsString(e));
		}
	}

}
