package jp.co.nec.aim.convert;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerAxisType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPatternType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionBaseType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.GenderType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.PalmPositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.PrefilterYobMethodType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.RaceType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.RegionCodeType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.BasicImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.CMLaFFeTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.CMLaFImageEnhanceType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.ExtractOutputModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionAlgorithmType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionRotationType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionShrinkFactorType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceDetectionSortingOrderType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceExtractProcessType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FisTypeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.ImageWhiteBlackLevelType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaDbType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.MinutiaType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckAdvancedActivityType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckAdvancedStateType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.QualityCheckModeType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.IrisExtractionModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.CMLaFSearchModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.FilterModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.FingerSelectionModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.IrisSearchModeType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeAlgorithmType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeCorePositionType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LeRotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.LfmlSearchLevelType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.PalmRotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2DistortionLevelType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2RotationLimitType;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2SpeedLevelType;
import jp.co.nec.aim.mm.jaxb.AxisEnum;
import jp.co.nec.aim.mm.jaxb.CmlafEnhType;
import jp.co.nec.aim.mm.jaxb.DetectionAlgorithm;
import jp.co.nec.aim.mm.jaxb.DetectionMode;
import jp.co.nec.aim.mm.jaxb.EnhType;
import jp.co.nec.aim.mm.jaxb.ExtInfoModeFormat;
import jp.co.nec.aim.mm.jaxb.ExtractionFormats;
import jp.co.nec.aim.mm.jaxb.FaceProcessMode;
import jp.co.nec.aim.mm.jaxb.FaceRotation;
import jp.co.nec.aim.mm.jaxb.GenderEnum;
import jp.co.nec.aim.mm.jaxb.ImageFormat;
import jp.co.nec.aim.mm.jaxb.InquirySetEnum;
import jp.co.nec.aim.mm.jaxb.IrisSearchMode;
import jp.co.nec.aim.mm.jaxb.IrisExtractionMode;
import jp.co.nec.aim.mm.jaxb.JobStateEnum;
import jp.co.nec.aim.mm.jaxb.LfmlDistortionLevel;
import jp.co.nec.aim.mm.jaxb.LfmlRotationLimit;
import jp.co.nec.aim.mm.jaxb.LfmlSearchLevel;
import jp.co.nec.aim.mm.jaxb.LfmlSpeedLevel;
import jp.co.nec.aim.mm.jaxb.QcActivity;
import jp.co.nec.aim.mm.jaxb.QcDetailStatus;
import jp.co.nec.aim.mm.jaxb.QcMode;
import jp.co.nec.aim.mm.jaxb.ShrinkFactor;
import jp.co.nec.aim.mm.jaxb.SortingOrder;
import jp.co.nec.aim.mm.jaxb.WhiteBlackLevel;

import com.google.common.base.Throwables;

public final class ConvertCommon {
	private static final JAXBContext jaxbContext = getInstance();

	static final Integer RDBT_CONTAINER_ID = Integer.valueOf(1);
	static final Integer SDBT_CONTAINER_ID = Integer.valueOf(2);
	static final Integer RDBTM_CONTAINER_ID = new Integer(331);
	static final Integer SDBTM_CONTAINER_ID = new Integer(332);
	static final Integer RDBL_CONTAINER_ID = Integer.valueOf(3);
	static final Integer SDBL_CONTAINER_ID = Integer.valueOf(4);
	static final Integer RDBLS_CONTAINER_ID = new Integer(323);
	static final Integer SDBLS_CONTAINER_ID = new Integer(324);
	static final Integer RDBLM_CONTAINER_ID = new Integer(333);
	static final Integer SDBLM_CONTAINER_ID = new Integer(334);
	static final Integer XDBL_CONTAINER_ID = new Integer(341);
	static final Integer PDB_CONTAINER_ID = Integer.valueOf(5);
	static final Integer FDB_CONTAINER_ID = new Integer(335);
	static final Integer LDB_CONTAINER_ID = new Integer(321);
	static final Integer PLDB_CONTAINER_ID = new Integer(322);
	static final Integer LDBS_CONTAINER_ID = new Integer(326);
	static final Integer LDBM_CONTAINER_ID = new Integer(336);
	static final Integer LDBX_CONTAINER_ID = new Integer(342);
	static final Integer IDB_CONTAINER_ID = new Integer(343);

	static final Map<String, TemplateFormatType> stringToTemplateFormatTypeForRegistration;
	static final Map<String, ImagePositionType> stringToImagePositionType;
	static final Map<String, FingerPrintType> stringToFingerPrintType;
	static final Map<String, TemplateFormatType> functionNameToTemplateFormatType;
	static final Map<String, InquiryFunctionType> stringToInquiryFuncionType;
	static final Map<AfisLowLevelFunctionEnum, InquiryFunctionType> afisLowLevelFunctionEnumToInquiryFuncionType;
	static final Map<TemplateFormatType, List<String>> templateFormatTypeToListString;
	static final Map<Integer, TemplateFormatType> intToTemplateFormatType;
	static final Map<Integer, FingerPrintType> intToFingerPrintType;
	static final Map<String, Integer> stringToIntIndex;
	static final Map<GenderEnum, GenderType> genderEnumToGenderType;
	static final Map<String, RaceType> stringToRaceType;
	static final Map<Character, RegionCodeType> byteToRegionCodeType;
	static final Map<Character, FingerPatternType> byteToFingerPatternType;
	static final Map<Integer, FingerPositionBaseType> intToFingerPositionBaseType;
	static final Map<Character, PalmPositionType> byteToPalmPositionType;
	static final Map<String, FilterModeType> stringToFilterModeType;
	static final Map<String, FingerSelectionModeType> stringToFingerSelectionModeType;
	static final Map<String, PrefilterYobMethodType> stringToYobMethodType;
	static final Map<String, Pc2SpeedLevelType> stringToPc2SpeedLevelType;
	static final Map<String, Pc2RotationLimitType> stringToPc2RotationLimitType;
	static final Map<String, Pc2DistortionLevelType> stringToPc2DistortionLevelType;
	static final Map<String, LeAlgorithmType> stringToLeAlgorithmType;
	static final Map<String, LeRotationLimitType> stringToLeRotationLimitType;
	static final Map<String, LeCorePositionType> stringToLeCorePositionType;
	static final Map<String, PalmRotationLimitType> stringToPalmRotationLimitType;
	static final Map<String, CMLaFSearchModeType> stringToCmlafSearchModeType;
	static final Map<String, Pc2RotationLimitType> stringToTimPc2RotationLimitType;
	static final Map<JobStateType, JobStateEnum> jobStateTypeToJobStateEnum;
	static final Map<FingerAxisType, AxisEnum> fingerAxisTypeToAxisEnum;
	static final Map<LfmlSearchLevel, LfmlSearchLevelType> lfmlSearchLevelToLfmlSearchLevelType;
	static final Map<FingerSetType, InquirySetEnum> fingerSetTypeToInquirySetEnum;
	static final Map<ExtractionFormats, TemplateFormatType> extractionFormatsToTemplateFormatType;
	static final Map<String, FisTypeType> stringToFisTypeType;
	static final Map<String, ImagePositionType> posToImagePositionType;
	static final Map<ImageFormat, ImageFormatType> imageFormatToImageFormatType;
	static final Map<WhiteBlackLevel, ImageWhiteBlackLevelType> whiteBlackLevelToImageWhiteBlackLevelType;
	static final Map<String, MinutiaDbType> stringToMinutiaDbType;
	static final Map<String, MinutiaType> stringToMinutiaType;
	static final Map<EnhType, BasicImageEnhanceType> enhTypeToBasicImageEnhganceType;
	static final Map<QcMode, QualityCheckModeType> qcModeToQualityCheckModeType;
	static final Map<Integer, CMLaFFeTypeType> intToCmlafFeTypeType;
	static final Map<CmlafEnhType, CMLaFImageEnhanceType> cmlafEnhTypeToCmlafImageEnhganceType;
	static final Map<ExtInfoModeFormat, ExtractOutputModeType> extInfoModeFormatToExtractOutputModeType;
	static final Map<FaceProcessMode, FaceExtractProcessType> faceProcessModeToFaceExtractProcessType;
	static final Map<DetectionMode, FaceDetectionModeType> detectionModeToFaceDetectionModeType;
	static final Map<SortingOrder, FaceDetectionSortingOrderType> sortingOrderToFaceDetectionSortingOrderType;
	static final Map<DetectionAlgorithm, FaceDetectionAlgorithmType> detectionAlgorithmToFaceDetectionAlgorithmType;
	static final Map<FaceRotation, List<FaceDetectionRotationType>> faceRotationToListFaceDetectionRotationType;
	static final Map<ShrinkFactor, FaceDetectionShrinkFactorType> shrinkFactorToFaceDetectionShrinkFactorType;
	static final Map<ImagePositionType, Integer> imagePositionTypeToIntKey;
	static final Map<FingerPositionType, Integer> fingerPositionTypeToInt;
	static final Map<FingerPositionType, String> fingerPositionTypeToString;
	static final Map<QualityCheckAdvancedActivityType, QcActivity> qualityCheckAdvancedActivityTypeToQcActivity;
	static final Map<QualityCheckAdvancedStateType, QcDetailStatus> qualityCheckAdvancedStateTypeToQcDetailStatus;
	static final Map<jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType, jp.co.nec.aim.mm.jaxb.PsrType> protoPsrTypeToJaxbPsrType;
	static final Map<ImagePositionType, Integer> imagePositionTypeToIntPosition;
	static final Map<FingerPatternType, String> fingerPatternTypeToString;
	static final Map<MinutiaType, String> minutiaTypeToString;
	static final Map<MinutiaDbType, String> minutiaDbTypeToString;
	static final Map<FisTypeType, String> fisTypeTypeToString;
	static final Map<String, List<Integer>> stringToListInt;
	static final Map<InquirySetEnum, FingerSetType> inquirySetEnumToFingerSetType;
	static final Map<Integer, FingerPositionBaseType> intToFingerPositionBaseTypeForSelectFinger;
	static final Map<String, TemplateFormatType> stringToTemplateFormatTypeForInquiry;
	static final Map<Integer, String> intContainerIdToString;
	static final Map<LfmlRotationLimit, Pc2RotationLimitType> lfmlRotationLimitToPc2RotationLimitType;
	static final Map<LfmlSpeedLevel, Pc2SpeedLevelType> lfmlSpeedLevelToPc2SpeedLevelType;
	static final Map<LfmlDistortionLevel, Pc2DistortionLevelType> lfmlDistortionLevelToPc2DistortionLevelType;
	static final Map<TemplateFormatType, String> templateFormatTypeToStringName;
	static final Map<TemplateFormatType, String> templateFormatTypeToStringDbType;
	static final Map<IrisSearchMode, IrisSearchModeType> irisSearchModeToIrisSearchModeType;
	static final Map<String, TemplateFormatType> stringToTemplateFormatTypeForGetBinary;
	static final Map<String, TemplateFormatType> stringSearchTemplateToTemplateFormatTypeForGetBinary;
	static final Map<String, TemplateFormatType> stringToTemplateFormatTypeForInsert;
	static final Map<IrisExtractionMode, IrisExtractionModeType> irisExtractionModeToIrisExtractionModeType; 

	static final String EMPTY = "";

	static {
		{
			// table 1
			String[] rolledKeys = {
				"RDBL_", "RDBLS_", "RDBLM_"
			};
			Map<String, ImagePositionType> map = new HashMap<>();
			for (int i = 0; i < rolledKeys.length; i++) {
				map.put(new StringBuilder(rolledKeys[i]).append("1").toString(),
					ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
				map.put(new StringBuilder(rolledKeys[i]).append("2").toString(),
					ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX);
				map.put(new StringBuilder(rolledKeys[i]).append("3").toString(),
					ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE);
				map.put(new StringBuilder(rolledKeys[i]).append("4").toString(),
					ImagePositionType.IMAGE_ROLLED_RIGHT_RING);
				map.put(new StringBuilder(rolledKeys[i]).append("5").toString(),
					ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE);
				map.put(new StringBuilder(rolledKeys[i]).append("6").toString(),
					ImagePositionType.IMAGE_ROLLED_LEFT_THUMB);
				map.put(new StringBuilder(rolledKeys[i]).append("7").toString(),
					ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
				map.put(new StringBuilder(rolledKeys[i]).append("8").toString(),
					ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE);
				map.put(new StringBuilder(rolledKeys[i]).append("9").toString(),
					ImagePositionType.IMAGE_ROLLED_LEFT_RING);
				map.put(new StringBuilder(rolledKeys[i]).append("10").toString(),
					ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE);
			}
			String[] slapKeys = {
				"SDBL_", "SDBLS_", "SDBLM_"
			};
			for (int i = 0; i < slapKeys.length; i++) {
				map.put(new StringBuilder(slapKeys[i]).append("1").toString(),
					ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
				map.put(new StringBuilder(slapKeys[i]).append("2").toString(),
					ImagePositionType.IMAGE_SLAP_RIGHT_INDEX);
				map.put(new StringBuilder(slapKeys[i]).append("3").toString(),
					ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE);
				map.put(new StringBuilder(slapKeys[i]).append("4").toString(),
					ImagePositionType.IMAGE_SLAP_RIGHT_RING);
				map.put(new StringBuilder(slapKeys[i]).append("5").toString(),
					ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE);
				map.put(new StringBuilder(slapKeys[i]).append("6").toString(),
					ImagePositionType.IMAGE_SLAP_LEFT_THUMB);
				map.put(new StringBuilder(slapKeys[i]).append("7").toString(),
					ImagePositionType.IMAGE_SLAP_LEFT_INDEX);
				map.put(new StringBuilder(slapKeys[i]).append("8").toString(),
					ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE);
				map.put(new StringBuilder(slapKeys[i]).append("9").toString(),
					ImagePositionType.IMAGE_SLAP_LEFT_RING);
				map.put(new StringBuilder(slapKeys[i]).append("10").toString(),
					ImagePositionType.IMAGE_SLAP_LEFT_LITTLE);
			}

			ImagePositionType[] palmValues =
				{
					ImagePositionType.IMAGE_PALM_RIGHT_FULL,
					ImagePositionType.IMAGE_PALM_RIGHT_WRITER,
					ImagePositionType.IMAGE_PALM_LEFT_FULL,
					ImagePositionType.IMAGE_PALM_LEFT_WRITER,
					ImagePositionType.IMAGE_PALM_RIGHT_LOWER,
					ImagePositionType.IMAGE_PALM_RIGHT_UPPER,
					ImagePositionType.IMAGE_PALM_LEFT_LOWER,
					ImagePositionType.IMAGE_PALM_LEFT_UPPER,
					ImagePositionType.IMAGE_PALM_RIGHT_OTHER,
					ImagePositionType.IMAGE_PALM_LEFT_OTHER,
					ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL,
					ImagePositionType.IMAGE_PALM_RIGHT_THENAR,
					ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR,
					ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL,
					ImagePositionType.IMAGE_PALM_LEFT_THENAR,
					ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR
				};
			for (int i = 0; i < palmValues.length; i++) {
				map.put(new StringBuilder("PDB_").append(i + 1).toString(), palmValues[i]);
			}
			stringToImagePositionType = Collections.unmodifiableMap(map);
		}
		{
			// table 2
			Map<String, TemplateFormatType> map = new HashMap<>();
			map.put("RDBT", TemplateFormatType.TEMPLATE_RDBT);
			map.put("SDBT", TemplateFormatType.TEMPLATE_RDBT);
			map.put("RDBTM", TemplateFormatType.TEMPLATE_RDBTM);
			map.put("SDBTM", TemplateFormatType.TEMPLATE_RDBTM);
			map.put("XDBL", TemplateFormatType.TEMPLATE_RDBLX);
			map.put("LR", TemplateFormatType.TEMPLATE_LDB);
			map.put("LRP", TemplateFormatType.TEMPLATE_PLDB);
			map.put("LRS", TemplateFormatType.TEMPLATE_LDBS);
			map.put("LRM", TemplateFormatType.TEMPLATE_LDBM);
			map.put("LRX", TemplateFormatType.TEMPLATE_LDBX);
			map.put("IDB", TemplateFormatType.TEMPLATE_IDB);

			String[] keys = {
				"RDBL_", "RDBLS_", "RDBLM_", "SDBL_", "SDBLS_", "SDBLM_"
			};
			TemplateFormatType[] templates =
				{
					TemplateFormatType.TEMPLATE_RDBL, TemplateFormatType.TEMPLATE_RDBLS,
					TemplateFormatType.TEMPLATE_RDBLM
				};

			for (int i = 0; i < keys.length; i++) {
				for (int number = 1; number < 11; number++) {
					map.put(new StringBuilder(keys[i]).append(number).toString(),
						templates[i % 3]);
				}
			}

			for (int i = 1; i < 17; i++) {
				map.put(new StringBuilder("PDB_").append(i).toString(),
					TemplateFormatType.TEMPLATE_PDB);
			}
			for (int i = 1; i < 11; i++) {
				map.put(new StringBuilder("FDB_").append(i).toString(),
					TemplateFormatType.TEMPLATE_FDB);
			}

			stringToTemplateFormatTypeForRegistration = Collections.unmodifiableMap(map);
		}
		{
			// table 3
			Map<String, FingerPrintType> map = new HashMap<>();
			map.put("RDBT", FingerPrintType.FINGER_PRINT_ROLLED);
			map.put("SDBT", FingerPrintType.FINGER_PRINT_SLAP);
			map.put("RDBTM", FingerPrintType.FINGER_PRINT_ROLLED);
			map.put("SDBTM", FingerPrintType.FINGER_PRINT_SLAP);
			map.put("TI_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED);
			map.put("TI_SLAP", FingerPrintType.FINGER_PRINT_SLAP);
			map.put("TIM_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED);
			map.put("TIM_SLAP", FingerPrintType.FINGER_PRINT_SLAP);
			map.put("TLI_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED);
			map.put("TLI_SLAP", FingerPrintType.FINGER_PRINT_SLAP);
			map.put("TLIS_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED);
			map.put("TLIS_SLAP", FingerPrintType.FINGER_PRINT_SLAP);
			map.put("TLIM_ROLLED", FingerPrintType.FINGER_PRINT_ROLLED);
			map.put("TLIM_SLAP", FingerPrintType.FINGER_PRINT_SLAP);
			stringToFingerPrintType = Collections.unmodifiableMap(map);
		}
		{
			// table 4
			Map<String, TemplateFormatType> map = new HashMap<>();
			map.put("TI", TemplateFormatType.TEMPLATE_TI);
			map.put("TI-M", TemplateFormatType.TEMPLATE_TIM);
			map.put("TLI", TemplateFormatType.TEMPLATE_TLI);
			map.put("TLI-S", TemplateFormatType.TEMPLATE_TLIS);
			map.put("TLI-M", TemplateFormatType.TEMPLATE_TLIM);
			map.put("TLI-X", TemplateFormatType.TEMPLATE_TLIX);
			map.put("LI", TemplateFormatType.TEMPLATE_LI);
			map.put("LI-S", TemplateFormatType.TEMPLATE_LIS);
			map.put("LI-M", TemplateFormatType.TEMPLATE_LIM);
			map.put("LI-X", TemplateFormatType.TEMPLATE_LIX);
			map.put("LLI", TemplateFormatType.TEMPLATE_LLI);
			map.put("LLI-S", TemplateFormatType.TEMPLATE_LLIS);
			map.put("LLI-M", TemplateFormatType.TEMPLATE_LLIM);
			map.put("LLI-X", TemplateFormatType.TEMPLATE_LLIX);
			map.put("LI-P", TemplateFormatType.TEMPLATE_LIP);
			map.put("LLI-P", TemplateFormatType.TEMPLATE_LLIP);
			map.put("TLI-P", TemplateFormatType.TEMPLATE_TLIP);
			map.put("FI", TemplateFormatType.TEMPLATE_FI);
			map.put("II", TemplateFormatType.TEMPLATE_II);
			functionNameToTemplateFormatType = Collections.unmodifiableMap(map);
		}
		{
			// table 5
			Map<String, InquiryFunctionType> map = new HashMap<>();
			map.put("TI", InquiryFunctionType.TI);
			map.put("TI-M", InquiryFunctionType.TIM);
			map.put("TLI", InquiryFunctionType.TLI);
			map.put("TLI-S", InquiryFunctionType.TLI);
			map.put("TLI-M", InquiryFunctionType.TLIM);
			map.put("TLI-X", InquiryFunctionType.TLIX);
			map.put("LI", InquiryFunctionType.LI);
			map.put("LI-S", InquiryFunctionType.LI);
			map.put("LI-M", InquiryFunctionType.LIM);
			map.put("LI-X", InquiryFunctionType.LIX);
			map.put("LLI", InquiryFunctionType.LLI);
			map.put("LLI-S", InquiryFunctionType.LLI);
			map.put("LLI-M", InquiryFunctionType.LLIM);
			map.put("LLI-X", InquiryFunctionType.LLIX);
			map.put("LI-P", InquiryFunctionType.LIP);
			map.put("LLI-P", InquiryFunctionType.LLIP);
			map.put("TLI-P", InquiryFunctionType.TLIP);
			map.put("FI", InquiryFunctionType.FI);
			map.put("II", InquiryFunctionType.II);
			stringToInquiryFuncionType = Collections.unmodifiableMap(map);
		}
		{
			// table 6
			Map<AfisLowLevelFunctionEnum, InquiryFunctionType> map = new HashMap<>();
			map.put(AfisLowLevelFunctionEnum.TI, InquiryFunctionType.TI);
			map.put(AfisLowLevelFunctionEnum.TIM, InquiryFunctionType.TIM);
			map.put(AfisLowLevelFunctionEnum.TLI, InquiryFunctionType.TLI);
			map.put(AfisLowLevelFunctionEnum.TLIM, InquiryFunctionType.TLIM);
			map.put(AfisLowLevelFunctionEnum.TLIX, InquiryFunctionType.TLIX);
			map.put(AfisLowLevelFunctionEnum.LI, InquiryFunctionType.LI);
			map.put(AfisLowLevelFunctionEnum.LIM, InquiryFunctionType.LIM);
			map.put(AfisLowLevelFunctionEnum.LIX, InquiryFunctionType.LIX);
			map.put(AfisLowLevelFunctionEnum.LLI, InquiryFunctionType.LLI);
			map.put(AfisLowLevelFunctionEnum.LLIM, InquiryFunctionType.LLIM);
			map.put(AfisLowLevelFunctionEnum.LLIX, InquiryFunctionType.LLIX);
			map.put(AfisLowLevelFunctionEnum.LIP, InquiryFunctionType.LIP);
			map.put(AfisLowLevelFunctionEnum.LLIP, InquiryFunctionType.LLIP);
			map.put(AfisLowLevelFunctionEnum.TLIP, InquiryFunctionType.TLIP);
			map.put(AfisLowLevelFunctionEnum.FI, InquiryFunctionType.FI);
			map.put(AfisLowLevelFunctionEnum.II, InquiryFunctionType.II);
			afisLowLevelFunctionEnumToInquiryFuncionType =
				Collections.unmodifiableMap(map);
		}
		{
			// table 7
			TemplateFormatType[] keys =
				{
					TemplateFormatType.TEMPLATE_RDBT, TemplateFormatType.TEMPLATE_RDBTM,
					TemplateFormatType.TEMPLATE_RDBLX, TemplateFormatType.TEMPLATE_LDB,
					TemplateFormatType.TEMPLATE_PLDB, TemplateFormatType.TEMPLATE_LDBS,
					TemplateFormatType.TEMPLATE_LDBM, TemplateFormatType.TEMPLATE_LDBX,
					TemplateFormatType.TEMPLATE_RDBL, TemplateFormatType.TEMPLATE_RDBLS,
					TemplateFormatType.TEMPLATE_RDBLM, TemplateFormatType.TEMPLATE_PDB,
					TemplateFormatType.TEMPLATE_FDB, TemplateFormatType.TEMPLATE_IDB,
					TemplateFormatType.TEMPLATE_TI, TemplateFormatType.TEMPLATE_TIM,
					TemplateFormatType.TEMPLATE_TLI, TemplateFormatType.TEMPLATE_TLIS,
					TemplateFormatType.TEMPLATE_TLIM, TemplateFormatType.TEMPLATE_TLIX,
					TemplateFormatType.TEMPLATE_LI, TemplateFormatType.TEMPLATE_LIS,
					TemplateFormatType.TEMPLATE_LIM, TemplateFormatType.TEMPLATE_LIX,
					TemplateFormatType.TEMPLATE_LLI, TemplateFormatType.TEMPLATE_LLIS,
					TemplateFormatType.TEMPLATE_LLIM, TemplateFormatType.TEMPLATE_LLIX,
					TemplateFormatType.TEMPLATE_LIP, TemplateFormatType.TEMPLATE_LLIP,
					TemplateFormatType.TEMPLATE_TLIP, TemplateFormatType.TEMPLATE_FI,
					TemplateFormatType.TEMPLATE_II,
				};
			String[][] values = {
				{
					"RDBT", "SDBT"
				}, {
					"RDBTM", "SDBTM"
				}, {
					"XDBL"
				}, {
					"LDB"
				}, {
					"PLDB"
				}, {
					"LDBS"
				}, {
					"LDBM"
				}, {
					"LDBX"
				}, {
					"RDBL_", "SDBL_"
				}, {
					"RDBLS_", "SDBLS_"
				}, {
					"RDBLM_", "SDBLM_"
				}, {
					"PDB_"
				}, {
					"FDB_"
				}, {
					"IDB"
				}, {
					"TI_ROLLED", "TI_SLAP"
				}, {
					"TIM_ROLLED", "TIM_SLAP"
				}, {
					"TLI_ROLLED", "TLI_SLAP"
				}, {
					"TLIS_ROLLED", "TLIS_SLAP"
				}, {
					"TLIM_ROLLED", "TLIM_SLAP"
				}, {
					"TLIX"
				}, {
					"LI"
				}, {
					"LIS"
				}, {
					"LIM"
				}, {
					"LIX"
				}, {
					"LLI"
				}, {
					"LLIS"
				}, {
					"LLIM"
				}, {
					"LLIX"
				}, {
					"LIP"
				}, {
					"LLIP"
				}, {
					"TLIP"
				}, {
					"FI_"
				}, {
					"II"
				}
			};
			Map<TemplateFormatType, List<String>> map = new HashMap<>();
			for (int i = 0; i < keys.length; i++) {
				map.put(keys[i], Collections.unmodifiableList(Arrays.asList(values[i])));
			}
			templateFormatTypeToListString = Collections.unmodifiableMap(map);
		}
		{
			// table 8
			Map<Integer, TemplateFormatType> map = new HashMap<>();
			map.put(RDBT_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBT);
			map.put(SDBT_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBT);
			map.put(RDBTM_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBTM);
			map.put(SDBTM_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBTM);
			map.put(RDBL_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBL);
			map.put(SDBL_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBL);
			map.put(RDBLS_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBLS);
			map.put(SDBLS_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBLS);
			map.put(RDBLM_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBLM);
			map.put(SDBLM_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBLM);
			map.put(XDBL_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBLX);
			map.put(PDB_CONTAINER_ID, TemplateFormatType.TEMPLATE_PDB);
			map.put(FDB_CONTAINER_ID, TemplateFormatType.TEMPLATE_FDB);
			map.put(LDB_CONTAINER_ID, TemplateFormatType.TEMPLATE_LDB);
			map.put(PLDB_CONTAINER_ID, TemplateFormatType.TEMPLATE_PLDB);
			map.put(LDBS_CONTAINER_ID, TemplateFormatType.TEMPLATE_LDBS);
			map.put(LDBM_CONTAINER_ID, TemplateFormatType.TEMPLATE_LDBM);
			map.put(LDBX_CONTAINER_ID, TemplateFormatType.TEMPLATE_LDBX);
			map.put(IDB_CONTAINER_ID, TemplateFormatType.TEMPLATE_IDB);
			intToTemplateFormatType = Collections.unmodifiableMap(map);
		}
		{
			// table 9
			Map<Integer, FingerPrintType> map = new HashMap<>();
			map.put(RDBT_CONTAINER_ID, FingerPrintType.FINGER_PRINT_ROLLED);
			map.put(SDBT_CONTAINER_ID, FingerPrintType.FINGER_PRINT_SLAP);
			map.put(RDBTM_CONTAINER_ID, FingerPrintType.FINGER_PRINT_ROLLED);
			map.put(SDBTM_CONTAINER_ID, FingerPrintType.FINGER_PRINT_SLAP);
			map.put(RDBL_CONTAINER_ID, FingerPrintType.FINGER_PRINT_ROLLED);
			map.put(SDBL_CONTAINER_ID, FingerPrintType.FINGER_PRINT_SLAP);
			map.put(RDBLS_CONTAINER_ID, FingerPrintType.FINGER_PRINT_ROLLED);
			map.put(SDBLS_CONTAINER_ID, FingerPrintType.FINGER_PRINT_SLAP);
			map.put(RDBLM_CONTAINER_ID, FingerPrintType.FINGER_PRINT_ROLLED);
			map.put(SDBLM_CONTAINER_ID, FingerPrintType.FINGER_PRINT_SLAP);
			intToFingerPrintType = Collections.unmodifiableMap(map);
		}
		{
			// table 10
			String[] keys = {
				"FDB_", "FI_"
			};
			Map<String, Integer> map = new HashMap<>();
			for (int i = 0; i < keys.length; i++) {
				for (int number = 1; number < 11; number++) {
					map.put(new StringBuilder(keys[i]).append(number).toString(), Integer
						.valueOf(number));
				}
			}
			stringToIntIndex = Collections.unmodifiableMap(map);
		}
		{
			// table 11
			Map<GenderEnum, GenderType> map = new HashMap<>();
			map.put(GenderEnum.M, GenderType.GENDER_MALE);
			map.put(GenderEnum.F, GenderType.GENDER_FEMALE);
			map.put(GenderEnum.U, GenderType.GENDER_UNKNOWN);
			genderEnumToGenderType = Collections.unmodifiableMap(map);
		}
		{
			// table 12
			Map<String, RaceType> map = new HashMap<>();
			map.put("1", RaceType.RACE_WHITE);
			map.put("2", RaceType.RACE_BLACK);
			map.put("4", RaceType.RACE_AMERICAN_INDIAN);
			map.put("8", RaceType.RACE_ASIAN);
			map.put("-1", RaceType.RACE_UNKNOWN);
			stringToRaceType = Collections.unmodifiableMap(map);
		}
		{
			// table 13
			Map<Character, RegionCodeType> map = new HashMap<>();
			map.put(Character.valueOf('1'), RegionCodeType.REGION_CODE_1);
			map.put(Character.valueOf('2'), RegionCodeType.REGION_CODE_2);
			map.put(Character.valueOf('3'), RegionCodeType.REGION_CODE_3);
			map.put(Character.valueOf('4'), RegionCodeType.REGION_CODE_4);
			map.put(Character.valueOf('5'), RegionCodeType.REGION_CODE_5);
			map.put(Character.valueOf('6'), RegionCodeType.REGION_CODE_6);
			map.put(Character.valueOf('7'), RegionCodeType.REGION_CODE_7);
			map.put(Character.valueOf('8'), RegionCodeType.REGION_CODE_8);
			map.put(Character.valueOf('9'), RegionCodeType.REGION_CODE_9);
			map.put(Character.valueOf('A'), RegionCodeType.REGION_CODE_A);
			map.put(Character.valueOf('B'), RegionCodeType.REGION_CODE_B);
			map.put(Character.valueOf('C'), RegionCodeType.REGION_CODE_C);
			map.put(Character.valueOf('D'), RegionCodeType.REGION_CODE_D);
			map.put(Character.valueOf('E'), RegionCodeType.REGION_CODE_E);
			map.put(Character.valueOf('F'), RegionCodeType.REGION_CODE_F);
			map.put(Character.valueOf('U'), RegionCodeType.REGION_CODE_UNKNOWN);
			byteToRegionCodeType = Collections.unmodifiableMap(map);
		}
		{
			// table 14
			Map<Character, FingerPatternType> map = new HashMap<>();
			map.put(Character.valueOf('A'), FingerPatternType.FINGER_PATTERN_ARCH);
			map.put(Character.valueOf('L'), FingerPatternType.FINGER_PATTERN_LEFTLOOP);
			map.put(Character.valueOf('R'), FingerPatternType.FINGER_PATTERN_RIGHTLOOP);
			map.put(Character.valueOf('W'), FingerPatternType.FINGER_PATTERN_WHORL);
			map.put(Character.valueOf('S'), FingerPatternType.FINGER_PATTERN_SCAR);
			map.put(Character.valueOf('U'), FingerPatternType.FINGER_PATTERN_UNKNOWN);
			map.put(Character.valueOf('*'), FingerPatternType.FINGER_PATTERN_NONE);
			byteToFingerPatternType = Collections.unmodifiableMap(map);
		}
		{
			// table 15
			FingerPositionBaseType[] values =
				{
					FingerPositionBaseType.RIGHT_THUMB,
					FingerPositionBaseType.RIGHT_INDEX,
					FingerPositionBaseType.RIGHT_MIDDLE,
					FingerPositionBaseType.RIGHT_RING,
					FingerPositionBaseType.RIGHT_LITTLE,
					FingerPositionBaseType.LEFT_THUMB, FingerPositionBaseType.LEFT_INDEX,
					FingerPositionBaseType.LEFT_MIDDLE, FingerPositionBaseType.LEFT_RING,
					FingerPositionBaseType.LEFT_LITTLE
				};
			Map<Integer, FingerPositionBaseType> map = new HashMap<>();
			for (int i = 0; i < values.length; i++) {
				map.put(Integer.valueOf(i + 1), values[i]);
			}
			intToFingerPositionBaseType = Collections.unmodifiableMap(map);
		}
		{
			// table 16
			Map<Character, PalmPositionType> map = new HashMap<>();
			map.put(Character.valueOf('0'), PalmPositionType.PALM_UNKNOWN);
			map.put(Character.valueOf('1'), PalmPositionType.PALM_RIGHT_FULL);
			map.put(Character.valueOf('2'), PalmPositionType.PALM_RIGHT_WRITER);
			map.put(Character.valueOf('3'), PalmPositionType.PALM_LEFT_FULL);
			map.put(Character.valueOf('4'), PalmPositionType.PALM_LEFT_WRITER);
			map.put(Character.valueOf('5'), PalmPositionType.PALM_RIGHT_LOWER);
			map.put(Character.valueOf('6'), PalmPositionType.PALM_RIGHT_UPPER);
			map.put(Character.valueOf('7'), PalmPositionType.PALM_LEFT_LOWER);
			map.put(Character.valueOf('8'), PalmPositionType.PALM_LEFT_UPPER);
			map.put(Character.valueOf('9'), PalmPositionType.PALM_RIGHT_OTHER);
			map.put(Character.valueOf('A'), PalmPositionType.PALM_LEFT_OTHER);
			map.put(Character.valueOf('B'), PalmPositionType.PALM_RIGHT_INTERDIGITAL);
			map.put(Character.valueOf('C'), PalmPositionType.PALM_RIGHT_THENAR);
			map.put(Character.valueOf('D'), PalmPositionType.PALM_RIGHT_HYPOTHENAR);
			map.put(Character.valueOf('E'), PalmPositionType.PALM_LEFT_INTERDIGITAL);
			map.put(Character.valueOf('F'), PalmPositionType.PALM_LEFT_THENAR);
			map.put(Character.valueOf('G'), PalmPositionType.PALM_LEFT_HYPOTHENAR);
			byteToPalmPositionType = Collections.unmodifiableMap(map);
		}
		{
			// table 17
			Map<String, FilterModeType> map = new HashMap<>();
			map.put("0", FilterModeType.NO_FILTER);
			map.put("1", FilterModeType.PATTERN_ONLY);
			map.put("2", FilterModeType.GENDER_ONLY);
			map.put("3", FilterModeType.PATTERN_GENDER);
			map.put("4", FilterModeType.YOB_ONLY);
			map.put("5", FilterModeType.PATTERN_YOB);
			map.put("6", FilterModeType.GENDER_YOB);
			map.put("7", FilterModeType.PATTERN_GENDER_YOB);
			stringToFilterModeType = Collections.unmodifiableMap(map);
		}
		{
			// table 18
			Map<String, FingerSelectionModeType> map = new HashMap<>();
			map.put("1", FingerSelectionModeType.FIXED_1_FINGER);
			map.put("2", FingerSelectionModeType.FIXED_2_FINGERS);
			map.put("3", FingerSelectionModeType.FIXED_3_FINGERS);
			map.put("19", FingerSelectionModeType.FIXED_4_FINGERS);
			map.put("20", FingerSelectionModeType.FIXED_5_FINGERS);
			map.put("21", FingerSelectionModeType.FIXED_6_FINGERS);
			map.put("27", FingerSelectionModeType.FIXED_7_FINGERS);
			map.put("28", FingerSelectionModeType.FIXED_8_FINGERS);
			map.put("29", FingerSelectionModeType.FIXED_9_FINGERS);
			map.put("4", FingerSelectionModeType.AVG_1_2_FINGERS);
			map.put("5", FingerSelectionModeType.AVG_1_5_FINGERS);
			map.put("6", FingerSelectionModeType.AVG_1_8_FINGERS);
			map.put("7", FingerSelectionModeType.AVG_2_0_FINGERS);
			map.put("8", FingerSelectionModeType.AVG_2_2_FINGERS);
			map.put("9", FingerSelectionModeType.AVG_2_5_FINGERS);
			map.put("10", FingerSelectionModeType.AVG_2_6_FINGERS);
			map.put("11", FingerSelectionModeType.AVG_2_8_FINGERS);
			map.put("12", FingerSelectionModeType.AVG_3_0_FINGERS);
			map.put("13", FingerSelectionModeType.AVG_3_5_FINGERS);
			map.put("22", FingerSelectionModeType.AVG_4_0_FINGERS);
			map.put("23", FingerSelectionModeType.AVG_4_5_FINGERS);
			map.put("24", FingerSelectionModeType.AVG_5_0_FINGERS);
			map.put("25", FingerSelectionModeType.AVG_5_5_FINGERS);
			map.put("26", FingerSelectionModeType.AVG_6_0_FINGERS);
			map.put("30", FingerSelectionModeType.AVG_7_0_FINGERS);
			map.put("31", FingerSelectionModeType.AVG_8_0_FINGERS);
			map.put("32", FingerSelectionModeType.AVG_9_0_FINGERS);
			map.put("15", FingerSelectionModeType.PRIORITY_1_6);
			map.put("16", FingerSelectionModeType.DIFFERENT_HAND_SAME_FINGER);
			map.put("17", FingerSelectionModeType.SAME_HAND_DIFFERENT_FINGER);
			map.put("18", FingerSelectionModeType.DIFFERENT_HAND_DIFFERENT_FINGER);
			map.put("14", FingerSelectionModeType.COLD_SEARCH);
			stringToFingerSelectionModeType = Collections.unmodifiableMap(map);
		}
		{
			// table 19
			Map<String, PrefilterYobMethodType> map = new HashMap<>();
			map.put("0", PrefilterYobMethodType.YOB_METHOD_RANGE);
			map.put("1", PrefilterYobMethodType.YOB_METHOD_THRESHOLD);
			stringToYobMethodType = Collections.unmodifiableMap(map);
		}
		{
			// table 20
			Map<String, Pc2SpeedLevelType> map = new HashMap<>();
			map.put("1", Pc2SpeedLevelType.PC2_SPEED_LEVEL_1);
			map.put("2", Pc2SpeedLevelType.PC2_SPEED_LEVEL_2);
			map.put("3", Pc2SpeedLevelType.PC2_SPEED_LEVEL_3);
			map.put("4", Pc2SpeedLevelType.PC2_SPEED_LEVEL_4);
			map.put("5", Pc2SpeedLevelType.PC2_SPEED_LEVEL_5);
			map.put("6", Pc2SpeedLevelType.PC2_SPEED_LEVEL_6);
			map.put("7", Pc2SpeedLevelType.PC2_SPEED_LEVEL_7);
			map.put("8", Pc2SpeedLevelType.PC2_SPEED_LEVEL_8);
			map.put("9", Pc2SpeedLevelType.PC2_SPEED_LEVEL_9);
			stringToPc2SpeedLevelType = Collections.unmodifiableMap(map);
		}
		{
			// table 21
			Map<String, Pc2RotationLimitType> map = new HashMap<>();
			map.put("1", Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
			map.put("2", Pc2RotationLimitType.PC2_ROTATION_DEGREE_30);
			map.put("3", Pc2RotationLimitType.PC2_ROTATION_DEGREE_60);
			map.put("4", Pc2RotationLimitType.PC2_ROTATION_DEGREE_180);
			stringToPc2RotationLimitType = Collections.unmodifiableMap(map);
		}
		{
			// table 22
			Map<String, Pc2DistortionLevelType> map = new HashMap<>();
			map.put("1", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_1);
			map.put("2", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_2);
			map.put("3", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_3);
			map.put("4", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_4);
			map.put("5", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_5);
			map.put("6", Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_6);
			stringToPc2DistortionLevelType = Collections.unmodifiableMap(map);
		}
		{
			// table 23
			Map<String, LeAlgorithmType> map = new HashMap<>();
			map.put("1", LeAlgorithmType.LE_ALGORITHM_STANDARD);
			map.put("2", LeAlgorithmType.LE_ALGORITHM_ELMA_A);
			map.put("3", LeAlgorithmType.LE_ALGORITHM_ELMA_B);
			stringToLeAlgorithmType = Collections.unmodifiableMap(map);
		}
		{
			// table 24
			Map<String, LeRotationLimitType> map = new HashMap<>();
			map.put("1", LeRotationLimitType.LE_ROTATION_DEGREE_15);
			map.put("2", LeRotationLimitType.LE_ROTATION_DEGREE_30);
			map.put("3", LeRotationLimitType.LE_ROTATION_DEGREE_45);
			map.put("4", LeRotationLimitType.LE_ROTATION_DEGREE_NO_LIMIT);
			stringToLeRotationLimitType = Collections.unmodifiableMap(map);
		}
		{
			// table 25
			Map<String, LeCorePositionType> map = new HashMap<>();
			map.put("1", LeCorePositionType.LE_CORE_POSITION_STANDARD);
			map.put("2", LeCorePositionType.LE_CORE_POSITION_SEMI_LOOSE);
			map.put("3", LeCorePositionType.LE_CORE_POSITION_LOOSE);
			map.put("4", LeCorePositionType.LE_CORE_POSITION_NO_CORE);
			stringToLeCorePositionType = Collections.unmodifiableMap(map);
		}
		{
			// table 26
			Map<String, PalmRotationLimitType> map = new HashMap<>();
			map.put("1", PalmRotationLimitType.PALM_ROTATION_DEGREE_30);
			map.put("2", PalmRotationLimitType.PALM_ROTATION_DEGREE_60);
			map.put("3", PalmRotationLimitType.PALM_ROTATION_DEGREE_90);
			map.put("4", PalmRotationLimitType.PALM_ROTATION_DEGREE_180);
			stringToPalmRotationLimitType = Collections.unmodifiableMap(map);
		}
		{
			// table 27
			Map<String, CMLaFSearchModeType> map = new HashMap<>();
			map.put("1", CMLaFSearchModeType.NORMAL_MODE);
			map.put("2", CMLaFSearchModeType.SPEED_MODE);
			map.put("3", CMLaFSearchModeType.ACCURATE_MODE);
			stringToCmlafSearchModeType = Collections.unmodifiableMap(map);
		}
		{
			// table 28
			Map<String, Pc2RotationLimitType> map = new HashMap<>();
			map.put("1", Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
			map.put("2", Pc2RotationLimitType.PC2_ROTATION_DEGREE_30);
			map.put("3", Pc2RotationLimitType.PC2_ROTATION_DEGREE_45);
			map.put("4", Pc2RotationLimitType.PC2_ROTATION_DEGREE_60);
			map.put("5", Pc2RotationLimitType.PC2_ROTATION_DEGREE_180);
			stringToTimPc2RotationLimitType = Collections.unmodifiableMap(map);
		}
		{
			// table 29
			Map<LfmlSearchLevel, LfmlSearchLevelType> map = new HashMap<>();
			map.put(LfmlSearchLevel.SEARCH_LEVEL_1,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_1);
			map.put(LfmlSearchLevel.SEARCH_LEVEL_2,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_2);
			map.put(LfmlSearchLevel.SEARCH_LEVEL_3,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_3);
			map.put(LfmlSearchLevel.SEARCH_LEVEL_4,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_4);
			map.put(LfmlSearchLevel.SEARCH_LEVEL_5,
				LfmlSearchLevelType.LFML_SEARCH_LEVEL_5);
			lfmlSearchLevelToLfmlSearchLevelType = Collections.unmodifiableMap(map);
		}
		{
			// table 30
			Map<JobStateType, JobStateEnum> map = new HashMap<>();
			map.put(JobStateType.JOB_STATE_QUEUED, JobStateEnum.QUEUED);
			map.put(JobStateType.JOB_STATE_WORKING, JobStateEnum.WORKING);
			map.put(JobStateType.JOB_STATE_DONE, JobStateEnum.DONE);
			jobStateTypeToJobStateEnum = Collections.unmodifiableMap(map);
		}
		{
			// table 31
			Map<FingerAxisType, AxisEnum> map = new HashMap<>();
			map.put(FingerAxisType.FINGER_AXIS_A, AxisEnum.A);
			map.put(FingerAxisType.FINGER_AXIS_B, AxisEnum.B);
			map.put(FingerAxisType.FINGER_AXIS_C, AxisEnum.C);
			map.put(FingerAxisType.FINGER_AXIS_D, AxisEnum.D);
			fingerAxisTypeToAxisEnum = Collections.unmodifiableMap(map);
		}
		{
			// table 32
			Map<FingerSetType, InquirySetEnum> map = new HashMap<>();
			map.put(FingerSetType.PC2_ROLLED, InquirySetEnum.PC_2_ROLLED);
			map.put(FingerSetType.PC2_SLAP, InquirySetEnum.PC_2_SLAP);
			map.put(FingerSetType.PC2_LATENT, InquirySetEnum.PC_2_LATENT);
			map.put(FingerSetType.FMP5_ROLLED, InquirySetEnum.FMP_5_ROLLED);
			map.put(FingerSetType.FMP5_SLAP, InquirySetEnum.FMP_5_SLAP);
			map.put(FingerSetType.FMP5_LATENT, InquirySetEnum.FMP_5_LATENT);
			fingerSetTypeToInquirySetEnum = Collections.unmodifiableMap(map);
		}
		{
			// table 33
			Map<ExtractionFormats, TemplateFormatType> map = new HashMap<>();
			map.put(ExtractionFormats.TR_RDBT, TemplateFormatType.TEMPLATE_RDBT);
			map.put(ExtractionFormats.TR_RDBT_M, TemplateFormatType.TEMPLATE_RDBTM);
			map.put(ExtractionFormats.TR_XDBL, TemplateFormatType.TEMPLATE_RDBLX);
			map.put(ExtractionFormats.LR, TemplateFormatType.TEMPLATE_LDB);
			map.put(ExtractionFormats.LR_P, TemplateFormatType.TEMPLATE_PLDB);
			map.put(ExtractionFormats.LR_S, TemplateFormatType.TEMPLATE_LDBS);
			map.put(ExtractionFormats.LR_M, TemplateFormatType.TEMPLATE_LDBM);
			map.put(ExtractionFormats.LR_X, TemplateFormatType.TEMPLATE_LDBX);
			map.put(ExtractionFormats.TR_RDBL, TemplateFormatType.TEMPLATE_RDBL);
			map.put(ExtractionFormats.TR_RDBL_S, TemplateFormatType.TEMPLATE_RDBLS);
			map.put(ExtractionFormats.TR_RDBL_M, TemplateFormatType.TEMPLATE_RDBLM);
			map.put(ExtractionFormats.TR_P, TemplateFormatType.TEMPLATE_PDB);
			map.put(ExtractionFormats.FR_FDB, TemplateFormatType.TEMPLATE_FDB);
			map.put(ExtractionFormats.TI, TemplateFormatType.TEMPLATE_TI);
			map.put(ExtractionFormats.TI_M, TemplateFormatType.TEMPLATE_TIM);
			map.put(ExtractionFormats.TLI, TemplateFormatType.TEMPLATE_TLI);
			map.put(ExtractionFormats.TLI_S, TemplateFormatType.TEMPLATE_TLIS);
			map.put(ExtractionFormats.TLI_M, TemplateFormatType.TEMPLATE_TLIM);
			map.put(ExtractionFormats.TLI_X, TemplateFormatType.TEMPLATE_TLIX);
			map.put(ExtractionFormats.LI, TemplateFormatType.TEMPLATE_LI);
			map.put(ExtractionFormats.LI_S, TemplateFormatType.TEMPLATE_LIS);
			map.put(ExtractionFormats.LI_M, TemplateFormatType.TEMPLATE_LIM);
			map.put(ExtractionFormats.LI_X, TemplateFormatType.TEMPLATE_LIX);
			map.put(ExtractionFormats.LLI, TemplateFormatType.TEMPLATE_LLI);
			map.put(ExtractionFormats.LLI_S, TemplateFormatType.TEMPLATE_LLIS);
			map.put(ExtractionFormats.LLI_M, TemplateFormatType.TEMPLATE_LLIM);
			map.put(ExtractionFormats.LLI_X, TemplateFormatType.TEMPLATE_LLIX);
			map.put(ExtractionFormats.LI_P, TemplateFormatType.TEMPLATE_LIP);
			map.put(ExtractionFormats.LLI_P, TemplateFormatType.TEMPLATE_LLIP);
			map.put(ExtractionFormats.TLI_P, TemplateFormatType.TEMPLATE_TLIP);
			map.put(ExtractionFormats.FI, TemplateFormatType.TEMPLATE_FI);
			map.put(ExtractionFormats.II, TemplateFormatType.TEMPLATE_II);
			map.put(ExtractionFormats.IR_IDB, TemplateFormatType.TEMPLATE_IDB);
			extractionFormatsToTemplateFormatType = Collections.unmodifiableMap(map);
		}
		{
			// table 34
			Map<String, FisTypeType> map = new HashMap<>();
			map.put("A", FisTypeType.FIS_TYPE_A);
			map.put("B", FisTypeType.FIS_TYPE_B);
			map.put("C", FisTypeType.FIS_TYPE_C);
			// map.put("D", FisTypeType.FIS_TYPE_D);
			map.put("E", FisTypeType.FIS_TYPE_E);
			map.put("F", FisTypeType.FIS_TYPE_F);
			map.put("P", FisTypeType.FIS_TYPE_P);
			stringToFisTypeType = Collections.unmodifiableMap(map);
		}
		{
			// table 35
			Map<String, ImagePositionType> map = new HashMap<>();
			map.put("1", ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
			map.put("2", ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX);
			map.put("3", ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE);
			map.put("4", ImagePositionType.IMAGE_ROLLED_RIGHT_RING);
			map.put("5", ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE);
			map.put("6", ImagePositionType.IMAGE_ROLLED_LEFT_THUMB);
			map.put("7", ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
			map.put("8", ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE);
			map.put("9", ImagePositionType.IMAGE_ROLLED_LEFT_RING);
			map.put("10", ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE);
			map.put("11", ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
			map.put("40", ImagePositionType.IMAGE_SLAP_RIGHT_INDEX);
			map.put("41", ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE);
			map.put("42", ImagePositionType.IMAGE_SLAP_RIGHT_RING);
			map.put("43", ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE);
			map.put("12", ImagePositionType.IMAGE_SLAP_LEFT_THUMB);
			map.put("44", ImagePositionType.IMAGE_SLAP_LEFT_INDEX);
			map.put("45", ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE);
			map.put("46", ImagePositionType.IMAGE_SLAP_LEFT_RING);
			map.put("47", ImagePositionType.IMAGE_SLAP_LEFT_LITTLE);
			map.put("13", ImagePositionType.IMAGE_SLAP_RIGHT_FOUR);
			map.put("14", ImagePositionType.IMAGE_SLAP_LEFT_FOUR);
			map.put("15", ImagePositionType.IMAGE_SLAP_THUMBS);
			map.put("21", ImagePositionType.IMAGE_PALM_RIGHT_FULL);
			map.put("22", ImagePositionType.IMAGE_PALM_RIGHT_WRITER);
			map.put("23", ImagePositionType.IMAGE_PALM_LEFT_FULL);
			map.put("24", ImagePositionType.IMAGE_PALM_LEFT_WRITER);
			map.put("25", ImagePositionType.IMAGE_PALM_RIGHT_LOWER);
			map.put("26", ImagePositionType.IMAGE_PALM_RIGHT_UPPER);
			map.put("27", ImagePositionType.IMAGE_PALM_LEFT_LOWER);
			map.put("28", ImagePositionType.IMAGE_PALM_LEFT_UPPER);
			map.put("29", ImagePositionType.IMAGE_PALM_RIGHT_OTHER);
			map.put("30", ImagePositionType.IMAGE_PALM_LEFT_OTHER);
			map.put("31", ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL);
			map.put("32", ImagePositionType.IMAGE_PALM_RIGHT_THENAR);
			map.put("33", ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR);
			map.put("34", ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL);
			map.put("35", ImagePositionType.IMAGE_PALM_LEFT_THENAR);
			map.put("36", ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR);
			map.put("60", ImagePositionType.IMAGE_IRIS_RIGHT);
			map.put("61", ImagePositionType.IMAGE_IRIS_LEFT);

			posToImagePositionType = Collections.unmodifiableMap(map);
		}
		{
			// table 36
			Map<ImageFormat, ImageFormatType> map = new HashMap<>();
			map.put(ImageFormat.RAW, ImageFormatType.RAW);
			map.put(ImageFormat.WSQ, ImageFormatType.WSQ);
			map.put(ImageFormat.JPEG2000, ImageFormatType.JPEG2000);
			map.put(ImageFormat.JPEG, ImageFormatType.JPEG);
			map.put(ImageFormat.BMP, ImageFormatType.BMP);
			map.put(ImageFormat.PNG, ImageFormatType.PNG);
			map.put(ImageFormat.NECGRAY4, ImageFormatType.NECGRAY4);
			map.put(ImageFormat.WSQ4, ImageFormatType.WSQ4);
			imageFormatToImageFormatType = Collections.unmodifiableMap(map);
		}
		{
			Map<WhiteBlackLevel, ImageWhiteBlackLevelType> map = new HashMap<>();
			// table 37
			map.put(WhiteBlackLevel.WHITELEVEL,
				ImageWhiteBlackLevelType.IMAGE_LEVEL_WHITE);
			map.put(WhiteBlackLevel.BLACKLEVEL,
				ImageWhiteBlackLevelType.IMAGE_LEVEL_BLACK);
			whiteBlackLevelToImageWhiteBlackLevelType = Collections.unmodifiableMap(map);
		}
		{
			// table 38
			Map<String, MinutiaDbType> map = new HashMap<>();
			map.put("RDBTM", MinutiaDbType.MINUTIA_DB_RDBTM);
			map.put("RDBLM", MinutiaDbType.MINUTIA_DB_RDBLM);
			stringToMinutiaDbType = Collections.unmodifiableMap(map);
		}
		{
			// table 39
			Map<String, MinutiaType> map = new HashMap<>();
			map.put("FIS", MinutiaType.MINUTIA_FIS);
			map.put("PC2", MinutiaType.MINUTIA_PC2);
			map.put("BT5", MinutiaType.MINUTIA_BT5);
			stringToMinutiaType = Collections.unmodifiableMap(map);
		}
		{
			// table 40
			Map<EnhType, BasicImageEnhanceType> map = new HashMap<>();
			map.put(EnhType.ENH_SMOOTH, BasicImageEnhanceType.IMAGE_ENHANCE_SMOOTH);
			map.put(EnhType.ENH_AGC, BasicImageEnhanceType.IMAGE_ENHANCE_AGC);
			map.put(EnhType.ENH_HISTOGRAM, BasicImageEnhanceType.IMAGE_ENHANCE_HISTOGRAM);
			map.put(EnhType.ENH_VRP_TEN, BasicImageEnhanceType.IMAGE_ENHANCE_VRP_TENPRINT);
			map.put(EnhType.ENH_VRP_LAT, BasicImageEnhanceType.IMAGE_ENHANCE_VRP_LATENT);
			map.put(EnhType.ENH_ENHANCE, BasicImageEnhanceType.IMAGE_ENHANCE_ENHANCE);
			map.put(EnhType.ENH_DEINTERLACE,
				BasicImageEnhanceType.IMAGE_ENHANCE_DEINTERLACE);
			enhTypeToBasicImageEnhganceType = Collections.unmodifiableMap(map);
		}
		{
			// table 41
			Map<QcMode, QualityCheckModeType> map = new HashMap<>();
			map.put(QcMode.QC_MODE_OFF, QualityCheckModeType.QC_MODE_OFF);
			map.put(QcMode.QC_MODE_NORMAL, QualityCheckModeType.QC_MODE_STANDARD);
			map.put(QcMode.QC_MODE_ADVANCED, QualityCheckModeType.QC_MODE_ADVANCED);
			qcModeToQualityCheckModeType = Collections.unmodifiableMap(map);
		}
		{
			// table 42
			Map<Integer, CMLaFFeTypeType> map = new HashMap<>();
			map.put(Integer.valueOf(2), CMLaFFeTypeType.CMLAF_FE_TYPE_B);
			map.put(Integer.valueOf(3), CMLaFFeTypeType.CMLAF_FE_TYPE_E);
			map.put(Integer.valueOf(9), CMLaFFeTypeType.CMLAF_FE_TYPE_FE);
			intToCmlafFeTypeType = Collections.unmodifiableMap(map);
		}
		{
			// table 43
			Map<CmlafEnhType, CMLaFImageEnhanceType> map = new HashMap<>();
			map.put(CmlafEnhType.CMLaF_ENH_G, CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_G);
			map.put(CmlafEnhType.CMLaF_ENH_R, CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_R);
			map.put(CmlafEnhType.CMLaF_ENH_C, CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_C);
			map.put(CmlafEnhType.CMLaF_ENH_C2,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_C2);
			map.put(CmlafEnhType.CMLaF_ENH_L, CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_L);
			map.put(CmlafEnhType.CMLaF_ENH_L2,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_L2);
			map.put(CmlafEnhType.CMLaF_ENH_H, CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_H);
			map.put(CmlafEnhType.CMLaF_ENH_E, CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_E);
			map.put(CmlafEnhType.CMLaF_ENH_A, CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_A);
			map.put(CmlafEnhType.CMLaF_ENH_NO,
				CMLaFImageEnhanceType.CMLAF_IMAGE_ENHANCE_NO);
			cmlafEnhTypeToCmlafImageEnhganceType = Collections.unmodifiableMap(map);
		}
		{
			// table 44
			Map<ExtInfoModeFormat, ExtractOutputModeType> map = new HashMap<>();
			map.put(ExtInfoModeFormat.EXTINFO_TEMPLATE_AND_RESULTINFO,
				ExtractOutputModeType.EXTRACT_OUTPUT_MODE_ALL);
			map.put(ExtInfoModeFormat.EXTINFO_TEMPLATE,
				ExtractOutputModeType.EXTRACT_OUTPUT_MODE_TEMPLATE);
			map.put(ExtInfoModeFormat.EXTINFO_RESULTINFO,
				ExtractOutputModeType.EXTRACT_OUTPUT_MODE_INFO);
			extInfoModeFormatToExtractOutputModeType = Collections.unmodifiableMap(map);
		}
		{
			// table 45
			Map<FaceProcessMode, FaceExtractProcessType> map = new HashMap<>();
			map.put(FaceProcessMode.DETECTION,
				FaceExtractProcessType.FACE_EXTRACT_PROCESS_DETECTION);
			map.put(FaceProcessMode.DETECTION_EXTRACTION,
				FaceExtractProcessType.FACE_EXTRACT_PROCESS_DETECTION_EXTRACTION);
			map.put(FaceProcessMode.EXTRACTION,
				FaceExtractProcessType.FACE_EXTRACT_PROCESS_EXTRATION);
			faceProcessModeToFaceExtractProcessType = Collections.unmodifiableMap(map);
		}
		{
			// table 46
			Map<DetectionMode, FaceDetectionModeType> map = new HashMap<>();
			map.put(DetectionMode.REPEAT,
				FaceDetectionModeType.FACE_DETECTION_MODE_REPEAT);
			map.put(DetectionMode.NO, FaceDetectionModeType.FACE_DETECTION_MODE_NO);
			detectionModeToFaceDetectionModeType = Collections.unmodifiableMap(map);
		}
		{
			// table 47
			Map<SortingOrder, FaceDetectionSortingOrderType> map = new HashMap<>();
			map.put(SortingOrder.DETECTION_SCORE,
				FaceDetectionSortingOrderType.FACE_DETECTION_SORTING_ORDER_SCORE);
			map.put(SortingOrder.FACE_SIZE,
				FaceDetectionSortingOrderType.FACE_DETECTION_SORTING_ORDER_SIZE);
			sortingOrderToFaceDetectionSortingOrderType =
				Collections.unmodifiableMap(map);
		}
		{
			// table 48
			Map<DetectionAlgorithm, FaceDetectionAlgorithmType> map = new HashMap<>();
			map.put(DetectionAlgorithm.D3,
				FaceDetectionAlgorithmType.FACE_DETECTION_ALGORITHM_D3);
			map.put(DetectionAlgorithm.D4,
				FaceDetectionAlgorithmType.FACE_DETECTION_ALGORITHM_D4);
			map.put(DetectionAlgorithm.D8,
				FaceDetectionAlgorithmType.FACE_DETECTION_ALGORITHM_D8);
			detectionAlgorithmToFaceDetectionAlgorithmType =
				Collections.unmodifiableMap(map);
		}
		{
			// table 49
			Map<FaceRotation, List<FaceDetectionRotationType>> map = new HashMap<>();
			FaceRotation[] keys =
				{
					FaceRotation.DEGREE_0, FaceRotation.DEGREE_90,
					FaceRotation.DEGREE_0_90, FaceRotation.DEGREE_180,
					FaceRotation.DEGREE_0_180, FaceRotation.DEGREE_90_180,
					FaceRotation.DEGREE_0_90_180, FaceRotation.DEGREE_270,
					FaceRotation.DEGREE_0_270, FaceRotation.DEGREE_90_270,
					FaceRotation.DEGREE_0_90_270, FaceRotation.DEGREE_180_270,
					FaceRotation.DEGREE_0_180_270, FaceRotation.DEGREE_90_180_270,
					FaceRotation.DEGREE_0_90_180_270
				};

			FaceDetectionRotationType values[][] =
				{
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_0
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_90
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_90
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_180
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_180
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_180
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_180
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_270
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_270
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_270
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_270
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_180,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_270
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_180,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_270
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_180,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_270
					},
					{
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_0,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_90,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_180,
						FaceDetectionRotationType.FACE_DETECTION_ROTATION_270
					},
				};
			for (int i = 0; i < keys.length; i++) {
				map.put(keys[i], Collections.unmodifiableList(Arrays.asList(values[i])));
			}
			faceRotationToListFaceDetectionRotationType =
				Collections.unmodifiableMap(map);
		}
		{
			// table 50
			Map<ShrinkFactor, FaceDetectionShrinkFactorType> map = new HashMap<>();
			map.put(ShrinkFactor.NO_SHRINK,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_ORIGINAL);
			map.put(ShrinkFactor.A_HALF,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_HALF);
			map.put(ShrinkFactor.A_QUARTER,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_ONE_4TH);
			map.put(ShrinkFactor.A_EIGHTHS,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_ONE_8TH);
			map.put(ShrinkFactor.A_SIXTEENTHS,
				FaceDetectionShrinkFactorType.FACE_DETECTION_SHRINK_FACTOR_ONE_16TH);
			shrinkFactorToFaceDetectionShrinkFactorType =
				Collections.unmodifiableMap(map);
		}
		{
			// table 51
			Map<ImagePositionType, Integer> map = new HashMap<>();
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB, Integer.valueOf(1));
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX, Integer.valueOf(2));
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE, Integer.valueOf(3));
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_RING, Integer.valueOf(4));
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE, Integer.valueOf(5));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_THUMB, Integer.valueOf(6));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_INDEX, Integer.valueOf(7));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE, Integer.valueOf(8));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_RING, Integer.valueOf(9));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE, Integer.valueOf(10));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB, Integer.valueOf(1));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_INDEX, Integer.valueOf(2));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE, Integer.valueOf(3));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_RING, Integer.valueOf(4));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE, Integer.valueOf(5));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_THUMB, Integer.valueOf(6));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_INDEX, Integer.valueOf(7));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE, Integer.valueOf(8));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_RING, Integer.valueOf(9));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_LITTLE, Integer.valueOf(10));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_FULL, Integer.valueOf(1));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_WRITER, Integer.valueOf(2));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_FULL, Integer.valueOf(3));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_WRITER, Integer.valueOf(4));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_LOWER, Integer.valueOf(5));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_UPPER, Integer.valueOf(6));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_LOWER, Integer.valueOf(7));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_UPPER, Integer.valueOf(8));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_OTHER, Integer.valueOf(9));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_OTHER, Integer.valueOf(10));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL, Integer.valueOf(11));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_THENAR, Integer.valueOf(12));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR, Integer.valueOf(13));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL, Integer.valueOf(14));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_THENAR, Integer.valueOf(15));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR, Integer.valueOf(16));
			imagePositionTypeToIntKey = Collections.unmodifiableMap(map);
		}
		{
			// table 52
			Map<FingerPositionType, Integer> map = new HashMap<>();
			map.put(FingerPositionType.ROLLED_RIGHT_THUMB, Integer.valueOf(1));
			map.put(FingerPositionType.ROLLED_RIGHT_INDEX, Integer.valueOf(2));
			map.put(FingerPositionType.ROLLED_RIGHT_MIDDLE, Integer.valueOf(3));
			map.put(FingerPositionType.ROLLED_RIGHT_RING, Integer.valueOf(4));
			map.put(FingerPositionType.ROLLED_RIGHT_LITTLE, Integer.valueOf(5));
			map.put(FingerPositionType.ROLLED_LEFT_THUMB, Integer.valueOf(6));
			map.put(FingerPositionType.ROLLED_LEFT_INDEX, Integer.valueOf(7));
			map.put(FingerPositionType.ROLLED_LEFT_MIDDLE, Integer.valueOf(8));
			map.put(FingerPositionType.ROLLED_LEFT_RING, Integer.valueOf(9));
			map.put(FingerPositionType.ROLLED_LEFT_LITTLE, Integer.valueOf(10));
			map.put(FingerPositionType.SLAP_RIGHT_THUMB, Integer.valueOf(11));
			map.put(FingerPositionType.SLAP_RIGHT_INDEX, Integer.valueOf(40));
			map.put(FingerPositionType.SLAP_RIGHT_MIDDLE, Integer.valueOf(41));
			map.put(FingerPositionType.SLAP_RIGHT_RING, Integer.valueOf(42));
			map.put(FingerPositionType.SLAP_RIGHT_LITTLE, Integer.valueOf(43));
			map.put(FingerPositionType.SLAP_LEFT_THUMB, Integer.valueOf(12));
			map.put(FingerPositionType.SLAP_LEFT_INDEX, Integer.valueOf(44));
			map.put(FingerPositionType.SLAP_LEFT_MIDDLE, Integer.valueOf(45));
			map.put(FingerPositionType.SLAP_LEFT_RING, Integer.valueOf(46));
			map.put(FingerPositionType.SLAP_LEFT_LITTLE, Integer.valueOf(47));
			fingerPositionTypeToInt = Collections.unmodifiableMap(map);
		}
		{
			// table 53
			Map<FingerPositionType, String> map = new HashMap<>();
			map.put(FingerPositionType.ROLLED_RIGHT_THUMB, "1");
			map.put(FingerPositionType.ROLLED_RIGHT_INDEX, "2");
			map.put(FingerPositionType.ROLLED_RIGHT_MIDDLE, "3");
			map.put(FingerPositionType.ROLLED_RIGHT_RING, "4");
			map.put(FingerPositionType.ROLLED_RIGHT_LITTLE, "5");
			map.put(FingerPositionType.ROLLED_LEFT_THUMB, "6");
			map.put(FingerPositionType.ROLLED_LEFT_INDEX, "7");
			map.put(FingerPositionType.ROLLED_LEFT_MIDDLE, "8");
			map.put(FingerPositionType.ROLLED_LEFT_RING, "9");
			map.put(FingerPositionType.ROLLED_LEFT_LITTLE, "10");
			map.put(FingerPositionType.SLAP_RIGHT_THUMB, "11");
			map.put(FingerPositionType.SLAP_RIGHT_INDEX, "12");
			map.put(FingerPositionType.SLAP_RIGHT_MIDDLE, "13");
			map.put(FingerPositionType.SLAP_RIGHT_RING, "14");
			map.put(FingerPositionType.SLAP_RIGHT_LITTLE, "15");
			map.put(FingerPositionType.SLAP_LEFT_THUMB, "16");
			map.put(FingerPositionType.SLAP_LEFT_INDEX, "17");
			map.put(FingerPositionType.SLAP_LEFT_MIDDLE, "18");
			map.put(FingerPositionType.SLAP_LEFT_RING, "19");
			map.put(FingerPositionType.SLAP_LEFT_LITTLE, "20");
			map.put(FingerPositionType.FINGER_AMPUTATED, "*");
			map.put(FingerPositionType.FINGER_UNKNOWN, "?");
			fingerPositionTypeToString = Collections.unmodifiableMap(map);
		}
		{
			// table 54
			Map<QualityCheckAdvancedActivityType, QcActivity> map = new HashMap<>();
			map.put(QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_DUPLICATE,
				QcActivity.SLAP_DUPLICATE);
			map.put(
				QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_RIGHT_4FINGERS,
				QcActivity.SLAP_RIGHT_4_FINGERS);
			map.put(
				QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_RIGHT_4CONFIDENCE,
				QcActivity.SLAP_RIGHT_4_CONFIDENCE);
			map.put(
				QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_LEFT_4FINGERS,
				QcActivity.SLAP_LEFT_4_FINGERS);
			map.put(
				QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_SLAP_LEFT_4CONFIDENCE,
				QcActivity.SLAP_LEFT_4_CONFIDENCE);
			map.put(
				QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_ROLLED_DUPLICATE,
				QcActivity.ROLLED_DUPLICATE);
			map.put(
				QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_ROLLED_SEQUENCE,
				QcActivity.ROLLED_SEQUENCE);
			map.put(QualityCheckAdvancedActivityType.QC_ADVANCED_ACTIVITY_ROLLED_QUALITY,
				QcActivity.ROLLED_QUALITY);
			qualityCheckAdvancedActivityTypeToQcActivity =
				Collections.unmodifiableMap(map);
		}
		{
			// table 55
			Map<QualityCheckAdvancedStateType, QcDetailStatus> map = new HashMap<>();
			map.put(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NOT_AVAILABLE,
				QcDetailStatus.QC_STATE_NOT_AVAILABLE);
			map.put(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_OK,
				QcDetailStatus.QC_STATE_OK);
			map.put(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NG,
				QcDetailStatus.QC_STATE_NG);
			map.put(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NG_CORRECTED,
				QcDetailStatus.QC_STATE_NG_CORRECTED);
			map.put(
				QualityCheckAdvancedStateType.QC_ADVANCED_STATE_NG_CORRECT_IMPOSSIBLE,
				QcDetailStatus.QC_STATE_NG_CORRECT_IMPOSSIBLE);
			map.put(QualityCheckAdvancedStateType.QC_ADVANCED_STATE_UNKNOWN,
				QcDetailStatus.QC_STATE_UNKNOWN);
			qualityCheckAdvancedStateTypeToQcDetailStatus =
				Collections.unmodifiableMap(map);
		}
		{
			// table 56
			Map<jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType, jp.co.nec.aim.mm.jaxb.PsrType> map =
				new HashMap<>();
			map.put(jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType.PSR_AC,
				jp.co.nec.aim.mm.jaxb.PsrType.AC);
			map.put(jp.co.nec.aim.message.proto.ExtractEnumTypes.PsrType.PSR_CMLaF,
				jp.co.nec.aim.mm.jaxb.PsrType.CM_LA_F);
			protoPsrTypeToJaxbPsrType = Collections.unmodifiableMap(map);
		}
		{
			// table 57
			Map<ImagePositionType, Integer> map = new HashMap<>();
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB, Integer.valueOf(1));
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX, Integer.valueOf(2));
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE, Integer.valueOf(3));
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_RING, Integer.valueOf(4));
			map.put(ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE, Integer.valueOf(5));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_THUMB, Integer.valueOf(6));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_INDEX, Integer.valueOf(7));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE, Integer.valueOf(8));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_RING, Integer.valueOf(9));
			map.put(ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE, Integer.valueOf(10));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB, Integer.valueOf(11));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_INDEX, Integer.valueOf(40));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE, Integer.valueOf(41));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_RING, Integer.valueOf(42));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE, Integer.valueOf(43));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_THUMB, Integer.valueOf(12));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_INDEX, Integer.valueOf(44));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE, Integer.valueOf(45));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_RING, Integer.valueOf(46));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_LITTLE, Integer.valueOf(47));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_FULL, Integer.valueOf(21));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_WRITER, Integer.valueOf(22));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_FULL, Integer.valueOf(23));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_WRITER, Integer.valueOf(24));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_LOWER, Integer.valueOf(25));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_UPPER, Integer.valueOf(26));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_LOWER, Integer.valueOf(27));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_UPPER, Integer.valueOf(28));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_OTHER, Integer.valueOf(29));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_OTHER, Integer.valueOf(30));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL, Integer.valueOf(31));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_THENAR, Integer.valueOf(32));
			map.put(ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR, Integer.valueOf(33));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL, Integer.valueOf(34));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_THENAR, Integer.valueOf(35));
			map.put(ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR, Integer.valueOf(36));
			map.put(ImagePositionType.IMAGE_IRIS_RIGHT, Integer.valueOf(60));
			map.put(ImagePositionType.IMAGE_IRIS_LEFT, Integer.valueOf(61));
			map.put(ImagePositionType.IMAGE_SLAP_RIGHT_FOUR, Integer.valueOf(13));
			map.put(ImagePositionType.IMAGE_SLAP_LEFT_FOUR, Integer.valueOf(14));
			map.put(ImagePositionType.IMAGE_SLAP_THUMBS, Integer.valueOf(15));
			imagePositionTypeToIntPosition = Collections.unmodifiableMap(map);
		}
		{
			// table 58
			Map<FingerPatternType, String> map = new HashMap<>();
			map.put(FingerPatternType.FINGER_PATTERN_ARCH, "A");
			map.put(FingerPatternType.FINGER_PATTERN_LEFTLOOP, "L");
			map.put(FingerPatternType.FINGER_PATTERN_RIGHTLOOP, "R");
			map.put(FingerPatternType.FINGER_PATTERN_WHORL, "W");
			map.put(FingerPatternType.FINGER_PATTERN_SCAR, "S");
			map.put(FingerPatternType.FINGER_PATTERN_UNKNOWN, "U");
			map.put(FingerPatternType.FINGER_PATTERN_NONE, " ");
			fingerPatternTypeToString = Collections.unmodifiableMap(map);
		}
		{
			// table 59
			Map<MinutiaType, String> map = new HashMap<>();
			map.put(MinutiaType.MINUTIA_FIS, "FIS");
			map.put(MinutiaType.MINUTIA_PC2, "PC2");
			map.put(MinutiaType.MINUTIA_BT5, "BT5");
			map.put(MinutiaType.MINUTIA_FMP5, "FMP5");
			map.put(MinutiaType.MINUTIA_PZIP, "PZIP");
			map.put(MinutiaType.MINUTIA_PC3R, "PC3R");
			minutiaTypeToString = Collections.unmodifiableMap(map);
		}
		{
			// table 60
			Map<MinutiaDbType, String> map = new HashMap<>();
			map.put(MinutiaDbType.MINUTIA_DB_RDBT, "RDBT");
			map.put(MinutiaDbType.MINUTIA_DB_RDBTM, "RDBTM");
			map.put(MinutiaDbType.MINUTIA_DB_RDBL, "RDBL");
			map.put(MinutiaDbType.MINUTIA_DB_RDBLS, "RDBLS");
			map.put(MinutiaDbType.MINUTIA_DB_RDBLM, "RDBLM");
			map.put(MinutiaDbType.MINUTIA_DB_RDBLX, "RDBLX");
			map.put(MinutiaDbType.MINUTIA_DB_LDB, "LDB");
			map.put(MinutiaDbType.MINUTIA_DB_LDBS, "LDBS");
			map.put(MinutiaDbType.MINUTIA_DB_LDBX, "LDBX");
			map.put(MinutiaDbType.MINUTIA_DB_PDB, "PDB");
			map.put(MinutiaDbType.MINUTIA_DB_PLDB, "PLDB");
			minutiaDbTypeToString = Collections.unmodifiableMap(map);
		}
		{
			// table 61
			Map<FisTypeType, String> map = new HashMap<>();
			map.put(FisTypeType.FIS_TYPE_A, "TYPE_A");
			map.put(FisTypeType.FIS_TYPE_B, "TYPE_B");
			map.put(FisTypeType.FIS_TYPE_C, "TYPE_C");
			// map.put(FisTypeType.FIS_TYPE_D, "TYPE_D");
			map.put(FisTypeType.FIS_TYPE_E, "TYPE_E");
			map.put(FisTypeType.FIS_TYPE_F, "TYPE_F");
			map.put(FisTypeType.FIS_TYPE_P, "TYPE_P");
			map.put(FisTypeType.FIS_TYPE_CMLaF, "TYPE_CMLaF");
			map.put(FisTypeType.FIS_TYPE_LFML, "TYPE_LFML");
			fisTypeTypeToString = Collections.unmodifiableMap(map);
		}
		{
			// table 62
			String[] keys =
				{
					"TI", "TI-M", "TLI", "TLI-S", "TLI-M", "TLI-X", "LI", "LI-S", "LI-M",
					"LI-X", "LLI", "LLI-S", "LLI-M", "LLI-X", "LI-P", "LLI-P", "TLI-P",
					"FI", "II"
				};
			Integer values[][] = {
				{
					RDBT_CONTAINER_ID, SDBT_CONTAINER_ID
				}, {
					RDBTM_CONTAINER_ID, SDBTM_CONTAINER_ID
				}, {
					LDB_CONTAINER_ID
				}, {
					LDBS_CONTAINER_ID
				}, {
					LDBM_CONTAINER_ID
				}, {
					LDBX_CONTAINER_ID
				}, {
					RDBL_CONTAINER_ID, SDBL_CONTAINER_ID
				}, {
					RDBLS_CONTAINER_ID, SDBLS_CONTAINER_ID
				}, {
					RDBLM_CONTAINER_ID, SDBLM_CONTAINER_ID
				}, {
					XDBL_CONTAINER_ID
				}, {
					LDB_CONTAINER_ID
				}, {
					LDBS_CONTAINER_ID
				}, {
					LDBM_CONTAINER_ID
				}, {
					LDBX_CONTAINER_ID
				}, {
					PDB_CONTAINER_ID
				}, {
					PLDB_CONTAINER_ID
				}, {
					PLDB_CONTAINER_ID
				}, {
					FDB_CONTAINER_ID
				}, {
					IDB_CONTAINER_ID
				}
			};
			Map<String, List<Integer>> map = new HashMap<>();
			for (int i = 0; i < keys.length; i++) {
				map.put(keys[i], Collections.unmodifiableList(Arrays.asList(values[i])));
			}
			stringToListInt = Collections.unmodifiableMap(map);
		}
		{
			// table 63
			Map<InquirySetEnum, FingerSetType> map = new HashMap<>();
			map.put(InquirySetEnum.PC_2_ROLLED, FingerSetType.PC2_ROLLED);
			map.put(InquirySetEnum.PC_2_SLAP, FingerSetType.PC2_SLAP);
			map.put(InquirySetEnum.PC_2_LATENT, FingerSetType.PC2_LATENT);
			map.put(InquirySetEnum.FMP_5_ROLLED, FingerSetType.FMP5_ROLLED);
			map.put(InquirySetEnum.FMP_5_SLAP, FingerSetType.FMP5_SLAP);
			map.put(InquirySetEnum.FMP_5_LATENT, FingerSetType.FMP5_LATENT);
			inquirySetEnumToFingerSetType = Collections.unmodifiableMap(map);
		}
		{
			// table 64
			Map<Integer, FingerPositionBaseType> map = new HashMap<>();
			map.put(Integer.valueOf(0), FingerPositionBaseType.RIGHT_THUMB);
			map.put(Integer.valueOf(1), FingerPositionBaseType.RIGHT_INDEX);
			map.put(Integer.valueOf(2), FingerPositionBaseType.RIGHT_MIDDLE);
			map.put(Integer.valueOf(3), FingerPositionBaseType.RIGHT_RING);
			map.put(Integer.valueOf(4), FingerPositionBaseType.RIGHT_LITTLE);
			map.put(Integer.valueOf(5), FingerPositionBaseType.LEFT_THUMB);
			map.put(Integer.valueOf(6), FingerPositionBaseType.LEFT_INDEX);
			map.put(Integer.valueOf(7), FingerPositionBaseType.LEFT_MIDDLE);
			map.put(Integer.valueOf(8), FingerPositionBaseType.LEFT_RING);
			map.put(Integer.valueOf(9), FingerPositionBaseType.LEFT_LITTLE);
			intToFingerPositionBaseTypeForSelectFinger = Collections.unmodifiableMap(map);
		}
		{
			// table 65
			Map<String, TemplateFormatType> map = new HashMap<>();
			map.put("TI_ROLLED", TemplateFormatType.TEMPLATE_TI);
			map.put("TI_SLAP", TemplateFormatType.TEMPLATE_TI);
			map.put("TIM_ROLLED", TemplateFormatType.TEMPLATE_TIM);
			map.put("TIM_SLAP", TemplateFormatType.TEMPLATE_TIM);
			map.put("TLI_ROLLED", TemplateFormatType.TEMPLATE_TLI);
			map.put("TLI_SLAP", TemplateFormatType.TEMPLATE_TLI);
			map.put("TLIS_ROLLED", TemplateFormatType.TEMPLATE_TLIS);
			map.put("TLIS_SLAP", TemplateFormatType.TEMPLATE_TLIS);
			map.put("TLIM_ROLLED", TemplateFormatType.TEMPLATE_TLIM);
			map.put("TLIM_SLAP", TemplateFormatType.TEMPLATE_TLIM);
			map.put("TLIX", TemplateFormatType.TEMPLATE_TLIX);
			map.put("LI", TemplateFormatType.TEMPLATE_LI);
			map.put("LIS", TemplateFormatType.TEMPLATE_LIS);
			map.put("LIM", TemplateFormatType.TEMPLATE_LIM);
			map.put("LIX", TemplateFormatType.TEMPLATE_LIX);
			map.put("LLI", TemplateFormatType.TEMPLATE_LLI);
			map.put("LLIS", TemplateFormatType.TEMPLATE_LLIS);
			map.put("LLIM", TemplateFormatType.TEMPLATE_LLIM);
			map.put("LLIX", TemplateFormatType.TEMPLATE_LLIX);
			map.put("LIP", TemplateFormatType.TEMPLATE_LIP);
			map.put("LLIP", TemplateFormatType.TEMPLATE_LLIP);
			map.put("TLIP", TemplateFormatType.TEMPLATE_TLIP);
			map.put("FI", TemplateFormatType.TEMPLATE_FI);
			map.put("II", TemplateFormatType.TEMPLATE_II);
			stringToTemplateFormatTypeForInquiry = Collections.unmodifiableMap(map);
		}
		{
			// table 66
			Map<Integer, String> map = new HashMap<>();
			map.put(RDBT_CONTAINER_ID, "RDBT");
			map.put(SDBT_CONTAINER_ID, "SDBT");
			map.put(RDBTM_CONTAINER_ID, "RDBTM");
			map.put(SDBTM_CONTAINER_ID, "SDBTM");
			map.put(RDBL_CONTAINER_ID, "RDBL_");
			map.put(SDBL_CONTAINER_ID, "SDBL_");
			map.put(RDBLS_CONTAINER_ID, "RDBLS_");
			map.put(SDBLS_CONTAINER_ID, "SDBLS_");
			map.put(RDBLM_CONTAINER_ID, "RDBLM_");
			map.put(SDBLM_CONTAINER_ID, "SDBLM_");
			map.put(XDBL_CONTAINER_ID, "XDBL");
			map.put(PDB_CONTAINER_ID, "PDB_");
			map.put(FDB_CONTAINER_ID, "FDB_");
			map.put(LDB_CONTAINER_ID, "LDB");
			map.put(PLDB_CONTAINER_ID, "PLDB");
			map.put(LDBS_CONTAINER_ID, "LDBS");
			map.put(LDBM_CONTAINER_ID, "LDBM");
			map.put(LDBX_CONTAINER_ID, "LDBX");
			map.put(IDB_CONTAINER_ID, "IDB");
			intContainerIdToString = Collections.unmodifiableMap(map);
		}
		{
			// table 67
			Map<LfmlRotationLimit, Pc2RotationLimitType> map = new HashMap<>();
			map.put(LfmlRotationLimit.ROTATION_DEGREE_15,
				Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
			map.put(LfmlRotationLimit.ROTATION_DEGREE_30,
				Pc2RotationLimitType.PC2_ROTATION_DEGREE_30);
			map.put(LfmlRotationLimit.ROTATION_DEGREE_60,
				Pc2RotationLimitType.PC2_ROTATION_DEGREE_60);
			map.put(LfmlRotationLimit.ROTATION_DEGREE_180,
				Pc2RotationLimitType.PC2_ROTATION_DEGREE_180);
			lfmlRotationLimitToPc2RotationLimitType = Collections.unmodifiableMap(map);
		}
		{
			// table 68
			Map<LfmlSpeedLevel, Pc2SpeedLevelType> map = new HashMap<>();
			map.put(LfmlSpeedLevel.SPEED_LEVEL_1, Pc2SpeedLevelType.PC2_SPEED_LEVEL_1);
			map.put(LfmlSpeedLevel.SPEED_LEVEL_2, Pc2SpeedLevelType.PC2_SPEED_LEVEL_2);
			map.put(LfmlSpeedLevel.SPEED_LEVEL_3, Pc2SpeedLevelType.PC2_SPEED_LEVEL_3);
			map.put(LfmlSpeedLevel.SPEED_LEVEL_4, Pc2SpeedLevelType.PC2_SPEED_LEVEL_4);
			map.put(LfmlSpeedLevel.SPEED_LEVEL_5, Pc2SpeedLevelType.PC2_SPEED_LEVEL_5);
			map.put(LfmlSpeedLevel.SPEED_LEVEL_6, Pc2SpeedLevelType.PC2_SPEED_LEVEL_6);
			map.put(LfmlSpeedLevel.SPEED_LEVEL_7, Pc2SpeedLevelType.PC2_SPEED_LEVEL_7);
			map.put(LfmlSpeedLevel.SPEED_LEVEL_8, Pc2SpeedLevelType.PC2_SPEED_LEVEL_8);
			map.put(LfmlSpeedLevel.SPEED_LEVEL_9, Pc2SpeedLevelType.PC2_SPEED_LEVEL_9);
			lfmlSpeedLevelToPc2SpeedLevelType = Collections.unmodifiableMap(map);
		}
		{
			// table 69
			Map<LfmlDistortionLevel, Pc2DistortionLevelType> map = new HashMap<>();
			map.put(LfmlDistortionLevel.DISTORTION_LEVEL_1,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_1);
			map.put(LfmlDistortionLevel.DISTORTION_LEVEL_2,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_2);
			map.put(LfmlDistortionLevel.DISTORTION_LEVEL_3,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_3);
			map.put(LfmlDistortionLevel.DISTORTION_LEVEL_4,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_4);
			map.put(LfmlDistortionLevel.DISTORTION_LEVEL_5,
				Pc2DistortionLevelType.PC2_DISTORTION_LEVEL_5);
			lfmlDistortionLevelToPc2DistortionLevelType =
				Collections.unmodifiableMap(map);
		}
		{
			// table 70
			Map<TemplateFormatType, String> map = new HashMap<>();
			map.put(TemplateFormatType.TEMPLATE_RDBT, "RDBT");
			map.put(TemplateFormatType.TEMPLATE_RDBTM, "RDBTM");
			map.put(TemplateFormatType.TEMPLATE_RDBLX, "XDBL");
			map.put(TemplateFormatType.TEMPLATE_LDB, "LDB");
			map.put(TemplateFormatType.TEMPLATE_PLDB, "");
			map.put(TemplateFormatType.TEMPLATE_LDBS, "LDBS");
			map.put(TemplateFormatType.TEMPLATE_LDBM, "LDBM");
			map.put(TemplateFormatType.TEMPLATE_LDBX, "LDBX");
			map.put(TemplateFormatType.TEMPLATE_RDBL, "RDBL");
			map.put(TemplateFormatType.TEMPLATE_RDBLS, "RDBLS");
			map.put(TemplateFormatType.TEMPLATE_RDBLM, "RDBLM");
			map.put(TemplateFormatType.TEMPLATE_PDB, "");
			map.put(TemplateFormatType.TEMPLATE_FDB, "");
			map.put(TemplateFormatType.TEMPLATE_TI, "TI");
			map.put(TemplateFormatType.TEMPLATE_TIM, "TIM");
			map.put(TemplateFormatType.TEMPLATE_TLI, "TLI");
			map.put(TemplateFormatType.TEMPLATE_TLIS, "TLIS");
			map.put(TemplateFormatType.TEMPLATE_TLIM, "TLIM");
			map.put(TemplateFormatType.TEMPLATE_TLIX, "TLIX");
			map.put(TemplateFormatType.TEMPLATE_LI, "LI");
			map.put(TemplateFormatType.TEMPLATE_LIS, "LIS");
			map.put(TemplateFormatType.TEMPLATE_LIM, "LIM");
			map.put(TemplateFormatType.TEMPLATE_LIX, "LIX");
			map.put(TemplateFormatType.TEMPLATE_LLI, "LLI");
			map.put(TemplateFormatType.TEMPLATE_LLIS, "LLIS");
			map.put(TemplateFormatType.TEMPLATE_LLIM, "LLIM");
			map.put(TemplateFormatType.TEMPLATE_LLIX, "LLIX");
			map.put(TemplateFormatType.TEMPLATE_LIP, "LIP");
			map.put(TemplateFormatType.TEMPLATE_LLIP, "LLIP");
			map.put(TemplateFormatType.TEMPLATE_TLIP, "TLIP");
			map.put(TemplateFormatType.TEMPLATE_FI, "");
			templateFormatTypeToStringName = Collections.unmodifiableMap(map);
		}
		{
			// table 71
			Map<TemplateFormatType, String> map = new HashMap<>();
			map.put(TemplateFormatType.TEMPLATE_RDBT, "RDBT");
			map.put(TemplateFormatType.TEMPLATE_RDBTM, "RDBTM");
			map.put(TemplateFormatType.TEMPLATE_RDBLX, "RDBLX");
			map.put(TemplateFormatType.TEMPLATE_LDB, "LDB");
			map.put(TemplateFormatType.TEMPLATE_LDBS, "LDBS");
			map.put(TemplateFormatType.TEMPLATE_LDBM, "LDBM");
			map.put(TemplateFormatType.TEMPLATE_LDBX, "LDBX");
			map.put(TemplateFormatType.TEMPLATE_RDBL, "RDBL");
			map.put(TemplateFormatType.TEMPLATE_RDBLS, "RDBLS");
			map.put(TemplateFormatType.TEMPLATE_RDBLM, "RDBLM");
			map.put(TemplateFormatType.TEMPLATE_TI, "RDBT");
			map.put(TemplateFormatType.TEMPLATE_TIM, "RDBTM");
			map.put(TemplateFormatType.TEMPLATE_TLI, "RDBL");
			map.put(TemplateFormatType.TEMPLATE_TLIS, "RDBLS");
			map.put(TemplateFormatType.TEMPLATE_TLIM, "RDBLM");
			map.put(TemplateFormatType.TEMPLATE_TLIX, "RDBLX");
			map.put(TemplateFormatType.TEMPLATE_LI, "LDB");
			map.put(TemplateFormatType.TEMPLATE_LIS, "LDBS");
			map.put(TemplateFormatType.TEMPLATE_LIM, "LDBM");
			map.put(TemplateFormatType.TEMPLATE_LIX, "LDBX");
			map.put(TemplateFormatType.TEMPLATE_LLI, "LDB");
			map.put(TemplateFormatType.TEMPLATE_LLIS, "LDBS");
			map.put(TemplateFormatType.TEMPLATE_LLIM, "LDBM");
			map.put(TemplateFormatType.TEMPLATE_LLIX, "LDBX");
			templateFormatTypeToStringDbType = Collections.unmodifiableMap(map);
		}
		{
			// table 72
			Map<IrisSearchMode, IrisSearchModeType> map = new HashMap<>();
			map.put(IrisSearchMode.IRIS_SEARCH_MODE_PERFORMANCE,
				IrisSearchModeType.IRIS_SEARCH_MODE_PERFORMANCE);
			map.put(IrisSearchMode.IRIS_SEARCH_MODE_STANDARD,
				IrisSearchModeType.IRIS_SEARCH_MODE_STANDARD);
			map.put(IrisSearchMode.IRIS_SEARCH_MODE_ACCURACY,
				IrisSearchModeType.IRIS_SEARCH_MODE_ACCURACY);
			irisSearchModeToIrisSearchModeType = Collections.unmodifiableMap(map);
		}

		{
			// table 73
			Map<String, TemplateFormatType> map = new HashMap<>();
			map.put("RDBT", TemplateFormatType.TEMPLATE_RDBT);
			map.put("SDBT", TemplateFormatType.TEMPLATE_RDBT);
			map.put("RDBTM", TemplateFormatType.TEMPLATE_RDBTM);
			map.put("SDBTM", TemplateFormatType.TEMPLATE_RDBTM);
			map.put("XDBL", TemplateFormatType.TEMPLATE_RDBLX);
			map.put("LDB", TemplateFormatType.TEMPLATE_LDB);
			map.put("PLDB", TemplateFormatType.TEMPLATE_PLDB);
			map.put("LDB_S", TemplateFormatType.TEMPLATE_LDBS);
			map.put("LDBM", TemplateFormatType.TEMPLATE_LDBM);
			map.put("LDBX", TemplateFormatType.TEMPLATE_LDBX);
			map.put("IDB", TemplateFormatType.TEMPLATE_IDB);

			String[] keys = {
				"RDBL_", "RDBLS_", "RDBLM_", "SDBL_", "SDBLS_", "SDBLM_"
			};
			TemplateFormatType[] templates =
				{
					TemplateFormatType.TEMPLATE_RDBL, TemplateFormatType.TEMPLATE_RDBLS,
					TemplateFormatType.TEMPLATE_RDBLM
				};

			for (int i = 0; i < keys.length; i++) {
				for (int number = 1; number < 11; number++) {
					map.put(new StringBuilder(keys[i]).append(number).toString(),
						templates[i % 3]);
				}
			}

			for (int i = 1; i < 17; i++) {
				map.put(new StringBuilder("PDB_").append(i).toString(),
					TemplateFormatType.TEMPLATE_PDB);
			}
			for (int i = 1; i < 11; i++) {
				map.put(new StringBuilder("FDB_").append(i).toString(),
					TemplateFormatType.TEMPLATE_FDB);
			}

			map.put("TI_ROLLED", TemplateFormatType.TEMPLATE_TI);
			map.put("TI_SLAP", TemplateFormatType.TEMPLATE_TI);
			map.put("TIM_ROLLED", TemplateFormatType.TEMPLATE_TIM);
			map.put("TIM_SLAP", TemplateFormatType.TEMPLATE_TIM);
			map.put("TLI_ROLLED", TemplateFormatType.TEMPLATE_TLI);
			map.put("TLI_SLAP", TemplateFormatType.TEMPLATE_TLI);
			map.put("TLIS_ROLLED", TemplateFormatType.TEMPLATE_TLIS);
			map.put("TLIS_SLAP", TemplateFormatType.TEMPLATE_TLIS);
			map.put("TLIM_ROLLED", TemplateFormatType.TEMPLATE_TLIM);
			map.put("TLIM_SLAP", TemplateFormatType.TEMPLATE_TLIM);
			map.put("TLIX", TemplateFormatType.TEMPLATE_TLIX);
			map.put("LI", TemplateFormatType.TEMPLATE_LI);
			map.put("LI_S", TemplateFormatType.TEMPLATE_LIS);
			map.put("LIM", TemplateFormatType.TEMPLATE_LIM);
			map.put("LIX", TemplateFormatType.TEMPLATE_LIX);
			map.put("LLI", TemplateFormatType.TEMPLATE_LLI);
			map.put("LLI_S", TemplateFormatType.TEMPLATE_LLIS);
			map.put("LLIM", TemplateFormatType.TEMPLATE_LLIM);
			map.put("LLIX", TemplateFormatType.TEMPLATE_LLIX);
			map.put("LIP", TemplateFormatType.TEMPLATE_LIP);
			map.put("LLIP", TemplateFormatType.TEMPLATE_LLIP);
			map.put("TLIP", TemplateFormatType.TEMPLATE_TLIP);
			map.put("FI_1", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_2", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_3", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_4", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_5", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_6", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_7", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_8", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_9", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_10", TemplateFormatType.TEMPLATE_FI);
			map.put("II", TemplateFormatType.TEMPLATE_II);

			stringToTemplateFormatTypeForGetBinary = Collections.unmodifiableMap(map);
		}
		{
			// table 74
			Map<String, TemplateFormatType> map = new HashMap<>();
			map.put("TI_ROLLED", TemplateFormatType.TEMPLATE_TI);
			map.put("TI_SLAP", TemplateFormatType.TEMPLATE_TI);
			map.put("TIM_ROLLED", TemplateFormatType.TEMPLATE_TIM);
			map.put("TIM_SLAP", TemplateFormatType.TEMPLATE_TIM);
			map.put("TLI_ROLLED", TemplateFormatType.TEMPLATE_TLI);
			map.put("TLI_SLAP", TemplateFormatType.TEMPLATE_TLI);
			map.put("TLIS_ROLLED", TemplateFormatType.TEMPLATE_TLIS);
			map.put("TLIS_SLAP", TemplateFormatType.TEMPLATE_TLIS);
			map.put("TLIM_ROLLED", TemplateFormatType.TEMPLATE_TLIM);
			map.put("TLIM_SLAP", TemplateFormatType.TEMPLATE_TLIM);
			map.put("TLIX", TemplateFormatType.TEMPLATE_TLIX);
			map.put("LI", TemplateFormatType.TEMPLATE_LI);
			map.put("LI_S", TemplateFormatType.TEMPLATE_LIS);
			map.put("LIM", TemplateFormatType.TEMPLATE_LIM);
			map.put("LIX", TemplateFormatType.TEMPLATE_LIX);
			map.put("LLI", TemplateFormatType.TEMPLATE_LLI);
			map.put("LLI_S", TemplateFormatType.TEMPLATE_LLIS);
			map.put("LLIM", TemplateFormatType.TEMPLATE_LLIM);
			map.put("LLIX", TemplateFormatType.TEMPLATE_LLIX);
			map.put("LIP", TemplateFormatType.TEMPLATE_LIP);
			map.put("LLIP", TemplateFormatType.TEMPLATE_LLIP);
			map.put("TLIP", TemplateFormatType.TEMPLATE_TLIP);
			map.put("FI_1", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_2", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_3", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_4", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_5", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_6", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_7", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_8", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_9", TemplateFormatType.TEMPLATE_FI);
			map.put("FI_10", TemplateFormatType.TEMPLATE_FI);
			map.put("II", TemplateFormatType.TEMPLATE_II);

			stringSearchTemplateToTemplateFormatTypeForGetBinary =
				Collections.unmodifiableMap(map);
		}

		{
			// table 75
			Map<String, TemplateFormatType> map = new HashMap<>();
			map.put("RDBT", TemplateFormatType.TEMPLATE_RDBT);
			map.put("SDBT", TemplateFormatType.TEMPLATE_RDBT);
			map.put("RDBTM", TemplateFormatType.TEMPLATE_RDBTM);
			map.put("SDBTM", TemplateFormatType.TEMPLATE_RDBTM);
			map.put("XDBL", TemplateFormatType.TEMPLATE_RDBLX);
			map.put("LDB", TemplateFormatType.TEMPLATE_LDB);
			map.put("PLDB", TemplateFormatType.TEMPLATE_PLDB);
			map.put("LDBS", TemplateFormatType.TEMPLATE_LDBS);
			map.put("LDBM", TemplateFormatType.TEMPLATE_LDBM);
			map.put("LDBX", TemplateFormatType.TEMPLATE_LDBX);
			map.put("IDB", TemplateFormatType.TEMPLATE_IDB);

			String[] keys = {
				"RDBL_", "RDBLS_", "RDBLM_", "SDBL_", "SDBLS_", "SDBLM_"
			};
			TemplateFormatType[] templates =
				{
					TemplateFormatType.TEMPLATE_RDBL, TemplateFormatType.TEMPLATE_RDBLS,
					TemplateFormatType.TEMPLATE_RDBLM
				};

			for (int i = 0; i < keys.length; i++) {
				for (int number = 1; number < 11; number++) {
					map.put(new StringBuilder(keys[i]).append(number).toString(),
						templates[i % 3]);
				}
			}

			for (int i = 1; i < 17; i++) {
				map.put(new StringBuilder("PDB_").append(i).toString(),
					TemplateFormatType.TEMPLATE_PDB);
			}
			for (int i = 1; i < 11; i++) {
				map.put(new StringBuilder("FDB_").append(i).toString(),
					TemplateFormatType.TEMPLATE_FDB);
			}

			stringToTemplateFormatTypeForInsert = Collections.unmodifiableMap(map);
		}

		{
			// table 76
			Map<IrisExtractionMode, IrisExtractionModeType> map = new HashMap<>();
			map.put(IrisExtractionMode.IRIS_EXTRACT_MODE_PERFORMANCE,
				IrisExtractionModeType.IRIS_EXTRACTION_MODE_PERFORMANCE);
			map.put(IrisExtractionMode.IRIS_EXTRACT_MODE_ACCURACY,
				IrisExtractionModeType.IRIS_EXTRACTION_MODE_ACCURACY);
			irisExtractionModeToIrisExtractionModeType = Collections.unmodifiableMap(map);
		}
	}
	/**
	 * 
	 * @param key
	 * @param map
	 * @return
	 * @throws InvalidParameterException
	 */
	public static <K, V> V getValue(K key, Map<K, V> map)
		throws InvalidParameterException {
		if (key == null) {
			throw new InvalidParameterException("An invalid parameter: source is null.");
		}

		if (key instanceof String) {
			if (((String)key).equals(EMPTY)) {
				throw new InvalidParameterException(
					"An invalid parameter: value is empty.");
			}
		}

		if (!map.containsKey(key)) {
			StringBuilder sb =
				new StringBuilder("An invalid parameter: couldn't get a value with ");
			sb.append(toString(key)).append(".");
			throw new InvalidParameterException(sb.toString());
		}
		return map.get(key);
	}

	/**
	 * 
	 * 
	 * @return
	 */
	private static JAXBContext getInstance() {
		try {
			return JAXBContext.newInstance("jp.co.nec.aim.mm.jaxb");
		} catch (JAXBException e) {
			// get wrapped in RuntimeException
			Throwables.propagate(e);
		}
		return null;
	}

	/**
	 * 
	 * 
	 */
	public static JAXBContext getJaxbContext() {
		return jaxbContext;
	}

	/**
	 * 
	 * @param key
	 * @return
	 */
	private static <K> String toString(K key) {
		StringBuilder sb = new StringBuilder(EMPTY);
		if (key instanceof String) {
			sb.append(key);
		} else if (key.getClass().isEnum()) {
			sb.append(key.toString());
		} else if (key instanceof Integer) {
			sb.append(String.valueOf(((Integer)key).intValue()));
		} else if (key instanceof Character) {
			sb.append(key.toString());
		}
		return sb.toString();
	}
}
