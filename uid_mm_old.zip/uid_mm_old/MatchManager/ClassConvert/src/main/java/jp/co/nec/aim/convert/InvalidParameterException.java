package jp.co.nec.aim.convert;

public class InvalidParameterException extends ConvertException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7238277887127249336L;

	/**
	 * 
	 */
	public InvalidParameterException() {
		super();
	}

	/**
	 * 
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public InvalidParameterException(String message, Throwable cause,
		boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/**
	 * 
	 * @param message
	 * @param cause
	 */
	public InvalidParameterException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * 
	 * @param message
	 */
	public InvalidParameterException(String message) {
		super(message);
	}

	/**
	 * 
	 * @param cause
	 */
	public InvalidParameterException(Throwable cause) {
		super(cause);
	}
}
