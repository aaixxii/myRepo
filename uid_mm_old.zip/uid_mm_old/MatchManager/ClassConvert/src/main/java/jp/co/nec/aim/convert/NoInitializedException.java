package jp.co.nec.aim.convert;

public class NoInitializedException extends ConvertException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3085291537691605852L;
	
	/**
	 * 
	 */
	public NoInitializedException() {
		super();
	}

	/**
	 * 
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public NoInitializedException(String message, Throwable cause,
		boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/**
	 * 
	 * @param message
	 * @param cause
	 */
	public NoInitializedException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * 
	 * @param message
	 */
	public NoInitializedException(String message) {
		super(message);
	}

	/**
	 * 
	 * @param cause
	 */
	public NoInitializedException(Throwable cause) {
		super(cause);
	}
}
