package jp.co.nec.aim.convert;

public class UnmarshalException extends ConvertException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7506340002695016379L;

	public UnmarshalException() {
		super();
	}

	public UnmarshalException(String message, Throwable cause,
		boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public UnmarshalException(String message, Throwable cause) {
		super(message, cause);
	}

	public UnmarshalException(String message) {
		super(message);
	}

	public UnmarshalException(Throwable cause) {
		super(cause);
	}

}
