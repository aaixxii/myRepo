package jp.co.nec.aim.convert;

public class InvalidPayloadException extends ConvertException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3567331470942166002L;

	public InvalidPayloadException() {
		super();
	}

	public InvalidPayloadException(String message, Throwable cause,
		boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public InvalidPayloadException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidPayloadException(String message) {
		super(message);
	}

	public InvalidPayloadException(Throwable cause) {
		super(cause);
	}

}
