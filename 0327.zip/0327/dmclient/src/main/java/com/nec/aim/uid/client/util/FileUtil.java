package com.nec.aim.uid.client.util;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FileUtil {
	private static Logger logger = LoggerFactory.getLogger(FileUtil.class);

	public static byte[] getDataFromFile(String templateFileName) {
		File templateFile = new File(templateFileName);
		if (!templateFile.exists() || !templateFile.isFile()) {
			logger.error("The template file is wrong. skip process...");
			return null;
		}
		FileInputStream input = null;
		byte[] temp = null;
		try {
			input = new FileInputStream(templateFile);
			temp = new byte[4000];
			input.read(temp);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			templateFile = null;
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return temp;
	}

	public static List<String> readStringDataByJava8(String fullPath) throws IOException {
		String os = System.getProperty("os.name").toLowerCase();
		if (os.indexOf("windows") >= 0 && fullPath.startsWith("/")) {
			fullPath = fullPath.substring(1, fullPath.length());
		}
		return Files.lines(Paths.get(fullPath)).collect(Collectors.toList());
	}

	public static String readStringFromDat(String fullPath) throws IOException {
		File file = new File(fullPath);
		BufferedReader br = new BufferedReader(new FileReader(file));
		StringBuffer fileContents = new StringBuffer();
		String line = br.readLine();
		while (line != null) {
			fileContents.append(line);
			line = br.readLine();
		}
		br.close();
		return fileContents.toString();
	}

	public static List<byte[]> readMuiltByteData(String fullPath) throws IOException {
		List<byte[]> results = new ArrayList<>();
		String pathString = readStringFromDat(fullPath);
		int idx = pathString.indexOf("=");
		pathString = pathString.substring(idx + 1, pathString.length());
		String[] stringArry = pathString.split(";");
		for (String one : stringArry) {
			byte[] tmp = getDataFromFile(one);
			results.add(tmp);
		}
		return results;
	}
	
	public void saveImageToFile(String imageFormat, byte[] toBeSaveImage, String fileNameNoextension) {
		try {
			InputStream in = new ByteArrayInputStream(toBeSaveImage);
			BufferedImage bImageFromConvert = ImageIO.read(in);
			ImageIO.write(bImageFromConvert, imageFormat, new File(fileNameNoextension + "." + imageFormat));									
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
	
	public static byte[] readImageFromFile(String imageFormat, String imageFullName)  {
		ByteArrayOutputStream baos = null;
		try {
			BufferedImage originalImage = ImageIO.read(new File(imageFullName));
			baos = new ByteArrayOutputStream();
			ImageIO.write( originalImage, imageFormat, baos );
			baos.flush();
			byte[] imageInByte = baos.toByteArray();
			originalImage = null;
			return imageInByte;
		} catch (Exception e) {
			return null;
		} finally {
			try {
				baos.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);				
			}
		}
	}
	
	public static void saveStringToFile(String savecontent, String savePath)  {	
		File file = new File(savePath);
		try (FileOutputStream fop = new FileOutputStream(file)) {			
			if (!file.exists()) {
				file.createNewFile();
			}			
			byte[] contentInBytes = savecontent.getBytes();

			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			logger.info("Sucess save string to " + savePath);

		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}		
	}
}
