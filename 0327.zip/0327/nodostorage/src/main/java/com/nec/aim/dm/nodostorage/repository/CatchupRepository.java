package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;
import java.util.List;
import com.nec.aim.dm.nodostorage.entity.Catchup;

public interface CatchupRepository {
	 public List<Catchup> getMyCathupData(Integer storageId,  List<Long> segmentIds) throws SQLException;
	 public void deleteAfterCatchup (Integer storageId, Long segmentId) throws SQLException;

}
