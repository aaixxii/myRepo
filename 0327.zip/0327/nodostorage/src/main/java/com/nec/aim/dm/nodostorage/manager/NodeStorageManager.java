package com.nec.aim.dm.nodostorage.manager;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.nec.aim.dm.nodostorage.segments.SegmentWriter;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class NodeStorageManager {

	private static final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
	private static ExecutorService dmJobExecutor = Executors.newCachedThreadPool();
	private static final ConcurrentHashMap<Long, SegmentWriter> segmentsQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Integer> dmIntSetingMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, String> dmStringSetingMap = new ConcurrentHashMap<>();
	
	public static void saveDmIntConfigToMe(String key, Integer value) {
		dmIntSetingMap.putIfAbsent(key, value);
	}
	
	public static int getIntDmConfigValue(String key) {
		return dmIntSetingMap.get(key);
	}
	
	public static void saveStringDmConfigToMe(String key, String value) {
		 dmStringSetingMap.putIfAbsent(key, value);
	}
	
	public static String getStringDmConfigValue(String key) {
		return dmStringSetingMap.get(key);
	}
	
	

	public static void sheduleTask(Runnable task, long rate) {
		scheduler.scheduleAtFixedRate(task, 0, rate, TimeUnit.MILLISECONDS);
	}

	public static void saveToQueue(Long segId, SegmentWriter segInfo) {
		segmentsQueue.putIfAbsent(segId, segInfo);
		log.info("success saved to queue");
	}

	public static void updateToQueue(Long segId, SegmentWriter segInfo) {
		segmentsQueue.remove(segId);
		segmentsQueue.put(segId, segInfo);
		log.info("success update to queue");
	}

	public static SegmentWriter getSegmentWriter(Long segId) {
		return segmentsQueue.get(segId);
	}

	public static Boolean sumitDmJob(Callable<Boolean> task) {
		Future<Boolean> future = dmJobExecutor.submit(task);
		try {
			return future.get();
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
			return Boolean.FALSE;
		}
	}

	public static <T> CompletableFuture<T> callableAsync(Callable<T> c) {
		CompletableFuture<T> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());

			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf;
	}

	public static Boolean submit(Callable<Boolean> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Boolean> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

}
