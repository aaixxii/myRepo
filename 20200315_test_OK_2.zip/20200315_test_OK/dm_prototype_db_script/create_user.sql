#create dmdb user

CREATE USER 'dmuser'@'%' IDENTIFIED BY 'dmuser@SV99';
GRANT ALL PRIVILEGES ON *.* TO 'dmuser'@'%' WITH GRANT OPTION;
flush privileges;

