package com.nec.aim.dm.dmservice.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class ConfigProperties {	
	@Value("${dm.charset}")
	private String charset;

	@Value("${dm.serverSocketPort}")
	private String serverSocketPort;
	
	@Value("${dm.serverSocketTimeout}")
	private String serverSocketTimeout;	
}
