package com.nec.aim.dm.dmservice.dispatch;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.entity.NodeStorage;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.DmInfoRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentLoadRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;


@Service
public class Dispatcher {
	
	@Autowired
	DmInfoRepository dmInfoRepository;

	@Autowired
	NodeStorageRepository nodeRepository;

	@Autowired
	DmConfigRepository dmConfigRepository;

	@Autowired
	SegmentLoadRepository segmentLoadRepository;

	@Autowired
	SegmentRepository segmentRepository;

	@Transactional
	public Boolean handlePostRequest(PBDmSyncRequest dmSegReq) throws SQLException, DmServiceException {		
		String changeType = null;
		Long bioId_start = null;
		Long bioId_end = null;		
		Long segId = null;
		Long segVer = null;
		try {
			changeType = dmSegReq.getCmd().name().toUpperCase();			
			if (dmSegReq.hasBioIdStart()) {
				bioId_start = Long.valueOf(dmSegReq.getBioIdStart());
			}			
			if (dmSegReq.hasBioIdEnd()) {
				bioId_end = Long.valueOf(dmSegReq.getBioIdEnd());
			}			
					
			segId = Long.valueOf(dmSegReq.getTargetSegment().getId());
			segVer = Long.valueOf(dmSegReq.getTargetSegment().getVersion());
			
		} catch (Exception e) {
			throw new DmServiceException(e);
		}
		
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(segId);
		segInfo.setVersion(segVer);
		if (bioId_start != null) {
			segInfo.setBioIdStart(bioId_start);			
		}	
		
		if (bioId_end != null) {
			segInfo.setBioIdEnd(bioId_end);			
		}	
		
		int redundancy = dmConfigRepository.getRedundancy();
		List<NodeStorage> activeNodeStorages = nodeRepository.findNeedNodeByRedundancy(redundancy);
		if (activeNodeStorages == null || activeNodeStorages.size() < 1) {
			throw new DmServiceException("No active node storages! skip process and return.");
		}
		
		if (redundancy < 1) {
			throw new DmServiceException("redundancy is less 1! Can't process dm service will return.");
		}
		
		boolean mmReturnValue = true;

		if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) { // add segment			
			mmReturnValue = processNewSegment(activeNodeStorages, segInfo, dmSegReq);
		}  else {
			List<NodeStorage> targetNodeStorages = nodeRepository.getNodeStorgeBySegmentId(segInfo.getSegmentId());
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) { // update template
				mmReturnValue = processTempalteInsert(targetNodeStorages, segInfo, dmSegReq);
			} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) { // delete template
				mmReturnValue = processTempalteDelete(activeNodeStorages, segInfo, dmSegReq);
			}
		}		
		return Boolean.valueOf(mmReturnValue);
	}

	private boolean processNewSegment(List<NodeStorage> activeNodeStorages, SegmentInfo segInfo, PBDmSyncRequest dmSegReq) throws SQLException {
		
		if (segInfo.getBioIdStart() == null || segInfo.getBioIdEnd() == null) {
			throw new DmServiceException("In new segment, bio_id_start and bio_id_end can't be null");
		}
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		segLoading.setLastVersion(0L);
		segInfo.setVersion(0L);
		//List<NodeStorage> allNodeStorages = nodeRepository.findAll();
		boolean mmReturnValue = true;
//		List<NodeStorage> notActiveNodeStorages = allNodeStorages.stream()
//				.filter(one -> !activeNodeStorages.contains(one)).collect(Collectors.toList());

		segmentRepository.insertSegment(segInfo);
		
		for (int i = 0; i < activeNodeStorages.size(); i++) {
			NodeStorage one = activeNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			segLoading.setStatus(0);			
			try {				
				segmentLoadRepository.insertSegmentLoad(segLoading);
			} catch (Exception e) {
				throw new DmServiceException(e);
			}
			String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
			Boolean result = HttpPoster.post(nodeUrl, dmSegReq);
			try {
				if (result.booleanValue()) {
					segmentRepository.updateAfterNew(-1, segInfo.getSegmentId());
					segmentLoadRepository.updateAfterNew(-1, one.getStorageId(), segInfo.getSegmentId());
				} else {
					segmentRepository.updateAfterNew(-9, segInfo.getSegmentId());
					segmentLoadRepository.updateAfterNew(-9, one.getStorageId(), segInfo.getSegmentId());
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				}
			} catch (Exception e) {				
				throw new DmServiceException(e);
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}
		return mmReturnValue;
	}

	private boolean processTempalteInsert(List<NodeStorage> targetNodeStorages,SegmentInfo segInfo, PBDmSyncRequest dmSegReq) {			
		boolean mmReturnValue = true;		
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());			
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			NodeStorage one = targetNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			Boolean result = null;
			try {
				long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getStorageId(), segInfo.getSegmentId());						
				if (segInfo.getVersion() == nodoSegmentVersion + 1) {
					segmentRepository.updateSegment(segInfo);
					String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
					result = HttpPoster.post(nodeUrl, dmSegReq);
					if (result.booleanValue()) {						
						segLoading.setLastVersion(segInfo.getVersion());
						segmentLoadRepository.updateSegmentLoadNoMailFlag(segLoading);
					}
				} else {
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				}

			} catch (SQLException e) {
				throw new DmServiceException(e);
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}
		return mmReturnValue;
	}

	private boolean processTempalteDelete(List<NodeStorage> targetNodeStorages, SegmentInfo segInfo,
			PBDmSyncRequest dmSegReq) {
		boolean mmReturnValue = true;
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());		
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			NodeStorage one = targetNodeStorages.get(i);
			segLoading.setStorage_id(one.getStorageId());
			Boolean result = null;
			try {
				long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getStorageId(),
						segInfo.getSegmentId());
				if (segInfo.getVersion() == nodoSegmentVersion + 1) {
					segmentRepository.updateSegmentAfterDelete(segInfo); //how to do with bio_end
					String nodeUrl = dmInfoRepository.getNodeStorageUrl(one.getStorageId());
					result = HttpPoster.post(nodeUrl, dmSegReq);
					if (result.booleanValue()) {
						segLoading.setLastVersion(segInfo.getVersion());										
						segmentLoadRepository.updateAfterDelWithNoMailFlag(segLoading);
					}
				} else {
					nodeRepository.setSignalMailFlag(one.getStorageId(), one.getDmStorageid());
				}

			} catch (SQLException e) {
				result = false;
				throw new DmServiceException(e);
			}
			mmReturnValue = mmReturnValue && result.booleanValue();
		}
		return mmReturnValue;
	}

	public byte[] dispatchGetRequest(Long segId) throws InterruptedException, ExecutionException, SQLException {
		List<NodeStorage> activeList = nodeRepository.findAll();
		if (activeList == null || activeList.size() < 1) {
			throw new DmServiceException("No active dm stroage node for process");
		}
		Collections.shuffle(activeList);
		byte[] result = HttpPoster.getSegment(activeList.get(0).getUrl(), segId);
		return result;
	}
}
