//package jp.co.nec.aim.mm.ws;
//
//import javax.annotation.PostConstruct;
//import javax.ejb.EJB;
//import javax.ejb.Stateless;
//import javax.ejb.TransactionAttribute;
//import javax.ejb.TransactionAttributeType;
//import javax.jws.WebMethod;
//import javax.jws.WebParam;
//import javax.jws.WebService;
//import javax.jws.soap.SOAPBinding;
//import javax.xml.ws.soap.SOAPFaultException;
//
//import jp.co.nec.aim.clientapi.CommonOptions;
//import jp.co.nec.aim.clientapi.afis.AfisDeletionFunctionEnum;
//import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
//import jp.co.nec.aim.clientapi.afis.AfisRegistrationFunctionEnum;
//import jp.co.nec.aim.clientapi.afis.AfisUpdateFunctionEnum;
//import jp.co.nec.aim.convert.ProtoClassConvert;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
//import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
//import jp.co.nec.aim.mm.acceptor.service.AimExtractService;
//import jp.co.nec.aim.mm.acceptor.service.AimInquiryService;
//import jp.co.nec.aim.mm.acceptor.service.AimSyncService;
//import jp.co.nec.aim.mm.exception.AimRuntimeException;
//import jp.co.nec.aim.mm.exception.ExceptionHelper;
//import jp.co.nec.aim.mm.jaxb.AfisTemplateSet;
//import jp.co.nec.aim.mm.logger.PerformanceLogger;
//import jp.co.nec.aim.mm.util.StopWatch;
//
//import org.jboss.logging.NDC;
//import org.jboss.ws.api.annotation.WebContext;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
///**
// * Published WebService for IRIS.
// * 
// * @author mozj
// * 
// */
//@WebService(name = "IrisJobControlService")
//@Stateless
//@TransactionAttribute(TransactionAttributeType.REQUIRED)
//@WebContext(contextRoot = "/AIMWebServices", secureWSDLAccess = false)
//@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
//public class IrisJobControl {
//	private final static Logger log = LoggerFactory
//			.getLogger(IrisJobControl.class);
//
//	@EJB
//	private AimSyncService syncService;
//
//	@EJB
//	private AimInquiryService inquiryService;
//
//	@EJB
//	private AimExtractService extractService;
//
//	/** exception **/
//	private ExceptionHelper exception;
//
//	/** the common of Class Converter **/
//	private ProtoClassConvert convert;
//
//	/**
//	 * Default constructor
//	 */
//	public IrisJobControl() {
//	}
//
//	/**
//	 * Initial function
//	 */
//	@PostConstruct
//	public void init() {
//		this.convert = new ProtoClassConvert();
//		this.exception = new ExceptionHelper();
//	}
//
//	/**
//	 * Iris Registration
//	 * 
//	 * @param externalId
//	 * @param eventId
//	 * @param afisTemplateSet
//	 * @throws PIDFaultException
//	 * @throws InvalidTemplateException
//	 */
//	@WebMethod
//	public void IR(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("IR");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisRegistrationFunctionEnum.IR, externalId, eventId,
//					afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("IR succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "IR",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	/**
//	 * Iris Update (Iris Delete and Iris Registration)
//	 * 
//	 * @param externalId
//	 * @param eventId
//	 * @param afisGroupId
//	 * @param afisTemplateSet
//	 * @throws PIDFaultException
//	 * @throws InvalidTemplateException
//	 */
//	@WebMethod
//	public void IU(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			@WebParam(name = "afisGroupId") Integer afisGroupId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("IU");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisUpdateFunctionEnum.IU, externalId, eventId,
//					afisGroupId, afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("IU succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId = "
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "IU",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	/**
//	 * Iris Delete
//	 * 
//	 * @param externalId
//	 * @param eventId
//	 * @param afisGroupId
//	 * @throws PIDFaultException
//	 */
//	@WebMethod
//	public void ID(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") Integer eventId,
//			@WebParam(name = "afisGroupId") Integer afisGroupId)
//			throws AimRuntimeException {		
//		NDC.push("ID");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisDeletionFunctionEnum.ID, externalId, eventId,
//					afisGroupId);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("ID succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId = "
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "ID",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	/**
//	 * Iris inquiry
//	 * 
//	 * @param afisTemplateSet
//	 * @param commonOptions
//	 * @return
//	 * @throws PIDFaultException
//	 */
//	@WebMethod
//	public long II(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("II");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert
//					.toPBInquiryJobRequest(AfisLowLevelFunctionEnum.II,
//							afisTemplateSet, commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "II",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//}
