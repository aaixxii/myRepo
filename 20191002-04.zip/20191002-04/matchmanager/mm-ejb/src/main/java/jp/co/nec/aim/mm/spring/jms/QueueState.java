package jp.co.nec.aim.mm.spring.jms;

/**
 * QueueState represents Queue status in JBoss.
 * 
 * @author kurosu
 * 
 */
public class QueueState {
	/** Max number of messages in Queue */
	private int maxSize;
	/** Number of messages in Queue */
	private int messageCount;

	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public int getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(int messageCount) {
		this.messageCount = messageCount;
	}

}
