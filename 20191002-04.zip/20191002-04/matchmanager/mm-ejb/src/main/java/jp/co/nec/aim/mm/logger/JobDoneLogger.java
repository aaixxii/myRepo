/**
 * 
 */
package jp.co.nec.aim.mm.logger;

import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.baton.JobQueueMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidateList;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidate;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateList;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.mm.entities.JobQueueEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Wrapper class of jobDoneLogger.
 * 
 * @author mozj
 * 
 */
public class JobDoneLogger {

	private static Logger log = LoggerFactory.getLogger("jobDoneLogger");

	private JdbcTemplate jdbcTemplate;

	public JobDoneLogger(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * export log to jobdone.log
	 * 
	 * @param jobQueue
	 * @param results
	 * @param failed
	 */
	public void info(JobQueueEntity jobQueue,
			IdentifyResponse searchJobResult, Integer functionId) {
		JobQueueMessage message = copyJobQueue(jobQueue, searchJobResult,
				functionId);
		log.info(message.toString());
	}

	/**
	 * Copy from JobQueueEntity to JobQueueMessage.
	 * 
	 * @param jobQueue
	 * @param results
	 * @param failed
	 * @return
	 */
	private JobQueueMessage copyJobQueue(JobQueueEntity jobQueue,
			IdentifyResponse searchJobResult, Integer functionId) {
		Long submissionTs = jdbcTemplate.queryForObject(
				"select submission_ts from job_queue where job_id=?",
				Long.class, new Long(jobQueue.getJobId()));
		PBBusinessMessage pbMsg = PBBusinessMessage.parseFrom(searchJobResult.getBusinessMessage(0).toByteArray());
		long readCount = searchJobResult.getStatistics().getAmr()
				.getReadCount();
		long matchCount = searchJobResult.getStatistics().getAmr()
				.getMatchCount();
		//boolean isHit = hasHitFlag(searchJobResult.getCandidateList());
		boolean failed = pbMsg.getResponse().getStatus().toLowerCase().contains(" success");
				
		JobQueueMessage message = new JobQueueMessage();
		message.setConsolidateByContainer(false);
		message.setFailed(failed);
		message.setHitThreshold(jobQueue.getHitThreshold());
		message.setId(jobQueue.getJobId());
		message.setMaxCandidates(jobQueue.getMaxCandidates());
		message.setMultiRecordCandidates(false);
		message.setPaused(false);
		message.setPercentagePoint(jobQueue.getPercentagePoint());
		message.setPriority(jobQueue.getPriority());
		message.setRevision(0);
		message.setState(jobQueue.getJobState().getVal());
		message.setTimeOfResults(new Date(jobQueue.getResultsTS()));
		message.setTimeOfSubmission(new Date(submissionTs));
		message.setHit(isHit);
		message.setReadCount((int) readCount);
		message.setMatchCount((int) matchCount);
		message.setFunctionId(functionId);
		return message;
	}

	private boolean hasHitFlag(PBCandidateList inquiryList) {
		if (inquiryList != null) {
		 List<PBCandidate> candidateList = inquiryList.getCandidatesList();
		 //ToDo
					
//			for (PBCandidate candidate : candidateList) {
//				Boolean hit = candidate.getHitFlag();
//				if (hit != null && hit.booleanValue()) {
//					return true;
//				}
//			}
		}
		return false;
	}
}
