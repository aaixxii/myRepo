package jp.co.nec.aim.mm.acceptor;

/**
 * Record information used for save the template
 * 
 * @author liuyq
 * 
 */
public class Record {

	/**
	 * Record default constructor
	 * 
	 * @param binary
	 *            template binary
	 */
	public Record(byte[] binary) {
		this.binary = binary;
	}

	private byte[] binary;

	public byte[] getBinary() {
		return binary;
	}

	public void setBinary(byte[] binary) {
		this.binary = binary;
	}
}
