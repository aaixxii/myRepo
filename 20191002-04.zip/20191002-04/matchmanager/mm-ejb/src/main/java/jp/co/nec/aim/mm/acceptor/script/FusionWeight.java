package jp.co.nec.aim.mm.acceptor.script;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlValue;

/**
 * <p>
 * Java class for fusion-weight complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="fusion-weight">
 *   &lt;simpleContent>
 *     &lt;extension base="&lt;http://www.w3.org/2001/XMLSchema>int">
 *       &lt;attribute name="inquirySet" type="{urn:nec:aim}inquiry-set-enum" />
 *     &lt;/extension>
 *   &lt;/simpleContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fusion-weight", propOrder = { "value" })
public class FusionWeight {

	@XmlValue
	protected int value;
	@XmlAttribute
	protected String inquirySet;

	/**
	 * Gets the value of the value property.
	 * 
	 */
	public int getValue() {
		return value;
	}

	/**
	 * Sets the value of the value property.
	 * 
	 */
	public void setValue(int value) {
		this.value = value;
	}

	/**
	 * Gets the value of the inquirySet property.
	 * 
	 * @return possible object is {@link InquirySetEnum }
	 * 
	 */
	public String getInquirySet() {
		return inquirySet;
	}

	/**
	 * Sets the value of the inquirySet property.
	 * 
	 * @param value
	 *            allowed object is {@link InquirySetEnum }
	 * 
	 */
	public void setInquirySet(String value) {
		this.inquirySet = value;
	}

}
