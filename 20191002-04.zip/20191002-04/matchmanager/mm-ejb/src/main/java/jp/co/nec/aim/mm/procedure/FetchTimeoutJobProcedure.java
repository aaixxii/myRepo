package jp.co.nec.aim.mm.procedure;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Procedure sub Class to call finish_timeout_job()<br/>
 * finish_timeout_job() set DONE for SEMGNET_JOBS but not JOB_QUEUE. TopLevelJob
 * should be set DONE by JobAggregation
 * 
 * @author kurosu
 * 
 */
public class FetchTimeoutJobProcedure extends StoredProcedure {
	private static final String SQL = "MATCH_MANAGER_API.fetch_timeout_job";

	public FetchTimeoutJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		declareParameter(new SqlOutParameter("p_job_ids", Types.ARRAY,
				"NUM_TABLE_TYPE"));
		setSql(SQL);
		compile();
	}

	/**
	 * update timeout JOBS DONE.
	 * 
	 * @return long array of JOB_ID , which is timeout and should be retry.
	 * @throws SQLException
	 */
	public List<Long> execute() throws SQLException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = execute(new HashMap<String, Object>());
		Array array = (Array) map.get("p_job_ids");

		BigDecimal[] result = (BigDecimal[]) array.getArray();

		List<Long> list = new ArrayList<Long>();
		for (BigDecimal jobId : result) {
			list.add(jobId.longValue());
		}

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());

		return list;
	}

}
