package jp.co.nec.aim.mm.sessionbeans;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.xml.ws.http.HTTPException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;

import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.BatchJobInfoDao;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.MuLoadDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExtractJobHandler;
import jp.co.nec.aim.mm.util.Deflater;
import jp.co.nec.aim.mm.util.TimeHelper;

/**
 * EJB to record search job results into DB.
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ExtractJobCompleteBean {
	private static final Logger log = LoggerFactory.getLogger(ExtractJobCompleteBean.class);
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	private SystemConfigDao sysConfigDao;
	private MuLoadDao muLoadDao;
	private FEJobDao feJobDao;
	private DateDao dateDao;
	private BatchJobInfoDao batchInoDao;

	private ExtractJobHandler extractJobHandler;
	private FeJobDoneLogger feJobDoneLogger;
	private ExceptionSender exceptionSender;

	public ExtractJobCompleteBean() {
	}

	@PostConstruct
	public void init() {
		extractJobHandler = new ExtractJobHandler(manager, dataSource);
		feJobDoneLogger = new FeJobDoneLogger(dataSource);
		exceptionSender = new ExceptionSender();

		sysConfigDao = new SystemConfigDao(manager);
		muLoadDao = new MuLoadDao(dataSource);
		feJobDao = new FEJobDao(manager);
		batchInoDao = new BatchJobInfoDao(manager);
		dateDao = new DateDao(dataSource);
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * Update for extract jobs
	 * 
	 * @param extactJobResult
	 * @throws InvalidProtocolBufferException
	 */
	public void completeExtractJobs(PBMuExtractJobResult extactJobResult) throws InvalidProtocolBufferException {
		long muId = extactJobResult.getMuId();
		long lotJobId = extactJobResult.getLotJobId();
		int updatedRecordCnt = 0;
		log.info("Ready to complete Lot Extract Jobs: {}, MU id: {}.", lotJobId, muId);
		try {
			Integer maxExtractJobFailures = sysConfigDao.getMMPropertyInt(MMConfigProperty.MAX_EXTRACT_JOB_FAILURES);			

			for (PBMuExtractJobResultItem ejrItem : extactJobResult.getResultList()) {
				long exJobId = ejrItem.getJobId();
				log.info("mu PBMuExtractJobResultItem jobId= {}", exJobId);
				PBBusinessMessage pbMsg = PBBusinessMessage.parseFrom(ejrItem.getResult());
				E_REQUESET_TYPE reqType = pbMsg.getRequest().getRequestType();
				if (reqType.equals(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT)) {
					AimManager.saveToExtractJobResutQueue(String.valueOf(exJobId), ejrItem);
					log.info("Get extract result for INSERT_REFURL. jobId:{}", exJobId);
					return;
				}	
				PBResponse muResponse = pbMsg.getResponse();
				if (muResponse.getStatus().toLowerCase().equals("0")) {
					log.info("MU " + muId + " finishing extract job " + ejrItem.getJobId());
					updatedRecordCnt = finishExtractJob(ejrItem.getJobId(), muId, ejrItem, false);
				} else {
					if (muResponse.hasResendable() && muResponse.getResendable().toUpperCase().equals("Y")) {
						exceptionSender.sendAimException(muResponse.getStatus(), muResponse.getErrorMessage(), 0,
								ejrItem.getJobId(), muId, null);

						FeJobQueueEntity eje = manager.find(FeJobQueueEntity.class, new Long(ejrItem.getJobId()));
						manager.refresh(eje);
						if (eje == null || eje.getMuId() == null || eje.getMuId() != muId) {
							log.warn("MU " + muId + " attempting to report error reason '" + muResponse.getStatus()
									+ " : " + muResponse.getStatus() + "' of nonexistant or unassigned job "
									+ ejrItem.getJobId() + ", ignoring...");
						} else {
							AimServiceState aimServiceState = new AimServiceState();
							aimServiceState.setErrMsg(muResponse.getErrorMessage());
							aimServiceState.setErrorcode(muResponse.getStatus());
							aimServiceState.setFailureTime(muResponse.getResponseAttributes(0).getAttributeValue());
							updatedRecordCnt = extractJobHandler.failExtractJob(eje, muId, aimServiceState, false,
									maxExtractJobFailures);
						}

					} else {
						log.warn("MU " + muId + " failed extract job " + ejrItem.getJobId());
						if (Objects.isNull(muResponse.getErrorMessage())) {
							throw new IllegalArgumentException(
									"The reason must be specified when service state is error..");
						}
						exceptionSender.sendAimException(muResponse.getStatus(), muResponse.getErrorMessage(), 0,
								ejrItem.getJobId(), muId, null);
						updatedRecordCnt = finishExtractJob(ejrItem.getJobId(), muId, ejrItem, true);
					}
				}

				/* send Jms to ExtractJobPlanner */
				JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.FEJobCompleteBean,
						"Recieve Extract Job " + ejrItem.getJobId());
			}
		} catch (SQLException | IOException e) {
			log.error(e.getMessage(), e);
			throw new AimRuntimeException(e.getMessage(), e);
		} finally {
			log.info("Ready to delete Lot Extract Jobs: {}" + " and decrease ExtractLoad with MU id: {}.", lotJobId,
					muId);
			feJobDao.deleteLotJob(extactJobResult.getLotJobId());
			if (updatedRecordCnt > 0) {
				muLoadDao.decreaseExtractLoad(muId);
				// increaseExtractJobCompleteCount(updatedRecordCnt);
			}
		}
	}


	/**
	 * Finish extract job normally.
	 * 
	 * @param jobId
	 * @param muId
	 * @param itemResult
	 * @param failed
	 * @throws SQLException
	 * @throws IOException
	 * @throws HTTPException
	 */
	private int finishExtractJob(long jobId, long muId, PBMuExtractJobResultItem jobResult, boolean failed)
			throws SQLException, IOException {
		TimeHelper th = new TimeHelper("finishExtractJob");
		th.t();
		PBBusinessMessage pbMsg = PBBusinessMessage.parseFrom(jobResult.getResult());
		PBResponse muResponse = pbMsg.getResponse();
		int numCompleted = extractJobHandler.completeExtractJob(jobId, muId, jobResult, failed);

		if (0 < numCompleted) {
			if (failed) {
				log.warn("{} is faild, error info:{}", jobId, muResponse.getErrorMessage());
			}
			// ExtractResponse lastResut =
			// unPressPayloadAndBuildPBExtractJobResult(jobResult); toBeCheck
			List<BatchJobInfoEntity> batchInfo = batchInoDao.getBatchJobInfo(jobId, BatchType.EXTRACT.name());
			BatchJobInfoEntity entify = batchInfo.get(0);
			ExtractResponse.Builder resResult = ExtractResponse.newBuilder();
			resResult.setBatchJobId(entify.getBatchJobId());
			resResult.setType(BatchType.valueOf(entify.getBatchType()));
			resResult.addBusinessMessage(pbMsg.toByteString());	
			log.info("AIM jobId= {}",Long.valueOf(jobId));
			log.info("AIM resResult:{}", resResult.toString());
			AimManager.saveExtractClientJobResult(String.valueOf(jobId), resResult.build());
			feJobDoneLogger.info(jobId);

		} else {
			log.warn("Extract job (Id:" + jobId + ") is nonexistent or already-complete.");
		}

		th.t();
		if (log.isDebugEnabled()) {
			log.debug(th.message());
		}

		return numCompleted;
	}

	public void increaseExtractJobCompleteCount(int finishedFeJobs) {
		Long updateTime = dateDao.getCurrentTimeMS();
		String updateSql = "" + "UPDATE extract_complete_count " + "SET complete_count = COMPLETE_COUNT + ?, "
				+ " complete_ts = ?";
		jdbcTemplate.update(updateSql, new Object[] { new Integer(finishedFeJobs), updateTime });
	}

	public ExtractResponse unPressPayloadAndBuildPBExtractJobResult(PBMuExtractJobResultItem pbExInternal)
			throws IOException {
		byte[] compressedPBBusinessMessage = null;
		ExtractResponse.Builder pBExtractJobResult = ExtractResponse.newBuilder();
		compressedPBBusinessMessage = pbExInternal.getResult().toByteArray();
		byte[] uncompressedResult = Deflater.uncompress(compressedPBBusinessMessage);
		pBExtractJobResult.addBusinessMessage(ByteString.copyFrom(uncompressedResult));
		return pBExtractJobResult.build();
	}
}
