package jp.co.nec.aim.mm.acceptor.service;


import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.util.ProtobufCreater;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimSyncServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private AimSyncService aimSyncService;
	@Resource
	private JdbcTemplate jdbcTemplate;
	
	private ProtobufCreater protobufCreater;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from SYSTEM_CONFIG");
		jdbcTemplate
				.update("INSERT INTO SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME, PROPERTY_VALUE) VALUES (1000, 'TEMPLATE_VALIDATION.ENABLED', 'false')");

		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.execute("commit");
		setMockMethod();
		protobufCreater = new ProtobufCreater();
	}

	@After
	public void tearDown() {

		jdbcTemplate
				.update("update CONTAINERS set MAX_SEGMENT_SIZE = 20000000 ");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");		
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.execute("commit");		
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}

		};
	}
	
	@Test
	@Ignore
	public void syncDataTest_insert_by_url() {
		SyncRequest syncReq = protobufCreater.createInsertRequest(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);
		PBMuExtractJobResultItem.Builder  exresult  = PBMuExtractJobResultItem.newBuilder();
		exresult.setJobId(100);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);		
		pq.setEnrollmentId("enrollId1");
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		PBResponse.Builder pbRes = PBResponse.newBuilder();
		pbRes.setStatus("0:sucess");
		PBDataBlock.Builder dataBlock = PBDataBlock.newBuilder();
		PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
		template.setData(ByteString.copyFrom("template data".getBytes()));
		template.setReferenceId("enrollId1");
		dataBlock.setTemplateInfo(template.build());
		pbMsg.setDataBlock(dataBlock.build());
		exresult.setResult(pbMsg.build().toByteString());
		aimSyncService.syncData(syncReq);		
	}
	
	@Test
	public void syncDataTest_insert_by_refId() throws InvalidProtocolBufferException {		
		SyncRequest syncReq = protobufCreater.createInsertRequest(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);		
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);		
		pq.setEnrollmentId("enrollId1");
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		PBResponse.Builder pbRes = PBResponse.newBuilder();
		pbRes.setStatus("0:sucess");
		PBDataBlock.Builder dataBlock = PBDataBlock.newBuilder();
		PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
		template.setData(ByteString.copyFrom("template data".getBytes()));
		template.setReferenceId("enrollId1");
		dataBlock.setTemplateInfo(template.build());
		pbMsg.setDataBlock(dataBlock.build());	
		PBMuExtractJobResultItem.Builder muItem = PBMuExtractJobResultItem.newBuilder();
		muItem.setJobId(100);
		muItem.setResult(pbMsg.build().toByteString());
		byte[] result = muItem.build().toByteArray();
		String sql = "insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,REFERENCE_ID,JOB_STATE,SUBMISSION_TS, RESULT) "
				+ "values(1000,17,'enrollId1',1, 333, ?)";
		jdbcTemplate.update(sql, new Object[] {result});
	
		SyncResponse responce = aimSyncService.syncData(syncReq);		
		Assert.assertNotNull(responce);
		PBBusinessMessage pbmg = PBBusinessMessage.parseFrom(responce.getBusinessMessage(0).toByteArray());
		pbmg.getResponse().getStatus().contains("success");
	}
	
	@Test
	public void syncDeleteTest() throws InvalidProtocolBufferException {
		SyncRequest.Builder syncDeleteReq = SyncRequest.newBuilder();
		syncDeleteReq.setBatchJobId(1);
		syncDeleteReq.setType(BatchType.ENROLL);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setEnrollmentId("external1");
		pq.setRequestType(E_REQUESET_TYPE.DELETE_REFID);
		pbMsg.setRequest(pq.build());
		syncDeleteReq.addBusinessMessage(pbMsg.build().toByteString());
		jdbcTemplate
		.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID) "
				+ "values(1,'external1',TO_BLOB('111'),3,111,0,1,1)");
		jdbcTemplate.execute("commit");
		SyncResponse responce = aimSyncService.syncData(syncDeleteReq.build());		
		Assert.assertNotNull(responce);
		PBBusinessMessage pbmg = PBBusinessMessage.parseFrom(responce.getBusinessMessage(0).toByteArray());
		pbmg.getResponse().getStatus().contains("success");	
	}
}
