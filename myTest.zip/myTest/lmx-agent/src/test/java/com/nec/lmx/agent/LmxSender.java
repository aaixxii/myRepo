package com.nec.lmx.agent;

import java.lang.reflect.Type;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class LmxSender {
	private final static ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();

	public static void main(String[] args) {
		LmxSocketMock mock = new LmxSocketMock();
		mock.init(8888);
		licenseMap.put("AFIS", "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS");
		licenseMap.put("EXPIRED", "false");
		licenseMap.put("DIFFERENT", "false");
		Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();	

		Type mapType = new TypeToken<Map<String, String>>() {}.getType();		
		String licesneInfo = gson.toJson(licenseMap, mapType);		
		mock.sendLinceseInfo(licesneInfo);

	}

}
