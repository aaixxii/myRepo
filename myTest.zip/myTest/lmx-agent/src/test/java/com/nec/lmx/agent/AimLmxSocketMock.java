package com.nec.lmx.agent;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.event.EventAdapter;
import com.nec.lmx.agent.event.EventNotifier;

public class AimLmxSocketMock extends EventAdapter {
	private Selector selector;
	private SocketChannel socketChannel;
	private Object channelLocker;
	private int lmxPort;

	//private static Logger logger = LoggerFactory.getLogger(AimLmxSocketMock.class);

	private static final AimLmxSocketMock lmxSocket = new AimLmxSocketMock();

	public static AimLmxSocketMock getInstance() {
		return lmxSocket;
	}

	public AimLmxSocketMock() {
		this.channelLocker = new Object();
	}

	public void init(int port) {
		try {
			InetSocketAddress hostAddress = new InetSocketAddress("localhost", port);
			socketChannel = SocketChannel.open(hostAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setKeepAlive(true);
			selector = Selector.open();
			socketChannel.register(selector, SelectionKey.OP_WRITE);
			System.out.println(
					"Connected to" + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());
			this.lmxPort = port;
			EventNotifier.getInstance().addListener(this);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onMessage(String msg) {
		sendLinceseInfo(msg);
	}

	private void sendLinceseInfo(String licenseInfo) {
		int sendSize = 0;
		try {
			byte[] bodys = licenseInfo.getBytes("UTF-8");
			int sizeOfBody = bodys.length;
			ByteBuffer sendBuff = ByteBuffer.allocate(sizeOfBody);
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.put(bodys);
			sendBuff.flip();
		
				while (sendBuff.hasRemaining()) {
					sendSize = socketChannel.write(sendBuff);
					System.out.println("Send data size{}: " + sendSize);
				}
			
			sendBuff.clear();
			sendBuff = null;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		SelectionKey key = null;
		try {
			while (selector.select() > 0) {
				if (!socketChannel.isConnected() || !socketChannel.isOpen()) {
					init(lmxPort);
				} else {
					System.out.println("LmxSocket still active .");
				}
				Set<SelectionKey> keys = selector.selectedKeys();
				Iterator<SelectionKey> keyIterator = keys.iterator();
				while (keyIterator.hasNext()) {
					key = (SelectionKey) keyIterator.next();
					keyIterator.remove();
					if (!key.isWritable()) {
						continue;
					}
					try {
						Thread.sleep(10 * 60 * 1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			try {
				if (key != null) {
					key.cancel();
					key.channel().close();
				}
			} catch (Exception ex) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onStop() throws IOException {
		if (socketChannel != null || socketChannel.isOpen()) {
			socketChannel.close();
		}
	}

}
