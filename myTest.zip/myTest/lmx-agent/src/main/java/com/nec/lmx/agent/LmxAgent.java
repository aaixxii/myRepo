package com.nec.lmx.agent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.lmx.FloatingLicenseManager;
import com.nec.lmx.agent.socket.LmxSocket;

/**
 * @author 000001A006PBP
 *
 */
public class LmxAgent {
	
	public LmxAgent() {		
	}
	
	private static Logger logger = LoggerFactory.getLogger(LmxAgent.class);		
	private static final String SHUTDONW = "shutdown";	
	private static  String PORT;
	private static  String LICENSE_SERVER_URL;
	
	
	public static void main(String[] args) {	
		LmxAgent LmxAgent = new LmxAgent();
		LmxAgent.handleParameter(args);
		 String licenseServerUrl = System.getProperty("java.lmx.license.path");
		 if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {
			 logger.error("License server url is invaild: it's empty!");
			 System.exit(0);
		 }
		if (isCheckUrl(licenseServerUrl)) {
			LICENSE_SERVER_URL = licenseServerUrl;			
		} else {
			logger.error("License server url is invaild: {}", licenseServerUrl);
			System.exit(0);
		}
		startAgent();
	}
	
	private void handleParameter(String[] args) {		
		if (args.length < 1) {			
			pringUsage();
			System.exit(0);
		} 
		
		if (args[0].isEmpty()) {
			pringUsage();
			System.exit(0);
		}
		
		 if (args[0].toUpperCase().equals(SHUTDONW)) {
			 shutdown();
		 }
		 
		 if (args[0].length() > 1) {
			 if (isMatchPort(args[0])) {
				 PORT = args[0];				 
			 }
		 }		
	}
	
	private void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("Usage for boot LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("LmxAgent port serverUrl");
		logger.info(sb.toString());		
		sb.delete(0, sb.length());

		sb.append("Usage for stop LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("LmxAgent shutdown");
		logger.info(sb.toString());		

	}
	
	private void shutdown() {
		//ToDo release all resource
	}
	
	private static void startAgent() {
		FloatingLicenseManager.getInstance().initLmx(LICENSE_SERVER_URL);
		LmxSocket agent = LmxSocket.getInstance();
		agent.init(Integer.valueOf(PORT));
		agent.run();
	}
	
	
	
	private boolean isMatchPort(String port) {
		if (port == null || port.isEmpty()) {
			return false;
		}
		 Pattern p = Pattern.compile("^[1-9]*$");
		 Matcher m = p.matcher(port);
		 return m.matches();
		//return port.matches("^[0-9]*$");
	}
	
	public  static boolean isCheckUrl(String licenseServerUrl) {		
		if (licenseServerUrl == null || licenseServerUrl.isEmpty() || licenseServerUrl.length() < 5 ) {
			return false;
		} 		
		int index = licenseServerUrl.indexOf("@");
		if (index < 0 ) {
			return false;
		} else {
			String firstEx = licenseServerUrl.substring(0, index);
			if (!firstEx.matches("^[0-9]*$")) {
				return false;				
			} else {
				 String tmp = licenseServerUrl.substring(index + 1, licenseServerUrl.length());
				if (tmp == null || tmp.length() < 1) {
					return false;
				} else {
					return true;
				}
			}
		}
	}

}
