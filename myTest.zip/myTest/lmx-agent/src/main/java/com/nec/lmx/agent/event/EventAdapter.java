package com.nec.lmx.agent.event;

import java.io.IOException;



/**
 * @author xiazp <br/>
 * The interface of EventListener
 */
public class EventAdapter implements EventListener {

	@Override
	public void onError(String error) {
	}

	@Override
	public void onStop() throws IOException {
	}

	@Override
	public void onMessage(String msg) {	
	}	
}