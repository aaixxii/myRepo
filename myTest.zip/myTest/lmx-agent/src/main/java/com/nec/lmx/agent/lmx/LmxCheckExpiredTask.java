package com.nec.lmx.agent.lmx;

public class LmxCheckExpiredTask implements Runnable{
	@Override
	public void run() {
		FloatingLicenseManager fm = FloatingLicenseManager.getInstance();
		fm.checkEndDate();			
	}
}
