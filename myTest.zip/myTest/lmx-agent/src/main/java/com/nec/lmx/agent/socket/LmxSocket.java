package com.nec.lmx.agent.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.event.EventAdapter;
import com.nec.lmx.agent.event.EventNotifier;

public class LmxSocket extends EventAdapter {
	private static final int BUFF_SIZE = 256;
	private ByteBuffer sendBuff;
	private Selector selector;
	private SocketChannel socketChannel;
	private Object channelLocker;
	private int lmxPort;

	private static Logger logger = LoggerFactory.getLogger(LmxSocket.class);

	private static final LmxSocket lmxSocket = new LmxSocket();

	public static LmxSocket getInstance() {
		return lmxSocket;
	}

	public LmxSocket() {
		this.channelLocker = new Object();
	}

	public void init(int port) {
		try {
			InetSocketAddress hostAddress = new InetSocketAddress("localhost", port);
			socketChannel = SocketChannel.open(hostAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setKeepAlive(true);
			selector = Selector.open();
			socketChannel.register(selector, SelectionKey.OP_WRITE);
			sendBuff = ByteBuffer.allocate(BUFF_SIZE);
			logger.info(
					"Connected to" + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());
			this.lmxPort = port;
			EventNotifier.getInstance().addListener(this);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	public void onMessage(String msg) {
		sendLinceseInfo(msg);
	}

	private void sendLinceseInfo(String licenseInfo) {
		int sendSize = 0;
		try {
			byte[] bodys = licenseInfo.getBytes("UTF-8");
			//int sizeOfBody = bodys.length;
			sendBuff.clear();
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.put(bodys);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					sendSize = socketChannel.write(sendBuff);
					logger.info("Send data size{}: ", sendSize);
				}
			}
			sendBuff.clear();			
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public void run() {
		SelectionKey key = null;
		try {
			while (selector.select() > 0) {
				if (!socketChannel.isConnected() || !socketChannel.isOpen()) {
					init(lmxPort);
				} else {
					logger.debug("LmxSocket still active on {}.", new Date());
				}
				Set<SelectionKey> keys = selector.selectedKeys();
				Iterator<SelectionKey> keyIterator = keys.iterator();
				while (keyIterator.hasNext()) {
					key = (SelectionKey) keyIterator.next();
					keyIterator.remove();
					if (!key.isWritable()) {
						continue;
					}
					try {
						Thread.sleep(10 * 60 * 1000);
					} catch (InterruptedException e) {
						logger.error(e.getMessage(), e);
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			try {
				if (key != null) {
					key.cancel();
					key.channel().close();
				}
			} catch (Exception ex) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	@Override
	public void onStop() throws IOException {
		if (socketChannel != null || socketChannel.isOpen()) {
			socketChannel.close();
		}
	}
}
