package com.nec.lmx.agent.lmx;


public class LmxHeatBeatTask implements Runnable{

	@Override
	public void run() {
		FloatingLicenseManager fm = FloatingLicenseManager.getInstance();
		fm.lmxHeartbeat();			
	}
}
