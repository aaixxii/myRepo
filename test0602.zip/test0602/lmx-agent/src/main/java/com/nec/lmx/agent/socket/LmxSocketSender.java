package com.nec.lmx.agent.socket;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.event.EventListener;
import com.nec.lmx.agent.event.EventNotifier;

class LmxSocketSender implements EventListener {
	private static final int BUFF_SIZE = 256;
	private ByteBuffer sendBuff;
	private SocketChannel socketChannel;
	private Object channelLocker;

	private static Logger logger = LoggerFactory.getLogger(LmxSocketSender.class);
	
	private static final LmxSocketSender INSTANCE = new LmxSocketSender();
	public static LmxSocketSender getInstance() {
		return INSTANCE;
	}	
	
	public LmxSocketSender() {	
		this.channelLocker = new Object();
		sendBuff = ByteBuffer.allocate(BUFF_SIZE);
	}
	

	public void init(SocketChannel socketChannel) {
		this.socketChannel = socketChannel;			
		logger.info("LmxSocketSender succss started!");		
		EventNotifier.getInstance().addListener(this);
		logger.info("Send first test messag:");
		sendTestMessge();
		logger.info("Success send first test messag:");
	}

	@Override
	public void onMessage(String msg) {
		sendLinceseInfo(msg);
	}

	@Override
	public void onStop() throws IOException {
		if (socketChannel != null || socketChannel.isOpen()) {
			socketChannel.close();
		}
	}

	@Override
	public void onError(String error) {
		sendLinceseInfo(error);
	}

	private void sendLinceseInfo(String licenseInfo) {
		int sendSize = 0;
		try {
			byte[] bodys = licenseInfo.getBytes("UTF-8");
			// int sizeOfBody = bodys.length;
			sendBuff.clear();
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.put(bodys);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					sendSize = socketChannel.write(sendBuff);
					logger.info("Send data size = {}", sendSize);
				}
			}
			sendBuff.clear();
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}
	
	private static void sendTestMessge() {
		String option = "TYPE=FULL;COMPONENT=MM;MODALTY=FINGER,FACE,PALM,IRIS";
		String expired = "false";
		StringBuilder sb = new StringBuilder();
		sb.append("AFIS");
		sb.append("=");
		sb.append(option);
		sb.append(";");
		sb.append("EXPIRED");
		sb.append("=");
		sb.append(expired);
		EventNotifier.getInstance().fireOnMessage(sb.toString());
	}
}
