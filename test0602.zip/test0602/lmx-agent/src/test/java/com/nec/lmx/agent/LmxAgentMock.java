/**
 * 
 */
package com.nec.lmx.agent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author 000001A006PBP
 *
 */
public class LmxAgentMock {
	
	public LmxAgentMock() {		
	}
	
	private static Logger logger = LoggerFactory.getLogger(LmxAgent.class);	
	
	public static void main(String[] args) {	
		LmxAgentMock LmxAgent = new LmxAgentMock();
		LmxAgent.handleParameter(args);
		 String licenseServerUrl = System.getProperty("java.lmx.license.path");
		 if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {
			 logger.error("License server url is invaild: it's empty!");
			 System.exit(0);
		 }
		if (isMatchUrl(licenseServerUrl)) {			
		} else {
			logger.error("License server url is invaild: {}", licenseServerUrl);
			System.exit(0);
		}
		
	}
	
	public void handleParameter(String[] args) {		
		if (args.length < 1) {			
			pringUsage();
			System.exit(0);
		} 
		
		if (args[0].isEmpty()) {
			pringUsage();
			System.exit(0);
		}		
	
		 
		 if (args[0].length() > 1) {
			 if (isMatchPort(args[0])) {				 
			 }
		 }		
	}
	
	public void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("Usage for boot LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("LmxAgent port serverUrl");
		logger.info(sb.toString());		
		sb.delete(0, sb.length());

		sb.append("Usage for stop LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("LmxAgent shutdown");
		logger.info(sb.toString());	

	}	
	
	
	public boolean isMatchPort(String port) {
		if (port == null || port.isEmpty()) {
			return false;
		}
		 Pattern p = Pattern.compile("^[1-9]*$");
		 Matcher m = p.matcher(port);
		 return m.matches();

		//return port.matches("^[0-9]*$");
	}
	
	public static boolean isMatchUrl(String licenseServerUrl) {
		if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {
			return false;
		}
		Pattern ptn = Pattern.compile("^d{1,}\\@(((\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5])([.](?!$)|$)){4})");
	    Matcher mtch = ptn.matcher(licenseServerUrl);
		return mtch.find();
	}
	
	public boolean isMatchIp(String ip) {
		if (ip == null || ip.isEmpty()) {
			return false;
		}
		Pattern ptn = Pattern.compile("((\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5])([.](?!$)|$)){4}");
		
		//Pattern ptn = Pattern.compile("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");

	    Matcher mtch = ptn.matcher(ip);
		return mtch.matches();		
	}
	
	public  static boolean isCheckUrl(String licenseServerUrl) {		
		if (licenseServerUrl == null || licenseServerUrl.isEmpty() || licenseServerUrl.length() < 5 ) {
			return false;
		} 		
		int index = licenseServerUrl.indexOf("@");
		if (index < 0 ) {
			return false;
		} else {
			String firstEx = licenseServerUrl.substring(0, index);
			if (!firstEx.matches("^[0-9]*$")) {
				return false;				
			} else {
				 String tmp = licenseServerUrl.substring(index + 1, licenseServerUrl.length());
				if (tmp == null || tmp.length() < 1) {
					return false;
				} else {
					return true;
				}
			}
		}
	}
}
