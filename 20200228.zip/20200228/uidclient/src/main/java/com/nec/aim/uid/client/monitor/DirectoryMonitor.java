package com.nec.aim.uid.client.monitor;

import static com.nec.aim.uid.client.common.UidClientConstants.MONITOR_PATH;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.poster.UidMmJobRunManager;

public class DirectoryMonitor implements Runnable {
	private static Logger logger = LoggerFactory.getLogger("DirectoryMonitor");	
	private AtomicBoolean stop = new AtomicBoolean(false);

	public DirectoryMonitor() {		
	}

	@SuppressWarnings("unchecked")
	private void watch() {	
		String monitorPath = UidCommonManager.getValue(MONITOR_PATH);	
			logger.info("begin nomitor directory:{}", monitorPath);
			String os = System.getProperty("os.name").toLowerCase();
			if (os.indexOf("windows") >= 0 ) {
				if (monitorPath.startsWith("/")) {
					monitorPath = monitorPath.substring(1, monitorPath.length());
				}					
			}
			Path path = Paths.get(monitorPath);
			WatchService watchService = null;
			try {
				watchService = FileSystems.getDefault().newWatchService();
				path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);
			} catch (Exception e) {
				throw new UidClientException(e.getMessage(), e);
			}
		
		
			while (!stop.get()) {
				List<String> newFiles = new ArrayList<>();
				try {
					WatchKey watchKey = watchService.take();
					for (WatchEvent<?> event : watchKey.pollEvents()) {	
						WatchEvent.Kind<?> kind = event.kind();						 
						if (kind == StandardWatchEventKinds.OVERFLOW) {
						    continue;
						}
						WatchEvent<Path> ev = (WatchEvent<Path>)event;
						Path filePath = ev.context();						
						String newPath = monitorPath + "/" + filePath.toString();						
						if (newPath != null) {						
							newFiles.add(newPath);
							logger.trace( "found new file:{}!", newPath);						
						}
					}					
					if (newFiles.size() > 0) {
						UidMmJobRunManager.getInstance().jobConsumer.accept(newFiles);
					}
					boolean valid =watchKey.reset();					
					    if (!valid) {
					    	logger.trace( "watch key is invalid, stopping monitor.");
					        break;
					    }
					Thread.sleep(1000);
					
				} catch (Exception e) {
					logger.warn(e.getMessage());
				}	
			}
	}

	public void setStop(boolean action) {
		stop.set(action);
	}

	@Override
	public void run() {
		watch();		
	}
}
