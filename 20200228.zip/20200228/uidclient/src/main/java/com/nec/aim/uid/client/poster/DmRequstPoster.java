package com.nec.aim.uid.client.poster;

import java.util.concurrent.Callable;

public class DmRequstPoster implements Callable<Object> {

	@Override
	public Object call() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
