package com.nec.aim.dm.dmservice.persistence;

import java.util.List;
import com.nec.aim.dm.dmservice.entity.Node;

public interface NodeRepository {
	List<Node> findAll();
	Node findById(Long id);

}
