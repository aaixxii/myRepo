package com.nec.aim.dm.dmservice.config;

import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
//@ConfigurationProperties(prefix = "curator")
public class ConfigProperties {
    private int postTimeOut;  
}  



