package com.nec.aim.dm.nodostorage.controller;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncRequest;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncResponce;
import lombok.extern.slf4j.Slf4j;

/**
 * @author xia
 *
 */
/**
 * @author xia
 *
 */
@Controller
@Slf4j
public class SegmentController extends HttpServlet {
	private static final long serialVersionUID = 8978225136377187339L;

	
	@Autowired
	ConfigProperties config;

	/**
	 * @param req
	 * @param res
	 */
	@RequestMapping(value = "/dmsyncservice", method = RequestMethod.POST)	
	public void dmSegmentHandler(HttpServletRequest req, HttpServletResponse res) {
		log.info("Received dmSyncSegment from {}", req.getRemoteHost());
		
		try {			
			PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(req.getInputStream());
			//boolean result = segmentService.handlePostRequest(dmSegReq);
			PBDmSyncResponce.Builder dmRes = PBDmSyncResponce.newBuilder();
			dmRes.setSuccess(config.isRespose());	
			log.info("Respone to dm service({}), response = {}",  req.getRemoteAddr(), dmRes.getSuccess());
			dmRes.build().writeTo(res.getOutputStream());
				
		} catch (Exception e) {
			PBDmSyncResponce.Builder dmRes = PBDmSyncResponce.newBuilder();		
			
			try {
				dmRes.build().writeTo(res.getOutputStream());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}		
	}
}
