package com.nec.aim.dm.nodostorage.segments;

import static com.nec.aim.dm.nodostorage.segments.DmConstants.SEGMENT_HEADER_SIZE;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_CHECKSUM;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_EMBEDDED_ID;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_MAX_SEGMENT;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_TEMPLATE_ID;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_TSZ;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_VERSION;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.sql.SQLException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.nec.aim.dm.nodostorage.exception.NodeStroageException;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncRequest;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBTemplateInfo;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class SegmentWriter {
	private Long segmentId;
	private Long segmentVerStart;
	private Long bioIdStart;	
	private ReadWriteLock locker;	
	private boolean corrupted;
	private final Lock readLock; 
    private final Lock writeLock;
    private  File myFile;  
    private int oneTemplateSize; 
	
	public SegmentWriter(Long segmentId, Long bioIdStart, Long segVer) throws IOException, SQLException {
		this.segmentId = segmentId;
		this.bioIdStart = bioIdStart;
		this.segmentVerStart = segVer;		
		String storagePath = NodeStorageManager.getStringDmConfigValue("storagePath");
		storagePath = storagePath + "/" + String.valueOf(this.segmentId);
		if (storagePath.contains("\\")) {
			storagePath.replace("\\", "\\\\");
		}		
		this.myFile = new File(NodeStorageManager.getStringDmConfigValue("storagePath") + "/" + String.valueOf(this.segmentId));		
		myFile.createNewFile();
		this.locker = new ReentrantReadWriteLock();			
		this.readLock = locker.readLock();
		this.writeLock = locker.writeLock();
		this.corrupted = false;			
		this.oneTemplateSize = NodeStorageManager.getIntDmConfigValue("templateSize");		
	}	
	
	public Boolean writeSegmentHead()  {
		ByteBuffer segBuffer = ByteBuffer.allocate(DmConstants.SEGMENT_HEADER_SIZE);
		FileOutputStream outputStream = null;
		Boolean sucess = Boolean.FALSE;		
			try {
				outputStream = new FileOutputStream(myFile);
				FileChannel ch = outputStream.getChannel();	
				segBuffer.position(0);
				segBuffer.putInt(DmConstants.AIM_VERSION);
				segBuffer.putShort(DmConstants.FORMAT_ID);
				segBuffer.putLong(DmConstants.MAX_SEGMENT_SIZE);
				segBuffer.putInt(0); //recordCount
				segBuffer.putLong(segmentVerStart);
				segBuffer.flip();
				 FileLock fileLock 
                 = ch.tryLock(0, DmConstants.SEGMENT_HEADER_SIZE, false);
				 if (fileLock != null) {
					 ch.write(segBuffer);
					 outputStream.flush();
				 } else {
					log.error("Can't write to segment file({}", this.segmentId); 
				 }
				
				ch.close();
				NodeStorageManager.saveToQueue(this.segmentId, this);				
				sucess = Boolean.TRUE;
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				sucess = false;
				//myFile.delete();				
			} finally {		
				segBuffer.clear();
				segBuffer = null;
			}
		return sucess;		
	}
	
	public Boolean writeTemplate(PBDmSyncRequest dmSegReq) throws InterruptedException, ExecutionException {
		Callable<Boolean> oneTemplateWrite = () -> {
			long bioIdEnd = dmSegReq.getBioIdEnd();
			PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
			String externalId = null;
			byte[] templateData = null;
			externalId = templateInfo.getReferenceId();
			templateData = templateInfo.getData().toByteArray();		
				
			if (externalId == null || templateData == null || templateData.length < 0) {
				log.error(externalId == null ? "externalId can't null!" : "template data can't null!");
				return Boolean.FALSE;
			}
			long segId = dmSegReq.getTargetSegment().getId();
			long segVer = dmSegReq.getTargetSegment().getVersion();			
			Boolean success = null;
			writeLock.tryLock();			
			try {
				byte[] templateWithHeader = TemplateHeaderHelper.prependHeader(bioIdEnd, templateData, externalId, 1);			
				RandomAccessFile randomFile = new RandomAccessFile(myFile, "rw");				
				randomFile.seek(SIZE_VERSION + SIZE_EMBEDDED_ID + SIZE_MAX_SEGMENT);
				int recordCount = (int)bioIdEnd - this.bioIdStart.intValue() + 1;
				randomFile.writeInt( recordCount);				
				randomFile.writeLong(segVer);
				int beginPosition = DmConstants.SEGMENT_HEADER_SIZE + (int) ((bioIdEnd - this.bioIdStart) * oneTemplateSize) + 1;				
				randomFile.seek(beginPosition);
				randomFile.write(templateWithHeader);
				randomFile.close();	
				success = Boolean.TRUE;
				log.info("Success saved tempate data to segment file, segmentId={}", segId);
			} catch (Exception e) {
				log.error(e.getMessage());
				success = Boolean.FALSE;
			}			
			finally {
				writeLock.unlock();
			}
			return success;
		};
		return NodeStorageManager.submit(oneTemplateWrite);
	}
	
	public Boolean deleteTemplate(Long segId, Long segVer, Long bioId, String extId)
			throws InterruptedException, ExecutionException, IOException {
		Callable<Boolean> delTemplateTask = () -> {	
	
			RandomAccessFile randomFile = null;
			Boolean deleted = null;
			writeLock.tryLock();
			try {
				randomFile = new RandomAccessFile(this.getMyFile(), "rw");
				byte b = 1;				
				int seekPosition = SEGMENT_HEADER_SIZE + (bioId.intValue() - this.getBioIdStart().intValue()) * NodeStorageManager.getIntDmConfigValue("templateSize") + SIZE_CHECKSUM + SIZE_TSZ;
				randomFile.seek(seekPosition);
				long templateId = randomFile.readLong();
				if (templateId == bioId.longValue()) {
					randomFile.seek(seekPosition + SIZE_TEMPLATE_ID);
					randomFile.writeByte(b);
					int recordCount = (bioId.intValue() - this.bioIdStart.intValue()) - 1;
					updateSegmentHead(randomFile, recordCount, segVer);					
					deleted = Boolean.TRUE;
				} else {
					throw new NodeStroageException("Template Id(" + String.valueOf(bioId) + ") not found bioId");
				}				
		
			} catch (Exception e) {
				deleted = Boolean.FALSE;
				log.error(e.getMessage(), e);
			} finally {
				writeLock.unlock();
				randomFile.close();
			}
			return  deleted;
		};
		return NodeStorageManager.submit(delTemplateTask);
	}
	
	private void updateSegmentHead(RandomAccessFile randomFile, int recordCount, long segVer) throws IOException {
		randomFile.seek(SIZE_VERSION + SIZE_EMBEDDED_ID + SIZE_MAX_SEGMENT);
		randomFile.writeInt(recordCount);		
		randomFile.writeLong(segVer);		
	}
	
	public boolean isFileExists(long segmentId) {
		if (this.segmentId == segmentId &&  this.myFile != null && myFile.exists()) {
			return true;
		} else {
			return false;
		}			
	}	
}
