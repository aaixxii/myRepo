package jp.co.nec.aim.mm.identify.planner;

import java.util.Comparator;

/**
 * 
 * @author xiazp
 *
 */
public class JobInfoFromDBComparator implements Comparator<JobInfoFromDB> {
	@Override
	public int compare(JobInfoFromDB o1, JobInfoFromDB o2) {
		int first = o1.getTopJobId().compareTo(o2.getTopJobId());
		int second = o1.getFunctionId().compareTo(o2.getFunctionId());
		int third = o1.getContainerId().compareTo(o2.getContainerId());
		int fourth = o1.getContainerJobId().compareTo(o2.getContainerJobId());
		return (first != 0 ? first : (second != 0 ? second
				: (third != 0 ? third : fourth)));
	}
}
