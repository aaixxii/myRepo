package jp.co.nec.aim.mm.scheduler;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.util.TimeHelper;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class PurgeJobQueueSchedulable extends AbstractJob {

	private static final Logger log = LoggerFactory
			.getLogger(PurgeJobQueueSchedulable.class);

	private static final String TITLE = "Purge Job queue";

	@Override
	public void executeJob(JobExecutionContext context)
			throws JobExecutionException {
		if (log.isDebugEnabled()) {
			log.debug("PurgeJobQueueSchedulable start...");
		}
		TimeHelper timeHelper = new TimeHelper(TITLE);
		timeHelper.t();
		try {
			pollBean.purgeJobQueueByResultTs();
		} catch (RuntimeException e) {
			String message = "Exception during " + TITLE;
			log.error(message, e);
			AimError error = AimError.SCHEDULABLE_ERROR;
			ExceptionSender exceptionSender = new ExceptionSender();
			exceptionSender.sendAimException(error.getErrorCode(),
					String.format(error.getMessage(), e.getMessage()), e);
		}
		timeHelper.t();
		if (log.isDebugEnabled()) {
			log.debug(timeHelper.message());
			log.debug("PurgeJobQueueSchedulable end...");
		}
	}

	@Override
	protected String getTitle() {
		return TITLE;
	}
}
