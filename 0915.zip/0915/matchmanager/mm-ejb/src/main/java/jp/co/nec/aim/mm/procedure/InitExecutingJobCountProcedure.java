package jp.co.nec.aim.mm.procedure;

import javax.sql.DataSource;

import org.springframework.jdbc.object.StoredProcedure;

public class InitExecutingJobCountProcedure extends StoredProcedure {

	private static final String SQL = "init_executing_job_count";

	public InitExecutingJobCountProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		compile();
	}

	public void execute() {
		super.execute();
	}
}
