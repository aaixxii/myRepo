package com.nec.aim.audio.service;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class FileUtil {
	private static Logger logger = LoggerFactory.getLogger(FileUtil.class);

	public FileUtil() {
	}

	public byte[] getDataFromFile(String templateFileName) {
		File templateFile = new File(templateFileName);
		if (!templateFile.exists() || !templateFile.isFile()) {
			logger.error("The template file is wrong. skip process...");
			return null;
		}
		FileInputStream input = null;
		byte[] temp = null;
		try {
			input = new FileInputStream(templateFile);
			temp = new byte[input.available()];
			input.read(temp);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			templateFile = null;
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return temp;
	}

	public List<String> readStringDataByJava8(String fullPath) throws IOException {
		String os = System.getProperty("os.name").toLowerCase();
		if (os.indexOf("windows") >= 0 && fullPath.startsWith("/")) {
			fullPath = fullPath.substring(1, fullPath.length());
		}
		return Files.lines(Paths.get(fullPath)).collect(Collectors.toList());
	}

	public String readStringFromDat(String fullPath) throws IOException {
		File file = new File(fullPath);
		BufferedReader br = new BufferedReader(new FileReader(file));
		StringBuffer fileContents = new StringBuffer();
		String line = br.readLine();
		while (line != null) {
			fileContents.append(line);
			line = br.readLine();
		}
		br.close();
		return fileContents.toString();
	}

	public List<byte[]> readMuiltByteData(String fullPath) throws IOException {
		List<byte[]> results = new ArrayList<>();
		String pathString = readStringFromDat(fullPath);
		int idx = pathString.indexOf("=");
		pathString = pathString.substring(idx + 1, pathString.length());
		String[] stringArry = pathString.split(";");
		for (String one : stringArry) {
			byte[] tmp = getDataFromFile(one);
			results.add(tmp);
		}
		return results;
	}
	
	public void saveImageToFile(String imageFormat, byte[] toBeSaveImage, String fileNameNoextension) {
		try {
			InputStream in = new ByteArrayInputStream(toBeSaveImage);
			BufferedImage bImageFromConvert = ImageIO.read(in);
			ImageIO.write(bImageFromConvert, imageFormat, new File(fileNameNoextension + "." + imageFormat));									
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
	
	public byte[] readImageFromFile(String imageFormat, String imageFullName)  {
		ByteArrayOutputStream baos = null;
		try {
			BufferedImage originalImage = ImageIO.read(new File(imageFullName));
			baos = new ByteArrayOutputStream();
			ImageIO.write( originalImage, imageFormat, baos );
			baos.flush();
			byte[] imageInByte = baos.toByteArray();
			originalImage = null;
			return imageInByte;
		} catch (Exception e) {
			return null;
		} finally {
			try {
				baos.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);				
			}
		}
	}
	
	public void saveStringToFile(String savecontent, String savePath)  {	
		File file = new File(savePath);
		try (FileOutputStream fop = new FileOutputStream(file)) {			
			if (!file.exists()) {
				file.createNewFile();
			}			
			byte[] contentInBytes = savecontent.getBytes();

			fop.write(contentInBytes);
			fop.flush();
			fop.close();
			logger.info("Sucess save string to " + savePath);

		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}		
	}
	
	@SuppressWarnings("unused")
	private static void writeXmlDocumentToXmlFile(Document xmlDocument, String fileName) {
	
	    TransformerFactory tf = TransformerFactory.newInstance();
	    javax.xml.transform.Transformer transformer;
	    try {
	        transformer = tf.newTransformer();	
	        FileOutputStream outStream = new FileOutputStream(new File(fileName)); 	 
	        transformer.transform(new DOMSource(), new StreamResult(outStream));
	    } 
	    catch (TransformerException e) 
	    {
	        e.printStackTrace();
	    }
	    catch (Exception e) 
	    {
	        e.printStackTrace();
	    }
	}
	
    @SuppressWarnings("unused")
	private static Document convertStringToXMLDocument(String xmlString)
    {
        //Parser that produces DOM object trees from XML content
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         
        //API to obtain DOM Document instance
        DocumentBuilder builder = null;
        try
        {
            //Create DocumentBuilder with default configuration
            builder = factory.newDocumentBuilder();
             
            //Parse the content to Document object
            Document doc = (Document) builder.parse(new InputSource(new StringReader(xmlString)));
            return doc;
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    
    @SuppressWarnings("unused")
	private static Document convertXMLFileToXMLDocument(String filePath) 
    {
        //Parser that produces DOM object trees from XML content
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
         
        //API to obtain DOM Document instance
        DocumentBuilder builder = null;
        try
        {
            //Create DocumentBuilder with default configuration
            builder = factory.newDocumentBuilder();
             
            //Parse the content to Document object
            Document doc = (Document) builder.parse(new File(filePath));
            return doc;
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        return null;
    }
    public static void stringToDom(String xmlSource) 
            throws IOException {
        java.io.FileWriter fw = new java.io.FileWriter("my-file.xml");
        fw.write(xmlSource);
        fw.close();
    }
    
    public static void stringToDom2(String xmlSource) 
            throws SAXException, ParserConfigurationException, IOException, TransformerException {
        // Parse the given input
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new InputSource(new StringReader(xmlSource)));

        // Write the parsed document to an xml file
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        javax.xml.transform.Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);

        StreamResult result =  new StreamResult(new File("my-file.xml"));
        transformer.transform(source, result);
    }
}


