package jp.co.nec.lsm.event.identify.notifier;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Queue;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.command.ActiveMQQueue;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.identify.BatchJobDeliveryCheckPollBeanEvent;
import jp.co.nec.lsm.event.identify.GetBatchJobPollTimerEvent;
import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;
import jp.co.nec.lsm.event.identify.IdentifyBatchJobResultEvent;
import jp.co.nec.lsm.event.identify.IdentifyMergerJobDoneEvent;
import jp.co.nec.lsm.event.identify.IdentifyPrepareTemplateEvent;
import jp.co.nec.lsm.event.identify.IdentifySegmentJobPreparedEvent;
import jp.co.nec.lsm.event.identify.IdentifyStartHeartbeatTimerEvent;
import jp.co.nec.lsm.event.identify.IdentifyStartJobPollbeanTimerEvent;
import jp.co.nec.lsm.event.identify.IdentifyStartUSCPollbeanTimerEvent;
import jp.co.nec.lsm.event.identify.IdentifySyncSegmentJobDoneEvent;
import jp.co.nec.lsm.event.identify.IdentifyTemplatePreparedEvent;
import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import junit.framework.Assert;
import mockit.Mock;
import mockit.MockUp;

public class IdentifyNotifierTest {

	private ConnectionFactory jmsFactory;
	private Queue queueDestination;

	private Event receivedEvent;
	private boolean isNotReceived = true;
	private int rerunLimit = 50;
	long batchJobId = 12122L;

	static BrokerService broker = new BrokerService();

	@BeforeClass
	public static void startService() throws Exception {
		broker.setBrokerName("one");
		broker.setPersistent(false);
		broker.start();
	}

	@AfterClass
	public static void stopService() throws Exception {
		broker.stop();
	}

	@Before
	public void init() {
		receivedEvent = null;
	}

	/**
	 * setMockMethod
	 */
	public void setJMSMockMethod(final String jndiQueueName) {
		new MockUp<ServiceLocator>() {
			@Mock
			private Object lookUpJndiObject(String jndiName) {
				if (jndiName.equals(JNDIConstants.JmsFactory)) {
					return jmsFactory;
				} else if (jndiName.equals(jndiQueueName)) {
					return queueDestination;
				}
				return null;
			}

			@Mock
			private Object lookUpJndiObjectReomte(String jndiName, String ip) {
				if (jndiName.equals(JNDIConstants.JmsFactory)) {
					return jmsFactory;
				} else if (jndiName.equals(jndiQueueName)) {
					return queueDestination;
				}
				return null;
			}
		};
	}

	@Test
	public void testSendEvent_Heartbeat_TMA() throws Exception {
		setJMSMockMethod("queue/aggregation_queue_event");

		DefaultMessageListenerContainer listener = null;

		try {
			listener = startServiceAndListener("aggregation_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notifier = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyStartHeartbeatTimerEvent(
							10000,
							IdentifyNotifierEnum.SystemInitializationBean,
							IdentifyReceiverEnum.AggregationHeartbeatStarterBean);
					notifier.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(null,
					IdentifyReceiverEnum.AggregationHeartbeatStarterBean.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testSendEvent_Heartbeat_TMI() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");

		DefaultMessageListenerContainer listener = null;

		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notifier = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyStartHeartbeatTimerEvent(
							10000,
							IdentifyNotifierEnum.SystemInitializationBean,
							IdentifyReceiverEnum.IdentifyHeartbeatStarterBean);
					notifier.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(null,
					IdentifyReceiverEnum.IdentifyHeartbeatStarterBean.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testSendPrepareTemplateEvent() throws Exception {
		setJMSMockMethod("queue/identify_prepare_template_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_prepare_template_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							12122L, IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyPrepareTemplateService);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();
			assertResult(12122L,
					IdentifyReceiverEnum.IdentifyPrepareTemplateService.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}

		}
	}

	@Test
	public void testSendSyncWithAggregationEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifySyncSegmentJobDoneEvent event = new IdentifySyncSegmentJobDoneEvent(
							1213222L,
							IdentifyNotifierEnum.IdentifyBatchJobResultService,
							IdentifyReceiverEnum.IdentifySyncWithAggregationServiceBean);
					event.setIpAddress("192.168.100.88");
					event.setBatchSegmentJobMap(null);
					event.getTraceMessage();
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(1213222L,
					IdentifyReceiverEnum.IdentifySyncWithAggregationServiceBean
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testSendBatchJobResultEvent() throws Exception {
		setJMSMockMethod("queue/aggregation_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("aggregation_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyBatchJobResultEvent event = new IdentifyBatchJobResultEvent(
							12132223L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyBatchJobResultService);
					event.setBatchSegmentJobMap(null);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(12132223L,
					IdentifyReceiverEnum.IdentifyBatchJobResultService.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testJobPollTimerEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyStartJobPollbeanTimerEvent(
							12132225L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyJobPollTimerStartBean);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(12132225L,
					IdentifyReceiverEnum.IdentifyJobPollTimerStartBean.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testUSCPollTimerEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");

		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyStartUSCPollbeanTimerEvent(
							12132226L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyUSCPollTimerStartBean);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(12132226L,
					IdentifyReceiverEnum.IdentifyUSCPollTimerStartBean.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testDeliveryCheckEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new BatchJobDeliveryCheckPollBeanEvent(
							12132227L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.BatchJobDeliveryCheckPollTimerStarterBean);
					notify.sendEvent(event);
				}
			});
			thread.start();
			thread.join();
			assertResult(
					12132227L,
					IdentifyReceiverEnum.BatchJobDeliveryCheckPollTimerStarterBean
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testGetIdentifyBatchJobEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new GetBatchJobPollTimerEvent(
							12132228L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.GetIdentifyBatchJobPollTimerStarterBean);
					notify.sendEvent(event);
				}
			});
			thread.start();
			thread.join();
			assertResult(
					12132228L,
					IdentifyReceiverEnum.GetIdentifyBatchJobPollTimerStarterBean
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testPrepareSegmentJobEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifySegmentJobPreparedEvent event = new IdentifySegmentJobPreparedEvent(
							12132229L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyPrepareSegmentJobService);
					event.setBatchSegmentJobMap(null);
					notify.sendEvent(event);
				}
			});
			thread.start();
			thread.join();
			assertResult(12132229L,
					IdentifyReceiverEnum.IdentifyPrepareSegmentJobService
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testSendMergerJobDoneEvent() throws Exception {
		setJMSMockMethod("queue/aggregation_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("aggregation_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notifier = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyMergerJobDoneEvent(
							batchJobId,
							IdentifyNotifierEnum.IdentifyTmaPollbeanService,
							IdentifyReceiverEnum.IdentifyBatchJobResultService);
					notifier.sendEvent(event);
				}
			});

			thread.start();
			thread.join();
			assertResult(12122L,
					IdentifyReceiverEnum.IdentifyBatchJobResultService.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}

		}
	}

	@Test
	public void testSendTemplatePreparedEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				public void run() {
					IdentifyNotifier notifier = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyTemplatePreparedEvent(
							batchJobId,
							IdentifyNotifierEnum.IdentifyPrepareTemplateService,
							IdentifyReceiverEnum.IdentifyPrepareSegmentJobService);
					notifier.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(batchJobId,
					IdentifyReceiverEnum.IdentifyPrepareSegmentJobService
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	/**
	 * startServiceAndListener
	 * 
	 * @throws Exception
	 */
	private DefaultMessageListenerContainer startServiceAndListener(
			String queueName) throws Exception {

		jmsFactory = new ActiveMQConnectionFactory(
				"vm://localhost?broker.persistent=false");
		queueDestination = new ActiveMQQueue(queueName);
		final SingleConnectionFactory singleConnectionFactory1 = new SingleConnectionFactory(
				jmsFactory);

		DefaultMessageListenerContainer listener = new DefaultMessageListenerContainer();
		listener.setConnectionFactory(singleConnectionFactory1);
		listener.setDestination(queueDestination);

		listener.setMessageListener(new MessageListener() {
			public void onMessage(Message message) {
				if (message instanceof ObjectMessage) {
					ObjectMessage objMsg = (ObjectMessage) message;
					try {
						receivedEvent = (Event) objMsg.getObject();
					} catch (JMSException e) {
					}
				}
				isNotReceived = false;
			}
		});
		listener.afterPropertiesSet();
		listener.start();
		Thread.sleep(1000);
		return listener;
	}

	/**
	 * asserts
	 */
	private void assertResult(Long batchJobId, String seletorName) {
		int run = 0;
		while (isNotReceived && run++ <= rerunLimit) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (run > rerunLimit) {
			Assert.fail();
		}

		if (receivedEvent == null) {
			Assert.fail();
		}
		if (batchJobId != null) {
			Long receivedBatchJobId = receivedEvent.getBatchJobId();
			Assert.assertEquals(batchJobId, receivedBatchJobId);
		}

		String messageSeletor = receivedEvent.getMessageSelector();
		Assert.assertEquals(messageSeletor, seletorName);
	}
}
