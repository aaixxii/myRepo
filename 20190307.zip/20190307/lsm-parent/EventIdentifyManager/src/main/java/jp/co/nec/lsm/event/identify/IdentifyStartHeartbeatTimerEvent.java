package jp.co.nec.lsm.event.identify;

import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;

public class IdentifyStartHeartbeatTimerEvent extends IdentifyAbstractEvent {
	private static final long serialVersionUID = 1L;
	private int pollDuraton;
	public IdentifyStartHeartbeatTimerEvent(int pollDuraton,
			IdentifyNotifierEnum identifyNotifier,
			IdentifyReceiverEnum identifyReceiver) {
		this.pollDuraton=pollDuraton;
		setIdentifyNotifier(identifyNotifier);
		setIdentifyReceiver(identifyReceiver);
	}
	
	public int getPollDuraton()
	{
		return pollDuraton;
	}
}
