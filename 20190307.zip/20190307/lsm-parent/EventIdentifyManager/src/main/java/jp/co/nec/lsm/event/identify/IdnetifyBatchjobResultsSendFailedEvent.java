package jp.co.nec.lsm.event.identify;

import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;


public class IdnetifyBatchjobResultsSendFailedEvent  extends IdentifyAbstractEvent {	
	private static final long serialVersionUID = -7326066881120174314L;
	
	public IdnetifyBatchjobResultsSendFailedEvent(long batchJobId,
			IdentifyNotifierEnum identifyNotifier,
			IdentifyReceiverEnum identifyReceiver) {
		setBatchJobId(batchJobId);
		setIdentifyNotifier(identifyNotifier);
		setIdentifyReceiver(identifyReceiver);
	}

}
