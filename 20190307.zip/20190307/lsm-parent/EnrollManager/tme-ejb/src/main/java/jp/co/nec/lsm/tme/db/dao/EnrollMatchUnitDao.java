package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.util.MUUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MatchUnitHelper;

/**
 * @author liuj <br>
 * 
 */

public class EnrollMatchUnitDao  {
	
	private EntityManager manager;	
	private MatchUnitHelper muHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollMatchUnitDao.class);


	/**
	 * constructor
	 */
	public EnrollMatchUnitDao(EntityManager manager) {
		this.manager = manager;
		muHelper = new MatchUnitHelper(manager);
		printLogMessage("EnrollMatchUnitDao init");
	}

	/**
	 * find EnrollTMEUnitEntity by match unit Id
	 * 
	 * @param uniqueId
	 *            match unit Id
	 * @return EnrollTMEUnitEntity
	 */	
	public MatchUnitEntity search(String uniqueId) {

		if (uniqueId == null || uniqueId.isEmpty()) {
			log.warn("uniqueId is null or empty.");
			return null;
		}

		MatchUnitEntity enrollTMEUnit = muHelper.search(uniqueId);

		return enrollTMEUnit;
	}

	/**
	 * update EnrollTMEUnitEntity information
	 * 
	 * @param mu
	 *            EnrollTMEUnitEntity
	 * @param type
	 *            match unit type
	 * @param url
	 *            match unit url
	 * @param version
	 *            match unit version
	 * @return EnrollTMEUnitEntity
	 */	
	public void update(MatchUnitEntity enrollTMEUnit, ComponentType type,
			String url, Long ramSpace, Long diskSpace, Float performanceFactor,
			Integer numCPUs, String version) {
		if (enrollTMEUnit == null || type == null || url == null
				|| url.isEmpty()) {
			log.warn("one of parameters is null or empty.");
			return;
		}
		muHelper.update(enrollTMEUnit, type, url, DateUtil.getCurrentDate(),
				ramSpace, diskSpace, numCPUs, version, performanceFactor);
		manager.flush();
	}

	/**
	 * 
	 * @param type
	 * @param uniqueId
	 * @param url
	 * @param ramSpace
	 * @param diskSpace
	 * @param performanceFactor
	 * @param numCPUs
	 * @param now
	 * @param version
	 * @return
	 */	
	public MatchUnitEntity add(ComponentType type, String uniqueId, String url,
			Long ramSpace, Long diskSpace, Float performanceFactor,
			Integer numCPUs, String version) {
		if (uniqueId == null || uniqueId.isEmpty() || type == null
				|| url == null || url.isEmpty()) {
			log.warn("one of parameters is null or empty.");
			return null;
		}
		MatchUnitEntity mu = muHelper.add(type, uniqueId, url, ramSpace,
				diskSpace, performanceFactor, numCPUs,
				DateUtil.getCurrentDate(), version);
		manager.flush();
		return mu;
	}

	/**
	 * 
	 * @param muId
	 * @return
	 */	
	public MatchUnitEntity findAndWarnState(long muId) {

		MatchUnitEntity mu = muHelper.findAndWarnState(muId);

		return mu;
	}

	/**
	 * 
	 * @param muId
	 * @return
	 */	
	public boolean isWorkingUnitExist(long unitId) {
		MatchUnitEntity unit = muHelper.findAndWarnState(unitId);
		if (unit == null) {
			log.warn(
					"unit id:{} is not found in match_unit, need to re enter ",
					unitId);
			return false;
		} else {
			if (!MUUtil.isWorkingState(unit.getState())) {
				log.warn(
						"unit id: {}  expected to be in state WORKING, instead was in {}",
						unitId, unit.getState());
				return false;

			}
		}
		return true;
	}

	/**
	 * 
	 * @param mu
	 *            EnrollTMEUnitEntity
	 */	
	public void mergeEnrollTMEUnitEntity(MatchUnitEntity enrollTMEUnit) {
		printLogMessage("start public function merge..");

		if (enrollTMEUnit == null) {
			log.warn("EnrollTMEUnitEntity mu is null.");
			return;
		}

		manager.merge(enrollTMEUnit);
		manager.flush();
		printLogMessage("end public function merge..");

	}

	/**
	 * get Match Units By Type And State from MUTCH_UNITS
	 * 
	 * @param type
	 *            Match Unit Type
	 * @param state
	 *            Match Unit State
	 * @return list of EnrollTMEUnitEntity
	 */	
	public List<MatchUnitEntity> getMatchUnitsByTypeAndState(
			ComponentType type, MUState state) {
		printLogMessage("start public function getMatchUnitsByTypeAndState()..");

		if (type == null || state == null) {
			log.warn("one of param is null.");
			return null;
		}

		// get Match Units By Type And State from MUTCH_UNITS
		List<MatchUnitEntity> dmList = muHelper.getMatchUnitsByTypeAndState(
				type, state);

		printLogMessage("end public function getMatchUnitsByTypeAndState()..");
		return dmList;
	}
	
	public List<MatchUnitEntity> findAllMUUnit(ComponentType type) {
		return muHelper.findMuByType(type);
	}

	/**
	 * update MatchUnits state
	 * 
	 * @param em
	 * @param oldState
	 * @param newState
	 */	
	public void updateMatchUnits(MUState oldState, MUState newState) {
		if (oldState == null || newState == null) {
			log.warn("one of param is null.");
			return;
		}
		muHelper.updateMatchUnits(oldState, newState);

	}

	/**
	 * get list of Timed Out EnrollTMEUnitEntity From Report time
	 * 
	 * @param minStart
	 * @return list of EnrollTMEUnitEntity
	 */	
	public List<MatchUnitEntity> getTimedOutUtilsFromReport(Date minStart) {
		printLogMessage("start public function getTimedOutUtilsFromReport()..");
		if (minStart == null) {
			log.warn("param minStart is null.");
			return null;
		}
		List<MatchUnitEntity> deadMUs = muHelper
				.getTimedOutUtilsFromReport(minStart);

		printLogMessage("start public function getTimedOutUtilsFromReport()..");

		return deadMUs;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
