package jp.co.nec.lsm.tme.service.sessionbean;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.proto.control.EnterResponseProto.EnterResponse;
import jp.co.nec.lsm.proto.segment.ReportStateRequestProto.ReportStateRequest;
import jp.co.nec.lsm.proto.segment.ReportStateResponseProto.ReportStateResponse;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.constants.ReportResponseReturnStatus;
import jp.co.nec.lsm.tm.common.core.jobs.ReportResponseReturn;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.common.constants.ExtractJobFailedReason;
import jp.co.nec.lsm.tme.core.jobs.EnrollExtractJobFailManager;
import jp.co.nec.lsm.tme.db.dao.EnrollContactTimesSPDao;
import jp.co.nec.lsm.tme.db.dao.EnrollMatchUnitDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;

/**
 * @author liuj The class used to manage the working state of the MU.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollStatusManagerBean  {
	
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	
	private EnrollMatchUnitDao enrollMatchUnitDao;
	
	private EnrollSystemConfigDao systemConfigDao;
	
	private EnrollContactTimesSPDao contactTimesSPDao;

	private static final Logger log = LoggerFactory
			.getLogger(EnrollStatusManagerBean.class);

	/**
	 * constructor
	 */
	public EnrollStatusManagerBean() {
	}
	
	@PostConstruct
	public void init() {
		systemConfigDao = new EnrollSystemConfigDao(entityManager, dataSource);
		enrollMatchUnitDao = new EnrollMatchUnitDao(entityManager);
		contactTimesSPDao = new EnrollContactTimesSPDao(entityManager);
	}

	/***
	 * The method of handling MU to enter. 1.Check MU is existed. 2.If present,
	 * update MU, if does not exist, increase MU. 3.Return EnterResponse.
	 */
	public EnterResponse enter(EnterRequest enterRequest) {
		if (enterRequest == null) {
			throw new IllegalArgumentException("EnterRequest can not be null.");
		}

		printLogMessage("Received enter() from unique id {}, at URL {}",
				enterRequest.getUniqueId(), enterRequest.getContactURL());

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		ComponentType type = enterRequest.getType();

		// what kind of entity is entering?
		if (enterRequest.getType() != ComponentType.MFE) {
			throw new IllegalArgumentException(
					"Some kind of resource report must be specified.");
		}

		MatchUnitEntity mu = enrollMatchUnitDao.search(enterRequest
				.getUniqueId());

		if (mu != null) {
			if (mu.getState() == MUState.WORKING) {
				Date now = DateUtil.getCurrentDate();
				// get MAX_EXTRACT_JOB_FAILURES Property
				Integer maxExtractFailure = systemConfigDao
						.getMaxExtractjobFailure();

				EnrollExtractJobFailManager failManager = new EnrollExtractJobFailManager();
				failManager.checkExtractJobByMFEId(mu.getId(),
						maxExtractFailure, now,
						ExtractJobFailedReason.MFE_REENTER);
			}

			enrollMatchUnitDao.update(mu, type, enterRequest.getContactURL(),
					enterRequest.getPrimarySize(), enterRequest
							.getSecondarySize(),
					EnrollConstants.DEFAULT_PERFORMANCE_FACTOR, enterRequest
							.getNumberOfCpus(), enterRequest.getVersion());
		} else {
			mu = enrollMatchUnitDao.add(type, enterRequest.getUniqueId(),
					enterRequest.getContactURL(),
					enterRequest.getPrimarySize(), enterRequest
							.getSecondarySize(),
					EnrollConstants.DEFAULT_PERFORMANCE_FACTOR, enterRequest
							.getNumberOfCpus(), enterRequest.getVersion());
		}

		EnterResponse enterResponse = createEnterResponse((int) mu.getId());

		log.info(InfoLogger.statusInfoOutput(ComponentType.MFE.name(),
				LogConstants.EVENT_ENTER));

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_STATUS_MANAGER_BEAN,
				LogConstants.FUNCTION_ENTER_TME, stopWatch.getTime());
		printLogMessage("Returning from enter() for {} giving unit ID: {}", mu
				.getId(), enterRequest.getUniqueId());

		return enterResponse;
	}

	/**
	 * 
	 * @param gmvId
	 * @return
	 */
	private EnterResponse createEnterResponse(int gmvId) {
		EnterResponse.Builder enterResponse = EnterResponse.newBuilder();
		enterResponse.setGmvId(gmvId);
		return enterResponse.build();
	}

	/***
	 * The method of handling MU to exit. 1.Check MU is existed. 2.Check the
	 * types of MU for MATCH_UNIT. 3.Loop to do extract job exit check. 4.Update
	 * job state. 5.Update MU state.
	 */
	public void exit(long muId) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		printLogMessage("received exit request from unit: {}", muId);

		MatchUnitEntity mu = enrollMatchUnitDao.findAndWarnState(muId);
		if (mu != null) {
			mu.setState(MUState.EXITED);

			// type must be match unit
			if (mu.getType() == ComponentType.MFE) {

				// get MAX_EXTRACT_JOB_FAILURES Property
				Integer maxExtractFailure = systemConfigDao
						.getMaxExtractjobFailure();
				Date now = DateUtil.getCurrentDate();

				EnrollExtractJobFailManager failManager = new EnrollExtractJobFailManager();

				failManager
						.checkExtractJobByMFEId(mu.getId(), maxExtractFailure,
								now, ExtractJobFailedReason.MFE_EXIT);

			}
			enrollMatchUnitDao.mergeEnrollTMEUnitEntity(mu);
		}

		log.info(InfoLogger.statusInfoOutput(ComponentType.MFE.name(),
				LogConstants.EVENT_EXIT));

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_STATUS_MANAGER_BEAN,
				LogConstants.FUNCTION_EXIT_TME, stopWatch.getTime());
	}

	/**
	 * 
	 */
	public ReportResponseReturn reportState(
			ReportStateRequest reportStateRequest) {
		if (reportStateRequest == null) {
			throw new IllegalArgumentException(
					"ReportStateRequest can not be null.");
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		printLogMessage("Received heartbeat from muId ", reportStateRequest
				.getGmvId());

		long muId = reportStateRequest.getGmvId();
		// check unitId in match unit table
		if (!enrollMatchUnitDao.isWorkingUnitExist(muId)) {
			return new ReportResponseReturn(
					ReportResponseReturnStatus.REPORT_UNIT_STATUS_UNNORMAL,
					null);
		}

		printLogMessage("MFE(muId = {}) report state.", muId);
		// update mu_contacttimes.
		contactTimesSPDao.updateContactTimes(muId, true, true);

		// ReportStateResponse Create.
		ReportStateResponse reportStateResponse = createReportStateResponse(reportStateRequest
				.getGmvId());

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_STATUS_MANAGER_BEAN,
				LogConstants.FUNCTION_REPORT_STATE_TME, stopWatch.getTime());
		ReportResponseReturn reportResponseReturn = new ReportResponseReturn(
				ReportResponseReturnStatus.REPORT_NORMAL_RETURNED,
				reportStateResponse);
		return reportResponseReturn;
	}

	/**
	 * 
	 * @param gmvId
	 * @return
	 */
	private ReportStateResponse createReportStateResponse(int gmvId) {
		ReportStateResponse.Builder reportStateResponse = ReportStateResponse
				.newBuilder();
		reportStateResponse.setGmvId(gmvId);
		return reportStateResponse.build();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
