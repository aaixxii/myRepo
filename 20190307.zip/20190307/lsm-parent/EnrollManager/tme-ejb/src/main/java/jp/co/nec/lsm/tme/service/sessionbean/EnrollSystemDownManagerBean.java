package jp.co.nec.lsm.tme.service.sessionbean;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.db.dao.EnrollTransactionManagerDao;

/**
 * @author liuj
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollSystemDownManagerBean {		

	private static final Logger log = LoggerFactory
			.getLogger(EnrollSystemDownManagerBean.class);
	
	private EnrollTransactionManagerDao transactionManagerDao;
	
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	protected DataSource dataSource;
	

	/**
	 * constructor
	 */
	public EnrollSystemDownManagerBean() {
	}
	
	@PostConstruct
	public void init() {
		transactionManagerDao = new EnrollTransactionManagerDao(manager);		
	}

	/**
	 * TME shutdown process.
	 */
	public void shutdown() {
		printLogMessage("start public function shutdown.");

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_SYSTEM_DOWN_MANAGER,
					LogConstants.FUNCTION_SHUT_DOWN, "DETAIL",
					"called in EnrollSystemDownManager"));
		}

		// change TME Status To Exit
		transactionManagerDao.changeTMEToExit();

		EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
				.getInstance();
		batchJobGetterTimer.setStop(true);

		// interrupt the batch job getter sleep thread.
		Thread sleepThread = batchJobGetterTimer.getSleepThread();
		if (sleepThread != null) {
			if (log.isInfoEnabled()) {
				log.info("interrupt the batch job getter sleep thread. "
						+ "thread Id: {}", sleepThread.getId());
			}
			sleepThread.interrupt();
		}

		printLogMessage("end public function shutdown.");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
