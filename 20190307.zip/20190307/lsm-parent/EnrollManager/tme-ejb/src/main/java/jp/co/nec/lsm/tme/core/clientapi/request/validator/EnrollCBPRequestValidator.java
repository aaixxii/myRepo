package jp.co.nec.lsm.tme.core.clientapi.request.validator;

import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.common.constants.RequestSpecConstants;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tme.exception.EmptyRequestIDException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBiometricsData;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

public class EnrollCBPRequestValidator {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollCBPRequestValidator.class);

	/**
	 * 
	 * @return
	 */
	public static ValidationResult validate(long batchJobId, int jobIndex,
			CPBRequest request) {
		printLogMessage("start public function validateEctractJob().");
		ValidationResult result = new ValidationResult();
		ValidationResultError error = null;

		// check Request Id
		printLogMessage("check Request Id.");
		error = validateRequestIdCorrect(jobIndex, request.getRequestId(),
				batchJobId);
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		printLogMessage("check REQUESET TYPE.");
		error = validateE_REQUESET_TYPE(jobIndex, request.getRequestType(),
				batchJobId);
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		// check Reference Id
		printLogMessage("check Reference Id.");
		error = validateReferenceIdCorrect(jobIndex, request.getEnrollmentId(),
				batchJobId);
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}

		printLogMessage("check Biometrics Data.");
		error = validateBiometricsData(jobIndex, request.getBiometricsData(),
				batchJobId);
		if (error != null) {
			result.addErrorIfNeccessary(error);
			return result;
		}
		printLogMessage("end public function validateEctractJob().");
		return null;
	}

	/**
	 * 
	 * @param jobIndex
	 * @param biometricsData
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateBiometricsData(int jobIndex,
			CPBBiometricsData biometricsData, long batchJobId) {
		//
		if (biometricsData == null
				|| biometricsData.getBiometricElement() == null
				|| biometricsData.getBiometricElement().getFilePath().isEmpty()) {
			String errorInfo = "Enroll Job ( CPBRequest CPBBiometricsData is incorrect. )";
			log.error(errorInfo);
			return new ValidationResultError(false, jobIndex,
					EnrollErrorMessage.BIOMETRICSDATA_INCORRECT.getErrorCode(),
					errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param jobIndex
	 * @param type
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateE_REQUESET_TYPE(int jobIndex,
			E_REQUESET_TYPE type, long batchJobId) {
		if (type != E_REQUESET_TYPE.INSERT) {
			String errorInfo = "Enroll Job ( CPBRequest E_REQUESET_TYPE is incorrect. "
					+ " E_REQUESET_TYPE: " + type.name() + " ).";
			log.error(errorInfo);
			return new ValidationResultError(
					false,
					jobIndex,
					EnrollErrorMessage.E_REQUESET_TYPE_INCORRECT.getErrorCode(),
					errorInfo);
		}

		return null;
	}

	/**
	 * 
	 * @param requestId
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateRequestIdCorrect(int jobIndex,
			String requestId, long batchJobId) {
		if (requestId == null || requestId.isEmpty()) {
			String errorInfo = "Enroll Job ( One EnrollJobInfo doesn't"
					+ " have Request Id in EnrollRequest )";
			log.error(errorInfo);
			throw new EmptyRequestIDException(errorInfo);
		} else if (requestId.length() != RequestSpecConstants.REQUEST_ID_LENGTH) {
			String errorInfo = "Enroll Job ( Request Id:" + requestId
					+ " length:" + requestId.length() + " is incorrect. ) ";
			log.error(errorInfo);
			return new ValidationResultError(false, jobIndex,
					EnrollErrorMessage.INSERT_REQUESTID_LENGTH_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * 
	 * @param requestId
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateReferenceIdCorrect(
			int jobIndex, String referenceId, long batchJobId) {
		if (referenceId == null) {
			String errorInfo = "Enroll Job ( One EnrollJobInfo doesn't "
					+ "have Reference Id in EnrollRequest ) ";
			log.error(errorInfo);
			return new ValidationResultError(false, jobIndex,
					EnrollErrorMessage.INSERT_REFERENCEID_LENGTH_INCORRECT
							.getErrorCode(), errorInfo);
		} else if (referenceId.length() != RequestSpecConstants.REFERENCE_ID_LENGTH) {
			String errorInfo = "Enroll Job ( Reference Id:" + referenceId
					+ " length:" + referenceId.length() + " is incorrect. ) ";
			log.error(errorInfo);
			return new ValidationResultError(false, jobIndex,
					EnrollErrorMessage.INSERT_REFERENCEID_LENGTH_INCORRECT
							.getErrorCode(), errorInfo);
		}
		return null;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
