package jp.co.nec.lsm.tme.service.sessionbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;

import jp.co.nec.lsm.tm.common.constants.RequestSpecConstants;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.core.clientapi.request.validator.EnrollRequestValidator;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.db.dao.EnrollBatchJobQueueDao;
import jp.co.nec.lsm.tme.db.dao.EnrollJobQueueDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;
import jp.co.nec.lsm.tme.exception.DuplicateEnrollBatchJobException;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

/**
 * @author mozj <br>
 *         add the enroll request into local enroll queue.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollAcceptServiceBean  {
	
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	
	private EnrollBatchJobQueueDao batchJobQueueDao;
	
	private EnrollJobQueueDao jobQueueDao;
	
	private EnrollSystemConfigDao systemConfigDao;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollAcceptServiceBean.class);

	/**
	 * constructor
	 */
	public EnrollAcceptServiceBean() {

	}
	
	@PostConstruct
	public void init() {
		systemConfigDao = new EnrollSystemConfigDao(entityManager, dataSource);
		jobQueueDao = new EnrollJobQueueDao(entityManager, dataSource);
		batchJobQueueDao = new EnrollBatchJobQueueDao(entityManager);
	}


	/**
	 * add the enroll request into local enroll queue.
	 */	
	public void doAccept(Long batchJobId, BatchType batchType,
			List<CPBBusinessMessage> businessMessageList) {
		if (businessMessageList == null) {
			throw new IllegalArgumentException(
					"CPBBusinessMessage List can not be null.");
		}

		printLogMessage("start public function doAccept().");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.deliveryJobInfoOutput(
					LogConstants.DETAIL_ENROLL_DO_ACCEPT,
					LogConstants.KEY_BATCH_JOB_ID, batchJobId.toString()));
		}

		checkDuplication(batchJobId);

		// create Enroll Batch Job based Enroll Request from Transformer
		LocalEnrollBatchJob enrollBatchJob = LocalEnrollBatchJob
				.createEnrollBatchJob(batchJobId, batchType,
						businessMessageList, DateUtil.getCurrentDate());

		// add the enroll request into DB.
		acceptService(batchJobId, enrollBatchJob);

		enqueueRequest(enrollBatchJob);

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput("EnrollAcceptServiceBean",
					"doAccept", "DETAIL", "Add batchjob(batchId:"
							+ enrollBatchJob.getBatchJobId()
							+ ") with top level job count: "
							+ enrollBatchJob.getExtractJobCount()
							+ " into enroll local queue successfully"));
		}

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_ACCEPT_SERVICE_BEAN_TME,
				LogConstants.FUNCTION_ACCEPT_SERVICE_TME, stopWatch.getTime(),
				LogConstants.KEY_BATCH_JOB_ID, new Long(batchJobId).toString());

		printLogMessage("end public function doAccept()..");
	}

	private void checkDuplication(long batchJobId) {

		boolean isExist = batchJobQueueDao.checkBatchJobExist(batchJobId);
		if (isExist == false) {
			// get batch job by Batch Job Id
			EnrollBatchJobManager queueManage = EnrollBatchJobManager
					.getInstance();
			LocalEnrollBatchJob batchJob = queueManage
					.getEnrollBatchJobById(batchJobId);
			if (batchJob == null) {
				return;
			}
		}

		String message = "Enroll Job ( Batch Job: " + batchJobId
				+ " is already existence ).";
		log.error(message);
		throw new DuplicateEnrollBatchJobException(message);

	}

	/**
	 * 
	 * @param enrollBatchJob
	 */
	private void enqueueRequest(LocalEnrollBatchJob enrollBatchJob) {

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		// add the enroll request into local enroll queue
		queueManage.addEnrollBatchJob(enrollBatchJob);
	}

	/**
	 * check all data in enroll request whether there are correct, and add the
	 * enroll request into local enroll queue. And then persist batch job
	 * information into database
	 * 
	 * @param request
	 *            enroll request from Transformer
	 * @return 0 there are incorrect data in enroll request. 1 all data in
	 *         enroll request are correct.
	 */
	public void acceptService(Long batchJobId,
			LocalEnrollBatchJob enrollBatchJob) {
		printLogMessage("start public function AcceptService()..");

		if (enrollBatchJob == null) {
			throw new IllegalArgumentException(
					"LocalEnrollBatchJob can not be null.");
		}

		printLogMessage("create Enroll Batch Job: {} based Enroll Request",
				batchJobId);

		// Instance for persist EnrollBatchJobQueueEntity
		EnrollBatchJobQueueEntity batchJobEntity = new EnrollBatchJobQueueEntity();
		// prepare EnrollBatchJobQueueEntity for persist Enroll Batch Job
		prepareEnrollJobQueueEntity(batchJobId, batchJobEntity);

		// persist BatchJob to database
		batchJobQueueDao.persistBatchJob(batchJobEntity);

		// Instance for persist EnrollJobQueueEntity
		List<EnrollJobQueueEntity> enrollJobList = new ArrayList<EnrollJobQueueEntity>();

		// prepare EnrollJobQueueEntity List for persist Extract Jobs
		// Information
		prepareEnrollJobQueueEntity(enrollBatchJob, enrollJobList, batchJobId,
				EnrollConstants.EXTRACT_JOB_START_INDEX);

		// insert Extract Jobs Information into database
		jobQueueDao.insertExctractJobQueue(enrollJobList);

		// commit
		batchJobQueueDao.commit();

		printLogMessage("end public function AcceptService()..");
	}

	/**
	 * prepare EnrollBatchJobQueueEntity Instance for persist Enroll Batch Job
	 * Information
	 * 
	 * @param request
	 *            Enroll Request from transformer
	 * @param batchJobEntity
	 *            EnrollBatchJobQueueEntity Instance
	 */
	private void prepareEnrollJobQueueEntity(long batchJobId,
			EnrollBatchJobQueueEntity batchJobEntity) {
		printLogMessage("start private function prepareBatchJobQueueEntity()..");

		printLogMessage("prepare EnrollBatchJobQueueEntity Instance.");

		// prepare EnrollBatchJobQueueEntity Instance
		if (batchJobEntity != null) {
			batchJobEntity.setBatchjobId(batchJobId);
			batchJobEntity.setBatchjobStatus(EnrollBatchJobStatus.QUEUED
					.getIntValues());
			batchJobEntity.setEnqueueTs(DateUtil.getCurrentDate());
		}

		printLogMessage("end private function prepareBatchJobQueueEntity()..");
	}

	/**
	 * prepare EnrollJobQueueEntity List for persist Extract Jobs Information
	 * 
	 * @param request
	 *            Enroll Request from transformer
	 * @param enrollJobList
	 *            EnrollJobQueueEntity List Instance
	 * @param jobIndex
	 *            Extract job Index
	 */
	private void prepareEnrollJobQueueEntity(
			LocalEnrollBatchJob enrollBatchJob,
			List<EnrollJobQueueEntity> enrollJobList, long batchJobId,
			int jobIndex) {
		printLogMessage("start private function prepareEnrollJobQueueEntity()..");

		printLogMessage("loop to prepare EnrollJobQueueEntity Instance List.");
		// prepare EnrollJobQueueEntity Instance List

		for (int i = 0; i < enrollBatchJob.getExtractJobCount(); i++) {
			LocalExtractJobInfo extractJobInfo = enrollBatchJob
					.getExtractJobInfo(jobIndex);
			CPBBusinessMessage businessMessage = extractJobInfo.getRequest();
			CPBRequest request = businessMessage.getRequest();

			// create new EnrollJobQueueEntity Instance.
			EnrollJobQueueEntity jobEntity = new EnrollJobQueueEntity();
			jobEntity.setBatchJobId(batchJobId);
			jobEntity.setJobIndex(jobIndex);

			String referenceId = request.getEnrollmentId();
			if (referenceId.length() > RequestSpecConstants.REFERENCE_ID_LENGTH) {
				jobEntity.setReferenceId(referenceId.substring(0,
						RequestSpecConstants.REFERENCE_ID_LENGTH));
			} else {
				jobEntity.setReferenceId(referenceId);
			}

			String requestId = request.getRequestId();
			if (requestId.length() > RequestSpecConstants.REQUEST_ID_LENGTH) {
				jobEntity.setRequestId(requestId.substring(0,
						RequestSpecConstants.REQUEST_ID_LENGTH));
			} else {
				jobEntity.setRequestId(requestId);
			}

			jobEntity.setReturnCode(extractJobInfo.getReturnCode());
			jobEntity.setRequest(businessMessage.toByteArray());
			jobEntity.setErrorCode(extractJobInfo.getErrorCode());
			jobEntity.setReSendable(extractJobInfo.isReSendable());
			jobEntity.setErrorMessage(extractJobInfo.getErrorMessage());

			// add EnrollJobQueueEntity into List
			enrollJobList.add(jobEntity);

			jobIndex++;
		}

		printLogMessage("end private function prepareEnrollJobQueueEntity()..");
	}

	/**
	 * validate all data in enroll request whether there are correct.
	 * 
	 * @param request
	 *            enroll request from Transformer
	 * @return false: there are incorrect data in enroll request. true: all data
	 *         in enroll request are correct.
	 */
	public void validateRequest(EnrollRequest enrollRequest,
			List<CPBBusinessMessage> businessMessageList) {
		printLogMessage("start private function validateRequest().");

		int maxTopLevelJob = Integer.parseInt(systemConfigDao
				.getJobCountToTransformer());

		ValidationResult validationResult = EnrollRequestValidator.validate(
				enrollRequest, businessMessageList, maxTopLevelJob);
		if (validationResult.hasErrors()) {
			String massege = "EnrollRequest has some errors:"
					+ validationResult.getRequestError().get(0)
							.getInvalidReason();
			log.error(massege);
			throw new EnrollRuntimeException(massege);
		}

		// all data in enroll request are correct.
		printLogMessage("end private function validateRequest().");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
