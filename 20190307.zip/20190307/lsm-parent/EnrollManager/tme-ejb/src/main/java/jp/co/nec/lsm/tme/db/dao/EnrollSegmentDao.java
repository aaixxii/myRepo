package jp.co.nec.lsm.tme.db.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SegmentHelper;

/**
 * @author liuj <br>
 * 
 */
public class EnrollSegmentDao  {
	

	private SegmentHelper segHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollSegmentDao.class);

	/**
	 * constructor
	 */
	public EnrollSegmentDao(EntityManager manager) {		
		segHelper = new SegmentHelper(manager);
		printLogMessage("EnrollSegmentDao init");
	}

	/**
	 * get all Segment IDs.
	 * 
	 * @return list of EnrollSegmentEntity IDs
	 */	
	public List<Long> getAllSegmentIds() {
		printLogMessage("start public function getAllSegmentIds()..");

		List<Long> segmentIds = segHelper.getAllSegmentIds();

		printLogMessage("end public function getAllSegmentIds()..");
		return segmentIds;
	}

	/**
	 * get all Segments Information.
	 * 
	 * @return list of EnrollSegmentEntity
	 */	
	public List<SegmentEntity> getAllSegmentsInfo() {
		printLogMessage("start public function getAllSegmentsInfo()..");

		List<SegmentEntity> segmentEntities = segHelper.getAllSegmentsInfo();

		printLogMessage("end public function getAllSegmentsInfo()..");
		return segmentEntities;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
