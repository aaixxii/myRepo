package jp.co.nec.lsm.tme.exception;

/**
 * @author zhulk <br>
 */
public class DuplicateEnrollBatchJobException extends EnrollRuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8805895846078291032L;

	public DuplicateEnrollBatchJobException(String message) {
		super(message);
	}
}
