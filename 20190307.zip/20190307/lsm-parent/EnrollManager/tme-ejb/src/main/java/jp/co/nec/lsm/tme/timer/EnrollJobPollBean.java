package jp.co.nec.lsm.tme.timer;

import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollExtractJobFailManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;

/**
 * @author zhulk
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollJobPollBean  {
	
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private EnrollSystemConfigDao systemConfigDao;

	private static Logger log = LoggerFactory
			.getLogger(EnrollJobPollBean.class);

	/**
	 * constructor
	 */
	public EnrollJobPollBean() {
	}
	
	@PostConstruct
	public void init() {
		systemConfigDao  = new EnrollSystemConfigDao(entityManager, dataSource);		
	}

	/**
	 * find extract jobs exit by time and then retry or done them
	 * 
	 * @param failManager
	 */
	public void timeoutExtractJob(EnrollExtractJobFailManager failManager) {
		try {
			// get EXTRACT_JOB_TIMEOUT Property
			Integer extractJobTimeout = systemConfigDao.getExtractJobTimeOut();
			// get MAX_EXTRACT_JOB_FAILURES Property
			Integer maxExtractFailure = systemConfigDao
					.getMaxExtractjobFailure();

			long now = (DateUtil.getCurrentDate()).getTime();

			// change Extract Job information by Time out
			failManager.checkExtractJobByTime(extractJobTimeout,
					maxExtractFailure, now);
		} catch (Exception ex) {
			log.error("Exception when check extract jobs timeout.", ex);
		}
	}

	/**
	 * 
	 */	
	public void poll() {
		printLogMessage("poll() is called.");

		StopWatch t = new StopWatch();
		t.start();

		EnrollExtractJobFailManager failManager = new EnrollExtractJobFailManager();

		// check is there any Completed batch job
		timeoutExtractJob(failManager);

		// poll to check is there any Completed batch job, if done then call
		// notifyBatchJobDone
		callCompletedBatchJob();

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_JOB_POLL_BEAN,
				LogConstants.FUNCTION_POLL, t.getTime());

	}

	/**
	 * poll to check is there any Completed batch job <br>
	 * if done call notifyBatchJobDone
	 */
	private void callCompletedBatchJob() {
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = EnrollBatchJobManager
				.getInstance().getEnrollLinkQueue();
		Date now = DateUtil.getCurrentDate();
		for (LocalEnrollBatchJob batchJob : enrollLinkQueue) {

			if (!(batchJob.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTING) && batchJob
					.areAllExtractJobsDone())) {
				continue;
			}
			batchJob.complete(now);

			printLogMessage("all of extract jobs of batch job "
					+ batchJob.getBatchJobId() + " is completed.");

			if (log.isInfoEnabled()) {
				BatchJobStatusLogger.outputBatchJobStatus(
						LogConstants.STATUS_CATEGORY_TME, batchJob
								.getBatchJobId(),
						EnrollBatchJobStatus.EXTRACTED.name());
			}

			// notify EnrollUpdateBatchJobServiceBean that Batch Job
			// Completed by Batch Job Id
			EnrollEventBus.notifyBatchJobCompleted(batchJob.getBatchJobId(),
					EnrollNotifierEnum.EnrollJobPollBean);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
