package jp.co.nec.lsm.tme.db.dao;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;

/**
 * @author liuj <br>
 * 
 */
public class EnrollSystemConfigDao  {	
	private EntityManager manager;
	
	protected DataSource dataSource;

	private SystemConfigHelper sysConfigHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollSystemConfigDao.class);

	/**
	 * constructor
	 */
	public EnrollSystemConfigDao(EntityManager manager, DataSource dataSource) {
		this.manager = manager;
		this.dataSource = dataSource;
		sysConfigHelper = new SystemConfigHelper(manager);
		printLogMessage("EnrollSystemConfigDao init");
	}

	/**
	 * write All Missing Properties into DB
	 */	
	public void writeAllMissingProperties() {
		printLogMessage("call public function writeAllMissingProperties().");
		sysConfigHelper.writeAllMissingProperties(dataSource);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
	
	public String getDMPushURL() {
		printLogMessage("call public function getDMPushURL().");
		return sysConfigHelper.getTMProperty(ConfigProperty.DM_PUSH_URL);
	}
	
	public Integer getExtractJobTimeOut() {
		printLogMessage("call public function getMinUSCRedundancy().");
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.TIMEOUT_EXTRACT_JOB);
	}
	
	public Integer getHeartBeatTimeOut() {
		printLogMessage("call public function getMinUSCRedundancy().");
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.TIMEOUTS_TME_UNIT_HEARTBEAT);
	}
	
	public Integer getMaxExtractjobFailure() {
		printLogMessage("call public function getMaxExtractjobFailure().");
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.MAX_EXTRACT_JOB_FAILURES);
	}
	
	public Long getMaxSegmentSize() {
		printLogMessage("call public function getMaxSegmentSize().");
		return sysConfigHelper
				.getTMPropertyLong(ConfigProperty.MAX_SEGMENT_SIZE);
	}
	
	public Integer getMinUSCRedundancy() {
		printLogMessage("call public function getMinUSCRedundancy().");
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.USC_MIN_REDUNDANCY);
	}
	
	public Integer getDefaultUSCRedundancy() {
		printLogMessage("call public function getDefaultUSCRedundancy().");
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.USC_DEF_REDUNDANCY);
	}
	
	public Integer getMaxUSCRedundancy() {
		printLogMessage("call public function getMaxUSCRedundancy().");
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.USC_MAX_REDUNDANCY);
	}
	
	public int getMinUscForSlb() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.MIN_USCS_FOR_SLB);
	}
	
	public boolean getSlbEnabled() {
		return sysConfigHelper
				.getTMPropertyBoolean(ConfigProperty.SEGMENT_LOAD_BALANCER_ENABLED);
	}

	// add transformer IF start	
	public int getHighLevelEnrollBatchJobs() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.BATCHJOB_COUNT_ENROLL_JOBFETCH_FOR_HIGH_LEVEL);
	}
	
	public int getLowLevelEnrollBatchJobs() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.BATCHJOB_COUNT_ENROLL_JOBFETCH_FOR_LOW_LEVEL);
	}
	
	public int getIntervalForEnrollHighLevel() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.INTERVALS_ENROLL_JOBFETCH_FOR_HIGH_LEVEL);
	}
	
	public int getIntervalForEnrollLowLevel() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.INTERVALS_ENROLL_JOBFETCH_FOR_LOW_LEVEL);
	}
	
	public int getIntervalForEnrollNormal() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.INTERVALS_ENROLL_JOBFETCH_FOR_NORMAL_LEVEL);
	}
	
	public String getBatchJobFromTransformerUrl() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.ENROLL_GETBATCHJOB_URL);
	}
	
	public String getPostToTransformerUrl() {
		return sysConfigHelper.getTMProperty(ConfigProperty.ENROLL_POST_URL);
	}
	
	public String getJobCountToTransformer() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TRANSFORMER_TME_GET_JOB_COUNT);
	}
	
	public String getBatchJobCountToTransformer() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TRANSFORMER_TME_GET_BATCHJOB_COUNT);
	}
	
	public String getTurnAroundTime() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TRANSFORMER_TME_TURNAROUNDTIME);
	}
	
	public String getTMEIpAddress() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TME_IP_ADDRESS);
	}
	
	public boolean getEnrollServiceEnabled() {
		return sysConfigHelper
				.getTMPropertyBoolean(ConfigProperty.ENROLL_SERVICE_ENABLED);
	}
	
	public int getHeartbeatPollingDuration() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.TM_HEAERBEAT_POLLING_DURATION);
	}

	/**
	 * get tme job receiver url
	 * 
	 * @return Web Port number
	 */	
	public String getTmeBatchJobReceiverUrl() {
		String tmeIp = getTMEIpAddress();
		String tmeWebPort = sysConfigHelper
				.getTMProperty(ConfigProperty.TME_WEB_PORT_NUM);
		String jobReceiverUrl = sysConfigHelper
				.getTMProperty(ConfigProperty.TME_BATCHJOB_RECEIVER_URL);
		return Constants.HTTP + tmeIp + Constants.COLON + tmeWebPort
				+ jobReceiverUrl;
	}

	/**
	 * get Web Port number
	 * 
	 * @return Web Port number
	 */	
	public String getTMEWebPort() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TME_WEB_PORT_NUM);
	}

	/**
	 * get Template Size
	 * 
	 * @return Template Size
	 */	
	public int getTemplateSize() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.PERSON_TEMPLATE_SIZE);
	}

	/**
	 * get USC Segment Synchronize Enable
	 * 
	 * @return USC Segment Synchronize Enable
	 */	
	public String getSegmentDeleteSyn() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.SEGMENT_DELETE_SYNCHRONIZE_SCOPE);
	}

}
