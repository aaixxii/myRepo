package jp.co.nec.lsm.tme.exception;

/**
 * @author mozj <br>
 */
public class EmptyRequestIDException extends EnrollRuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8683162195039708172L;

	public EmptyRequestIDException(String message) {
		super(message);
	}
}
