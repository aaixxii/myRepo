package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;

/**
 * @author liuj <br>
 * 
 */

public class EnrollTransactionManagerDao {	
	
	private EntityManager manager;

	private TransactionManagerHelper tmHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollTransactionManagerDao.class);
	
	public EnrollTransactionManagerDao(EntityManager manager) {
		this.manager = manager;
		printLogMessage("EnrollTransactionManagerDao init");
	}

	/**
	 * Create or update MATCH_MANAGERS TABLE. this method judge called at an
	 * initial boot timing and "update MATCH_MANAGERS set version=parameter;".
	 * 
	 * @return
	 */	
	public TransactionManagerEntity createOrLookup() {

		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity enrollTransactionManaget = tmHelper
				.createOrLookupVersion(now, TMeVersion.readVersion());
		enrollTransactionManaget.setState(TmState.WORKING);
		enrollTransactionManaget.setLastHeartbeatTs(now);
		enrollTransactionManaget.setLastPollTs(now);
		manager.merge(enrollTransactionManaget);
		manager.flush();

		return enrollTransactionManaget;
	}

	/**
	 * update MATCH_MANAGERS TABLE. this method judge called at an initial boot
	 * timing and "update MATCH_MANAGERS set version=parameter;".
	 * 
	 * @return
	 */	
	public void changeTMEToExit() {

		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity enrollTransactionManaget = tmHelper
				.createOrLookupVersion(now, TMeVersion.readVersion());
		enrollTransactionManaget.setState(TmState.EXITED);
		enrollTransactionManaget.setLastHeartbeatTs(now);
		enrollTransactionManaget.setLastPollTs(now);
		manager.merge(enrollTransactionManaget);
		manager.flush();

		return;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
