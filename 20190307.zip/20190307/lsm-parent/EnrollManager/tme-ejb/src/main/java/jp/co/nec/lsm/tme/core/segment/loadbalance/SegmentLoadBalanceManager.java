package jp.co.nec.lsm.tme.core.segment.loadbalance;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.loadbalance.range.DeployException;
import jp.co.nec.loadbalance.range.DuplicateNodeException;
import jp.co.nec.loadbalance.range.DuplicateSegmentException;
import jp.co.nec.loadbalance.range.Node;
import jp.co.nec.loadbalance.range.NodeState;
import jp.co.nec.loadbalance.range.Param;
import jp.co.nec.loadbalance.range.RangeDeployer;
import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.log.SLBLogger;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tme.db.dao.EnrollMatchUnitDao;
import jp.co.nec.lsm.tme.db.dao.EnrollMuSegmentMapDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSegmentDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

/**
 * @author zhulk
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SegmentLoadBalanceManager {
		

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(SegmentLoadBalanceManager.class);
	
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	
	private EnrollMuSegmentMapDao muSegmentMapDao;
	
	private EnrollSegmentDao segmentDao;
	
	private EnrollSystemConfigDao systemConfigDao;
	
	private EnrollMatchUnitDao matchUnitDao;

	/**
	 * constructor
	 */
	public SegmentLoadBalanceManager() {
	}
	
	@PostConstruct
	public void init() {
		systemConfigDao = new EnrollSystemConfigDao(entityManager, dataSource);
		muSegmentMapDao = new EnrollMuSegmentMapDao(entityManager, dataSource);
		segmentDao = new EnrollSegmentDao(entityManager);
		matchUnitDao = new EnrollMatchUnitDao(entityManager);
	}

	/**
	 * get boolean[][] for new MU-Segment Maps, and update changes into DB
	 * 
	 * 1. prepare Parameters for redeploy
	 * 
	 * 2. get boolean[][] for new MU-Segment Maps
	 * 
	 * 3. update changes into DB
	 * 
	 * @return boolean[][] for new MU-Segment Maps
	 * @throws EnrollDeployException
	 */
	public void excuteSLB() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		boolean isSLBEnable = systemConfigDao.getSlbEnabled();
		if (isSLBEnable == false) {
			log.warn("Don't do SLB because SLB is disable.");
			return;
		}

		// get deployed Segment entities count
		int preSegmentsCount = muSegmentMapDao.findSegmentsCountInMuSegMap();
		// get all Segment entities IDs
		List<Long> segmentIds = segmentDao.getAllSegmentIds();

		// check whether There are segments which have been created
		if (preSegmentsCount == segmentIds.size()) {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.infoOutput(
						LogConstants.COMPONENT_SEGMENT_LOAD_BALACE_MANAGER,
						LogConstants.FUNCTION_EXCUTE_SLB_TME, "DETAIL",
						"There is not segment which has been created."));
			}
			return;
		}

		// reDeploy for USC and persist into DB
		reDeployForUSC(segmentIds);

		// reDeploy for DM and persist into DB
		reDeployForDM(segmentIds);

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_SEGMENT_LOAD_BALACE_MANAGER,
				LogConstants.FUNCTION_EXCUTE_SLB_TME, stopWatch.getTime());

		return;
	}

	/**
	 * do reDeploy for USC and persist MU_SegmentMaps into DB
	 * 
	 * @param preSegmentEntities
	 * @param segmentEntities
	 */
	private void reDeployForUSC(List<Long> segmentIDs) {

		// get working USC Entity List
		List<MatchUnitEntity> workingUSCs = matchUnitDao
				.getMatchUnitsByTypeAndState(ComponentType.USC, MUState.WORKING);
		// check if the working USC number
		int workingUSCNumber = workingUSCs.size();
		if (workingUSCNumber == 0) {
			log.warn("There is no working USC for doing SLB.");
			return;
		}
		// check if the working usc is under MIN_USCS_FOR_SLB
		if (isUnderMinUSCForSlb(workingUSCNumber)) {
			log.warn("Don't do SLB because of working USCs number limit.");
			return;
		}

		// get redundancy of segment from SYSTEM_CONFIG table
		Integer minRedundancy = systemConfigDao.getMinUSCRedundancy();
		Integer defRedundancy = systemConfigDao.getDefaultUSCRedundancy();
		Integer maxRedundancy = systemConfigDao.getMaxUSCRedundancy();
		// check if the working usc is under redundancy
		if (minRedundancy > workingUSCNumber) {
			log.warn("Don't do SLB because of min Redundancy: {} "
					+ "> Working USCs Number: {}.", new Object[] {
					minRedundancy, workingUSCNumber });
			return;
		}

		// get MuSegment entities of USC
		List<MuSegmentEntity> preUSCSegmentMaps = muSegmentMapDao
				.findMuSegMapOfMU();
		// get USC Entity List
		List<MatchUnitEntity> uscEntities = matchUnitDao
				.findAllMUUnit(ComponentType.USC);

		// reDeploy for USC and persist into DB
		String msg = "Exception when  execute Segment Load Balance for USC";
		try {
			reDeployForUnit(uscEntities, segmentIDs, preUSCSegmentMaps,
					minRedundancy, defRedundancy, maxRedundancy,
					ComponentType.USC);
		} catch (DeployException e) {
			log.error(msg, e);
			throw new EnrollRuntimeException(msg, e);
		} catch (DuplicateSegmentException e) {
			log.error(msg, e);
			throw new EnrollRuntimeException(msg, e);
		} catch (DuplicateNodeException e) {
			log.error(msg, e);
			throw new EnrollRuntimeException(msg, e);
		}
	}

	/**
	 * do reDeploy for DM and persist MU_SegmentMaps into DB
	 * 
	 * @param preSegmentEntities
	 * @param segmentEntities
	 */
	private void reDeployForDM(List<Long> segmentIDs) {

		// get DM Entity List
		List<MatchUnitEntity> dmEntities = matchUnitDao
				.findAllMUUnit(ComponentType.DM);

		// check if the working DM number
		int dmNumber = dmEntities.size();
		if (dmNumber == 0) {
			log.warn("There is no working DM for doing SLB.");
			return;
		}

		// set dmRedundancy to dmNumber due to mantis 0001292
		Integer dmRedundancy = dmNumber;

		// get MuSegment entities of DM
		List<MuSegmentEntity> preDMSegmentMaps = muSegmentMapDao
				.findMuSegMapOfDM();

		// reDeploy for USC and persist into DB
		String msg = "Exception when execute Segment Load Balance for DM";
		try {
			reDeployForUnit(dmEntities, segmentIDs, preDMSegmentMaps,
					dmRedundancy, dmRedundancy, dmRedundancy, ComponentType.DM);
		} catch (DeployException e) {
			log.error(msg, e);
			throw new EnrollRuntimeException(msg, e);
		} catch (DuplicateSegmentException e) {
			log.error(msg, e);
			throw new EnrollRuntimeException(msg, e);
		} catch (DuplicateNodeException e) {
			log.error(msg, e);
			throw new EnrollRuntimeException(msg, e);
		}
	}

	/**
	 * reDeploy for TM Unit and persist into DB
	 * 
	 * @param muEntities
	 * @param preSegmentEntities
	 * @param segmentEntities
	 * @param muSegMaps
	 * @param redundancy
	 * @return
	 * @throws DeployException
	 * @throws DuplicateNodeException
	 * @throws DuplicateSegmentException
	 */
	private void reDeployForUnit(List<MatchUnitEntity> muEntities,
			List<Long> segmentIDs, List<MuSegmentEntity> muSegMaps,
			Integer minRedundancy, Integer defRedundancy,
			Integer maxRedundancy, ComponentType unitType)
			throws DeployException, DuplicateSegmentException,
			DuplicateNodeException {
		printLogMessage("start private function reDeployForUnit.");
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.slbInfoOutput(
					LogConstants.DETAIL_MIN_REDUNDANCY, String
							.valueOf(minRedundancy),
					LogConstants.DETAIL_DEFAULT_REDUNDANCY, String
							.valueOf(defRedundancy),
					LogConstants.DETAIL_MAX_REDUNDANCY, String
							.valueOf(maxRedundancy),
					LogConstants.DETAIL_ALL_UNIT_NUM, String.valueOf(muEntities
							.size()), LogConstants.DETAIL_UNIT_TYPE, unitType
							.name(), LogConstants.DETAIL_ALL_SEGMENT_NUM,
					String.valueOf(segmentIDs.size())));
		}
		// 1. prepare Parameters for redeploy
		// prepare Param for new MU-Segment Maps
		printLogMessage("prepare Param for new MU-Segment Maps.");
		Param param = prepareParam(muEntities, segmentIDs, unitType);

		// prepare old MU-Segment Maps
		boolean[][] preMatrix = preparePreMatrix(muEntities, segmentIDs,
				muSegMaps);

		// 2. get boolean[][] for new MU-Segment Maps
		RangeDeployer deploye = new RangeDeployer(minRedundancy, defRedundancy,
				maxRedundancy);
		printLogMessage("get boolean[][] for new MU-Segment Maps.");

		boolean[][] newMatrix = deploye.reDeploy(preMatrix, param);

		// 3. update changes into DB
		// update new MU-Segment Maps information into database
		printLogMessage("update new MU-Segment Maps information into database.");

		if (newMatrix != null) {
			muSegmentMapDao.updateMuSegMap(newMatrix, muEntities, segmentIDs,
					muSegMaps, unitType);

			// SLB Log
			SLBLogger.slbOutput(LogConstants.STATUS_CATEGORY_TME, unitType,
					preMatrix, newMatrix);
		} else {
			log
					.warn("Can't update MU-Segment table because newMatrix is null.");
		}

		printLogMessage("end private function reDeployForUnit.");

		return;
	}

	/**
	 * isUnderMinUSCForSlb
	 * 
	 * @param allMuEntities
	 * @return
	 */
	private boolean isUnderMinUSCForSlb(int uscNumber) {
		// if the working USC is under the MIN_USC_FOR_SLB
		// skip run slb
		int minUSCForSlb = systemConfigDao.getMinUscForSlb();
		if (uscNumber < minUSCForSlb) {
			log
					.warn(
							"the working USC(number: {}) is under the [MIN_USCS_FOR_SLB]({})",
							uscNumber, minUSCForSlb);
			return true;
		}
		return false;
	}

	/**
	 * prepare boolean[][] for old MU-Segment Maps
	 * 
	 * @param muEntities
	 *            mu Entities List
	 * @param preSegmentEntities
	 *            segment Entities list
	 * @param muSegMaps
	 *            MU-Segment Maps list
	 * @return boolean[][] for old MU-Segment Maps
	 */
	public boolean[][] preparePreMatrix(List<MatchUnitEntity> muEntities,
			List<Long> segmentIDs, List<MuSegmentEntity> muSegMaps) {
		printLogMessage("start public function preparePreMatrix()..");

		// initiate variable
		int preSegmentCount = segmentIDs.size();
		int muCount = muEntities.size();
		boolean[][] preMatrix = new boolean[muCount][preSegmentCount];

		// prepare boolean[][] for old MU-Segment Maps
		printLogMessage("prepare boolean[][] for old MU-Segment Maps...");

		int matrixMu = 0;
		int matrixSeg = 0;
		for (MuSegmentEntity mse : muSegMaps) {
			matrixMu = -1;
			matrixSeg = -1;
			// find deployed Mu Index to prepare boolean[][]
			for (int muIndex = 0; muIndex < muCount; muIndex++) {
				if (muEntities.get(muIndex).getId() == mse.getMuId()) {
					matrixMu = muIndex;
					break;
				}
			}

			// find deployed segment Index to prepare boolean[][]
			for (int segIndex = 0; segIndex < preSegmentCount; segIndex++) {
				if (segmentIDs.get(segIndex).longValue() == mse.getSegmentId()) {
					matrixSeg = segIndex;
					break;
				}
			}

			// prepare MU-Segment Maps values
			if (matrixMu != -1 && matrixSeg != -1) {
				preMatrix[matrixMu][matrixSeg] = true;
			}
		}

		printLogMessage("end public function preparePreMatrix()..");

		return preMatrix;
	}

	/**
	 * prepare Parameter for Mu-Segment deploy
	 * 
	 * @param muEntities
	 *            mu Entities List
	 * @param redundancy
	 *            redundancy number of Segment
	 * @param segs
	 *            segments number
	 * @return Parameter for Mu-Segment deploy
	 */
	private Param prepareParam(List<MatchUnitEntity> muEntities,
			List<Long> segmentIds, ComponentType unitType) {
		printLogMessage("start private function prepareParam()..");

		// prepare Mu nodes for param
		List<Node> nodes = new ArrayList<Node>();
		for (int index = 0; index < muEntities.size(); index++) {
			MatchUnitEntity entity = muEntities.get(index);
			NodeState state;
			if (unitType == ComponentType.DM) {
				state = NodeState.WORKING;
			} else {
				state = entity.getState() == MUState.WORKING ? NodeState.WORKING
						: NodeState.STOPPED;
			}
			nodes.add(new Node(entity.getId(), state));
		}

		long[] segIdArray = new long[segmentIds.size()];
		for (int i = 0; i < segmentIds.size(); i++) {
			segIdArray[i] = segmentIds.get(i).longValue();
		}

		// set values into param
		Param param = new Param(nodes, segIdArray);

		printLogMessage("end private function prepareParam()..");

		return param;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
