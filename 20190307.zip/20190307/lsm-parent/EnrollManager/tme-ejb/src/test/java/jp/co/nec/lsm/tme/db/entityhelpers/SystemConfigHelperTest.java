package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.InputStream;
import java.util.EnumSet;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.SystemConfigNamespace;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class SystemConfigHelperTest {

	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	private Properties properties = new Properties();
	@Resource
	protected JdbcTemplate jdbcTemplate;
	@Resource
	protected DataSource dataSource;

	/**
	 * clear disturbing for testing
	 */
	@Before
	public void setUp() {
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		try {
			InputStream is = ConfigProperty.class.getClassLoader()
					.getResourceAsStream(
							SystemConfigNamespace.TM
									.getDefaultPropertiesFilename());
			properties.load(is);
			is.close();
		} catch (IOException e) {
			fail(e.getMessage());
		}
	}

	@After
	public void tearDown() {
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testWriteAllMissingProperties]<br/>
	 * 1 - call writeAllMissingProperties<br/>
	 * 2 - call entrySet<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testWriteAllMissingProperties() {
		SystemConfigHelper helper = new SystemConfigHelper(entityManager);

		// clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");

		// 1 - call writeAllMissingProperties
		helper.writeAllMissingProperties(dataSource);
		// 2 - call entrySet
		Set<Entry<Object, Object>> entrySet = properties.entrySet();

		// 3 - assert concerning information
		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			String value = properties.getProperty(key);
			assertEquals(value, helper.getTMProperty(key));
		}
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testGetTMProperty]<br/>
	 * 1 - call writeAllMissingProperties<br/>
	 * 2 - call entrySet<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testGetTMProperty() {
		SystemConfigHelper helper = new SystemConfigHelper(entityManager);

		// clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");

		// 1 - call writeAllMissingProperties
		helper.writeAllMissingProperties(dataSource);
		// 2 - call entrySet
		Set<Entry<Object, Object>> entrySet = properties.entrySet();

		// 3 - assert concerning information
		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			for (ConfigProperty mm : EnumSet.allOf(ConfigProperty.class)) {
				if (mm.getName().equals(key)) {
					assertEquals(properties.getProperty(key), helper
							.getTMProperty(mm));
				}
			}
		}
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testTMPConfigPropertySize]<br/>
	 * 1 - assert concerning information<br/>
	 */
	@Test
	public void testTMPConfigPropertySize() {

		// 1 - assert concerning information
		assertEquals(properties.size(), EnumSet.allOf(ConfigProperty.class)
				.size());
	}

	@Test
	public void testGetTMPropertyLong() {
		SystemConfigHelper helper = new SystemConfigHelper(entityManager);
		// clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");

		long size = 3221225472L;

		updateDatabase(size);

		long sizeDB = helper.getTMPropertyLong(ConfigProperty.MAX_SEGMENT_SIZE);
		assertEquals(size, sizeDB);
	}

	private void updateDatabase(long size) {
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (1,'BEHAVIOR.MAX_SEGMENT_SIZE','"
						+ size
						+ "')");
	}

}
