package jp.co.nec.lsm.tme.core.gmvapi.request.validator;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;

public class EnterRequestValidatorTest {

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 */
	@Test
	public void testValidate() {
		// prepare EnterRequest for test
		EnterRequest.Builder request = EnterRequest.newBuilder();
		request.setType(ComponentType.DM);
		request.setContactURL("");
		request.setUniqueId("");
		request.setVersion("2132");
		request.setNumberOfCpus(1);
		request.setPrimarySize(12124);
		request.setSecondarySize(124342332);

		// call EnterRequestValidator.validate()
		ValidationResult result = EnterRequestValidator.validate(request
				.build());

		// assert result
		assertEquals(3, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}
	
	/**
	 * 
	 */
	@Test
	public void testValidate_NotError() {
		// prepare EnterRequest for test
		EnterRequest.Builder request = EnterRequest.newBuilder();
		request.setType(ComponentType.MFE);
		request.setContactURL("324dfswf");
		request.setUniqueId("fgsdsd");
		request.setVersion("2132");
		request.setNumberOfCpus(1);
		request.setPrimarySize(12124);
		request.setSecondarySize(124342332);

		// call EnterRequestValidator.validate()
		ValidationResult result = EnterRequestValidator.validate(request
				.build());

		// assert result
		assertEquals(0, result.getRequestError().size());

	}
}
