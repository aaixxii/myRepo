package jp.co.nec.lsm.tme.db.procedure;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;

import jp.co.nec.lsm.tm.common.communication.PersonReferenceID;
import jp.co.nec.lsm.tm.common.communication.PersonTemplate;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.db.enroll.procedure.AddBiometricsProcedure;
import jp.co.nec.lsm.tme.util.TMETestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollAddBiometricsProcedureTest {
	@PersistenceContext(unitName = "tme-ngi")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
		clearDatabase();
		updateDatabase();
	}

	@Test
	public void testAddBiometrics_CreateSegment() {
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";
		AddBiometricsProcedure addBiometricsProcedure = new AddBiometricsProcedure(
				dataSource);
		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		// one segment create.
		List<PersonTemplate> jobInfo = prepareLocalEnrollBatchJobInfo(0);
		addBiometricsProcedure.setBiometicsDate(jobInfo);
		List<SegmentPosition> segPos = addBiometricsProcedure.execute(
				duplicateIds, personReferenceIDList);
		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_segment_version_detail = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(10, list_person_biometrics.size());
		assertEquals(10, personReferenceIDList.size());

		assertEquals(1, list_segment_version_detail.size());
		assertEquals("0", list_segment_version_detail.get(0).get("VERSION")
				.toString());
		assertEquals("10", list_segment_version_detail.get(0).get(
				"RECORD_COUNT").toString());

		assertEquals(1, list_segments.size());
		assertEquals("0", list_segments.get(0).get("VERSION").toString());
		assertEquals("10", list_segments.get(0).get("RECORD_COUNT").toString());

		assertEquals(0, duplicateIds.size());

		assertEquals(1, segPos.size());
		assertEquals(0, segPos.get(0).getVersion());
	}

	@Test
	public void testAddBiometrics_UpdateAndCreateSegment() {
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";
		AddBiometricsProcedure addBiometricsProcedure = new AddBiometricsProcedure(
				dataSource);
		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		preparePersonBiometics(10);
		prepareSegment(1, 10);

		// update an existing segment and create a new segment
		List<PersonTemplate> jobInfo2 = prepareLocalEnrollBatchJobInfo(10);
		addBiometricsProcedure.setBiometicsDate(jobInfo2);
		List<SegmentPosition> segPos = addBiometricsProcedure.execute(
				duplicateIds, personReferenceIDList);
		List<Map<String, Object>> list_person_biometrics1 = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_segment_version_detail1 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments1 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(20, list_person_biometrics1.size());
		assertEquals(10, personReferenceIDList.size());

		assertEquals(3, list_segment_version_detail1.size());
		assertEquals("0", list_segment_version_detail1.get(0).get("VERSION")
				.toString());
		assertEquals("10", list_segment_version_detail1.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("1", list_segment_version_detail1.get(1).get("VERSION")
				.toString());
		assertEquals("5", list_segment_version_detail1.get(1).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail1.get(2).get("VERSION")
				.toString());
		assertEquals("5", list_segment_version_detail1.get(2).get(
				"RECORD_COUNT").toString());

		assertEquals(2, list_segments1.size());
		assertEquals("1", list_segments1.get(0).get("VERSION").toString());
		assertEquals("15", list_segments1.get(0).get("RECORD_COUNT").toString());
		assertEquals("0", list_segments1.get(1).get("VERSION").toString());
		assertEquals("5", list_segments1.get(1).get("RECORD_COUNT").toString());

		assertEquals(0, duplicateIds.size());

		assertEquals(2, segPos.size());
		assertEquals(1, segPos.get(0).getVersion());
		assertEquals(0, segPos.get(1).getVersion());
	}

	@Test
	public void testAddBiometrics_UpdateSegment() {
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";
		AddBiometricsProcedure addBiometricsProcedure = new AddBiometricsProcedure(
				dataSource);
		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		preparePersonBiometics(20);
		prepareSegment(2, 5);

		// update an existing segment
		List<PersonTemplate> jobInfo3 = prepareLocalEnrollBatchJobInfo(20);
		addBiometricsProcedure.setBiometicsDate(jobInfo3);
		List<SegmentPosition> segPos = addBiometricsProcedure.execute(
				duplicateIds, personReferenceIDList);
		List<Map<String, Object>> list_person_biometrics2 = jdbcTemplate.queryForList(sql_person_biometrics);
				
		List<Map<String, Object>> list_segment_version_detail2 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments2 = jdbcTemplate
				.queryForList(sql_segments);
		
		assertEquals(10, personReferenceIDList.size());

		assertEquals(3, list_segment_version_detail2.size());
		assertEquals("0", list_segment_version_detail2.get(0).get("VERSION")
				.toString());
		assertEquals("15", list_segment_version_detail2.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail2.get(1).get("VERSION")
				.toString());
		assertEquals("5", list_segment_version_detail2.get(1).get(
				"RECORD_COUNT").toString());
		assertEquals("1", list_segment_version_detail2.get(2).get("VERSION")
				.toString());
		assertEquals("10", list_segment_version_detail2.get(2).get(
				"RECORD_COUNT").toString());

		assertEquals(2, list_segments2.size());
		assertEquals("0", list_segments2.get(0).get("VERSION").toString());
		assertEquals("15", list_segments2.get(0).get("RECORD_COUNT").toString());
		assertEquals("1", list_segments2.get(1).get("VERSION").toString());
		assertEquals("15", list_segments2.get(1).get("RECORD_COUNT").toString());

		assertEquals(0, duplicateIds.size());

		assertEquals(1, segPos.size());
		assertEquals(1, segPos.get(0).getVersion());
	}

	@Test
	public void testAddBiometrics_AllDuplicated() {
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";
		AddBiometricsProcedure addBiometricsProcedure = new AddBiometricsProcedure(
				dataSource);
		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		preparePersonBiometics(30);
		prepareSegment(2, 15);

		// all of reference ids are duplicated
		List<PersonTemplate> jobInfo4 = prepareLocalEnrollBatchJobInfo(20);
		addBiometricsProcedure.setBiometicsDate(jobInfo4);
		List<SegmentPosition> segPos = addBiometricsProcedure.execute(
				duplicateIds, personReferenceIDList);
		List<Map<String, Object>> list_person_biometrics21 = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_segment_version_detail21 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments21 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(30, list_person_biometrics21.size());
		assertEquals(0, personReferenceIDList.size());

		assertEquals(2, list_segment_version_detail21.size());
		assertEquals("0", list_segment_version_detail21.get(0).get("VERSION")
				.toString());
		assertEquals("15", list_segment_version_detail21.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail21.get(1).get("VERSION")
				.toString());
		assertEquals("15", list_segment_version_detail21.get(1).get(
				"RECORD_COUNT").toString());

		assertEquals(2, list_segments21.size());
		assertEquals("0", list_segments21.get(0).get("VERSION").toString());
		assertEquals("15", list_segments21.get(0).get("RECORD_COUNT")
				.toString());
		assertEquals("0", list_segments21.get(1).get("VERSION").toString());
		assertEquals("15", list_segments21.get(1).get("RECORD_COUNT")
				.toString());

		assertEquals(10, duplicateIds.size());

		assertEquals(0, segPos.size());
	}

	@Test
	public void testAddBiometrics_PartDuplicated() {
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";
		AddBiometricsProcedure addBiometricsProcedure = new AddBiometricsProcedure(
				dataSource);

		preparePersonBiometics(30);
		prepareSegment(2, 15);

		// some of reference ids are duplicated
		List<String> duplicateIds2 = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		List<PersonTemplate> jobInfo5 = prepareLocalEnrollBatchJobInfo(25);
		addBiometricsProcedure.setBiometicsDate(jobInfo5);
		List<SegmentPosition> segPos = addBiometricsProcedure.execute(
				duplicateIds2, personReferenceIDList);
		List<Map<String, Object>> list_person_biometrics3 = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_segment_version_detail3 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments3 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(35, list_person_biometrics3.size());
		assertEquals(5, personReferenceIDList.size());

		assertEquals(3, list_segment_version_detail3.size());
		assertEquals("0", list_segment_version_detail3.get(0).get("VERSION")
				.toString());
		assertEquals("15", list_segment_version_detail3.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail3.get(1).get("VERSION")
				.toString());
		assertEquals("15", list_segment_version_detail3.get(1).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail3.get(2).get("VERSION")
				.toString());
		assertEquals("5", list_segment_version_detail3.get(2).get(
				"RECORD_COUNT").toString());

		assertEquals(3, list_segments3.size());
		assertEquals("0", list_segments3.get(0).get("VERSION").toString());
		assertEquals("15", list_segments3.get(0).get("RECORD_COUNT").toString());
		assertEquals("0", list_segments3.get(1).get("VERSION").toString());
		assertEquals("15", list_segments3.get(1).get("RECORD_COUNT").toString());
		assertEquals("0", list_segments3.get(2).get("VERSION").toString());
		assertEquals("5", list_segments3.get(2).get("RECORD_COUNT").toString());

		assertEquals(5, duplicateIds2.size());

		assertEquals(1, segPos.size());
		assertEquals(0, segPos.get(0).getVersion());
	}

	private List<PersonTemplate> prepareLocalEnrollBatchJobInfo(int startIds) {
		List<PersonTemplate> jobinfo = new ArrayList<PersonTemplate>();
		for (int i = 1; i <= 10; i++) {
			byte[] bs = prepareTemplate(String.valueOf(i)).toByteArray();

			PersonTemplate localEnrollBatchJobInfo = new PersonTemplate();
			localEnrollBatchJobInfo
					.setReferenceId("reference" + (i + startIds));
			localEnrollBatchJobInfo.setBiometicsData(bs);
			jobinfo.add(localEnrollBatchJobInfo);

		}
		return jobinfo;
	}

	private ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	private void clearDatabase() {
		jdbcTemplate.execute("delete FROM PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
	}

	private void updateDatabase() {
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (1,'BEHAVIOR.MAX_SEGMENT_SIZE','"
						+ (TMETestUtil.PERSON_TEMPLATE_SIZE * 15 + 40) + "')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(100, "
				+ "'PERSON_TEMPLATE_SIZE', '"
				+ TMETestUtil.PERSON_TEMPLATE_SIZE + "')");
	}

	private void preparePersonBiometics(int count) {
		for (int i = 1; i <= count; i++) {
			String sql = "INSERT INTO person_biometrics( biometrics_id, reference_id,"
					+ " biometric_data, biometric_data_len, date_added ) VALUES("
					+ i
					+ ",'"
					+ ("reference" + (i))
					+ "', '0', "
					+ TMETestUtil.PERSON_TEMPLATE_SIZE + ", systimestamp)";
			jdbcTemplate.execute(sql);
		}
	}

	private void prepareSegment(int count, int lastRecordCount) {
		int startId = -1;
		int endId = -1;
		int segLength = -1;
		for (int i = 1; i <= count; i++) {
			startId = ((i - 1) * 15 + 1);
			if (i == count) {
				endId = startId + lastRecordCount - 1;
			} else {
				endId = (i * 15);
			}
			segLength = (endId - startId + 1)
					* TMETestUtil.PERSON_TEMPLATE_SIZE;
			String segSQL = "INSERT INTO SEGMENTS(SEGMENT_ID, BIO_ID_START, BIO_ID_END,"
					+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, GENERATION,"
					+ " BINARY_LENGTH_UNCOMPACTED ) VALUES ( "
					+ i
					+ ", "
					+ startId
					+ ","
					+ endId
					+ ","
					+ segLength
					+ ","
					+ (endId - startId + 1) + ", 0,0," + segLength + ")";
			jdbcTemplate.execute(segSQL);

			String segDetailSQL = "INSERT INTO SEGMENT_VERSION_DETAIL(SEGMENT_ID,VERSION,"
					+ " BIO_ID_START, BIO_ID_END,UPDATE_TS,RECORD_COUNT, CHANGE_TYPE) VALUES ( "
					+ i
					+ ", 0,"
					+ startId
					+ ","
					+ endId
					+ ",systimestamp,"
					+ (endId - startId + 1) + ", 0)";
			jdbcTemplate.execute(segDetailSQL);
		}
	}

	@Test
	public void testAddBiometricsData() {
		clearDatabase();
		updateDatabase();
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		AddBiometricsProcedure addBiometricsProcedure = new AddBiometricsProcedure(
				dataSource);
		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		List<PersonTemplate> jobInfo = prepareLocalEnrollBatchJobInfo(0);
		addBiometricsProcedure.setBiometicsDate(jobInfo);
		addBiometricsProcedure.execute(duplicateIds, personReferenceIDList);

		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);

		int count = 0;
		for (int i = 0; i < 10; i++) {
			String id = ((String) list_person_biometrics.get(i).get(
					"REFERENCE_ID")).trim();
			for (PersonTemplate info : jobInfo) {
				if (info.getReferenceId().equals(id)) {
					byte[] data = (byte[]) list_person_biometrics.get(i).get(
							"BIOMETRIC_DATA");
					assertEquals(200, data.length);
					for (int j = 0; j < data.length; j++) {
						assertEquals(info.getBiometicsData()[j], data[j]);
					}
					count++;
					break;
				}
			}
		}
		assertEquals(10, count);
		assertEquals(10, personReferenceIDList.size());
	}

}
