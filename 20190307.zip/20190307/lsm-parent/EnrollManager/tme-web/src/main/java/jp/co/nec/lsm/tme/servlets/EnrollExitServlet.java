package jp.co.nec.lsm.tme.servlets;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.proto.control.ExitRequestProto.ExitRequest;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServletRequestUtil;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollStatusManagerBean;

/**
 * @author mozj
 * @web.servlet name="ExitServletRemote"
 * @web.servlet-mapping url-pattern="/Exit"
 */
public class EnrollExitServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6752834018001559370L;
	private static final Logger log = LoggerFactory
			.getLogger(EnrollExitServlet.class);
	
	@EJB
	private EnrollStatusManagerBean statusManager;

	public void init() throws ServletException {

	}

	/**
	 * 
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException {

		if (ServletRequestUtil.isRequestContextSizeEmpty(req)) {
			log.warn("Received an empty POST request");
			return;
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		ExitRequest exitRequest = null;
		try {
			exitRequest = ExitRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpServletResponse.SC_BAD_REQUEST,
					"parse ExitRequest object error", ex);
			return;
		}

		try {
			statusManager.exit(exitRequest.getGmvId());
		} catch (Exception ex) {
			writeErrorToResponse(req, res,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"enroll exit error.", ex);
			return;
		}

		stopWatch.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_EXIT_SERVLET_TME,
				LogConstants.FUNCTION_DO_POST, stopWatch.getTime());

	}

}
