/**
 * 
 */
package jp.co.nec.lsm.tme.listener;

import javax.ejb.EJB;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tme.service.sessionbean.EnrollSystemDownManagerBean;

/**
 * @author liuj
 * @web:listener
 */
public class ShutDownManagerListener implements ServletContextListener {
	private static final Logger log = LoggerFactory
			.getLogger(ShutDownManagerListener.class);

	@EJB
	EnrollSystemDownManagerBean sdm;

	/*
	 * (non-Javadoc)
	 * 
	 * @seejavax.servlet.ServletContextListener#contextDestroyed(javax.servlet.
	 * ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent sce) {
		printLogMessage("contextDestroyed called, TME shutdown.");

		sdm.shutdown();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.ServletContextListener#contextInitialized(javax.servlet
	 * .ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent sce) {

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
