package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollBatchJobsSnapshotsSevletTest {
	@Resource
	EnrollBatchJobsSnapshotsSevlet sevlet;
	
	EnrollBatchJobManager queueManage;

	@Before
	public void setUp() throws ServletException {
		sevlet.init();

		cleanMemoryQueue();
	}

	@After
	public void tearDown() {
		cleanMemoryQueue();
	}

	/**
	 * 
	 */
	private void cleanMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}
	}

	private void prepareEnrollBatchJob(long batchID) {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		for (int index = 0; index <= 5; index++) {
			LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
			enrollBatchJob.setBatchJobId(batchID + index);
			enrollBatchJob
					.setBatchJobStatus(EnrollBatchJobStatus.values()[index]);
			enrollBatchJob.setBatchJobType(BatchType.ENROLL);
			enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());

			for (int i = 1; i <= 10; i++) {
				LocalExtractJobInfo jobInfo = new LocalExtractJobInfo();
				jobInfo.setJobId(i);
				jobInfo.setReferenceId("referentID" + i);
				jobInfo.setRequestId(String.valueOf(i));

				if (index == 0) {
					jobInfo.setReturnCode(ReturnCode.NotUsed);
					jobInfo.setStatus(LocalExtractJobStatus.READY);
				} else if (index == 1) {
					jobInfo.setReturnCode(ReturnCode.NotUsed);
					jobInfo.setStatus(LocalExtractJobStatus.EXTRACTING);
				} else if (index == 4) {
					enrollBatchJob.setSyncGmv("DM");
					jobInfo.setReturnCode(ReturnCode.JobFailed);
					jobInfo.setStatus(LocalExtractJobStatus.DONE);
				} else {
					jobInfo.setReturnCode(ReturnCode.JobSuccess);
					jobInfo.setStatus(LocalExtractJobStatus.DONE);
				}

				enrollBatchJob.putExtractJobInfo(jobInfo);
			}

			queueManage.addEnrollBatchJob(enrollBatchJob);
		}
	}

	@Test
	public void testDoGet_Success() throws ServletException, IOException {
		long batchID = 17694541L;

		prepareEnrollBatchJob(batchID);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		sevlet.doGet(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertTrue(0 == resp.getContentLength());

		cleanMemoryQueue();
	}

	@Test
	public void testDoGet_ServletException() throws ServletException,
			IOException {

		new MockUp<EnrollBatchJobsSnapshotsSevlet>() {
			@Mock
			void forward(HttpServletRequest req, HttpServletResponse res)
					throws ServletException, IOException {
				throw new ServletException("ServletException");
			}

		};

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		try {
			sevlet.doGet(req, resp);
			fail();
		} catch (EnrollRuntimeException e) {
			assertEquals(
					"ServletException occured while Jump to Jsp -> /jsp/EnrollSnapShot.jsp",
					e.getMessage());
		} catch (Exception e) {
			fail();
		}

		cleanMemoryQueue();
	}

	@Test
	public void testDoGet_IOException() throws ServletException, IOException {

		new MockUp<EnrollBatchJobsSnapshotsSevlet>() {
			@Mock
			void forward(HttpServletRequest req, HttpServletResponse res)
					throws ServletException, IOException {
				throw new IOException("IOException");
			}

		};

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		try {
			sevlet.doGet(req, resp);
			fail();
		} catch (EnrollRuntimeException e) {
			assertEquals(
					"IOException occured while Jump to Jsp -> /jsp/EnrollSnapShot.jsp",
					e.getMessage());
		} catch (Exception e) {
			fail();
		}

		cleanMemoryQueue();
	}
}
