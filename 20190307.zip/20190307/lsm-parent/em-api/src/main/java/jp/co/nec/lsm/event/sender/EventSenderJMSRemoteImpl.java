package jp.co.nec.lsm.event.sender;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.jms.ConnectionFactory;
import javax.jms.Queue;

import jp.co.nec.lsm.event.exception.EventRuntimeException;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jimy <br>
 *         EventSenderJMSRemoteImpl
 */
public class EventSenderJMSRemoteImpl extends AbstractEventSender {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(EventSenderJMSRemoteImpl.class);

	private String ipAddress;
	private static Map<String, EventSenderJMSRemoteImpl> queueSelector = new ConcurrentHashMap<String, EventSenderJMSRemoteImpl>();

	/**
	 * private constructor
	 * 
	 * @param remoteIp
	 * @param queueName
	 */
	private EventSenderJMSRemoteImpl(String remoteIp, String queueName) {
		this.ipAddress = remoteIp;
		this.queueName = queueName;
	}

	/**
	 * clearJmsCache
	 */
	public static void clearJmsCache() {
		queueSelector.clear();
	}

	/**
	 * create single instance
	 * 
	 * @param remoteIp
	 *            remote ip address
	 * @param queueName
	 *            jms queue name
	 * @return this instance
	 */
	public synchronized static EventSenderJMSRemoteImpl getInstance(
			String remoteIp, String queueName) {
		EventSenderJMSRemoteImpl instance = queueSelector.get(queueName);
		if (instance == null) {
			instance = new EventSenderJMSRemoteImpl(remoteIp, queueName);
			queueSelector.put(queueName, instance);
		}
		return instance;
	}

	@Override
	protected void buildConnectionFactoryAndQueue() {
		printLogMessage("start protected function buildConnectionFactoryAndQueue.");
		if (jmsConnectionFactory == null) {
			Object connection = ServiceLocator.lookUpJndiObjectReomte(
					JNDIConstants.JmsFactory, ipAddress);
			if (connection == null) {
				throw new EventRuntimeException(
						"look jmsConnectionFactory error");
			}
			jmsConnectionFactory = (ConnectionFactory) connection;
		}

		if (this.queue == null) {
			Object queueObject = ServiceLocator.lookUpJndiObjectReomte(
					queueName, ipAddress);
			if (queueObject == null) {
				throw new EventRuntimeException("look queue error");
			}
			queue = (Queue) queueObject;
		}
		printLogMessage("end protected function buildConnectionFactoryAndQueue.");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
