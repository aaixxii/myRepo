package jp.co.nec.lsm.event.sender;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.jms.ConnectionFactory;
import javax.jms.Queue;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jimy <br>
 *         EventSenderJMSLocalImpl
 */
public class EventSenderJMSLocalImpl extends AbstractEventSender {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(EventSenderJMSLocalImpl.class);

	private static Map<String, EventSenderJMSLocalImpl> queueSelector = new ConcurrentHashMap<String, EventSenderJMSLocalImpl>();

	private EventSenderJMSLocalImpl(String queueName) {
		this.queueName = queueName;
	}

	public synchronized static EventSenderJMSLocalImpl getInstance(
			String queueName) {
		EventSenderJMSLocalImpl instance = queueSelector.get(queueName);
		if (instance == null) {
			instance = new EventSenderJMSLocalImpl(queueName);
			queueSelector.put(queueName, instance);
		}
		return instance;
	}

	public static void clearQueueSelector() {
		queueSelector.clear();
	}

	@Override
	protected void buildConnectionFactoryAndQueue() {
		printLogMessage("start protected function buildConnectionFactoryAndQueue.");
		if (this.jmsConnectionFactory == null) {
			jmsConnectionFactory = ServiceLocator.getLookUpJndiObject(
					JNDIConstants.JmsFactory, ConnectionFactory.class);
		}
		if (this.queue == null) {
			queue = ServiceLocator.getLookUpJndiObject(queueName, Queue.class);
		}
		printLogMessage("end protected function buildConnectionFactoryAndQueue.");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
