package jp.co.nec.lsm.tma.servlet;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.SystemConfigNamespace;
import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tm.common.util.Version;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;
import jp.co.nec.lsm.tma.service.sessionbean.AggregationInitializationBean;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class TMAInitializationServletTest {
	private TransactionManagerHelper tmHelper;
	@Resource
	private AggregationInitializationBean bean;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;

	private Properties properties = new Properties();

	private void setMockMethod() {
		new MockUp<ServiceLocator>() {
			@SuppressWarnings( { "unchecked" })
			@Mock
			public <T> T getLookUpJndiObject(String jndiName, Class<T> clazz) {
				T t = null;
				if ("aggregationmanager/AggregationInitializationBean/local"
						.equals(jndiName)) {
					t = (T) bean;
				}
				return t;
			}
		};
	}

	private void setMockMethodJMS() {
		new MockUp<AggregationInitializationBean>() {
			@Mock
			public void removeJmsMessage(String queueName) {
				return;
			}

			@Mock
			public void startTimer() {
				return;
			}

			@Mock
			private void notifyHeartbeatPollTimerService() {
				return;
			}
		};

		new MockUp<Version>() {
			@Mock
			public String readVersion(String warFile, String groupId,
					String artifactId) {
				return "1.0";
			}
		};

		new MockUp<AggregationInitializationBean>() {
			@Mock
			public void init() {
				return;
			}
		};

	}

	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Test
	public void testTMAInitialization() throws ServletException {

		try {
			setMockMethod();
			setMockMethodJMS();

			// 1 - clear database to avoid disturbing
			jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");
			jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
			tmHelper = new TransactionManagerHelper(manager, dataSource, TMType.TMA);
			jdbcTemplate = new JdbcTemplate(dataSource);
			try {
				InputStream is = ConfigProperty.class.getClassLoader()
						.getResourceAsStream(
								SystemConfigNamespace.TM
										.getDefaultPropertiesFilename());
				properties.load(is);
				is.close();
			} catch (IOException e) {
			}

			TMAInitializationServlet initServlet = new TMAInitializationServlet();
			initServlet.init();

			SystemConfigHelper helper = new SystemConfigHelper(manager);
			Set<Entry<Object, Object>> entrySet = properties.entrySet();
			for (Entry<Object, Object> e : entrySet) {
				String key = (String) e.getKey();
				String value = properties.getProperty(key);
				assertEquals(helper.getTMProperty(key), value);
			}

			TransactionManagerEntity tm = tmHelper.createOrLookup(DateUtil
					.getCurrentDate());

			// 2 - assert concerning information
			assertNotNull(tm);
			assertNotNull(tm.getLastHeartbeatTs());
			assertNotNull(tm.getLastPollTs());
			assertEquals(TmState.WORKING, tm.getState());

		} finally {
			jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
			jdbcTemplate.execute("commit");
		}

	}

}
