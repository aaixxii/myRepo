package jp.co.nec.lsm.tma.servlet.debug;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;

/**
 * @author dongqk <br>
 * 
 */
public class TMABatchJobStatusServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8383145556418812766L;

	/**
	 * 
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String str = BatchSegmentJobManager
				.printBatchSegmentJobMap(BatchSegmentJobManager.getInstance()
						.getBatchSegmentJobMaps());
		resp.getWriter().write(str);
		resp.getWriter().close();
	}

	/**
	 * 
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
}
