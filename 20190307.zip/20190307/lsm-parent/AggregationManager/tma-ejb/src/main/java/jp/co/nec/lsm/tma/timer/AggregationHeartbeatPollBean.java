package jp.co.nec.lsm.tma.timer;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tma.db.dao.AggregationSystemConfigDao;
import jp.co.nec.lsm.tma.db.dao.AggregationTransactionManagerDao;
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationHeartbeatPollBean  {
	
	private static Logger log = LoggerFactory
	.getLogger(AggregationHeartbeatPollBean.class);	

	@PersistenceContext(unitName = "tma-unit")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	AggregationTransactionManagerDao dao;
	
	public AggregationHeartbeatPollBean() {
		
	}
	
	@PostConstruct
	public void init() {
		dao = new AggregationTransactionManagerDao(entityManager);
	}


	public void poll() {
		printLogMessage("poll() is called.");

		StopWatch t = new StopWatch();
		t.start();
		
		dao.createOrLookup();
		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_AGGREGATION_HEARTBEAT_POLL_BEAN,
				LogConstants.FUNCTION_POLL, t.getTime());
	}
	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
