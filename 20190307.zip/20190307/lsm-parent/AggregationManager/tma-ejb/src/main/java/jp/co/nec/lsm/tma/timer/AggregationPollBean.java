package jp.co.nec.lsm.tma.timer;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.communication.BSJobStatus;
import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.ReSendable;
import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobDBStatus;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobQueueEntity;
import jp.co.nec.lsm.tma.common.constants.AggregationErrorMessage;
import jp.co.nec.lsm.tma.common.util.AggregationEventBus;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.db.dao.AggregationBatchJobDao;
import jp.co.nec.lsm.tma.db.dao.AggregationSystemConfigDao;

/**
 * @author liuyq <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationPollBean  {
	private static Logger log = LoggerFactory
			.getLogger(AggregationPollBean.class);

	@PersistenceContext(unitName = "tma-unit")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private AggregationSystemConfigDao sysConfigDao;

	
	private AggregationBatchJobDao aggregationBatchJobDao;

	/**
	 * constructor
	 */
	public AggregationPollBean() {		
	}

	@PostConstruct
	public void init() {
		printLogMessage("CNTR: AggregationPollBean init");
		sysConfigDao = new AggregationSystemConfigDao(entityManager, dataSource);
		aggregationBatchJobDao = new AggregationBatchJobDao(dataSource, entityManager);
	}

	/**
	 * here check the batch segment job timeout if timeout raise a timeout event
	 * to notify TMI to re delivery this batch segment job
	 */
	public void poll() {
		printLogMessage("poll() is started...");

		StopWatch t = new StopWatch();
		t.start();

		// set start time
		try {
			setStartTime();
		} catch (Exception e) {
			log.error("error occured while set start time.", e);
		}

		// check batch job timeout
		try {
			checkAllBatchJobsTimeout();
		} catch (Exception e) {
			log.error("error occured while check batch job timeout.", e);
		}

		// Verify that the BatchJob had been done , if had done
		checkBatchJobCompletion();

		printLogMessage("poll() is finished...");

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_POLL_SERVICE_BEAN,
				LogConstants.FUNCTION_POLL, t.getTime());
	}

	/**
	 * 
	 */
	private void setStartTime() {
		Map<Long, BatchSegmentJobMap> batchSegmentJobMaps = BatchSegmentJobManager
				.getInstance().getBatchSegmentJobMaps();
		List<IdentifyBatchJobQueueEntity> allRunningBatchJobs = aggregationBatchJobDao
				.getAllRunningBatchJobs(IdentifyBatchJobDBStatus.RUNNING);

		for (int i = 0, size = allRunningBatchJobs.size(); i < size; i++) {
			IdentifyBatchJobQueueEntity batchJob = allRunningBatchJobs.get(i);
			if (null == batchJob) {
				continue;
			}
			BatchSegmentJobMap batchSegmentJobMap = batchSegmentJobMaps
					.get(batchJob.getBatchjobId());
			if (null != batchSegmentJobMap
					&& null == batchSegmentJobMap.getStartTime()) {
				batchSegmentJobMap.setStartTime(batchJob.getStartTs());
			}
		}
	}

	/**
	 * 
	 */
	private void checkAllBatchJobsTimeout() {
		Date now = DateUtil.getCurrentDate();
		// get batch job limit time from DB
		long defaultBatchJobTimeout = sysConfigDao.getTMaBatchJobTimeout();
		if (defaultBatchJobTimeout < 0) {
			return;
		}

		// get batch job limit rerun times From DB
		int reRunLimit = sysConfigDao.getTMaBatchJobReRunLimit();
		if (reRunLimit < 0) {
			return;
		}

		Collection<BatchSegmentJobMap> batchSegmentJobMaps = BatchSegmentJobManager
				.getInstance().getBatchSegmentJobMaps().values();

		for (BatchSegmentJobMap jobMap : batchSegmentJobMaps) {
			// batch job start time -> receive batchSegmentJobMap start time
			if (jobMap.getStartTime() == null) {
				printLogMessage("batchjob id: {}, find start time null..",
						jobMap.getbJobId());
				continue;
			}
			long batchJobTimeout = jobMap.getTimeOut() <= 0 ? defaultBatchJobTimeout
					: jobMap.getTimeOut();

			if (isNeededToTimeoutBatchJob(now, batchJobTimeout,
					jobMap.getStartTime(), jobMap.getBatchJobStatus())) {
				checkBatchJobTimeout(jobMap, batchJobTimeout, reRunLimit);
			}
		}
	}

	/**
	 * check this BatchJob is needed to TimeOut
	 * 
	 * @param now
	 * @param batchJobTimeout
	 * @param batchStartTime
	 * @param batchJobStatus
	 * @return
	 */
	private boolean isNeededToTimeoutBatchJob(Date now, long batchJobTimeout,
			Date batchStartTime, BatchJobMapStatus batchJobStatus) {
		// check now - timeout >= batchStartTime and status != done
		return now.getTime() - batchJobTimeout >= batchStartTime.getTime()
				&& batchJobStatus != BatchJobMapStatus.TMA_WORKING_DONE;
	}

	/**
	 * poll to check is there any Completed batch job <br>
	 * if done call notifyBatchJobDone
	 */
	private void checkBatchJobCompletion() {
		BatchSegmentJobManager queueManager = BatchSegmentJobManager
				.getInstance();

		Collection<IdentifyResult> identifyResults = queueManager
				.getIdentifyResults().values();

		for (IdentifyResult identifyResult : identifyResults) {
			long batchJobId = identifyResult.getBatchJobId();
			if (queueManager.isBatchJobDone(batchJobId)
					&& !queueManager.isSendDoneEvent(batchJobId)) {
				queueManager.setBatchJobStatus(batchJobId,
						BatchJobMapStatus.TMA_WORKING_DONE);
				queueManager.changeSendDoneEventFlag(batchJobId, true);
				AggregationEventBus.notifyBatchjobDone(batchJobId);
				if (log.isInfoEnabled()) {
					log.info(InfoLogger.infoOutput(
							LogConstants.INFO_AGGREGATION_MERGE_BSJ_SCORE,
							LogConstants.FUNCTION_MERGE_IDENTIFYRESULT,
							LogConstants.DETAIL_BATCH_JOB_ID,
							String.valueOf(batchJobId),
							LogConstants.DETAIL_READ_COUNT,
							String.valueOf(identifyResult.getReadCount()),
							"DETAIL",
							"send batchJobId which had done from IdentifySyncAggregationServiceBean "
									+ "to IdentifyBatchJobResultServiceBean..."));
				}
			}
		}
	}

	/**
	 * BatchJob Timeout
	 * 
	 * @param jobMap
	 * @param timeout
	 * @param reRunLimit
	 */
	private void checkBatchJobTimeout(BatchSegmentJobMap jobMap, long timeout,
			int reRunLimit) {
		// TimeOut time cut half
		jobMap.setTimeOut(timeout >> 1);
		// failureCount + 1
		int currentFailureCount = jobMap.getFailureCount() + 1;
		jobMap.setFailureCount(currentFailureCount);

		Collection<SegmentMap> segmentMaps = jobMap.getSegmentMaps().values();
		StringBuffer segmentIds = new StringBuffer();
		segmentIds.append("[");
		for (SegmentMap segmentMap : segmentMaps) {
			if (segmentMap.getBSJobStatus() != BSJobStatus.DONE) {
				segmentMap.setFailureCount(currentFailureCount);

				segmentIds.append("{");
				segmentIds.append(segmentMap.getSegmentId());
				segmentIds.append("},");
			}
		}
		if (segmentIds.length() > 1) {
			segmentIds.setCharAt(segmentIds.length() - 1, ']');
		} else {
			segmentIds.append("]");
		}

		if (currentFailureCount < reRunLimit) {
			log.warn(getSegmentSummary(jobMap.getbJobId(), currentFailureCount,
					segmentIds.toString()));
			notOverReRunLimit(jobMap);
		} else {
			overReRunLimit(jobMap);
		}
	}

	/**
	 * 
	 * @param batchJobId
	 * @param currentFailureCount
	 * @param segmentIds
	 * @return
	 */
	private String getSegmentSummary(long batchJobId, int currentFailureCount,
			String segmentIds) {
		StringBuffer msg = new StringBuffer();
		msg.append(LogConstants.KEY_CATEGORY);
		msg.append(LogConstants.KEY_VALUE_SEPARATOR);
		msg.append(LogConstants.KEY_WARN);
		msg.append(LogConstants.LOG_ITEM_SEPARATOR);
		msg.append(LogConstants.KEY_INFO_TYPE);
		msg.append(LogConstants.KEY_VALUE_SEPARATOR);
		msg.append(LogConstants.DETAIL_IDENTIFY_BATCH_JOB_REDELIVERY);
		msg.append(LogConstants.LOG_ITEM_SEPARATOR);
		msg.append(LogConstants.KEY_BATCH_JOB_ID);
		msg.append(LogConstants.KEY_VALUE_SEPARATOR);
		msg.append(batchJobId);
		msg.append(LogConstants.LOG_ITEM_SEPARATOR);
		msg.append(LogConstants.DETAIL_FAILURE_COUNT);
		msg.append(LogConstants.KEY_VALUE_SEPARATOR);
		msg.append(currentFailureCount);
		msg.append(LogConstants.LOG_ITEM_SEPARATOR);
		msg.append(LogConstants.DETAIL_RETRY_SEGMENT_IDS);
		msg.append(LogConstants.KEY_SEPARATOR);
		msg.append(segmentIds.toString());
		return msg.toString();
	}

	/**
	 * timeout failureCount is not over reRunLimit
	 * 
	 * @param batchSegmentJobMap
	 */
	private void notOverReRunLimit(BatchSegmentJobMap batchSegmentJobMap) {
		batchSegmentJobMap.setBatchJobStatus(BatchJobMapStatus.WARNING);

		// send BatchSegmentJobMap to TMI from TMA by JMS
		String tmiIpAddress = sysConfigDao.getTmiIpAddress();
		AggregationEventBus.sendBatchSegmentJobMapToTMI(batchSegmentJobMap,
				tmiIpAddress);

		batchSegmentJobMap.setStartTime(DateUtil.getCurrentDate());
		batchSegmentJobMap.setBatchJobStatus(BatchJobMapStatus.RUNNING);

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_POLL_SERVICE_BEAN,
					LogConstants.FUNCTION_POLL, "DETAIL",
					"notify event from TMA to TMI..."));
		}
	}

	/**
	 * timeout failureCount is over reRunLimit
	 * 
	 * @param batchSegmentJobMap
	 */
	private void overReRunLimit(BatchSegmentJobMap batchSegmentJobMap) {
		batchSegmentJobMap
				.setBatchJobStatus(BatchJobMapStatus.OVER_RETRY_LIMIT);

		// set all job failure
		IdentifyResult identifyResult = BatchSegmentJobManager.getInstance()
				.getIdentifyResult(batchSegmentJobMap.getbJobId());
		if (null == identifyResult) {
			log.warn("BatchjobId: {}, find IdentifyResult"
					+ " from aggregation memory queue null..",
					batchSegmentJobMap.getbJobId());
			return;
		}

		Int2ObjectArrayMap<IdentifyJobResult> jobResults = identifyResult
				.getSearchJobResults();

		for (Entry<Integer, IdentifyJobResult> entry : jobResults.entrySet()) {
			IdentifyJobResult jobResult = entry.getValue();
			if (null != jobResult) {
				jobResult.setReturnCode(ReturnCode.JobFailed);
				jobResult.setErrorCode(AggregationErrorMessage.RETRY_TIMES_OVER
						.getErrorCode());
				// let ReSendable flag to YES
				jobResult.setResendable(ReSendable.YES);
				jobResult.setErrorMessage("Identify Job ( Aggregation "
						+ "batchjob timeout over retry times.. ) ");
			} else {
				log.warn("batch job id {}, jobResult is null..",
						batchSegmentJobMap.getbJobId());
			}
		}

		String endPoint = sysConfigDao.getPostToTransformerUrl();
		Integer timeout = sysConfigDao.getTransformerPostTimeout();

		// 2. send IdentifyResponse Object to Transformer
		AggregationEventBus.sendIdentifyResponseToTransformer(identifyResult,
				endPoint, timeout);

		// 3. send BatchSegmentJobMap which had done to TMI by JMS
		String tmiIpAddress = sysConfigDao.getTmiIpAddress();
		AggregationEventBus.sendBatchSegmentJobMapToTMI(batchSegmentJobMap,
				tmiIpAddress);

		// remove from memory queue
		BatchSegmentJobManager.getInstance().remove(
				batchSegmentJobMap.getbJobId());
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
