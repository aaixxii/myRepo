package jp.co.nec.lsm.tma.db.dao;

import java.util.Date;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;

/**
 * @author dongqk <br>
 *
 */

public class AggregationTransactionManagerDao {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationTransactionManagerDao.class);

	
	private EntityManager manager;
	private TransactionManagerHelper tmaHelper;
	
	/**
	 * constructor
	 */
	public AggregationTransactionManagerDao(EntityManager manager) {
		this.manager = manager;
		tmaHelper = new TransactionManagerHelper(manager, TMType.TMA);
	}	

	public void setStartupTime() {
		printLogMessage("start public function setStartupTime()..");

		Date now = DateUtil.getCurrentDate();		
		TransactionManagerEntity ame = tmaHelper.createOrLookupVersion(now, TMaVersion.readVersion());
		// set start time
		ame.setLastHeartbeatTs(now);
		manager.persist(ame);

		printLogMessage("end public function setStartupTime()..");
	}

	public TransactionManagerEntity createOrLookup() {
		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity tma = tmaHelper
				.createOrLookupVersion(now,TMaVersion.readVersion());
		tma.setState(TmState.WORKING);
		tma.setLastHeartbeatTs(now);
		tma.setLastPollTs(now);
		manager.merge(tma);
		manager.flush();

		return tma;
	}
	
	public void changeTMAToExit() {
		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity ame = tmaHelper.createOrLookupVersion(now, TMaVersion.readVersion());
		ame.setState(TmState.EXITED);
		ame.setLastHeartbeatTs(now);
		ame.setLastPollTs(now);
		manager.merge(ame);
		manager.flush();
		return;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
	
	public TransactionManagerEntity createOrLookupVersion(Date now) {
		return createOrLookup();
	}

}
