package jp.co.nec.lsm.tma.db.dao;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;

/**
 * @author dongqk <br>
 * 
 */

public class AggregationSystemConfigDao{

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationSystemConfigDao.class);
	
	
	private SystemConfigHelper sysConfigHelper;
	
	private DataSource dataSource;
	
	/**
	 * constructor
	 */
	public AggregationSystemConfigDao(EntityManager manager, DataSource dataSource) {
		this.dataSource = dataSource;		
		sysConfigHelper = new SystemConfigHelper(manager);
	}
	

	
	public void writeAllMissingProperties() {
		printLogMessage("start public function writeAllMissingProperties()..");

		sysConfigHelper.writeAllMissingProperties(dataSource);

		printLogMessage("end public function writeAllMissingProperties()..");

	}


	
	public Long getTMaBatchJobTimeout() {
		return sysConfigHelper
				.getTMPropertyLong(ConfigProperty.TIMEOUTS_TMA_BATCHJOB);
	}
	
	public Integer getTMaBatchJobReRunLimit() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.RERUNLIMIT_TMA_BATCHJOB);
	}

	public String getPostToTransformerUrl() {
		return sysConfigHelper.getTMProperty(ConfigProperty.IDENTIFY_POST_URL);
	}

	public String getTmiIpAddress() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TMI_IP_ADDRESS);
	}
	
	public String getTmaIpAddress() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TMA_IP_ADDRESS);
	}

	public Integer getTransformerPostTimeout() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.TRANSFORMER_POST_CONNECT_TIMEOUT);
	}

	public String getTMAWebPort()
	{
		return sysConfigHelper
		.getTMProperty(ConfigProperty.TMA_WEB_PORT_NUM);
	}
	public int getHeartbeatPollingDuration()
	{
		return sysConfigHelper
		.getTMPropertyInt(ConfigProperty.TM_HEAERBEAT_POLLING_DURATION);
	}
	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
