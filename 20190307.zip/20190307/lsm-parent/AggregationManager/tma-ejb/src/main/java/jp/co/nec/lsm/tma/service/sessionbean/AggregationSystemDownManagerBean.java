package jp.co.nec.lsm.tma.service.sessionbean;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tma.db.dao.AggregationTransactionManagerDao;

/**
 * @author dongqk <br>
 *
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationSystemDownManagerBean  {

	private static final Logger log = LoggerFactory
			.getLogger(AggregationSystemDownManagerBean.class);
	
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	
	private AggregationTransactionManagerDao transactionManagerDao;

	/**
	 * constructor
	 */
	public AggregationSystemDownManagerBean() {		
	}
	
	@PostConstruct
	public void init() {
		transactionManagerDao = new AggregationTransactionManagerDao(entityManager, dataSource);		
	}

	/**
	 * TMI shutdown process.
	 */
	public void shutdown() {
		printLogMessage("start public function shutdown.");

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_SYSTEM_DOWN_MANAGER_TMA,
					LogConstants.FUNCTION_SHUT_DOWN, "DETAIL",
					"called in AggregationSystemDownManagerBean"));
		}

		// change TMA Status To Exit
		transactionManagerDao.changeTMAToExit();

		printLogMessage("end public function shutdown.");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
