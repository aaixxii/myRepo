package jp.co.nec.lsm.tma.core.score;

import java.util.Arrays;
import java.util.Comparator;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tma.common.util.TMASwitchUtil;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.core.merger.TopLevelInfoMerger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 */
public class TopLevelCandidateMergerLimitTest {

	private static long bJobIdStart = 10000;
	private final static int jobIdStart = 0;
	private final static int bJobCount = 2;
	private final static int jobCount = 100;
	private final static int segmentCount = 2000;
	private final static int segmentEachCount = 10;

	private BatchSegmentJobManager queueManager;

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	/**
	 * All job: Candidate size = 0, maxCandidate = 0
	 */
	@Test
	public void testCandidateSize0MaxCandidate0() {
		// init
		int maxCandidate = 0;
		int[] initMemoryScoresEmpty = {};
		int[] mergeScoresEmpty = {};
		//
		test(initMemoryScoresEmpty, maxCandidate, mergeScoresEmpty);
		// assert
		for (int i = 0; i < jobCount; i++) {
			// expectedMergedValues Scores
			int[] mergedScores = getMergedScoreFromMemory(bJobIdStart,
					initMemoryScoresEmpty.length, jobIdStart + i);
			// check
			Assert.assertArrayEquals(mergeScoresEmpty, mergedScores);
		}
	}

	/**
	 * All job: Candidate size = 0, maxCandidate = 1
	 */
	@Test
	public void testCandidateSize0MaxCandidate1() {
		// init
		int maxCandidate = 1;
		int[] initMemoryScoresEmpty = {};
		int[] mergeScoresEmpty = {};
		//
		test(initMemoryScoresEmpty, maxCandidate, mergeScoresEmpty);
		// assert
		for (int i = 0; i < jobCount; i++) {
			// expectedMergedValues Scores
			int[] mergedScores = getMergedScoreFromMemory(bJobIdStart,
					initMemoryScoresEmpty.length, jobIdStart + i);
			// check
			Assert.assertArrayEquals(mergeScoresEmpty, mergedScores);
		}
	}

	/**
	 * All job: Candidate size = 1, maxCandidate = 0
	 */
	@Test
	public void testCandidateSize1MaxCandidate0() {
		// init
		int maxCandidate = 0;
		int maxScore = 1000;
		int minScore = 1;
		int[] initMemoryScores = initMemoryScores(maxCandidate);
		int[] mergeScores = UtilCreateData.createScores(maxCandidate, maxScore,
				minScore);
		//
		test(initMemoryScores, maxCandidate, mergeScores);
		// assert
		for (int i = 0; i < jobCount; i++) {
			// expectedMergedValues Scores
			int[] mergedScores = getMergedScoreFromMemory(bJobIdStart,
					initMemoryScores.length, jobIdStart + i);
			// check
			Assert.assertArrayEquals(mergeScores, mergedScores);
		}
	}

	/**
	 * All job: Candidate size = 255, maxCandidate = 255
	 */
	@Test
	public void testCandidateSize255MaxCandidate255() {

		bJobIdStart = 13123;

		// init
		int maxCandidate = 255;
		int maxScore = 1000;
		int minScore = 1;
		int[] initMemoryScores = initMemoryScores(maxCandidate);
		int[] mergeScores = UtilCreateData.createScores(maxCandidate, maxScore,
				minScore);
		//
		test(initMemoryScores, maxCandidate, mergeScores);
		// assert
		// for (int i = 0; i < jobCount; i++) {
		// expectedMergedValues Scores
		int[] mergedScores = getMergedScoreFromMemory(bJobIdStart,
				initMemoryScores.length, jobIdStart);

		Arrays.sort(mergeScores);
		Arrays.sort(mergedScores);

		// check
		Assert.assertArrayEquals(mergeScores, mergedScores);

		// }

		bJobIdStart = 10000;
	}

	/**
	 * All job: Candidate size = 256, maxCandidate = 255
	 */
	@Test
	public void testCandidateSize256MaxCandidate255() {
		bJobIdStart = 132323;
		// init
		int maxCandidate = 255;
		int maxScore = 1000;
		int minScore = 1;
		int overMaxCandidateSize = 1;
		int[] initMemoryScores = initMemoryScores(maxCandidate);
		int[] mergeScores = UtilCreateData.createScores(maxCandidate
				+ overMaxCandidateSize, maxScore, minScore);
		//
		test(initMemoryScores, maxCandidate, mergeScores);
		// assert
		// for (int i = 0; i < jobCount; i++) {
		// expectedMergedValues Scores
		int[] mergedScores = getMergedScoreFromMemory(bJobIdStart,
				initMemoryScores.length, jobIdStart);

		Arrays.sort(mergeScores);
		Arrays.sort(mergedScores);

		// check
		int[] originalScore = Arrays.copyOfRange(mergeScores, 1,
				mergeScores.length);
		Assert.assertArrayEquals(originalScore, mergedScores);

		bJobIdStart = 10000;
	}

	/**
	 * 
	 * @param initMemoryScores
	 * @param maxCandidate
	 * @param mergeScores
	 */
	private void test(int[] initMemoryScores, int maxCandidate,
			int[] mergeScores) {
		// create memory data
		createMemoryQueue(initMemoryScores, maxCandidate);

		Assert.assertNotNull(queueManager.getIdentifyResult(bJobIdStart));

		// create merge data
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(bJobIdStart, jobIdStart, jobCount,
						mergeScores, segmentEachCount, maxCandidate);

		// merge
		TopLevelInfoMerger.mergeTopLevel(queueManager
				.getIdentifyResult(bJobIdStart), TMASwitchUtil
				.switchIdentifyResult(identifyResult));
	}

	/**
	 * 
	 * @param memoryScores
	 * @param maxCandidate
	 */
	private void createMemoryQueue(int[] memoryScores, int maxCandidate) {
		// create memory data
		IdentifyResult identifyResult = null;
		for (int i = 0; i < bJobCount; i++) {
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart + i, jobIdStart, jobCount, memoryScores,
					segmentCount, maxCandidate);

			queueManager.add(identifyResult);
			identifyResult = null;
		}

		Assert
				.assertEquals(bJobCount, queueManager.getIdentifyResults()
						.size());
		Assert.assertEquals(segmentCount, queueManager.getSegmentIds(
				bJobIdStart).size());
		Assert.assertEquals(jobCount, queueManager.getIdentifyResult(
				bJobIdStart).getSearchJobResults().size());
	}

	/**
	 * 
	 * @param batchJobId
	 * @param initMemoryScoresSize
	 * @param jobIndex
	 * @return
	 */
	private int[] getMergedScoreFromMemory(long batchJobId,
			int initMemoryScoresSize, int jobIndex) {
		IdentifyResult identifyResult = queueManager
				.getIdentifyResult(batchJobId);
		Object[] cs = TMASwitchUtil.switchCandidates(identifyResult
				.getSearchJobResults().get(jobIdStart).getCandidates());

		Integer[] mergedScores = new Integer[initMemoryScoresSize];
		for (int i = 0; i < initMemoryScoresSize; i++) {
			mergedScores[i] = ((Candidate) cs[i]).getScaledScore();
		}
		Arrays.sort(mergedScores, new ScoreComparator());

		int[] newArray = new int[mergedScores.length];
		for (int i = 0; i < mergedScores.length; i++) {
			newArray[i] = mergedScores[i].intValue();
		}

		return newArray;
	}

	/**
	 * 
	 * @param maxCandidate
	 * @return
	 */
	private int[] initMemoryScores(int maxCandidate) {
		int[] initMemorySocres = new int[maxCandidate];
		for (int i = 0; i < maxCandidate; i++) {
			initMemorySocres[i] = Integer.MIN_VALUE;
		}
		return initMemorySocres;
	}
}

/**
 * sort ScaledScore desc
 */
class ScoreComparator implements Comparator<Integer> {
	public int compare(Integer c1, Integer c2) {
		return c1 < c2 ? 1 : 0;
	}
}
