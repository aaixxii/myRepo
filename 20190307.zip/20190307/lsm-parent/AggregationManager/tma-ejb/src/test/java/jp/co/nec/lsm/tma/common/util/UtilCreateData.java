package jp.co.nec.lsm.tma.common.util;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.longs.LongArraySet;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.communication.BSJobStatus;
import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.ReSendable;
import jp.co.nec.lsm.tm.common.communication.SearchJobInfo;
import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidate;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBScore;
import com.nec.everest.proto.protobuf.BusinessMessage.E_MODALITY_TYPE;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

public class UtilCreateData {

	/**
	 * 
	 * @param size
	 * @param max
	 * @param min
	 * @return
	 */
	public static int[] createScores(int size, int max, int min) {
		Integer[] scores = new Integer[size];
		for (int i = 0; i < size; i++) {
			scores[i] = Math.round((float) Math.random() * max) + min - 1; // minScore~maxScore
		}
		Arrays.sort(scores, new ScoreComparator());
		int[] newArray = new int[scores.length];
		for (int i = 0; i < scores.length; i++) {
			newArray[i] = scores[i].intValue();
		}
		return newArray;
	}

	/**
	 * create CPBCandidate List, sort ScaledScore desc
	 * 
	 * @param candidateSize
	 * @param scoreComparator
	 * @return
	 */
	public static ObjectArrayList<Candidate> createCandidatesData(
			int candidateSize, CandidateScoreComparator scoreComparator,
			int maxScore, int minScore) {
		int[] scores = createScores(candidateSize, maxScore, minScore);
		return createCandidatesData(scores, scoreComparator);
	}

	/**
	 * create CPBCandidate List, sort ScaledScore desc
	 * 
	 * @param candidateSize
	 * @param scoreComparator
	 * @return
	 */
	public static ObjectArrayList<Candidate> createCandidatesData(int[] scores,
			CandidateScoreComparator scoreComparator) {
		ObjectArrayList<Candidate> candidates = new ObjectArrayList<Candidate>(
				scores.length);
		for (int i = 0; i < scores.length; i++) {
			Candidate.Builder candidateBuilder = Candidate.newBuilder();
			candidateBuilder.setReferenceId("ReferenceId-"
					+ UUID.randomUUID().toString());
			candidateBuilder.setScaledScore(scores[i]);

			CPBCandidate.Builder candidate = candidateBuilder
					.getModalScoreBuilder();
			candidate.setEnrollmentId(
					"ReferenceId-" + UUID.randomUUID().toString())
					.setScaledScore(scores[i]).addScore(
							CPBScore.newBuilder().setModalityType(
									E_MODALITY_TYPE.FACE).setValue("0")
									.setModalitySubType("").setBufferValue1("")
									.build()).addScore(
							CPBScore.newBuilder().setModalityType(
									E_MODALITY_TYPE.FINGER).setValue("0")
									.setModalitySubType("").setBufferValue1("")
									.build()).addScore(
							CPBScore.newBuilder().setModalityType(
									E_MODALITY_TYPE.IRIS).setValue("0")
									.setModalitySubType("").setBufferValue1("")
									.build());
			candidates.add(candidateBuilder.build());
		}
		Collections.sort(candidates, scoreComparator);
		return candidates;
	}

	/**
	 * create CPBCandidate List, sort ScaledScore desc
	 * 
	 * @param candidateSize
	 * @return
	 */
	public static ObjectArrayList<Candidate> createCandidatesData(int[] scores) {
		return createCandidatesData(scores, new CandidateScoreComparator());
	}

	/**
	 * create CPBCandidate List, sort ScaledScore desc
	 * 
	 * @param candidateSize
	 * @return
	 */
	public static ObjectArrayList<Candidate> createCandidatesData(
			int candidateSize) {
		return createCandidatesData(candidateSize,
				new CandidateScoreComparator(), 1000, 0);
	}

	/**
	 * create IdentifyResult data
	 * 
	 * @param batchJobId
	 * @param jobIdStart
	 * @param jobCount
	 * @param candidateSize
	 * @return
	 */
	public static IdentifyResult createIdentifyResultData(long batchJobId,
			int jobIdStart, int jobCount, int candidateSize,
			long segmentIdStart, int segmentIdCount, int maxCandiate,
			ReSendable reSendable) {
		Int2ObjectArrayMap<IdentifyJobResult> jobResultInfos = new Int2ObjectArrayMap<IdentifyJobResult>(
				jobCount);

		CandidateScoreComparator scoreComparator = new CandidateScoreComparator();

		int maxScore = 900;
		int minScore = 100;
		int remainder;

		List<Integer> aaList = Arrays.asList(1, 2, 3, 4, 5);
		List<Integer> bbList = Arrays.asList(6, 7, 8, 9, 10);
		List<Integer> ccList = Arrays.asList(10, 11, 13, 16, 17, 19);

		for (int jobIndex = jobIdStart; jobIndex < jobCount + jobIdStart; jobIndex++) {
			remainder = Math.round((float) Math.random() * 1000)
					% (jobIndex + 1);
			if (aaList.contains(remainder)) {
				maxScore = 99;
				minScore = 0;
			} else if (bbList.contains(remainder)) {
				maxScore = 200;
				minScore = 100;
			} else if (ccList.contains(remainder)) {
				maxScore = 400;
				minScore = 300;
			} else {
				maxScore = 900;
				minScore = 700;
			}

			int candidateSizeNow = candidateSize;
			if (jobIndex % 5 == 0) {
				candidateSizeNow = candidateSize + 4;
			} else {
				candidateSizeNow = candidateSize;
			}

			jobResultInfos.put(jobIndex, newSearchJobResult(jobIndex,
					new ObjectArrayList<Candidate>(createCandidatesData(
							candidateSizeNow, scoreComparator, maxScore,
							minScore)), maxCandiate, reSendable));
		}

		LongArraySet segmentIds = new LongArraySet(segmentIdCount);
		for (int i = 0; i < segmentIdCount; i++) {
			segmentIds.add(segmentIdStart++);
		}

		return new IdentifyResult(batchJobId, segmentIds, jobResultInfos, 0L);
	}

	/**
	 * create IdentifyResult Data
	 * 
	 * @param bJobId
	 * @param jobCount
	 * @param maxCandidate
	 * @param jobIdStart
	 * @return
	 * @throws IOException
	 */
	public static IdentifyResult createIdentifyResultData(long batchJobId,
			int jobCount, int candidateSize, long segmentIdStart,
			int segmentIdCount, int maxCandidate, ReSendable reSendable) {
		return createIdentifyResultData(batchJobId, 1, jobCount, candidateSize,
				segmentIdStart, segmentIdCount, maxCandidate, reSendable);
	}

	/**
	 * create IdentifyResult data
	 * 
	 * @param batchJobId
	 * @param jobIdStart
	 * @param jobCount
	 * @param scores
	 * @return
	 */
	public static IdentifyResult createIdentifyResultData(long batchJobId,
			int jobIdStart, int jobCount, int[] scores, int segmentCount,
			int maxCandidate) {
		return createIdentifyResultData(batchJobId, jobIdStart, jobCount,
				scores, segmentCount, maxCandidate, ReturnCode.JobSuccess,
				ReSendable.EMPTY);
	}

	/**
	 * create IdentifyResult data
	 * 
	 * @param batchJobId
	 * @param jobIdStart
	 * @param jobCount
	 * @param scores
	 * @return
	 */
	public static IdentifyResult createIdentifyResultData(long batchJobId,
			int jobIdStart, int jobCount, int[] scores, int segmentCount,
			int maxCandidate, ReturnCode returnCode, ReSendable reSendable) {
		String[] referenceIds = new String[scores.length];
		for (int i = 0; i < scores.length; i++) {
			referenceIds[i] = "ReferenceId-" + UUID.randomUUID().toString();
		}
		return createIdentifyResultData(batchJobId, jobIdStart, jobCount,
				referenceIds, scores, segmentCount, maxCandidate, returnCode,
				reSendable);
	}

	/**
	 * create IdentifyResult data
	 * 
	 * @param batchJobId
	 * @param jobIdStart
	 * @param jobCount
	 * @param scores
	 * @return
	 */
	public static IdentifyResult createIdentifyResultData(long batchJobId,
			int jobIdStart, int jobCount, String[] referenceIds, int[] scores,
			int segmentCount, int maxCandidate) {
		return createIdentifyResultData(batchJobId, jobIdStart, jobCount,
				referenceIds, scores, segmentCount, maxCandidate,
				ReturnCode.JobSuccess, ReSendable.EMPTY);
	}

	/**
	 * create IdentifyResult data
	 * 
	 * @param batchJobId
	 * @param jobIdStart
	 * @param jobCount
	 * @param scores
	 * @return
	 */
	public static IdentifyResult createIdentifyResultData(long batchJobId,
			int jobIdStart, int jobCount, String[] referenceIds, int[] scores,
			int segmentCount, int maxCandidate, ReturnCode returnCode,
			ReSendable reSendable) {
		Int2ObjectArrayMap<IdentifyJobResult> jobResultInfos = new Int2ObjectArrayMap<IdentifyJobResult>(
				jobCount);
		ObjectArrayList<Candidate> candidates;
		CandidateScoreComparator sc = new CandidateScoreComparator();
		for (int jobIndex = 0; jobIndex < jobCount; jobIndex++) {

			candidates = new ObjectArrayList<Candidate>(scores.length);
			for (int i = 0; i < scores.length; i++) {
				Candidate.Builder candidateBuilder = Candidate.newBuilder();
				candidateBuilder.setReferenceId(referenceIds[i]);
				candidateBuilder.setScaledScore(scores[i]);

				CPBCandidate.Builder candidate = candidateBuilder
						.getModalScoreBuilder();

				candidate.setEnrollmentId(referenceIds[i]).setScaledScore(
						scores[i]).addScore(
						CPBScore.newBuilder().setModalityType(
								E_MODALITY_TYPE.FACE).setValue("0")
								.setModalitySubType("").setBufferValue1("")
								.build()).addScore(
						CPBScore.newBuilder().setModalityType(
								E_MODALITY_TYPE.FINGER).setValue("0")
								.setModalitySubType("").setBufferValue1("")
								.build()).addScore(
						CPBScore.newBuilder().setModalityType(
								E_MODALITY_TYPE.IRIS).setValue("0")
								.setModalitySubType("").setBufferValue1("")
								.build());
				candidates.add(i, candidateBuilder.build());
			}
			Collections.sort(candidates, sc);

			IdentifyJobResult jobResult = newSearchJobResult(jobIndex
					+ jobIdStart, candidates, maxCandidate, returnCode,
					reSendable);

			jobResult.getaMRState().increaseFace(jobIndex);
			jobResult.getaMRState().increaseFinger(jobIndex);
			jobResult.getaMRState().increaseIris_left(jobIndex);
			jobResult.getaMRState().increaseIris_right(jobIndex * 2);
			jobResult.getaMRState().increasePassedF(jobIndex);
			jobResult.getaMRState().increasePassedS(jobIndex * 2);
			jobResult.getaMRState().increasePassedT(jobIndex * 3);

			jobResultInfos.put(jobIndex, jobResult);
		}

		LongArraySet segmentIds = new LongArraySet(segmentCount);
		for (int i = 1; i <= segmentCount; i++) {
			segmentIds.add(i);
		}

		return new IdentifyResult(batchJobId, segmentIds, jobResultInfos, 0L);
	}

	/**
	 * 
	 * @param jobIndex
	 * @param candidates
	 * @return
	 */
	private static IdentifyJobResult newSearchJobResult(int jobIndex,
			ObjectArrayList<Candidate> candidates, int maxCandidate,
			ReSendable reSendable) {
		return newSearchJobResult(jobIndex, candidates, maxCandidate,
				ReturnCode.JobSuccess, reSendable);
	}

	/**
	 * 
	 * @param jobIndex
	 * @param candidates
	 * @return
	 */
	private static IdentifyJobResult newSearchJobResult(int jobIndex,
			ObjectArrayList<Candidate> candidates, int maxCandidate,
			ReturnCode returnCode, ReSendable reSendable) {
		return new IdentifyJobResult(jobIndex, "RequestId-" + jobIndex,
				"ReferenceId-" + UUID.randomUUID().toString(), maxCandidate,
				returnCode, candidates, "", "", reSendable);
	}

	/**
	 * create BatchSegmentJobMap data
	 * 
	 * @param batchJobId
	 * @param jobCount
	 * @param maxCandidate
	 * @param segmentIdStart
	 * @param segmentCount
	 * @param muIdStart
	 * @param muCount
	 * @return
	 */
	public static BatchSegmentJobMap createBatchSegmentJobMapData(
			long batchJobId, int jobCount, int maxCandidate,
			long segmentIdStart, int segmentCount) {
		return createBatchSegmentJobMapData(batchJobId, 0, jobCount,
				maxCandidate, segmentIdStart, segmentCount);
	}

	/**
	 * create BatchSegmentJobMap data
	 * 
	 * @param batchJobId
	 * @param jobIdStart
	 * @param jobCount
	 * @param maxCandidate
	 * @param segmentIdStart
	 * @param segmentCount
	 * @return
	 */
	public static BatchSegmentJobMap createBatchSegmentJobMapData(
			long batchJobId, int jobIdStart, int jobCount, int maxCandidate,
			long segmentIdStart, int segmentCount) {
		List<SearchJobInfo> jobInfosToAMs = new ArrayList<SearchJobInfo>();
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();

		for (int j = jobIdStart; j < jobCount + jobIdStart; j++) {
			String referenceId = "ReferenceId-" + UUID.randomUUID().toString();
			jobInfosToAMs.add(new SearchJobInfo(j, "RequestId-"
					+ String.valueOf(j), referenceId, maxCandidate,
					ReturnCode.JobSuccess));

			CPBBusinessMessage.Builder buinessMsg = CPBBusinessMessage
					.newBuilder();
			buinessMsg.setRequest(CPBRequest.newBuilder().setRequestId(
					"RequestId-" + String.valueOf(j)).setEnrollmentId(
					referenceId).setRequestType(E_REQUESET_TYPE.CLEAR));

			businessMessageList.add(buinessMsg.build());
		}

		Map<Long, SegmentMap> segmentMaps = new ConcurrentHashMap<Long, SegmentMap>();

		long muId = segmentIdStart;
		for (long i = segmentIdStart; i < segmentIdStart + segmentCount; i++) {
			if (i % 10 == 0) {
				++muId;
			}
			segmentMaps.put(i, new SegmentMap(i, BSJobStatus.RUNNING, muId, 0,
					null, null, 0));
		}

		BatchSegmentJobMap batchSegmentJobMap = new BatchSegmentJobMap(
				batchJobId, jobInfosToAMs, segmentMaps, BatchJobMapStatus.WAIT);

		batchSegmentJobMap.setStartTime(DateUtil.getCurrentDate());
		batchSegmentJobMap.setBusinessMessages(businessMessageList);
		return batchSegmentJobMap;
	}

	/**
	 * create BatchSegmentJobMap data
	 * 
	 * @param batchJobId
	 * @param jobIdStart
	 * @param jobCount
	 * @param maxCandidate
	 * @param segmentIdStart
	 * @param segmentCount
	 * @return
	 */
	public static BatchSegmentJobMap createBatchSegmentJobMapData(
			long batchJobId, int jobIdStart, int jobCount, int maxCandidate,
			long segmentIdStart, int segmentCount, ReturnCode returnCode) {
		List<SearchJobInfo> jobInfosToAMs = new ArrayList<SearchJobInfo>();
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();

		for (int j = jobIdStart; j < jobCount + jobIdStart; j++) {
			String referenceId = "ReferenceId-" + UUID.randomUUID().toString();
			jobInfosToAMs
					.add(new SearchJobInfo(j, "RequestId-" + String.valueOf(j),
							referenceId, maxCandidate, returnCode));

			CPBBusinessMessage.Builder buinessMsg = CPBBusinessMessage
					.newBuilder();
			buinessMsg.setRequest(CPBRequest.newBuilder().setRequestId(
					"RequestId-" + String.valueOf(j)).setEnrollmentId(
					referenceId).setRequestType(E_REQUESET_TYPE.CLEAR));

			businessMessageList.add(buinessMsg.build());
		}

		Map<Long, SegmentMap> segmentMaps = new ConcurrentHashMap<Long, SegmentMap>();

		long muId = segmentIdStart;
		for (long i = segmentIdStart; i < segmentIdStart + segmentCount; i++) {
			if (i % 10 == 0) {
				++muId;
			}
			segmentMaps.put(i, new SegmentMap(i, BSJobStatus.RUNNING, muId, 0,
					null, null, 0));
		}

		BatchSegmentJobMap batchSegmentJobMap = new BatchSegmentJobMap(
				batchJobId, jobInfosToAMs, segmentMaps, BatchJobMapStatus.WAIT);

		batchSegmentJobMap.setStartTime(DateUtil.getCurrentDate());
		batchSegmentJobMap.setBusinessMessages(businessMessageList);
		return batchSegmentJobMap;
	}

}

/**
 * sort ScaledScore desc
 */
class ScoreComparator implements Comparator<Integer> {
	public int compare(Integer c1, Integer c2) {
		return c1 < c2 ? 1 : 0;
	}
}

/**
 * sort ScaledScore desc
 */
class CandidateScoreComparator implements Comparator<Candidate> {
	public int compare(Candidate c1, Candidate c2) {
		return c1.getScaledScore() < c2.getScaledScore() ? 1 : 0;
	}
}
