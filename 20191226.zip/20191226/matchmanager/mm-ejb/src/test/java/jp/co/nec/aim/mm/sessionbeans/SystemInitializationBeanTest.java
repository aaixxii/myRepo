package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.constants.EventLogLevel;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.procedure.InitExecutingJobCountProcedure;
import jp.co.nec.aim.mm.scheduler.QuartzManager;
import jp.co.nec.aim.mm.segment.sync.SyncThreadExecutor;
import jp.co.nec.aim.mm.sessionbeans.pojo.EventSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class SystemInitializationBeanTest {

	@Resource
	private SystemInitializationBean initBean;
	@Resource
	private DataSource dataSource;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private boolean exception;
	private String message;
	private String desc;
	private boolean startReport;
	private String scheduler;
	private ConfigProperties configProps;

	@Before
	public void setUp() throws Exception {
		configProps = ConfigProperties.getInstance();
		clearDB();

		intsertUnit();
		intsertInquiryJob();
		List<Map<String, Object>> listecc = jdbcTemplate
				.queryForList("select * from EXTRACT_COMPLETE_COUNT");
		if (listecc.size() == 0) {
			jdbcTemplate
					.update("insert into EXTRACT_COMPLETE_COUNT values(0,0)");
		}
		jdbcTemplate.execute("commit");

		exception = false;
		startReport = false;
		message = "";
		desc = "";
		scheduler = "";

		setMockMethod();
	}

	@After
	public void tearDown() throws Exception {
		clearDB();		
	}

	private void clearDB() {
		jdbcTemplate.update("UPDATE INQUIRY_TRAFFIC SET JOB_EXEC_COUNT = 0");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FUSION_JOBS");
		jdbcTemplate.execute("delete from CONTAINER_JOBS");
		jdbcTemplate.execute("delete from MATCH_MANAGERS");
		jdbcTemplate.execute("delete from MM_EVENTS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from LAST_ASSIGNED_MR");
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("commit");
	}

	private void intsertUnit() {
		for (int id = 1; id <= 3; id++) {
			jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
					+ " RING_LOCATION, STATE) values(" + id + ", '" + id
					+ "', " + id + ", 'WORKING')");
			jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
					+ " values(" + id + ", 1540651052)");
		}

		jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
				+ " ASSIGNED_TS) values(1, 1540651052)");
	}

	private void intsertInquiryJob() {
		String jqSQL = "insert into JOB_QUEUE(JOB_ID, PRIORITY, JOB_STATE,"
				+ " SUBMISSION_TS, ASSIGNED_TS, CALLBACK_STYLE, TIMEOUTS,"
				+ " FAILURE_COUNT, REMAIN_JOBS, FAMILY_ID)"
				+ " values(?, 5, ?, 1421206612748, ?, 0, 900000, ?, ?, ?)";

		String fjSQL = "insert into FUSION_JOBS(FUSION_JOB_ID, FUNCTION_ID,"
				+ " JOB_ID, SEARCH_REQUEST_INDEX) values(?, ?, ?, ?)";

		String cjSQL = "insert into CONTAINER_JOBS(CONTAINER_JOB_ID,"
				+ " CONTAINER_ID, FUSION_JOB_ID, MR_ID, ASSIGNED_TS, JOB_STATE,"
				+ " PLAN_ID) values(?, ?, ?, ?, ?, 1, ?)";

		for (int jobId = 1; jobId <= 3; jobId++) {
			jdbcTemplate.update(jqSQL, new Object[] { jobId, 1, 1540651052, 0,
					4, jobId });
			for (int fjId = 1; fjId <= 2; fjId++) {
				jdbcTemplate.update(fjSQL, new Object[] {
						(jobId - 1) * 2 + fjId, jobId, jobId, fjId });
				for (int cjId = 1; cjId <= 2; cjId++) {
					jdbcTemplate.update(cjSQL, new Object[] {
							(((jobId - 1) * 2 + fjId) - 1) * 2 + cjId, cjId,
							(jobId - 1) * 2 + fjId, jobId, 1540651052, jobId });
				}
			}
		}

		jdbcTemplate.update(jqSQL, new Object[] { 4, 1, 1540651052, 0, 4, 1 });
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		new MockUp<EventSender>() {
			@Mock
			public void sendEvent(String reasonCode, String eventType,
					Long unitId, String description, EventLogLevel level,
					Date date) {
				desc = description;
				return;
			}
		};

		new MockUp<ExceptionSender>() {
			@Mock
			private void send(String reasonCode, String msg, long jobId,
					long topLevelId, long unitId, Exception e) {
				message = msg;
				return;
			}
		};

		new MockUp<AMRReportBean>() {
			@Mock
			public void startReport() {
				startReport = true;
				return;
			}
		};

		new MockUp<QuartzManager>() {
			@Mock
			public synchronized void startScheduler() {
				scheduler = "startScheduler";
				if (exception) {
					throw new AimRuntimeException("startScheduler");
				}
				return;
			}

			@Mock
			public void shutdownScheduler() {
				scheduler = "shutdownScheduler";
				jdbcTemplate.execute("commit");
				if (exception) {
					throw new AimRuntimeException();
				}
				return;
			}
		};
	}

	@Test
	public void test_initializeAIM() {

		String ip = configProps
				.getPropertyValue(ConfigPropertyNames.MM_IP_ADDRESS);
		String uniqueId = ip;
		String connectUrl = "http://" + ip + ":8080/matchmanager";

		jdbcTemplate.execute("delete from MATCH_MANAGERS");
		jdbcTemplate.execute("commit");
		initBean.initializeAIM();

		jdbcTemplate.execute("commit");

		// Match Manager
		List<Map<String, Object>> listMM = jdbcTemplate
				.queryForList("select * from MATCH_MANAGERS");
		assertEquals(1, listMM.size());
		assertEquals(uniqueId, listMM.get(0).get("UNIQUE_ID").toString());
		assertEquals(connectUrl, listMM.get(0).get("CONTACT_URL").toString());
		assertEquals("WORKING", listMM.get(0).get("STATE").toString());
		// assertNotNull(listMM.get(0).get("VERSION"));

		// System Configure
		int sysCount = jdbcTemplate.queryForObject(
				"select count(*) from SYSTEM_CONFIG", Integer.class);
		assertEquals(EnumSet.allOf(MMConfigProperty.class).size(), sysCount);

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			if (i < 1) {
				assertEquals("1", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			} else {
				assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			}
		}

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " RESULT, RESULT_TS, FAILED_FLAG, FAILURE_COUNT,"
						+ " REMAIN_JOBS from JOB_QUEUE order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < 3; i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("0", listTLJ.get(i).get("JOB_STATE").toString());
			assertNull(listTLJ.get(i).get("ASSIGNED_TS"));
			assertNull(listTLJ.get(i).get("RESULT"));
			assertNull(listTLJ.get(i).get("RESULT_TS"));
			assertNull(listTLJ.get(i).get("FAILED_FLAG"));
			assertEquals("1", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("4", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		assertEquals("4", listTLJ.get(3).get("JOB_ID").toString());
		assertEquals("1", listTLJ.get(3).get("JOB_STATE").toString());
		assertEquals("1540651052", listTLJ.get(3).get("ASSIGNED_TS").toString());
		assertNull(listTLJ.get(3).get("RESULT"));
		assertNull(listTLJ.get(3).get("RESULT_TS"));
		assertNull(listTLJ.get(3).get("FAILED_FLAG"));
		assertEquals("0", listTLJ.get(3).get("FAILURE_COUNT").toString());
		assertEquals("4", listTLJ.get(3).get("REMAIN_JOBS").toString());

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, CONTAINER_JOB_RESULT, RESULT_TS,"
						+ " JOB_STATE, ASSIGNED_TS, PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNull(listCJ.get(i).get("MR_ID"));
			assertNull(listCJ.get(i).get("CONTAINER_JOB_RESULT"));
			assertNull(listCJ.get(i).get("RESULT_TS"));
			assertEquals("0", listCJ.get(i).get("JOB_STATE").toString());
			assertNull(listCJ.get(i).get("ASSIGNED_TS"));
			assertNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(0, reasonCount.intValue());

		// SEGMENT DEFRAGMENTATION
		int containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(-1, containerId);

		// other
		assertEquals(true, startReport);
		assertTrue(message.contains("Exception: Container job"));
		assertTrue(message.contains(") restart clear Map Reduces."));
		assertEquals("Match Manager on " + ip + " started up.", desc);
		assertEquals("startScheduler", scheduler);
	}

	@Test
	public void test_finalizeAIM() {
		String ip = configProps
				.getPropertyValue(ConfigPropertyNames.MM_IP_ADDRESS);
		String uniqueId = ip;

		new MockUp<SyncThreadExecutor>() {
			@Mock
			public void stopInternal() {
				if (exception) {
					throw new AimRuntimeException();
				}
				return;
			}
		};

		exception = true;

		initBean.finalizeAIM();

		String sql = "select STATE from MATCH_MANAGERS where UNIQUE_ID=?";
		String state = jdbcTemplate.queryForObject(sql,
				new Object[] { uniqueId }, String.class);
		assertEquals("EXITED", state);
	}

	@Test
	public void test_initializeAIM_IEJCP() {
		exception = true;
		new MockUp<InitExecutingJobCountProcedure>() {
			@Mock
			public void execute() {
				if (exception) {
					throw new IncorrectResultSizeDataAccessException(0);
				}
			}
		};

		try {
			initBean.initializeAIM();
		} catch (AimRuntimeException e) {
			assertEquals("DataAccessException when Init Executing Job Count",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void test_initializeAIM_Scheduler() {
		exception = true;

		try {
			initBean.initializeAIM();
		} catch (AimRuntimeException e) {
			assertEquals(
					"jp.co.nec.aim.mm.exception.AimRuntimeException: startScheduler",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void test_initializeAIM_TowMM() {
		String ip = configProps
				.getPropertyValue(ConfigPropertyNames.MM_IP_ADDRESS);
		String uniqueId = ip;
		String connectUrl = "http://" + ip + ":8080/matchmanager";

		jdbcTemplate.execute("insert into MATCH_MANAGERS(MM_ID, UNIQUE_ID,"
				+ " STATE, HEARTBEAT_TS) values(SERVER_SEQ.nextval, "
				+ "'127.0.0.2', 'WORKING', 1540651052)");
		jdbcTemplate.execute("commit");

		initBean.initializeAIM();

		jdbcTemplate.execute("commit");

		// Match Manager
		List<Map<String, Object>> listMM = jdbcTemplate
				.queryForList("select * from MATCH_MANAGERS order by MM_ID");
		assertEquals(2, listMM.size());
		assertEquals(uniqueId, listMM.get(1).get("UNIQUE_ID").toString());
		assertEquals(connectUrl, listMM.get(1).get("CONTACT_URL").toString());
		assertEquals("WORKING", listMM.get(1).get("STATE").toString());
		// assertNotNull(listMM.get(1).get("VERSION"));

		// System Configure
		int sysCount = jdbcTemplate.queryForObject(
				"select count(*) from SYSTEM_CONFIG", Integer.class);
		assertEquals(EnumSet.allOf(MMConfigProperty.class).size(), sysCount);

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			if (i < 1) {
				assertEquals("2", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			} else if (i < 3) {
				assertEquals("1", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			} else {
				assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			}
		}

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " FAILURE_COUNT, REMAIN_JOBS from JOB_QUEUE"
						+ " order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < listTLJ.size(); i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("1", listTLJ.get(i).get("JOB_STATE").toString());
			assertEquals("1540651052", listTLJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNull(listTLJ.get(i).get("RESULT"));
			assertNull(listTLJ.get(i).get("RESULT_TS"));
			assertNull(listTLJ.get(i).get("FAILED_FLAG"));
			assertEquals("0", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("4", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, CONTAINER_JOB_RESULT, RESULT_TS,"
						+ " JOB_STATE, ASSIGNED_TS, PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNotNull(listCJ.get(i).get("MR_ID"));
			assertNull(listCJ.get(i).get("CONTAINER_JOB_RESULT"));
			assertNull(listCJ.get(i).get("RESULT_TS"));
			assertEquals("1", listCJ.get(i).get("JOB_STATE").toString());
			assertEquals("1540651052", listCJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNotNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(0, reasonCount.intValue());

		// MAP REDUCERS
		int mrCount = jdbcTemplate.queryForObject(
				"select count(*) from MAP_REDUCERS", Integer.class);
		assertEquals(3, mrCount);
		int mrcCount = jdbcTemplate.queryForObject(
				"select count(*) from MR_CONTACTS", Integer.class);
		assertEquals(3, mrcCount);
		int lmrCount = jdbcTemplate.queryForObject(
				"select count(*) from LAST_ASSIGNED_MR", Integer.class);
		assertEquals(1, lmrCount);

		// SEGMENT DEFRAGMENTATION
		int containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(-1, containerId);

		// other
		assertEquals(true, startReport);
		assertEquals("", message);
		assertEquals("Match Manager on " + ip + " started up.", desc);
		assertEquals("startScheduler", scheduler);
	}

	@Test
	public void testInitCompletedJobCount() {
		initBean.initCompletedJobCount();
		String extractSql = "select complete_count from extract_complete_count where ROWNUM = 1";
		Long results = jdbcTemplate.queryForObject(extractSql, Long.class);
		assertEquals(0, results.intValue());
		String inquirySql = "select JOB_COMPLETE_COUNT from inquiry_traffic";
		List<Map<String, Object>> inquiryResult = jdbcTemplate
				.queryForList(inquirySql);
		for (int i = 0; i < inquiryResult.size(); i++) {
			java.math.BigDecimal tmp = (BigDecimal) inquiryResult.get(i).get(
					"JOB_COMPLETE_COUNT");
			assertEquals(0, tmp.intValue());
		}
	}
}
