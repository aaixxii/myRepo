package jp.co.nec.aim.mm.acceptor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncRequest;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResponse;
import jp.co.nec.aim.mm.common.HttpTestServer;
//import jp.co.nec.aim.mm.util.JmsSender;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class RegistrationTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	private Registration reg;

	@Before
	public void setUp() {
		reg = new Registration(dataSource, entityManager);
		jdbcTemplate.update("delete from mu_segments");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from dm_segments");
		jdbcTemplate.update("delete from data_managers");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.execute("commit");
		map.clear();

		setMockMethod();
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from mu_segments");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from dm_segments");
		jdbcTemplate.update("delete from data_managers");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.execute("commit");
		map.clear();		
	}

	@BeforeClass
	public static void init() throws Exception {
		// _server = new HttpTestServer(65521);
		// _server.start(getMockHandler());
	}

	@AfterClass
	public static void after() throws Exception {

		// if (_server != null) { _server.stop(); }

	}

	@Test
	public void testInsert1_NewSeg() throws Exception {

		jdbcTemplate
				.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
		jdbcTemplate.update("commit");
		List<SyncRequest> syncRequests = Lists.newArrayList();
		byte[] binary = { 1, 2, 2 };
		Record record = new Record(binary);
		SyncRequest syncRequest = new SyncRequest(1, record);
		SyncRequest syncRequest1 = new SyncRequest(2, record);
		syncRequests.add(syncRequest);
		syncRequests.add(syncRequest1);
		reg.insert(1, "1", syncRequests);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from RESOURCE_UPDATE_COUNT");
		Assert.assertEquals(
				Integer.parseInt(list.get(0).get("UPDATE_COUNT").toString()), 1);

	}

	@Test
	public void testInsert_Update_segments() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(2, "testInsert_Update_segments"));
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(2,1,'http://127.0.0.1:65521/2','WORKING')");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(2,1,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(2,2,1)");
			jdbcTemplate.update("commit");
			List<SyncRequest> syncRequests = Lists.newArrayList();
			byte[] binary = { 1, 2, 2 };
			Record record = new Record(binary);
			Record record1 = new Record(binary);
			SyncRequest syncRequest = new SyncRequest(1, record);
			SyncRequest syncRequest2 = new SyncRequest(1, record1);
			SyncRequest syncRequest1 = new SyncRequest(2, record);
			syncRequests.add(syncRequest);
			syncRequests.add(syncRequest1);
			syncRequests.add(syncRequest2);
			reg.insert(1, "1", syncRequests);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Thread.sleep(5000);
			Assert.assertEquals(2, map.size());

			PBSegmentSyncRequest segmentSyncRequest = map
					.get("/1/matchunit/SegmentUpdateJob");
			Assert.assertEquals(1, segmentSyncRequest.getSegmentUpdatesCount());
			PBSegmentSyncRequest segmentSyncRequest1 = map
					.get("/2/datamanager/SegmentUpdateJob");
			Assert.assertEquals(1, segmentSyncRequest1.getSegmentUpdatesCount());
			Assert.assertEquals(2, segmentSyncRequest1.getSegmentUpdates(0)
					.getSyncItem().getCatUpInfo().getCatchUpItemsCount());
			Assert.assertEquals(
					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
					segmentSyncRequest1.getSegmentUpdates(0).getSyncItem()
							.getCatUpInfo().getCatchUpItems(0).getCommand());

			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testInsert_Update_segments_stateNotWorking() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(1, "testInsert_Update_segments"));
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','EXITED')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(2,1,'http://127.0.0.1:65521/2','WORKING')");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(2,1,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(2,2,1)");
			jdbcTemplate.update("commit");
			List<SyncRequest> syncRequests = Lists.newArrayList();
			byte[] binary = { 1, 2, 2 };
			Record record = new Record(binary);
			Record record1 = new Record(binary);
			SyncRequest syncRequest = new SyncRequest(1, record);
			SyncRequest syncRequest2 = new SyncRequest(1, record1);
			SyncRequest syncRequest1 = new SyncRequest(2, record);
			syncRequests.add(syncRequest);
			syncRequests.add(syncRequest1);
			syncRequests.add(syncRequest2);
			reg.insert(1, "1", syncRequests);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Thread.sleep(5000);
			Assert.assertEquals(1, map.size());
			PBSegmentSyncRequest segmentSyncRequest1 = map
					.get("/2/datamanager/SegmentUpdateJob");
			Assert.assertEquals(1, segmentSyncRequest1.getSegmentUpdatesCount());
			Assert.assertEquals(2, segmentSyncRequest1.getSegmentUpdates(0)
					.getSyncItem().getCatUpInfo().getCatchUpItemsCount());
			Assert.assertEquals(
					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
					segmentSyncRequest1.getSegmentUpdates(0).getSyncItem()
							.getCatUpInfo().getCatchUpItems(0).getCommand());

			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testInsert_Update_segments_FiveSegments_TwoCatchUpInfo()
			throws Exception {
		HttpTestServer server = null;

		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(2,
					"testInsert_Update_segments_FiveSegments_TwoCatchUpInfo"));
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(2,1,'http://127.0.0.1:65521/2','WORKING')");

			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(2,1,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(3,3,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(4,4,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(5,5,1,1,26,1,10,1,26)");

			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,2,1)");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(2,3,1)");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(2,4,1)");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(2,5,1)");
			jdbcTemplate.update("commit");
			List<SyncRequest> syncRequests = Lists.newArrayList();
			byte[] binary = { 1, 2, 2 };
			Record record = new Record(binary);
			Record record1 = new Record(binary);
			SyncRequest syncRequest = new SyncRequest(1, record);
			SyncRequest syncRequest2 = new SyncRequest(1, record1);

			SyncRequest syncRequest1 = new SyncRequest(2, record);
			SyncRequest syncRequest3 = new SyncRequest(2, record1);
			SyncRequest syncRequest4 = new SyncRequest(3, record1);
			SyncRequest syncRequest5 = new SyncRequest(3, record);

			SyncRequest syncRequest6 = new SyncRequest(4, record1);
			SyncRequest syncRequest7 = new SyncRequest(4, record);
			SyncRequest syncRequest8 = new SyncRequest(5, record1);
			SyncRequest syncRequest9 = new SyncRequest(5, record);
			syncRequests.add(syncRequest);
			syncRequests.add(syncRequest1);
			syncRequests.add(syncRequest2);
			syncRequests.add(syncRequest3);
			syncRequests.add(syncRequest4);
			syncRequests.add(syncRequest5);
			syncRequests.add(syncRequest6);
			syncRequests.add(syncRequest7);
			syncRequests.add(syncRequest8);
			syncRequests.add(syncRequest9);
			reg.insert(1, "1", syncRequests);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Thread.sleep(5000);
			Assert.assertEquals(2, map.size());

			PBSegmentSyncRequest request1 = map
					.get("/1/matchunit/SegmentUpdateJob");
			Assert.assertEquals(2, request1.getSegmentUpdatesCount());

			List<PBSegmentSyncInfo> syncInfos = request1
					.getSegmentUpdatesList();
			for (PBSegmentSyncInfo syncInfo : syncInfos) {
				Assert.assertEquals(2, syncInfo.getSyncItem().getCatUpInfo()
						.getCatchUpItemsCount());
			}

			PBSegmentSyncRequest request2 = map
					.get("/2/matchunit/SegmentUpdateJob");
			Assert.assertEquals(3, request2.getSegmentUpdatesCount());

			List<PBSegmentSyncInfo> syncInfos1 = request2
					.getSegmentUpdatesList();
			for (PBSegmentSyncInfo syncInfo : syncInfos1) {
				Assert.assertEquals(2, syncInfo.getSyncItem().getCatUpInfo()
						.getCatchUpItemsCount());
			}

			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testDelete1() throws Exception {

		jdbcTemplate
				.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
		jdbcTemplate.update("commit");
		List<Integer> containerIds = Lists.newArrayList();
		containerIds.add(1);
		reg.delete(1, "1", containerIds);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from RESOURCE_UPDATE_COUNT");
		Assert.assertEquals(0, list.size());
	}

	@Test
	public void testDelete_Push_OneContainerId() throws Exception {
		HttpTestServer server = null;

		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(1, "testDelete_Push_OneContainerId"));
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,111,0,1,2)");
			jdbcTemplate.update("commit");
			List<Integer> containerIds = Lists.newArrayList();
			containerIds.add(2);
			reg.delete(1, "1", containerIds);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Thread.sleep(5000);
			Assert.assertEquals(1, map.size());

			PBSegmentSyncRequest request1 = map
					.get("/1/matchunit/SegmentUpdateJob");
			Assert.assertEquals(1, request1.getSegmentUpdatesCount());

			List<PBSegmentSyncInfo> syncInfos = request1
					.getSegmentUpdatesList();
			for (PBSegmentSyncInfo syncInfo : syncInfos) {
				Assert.assertEquals(1, syncInfo.getSyncItem().getCatUpInfo()
						.getCatchUpItemsCount());
			}
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testDelete_Push_ThreeContainerId_TwoMU_OneDM() throws Exception {
		HttpTestServer server = null;

		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(3,
					"testDelete_Push_ThreeContainerId_TwoMU_OneDM"));
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(2,1,2,2,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(3,321,3,3,26,1,10,1,26)");
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(2,1,'http://127.0.0.1:65521/2','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(3,1,'http://127.0.0.1:65521/3','WORKING')");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(2,2,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(3,3,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,111,0,1,2)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(2,'1',CAST('111' AS BINARY),3,111,0,1,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(3,'1',CAST('111' AS BINARY),3,111,0,1,321)");
			jdbcTemplate.update("commit");
			List<Integer> containerIds = Lists.newArrayList();
			containerIds.add(1);
			containerIds.add(2);
			containerIds.add(321);
			reg.delete(1, "1", containerIds);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Thread.sleep(5000);
			Assert.assertEquals(3, map.size());

			PBSegmentSyncRequest request1 = map
					.get("/1/matchunit/SegmentUpdateJob");
			Assert.assertEquals(1, request1.getSegmentUpdatesCount());

			List<PBSegmentSyncInfo> syncInfos = request1
					.getSegmentUpdatesList();
			for (PBSegmentSyncInfo syncInfo : syncInfos) {
				Assert.assertEquals(1, syncInfo.getSyncItem().getCatUpInfo()
						.getCatchUpItemsCount());
			}

			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testUpdate1_Seg12INsertDEL_Seg3DEL_Seg4Insert()
			throws Exception {

		HttpTestServer server = null;

		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(3,
					"testUpdate1_Seg12INsertDEL_Seg3DEL_Seg4Insert"));
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(2,1,2,2,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(3,321,3,3,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(4,3,3,3,26,1,10,1,26)");
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(2,1,'http://127.0.0.1:65521/2','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(3,1,'http://127.0.0.1:65521/3','WORKING')");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,4,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(2,2,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(3,3,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,111,0,1,2)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(2,'1',CAST('111' AS BINARY),3,111,0,1,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(3,'1',CAST('111' AS BINARY),3,111,0,1,321)");
			jdbcTemplate.update("commit");
			List<Integer> containerIds = Lists.newArrayList();
			containerIds.add(1);
			containerIds.add(2);
			containerIds.add(321);
			List<SyncRequest> syncRequests = Lists.newArrayList();
			byte[] binary = { 1, 2, 2 };
			Record record = new Record(binary);
			Record record1 = new Record(binary);
			SyncRequest syncRequest = new SyncRequest(1, record);
			SyncRequest syncRequest2 = new SyncRequest(1, record1);

			SyncRequest syncRequest1 = new SyncRequest(2, record);
			SyncRequest syncRequest3 = new SyncRequest(2, record1);
			SyncRequest syncRequest4 = new SyncRequest(3, record1);
			SyncRequest syncRequest5 = new SyncRequest(3, record);
			syncRequests.add(syncRequest1);
			syncRequests.add(syncRequest2);
			syncRequests.add(syncRequest3);
			syncRequests.add(syncRequest4);
			syncRequests.add(syncRequest5);
			syncRequests.add(syncRequest);
			reg.update(1, "1", containerIds, syncRequests);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Thread.sleep(5000);
			Assert.assertEquals(3, map.size());

			PBSegmentSyncRequest request1 = map
					.get("/1/matchunit/SegmentUpdateJob");
			Assert.assertEquals(2, request1.getSegmentUpdatesCount());

			List<PBSegmentSyncInfo> syncInfos = request1
					.getSegmentUpdatesList();
			for (PBSegmentSyncInfo syncInfo : syncInfos) {
				if (syncInfo.getId() == 4) {
					Assert.assertEquals(2, syncInfo.getSyncItem()
							.getCatUpInfo().getCatchUpItemsCount());
					Assert.assertEquals(
							SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
							syncInfo.getSyncItem().getCatUpInfo()
									.getCatchUpItems(0).getCommand());
					Assert.assertEquals(
							SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
							syncInfo.getSyncItem().getCatUpInfo()
									.getCatchUpItems(1).getCommand());
				}
				if (syncInfo.getId() == 1) {
					Assert.assertEquals(3, syncInfo.getSyncItem()
							.getCatUpInfo().getCatchUpItemsCount());
				}

			}

			PBSegmentSyncRequest request2 = map
					.get("/3/datamanager/SegmentUpdateJob");
			Assert.assertEquals(1, request2.getSegmentUpdatesCount());

			PBSegmentSyncInfo syncInfo = request2.getSegmentUpdatesList()
					.get(0);
			Assert.assertEquals(3, syncInfo.getId());
			Assert.assertEquals(1, syncInfo.getSyncItem().getCatUpInfo()
					.getCatchUpItemsCount());
			Assert.assertEquals(
					SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE,
					syncInfo.getSyncItem().getCatUpInfo().getCatchUpItems(0)
							.getCommand());
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testUpdate_NoDel() throws Exception {
		HttpTestServer server = null;

		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(2, "testUpdate_NoDel"));
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(2,1,2,2,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(3,321,3,3,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(4,3,3,3,26,1,10,1,26)");
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(2,1,'http://127.0.0.1:65521/2','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(3,1,'http://127.0.0.1:65521/3','WORKING')");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,4,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(2,2,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(3,3,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,111,0,1,2)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(2,'1',CAST('111' AS BINARY),3,111,0,1,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(3,'1',CAST('111' AS BINARY),3,111,0,1,321)");
			jdbcTemplate.update("commit");
			List<Integer> containerIds = Lists.newArrayList();
			List<SyncRequest> syncRequests = Lists.newArrayList();
			byte[] binary = { 1, 2, 2 };
			Record record = new Record(binary);
			Record record1 = new Record(binary);
			SyncRequest syncRequest = new SyncRequest(1, record);
			SyncRequest syncRequest2 = new SyncRequest(1, record1);

			SyncRequest syncRequest1 = new SyncRequest(2, record);
			SyncRequest syncRequest3 = new SyncRequest(2, record1);
			SyncRequest syncRequest4 = new SyncRequest(3, record1);
			SyncRequest syncRequest5 = new SyncRequest(3, record);
			syncRequests.add(syncRequest1);
			syncRequests.add(syncRequest2);
			syncRequests.add(syncRequest3);
			syncRequests.add(syncRequest4);
			syncRequests.add(syncRequest5);
			syncRequests.add(syncRequest);
			reg.update(1, "1", containerIds, syncRequests);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}

			Thread.sleep(5000);
			Assert.assertEquals(2, map.size());

			PBSegmentSyncRequest request1 = map
					.get("/1/matchunit/SegmentUpdateJob");
			Assert.assertEquals(2, request1.getSegmentUpdatesCount());

			List<PBSegmentSyncInfo> syncInfos = request1
					.getSegmentUpdatesList();
			for (PBSegmentSyncInfo syncInfo : syncInfos) {
				if (syncInfo.getId() == 4) {
					Assert.assertEquals(2, syncInfo.getSyncItem()
							.getCatUpInfo().getCatchUpItemsCount());
					Assert.assertEquals(
							SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
							syncInfo.getSyncItem().getCatUpInfo()
									.getCatchUpItems(0).getCommand());
					Assert.assertEquals(
							SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT,
							syncInfo.getSyncItem().getCatUpInfo()
									.getCatchUpItems(1).getCommand());
				}
				if (syncInfo.getId() == 1) {
					Assert.assertEquals(2, syncInfo.getSyncItem()
							.getCatUpInfo().getCatchUpItemsCount());
				}
			}
			PBSegmentSyncRequest request = map
					.get("/2/datamanager/SegmentUpdateJob");
			Assert.assertEquals(1, request.getSegmentUpdatesCount());
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testUpdate_NoIns() throws Exception {

		jdbcTemplate
				.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,2,1,1,26,1,10,1,26)");
		jdbcTemplate
				.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(2,1,2,2,26,1,10,1,26)");
		jdbcTemplate
				.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(3,321,3,3,26,1,10,1,26)");
		jdbcTemplate
				.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(4,3,3,3,26,1,10,1,26)");
		jdbcTemplate
				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
		jdbcTemplate
				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(2,1,'http://127.0.0.1:65521/2','WORKING')");
		jdbcTemplate
				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(3,1,'http://127.0.0.1:65521/3','WORKING')");
		jdbcTemplate
				.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
		jdbcTemplate
				.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,4,1)");
		jdbcTemplate
				.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(2,2,1)");
		jdbcTemplate
				.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(3,3,1)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,111,0,1,2)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(2,'1',CAST('111' AS BINARY),3,111,0,1,1)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(3,'1',CAST('111' AS BINARY),3,111,0,1,321)");
		jdbcTemplate.update("commit");
		List<Integer> containerIds = Lists.newArrayList();
		containerIds.add(1);
		containerIds.add(2);
		List<SyncRequest> syncRequests = Lists.newArrayList();
		reg.update(1, "1", containerIds, syncRequests);

	}

	@Test
	public void testInsert() throws Exception {
		byte[] binary = { 1, 2, 3 };
		Record record = new Record(binary);
		SyncRequest syncReq = new SyncRequest(1, record);
		List<SyncRequest> syncReqs = new ArrayList<SyncRequest>();
		syncReqs.add(syncReq);
		reg.insert(1, "123", syncReqs);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Thread.sleep(5000);
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(map.get("CONTAINER_ID"), mapSeg.get("CONTAINER_ID"));

	}

	@Test
	public void testDelete() throws Exception {
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,'1234',0,1,1)");
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		containerIds.add(2);
		reg.delete(1, "1", containerIds);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Thread.sleep(5000);
		Assert.assertEquals(0, list.size());
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertFalse(mapSeg.get("BINARY_LENGTH_COMPACTED").equals(83));

	}

	@Test
	public void testUpdate() throws Exception {
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,'1234',0,1,1)");
		byte[] binary = { 1, 2, 3, 4 };
		Record record = new Record(binary);
		SyncRequest syncReq = new SyncRequest(1, record);
		List<SyncRequest> syncReqs = new ArrayList<SyncRequest>();
		syncReqs.add(syncReq);
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		containerIds.add(2);
		reg.update(1, "1", containerIds, syncReqs);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Thread.sleep(5000);
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(map.get("CONTAINER_ID"), mapSeg.get("CONTAINER_ID"));
	}

	@Test
	public void testCreateCheckResultsEventIdsContainerIdsBothNull() {
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,'1234',0,1,1)");
		jdbcTemplate.update("commit");
		String externalId = "1";
		PBCheckExternalIdResponse response = reg.createCheckResults(externalId,
				null, null);
		Assert.assertEquals("1", response.getExternalId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		Assert.assertEquals(1, response.getCheckResultList().size());
	}

	@Test
	public void testCheckExternalIdEventIdsNull() throws Exception {
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,'1234',0,1,1)");
		jdbcTemplate.update("commit");
		String externalId = "1";
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		PBCheckExternalIdResponse response = reg.createCheckResults(externalId,
				null, containerIds);
		Thread.sleep(5000);
		Assert.assertEquals("1", response.getExternalId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		Assert.assertEquals(1, response.getCheckResultList().size());
	}

	@Test
	public void testCheckExternalIdContainerIdsNull() throws Exception {
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,'1234',0,1,1)");
		jdbcTemplate.update("commit");
		String externalId = "1";
		List<Integer> eventIds = new ArrayList<Integer>();
		eventIds.add(1);
		PBCheckExternalIdResponse response = reg.createCheckResults(externalId,
				eventIds, null);
		Thread.sleep(5000);
		Assert.assertEquals("1", response.getExternalId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		Assert.assertEquals(1, response.getCheckResultList().size());
	}

	@Test
	public void testCheckExternalIdContainerIdsEventIdsBothNotNull()
			throws Exception {
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,'1234',0,1,1)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(2,'1',CAST('111' AS BINARY),3,'1234',0,1,2)");

		jdbcTemplate.update("commit");
		String externalId = "1";
		List<Integer> eventIds = new ArrayList<Integer>();
		eventIds.add(1);
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		containerIds.add(2);
		PBCheckExternalIdResponse response = reg.createCheckResults(externalId,
				eventIds, containerIds);
		Thread.sleep(5000);
		Assert.assertEquals("1", response.getExternalId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		Assert.assertEquals(1, response.getCheckResultList().size());
		Assert.assertEquals(2, response.getCheckResultList().get(0)
				.getContainerResultList().size());
		Assert.assertEquals(1, response.getCheckResultList().get(0)
				.getContainerResultList().get(0).getContainerId());
	}

	@Test
	public void testCheckExternalIdContainerIdsEventIdsBothNotNullSame()
			throws Exception {
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',CAST('111' AS BINARY),3,'1234',0,1,1)");

		jdbcTemplate.update("commit");
		String externalId = "1";
		List<Integer> eventIds = new ArrayList<Integer>();
		eventIds.add(1);
		eventIds.add(1);
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		containerIds.add(1);
		PBCheckExternalIdResponse response = reg.createCheckResults(externalId,
				eventIds, containerIds);
		Thread.sleep(5000);
		Assert.assertEquals("1", response.getExternalId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		Assert.assertEquals(1, response.getCheckResultList().size());
		Assert.assertEquals(1, response.getCheckResultList().get(0)
				.getContainerResultList().size());
		Assert.assertEquals(1, response.getCheckResultList().get(0)
				.getContainerResultList().get(0).getContainerId());
	}

	private final Object LOCKER = new Object();
	private static final Map<String, PBSegmentSyncRequest> map = Maps
			.newConcurrentMap();

	/**
	 * getMockHandler
	 * 
	 * @return AbstractHandler
	 */
	public Handler getMockHandler(final Integer a, final String... name) {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();

				PBSegmentSyncRequest result = PBSegmentSyncRequest
						.parseFrom(request.getInputStream());
				// System.out.println(baseRequest.getRequestURI());
				// System.out.println(result.toString());

				map.put(baseRequest.getRequestURI(), result);

				System.out.println("ThreadName:"
						+ Thread.currentThread().getId() + "=================="
						+ ((name == null || name.length == 0) ? "" : name[0])
						+ "==================" + "result->\n"
						+ result.toString());

				// q.add(result);

				if (map.size() == a) {
					synchronized (LOCKER) {
						LOCKER.notify();
					}
				}
				response.setStatus(200);
				response.setContentType("application/octet-stream");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}
}