package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.procedure.ContainerJobResult;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class AggregatorDaoTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private AggregatorDao aggregatordao;

	private InquiryJobDao inquiryjobdao;

	private DateDao datedao;

	@Before
	public void setUp() throws Exception {
		inquiryjobdao = new InquiryJobDao(entityManager);
		aggregatordao = new AggregatorDao(ds);
		datedao = new DateDao(ds);
		JdbcTemplateHelper helper = new JdbcTemplateHelper();
		helper.deleteInquiryJob(jdbcTemplate);
		helper.scene01(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetAllContainerJobs() {

		List<byte[]> result = aggregatordao.getAllContainerJobs(1005);
		List<ContainerJobResult> containerJobResultlist = result.stream().map(ContainerJobResult::new).collect(Collectors.toList());		
		assertEquals(80, containerJobResultlist.size());
	}

	@Test
	public void testCallCompleteTopLevelJob() {
		byte[] result = "101101010".getBytes();
		boolean failed = true;
		long jobId = 1005;
		aggregatordao.callCompleteTopLevelJob(jobId, result, failed);
		JobQueueEntity jobQueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(1005, jobQueue.getJobId());
		assertEquals(JobState.DONE, jobQueue.getJobState());
		assertNotNull(jobQueue.getResultsTS());
		assertEquals(true, jobQueue.getFailedFlag());
		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
				.getInquiryTraffic(jobId);
		assertEquals(jobQueue.getFamilyId(), inquiryTraffic.getFamilyId());
		assertEquals("TI", inquiryTraffic.getFamilyName());
		assertEquals(new Long(1), inquiryTraffic.getJobExecCount());
	}

	@Test
	public void testCallCompleteTopLevelJob_false() {
		byte[] result = "101101010".getBytes();
		boolean failed = false;
		long jobId = 1005;
		aggregatordao.callCompleteTopLevelJob(jobId, result, failed);
		JobQueueEntity jobQueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(1005, jobQueue.getJobId());
		assertEquals(JobState.DONE, jobQueue.getJobState());
		assertNotNull(jobQueue.getResultsTS());
		assertEquals(false, jobQueue.getFailedFlag());
		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
				.getInquiryTraffic(jobId);
		assertEquals(jobQueue.getFamilyId(), inquiryTraffic.getFamilyId());
		assertEquals("TI", inquiryTraffic.getFamilyName());
		assertEquals(new Long(1), inquiryTraffic.getJobExecCount());
	}

	@Test
	public void testUpdateJobResult() {
		byte[] result = "101101010".getBytes();
		long remain_job = aggregatordao.updateJobResult(1003, 0, 10741, result);
		ContainerJobEntity containerJob = inquiryjobdao.getContainerJob(10741);
		assertEquals(9, remain_job);
		assertEquals(2, containerJob.getContainerId());
		byte[] containerjobresult = containerJob.getContainerJobResult();
		assertEquals(result.length, containerjobresult.length);
		for (int index = 0; index < result.length; index++) {
			assertEquals(result[index], containerjobresult[index]);
		}
		assertEquals(JobState.DONE, containerJob.getJobState());
		assertNotNull(containerJob.getResultTs());

		JobQueueEntity jobqueue = inquiryjobdao.getTopLevelJob(1003);
		assertEquals(9, jobqueue.getRemainJobs());
	}

	@Test
	public void testFailJobResult() {
		String code = "1201";
		String reason = "ABCD";
		String failureTime = datedao.getCurrentTimeMS().toString();
		long containerJobId = 10148;
		Long segmentId = null;
		PBServiceState.Builder serviceState = PBServiceState.newBuilder();
		serviceState.setState(ServiceStateType.SERVICE_STATE_ERROR).setReason(
				PBServiceStateReason.newBuilder().setCode(code)
						.setDescription(reason).setTime(failureTime));
		byte[] btr = "ABCDE".getBytes();
		long jobId = aggregatordao.failJobResult(serviceState.build(), btr,
				containerJobId, segmentId);

		assertEquals(1004, jobId);
		JobQueueEntity jobqueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(1, jobqueue.getFailureCount());
		// assertEquals(null, jobqueue.getAssignedTs());
		ContainerJobEntity containerjob = inquiryjobdao
				.getContainerJob(containerJobId);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
	}

	@Test
	public void testRetryJob() {
		long jobId = 1000;
		long exec_count = aggregatordao.retryJob(1000);// JobId 1000
		assertEquals(1, exec_count);
		JobQueueEntity jobqueue = inquiryjobdao.getTopLevelJob(jobId);

		assertEquals(1, jobqueue.getFailureCount());
		assertEquals(JobState.QUEUED, jobqueue.getJobState());
		assertNull(jobqueue.getAssignedTs());// TODO AssignedTs==null
		List<ContainerJobEntity> containerjoblist = inquiryjobdao
				.getAllContainerJob(jobId);
		for (ContainerJobEntity containerjob : containerjoblist) {
			assertNull(containerjob.getMrId());
			assertNull(containerjob.getAssignedTs());
			assertNull(containerjob.getPlanId());
			assertNull(containerjob.getResultTs());
			assertNull(containerjob.getContainerJobResult());
			assertEquals(JobState.QUEUED, containerjob.getJobState());
		}

		assertEquals(containerjoblist.size(), jobqueue.getRemainJobs());

		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
				.getInquiryTraffic(jobId);
		assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());// Error
	}

}
