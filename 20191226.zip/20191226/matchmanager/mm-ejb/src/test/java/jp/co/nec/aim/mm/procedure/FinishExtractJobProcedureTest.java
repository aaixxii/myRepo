package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FinishExtractJobProcedureTest {
	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private DateDao dateDao;
	private SystemConfigDao systemconfigdao;
	private long curTime;

	@Before
	public void setUp() throws Exception {
		clearDB();
		dateDao = new DateDao(dataSource);
		//systemconfigdao = new SystemConfigDao(entityManager);
		//systemconfigdao.writeAllMissingProperties(dataSource);
		curTime = 1000;

		intsertUnit();
		insertFeJob();

	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	private void intsertUnit() {
		for (int id = 1; id <= 3; id++) {
			jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"
					+ " values(" + id + ", " + curTime + ")");
			jdbcTemplate.execute("insert into MU_EXTRACT_LOAD(MU_ID, PRESSURE,"
					+ " UPDATE_TS) values(" + id + ", 3, " + curTime + ")");
		}
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from MM_EVENTS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	private void insertFeJob() {
		String fljSQL = "insert into FE_LOT_JOBS(LOT_JOB_ID, MU_ID,"
				+ " ASSIGNED_TS, TIMEOUTS) values(?, ?, ?, ?)";

		String fejSQL = "insert into FE_JOB_QUEUE(JOB_ID, LOT_JOB_ID, PRIORITY,"
				+ " FUNCTION_ID, JOB_STATE, SUBMISSION_TS, ASSIGNED_TS, MU_ID,"
				+ " CALLBACK_STYLE, CALLBACK_URL, FAILURE_COUNT) values(?, ?,"
				+ "  5,17, ?, 1421206612748, ?, ?, 1, 'test Url', ?)";

		int fljId = 1;
		jdbcTemplate.update(fljSQL, new Object[] { fljId, fljId, curTime,
				300 * 1000 });
		for (int fejId = 1; fejId <= 3; fejId++) {
			jdbcTemplate.update(fejSQL, new Object[] { (fljId - 1) * 3 + fejId,
					fljId, fejId - 1, curTime, fejId, 0 });
		}
	}

	private PBExtractJobResult createPBExtractJobResult() {
		PBServiceState.Builder state = PBServiceState.newBuilder();
		state.setState(ServiceStateType.SERVICE_STATE_SUCCESS);

		PBExtractJobResult.Builder resultBuilder = PBExtractJobResult
				.newBuilder();
		resultBuilder.setServiceState(state);
		for (int i = 0; i < 6; i++) {
			PBKeyedTemplateIndexer.Builder index = PBKeyedTemplateIndexer
					.newBuilder();
			if (i % 3 == 0) {
				index.setPosition(ImagePositionType.values()[i / 3]);
			} else if (i % 3 == 1) {
				index.setFingerPrintType(FingerPrintType.values()[i / 3]);
			} else {
				index.setIndex(i / 3);
			}
			PBKeyedTemplate.Builder keyTemp = PBKeyedTemplate.newBuilder();
			keyTemp.setTemplateBinary(ByteString.copyFromUtf8("Byte_" + i));
			keyTemp.setKey(TemplateFormatType.values()[i]);
			keyTemp.setIndexer(index);

			resultBuilder.addKeyedTemplate(keyTemp);
		}
		resultBuilder.setJobId(3);
		PBExtractJobResult result = resultBuilder.build();
		return result;
	}

	private void assertProcedureResult(int jobbId) {
		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE where JOB_ID="
						+ jobbId);
		assertEquals(1, listFeJ.size());

		assertEquals("" + jobbId, listFeJ.get(0).get("JOB_ID").toString());
		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
		assertEquals("2", listFeJ.get(0).get("JOB_STATE").toString());
		assertEquals("0", listFeJ.get(0).get("FAILED_FLAG").toString());
		assertEquals("" + jobbId, listFeJ.get(0).get("MU_ID").toString());
		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
		assertNotNull(listFeJ.get(0).get("RESULT_TS"));
		assertNotNull(listFeJ.get(0).get("RESULT"));
		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());

		List<Map<String, Object>> listFeR = jdbcTemplate
				.queryForList("select * from FE_RESULTS order by RESULT_ID");
		assertEquals(6, listFeR.size());
		for (int index = 0; index < 6; index++) {
			assertEquals("" + jobbId, listFeR.get(index).get("JOB_ID")
					.toString());
			int i = TemplateFormatType.valueOf(
					listFeR.get(index).get("TEMPLATE_KEY").toString())
					.ordinal();
			String data = new String((byte[]) listFeR.get(index).get(
					"RESULT_DATA"));
			assertEquals("Byte_" + i, data);
			if (i % 3 == 0) {
				assertEquals(
						"" + ImagePositionType.values()[i / 3].getNumber(),
						listFeR.get(index).get("TEMPLATE_INDEX").toString());
			} else if (i % 3 == 1) {
				assertEquals("" + FingerPrintType.values()[i / 3].getNumber(),
						listFeR.get(index).get("TEMPLATE_INDEX").toString());
			} else {
				assertEquals("" + (i / 3),
						listFeR.get(index).get("TEMPLATE_INDEX").toString());
			}
		}
	}

	private void assertUndoProcedureResult(int jobbId) {
		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE where JOB_ID="
						+ jobbId);
		assertEquals(1, listFeJ.size());

		assertEquals("" + jobbId, listFeJ.get(0).get("JOB_ID").toString());
		assertEquals("1", listFeJ.get(0).get("LOT_JOB_ID").toString());
		assertEquals("" + (jobbId - 1), listFeJ.get(0).get("JOB_STATE")
				.toString());
		assertNull(listFeJ.get(0).get("FAILED_FLAG"));
		assertEquals("" + jobbId, listFeJ.get(0).get("MU_ID").toString());
		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
		assertNull(listFeJ.get(0).get("RESULT_TS"));
		assertNull(listFeJ.get(0).get("RESULT"));
		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());

		List<Map<String, Object>> listFeR = jdbcTemplate
				.queryForList("select * from FE_RESULTS order by RESULT_ID");
		assertEquals(0, listFeR.size());
	}

	@Test(expected = UncategorizedSQLException.class)
	public void test_NullUndexerAndTemplate() throws SQLException, IOException {

		PBServiceState.Builder state = PBServiceState.newBuilder();
		state.setState(ServiceStateType.SERVICE_STATE_SUCCESS);

		PBExtractJobResult.Builder resultBuilder = PBExtractJobResult
				.newBuilder();
		resultBuilder.setServiceState(state);

		PBKeyedTemplate.Builder keyTemp1 = PBKeyedTemplate.newBuilder();
		keyTemp1.setTemplateBinary(ByteString.copyFromUtf8("Byte_0"));
		keyTemp1.setKey(TemplateFormatType.values()[0]);
		resultBuilder.addKeyedTemplate(keyTemp1);

		PBKeyedTemplateIndexer.Builder index = PBKeyedTemplateIndexer
				.newBuilder();

		PBKeyedTemplate.Builder keyTemp2 = PBKeyedTemplate.newBuilder();
		keyTemp2.setTemplateBinary(ByteString.copyFromUtf8("Byte_1"));
		keyTemp2.setKey(TemplateFormatType.values()[1]);
		keyTemp2.setIndexer(index);
		resultBuilder.addKeyedTemplate(keyTemp2);

		PBKeyedTemplate.Builder keyTemp3 = PBKeyedTemplate.newBuilder();
		keyTemp3.setKey(TemplateFormatType.values()[2]);
		resultBuilder.addKeyedTemplate(keyTemp3);
		resultBuilder.setJobId(3);
		PBExtractJobResult result = resultBuilder.build();

		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);		
		int count = procedure.execute(2, 2, result.toByteArray(),
				result.getKeyedTemplateList());

		assertEquals(1, count);

		// Extract Job
		int jobId = 2;
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE where JOB_ID="
						+ jobId);
		assertEquals(1, listFeJ.size());

		assertEquals("" + jobId, listFeJ.get(0).get("JOB_ID").toString());
		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
		assertEquals("2", listFeJ.get(0).get("JOB_STATE").toString());
		assertEquals("0", listFeJ.get(0).get("FAILED_FLAG").toString());
		assertEquals("" + jobId, listFeJ.get(0).get("MU_ID").toString());
		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
		assertNotNull(listFeJ.get(0).get("RESULT_TS"));
		assertNotNull(listFeJ.get(0).get("RESULT"));
		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());

		List<Map<String, Object>> listFeR = jdbcTemplate
				.queryForList("select * from FE_RESULTS order by RESULT_ID");
		assertEquals(3, listFeR.size());
		for (int ii = 0; ii < listFeR.size(); ii++) {
			assertEquals("" + jobId, listFeR.get(ii).get("JOB_ID").toString());
			int i = TemplateFormatType.valueOf(
					listFeR.get(ii).get("TEMPLATE_KEY").toString()).ordinal();
			String data = new String((byte[]) listFeR.get(ii)
					.get("RESULT_DATA"));
			if (i == 0) {
				assertEquals("Byte_0", data);
				assertEquals("0", listFeR.get(ii).get("TEMPLATE_INDEX")
						.toString());
			} else if (i == 1) {
				assertEquals("Byte_1", data);
				assertEquals("0", listFeR.get(ii).get("TEMPLATE_INDEX")
						.toString());
			} else {
				assertEquals("", data);
				assertEquals("0", listFeR.get(ii).get("TEMPLATE_INDEX")
						.toString());
			}
		}
	}

	@Test
	public void test_UndoQueuedExtractJob() throws SQLException, IOException {
		PBExtractJobResult result = createPBExtractJobResult();
		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);

		int count = procedure.execute(1, 1, result.toByteArray(),
				result.getKeyedTemplateList());

		assertEquals(0, count);

		assertUndoProcedureResult(1);
	}

	@Test
	public void test_Undo_Diff_MU_WorkingExtractJob() throws SQLException,
			IOException {
		PBExtractJobResult result = createPBExtractJobResult();
		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);

		int count = procedure.execute(1, 2, result.toByteArray(),
				result.getKeyedTemplateList());

		assertEquals(0, count);

		assertUndoProcedureResult(2);
	}

	@Test
	public void test_FinishWorkingExtractJob() throws SQLException, IOException {
		PBExtractJobResult result = createPBExtractJobResult();
		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);

		int count = procedure.execute(2, 2, result.toByteArray(),
				result.getKeyedTemplateList());

		assertEquals(1, count);

		assertProcedureResult(2);
	}

	@Test
	public void test_UndoDoneExtractJob() throws SQLException, IOException {
		PBExtractJobResult result = createPBExtractJobResult();
		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);

		int count = procedure.execute(1, 3, result.toByteArray(),
				result.getKeyedTemplateList());

		assertEquals(0, count);

		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE where JOB_ID=" + 3);
		assertEquals(1, listFeJ.size());

		assertEquals("3", listFeJ.get(0).get("JOB_ID").toString());
		assertEquals("1", listFeJ.get(0).get("LOT_JOB_ID").toString());
		assertEquals("2", listFeJ.get(0).get("JOB_STATE").toString());
		assertNull(listFeJ.get(0).get("FAILED_FLAG"));
		assertEquals("3", listFeJ.get(0).get("MU_ID").toString());
		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
		assertNull(listFeJ.get(0).get("RESULT_TS"));
		assertNull(listFeJ.get(0).get("RESULT"));
		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());

		List<Map<String, Object>> listFeR = jdbcTemplate
				.queryForList("select * from FE_RESULTS order by RESULT_ID");
		assertEquals(0, listFeR.size());
	}

	@Test
	public void test_IllegalArgument_MUID() throws SQLException, IOException {
		PBExtractJobResult result = createPBExtractJobResult();

		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);
		try {
			procedure.execute(0, 1, result.toByteArray(),
					result.getKeyedTemplateList());
		} catch (IllegalArgumentException e) {
			assertEquals("muId is less than 1", e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void test_IllegalArgument_ExractJobId() throws SQLException,
			IOException {
		PBExtractJobResult result = createPBExtractJobResult();

		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);
		try {
			procedure.execute(1, 0, result.toByteArray(),
					result.getKeyedTemplateList());
		} catch (IllegalArgumentException e) {
			assertEquals("jobId is less than 1", e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void test_IllegalArgument_Results() throws SQLException, IOException {
		PBExtractJobResult result = createPBExtractJobResult();

		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);
		try {
			procedure.execute(1, 1, null, result.getKeyedTemplateList());
		} catch (IllegalArgumentException e) {
			assertEquals("results is null", e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void test_IllegalArgument_KeyedBinaries() throws SQLException,
			IOException {
		PBExtractJobResult result = createPBExtractJobResult();

		FinishExtractJobProcedure procedure = new FinishExtractJobProcedure(
				dataSource);
		try {
			procedure.execute(1, 1, result.toByteArray(), null);
		} catch (IllegalArgumentException e) {
			assertEquals("keyedBinaries is null", e.getMessage());
			return;
		}
		fail();
	}
}
