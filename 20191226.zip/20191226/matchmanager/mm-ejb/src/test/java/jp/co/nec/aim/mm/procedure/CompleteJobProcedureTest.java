package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;


import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class CompleteJobProcedureTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	private InquiryJobDao inquiryjobdao;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private CompleteJobProcedure completejobprocedure;
	JdbcTemplateHelper helper = new JdbcTemplateHelper();

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);
		completejobprocedure = new CompleteJobProcedure(ds);
		inquiryjobdao = new InquiryJobDao(entityManager);
		helper.deleteInquiryJob(jdbcTemplate);
		helper.scene01(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		helper.deleteInquiryJob(jdbcTemplate);
	}

	@Test
	public void testCompleteJobProcedure_true() {
		byte[] result = "101101010".getBytes();
		boolean failed = true;
		long jobId = 1005;
		long execCount = completejobprocedure.action(jobId, result, failed);
		Assert.assertEquals(1, execCount);
//		JobQueueEntity jobQueue = inquiryjobdao.getTopLevelJob(jobId);
//		assertEquals(1005, jobQueue.getJobId());
//		assertEquals(JobState.DONE, jobQueue.getJobState());
//		assertNotNull(jobQueue.getResultsTS());
//		assertEquals(true, jobQueue.getFailedFlag());
//		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
//				.getInquiryTraffic(jobId);
//		assertEquals(jobQueue.getFamilyId(), inquiryTraffic.getFamilyId());
//		assertEquals("TI", inquiryTraffic.getFamilyName());
//		assertEquals(new Long(1), inquiryTraffic.getJobExecCount());
	}

	@Test
	public void testCompleteJobProcedure_false() {
		byte[] result = "101101010".getBytes();
		boolean failed = false;
		long jobId = 1005;
		long testResult = completejobprocedure.action(jobId, result, failed);
		Assert.assertEquals(1, testResult);
//		JobQueueEntity jobQueue = inquiryjobdao.getTopLevelJob(jobId);
//		assertEquals(1005, jobQueue.getJobId());
//		assertEquals(JobState.DONE, jobQueue.getJobState());
//		assertNotNull(jobQueue.getResultsTS());
//		assertEquals(false, jobQueue.getFailedFlag());
//		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
//				.getInquiryTraffic(jobId);
//		assertEquals(jobQueue.getFamilyId(), inquiryTraffic.getFamilyId());
//		assertEquals("TI", inquiryTraffic.getFamilyName());
//		assertEquals(new Long(1), inquiryTraffic.getJobExecCount());
	}
}
