UPDATE HIGH_LEVEL_SERVICE_LAYOUTS t SET t.script_xml = REPLACE(t.script_xml,' <scope>1</scope>',' <scope>2</scope>')WHERE t.script_id  =3;
UPDATE HIGH_LEVEL_SERVICE_LAYOUTS t set t.script_xml = replace(t.script_xml,'<scope>1</scope>','<scope>2</scope>')where script_id=2;
UPDATE HIGH_LEVEL_SERVICE_LAYOUTS t set t.script_xml = REPLACE(t.script_xml,'<scope>1</scope>','<scope>2</scope>')where script_id=1;

insert into SCOPES values(2);
insert into "CONTAINERS"(CONTAINER_ID,CONTAINER_NAME,SCOPE_ID,FORMAT_ID,MAX_SEGMENT_SIZE)
values(1001,'RDBT',2,1,200000);
insert into "CONTAINERS"(CONTAINER_ID,CONTAINER_NAME,SCOPE_ID,FORMAT_ID,MAX_SEGMENT_SIZE)
values(1331,'RDBTM',2,16,200000);
insert into "CONTAINERS"(CONTAINER_ID,CONTAINER_NAME,SCOPE_ID,FORMAT_ID,MAX_SEGMENT_SIZE)
values(1002,'SDBT',2,1,200000);
commit;