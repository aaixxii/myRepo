package jp.co.nec.aim.mm.dao;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.procedure.MRFetcherProcedure;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * MapReducersDao
 * 
 * @author liuyq
 * 
 */
public class MapReducersDao {

	private DataSource dataSource;
	private EntityManager em;
	private JdbcTemplate jdbcTemplate;

	/**
	 * MapReducersDao constructor
	 * 
	 * @param dataSource
	 *            dataSource instance
	 * @param EntityManager
	 */
	public MapReducersDao(DataSource dataSource, EntityManager em) {
		this.dataSource = dataSource;
		this.em = em;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * getNextMapReducer
	 * 
	 * @return MapReducerEntity instance
	 */
	public MapReducerEntity getNextMapReducer() {
		
		MRFetcherProcedure procedure = new MRFetcherProcedure(dataSource);
		return procedure.execute();
	}

	/**
	 * updateMRState
	 * 
	 * @param mrId
	 *            MR id
	 * @param unitState
	 *            UnitState
	 */
	public void updateMRState(long mrId, UnitState unitState) {
		final String sql = "update MAP_REDUCERS set STATE=? where MR_ID = ?";
		jdbcTemplate.update(sql, unitState.name(), mrId);
		jdbcTemplate.execute("commit");
	}

	public void updateLastMapReducer(MapReducerEntity mapReducer) {
		em.persist(mapReducer);
	}
}
