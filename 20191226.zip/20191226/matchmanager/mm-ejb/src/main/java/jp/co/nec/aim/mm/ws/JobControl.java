package jp.co.nec.aim.mm.ws;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.xml.ws.soap.SOAPFaultException;

import jp.co.nec.aim.clientapi.CommonOptions;
import jp.co.nec.aim.convert.ProtoClassConvert;
import jp.co.nec.aim.convert.WebServiceClassConvert;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryResponse;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResponse;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdRequest;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResponse;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.acceptor.JobType;
import jp.co.nec.aim.mm.acceptor.service.AimExtractService;
import jp.co.nec.aim.mm.acceptor.service.AimInquiryService;
import jp.co.nec.aim.mm.acceptor.service.AimManageService;
import jp.co.nec.aim.mm.acceptor.service.AimSyncService;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.jaxb.CheckResults;
import jp.co.nec.aim.mm.jaxb.ExtractJobResult;
import jp.co.nec.aim.mm.jaxb.ExtractionInputs;
import jp.co.nec.aim.mm.jaxb.JobStatus;
import jp.co.nec.aim.mm.jaxb.RegistrationRequest;
import jp.co.nec.aim.mm.jaxb.SearchJobResult;
import jp.co.nec.aim.mm.jaxb.SearchRequest;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.StopWatch;

import org.jboss.logging.NDC;
import org.jboss.ws.api.annotation.WebContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * JobControl web service
 * 
 * @author liuyq
 * 
 */
@WebService(name = "JobControlService")
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
@WebContext(contextRoot = "/AIMWebServices", secureWSDLAccess = false)
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public class JobControl {
	private static final Logger log = LoggerFactory.getLogger(JobControl.class);

	@EJB
	private AimSyncService syncService;

	@EJB
	private AimInquiryService inquiryService;

	@EJB
	private AimExtractService extractService;

	@EJB
	private AimManageService manageService;

	@EJB
	private Inquiry inquiry;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	/** exception **/
	private ExceptionHelper exception;
	private SystemConfigDao configDao;

	/** the common of Class Converter **/
	private ProtoClassConvert convert;
	private WebServiceClassConvert webConvert;

	/**
	 * JobControl default constructor
	 */
	public JobControl() {
	}

	@PostConstruct
	public void init() {
		this.convert = new ProtoClassConvert();
		this.webConvert = new WebServiceClassConvert();
		this.exception = new ExceptionHelper();
		this.configDao = new SystemConfigDao(manager);
	}

	// /////////////////// EXTRACTION ////////////////////////
	@WebMethod
	public long extract(
			@WebParam(name = "extractionInputs") ExtractionInputs extractInputs)
			throws AimRuntimeException {		
		NDC.push("extract");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBExtractJobResponse response = extractService.extract(
					convert.toPBExtractJobRequest(extractInputs), false);
			return response.getJobId();
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "extract",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	public ExtractJobResult getExtractJobResult(
			@WebParam(name = "jobId") long jobId) throws AimRuntimeException {		
		NDC.push("getExtractJobResult");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBExtractJobResult response = extractService.getJobResult(convert
					.toPBJobResultRequest(jobId));
			return webConvert.toExtractJobResult(response);
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(),
					"getExtractJobResult", stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	public byte[] getExtractJobBinary(@WebParam(name = "jobId") long jobId,
			@WebParam(name = "key") String key) throws AimRuntimeException {		
		NDC.push("getExtractJobBinary");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBExtractJobBinaryResponse response = extractService
					.getJobBinary(convert.toPBExtractJobBinaryRequest(jobId,
							key));
			List<PBKeyedTemplate> l = response.getKeyedTemplateList();
			if (CollectionsUtil.isNotEmpty(l)) {
				return CollectionsUtil.getFirst(l).getTemplateBinary()
						.toByteArray();
			}

			return null;
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(),
					"getExtractJobBinary", stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	// /////////////////// REGISTRATION FUNCTIONS ////////////////////////

	@WebMethod
	public void insert(@WebParam(name = "externalId") String externalId,
			@WebParam(name = "eventId") int eventId,
			@WebParam(name = "reqs") List<RegistrationRequest> reqs)
			throws AimRuntimeException {		
		NDC.push("insert");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBSyncJobRequest request = convert.toPBSyncJobRequest(externalId,
					eventId, reqs);
			syncService.syncData(request);
			if (log.isDebugEnabled()) {
				log.debug("insert succeeded, ecternalId = " + externalId
						+ ", eventId = " + eventId);
			}
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "insert",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	public void update(@WebParam(name = "externalId") String externalId,
			@WebParam(name = "eventId") int eventId,
			@WebParam(name = "reqs") List<RegistrationRequest> reqs,
			@WebParam(name = "containerIdsToDelete") List<Integer> containerIds)
			throws AimRuntimeException {		
		NDC.push("update");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBSyncJobRequest request = convert.toPBSyncJobRequest(externalId,
					eventId, reqs, containerIds);
			syncService.syncData(request);
			if (log.isDebugEnabled()) {
				log.debug("update succeeded, ecternalId = " + externalId
						+ ", eventId = " + eventId);
			}
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "update",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	public int delete(@WebParam(name = "externalId") String externalId,
			@WebParam(name = "eventId") Integer eventId,
			@WebParam(name = "containerIds") List<Integer> containerIds)
			throws AimRuntimeException {		
		NDC.push("delete");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBSyncJobRequest request = convert.toPBSyncJobRequest(externalId,
					eventId, containerIds);

			final AtomicInteger delCount = new AtomicInteger();
			syncService.syncData(request, delCount);
			if (log.isDebugEnabled()) {
				log.debug("Deleted " + delCount.get()
						+ " records, ecternalId = " + externalId
						+ ", eventId = " + eventId);
			}
			return delCount.get();
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "delete",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	// /////////////////// INQUIRY FUNCTIONS ///////////////////////

	@WebMethod
	public long search(
			@WebParam(name = "searchRequests") List<SearchRequest> searchRequests,
			@WebParam(name = "commonOptions") CommonOptions options,
			@WebParam(name = "mateExternalId") String mateExternalId)
			throws AimRuntimeException {		
		NDC.push("search");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
					searchRequests, options);
			PBInquiryJobResponse response = inquiryService.inquiry(request,
					false);
			return response.getJobId();
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "search",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	// /////////////////// JOB CONTROL FUNCTIONS ////////////////////////

	@WebMethod
	public void deleteJob(@WebParam(name = "jobType") JobType jobType,
			@WebParam(name = "jobId") long jobId) throws AimRuntimeException {		
		NDC.push("deleteJob");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			switch (jobType) {
			case SEARCH:
				inquiryService.deleteJob(convert.toPBDeleteJobRequest(jobId));
				break;
			case EXTRACT:
				extractService.deleteJob(convert.toPBDeleteJobRequest(jobId));
				break;
			default:
				break;
			}
		} catch (RuntimeException e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "deleteJob",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	public void clearJobs(@WebParam(name = "jobType") JobType jobType)
			throws AimRuntimeException {		
		NDC.push("clearJobs");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			switch (jobType) {
			case SEARCH:
				inquiryService.clearJobs();
				break;
			case EXTRACT:
				extractService.clearJobs();
				break;
			default:
				break;
			}
		} catch (RuntimeException e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "clearJobs",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	public SearchJobResult getSearchJobResult(
			@WebParam(name = "jobId") long jobId) throws AimRuntimeException {		
		NDC.push("getSearchJobResult");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBInquiryJobResult result = inquiryService.getJobResult(convert
					.toPBJobResultRequest(jobId));
			return webConvert.toSearchJobResult(result);
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(),
					"getSearchJobResult", stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	public JobStatus getJobStatus(@WebParam(name = "jobType") JobType jobType,
			@WebParam(name = "jobId") long jobId) throws AimRuntimeException {		
		NDC.push("getJobStatus");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBJobStatusResponse response = null;
			switch (jobType) {
			case SEARCH:
				response = inquiryService.getJobStatus(convert
						.toPBJobStatusRequest(jobId));
				break;
			case EXTRACT:
				response = extractService.getJobStatus(convert
						.toPBJobStatusRequest(jobId));
				break;
			default:
				break;
			}
			return webConvert.toJobStatus(response);
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "getJobStatus",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	public void callbackTest(
			@WebParam(name = "callbackURL") String callbackURL,
			@WebParam(name = "testString") String body)
			throws AimRuntimeException {		
		NDC.push("callbackTest");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			final int retryCount = configDao
					.getMMPropertyInt(MMConfigProperty.CLIENT_POST_COUNT);
			HttpPoster.post(callbackURL, body, retryCount);
		} catch (RuntimeException e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "callbackTest",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	@WebMethod
	@WebResult(name = "check-results", targetNamespace = "urn:nec:aim")
	public CheckResults checkExternalId(
			@WebParam(name = "externalId") String externalId,
			@WebParam(name = "eventIds") List<Integer> eventIds,
			@WebParam(name = "containerIds") List<Integer> containerIds)
			throws AimRuntimeException {		
		NDC.push("checkExternalId");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBCheckExternalIdRequest request = convert
					.toPBChechkExternalIdRequest(externalId, eventIds,
							containerIds);
			PBCheckExternalIdResponse response = manageService
					.checkExternalId(request);
			return webConvert.toCheckResults(response);
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(),
					"checkExternalId", stopWatch.elapsedTime());
			NDC.clear();
		}
	}
}
