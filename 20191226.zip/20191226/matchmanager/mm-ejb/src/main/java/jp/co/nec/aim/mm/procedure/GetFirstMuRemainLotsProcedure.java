package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.extract.planner.MuRemainLots;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import io.netty.util.internal.StringUtil;

/**
 * pickup one mu that is best fit to assign job to it
 * 
 * @author xiazp
 */
public class GetFirstMuRemainLotsProcedure extends StoredProcedure {
	private static final String SQL = "get_first_mu_remain_lots";
	private Integer maxLot;
	private JdbcTemplate jdbcTemplate;

	public GetFirstMuRemainLotsProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_max_lot", Types.INTEGER));
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));
		compile();
	}

	public MuRemainLots getfirstMuRemainLots(int maxMuLot)
			throws DataAccessException, SQLException {
		if (maxMuLot < 0) {
			throw new IllegalArgumentException("Max Mu Lot is null or empty"
					+ " when call getfirstMuRemainLots");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_max_lot", maxMuLot);
		Map<String, Object> resultMap = execute(map);
		if (resultMap.values().toString().equals("[[]]")) {
			return null;
		}
		String tableName = (String) resultMap.get("tab_name");
		if (StringUtils.isBlank(tableName)) return null;			
		String sql = "select * from " + tableName;
		 List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		 if (results.size() < 1) return null;
		 Integer muId =   (Integer) results.get(0).get("mu_id");
		Integer currentlots =  (Integer) results.get(0).get("currentlots");
		Integer numExtractor =  (Integer) results.get(0).get("num_extractor");
		Integer remainLots =  (Integer) results.get(0).get("remain_lots");
		MuRemainLots muRemainLots = new MuRemainLots();
		muRemainLots.setMuId(Long.valueOf(muId.longValue()));
		muRemainLots.setCureentLots(currentlots);
		muRemainLots.setNumOfExtractor( numExtractor);
		muRemainLots.setRemainLots(remainLots);
		return muRemainLots;
	}

	public Integer getMaxLot() {
		return maxLot;
	}

	public void setMaxLot(Integer maxLot) {
		this.maxLot = maxLot;
	}
}
