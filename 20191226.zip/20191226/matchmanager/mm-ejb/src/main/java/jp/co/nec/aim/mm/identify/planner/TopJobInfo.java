package jp.co.nec.aim.mm.identify.planner;

import java.util.Comparator;
import java.util.List;

public class TopJobInfo implements Comparator<TopJobInfo> {
	private Long topJobId;
	private int familyId;
	private List<CombinedJobInfo> combinedJobInfoList;

	public Long getTopJobId() {
		return topJobId;
	}

	public void setTopJobId(Long topJobId) {
		this.topJobId = topJobId;
	}

	public List<CombinedJobInfo> getCombinedJobInfoList() {
		return combinedJobInfoList;
	}

	public void setCombinedJobInfoList(List<CombinedJobInfo> combinedJobInfoList) {
		this.combinedJobInfoList = combinedJobInfoList;
	}

	public int getFamilyId() {
		return familyId;
	}

	public void setFamilyId(int familyId) {
		this.familyId = familyId;
	}

	@Override
	public int compare(TopJobInfo o1, TopJobInfo o2) {
		return o1.getTopJobId().compareTo(o2.getTopJobId());
	}

}
