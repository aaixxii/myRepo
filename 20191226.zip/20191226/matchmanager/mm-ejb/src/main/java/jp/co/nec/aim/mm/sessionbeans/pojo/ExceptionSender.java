package jp.co.nec.aim.mm.sessionbeans.pojo;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import jp.co.nec.aim.baton.AimException;
import jp.co.nec.aim.baton.constant.LogKey;
import jp.co.nec.aim.baton.constant.LogType;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.logger.DuplicateMessageFilter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExceptionSender {
	private static Logger log = LoggerFactory.getLogger(ExceptionSender.class);

	private JmsSender jmsSender;

	public ExceptionSender() {
		jmsSender = JmsSender.getInstance();
	}

	/**
	 * sending the message included AimException for general.
	 * 
	 * General means the message don't have muId, jobId and topLevelId.
	 * 
	 * @param reasonCode
	 * @param message
	 * @param e
	 */
	public void sendAimException(String reasonCode, String message, Exception e) {
		sendAimException(reasonCode, message, -1L, -1L, -1L, e);
	}

	/**
	 * sending the message included AimException which has jobId, topLevelJobId
	 * and muId.
	 * 
	 * If such as jobId is nullValue, this method dosen't set value into
	 * AimException.
	 * 
	 * If an error occurred in this method, there is nothing to do except
	 * writing a error log.
	 * 
	 * If reasonCode is null, AIM_DEFAULT is set into reasonCode.
	 * 
	 * @param reasonCode
	 * @param message
	 * @param jobId
	 * @param topLevelId
	 * @param unitId
	 * @param e
	 */
	public void sendAimException(String reasonCode, String message, long jobId,
			long topLevelId, long unitId, Exception e) {
		send(reasonCode, message, jobId, topLevelId, unitId, e);
	}

	/**
	 * This method should be used from some messages from MU only.<br>
	 * This method don't have to use from MM's inside logic.
	 * 
	 * @param reasonCode
	 * @param message
	 * @param jobId
	 * @param topLevelId
	 * @param unitId
	 * @param e
	 */
	private void send(String reasonCode, String message, long jobId,
			long topLevelId, long unitId, Exception e) {
		// get DuplicateMessageFilter from BeanFactory, it's Singleton.
		DuplicateMessageFilter filter = DuplicateMessageFilter.getInstance();
		if (filter.isDuplicate(reasonCode)) {
			log.info(reasonCode + " isn't sent because duplicate.");
			return;
		}

		Throwable exception = (e != null && e.getCause() != null) ? e
				.getCause() : e;
		AimException aimException = new AimException(message, exception);
		if (jobId != -1L) {
			aimException.setId(jobId);
		}
		if (topLevelId != -1L) {
			aimException.setTopLevelJobId(topLevelId);
		}
		if (unitId != -1L) {
			aimException.setMuId(unitId);
		}
		if (reasonCode == null || reasonCode.length() <= 0) {
			reasonCode = AimError.INTERNAL_ERROR.getErrorCode();
		}
		Map<String, Serializable> map = new HashMap<String, Serializable>(3);
		map.put(LogKey.REASON_CODE.getKey(), reasonCode);
		map.put(LogKey.EXCEPTION.getKey(), aimException);
		map.put(LogKey.TYPE.getKey(), LogType.EXCEPTION.getType());
		log.warn(reasonCode + " " + aimException.getMessage());

		// send the object to error queue
		jmsSender.sendToErrorQueue(map);
	}
}
