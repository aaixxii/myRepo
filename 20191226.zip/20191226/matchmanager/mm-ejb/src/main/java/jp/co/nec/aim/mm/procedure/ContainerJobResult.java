package jp.co.nec.aim.mm.procedure;

public class ContainerJobResult {
	byte[] containerJobsResult;
	
 public ContainerJobResult(byte[] jobResult) {
	 this.containerJobsResult = jobResult;
 }
 
 public ContainerJobResult() {
	 
 }

	/**
	 * @return the containerJobsResult
	 */
	public byte[] getContainerJobsResult() {
		return containerJobsResult;
	}

	/**
	 * @param containerJobsResult
	 *            the containerJobsResult to set
	 */
	public void setContainerJobsResult(byte[] containerJobsResult) {
		this.containerJobsResult = containerJobsResult;
	}

}
