package jp.co.nec.aim.mm.exception;

import org.apache.commons.lang3.StringUtils;

/**
 * TemplateValidatorException
 * 
 * @author liuyq
 * 
 */
public class TemplateValidatorException extends AimErrorInfoException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5670653981311541162L;

	/**
	 * ArgumentException
	 * 
	 * @param errorCode
	 *            error code
	 * @param description
	 *            error description
	 * @param epochTime
	 *            error epoch time
	 */
	public TemplateValidatorException(String errorCode, String description,
			String epochTime) {
		super(errorCode, description, epochTime);
	}

	/**
	 * TemplateValidatorException
	 * 
	 * @param errorCode
	 * @param description
	 */
	public TemplateValidatorException(String errorCode, String description) {
		super(errorCode, description, StringUtils.EMPTY);
	}

}
