package jp.co.nec.aim.mm.identify.planner;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.EJB;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.sql.DataSource;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.IdentifyPlannerDao;
import jp.co.nec.aim.mm.dao.IdentifyPlannerDaoImpl;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.notifier.IdentifyPlanCreatedNotifer;
import jp.co.nec.aim.mm.util.StopWatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

/**
 * 
 * @author xiazp
 * 
 */
@Singleton
@Startup
@TransactionManagement(TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class IdentifyPlanManager {
	private static final Logger logger = LoggerFactory
			.getLogger(IdentifyPlanManager.class);
	private static String INQUIRY_DISTRIBUTOR_QUEUE = "IdentifyDispatchQueue";
	private static final int COMMIT_THREASHOLD_MAX_LIMIT = 10;
	private static final int COMMIT_THREASHOLD_MIN_LIMIT = 1;

	private ResoureceUpdateCount RUC = new ResoureceUpdateCount();
	private ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> memMuSegmentMaps = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();
	private IdentifyPlannerDao identifyDao;
	private DateDao dateDao;
	private int commitThreashold = (COMMIT_THREASHOLD_MAX_LIMIT + COMMIT_THREASHOLD_MIN_LIMIT) / 2;

	@Resource
	private UserTransaction userTransaction;
	@EJB
	IdentifyPlanCreatedNotifer notifer;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	public IdentifyPlanManager() {
	}

	@PostConstruct
	public void IndentiyPlannerStartup() {
		initialize();

	}

	@PreDestroy
	public void IndentiyPlannerShutdown() {
		identifyDao = null;
		dateDao = null;
	}

	private List<MuJobExecutePlan> muPlans = new ArrayList<MuJobExecutePlan>();

	@Lock(LockType.WRITE)
	private void initialize() {
		dateDao = new DateDao(dataSource);
		identifyDao = new IdentifyPlannerDaoImpl(dataSource, entityManager);
		RUC.setUpdateCount(0);
		try {
			identifyDao.setRUC(0L);
		} catch (PersistenceException | SQLException e) {
			logger.error(e.getMessage(), e);
			try {
				throw e;
			} catch (Exception e1) {
				logger.error(e1.getMessage(), e);
			}
		}
	}

	/**
	 * making mu executing plans for all queued jobs which job counts is under
	 * limited jobs
	 * 
	 * @return
	 */
	@Lock(LockType.WRITE)
	public void doMakePlanProcess() {
		logger.debug("IdentiyPlanner prepare to making mu executing plans...");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<TopJobInfo> jobInfoList = new ArrayList<TopJobInfo>();
		ConcurrentHashMap<MuSegmentMapKey, Boolean> alreadyPlannedMap = new ConcurrentHashMap<MuSegmentMapKey, Boolean>();
		try {
			Integer numOfMR = identifyDao.getWorkingMR();
			if (numOfMR < 1) {
				logger.warn("No MR is in working! skip creating plan.");
				return;
			}

			List<Long> limitedJobList = identifyDao.getLimitedJobsByFamiliy();
			if (limitedJobList == null || limitedJobList.size() < 0) {
				logger.debug("No job for create identify plans,Skip creating plan.");
				return;
			}

			Long[] jobIds = new Long[limitedJobList.size()];
			limitedJobList.toArray(jobIds);
			jobInfoList = identifyDao.getJobInfoForCreatePlans(jobIds);
			if (jobInfoList == null || jobInfoList.size() < 0) {
				logger.warn("Got empty job info from DB! IndentiyPlanner will be return.");
				return;
			}

			if (logger.isDebugEnabled()) {
				debugTopJobInfoList(jobInfoList);
			}

		} catch (PersistenceException | DataAccessException | SQLException e) {
			logger.error("IndentiyPlanner returned due to "
					+ e.getClass().getName(), e);
			return;
		}
		boolean isSuccess = doBatchPlanning(jobInfoList, alreadyPlannedMap);
		if (isSuccess) {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(),
					"doMakePlanProcess", stopWatch.elapsedTime());
		}
	}

	private void debugTopJobInfoList(List<TopJobInfo> jobInfoList) {
		StringBuilder sb = new StringBuilder();
		for (TopJobInfo oneTopJob : jobInfoList) {
			sb.append("[");
			sb.append(String.valueOf(oneTopJob.getTopJobId()));
			for (CombinedJobInfo info : oneTopJob
					.getCombinedJobInfoList()) {
				sb.append("(");
				sb.append(info.getContaierJobId());
				sb.append(",");
				sb.append(info.getContainerId());
				sb.append(",");
				sb.append(info.getFunctionId());
				sb.append(")");
			}
			sb.append("]");
		}
		logger.debug("Got JobInfoList: " + sb.toString());
	}

	private boolean doBatchPlanning(List<TopJobInfo> jobInfoList,
			ConcurrentHashMap<MuSegmentMapKey, Boolean> alreadyPlannedKeyMap) {
		logger.info("Start {} search jobs planning", jobInfoList.size());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		int plannedCnt = 0;
		try {
			userTransaction.begin();
			int lastFamilyId = jobInfoList.get(0).getFamilyId();
			for (TopJobInfo oneJob : jobInfoList) {
				int currentFamilyId = oneJob.getFamilyId();
				if (0 < plannedCnt
						&& (commitThreashold <= plannedCnt || lastFamilyId != currentFamilyId)) {

					if (logger.isDebugEnabled()) {
						logger.debug(
								"Already {} times planned or changed familyId against previous one."
										+ " Try commit.",
								commitThreashold);
					}

					userTransaction.commit();
					userTransaction.begin();
					commitThreashold = Math.min(++commitThreashold,
							COMMIT_THREASHOLD_MAX_LIMIT);
					plannedCnt = 0;
					lastFamilyId = currentFamilyId;
				}

				if (!planAndDispatch1Tlj(alreadyPlannedKeyMap, oneJob)) {
					userTransaction.rollback();
					userTransaction.begin();
					commitThreashold = Math.max(--commitThreashold,
							COMMIT_THREASHOLD_MIN_LIMIT);
					plannedCnt = 0;
					continue;
				}
				plannedCnt++;
			}
			userTransaction.commit();
		} catch (NotSupportedException | SystemException | SecurityException
				| IllegalStateException | RollbackException
				| HeuristicMixedException | HeuristicRollbackException e) {
			logger.error(
					"Exception happend during making search job planning.", e);
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(),
					"doBatchPlanning-fail", stopWatch.elapsedTime());
			try {
				userTransaction.rollback();
			} catch (IllegalStateException | SecurityException
					| SystemException e1) {
				logger.error("Rollback failed!!", e1);
			}
			return false;
		}
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doBatchPlanning",
				stopWatch.elapsedTime());
		return true;
	}

	private boolean planAndDispatch1Tlj(
			ConcurrentHashMap<MuSegmentMapKey, Boolean> alreadyPlannedMap,
			TopJobInfo oneJob) {
		StopWatch sw = new StopWatch();
		sw.start();
		long jobId = oneJob.getTopJobId();
		try {
			try {
				identifyDao.lockJobQueueRowForProcess(jobId);
			} catch (Exception e) {
				logger.warn(
						"Coudn't get JOB_QUEUE lock jobId={}. Othre mm already got it to creaet job plan",
						jobId);
				return true;
			}
			logger.info("Start planning jobId={}", jobId);
			muPlans = processOneJob(oneJob, alreadyPlannedMap);
			if (muPlans == null || muPlans.size() <= 0) {
				logger.warn(
						"Search job planning process has rollbacked due to top job(JobId={}) planning was failed.",
						jobId);
				return false;
			} else {
				CompressUtil util = new CompressUtil();
				byte[] byteJms = util.zipCompressWithPlanId(muPlans);
				boolean updateInquiryTrafficSuccessed = false;
				boolean notifySuccssed = false;
				updateInquiryTrafficSuccessed = identifyDao
						.updateInquiryTraffic(jobId);
				notifySuccssed = notifer.sendCompressedByte(byteJms);
				if (updateInquiryTrafficSuccessed && notifySuccssed) {
					logger.info(
							"IndendifyPlanner success to queueing top job(JobId={}) plans to JMS <{}>.",
							oneJob.getTopJobId(), INQUIRY_DISTRIBUTOR_QUEUE);
				} else {
					if (!updateInquiryTrafficSuccessed) {
						logger.warn(
								"Search job planning process has rollbacked due to updateInquiryTraffic is failed for topJob({})",
								jobId);
					}
					if (!notifySuccssed) {
						logger.warn(
								"Search job planning process has rollbacked due to queueing top job(JobId={}) plans to JMS <{}> was failed.",
								jobId, INQUIRY_DISTRIBUTOR_QUEUE);
					}
					return false;
				}
			}
		} catch (Exception e) {
			logger.error(
					"Transaction rollbacked due to other exception! jobId={}",
					jobId, e);
			return false;
		}
		sw.stop();
		PerformanceLogger.log(getClass().getSimpleName(),
				"planAndDispatch1Tlj", sw.elapsedTime());
		return true;
	}

	/**
	 * 
	 * @param jobInfo
	 * @return
	 */
	private List<MuJobExecutePlan> processOneJob(TopJobInfo jobInfo,
			ConcurrentHashMap<MuSegmentMapKey, Boolean> alreadyPlannedMap) {
		logger.debug("IndentiyPlanner processOneJob process is running...");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		if (!updateMemSegVer(jobInfo, alreadyPlannedMap)) {
			logger.warn("Failed to update memory segment version!! Abort search job planning.");
			return null;
		}

		List<MuJobExecutePlan> muJobExecuteplans = new ArrayList<MuJobExecutePlan>();
		for (CombinedJobInfo info : jobInfo.getCombinedJobInfoList()) {
			String planStringPerContainer = makePlanString(jobInfo, info);
			if (planStringPerContainer == null
					|| planStringPerContainer.isEmpty()) {
				logger.warn(
						"IdentifyPlanner created empty identify job plan! for funcitonId={},containerID = {}",
						info.getFunctionId(), info.getContainerId());
				return null;
			}
			logger.debug(
					"IdentifyPlanner created plan:{} for jobId:{} funtionId:{} containerId:{}",
					planStringPerContainer.toString(), jobInfo.getTopJobId(),
					info.getFunctionId(), info.getContainerId());

			Long planId = updateAfterPlanned(jobInfo, info,
					planStringPerContainer);
			if (planId == null || planId.longValue() < 0L) {
				logger.warn("PlanId is incorrect! It is null or less than 0!");
				return null;
			}
			logger.info(
					"IndendifyPlanner has succeeded to create planId:{} for jobId:{} funtionId:{} containerId:{}",
					planId, jobInfo.getTopJobId(), info.getFunctionId(),
					info.getContainerId());
			addJobExecutePlan(jobInfo, muJobExecuteplans, info,
					planStringPerContainer, planId);
		}
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "processOneJob",
				stopWatch.elapsedTime());
		logger.debug("processOneJob(JobId:{}) success finished.",
				jobInfo.getTopJobId());
		return muJobExecuteplans;
	}

	private Long updateAfterPlanned(TopJobInfo jobInfo, CombinedJobInfo info,
			String planStringPerContainer) {
		Long planId;
		try {
			planId = identifyDao.updateAfterPlanned(jobInfo.getTopJobId(),
					info.getContainerId(), info.getContaierJobId(),
					info.getFunctionId(), planStringPerContainer);
		} catch (PersistenceException e) {
			logger.error(
					"Failed to update JOB_STATE of JOB_QUEUE and CONTAINERS_JOBS!!",
					e);
			return null;
		}
		return planId;
	}

	private String makePlanString(TopJobInfo jobInfo, CombinedJobInfo info) {
		MuSegmentMapKey key = new MuSegmentMapKey(info.getFunctionId(),
				info.getContainerId());
		List<MuSegmentMap> muSegMapList = memMuSegmentMaps.get(key);
		List<MuCpuAndPressure> muCpuAndPressureList = null;
		try {
			muCpuAndPressureList = identifyDao
					.getMuCpuAndPressure(fetchMuIdsFromMuSegMap(muSegMapList));
			if (muCpuAndPressureList == null) {
				logger.warn(
						"Number of working MU is decrease during planning MuJob assignment."
								+ " Skip distributing MuJob of TopLevelJobId {}",
						jobInfo.getTopJobId());
				return null;
			}
		} catch (PersistenceException | SQLException e) {
			logger.error("Failed to get MU CPU ability and pressure from DB!!",
					e);
			return null;
		}
		MuExcutionPlanCreator creator = new MuExcutionPlanCreator(muSegMapList,
				muCpuAndPressureList, dateDao);
		String planStringPerContainer = creator.createMuPlans();
		return planStringPerContainer;
	}

	private void addJobExecutePlan(TopJobInfo jobInfo,
			List<MuJobExecutePlan> muJobExecuteplans, CombinedJobInfo info,
			String planStringPerContainer, Long planId) {
		MuJobExecutePlan muPlan = new MuJobExecutePlan();
		muPlan.setContainerId(info.getContainerId());
		muPlan.setJobId(jobInfo.getTopJobId());
		muPlan.setFunctionId(info.getFunctionId());
		muPlan.setPlanId(planId);
		muPlan.setPlan(planStringPerContainer);
		muJobExecuteplans.add(muPlan);
	}

	private boolean updateMemSegVer(TopJobInfo jobInfo,
			ConcurrentHashMap<MuSegmentMapKey, Boolean> alreadyPlannedMap) {
		List<MuSegmentMapKey> muSegKeys = makeUniqeKey(jobInfo
				.getCombinedJobInfoList());
		long dbRUC;
		try {
			dbRUC = identifyDao.getRUCFromDB();
			if (logger.isDebugEnabled()) {
				logger.debug("RUC in db = {}", dbRUC);
				logger.debug("RUC in memory = {}", this.getRUC()
						.getUpdateCount());
			}
		} catch (PersistenceException | SQLException e) {
			logger.error("Couldn't get RUC value from DB!!", e);
			return false;
		}

		if (dbRUC != getRUC().getUpdateCount()
				|| memMuSegmentMaps.size() == 0) {
			// Update MuSegmentMaps which MM already has
			for (MuSegmentMapKey muSegKey : memMuSegmentMaps.keySet()) {
				if (!doUpdateMuSegMapsFromDB(muSegKey, jobInfo.getTopJobId())) {
					return false;
				}
				alreadyPlannedMap.put(muSegKey, true);
			}
			// Get MuSegmentMaps from DB if MM doesn't have.
			for (MuSegmentMapKey muSegKey : muSegKeys) {
				if (!memMuSegmentMaps.containsKey(muSegKey)) {
					if (!doUpdateMuSegMapsFromDB(muSegKey,
							jobInfo.getTopJobId())) {
						return false;
					}
					alreadyPlannedMap.put(muSegKey, true);
				}
			}
			getRUC().setUpdateCount(dbRUC);
		} else {
			for (MuSegmentMapKey muSegKey : muSegKeys) {
				if (!memMuSegmentMaps.containsKey(muSegKey)
						|| memMuSegmentMaps.get(muSegKey).size() == 0) {
					if (!doUpdateMuSegMapsFromDB(muSegKey,
							jobInfo.getTopJobId())) {
						return false;
					}
					alreadyPlannedMap.put(muSegKey, true);
				} else {
					if (alreadyPlannedMap.get(muSegKey) == null
							|| !alreadyPlannedMap.get(muSegKey)) {
						if (!doUpdateMuSegMapsFromMem(muSegKey,
								jobInfo.getTopJobId())) {
							return false;
						}
						alreadyPlannedMap.put(muSegKey, true);
					} else {
						if (logger.isDebugEnabled()) {
							logger.debug(
									"Skip fetching segment version because already got it at the previous planning. MuSegKey={}",
									muSegKey.toString());
						}
					}
				}
			}
		}
		return true;
	}

	private List<MuSegmentMapKey> makeUniqeKey(
			List<CombinedJobInfo> combinedJobInfoList) {
		List<MuSegmentMapKey> resultKeys = new ArrayList<MuSegmentMapKey>();
		MuSegmentMapKey currentKey = new MuSegmentMapKey(combinedJobInfoList
				.get(0).getFunctionId(), combinedJobInfoList.get(0)
				.getContainerId());
		for (int i = 1; i < combinedJobInfoList.size(); i++) {
			if (combinedJobInfoList.get(i).getFunctionId().intValue() == currentKey
					.getFunctionId().intValue()
					&& combinedJobInfoList.get(i).getContainerId().intValue() == currentKey
							.getContainerId()) {
				continue;
			} else {
				resultKeys.add(currentKey);
				currentKey = null;
				currentKey = new MuSegmentMapKey(combinedJobInfoList.get(i)
						.getFunctionId(), combinedJobInfoList.get(i)
						.getContainerId());
			}
		}
		resultKeys.add(currentKey);
		return resultKeys;
	}

	private synchronized boolean doUpdateMuSegMapsFromDB(
			MuSegmentMapKey muSegKey, Long jobId) {
		logger.info(
				"Start updating memory MU_SEGMENT_MAP (functionId:{},ContainerId:{}) from DB.",
				muSegKey.getFunctionId(), muSegKey.getContainerId());
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<MuSegmentMap> tmpMap = null;
		try {
			tmpMap = identifyDao.getNewMuSegMaps(muSegKey.getContainerId(),
					muSegKey.getFunctionId());
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return false;
		}
		if (tmpMap == null) {
			logger.warn(
					"Got empty muSegmentMap! Can't create excuting plan for (functionId = {},containerid = {})",
					muSegKey.getFunctionId(), muSegKey.getContainerId());
			return false;
		}
		if (memMuSegmentMaps.contains(muSegKey)) {
			memMuSegmentMaps.remove(muSegKey);
		}
		memMuSegmentMaps.put(muSegKey, tmpMap);
		logger.info("Success to update memory MU_SEGMENT_MAP from DB.");
		if (!segCountIsEqual(muSegKey, jobId)) {
			return false;
		}
		stopWatch.stop();
		String muSegKeyStr = String.format("doUpdateMuSegMapsFromDB-%d-%d",
				muSegKey.getFunctionId(), muSegKey.getContainerId());
		PerformanceLogger.log(getClass().getSimpleName(), muSegKeyStr,
				stopWatch.elapsedTime());
		return true;
	}

	private boolean doUpdateMuSegMapsFromMem(MuSegmentMapKey muSegKey,
			Long jobId) {
		if (!segCountIsEqual(muSegKey, jobId)) {
			return false;
		}
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<MuSegmentMap> tempMap = memMuSegmentMaps.get(muSegKey);
		List<SegmentIdAndVeison> newSegVersions = null;
		try {
			newSegVersions = identifyDao
					.getSegmentVersionByContainerId(muSegKey.getContainerId());
		} catch (PersistenceException | SQLException e) {
			logger.error(e.getMessage(), e);
			return false;
		}
		if (newSegVersions == null) {
			logger.warn(
					"There are any wrong! Got empty data while fetching new semgemts version from containerId = {} functionId = {}",
					muSegKey.getContainerId(), muSegKey.getFunctionId());
			return false;
		}
		for (MuSegmentMap map : tempMap) {
			for (SegmentIdAndVeison sv : newSegVersions) {
				if (map.getSegmentId().longValue() == sv.getSegmentId()
						.longValue()) {
					map.setSegmentVersion(sv.getVersion());
					break;
				}
			}
		}
		stopWatch.stop();
		String muSegKeyStr = String.format("doUpdateMuSegMapsFromMem-%d-%d",
				muSegKey.getFunctionId(), muSegKey.getContainerId());
		PerformanceLogger.log(getClass().getSimpleName(), muSegKeyStr,
				stopWatch.elapsedTime());
		return true;
	}

	private boolean segCountIsEqual(MuSegmentMapKey muSegKey, Long jobId) {
		int segmentCountDB;
		try {
			segmentCountDB = identifyDao.getSegmentCount(muSegKey
					.getContainerId());
		} catch (PersistenceException | SQLException e) {
			logger.error(e.getMessage(), e);
			return false;
		}
		int segmentCountMem = calculatingSegmentCount(muSegKey);
		if (segmentCountDB != segmentCountMem) {
			logger.warn(
					"The count of segments in db is not equal it's in memory! "
							+ "DB count={} Mem count={} jobId={} functionId={} containerId={}",
					segmentCountDB, segmentCountMem, jobId,
					muSegKey.getFunctionId(), muSegKey.getContainerId());
		}
		return segmentCountDB == segmentCountMem;
	}

	@Lock(LockType.WRITE)
	private ResoureceUpdateCount getRUC() {
		return RUC;
	}

	@Lock(LockType.WRITE)
	private void setRUC(ResoureceUpdateCount rUC) {
		RUC = rUC;
	}

	@SuppressWarnings("unused")
	private ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> getMemMuSegmentMaps() {
		return memMuSegmentMaps;
	}

	@Lock(LockType.WRITE)
	protected void setMemMuSegmentMaps(
			ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> memMuSegmentMaps) {
		this.memMuSegmentMaps = memMuSegmentMaps;
	}

	@Lock(LockType.WRITE)
	private Integer calculatingSegmentCount(MuSegmentMapKey muSegKey) {
		int count = 0;
		List<MuSegmentMap> tmpMaps = null;
		Set<MuSegmentMapKey> muSegmentMapKeys = memMuSegmentMaps.keySet();
		for (MuSegmentMapKey key : muSegmentMapKeys) {
			if (key.equals(muSegKey)) {
				tmpMaps = memMuSegmentMaps.get(key);
				break;
			}
		}
		Collections.sort(tmpMaps, new MuSegmentMapComparator());
		long currentSegId = tmpMaps.get(0).getSegmentId().longValue();
		count++;
		for (int i = 0; i < tmpMaps.size(); i++) {
			if (currentSegId != tmpMaps.get(i).getSegmentId().longValue()) {
				count++;
				currentSegId = tmpMaps.get(i).getSegmentId();
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Segment counts in memory = {}", count);
		}
		return count;
	}

	/**
	 * 
	 * @param muSegMaps
	 * @return
	 */
	@Lock(LockType.WRITE)
	private Set<Integer> fetchMuIdsFromMuSegMap(List<MuSegmentMap> muSegMaps) {
		Set<Integer> muIds = new HashSet<Integer>();
		for (MuSegmentMap map : muSegMaps) {
			muIds.add(map.getMuId());
		}
		if (logger.isDebugEnabled()) {
			StringBuilder sb = new StringBuilder();
			for (Integer one : muIds) {
				sb.append(String.valueOf(one));
				sb.append(" ");
			}
			logger.debug("fetched MuIds from memory map:", sb.toString());
		}
		return muIds;
	}
}
