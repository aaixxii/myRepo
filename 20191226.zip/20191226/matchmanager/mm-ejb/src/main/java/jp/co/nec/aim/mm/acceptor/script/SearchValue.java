package jp.co.nec.aim.mm.acceptor.script;

import java.util.List;
import java.util.Set;

import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;

import com.google.common.collect.Lists;

/**
 * SearchValue
 * 
 * @author liuyq
 * 
 */
public final class SearchValue implements Value {
	/** fusion weights list **/
	private List<PBInquiryFusionWeight> fwList = Lists.newArrayList();
	private Integer containerId; // containerId
	private Integer scope; // scope

	/**
	 * the default constructor
	 */
	public SearchValue() {
	}

	/**
	 * SearchValue
	 * 
	 * @param fwList
	 *            the list of PBInquiryFusionWeight
	 * @param containerId
	 *            containerId
	 * @param scope
	 *            scope
	 */
	public SearchValue(List<PBInquiryFusionWeight> fwList, Integer containerId,
			Integer scope) {
		this.fwList = fwList;
		this.containerId = containerId;
		this.scope = scope;

	}

	public List<PBInquiryFusionWeight> getFwList() {
		return fwList;
	}

	public void setFwList(List<PBInquiryFusionWeight> fwList) {
		this.fwList = fwList;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public Integer getScope() {
		return scope;
	}

	public void setScope(Integer scope) {
		this.scope = scope;
	}

	@Override
	public Set<Integer> getContainerIds() {
		throw new UnsupportedOperationException();
	}

}
