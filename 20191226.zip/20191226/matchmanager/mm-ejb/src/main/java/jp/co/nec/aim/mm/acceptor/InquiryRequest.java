package jp.co.nec.aim.mm.acceptor;

import java.io.Serializable;

import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;

/**
 * InquiryRequest
 * 
 * @author liuyq
 * 
 */
public final class InquiryRequest implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1485113056588337155L;

	private String functionName; // inquiry functionName
	private String containerIds; // container id list unique
	// Request instance Serialization
	// Fusion job [INQUIRY_JOB_DATA]
	private PBInquiryJobRequest.Builder request;

	/**
	 * InquiryRequest
	 * 
	 * @param containerId
	 * @param binary
	 * @param eventId
	 * @param externalId
	 */
	public InquiryRequest(String functionName, String containerIds,
			PBInquiryJobRequest.Builder request) {
		this.functionName = functionName;
		this.containerIds = containerIds;
		this.setRequest(request);
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}	

	public String getContainerIds() {
		return containerIds;
	}

	public void setContainerIds(String containerIds) {
		this.containerIds = containerIds;
	}

	public PBInquiryJobRequest.Builder getRequest() {
		return request;
	}

	public void setRequest(PBInquiryJobRequest.Builder request) {
		this.request = request;
	}
}
