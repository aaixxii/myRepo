package jp.co.nec.aim.mm.spring.jms;

import java.io.Serializable;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

/**
 * AIMMessageCoverter converts Object to JMS Object
 * 
 * @author kurosu
 * 
 */
public class AIMMessageConverter implements MessageConverter {

	/**
	 * Converts from javax.jms.Message to Object
	 */
	@Override
	public Object fromMessage(Message message) throws JMSException,
			MessageConversionException {
		if (message instanceof TextMessage) {
			return ((TextMessage) message).getText();
		} else if (message instanceof ObjectMessage) {
			return ((ObjectMessage) message).getObject();
		} else {
			return message;
		}
	}

	/**
	 * Converts from Object to JMS Object
	 */
	@Override
	public Message toMessage(Object object, Session session)
			throws JMSException, MessageConversionException {
		if (object instanceof String) {
			return session.createTextMessage((String) object);
		} else {
			return session.createObjectMessage((Serializable) object);
		}
	}
}
