package jp.co.nec.aim.mm.ws;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.ws.soap.SOAPFaultException;

import jp.co.nec.aim.clientapi.CommonOptions;
import jp.co.nec.aim.clientapi.afis.AfisDeletionFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisRegistrationFunctionEnum;
import jp.co.nec.aim.clientapi.afis.AfisUpdateFunctionEnum;
import jp.co.nec.aim.convert.ProtoClassConvert;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.mm.acceptor.service.AimExtractService;
import jp.co.nec.aim.mm.acceptor.service.AimInquiryService;
import jp.co.nec.aim.mm.acceptor.service.AimSyncService;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.jaxb.AfisTemplateSet;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.jboss.logging.NDC;
import org.jboss.ws.api.annotation.WebContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Published WebService for FACE.
 * 
 * @author f-kawakami
 * 
 */
@WebService(name = "FaceJobControlService")
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
@WebContext(contextRoot = "/AIMWebServices", secureWSDLAccess = false)
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public class FaceJobControl {
	private final static Logger log = LoggerFactory
			.getLogger(FaceJobControl.class);

	@EJB
	private AimSyncService syncService;

	@EJB
	private AimInquiryService inquiryService;

	@EJB
	private AimExtractService extractService;

	/** exception **/
	private ExceptionHelper exception;

	/** the common of Class Converter **/
	private ProtoClassConvert convert;

	/**
	 * Default constructor
	 */
	public FaceJobControl() {
	}

	/**
	 * Initial function
	 */
	@PostConstruct
	public void init() {
		this.convert = new ProtoClassConvert();
		this.exception = new ExceptionHelper();
	}

	/**
	 * Face Registration
	 * 
	 * @param externalId
	 * @param eventId
	 * @param afisTemplateSet
	 * @throws PIDFaultException
	 * @throws InvalidTemplateException
	 */
	@WebMethod
	public void FR(@WebParam(name = "externalId") String externalId,
			@WebParam(name = "eventId") int eventId,
			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
			throws AimRuntimeException {		
		NDC.push("FR");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBSyncJobRequest request = convert.toPBSyncJobRequest(
					AfisRegistrationFunctionEnum.FR, externalId, eventId,
					afisTemplateSet);
			syncService.syncData(request);
			if (log.isDebugEnabled()) {
				log.debug("FR succeeded, ecternalId = " + externalId
						+ ", eventId = " + eventId);
			}
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "FR",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	/**
	 * Face Update (Face Delete and Face Registration)
	 * 
	 * @param externalId
	 * @param eventId
	 * @param afisGroupId
	 * @param afisTemplateSet
	 * @throws PIDFaultException
	 * @throws InvalidTemplateException
	 */
	@WebMethod
	public void FU(@WebParam(name = "externalId") String externalId,
			@WebParam(name = "eventId") int eventId,
			@WebParam(name = "afisGroupId") Integer afisGroupId,
			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
			throws AimRuntimeException {		
		NDC.push("FU");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBSyncJobRequest request = convert.toPBSyncJobRequest(
					AfisUpdateFunctionEnum.FU, externalId, eventId,
					afisGroupId, afisTemplateSet);
			syncService.syncData(request);
			if (log.isDebugEnabled()) {
				log.debug("FU succeeded, ecternalId = " + externalId
						+ ", eventId = " + eventId + ", afisGroupId = "
						+ afisGroupId);
			}
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "FU",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	/**
	 * Face Delete
	 * 
	 * @param externalId
	 * @param eventId
	 * @param afisGroupId
	 * @throws PIDFaultException
	 */
	@WebMethod
	public void FD(@WebParam(name = "externalId") String externalId,
			@WebParam(name = "eventId") Integer eventId,
			@WebParam(name = "afisGroupId") Integer afisGroupId)
			throws AimRuntimeException {		
		NDC.push("FD");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBSyncJobRequest request = convert.toPBSyncJobRequest(
					AfisDeletionFunctionEnum.FD, externalId, eventId,
					afisGroupId);
			syncService.syncData(request);
			if (log.isDebugEnabled()) {
				log.debug("FD succeeded, ecternalId = " + externalId
						+ ", eventId = " + eventId + ", afisGroupId = "
						+ afisGroupId);
			}
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "FD",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}

	/**
	 * Face inquiry
	 * 
	 * @param afisTemplateSet
	 * @param commonOptions
	 * @return
	 * @throws PIDFaultException
	 */
	@WebMethod
	public long FI(
			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
			@WebParam(name = "commonOptions") CommonOptions commonOptions)
			throws AimRuntimeException {		
		NDC.push("FI");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			PBInquiryJobRequest request = convert
					.toPBInquiryJobRequest(AfisLowLevelFunctionEnum.FI,
							afisTemplateSet, commonOptions);
			PBInquiryJobResponse response = inquiryService.inquiry(request,
					false);
			return response.getJobId();
		} catch (Exception e) {
			throw new SOAPFaultException(exception.createSOAPFault(e));
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "FI",
					stopWatch.elapsedTime());
			NDC.clear();
		}
	}
}
