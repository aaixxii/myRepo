package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;
import jp.co.nec.aim.mm.identify.planner.MuSegmentMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class GetNewMuSegMapsProcedures extends StoredProcedure {
	private JdbcTemplate jdbcTemplate;
	private static final String GET_NEW_MU_SEG_MAPS = "get_new_mu_seg_maps";
	
	public GetNewMuSegMapsProcedures(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(GET_NEW_MU_SEG_MAPS);
		declareParameter(new SqlParameter("p_container_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_function_id", Types.BIGINT));
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));				
		compile();
	}

	/**
	 * 
	 * @param containerId
	 * @param fuctionId
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	public List<MuSegmentMap> getNewMuSegMaps(Integer containerId,
			Integer fuctionId) throws DataAccessException, SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_container_id", containerId);
		map.put("p_function_id", fuctionId);
		Map<String, Object> resultMap = execute(map);
		String tableName = (String) resultMap.get("tab_name");
		if (StringUtils.isBlank(tableName)) return null;
		String sql = "select * from " + tableName;
		 List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);
		 jdbcTemplate.execute("DROP TABLE IF EXISTS " + tableName);		 
		 final List<MuSegmentMap> newMuMaps =new ArrayList<>();
		result.forEach(one -> {			
			Integer muId =  (Integer) one.get("mu_id");
			Long segId = (Long) one.get("seg_id");
			Long segVer = (Long) one.get("seg_ver");
			Integer conId = (Integer) one.get("container_id");
			Integer funId = (Integer) one.get("function_id");
			MuSegmentMap mp = new MuSegmentMap();
			mp.setMuId(muId);
			mp.setSegmentId(segId);
			mp.setSegmentVersion(segVer);
			mp.setContainerId(conId);
			mp.setFunctionId(funId);
			newMuMaps.add(mp);
		});
		return newMuMaps;
	}

	/**
	 * 
	 * @author xiazp
	 *
	 */
	@SuppressWarnings("unused")
	private class CursorMapper implements RowMapper<MuSegmentMap> {
		@Override
		public MuSegmentMap mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			MuSegmentMap msMap = new MuSegmentMap();
			msMap.setContainerId(rs.getInt("container_id"));
			msMap.setMuId(rs.getInt("mu_id"));
			msMap.setSegmentId(rs.getLong("segment_id"));
			msMap.setSegmentVersion(rs.getLong("segment_version"));
			msMap.setFunctionId(rs.getInt("function_id"));
			return msMap;
		}
	}
}
