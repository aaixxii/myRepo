package jp.co.nec.aim.mm.segment.sync;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.google.common.collect.Maps;

import jp.co.nec.aim.message.proto.AIMMessages.PBCorruptTempalte;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentInfo;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SegmentDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.DmSegReportEntity;
import jp.co.nec.aim.mm.entities.MuSegReportEntity;
import jp.co.nec.aim.mm.entities.SegmentEntity;
import jp.co.nec.aim.mm.entities.UnitSegReport;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.procedure.MarkCorruptedTemplate;
import jp.co.nec.aim.mm.util.CollectionsUtil;

/**
 * The work flow of unit segment report related operation <br>
 * 
 * Persist the segment report information base on the latest <br>
 * segment version and report segment version <br>
 * 
 * @author liuyq
 * 
 */
public class SegReportManager {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(SegReportManager.class);

	/** SystemConfigDao instance **/
	private SystemConfigDao configDao;
	/** SegmentDao instance **/
	private SegmentDao segmentDao;
	/** EntityManager instance **/
	private EntityManager manager;
	/** DataSource instance **/
	private DataSource dataSource;	
	

	/**
	 * SegReportManager constructor
	 * 
	 * @param entityManager
	 *            EntityManager instance
	 * @param dataSource
	 *            DataSource instance
	 */
	public SegReportManager(EntityManager entityManager, DataSource dataSource) {
		this.manager = entityManager;
		this.dataSource = dataSource;
		this.configDao = new SystemConfigDao(entityManager);
		this.segmentDao = new SegmentDao(entityManager);		
	}

	/**
	 * Filter the segment from the segment information list <br>
	 * if the latest segment version - report version is reached <br>
	 * the max segment DIFF value, remove from the list and mark <br>
	 * the Corrupt templates to PERSON BIOMETRICS
	 * 
	 * @param segInfos
	 *            PBSegmentInfo instance
	 */
	public void filterSegmentInfos(List<PBSegmentInfo> segInfos) {
		// get [max segment different] from system configuration
		int maxSegDiff = configDao
				.getMMPropertyInt(MMConfigProperty.MAX_SEGMENT_DIFFS);

		// loop each segInfos, if latest segment version - report segment
		// > maxSegDiff. then remove and filter this segment
		Iterator<PBSegmentInfo> iter = segInfos.iterator();

		while (iter.hasNext()) {
			PBSegmentInfo segmentInfo = iter.next();
			long segId = segmentInfo.getId();
			SegmentEntity segment = segmentDao.findSegment(segId);
			if (segment == null) {
				log.warn("Segment id: {} is not found in System..", segId);
				continue;
			}

			if (isOverMaxSegDiff(segmentInfo, segment.getVersion(), maxSegDiff)) {
				handleBadTemplates(segmentInfo.getCorruptTemplates());
				iter.remove();
				// manager.remove(segmentsEntity);
			}
		}
	}

	/**
	 * isOverMaxSegDiff
	 * 
	 * @param segmentInfo
	 *            PBSegmentInfo instance
	 * @param latestVer
	 *            segment latest version
	 * @param maxSegDiff
	 *            max segment different form system configuration
	 * @return is already reached the max segment different
	 */
	private boolean isOverMaxSegDiff(final PBSegmentInfo segmentInfo,
			long latestVer, int maxSegDiff) {
		long reportVer = (segmentInfo.hasVersion()) ? segmentInfo.getVersion()
				: segmentInfo.getQueuedVersion();
		return (latestVer - reportVer > maxSegDiff);
	}

	/**
	 * get MU segment report information
	 * 
	 * @param muId
	 *            match unit id
	 * @return MU segment report information
	 */
	@SuppressWarnings("unchecked")
	private Map<Long, UnitSegReport> listMu(long muId) {
		Query q = manager.createNamedQuery("NQ::getSegReportsForMuid");
		q.setParameter("muId", muId);
		Map<Long, UnitSegReport> oldSegReports = Maps.newHashMap();
		List<MuSegReportEntity> results = q.getResultList();
		for (MuSegReportEntity r : results) {
			oldSegReports.put(r.getSegmentId(), r);
		}
		return oldSegReports;
	}

	/**
	 * get DM segment report information
	 * 
	 * @param dmId
	 *            data manager id
	 * @return DM segment report information
	 */
	@SuppressWarnings("unchecked")
	private Map<Long, UnitSegReport> listDm(long dmId) {
		Query q = manager.createNamedQuery("NQ::getSegReportsForDmid");
		q.setParameter("dmId", dmId);
		Map<Long, UnitSegReport> oldSegReports = Maps.newHashMap();
		List<DmSegReportEntity> results = q.getResultList();
		for (DmSegReportEntity r : results) {
			oldSegReports.put(r.getSegmentId(), r);
		}
		return oldSegReports;
	}

	/**
	 * create report map from client
	 * 
	 * @param muId
	 *            match unit id
	 * @param segInfos
	 *            the PBSegmentInfo list from client
	 * @return Unit segment report information
	 */
	private Map<Long, UnitSegReport> createMapFromSegReport(long unitId,
			final List<PBSegmentInfo> segInfos, boolean isMu) {
		Map<Long, UnitSegReport> newSegReports = Maps.newHashMap();

		// loop each segInfos
		for (final PBSegmentInfo s : segInfos) {
			// mark the Corrupt Templates corrupted_flag to 1
			// with specified template id list from client
			handleBadTemplates(s.getCorruptTemplates());

			final UnitSegReport segReport = isMu ? new MuSegReportEntity()
					: new DmSegReportEntity();
			segReport.setUnitId(unitId); // set MU id or DM id
			segReport.setSegmentId(s.getId());
			if (s.hasVersion()) {
				segReport.setVersion(s.getVersion());
			}
			if (s.hasQueuedVersion()) {
				segReport.setQueuedVersion(s.getQueuedVersion());
			} else {
				segReport.setQueuedVersion(s.getVersion());
			}
			segReport.setStatus(s.getState().ordinal());
			newSegReports.put(s.getId(), segReport);

		}
		return newSegReports;
	}

	/**
	 * handleBadTemplates
	 * 
	 * @param badTemplate
	 *            PBCorruptTempalte instance
	 */
	private void handleBadTemplates(PBCorruptTempalte badTemplate) {
		List<Long> badTemplateIds = badTemplate.getIdList();

		if (CollectionsUtil.isNotEmpty(badTemplateIds)) {
			markCorrupted(badTemplateIds);
		}
	}

	/**
	 * markCorrupted
	 * 
	 * @param bioIds
	 *            bioIds
	 */
	private void markCorrupted(List<Long> bioIds) {
		if (log.isDebugEnabled()) {
			log.debug("markCorrupted() called with " + bioIds.size() + " ids.");
		}
		try {
			MarkCorruptedTemplate template = new MarkCorruptedTemplate(
					dataSource);
			template.setBioIds(bioIds);
			int numRowsUpdated = template.execute();
			if (log.isDebugEnabled()) {
				log.debug("markCorrupted() marked " + numRowsUpdated + " rows.");
			}
		} catch (DataAccessException e) {
			throwReportDBException(e, "");
		}
	}

	/**
	 * updateMuSegReport
	 * 
	 * @param segInfos
	 *            PBSegmentInfo list
	 * @param muId
	 *            MU id
	 */
	public void updateMuSegReport(final List<PBSegmentInfo> segInfos, long muId) {
		if (log.isDebugEnabled()) {
			log.debug("** updateSegReport() called by muId " + muId + "**");
		}

		// get MU segment report information with muId
		// and category it by segment id
		Map<Long, UnitSegReport> oldSegReports = listMu(muId);
		// convert the segInfos that from client to UnitSegReport map
		Map<Long, UnitSegReport> newSegReports = createMapFromSegReport(muId,
				segInfos, true);

		// Compare with the old and new SegReports
		// Persist into the database
		persistSegReport(oldSegReports, newSegReports);
	}

	/**
	 * updateDmSegReport
	 * 
	 * @param segInfos
	 *            PBSegmentInfo list
	 * @param dmId
	 *            DM id
	 */
	public void updateDmSegReport(final List<PBSegmentInfo> segInfos, long dmId) {
		/*
		 * if (CollectionsUtil.isEmpty(segInfos)) { throw new
		 * AimRuntimeException("PBSegmentInfo list is null or empty" +
		 * " when update Mu seg report.."); }
		 */
		if (log.isDebugEnabled()) {
			log.debug("** updateSegReport() called by dmId " + dmId + "**");
		}

		// get DM segment report information with dmId
		// and category it by segment id
		Map<Long, UnitSegReport> oldSegReports = listDm(dmId);
		// convert the segInfos that from client to UnitSegReport map
		Map<Long, UnitSegReport> newSegReports = createMapFromSegReport(dmId,
				segInfos, false);

		// Compare with the old and new SegReports
		// Persist into the database
		persistSegReport(oldSegReports, newSegReports);
	}

	/**
	 * Compare with the old and new SegReports and persist into the database
	 * 
	 * @param oldSegReports
	 *            old segment report
	 * @param newSegReports
	 *            new Segment report
	 */
	private void persistSegReport(Map<Long, UnitSegReport> oldSegReports,
			Map<Long, UnitSegReport> newSegReports) {
		for (UnitSegReport newReport : newSegReports.values()) {
			UnitSegReport oldReport = oldSegReports.get(newReport
					.getSegmentId());
			if (oldReport == null) {
				// old segment report didn't contain this segment; persist this
				// new one.
				if (log.isDebugEnabled()) {
					log.debug("Adding report entry: " + newReport.toString());
				}
				manager.persist(newReport);
			} else if (!oldReport.equals(newReport)) {
				// old segment report was out of date
				if (log.isDebugEnabled()) {
					log.debug("Updating report entry, was: "
							+ oldReport.toString() + ", now: "
							+ newReport.toString());
				}
				manager.merge(newReport);
			}
			oldSegReports.remove(newReport.getSegmentId());
		}
		for (UnitSegReport remainingOld : oldSegReports.values()) {
			if (log.isDebugEnabled()) {
				log.debug("Removing report entry: " + remainingOld.toString());
			}
			manager.remove(remainingOld);
		}

		// flush() call strictly necessary; otherwise native SQL query used by
		// getSegmentUpdates() will not pick up the changes made here.
		manager.flush();
		log.debug("-- updateSegReport() returning. --");
	}

	/**
	 * throwReportDBException
	 * 
	 * @param ex
	 *            Exception instance
	 * @param error
	 *            error message
	 */
	private void throwReportDBException(Exception ex, String error) {
		log.error(error, ex);
		final AimError aimError = AimError.INQ_DB;
		final String errorTime = String.valueOf(System.currentTimeMillis());
		final String errorMsg = String.format(aimError.getMessage(),
				ex.getMessage());
		throw new DataBaseException(aimError.getErrorCode(), errorMsg,
				errorTime, aimError.getUidCode());
	}

}
