package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * The persistent class for the FUSION_JOBS database table.
 * 
 */
@Entity
@Table(name = "FUSION_JOBS")
public class FusionJobEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FUSION_JOB_ID")
	private long fusionJobId;

	@Column(name = "FUNCTION_ID")
	private int functionId;

	@Lob
	@Column(name = "INQUIRY_JOB_DATA")
	private byte[] inquiryJobData;

	@Column(name = "JOB_ID")
	private long jobId;

	@Column(name = "SEARCH_REQUEST_INDEX")
	private int searchRequestIndex;

	public FusionJobEntity() {
	}

	public long getFusionJobId() {
		return this.fusionJobId;
	}

	public void setFusionJobId(long fusionJobId) {
		this.fusionJobId = fusionJobId;
	}

	public int getFunctionId() {
		return this.functionId;
	}

	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}

	public byte[] getInquiryJobData() {
		return this.inquiryJobData;
	}

	public void setInquiryJobData(byte[] inquiryJobData) {
		this.inquiryJobData = inquiryJobData;
	}

	public long getJobId() {
		return this.jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public int getSearchRequestIndex() {
		return this.searchRequestIndex;
	}

	public void setSearchRequestIndex(int searchRequestIndex) {
		this.searchRequestIndex = searchRequestIndex;
	}

}