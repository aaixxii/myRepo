package jp.co.nec.aim.mm.dao;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.extract.planner.FeProcedureResults;
import jp.co.nec.aim.mm.extract.planner.MuRemainLots;
import jp.co.nec.aim.mm.extract.planner.MuRemainLotsRowMapper;
import jp.co.nec.aim.mm.procedure.GetFirstMuRemainLotsProcedure;
import jp.co.nec.aim.mm.procedure.ProcessOneFeMatchUnitProcedure;
import jp.co.nec.aim.mm.procedure.ProcessOneMuLotProcedure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * get all data from database for creating extract plans
 * 
 * @author xiazp
 *
 */
public class FEPlannerDAOImpl implements FEPlannerDAO {
	private static final Logger logger = LoggerFactory
			.getLogger(FEPlannerDAOImpl.class);

	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;

	private GetFirstMuRemainLotsProcedure getFirstMuRemainLotsProcedure;
	private ProcessOneMuLotProcedure processOneMuLotProcedure;
	private ProcessOneFeMatchUnitProcedure processOneFeMatchUnitProcedure;

	private static final String ROLL_BACK_FELOT_JOB_SQL = "delete from fe_lot_jobs where lot_job_id = ?";
	private static final String ROLLBACK_MU_EXTRACT_LOAD_SQL = "update mu_extract_load ml set ml.pressure =DECODE(SIGN(ml.pressure -1),-1,0,0,0,1,ml.pressure -1),ml.update_ts = 0 where ml.mu_id = ?";

	private static final String ROLLBACK_FE_JOB_QUQUE = ""
			+ "UPDATE fe_job_queue SET lot_job_id = null, mu_id = null, job_state = 0, assigned_ts = null "
			+ "WHERE lot_job_id = ?";

	private static final String GET_MAX_MU_LOT = " SELECT key_value  FROM system_init "
			+ " WHERE key_name = 'NUM_OF_MAX_FE_LOT'";

	private static final String SET_PRESSURE_TO_MAX_LOT_COUNT = "update MuExtractLoadEntity ml set ml.pressure = :pressure where ml.muId = :muId";
	private static final String GET_FIRST_MU_SQL = ""
			+ "SELECT mus.mu_id, "
			+ "	             mls.pressure             AS currentlots, "
			+ "	             mus.number_of_extractors AS num_extractor, "
			+ "	             ? - mls.pressure AS remain_lots "
			+ "	      FROM   match_units mus, "
			+ "	             mu_extract_load mls "
			+ "	      WHERE  mus.mu_id = mls.mu_id "
			+ "	             AND MUS.state = 'WORKING' "
			+ "	             AND mus.mu_id = (SELECT mu_id "
			+ "                              FROM   (SELECT mu.mu_id, "
			+ "                                             ml.pressure "
			+ "                                             AS "
			+ "                                             currentlots, "
			+ "                                             mu.number_of_extractors "
			+ "                                             AS "
			+ "                                             num_extractor, "
			+ "                                             ? - ML.pressure "
			+ "                                             AS "
			+ "                                             remain_lots, "
			+ "                                             Row_number() "
			+ "                                               over ( "
			+ "                                                 ORDER BY ml.pressure, "
			+ "                                               ml.update_ts) AS "
			+ "                                             rn "
			+ "                                      FROM   match_units mu, "
			+ "                                             mu_extract_load ml, "
			+ "                                             mu_eligible_functions mf "
			+ "                                      WHERE  mu.mu_id = ml.mu_id "
			+ "                                             AND mu.mu_id = mf.mu_id "
			+ "                                             AND mu.state = 'WORKING' "
			+ "                                             AND  ? - ml.pressure > 0 "
			+ "                                             AND mf.function_id = 17) "
			+ "                              WHERE  rn <= 1) "
			+ "                              for update of mus.mu_id,mls.mu_id NOWAIT";

	// private static final String LOCK_FOR_FEPLANNER =
	// "LOCK TABLE match_units, mu_extract_load,fe_job_queue IN SHARE ROW EXCLUSIVE MODE";
	private static final String LOCK_FOR_FEPLANNER = "select name from mm_events where name = 'FEJOB_PLANNER' for update";

	private static final String GET_CURRENT_MU_LOT_SQL = "select pressure from mu_extract_load where mu_id = ? for update";

	public FEPlannerDAOImpl(DataSource dataSource, EntityManager manager) {
		this.manager = manager;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		getFirstMuRemainLotsProcedure = new GetFirstMuRemainLotsProcedure(
				dataSource);
		processOneMuLotProcedure = new ProcessOneMuLotProcedure(dataSource);
		processOneFeMatchUnitProcedure = new ProcessOneFeMatchUnitProcedure(
				dataSource);
	}

	/**
	 * get one mu that is best fit to assign job to it
	 * 
	 * @param maxMuLot
	 * @return MuRemainLots
	 * @exception PersistenceException
	 */

	@Override
	public MuRemainLots getfirstMuRemainLots(int maxMuLot) {
		try {
			MuRemainLots resutls = getFirstMuRemainLotsProcedure
					.getfirstMuRemainLots(maxMuLot);
			return resutls;
		} catch (DataAccessException | SQLException e) {
			return null;
		}

	}

	/**
	 * assign one lot extract jobs to mu
	 * 
	 * @param muRemainLot
	 * @return assigned mu_lot_job_id
	 */
	@Override
	public Long processOneMuLot(MuRemainLots muRemainLot) {
		try {
			Long results = processOneMuLotProcedure
					.processOneMuList(muRemainLot);
			return results;
		} catch (DataAccessException | SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		}

	}

	/**
	 * get max mu lots from system_config table
	 * 
	 * @return max_mu_lots
	 */
	@Override
	public Integer getMaxMuLots() {
		Integer maxMuLot = -999;
		try {
			Query q = manager.createNativeQuery(GET_MAX_MU_LOT);
			String result = (String) q.getSingleResult();
			if (result != null) {
				maxMuLot = Integer.valueOf(result);
			}
		} catch (Exception e) {
			return -1;
		}

		return maxMuLot;
	}

	@Override
	public void setPressureToMaxLot(Long muId, Long newPressure)
			throws PersistenceException, SQLException {
		Query q = manager.createQuery(SET_PRESSURE_TO_MAX_LOT_COUNT);
		q.setParameter("pressure", newPressure);
		q.setParameter("muId", muId);
		q.executeUpdate();
		manager.flush();
	}

	@Override
	public FeProcedureResults processOneFeMatchUnit(int maxMuLot) {
		try {
			FeProcedureResults oneResult = processOneFeMatchUnitProcedure
					.processOneFeMatchUnit(maxMuLot);
			return oneResult;
		} catch (DataAccessException | SQLException e) {
			return null;
		}
	}

	@Override
	public Long getCurretMuLots(Long muId) {
		try {
			Long result = jdbcTemplate.queryForObject(GET_CURRENT_MU_LOT_SQL,
					Long.class, new Object[] { muId });
			return result;
		} catch (DataAccessException e) {
			return -1L;
		}
	}

	@Override
	public void lockForFePlanner() throws DataAccessException {
		jdbcTemplate.update(LOCK_FOR_FEPLANNER);
	}

	@Override
	public MuRemainLots lockAndGetfirstMuRemainLots(int maxMuLot) {
		try {
			MuRemainLots results = jdbcTemplate.queryForObject(
					GET_FIRST_MU_SQL, new Object[] { new Integer(maxMuLot),
							new Integer(maxMuLot), new Integer(maxMuLot) },
					new MuRemainLotsRowMapper());
			return results;
		} catch (EmptyResultDataAccessException e) {
			return null;
		} catch (DataAccessException e) {
			return null;
		}
	}

	@Override
	public void rollbackFeLotJobRelated(Long feLotJobId, Long muId) {
		deleteFeLotJob(feLotJobId);
		rollbackFeJobQueue(feLotJobId);
		rollbackMuExtractLoad(muId);
		jdbcTemplate.execute("commit");
	}

	public void deleteFeLotJob(Long feLotJobId) {
		jdbcTemplate.update(ROLL_BACK_FELOT_JOB_SQL, feLotJobId);
	}

	public void rollbackMuExtractLoad(Long muId) {
		jdbcTemplate.update(ROLLBACK_MU_EXTRACT_LOAD_SQL, muId);
	}

	public void rollbackFeJobQueue(Long feLotJobId) {
		jdbcTemplate.update(ROLLBACK_FE_JOB_QUQUE, feLotJobId);
	}

	@Override
	public Integer getFeLotJobCount(Long feLotJobId) {
		String countSlq = "selcet count(*) from fe_lot_jobs where lot_job_id = ?";
		try {
			Integer results = jdbcTemplate.queryForObject(countSlq,
					new Object[] { feLotJobId }, Integer.class);
			return results;
		} catch (EmptyResultDataAccessException e) {
			return null;
		} catch (DataAccessException e) {
			return null;
		}
	}

}
