package jp.co.nec.aim.mm.sessionbeans;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;
import jp.co.nec.aim.mm.scheduler.QuartzManager;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class PartitionServiceBean {
	private static Logger logger = LoggerFactory.getLogger(PartitionServiceBean.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;	
	

	private PartitionDao partitionDao;
	private SystemInitDao systemInitDao;

	public PartitionServiceBean() {
	}

	@PostConstruct
	public void init() {
		partitionDao = new PartitionDao(dataSource);
		systemInitDao = new SystemInitDao(manager);
	}
	
	public void initPartition() {
		int pNoCount = partitionDao.getPatitionPnoCount();
		if (pNoCount > 0) {
			logger.info("Segment_change_log partition is allready initialized.");			
		} else {		
			long hashValue = PartitionUtil.getInstance().caculateHashAtThisToday(LocalDate.now());
			partitionDao.initPartition(hashValue);
			logger.info("Created one partition{}).", hashValue);	
			QuartzManager quartzManager = QuartzManager.getInstance(manager);
			quartzManager.startSetTodayPnoJob();
			quartzManager.startCreateNextDayPartitionJob();
			quartzManager.startClearOldPartitionJob(LocalDate.now().plusDays(hashValue));
		}
	}

	public void updatePartition(Long newNo) {
		Long oldSaveDays = systemInitDao.getSegChangeLogSaveDays();	
		if (newNo.longValue() - oldSaveDays.longValue() > 0) {
			doAddPartition(newNo.longValue());
		} else {			
			doReducePartition(newNo.longValue());
		}
	}

	private void doAddPartition(long newNo) {
		LocalDate now = LocalDate.now();
		LocalDate firstAddDay = now.plusDays(2);
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstAddDay);
		long adjust = PartitionUtil.getInstance().caculateNewAdjustAtThisDay(newNo, firstAddDay);
		long newHashValue = (epochDays + adjust) % newNo;
		Date sqlDate = Date.valueOf(firstAddDay);
		systemInitDao.updateInUsingAdjuist(adjust);
		systemInitDao.updateSegChangeLogSaveDays(String.valueOf(newHashValue));		
		partitionDao.insertPno(newHashValue, sqlDate);
		partitionDao.createPartition(newHashValue);
	}

	private void doReducePartition(long newNo) {
		long oldSaveDay = systemInitDao.getSegChangeLogSaveDays();
		long diff = oldSaveDay - newNo > 0 ? oldSaveDay - newNo : -1 * (oldSaveDay - newNo);
		LocalDate now = LocalDate.now();
		LocalDate firstUpdateDay = now.plusDays(diff);
		QuartzManager qManager = QuartzManager.getInstance(manager);
		qManager.addReservationReducePartitionJob(newNo, firstUpdateDay);
		qManager.rescheduleClearOldPartitionJob(firstUpdateDay);
	}
	
	public void doReducePartitionAtNow(long newNo) { 
		long oldSaveDay = systemInitDao.getSegChangeLogSaveDays();
		long diff = oldSaveDay - newNo > 0 ? oldSaveDay - newNo : -1 * (oldSaveDay - newNo);
		LocalDate now = LocalDate.now();
		LocalDate firstRunDay = now.plusDays(diff);
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstRunDay);
		long adjust = PartitionUtil.getInstance().caculateNewAdjustAtThisDay(newNo, firstRunDay);
		long newHashValue = (epochDays + adjust) % newNo;
		Date sqlDate = Date.valueOf(firstRunDay);
		systemInitDao.updateInUsingAdjuist(adjust);
		systemInitDao.updateSegChangeLogSaveDays(String.valueOf(newHashValue));		
		partitionDao.insertPno(newHashValue, sqlDate);
		partitionDao.createPartition(newHashValue);
		logger.info("Success do reduce partition({}->{}) in day8{})", oldSaveDay , newNo, firstRunDay);
		 QuartzManager.getInstance(manager).rescheduleClearOldPartitionJob(firstRunDay);
	}
}
