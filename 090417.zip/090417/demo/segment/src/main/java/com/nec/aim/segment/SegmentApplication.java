package com.nec.aim.segment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegmentApplication.class, args);
	}

}
