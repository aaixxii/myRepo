package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the MU_ELIGIBLE_CONTAINERS database table.
 * 
 */
@Entity
@Table(name = "MU_ELIGIBLE_CONTAINERS")
@NamedQuery(name = "MuEligibleContainerEntity.findAll", query = "SELECT m FROM MuEligibleContainerEntity m")
public class MuEligibleContainerEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MuEligibleContainerEntityPK id;

	public MuEligibleContainerEntity() {
	}

	public MuEligibleContainerEntityPK getId() {
		return this.id;
	}

	public void setId(MuEligibleContainerEntityPK id) {
		this.id = id;
	}

}