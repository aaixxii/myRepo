package jp.co.nec.aim.mm.dao;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.entities.MatchManagerEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.properties.Version;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj
 */
public class MatchManagerDao {
	private static final Object lock = new Object();

	private static Logger log = LoggerFactory.getLogger(MatchManagerDao.class);
	private EntityManager manager;
	private ConfigProperties configProps;

	public MatchManagerDao(EntityManager manager) {
		this.manager = manager;
		configProps = ConfigProperties.getInstance();
	}

	public MatchManagerEntity createOrLookupVersion() {
		String version = Version.readVersion();
		return createOrLookup(version);
	}

	public MatchManagerEntity createOrLookup() {
		return createOrLookup(null);
	}

	/**
	 * Create or update MATCH_MANAGERS TABLE.
	 * 
	 * If version is null, this method judge the version number has been already
	 * set. If version is not null, this method judge called at an initial boot
	 * timing and "update MATCH_MANAGERS set version=parameter;".
	 * 
	 * @param version
	 * @return
	 */
	MatchManagerEntity createOrLookup(String version) {
		synchronized (lock) {
			String mmUniqueId = getMMUniqueId();

			MatchManagerEntity mm = lookup(mmUniqueId);
			if (mm == null) {
				create(mmUniqueId, version, getContactURL());
				manager.flush();
			} else {
				if (version == null) {
					update(mmUniqueId, mm.getVersion(), getContactURL());
				} else {
					update(mmUniqueId, version, getContactURL());
				}
			}
			if (log.isDebugEnabled()) {
				if (version != null) {
					log.debug("MM version : " + version);
				}
			}
			mm = lookup(mmUniqueId);
			return mm;
		}
	}

	int create(String mmUniqueId, String version, String contactUrl) {
		Query query = manager.createNamedQuery("NQ::createMatchManagerEntity");
		query.setParameter("uniqueId", mmUniqueId);
		query.setParameter("version", version);
		query.setParameter("contactUrl", contactUrl);
		return query.executeUpdate();
	}

	int update(String uniqueId, String version, String contactUrl) {
		Query query = manager.createNamedQuery("NQ::updateMatchManagerEntity");
		query.setParameter("uniqueId", uniqueId);
		query.setParameter("version", version);
		query.setParameter("contactUrl", contactUrl);
		return query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	public List<MatchManagerEntity> listDeadMMs() {
		Query q = manager.createNamedQuery("NQ::listDeadMMs");
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	public MatchManagerEntity lookup(String uniqueId) {
		Query q = manager.createNamedQuery("NQ::lookupMM");
		q.setParameter("uniqueId", uniqueId);
		List<MatchManagerEntity> results = q.getResultList();
		if (results.size() == 0) {
			return null;
		} else if (1 < results.size()) {
			throw new AimRuntimeException(
					"Duplicate Match Managers with same unique id: " + uniqueId);
		} else {
			return results.get(0);
		}
	}

	private String getContactURL() {
		String port = configProps
				.getPropertyValue(ConfigPropertyNames.MM_WEB_PORT_NUM);
		String contextPath = configProps
				.getPropertyValue(ConfigPropertyNames.MM_WEB_CONTEXT_NAME);
		if (port == null || contextPath == null) {
			return null;
		} else {
			return "http://" + getMMUniqueId() + ":" + port + "/" + contextPath;
		}
	}

	/**
	 * Get an ip-address of MM from aim.mm.properties.
	 * 
	 * If the ip-address is not gotten from properties, it must be missing the
	 * default setting. Therefore It is not necessary to send SM and get the
	 * real ip of NIC.
	 * 
	 * @return
	 */
	private String getMMUniqueId() {

		String mmUniqueId = configProps
				.getPropertyValue(ConfigPropertyNames.MM_IP_ADDRESS);
		if (mmUniqueId == null) {
			log.warn(ConfigPropertyNames.MM_IP_ADDRESS
					+ " is not found in aim.mm.properties.");

			mmUniqueId = "MM_DEFAULT_ID";

			// basically, we prefer to use numeric IP address but will use
			// hostname
			// otherwise.
			// worst-case scenario we use the default above.
			try {
				mmUniqueId = InetAddress.getLocalHost().getHostName();

				Enumeration<NetworkInterface> interfaces = java.net.NetworkInterface
						.getNetworkInterfaces();
				while (interfaces.hasMoreElements()) {
					NetworkInterface ni = interfaces.nextElement();
					Enumeration<InetAddress> addrs = ni.getInetAddresses();
					while (addrs.hasMoreElements()) {
						InetAddress addr = addrs.nextElement();
						if (!addr.isLoopbackAddress()) {
							mmUniqueId = addr.getHostAddress();
						}
					}
				}
			} catch (SocketException e) {
				log.error(
						"Got a socket exception while trying to enumerate machine network interfaces to determine MM unique ID, using default.",
						e);
			} catch (UnknownHostException e) {
				log.error(
						"Can't set the MM's unique ID to hostname due to unknown host exception",
						e);
			}
		}
		return mmUniqueId;
	}

	@SuppressWarnings("unchecked")
	public List<MatchManagerEntity> listWorkingMMs() {
		Query q = manager.createNamedQuery("NQ::listWorkingMMs");
		return q.getResultList();
	}

}
