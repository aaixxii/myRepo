package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeLotJobEntity;
import jp.co.nec.aim.mm.entities.MuExtractLoadEntity;
import jp.co.nec.aim.mm.extract.planner.MuRemainLots;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class ProcessOneMuLotProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "AIMDB")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	private ProcessOneMuLotProcedure feDao;

	@Before
	public void setUp() throws Exception {
		feDao = new ProcessOneMuLotProcedure(dataSource);
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from mu_extract_load");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		feDao = new ProcessOneMuLotProcedure(dataSource);
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from mu_extract_load");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testProcessOneMuList() {
		Long muId = 1000L;
		Integer muCpu = 4;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], String.valueOf(i), "extract", muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ " AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;

		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });
		jdbcTemplate.execute("commit");
		Long lotJobId = null;

		try {
			lotJobId = feDao.processOneMuList(muRemainLot);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertTrue(lotJobId.longValue() > 0);
		FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
				lotJobId);
		Assert.assertNotNull(topJobtimeOutValue);
		Assert.assertEquals(topJobtimeOutValue.longValue(),
				feLotJob.getTimeouts());
		Assert.assertEquals(muId.intValue(), feLotJob.getMuId());
		String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
		Query q = entityManager.createQuery(muExLoadSql);
		q.setParameter("muid", muId);
		MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q.getSingleResult();
		Assert.assertNotNull(muLoad);
		Assert.assertTrue((muLoad.getPressure() >= 1L));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneMuList_feJob1_proority_selected() {
		Long muId = 1000L;
		Integer muCpu = 4;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 1, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],String.valueOf(i), "extract", muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ " AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * 1;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });

		jdbcTemplate.execute("commit");
		Long lotJobId = null;

		try {
			lotJobId = feDao.processOneMuList(muRemainLot);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertTrue(lotJobId.longValue() > 0);
		FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
				lotJobId);
		Assert.assertNotNull(topJobtimeOutValue);
		Assert.assertEquals(topJobtimeOutValue.longValue(),
				feLotJob.getTimeouts());
		Assert.assertEquals(muId.intValue(), feLotJob.getMuId());
		String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
		Query q = entityManager.createQuery(muExLoadSql);
		q.setParameter("muid", muId.longValue());
		MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q.getSingleResult();
		Assert.assertNotNull(muLoad);
		Assert.assertTrue((muLoad.getPressure() >= 1L));
		Assert.assertTrue((muLoad.getUpdateTs() != null));
		String seleFeQSql = "select fq from FeJobQueueEntity fq where fq.lotJobId=:felotJobId";
		entityManager.flush();
		//List<FeJobQueueEntity> test = entityManager.createQuery(seleFeQSql, FeJobQueueEntity.class).setParameter("felotJobId", lotJobId).getResultList();
		Query query = entityManager.createQuery(seleFeQSql, FeJobQueueEntity.class);
		query.setParameter("felotJobId", lotJobId);
		List<FeJobQueueEntity> fqJobs = query.getResultList();
		Assert.assertEquals(1, fqJobs.size());
		for (int i = 0; i < fqJobs.size(); i++) {
			Assert.assertEquals(muId.intValue(), fqJobs.get(i).getMuId()
					.intValue());
			Assert.assertEquals("WORKING", fqJobs.get(i).getStatus().toString());
			Assert.assertNotNull(fqJobs.get(i).getAssignedTs());
			Assert.assertEquals(1, fqJobs.get(i).getPriority());
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneMuList_second_maxFailureCount_selected() {
		Long muId = 1000L;
		Integer muCpu = 2;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 2, 2, 2, 2, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 3, 4, 5 };

		String feJobSql = "insert into fe_job_queue(job_id,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],String.valueOf(i), "extract", muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ " AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });

		jdbcTemplate.execute("commit");
		Long lotJobId = null;

		try {
			lotJobId = feDao.processOneMuList(muRemainLot);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertTrue(lotJobId.longValue() > 0);
		FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
				lotJobId);
		Assert.assertNotNull(topJobtimeOutValue);
		Assert.assertEquals(topJobtimeOutValue.longValue(),
				feLotJob.getTimeouts());
		Assert.assertEquals(muId.intValue(), feLotJob.getMuId());
		String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
		Query q = entityManager.createQuery(muExLoadSql);
		q.setParameter("muid", muId.longValue());
		MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q.getSingleResult();
		Assert.assertNotNull(muLoad);
		Assert.assertTrue((muLoad.getPressure() >= 1L));
		Assert.assertTrue((muLoad.getUpdateTs() != null));
		String feqSql = "select count(*) from fe_job_queue where LOT_JOB_ID=" + String.valueOf(lotJobId);
		int count = jdbcTemplate.queryForObject(feqSql, Integer.class);
		Assert.assertEquals(2, count);
		String seleFeQSql = "from FeJobQueueEntity fq where fq.lotJobId=:felotJobId";
		Query query = entityManager.createQuery(seleFeQSql);
		
		query.setParameter("felotJobId", lotJobId);
		List<FeJobQueueEntity> fqJobs = query.getResultList();
		Assert.assertEquals(2, fqJobs.size());

		Assert.assertEquals(muId.intValue(), fqJobs.get(0).getMuId().intValue());
		Assert.assertEquals("WORKING", fqJobs.get(0).getStatus().toString());
		Assert.assertNotNull(fqJobs.get(0).getAssignedTs());
		Assert.assertEquals(2, fqJobs.get(0).getPriority());

		Assert.assertEquals(muId.intValue(), fqJobs.get(0).getMuId().intValue());
		Assert.assertEquals("WORKING", fqJobs.get(0).getStatus().toString());
		Assert.assertNotNull(fqJobs.get(1).getAssignedTs());
		Assert.assertEquals(2, fqJobs.get(1).getPriority());
		Assert.assertEquals(5, fqJobs.get(1).getFailureCount().intValue());
	}

	@Test
	public void testProcessOneMuList_no_feJob_selected() {
		Long muId = 1000L;
		Integer muCpu = 4;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 1, 1, 2, 3, 2 };
		Integer[] states = { 2, 2, 2, 1, 1 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],String.valueOf(i), "extract", muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ " AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });

		jdbcTemplate.execute("commit");
		try {
			Long lotJobId = feDao.processOneMuList(muRemainLot);
			Assert.assertTrue(lotJobId < 1L);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testProcessOneMuList_all_feJob_no_state0() {
		Long muId = 1000L;
		Integer muCpu = 1;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 1, 2, 2, 3, 2 };
		Integer[] states = { 2, 2, 2, 1, 1 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], String.valueOf(i), "extract",muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ " AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });
		jdbcTemplate.execute("commit");
		try {
			Long lotJobId = feDao.processOneMuList(muRemainLot);
			Assert.assertTrue(lotJobId < 1L);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testProcessOneMuList_feJob1_proority_selected_one_only() {
		Long muId = 1000L;
		Integer muCpu = 4;
		MuRemainLots muRemainLot = new MuRemainLots();
		muRemainLot.setMuId(muId);
		muRemainLot.setNumOfExtractor(muCpu);
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql, new Object[] { muId, String.valueOf((muId)),
				"WORKING", new Integer(muCpu) });

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };

		Integer[] priotity = { 1, 1, 1, 1, 1 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,mu_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], String.valueOf(i), "extract",muId,
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}

		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ " AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * 1;
		String muExtractLoadInsSqL = "insert into mu_extract_load(mu_id,pressure,update_ts)values(?,0,1000)";
		jdbcTemplate.update(muExtractLoadInsSqL, new Object[] { muId });

		jdbcTemplate.execute("commit");
		Long lotJobId = null;

		try {
			lotJobId = feDao.processOneMuList(muRemainLot);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertTrue(lotJobId.longValue() > 0);
		FeLotJobEntity feLotJob = entityManager.find(FeLotJobEntity.class,
				lotJobId);
		Assert.assertNotNull(topJobtimeOutValue);
		Assert.assertEquals(topJobtimeOutValue.longValue(),
				feLotJob.getTimeouts());
		Assert.assertEquals(muId.intValue(), feLotJob.getMuId());
		String muExLoadSql = "from MuExtractLoadEntity ml where ml.muId =:muid";
		Query q = entityManager.createQuery(muExLoadSql);
		q.setParameter("muid", muId.longValue());
		MuExtractLoadEntity muLoad = (MuExtractLoadEntity) q.getSingleResult();
		Assert.assertNotNull(muLoad);
		Assert.assertTrue((muLoad.getPressure() >= 1L));
		Assert.assertTrue((muLoad.getUpdateTs() != null));
		String seleFeQSql = "from FeJobQueueEntity fq where fq.lotJobId=:felotJobId";
		Query query = entityManager.createQuery(seleFeQSql);
		query.setParameter("felotJobId", lotJobId.longValue());
		List<FeJobQueueEntity> fqJobs = query.getResultList();
		Assert.assertEquals(1, fqJobs.size());
		for (int i = 0; i < fqJobs.size(); i++) {
			Assert.assertEquals(muId.intValue(), fqJobs.get(i).getMuId()
					.intValue());
			Assert.assertEquals("WORKING", fqJobs.get(i).getStatus().toString());
			Assert.assertNotNull(fqJobs.get(i).getAssignedTs());
			Assert.assertEquals(1, fqJobs.get(i).getPriority());
		}
	}
}
