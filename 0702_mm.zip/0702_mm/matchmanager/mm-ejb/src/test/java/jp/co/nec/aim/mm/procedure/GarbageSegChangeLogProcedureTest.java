package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;

import java.net.URL;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SystemConfigDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GarbageSegChangeLogProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {

	private static final String COUNT_LOGS_SQL = "select count(SEGMENT_CHANGE_ID) from SEGMENT_CHANGE_LOG ";
	private static final String COUNT_LOGS_BY_ID = "select count(SEGMENT_CHANGE_ID) from SEGMENT_CHANGE_LOG  where SEGMENT_ID=?";

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;

	private SystemConfigDao systemConfigDao;

	@Before
	public void setUp() throws Exception {
		JdbcTemplateHelper helper = new JdbcTemplateHelper();
		helper.deleteSystemConfig(jdbcTemplate);
		//systemConfigDao = new SystemConfigDao(entityManager);
		//systemConfigDao.writeAllMissingProperties(ds);
		helper.UpdateSystemConfig(jdbcTemplate,
				MMConfigProperty.MAX_SEGMENT_DIFFS.getName(), "5");
		tearDown();
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from SEGMENTS");
		jdbcTemplate.execute("delete from SEGMENT_CHANGE_LOG ");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void test_extcuteNoRecords() {
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(0, procedure.execute());
		assertEquals(Integer.valueOf(0),
				jdbcTemplate.queryForObject(COUNT_LOGS_SQL, Integer.class));
	}

	/**
	 * 6 records exist in SEG_CHANGE_LOG. Can't delete record because no record
	 * in MU_SEGMENTS.
	 * 
	 */
	@Test
	public void test_6Records_BinID1() {
		URL url = this.getClass().getResource("6segchangelog-binid1.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		jdbcTemplate.execute("commit");
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(1, procedure.execute());
		assertEquals(Integer.valueOf(6),
				jdbcTemplate.queryForObject(COUNT_LOGS_SQL, Integer.class));
	}

	@Test
	public void test_5Records_BinID1() {
		URL url = this.getClass().getResource("5segchangelog-binid1.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(1, procedure.execute());
		assertEquals(Integer.valueOf(5),
				jdbcTemplate.queryForObject(COUNT_LOGS_SQL, Integer.class));
	}

	@Test
	public void test_5Records_BinID1and2() {
		URL url = this.getClass().getResource("5segchangelog-binid1and2.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(2, procedure.execute());
		assertEquals(Integer.valueOf(5),
				jdbcTemplate.queryForObject(COUNT_LOGS_SQL, Integer.class));
	}

	/**
	 * No records in MU_SEGMENTS. Can't delete record in SEG_CHANGE_LOG.
	 */
	@Test
	public void test_8Records_BinID1and2() {
		URL url = this.getClass().getResource("8segchangelog-binid1and2.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(2, procedure.execute());
		assertEquals(Integer.valueOf(8),
				jdbcTemplate.queryForObject(COUNT_LOGS_SQL, Integer.class));
	}

	/**
	 * Record exists in MU_SEGMENTS, but no records in SEGMENT_CHNAGE_LOG
	 */
	@Test
	public void testMuIsWorkingButNoSegmentReport() {
		URL url = this.getClass().getResource("8segchangelog-noreport.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(1, procedure.execute());
		assertEquals(Integer.valueOf(8),
				jdbcTemplate.queryForObject(COUNT_LOGS_SQL, Integer.class));
	}

	/**
	 * Record exists in MU_SEGMENTS, but no records in SEGMENT_CHNAGE_LOG
	 */
	@Test
	public void testVersionDiff1() {
		URL url = this.getClass()
				.getResource("8segchangelog-version-diff1.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(1, procedure.execute());
		assertEquals(Integer.valueOf(8),
				jdbcTemplate.queryForObject(COUNT_LOGS_SQL, Integer.class));
	}

	/**
	 * Record exists in MU_SEGMENTS, but no records in SEGMENT_CHNAGE_LOG
	 */
	@Test
	public void testUnderBottomVersion() {
		URL url = this.getClass().getResource("8segchangelog-under-bottom.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(1, procedure.execute());
		assertEquals(Integer.valueOf(8), jdbcTemplate.queryForObject(
				COUNT_LOGS_BY_ID, new Object[] { 1 }, Integer.class));
	}

	/**
	 * Record exists in MU_SEGMENTS, but no records in SEGMENT_CHNAGE_LOG
	 */
	@Test
	public void testAllLatestVersion() {
		URL url = this.getClass().getResource("8segchangelog-latest.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(1, procedure.execute());
		assertEquals(Integer.valueOf(8), jdbcTemplate.queryForObject(
				COUNT_LOGS_BY_ID, new Object[] { 1 }, Integer.class));
	}

	/**
	 * Record exists in MU_SEGMENTS, but no records in SEGMENT_CHNAGE_LOG
	 */
	@Test
	public void test3Segments() {
		URL url = this.getClass().getResource("8segchangelog-3segments.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		jdbcTemplate.execute("commit");
		GarbageSegChangeLogProcedure procedure = new GarbageSegChangeLogProcedure(
				ds);
		assertEquals(3, procedure.execute());
		assertEquals(Integer.valueOf(8), jdbcTemplate.queryForObject(
				COUNT_LOGS_BY_ID, new Object[] { 1 }, Integer.class));
		assertEquals(Integer.valueOf(8), jdbcTemplate.queryForObject(
				COUNT_LOGS_BY_ID, new Object[] { 2 }, Integer.class));
		assertEquals(Integer.valueOf(8), jdbcTemplate.queryForObject(
				COUNT_LOGS_BY_ID, new Object[] { 3 }, Integer.class));
		assertEquals(
				Integer.valueOf(6),
				jdbcTemplate
						.queryForObject(
								"select count(SEGMENT_CHANGE_ID) from SEGMENT_CHANGE_LOG where SEGMENT_CHANGE_ID in (1, 2, 9, 10, 17, 18)",
								Integer.class));
	}

}
