package jp.co.nec.aim.mm.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.Queue;
import java.util.Set;

import jp.co.nec.aim.mm.exception.UDPNotifyException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Queues;

public class UDPNotifyHelper {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(UDPNotifyHelper.class);

	/** the broadcast destination **/
	private final Queue<InetSocketAddress> socketAddrs;
	/** notify socket timeout **/
	private static final int SOCKET_TIMEOUT_MS = 200;

	/** the charsetName **/
	private static final String CHARSET_NAME = "UTF-8";

	/** comma **/
	private static final String COMMA = ",";

	/**
	 * public constructor
	 */
	public UDPNotifyHelper() {
		socketAddrs = Queues.newConcurrentLinkedQueue();
	}

	/**
	 * add IP address to set
	 * 
	 * @param ip
	 *            MU broadcast IP address
	 * @param port
	 *            MU listening port
	 * 
	 */
	public void addIPAddress(String ip, int port) {
		if (StringUtils.isBlank(ip)) {
			log.warn("ip is null while add Unit broadcast ip address, skip..");
			return;
		}

		if (port <= 0 || port >= 65535) {
			log.warn("the port is out of range, skip..");
			return;
		}
		this.socketAddrs.add(new InetSocketAddress(ip, port));
	}

	/**
	 * clear Ip Address
	 */
	public void clearIPAddress() {
		this.socketAddrs.clear();
	}

	/**
	 * <p>
	 * Notify the MU with specified message
	 * <p>
	 * 
	 * <p>
	 * MULTI-BROADCAST IP address specified is allowed
	 * <p>
	 */
	public void notifyCompoent(String message) {
		if (log.isDebugEnabled()) {
			log.debug("begin notify to Units.");
		}

		// if the message that will be send is null or empty
		// skip notify operation and return directly
		if (StringUtils.isBlank(message)) {
			log.error("the message will be send is null or empty, skip notify.");
			return;
		}

		// if the IP and port from sysInit is empty, skip directly..
		if (socketAddrs.isEmpty()) {
			log.error("please confirm the notify ip and port is exist "
					+ "in table SYSTEM_INIT due to the ip address is empty,"
					+ " nothing to send..");
			return;
		}

		DatagramSocket dSocket = null;
		try {
			final byte[] bytes = message.getBytes(CHARSET_NAME);

			dSocket = new DatagramSocket();
			dSocket.setBroadcast(true);
			dSocket.setSendBufferSize(bytes.length);
			dSocket.setSoTimeout(SOCKET_TIMEOUT_MS);
			dSocket.setReuseAddress(false);

			// //////////////////////////////////////////////////////////////
			// ///////////loop the IP address and notify////////////////////
			// /////////////////////////////////////////////////////////////
			for (final InetSocketAddress address : socketAddrs) {
				log.info(" notify broadcast begin, ip address-> {}, "
						+ "port-> {}, message-> {}",
						new Object[] { address.getHostName(),
								address.getPort(), message });
				try {
					DatagramPacket msgPacket = new DatagramPacket(bytes,
							bytes.length, address);
					dSocket.send(msgPacket);
				} catch (IOException e) {
					log.error(
							"IOException occurred while send UDP package to unit, "
									+ "ip address-> {}, port-> {}, message-> {}",
							new Object[] { address.getHostName(),
									address.getPort(), message });
				} catch (Exception e) {
					log.error(
							"Unknown Exception occurred while send UDP package to unit, "
									+ "ip address-> {}, port-> {}, message-> {}",
							new Object[] { address.getHostName(),
									address.getPort(), message });
				}
			}
		} catch (UnsupportedEncodingException e) {
			final String error = "UnsupportedEncodingException occurred while"
					+ " convert the message to bytes using charsetName UTF-8";
			log.error(error, e);
			throw new UDPNotifyException(error, e);
		} catch (SocketException e) {
			final String error = "SocketException occurred while"
					+ " create instance DatagramSocket";
			log.error(error, e);
			throw new UDPNotifyException(error, e);
		} catch (Exception e) {
			final String error = "Unknown exception occurred while"
					+ " notify to unit.";
			log.error(error, e);
			throw new UDPNotifyException(error, e);
		} finally {
			// close and release the socket
			if (dSocket != null) {
				dSocket.close();
			}

			if (log.isDebugEnabled()) {
				log.debug("end notify Units.");
			}
		}
	}

	/**
	 * convert the functionName, jobId and muIds into specified format
	 * 
	 * @param functionName
	 *            the function name
	 * @param jobId
	 *            the job id
	 * @param muids
	 *            the MU id set that will fetch the job
	 * @return converted string like following
	 *         <code>function=LIX,JobID=007,1,2,15,17,56,28,29, </code>
	 */
	public static String convert(final Set<Long> itemIds) {

		StringBuffer itemIdStr = new StringBuffer();
		if (!CollectionsUtil.isEmpty(itemIds)) {
			for (final Long itemId : itemIds) {
				itemIdStr.append(itemId);
				itemIdStr.append(COMMA);
			}
		}

		return itemIdStr.toString();
	}
}
