package jp.co.nec.aim.mm.constants;

/**
 * Component type
 */
public enum Component {
	MATCHMANAGER("1"), DATAMANAGER("2"), MATCHUNIT("3"), SYSTEMMANAGER("4"), VERIFICATIONMANAGER(
			"5"), VERIFICATIONPROCESSOR("6"), MAPREDUCER("7"), UNKNOWN("8"), AIM(
			"9");

	private String errorCode; // error code

	private Component(String errorCode) {
		this.setErrorCode(errorCode);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
