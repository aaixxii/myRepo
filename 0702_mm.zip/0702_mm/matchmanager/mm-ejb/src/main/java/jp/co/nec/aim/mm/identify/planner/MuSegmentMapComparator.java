package jp.co.nec.aim.mm.identify.planner;

import java.util.Comparator;

import jp.co.nec.aim.mm.exception.AimRuntimeException;

public class MuSegmentMapComparator implements Comparator<MuSegmentMap> {

	@Override
	public int compare(MuSegmentMap o1, MuSegmentMap o2) {
		if (o1.getMuId() == null || o2.getMuId() == null) {
			String errMsg = "one or more MuId is null";
			throw new AimRuntimeException(errMsg);
		}
		if (o1.getSegmentId() == null || o2.getSegmentId() == null) {
			String errMsg = "one or more segmentId is null";
			throw new AimRuntimeException(errMsg);
		}
		int first = o1.getSegmentId().compareTo(o2.getSegmentId());
		int second = o1.getMuId().compareTo(o2.getMuId());
		return first != 0 ? first : second;
	}
}
