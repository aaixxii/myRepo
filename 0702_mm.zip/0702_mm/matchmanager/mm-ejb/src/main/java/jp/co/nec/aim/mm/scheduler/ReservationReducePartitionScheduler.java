package jp.co.nec.aim.mm.scheduler;

import java.time.LocalDate;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.sessionbeans.ReservationReducePartitionBean;
import jp.co.nec.aim.mm.util.JndiLookup;

@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class ReservationReducePartitionScheduler implements Job {
    
    private static final Logger logger = LoggerFactory.getLogger(ReservationReducePartitionScheduler.class);
    
    public static final String NEW_SAVE_DAYS = "newSaveDays";
    
    public static final String RUN_AT_THIS_DAY = "runAtThisDay";
    
    ReservationReducePartitionBean reservationReducePartitionBean;
    
    public ReservationReducePartitionScheduler() {
        reservationReducePartitionBean = JndiLookup.lookUp(
            JNDIConstants.RESERVAIONREDUCEPARTITIONBEAN, ReservationReducePartitionBean.class);
    }
    
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        if (logger.isDebugEnabled()) {
            logger.debug("ReservationReducePartitionScheduler is run...");
        }
        JobDataMap dataMap = context.getJobDetail().getJobDataMap();
        long newPno = (long) dataMap.get(NEW_SAVE_DAYS);
        LocalDate runDay = (LocalDate) dataMap.get(RUN_AT_THIS_DAY);
        reservationReducePartitionBean.doReducePartition(newPno, runDay);
    }
}
