package jp.co.nec.aim.mm.sessionbeans;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ReservationReducePartitionBean {
	
	private static Logger logger = LoggerFactory.getLogger(ReservationReducePartitionBean.class);
	@PersistenceContext(unitName = "AIMDB")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	
	private PartitionDao partitionDao;
	 private SystemInitDao systemInitDao;	
	
	public ReservationReducePartitionBean() {	
	}
	
	public void doReducePartition(long newNo, LocalDate ruDay) {
		long oldSaveDay = systemInitDao.getSegChangeLogSaveDays();
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, ruDay);
		long adjust = PartitionUtil.getInstance().caculateNewAdjustAtThisDay(newNo, ruDay);
		long newHashValue = (epochDays + adjust) % newNo;
		Date sqlDate = Date.valueOf(ruDay);
		systemInitDao.updateInUsingAdjuist(adjust);
		systemInitDao.updateSegChangeLogSaveDays(String.valueOf(newHashValue));		
		partitionDao.insertPno(newHashValue, sqlDate);
		partitionDao.createPartition(newHashValue);
		logger.info("Success do reduce partition({}->{}) in day{})", oldSaveDay , newNo, ruDay);
	}

}
