CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_new_segment`(
  p_container_id int,
  p_biometrics_id long,
  p_biometric_data_len long,
  out o_reated_segment_id long
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
 declare  del_conatiner_id int;
 declare  l_new_segment_id long;
 DECLARE t_error INTEGER DEFAULT 0; 
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
		INSERT INTO SEGMENTS
             (            
            BIO_ID_START,
             BIO_ID_END,
             BINARY_LENGTH_COMPACTED,
             BINARY_LENGTH_UNCOMPACTED,
             RECORD_COUNT,
             VERSION,
             CONTAINER_ID,
             REVISION
              )
              VALUES
               (                
                  p_biometrics_id,
                  p_biometrics_id,
                  p_biometric_data_len + 54 + 26,
                  p_biometric_data_len + 54 + 26,
                  1,
                  0,
                  p_container_id,
                  0
                );
      -- select last_insert_id() INTO l_new_segment_id;
      select max(SEGMENT_ID) from SEGMENTS into l_new_segment_id;
      set o_reated_segment_id = l_new_segment_id;
END