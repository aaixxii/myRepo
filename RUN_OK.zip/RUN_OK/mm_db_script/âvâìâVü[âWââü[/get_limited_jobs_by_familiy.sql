CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_limited_jobs_by_familiy`(
     OUT tab_name VARCHAR(50)
)
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_family_id int;
  DECLARE l_job_limit_count int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE not_found int DEFAULT 0;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE v_id int;
  DECLARE limit_job_cur CURSOR FOR
  SELECT
    FAMILY_ID,
    JOB_LIMIT_COUNT - JOB_EXEC_COUNT AS limit_count
  FROM INQUIRY_TRAFFIC
  WHERE (JOB_LIMIT_COUNT - JOB_EXEC_COUNT) > 0;

  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
  DROP TABLE IF EXISTS l_job_id_tab;
CREATE TABLE l_job_id_tab (
    id BIGINT(38)
)  ENGINE=INNODB;
   SET  @@autocommit=0;
  OPEN limit_job_cur;
lable_loop:
  LOOP
    FETCH limit_job_cur INTO l_family_id, l_job_limit_count;
	IF not_found = 1 THEN
		LEAVE lable_loop;
	END IF;
    INSERT INTO l_job_id_tab (id)
     SELECT JOB_ID FROM JOB_QUEUE WHERE FAMILY_ID = l_family_id AND JOB_STATE = 0 ORDER BY PRIORITY, FAILURE_COUNT DESC, JOB_ID LIMIT l_job_limit_count;
  END LOOP;
  CLOSE limit_job_cur;
  set tab_name= 'l_job_id_tab';
    if t_error =1 then 
   ROLLBACK;
     set tab_name= '';   
  else 
    commit;
  end if;  
END