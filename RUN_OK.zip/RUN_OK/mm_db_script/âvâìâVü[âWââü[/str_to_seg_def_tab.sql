CREATE DEFINER=`aimuser`@`%` PROCEDURE `str_to_seg_def_tab`(
 IN p_seg_diffs VARCHAR(1024)
)
mylable:BEGIN
	DECLARE v_idx INT DEFAULT 999;
	DECLARE v_tmp_str VARCHAR(1024);
    DECLARE v_view_str VARCHAR(1024);
	DECLARE v_ch_log_id int(38);
    DECLARE his_count int;
	DECLARE seg_diff varchar(64);
	DECLARE v_segmentId VARCHAR(50);
	DECLARE v_reportVersion VARCHAR(50);
	DECLARE v_latestVersion VARCHAR(50);
	DECLARE t_error integer DEFAULT 0;
	DECLARE not_found integer DEFAULT 0; 
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
    	DROP TEMPORARY TABLE IF EXISTS segment_diffs;
	CREATE TEMPORARY TABLE segment_diffs (
      segmentId BIGINT(38),
      reportVersion BIGINT(38),
      latestVersion BIGINT(38)
	) ENGINE = MEMORY;
    	SET  @@autocommit=0;
    IF LENGTH(p_seg_diffs) < 1 THEN
	    LEAVE mylable;
	END IF;
    -- p_seg_diffs= '{1000:1:5},{1001:2:5},{1002:1:7}';
	while_labe: WHILE v_idx > 0 DO
     SET v_idx = INSTR(p_seg_diffs,',');
	 IF v_idx <=0 then
         SET v_tmp_str = SUBSTR(p_seg_diffs,2,LENGTH(p_seg_diffs)-2); 
		 SET v_segmentId = SUBSTRING_INDEX(v_tmp_str,':',1);           
		 SET v_reportVersion = SUBSTRING_INDEX(v_tmp_str,':',2);
         SET v_reportVersion = SUBSTRING_INDEX(v_reportVersion, ':', -1);
		 SET v_latestVersion = SUBSTRING_INDEX(v_tmp_str,':',-1);
		 INSERT INTO  segment_diffs VALUES(CAST(v_segmentId AS UNSIGNED), CAST(v_reportVersion AS UNSIGNED),CAST(v_latestVersion AS UNSIGNED));       
         LEAVE while_labe;
      END IF;
      SET v_tmp_str = SUBSTR(p_seg_diffs,2,v_idx-2);       
	  	 SET v_segmentId = SUBSTRING_INDEX(v_tmp_str,':',1);           
		 SET v_reportVersion = SUBSTRING_INDEX(v_tmp_str,':',2);
         SET v_reportVersion = SUBSTRING_INDEX(v_reportVersion, ':', -1);
		 SET v_latestVersion = SUBSTRING_INDEX(v_tmp_str,':',-1);
		 INSERT INTO  segment_diffs VALUES(CAST(v_segmentId AS UNSIGNED), CAST(v_reportVersion AS UNSIGNED),CAST(v_latestVersion AS UNSIGNED));
         SET p_seg_diffs=substr(p_seg_diffs,v_idx +1 ,LENGTH(p_seg_diffs));
	END WHILE;
    COMMIT;
END