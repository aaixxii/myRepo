CREATE DEFINER=`aimuser`@`%` PROCEDURE `delete_person_bio`(IN p_biometrics_id int(38),
OUT del_count int)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE not_found int DEFAULT 0;
  DECLARE t_error integer DEFAULT 0;
  DECLARE delete_count int DEFAULT 0;
  DECLARE del_count int DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
  SET @@autocommit = 0;
  DELETE
    FROM PERSON_BIOMETRICS
  WHERE BIOMETRICS_ID = p_biometrics_id;
  SELECT
    ROW_COUNT() INTO del_count;
END