CREATE DEFINER=`aimuser`@`%` PROCEDURE `increase_ruc`()
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_count int;
  DECLARE l_update_count int;
  DECLARE l_current_time BIGINT;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
   SET  @@autocommit=0;
SELECT UNIX_TIMESTAMP(NOW()) INTO l_current_time;
  START TRANSACTION;
SELECT 
    COUNT(UPDATE_COUNT)
INTO l_count FROM
    RESOURCE_UPDATE_COUNT;
    IF (l_count = 0) THEN
      INSERT INTO RESOURCE_UPDATE_COUNT (UPDATE_COUNT,
      UPDATE_TS)
        VALUES (1, l_current_time);
    ELSE
      SELECT
        UPDATE_COUNT + 1 INTO l_update_count
      FROM RESOURCE_UPDATE_COUNT
      ORDER BY UPDATE_TS DESC LIMIT 1;
      IF l_update_count < 0 THEN
        SET l_update_count := 0;
      END IF;
UPDATE RESOURCE_UPDATE_COUNT 
SET 
    UPDATE_COUNT = l_update_count,
    UPDATE_TS = l_current_time;
    END IF;
    IF t_error = 1 THEN
      ROLLBACK;
    ELSE
     commit;
    END IF;
  END