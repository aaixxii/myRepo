CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_new_fe_job`(
  IN p_exteral_id  VARCHAR(36),
  IN  p_payload   BLOB,
  IN l_fe_job_id  BIGINT(38)
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_fe_job_id BIGINT(38);
  DECLARE t_error INT DEFAULT 0;
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
   INSERT INTO fe_job_queue (       
        function_id,
        reference_id,
        priority,
        failure_count,
        job_state,
        submission_ts
    ) VALUES (       
        17,
        p_exteral_id,
        1,
        0,
        0,
        match_manager_api.get_epoch_time_num()
    ) ;   
    SELECT MAX(job_id ) into l_fe_job_id FROM fe_job_queue;
    INSERT INTO fe_job_payloads (
        payload_id,
        job_id,
        payload
    ) VALUES (
        fe_job_payload_seq.NEXTVAL,
        l_fe_job_id,
        p_payload
    );
     IF t_error = 1 THEN
       ROLLBACK;        
     ELSE
       COMMIT;         
    END IF; 
END