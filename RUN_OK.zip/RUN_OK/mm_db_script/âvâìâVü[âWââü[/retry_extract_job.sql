CREATE DEFINER=`aimuser`@`%` PROCEDURE `retry_extract_job`(
IN p_extract_job_id BIGINT(38),
IN p_mu_id int,
IN p_reason varchar(20),
IN p_code varchar(20),
IN p_time varchar(20),
OUT l_count int)
    MODIFIES SQL DATA
BEGIN  
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SET  @@autocommit=0;
  UPDATE FE_JOB_QUEUE
  SET LOT_JOB_ID = NULL,
      MU_ID = NULL,
      ASSIGNED_TS = NULL,
      FAILURE_COUNT = FAILURE_COUNT + 1,
      JOB_STATE = 0
  WHERE JOB_ID = p_extract_job_id
  AND JOB_STATE = 1
  AND MU_ID = p_mu_id;
  SELECT  ROW_COUNT() INTO l_count;   
  IF (0 < l_count) THEN
    INSERT INTO FE_JOB_FAILURE_REASONS (
    JOB_ID,
    MU_ID,
    CODE,
    REASON,
    FAILURE_TIME)
      VALUES (p_extract_job_id, p_mu_id, p_code, p_reason, p_time);
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;   
  ELSE
    COMMIT;   
  END IF; 
END