CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_seg_for_del`(
 IN p_biometrics_id bigint(38),
 IN p_container_id int(8),
 IN p_biometric_data_len int(16), 
 out o_seg_id bigint(38),
 out o_seg_ver bigint(38)
 
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
begin_lab:BEGIN
 DECLARE l_segmet_id bigint(38);
 DECLARE l_segment_ver bigint(38);
 DECLARE l_seg_binary_len_comp int(16); 
 DECLARE l_seg_rec_count  bigint(38);
 DECLARE l_seg_revision bigint(38);
 DECLARE del_count int;
 DECLARE l_effect_count int;
 DECLARE t_error INTEGER DEFAULT 0;  
 DECLARE not_found INTEGER DEFAULT 0; 
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found=1; 
  SET  @@autocommit=0;
      DELETE FROM PERSON_BIOMETRICS       
      WHERE BIOMETRICS_ID =  p_biometrics_id;
      SELECT ROW_COUNT() INTO del_count;   
      if del_count <=> 0 THEN        
         SET o_seg_id = -1;
         SET o_seg_ver = -1;
        LEAVE begin_lab;
	  end if;        
      
  SELECT SEGMENT_ID,VERSION, BINARY_LENGTH_COMPACTED,RECORD_COUNT,REVISION
  INTO l_segmet_id,l_segment_ver,l_seg_binary_len_comp,l_seg_rec_count,l_seg_revision
  FROM SEGMENTS
  WHERE  CONTAINER_ID =p_container_id
  AND  p_biometrics_id BETWEEN BIO_ID_START AND BIO_ID_END;
  IF not_found<=>1 THEN  
	 SET o_seg_id = -1;
	 SET o_seg_ver = -1;
     LEAVE begin_lab;
  END IF;   
UPDATE SEGMENTS s
SET BINARY_LENGTH_COMPACTED = l_seg_binary_len_comp - p_biometric_data_len -54,  
	RECORD_COUNT = l_seg_rec_count -1,
	VERSION = l_segment_ver + 1,
	REVISION = l_seg_revision + 1     
WHERE  SEGMENT_ID = l_segmet_id;
   IF t_error <=> 1 THEN  
 	 SET o_seg_id = -1;
	 SET o_seg_ver = -1;
      LEAVE begin_lab;
   END IF;
  SELECT ROW_COUNT() INTO l_effect_count;
  IF l_effect_count = 0 THEN      
	  SET o_seg_id = -1;
	  SET o_seg_ver = -1;      
      LEAVE begin_lab;
    END IF;     
INSERT INTO SEGMENT_CHANGE_LOG(SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE,BIOMETRICS_ID)            
VALUES(l_segmet_id,l_segment_ver+1,1, p_biometrics_id); 
  IF t_error = 1 THEN 
 	 SET o_seg_id = -1;
	 SET o_seg_ver = -1;    
     ROLLBACK;
ELSE   
	SET o_seg_id = l_segmet_id;
	SET o_seg_ver = l_segment_ver + 1;
    COMMIT;
  END IF;
END