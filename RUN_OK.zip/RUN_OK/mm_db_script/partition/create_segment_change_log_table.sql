--create segment change log table

CREATE TABLE IF NOT EXISTS segment_change_log (
  segment_change_id BIGINT(38) ,
  biometrics_id BIGINT(38)  NOT NULL,
  external_id VARCHAR(36),
  template_data BLOB  NULL,   
  segment_id BIGINT(38)  NOT NULL ,
  segment_version BIGINT(38)  NOT NULL ,
  change_type INT(4)  NOT NULL,   #new:0,insert:1,delete:2,update:3 
  update_ts DATE  NOT NULL,
  p_no BIGINT NOT NULL,
  PRIMARY KEY (segment_change_id,p_no)
) ENGINE=INNODB;