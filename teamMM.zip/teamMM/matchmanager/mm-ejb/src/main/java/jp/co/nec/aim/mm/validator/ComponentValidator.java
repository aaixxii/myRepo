package jp.co.nec.aim.mm.validator;

import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBExitRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentInfo;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.util.CollectionsUtil;

import org.apache.commons.lang3.StringUtils;

/**
 * ComponentValidator is used for check the instance of PBComponentInfo <br>
 * if any parameter is not matched, throw ArgumentException, servLet <br>
 * will catch the exception and set the service state to ROLLBACK <br>
 * 
 * @author liuyq
 * 
 */
public final class ComponentValidator {

	/** the instance of ExceptionHelper **/
	private ExceptionHelper exception;

	/**
	 * ComponentValidator default constructor
	 * 
	 * @param dateDao
	 *            the instance of DateDao
	 */
	public ComponentValidator(DataSource dataSource) {
		this.exception = new ExceptionHelper(new DateDao(dataSource));
	}

	/**
	 * checkPBComponentInfo
	 * 
	 * @param component
	 *            PBComponentInfo instance
	 */
	public void checkPBComponentInfo(final PBComponentInfo component) {
		final ComponentType type = component.getComponent();
		if (type == null) {
			exception.throwArgException(AimError.COMPONENT_TYPE_NULL, null);
		}

		if (type == ComponentType.MATCH_MANAGER) {
			exception.throwArgException(AimError.COMPONENT_TYPE, null);
		}

		String version = component.getVersion();
		if (StringUtils.isBlank(version)) {
			exception.throwArgException(AimError.COMPONENT_VERSION, null);
		}

		String uniqueId = component.getUniqueId();
		if (StringUtils.isBlank(uniqueId)) {
			exception.throwArgException(AimError.COMPONENT_UNIQUEID, null);
		}

		String contactURL = component.getContactUrl();
		if (StringUtils.isBlank(contactURL)) {
			exception.throwArgException(AimError.COMPONENT_CONTACTURL, null);
		}

		if (type == ComponentType.MATCH_UNIT
				|| type == ComponentType.DATA_MANAGER) {
			if (component.hasResourceInfo()) {
				PBResourceInfo resource = component.getResourceInfo();
				if (CollectionsUtil.isNotEmpty(resource.getSegmentInfoList())) {
					for (PBSegmentInfo s : resource.getSegmentInfoList()) {
						checkPBSegmentInfo(s);
					}
				}
			}
		}
	}

	/**
	 * check PBExitRequest instance
	 * 
	 * @param PBExitRequest
	 *            PBExitRequest instance
	 */
	public void checkPBExitRequest(final PBExitRequest request) {
		final ComponentType type = request.getComponent();
		if (type == null) {
			exception.throwArgException(AimError.COMPONENT_TYPE_NULL, null);
		}

		if (type == ComponentType.MATCH_MANAGER) {
			exception.throwArgException(AimError.COMPONENT_TYPE, null);
		}

		long unitId = request.getId();
		if (unitId <= 0) {
			exception.throwArgException(AimError.COMPONENT_UNIT_ID, null);
		}
	}

	/**
	 * check PBSegmentInfo instance is valid
	 * 
	 * @param s
	 *            PBSegmentInfo instance
	 */
	private void checkPBSegmentInfo(PBSegmentInfo s) {
		if (s.getId() < 0) {
			exception.throwArgException(AimError.COMPONENT_SEG_ID, null);
		}		
		if ( s.getState() == null) {
			exception.throwArgException(AimError.COMPONENT_SEG_STATUS, null);
		}

		if (s.getState() != null) {
			SegmentStateType state = s.getState();
			if (state == SegmentStateType.SEGMENT_STATE_MEMORY
					|| state == SegmentStateType.SEGMENT_STATE_DISK) {
				if (s.getVersion() < -1) {
					exception.throwArgException(
							AimError.COMPONENT_SEG_VER_NULL, null);
				}
				long version = s.getVersion();
				if (version < 0) {
					exception.throwArgException(AimError.COMPONENT_SEG_VER, null);
				}

				if (s.getQueuedVersion() < -1) {
					long queuedVersion = s.getQueuedVersion();
					if (queuedVersion < version) {
						exception.throwArgException(
								AimError.COMPONENT_SEG_QUEUEVER, null);
					}
				}
			}
		}
	}
}
