package jp.co.nec.aim.mm.sessionbeans;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.acceptor.service.AimExtractService;
import jp.co.nec.aim.mm.acceptor.service.AimInquiryService;
import jp.co.nec.aim.mm.acceptor.service.AimSyncService;
import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.dao.AmqSettingDao;
import jp.co.nec.aim.mm.entities.RqSettingEntity;
import jp.co.nec.aim.mm.util.JndiLookup;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class  AmqServiceBean {
		
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;	
	
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private AmqSettingDao amqDao;
	

	public AmqServiceBean() {
		// zero-arg ctor for container.
	}

	@PostConstruct
	public void init() {		
		amqDao = new AmqSettingDao(manager);
	}
	
	public List<RqSettingEntity> getAllAmqSetting() {
		List<RqSettingEntity> allAmqSetting = amqDao.findAllAmqSetting();
		return allAmqSetting;
	}
	
	public RqSettingEntity getAmqSetting(String amqId) {
		RqSettingEntity oneSetting = amqDao.findAmqSetting(amqId);	
		return oneSetting;
	}
	
	public int updateMasterNode(String masterNode, Timestamp ts, String id) {
		return amqDao.updateMasterNode(masterNode, ts, id);
	}
	
	public RqSettingEntity updateMqEntity(RqSettingEntity newRqSetting) {
		return amqDao.updateMqEntity(newRqSetting);
	}
	
	public AimExtractService lookupAimExtractService() {
		return JndiLookup.lookUp(JNDIConstants.AimExtractService, AimExtractService.class);
	}
	
	public AimInquiryService lookupAimInquiryService() {
		return JndiLookup.lookUp(JNDIConstants.AimInquiryService, AimInquiryService.class);
	}
	
	public AimSyncService lookupAimSyncService() {
		return JndiLookup.lookUp(JNDIConstants.AimSyncService, AimSyncService.class);
	}
}
