package jp.co.nec.aim.mm.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.MMEventType;
import jp.co.nec.aim.mm.constants.SchedulerEnum;
import jp.co.nec.aim.mm.entities.MmEventEntity;

public class MMEventsDao {
	private static final Logger log = LoggerFactory
			.getLogger(MMEventsDao.class);
	private EntityManager manager;

	public MMEventsDao(EntityManager manager) {
		this.manager = manager;
	}

	public Long getLast(MMEventType type) {
		MmEventEntity mmt = manager.find(MmEventEntity.class, type.name());
		if (mmt == null) {
			return null;
		} else {
			return mmt.getLastTs();
		}
	}

	public MmEventEntity getLastMmEventEntity(MMEventType MMEventType) {
		return manager.find(MmEventEntity.class, MMEventType.name());
	}

	public void setLast(long mmId, MMEventType type) {
		MmEventEntity mmt = manager.find(MmEventEntity.class, type.name());
		if (mmt == null) {
			insert(mmId, type);
		} else {
			update(mmId, type);
		}
	}

	int insert(long mmId, MMEventType type) {
		Query query = manager.createNamedQuery("NQ::insertMMEvents");
		query.setParameter("mmId", new Long(mmId));
		query.setParameter("name", type.name());
		return query.executeUpdate();
	}

	int update(long mmId, MMEventType type) {
		Query query = manager.createNamedQuery("NQ::updateMMEvents");
		query.setParameter("mmId", new Long(mmId));
		query.setParameter("name", type.name());
		return query.executeUpdate();
	}

	/**
	 * Returns true if "select * from match_manager_times where name=xxx"
	 * success, returns false if it failes
	 * 
	 * @param schedulerEnum
	 * @return
	 */
	public boolean selectForUpdate(SchedulerEnum schedulerEnum) {
		String sql = "select name from match_manager_times where name='"
				+ schedulerEnum.getMMEventType().name() + "' for update";
		try {
			Query query = manager.createNativeQuery(sql);
			return query.getResultList().size() == 1;
		} catch (PersistenceException e) {
			log.warn(e.getMessage(), e);
			log.warn("Could not get lock of match_manager_times, name="
					+ schedulerEnum.getMMEventType().name());
			return false;
		}
	}

	/**
	 * Judge if MatchManager was working at now - milliDuration(msec)
	 * 
	 * @param milliDuration
	 * @return
	 */
	public boolean isMatchManagerAlive(int milliDuration) {
		if (milliDuration < 0) {
			throw new IllegalArgumentException("duration = " + milliDuration
					+ ", it must be positive.");
		}
		if (getLast(MMEventType.STARTUP) == null) {
			return true;
		}
		Query query = manager.createNamedQuery("NQ::isMatchManagerAlive");
		query.setParameter("milliDuration", new Integer(milliDuration));
		BigInteger result = (BigInteger) query.getSingleResult();
		return result.intValue() == 1;
	}

	public long passedEnough(String name, Long interval, Long limit) {
		log.debug("passedEnough start..");
		Query query = manager.createNamedQuery("NQ:passedEnough");
		query.setParameter("name", name);
		query.setParameter("interval", interval);
		query.setParameter("limit", limit);
		BigInteger count = ((BigInteger) query.getSingleResult());
		log.debug("passedEnough end..");
		return count.longValue();
	}
}
