package jp.co.nec.aim.mm.exception;

public class HttpPostException extends AimErrorInfoException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2874681181709291204L;

	public HttpPostException(String errorCode, String description,String time, String uidCode) {
		super(errorCode,description, time, uidCode);
	}

	public HttpPostException(Throwable ex) {
		super(ex);
	}

	public HttpPostException(String detail, Throwable ex) {
		super(detail, ex);
	}

}
