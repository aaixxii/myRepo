package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * Procedure sub Class to call finish_timeout_job()<br/>
 * finish_timeout_job() set DONE for SEMGNET_JOBS but not JOB_QUEUE. TopLevelJob
 * should be set DONE by JobAggregation
 * 
 * @author kurosu
 * 
 */
public class FetchTimeoutJobProcedure extends StoredProcedure {
	private static final String SQL = "fetch_timeout_job";
	private JdbcTemplate jdbcTemplate;

	public FetchTimeoutJobProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));				
		setSql(SQL);
		compile();
	}

	/**
	 * update timeout JOBS DONE.
	 * 
	 * @return long array of JOB_ID , which is timeout and should be retry.
	 * @throws SQLException
	 */
	public List<Long> execute() throws SQLException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = execute(new HashMap<String, Object>());		
		String tableName = (String) map.get("tab_name");
		String sql = "select * from " + tableName;
		List<Long> timeOutJobList = jdbcTemplate.queryForList(sql, Long.class);
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());
		jdbcTemplate.execute("DROP TEMPORARY TABLE IF EXISTS " + tableName);
		return timeOutJobList;
	}

}
