package jp.co.nec.aim.mm.extract.dispatch;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.HttpResponseInfo;
import jp.co.nec.aim.mm.util.StopWatch;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Http poster to post extract request to mu
 * 
 * @author xiazp
 * 
 */
public class ExtractRequestPoster {
	private static final Logger logger = LoggerFactory
			.getLogger(ExtractRequestPoster.class);
	private static final int EXTRACT_TIMEOUT = 60000;
	private static final long PostPeriodFor503 = 1000;

	/**
	 * @param Url
	 * @param muPostRetryCount
	 * @param request
	 * @return
	 */
	public boolean postRequest(String Url, int muPostRetryCount, byte[] request) {
		HttpResponseInfo info = null;
		boolean postResults = false;
		logger.info("Starting to send extract request to: {}, body size: {}.",
				Url, request.length);
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		if (request == null || request.length == 0 || Url == null
				|| Url.length() <= 0 || Url.isEmpty()) {
			throw new IllegalArgumentException();
		}
		try {
			info = HttpPoster.post(Url, request, muPostRetryCount,
					EXTRACT_TIMEOUT);
			switch (info.getStatusCode()) {
			case HttpStatus.SC_OK:
				logger.info("Success to send extract request to:" + Url);
				stopWatch.stop();
				PerformanceLogger.log(getClass().getSimpleName(),
						"postRequest", stopWatch.elapsedTime());
				postResults = true;
				break;
			case HttpStatus.SC_SERVICE_UNAVAILABLE:
				postResults = retryPost(Url, request, muPostRetryCount,
						EXTRACT_TIMEOUT);
				break;
			default:
				logger.warn(
						"Failed to send extract request to:{}, response status:{}:",
						Url, info.getStatusCode());
				postResults = false;
			}
		} catch (HttpPostException e) {
			logger.error(e.getMessage(), e);
			AimError error = AimError.EXTRACT_DISPATCH_SEND_RETRY_OVER;
			ExceptionSender exceptionSender = new ExceptionSender();
			exceptionSender.sendAimException(error.getErrorCode(),
					String.format(error.getMessage() + " ." + e.getMessage()),
					new Exception(e.getMessage()));
			postResults = false;
		}
		return postResults;
	}

	/**
	 * 
	 * @param Url
	 * @param request
	 * @param muPostRetryCount
	 * @param EXTRACT_TIMEOUT
	 */
	public boolean retryPost(String Url, byte[] request, int muPostRetryCount,
			int EXTRACT_TIMEOUT) {
		HttpResponseInfo info = null;
		boolean mustPost = true;
		boolean retryPostResults = false;
		StopWatch stopWatch = new StopWatch();
		while (mustPost) {
			logger.warn(
					"Mu is in status of preparing, continue to post to {} until successed.",
					Url);
			try {
				Thread.sleep(PostPeriodFor503);
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);
				retryPostResults = false;
				mustPost = false;
			}
			try {
				info = HttpPoster.post(Url, request, muPostRetryCount,
						EXTRACT_TIMEOUT);
				switch (info.getStatusCode()) {
				case HttpStatus.SC_OK:
					mustPost = false;
					retryPostResults = true;
					stopWatch.stop();
					PerformanceLogger.log(getClass().getSimpleName(),
							"retryPost", stopWatch.elapsedTime());
					break;
				case HttpStatus.SC_SERVICE_UNAVAILABLE:
					break;
				default:
					logger.warn(
							"Failed to send extract request to:{}, response status:{}",
							Url, info.getStatusCode());
					retryPostResults = false;
					mustPost = false;
				}
			} catch (HttpPostException e) {
				logger.error(e.getMessage(), e);
				AimError error = AimError.EXTRACT_DISPATCH_SEND_RETRY_OVER;
				ExceptionSender exceptionSender = new ExceptionSender();
				exceptionSender.sendAimException(error.getErrorCode(),
						String.format(error.getMessage() +  e.getMessage()),
						new Exception(e.getMessage()));
				retryPostResults = false;
				mustPost = false;
			}
		}
		return retryPostResults;
	}

	/**
	 * PostRequest to the mu
	 * 
	 * @param Url
	 * @param message
	 * @return
	 */
	public boolean postRequest(String Url, int muPostRetryCount, String message) {
		logger.info("Starting to send extract request to:" + Url);
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		HttpResponseInfo info = null;
		boolean postResults = false;
		if (message == null || message.length() == 0 || Url == null
				|| Url.length() <= 0 || Url.isEmpty()) {
			throw new IllegalArgumentException();
		}
		try {
			info = HttpPoster.post(Url, message, muPostRetryCount,
					EXTRACT_TIMEOUT);
			switch (info.getStatusCode()) {
			case HttpStatus.SC_OK:
				logger.info("Success to send extract request to:" + Url);
				stopWatch.stop();
				PerformanceLogger.log(getClass().getSimpleName(),
						"postRequest", stopWatch.elapsedTime());
				postResults = true;
				break;
			case HttpStatus.SC_SERVICE_UNAVAILABLE:
				postResults = retryPost(Url, muPostRetryCount, message);
				break;
			default:
				logger.warn(
						"Failed to send extract request to:{}, response status:{}:",
						Url, info.getStatusCode());
				postResults = false;
			}
		} catch (HttpPostException e) {
			logger.error(e.getMessage(), e);
			AimError error = AimError.EXTRACT_DISPATCH_SEND_RETRY_OVER;
			ExceptionSender exceptionSender = new ExceptionSender();
			exceptionSender.sendAimException(error.getErrorCode(),
					String.format(error.getMessage(), e.getMessage()),
					new Exception(e.getMessage()));
			postResults = false;
		}
		return postResults;
	}

	/**
	 * 
	 * @param Url
	 * @param muPostRetryCount
	 * @param message
	 */
	public boolean retryPost(String Url, int muPostRetryCount, String message) {
		boolean mustPost = true;
		boolean retryPostResults = false;
		HttpResponseInfo info = null;
		StopWatch stopWatch = new StopWatch();
		while (mustPost) {
			logger.warn(
					"Mu is in status of preparing, continue to post to {} until successed.",
					Url);
			try {
				Thread.sleep(PostPeriodFor503);
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);
				retryPostResults = false;
				mustPost = false;
			}
			try {
				info = HttpPoster.post(Url, message, muPostRetryCount,
						EXTRACT_TIMEOUT);
				switch (info.getStatusCode()) {
				case HttpStatus.SC_OK:
					mustPost = false;
					retryPostResults = true;
					stopWatch.stop();
					PerformanceLogger.log(getClass().getSimpleName(),
							"retryPost", stopWatch.elapsedTime());
					break;
				case HttpStatus.SC_SERVICE_UNAVAILABLE:
					break;
				default:
					logger.warn(
							"Failed to send extract request to:{}, response status:{}:",
							Url, info.getStatusCode());
					retryPostResults = false;
					mustPost = false;
				}
			} catch (HttpPostException e) {
				logger.error(e.getMessage(), e);
				AimError error = AimError.EXTRACT_DISPATCH_SEND_RETRY_OVER;
				ExceptionSender exceptionSender = new ExceptionSender();
				exceptionSender.sendAimException(error.getErrorCode(),
						String.format(error.getMessage(), e.getMessage()),
						new Exception(e.getMessage()));
				retryPostResults = false;
				mustPost = false;
			}
		}
		return retryPostResults;
	}
}
