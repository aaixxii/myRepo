package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.FusionJobEntity;
import jp.co.nec.aim.mm.util.CollectionsUtil;

/**
 * FusionJobDao Utility
 * 
 * @author xiazp
 * 
 */
public class FusionJobDao {
	private EntityManager manager; // EntityManager instance

	public FusionJobDao(EntityManager manager) {
		this.manager = manager;
	}

	@SuppressWarnings("unchecked")
	public FusionJobEntity getFusionInfo(Long jobId) {
		Query q = manager.createNamedQuery("NQ::getFusionInfo");
		q.setParameter("topJobId", jobId);
		List<FusionJobEntity> results = q.getResultList();
		if (CollectionsUtil.isEmpty(results)) {
			return null;
		}
		return CollectionsUtil.getFirst(results);
	}
}
