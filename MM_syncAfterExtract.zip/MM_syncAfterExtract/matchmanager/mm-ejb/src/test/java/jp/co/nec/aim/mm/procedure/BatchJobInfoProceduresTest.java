package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class BatchJobInfoProceduresTest {	
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	
	private BatchJobInfoProcedures batchJobInfoProcedures;

	@Before
	public void setUp() throws Exception {
		batchJobInfoProcedures = new BatchJobInfoProcedures(dataSource);
		jdbcTemplate.update("delete from BATCH_JOB_INFO");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateNewBatchJobInfo() throws SQLException {
		Integer batchJobId= 1000;
		String requestId = "reQuestId1111";
		String referenceId = "refernceId1111";
		String batchType = "EXRACT";
		Integer feJobId = 1000;		
		batchJobInfoProcedures.createNewBatchJobInfo(batchJobId, requestId,referenceId, batchType, feJobId);
		System.out.print("OKOK");		
	}
	
	   @Test
	    public void testCreateNewBatchJobInfo_refId_null() throws SQLException {
	        Integer batchJobId= 1000;
	        String requestId = "reQuestId1111";
	        String referenceId = null;
	        String batchType = "EXRACT";
	        Integer feJobId = 1000;     
	        batchJobInfoProcedures.createNewBatchJobInfo(batchJobId, requestId,referenceId, batchType, feJobId);
	        System.out.print("OKOK");       
	    }

}
