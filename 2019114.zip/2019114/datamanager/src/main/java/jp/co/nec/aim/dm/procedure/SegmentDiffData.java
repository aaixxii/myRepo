package jp.co.nec.aim.dm.procedure;

import jp.co.nec.aim.dm.constants.DiffCommand;

public class SegmentDiffData implements Comparable<SegmentDiffData>{
	private int version;
	private DiffCommand diffCommand;
	private long templateId;
	private byte[] template;
	private String externalId;
	private int eventId;

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public DiffCommand getDiffCommand() {
		return diffCommand;
	}

	public void setDiffCommand(DiffCommand diffCommand) {
		this.diffCommand = diffCommand;
	}

	public long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(long templateId) {
		this.templateId = templateId;
	}

	public byte[] getTemplate() {
		return template;
	}

	public void setTemplate(byte[] template) {
		this.template = template;
	}

	@Override
	public int compareTo(SegmentDiffData o) {
		if(templateId == o.templateId) {
			return (int)(version - o.version);
		} else {
			return (int)(templateId - o.templateId);
		}
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

}
