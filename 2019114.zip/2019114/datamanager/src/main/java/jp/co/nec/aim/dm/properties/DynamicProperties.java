package jp.co.nec.aim.dm.properties;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import jp.co.nec.aim.dm.exception.DataManagerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DynamicProperties {
	private static Logger log = LoggerFactory
			.getLogger(DynamicProperties.class);
	private static final String PROPERTIES_FILE = "aim.dm.properties";
	private static final DynamicProperties INSTANCE = new DynamicProperties();
	private Properties props;

	public static DynamicProperties getInstance() {
		return INSTANCE;
	}

	private DynamicProperties() {
		load();
	}

	private void load() {
		try {
			InputStream in = this.getClass().getClassLoader()
					.getResourceAsStream(PROPERTIES_FILE);
			if (in != null) {
				props = new Properties();
				props.load(in);
				log.debug("Loaded DM Properties: "
						+ props.entrySet().toString());
			} else {
				throw new DataManagerException(
						"Couldn't find properties file: " + PROPERTIES_FILE);
			}
		} catch (IOException e) {
			throw new DataManagerException(
					"IOException reading properties file: " + PROPERTIES_FILE,
					e);
		}
	}

	/**
	 * get max download limit
	 * 
	 * @return max download limit
	 */
	public Integer getDownloadLimit() {
		String value = getPropertyValue(
				DynamicPropertyNames.LIMIT_OF_SEGMENT_DOWNLOAD_REQUEST, true);
		return Integer.valueOf(value);
	}

	public String getPropertyValue(DynamicPropertyNames name) {
		return getPropertyValue(name, true);
	}

	public String getPropertyValue(DynamicPropertyNames name, boolean mustExist) {
		if (props != null) {
			String val = props.getProperty(name.name());
			if (mustExist && val == null)
				throw new DataManagerException("Property " + name
						+ " not set in properties file.");
			return val;
		} else {
			throw new DataManagerException(
					"Dynamic properties never initialized.");
		}
	}
}
