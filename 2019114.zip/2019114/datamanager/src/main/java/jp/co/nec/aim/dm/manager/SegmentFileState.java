package jp.co.nec.aim.dm.manager;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import jp.co.nec.aim.dm.constants.SegmentStatusValue;
import jp.co.nec.aim.dm.constants.WriteAction;
import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.exception.DataManagerException;
import jp.co.nec.aim.dm.persistence.SegmentFileWriteResult;
import jp.co.nec.aim.dm.persistence.SegmentFileWritingJob;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

public class SegmentFileState {

	private static Logger log = LoggerFactory.getLogger(SegmentFileState.class);
	// immutable state
	private final Integer segmentId;
	private final File segmentFile;
	private final ReentrantReadWriteLock readWriteLock;

	// mutable state
	private Integer version; // if null, not on disk
	private Integer serverVersion; // if null, unassigned or defunct. if
	// non-null, represents last version from
	// MM.
	private SegmentFileWritingJob writeJob; // if null, no write job scheduled.
	private boolean writeJobInProgress;
	private Date lastFailure;
	private int deletesAfterSegmentation;
	private List<Long> badTemplateIds;

	private SegmentFileState(Integer segmentId, Integer version) {
		this.segmentId = segmentId;
		segmentFile = new File(new SegmentFileName(segmentId).getName());
		readWriteLock = new ReentrantReadWriteLock();
		this.version = version;
		this.serverVersion = null;
		writeJob = null;
		writeJobInProgress = false;
		lastFailure = null;
		deletesAfterSegmentation = 0;
		badTemplateIds = new ArrayList<Long>();
	}

	// ///////////////// FACTORY (CONSTRUCTION) METHODS /////////////////////
	// New SegmentState objects are created in only two places: at startup, when
	// taking inventory from disk, and by the communication thread upon commands
	// from the MM.
	// Hence there are two factory methods for instantiating a SegmentState
	// object, one
	// for each situation.

	// called at startup by the StartupSegmentFileInventory with version = (disk
	// version),
	// called by communication thread when it discovers need for a new hashmap
	// entry with version = null.
	public static  SegmentFileState newInstance(Integer segmentId,
			Integer version) {
		return new SegmentFileState(segmentId, version);
	}

	// /////////// METHODS CALLED BY HTTP DOWNLOAD THREADS ONLY
	// ////////////////////

	// called by HTTP threads only.
	public synchronized boolean isOnDisk() {
		return version != null;
	}

	public synchronized boolean isWriteInProgress() {
		return writeJobInProgress;
	}

	// called by HTTP threads only.
	public void acquireReadLock() {
		readWriteLock.readLock().lock();
	}

	// called by HTTP threads only.
	public void releaseReadLock() {
		readWriteLock.readLock().unlock();
	}

	// called by HTTP threads only.
	public File getFile() throws FileNotFoundException {
		// callers should always posses read lock at this point.
		if (readWriteLock.getReadLockCount() == 0) {
			throw new DataManagerException(
					"getInputStream() caller does not posses readWriteLock.. should be impossible.");
		}
		return segmentFile;
	}

	// ///////////// METHODS CALLED BY WRITE THREADS ONLY
	// ////////////////////////

	// called by write threads only.
	public Integer getSegmentId() {
		return segmentId; // safe because segmentId is immutable.
	}

	// called by write threads only. only write threads acquire the write lock.
	public void acquireWriteLock() {
		readWriteLock.writeLock().lock();
	}

	// called by write threads only. only write threads acquire the write lock.
	public void releaseWriteLock() {
		readWriteLock.writeLock().unlock();
	}

	// called by write threads only.
	public synchronized WriteAction startAction() {
		if (writeJob == null) {
			throw new DataManagerException(
					"Impossible state: startAction() call when writeJob is null");
		}
		writeJobInProgress = true;
		return decideNeededAction();
	}

	private WriteAction decideNeededAction() {
		if (serverVersion == null) {
			return WriteAction.NO_OP;
		} else {
			if (version != null) {
				// get the version different, if over maxSegmentDiff
				// the next action will create SegmentFileCreator instance
				// if between the 0 and maxSegmentDiff, do update operation
				// otherwise do no operation.
				ApplicationContext appContext = SegmentFileManager.getInstance().getAppContext();
				JdbcTemplate jdbcTemplate = (JdbcTemplate) appContext.getBean("jdbcTemplate");
				int maxSegmentDiff = Integer.MAX_VALUE;
				try {
					maxSegmentDiff = jdbcTemplate.queryForInt("select PROPERTY_VALUE from SYSTEM_CONFIG where PROPERTY_NAME='BEHAVIOR.MAX_SEGMENT_DIFFS'");
				} catch (DataAccessException e) {
					log.error(e.getMessage(), e);
				}
				if(maxSegmentDiff <= 0) {
					log.warn("BEHAVIOR.MAX_SEGMENT_DIFFS in SYSTEM_CONFIG is {}, are you OK?", maxSegmentDiff);
				}

				int versionDiff = serverVersion - version;
				if(versionDiff <= 0) {
					return WriteAction.NO_OP;
				} else {
					if(versionDiff < maxSegmentDiff) {
						return WriteAction.UPDATE;
					} else {
						return WriteAction.RE_CREATE;
					}
				}
			} else {
				return WriteAction.CREATE;
			}
		}
	}

	private SegmentStatusValue decideStatusValue() {
		if (version == null) {
			WriteAction action = decideNeededAction();
			if (action == WriteAction.CREATE && writeJob != null) {
				if (writeJobInProgress)
					return SegmentStatusValue.CURRENTLY_DOWNLOADING;
				else
					return SegmentStatusValue.QUEUED_FOR_DOWNLOAD;
			}
			return SegmentStatusValue.NOT_REPORTED;
		} else {
			return SegmentStatusValue.ON_DISK; // if we have the segment, just
			// return ON_DISK
		}
	}

	public synchronized SegmentFileStateSnapshot getSnapShot() {
		SegmentStatusValue statusValue = decideStatusValue();
		String jobState = (writeJob == null ? null : writeJob.getJobState());
		return new SegmentFileStateSnapshot(segmentId, statusValue, version,
				serverVersion, jobState, writeJobInProgress, lastFailure,
				deletesAfterSegmentation, badTemplateIds);
	}

	public synchronized void finishAction(SegmentFileWriteResult fwr) {
		if (fwr != null) {
			writeJob = null;
			writeJobInProgress = false;
			lastFailure = null;
			if (fwr.isSetVersion()) {
				version = fwr.getSegmentVersion();
			}
			if (fwr.isClearNumDeleted()) {
				deletesAfterSegmentation = 0;
			} else {
				deletesAfterSegmentation += fwr.getNumDeleted();
			}
			if (fwr.isClearBadTemplates()) {
				badTemplateIds.clear();
			}
			if (fwr.getBadTemplateIds() != null) {
				badTemplateIds.addAll(fwr.getBadTemplateIds());
			}
		} else {
			failAction();
		}
	}

	public synchronized void failAction() {
		writeJob = null;
		writeJobInProgress = false;
		version = null;
		lastFailure = new Date();
	}

	/**
	 * Called by communication thread AND segmentfileCompaction thread to
	 * schedule a WRITE. returns whether or not a new write thread Runnable
	 * needs to be created.
	 * 
	 */
	public synchronized boolean scheduleWriteIfNecessary(
			SegmentFileWritingJob newWriteJob, Integer serverVersion) {
		log.debug("scheduleWriteIfNecessary() called for segment " + segmentId);
		if (!writeJobInProgress) { // while write is actually in progress, no
			// further scheduling possible.
			if (this.serverVersion != serverVersion) {
				log.debug("Setting serverVersion -> " + serverVersion);
				this.serverVersion = serverVersion;
			}

			if (writeJob == null) {
				writeJob = newWriteJob;
				return true;
			}

		} else {
			log.debug("write job in progress... skipping.");
		}
		return false;
	}

	public synchronized void unsetWriteAction() {
		writeJob = null;
	}

	// Called by Write thread(DiffGenerator)
	public synchronized Integer getVersion() {
		return version;
	}

	// called in various places, should be safe though...
	public synchronized String toString() {
		return new ToStringBuilder(this).append("segmentId", segmentId)
				.append("segmentFile", segmentFile).append("version", version)
				.append("writeInProgress", writeJobInProgress)
				.append("lastFailure", lastFailure).toString();
	}

}
