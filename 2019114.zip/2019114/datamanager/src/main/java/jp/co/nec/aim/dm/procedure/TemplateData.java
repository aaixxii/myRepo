package jp.co.nec.aim.dm.procedure;


public class TemplateData {
	private long biometricsId;
	private byte[] biometricData;
	private String externalId;
	private int eventId;

	public long getBiometricsId() {
		return biometricsId;
	}

	public void setBiometricsId(long biometricsId) {
		this.biometricsId = biometricsId;
	}

	public byte[] getBiometricData() {
		return biometricData;
	}

	public void setBiometricData(byte[] biomrtdicData) {
		this.biometricData = biomrtdicData;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

}
