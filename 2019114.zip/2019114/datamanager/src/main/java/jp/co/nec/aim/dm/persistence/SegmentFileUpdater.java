package jp.co.nec.aim.dm.persistence;

import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_CHECK_SUM;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_HEADER_VERSION;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_MAX_SEGMENT_FILE_LENGTH;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_RECORD_COUNT;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_SEGMENT_GROUP;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import javax.sql.DataSource;

import jp.co.nec.aim.dm.constants.DiffCommand;
import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.exception.SegmentFileWritingException;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.manager.IndexManager;
import jp.co.nec.aim.dm.procedure.DownloadSegmentDiffsProcedure;
import jp.co.nec.aim.dm.procedure.SegmentDiffData;
import jp.co.nec.aim.dm.util.SumFileUtil;
import jp.co.nec.aim.helper.TemplateHeaderHelper;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SegmentFileUpdater implements SegmentFileWriter,
		ApplicationContextAware {
	private static final Logger log = LoggerFactory
			.getLogger(SegmentFileUpdater.class);
	private static ApplicationContext appContext;

	// ///////////////////// STATE related ///////////////////////
	// This is to display progress for the xml 'view'

	private static enum SegmentFileUpdateState {
		WAITING_TO_RUN, EXECUTING_QUERY, APPLYING_UPDATES, DONE;
	}

	private SegmentFileUpdateState state;
	private Integer currentVersion;

	private List<Long> badTemplateIds;
	private DownloadSegmentDiffsProcedure procedure;

	public SegmentFileUpdater() {
		badTemplateIds = new ArrayList<Long>();
		currentVersion = null;
		state = SegmentFileUpdateState.WAITING_TO_RUN;
	}

	private synchronized void updateJobState(int currentVersion) {
		this.state = SegmentFileUpdateState.APPLYING_UPDATES;
		this.currentVersion = currentVersion;
	}

	private synchronized void updateJobState(SegmentFileUpdateState state) {
		this.state = state;
	}

	// called by XML 'view' classes to display state of running jobs.
	public synchronized String getJobState() {
		if (state == SegmentFileUpdateState.APPLYING_UPDATES) {
			return "Applying segment version update " + currentVersion;
		} else {
			return state.name();
		}
	}

	// ///////////////////// SEGMENT FILE UPDATE ///////////////////////
	// Main execute() function and helpers

	@Override
	public SegmentFileWriteResult execute(int segmentId, Integer startingVersion)
			throws SegmentFileWritingException {
		log.info("Segment file writer starting UPDATE of segment: " + segmentId
				+ ", starting version: " + startingVersion);
		RandomAccessFile randFile = null;
		SegmentFileName segFileName = new SegmentFileName(segmentId);
		File segFile = new File(segFileName.getName());
		try {
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			if (!segFile.exists()) {
				throw new SegmentFileWritingException(segFile.getName()
						+ " does not exist");
			}
			if (SumFileUtil.exists(segmentId)) {
				log.warn("[{}].sum exists. I'll remove this.", segmentId);
				if (!SumFileUtil.remove(segmentId)) {
					String message = "Can't remove [" + segmentId
							+ "].sum file";
					log.error(message);
					throw new SegmentFileWritingException(message);
				}
				SegmentFileCreator creator = (SegmentFileCreator) appContext
						.getBean("segmentFileCreator");
				return creator.execute(segmentId, startingVersion);
			}

			SumFileUtil.create(segmentId);
			// Call loadIndexFile() before new RandomAccessFile(). because
			// loadIndexFile() might open Segment File
			IndexManager.getInstance().loadIndexFile(segmentId);
			randFile = new RandomAccessFile(segFileName.getName(), "rw");

			checkHeaderInfo(segmentId, startingVersion, randFile);
			int recordCount = readRecordCount(randFile);
			SegmentFileUpdateProgress prog = new SegmentFileUpdateProgress(
					startingVersion, recordCount);

			log.debug("Querying for segment diffs for segment " + segmentId
					+ ", starting version: " + startingVersion);
			updateJobState(SegmentFileUpdateState.EXECUTING_QUERY);
			List<SegmentDiffData> diffDataList = setOffDiffData(
					segmentId,
					prog,
					procedure.execute((long) segmentId,
							startingVersion.longValue()));
			List<SegmentDiffData> deleteDataList = fetchDeleteData(diffDataList);
			List<SegmentDiffData> insertDataList = fetchInsertData(diffDataList);

			bulkDelete(randFile, segmentId, prog, deleteDataList);
			bulkInsert(randFile, segmentId, prog, insertDataList);

			writeRecordCountHeader(randFile, segmentId, prog.getRecordCount());
			writeSegmentVersionHeader(randFile, segmentId, prog.getVersion());
			randFile.getChannel().force(false);
			IOUtils.closeQuietly(randFile);

			IndexManager.getInstance().saveIndex(segmentId);
			if (!SumFileUtil.remove(segmentId)) {
				log.warn("Can't remove {}.sum!", segmentId);
			}
			updateJobState(SegmentFileUpdateState.DONE);

			log.info("Finished SegmentFileUpdate of segment: " + segmentId
					+ ". Went from v." + startingVersion + " -> v."
					+ prog.getVersion());
			if (log.isDebugEnabled()) {
				log.debug("Total number of inserts= {}, no-op inserts= {}",
						new Integer(prog.getNumInserts()),
						new Integer(prog.getNumFakeInserts()));
				log.debug("Total number of deletes= {}, no-op deletes= ",
						new Integer(prog.getNumDeletes()),
						new Integer(prog.getNumFakeDeletes()));
			}

			stopWatch.stop();
			log.info("Updated {}.seg from version:{} to {} took {} msec",
					new Object[] { new Integer(segmentId), startingVersion,
							prog.getVersion(), new Long(stopWatch.getTime()) });
			PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
					.getSimpleName(), Thread.currentThread().getStackTrace()[1]
					.getMethodName(), stopWatch.getTime());
			return SegmentFileWriteResult.constructUpdateResult(
					prog.getVersion(), prog.getNumDeletes(), badTemplateIds);
		} catch (IOException e) {
			throw new SegmentFileWritingException(
					"Exception while updating the segment file" + segmentId, e);
		} finally {
			IOUtils.closeQuietly(randFile);
		}
	}

	void bulkInsert(RandomAccessFile randFile, int segmentId,
			SegmentFileUpdateProgress prog, List<SegmentDiffData> insertDataList)
			throws IOException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		int preInserts = prog.getNumInserts();
		try {
			if (insertDataList == null || insertDataList.size() == 0) {
				return;
			}
			// Seek to the end of file.
			randFile.seek(randFile.length());
			for (SegmentDiffData data : insertDataList) {
				int version = data.getVersion();
				byte[] templates = data.getTemplate();
				long templateId = data.getTemplateId();
				if (log.isDebugEnabled()) {
					log.debug(
							"For update of segment {}, applying segment diff: INSERT {} (v.{})",
							new Object[] { new Integer(segmentId),
									new Long(templateId), new Integer(version) });
				}

				if (prog.getVersion().intValue() < version) {
					if (log.isDebugEnabled()) {
						log.debug(
								"Update {}.seg version from {} to {}",
								new Object[] { new Integer(segmentId),
										prog.getVersion(), new Integer(version) });
					}
					updateJobState(version);
					prog.setVersion(new Integer(version));
				}
				if (templates == null) {
					log.warn(
							"TEMPLATE_ID:{} is empty. Can't add template to {}.seg, ignoring...",
							new Long(templateId), new Integer(segmentId));
					prog.incrementFakeInserts();
				} else {
					IndexManager.getInstance().addIndexEndOfFile(randFile,
							segmentId, templateId);
					byte[] templateWithHeader = TemplateHeaderHelper
							.prependHeader(templateId, templates,
									data.getExternalId(), data.getEventId());
					randFile.write(templateWithHeader);
					// increment the record count and write it out
					prog.incrementRecordCount();
					if (log.isDebugEnabled()) {
						int count = prog.getRecordCount();
						log.debug(
								"Inserted TEMPLATE_ID:{} into {}.seg. Increased recordCount from {} to {}",
								new Object[] { new Long(templateId),
										new Integer(segmentId),
										new Integer(count - 1),
										new Integer(count) });
					}
				}
				prog.incrementInserts();
			}
		} finally {
			stopWatch.stop();
			log.info(
					"bulkInsert() inserted {} records and took {} msec for SEGMENT_ID:{}",
					new Object[] {
							new Integer((prog.getNumInserts() - preInserts)),
							new Long(stopWatch.getTime()), new Long(segmentId) });
		}
	}

	void bulkDelete(RandomAccessFile randFile, int segmentId,
			SegmentFileUpdateProgress prog, List<SegmentDiffData> deleteDataList)
			throws IOException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		int preDeletes = prog.getNumDeletes();
		SeekState seekState = new SeekState(randFile.length());
		try {
			if (deleteDataList == null || deleteDataList.size() == 0) {
				return;
			}
			// deleteDataList is sorted by templateId.
			for (SegmentDiffData deleteData : deleteDataList) {
				long toDeleteId = deleteData.getTemplateId();
				long indexedPosition = IndexManager.getInstance().getPosition(
						segmentId, toDeleteId);
				StopWatch deleteWatch = new StopWatch();
				deleteWatch.start();
				if (indexedPosition < 0) {
					// toDeleteId does not exist in segment file.
					log.warn("TEMPLATE_ID:{} does not exist in {}.seg",
							new Long(toDeleteId), new Long(segmentId));
					prog.incrementFakeDeletes();
				} else {
					if (log.isDebugEnabled()) {
						log.debug(
								"File Index pointer of TEMPLATE_ID:{} in {}.seg is {}",
								new Object[] { new Long(toDeleteId),
										new Integer(segmentId),
										new Long(indexedPosition) });
					}
					seekState.updateCurrentPosition(indexedPosition);
					if (log.isDebugEnabled()) {
						log.debug("Going to seek from {} in {}.seg", new Long(
								seekState.getCurrentPosition()), new Integer(
								segmentId));
					}
					boolean deleted = false;
					while (seekState.canSeek()) {
						if (log.isDebugEnabled()) {
							log.debug("Seek position:{} in {}.seg", new Long(
									seekState.getCurrentPosition()),
									new Integer(segmentId));
						}
						randFile.seek(seekState.getCurrentPosition());
						seekState.addSeekTime();
						int templateSize = randFile.readInt();
						long templateId = randFile.readLong();
						if (log.isDebugEnabled()) {
							log.debug(
									"Read TEMPLATE_ID:{} , templateSize:{} in {}.seg",
									new Object[] { new Long(templateId),
											new Integer(templateSize),
											new Integer(segmentId) });
						}
						if (templateId == toDeleteId) {
							if (log.isDebugEnabled()) {
								log.debug(
										"Found {} at {} in {}.seg",
										new Object[] {
												new Long(toDeleteId),
												new Long(seekState
														.getCurrentPosition()),
												new Integer(segmentId) });
							}
							if (deleted = deleteTemplate(randFile, prog,
									seekState, deleteData)) {
								if (log.isDebugEnabled()) {
									log.debug(
											"Set deleteFlag=1 for TEMPLATE_ID:{} in {}.seg",
											new Long(templateId), new Integer(
													segmentId));
								}
							} else {
								// Can't delete
								log.warn(
										"deleteFlag of TEMPLATE_ID:{} in {}.seg is already set 1, skipping...",
										new Long(templateId), new Integer(
												segmentId));
							}
							seekState.addCurrentPosition(SIZE_CHECK_SUM
									+ templateSize);
							break;
						} else if (toDeleteId < templateId) {
							// Can't delete
							log.warn(
									"Can't find to delete TEMPLATE_ID:{} in {}.seg. It might have been removed from PERSON_BIOMETRICS",
									new Long(toDeleteId),
									new Integer(segmentId));
							break;
						} else {
							seekState.addCurrentPosition(SIZE_CHECK_SUM
									+ templateSize);
						}
					}

					if (!deleted) {
						log.warn(
								"Couldn't set deleteFlag=1 for TEMPLATE_ID:{} in {}.seg",
								new Long(toDeleteId), new Integer(segmentId));
						prog.incrementFakeDeletes();
					}
				}

				tryUpdateVersion(prog, deleteData);
				seekState.replaceLastWithCurrent();
				prog.incrementDeletes();
				deleteWatch.stop();
				if (log.isDebugEnabled()) {
					log.debug("It took {} msec to try delete templateId:{}",
							deleteWatch.getTime(), toDeleteId);
				}
			}
		} finally {
			stopWatch.stop();
			log.info(
					"bulkDelete() deleted {} records, seek {} times and took {} msec for SEGMENT_ID:{}",
					new Object[] {
							new Integer((prog.getNumDeletes() - preDeletes)),
							new Long(seekState.getSeekTimes()),
							new Long(stopWatch.getTime()),
							new Integer(segmentId) });
		}
	}

	/**
	 * Set deleteFlag=1 , returns true if changed deleteFlag from 0 to 1.
	 * 
	 * @param randFile
	 * @param prog
	 * @param seekState
	 * @param deleteData
	 * @return
	 * @throws IOException
	 */
	private boolean deleteTemplate(RandomAccessFile randFile,
			SegmentFileUpdateProgress prog, SeekState seekState,
			SegmentDiffData deleteData) throws IOException {
		long deletedFlagPos = randFile.getFilePointer();
		int deletedFlag = randFile.readByte();
		if (deletedFlag == 1) {
			return false;
		} else {
			randFile.seek(deletedFlagPos);
			seekState.addSeekTime();
			randFile.writeByte(1);
			prog.decrementRecordCount();
			if (log.isDebugEnabled()) {
				int count = prog.getRecordCount();
				log.debug("Decreased RecordCount from {} to {}", (count + 1),
						count);
			}
			return true;
		}
	}

	private void tryUpdateVersion(SegmentFileUpdateProgress prog,
			SegmentDiffData deleteData) {
		int version = deleteData.getVersion();
		if (prog.getVersion().intValue() < version) {
			log.info("set version from {} to {}", prog.getVersion(),
					new Integer(version));
			updateJobState(version);
			prog.setVersion(new Integer(version));
		}
	}

	private List<SegmentDiffData> fetchDeleteData(
			List<SegmentDiffData> diffDataList) {
		List<SegmentDiffData> list = new ArrayList<SegmentDiffData>();
		for (SegmentDiffData data : diffDataList) {
			if (data.getDiffCommand() == DiffCommand.DELETE) {
				list.add(data);
			}
		}
		return list;
	}

	List<SegmentDiffData> fetchInsertData(List<SegmentDiffData> diffDataList) {
		List<SegmentDiffData> list = new ArrayList<SegmentDiffData>();
		for (SegmentDiffData data : diffDataList) {
			if (data.getDiffCommand() == DiffCommand.INSERT) {
				list.add(data);
			}
		}
		return list;
	}

	/**
	 * Remove templateId TR and TD are executed.
	 * 
	 * @param segmentId
	 * 
	 * @param prog
	 * @param dataList
	 * @return List<SegmentDiffData> sorted by templateId.
	 */
	List<SegmentDiffData> setOffDiffData(int segmentId,
			SegmentFileUpdateProgress prog, List<SegmentDiffData> dataList) {
		List<SegmentDiffData> list = new ArrayList<SegmentDiffData>();
		List<Long> insertedIds = new ArrayList<Long>();
		List<Long> deletedIds = new ArrayList<Long>();
		for (SegmentDiffData diffData : dataList) {
			if (diffData.getDiffCommand() == DiffCommand.INSERT) {
				insertedIds.add(diffData.getTemplateId());
			} else if (diffData.getDiffCommand() == DiffCommand.DELETE) {
				deletedIds.add(new Long(diffData.getTemplateId()));
			}
		}
		for (SegmentDiffData diffData : dataList) {
			Long templateId = new Long(diffData.getTemplateId());
			if (insertedIds.contains(templateId)
					&& deletedIds.contains(templateId)) {
				if (log.isDebugEnabled()) {
					log.debug(
							"Executed insert and delete for same TEMPLATE_ID:{}, cancel these operation",
							templateId);
				}
				int version = diffData.getVersion();
				if (prog.getVersion().intValue() < version) {
					if (log.isDebugEnabled()) {
						log.debug(
								"update {}.seg version from {} to {}",
								new Object[] { new Integer(segmentId),
										prog.getVersion(), new Integer(version) });
					}
					updateJobState(version);
					prog.setVersion(new Integer(version));
				}
			} else {
				list.add(diffData);
			}
		}
		Collections.sort(list);
		return list;
	}

	private void checkHeaderInfo(int segmentId, Integer startingVersion,
			RandomAccessFile randFile) throws IOException {
		// read the current version
		randFile.seek(SIZE_HEADER_VERSION + SIZE_SEGMENT_GROUP
				+ SIZE_MAX_SEGMENT_FILE_LENGTH + SIZE_RECORD_COUNT);
		int fileVersion = (int) randFile.readLong();
		if (fileVersion != startingVersion) {
			throw new SegmentFileWritingException(
					"Segment version in file out of sync with that in memory for segment "
							+ segmentId + ". File version: " + fileVersion
							+ ", memory version: " + startingVersion);
		}
	}

	private int readRecordCount(RandomAccessFile randFile) throws IOException {
		// read the seg group id
		randFile.seek(SIZE_HEADER_VERSION);
		// read the record count
		randFile.seek(SIZE_HEADER_VERSION + SIZE_SEGMENT_GROUP
				+ SIZE_MAX_SEGMENT_FILE_LENGTH);
		int recordCount = randFile.readInt();
		return recordCount;
	}

	private void writeSegmentVersionHeader(RandomAccessFile randFile,
			int segmentId, Integer updatedVersion) throws IOException {
		// write the new segment version
		log.debug("Setting header segment version to " + updatedVersion
				+ " for segment " + segmentId);
		randFile.seek(SIZE_HEADER_VERSION + SIZE_SEGMENT_GROUP
				+ SIZE_MAX_SEGMENT_FILE_LENGTH + SIZE_RECORD_COUNT);
		randFile.writeLong(updatedVersion);
	}

	private void writeRecordCountHeader(RandomAccessFile randFile,
			int segmentId, int recordCount) throws IOException {
		// write the new record count
		log.debug("Setting header record count to " + recordCount
				+ " for segment " + segmentId);

		randFile.seek(SIZE_HEADER_VERSION + SIZE_SEGMENT_GROUP
				+ SIZE_MAX_SEGMENT_FILE_LENGTH);
		randFile.writeInt(recordCount);
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		appContext = applicationContext;
		DataSource dataSource = (DataSource) appContext.getBean("dataSource");
		procedure = new DownloadSegmentDiffsProcedure(dataSource);
	}

	// ///////////////////// PROGRESS related ///////////////////////
	// this is so the update command can keep track of what has been
	// done during execution (to write the correct record count and version
	// in the header at the end, and in debug statements).

	private static class SegmentFileUpdateProgress {
		private AtomicInteger deletes;
		private AtomicInteger fakeDeletes;
		private AtomicInteger inserts;
		private AtomicInteger fakeInserts;
		private AtomicInteger recordCount;
		private Integer version;

		public SegmentFileUpdateProgress(Integer startingVersion,
				int recordCount) {
			deletes = new AtomicInteger(0);
			fakeDeletes = new AtomicInteger(0);
			inserts = new AtomicInteger(0);
			fakeInserts = new AtomicInteger(0);
			this.recordCount = new AtomicInteger(recordCount);
			this.version = startingVersion;
		}

		public void incrementInserts() {
			inserts.incrementAndGet();
		}

		public void incrementFakeInserts() {
			fakeInserts.incrementAndGet();
		}

		public void incrementDeletes() {
			deletes.incrementAndGet();
		}

		public void incrementFakeDeletes() {
			fakeDeletes.incrementAndGet();
		}

		public void setVersion(Integer updatedVersion) {
			this.version = updatedVersion;
		}

		public Integer getVersion() {
			return version;
		}

		public int getRecordCount() {
			return recordCount.get();
		}

		public void incrementRecordCount() {
			recordCount.incrementAndGet();
		}

		public void decrementRecordCount() {
			recordCount.decrementAndGet();
		}

		public int getNumInserts() {
			return inserts.get();
		}

		public int getNumFakeInserts() {
			return fakeInserts.get();
		}

		public int getNumDeletes() {
			return deletes.get();
		}

		public int getNumFakeDeletes() {
			return fakeDeletes.get();
		}

	}

	private static class SeekState {
		private long seekTimes;
		private long currentPosition;
		private long lastPosition = -1L;
		private long lastIndexPosition = -1L;
		private long fileLength;

		SeekState(long fileLength) {
			this.fileLength = fileLength;
		}

		public long getSeekTimes() {
			return seekTimes;
		}

		public void replaceLastWithCurrent() {
			lastPosition = currentPosition;
		}

		public void addCurrentPosition(long length) {
			currentPosition += length;
		}

		public void addSeekTime() {
			seekTimes++;
		}

		public long getCurrentPosition() {
			return currentPosition;
		}

		public boolean canSeek() {
			return currentPosition < fileLength;
		}

		public void updateCurrentPosition(long indexedPosition) {
			if (indexedPosition == lastIndexPosition) {
				if (0L < lastPosition && lastPosition < fileLength) {
					currentPosition = lastPosition;
				} else {
					currentPosition = indexedPosition;
				}
			} else {
				lastIndexPosition = indexedPosition;
				currentPosition = indexedPosition;
			}
		}

	}

}