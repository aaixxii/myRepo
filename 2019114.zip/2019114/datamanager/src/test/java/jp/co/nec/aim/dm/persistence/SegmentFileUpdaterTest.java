package jp.co.nec.aim.dm.persistence;

import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_CHECK_SUM;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_HEADER_VERSION;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_MAX_SEGMENT_FILE_LENGTH;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_SEGMENT_FILE_HEADER;
import static jp.co.nec.aim.dm.persistence.HeaderInfo.SIZE_SEGMENT_GROUP;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;

import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.manager.IndexManager;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;
import jp.co.nec.aim.dm.util.SegmentUtil;
import jp.co.nec.aim.helper.SegmentFileConstants;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Test class for SegmentFileUpdater
 * 
 * @author kurosu
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class SegmentFileUpdaterTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	private static Logger log = LoggerFactory.getLogger(SegmentFileUpdaterTest.class);

	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private SegmentFileUpdater segmentFileUpdater;
	@Resource
	private SegmentFileCreator segmentFileCreator;

	@Before
	public void before() {
		jdbcTemplate.execute("delete from person_biometrics");
		jdbcTemplate.execute("delete from segments");
		SegmentUtil.createDir();
		deleteSerializedFile();
	}

	private void deleteSerializedFile() {
		URL url = this.getClass().getResource(
				"SegmentFileUpdaterTest-context.xml");
		String path = url.getPath();
		int index = path.lastIndexOf("/");
		String dir = path.substring(0, index - 1);
		// Set jboss tmp to path of this class, under target
		System.setProperty("jboss.server.temp.dir", dir);
	}

	@After
	public void after() {
		SegmentUtil.cleanSegmentFile();
		deleteSerializedFile();
	}

	@Test
	public void testExecute() throws IOException {
		// 1 segment has 1000 records, current records = 200.
		int segmentId = 1;
		int currentVersion = 1;
		int templateSize = 100;
		int records = 200;
		SegmentUtil.insertSegmentRecords(records, 1000, templateSize,
				jdbcTemplate);

		segmentFileCreator.execute(segmentId, new Integer(currentVersion));
		currentVersion = records - 1;
		checkSegmetFile(segmentId, currentVersion, templateSize, records);
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		records++;
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		records++;
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		records++;
		long t1 = System.currentTimeMillis();
		segmentFileUpdater.execute(segmentId, new Integer(currentVersion));
		long t2 = System.currentTimeMillis();
		log.info("It took " + (t2 - t1) + "msec to update Segment File");
		currentVersion += 3;
		checkSegmetFile(segmentId, currentVersion, templateSize, records);
	}

	@Test
	public void testExecuteTemplateSize40kRecords100() throws IOException {
		// 1 segment has 1000 records, current records = 200.
		int segmentId = 1;
		int currentVersion = 1;
		int templateSize = 40000;
		int records = 100;
		SegmentUtil.insertSegmentRecords(records, 1000, templateSize,
				jdbcTemplate);

		segmentFileCreator.execute(segmentId, new Integer(currentVersion));
		currentVersion = records - 1;
		checkSegmetFile(segmentId, currentVersion, templateSize, records);
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		records++;
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		records++;
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		records++;
		long t1 = System.currentTimeMillis();
		segmentFileUpdater.execute(segmentId, new Integer(currentVersion));
		long t2 = System.currentTimeMillis();
		log.info("It took " + (t2 - t1) + "msec to update Segment File");
		currentVersion += 3;
		checkSegmetFile(segmentId, currentVersion, templateSize, records);
	}

	@Test
	public void testBulkInsertAndDelete() throws IOException {
		URL url = this.getClass().getResource("insert-1template.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		int segmentId = 1;
		segmentFileCreator.execute(segmentId, new Integer(0));

		url = this.getClass().getResource("add-3templates.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		segmentFileUpdater.execute(segmentId, new Integer(0));
		// expectedVersion=3, templateSize = 2bytes, records=4;
		checkSegmetFile(segmentId, 3, 2, 4);

		url = this.getClass().getResource("delete-alltemplates.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		segmentFileUpdater.execute(segmentId, new Integer(3));
		checkEmptySegmetFile(segmentId, 7, 2, 4);
	}
	
	/**
	 * Test Case for Redmine #1499
	 * @throws IOException 
	 */
	@Test
	@Ignore
	public void testDeleteIndexAndBulkInsert() throws IOException {
		URL url = this.getClass().getResource("321.seg");
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		FileUtils.copyFile(new File(url.getPath()), new File(dir +"/" + "321.seg"));
		int segmentId=321;
		jdbcTemplate.update("INSERT INTO SEGMENTS "
				 + "(SEGMENT_ID, container_id, BIO_ID_START, BIO_ID_END, BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED)"
				+ "VALUES(321, 1, 1, 365199, 42, 1, 0, 1, 100)");
		int startVersion = 265199;
		insertPersonBio(startVersion, 100);
		insertSegmentChangeLog(segmentId, startVersion, 100);
		segmentFileUpdater.execute(segmentId, new Integer(startVersion));	
	}

	
	private void checkEmptySegmetFile(int segmentId, int expectVersion,
			int templateSize, int records) throws IOException {
		SegmentFileName segFileName = new SegmentFileName(segmentId);
		File segFile = new File(segFileName.getName());
		assertTrue(segFile.exists());
		byte[] contents = FileUtils.readFileToByteArray(segFile);
		ByteBuffer bb = ByteBuffer.wrap(contents);
		assertEquals(SegmentFileCreator.AIM_VERSION, bb.getInt());
		assertEquals((short) 1, bb.getShort()); // EMBEDDED_ID
		assertEquals(20000000L, bb.getLong()); // MAX_SEGMENT_SIZE
		assertEquals(0, bb.getInt()); // RECORD_COUNT
		assertEquals((long) expectVersion, bb.getLong()); // VERSION
		assertEquals(SegmentFileConstants.SEGMENT_HEADER_SIZE + records
				* (templateSize + SegmentFileConstants.SIZE_TEMPLATE_HEADER_CHECKSUM),
				contents.length);
	}

	private void checkSegmetFile(int segmentId, int expectVersion,
			int templateSize, int records) throws IOException {
		SegmentFileName segFileName = new SegmentFileName(segmentId);
		File segFile = new File(segFileName.getName());
		assertTrue(segFile.exists());
		byte[] contents = FileUtils.readFileToByteArray(segFile);
		ByteBuffer bb = ByteBuffer.wrap(contents);
		assertEquals(SegmentFileCreator.AIM_VERSION, bb.getInt());
		assertEquals((short) 1, bb.getShort()); // EMBEDDED_ID
		assertEquals(20000000L, bb.getLong()); // MAX_SEGMENT_SIZE
		assertEquals(records, bb.getInt()); // RECORD_COUNT
		assertEquals((long) expectVersion, bb.getLong()); // VERSION
		assertEquals(SegmentFileConstants.SEGMENT_HEADER_SIZE + records
				* (templateSize + SegmentFileConstants.SIZE_TEMPLATE_HEADER_CHECKSUM),
				contents.length);
	}

	@Test
	public void testBulkDeleteWithIndex() throws IOException {
		int records = 1000;
		int toDelete = 100;
		int segmentId = 1;
		insertPersonBio(records);
		jdbcTemplate
				.update("INSERT INTO SEGMENTS (SEGMENT_ID, container_id, BIO_ID_START, BIO_ID_END, "
						+ "BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED) "
						+ "VALUES(1, 1, 1, ?, 16026, ?, ?, 1, 100)",
						new Integer(records), new Integer(records),
						new Integer(records - 1));
		insertSegmentChangeLog(records);
		
		// SegmentFileCreator initialize IndexManager.
		segmentFileCreator.execute(segmentId, new Integer(0));
		IndexManager manager = IndexManager.getInstance();
		manager.putIndexMap(segmentId);
		// Each template is 2byte, 16 bits. Index exists every 50 templates
		assertEquals(27L,  manager.getPosition(segmentId, 1L));
		assertEquals(27L,  manager.getPosition(segmentId, 2L));
		assertEquals(2547L,  manager.getPosition(segmentId, 50));
		assertEquals(2827L,  manager.getPosition(segmentId, 51L));

		assertEquals(5347L,  manager.getPosition(segmentId, 100L));
		assertEquals(5627L,  manager.getPosition(segmentId, 101L));

		assertEquals(53227L,  manager.getPosition(segmentId, 951L));
		assertEquals(55747L,  manager.getPosition(segmentId, 1000L));
		assertEquals(55747L,  manager.getPosition(segmentId, 1001L));


		List<Long> deletedIds = deleteTemplate(toDelete, records);
		segmentFileUpdater.execute(segmentId, new Integer(records - 1));

		SegmentFileName segFileName = new SegmentFileName(segmentId);
		RandomAccessFile randFile = null;
		try {
			randFile = new RandomAccessFile(segFileName.getName(), "rw");
			randFile.seek(SIZE_HEADER_VERSION + SIZE_SEGMENT_GROUP
					+ SIZE_MAX_SEGMENT_FILE_LENGTH);
			int recordCount = randFile.readInt();
			assertEquals(records-toDelete, recordCount);

			long seekPos = SIZE_SEGMENT_FILE_HEADER + SIZE_CHECK_SUM;
			int deletedNum = 0;
			for (int i = 0; i < records; i++) {
				randFile.seek(seekPos);
				int templateSize = randFile.readInt();
				Long templateId = new Long(randFile.readLong());
				// subtract sum of bytes of int, 4 , and bytes of long, 8
				int deleted = randFile.readByte();
				if (deleted == 1) {
					assertTrue("templateId = " + templateId + " is not dleted!", deletedIds.contains(templateId));
					deletedNum++;
				}
				seekPos += templateSize;
				seekPos += SIZE_CHECK_SUM;
			}
			assertEquals(toDelete, deletedNum);
		} finally {
			randFile.close();
		}
	}

	private List<Long> deleteTemplate(int totalDelete, int records) {
		String sql = "INSERT INTO SEGMENT_CHANGE_LOG (SEGMENT_CHANGE_ID, SEGMENT_ID, SEGMENT_VERSION, "
				+ "BIOMETRICS_ID, CHANGE_TYPE) VALUES(?, 1, ?, ?, 1)";
		List<Long> deletedIds = new ArrayList<Long>();
		Random random = new Random(1L);
		int id = records + 1;
		for (int i = 0; i < totalDelete; i++) {
			Long templateId = null;
			while (deletedIds.contains(templateId = new Long(random
					.nextInt(records) + 1))) {
			}
			jdbcTemplate.update(sql, new Integer(id), new Integer(id - 1),
					templateId);
			deletedIds.add(templateId);
			id++;
		}
		return deletedIds;
	}

	private void insertSegmentChangeLog(int records) {
		insertSegmentChangeLog(1, 1, records);
	}

	private void insertSegmentChangeLog(int segmentId, int startId, int records) {
		String sql = "INSERT INTO SEGMENT_CHANGE_LOG (SEGMENT_CHANGE_ID, SEGMENT_ID, SEGMENT_VERSION, "
				+ "BIOMETRICS_ID, CHANGE_TYPE) VALUES(?, ?, ?, ?, 0)";
		for (int id = startId; id < startId + records; id++) {
			jdbcTemplate.update(sql, new Integer(id), new Integer(segmentId), new Integer(id - 1),
					new Integer(id));
		}		
	}

	private void insertPersonBio(int records) {
		insertPersonBio(1, records);
	}

	private void insertPersonBio(int startId, int records) {
		String sql = "INSERT INTO PERSON_BIOMETRICS"
				+ "(BIOMETRICS_ID, EXTERNAL_ID, EVENT_ID, container_id, CORRUPTED_FLAG, BIOMETRIC_DATA, BIOMETRIC_DATA_LEN, registed_ts) "
				+ "VALUES (?, ?, 1, 1, 0, TO_BLOB('1111'), 4, 123)";
		for (int id = startId; id < startId + records; id++) {
			jdbcTemplate.update(sql, new Integer(id),
					"external-" + String.format("%04d", id));
		}
		
	}

}
