package jp.co.nec.aim.dm.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.List;

import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;
import jp.co.nec.aim.dm.util.SegFileUtil;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class IndexFileTest {

	@BeforeClass
	public static void before() {
		SegFileUtil.removeIndexAndSegment();
	}

	@AfterClass
	public static void after() {
		SegFileUtil.removeIndexAndSegment();
	}

	@Test
	public void testListIndexFile() throws IOException {
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);

		for (int id = 1; id <= 5; id++) {
			File file = new File(dir + File.separator + "." + id + ".index");
			FileUtils.writeStringToFile(file, "hoge");
		}
		for (int id = 1; id <= 5; id++) {
			File file = new File(dir + File.separator + "." + id + ".sum");
			FileUtils.writeStringToFile(file, "hoge");
		}
		for (int id = 1; id <= 5; id++) {
			File file = new File(dir + File.separator + id + ".seg");
			FileUtils.writeStringToFile(file, "hoge");
		}

		List<IndexFile> files = IndexFile.listIndexFile();
		assertEquals(5, files.size());
		for (IndexFile file : files) {
			String name = file.getName();
			assertTrue(0 < name.lastIndexOf(".index"));
		}
	}

}
