package jp.co.nec.aim.dm.procedure;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.annotation.Resource;

import jp.co.nec.aim.dm.constants.DiffCommand;
import jp.co.nec.aim.dm.util.SegmentUtil;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Test Class for DownloadSegmentDiffsProcedure
 * 
 * @author kurosu
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class DownloadSegmentDiffsProcedureTest {
	@Resource
	private DownloadSegmentDiffsProcedure procedure;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void before() {
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from person_biometrics");
	}

	@Test
	public void testExecute_Success() {
		// 1 segment has 1000 records, current records = 200.
		long segmentId = 1L;
		long currentVersion = 1L;
		int templateSize = 100;
		SegmentUtil.insertSegmentRecords(200, 1000, templateSize, jdbcTemplate);
		// version=199
		List<SegmentDiffData> diffDataList = procedure.execute(segmentId,
				currentVersion);
		assertEquals(198, diffDataList.size());
		diffDataList = procedure.execute((segmentId + 1L), currentVersion);
		assertEquals(0, diffDataList.size());

		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		// version=200
		diffDataList = procedure.execute(segmentId, currentVersion);
		assertEquals(199, diffDataList.size());
		SegmentDiffData diffData = diffDataList.get(0);
		assertEquals(currentVersion + 1, (long) diffData.getVersion());
		assertEquals(DiffCommand.INSERT, diffData.getDiffCommand());
		assertEquals(templateSize, diffData.getTemplate().length);

		currentVersion = 201;
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		SegmentUtil.addTemplate(segmentId, templateSize, jdbcTemplate);
		// version=203
		diffDataList = procedure.execute(segmentId, currentVersion);
		assertEquals(2, diffDataList.size());
		for (int index = 0; index < diffDataList.size(); index++) {
			SegmentDiffData segDiffData = diffDataList.get(index);
			assertEquals(currentVersion + index + 1,
					(long) segDiffData.getVersion());
			assertEquals(DiffCommand.INSERT, segDiffData.getDiffCommand());
			assertEquals(templateSize, segDiffData.getTemplate().length);
		}
	}

	@Test
	public void testExecute_IllegalArgument() {
		// 1 segment has 1000 records, current records = 200.
		long currentVersion = 1L;
		int templateSize = 100;
		SegmentUtil.insertSegmentRecords(200, 1000, templateSize, jdbcTemplate);

		List<SegmentDiffData> diffDataList = procedure.execute(0L,
				currentVersion);
		assertEquals(0, diffDataList.size());
		diffDataList = procedure.execute(1L, -1L);
		assertEquals(0, diffDataList.size());
	}

}
