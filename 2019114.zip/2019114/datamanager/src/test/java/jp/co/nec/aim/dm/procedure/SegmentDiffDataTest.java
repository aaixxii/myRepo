package jp.co.nec.aim.dm.procedure;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;


public class SegmentDiffDataTest {
	
	@Test
	public void testSort() {
		List<SegmentDiffData> dataList = new ArrayList<SegmentDiffData>();
		SegmentDiffData data1 = new SegmentDiffData();
		data1.setTemplateId(5);
		data1.setVersion(1);
		dataList.add(data1);
		
		SegmentDiffData data2 = new SegmentDiffData();
		data2.setTemplateId(7);
		data2.setVersion(4);
		dataList.add(data2);

		SegmentDiffData data3 = new SegmentDiffData();
		data3.setTemplateId(7);
		data3.setVersion(1);
		dataList.add(data3);
		
		SegmentDiffData data4 = new SegmentDiffData();
		data4.setTemplateId(3);
		data4.setVersion(10);
		dataList.add(data4);
		
		Collections.sort(dataList);
		assertEquals(data4, dataList.get(0));
		assertEquals(data1, dataList.get(1));
		assertEquals(data3, dataList.get(2));
		assertEquals(data2, dataList.get(3));
	}

}
