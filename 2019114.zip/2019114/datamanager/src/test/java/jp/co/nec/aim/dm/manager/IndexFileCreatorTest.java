package jp.co.nec.aim.dm.manager;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Collection;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.junit.Ignore;
import org.junit.Test;

public class IndexFileCreatorTest {

	@Test
	public void testPrintUsage() {
		String[] args = new String[] { "-h" };
		IndexFileCreator.main(args);
	}

	@Ignore
	@Test
	public void testCrateIndex() throws IOException {
		URL url = this.getClass().getResource("IndexManagerTest-context.xml");
		String path = url.getPath();
		int index = path.lastIndexOf("/");
		String dir = path.substring(0, index);
		File directory = new File(dir);

		RegexFileFilter segFilter = new RegexFileFilter("[0-9]*.seg");
		Collection<File> segFiles = FileUtils.listFiles(directory, segFilter,
				null);
		for (File file : segFiles) {
			String[] args = new String[] { "-f", file.getPath() };
			IndexFileCreator.main(args);
		}

		RegexFileFilter filter = new RegexFileFilter("\\..*\\.index");
		Collection<File> files = FileUtils.listFiles(directory, filter, null);
		assertEquals(2, files.size());
		for (File indexFile : files) {
			List<String> lines = FileUtils.readLines(indexFile);
			assertEquals(4, lines.size());
			assertEquals("\"1\",\"27\"", lines.get(0));
			assertEquals("\"19\",\"315\"", lines.get(1));
			assertEquals("\"37\",\"603\"", lines.get(2));
			assertEquals("\"55\",\"891\"", lines.get(3));
		}
	}
}
