package jp.co.nec.aim.mm.extract.planner;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.NamingException;

import jp.co.nec.aim.mm.jms.JndiObjectLookuper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JmsTester {
	private static Logger logger = LoggerFactory.getLogger(JmsTester.class);
	private Connection connection;
	private Destination idnetfyPlanCreatedQueue;

	public JmsTester() throws JMSException, NamingException {
		connection = JndiObjectLookuper.getInstance().lookupDefaultConnection();
		idnetfyPlanCreatedQueue = JndiObjectLookuper.getInstance()
				.lookupIdentifyDispatcherPlannerQueue();
	}

	public static void main(String[] args) throws Exception {
		JmsTester tester = new JmsTester();
		tester.sendTxtMessage("abceeff");
	}

	/**
	 * 
	 * @param plans
	 * @return
	 */
	public boolean sendTxtMessage(String plans) {
		logger.info("IdentifyPlanCreatedNotifor is running...");
		Session session = null;
		MessageProducer producer = null;
		try {
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			producer = session.createProducer(idnetfyPlanCreatedQueue);
			connection.start();
			TextMessage txtMessage = session.createTextMessage(plans);
			producer.send(txtMessage);
			logger.info(
					"IdentifyPlanCreatedNotifor success send message to queue({})",
					idnetfyPlanCreatedQueue.toString());
		} catch (Exception e) {
			logger.error(
					"JMSException occurred while send jms to IdentifyDispatchQueue",
					e);
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @param compressedJms
	 * @return
	 */
	public boolean sendCompressedByte(byte[] compressedJms) {
		logger.info("IdentifyPlanCreatedNotifor is runing...");
		Session session = null;
		MessageProducer producer = null;
		try {
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			producer = session.createProducer(idnetfyPlanCreatedQueue);
			connection.start();
			BytesMessage byteMessage = session.createBytesMessage();
			byteMessage.readBytes(compressedJms);
			producer.send(byteMessage);
			logger.info(
					"IdentifyPlanCreatedNotifor success send message to queue({})",
					idnetfyPlanCreatedQueue.toString());
		} catch (Exception e) {
			logger.error(
					"JMSException occurred while send jms to IdentifyDispatchQueue",
					e);

			return false;
		}
		return true;
	}
}
