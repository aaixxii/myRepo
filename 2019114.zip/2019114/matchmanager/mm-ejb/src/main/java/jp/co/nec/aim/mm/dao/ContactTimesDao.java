package jp.co.nec.aim.mm.dao;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.procedure.UpdateContactTimesProcedure;

import org.springframework.dao.DataAccessException;

/**
 * ContactTimesDao
 * 
 * @author liuyq
 * 
 */
public class ContactTimesDao {
	private DataSource dataSource; // DataSource instance

	/**
	 * ContactTimesDao constructor
	 * 
	 * @param dataSource
	 */
	public ContactTimesDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * update Contact time with unit id and type
	 * 
	 * @param unitId
	 *            unit id
	 * @param unitType
	 *            unit type c_component_type_mu CONSTANT NUMBER := 3;
	 *            c_component_type_mr CONSTANT NUMBER := 2; c_component_type_dm
	 *            CONSTANT NUMBER := 1;
	 */
	public void updateContact(long unitId, int unitType) {
		try {
			UpdateContactTimesProcedure procedure = new UpdateContactTimesProcedure(
					dataSource);
			procedure.setUnitId(unitId);
			procedure.setUnitType(unitType);
			procedure.execute();
		} catch (DataAccessException e) {
			throw new AimRuntimeException(e);
		}
	}

}
