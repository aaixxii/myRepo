package jp.co.nec.aim.mm.jms;

public enum NotifierEnum {
	Aggregator("Aggregator"), //
	FEJobCompleteBean("ExtractJobCompleteBean"), //
	InquiryJobCompleteBean("InquiryJobCompleteBean"), //
	InquiryJobHandler("InquiryJobHandler"), //
	PollBean("PollBean"), //
	StatusManagerBean("StatusManagerBean"), //
	Inquiry("Inquiry"), //
	Registration("Registration"), //
	ExtractService("ExtractService"), //
	;

	private String notifierName;

	private NotifierEnum(String notifierName) {
		this.notifierName = notifierName;
	}

	public String getNotifierName() {
		return notifierName;
	}
}
