package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MU_CONTACTS database table.
 * 
 */
@Entity
@Table(name = "MU_CONTACTS")
@NamedQuery(name = "MuContactEntity.findAll", query = "SELECT m FROM MuContactEntity m")
public class MuContactEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MU_CONTACTS_MUID_GENERATOR", sequenceName = "MU_CONTACTS", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MU_CONTACTS_MUID_GENERATOR")
	@Column(name = "MU_ID")
	private long muId;

	@Column(name = "CONTACT_TS")
	private long contactTs;

	public MuContactEntity() {
	}

	public long getMuId() {
		return this.muId;
	}

	public void setMuId(long muId) {
		this.muId = muId;
	}

	public long getContactTs() {
		return this.contactTs;
	}

	public void setContactTs(long contactTs) {
		this.contactTs = contactTs;
	}

}