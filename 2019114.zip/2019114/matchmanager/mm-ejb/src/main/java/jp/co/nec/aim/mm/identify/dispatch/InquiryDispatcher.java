package jp.co.nec.aim.mm.identify.dispatch;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.mm.aggregator.Aggregator;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.CommitDao;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.MapReducersDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.FusionJobEntity;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ProtobufException;
import jp.co.nec.aim.mm.identify.planner.MuJobExecutePlan;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.notifier.DistributorNotifier;
import jp.co.nec.aim.mm.procedure.InquiryDistributorProcedure;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.InquiryJobHandler;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.StopWatch;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

/**
 * Inquiry job Dispatcher <br>
 * 1. Receive event from the planner <br>
 * 2. Find the next MR position <br>
 * 3. Look for the Inquiry information <br>
 * 4. Post to MR with PBMapInquiryJobRequest <br>
 * 
 * @author liuyq
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class InquiryDispatcher {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(InquiryDispatcher.class);

	/** mapreducer/MapInquiryJob **/
	private static final String DISPATCH_MR_URL = "mapreducer/MapInquiryJob";
	
	private static final String COMMA = ", ";	
	

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	@EJB
	private Aggregator aggregator;

	private InquiryJobRequestBuilder requestBuilder;
	private MapReducersDao mapReducersDao;
	private InquiryJobHandler jobHandler;
	private InquiryJobDao inquiryJobDao;
	private DateDao dateDao;
	private UnitDao unitDao;
	private SystemConfigDao configDao;
	private CommitDao commitDao;
	
	private ExceptionSender exceptionSender;

	@PostConstruct
	public void init() {
		this.dateDao = new DateDao(dataSource);
		this.unitDao = new UnitDao(manager);
		this.requestBuilder = new InquiryJobRequestBuilder(unitDao);
		this.mapReducersDao = new MapReducersDao(dataSource, manager);
		this.jobHandler = new InquiryJobHandler(manager, dataSource, aggregator);
		this.inquiryJobDao = new InquiryJobDao(manager, dataSource);
		this.configDao = new SystemConfigDao(manager);
		this.commitDao = new CommitDao(dataSource);
		this.exceptionSender = new ExceptionSender();
	}

	/**
	 * InquiryDistributor constructor
	 */
	public InquiryDispatcher() {
	}

	/**
	 * dispatch the inquiry job to MR
	 * 
	 * @param plan
	 *            ExecutePlanEntity instance
	 */
	public void dispatch(final Map<Long, MuJobExecutePlan> plans) {
		if (CollectionsUtil.isEmpty(plans)) {
			throw new IllegalArgumentException(
					"Plans is empty while do inquiry dispatch operation.");
		}

		// loop each plan and do dispatch operation
		// if error occurred in one of the plan process
		// throw the exception and skip do next plan
		Collection<MuJobExecutePlan> mjes = plans.values();
		for (final MuJobExecutePlan plan : mjes) {
			checkPlan(plan);
			log.info("Prepare PBMapInquiryJobRequest and "
					+ "distribute to MR with plan id {}.", plan.getPlanId());
			if (!findAndNotifyMR(plan)) {
				// could not found the MR, break directly..
				break;
			}
		}
	}

	/**
	 * check plan
	 * 
	 * @param MuJobExecutePlan
	 *            plan
	 */
	private void checkPlan(MuJobExecutePlan plan) {
		final Long planId = plan.getPlanId();

		if (planId == null || planId <= 0) {
			throw new IllegalArgumentException(
					"Plan id is not correct while do inquiry dispatch operation.");
		}

		final Long jobId = plan.getJobId();
		if (jobId == null || jobId <= 0) {
			throw new IllegalArgumentException(
					"Job id is not correct while do inquiry dispatch operation.");
		}
		final Integer functionId = plan.getFunctionId();
		if (functionId == null || functionId <= 0) {
			throw new IllegalArgumentException(
					"Function id is not correct while do inquiry dispatch operation.");
		}

		final Integer containerId = plan.getContainerId();
		if (containerId == null || containerId <= 0) {
			throw new IllegalArgumentException(
					"Container id is not correct while do inquiry dispatch operation.");
		}
	}

	/**
	 * find And Notify MR
	 * 
	 * @param planId
	 *            plan id from the inquiry planner
	 * @return next MR position could be found or not
	 */
	private boolean findAndNotifyMR(MuJobExecutePlan plan) {
		MapReducerEntity nextMR = null;
		InqDispatchInfo info = null;
		PBMapInquiryJobRequest.Builder request = null;
		int exeCount = 0;

		StopWatch sw = new StopWatch();
		sw.start();

		// before loop find MR, get the number working MR as
		// max retry count.
		int retryCount = unitDao.getWorkingMRCount();
		if (retryCount <= 0) {
			log.warn("Working MR is not exist when dispatch inquiry job..");
		}
		try {
			while (nextMR == null) {
				log.info("Ready to fetch the next MR, Executed {} times.",
						++exeCount);

				// if exeCount is over max retry
				if (exeCount > retryCount) {
					log.error("Could not fetch the next MR due to "
							+ "there are no Working MR...");
					nextMR = null;
					break;
				}

				// call MRFetcher Procedure and find next MR
				// if Multiple thread reached,
				// we will lock table [LAST_ASSIGNED_MR] to
				// avoid fetch the same MR position
				nextMR = mapReducersDao.getNextMapReducer();

				// nextMR is null means can not found next MR position
				// we will fail the container job, so break this loop
				if (nextMR == null) {
					log.error("Could not find next MR position,"
							+ " Ready to fail the Conatiner job..");
					break;
				}

				// nextMR contact URL is blank
				// continue to find next MR position..
				// maybe next MR is alive
				String contactUrl = nextMR.getContactUrl();
				if (StringUtils.isBlank(contactUrl)) {
					log.error("nextMR contact URL is blank, "
							+ "continue to find next MR position..");
					nextMR = null;
					continue;
				} else {
					if (contactUrl.endsWith("/")) {
						contactUrl += DISPATCH_MR_URL;
					} else {
						contactUrl += "/" + DISPATCH_MR_URL;
					}
				}

				// get the instance of InqDispatchInfo
				info = getJobinfo(plan, info);

				// request only build once is enough
				if (request == null) {
					request = requestBuilder.createRequest(info, plan);
				}

				// notify the MR with specified URL and body
				// 1. lock the container job row with id (transaction 1)
				// 2. job complete wait for 1 (transaction 2)
				// 3. update the container job set the AssignedTs and MR id
				// (transaction 1)
				// 4. commit (transaction 1)
				// 5. job complete do completion operation (transaction 2)
				long cJobId = inquiryJobDao.lockContainerJob(info
						.getContainerJobId());
				log.info("Container job id {} was locked for update.", cJobId);
				boolean isSuccess = notifyMR(contactUrl, request);
				if (isSuccess) {
					log.info(
							"Notify MR({}) with URL({}) JobId({}) ContainerJobId({}) PlanId({}) successfully..",
							nextMR.getMrId(), contactUrl, plan.getJobId(),
							cJobId, plan.getPlanId());

					// update MR id and ASSIGNED_TS(current epoch time)
					inquiryJobDao.updateContainerJob((int) nextMR.getMrId(),
							info.getContainerJobId());
					// commit and unlock the container job row
					// let the inquiry job complete the result
					commitDao.commit();
					// Notify the MR successfully, break Notify..
					break;
				} else {
					log.warn("Notify MR({}) with URL({}) failed, "
							+ "find next MR position..", nextMR.getMrId(),
							contactUrl);
					// offLine the current MR that was not alive
					mapReducersDao.updateMRState(nextMR.getMrId(),
							UnitState.TIMED_OUT);

					// rollBack container jobs with MR id
					rollbackInqJobs(nextMR.getMrId());

					commitDao.commit();

					// reFind the next MR position
					nextMR = null;
				}
			}

			// NextMR is null due to the system without any map reducer
			// we will fail the inquiry container job and
			if (nextMR == null) {
				final AimError aimError = AimError.DISPATCHER_MR_NOT_FOUND;
				info = getJobinfo(plan, info);
				final long containerJobId = info.getContainerJobId();
				final String failTime = dateDao.getReasonTime();
				log.warn(aimError.getMessage());
				PBBusinessMessage pbMessage = getPBBusinessMessage(containerJobId);
				jobHandler.failInquiryJob(containerJobId,aimError.getErrorCode(), aimError.getMessage(),pbMessage, failTime);
						
						
				return false;
			}
		} catch (Exception ex) {
			log.error("Exception occurred when findAndNotifyMR,"
					+ " rollback the job..", ex);

			final AimError aimError = AimError.DISPATCHER_EXCEPTION;
			final String failTime = dateDao.getReasonTime();
			if (info == null) {
				info = getInquiryJobInfo(plan);
				if (info == null) {
					log.info(
							"Could not fetch the container job id with "
									+ "plan id: {}, job id: {} function id: {},"
									+ " container id: {}, fail "
									+ "or rollback with job id.",
							new Object[] { plan.getPlanId(), plan.getJobId(),
									plan.getFunctionId(), plan.getContainerId() });

					List<ContainerJobEntity> containerJobs = inquiryJobDao
							.getAllContainerJob(plan.getJobId());
					for (ContainerJobEntity containerJob : containerJobs) {
						PBBusinessMessage pbMessage = getPBBusinessMessage(containerJob.getContainerJobId());
						jobHandler.failInquiryJob(containerJob
								.getContainerJobId(), aimError.getErrorCode(),
								String.format(aimError.getMessage(), ex
										.getClass().getSimpleName(), ex
										.getMessage()), pbMessage, failTime);
					}
					return false;
				}
			}

			String errorMessage = String.format(aimError.getMessage(), ex
					.getClass().getSimpleName(), ex.getMessage());
			final long containerJobId = info.getContainerJobId();
			PBBusinessMessage pbMessage = getPBBusinessMessage(containerJobId);
			jobHandler.failInquiryJob(containerJobId, aimError.getErrorCode(),
					errorMessage, pbMessage, failTime);

			// send the inquiry error event to error queue
			exceptionSender.sendAimException(aimError.getErrorCode(),
					errorMessage, containerJobId, plan.getJobId(),
					(nextMR == null) ? -1 : nextMR.getMrId(), ex);

			return false;
		} finally {
			sw.stop();
			PerformanceLogger.log(getClass().getSimpleName(),
					"findAndNotifyMR", sw.elapsedTime());
		}

		return true;
	}

	/**
	 * getJobinfo, if could not fetch from DB, throw the exception
	 * 
	 * @param plan
	 *            the instance of MuJobExecutePlan
	 * @param info
	 *            the instance of InqDispatchInfo
	 * @return the instance of InqDispatchInfo
	 */
	private InqDispatchInfo getJobinfo(MuJobExecutePlan plan,
			InqDispatchInfo info) {
		if (info == null) {
			info = getInquiryJobInfo(plan);
			if (info == null) {
				throw new AimRuntimeException("Could not found the inquiry "
						+ "information with plan id:" + plan.getPlanId());
			}
		}
		return info;
	}

	/**
	 * Get necessary inquiry job information
	 * 
	 * @param planId
	 *            plan id
	 * @return InqDistributorInfo instance
	 */
	private InqDispatchInfo getInquiryJobInfo(MuJobExecutePlan plan) {
		final InquiryDistributorProcedure procedure = new InquiryDistributorProcedure(
				dataSource);
		procedure.setPlanId(plan.getPlanId());
		procedure.setFunctionId(plan.getFunctionId());
		procedure.setJobId(plan.getJobId());
		return procedure.execute();
	}

	/**
	 * notifyMR
	 * 
	 * @param url
	 * @param request
	 */
	private boolean notifyMR(final String url,
			final PBMapInquiryJobRequest.Builder request) {
		final int retryCount = configDao
				.getMMPropertyInt(MMConfigProperty.MR_POST_COUNT);
		final DistributorNotifier notifier = new DistributorNotifier(url,
				request.build().toByteArray(), retryCount);
		return notifier.notifyMR();
	}

	/**
	 * Roll back the inquiry job with specified MR id
	 * 
	 * @param mrId
	 *            MR id
	 */
	public void rollbackInqJobs(long mrId) {
		List<ContainerJobEntity> deadJobs = inquiryJobDao.listDeadJobs(mrId);
		if (CollectionsUtil.isEmpty(deadJobs)) {
			if (log.isDebugEnabled()) {
				log.debug("mr id: {} could not found any container jobs.", mrId);
			}
			return;
		}		
		log.warn("{}", makeDeadJobInfo(mrId, deadJobs));
		// loop each dead inquiry jobs
		for (final ContainerJobEntity job : deadJobs) {
			long containerJobId = job.getContainerJobId();
			try {
				final AimError aimError = AimError.DISPATCHER_MR_RESPONSE;
				PBBusinessMessage pbMessage = getPBBusinessMessage(containerJobId);
				jobHandler.failInquiryJob(containerJobId,
						aimError.getErrorCode(),
						String.format(aimError.getMessage(), mrId),pbMessage,dateDao.getReasonTime());						
			} catch (Exception e) {
				final AimError aimError = AimError.INQ_JOB_RETRY;
				String message = String.format(aimError.getMessage(),
						containerJobId, mrId);
				log.error(message, e);
				exceptionSender.sendAimException(aimError.getErrorCode(),
						message, containerJobId, containerJobId, mrId, e);
			}
		}
	}
	
	private String makeDeadJobInfo(long mrId,
			List<ContainerJobEntity> deadJobList) {
		StringBuilder sb = new StringBuilder();
		String firstWarnInfo = "Failed to notify containerJob to MR(ID="
				+ String.valueOf(mrId)
				+ "). Process job as failed or retrying : ";
		sb.append(firstWarnInfo);		
		for (ContainerJobEntity job : deadJobList) {
			sb.append("[");	
			sb.append("FUSION_JOB_ID=");
			sb.append(job.getFusionJobId());
			sb.append(COMMA);
			sb.append("CONTAINER_JOB_ID=");
			sb.append(job.getContainerJobId());
			sb.append(COMMA);
			sb.append("PLAN_ID=");
			sb.append(job.getPlanId());
			sb.append("]");
			sb.append(COMMA);
		}			
		sb.delete(sb.length() -2 , sb.length() -1);	
		return sb.toString();
	}
	
	public PBBusinessMessage getPBBusinessMessage(long containerJobId)  {
		ContainerJobEntity cntJob = inquiryJobDao.getContainerJob(containerJobId);
		long funsionJobId = cntJob.getFusionJobId();
		List<FusionJobEntity> listFusionJob = inquiryJobDao.getFusionJob(funsionJobId, 1);
		FusionJobEntity fusionEntity = listFusionJob.get(0);
		byte[] data = fusionEntity.getInquiryJobData();
		PBBusinessMessage pbMsg = null;
		try {
			pbMsg = PBBusinessMessage.parseFrom(data);
		} catch (InvalidProtocolBufferException e) {
			AimError probufErr = AimError.PROTOBUF_ERROR;
			throw new ProtobufException(probufErr.getErrorCode(), probufErr.getMessage(), dateDao.getReasonTime(), probufErr.getUidCode());
		}
		return pbMsg;
		
	}
}
