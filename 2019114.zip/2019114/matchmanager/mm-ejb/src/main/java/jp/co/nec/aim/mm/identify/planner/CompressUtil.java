package jp.co.nec.aim.mm.identify.planner;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author xiazp
 *
 */
public class CompressUtil {
	private static Logger logger = LoggerFactory.getLogger(CompressUtil.class);
	private static final String ZIP_NAME = "MuJobExecutePlan";

	/**
	 * 
	 * @param muPlans
	 * @return
	 */
	public byte[] zipCompressWithPlanId(List<MuJobExecutePlan> muPlans) {
		if (muPlans == null || muPlans.size() == 0) {
			logger.warn("Parameter is incorrect, process will be return!");
			return null;
		}
		Map<Long, MuJobExecutePlan> mapPlans = new HashMap<Long, MuJobExecutePlan>();
		for (MuJobExecutePlan plan : muPlans) {
			mapPlans.put(plan.getPlanId(), plan);
		}
		byte[] compressed;
		ByteArrayOutputStream out = null;
		ZipOutputStream zout = null;
		try {
			out = new ByteArrayOutputStream();
			zout = new ZipOutputStream(out);
			ZipEntry ze = new ZipEntry(ZIP_NAME);
			zout.putNextEntry(ze);
			ByteArrayOutputStream bout1 = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(bout1);
			oos.writeObject(mapPlans);
			byte[] bytes = bout1.toByteArray();
			zout.write(bytes);
			zout.closeEntry();
			compressed = out.toByteArray();
		} catch (IOException e) {
			logger.error(
					"IOException occurred while compress Mu Job ExecutePlans.",
					e);
			return null;
		} finally {
			if (zout != null) {
				try {
					zout.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while compress Mu Job ExecutePlans.",
							e);
				}
			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while compress Mu Job ExecutePlans.",
							e);
				}
			}
		}
		return compressed;
	}

	/**
	 * 
	 * @param toBeunCompressed
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	public Map<Long, MuJobExecutePlan> unzipCompressWithPlanId(
			byte[] toBeunCompressed) {
		if (toBeunCompressed == null || toBeunCompressed.length <= 0) {
			logger.warn("Parameter is incorrect, process will be return!");
			return null;
		}
		Map<Long, MuJobExecutePlan> mapPlans = null;
		ByteArrayOutputStream out = null;
		ByteArrayInputStream in = null;
		ZipInputStream zin = null;
		try {
			out = new ByteArrayOutputStream();
			in = new ByteArrayInputStream(toBeunCompressed);
			zin = new ZipInputStream(in);
			ZipEntry entry = zin.getNextEntry();
			byte[] buffer = new byte[1024];
			int readed = -999;
			while ((readed = zin.read(buffer)) != -1) {
				out.write(buffer, 0, readed);
			}

			ByteArrayInputStream in1 = new ByteArrayInputStream(
					out.toByteArray());
			ObjectInputStream ois = new ObjectInputStream(in1);
			mapPlans = (Map<Long, MuJobExecutePlan>) ois.readObject();

		} catch (Exception e) {
			logger.error(
					"IOException occurred while uncompress Mu Job ExecutePlans.",
					e);
			return null;
		} finally {
			if (zin != null) {
				try {
					zin.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while uncompress Mu Job ExecutePlans.",
							e);
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while uncompress Mu Job ExecutePlans.",
							e);
				}
			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while uncompress Mu Job ExecutePlans.",
							e);
				}
			}
		}
		return mapPlans;
	}

	/**
	 * 
	 * @param muPlans
	 * @return
	 */
	public byte[] zipCompress(List<MuJobExecutePlan> muPlans) {
		if (muPlans == null || muPlans.size() == 0) {
			logger.warn("Parameter is incorrect, process will be return!");
			return null;
		}
		byte[] compressed;
		ByteArrayOutputStream out = null;
		ZipOutputStream zout = null;
		try {
			out = new ByteArrayOutputStream();
			zout = new ZipOutputStream(out);
			ZipEntry ze = new ZipEntry(ZIP_NAME);
			zout.putNextEntry(ze);
			ByteArrayOutputStream bout1 = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(bout1);
			oos.writeObject(muPlans);
			byte[] bytes = bout1.toByteArray();
			zout.write(bytes);
			zout.closeEntry();
			compressed = out.toByteArray();
		} catch (IOException e) {
			logger.error(
					"IOException occurred while compress Mu Job ExecutePlans.",
					e);
			return null;
		} finally {
			if (zout != null) {
				try {
					zout.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while compress Mu Job ExecutePlans.",
							e);
				}
			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while compress Mu Job ExecutePlans.",
							e);
				}
			}
		}
		return compressed;
	}

	/**
	 * 
	 * @param toBeunCompressed
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	public List<MuJobExecutePlan> unZipCompress(byte[] toBeunCompressed) {
		if (toBeunCompressed == null || toBeunCompressed.length <= 0) {
			logger.warn("Parameter is incorrect, process will be return!");
			return null;
		}
		List<MuJobExecutePlan> muPlanList = null;
		ByteArrayOutputStream out = null;
		ByteArrayInputStream in = null;
		ZipInputStream zin = null;
		try {
			out = new ByteArrayOutputStream();
			in = new ByteArrayInputStream(toBeunCompressed);
			zin = new ZipInputStream(in);
			ZipEntry entry = zin.getNextEntry();
			byte[] buffer = new byte[1024];
			int readed = -999;
			while ((readed = zin.read(buffer)) != -1) {
				out.write(buffer, 0, readed);
			}

			ByteArrayInputStream in1 = new ByteArrayInputStream(
					out.toByteArray());
			ObjectInputStream ois = new ObjectInputStream(in1);
			muPlanList = (List<MuJobExecutePlan>) ois.readObject();

		} catch (Exception e) {
			logger.error(
					"IOException occurred while uncompress Mu Job ExecutePlans.",
					e);
			return null;
		} finally {
			if (zin != null) {
				try {
					zin.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while uncompress Mu Job ExecutePlans.",
							e);
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while uncompress Mu Job ExecutePlans.",
							e);
				}
			}
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					logger.error(
							"IOException occurred while uncompress Mu Job ExecutePlans.",
							e);
				}
			}
		}
		return muPlanList;
	}
}
