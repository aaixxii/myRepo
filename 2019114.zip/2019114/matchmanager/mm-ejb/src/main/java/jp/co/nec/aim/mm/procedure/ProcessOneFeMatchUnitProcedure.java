package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.extract.planner.FeProcedureResults;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * pickup one mu that remain lot is largest and assign one lots of fe job to it
 * 
 * @author xiazp
 */
public class ProcessOneFeMatchUnitProcedure extends StoredProcedure {
	private static final String SQL = "MATCH_MANAGER_API.process_one_mu";
	private Integer maxLot;

	private static Logger logger = LoggerFactory
			.getLogger(ProcessOneFeMatchUnitProcedure.class);

	public ProcessOneFeMatchUnitProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_max_lot", Types.INTEGER));
		declareParameter(new SqlOutParameter("l_lot_job_id", Types.BIGINT));
		declareParameter(new SqlOutParameter("l_mu_id", Types.BIGINT));
		declareParameter(new SqlOutParameter("l_currentlots ", Types.BIGINT));
		compile();
	}

	public FeProcedureResults processOneFeMatchUnit(int maxMuLot)
			throws DataAccessException, SQLException {
		logger.debug("FEPlannerDAO->ProcessOneFeMatchUnitProcedure is called...");
		if (maxMuLot < 0) {
			throw new IllegalArgumentException("Max Mu Lot is null or empty"
					+ " when call ProcessOneFeMatchUnitProcedure");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_max_lot", maxMuLot);
		Map<String, Object> resultMap = execute(map);
		if (resultMap.values().toString().contains("[[]]")) {
			return null;
		}
		if (resultMap.get("l_lot_job_id") == null
				|| resultMap.get("l_mu_id") == null) {
			return null;
		}
		Long lotJobId = (Long) resultMap.get("l_lot_job_id");
		Long muId = (Long) resultMap.get("l_mu_id");
		Long currentlots = (Long) resultMap.get("l_currentlots ");
		FeProcedureResults results = new FeProcedureResults();
		results.setFeLotJobId(lotJobId);
		results.setMuId(muId);
		results.setCurrentlots(currentlots);
		logger.debug("FEPlannerDAO->ProcessOneFeMatchUnitProcedure success finished");
		return results;

	}

	public Integer getMaxLot() {
		return maxLot;
	}

	public void setMaxLot(Integer maxLot) {
		this.maxLot = maxLot;
	}

}
