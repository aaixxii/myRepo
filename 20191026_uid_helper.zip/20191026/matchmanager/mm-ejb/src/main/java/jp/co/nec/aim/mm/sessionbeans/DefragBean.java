package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.DefragDao;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class DefragBean {
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private DefragDao dh;

	public DefragBean() {
		// zero-arg ctor for container.
	}

	@PostConstruct
	public void init() {
		dh = new DefragDao();
	}

	public void defrag() {
		dh.defrag(dataSource);
	}
}
