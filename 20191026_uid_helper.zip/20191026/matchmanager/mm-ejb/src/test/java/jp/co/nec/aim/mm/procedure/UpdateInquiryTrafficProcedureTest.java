package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class UpdateInquiryTrafficProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private UpdateInquiryTrafficProcedure updateProcedure;

	@Before
	public void setUp() throws Exception {
		updateProcedure = new UpdateInquiryTrafficProcedure(dataSource);
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("update inquiry_traffic set job_exec_count = 0");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		updateProcedure = null;
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testUpdateInquiryTraffic_normal() throws DataAccessException,
			SQLException {
		Integer familyId = 1;
		long topJobId = 1000l;
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(1000,2,2,3000,0,0,0,1)";
		jdbcTemplate.update(jobQueueSql);
		String seletJobExecCount = "select job_exec_count from inquiry_traffic it where it.family_id = ?";
		int pre = jdbcTemplate.queryForObject(seletJobExecCount,
				new Object[] { familyId }, Integer.class);
		jdbcTemplate.execute("commit");
		updateProcedure.updateInquiryTraffic(topJobId);
		int after = jdbcTemplate.queryForObject(seletJobExecCount,
				new Object[] { familyId }, Integer.class);
		Assert.assertEquals(pre + 1, after);
	}

	@Test
	public void testUpdateInquiryTraffic_over_jobLimt_count()
			throws DataAccessException, SQLException {
		Integer familyId = 1;
		long[] topJobId = { 1000l, 1001l, 1002l, 1003l, 1004l };
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,2,1,3000,0,0,0,1)";
		for (int i = 0; i < topJobId.length; i++) {
			jdbcTemplate.update(jobQueueSql, topJobId[i]);
		}
		String updateTrafficJobExcuteCountSql = "UPDATE inquiry_traffic set job_exec_count = 16 where family_id = ?";
		jdbcTemplate.update(updateTrafficJobExcuteCountSql, familyId);
		jdbcTemplate.execute("commit");
		updateProcedure.updateInquiryTraffic(1000l);
		String seletJobExecCount = "select job_exec_count from inquiry_traffic it where it.family_id = ?";
		int after = jdbcTemplate.queryForObject(seletJobExecCount,
				new Object[] { familyId }, Integer.class);
		Assert.assertEquals(5, after);
	}

	@Test
	public void testUpdateInquiryTraffic_job_excute_count_minus()
			throws DataAccessException, SQLException {
		Integer familyId = 1;
		long[] topJobId = { 1000l, 1001l, 1002l, 1003l, 1004l };
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,2,1,3000,0,0,0,1)";
		for (int i = 0; i < topJobId.length; i++) {
			jdbcTemplate.update(jobQueueSql, topJobId[i]);
		}
		String updateTrafficJobExcuteCountSql = "UPDATE inquiry_traffic set job_exec_count = -10 where family_id = ?";
		jdbcTemplate.update(updateTrafficJobExcuteCountSql, familyId);
		jdbcTemplate.execute("commit");
		updateProcedure.updateInquiryTraffic(1000l);
		String seletJobExecCount = "select job_exec_count from inquiry_traffic it where it.family_id = ?";
		int after = jdbcTemplate.queryForObject(seletJobExecCount,
				new Object[] { familyId }, Integer.class);
		Assert.assertEquals(5, after);
	}

}
