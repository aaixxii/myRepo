      var wavesurfer;
        var timeline;
        var totalTime;
        var currentTime;
        var pxPerSec = 50;
        var seconds = 1.00;
        var muitSpRegions = [];
        var RegionList = [];
        var speakerColorList = [];
        var spkRegionList = [];
        var hasXmlFile = false;
        var hasWaveFile = false;
        var minPxPerSec = 50;
        var waveformWidth;
        var waveUrl;
        var hasTable = false;
        var isPlay = false;
        var isMuted = false;
        var isToggled = false;

        const colorArr = [
            'hsla(200, 100%, 30%, 0.3)',
            'hsla(400, 100%, 30%, 0.3)',
            'hsla(120,65%,75%,0.3)',
            'hsla(250,65%,75%,0.3)',
            'hsla(180,50%,50%,0.3)',
            'hsla(300, 90%, 30%, 0.2)',
            'hsla(120, 100 %, 50%, 0.3)'
        ];

   function initWaveSurfer(url) {
            wavesurfer = WaveSurfer.create({
                container: '#waveform',
                waveColor: 'green',
                fillParent: false,
                scrollParent: true,
                minPxPerSec: 50,
                hideScrollbar: false,
                barHeight: 2,
                height: 200,
                responsive: true

            });
            wavesurfer.load(url);
            wavesurfer.on('ready', function() {
                totalTime = wavesurfer.getDuration();
                var wf = document.getElementById("waveform");
                var rt = wf.getBoundingClientRect();
                waveformWidth = rt.left + rt.right;
                timeline = Object.create(WaveSurfer.Timeline);
                timeline.init({
                    wavesurfer: wavesurfer,
                    container: '#waveform-timeline',
                    // formatTimeCallback: formatTimeCallback(seconds, pxPerSec),
                    // timeInterval: timeInterval(pxPerSec),
                    // primaryLabelInterval: primaryLabelInterval(pxPerSec),
                    // secondaryLabelInterval: secondaryLabelInterval(pxPerSec),
                    primaryColor: 'red',
                    secondaryColor: 'blue',
                    primaryFontColor: 'red',
                    secondaryFontColor: 'blue'
                });
                wavesurfer.enableDragSelection({});
                //let muitRegs = test();
                if (muitSpRegions.length < 1) {
                    console.log("no data!");
                    return;
                }
                createInfoDiv();
                createAnime();
                for (let i in muitSpRegions) {
                    let tmp = muitSpRegions[i];
                    let arrs = tmp.regions;
                    for (let i in arrs) {
                        let tmp = arrs[i];
                        tmp.id = tmp.id + "-" + tmp.start;
                        let reg = wavesurfer.addRegion(tmp);
                        RegionList.push(reg);
                    }
                }
            });

            wavesurfer.on('audioprocess', function() {});

            wavesurfer.on('finish', function() {
                clearInfo();
            });

            wavesurfer.on("region-in", function(region) {
                //render(region);           
                let id = region.id;
                let index = id.indexOf('-');
                let name = id.substring(0, index);
                let target = document.getElementById(name);
                let txt = name + " is speaking!!";
                $(target).html(txt);
                $(target).css("color", "red");
            });

            wavesurfer.on("region-out", function(region) {
                let id = region.id;
                let index = id.indexOf('-');
                let name = id.substring(0, index);
                let target = document.getElementById(name);
                let txt = name;
                $(target).html(txt);
                $(target).css("color", region.color);


            });

            wavesurfer.on('region-click', function(region, e) {
                console.log(region.start);
                console.log(region.end);
                e.stopPropagation();
                wavesurfer.play(region.start, region.end);
            });

        } //end int wavessurfer

        function myplay() {
            if (!isPlay) {
                $("#cplay").removeClass('fa-play-circle');
                $("#cplay").addClass('fa-pause-circle');
            } else {
                $("#cplay").removeClass('fa-pause-circle');
                $("#cplay").addClass('fa-play-circle');
            }
            isPlay = !isPlay;
            if (!wavesurfer.params.scrollParent) {
                wavesurfer.toggleScroll();
            }
            clearInfo();
            wavesurfer.playPause();


        }

        function doStop() {
            wavesurfer.stop();
        }

        function toggleMute() {
            if (!isMuted) {
                $("#cmute").removeClass('fa-volume-off');
                $("#cmute").addClass('fa-volume-up');
            } else {
                $("#cmute").removeClass('fa-volume-up');
                $("#cmute").addClass('fa-volume-off');
            }
            isMuted = !isMuted;
            wavesurfer.toggleMute();
            let muteBtn = $("#mute");
            if (wavesurfer.isMuted) {
                muteBtn.prop('title', 'not muted');
                //muteBtn.html('SetToNoMute');
                $("#cmute").removeClass('fa-volume-mute');
            } else {
                // muteBtn.html('SetToMute');
                muteBtn.prop('title', 'muted');
            }
        }

        function myToggle() {
            if (!isToggled) {
                $("#cttab").removeClass('fa-toggle-on');
                $("#cttab").addClass('fa-toggle-off');
            } else {
                $("#cttab").removeClass('fa-toggle-off');
                $("#cttab").addClass('fa-toggle-on');
            }
            isToggled = !isToggled;
        }

        function clearAll() {
            $('#audioFile').val('');
            muitSpRegions = [];
            RegionList = [];
            speakerColorList = [];
            spkRegionList = [];
            hasXmlFile = false;
            hasWaveFile = false;
            waveUrl = "";
            hasTable = false;
            isPlay = false;
            isMuted = false;
            isToggled = false;
            wavesurfer.destroy();
        }

        function toggleScroll() {
            wavesurfer.toggleScroll();
        }

        function playRegion() {
            //var region = $(".wavesurfer-region"); 
            for (let i = 0; i < muitSpRegions.length; i++) {
                var test = muitSpRegions[i];
                var name = test.name;
                var regins = test.regions;
                var rg = regins[0];
                for (let j = 0; j < regins.length; j++) {
                    var rg = regins[i];
                    var st = rg.start;
                    var ed = rg.end;
                    wavesurfer.play(st, ed);
                    wavesurfer.playPause();
                }
            }
        }

        async function doPlayBytutton(e) {
            await playByButton(e);
        }

        function playByButton(ev) {
            wavesurfer.playPause();
            let row = $(ev).parent().parent().prevAll().length;
            let col = $(ev).parent().prevAll().length;
            let tab = document.getElementById("spkTab").childNodes[0];
            let spname = tab.rows[row].cells[0].innerHTML;
            let value = tab.rows[0].cells[col].innerHTML;
            let arr = value.split("-");
            let start = arr[0];
            let end = arr[1];
            let delay = ms => new Promise(resolve => setTimeout(resolve, ms));
            (async function loop() {
                for (let i = 0; i < muitSpRegions.length; i++) {
                    let test = muitSpRegions[i];
                    let name = test.name;
                    if (spname === name) {
                        let regins = test.regions;
                        for (let j = 0; j < regins.length; j++) {
                            let rg = regins[j];
                            let st = rg.start;
                            if (st === start) {
                                if (wavesurfer.isPlaying()) {
                                    wavesurfer.stop();
                                }
                                //wavesurfer.seekTo(start/totalTime);
                                wavesurfer.play(start, end);
                                await delay(500);

                            }
                        }
                    }
                }
            })();
        }


        function createTable() {
            if (hasTable) {
                alert("Speaker table is exist, skip!");
                return;
            }
            hasTable = true;
            var container = $("#table_container");
            let cap = "<h2>Speaker Timeline Info</>";
            $("#tabTitle").html(cap);

            var table = $("<table border=\"1\">");
            //let cap = $("<caption>Speaker List</caption>");
            //cap.attr("caption-side", "top");
            //cap.appendTo(table);      
            table.appendTo($("#spkTab"));

            let tr0 = $("<tr></tr>");
            tr0.appendTo(table);
            let td0 = $("<td>" + "Speaker" + "</td>");
            td0.attr('noWarp', 'noWrap');
            td0.css("color", "black");
            td0.appendTo(tr0);
            for (let i = 0; i < spkRegionList.length; i++) {
                let reg = spkRegionList[i];
                let txt = reg.start + "-" + reg.end;
                let td = $("<td></td>");
                td.html(txt);
                td.addClass('mycell');
                td.css("color", "blue");
                td.appendTo(tr0);
            }
            let rowCount = speakerColorList.length;
            for (let j = 0; j < rowCount; j++) {
                let name = speakerColorList[j].id;
                let ftr = $("<tr></tr>");
                let ftd = $("<td>" + name + "</td>");
                ftd.attr('noWarp', 'noWrap');
                ftd.css("color", "red");
                ftd.appendTo(ftr);
                for (let k = 0; k < spkRegionList.length; k++) {
                    let one = spkRegionList[k];
                    let td = $("<td></td>");
                    td.css("white-space", "nowrap");
                    if (one.id === name) {
                        let txt = one.id + ':' + one.start + '-' + one.end;
                        // let btn = $("<button type='button' class='btn btn-outline-success'>Play</button>"); 
                        // btn.attr('title',txt);
                        // btn.attr('onClick', 'doPlayBytutton(this);');                   
                        // td.append(btn);
                        let myad = new Audio(waveUrl + '#t=' + one.start + ',' + one.end);
                        myad.controls = true;
                        $(myad).css({
                            'width': '100'
                        });
                        // $(myad).attr('title',txt); 
                        td.attr('title', txt);
                        td.append(myad);

                    }
                    td.appendTo(ftr);
                    ftr.appendTo(table);
                }
            }

            $('.collapse').collapse();
        }

        function formatTimeCallback(seconds, pxPerSec) {
            seconds = Number(seconds);
            var minutes = Math.floor(seconds / 60);
            seconds = seconds % 60;
            // fill up seconds with zeroes
            var secondsStr = Math.round(seconds).toString();
            if (pxPerSec >= 25 * 10) {
                secondsStr = seconds.toFixed(2);
            } else if (pxPerSec >= 25 * 1) {
                secondsStr = seconds.toFixed(1);
            }

            if (minutes > 0) {
                if (seconds < 10) {
                    secondsStr = '0' + secondsStr;
                }
                return `${minutes}:${secondsStr}`;
            }
            return secondsStr;
        }

        function timeInterval(pxPerSec) {
            var retval = 1;
            if (pxPerSec >= 25 * 100) {
                retval = 0.01;
            } else if (pxPerSec >= 25 * 40) {
                retval = 0.025;
            } else if (pxPerSec >= 25 * 10) {
                retval = 0.1;
            } else if (pxPerSec >= 25 * 4) {
                retval = 0.25;
            } else if (pxPerSec >= 25) {
                retval = 1;
            } else if (pxPerSec * 5 >= 25) {
                retval = 5;
            } else if (pxPerSec * 15 >= 25) {
                retval = 15;
            } else {
                retval = Math.ceil(0.5 / pxPerSec) * 60;
            }
            return retval;
        }

        function primaryLabelInterval(pxPerSec) {
            var retval = 1;
            if (pxPerSec >= 25 * 100) {
                retval = 10;
            } else if (pxPerSec >= 25 * 40) {
                retval = 4;
            } else if (pxPerSec >= 25 * 10) {
                retval = 10;
            } else if (pxPerSec >= 25 * 4) {
                retval = 4;
            } else if (pxPerSec >= 25) {
                retval = 1;
            } else if (pxPerSec * 5 >= 25) {
                retval = 5;
            } else if (pxPerSec * 15 >= 25) {
                retval = 15;
            } else {
                retval = Math.ceil(0.5 / pxPerSec) * 60;
            }
            return retval;
        }

        function secondaryLabelInterval(pxPerSec) {
            // draw one every 10s as an example
            return Math.floor(10 / timeInterval(pxPerSec));
        }

        function handerDragAndDrop() {
            let obj = $("inputmyfile");
            obj.on('dragenter', function(e) {
                e.stopPropagation();
                e.preventDefault();
                $(this).css('border', '1px solid #0B85A1');
                $(this).width(100).height(2);
            });
            obj.on('dragover', function(e) {
                e.stopPropagation();
                e.preventDefault();
                e.dataTransfer.dropEffect = 'copy';
            });

            obj.on('dragleave', function(e) {
                e.stopPropagation();
                e.preventDefault();
                e.dataTransfer.dropEffect = 'copy';
            });

            obj.on('drop', function(e) {
                $(this).css('border', '1px dotted #0B85A1');
                $(this).width(100).height(2);
                e.preventDefault();
                let file = e.dataTransfer.files[0];
                let url = URL.createObjectURL(file);
                initWaveSurfer(url);
            });
        }
        handerDragAndDrop();

        function clear() {
            var inputObj = document.getElementById("#audioFile");
            inputObj.value = '';
        }

        function createRegions(start, end, color) {
            let regionObj = {};
            regionObj["start"] = start;
            regionObj["end"] = end;
            regionObj["color"] = color;
            return regionObj;
        }

        function createSpRegions(name, color, region) {
            let spRegions = {};
            spRegions["regions"] = [];
            spRegions["color"] = color;
            spRegions["regions"].push(region);
            return spRegions;
        }

        function addSpRegions(spRegions, regions) {
            if (!spRegions["regions"] || spRegions["regions"].length < 1) {
                spRegions["regions"] = [];
            }
            if (region.length < 1) {
                spRegions["regions"].push(regionregions);
            } else {
                spRegions["regions"].concat(regions);
            }
        }

        function test() {
            let muitSpRegions = [];

            let rc = 'hsla(200, 100%, 30%, 0.3)';
            let myRegions = [];
            myRegions.push(new Region("trump", 0.00, 5.00, rc));
            myRegions.push(new Region("trump", 7.00, 8.88, rc));
            myRegions.push(new Region("trump", 10.00, 15.00, rc));
            myRegions.push(new Region("trump", 15.05, 17.00, rc));
            let spRegion = new SpeekerRegions("trump", myRegions);
            muitSpRegions.push(spRegion);

            let rc2 = 'hsla(400, 100%, 30%, 0.3)';
            let myRegions2 = [];
            myRegions2.push(new Region("mumei", 18.00, 20.00, rc2));
            myRegions2.push(new Region("mumei", 23.00, 18.00, rc2));
            myRegions2.push(new Region("mumei", 25.00, 29.00, rc2));
            let spRegion2 = new SpeekerRegions("mumei", myRegions2);
            muitSpRegions.push(spRegion2);

            let rc3 = 'hsla(120,65%,75%,0.3)';
            let myRegions3 = [];
            myRegions3.push(new Region("taro", 30.00, 32.00, rc3));
            myRegions3.push(new Region("taro", 36.00, 40.00, rc3));
            let spRegion3 = new SpeekerRegions("taro", myRegions3);
            muitSpRegions.push(spRegion3);
            return muitSpRegions;
            // for test
            // green = hsla(120, 100 %, 50 %, 0.3);
            // light green = hsla(120, 100 %, 75 %, 0.3);
            // darkgreen = hsla(120, 100 %, 25 %, 0.3)
            // pastel green = hsla(120, 60 %, 70 %, 0.3);
            // red = hsl(0, 100 %, 50 %);
            // green = hsl(120, 100 %, 25 %);
            // yellow = hsl(60, 100 %, 50 %;
            //var x2js = new X2JS();
            //var jsonObj = x2js.xml_str2json( xmlText ); 
            //var jsonObj = x2js.xml_str2json(xmlText);
            //var xmlAsStr = x2js.json2xml_str(jsonObj);
        }

        function createAnime() {
            let parentDiv = document.getElementById("myAnime");
            for (let i in muitSpRegions) {
                let mydiv = $('<div></div>');
                mydiv.attr('id', muitSpRegions[i].name + "anime");
                mydiv.addClass('oneanime');
                let iobj = $('<i class="fas fa-smile  fa-7x"></i>');
                iobj.css('color', muitSpRegions[i].regions[0].color);
                iobj.appendTo(mydiv);
                mydiv.appendTo(parentDiv);
            }

        }

        function createInfoDiv() {
            let parentDiv = document.getElementById("audioInfo");
            totalTime = wavesurfer.getDuration();
            for (let i in muitSpRegions) {
                let mydiv = $('<div></div>');
                mydiv.attr('id', muitSpRegions[i].name);
                mydiv.attr('fontSize', 26);
                mydiv.attr('font-weight', "bold");
                mydiv.addClass('info');
                mydiv.text(muitSpRegions[i].name);
                let arrs = muitSpRegions[i].regions;
                let cr = arrs[0];
                mydiv.css("color", arrs[0].color);
                mydiv.appendTo(parentDiv);
                mydiv.on("click", function(e) {
                    wavesurfer.seekTo(0);
                    let objTarget = e.target;
                    e.stopPropagation();
                    let delay = ms => new Promise(resolve => setTimeout(resolve, ms));
                    (async function loop() {
                        for (let j in RegionList) {
                            // await delay(500);
                            let reg = RegionList[j];
                            let index = reg.id.indexOf('-');
                            let name = reg.id.substring(0, index);
                            if (!(name === objTarget.id)) {
                                continue;
                            }
                            reg.play();
                            await delay(1000);
                        }
                    })();
                });
            }
            // let txt = "Total Speaker:" + muitSpRegions.length;
            // let labdiv = $('<div></div>');
            // labdiv.attr('id', 'labdiv');
            // labdiv.addClass('info');
            // labdiv.text(txt);        
            // labdiv.css({ "color": "red"});
            // labdiv.css({ "background-color": "green"});
            // labdiv.appendTo(parentDiv);
        }

        function createSpkInfo() {
            clearInfo();
            if (wavesurfer.isPlaying()) {
                wavesurfer.stop();
            }
            if (wavesurfer.params.scrollParent) {
                wavesurfer.toggleScroll();
            }
            let temp = wavesurfer.params.scrollParent;
            for (let j in RegionList) {
                let one = RegionList[j];
                render(one);
            }

        }


        function render(region) {
            canvas = document.getElementById("audio_canvas");
            context = canvas.getContext("2d");
            // context.translate(0, 0);  
            context.width = totalTime * 50;
            waveformWidth;
            // var cs = document.getElementById("audio_canvas");
            // var csrt = cs.getBoundingClientRect();
            // var csd = csrt.left + csrt.right;
            var baseH = 0;
            let drawH = 50;
            context.beginPath();
            context.fillStyle = region.color;
            let st = region.start;
            let ed = region.end;
            context.fillRect(st * 50, baseH, (ed - st) * 50, drawH);
            context.save();
            context.closePath();
            context.beginPath();
            context.fillStyle = "green";
            context.font = '24pt Calibri';
            context.fillText(st + ":" + ed, st * 50 + ((ed - st) * 50) / 2 - 10, drawH - 12);
            context.closePath();
            context.restore();
        }

        function clearInfo() {
            const infoDiv = document.getElementById("audioInfo");
            for (let i = 0; i < infoDiv.children.length; i++) {
                let subDiv = infoDiv.children[i];
                let name = $(subDiv).attr('id');
                subDiv.innerHTML = name;
            }
        }

        function Region(id, start, end, color) {
            this.id = id;
            this.start = start;
            this.end = end;
            this.color = color;
        }

        function SpeakerColor(name, color) {
            this.id = name;
            this.color = color;
        }

        function SpeekerRegions(name, regions) {
            this.name = name;
            if (regions.length > 0) {
                this.regions = regions;
            } else {
                this.regions = [];
            }
        }

        function readXmlNew(fileList, evt) {
            if (!fileList.length) {
                alert('File is not selected.');
                return;
            }
            var fileToLoad = evt.target.files[0];
            if (fileToLoad) {
                var reader = new FileReader();
                reader.onload = function(fileLoadedEvent) {
                    var data = fileLoadedEvent.target.result;
                    var x2js = new X2JS();
                    var jsonTmp = x2js.xml_str2json(data);
                    var spList = jsonTmp.speakerList;
                    var set = new Set();
                    for (let i = 0; i < spList.speaker.length; i++) {
                        set.add(spList.speaker[i]._name);
                    }
                    var colorIndex = 0;
                    set.forEach(x => {
                        let spkClr = new SpeakerColor(x, colorArr[colorIndex]);
                        speakerColorList.push(spkClr);
                        colorIndex++;
                    });
                    for (let i = 0; i < spList.speaker.length; i++) {
                        let temp = spList.speaker[i];
                        let name = temp._name;
                        let start = temp._start;
                        let end = temp._end;
                        spkRegionList.push(new Region(name, start, end, getColor(name)));
                    }

                };
                reader.readAsText(fileToLoad, 'UTF-8');
            }
        } //end readXmlNew  

        function getColor(id) {
            for (let one in speakerColorList) {
                if (speakerColorList[one].name === id) {
                    return speakerColorList[one].color;
                }
            }
        }

        function readXml(fileList, evt) {
            if (!fileList.length) {
                alert('File is not selected.');
                return;
            }
            var fileToLoad = evt.target.files[0];
            if (fileToLoad) {
                var reader = new FileReader();
                reader.onload = function(fileLoadedEvent) {
                    var data = fileLoadedEvent.target.result;
                    var x2js = new X2JS();
                    var jsonTmp = x2js.xml_str2json(data);
                    var spList = jsonTmp.speakerList;
                    var set = new Set();
                    for (let i = 0; i < spList.speaker.length; i++) {
                        set.add(spList.speaker[i]._name);
                    }
                    var colorIndex = 0;
                    set.forEach(x => {
                        var myRegions = [];
                        for (let i = 0; i < spList.speaker.length; i++) {
                            if (spList.speaker[i]._name === x) {
                                let temp = spList.speaker[i];
                                let name = temp._name;
                                let start = temp._start;
                                let end = temp._end;
                                myRegions.push(new Region(name, start, end, colorArr[colorIndex]));
                                myRegions.sort();
                            }
                        }
                        let spRegion = new SpeekerRegions(x, myRegions);
                        muitSpRegions.push(spRegion);
                        colorIndex++;
                    });
                    //alert(muitSpRegions.length);
                    showSpkNum(muitSpRegions.length);

                    //$.showModal({title: "info", body: ""});
                };
                reader.readAsText(fileToLoad, 'UTF-8');
            }
        } //end readXml  

        function showSpkNum(num) {
            let delay = ms => new Promise(resolve => setTimeout(resolve, ms));
            (async function show() {
                let maru = document.getElementById("maru");
                $(maru).addClass("maru");
                //let spknum = document.getElementById("spknum");
                // $(spknum).addClass("letter3");
                let txt = "Speaker:" + num;
                $(maru).html(txt);
                await delay(1000);
                $(maru).removeClass("maru");
                //$(spknum).removeClass("spknum");
                $(maru).html('');
            })();

        }

        function readJson(evt) {
            var fileToLoad = evt.target.files[0];
            if (fileToLoad) {
                var reader = new FileReader();
                var fileName = fileToLoad.name;
                reader.onload = function(fileLoadedEvent) {
                    var data = fileLoadedEvent.target.result;
                    var json = JSON.parse(data);
                    if (fileName.toLowerCase().startsWith(PROBE)) {
                        //mergeMinutiaInfo(PROBE, json);
                    } else if (fileName.toLowerCase().startsWith(TARGET)) {
                        //mergeMinutiaInfo(TARGET, json);
                    }
                };
                reader.readAsText(fileToLoad, 'UTF-8');
            }
        }

        function doGetwaveDataAjx() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'http://url', true);
            xhr.responseType = 'arraybuffer';
            xhr.onload = function(e) {
                if (this.status == 200) {
                    // Note: .response instead of .responseText
                    // var blob = new Blob([this.response], { type: 'image/png' });
                    var uInt8Array = new Uint8Array(this.response);
                }
            };
            xhr.send();
        }

        function doGetXmlAjax(fileName) {
            var sendUrl = "?";
            $.ajax({
                type: "GET",
                url: sendUrl,
                timeout: 2000,
                dataType: "text",
                cache: false,
                async: false,
                success: function(data, status) {
                    if (data == "" || data == null || data == undefined) {
                        return;
                    }
                    updateVerifyJobResult(data);
                },
                error: function(XMLHttpRequest, status, errorThrown) {
                    console.log('Can not to get verify job results, Reason: ' + errorThrown);
                }
            });
        }
