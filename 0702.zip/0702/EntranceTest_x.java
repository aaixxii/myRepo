package jp.co.nec.aim.df.entrance;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;
import static org.apache.commons.io.IOUtils.write;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import jp.co.nec.aim.df.common.HttpTestServer;
import jp.co.nec.aim.df.common.StaticChange;
import jp.co.nec.aim.df.constant.SystemConstant;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dao.ContainerAnalysisDao;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.dao.SegmentDefragDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.entity.TotalInformation;
import jp.co.nec.aim.df.exception.CommunicationException;
import jp.co.nec.aim.df.exception.ConsoleException;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.exception.DefragmentUtilException;
import jp.co.nec.aim.df.exception.ReturnValueNotSuccessException;
import jp.co.nec.aim.df.service.CommunicationService;
import jp.co.nec.aim.df.service.ContainerInitService;
import jp.co.nec.aim.df.service.ExecutionService;
import jp.co.nec.aim.df.service.StatusCheckerService;
import jp.co.nec.aim.df.util.ConsoleUtil;
import jp.co.nec.aim.df.util.PropertiesUtil;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.kohsuke.args4j.CmdLineException;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class EntranceTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	private static DataCreatorUtil creator;
	private static ContainerAnalysisDao dao;
	private static SegmentDefragDao segDefragDao;

	private static final String[] DEFRAG_ARGS = { "-m", "defragment" };

	@Before
	public void setup() {
		if (dao == null) {
			dao = DaoFactory.createDao(ContainerAnalysisDao.class);
		}

		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}
		if (segDefragDao == null) {
			segDefragDao = DaoFactory.createDao(SegmentDefragDao.class);
		}
		clearData();
		final String methodName = name.getMethodName();
		if (methodName
				.equalsIgnoreCase("testDefragmentMain_Normally_MM_careFlagIsFalse")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs3();
			creator.insertSystemInitMultiBootFlag("false");
		} else if (methodName
				.equalsIgnoreCase("testDefragmentMain_DefragmentUtilException")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs3();
		} else if (methodName
				.equalsIgnoreCase("testDefragmentMain_ReturnValueNotSuccessException_MM_careFlagIsFalse")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs3();
		} else if (methodName
				.equalsIgnoreCase("testDefragmentMain_exec_container_UnknownException_MM_careFlagIsFalse")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs3();
		} else if (methodName
				.equalsIgnoreCase("testDefragmentMain_PlanIsEmpty")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs5();
		} else if (methodName
				.equalsIgnoreCase("testDefragmentMain_Normally_MM_careFlagIsTrue_withNoJobwait")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs3();
			creator.insertSystemInitMultiBootFlag("false");
		} else if (methodName.equalsIgnoreCase("testUpdateContainerId_Correct")) {
		}
		creator.cleanAndSetRUC();
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() {
		clearData();
	}

	@AfterClass
	public static void afterClass() {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
	}

	@Rule
	public TestName name = new TestName();

	private void clearData() {
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from person_biometrics");
		jdbcTemplate.execute("delete from segment_change_log");
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	/**
	 * MMcare is false MM is not alive
	 */
	@Test
	public void testDefragmentMain_Normally_MM_careFlagIsFalse() {
		MockUp<PropertiesUtil> mocked = new MockUp<PropertiesUtil>() {
			@Mock
			public boolean getMmCare() {
				return false;
			}
		};

		try {

			Entrance.main(DEFRAG_ARGS);
			List<SegmentSummary> segments = dao.getSegmentSummary(1);
			assertEquals(segments.size(), 5);

			SegmentSummary segment1 = segments.get(0);
			assertEquals(segment1.getContainerId().intValue(), 1);
			assertEquals(segment1.getSegId().intValue(), 1);
			assertEquals(segment1.getStartId().intValue(), 1);
			assertEquals(segment1.getEndId().intValue(), 44);
			assertEquals(segment1.getRecordCount().intValue(), 20);
			assertEquals(segment1.getVersion().intValue(), 2034);
			assertEquals(segment1.getReVersion().intValue(), 2034);
			assertEquals(segment1.getBlCompacted().intValue(), 176926);
			assertEquals(segment1.getBlunCompacted().intValue(), 176926);

			SegmentSummary segment2 = segments.get(1);
			assertEquals(segment2.getContainerId().intValue(), 1);
			assertEquals(segment2.getSegId().intValue(), 3);

			assertEquals(segment2.getStartId().intValue(), 45);
			assertEquals(segment2.getEndId().intValue(), 88);
			assertEquals(segment2.getRecordCount().intValue(), 20);
			assertEquals(segment2.getVersion().intValue(), 2034);
			assertEquals(segment2.getReVersion().intValue(), 2034);
			assertEquals(segment2.getBlCompacted().intValue(), 176926);
			assertEquals(segment2.getBlunCompacted().intValue(), 176926);
			
			//MMCare is false
			assertEquals(null, segDefragDao.getTrifficContainerId());
			assertEquals(0, segDefragDao.getSegDefragCount());
			assertEquals(new Integer(1), creator.getRUC());
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_DefragmentDaoException() {
		MockUp<ContainerInitService> mocked = new MockUp<ContainerInitService>() {
			@Mock
			public List<ContainerSummary> initContainerSummary() {
				throw new DefragmentDaoException("");
			}

			@Mocked
			public static final int sdsd = 1;
		};

		try {
			Entrance.main(DEFRAG_ARGS);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_ConsoleException() {
		MockUp<ConsoleUtil> mocked = new MockUp<ConsoleUtil>() {
			@Mock
			public final String displayHeader() throws ConsoleException {
				throw new ConsoleException("");
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_DefragmentUtilException() {
		MockUp<DataSourceCreator> mocked = new MockUp<DataSourceCreator>() {
			@Mock
			public final void setupDateSource() {
				throw new DefragmentUtilException("");
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
		} finally {
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_IllegalArgumentException() {
		MockUp<ConsoleUtil> mocked = new MockUp<ConsoleUtil>() {
			@Mock
			public final String displayContainerInfo(
					final TotalInformation information) {
				throw new IllegalArgumentException("");
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
		} finally {
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_UnknownException() {
		MockUp<DataSourceCreator> mocked = new MockUp<DataSourceCreator>() {
			@Mock
			public synchronized final DataSource getDataSource()
					throws Exception {
				throw new Exception("");
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_CommunicationException01() {
		MockUp<DataSourceCreator> mocked = new MockUp<DataSourceCreator>() {
			@Mock
			public synchronized final DataSource getDataSource()
					throws CommunicationException {
				throw new CommunicationException("");
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_CommunicationException02() {
		MockUp<ExecutionService> mocked = new MockUp<ExecutionService>() {
			@Mock
			protected boolean sendSignalToStartControl(final int containerId)
					throws Exception {
				throw new CommunicationException("");
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_DefragmentServiceException() {

		MockUp<ContainerInitService> mocked = null;
		try {
			mocked = new MockUp<ContainerInitService>() {
				@Mock
				public TotalInformation initTotalContainer() {
					throw new DefragmentServiceException("");
				}
			};

			Entrance.main(DEFRAG_ARGS);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_ReturnValueNotSuccessException_MM_careFlagIsFalse() {
		MockUp<PropertiesUtil> mocked = new MockUp<PropertiesUtil>() {
			@Mock
			public boolean getMmCare() {
				return true;
			}
		};

		MockUp<CommunicationService> mocked1 = new MockUp<CommunicationService>() {
			@Mock
			public final boolean sendStartSignal(final int containerId)
					throws ReturnValueNotSuccessException {
				throw new ReturnValueNotSuccessException("");
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
			List<SegmentSummary> segments = dao.getSegmentSummary(1);
			assertEquals(segments.size(), 5);

		} finally {	
			mocked.tearDown();
			mocked1.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_exec_container_UnknownException_MM_careFlagIsFalse() {

		MockUp<ExecutionService> mocked = new MockUp<ExecutionService>() {
			@Mock
			public void planExecution(final List<Plan> plans)
					throws NullPointerException {
				throw new NullPointerException("");
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
			List<SegmentSummary> segments = dao.getSegmentSummary(1);
			assertEquals(segments.size(), 5);

		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testDefragmentMain_PlanIsEmpty() {
		Entrance.main(DEFRAG_ARGS);
		List<SegmentSummary> segments = dao.getSegmentSummary(1);
		assertEquals(segments.size(), 5);
	}

	private Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {

				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();

				String containerId = baseRequest
						.getHeader(SystemConstant.MM_DEFRAGCONTAINERID);
				String status = baseRequest
						.getHeader(SystemConstant.MM_COMMAND);

				response.setStatus(200);

				if (status == null) {
					;
				} else if (status
						.equalsIgnoreCase(SystemConstant.MM_STATUS_START))
					write(containerId, response.getOutputStream());
				else if (status.equalsIgnoreCase(SystemConstant.MM_STATUS_STOP))
					write(String.valueOf(-1), response.getOutputStream());

				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};

		return handler;
	}

	@Test
	public void testDefragmentMain_Normally_MM_careFlagIsTrue_withNoJobwait()
			throws Exception {

		HttpTestServer server = null;
		MockUp<PropertiesUtil> mocked = null;
		try {
			server = new HttpTestServer(55513);
			server.start(getMockHandler());

			// creator.insertSystemInitflowcontrol("true");
			// jdbcTemplate.execute("commit");

			mocked = new MockUp<PropertiesUtil>() {
				@Mock
				public boolean getMmCare() {
					return true;
				}
			};

			Entrance.main(DEFRAG_ARGS);
			List<SegmentSummary> segments = dao.getSegmentSummary(1);
			assertEquals(segments.size(), 5);

			SegmentSummary segment1 = segments.get(0);
			assertEquals(segment1.getContainerId().intValue(), 1);
			assertEquals(segment1.getSegId().intValue(), 1);
			assertEquals(segment1.getStartId().intValue(), 1);
			assertEquals(segment1.getEndId().intValue(), 44);
			assertEquals(segment1.getRecordCount().intValue(), 20);
			assertEquals(segment1.getVersion().intValue(), 2034);
			assertEquals(segment1.getReVersion().intValue(), 2034);
			assertEquals(segment1.getBlCompacted().intValue(), 176926);
			assertEquals(segment1.getBlunCompacted().intValue(), 176926);

			SegmentSummary segment2 = segments.get(1);
			assertEquals(segment2.getContainerId().intValue(), 1);
			assertEquals(segment2.getSegId().intValue(), 3);
			assertEquals(segment2.getStartId().intValue(), 45);
			assertEquals(segment2.getEndId().intValue(), 88);
			assertEquals(segment2.getRecordCount().intValue(), 20);
			assertEquals(segment2.getVersion().intValue(), 2034);
			assertEquals(segment2.getReVersion().intValue(), 2034);
			assertEquals(segment2.getBlCompacted().intValue(), 176926);
			assertEquals(segment2.getBlunCompacted().intValue(), 176926);

			assertEquals(new Long(-1), segDefragDao.getTrifficContainerId());
			assertEquals(1, segDefragDao.getSegDefragCount());
			assertEquals(new Integer(3), creator.getRUC());
		} finally {
			if (server != null) {
				server.stop();
				mocked.tearDown();
			}			
		}
	}

	@Test
	public void testDefragmentMain_Normally_isMMFlowControlStatusOk() {
		MockUp<StatusCheckerService> mocked = new MockUp<StatusCheckerService>() {
			@Mock
			public boolean isMMStatusOk() {
				return false;
			}
		};

		try {
			Entrance.main(DEFRAG_ARGS);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testEntranceMainParaIsNullOrEmpty() {
		try {
			Entrance.main(null);
		} catch (Exception ex) {
			assertTrue(ex instanceof RuntimeException);
			assertEquals(ex.getMessage(),
					"the defragmentation parameter is null..");
		}

		try {
			Entrance.main(new String[] {});
		} catch (Exception ex) {
			assertTrue(ex instanceof RuntimeException);
			assertEquals(ex.getMessage(),
					"the defragmentation parameter is null..");
		}
	}

	 @Test
	 public void testEntranceMainParaIsInCorrect() {
	 try {
	 Entrance.main(new String[] { "-m", "errorParameter" });
	 } catch (Exception ex) {
	 assertTrue(ex instanceof IllegalArgumentException);
	 assertEquals(ex.getMessage(),
	 "the Execute mode errorParameter is not support..");
	 }
	
	 try {
	 Entrance.main(new String[] { "-m", "updateContainerId" });
	 } catch (Exception ex) {
	 assertTrue(ex instanceof IllegalArgumentException);
	 assertEquals(ex.getMessage(),
	 "parse containerid error while mode is updateContainerId.. ");
	 }
	
	 try {
	 Entrance.main(new String[] { "-m", "updateContainerId", "-b", "asd" });
	 } catch (Exception ex) {
	 assertTrue(ex.getCause() instanceof CmdLineException);
	 assertEquals(ex.getMessage(),
	 "the defragmentation parameters is invalid.");
	 }
	
	 }

	@Test
	public void testDefragmentMain_Normally_MM_careFlagIsTrue_Maxjoint()
			throws Exception {

		HttpTestServer server = null;
		try {
			server = new HttpTestServer(55513);
			server.start(getMockHandler());

			// creator.insertSystemInitflowcontrol("true");
			// jdbcTemplate.execute("commit");

			StaticChange.setFinalStatic(
					SystemConstant.class.getField("MAX_JOINT"), 1);

			Entrance.main(DEFRAG_ARGS);
			List<SegmentSummary> segments = dao.getSegmentSummary(1);
			assertEquals(segments.size(), 0);

		} finally {
			if (server != null) {
				server.stop();
			}
			StaticChange.setFinalStatic(
					SystemConstant.class.getField("MAX_JOINT"), 5);
		}
	}

}
