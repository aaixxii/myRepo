package com.nec.aim.dm.nodostorage.service;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.locks.Lock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.DmConfigRepository;
import com.nec.aim.dm.nodostorage.repository.SegmentLoadRepository;
import com.nec.aim.dm.nodostorage.segments.DmConstants;
import com.nec.aim.dm.nodostorage.segments.SegmentWriter;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TemplateService {

	@Autowired
	SegmentLoadRepository segmentLoadRepository;
	
	@Autowired
	DmConfigRepository dmConfigRepository;

	@Autowired
	ConfigProperties config;

	public byte[] getTemplate( Long segId, Long bioId) throws IOException {		
		SegmentWriter segWriter = NodeStorageManager.getSegmentWriter(segId);		
		File file = segWriter.getMyFile();		
		if (!file.exists()) {
			 String downloadPath = config.getPath() + "/" + String.valueOf(segId);	
			 file = new File(downloadPath);
		}
		int bioIdOffset = bioId.intValue() - segWriter.getBioIdStart().intValue();
		int readOffset = DmConstants.SEGMENT_HEADER_SIZE + bioIdOffset * NodeStorageManager.getIntDmConfigValue("templateSize") + DmConstants.SIZE_TEMPLATE_HEADER_CHECKSUM;
		byte[] byteData = new byte[readOffset];
		RandomAccessFile raf = null;
		Lock readLocker = segWriter.getReadLock();
		readLocker.lock();
		try {
			raf = new RandomAccessFile(file, "rwd");
			raf.seek(readOffset);
			raf.read(byteData);			
			raf.close();
			log.info("Success get segment({}) data", segId);
			return byteData;
		} catch (IOException e) {
			log.error(e.getMessage());
			return null;
		} finally {
			readLocker.unlock();
			raf.close();
		}
	}
}
