#!/bin/sh

# ----------------------------------------------------------------------
# Checking   paramters  all are correctly!
# 1. aim_release_version
# 2. currently_aim_branches_version
# 3. XSDSchema_developing_version
# exsample : ./doXSDSchemaRelease.sh 5.0.3  5.0.2 5.0.1
# ----------------------------------------------------------------------
# CHECK Args of doXSDSchemaRelease()
if test  $# != 3 ; then
	echo Usage : ./doXSDSchemaRelease.sh   aim_release_version  currently_aim_branches_version   XSDSchema_developing_version
	exit
fi
RELEASE_VER=$1
DEV_VER=$2
XSDSchema_VER=$3
XSDSchema_COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-$RELEASE_VER/AIM-$RELEASE_VER-DOC/XSDSchema/

XSDSchema_TAG_DIR=http://dev01a/svn/tags/XSDSchema/$RELEASE_VER/
XSDSchema_RELEASE_TAG_DIR=http://dev01a/svn/tags/Release/AIM-$RELEASE_VER/Common/
mkdir release
cd release
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ReleaseXSDSchema to shipment
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# CHECKOUT  SHIPMENT DIRECTORY OF XSDSchema
svn ls --username jenkins --password jenkins $XSDSchema_COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username jenkins --password jenkins --parents --message "Directory Created By Jenkins" $XSDSchema_COPY_TO_DIR
	svn co --username jenkins --password jenkins $XSDSchema_COPY_TO_DIR
else
	svn co --username jenkins --password jenkins --depth=empty $XSDSchema_COPY_TO_DIR
fi
--svn up --username jenkins --password jenkinsXSDSchema/*
cp ../schema/*  XSDSchema/
cd  XSDSchema
svn add *
svn commit --username jenkins --password jenkins --message "Update By Jenkins"
COMMIT_RESULT=$?
cd ../../
rm -rf release
if test $COMMIT_RESULT –ne 0 ; then
	echo “svn commit for shipment was failed!! Exit without making tag of DM source code.”
	exit
fi

# ----------------------------------------------------------------------------------------------------------------------------------------
# Create Tag  XSDSchema  
# -----------------------------------------------------------------------------------------------------------------------------------------

echo "--------------------------------------------------------------------------------"
echo "CREATE XSDSchema  Release TAG TO http://dev01a/svn/tags/Release/..."
echo "--------------------------------------------------------------------------------"

# CHECK IF TAG IS ALREADY CREATED OR NOT
svn ls --username jenkins --password jenkins $XSDSchema_RELEASE_TAG_DIR > /dev/null
if test $? = 0 ; then
	svn delete --username jenkins --password jenkins --message "Delete Tag by Jenkins" $XSDSchema_RELEASE_TAG_DIR
else
	svn mkdir --username jenkins --password jenkins --parents --message "Directory Created By Jenkins" $XSDSchema_RELEASE_TAG_DIR
fi

# CREATE RELEASE  TAG
svn copy --username jenkins --password jenkins --message "Create Source Code Tag by Jenkins" --parents http://dev01a/svn/branches/AIM-$DEV_VER/Common/XSDSchema  $XSDSchema_RELEASE_TAG_DIR

echo "--------------------------------------------------------------------------------------------"
echo "CREATE XSDSchema TAG TO http://dev01a/svn/tags/XSDSchema/.. "
echo "---------------------------------------------------------------------------------------------"

# CHECK IF TAG IS ALREADY CREATED OR NOT
svn ls --username jenkins --password jenkins $XSDSchema_TAG_DIR > /dev/null
if test $? = 0 ; then
	svn delete --username jenkins --password jenkins --message "Delete Tag by Jenkins" $XSDSchema_TAG_DIR
else 
        svn mkdir --username jenkins --password jenkins --parents --message "Directory Created By Jenkins" $XSDSchema_TAG_DIR
fi

# CREATE SOURCE CODE TAG
svn copy --username jenkins --password jenkins --message "Create Source Code Tag by Jenkins" --parents http://dev01a/svn/branches/AIM-$DEV_VER/Common/XSDSchema  $XSDSchema_TAG_DIR

echo "Completed ......Done!"
