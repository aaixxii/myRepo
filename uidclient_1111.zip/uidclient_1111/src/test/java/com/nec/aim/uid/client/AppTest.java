package com.nec.aim.uid.client;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.junit.Test;

import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
  
    public void testApp()  {   
    	UUID uuid = UUID.randomUUID();
        String str = uuid.toString();
        str.replace("-", "");
        System.out.println(str.toUpperCase() + ":" + str.length());
   
    
    }
	
    public static String getUUID32(){
		return UUID.randomUUID().toString().replace("-", "").toLowerCase();
	}
	public static String[] getUUID(int num){
		
		if( num <= 0)
			return null;
		
		String[] uuidArr = new String[num];
		
		for (int i = 0; i < uuidArr.length; i++) {
			uuidArr[i] = getUUID32();
		}
		
		return uuidArr;
	}
  
	@Test
	public void testPath() {
		Path path = Paths.get("C:\\Users\\xia\\Desktop\\test");
		String name1 = path.toAbsolutePath().toString();
		String name2 = path.getFileName().toString();
		String name3 = path.toFile().getAbsolutePath();
		System.out.print("OKOK");
		
	}
}
