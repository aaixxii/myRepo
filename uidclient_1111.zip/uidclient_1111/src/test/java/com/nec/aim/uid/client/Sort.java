package com.nec.aim.uid.client;

import java.util.*;
import java.util.stream.Collectors;

public class Sort {

    public static void main(String[] args) {        
        Map<Integer, Integer> map = new HashMap<>();
        map.put(21, 10);
        map.put(11, 12);
        map.put(2, 10);
        Map<Integer, Integer> result = map.entrySet().stream()
                .sorted(Map.Entry.<Integer, Integer>comparingByValue().reversed()
                        .thenComparing(Map.Entry.comparingByKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        for (Map.Entry<Integer, Integer> sorted : result.entrySet()) {
            System.out.printf("Key is %d  value is %d \n", sorted.getKey(), sorted.getValue());
        }
    }
}