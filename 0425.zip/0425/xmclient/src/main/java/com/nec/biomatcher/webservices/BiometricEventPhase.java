
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for biometricEventPhase.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="biometricEventPhase">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PENDING_SYNC"/>
 *     &lt;enumeration value="SYNC_COMPLETED"/>
 *     &lt;enumeration value="SYNC_ERROR"/>
 *     &lt;enumeration value="DATA_ERROR"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "biometricEventPhase")
@XmlEnum
public enum BiometricEventPhase {

    PENDING_SYNC,
    SYNC_COMPLETED,
    SYNC_ERROR,
    DATA_ERROR;

    public String value() {
        return name();
    }

    public static BiometricEventPhase fromValue(String v) {
        return valueOf(v);
    }

}
