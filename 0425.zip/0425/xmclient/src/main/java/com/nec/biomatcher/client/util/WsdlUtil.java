package com.nec.biomatcher.client.util;

import static com.nec.biomatcher.client.common.XmClientConstants.NAMESPACE_URL;
import static com.nec.biomatcher.client.common.XmClientConstants.WSDL_URL;
import static com.nec.biomatcher.client.common.XmClientConstants.WSDL_URL2;


import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.nec.biomatcher.client.exception.XmClientException;
import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;

public class WsdlUtil {	
	private static BioMatcherWebServiceInterface xmWebService;
	private static  BioMatcherWebServiceInterface xmWebService2;
	
	private static String wsdlUrl;
	private static String wsdlUrl2;
	
	
	
	private static void buildXmWebService() {	
		
		XmClientManager manager = XmClientManager.getInstance();
		if (manager.getMapSize() < 1 ) {
			manager.getAllProperties();
		}
		try {
			 wsdlUrl = manager.getValue(WSDL_URL);			
			URL url = new URL(wsdlUrl);
			QName qname = new QName(NAMESPACE_URL, "bioMatcherWebService");
			Service service = Service.create(url, qname);
			xmWebService = service.getPort(BioMatcherWebServiceInterface.class);		
		} catch (Exception e) {			
			throw new XmClientException(e.getMessage(), e);
		}
		
	}
	
	private static void buildXmWebService2() {
		XmClientManager manager = XmClientManager.getInstance();
		if (manager.getMapSize() < 1 ) {
			manager.getAllProperties();
		}
		try {
			wsdlUrl2 = manager.getValue(WSDL_URL2);
			if (wsdlUrl2 == null || wsdlUrl2.isEmpty()) {				
				return;
			}
			URL url2 = new URL(wsdlUrl2);
			QName qname = new QName(NAMESPACE_URL, "bioMatcherWebService");
			Service service = Service.create(url2, qname);
			xmWebService2 = service.getPort(BioMatcherWebServiceInterface.class);		
		} catch (Exception e) {			
			throw new XmClientException(e.getMessage(), e);
		}		
	}
	
	public static BioMatcherWebServiceInterface getXmWebService() {
		if (xmWebService == null) {
			buildXmWebService();
		}
		return xmWebService;
	}
	
	public static BioMatcherWebServiceInterface getXmWebService2() {
		if (xmWebService2 == null ) {
			buildXmWebService2();
		}
		return xmWebService2;
	}

	public static String getWsdlUrl() {
		return wsdlUrl;
	}

	public static void setWsdlUrl(String wsdlUrl) {
		WsdlUtil.wsdlUrl = wsdlUrl;
	}

	public static String getWsdlUrl2() {
		return wsdlUrl2;
	}

	public static void setWsdlUrl2(String wsdlUrl2) {
		WsdlUtil.wsdlUrl2 = wsdlUrl2;
	}	
}
