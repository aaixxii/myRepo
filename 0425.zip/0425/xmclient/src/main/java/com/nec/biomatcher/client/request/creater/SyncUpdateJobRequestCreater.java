package com.nec.biomatcher.client.request.creater;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_IP;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.SyncJobRequestDto;
import com.nec.biomatcher.webservices.UpdateBiometricEventUserFlagDto;
import com.nec.biomatcher.webservices.UpdateUserFlagMode;

public class SyncUpdateJobRequestCreater {
	private String reqeustFileFullName;	
		
	private String eventId;
	private String externalId;
	private UpdateUserFlagMode updateUserFlagMode;   
	private List<Integer> binIdList;
	private String userFlags;
	
	private static Logger logger = LoggerFactory.getLogger(SyncUpdateJobRequestCreater.class);
	
	public SyncUpdateJobRequestCreater(String reqeustFileFullName) {
		this.reqeustFileFullName = reqeustFileFullName;
	}
	
	
	public SyncJobRequestDto buildSyncUpdateRequest() {		
		String callbackIp = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_IP);
		String callbackPort = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT);
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;		
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);				
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(3600000L);		
		List<BiometricEventSyncTypeDto>  syncList = new ArrayList<>();
		syncList.add(buildUpdateBiometricEventDto());
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;		
	}
	
	private UpdateBiometricEventUserFlagDto buildUpdateBiometricEventDto() {
		readDatFileData();
		UpdateBiometricEventUserFlagDto updateDto = new UpdateBiometricEventUserFlagDto();		
		updateDto.setEventId(eventId);
		updateDto.setExternalId(externalId);
		updateDto.setUpdateUserFlagMode(updateUserFlagMode);
		updateDto.getBinIdList().addAll(binIdList);
		updateDto.setUserFlags(userFlags);
		return updateDto;		
	}
	
	private void readDatFileData() {
		File templateFile = new File(reqeustFileFullName);
		if (!templateFile.exists() || !templateFile.isFile()) {
			logger.error("The template file is wrong. skip process...");			
		}		
	}
}
