package com.nec.biomatcher.client.JobCancel;

import java.util.Collections;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.request.creater.ExtractJobReqeustCreater;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.client.util.WsdlUtil;
import com.nec.biomatcher.webservices.BioJobStatus;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;

public class ExtractionJobCancelProcesser {
	private String extractionJobCancelInfo;
	private String reqeustFileFullName;	
	private Integer extractionJobCount;
	private Integer deleteCount;	
	private  CopyOnWriteArrayList<String> extJobList = new  CopyOnWriteArrayList<>();
	

	private static Logger logger = LoggerFactory.getLogger(ExtractionJobCancelProcesser.class);
	
	public ExtractionJobCancelProcesser(String extCacelInfo, String fullReqeustFilePath) {
		this.extractionJobCancelInfo = extCacelInfo;
		this.reqeustFileFullName = fullReqeustFilePath;			
	}
	
	public void processExtractionJobCanceling() {
		if (reqeustFileFullName == null && reqeustFileFullName.isEmpty()) {
			logger.warn("Reqeust file is null! skip...");
			return ;
		}
		if (extractionJobCancelInfo == null || extractionJobCancelInfo.isEmpty()) {
			logger.warn("extractionJobCancelInfo is empty! skip...");
			return;			
		}		
		extractionJobCount = Integer.parseInt(extractionJobCancelInfo.split(",")[0].split(":")[1]);
		deleteCount = Integer.parseInt(extractionJobCancelInfo.split(",")[1].split(":")[1]);
		
		ExtractJobRequestDto extractJobRequestDto = new ExtractJobRequestDto();
		try {
			BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			BioMatcherWebServiceInterface xmWebService2 = WsdlUtil.getXmWebService2();
			logger.info("xmWebService2 is null: {}",xmWebService2 == null);
			if (reqeustFileFullName.endsWith(".xml")) {
				JaxBUtil<ExtractJobRequestDto> jaxbUtil = new JaxBUtil<ExtractJobRequestDto>();				
				extractJobRequestDto = jaxbUtil.unmarshalFromFile(ExtractJobRequestDto.class, reqeustFileFullName);
			} else if (reqeustFileFullName.endsWith(".dat")) {				
				ExtractJobReqeustCreater creater = new ExtractJobReqeustCreater();
				extractJobRequestDto = creater.buildExtractJobRequest(reqeustFileFullName);
			} else {
				logger.warn("Request file is worng , it is not a xml or dat file. skip...");
			}
			
			for (int i = 0; i < extractionJobCount; i++) {
				String jobId = xmWebService.submitExtractionJob(extractJobRequestDto);
				extJobList.add(jobId);					
			}
			
			Collections.shuffle(extJobList);			 
						
			for (int i = 0;  i < deleteCount; i++) {
				//int deleteIdx = (getRandomUderDeleteCount(i + 1));
				String  deleteJobId = extJobList.get(i);
				logger.info("To be delte jobid: {}",deleteJobId);
				logger.info("Before delete, {} Satus is {} in {}", deleteJobId, xmWebService.getExtractionJobStatus(deleteJobId).name(), WsdlUtil.getWsdlUrl());				
				if (xmWebService != null) {
					xmWebService.deleteExtractionJob(deleteJobId);
					logger.info("Delete job {} access to {}", deleteJobId, WsdlUtil.getWsdlUrl());
					 String status1 = xmWebService.getExtractionJobStatus(deleteJobId).name();
					logger.info("After delete, {} Satus is {} in {}", deleteJobId, status1, WsdlUtil.getWsdlUrl());
					if (BioJobStatus.NOT_FOUND.name().equals(status1)) {
						logger.info("Extraction Job Id {} status is:{}",deleteJobId, status1);
						logger.info("Delete OK!!");					
					}	
					 
				}				
				if (xmWebService2 != null) {
					xmWebService2.deleteExtractionJob(deleteJobId);					
					logger.info("Delete job {} access to {}", deleteJobId, WsdlUtil.getWsdlUrl2());
					String status2 = xmWebService2.getExtractionJobStatus(deleteJobId).name();
					logger.info("After delete, {} Satus is {} in {}", deleteJobId, status2, WsdlUtil.getWsdlUrl2());
					if (BioJobStatus.NOT_FOUND.name().equals(status2)) {
						logger.info("Extraction Job Id {} status is:{}",deleteJobId, status2);
						logger.info("Delete OK!!");					
					}	
				}				
			}			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}		
	}
}
