package com.nec.biomatcher.client.priority;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.ExtractInputParameter;
import com.nec.biomatcher.webservices.ExtractInputPayloadDto;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;
import com.nec.biomatcher.webservices.FaceExtractInputImage;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.Image;
import com.nec.biomatcher.webservices.ImageFormat;
import com.nec.biomatcher.webservices.ImagePosition;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.TemplateExtractInputImage;

public class ExtractPriorityJobReqeustCreater {
	//private static final  Integer binIds[]  = {1};
	private  String dataFile = "face0.jpg";
	private static GenderEnum Gender = GenderEnum.M;
	private static Integer Yob = 1977;	
	private static String Race = "B";	
	private static String templateType = "TEMPLATE_TYPE_1";	
	
	private Integer priority;
	private Integer jobCount;
	
	public ExtractPriorityJobReqeustCreater(Integer priority, Integer jobCount, String templatePath) {		
		this.priority = priority;
		this.jobCount = jobCount;	
		this.dataFile = templatePath + "/" + dataFile;
	}	

	public List<ExtractJobRequestDto> createExtractJobRequest() {
		List<ExtractJobRequestDto> jobRequests = new ArrayList<>();
		for (int i = 0; i < jobCount; i++) {
			jobRequests.add(buildExtractJobRequest());	
		}		
		return jobRequests;
	}
	
	private ExtractJobRequestDto buildExtractJobRequest() {		
		long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(60);
		ExtractJobRequestDto extractJobRequestDto = new ExtractJobRequestDto();		
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;		
		extractJobRequestDto.setCallbackUrl(callbackUrl);
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<Integer> exPriority = objectFactory.createExtractJobRequestDtoPriority(priority);
		extractJobRequestDto.setPriority(exPriority);
		extractJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		extractJobRequestDto.setJobMode("live");
		ExtractInputPayloadDto extractInputPayloadDto = buildExtractInputPayloadDto();
		extractJobRequestDto.setExtractInputPayload(extractInputPayloadDto);
		return extractJobRequestDto;
	}

	private ExtractInputPayloadDto buildExtractInputPayloadDto() {		
		 ObjectFactory objectFactory = new ObjectFactory();
		ExtractInputPayloadDto epDto = new ExtractInputPayloadDto();
		JAXBElement<String> candidateId = objectFactory.createExtractInputPayloadDtoCandidateId("mysql_test");
		epDto.setCandidateId(candidateId);
		TemplateExtractInputImage templateImage = new TemplateExtractInputImage();	
		FaceExtractInputImage faceExtractInputImag = new FaceExtractInputImage();			
		Image faceImage = new Image();
		FileUtil fu = new FileUtil();
        byte[] imageRollData = fu.readImageFromFile("jpg", dataFile);      
        faceImage.setType(ImageFormat.JPEG);
        faceImage.setPosition(ImagePosition.FRONTAL_FACE);
        faceImage.setData(imageRollData);        
        faceExtractInputImag.setFaceImage(faceImage);
        
		ExtractInputParameter parameter = new ExtractInputParameter();
		parameter.setAlgorithmType(AlgorithmType.FACE_NEC_S_17);
		parameter.setModality(Modality.FACE);		
		faceExtractInputImag.getExtractionParameters().add(parameter);        
       
        MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
        metaInfoCommon.setGender(GenderEnum.M);
        JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(Yob);
        metaInfoCommon.setYob(yob);
        metaInfoCommon.setRace(Race);
        metaInfoCommon.setGender(Gender);       
        JAXBElement<MetaInfoCommon> mm = objectFactory.createExtractInputPayloadDtoMetaInfoCommon(metaInfoCommon);
        epDto.setMetaInfoCommon(mm); 

      templateImage.setExtractInputImage(faceExtractInputImag);
      templateImage.getTemplateTypes().add(templateType);
      epDto.getTemplateExtractInputImageList().add(templateImage);
      fu = null;
      return epDto;	
	}
}
