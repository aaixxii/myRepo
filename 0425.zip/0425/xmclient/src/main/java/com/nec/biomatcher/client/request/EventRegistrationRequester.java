package com.nec.biomatcher.client.request;

import static com.nec.biomatcher.client.common.XmClientConstants.JOB_RESULT_PATH_XML;
import static com.nec.biomatcher.client.common.XmClientConstants.SEARCH_JOB_TIMEOUT;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.client.request.creater.SyncInsertJobRequestCreater;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.client.util.WsdlUtil;
import com.nec.biomatcher.webservices.BioJobStatus;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.SyncJobRequestDto;
import com.nec.biomatcher.webservices.SyncJobResultDto;

public class EventRegistrationRequester {
	private String jobId;
	InsertBiometricEventDto insertBiometricEventDto;
	private String reqeustFileFullName;
	private long jobTimeOutLimit;
	private static Logger logger = LoggerFactory.getLogger(EventRegistrationRequester.class);
	
	public EventRegistrationRequester(String reqeustFileFullName) {
		this.reqeustFileFullName = reqeustFileFullName;		
	}
	
	public SyncJobResultDto submitSyncInsertJob() {
		if (reqeustFileFullName == null && reqeustFileFullName.isEmpty()) {
			logger.warn("Reqeust file is null! skip...");
			return null;
		}		
		SyncJobResultDto jobResults = null;
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		try {
			BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			if (reqeustFileFullName.endsWith(".xml")) {
				JaxBUtil<SyncJobRequestDto> jaxbUtil = new JaxBUtil<SyncJobRequestDto>();				
				syncJobRequestDto = jaxbUtil.unmarshalFromFile(SyncJobRequestDto.class, reqeustFileFullName);			
				try {
					this.jobTimeOutLimit = syncJobRequestDto.getJobTimeoutMill();
				} catch (Exception e) {
					this.jobTimeOutLimit = Long.parseLong(XmClientManager.getInstance().getValue(SEARCH_JOB_TIMEOUT));
				}
			} else if (reqeustFileFullName.endsWith(".dat")) {				
				SyncInsertJobRequestCreater creater = new SyncInsertJobRequestCreater();
				syncJobRequestDto = creater.buildSyncInsertRequest(reqeustFileFullName);
			} else {
				logger.warn("Request file is worng , it is not a xml or dat file. skip...");
			}			
			jobId = xmWebService.submitSyncJob(syncJobRequestDto);			
			long startTime = System.currentTimeMillis();
			XmClientManager.getTimesMap().put(jobId, Long.valueOf(startTime));
			jobResults = getSyncJobResult(System.currentTimeMillis());			
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}
		return jobResults;
	}
	
	public SyncJobResultDto getSyncJobResult(long startTime) {	
		SyncJobResultDto results = null;		
		try {
			BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			while (System.currentTimeMillis() - startTime <= jobTimeOutLimit) {
				results = xmWebService.getSyncJobResult(jobId);
				if (results != null && results.getStatus() == BioJobStatus.COMPLETED) {					
					logger.info("SearchJobResult jobId:{}", results.getJobId());
					logger.info("SearchJobResult status:{}", results.getStatus().name());
					break;
				}
			}
			long usedTime = System.currentTimeMillis() - startTime;
			if (usedTime > jobTimeOutLimit) {
				logger.warn("Get sync job result is timeout, jobId={}, useTime={}", jobId, usedTime);
			}		
			//PerformanceLogger.trace(EventRegistrationRequester.class.getSimpleName(), "submitSyncInsertRequest", jobId, null, usedTime);
			if (results != null) {
				String resultXmlPath = XmClientManager.getInstance().getValue(JOB_RESULT_PATH_XML);
				resultXmlPath = resultXmlPath + "/" + jobId + ".xml";
				JaxBUtil<SyncJobResultDto> jaxbUtil = new JaxBUtil<SyncJobResultDto>();
				jaxbUtil.marshalToFile(SyncJobResultDto.class, results, resultXmlPath);								
			} else {
				logger.warn("Job result is empty, skip save to file. jobId={}", jobId);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
		return results;
	}
}
