
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateUserFlagMode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="updateUserFlagMode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ASSIGN"/>
 *     &lt;enumeration value="UNASSIGN"/>
 *     &lt;enumeration value="OVERWRITE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "updateUserFlagMode")
@XmlEnum
public enum UpdateUserFlagMode {

    ASSIGN,
    UNASSIGN,
    OVERWRITE;

    public String value() {
        return name();
    }

    public static UpdateUserFlagMode fromValue(String v) {
        return valueOf(v);
    }

}
