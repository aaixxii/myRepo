package com.nec.biomatcher.client.priority;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.JAXBElement;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.MatchInputParameter;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.Modality;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.SearchItemInputPayloadDto;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchOptionsDto;
import com.nec.biomatcher.webservices.SearchRequestItemDto;

public class TIPriorityJobReqeustCreater {
	private static final  String FunctionId = "TI";
	private static final  Integer binIds[]  = {35};
	private String dataFile = "TEMPLATE_TYPE_35_0.dat";	
	
	private Integer priority;
	private Integer jobCount;
	
	String templateType = "TEMPLATE_TYPE_35";
	
	public TIPriorityJobReqeustCreater(Integer priority, Integer jobCount, String templatePath) {		
		this.priority = priority;
		this.jobCount = jobCount;
		this.dataFile = templatePath + "/" + dataFile;
	}
	
	public List<SearchJobRequestDto> createSeachJobRequest() {
		List<SearchJobRequestDto> jobRequests = new ArrayList<>();
		for (int i = 0; i < jobCount; i++) {
			SearchJobRequestDto searchRq =  buildSeachJobRequest();
			jobRequests.add(searchRq);
		}
		return jobRequests;		
	}
	public SearchJobRequestDto buildSeachJobRequest() {
		//URL url = Thread.currentThread().getContextClassLoader().getResource(dataFile);
		SearchJobRequestDto searchJobRequestDto = new SearchJobRequestDto();	
		String callbackUrl = "http://" + "192.168.22.118" + ":" + "5679";
		searchJobRequestDto.setCallbackUrl(callbackUrl);		
		ObjectFactory objectFactory = new ObjectFactory();		
		JAXBElement<Integer> rqPriority = objectFactory.createSearchJobRequestDtoPriority(priority);		
		searchJobRequestDto.setPriority(rqPriority);
		searchJobRequestDto.setJobTimeoutMill(3600000L);
		searchJobRequestDto.setJobMode("live");
		JAXBElement<String> functionId = objectFactory.createSearchJobRequestDtoSearchFunctionId(FunctionId);
		searchJobRequestDto.setSearchFunctionId(functionId);
		SearchRequestItemDto searchRequestItemDto = new SearchRequestItemDto();
		searchRequestItemDto.setSearchItemPayloadDto(buildSearchItemInputPayload(dataFile));
		searchRequestItemDto.getBinIdList().addAll(Arrays.asList(binIds));
		searchJobRequestDto.getSearchRequestItemList().add(searchRequestItemDto);
		return searchJobRequestDto;
	}

	public SearchItemInputPayloadDto buildSearchItemInputPayload(String templateFileName) {
		SearchItemInputPayloadDto searchItemInputPayloadDto = new SearchItemInputPayloadDto();
		searchItemInputPayloadDto.setFunctionId(FunctionId);
		searchItemInputPayloadDto.setTemplateType(templateType);
		searchItemInputPayloadDto.setMaxHitCount(10);
		searchItemInputPayloadDto.setMinScoreThreshold(1);		

		SearchOptionsDto searchOptions = new SearchOptionsDto();
		MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
//		metaInfoCommon.setGender(GenderEnum.F);
//		metaInfoCommon.setRace("1");
//		ObjectFactory objectFactory = new ObjectFactory();		
//		
//		JAXBElement<Long> jaxLong = objectFactory.createMetaInfoCommonRegionFlags(1L);
//		metaInfoCommon.setRegionFlags(jaxLong);
//		
//		JAXBElement<String> userFlags = objectFactory.createMetaInfoCommonUserFlags("false");
//		metaInfoCommon.setUserFlags(userFlags);
//		
//		JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(1);
//		metaInfoCommon.setYob(yob);
//		JAXBElement<Integer> yobRange = objectFactory.createMetaInfoCommonYobRange(1);
//		metaInfoCommon.setYobRange(yobRange);

		List<MatchInputParameter> matchInputParameterList = new ArrayList<MatchInputParameter>();
		MatchInputParameter mp = new MatchInputParameter();
		mp.setModality(Modality.FINGER);
		mp.setAlgorithmType(AlgorithmType.FINGER_CML);
		matchInputParameterList.add(mp);
		searchOptions.setMetaInfoCommon(metaInfoCommon);
		searchOptions.getMatchInputParameterList().addAll(matchInputParameterList);
		FileUtil fu = new FileUtil();
		byte[] templateData = fu.getDataFromFile(templateFileName);				
		searchItemInputPayloadDto.setSearchOptions(searchOptions);
		searchItemInputPayloadDto.setTemplateData(templateData);
		fu = null;
		return searchItemInputPayloadDto;
	}	

}
