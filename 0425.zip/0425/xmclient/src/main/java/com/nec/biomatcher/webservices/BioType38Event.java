
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType38Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType38Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="lowerRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="upperRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="lowerLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="upperLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="writerRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="writerLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType38Event", propOrder = {
    "lowerRight",
    "upperRight",
    "lowerLeft",
    "upperLeft",
    "writerRight",
    "writerLeft"
})
public class BioType38Event
    extends BioTemplateEvent
{

    protected BioPalmFeatureInfo lowerRight;
    protected BioPalmFeatureInfo upperRight;
    protected BioPalmFeatureInfo lowerLeft;
    protected BioPalmFeatureInfo upperLeft;
    protected BioPalmFeatureInfo writerRight;
    protected BioPalmFeatureInfo writerLeft;

    /**
     * Gets the value of the lowerRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getLowerRight() {
        return lowerRight;
    }

    /**
     * Sets the value of the lowerRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setLowerRight(BioPalmFeatureInfo value) {
        this.lowerRight = value;
    }

    /**
     * Gets the value of the upperRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getUpperRight() {
        return upperRight;
    }

    /**
     * Sets the value of the upperRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setUpperRight(BioPalmFeatureInfo value) {
        this.upperRight = value;
    }

    /**
     * Gets the value of the lowerLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getLowerLeft() {
        return lowerLeft;
    }

    /**
     * Sets the value of the lowerLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setLowerLeft(BioPalmFeatureInfo value) {
        this.lowerLeft = value;
    }

    /**
     * Gets the value of the upperLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getUpperLeft() {
        return upperLeft;
    }

    /**
     * Sets the value of the upperLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setUpperLeft(BioPalmFeatureInfo value) {
        this.upperLeft = value;
    }

    /**
     * Gets the value of the writerRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getWriterRight() {
        return writerRight;
    }

    /**
     * Sets the value of the writerRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setWriterRight(BioPalmFeatureInfo value) {
        this.writerRight = value;
    }

    /**
     * Gets the value of the writerLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getWriterLeft() {
        return writerLeft;
    }

    /**
     * Sets the value of the writerLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setWriterLeft(BioPalmFeatureInfo value) {
        this.writerLeft = value;
    }

}
