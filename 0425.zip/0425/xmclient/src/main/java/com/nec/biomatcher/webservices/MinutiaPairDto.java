
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for minutiaPairDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="minutiaPairDto">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *       &lt;/sequence>
 *       &lt;attribute name="probeMinutiaNumber" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="targetMinutiaNumber" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="similitude" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="probeDirection" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="probeX" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="probeY" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="targetDirection" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="targetX" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="targetY" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "minutiaPairDto")
public class MinutiaPairDto {

    @XmlAttribute
    protected Integer probeMinutiaNumber;
    @XmlAttribute
    protected Integer targetMinutiaNumber;
    @XmlAttribute(required = true)
    protected int similitude;
    @XmlAttribute
    protected Integer probeDirection;
    @XmlAttribute
    protected Integer probeX;
    @XmlAttribute
    protected Integer probeY;
    @XmlAttribute
    protected Integer targetDirection;
    @XmlAttribute
    protected Integer targetX;
    @XmlAttribute
    protected Integer targetY;

    /**
     * Gets the value of the probeMinutiaNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getProbeMinutiaNumber() {
        return probeMinutiaNumber;
    }

    /**
     * Sets the value of the probeMinutiaNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setProbeMinutiaNumber(Integer value) {
        this.probeMinutiaNumber = value;
    }

    /**
     * Gets the value of the targetMinutiaNumber property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTargetMinutiaNumber() {
        return targetMinutiaNumber;
    }

    /**
     * Sets the value of the targetMinutiaNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTargetMinutiaNumber(Integer value) {
        this.targetMinutiaNumber = value;
    }

    /**
     * Gets the value of the similitude property.
     * 
     */
    public int getSimilitude() {
        return similitude;
    }

    /**
     * Sets the value of the similitude property.
     * 
     */
    public void setSimilitude(int value) {
        this.similitude = value;
    }

    /**
     * Gets the value of the probeDirection property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getProbeDirection() {
        return probeDirection;
    }

    /**
     * Sets the value of the probeDirection property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setProbeDirection(Integer value) {
        this.probeDirection = value;
    }

    /**
     * Gets the value of the probeX property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getProbeX() {
        return probeX;
    }

    /**
     * Sets the value of the probeX property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setProbeX(Integer value) {
        this.probeX = value;
    }

    /**
     * Gets the value of the probeY property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getProbeY() {
        return probeY;
    }

    /**
     * Sets the value of the probeY property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setProbeY(Integer value) {
        this.probeY = value;
    }

    /**
     * Gets the value of the targetDirection property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTargetDirection() {
        return targetDirection;
    }

    /**
     * Sets the value of the targetDirection property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTargetDirection(Integer value) {
        this.targetDirection = value;
    }

    /**
     * Gets the value of the targetX property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTargetX() {
        return targetX;
    }

    /**
     * Sets the value of the targetX property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTargetX(Integer value) {
        this.targetX = value;
    }

    /**
     * Gets the value of the targetY property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTargetY() {
        return targetY;
    }

    /**
     * Sets the value of the targetY property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTargetY(Integer value) {
        this.targetY = value;
    }

}
