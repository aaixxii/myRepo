package com.nec.biomatcher.client.request;

import static com.nec.biomatcher.client.common.XmClientConstants.JOB_RESULT_PATH_XML;
import static com.nec.biomatcher.client.common.XmClientConstants.SEARCH_JOB_TIMEOUT;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.logger.PerformanceLogger;
import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.client.request.creater.SearchJobReqeustCreater;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.client.util.WsdlUtil;
import com.nec.biomatcher.webservices.BioJobStatus;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchJobResultDto;

public class SearchRequester implements Requester<SearchJobRequestDto,SearchJobResultDto>{
	private String jobId;		
	private long jobTimeOutLimit;
	private Integer priority;
	private static Logger logger = LoggerFactory.getLogger(SearchRequester.class);


	@Override
	public SearchJobResultDto submitJobRequest(String reqeustFileFullName) {
		SearchJobResultDto jobResuslts = null;
		if (reqeustFileFullName == null || reqeustFileFullName.isEmpty()) {
			logger.warn("Reqeust file is null! skip...");
			return null;
		}
		SearchJobReqeustCreater qc;
		SearchJobRequestDto searchJobRequest = null;
		try {
			BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			if (reqeustFileFullName.endsWith(".xml")) {
				JaxBUtil<SearchJobRequestDto> jaxbUtil = new JaxBUtil<SearchJobRequestDto>();
				searchJobRequest = jaxbUtil.unmarshalFromFile(SearchJobRequestDto.class, reqeustFileFullName);				
			} else if (reqeustFileFullName.endsWith(".dat")) {
				qc = new SearchJobReqeustCreater();
				searchJobRequest = qc.buildSeachJobRequest(reqeustFileFullName);
			} else {
				logger.warn("Request file is worng , it is not a xml or dat file. skip...");
			}			
			try {
				this.jobTimeOutLimit = searchJobRequest.getJobTimeoutMill();
			} catch (Exception e) {
				this.jobTimeOutLimit = Long.parseLong(XmClientManager.getInstance().getValue(SEARCH_JOB_TIMEOUT));
			}
			this.priority = searchJobRequest.getPriority().getValue();
			jobId = xmWebService.submitSearchJob(searchJobRequest);
			XmClientManager.putPriority(jobId, priority);
			long startTime = System.currentTimeMillis();
			XmClientManager.getTimesMap().put(jobId, Long.valueOf(startTime));
			jobResuslts = getJobResult(System.currentTimeMillis());
			qc = null;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
			return null;
		}
		return jobResuslts;
	}

	@Override
	public SearchJobResultDto getJobResult(long startTime) {
		SearchJobResultDto results = null;		
		try {
				BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			while (System.currentTimeMillis() - startTime <= jobTimeOutLimit) {
				results = xmWebService.getSearchJobResult(jobId);
				if (results != null  && results.getStatus() == BioJobStatus.COMPLETED) {					
					logger.info("SearchJobResult jobId:{}", results.getJobId());
					logger.info("SearchJobResult status:{}", results.getStatus().name());
					break;
				}				
			}			
			long usedTime = System.currentTimeMillis() - startTime;
			PerformanceLogger.trace(InquiryRequester.class.getSimpleName(), "submitInquiryRequest", jobId, null, this.priority, usedTime);
			if (results != null) {
				String resultXmlPath = XmClientManager.getInstance().getValue(JOB_RESULT_PATH_XML);
				resultXmlPath = resultXmlPath + "/" + jobId + ".xml";				
				JaxBUtil<SearchJobResultDto> jaxbUtil = new JaxBUtil<SearchJobResultDto>();
				jaxbUtil.marshalToFile(SearchJobResultDto.class, results, resultXmlPath);
				//Object[] excelData = buildDataForCallExcell(results, usedTime);
				//ExcelWriter ew = new ExcelWriter(jobId);
				//ew.prepareExcellData(excelData);				
			} else {
				logger.warn("Job result is empty, skip save to file. jobId={}", jobId);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
		return results;
	}


}
