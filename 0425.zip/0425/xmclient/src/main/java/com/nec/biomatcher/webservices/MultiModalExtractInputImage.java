
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for multiModalExtractInputImage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="multiModalExtractInputImage">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}extractInputImage">
 *       &lt;sequence>
 *         &lt;element name="faceExtractInputImage" type="{http://webservices.biomatcher.nec.com/}faceExtractInputImage" minOccurs="0"/>
 *         &lt;element name="irisExtractInputImage" type="{http://webservices.biomatcher.nec.com/}irisExtractInputImage" minOccurs="0"/>
 *         &lt;element name="fingerExtractInputImage" type="{http://webservices.biomatcher.nec.com/}fingerExtractInputImage" minOccurs="0"/>
 *         &lt;element name="palmExtractInputImage" type="{http://webservices.biomatcher.nec.com/}palmExtractInputImage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "multiModalExtractInputImage", propOrder = {
    "faceExtractInputImage",
    "irisExtractInputImage",
    "fingerExtractInputImage",
    "palmExtractInputImage"
})
public class MultiModalExtractInputImage
    extends ExtractInputImage
{

    protected FaceExtractInputImage faceExtractInputImage;
    protected IrisExtractInputImage irisExtractInputImage;
    protected FingerExtractInputImage fingerExtractInputImage;
    protected PalmExtractInputImage palmExtractInputImage;

    /**
     * Gets the value of the faceExtractInputImage property.
     * 
     * @return
     *     possible object is
     *     {@link FaceExtractInputImage }
     *     
     */
    public FaceExtractInputImage getFaceExtractInputImage() {
        return faceExtractInputImage;
    }

    /**
     * Sets the value of the faceExtractInputImage property.
     * 
     * @param value
     *     allowed object is
     *     {@link FaceExtractInputImage }
     *     
     */
    public void setFaceExtractInputImage(FaceExtractInputImage value) {
        this.faceExtractInputImage = value;
    }

    /**
     * Gets the value of the irisExtractInputImage property.
     * 
     * @return
     *     possible object is
     *     {@link IrisExtractInputImage }
     *     
     */
    public IrisExtractInputImage getIrisExtractInputImage() {
        return irisExtractInputImage;
    }

    /**
     * Sets the value of the irisExtractInputImage property.
     * 
     * @param value
     *     allowed object is
     *     {@link IrisExtractInputImage }
     *     
     */
    public void setIrisExtractInputImage(IrisExtractInputImage value) {
        this.irisExtractInputImage = value;
    }

    /**
     * Gets the value of the fingerExtractInputImage property.
     * 
     * @return
     *     possible object is
     *     {@link FingerExtractInputImage }
     *     
     */
    public FingerExtractInputImage getFingerExtractInputImage() {
        return fingerExtractInputImage;
    }

    /**
     * Sets the value of the fingerExtractInputImage property.
     * 
     * @param value
     *     allowed object is
     *     {@link FingerExtractInputImage }
     *     
     */
    public void setFingerExtractInputImage(FingerExtractInputImage value) {
        this.fingerExtractInputImage = value;
    }

    /**
     * Gets the value of the palmExtractInputImage property.
     * 
     * @return
     *     possible object is
     *     {@link PalmExtractInputImage }
     *     
     */
    public PalmExtractInputImage getPalmExtractInputImage() {
        return palmExtractInputImage;
    }

    /**
     * Sets the value of the palmExtractInputImage property.
     * 
     * @param value
     *     allowed object is
     *     {@link PalmExtractInputImage }
     *     
     */
    public void setPalmExtractInputImage(PalmExtractInputImage value) {
        this.palmExtractInputImage = value;
    }

}
