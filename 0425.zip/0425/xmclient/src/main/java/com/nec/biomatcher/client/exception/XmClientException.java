package com.nec.biomatcher.client.exception;

public class XmClientException extends RuntimeException {

	private static final long serialVersionUID = 4092967622896782047L;

	/**
	 * @param message
	 */
	public XmClientException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public XmClientException(String message, Throwable cause) {
		super(message, cause);
	}
}
