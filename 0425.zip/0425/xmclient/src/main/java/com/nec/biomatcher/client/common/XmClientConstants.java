package com.nec.biomatcher.client.common;

public class XmClientConstants {
	// wsdlUrlSampe="http://10.10.100.100:8080/bio-matcher-webservices/bioMatcherWebservice/bioMatcherWebService?wsdl";
	public static final String MEGHA_CONTEXT_NAME = "bio-matcher-webservices/";
	public static final String XM_SERVICE_NAME = "bioMatcherWebservice/";
	public static final String MEGHA_WSDL_PATTEN = "bioMatcherWebService?wsdl";
	public static final String WSDL_URL = "wsdlUrl";
	public static final String WSDL_URL2 = "wsdlUrl2";
	public static final String NAMESPACE_URL = "http://webservices.biomatcher.nec.com/";

	public static final String XM_SUBMIT_SEARCH_JOB = "submitSearchJob";
	public static final String XM_GET_SEARCH_JOB_STATUS = "getSearchJobStatus";
	public static final String XM_GET_SEARCH_JOB_RESULT = "getSearchJobResult";
	public static final String XM_DELETE_SEARCH_JOB = "deleteSearchJob";

	public static final String SERVER_ID = "serverId";
	public static final String SERVER_PORT = "serverPort";
	
	public static final String SERVER2_ID = "server2Id";
	public static final String SERVER2_PORT = "server2Port";

	public static final String CIRCLE_THREAD_CURRENET_COUNT = "circleThreadCurrentCount";
	public static final String ONE_CIRCLE_JOB_COUNT = "oneCircleJobCount";
	public static final String SEARCH_JOB_TIMEOUT = "searchJobTimeout";	
	public static final String EXTRACTION_JOB_TIMEOUT = "extractJobTimeout";
	public static final String VERIFY_JOB_TIMEOUT = "verifyJobTimeout";	
	public static final String CLIENT_CALLBACK_PORT = "clientCallbackPort";	
	public static final String CLIENT_CALLBACK_IP = "clientCallbackIP";
	public static final String ONE_BY_ONE = "oneByOne";
	public static final String PRIORITY_JOB = "priorityJob";
	public static final String SEARCH_JOB_CANCEL_INFO = "searchJobCancelInfo";
	public static final String EXTRACTION_JOB_CANCEL_INFO = "extractionJobCancelInfo";
	public static final String VERIFY_JOB_CANCEL_INFO = "verifyJobCancelInfo";
	public static final String MUILT_SYNC_JOB_INFO = "muiltSyncJobInfo";
	
	public static final String PROPERTY_FULL_NAME = "propertyFullName";	
	public static final String JOB_REQUEST_PATH = "jobReqeustPath";	
	public static final String JOB_TEMPLATES_PATH = "jobTemplatesPath";	
	public static final String JOB_RESULT_PATH_XML = "jobresultPathXml";
	public static final String JOB_RESULT_PATH_XLSX = "jobresultPathXlsx";
	public static final String CLINET_CALLBACK_PATH = "clientCallbackPath";
	
	public static final String SEARCH_JOB_START_WITH = "search";
	public static final String EXTRACT_JOB_START_WITH = "extract";
	public static final String VERIFY_JOB_START_WITH = "verify";
	public static final String SYNC_INSERT_START_WITH = "sync_insert";
	public static final String SYNC_DELETE_START_WITH = "sync_delete";
	public static final String SYNC_UPDATE_START_WITH = "sync_update";	
	
	public static final String SLASH = "/";
	
	public static final String PRIORITY_JOB_INFO_FIRST_SEPARATOR = ",";
	public static final String PRIORITY_JOB_INFO_SECOND_SEPARATOR = ":";
	
}
