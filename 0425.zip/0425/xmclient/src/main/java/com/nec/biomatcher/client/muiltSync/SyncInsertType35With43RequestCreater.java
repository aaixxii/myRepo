package com.nec.biomatcher.client.muiltSync;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_IP;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;
import static com.nec.biomatcher.client.common.XmClientConstants.JOB_TEMPLATES_PATH;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.BioFeType;
import com.nec.biomatcher.webservices.BioFingerFeatureInfo;
import com.nec.biomatcher.webservices.BioTemplateEvent;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType35Event;
import com.nec.biomatcher.webservices.BioType43Event;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.InsertTemplateInfo;
import com.nec.biomatcher.webservices.PatternType;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncInsertType35With43RequestCreater {
	Random rnd = new Random();	
	private static String templateType35 = "TEMPLATE_TYPE_35";	
	private static String templateType43 = "TEMPLATE_TYPE_43";
	
	private static GenderEnum gender = GenderEnum.M;
	private static Integer yob = 1977;
	private static char race = 'B';
	private static String regionFlags = "32";
	private static String userFlag = "aaaaaaaa";
	private static long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);	
	
	private String  dataFilePath;
	
	
	public SyncInsertType35With43RequestCreater() {
		this.dataFilePath = XmClientManager.getInstance().getValue(JOB_TEMPLATES_PATH);
		dataFilePath = dataFilePath.endsWith("/") ? dataFilePath : dataFilePath + "/";		
	}
	
	public void buildSyncUpdateRequest(String extId, String eventId,  String[] templateType) throws Exception {
		SyncJobRequestDto insertRequest = buildSyncInsertRequest(extId, eventId, templateType);
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		 jaxb.marshalToFile(SyncJobRequestDto.class, insertRequest,
				 dataFilePath + "sync_insert_request_35_43.xml");		
		System.out.println("OKOKOK");
	}

	public SyncJobRequestDto buildSyncInsertRequest(String extId, String eventId,  String[] templateType) throws Exception {
		String callbackIp = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_IP);
		String callbackPort = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT);
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		
		List<BiometricEventSyncTypeDto> syncList = new ArrayList<>();
		InsertBiometricEventDto insertBiometricEventDto = new InsertBiometricEventDto();
		for (int i = 0; i < templateType.length; i++) {
			insertBiometricEventDto.getInsertTemplateInfoList().add(buildTemplateInsertTemplateInfo(extId, eventId, templateType[i]));
		}		
		syncList.add(insertBiometricEventDto);
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;
	}
	
	private InsertTemplateInfo buildTemplateInsertTemplateInfo(String extId, String eventId,  String templateType) {
		InsertTemplateInfo insertTemplateInfo = new InsertTemplateInfo();		
		insertTemplateInfo.setBinId(Integer.valueOf(templateType.substring(templateType.length() -2 , templateType.length())));
		FileUtil fu = new FileUtil();
		if (templateType.equals(templateType35)) {			
			insertTemplateInfo.setBinId(35);
			insertTemplateInfo.setTemplateData(fu.getDataFromFile(dataFilePath + "capsule_type_35.bin"));
		} else if (templateType.equals(templateType43)){
			insertTemplateInfo.setBinId(43);
			insertTemplateInfo.setTemplateData(fu.getDataFromFile(dataFilePath + "capsule_type_43.bin"));	
		}	
		insertTemplateInfo.setTemplateType(templateType);
		BioTemplatePayload  payload = new BioTemplatePayload();
		BioTemplateHeader header = new BioTemplateHeader();
		header.setExternalId(extId);
		header.setGender(gender);	
		header.setRace((byte)(race));
		header.setYob(yob.shortValue());
		header.setUserFlags(userFlag.getBytes());
		header.setRegionFlags(regionFlags.getBytes());
		payload.setTemplateHeader(header);	
		payload.getEvents().add(buildTemplateEvent(eventId, templateType));
		insertTemplateInfo.setTemplatePayload(payload);		
		return insertTemplateInfo;		
	}
	private BioTemplateEvent buildTemplateEvent(String eventId, String templateType) {
		BioTemplateEvent bioTemplateEvent =null;
		FileUtil fu = new FileUtil();
		if (templateType.equals(templateType35)) {
			BioType35Event  ev35 = new BioType35Event();			
			ev35.setEventId(eventId);	
			ev35.setIsRolledFlag(true);			
			byte[] featureData = fu.getDataFromFile(dataFilePath + "feature_type_35.bin");
			ev35.setCmlFeatureData(featureData);
			bioTemplateEvent = ev35;
		} else if (templateType.equals(templateType43)){
			BioType43Event ev43 = new BioType43Event();
			ev43.setEventId(eventId);
			byte[] featureData = fu.getDataFromFile(dataFilePath + "feature_type_43.bin");
			BioFingerFeatureInfo bf = new BioFingerFeatureInfo();
			bf.setFeatureData(featureData);
			bf.setFingerPosition(1);
			bf.setPrimaryPatternType(PatternType.L);
			ev43.setFeType(BioFeType.ELFT);
			ev43.setAlgorithmType(AlgorithmType.FINGER_LFML);
			ev43.getFingerInfoList().add(bf);
			bioTemplateEvent = ev43;
		}
		return bioTemplateEvent;
	}
}
