
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for verifyRawScoreDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="verifyRawScoreDto">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="score" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="algorithmType" type="{http://webservices.biomatcher.nec.com/}algorithmType" minOccurs="0"/>
 *         &lt;element name="probePosition" type="{http://webservices.biomatcher.nec.com/}imagePosition" minOccurs="0"/>
 *         &lt;element name="position" type="{http://webservices.biomatcher.nec.com/}imagePosition" minOccurs="0"/>
 *         &lt;element name="probeMinutiaDataIndex" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="targetMinutiaDataIndex" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="quality" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="probeMatchedAreaCenter" type="{http://webservices.biomatcher.nec.com/}pointDto" minOccurs="0"/>
 *         &lt;element name="targetMatchedAreaCenter" type="{http://webservices.biomatcher.nec.com/}pointDto" minOccurs="0"/>
 *         &lt;element name="minutiaPairList" type="{http://webservices.biomatcher.nec.com/}minutiaPairDto" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "verifyRawScoreDto", propOrder = {
    "score",
    "algorithmType",
    "probePosition",
    "position",
    "probeMinutiaDataIndex",
    "targetMinutiaDataIndex",
    "quality",
    "probeMatchedAreaCenter",
    "targetMatchedAreaCenter",
    "minutiaPairList"
})
public class VerifyRawScoreDto {

    protected Integer score;
    protected AlgorithmType algorithmType;
    protected ImagePosition probePosition;
    protected ImagePosition position;
    protected Integer probeMinutiaDataIndex;
    protected Integer targetMinutiaDataIndex;
    protected Integer quality;
    protected PointDto probeMatchedAreaCenter;
    protected PointDto targetMatchedAreaCenter;
    @XmlElement(nillable = true)
    protected List<MinutiaPairDto> minutiaPairList;

    /**
     * Gets the value of the score property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getScore() {
        return score;
    }

    /**
     * Sets the value of the score property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setScore(Integer value) {
        this.score = value;
    }

    /**
     * Gets the value of the algorithmType property.
     * 
     * @return
     *     possible object is
     *     {@link AlgorithmType }
     *     
     */
    public AlgorithmType getAlgorithmType() {
        return algorithmType;
    }

    /**
     * Sets the value of the algorithmType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlgorithmType }
     *     
     */
    public void setAlgorithmType(AlgorithmType value) {
        this.algorithmType = value;
    }

    /**
     * Gets the value of the probePosition property.
     * 
     * @return
     *     possible object is
     *     {@link ImagePosition }
     *     
     */
    public ImagePosition getProbePosition() {
        return probePosition;
    }

    /**
     * Sets the value of the probePosition property.
     * 
     * @param value
     *     allowed object is
     *     {@link ImagePosition }
     *     
     */
    public void setProbePosition(ImagePosition value) {
        this.probePosition = value;
    }

    /**
     * Gets the value of the position property.
     * 
     * @return
     *     possible object is
     *     {@link ImagePosition }
     *     
     */
    public ImagePosition getPosition() {
        return position;
    }

    /**
     * Sets the value of the position property.
     * 
     * @param value
     *     allowed object is
     *     {@link ImagePosition }
     *     
     */
    public void setPosition(ImagePosition value) {
        this.position = value;
    }

    /**
     * Gets the value of the probeMinutiaDataIndex property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getProbeMinutiaDataIndex() {
        return probeMinutiaDataIndex;
    }

    /**
     * Sets the value of the probeMinutiaDataIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setProbeMinutiaDataIndex(Integer value) {
        this.probeMinutiaDataIndex = value;
    }

    /**
     * Gets the value of the targetMinutiaDataIndex property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTargetMinutiaDataIndex() {
        return targetMinutiaDataIndex;
    }

    /**
     * Sets the value of the targetMinutiaDataIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTargetMinutiaDataIndex(Integer value) {
        this.targetMinutiaDataIndex = value;
    }

    /**
     * Gets the value of the quality property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQuality() {
        return quality;
    }

    /**
     * Sets the value of the quality property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQuality(Integer value) {
        this.quality = value;
    }

    /**
     * Gets the value of the probeMatchedAreaCenter property.
     * 
     * @return
     *     possible object is
     *     {@link PointDto }
     *     
     */
    public PointDto getProbeMatchedAreaCenter() {
        return probeMatchedAreaCenter;
    }

    /**
     * Sets the value of the probeMatchedAreaCenter property.
     * 
     * @param value
     *     allowed object is
     *     {@link PointDto }
     *     
     */
    public void setProbeMatchedAreaCenter(PointDto value) {
        this.probeMatchedAreaCenter = value;
    }

    /**
     * Gets the value of the targetMatchedAreaCenter property.
     * 
     * @return
     *     possible object is
     *     {@link PointDto }
     *     
     */
    public PointDto getTargetMatchedAreaCenter() {
        return targetMatchedAreaCenter;
    }

    /**
     * Sets the value of the targetMatchedAreaCenter property.
     * 
     * @param value
     *     allowed object is
     *     {@link PointDto }
     *     
     */
    public void setTargetMatchedAreaCenter(PointDto value) {
        this.targetMatchedAreaCenter = value;
    }

    /**
     * Gets the value of the minutiaPairList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the minutiaPairList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMinutiaPairList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MinutiaPairDto }
     * 
     * 
     */
    public List<MinutiaPairDto> getMinutiaPairList() {
        if (minutiaPairList == null) {
            minutiaPairList = new ArrayList<MinutiaPairDto>();
        }
        return this.minutiaPairList;
    }

}
