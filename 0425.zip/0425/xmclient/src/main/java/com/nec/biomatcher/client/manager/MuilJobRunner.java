package com.nec.biomatcher.client.manager;

public class MuilJobRunner {

}
