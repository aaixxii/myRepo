
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType5Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType5Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="quality" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="faceNFV3FeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType5Event", propOrder = {
    "quality",
    "faceNFV3FeatureData"
})
public class BioType5Event
    extends BioTemplateEvent
{

    protected Integer quality;
    protected byte[] faceNFV3FeatureData;

    /**
     * Gets the value of the quality property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQuality() {
        return quality;
    }

    /**
     * Sets the value of the quality property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQuality(Integer value) {
        this.quality = value;
    }

    /**
     * Gets the value of the faceNFV3FeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getFaceNFV3FeatureData() {
        return faceNFV3FeatureData;
    }

    /**
     * Sets the value of the faceNFV3FeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setFaceNFV3FeatureData(byte[] value) {
        this.faceNFV3FeatureData = ((byte[]) value);
    }

}
