package com.nec.biomatcher.client.muiltSync;

import static com.nec.biomatcher.client.common.XmClientConstants.JOB_RESULT_PATH_XML;
import static com.nec.biomatcher.client.common.XmClientConstants.SEARCH_JOB_TIMEOUT;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.client.util.WsdlUtil;
import com.nec.biomatcher.webservices.BioJobStatus;
import com.nec.biomatcher.webservices.BioMatcherWebServiceInterface;
import com.nec.biomatcher.webservices.SyncJobRequestDto;
import com.nec.biomatcher.webservices.SyncJobResultDto;

public class MuiltSyncJobProcesser {
	String muitSyncJobInfo;

	private static Logger logger = LoggerFactory.getLogger(MuiltSyncJobProcesser.class);

	public MuiltSyncJobProcesser(String muitSyncJobInfo) {
		this.muitSyncJobInfo = muitSyncJobInfo;
	}

	public void parseMuiltSyncJobInfo() {
		// jobcount:capseuleDataCount,capsule_type_35.bin:featureDataCount,feature_type_35.bin
		int jobCount = Integer.valueOf(muitSyncJobInfo.split(":")[0]);
		String[] externals = new String[jobCount];
		String[] events = new String[jobCount];
		String[] templateTypes = { "TEMPLATE_TYPE_35", "TEMPLATE_TYPE_43" };
		for (int i = 0; i < jobCount; i++) {
			externals[i] = "external" + i;
			events[i] = "event" + i;
		}
		SyncInsertType35With43RequestCreater creater = new SyncInsertType35With43RequestCreater();
		for (int i = 0; i < jobCount; i++) {			
			try {
				SyncJobRequestDto syncJobRequest = creater.buildSyncInsertRequest(externals[i], events[i], templateTypes);						
				Runnable runner = () -> {
					BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
					String jobId = xmWebService.submitSyncJob(syncJobRequest);
					long startTime = System.currentTimeMillis();
					XmClientManager.getTimesMap().put(jobId, Long.valueOf(startTime));
					getSyncJobResult(System.currentTimeMillis(), jobId);
				};
				XmClientManager.getInstance().commitJob(runner);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	private void getSyncJobResult(long startTime, String jobId) {
		SyncJobResultDto results = null;
		long jobTimeOutLimit = Long.parseLong(XmClientManager.getInstance().getValue(SEARCH_JOB_TIMEOUT));
		try {
			BioMatcherWebServiceInterface xmWebService = WsdlUtil.getXmWebService();
			while (System.currentTimeMillis() - startTime <= jobTimeOutLimit) {
				results = xmWebService.getSyncJobResult(jobId);
				if (results != null && results.getStatus() == BioJobStatus.COMPLETED) {
					logger.info("SearchJobResult jobId:{}", results.getJobId());
					logger.info("SearchJobResult status:{}", results.getStatus().name());
					break;
				}
			}
			long usedTime = System.currentTimeMillis() - startTime;
			if (usedTime > jobTimeOutLimit) {
				logger.warn("Get sync job result is timeout, jobId={}, useTime={}", jobId, usedTime);
			}
			// PerformanceLogger.trace(EventRegistrationRequester.class.getSimpleName(),
			// "submitSyncInsertRequest", jobId, null, usedTime);
			if (results != null) {
				String resultXmlPath = XmClientManager.getInstance().getValue(JOB_RESULT_PATH_XML);
				resultXmlPath = resultXmlPath + "/" + jobId + ".xml";
				JaxBUtil<SyncJobResultDto> jaxbUtil = new JaxBUtil<SyncJobResultDto>();
				jaxbUtil.marshalToFile(SyncJobResultDto.class, results, resultXmlPath);
			} else {
				logger.warn("Job result is empty, skip save to file. jobId={}", jobId);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
}
