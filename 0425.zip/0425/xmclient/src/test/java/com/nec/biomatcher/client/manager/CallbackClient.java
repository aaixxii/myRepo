package com.nec.biomatcher.client.manager;

import java.io.IOException;
import java.net.Socket;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.nec.biomatcher.webservices.BioJobStatus;
import com.nec.biomatcher.webservices.ErrorMessageDto;
import com.nec.biomatcher.webservices.SyncJobResultDto;

public class CallbackClient {
	//private Socket cSocket;

	public CallbackClient() {
//		try {
//			cSocket = new Socket("127.0.0.1", 1234);
//		} catch (IOException e) {
//			System.out.println("Server is not start, try....");
//		}
	}

	public static void main(String[] args) {
		CallbackClient client = new CallbackClient();
		try {
			for (int i = 0; i < 5; i++) {
				client.sendXmlMegToServer(String.valueOf(1000 * (i + 1)));
				System.out.println("Sucess send synJobResults to Server!");
			}

		} catch (Exception e) {
			System.out.println("Failed to send synJobResults to Server!");
			e.printStackTrace();
		}

	}

	private void sendXmlMegToServer(String jobId)
			throws DatatypeConfigurationException, JAXBException, IOException, InterruptedException {
		Socket cSocket = null;
		while (cSocket == null) {
			try {
				cSocket = new Socket("127.0.0.1", 1234);
			} catch (IOException e) {
				System.out.println("Server is not start, try....");
			}
		}

		SyncJobResultDto syncJobResultDto = new SyncJobResultDto();
		syncJobResultDto.setJobId(jobId);
		syncJobResultDto.setStatus(BioJobStatus.COMPLETED);
		ErrorMessageDto error = new ErrorMessageDto();
		error.setErrorCode("testError");
		error.setErrorMessage("test error message");
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(new Date());
		XMLGregorianCalendar date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		error.setErrorDateTime(date);
		syncJobResultDto.getErrorList().add(error);
		// JaxBUtil<SyncJobResultDto> jaxb = new JaxBUtil<SyncJobResultDto>();
		JAXBContext jaxbContext = JAXBContext.newInstance(SyncJobResultDto.class);
		Marshaller marshal = jaxbContext.createMarshaller();
		marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshal.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
		marshal.setProperty(Marshaller.JAXB_FRAGMENT, false);
		marshal.marshal(syncJobResultDto, cSocket.getOutputStream());
		//Thread.currentThread();
		//Thread.sleep(100);
	}
}
