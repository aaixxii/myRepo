package com.nec.biomatcher.client.request;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;

import com.nec.biomatcher.webservices.ExtractInputPayloadDto;
import com.nec.biomatcher.webservices.ExtractJobRequestDto;
import com.nec.biomatcher.webservices.FingerExtractInputImage;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.Image;
import com.nec.biomatcher.webservices.ImageFormat;
import com.nec.biomatcher.webservices.ImagePosition;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.TemplateExtractInputImage;

public class ExtractJobReqeustCreater {		
	private final static String callbackUrl = "http://192.168.111.1:5678";
	private String reqeustFullName;	

	public ExtractJobReqeustCreater(String reqeustFullName) {
		this.reqeustFullName = reqeustFullName;
	}

	public ExtractJobRequestDto buildExtractJobRequest() {
		long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(3600000);
		ExtractJobRequestDto extractJobRequestDto = new ExtractJobRequestDto();	
		ExtractInputPayloadDto extractInputPayloadDto = buildExtractInputPayloadDto();
		extractJobRequestDto.setExtractInputPayload(extractInputPayloadDto);
		extractJobRequestDto.setCallbackUrl(callbackUrl);
		// ExtractJobRequestDto.setCallbackUrl("http://192.168.22.118:8888");
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<Integer> priority = objectFactory.createExtractJobRequestDtoPriority(10);
		extractJobRequestDto.setPriority(priority);
		extractJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		extractJobRequestDto.setJobMode("live");

		return extractJobRequestDto;
	}

	private ExtractInputPayloadDto buildExtractInputPayloadDto() {
		ExtractInputPayloadDto epDto = new ExtractInputPayloadDto();		
		TemplateExtractInputImage templateImage = new TemplateExtractInputImage();
		//ObjectFactory objectFactory = new ObjectFactory();
		FingerExtractInputImage fingerExtractInputImag = new FingerExtractInputImage();
		//List<Image> images = new ArrayList<>();		
		Image rollImage = new Image();
        byte[] imageRollData = getTemplateData();      
        rollImage.setType(ImageFormat.WSQ);
        rollImage.setPosition(ImagePosition.ROLL_RRING);
        rollImage.setData(imageRollData);        
        fingerExtractInputImag.getImages().add(rollImage);
        
        ObjectFactory objectFactory = new ObjectFactory();
        MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
        metaInfoCommon.setGender(GenderEnum.M);
        JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(1997);
        metaInfoCommon.setYob(yob);
        JAXBElement<MetaInfoCommon> mm = objectFactory.createExtractInputPayloadDtoMetaInfoCommon(metaInfoCommon);
        epDto.setMetaInfoCommon(mm);
        
        
//  	  Image slapImage = new Image();
//      byte[] imageSlapData = getTemplateData("SLAP_12.wsq");      
//      rollImage.setType(ImageFormat.WSQ);
//      rollImage.setPosition(ImagePosition.SLAP_RRING);
//      rollImage.setData(imageSlapData); 
//      images.add(slapImage);
     
      fingerExtractInputImag.getImages().add(rollImage);
      //fingerExtractInputImag.getImages().add(slapImage);  
  
      templateImage.setExtractInputImage(fingerExtractInputImag);
      templateImage.getTemplateTypes().add("TEMPLATE_TYPE_35");
      epDto.getTemplateExtractInputImageList().add(templateImage);
      return epDto;
	
	}



	private byte[] getTemplateData() {
		File requestData = new File(this.reqeustFullName);
		if (requestData == null || !requestData.exists()) {
			System.out.println("The template data file is not found!");
			return null;
		}
		FileInputStream input = null;
		byte[] temp = null;
		try {
			input = new FileInputStream(requestData);
			temp = new byte[input.available()];
			input.read(temp);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			requestData = null;
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return temp;
	}
}
