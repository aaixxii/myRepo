package com.nec.biomatcher.client.manager;

import org.junit.Ignore;
import org.junit.Test;

public class XmClientRunnerTest {

	@Test
	@Ignore
	public void testRun() {		
		XmClientManager manager = XmClientManager.getInstance();
		manager.getAllProperties();		
		XmClientRunner.getInstance().run();
	}
}
