package com.nec.aim.audio.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nec.aim.audio.service.FileUtil;

@Controller
public class DownloadController extends HttpServlet {
	
	 @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
	                      throws ServletException, IOException {
	        
	    }

	private static final long serialVersionUID = -5673372086651421607L;

//	@Autowired
//	    private ServletContext servletContext;
	 
	 @Value("${audio.file.path}")
	    private String audioFilePath;	    
	   
	    @GetMapping("/download/Wav/")
	    public void downloadFile(HttpServletResponse resonse,
	            @RequestParam String fileName) throws IOException {	
	    	
	    	URL url = Thread.currentThread().getContextClassLoader().getResource("wav/" + fileName);
	    	File file = new File(url.getPath());	 
	       
	        resonse.setContentType("audio/mpeg");
	 
	        // Content-Disposition
	        resonse.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName());
	 
	        // Content-Length
	        resonse.setContentLength((int) file.length());
	 
	        BufferedInputStream inStream = new BufferedInputStream(new FileInputStream(file));
	        BufferedOutputStream outStream = new BufferedOutputStream(resonse.getOutputStream());
	 
	        byte[] buffer = new byte[1024 * 4 ];
	        int bytesRead = 0;
	        while ((bytesRead = inStream.read(buffer)) != -1) {
	            outStream.write(buffer, 0, bytesRead);
	        }
	        outStream.flush();
	        inStream.close();
	        buffer = null;
	    }
	    
	    @GetMapping("/getWavData")
	    public void getImageAsByteArray( @RequestParam String fileName, HttpServletResponse response) throws IOException {
	    	URL url = Thread.currentThread().getContextClassLoader().getResource("wav/" + fileName);
	    	// FileInputStream inputStream = new FileInputStream(url.getPath());
	        //InputStream in = servletContext.getResourceAsStream(url.getPath());
	        response.setContentType("audio/mpeg");
	        //IOUtils.copy(inputStream, response.getOutputStream());
	        OutputStream outStream = response.getOutputStream();
	       FileUtil utl = new FileUtil();
	       byte[] resutl = utl.getDataFromFile(url.getPath());
	       outStream.write(resutl);
	        System.out.print("OKOKOK");
	    }
}
