## Spring Data Cassandra

### Relevant Articles:
- [Introduction to Spring Data Cassandra](http://www.baeldung.com/spring-data-cassandra-tutorial)
- [Using the CassandraTemplate from Spring Data](http://www.baeldung.com/spring-data-cassandratemplate-cqltemplate)

### Build the Project with Tests Running
```
mvn clean install
```

### Run Tests Directly
```
mvn test
```

