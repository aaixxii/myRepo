package com.nec.aim.uid.dmwebapp.segments;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

import com.nec.aim.uid.dmwebapp.exception.DataAdapterException;

public class TemplateHeadBuilder {
	
	public  static byte[] prependHeader(long templateId, byte[] templateData, String externalId, int eventId) {
		if(templateId < 0L) {
			throw new IllegalArgumentException(
					"TemplateId must be positive long, it's " + templateId);
		}
		if (templateData == null) {
			throw new IllegalArgumentException(
					"Attempting to prepend header onto null template");
		}
		if(externalId == null) {
			throw new IllegalArgumentException("externalId is null!");
		}
		byte[] bytesOfExtId = externalId.getBytes(StandardCharsets.UTF_8);		
		int writeTtotalTemplateSize = DmConstants.SIZE_TEMPLATE_HEADER_CHECKSUM + templateData.length ;
		int totalTemplateSize = DmConstants.SIZE_TEMPLATE_HEADER; //for uid this must same to writeTtotalTemplateSize
		byte[] byteTempateArr = new byte[writeTtotalTemplateSize]; 
		ByteBuffer byteTemplate = ByteBuffer.wrap(byteTempateArr);
		byte[] emptyOneByte = new byte[1];
		byteTemplate.position(0);	
		byteTemplate.put(emptyOneByte); //checkSum
		byteTemplate.putInt(totalTemplateSize);
		byteTemplate.putLong(templateId);
		byteTemplate.put((byte)0); // delete flag
		byteTemplate.put(bytesOfExtId); 
		int blankExtIdSize = DmConstants.SIZE_EXTERNAL_ID - bytesOfExtId.length;			
		if (blankExtIdSize > 0) {				
			byteTemplate.put(new byte[blankExtIdSize]); 
		}
		if (eventId > 0)  {
			byteTemplate.putInt(eventId);
		} else {
			byteTemplate.put(new byte[DmConstants.SIZE_EVENT_ID]);
		}
		byteTemplate.put(templateData);	
		return byteTempateArr;			
	}
	
	public  static byte[] prependHeaderWithCheckSum(long templateId, byte[] templateData, String externalId, int eventId, String byteCheckSum) {
		if(templateId < 0L) {
			throw new IllegalArgumentException(
					"TemplateId must be positive long, it's " + templateId);
		}
		if (templateData == null) {
			throw new IllegalArgumentException(
					"Attempting to prepend header onto null template");
		}
		if(externalId == null) {
			throw new IllegalArgumentException("externalId is null!");
		}
		byte byteValueCheckSum = Byte.valueOf(byteCheckSum);
		byte[] bytesOfExtId = externalId.getBytes(StandardCharsets.UTF_8);		
		int writeTtotalTemplateSize = DmConstants.SIZE_TEMPLATE_HEADER_CHECKSUM + templateData.length ;
		int totalTemplateSize = DmConstants.SIZE_TEMPLATE_HEADER; //for uid this must same to writeTtotalTemplateSize
		byte[] byteTempateArr = new byte[writeTtotalTemplateSize]; 
		ByteBuffer byteTemplate = ByteBuffer.wrap(byteTempateArr);	
		byteTemplate.position(0);	
		byteTemplate.put(byteValueCheckSum); //checkSum
		byteTemplate.putInt(totalTemplateSize);
		byteTemplate.putLong(templateId);
		byteTemplate.put((byte)0); // delete flag
		byteTemplate.put(bytesOfExtId); 
		int blankExtIdSize = DmConstants.SIZE_EXTERNAL_ID - bytesOfExtId.length;			
		if (blankExtIdSize > 0) {				
			byteTemplate.put(new byte[blankExtIdSize]); 
		}
		if (eventId > 0)  {
			byteTemplate.putInt(eventId);
		} else {
			byteTemplate.put(new byte[DmConstants.SIZE_EVENT_ID]);
		}
		byteTemplate.put(templateData);	
		return byteTempateArr;			
	}
	
	

	public static byte[] prependHeaderOld(long templateId, byte[] templateData, String externalId, int eventId) {
		if(templateId <= 0L) {
			throw new IllegalArgumentException(
					"TemplateId must be positive long, it's " + templateId);
		}
		if (templateData == null) {
			throw new IllegalArgumentException(
					"Attempting to prepend header onto null template");
		}
		if(externalId == null) {
			throw new IllegalArgumentException("externalId is null!");
		}
		if(eventId < 0) {
			throw new IllegalArgumentException(
					"EventId must be positive long, it's " + eventId);
		}
		
		byte[] bytesOfExtId = externalId.getBytes();
		if(DmConstants.SIZE_EXTERNAL_ID < bytesOfExtId.length) {
			throw new IllegalArgumentException(
					"Max length of External ID is " + DmConstants.SIZE_EXTERNAL_ID 
					+ ", it's " + externalId.length());
		}
		try {
			int templateSize = DmConstants.SIZE_TEMPLATE_HEADER_CHECKSUM + templateData.length ;
			ByteArrayOutputStream bos = new ByteArrayOutputStream(
					templateSize);
			DataOutputStream dos = new DataOutputStream(bos);
			dos.writeByte(0); // leave space for checksum			
			dos.writeInt(templateSize);
			dos.writeLong(templateId);
			dos.writeByte(0); // delete flag
			dos.write(bytesOfExtId);
			int blankSize = DmConstants.SIZE_EXTERNAL_ID - bytesOfExtId.length;
			if(0 < blankSize) {
				byte[] blankData = new byte[blankSize];
				dos.write(blankData);
			}
			dos.writeInt(eventId);
			dos.write(templateData);
			dos.flush();
			byte[] templateDataWithHeader = bos.toByteArray();
			// checksum should not count itself (1-byte offset)
			templateDataWithHeader[0] = TemplateHeadBuilder.getCheckSum(templateDataWithHeader, 1);
			return templateDataWithHeader;
		} catch (IOException e) {
			throw new DataAdapterException(e);
		}
	}

	public static void validateChecksum(long templateId, byte[] templateData,
			int eventId, String externalId, byte givenChecksum) {
		byte[] header = prependHeader(templateId, templateData, externalId, eventId);
		byte calculatedChecksum = header[0];
		if (givenChecksum != calculatedChecksum) {
			throw new DataAdapterException("Calculated checksum '"
					+ calculatedChecksum
					+ "' does not match given checksum '" + givenChecksum
					+ "' for template " + templateId);
		}
	}

	public static byte getCheckSum(byte[] data) {
		return getCheckSum(data, 0);
	}

	
	public static byte getCheckSum(byte[] data, int offset) {
		byte result = 0;
		for (int i = offset; i < data.length; i++) {
			result ^= data[i];
		}
		return result;
	}

}
