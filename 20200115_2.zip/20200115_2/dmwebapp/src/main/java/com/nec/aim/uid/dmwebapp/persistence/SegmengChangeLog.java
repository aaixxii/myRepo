package com.nec.aim.uid.dmwebapp.persistence;

import java.io.Serializable;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Table(value = "segment_change_log")
public class SegmengChangeLog implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -1468372533905085999L;

	//@PrimaryKeyColumn(name="seg_change_id", ordinal = 0, type = PrimaryKeyType.PARTITIONED, ordering = Ordering.DESCENDING) 
	@PrimaryKeyColumn(name="seg_change_id", ordering = Ordering.DESCENDING) 
    long segChangeId;
    
    @Column(value = "bio_id")
    long bioId;
    
    @Column(value = "seg_id")
    long segId;
    
    @Column(value = "seg_ver")
    long segVer;
    
    @Column(value = "change_type")
    short changeType; 
    
    @Override
    public boolean equals(Object obj) {
        return false;
    }
    @Override
    public int hashCode() {
        return 0;        
    }   
}
