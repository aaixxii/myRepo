package com.nec.aim.uid.dmwebapp.persistence;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.HostDistance;
import com.datastax.driver.core.PoolingOptions;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

public class SegmentDaoService {
    private String insertSql = "insert into segments(seg_id, data) values (?, ?)";
    private String selectSql = "select data from segments where seg_id=?";
    private String deleteSql = "delete from segments where seg_id=?";
    
    public boolean insert() {
        Cluster cluster = Cluster.builder()
            .withClusterName("Test Cluster")
            .addContactPoints(new String[] {"192.168.22.106"})
            .build();
        Session session = cluster.connect("dmdb");
        ResultSet result = session.execute("select * from myTable where id = 1");        
        session.execute("select * from otherKeyspace.otherTable where id = 1");
        Row row = session.execute("select first_name, last_name from users where id = 1").one();
        String firstName = row.getString("first_name");
        
        String keyspace = "bio_matcher";
        int coreConnectionsPerHost = 4;
        int maxConnectionsPerHost = 10;
        int maxRequestsPerLocalConnection = 32768;
        int maxRequestsPerRemoteConnection = 2000;
        int heartbeatIntervalSeconds = 120;
        
        PoolingOptions poolingOptions = new PoolingOptions();
        poolingOptions.setCoreConnectionsPerHost(HostDistance.LOCAL, coreConnectionsPerHost)
        .setMaxConnectionsPerHost(HostDistance.LOCAL, maxConnectionsPerHost)
        .setMaxRequestsPerConnection(HostDistance.LOCAL, maxRequestsPerLocalConnection)
        .setMaxRequestsPerConnection(HostDistance.REMOTE, maxRequestsPerRemoteConnection)
         .setHeartbeatIntervalSeconds(heartbeatIntervalSeconds);
        Cluster cluster1 = Cluster.builder()
            .addContactPoints(new String[] {"192.168.22.106"})
            .withPort(9042)
            .withPoolingOptions(poolingOptions)
            .build();
        
        return false;
        
    }
    
}
