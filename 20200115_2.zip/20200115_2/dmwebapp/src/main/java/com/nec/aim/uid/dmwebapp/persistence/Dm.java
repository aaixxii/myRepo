package com.nec.aim.uid.dmwebapp.persistence;

import java.io.Serializable;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Table(value = "dm")
public class Dm implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -780998884959197663L;

	@PrimaryKeyColumn(name="dm_id", ordering = Ordering.DESCENDING) 
    int dmId;
    
    @Column(value = "url")
    String url;
    
    @Column(value = "status")
    String status;
    
    public Dm(Short id) {
    	this.setDmId(id);    	
    }
}
