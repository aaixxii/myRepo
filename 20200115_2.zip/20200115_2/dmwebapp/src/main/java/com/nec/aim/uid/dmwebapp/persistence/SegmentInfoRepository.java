package com.nec.aim.uid.dmwebapp.persistence;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SegmentInfoRepository extends CassandraRepository<SegmentInfo, Long> {
	
//	@Query("SELECT * from SegmentInfo where segId in(?0)")
//	SegmentInfo GetSegmentById(long id);
}
