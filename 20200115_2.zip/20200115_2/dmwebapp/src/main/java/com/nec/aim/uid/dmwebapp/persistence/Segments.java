package com.nec.aim.uid.dmwebapp.persistence;

import java.io.Serializable;
import java.sql.Blob;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Table(value = "segments")
public class Segments implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -5552299464283137498L;

	@PrimaryKeyColumn(name="seg_id", ordinal = 1, type = PrimaryKeyType.PARTITIONED, ordering = Ordering.DESCENDING)    
    long segId;
    
    @Column(value = "data")
    Blob data;
    
    public Segments(Long id) {
    	this.setSegId(id);    	
    }
}
