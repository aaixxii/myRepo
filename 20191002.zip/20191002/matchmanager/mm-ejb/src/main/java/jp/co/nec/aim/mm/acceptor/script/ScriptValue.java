package jp.co.nec.aim.mm.acceptor.script;

import java.util.List;
import java.util.Map;
import java.util.Set;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

/**
 * The class of ScriptValue <br>
 * 
 * Include following Value <br>
 * ContainerId list, fusionWeight list <br>
 * 
 * @author liuyq
 * 
 */
public final class ScriptValue implements Value {
	/** containerId set **/
	private Set<Integer> containerIdsSet = Sets.newTreeSet();

	// containerSpec.scope result
	private Integer scope;

	/** fusionWeights map **/
	private Map<FingerSetType, PBInquiryFusionWeight> fusionWeights = Maps
			.newTreeMap();

	/**
	 * ScriptValue default constructor
	 */
	public ScriptValue() {
	}

	public Integer getScope() {
		return scope;
	}

	public void setScope(Integer scope) {
		this.scope = scope;
	}

	/**
	 * ScriptValue constructor
	 * 
	 * @param containerId
	 *            set of containerId
	 * @param fusionWeights
	 * 
	 */
	public ScriptValue(Set<Integer> containerIds, Integer scope) {
		this.containerIdsSet = containerIds;
		this.scope = scope;
	}

	/**
	 * ScriptValue constructor
	 * 
	 * @param containerId
	 *            containerId
	 * @param scope
	 *            scope
	 */
	public ScriptValue(Integer containerId, Integer scope) {
		this.containerIdsSet.add(containerId);
		this.scope = scope;
	}

	/**
	 * clear ContainerIds set
	 */
	public void setContainerIds(Set<Integer> containerIds) {
		this.containerIdsSet = containerIds;
	}

	/**
	 * add addContainer id set to Set
	 * 
	 * @param containerIds
	 */
	public ScriptValue addContainerIds(Set<Integer> containerIds) {
		containerIdsSet.addAll(containerIds);
		return this;
	}

	/**
	 * add addContainer id to set
	 * 
	 * @param containerId
	 */
	public ScriptValue addContainerId(Integer containerId) {
		containerIdsSet.add(containerId);
		return this;
	}

	/**
	 * 
	 * @param containerId
	 * @return
	 */
	public ScriptValue addContainerId(Set<Integer> containerIds) {
		containerIdsSet.addAll(containerIds);
		return this;
	}

	/**
	 * getContainerIds
	 * 
	 * @return the set of container id
	 */
	public Set<Integer> getContainerIds() {
		return containerIdsSet;
	}

	/**
	 * getFusionWeights
	 * 
	 * @return the list of PBInquiryFusionWeight
	 */
	public List<PBInquiryFusionWeight> getFusionWeights() {
		return Lists.newArrayList(fusionWeights.values());
	}

	/**
	 * put the PBInquiryFusionWeight list
	 * 
	 * @param list
	 * @return
	 */
	public ScriptValue put(List<PBInquiryFusionWeight> list) {
		if (list == null) {
			return this;
		}

		for (PBInquiryFusionWeight weight : list) {
			FingerSetType key = weight.getInquirySet();
			if (!fusionWeights.containsKey(key)) {
				fusionWeights.put(key, weight);
			}
		}
		return this;
	}

	/**
	 * getFusionWeightsMap
	 * 
	 * @return Map<FingerSetType, PBInquiryFusionWeight>
	 */
	public Map<FingerSetType, PBInquiryFusionWeight> getFusionWeightsMap() {
		Map<FingerSetType, PBInquiryFusionWeight> tmp = Maps
				.newHashMapWithExpectedSize(this.fusionWeights.size());
		tmp.putAll(this.fusionWeights);
		return tmp;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
