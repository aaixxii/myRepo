package jp.co.nec.aim.mm.sessionbeans.pojo;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.google.common.collect.Maps;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
import jp.co.nec.aim.mm.procedure.FailExtractJobProcedure;
import jp.co.nec.aim.mm.procedure.FinishExtractJobProcedure;
import jp.co.nec.aim.mm.procedure.RetryExtractJobProcedure;

/**
 * @author mozj
 */

public class ExtractJobHandler {
	private static Logger log = LoggerFactory
			.getLogger(ExtractJobHandler.class);

	private SystemConfigDao sysConfigDao;	
	private DataSource dataSource;
	private FeJobDoneLogger feJobDoneLogger;	
	private EntityManager manager;

	/**
	 * Constructor is called by Java EE Container.
	 */
	public ExtractJobHandler(EntityManager entityManager,
			DataSource dataSource) {
		this.dataSource = dataSource;
		this.sysConfigDao = new SystemConfigDao(entityManager);		
		this.feJobDoneLogger = new FeJobDoneLogger(dataSource);
		this.manager = entityManager;		
	}

	/**
	 * 
	 * @param eje
	 * @param muId
	 * @param reason
	 * @param timeout
	 * @param maxCount
	 */
	public int failExtractJob(FeJobQueueEntity eje, long muId, PBResponse errResponse,
			 boolean timeout, Integer maxCount) {
        log.warn("Extract job " + ((timeout) ? "or MU timedout" : "failure")
                + ": (muId " + eje.getMuId() + ") Extract Job ID " 
                + eje.getId() + " failed for reason: '" + errResponse.getStatus()
                + " : " + errResponse.getErrorMessage() + "'");		

		Integer numFailures = (eje.getFailureCount() == null ? 0 : eje
				.getFailureCount().intValue());

		log.debug("Job " + eje.getId() + " has failed " + numFailures
				+ " times already.");

		if (numFailures >= maxCount - 1) {
			log.warn("Extract job id " + eje.getId()
					+ " failed too many times:" + (numFailures + 1)
					+ ", completing.");

			int numCompleted = 0;			
			try {
				FailExtractJobProcedure failProcedure = new FailExtractJobProcedure(
						dataSource);

				numCompleted = failProcedure.execute(eje.getId(), muId, errResponse.getErrorMessage(),
						errResponse.toByteArray());
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Failing Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}

			if (0 < numCompleted) {
				feJobDoneLogger.info(eje.getId());
				//callBacker.asynchCallback(eje.getId(), result); toDoXia
				// BatchJobInfoEntity batchInfo = getBatchJobInfo(eje.getId(), "EXTRACT");
				// AimManager.resExtractErr(batchInfo.getBatchJobId(), errResponse);				 
				
			} else {
				log.warn("complete_extract_job called against nonexistent or already-complete extract job Id "
						+ eje.getId());
			}
			return numCompleted;
		} else {
			try {
				log.warn("Extract job id " + eje.getId() + " failed, retry.");
				RetryExtractJobProcedure retryProcedure = new RetryExtractJobProcedure(
						dataSource);
				return retryProcedure.execute(eje.getId(), muId, errResponse);
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Retry Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		}
	}

	/**
	 * 
	 * @param reason
	 * @return
	 */
	private PBResponse createPBExtractJobErr(long jobId,
			PBServiceStateReason reason) {
		PBResponse.Builder errRes = PBResponse.newBuilder();
		errRes.setStatus("failed");	
		PBServiceState.Builder serviceState = PBServiceState.newBuilder();
		serviceState.setReason(reason);
		serviceState.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
		errRes.setErrorMessage(serviceState.toString());
		return errRes.build();
	}

	/**
	 * 
	 * @param jobId
	 * @param muId
	 * @param result
	 * @param failed
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public int completeExtractJob(long jobId, long muId,
			PBMuExtractJobResultItem result, boolean failed)
			throws SQLException, IOException {
		PBBusinessMessage pbMsg = PBBusinessMessage.parseFrom(result.getResult());
		PBResponse muResponse = pbMsg.getResponse();		 

		if (failed) {
			try {
				FailExtractJobProcedure failProcedure = new FailExtractJobProcedure(
						dataSource);

				int numCompleted = failProcedure.execute(jobId, muId,
						muResponse.getErrorMessage(),result.toByteArray());
				return numCompleted;
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Failing Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		} else {
			try {				
				PBTemplateInfo template = pbMsg.getDataBlock().getTemplateInfo();
				FinishExtractJobProcedure finishProcedure = new FinishExtractJobProcedure(dataSource);
				int numCompleted = finishProcedure.execute(muId, jobId,pbMsg.toByteArray(), template.toByteArray());
				return numCompleted;
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Finish Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private BatchJobInfoEntity getBatchJobInfo(long feJobId, String type) {
		Query q = manager.createNamedQuery("NQ::batchjobInfo");
		q.setParameter("internalJobId", feJobId);
		q.setParameter("batchType", type);
		Map<Long, BatchJobInfoEntity> batchJobInfo = Maps.newHashMap();
		List<BatchJobInfoEntity> results = q.getResultList();
		return results.get(0);
	
	}
}
