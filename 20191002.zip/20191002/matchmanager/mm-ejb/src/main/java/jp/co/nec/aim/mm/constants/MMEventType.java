package jp.co.nec.aim.mm.constants;

/**
 * @author Erik Vandekieft
 */
public enum MMEventType {
	POLL, //
	SEGMENT_LOAD_BALANCING, //
	CHECK_ORPHANED_JOBS, //
	STARTUP, //
	DEFRAG_HYPERSONIC, //
	PURGE_JOB_QUEUE, //
	JOB_AGGREGATION, //
	GARBAGE_LOGDOLLAR, //
	JOB_PLANNER, FEJOB_PLANNER, GARBAGE_SEGMENT_CHANGE_LOG; //
}
