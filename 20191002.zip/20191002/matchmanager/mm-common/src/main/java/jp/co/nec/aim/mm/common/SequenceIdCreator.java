package jp.co.nec.aim.mm.common;
import java.util.concurrent.atomic.AtomicLong;

public class SequenceIdCreator {
	private static AtomicLong lastBatchJobId = new AtomicLong(0);
	private static AtomicLong lastEnrollJobId = new AtomicLong(0);
	private static AtomicLong lastInquriyJobId = new AtomicLong(0);
	private static AtomicLong lastExtractJobId = new AtomicLong(0);
	private static AtomicLong lastMuId = new AtomicLong(0);
	
	public static synchronized long createNextSequence(SequenceIdType jobType) {
		long value = 0;
		switch (jobType){
		case BATCHJOB_ID:
			value = lastBatchJobId.incrementAndGet();
			break;
		case ENROLL_ID:
			value = lastEnrollJobId.incrementAndGet();
			break;	
		case INQUIRY_ID:
			value = lastInquriyJobId.incrementAndGet();
			break;
		case EXTEACT_ID:
			value = lastExtractJobId.incrementAndGet();
			break;
		case MU_ID:
			value = lastMuId.incrementAndGet();
			break;					
		}		
		return value;
	}
}
