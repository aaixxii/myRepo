package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.SegBioNsmUrl;

@Repository
public class SegmentRefenceStorageRepositoryImpl implements SegmentRefenceStorageRepository {
	
	private static final String insertSql = "insert into segment_ref_storage_info(nsm_id, segment_id, bio_id, external_id) values(?,?,?,?)";
	private static final String insertWitoutRefIdSql = "insert into segment_ref_storage_info(nsm_id, segment_id, bio_id) values(?,?,?)";
	private static final String updateSql = "update segment_ref_storage_info set external_id =? where nsm_id=? and segment_id=? and bio_id=?";
	private static final String deleteRefIdSql = "delete from segment_ref_storage_info where nsm_id=? and segment_id=? and bio_id=?";
	private static final String getSql = "select ng.url,srs.segment_id, srs.bio_id from segment_ref_storage_info srs, node_storage_manager ng where  srs.nsm_id = ng.nsm_id and ng.status=1 and srs.external_id=?";
	@Autowired
    private JdbcTemplate jdbcTemplate;	
	
	RowMapper<SegBioNsmUrl> segBioNsmUrlMapper = (rs, rowNum) -> {
		SegBioNsmUrl segBioNsmUrl = new SegBioNsmUrl();
		segBioNsmUrl.setUrl(rs.getString("url"));
		segBioNsmUrl.setSegmentId(rs.getLong("segment_id"));
		segBioNsmUrl.setBioId(rs.getLong("bio_id"));
		return segBioNsmUrl;
	};
	
	@Override
	public void inserSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId, String externalId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql, new Object[] {storageId, segId, bioId, externalId});		
	}

	@Override
	public void insertSegRefStorageWitoutRefId(Integer storageId, Long segId, Long bioId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertWitoutRefIdSql, new Object[] {storageId, segId, bioId});
	}

	@Override
	public int deleteSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		return jdbcTemplate.update(deleteRefIdSql, new Object[] {storageId, segId, bioId});
	}

	@Override
	public int updateSegmentRefenceStorageInfo(String externalId, Integer storageId, Long segId, Long bioId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		return jdbcTemplate.update(updateSql, new Object[] {externalId,storageId, segId, bioId});
	}

	@Override
	public List<SegBioNsmUrl> getInfoForGetTemplate(String externalId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		 List<SegBioNsmUrl> result = jdbcTemplate.query(getSql, new Object[] {externalId}, segBioNsmUrlMapper);
		return result;
	}

}
