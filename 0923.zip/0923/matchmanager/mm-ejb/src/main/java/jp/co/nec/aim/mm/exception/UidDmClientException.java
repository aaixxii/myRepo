package jp.co.nec.aim.mm.exception;

public class UidDmClientException extends RuntimeException {

	private static final long serialVersionUID = 4092967622896782047L;

	/**
	 * @param message
	 */
	public UidDmClientException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public UidDmClientException(String message, Throwable cause) {
		super(message, cause);
	}
}
