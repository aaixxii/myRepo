package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.PersonBiometricEntity;

/**
 * SegmentDao
 * 
 * @author liuyq
 * 
 */
public class PersonBiometricDao {

	private EntityManager manager;

	public PersonBiometricDao(EntityManager manager) {
		this.manager = manager;
	}

	/**
	 * findPersonBiometric
	 * 
	 * @param bioId
	 * @return PersonBiometric instance
	 */
	public PersonBiometricEntity findPersonBiometric(long bioId) {
		return manager.find(PersonBiometricEntity.class, bioId);
	}
	
	public int delBioByExternalId (String id) {
		Query q = manager.createNamedQuery("NQ::delBioUsingEnrollId");
		q.setParameter("enrollId", id);
		return q.executeUpdate();
	}
	
	public long getAllBioDataCount() {
		Query q = manager.createNamedQuery("NQ::getBioDataCount");	
		Long count = (Long) q.getSingleResult();
		return count.longValue();
	}
	
	
	@SuppressWarnings("unchecked")
	public PersonBiometricEntity getBioDataByExternalId(String enternalId) {
		Query q = manager.createNamedQuery("NQ::checkEnrollmentID");
		q.setParameter("enrollId", enternalId);		
		List<PersonBiometricEntity> results = q.getResultList();
		if (results.size() > 0) {
			return results.get(0);
		} else {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public PersonBiometricEntity isHaveBioMetricDataInMyTable(String refId) {
		Query q = manager.createNamedQuery("NQ::isHaveBiometricData");
		q.setParameter("refId", refId);	
		List<PersonBiometricEntity> results = q.getResultList();
		if (results.size() > 0) {
			return results.get(0);
		} else {
			return null;
		}
	}

}
