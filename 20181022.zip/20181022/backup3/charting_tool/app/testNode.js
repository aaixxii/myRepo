var fs = require("fs");
fs.readFile("index.txt",function(){
    
});