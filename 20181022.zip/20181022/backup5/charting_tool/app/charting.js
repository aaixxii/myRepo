/* charting.js */
var DOT_TYPE = "dot";
var RECT_TYPE = "rect";
var PROBE = "probe";
var TARGET = "target";

var canvasi;
var context;
var canvas_rect;

var win_width;
var win_height;
var first_start_x;
var first_start_y;
var second_start_x;
var second_start_y;

var radius = 10;
var strokelineWith = 1;

var hasFirstImage = false;
var hasSecondImage = false;
var xmlOrTxtFileInUsing = false;

var minutiaPairList = []; //used by one time drawing
var oneCandidateRawScoreList = []; //saved xx RawScoreList 
var verifyJobResult;
var firstImageData;
var secondImageData;

function Point(x, y) {
  this.x = x;
  this.y = y;
}

function VerifyJobResult(jobId, candidateResultList) {
  this.jobId = jobId;
  this.candidateResultList = candidateResultList;
}

function CandidateResultList(candidateId, modalScoreList) {
  this.candidateId = candidateId;
  this.modalScoreList = modalScoreList;
}

function ModalScoreList(modal, rawScoreList) {
  this.modal = modal;
  this.rawScoreList = rawScoreList;
}

function RawScoreList(algorithmType, probePosition, probeIndex, targetPosition, targetIndex, matchedDataList) {
  this.algorithmType = algorithmType;
  this.probePosition = probePosition;
  this.probeIndex = probeIndex;
  this.targetPosition = targetPosition;
  this.targetIndex = targetIndex;
  this.matchedDataList = matchedDataList;
}

function MatchedData(similitude, pn, px, py, tn, tx, ty) {
  this.similitude = similitude;
  this.pn = pn;
  this.px = px;
  this.py = py;
  this.tn = tn;
  this.tx = tx;
  this.ty = ty;
}

window.onload = function () {
  //window.addEventListener('resize', resizeCanvas, false);
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  canvasi.addEventListener('click', onCanvasClick, false);
  canvas_rect = canvasi.getBoundingClientRect();
  calculateSize();
  $("#imageFile").change(function (e) {
    if (!this.files.length) {
      alert('File is not selected.');
      return;
    }
    var file = this.files[0];
    if (!hasFirstImage) {
      readImage1(file, e);
      hasFirstImage = true;
    } else if (!hasSecondImage) {
      readImage2(file, e);
      hasSecondImage = true;
    }
  });

  $("#xmlFile").change(function (e) {
    var fileToLoad = e.target.files[0];
    var fileName = fileToLoad.name;
    if (fileName.toLowerCase().endsWith("xml")) {
      readXml(this.files, e);
    } else if (fileName.toLowerCase().endsWith("txt")) {
      readMinutia(e);
    }
  });

  $('#mapping').click(function (e) {
    if (!oneCandidateRawScoreList || oneCandidateRawScoreList.length < 1) {
      alert("No data for process");
      return;
    }
    minutiaPairList = oneCandidateRawScoreList[0].matchedDataList;
    //allMapingWithDot(mplist);
    allMapingWithRect(minutiaPairList);
  });

  $('#onebyone').click(function (e) {
    if (!oneCandidateRawScoreList || oneCandidateRawScoreList.length < 1) {
      alert("No data for process");
      return;
    }
    minutiaPairList = oneCandidateRawScoreList[0].matchedDataList;
    drawDotWithNum(minutiaPairList);
  });

  $('#backup').click(function (e) {
    firstImageData = context.getImageData(first_start_x, first_start_y, 512, 512);
    secondImageData = context.getImageData(second_start_x, second_start_y, 512, 512);

  });

  $('#restore').click(function (e) {
    context.clearRect(first_start_x - 30, first_start_y - 30, (second_start_x - first_start_x + 512 + 30), 512);
    context.putImageData(firstImageData, first_start_x, first_start_y);
    context.putImageData(secondImageData, second_start_x, second_start_y);
  });

  $('#clear').click(function (e) {
    clearAll();
  });

  var button = document.getElementById('downloadButton');
  button.addEventListener('click', function (e) {
    var dataURL = canvasi.toDataURL('image/png');
    button.href = dataURL;
  });

  $('#listButton').click(function (e) {
    //testCreateTable();
    createDynamicTable();
  });
}; //end windows.onload


function readImage1(file, evt) {
  calculateSize();
  var image = new Image();
  var fr = new FileReader();
  fr.onload = function (evt) {
    image.onload = function () {
      context.drawImage(image, first_start_x, first_start_y, 512, 512);
    };
    image.src = evt.target.result;
  };
  fr.readAsDataURL(file);
}

function readImage2(file, evt) {
  calculateSize();
  var image = new Image();
  var fr = new FileReader();
  fr.onload = function (evt) {
    image.onload = function () {
      context.drawImage(image, second_start_x, second_start_y, 512, 512);
    };
    image.src = evt.target.result;
  };
  fr.readAsDataURL(file);
}



function mergeMinutiaInfo(type, jsonData) {
  var minutias = jsonData.minutia;
  var fingerNum = jsonData.position;
  var index = jsonData.index;
  if (!minutias || !fingerNum || minutias.length < 1) {
    alert("There some wrong, get data failed!");
    return;
  }
  var updateCountP = 0;
  var updateCountT = 0;
  for (let i = 0; i < oneCandidateRawScoreList.length; i++) {
    let rowScore = oneCandidateRawScoreList[i];
    for (let j = 0; j < minutias.length; j++) {
      if (type === PROBE && rowScore.probePosition === fingerNum && Number(rowScore.probeIndex) === index) {
        let minutiaPairListP = rowScore.matchedDataList;
        for (let k = 0; k < minutiaPairListP.length; k++) {
          if (Number(minutiaPairListP[k].pn) === minutias[j]["number"]) {
            minutiaPairListP[k].px = minutias[j].x;
            minutiaPairListP[k].py = minutias[j].y;
            updateCountP++;
          }
        }
      } else if (type === TARGET && rowScore.targetPosition === fingerNum && Number(rowScore.targetIndex) === index) {
        let minutiaPairListT = rowScore.matchedDataList;
        for (let g = 0; g < minutiaPairListT.length; g++) {
          if (Number(minutiaPairListT[g].tn) === minutias[j]["number"]) {
            minutiaPairListT[g].tx = minutias[j].x;
            minutiaPairListT[g].ty = minutias[j].y;
            updateCountT++;
          }
        }
      }
    }
  }
  alert("updateCountP=" + updateCountP + " updateCountT=" + updateCountT);
}

function readMinutia(evt) {
  var fileToLoad = evt.target.files[0];
  if (fileToLoad) {
    var reader = new FileReader();
    var fileName = fileToLoad.name;
    reader.onload = function (fileLoadedEvent) {
      var data = fileLoadedEvent.target.result;
      var json = JSON.parse(data);
      if (fileName.toLowerCase().startsWith(PROBE)) {
        mergeMinutiaInfo(PROBE, json);
      } else if (fileName.toLowerCase().startsWith(TARGET)) {
        mergeMinutiaInfo(TARGET, json);
      }
    };
    reader.readAsText(fileToLoad, 'UTF-8');
  }
}

function readXml(fileList, evt) {
  if (!fileList.length) {
    alert('File is not selected.');
    return;
  }
  var fileToLoad = evt.target.files[0];
  if (fileToLoad) {
    var reader = new FileReader();
    reader.onload = function (fileLoadedEvent) {
      var data = fileLoadedEvent.target.result;
      var x2js = new X2JS();
      var jsonTmp = x2js.xml_str2json(data);
      var jobId = jsonTmp.verifyJobResultDto.jobId;
      var candidateId = jsonTmp.verifyJobResultDto.candidateResultList.candidateId;
      var modalScoreList = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList;
      var rawScoreList = modalScoreList.rawScoreList;
      var updateMinutiaPairCount = 0;
      var size = rawScoreList.length;
      if (size > 0) {
        for (var i = 0; i < rawScoreList.length; i++) {
          var algorithmType = rawScoreList[i].algorithmType;
          var probePosition = rawScoreList[i].probePosition;
          var probeIndex = rawScoreList[i].probeMinutiaDataIndex;
          var targetPosition = rawScoreList[i].position;
          var targetIndex = rawScoreList[i].targetMinutiaDataIndex;
          var mpList = rawScoreList[i].minutiaPairList;
          var newMinutiaPairList = [];
          for (var j = 0; j < mpList.length; j++) {
            var temp = mpList[j];
            var matchedData = new MatchedData(temp._similitude, temp._probeMinutiaNumber, null, null, temp._targetMinutiaNumber, null, null);
            newMinutiaPairList.push(matchedData);
            updateMinutiaPairCount++;
          }
          var newRawScoreList = new RawScoreList(algorithmType, probePosition, probeIndex, targetPosition, targetIndex, newMinutiaPairList);
          oneCandidateRawScoreList.push(newRawScoreList);
        }
      } else if (rawScoreList && !size) {
        var algorithmType = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.algorithmType;
        var probePosition = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.probePosition;
        var targetPosition = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.position;
        var mpList = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.minutiaPairList;
        var probeIndex = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.probeMinutiaDataIndex;
        var targetIndex = jsonTmp.verifyJobResultDto.candidateResultList.modalScoreList.rawScoreList.targetMinutiaDataIndex;
        var newMinutiaPairList = [];
        for (var j = 0; j < mpList.length; j++) {
          var temp = mpList[j];
          var matchedData = new MatchedData(temp._similitude, temp._probeMinutiaNumber, null, null, temp._targetMinutiaNumber, null, null);
          newMinutiaPairList.push(matchedData);
          updateMinutiaPairCount++;
        }
        var newRawScoreList = new RawScoreList(algorithmType, probePosition, probeIndex, targetPosition, targetIndex, newMinutiaPairList);
        oneCandidateRawScoreList.push(newRawScoreList);
      }
      alert(JSON.stringify(oneCandidateRawScoreList));
      alert("updateMinutiaPairCount=" + updateMinutiaPairCount);
    };
    reader.readAsText(fileToLoad, 'UTF-8');
  }
}

function drawAllChart(minutia_PairList) {
  calculateSize();
  for (var i = 0; i < minutia_PairList.length; i++) {
    var orrObj = minutia_PairList[i];
    var score = orrObj.similitude;
    var px = orrObj.px;
    var py = orrObj.py;
    var pn = orrObj.pn;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var tn = orrObj.tn;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);
    var canvasi = document.getElementById("canvas_i");
    var context = canvasi.getContext("2d");
    drawMapingData_dot(context, score, pn, newPositonP, tn, newPositonT);
  }
}

function allMapingWithDot(mpList) {
  calculateSize();
  for (var i = 0; i < mpList.length; i++) {
    var orrObj = mpList[i];
    var score = orrObj.similitude;
    var px = orrObj.px;
    var py = orrObj.py;
    var pn = orrObj.pn;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var tn = orrObj.tn;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);
    var canvasi = document.getElementById("canvas_i");
    var context = canvasi.getContext("2d");
    drawMapingData_dot(context, score, pn, newPositonP, tn, newPositonT);
  }
}

function allMapingWithRect(mpList) {
  calculateSize();
  for (var i = 0; i < mpList.length; i++) {
    var orrObj = mpList[i];
    var score = orrObj.similitude;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, px, py);
    var canvasi = document.getElementById("canvas_i");
    var context = canvasi.getContext("2d");
    drawMapingData_rect(context, score, newPositonP.x, newPositonP.y, newPositonT.x, newPositonT.y);
  }
}

function calculateSize() {
  win_width = $(window).width();
  win_height = $(window).height();

  first_start_x = Math.floor((win_width / 2 - 512) / 2);
  first_start_y = Math.floor((win_height * 0.6 - 512) / 2);
  second_start_x = Math.floor(win_width / 2 + (win_width / 2 - 512) / 2);
  second_start_y = first_start_y;

  var firstImageNewCoordinateOriginX = -(first_start_x + 512 / 2);
  var firstImageNewCoordinateOriginY = first_start_y + 512 / 2;
  var secondImageNewCoordinateOriginX = -(second_start_x + 512 / 2);
  var secondImageNewCoordinateOriginY = second_start_y + 512 / 2;
}

function resizeCanvas() {
  var canvas = document.getElementById("canvas_i");
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  calculateSize();
}

function drawMapingData_dot(context, score, pn, newPositonP, tn, newPositonT) {
  var pnx = newPositonP.x - 6;
  var pny = newPositonP.y - radius - 3;
  var lx = newPositonP.x;
  var ly = newPositonP.y;

  var tnx = newPositonT.x - 6;
  var tny = newPositonT.y - radius - 3;
  var rx = newPositonT.x;
  var ry = newPositonT.y;

  context.beginPath();
  context.fillStyle = 'blue';
  context.font = "12px Arial";
  context.fillText(pn, pnx, pny);

  context.beginPath();
  context.arc(lx, ly, radius, 0, Math.PI * 2, true);
  context.strokeStyle = "red";
  context.lineWidth = strokelineWith;
  context.stroke();

  context.beginPath();
  context.moveTo(lx + radius, ly);
  context.lineTo(rx - radius, ry);
  context.strokeStyle = "green";
  context.stroke();

  context.beginPath();
  context.arc(rx, ry, radius, 0, Math.PI * 2, true);
  context.strokeStyle = "red";
  context.stroke();

  context.beginPath();
  context.fillStyle = 'blue';
  context.font = "12px Arial";
  context.fillText(tn, tnx, tny);

  var sx = Math.abs((rx - lx) / 2 + lx);
  var sy = Math.abs((ry - ly) / 2 + ly);
  context.beginPath();
  context.fillStyle = 'blue';
  context.font = "12px Arial";
  context.fillText(score, sx, sy);
  // context.strokeText(score, sx, sy);
  //context.closePath();
}

function drawMapingData_rect(context, score, lx, ly, rx, ry) {
  context.beginPath();
  var size = radius;
  context.rect(lx - (size / 2), ly - (size / 2), size, size);
  context.strokeStyle = "red";
  context.lineWidth = strokelineWith;
  context.stroke();

  context.beginPath();
  context.moveTo(lx + (size / 2), ly);
  context.lineTo(rx - (size / 2), ry);
  context.strokeStyle = "green";
  context.stroke();

  context.beginPath();
  context.rect(rx - (size / 2), ry - (size / 2), size, size);
  context.strokeStyle = "red";
  context.closePath();
  context.stroke();

  var sx = Math.abs((rx - lx) / 2 + lx);
  var sy = Math.abs((ry - ly) / 2 + ly);
  context.beginPath();
  context.fillStyle = 'blue';
  context.font = "12px Arial";
  context.fillText(score, sx, sy);
}

function calculateNewPostion(start_x, start_y, x, y) {
  var newPositon = new Point();
  newPositon.x = start_x + x;
  newPositon.y = start_y + y;
  return newPositon;
}

function calculateNewPostion_O(start_x, start_y, x, y) {
  var newPositon = new Point();
  if (x < 0) {
    newPositon.x = start_x + (256 - (-1) * x);
  } else if (x >= 0) {
    newPositon.x = start_x + (256 + x);
  }
  if (y < 0) {
    newPositon.y = start_y + (256 + y);
  } else if (y >= 0) {
    newPositon.y = start_y + (256 - (-1) * y);
  }
  return newPositon;
}

function drawOneDot(imageNum, matchedData) {
  var orrObj = matchedData;
  if (imageNum === 1) {
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    context.beginPath();
    context.arc(newPositonP.x, newPositonP.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
  }
}

function drawDotWithNum(dotNpList) {
  calculateSize();
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  for (var i = 0; i < dotNpList.length; i++) {
    var orrObj = dotNpList[i];
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);

    var tn = orrObj.tn;
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);

    context.beginPath();
    context.arc(newPositonP.x, newPositonP.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();
    var pnx = newPositonP.x - 6;
    var pny = newPositonP.y - radius - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(pn, pnx, pny);

    context.beginPath();
    context.arc(newPositonT.x, newPositonT.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();

    var tnx = newPositonT.x - 6;
    var tny = newPositonT.y - radius - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(tn, tnx, tny);
  }
}

function mappingAll(minutia_PairList) {
  calculateSize();
  for (var i = 0; i < minutia_PairList.length; i++) {
    var orrObj = minutia_PairList[i];
    var score = orrObj.similitude;
    var px = orrObj.px;
    var py = orrObj.py;
    var pn = orrObj.pn;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var tn = orrObj.tn;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);
    var canvasi = document.getElementById("canvas_i");
    var context = canvasi.getContext("2d");
    drawMapingData_dot(context, score, pn, newPositonP, tn, newPositonT);
  }
}

function drawDotChartOneByOne(minutia_PairList) {
  calculateSize();
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  for (let i = 0; i < minutia_PairList.length; i++) {
    var orrObj = minutia_PairList[i];
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);

    var tn = orrObj.tn;
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);

    context.beginPath();
    context.arc(newPositonP.x, newPositonP.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();
    var pnx = newPositonP.x - 6;
    var pny = newPositonP.y - radius - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(pn, pnx, pny);

    context.beginPath();
    context.arc(newPositonT.x, newPositonT.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();

    var tnx = newPositonT.x - 6;
    var tny = newPositonT.y - radius - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(tn, tnx, tny);
  }
}

function drawRectWithNum(minutiaPairList) {
  calculateSize();
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  for (var i = 0; i < minutiaPairList.length; i++) {
    var orrObj = minutiaPairList[i];
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);

    var tn = orrObj.tn;
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);

    context.beginPath();
    context.rect(newPositonP.x - (radius / 2), newPositonP.y - (radius / 2), radius, radius);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();
    var pnx = newPositonP.x - 6;
    var pny = newPositonP.y - radius / 2 - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(pn, pnx, pny);

    context.beginPath();
    context.rect(newPositonT.x - (radius / 2), newPositonT.y - (radius / 2), radius, radius);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    context.stroke();

    var tnx = newPositonT.x - 6;
    var tny = newPositonT.y - radius / 2 - 3;
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(tn, tnx, tny);
  }
}

function drawLine(pointP, pointT, score, imageNum) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  px = pointP.x;
  py = pointP.y;
  tx = pointT.x;
  ty = pointT.y;
  if (imageNum === 1) {
    context.beginPath();
    context.moveTo(px + radius, py);
    context.lineTo(tx - radius, ty);
    context.strokeStyle = "green";
    context.stroke();
    var sx = Math.abs((tx - px) / 2 + px);
    var sy = Math.abs((ty - py) / 2 + py);
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(score, sx, sy);
  } else if (imageNum === 2) {
    context.beginPath();
    context.moveTo(tx - radius, ty);
    context.lineTo(px + radius, py);
    context.strokeStyle = "green";
    context.stroke();
    var sx = Math.abs((px - tx) / 2 + tx);
    var sy = Math.abs((py - ty) / 2 + ty);
    context.beginPath();
    context.fillStyle = 'blue';
    context.font = "12px Arial";
    context.fillText(score, sx, sy);
  } else {
    alert("unknown image number!!");
  }
}

function clearDot(ox, oy, radius) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var lx = ox - radius - strokelineWith;
  var ly = oy - radius - strokelineWith;
  context.clearRect(lx, ly, radius * 2 + strokelineWith, radius * 2 + strokelineWith);
}

function clearRect(ox, oy, rectSize) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var lx = ox - (rectSize / 2) - strokelineWith;
  var ly = oy - (rectSize / 2) - strokelineWith;
  context.clearRect(lx, ly, rectSize + (strokelineWith * 2), rectSize + (strokelineWith * 2));
}


function clearText(lx, ly, rx, ry, radius) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var sx = Math.abs((rx - lx) / 2 + lx);
  var sy = Math.abs((ry - ly) / 2 + ly);

  var dwith = 8;
  var dheight = 8;
  context.clearRect(sx, sy, dwith, dheight);
}

function clearLineWithDot(lx, ly, rx, ry, radius) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var clx = lx - radius - strokelineWith;
  var cly = ly - radius - strokelineWith;
  var dwith = rx - lx + radius + strokelineWith + radius + strokelineWith;
  var dheight = radius * 2 + strokelineWith * 2;
  context.clearRect(clx, cly, dwith, dheight);
}

function clearLineWithRect(lx, ly, rx, ry, rectSize) {
  canvasi = document.getElementById("canvas_i");
  context = canvasi.getContext("2d");
  var clx = lx - (rectSize / 2) - strokelineWith;
  var cly = ly - (rectSize / 2) - strokelineWith;
  var dwith = rx - lx + rectSize + (strokelineWith * 4);
  var dheight = rectSize + strokelineWith * 2;
  context.clearRect(clx, cly, dwith, dheight);
}

function clearAll() {
  $('#imageFile').replaceWith($('#imageFile').val('').clone(true));
  hasFirstImage = false;
  hasSecondImage = false;
  xmlOrTxtFileInUsing = false;
  //oneCandidateRawScoreList = [];
  context.clearRect(first_start_x - 20, first_start_y - 20, (second_start_x - first_start_x + 512 + 20), 530);
}

function doExit() {
  verifyJobResult = null;
  oneCandidateRawScoreList = null;
}

function onCanvasClick(e) {
  canvasi = document.getElementById("canvas_i");
  //var rect = canvasi.getBoundingClientRect();
  var rect = e.target.getBoundingClientRect();
  var x = e.offsetX;
  var y = e.offsetY;
  //var x = e.pageX - rect.left;
  //var y = e.pageY - rect.top;
  var imageNum;
  if (x >= first_start_x && x <= first_start_x + 512) {
    imageNum = 1;
  } else if (x >= second_start_x && x <= second_start_x + 512) {
    imageNum = 2;
  }
  for (var i = 0; i < minutiaPairList.length; i++) {
    var orrObj = minutiaPairList[i];
    var pn = orrObj.pn;
    var px = orrObj.px;
    var py = orrObj.py;
    var newPositonP = calculateNewPostion(first_start_x, first_start_y, px, py);

    var tn = orrObj.tn;
    var tx = orrObj.tx;
    var ty = orrObj.ty;
    var newPositonT = calculateNewPostion(second_start_x, second_start_y, tx, ty);
    context.beginPath();
    context.arc(newPositonP.x, newPositonP.y, radius, 0, Math.PI * 2, true);
    context.strokeStyle = "red";
    context.lineWidth = 1;
    if (context.isPointInPath(x, y)) {
      if (e.type == "click") {
        context.closePath();
        drawLine(newPositonP, newPositonT, orrObj.similitude, imageNum);
        return;
      } else if (e.type == "dbClick") {
        clearLineWithDot(newPositonP.x, newPositonP.y, newPositonT.y, newPositonT.y, radius);
      }
    }
  }
}

function init_load() {
  var win_width = $(window).width();
  var win_height = $(window).height();

  var second_start_x = win_width / 2 + (win_width / 2 - 512) / 2;
  var second_start_y = first_start_y;
  var canvasi = document.getElementById("canvas_i");
  var context = canvasi.getContext("2d");
  var imgf = new Image();
  imgf.onload = function () {
    drawOneImage(context, this, first_start_x, first_start_y, 512, 512);
  };
  imgf.src = 'image/f_data.bmp';

  var imgs = new Image();
  imgs.onload = function () {
    drawOneImage(context, this, second_start_x, second_start_y, 512, 512);
  };
  imgs.src = "image/s_data.bmp";
}

function drawOneImage(context, imageObj, x, y, dx, dy) {
  context.drawImage(imageObj, x, y, dx, dy);
}

function randomRGB() {
  var r = Math.floor(Math.random() * 256);
  var g = Math.floor(Math.random() * 256);
  var b = Math.floor(Math.random() * 256);
  return `rgb(${r},${g},${b})`;
}

function testCreateTable() {
  var minutiaList = [];
  for (let i = 0; i < 10; i++) {
    var similitude = Math.floor(Math.random() * 100 + 2);
    var pn = Math.floor(Math.random() * 64 + 1);
    var px = Math.floor(Math.random() * 512);
    var py = Math.floor(Math.random() * 512);
    var tn = Math.floor(Math.random() * 64 + 1);
    var tx = Math.floor(Math.random() * 512);
    var ty = Math.floor(Math.random() * 512);
    var matchedData = new MatchedData(similitude, pn, px, py, tn, tx, ty);
    minutiaList.push(matchedData);
  }
  minutiaPairList = minutiaList;
  var algorithmType = "finger";
  for (let i = 0; i < 10; i++) {
    var probePos = "ROLL_LINDEX";
    var probeIndex = Math.floor(Math.random() * 64);
    var targetPos = "ROLL_LINDEX";
    var targetIndex = Math.floor(Math.random() * 64);
    var rawScoreList = new RawScoreList(algorithmType, probePos, probeIndex, targetPos, targetIndex, minutiaList);
    oneCandidateRawScoreList.push(rawScoreList);
  }
  createDynamicTable();
}

function ajaxGetMinutiaData(type, capsulePath, fingerName, socreIndex) {
  //var sendUrl = "http://" + minutia_server_ip + ":" + get_method+ "?" + capsule + capsulePath + "&" + position + fingerName + "&" + index + minutiaIndex;
  var sendUrl = "http://" + "10.197.23.100:17777/getminutia?capsule=%2Fhome%2Fk-ishii%2FAIM-XM%2FKaveri%2Ftools%2Fmininfodumper%2FCAPSULE_TYPE_35.bin&position=0&index=1";

  $.ajax({
    type: "GET",
    url: sendUrl,
    timeout: 2000,
    dataType: "text",
    cache: false,
    async: false,
    success: function (data, status) {
      if (data == "" || data == null || data == undefined) {
        return;
      }
      alert("Successed!!!");
      updataMinutiaData(type, fingerName, socreIndex, data);
    },
    error: function (XMLHttpRequest, status, errorThrown) {
      alert('Can not to get minutia data, Reason: ' + errorThrown);
    }
  });
}

function ajaxGetVerifyResult() {
  $.ajax({
    type: "GET",
    url: "", //ToDo
    timeout: 2000,
    dataType: "xml",
    cache: false,
    async: false,
    success: function (data, status) {
      if (data == "" || data == null || data == undefined) {
        return;
      }
      updateVerifyJobResult(data); //ToDo
    },
    error: function (XMLHttpRequest, status, errorThrown) {
      console.log('Can not to get verify job results, Reason: ' + errorThrown);
    }
  });
}

function updataMinutiaData(type, fingerNum, index, data) {
  var json = JSON.parse(data);
  var minutias = json.minutia;
  if (!minutias || minutias.length < 1) {
    alert("There are some wrong, get data failed!");
    return;
  }
  var updateCountP = 0;
  var updateCountT = 0;

  for (let i = 0; i < oneCandidateRawScoreList.length; i++) {
    let rowScore = oneCandidateRawScoreList[i];
    for (let j = 0; j < minutias.length; j++) {
      if (type === PROBE && fingerNum === rowScore.probePosition && rowScore.probeIndex === index) {
        let minutiaPairListP = rowScore.matchedDataList;
        for (let k = 0; k < minutiaPairListP.length; k++) {
          var tempn = minutiaPairListP[k].pn;
          var tartN = minutias[j]["number"];
          if (Number(minutiaPairListP[k].pn) == minutias[j]["number"]) {
            minutiaPairListP[k].px = minutias[j].x;
            minutiaPairListP[k].py = minutias[j].y;
            updateCountP++;
          }
        }
      } else if (type === TARGET && fingerNum === rowScore.targetPosition && rowScore.targetIndex === index) {
        let minutiaPairListT = rowScore.matchedDataList;
        for (let g = 0; g < minutiaPairListT.length; g++) {
          if (Number(minutiaPairListT[g].tn) == minutias[j]["number"]) {
            minutiaPairListT[g].tx = minutias[j].x;
            minutiaPairListT[g].ty = minutias[j].y;
            updateCountT++;
          }
        }
      }
    }
    alert("updateCountP=" + updateCountP + " updateCountT=" + updateCountT);
    alert(JSON.stringify(oneCandidateRawScoreList));
  }
}

function handerTableSubmit(e) {
  var col = $(this).parent().children().index($(this));
  var row = $(this).parent().parent().children().index($(this).parent());  
  var tab = document.getElementById("chartingTable");
  var figerName;
  var index;
  if (col === 3) {
    var cell = tab.rows[row + 1].cells[0];
    var file = cell.firstChild.value;
    if (!file) {
      alert('Pelease select file.');
      return;
    }
    figerName = tab.rows[row + 1].cells[1].innerHTML;
    index = tab.rows[row + 1].cells[2].innerHTML;    
    ajaxGetMinutiaData(PROBE, file, figerName, index);

  } else if (col === 7) {
    var cell = tab.rows[row + 1].cells[4];
    var file = cell.firstChild.value;
    if (!file) {
      alert('Pelease select file.');
      return;
    }
    figerName = tab.rows[row + 1].cells[5].innerHTML;
    index = tab.rows[row + 1].cells[6].innerHTML;    
    ajaxGetMinutiaData(TARGET, file, figerName, index);
  }
}

function readProbeImage(evt) {
  var fileToLoad = evt.target.files[0];
  if (!fileToLoad) {
    alert('File is not selected.');
    return;
  }
  readImage1(fileToLoad, evt);
}

function readTargetImage(evt) {
  var fileToLoad = evt.target.files[0];
  if (!fileToLoad) {
    alert('File is not selected.');
    return;
  }
  readImage2(fileToLoad, evt);
}

function createDynamicTable() {
  var inputFileTxt = "<input class='form-control mr-sm-2' type='file'>";
  var checkTxt = "<input name='select[]' value='1' type='checkbox'> ";
  var submitTxt = "<input type='submit' class='btn btn-outline-primary btn-mini' value='Submit'>";
  var chartBtn = "<button type='button' class='btn btn-outline-danger'>Charting</button>";
  var oneByoneBtn = "<button type='button' class='btn btn-outline-success'>OneByOne</button>";
  // var chartBtn = "<div class='btn-group' role='group'>" +
  //   "<button id='btnGroupDrop1' type='button' class='btn btn-info dropdown-toggle' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>" +
  //   " Charting" +
  //   "</button>" +
  //   "<div class='dropdown-menu' aria-labelledby='btnGroupDrop1'>" +
  //   "<a class='dropdown-item' id='dochart' href='javascript:doAllCharting(e)'>Charting</a>" +
  //   "<a class='dropdown-item' id='onebyone' href='javascript:doOneByOne(e)'>OneBye</a>" +
  //   "</div>" +
  //   "</div>";  

  var inputProbeImageTxt = "<div class='custom-file m-1' lang='es' style='text-align:left;'>" +
    "<input type='file' class='custom-file-input' id='probeImage' aria-describedby='fileHelp'>" +
    "<label class='custom-file-label' for='exampleInputFile' style='color:red;'>" +
    "select probe image" +
    "</label>" +
    "</div>"

  var inputTargeImageTxt = "<div class='custom-file m-1' lang='es' style='text-align:left;'>" +
    "<input type='file' class='custom-file-input' id='targetImage' aria-describedby='fileHelp'>" +
    "<label class='custom-file-label' for='exampleInputFile' style='color:green;'>" +
    "select target image" +
    "</label>" +
    "</div>"

  var inputProbeCapuselTxt = "<div class='custom-file m-1' lang='es' style='text-align:left;'>" +
    "<input type='file' class='custom-file-input' id='imageFile' aria-describedby='fileHelp'>" +
    "<label class='custom-file-label' for='exampleInputFile' style='color:blue;'>" +
    "select probe Capsule" +
    "</label>" +
    "</div>"

  var inputTargeCapuselTxt = "<div class='custom-file m-1' lang='es' style='text-align:left;'>" +
    "<input type='file' class='custom-file-input' id='imageFile' aria-describedby='fileHelp'>" +
    "<label class='custom-file-label' for='exampleInputFile' style='color:blue;'>" +
    "select target Capsule" +
    "</label>" +
    "</div>"



  var chartTable = document.getElementById("chartingTable");
  var tblBody = document.createElement("tbody");

  for (var i = 0; i < oneCandidateRawScoreList.length; i++) {
    var imagRow = document.createElement("tr");
    var proImagCell = document.createElement("td");
    var progImagCellText = document.createTextNode("");
    proImagCell.appendChild(progImagCellText);
    $(proImagCell).html(inputProbeImageTxt).appendTo(imagRow);
    $(proImagCell).change(readProbeImage);

    imagRow.appendChild(proImagCell);

    var emptyCell = document.createElement("td");
    emptyCell.setAttribute("colSpan", 3);
    imagRow.appendChild(emptyCell); 

    var targetImagCell = document.createElement("td");
    var targeImagCellText = document.createTextNode("");
    targetImagCell.appendChild(targeImagCellText);
    $(targetImagCell).html(inputTargeImageTxt).appendTo(imagRow);
    $(targetImagCell).change(readTargetImage);
    imagRow.appendChild(targetImagCell);

    tblBody.appendChild(imagRow);

    var currentVal = oneCandidateRawScoreList[i];
    var row = document.createElement("tr");
    for (var j = 0; j < 10; j++) {
      var cell = document.createElement("td");
      switch (j) {
        case 0:
        case 4:
          var cellText = document.createTextNode("");
          cell.appendChild(cellText);
          $(cell).html(inputFileTxt).appendTo(row);
          row.appendChild(cell);
          break;

        case 3:
        case 7:
          var cellText = document.createTextNode("");
          cell.appendChild(cellText);
          $(cell).html(submitTxt).appendTo(row);
          $(cell).click(handerTableSubmit);
          row.appendChild(cell);
          break;
        case 1:
          var cellText = document.createTextNode(currentVal.probePosition);
          cell.appendChild(cellText);
          cell.style.verticalAlign = "middle";
          row.appendChild(cell);
          break;
        case 2:
          var cellText = document.createTextNode(currentVal.probeIndex);
          cell.appendChild(cellText);
          cell.style.verticalAlign = "middle";
          row.appendChild(cell);
          break;
        case 5:
          var cellText = document.createTextNode(currentVal.targetPosition);
          cell.appendChild(cellText);
          cell.style.verticalAlign = "middle";
          row.appendChild(cell);
          break;
        case 6:
          var cellText = document.createTextNode(currentVal.targetIndex);
          cell.appendChild(cellText);
          cell.style.verticalAlign = "middle";
          row.appendChild(cell);
          break;
        case 8:
          var cellText = document.createTextNode("");
          cell.appendChild(cellText);
          $(cell).html(chartBtn).appendTo(row);
          $(cell).click(doAllCharting);
          row.appendChild(cell);
          break;
        case 9:
          var cellText = document.createTextNode("");
          cell.appendChild(cellText);
          $(cell).html(oneByoneBtn).appendTo(row);
          $(cell).click(doOneByOneCharting);
          row.appendChild(cell);
          break;
      }
    }
    tblBody.appendChild(row);
  }
  chartTable.appendChild(tblBody);
}

function doAllCharting(evt) {
  if (!oneCandidateRawScoreList || oneCandidateRawScoreList.length < 1) {
    alert("No data to process, stop.");
    return;
  }
  $("#viewTrigger").collapse('hide');
  var col = $(this).parent().children().index($(this));
  var row = $(this).parent().parent().children().index($(this).parent());
  var tab = document.getElementById("chartingTable");
  var probeFigerName = tab.rows[row + 1].cells[1].innerHTML;
  var probeIndex = tab.rows[row + 1].cells[2].innerHTML;
  var targetFigerName = tab.rows[row + 1].cells[5].innerHTML;
  var targetIndex = tab.rows[row + 1].cells[6].innerHTML;
  for (let i = 0; i < oneCandidateRawScoreList.length; i++) {
    let temp = oneCandidateRawScoreList[i];
    if (temp.probePosition == probeFigerName &&
      temp.probeIndex == probeIndex &&
      temp.targetPosition == targetFigerName &&
      temp.targetIndex == targetIndex) {
      var minutiaList = temp.matchedDataList;
      minutiaPairList = minutiaList;
      mappingAll(minutiaList);
      //tab.deleteRow(row + 1);
     // tab.deleteRow(row);
      return;
    }
  }
}


function doOneByOneCharting() {
  if (!oneCandidateRawScoreList || oneCandidateRawScoreList.length < 1) {
    alert("No data to process, stop.");
    return;
  }
  $("#viewTrigger").collapse('hide');
  if (!oneCandidateRawScoreList || oneCandidateRawScoreList.length < 1) {
    alert("No data to process, stop.");
    return;
  }
  var col = $(this).parent().children().index($(this));
  var row = $(this).parent().parent().children().index($(this).parent());
  var tab = document.getElementById("chartingTable");

  var probeFigerName = tab.rows[row + 1].cells[1].innerHTML;
  var probeIndex = tab.rows[row + 1].cells[2].innerHTML;
  var targetFigerName = tab.rows[row + 1].cells[5].innerHTML;
  var targetIndex = tab.rows[row + 1].cells[6].innerHTML;
  for (let i = 0; i < oneCandidateRawScoreList.length; i++) {
    let temp = oneCandidateRawScoreList[i];
    if (temp.probePosition == probeFigerName &&
      temp.probeIndex == probeIndex &&
      temp.targetPosition == targetFigerName &&
      temp.targetIndex == targetIndex) {
      var minutiaList = temp.matchedDataList;
      minutiaPairList = minutiaList;
      drawDotChartOneByOne(minutiaList);
      //tab.deleteRow(row + 1);
     // tab.deleteRow(row);
      return;
    }
  }
}