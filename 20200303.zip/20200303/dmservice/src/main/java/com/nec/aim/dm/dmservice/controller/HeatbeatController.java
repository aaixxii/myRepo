package com.nec.aim.dm.dmservice.controller;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.nec.aim.dm.dmservice.config.ConfigProperties;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class HeatbeatController  extends HttpServlet {	
	
	private static final long serialVersionUID = -1378099207373980147L;
	@Autowired
	ConfigProperties config;
	
	@GetMapping("/heatbeat")
	public void isActive(HttpServletRequest req, HttpServletResponse res) throws Exception {		
			String resposeString = getMyIP();
			if (resposeString == null || resposeString.isEmpty()) {
				log.warn("There are some wrong, request ip is not myIp");				
			}
			res.getOutputStream().write(resposeString.getBytes());	
	}
	
	private String getMyIP() throws Exception {
		String resString = null;
		Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
		boolean stop = false;
		InetAddress myIp = null;
		while (e.hasMoreElements() && !stop) {
			NetworkInterface n = (NetworkInterface) e.nextElement();
			Enumeration<?> ee = n.getInetAddresses();
			while (ee.hasMoreElements()) {
				InetAddress i = (InetAddress) ee.nextElement();
				if (isMyId(i)) {	
					myIp = i;
					stop = true;					
				}
				if (stop) break;
			}
			if (stop) break;
		}
		
		if (myIp != null) {
			resString = myIp.getHostAddress() + " is active";
		} else {
			resString = "";
		}
		return resString;
	}
	
	private boolean isMyId(InetAddress addr) {
		String allIp = config.getConnectString();
		//String allIp = "192.168.232.143:2181,192.168.232.146:2181,127.0.0.1:2181";
		String[] ipArr = allIp.split(",") == null || allIp.split(",").length < 0 ? new String[] {} :  allIp.split(",") ;
		if (ipArr.length > 0) {
			for (String arr : ipArr) {
				int index = arr.indexOf(":");
				String ip = arr.substring(0, index);
				if (addr.getHostAddress().equals(ip)) {
					return true;
				}			
			}			
		}
		return false;
	}
}



