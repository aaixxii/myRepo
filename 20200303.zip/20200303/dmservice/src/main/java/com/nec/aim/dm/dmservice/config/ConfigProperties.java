package com.nec.aim.dm.dmservice.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
public class ConfigProperties {
	 @Value("${dm.connectString}")
    private String connectString; 
	 
	 @Value("${dm.charset}")
    private String charset;
}  



