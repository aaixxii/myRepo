package com.nec.aim.dm.dmservice.dispatch;


import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.dmservice.entity.Node;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.NodeRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class Dispatcher {
	
	@Autowired
	NodeRepository nodeRepository;
	
	public Boolean dispatchPostRequest(PBDmSyncRequest dmSegReq) {
 		List<Node> activeList = null;
//		Node node = new Node();
//		node.setId(1L);
//		node.setAddress("http://localhost:8080");
//		node.setDiskSize(20000);
//		node.setSpace(20000);
//		node.setStatus(1);			
//		node.setTs(new Timestamp(System.currentTimeMillis()));
		try {
			//nodeRepository.insert(node);
			activeList = nodeRepository.findAll();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
		if (activeList == null ||  activeList .size() < 1) {
			return Boolean.valueOf(false);
		}
		boolean result = true;
		for (Node one : activeList) {
			 boolean oneResult = HttpPoster.post(one.getAddress(), dmSegReq);
			 result = result && oneResult;
		}	
		return Boolean.valueOf(result);
	}
	
	public byte[] dispatchGetRequest(Long segId) throws InterruptedException, ExecutionException {
		List<Node> activeList = nodeRepository.findAll();
		if (activeList == null ||  activeList .size() < 1) {
			throw new DmServiceException("No active dm stroage node for process");
		}
		Collections.shuffle(activeList);
		byte[] result = HttpPoster.getSegment(activeList.get(0).getAddress(), segId);
		return result;
	}
}
