package com.nec.aim.dm.dmservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmserviceApplication.class, args);
	}
}
