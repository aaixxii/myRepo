package jp.co.nec.aim.mm.extract.dispatch;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.receiver.FEplanCreatedEventReceiver;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mockit;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class FEplanCreatedEventReceiverTest {
	private BrokerService broker = null;
	private String jmsURL = "tcp://localhost:61296";
	private String fEDispatcherQueue = JNDIConstants.EXTRACT_JOB_DISPATCH_QUEUE;
	private String mesgToFeDispatcher = "10001";
	@Resource
	private FEplanCreatedEventReceiver receiver;

	@Before
	public void setUp() throws Exception {
		broker = new BrokerService();
		broker.setBrokerName("AIM_JMS_SERVER");
		broker.addConnector(jmsURL);
		broker.setPersistent(false);
		broker.start();
		send(mesgToFeDispatcher);
	}

	public void send(String msg) throws JMSException {
		ConnectionFactory factory = new ActiveMQConnectionFactory(jmsURL);
		Connection connection = factory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		Destination queue = session.createQueue(fEDispatcherQueue);
		MessageProducer producer = session.createProducer(queue);
		TextMessage message = session.createTextMessage(msg);
		producer.send(message);
		connection.close();
	}

	@After
	public void tearDown() throws Exception {
		broker.stop();
	}

	@Test
	public void testOnMessage() throws JMSException {
		new MockUp<FEPlanDispatcher>() {
			@Mock
			public boolean doDispatch(Long feLotJobId) {
				return true;
			}
		};
		ConnectionFactory factory = new ActiveMQConnectionFactory(jmsURL);
		Connection connection = factory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		Destination queue = session.createQueue(fEDispatcherQueue);
		MessageConsumer consumer = session.createConsumer(queue);
		consumer.setMessageListener(receiver);
		Message rcvMessage = (Message) consumer.receive();
		TextMessage txtMsg = (TextMessage) rcvMessage;
		Assert.assertEquals(mesgToFeDispatcher, txtMsg.getText());
		Mockit.tearDownMocks();
	}
}
