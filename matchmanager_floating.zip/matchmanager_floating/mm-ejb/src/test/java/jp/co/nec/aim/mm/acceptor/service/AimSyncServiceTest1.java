package jp.co.nec.aim.mm.acceptor.service;

import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncInsertPayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobResponse;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:jp/co/nec/aim/mm/acceptor/service/AimSyncServiceTest-context.xml")
@Transactional
public class AimSyncServiceTest1 extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private AimSyncService aimSyncService;
	@Resource
	private JdbcTemplate jdbcTemplate;
	private ScriptManager manager = ScriptManager.getInstance();

	@Before
	public void setUp() {
		manager.clear();
		URL url2 = this.getClass().getResource("delete_containers.sql");
		executeSqlScript("file:///" + url2.getPath(), false);
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.execute("commit");
		setMockMethod();
	}

	@After
	public void tearDown() {
		URL url2 = this.getClass().getResource("delete_containers.sql");
		executeSqlScript("file:///" + url2.getPath(), false);
		jdbcTemplate
				.update("update CONTAINERS set MAX_SEGMENT_SIZE = 20000000 ");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.execute("commit");

	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object message) {
				return;
			}
		};
	}

	@Test
	public void testSyncDataDeleteNewSegRDBT_NOSCOPE() {
		jdbcTemplate.update("delete from person_biometrics");
		URL url2 = this.getClass().getResource("delete_containers.sql");
		executeSqlScript("file:///" + url2.getPath(), false);
		URL url = this.getClass().getResource("insert_containers.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		// jdbcTemplate.update("insert into segments (SEGMENT_ID,)");
		// segment_seq.NEXTVAL
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();

		aimSyncService.syncData(syncJobRequest1);

		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBT);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(1331,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, listSeg.size());
		Map<String, Object> mapSeg1 = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg1.get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg1.get("VERSION").toString()));
		Assert.assertEquals(1001,
				Integer.parseInt(mapSeg1.get("CONTAINER_ID").toString()));
		Map<String, Object> mapSeg2 = listSeg.get(1);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg2.get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg2.get("VERSION").toString()));
		Assert.assertEquals(1331,
				Integer.parseInt(mapSeg2.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Test
	public void testSyncDataDeleteNewSegRDBT_NOSCOPE_NOKeyTemplate() {
		jdbcTemplate.update("delete from person_biometrics");
		URL url2 = this.getClass().getResource("delete_containers.sql");
		executeSqlScript("file:///" + url2.getPath(), false);
		URL url = this.getClass().getResource("insert_containers.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		// jdbcTemplate.update("insert into segments (SEGMENT_ID,)");
		// segment_seq.NEXTVAL
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();

		aimSyncService.syncData(syncJobRequest1);

		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1)
				.setDeletePayload(PBSyncDeletePayload.newBuilder()).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, listSeg.size());
		Map<String, Object> mapSeg1 = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg1.get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg1.get("VERSION").toString()));
		Assert.assertEquals(1001,
				Integer.parseInt(mapSeg1.get("CONTAINER_ID").toString()));
		Map<String, Object> mapSeg2 = listSeg.get(1);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg2.get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg2.get("VERSION").toString()));
		Assert.assertEquals(1331,
				Integer.parseInt(mapSeg2.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(2, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Test
	public void testSyncDataInsertUpdSegRDBT_NoScope() {
		jdbcTemplate.update("delete from person_biometrics");
		URL url2 = this.getClass().getResource("delete_containers.sql");
		executeSqlScript("file:///" + url2.getPath(), false);
		URL url = this.getClass().getResource("insert_containers.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(1001,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");
		URL url1 = this.getClass().getResource("delete_containers.sql");
		executeSqlScript("file:///" + url1.getPath(), false);

	}

}
