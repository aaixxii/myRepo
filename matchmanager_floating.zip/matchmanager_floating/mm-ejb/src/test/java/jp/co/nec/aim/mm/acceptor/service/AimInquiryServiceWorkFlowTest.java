package jp.co.nec.aim.mm.acceptor.service;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobResultInternal;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryPayload;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatisticsAMR;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.FusionJobEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimInquiryServiceWorkFlowTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private AimInquiryService aimInquiryService;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FUSION_JOBS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.execute("commit");
		setMockMethod();
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FUSION_JOBS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.execute("commit");
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}

	@Test
	public void testInquiry_1top_1fusion_aggregation()
			throws InvalidProtocolBufferException {
		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TI).setPriority(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder()
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addScope(1))
				.setKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_TI)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_ROLLED))
												.setTemplateBinary(
														ByteString
																.copyFrom(new byte[] {
																		0, 1 }))));
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);
		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				true);
		// jdbcTemplate.execute("commit");

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.PROTOBUF, job.getCallbackStyle());
		Assert.assertEquals(JobState.DONE, job.getJobState());
		Assert.assertEquals(1, job.getPriority());
		Assert.assertEquals(false, job.getFailedFlag());
		Assert.assertEquals(10, job.getMaxCandidates().intValue());
		Assert.assertEquals(2000, job.getHitThreshold().intValue());
		Assert.assertTrue(5.2d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(0, job.getRemainJobs());
		Assert.assertEquals(1, job.getFamilyId());

		PBInquiryJobResultInternal result = PBInquiryJobResultInternal
				.parseFrom(job.getResults());
		System.out.println(result);
		Assert.assertTrue(result.hasStatistics());
		PBInquiryResultStatisticsAMR amr = result.getStatistics().getAmr();
		Assert.assertEquals(0, amr.getReadCount());
		Assert.assertEquals(0, amr.getMatchCount());

		// fusion job check
		List<FusionJobEntity> fusionJobs = dao.getFusionJob(jobId, 1);
		Assert.assertEquals(1, fusionJobs.size());
		Assert.assertEquals(jobId, fusionJobs.get(0).getJobId());
		Assert.assertEquals(0, fusionJobs.get(0).getSearchRequestIndex());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(fusionJobs
				.get(0).getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(1, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.TI, request.getJobInfo()
				.getFunction());
		Assert.assertEquals(StringUtils.EMPTY, request.getJobInfo()
				.getCallBackUrl());
		Assert.assertEquals(1, request.getFusionJobInputCount());
		Assert.assertTrue(request.hasJobInfo());

		/*
		 * PBInquiryOptions options = request.getFusionJobInput(0)
		 * .getInquiryOptions();
		 * 
		 * Assert.assertEquals(100, options.getMinScore());
		 */
	}

	@Test
	public void testInquiry_1top_2fusion_4containerjob_normal_TI()
			throws InvalidProtocolBufferException {
		// container id 1
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 1, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 1, 101, 200, 100, 1, 1, 100)");

		// container id 2
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(3, 7, 2, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(4, 7, 2, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TI).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder()
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setInquiryOptions(
						PBInquiryOptions
								.newBuilder()
								.setMinScore(121)
								.setInquiryPayload(
										PBInquiryPayload.newBuilder())
								.addFusionWeight(
										PBInquiryFusionWeight
												.newBuilder()
												.setInquirySet(
														FingerSetType.PC2_SLAP)
												.setWeight(20)))
				.setKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_TI)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_SLAP))
												.setTemplateBinary(
														ByteString
																.copyFrom(new byte[] {
																		0, 1 }))));
		PBFusionJobInput.Builder fusionJobBuilder1 = PBFusionJobInput
				.newBuilder()
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setInquiryOptions(
						PBInquiryOptions
								.newBuilder()
								.setMinScore(121)
								.setInquiryPayload(
										PBInquiryPayload.newBuilder())
								.addFusionWeight(
										PBInquiryFusionWeight
												.newBuilder()
												.setInquirySet(
														FingerSetType.PC2_ROLLED)
												.setWeight(20)))
				.setKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_TI)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_ROLLED))
												.setTemplateBinary(
														ByteString
																.copyFrom(new byte[] {
																		0, 1 }))));
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder)
				.addFusionJobInput(fusionJobBuilder1);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(121, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(4, job.getRemainJobs());
		Assert.assertEquals(1, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check
		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 1);
		Assert.assertEquals(2, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		FusionJobEntity f2 = fusionJob1s.get(1);
		Assert.assertEquals(jobId, f2.getJobId());
		Assert.assertEquals(1, f2.getSearchRequestIndex());

		// container job check
		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 1);

		Assert.assertEquals(1, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		List<ContainerJobEntity> cjob2 = dao.getContainerJob(
				f1.getFusionJobId(), 2);
		Assert.assertEquals(2, cjob2.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob2.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob2.get(0).getJobState());

		List<ContainerJobEntity> cjob3 = dao.getContainerJob(
				f2.getFusionJobId(), 1);
		Assert.assertEquals(1, cjob3.get(0).getContainerId());
		Assert.assertEquals(f2.getFusionJobId(), cjob3.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob3.get(0).getJobState());

		List<ContainerJobEntity> cjob4 = dao.getContainerJob(
				f2.getFusionJobId(), 2);
		Assert.assertEquals(2, cjob4.get(0).getContainerId());
		Assert.assertEquals(f2.getFusionJobId(), cjob4.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob4.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.TI, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertTrue(request.hasJobInfo());
		PBInquiryScopeOptions scopeOptions = request.getFusionJobInput(0)
				.getScopes();
		Assert.assertEquals(1, scopeOptions.getScopeCount());
		Assert.assertEquals(1, scopeOptions.getScopeList().get(0).intValue());
		Assert.assertEquals(2, scopeOptions.getTargetFingerPrintCount());
	}

	@Test
	public void testInquiry_1top_2fusion_4containerjob_normal_TIM()
			throws InvalidProtocolBufferException {
		// container id 331
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 331, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 331, 101, 200, 100, 1, 1, 100)");

		// container id 332
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(3, 7, 332, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(4, 7, 332, 101, 200, 100, 1, 1, 100)");
		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TIM).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(20));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TIM)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 }))
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		PBFusionJobInput.Builder fusionJobBuilder1 = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder)
				.addFusionJobInput(fusionJobBuilder1);
		try {
			aimInquiryService.inquiry(b.build(), false);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Inquiry Job (The combination of (key fingerPrintType) was duplicate.)",
					e.getMessage());
		}
	}

	@Test
	public void testInquiry_1top_4fusion_8containerjob_normal_TLI()
			throws InvalidProtocolBufferException {
		// container id 331
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 321, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 321, 101, 200, 100, 1, 1, 100)");

		// container id 332
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(3, 7, 326, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(4, 7, 336, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TLI).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder optionsBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_ROLLED)
								.setWeight(20));
		PBInquiryOptions.Builder optionsBuilder1 = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(20));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLI)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 }))
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBKeyedTemplateData.Builder templateBuilder1 = PBKeyedTemplateData
				.newBuilder()
				.setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIS)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 }))
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(optionsBuilder)
				.setKeyedTemplateData(templateBuilder);
		PBFusionJobInput.Builder fusionJobBuilder1 = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(optionsBuilder)
				.setKeyedTemplateData(templateBuilder);
		PBFusionJobInput.Builder fusionJobBuilder2 = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(optionsBuilder1)
				.setKeyedTemplateData(templateBuilder1);
		PBFusionJobInput.Builder fusionJobBuilder3 = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(optionsBuilder1)
				.setKeyedTemplateData(templateBuilder1);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder)
				.addFusionJobInput(fusionJobBuilder1)
				.addFusionJobInput(fusionJobBuilder2)
				.addFusionJobInput(fusionJobBuilder3);

		try {
			aimInquiryService.inquiry(b.build(), false);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Inquiry Job (The combination of (key fingerPrintType) was duplicate.)",
					e.getMessage());
		}
	}

	@Test
	public void testInquiry_1top_2fusion_2containerjob_normal_TLIM()
			throws InvalidProtocolBufferException {
		// container id 336
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 336, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 336, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TLIM).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(20));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIM)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 }))
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		PBFusionJobInput.Builder fusionJobBuilder1 = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder)
				.addFusionJobInput(fusionJobBuilder1);
		try {
			aimInquiryService.inquiry(b.build(), false);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Inquiry Job (The combination of (key fingerPrintType) was duplicate.)",
					e.getMessage());
		}
	}

	@Test
	public void testInquiry_1top_2fusion_4containerjob_normal_TLIX()
			throws InvalidProtocolBufferException {
		// container id 1
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 1, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 1, 101, 200, 100, 1, 1, 100)");

		// container id 2
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(3, 7, 2, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(4, 7, 342, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TLIX).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(20));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		PBFusionJobInput.Builder fusionJobBuilder1 = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder)
				.addFusionJobInput(fusionJobBuilder1);
		try {
			aimInquiryService.inquiry(b.build(), false);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Inquiry Job (The combination of (key fingerPrintType) was duplicate.)",
					e.getMessage());
		}

	}

	@Test
	public void testInquiry_1top_2fusion_4containerjob_normal_LI()
			throws InvalidProtocolBufferException {
		// container id 3,4
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 3, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 4, 101, 200, 100, 1, 1, 100)");

		// container id 323,324
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(3, 7, 323, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(4, 7, 324, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.LI).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_LATENT)
								.setWeight(20));

		PBInquiryOptions.Builder inqBuilder1 = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_LATENT)
								.setWeight(20));

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LI)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));

		PBKeyedTemplateData.Builder templateBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LIS)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		PBFusionJobInput.Builder fusionJobBuilder1 = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder1)
				.setKeyedTemplateData(templateBuilder1);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder)
				.addFusionJobInput(fusionJobBuilder1);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(121, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(4, job.getRemainJobs());
		Assert.assertEquals(2, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJobs = dao.getFusionJob(jobId, 8);
		Assert.assertEquals(1, fusionJobs.size());
		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 2);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		FusionJobEntity f2 = fusionJobs.get(0);
		Assert.assertEquals(jobId, f2.getJobId());
		Assert.assertEquals(1, f2.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(4, list.size());

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 3);

		Assert.assertEquals(3, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());
		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob2 = dao.getContainerJob(
				f1.getFusionJobId(), 4);

		Assert.assertEquals(4, cjob2.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob2.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob2.get(0).getJobState());

		List<ContainerJobEntity> cjob3 = dao.getContainerJob(
				f2.getFusionJobId(), 323);

		Assert.assertEquals(323, cjob3.get(0).getContainerId());
		Assert.assertEquals(f2.getFusionJobId(), cjob3.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob3.get(0).getJobState());

		List<ContainerJobEntity> cjob4 = dao.getContainerJob(
				f2.getFusionJobId(), 324);
		Assert.assertEquals(324, cjob4.get(0).getContainerId());
		Assert.assertEquals(f2.getFusionJobId(), cjob4.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob4.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.LI, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	/*
	 * @Test public void testInquiry_1top_2fusion_4containerjob_normal_LIS()
	 * throws InvalidProtocolBufferException { // container id 3,4 jdbcTemplate
	 * .update("INSERT INTO SEGMENTS " +
	 * "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END," +
	 * " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
	 * + " VALUES(1, 7, 3, 1, 100, 100, 1, 1, 100)"); jdbcTemplate
	 * .update("INSERT INTO SEGMENTS " +
	 * "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END," +
	 * " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
	 * + " VALUES(2, 7, 4, 101, 200, 100, 1, 1, 100)");
	 * 
	 * // container id 323,324 jdbcTemplate .update("INSERT INTO SEGMENTS " +
	 * "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END," +
	 * " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
	 * + " VALUES(3, 7, 323, 1, 100, 100, 1, 1, 100)"); jdbcTemplate
	 * .update("INSERT INTO SEGMENTS " +
	 * "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END," +
	 * " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
	 * + " VALUES(4, 7, 324, 101, 200, 100, 1, 1, 100)");
	 * 
	 * PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
	 * PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
	 * .setFunction(InquiryFunctionType.LIS).setPriority(3)
	 * .setMaxCandidate(32).setDynThreshHitThreshold(200)
	 * .setDynThreshPercentagePoint(5.4f)
	 * .setCallBackUrl("http://192.168.1.83/callback"); PBInquiryOptions.Builder
	 * inqBuilder = PBInquiryOptions .newBuilder() .setMinScore(121)
	 * .setInquiryPayload(PBInquiryPayload.newBuilder()) .addFusionWeight(
	 * PBInquiryFusionWeight.newBuilder()
	 * .setInquirySet(FingerSetType.PC2_LATENT) .setWeight(20));
	 * 
	 * PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
	 * .newBuilder() .setKeyedTemplate( PBKeyedTemplate .newBuilder()
	 * .setKey(TemplateFormatType.TEMPLATE_LIS)
	 * .setIndexer(PBKeyedTemplateIndexer.newBuilder()) .setTemplateBinary(
	 * ByteString.copyFrom(new byte[] { 0, 4, 1 })));
	 * PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
	 * .newBuilder().addScope(1); PBFusionJobInput.Builder fusionJobBuilder =
	 * PBFusionJobInput .newBuilder().setScopes(scopeBuilder)
	 * .setInquiryOptions(inqBuilder) .setKeyedTemplateData(templateBuilder);
	 * b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);
	 * 
	 * PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
	 * false);
	 * 
	 * PBServiceState state = response.getServiceState();
	 * Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
	 * state.getState());
	 * 
	 * long jobId = response.getJobId();
	 * 
	 * // top level job check InquiryJobDao dao = new
	 * InquiryJobDao(entityManager, dataSource); JobQueueEntity job =
	 * dao.getTopLevelJob(jobId); Assert.assertTrue(job != null);
	 * 
	 * Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
	 * Assert.assertEquals(JobState.QUEUED, job.getJobState());
	 * Assert.assertEquals(3, job.getPriority()); Assert.assertEquals(32,
	 * job.getMaxCandidates().intValue()); Assert.assertEquals(121,
	 * job.getMinScore().intValue()); Assert.assertEquals(200,
	 * job.getHitThreshold().intValue()); Assert.assertTrue(5.4d ==
	 * job.getPercentagePoint().doubleValue()); Assert.assertEquals(0,
	 * job.getFailureCount()); Assert.assertEquals(2, job.getRemainJobs());
	 * Assert.assertEquals(2, job.getFamilyId());
	 * Assert.assertEquals("http://192.168.1.83/callback",
	 * job.getCallbackUrl()); Assert.assertNull(job.getResults());
	 * 
	 * // fusion job check
	 * 
	 * List<FusionJobEntity> fusionJobs = dao.getFusionJob(jobId, 8);
	 * Assert.assertEquals(1, fusionJobs.size());
	 * 
	 * 
	 * FusionJobEntity f1 = fusionJobs.get(0); Assert.assertEquals(jobId,
	 * f1.getJobId()); Assert.assertEquals(0, f1.getSearchRequestIndex());
	 * 
	 * // container job check List<Map<String, Object>> list =
	 * jdbcTemplate.queryForList("select * from container_jobs");
	 * Assert.assertEquals(2, list.size());
	 * 
	 * List<ContainerJobEntity> cjob1 = dao.getContainerJob(
	 * f1.getFusionJobId(), 323);
	 * 
	 * Assert.assertEquals(323, cjob1.get(0).getContainerId());
	 * Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
	 * Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());
	 * 
	 * 
	 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
	 * f1.getFusionJobId(), 324);
	 * 
	 * Assert.assertEquals(324, cjob2.get(0).getContainerId());
	 * Assert.assertEquals(f1.getFusionJobId(), cjob2.get(0).getFusionJobId());
	 * Assert.assertEquals(JobState.QUEUED, cjob2.get(0).getJobState());
	 * 
	 * 
	 * 
	 * // InquiryJobData check PBInquiryJobRequest request =
	 * PBInquiryJobRequest.parseFrom(f1 .getInquiryJobData());
	 * System.out.println(request); Assert.assertEquals(3,
	 * request.getJobInfo().getPriority());
	 * Assert.assertEquals(InquiryFunctionType.LIS, request.getJobInfo()
	 * .getFunction()); Assert.assertEquals("http://192.168.1.83/callback",
	 * request .getJobInfo().getCallBackUrl()); Assert.assertEquals(32,
	 * request.getJobInfo().getMaxCandidate()); Assert.assertTrue(5.4f ==
	 * request.getJobInfo() .getDynThreshPercentagePoint());
	 * Assert.assertTrue(200 == request.getJobInfo()
	 * .getDynThreshHitThreshold()); }
	 */

	@Test
	public void testInquiry_1top_1fusion_2containerjob_normal_LIM()
			throws InvalidProtocolBufferException {
		// container id 333,334
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 333, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 334, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.LIM).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_LATENT)
								.setWeight(20));

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LIM)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(121, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(2, job.getRemainJobs());
		Assert.assertEquals(2, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJobs = dao.getFusionJob(jobId, 19);
		Assert.assertEquals(1, fusionJobs.size());

		FusionJobEntity f1 = fusionJobs.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(2, list.size());

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 333);

		Assert.assertEquals(333, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		List<ContainerJobEntity> cjob2 = dao.getContainerJob(
				f1.getFusionJobId(), 334);

		Assert.assertEquals(334, cjob2.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob2.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob2.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.LIM, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_1fusion_1containerjob_normal_LIX()
			throws InvalidProtocolBufferException {
		// container id 333,341
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 341, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 334, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.LIX).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(20));

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LIX)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(121, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(1, job.getRemainJobs());
		Assert.assertEquals(2, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJobs = dao.getFusionJob(jobId, 23);
		Assert.assertEquals(1, fusionJobs.size());

		FusionJobEntity f1 = fusionJobs.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, list.size());

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 341);

		Assert.assertEquals(341, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.LIX, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_2fusion_2containerjob_normal_LLI()
			throws InvalidProtocolBufferException {
		// container id 321
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 321, 1, 100, 100, 1, 1, 100)");

		// container id 326
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(3, 7, 326, 1, 100, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.LLI).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_LATENT)
								.setWeight(20));

		PBInquiryOptions.Builder inqBuilder1 = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_LATENT)
								.setWeight(20));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LLI)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));

		PBKeyedTemplateData.Builder templateBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LLIS)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		PBFusionJobInput.Builder fusionJobBuilder1 = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder1)
				.setKeyedTemplateData(templateBuilder1);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder)
				.addFusionJobInput(fusionJobBuilder1);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(121, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(2, job.getRemainJobs());
		Assert.assertEquals(4, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJobs = dao.getFusionJob(jobId, 4);
		Assert.assertEquals(1, fusionJobs.size());
		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 10);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJobs.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		FusionJobEntity f2 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f2.getJobId());
		Assert.assertEquals(1, f2.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(2, list.size());

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 321);

		Assert.assertEquals(321, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());
		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob2 = dao.getContainerJob(
				f2.getFusionJobId(), 326);

		Assert.assertEquals(326, cjob2.get(0).getContainerId());
		Assert.assertEquals(f2.getFusionJobId(), cjob2.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob2.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.LLI, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	/*
	 * @Test public void testInquiry_1top_1fusion_1containerjob_normal_LLIS()
	 * throws InvalidProtocolBufferException { // container id 321 jdbcTemplate
	 * .update("INSERT INTO SEGMENTS " +
	 * "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END," +
	 * " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
	 * + " VALUES(1, 7, 321, 1, 100, 100, 1, 1, 100)");
	 * 
	 * // container id 326 jdbcTemplate .update("INSERT INTO SEGMENTS " +
	 * "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END," +
	 * " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
	 * + " VALUES(3, 7, 326, 1, 100, 100, 1, 1, 100)");
	 * 
	 * PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
	 * PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
	 * .setFunction(InquiryFunctionType.LLIS).setPriority(3)
	 * .setMaxCandidate(32).setDynThreshHitThreshold(200)
	 * .setDynThreshPercentagePoint(5.4f)
	 * .setCallBackUrl("http://192.168.1.83/callback"); PBInquiryOptions.Builder
	 * inqBuilder = PBInquiryOptions .newBuilder() .setMinScore(121)
	 * .setInquiryPayload(PBInquiryPayload.newBuilder()) .addFusionWeight(
	 * PBInquiryFusionWeight.newBuilder()
	 * .setInquirySet(FingerSetType.PC2_LATENT) .setWeight(20));
	 * 
	 * PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
	 * .newBuilder() .setKeyedTemplate( PBKeyedTemplate .newBuilder()
	 * .setKey(TemplateFormatType.TEMPLATE_LLIS)
	 * .setIndexer(PBKeyedTemplateIndexer.newBuilder()) .setTemplateBinary(
	 * ByteString.copyFrom(new byte[] { 0, 4, 1 })));
	 * PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
	 * .newBuilder().addScope(1); PBFusionJobInput.Builder fusionJobBuilder =
	 * PBFusionJobInput .newBuilder().setScopes(scopeBuilder)
	 * .setInquiryOptions(inqBuilder) .setKeyedTemplateData(templateBuilder);
	 * b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);
	 * 
	 * PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
	 * false);
	 * 
	 * PBServiceState state = response.getServiceState();
	 * Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
	 * state.getState());
	 * 
	 * long jobId = response.getJobId();
	 * 
	 * // top level job check InquiryJobDao dao = new
	 * InquiryJobDao(entityManager, dataSource); JobQueueEntity job =
	 * dao.getTopLevelJob(jobId); Assert.assertTrue(job != null);
	 * 
	 * Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
	 * Assert.assertEquals(JobState.QUEUED, job.getJobState());
	 * Assert.assertEquals(3, job.getPriority()); Assert.assertEquals(32,
	 * job.getMaxCandidates().intValue()); Assert.assertEquals(121,
	 * job.getMinScore().intValue()); Assert.assertEquals(200,
	 * job.getHitThreshold().intValue()); Assert.assertTrue(5.4d ==
	 * job.getPercentagePoint().doubleValue()); Assert.assertEquals(0,
	 * job.getFailureCount()); Assert.assertEquals(1, job.getRemainJobs());
	 * Assert.assertEquals(4, job.getFamilyId());
	 * Assert.assertEquals("http://192.168.1.83/callback",
	 * job.getCallbackUrl()); Assert.assertNull(job.getResults());
	 * 
	 * // fusion job check
	 * 
	 * List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 10);
	 * Assert.assertEquals(1, fusionJob1s.size());
	 * 
	 * 
	 * FusionJobEntity f1 = fusionJob1s.get(0); Assert.assertEquals(jobId,
	 * f1.getJobId()); Assert.assertEquals(0, f1.getSearchRequestIndex());
	 * 
	 * // container job check List<Map<String, Object>> list =
	 * jdbcTemplate.queryForList("select * from container_jobs");
	 * Assert.assertEquals(1, list.size());
	 * 
	 * 
	 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
	 * f2.getFusionJobId(), 3 );
	 * 
	 * List<ContainerJobEntity> cjob1 = dao.getContainerJob(
	 * f1.getFusionJobId(), 326);
	 * 
	 * Assert.assertEquals(326, cjob1.get(0).getContainerId());
	 * Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
	 * Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());
	 * 
	 * 
	 * // InquiryJobData check PBInquiryJobRequest request =
	 * PBInquiryJobRequest.parseFrom(f1 .getInquiryJobData());
	 * System.out.println(request); Assert.assertEquals(3,
	 * request.getJobInfo().getPriority());
	 * Assert.assertEquals(InquiryFunctionType.LLIS, request.getJobInfo()
	 * .getFunction()); Assert.assertEquals("http://192.168.1.83/callback",
	 * request .getJobInfo().getCallBackUrl()); Assert.assertEquals(32,
	 * request.getJobInfo().getMaxCandidate()); Assert.assertTrue(5.4f ==
	 * request.getJobInfo() .getDynThreshPercentagePoint());
	 * Assert.assertTrue(200 == request.getJobInfo()
	 * .getDynThreshHitThreshold()); }
	 */

	@Test
	public void testInquiry_1top_1fusion_1containerjob_normal_LLIM()
			throws InvalidProtocolBufferException {
		// container id 336
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 336, 1, 100, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.LLIM).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_LATENT)
								.setWeight(20));

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LLIM)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(121, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(1, job.getRemainJobs());
		Assert.assertEquals(4, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 22);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, list.size());

		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 336);

		Assert.assertEquals(336, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.LLIM, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_1fusion_1containerjob_normal_LLIX()
			throws InvalidProtocolBufferException {
		// container id 342
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 342, 1, 100, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.LLIX).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBInquiryOptions.Builder inqBuilder = PBInquiryOptions
				.newBuilder()
				.setMinScore(121)
				.setInquiryPayload(PBInquiryPayload.newBuilder())
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_LATENT)
								.setWeight(20));

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LLIX)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setInquiryOptions(inqBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(121, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(1, job.getRemainJobs());
		Assert.assertEquals(4, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 25);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, list.size());

		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 342);

		Assert.assertEquals(342, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.LLIX, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_1fusion_1containerjob_normal_LIP()
			throws InvalidProtocolBufferException {
		// container id 5
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 5, 1, 100, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.LIP).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LIP)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(100, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(1, job.getRemainJobs());
		Assert.assertEquals(5, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 5);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, list.size());

		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 5);

		Assert.assertEquals(5, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.LIP, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_1fusion_1containerjob_normal_TLIP()
			throws InvalidProtocolBufferException {
		// container id 322
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 322, 1, 100, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TLIP).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIP)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(100, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(1, job.getRemainJobs());
		Assert.assertEquals(6, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 6);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, list.size());

		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 322);

		Assert.assertEquals(322, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.TLIP, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_1fusion_1containerjob_normal_LLIP()
			throws InvalidProtocolBufferException {
		// container id 322
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 322, 1, 100, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.LLIP).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LLIP)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(100, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(1, job.getRemainJobs());
		Assert.assertEquals(7, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 7);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, list.size());

		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 322);

		Assert.assertEquals(322, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.LLIP, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_1fusion_1containerjob_normal_FI()
			throws InvalidProtocolBufferException {
		// container id 335
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 335, 1, 100, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.FI).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FI)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(100, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(1, job.getRemainJobs());
		Assert.assertEquals(8, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 20);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, list.size());

		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 335);

		Assert.assertEquals(335, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.FI, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_1fusion_1containerjob_normal_II()
			throws InvalidProtocolBufferException {
		// container id 343
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 343, 1, 100, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.II).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");

		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_II)
								.setTemplateBinary(
										ByteString.copyFrom(new byte[] { 0, 4,
												1 })));
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1);
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder().setScopes(scopeBuilder)
				.setKeyedTemplateData(templateBuilder);
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(100, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(1, job.getRemainJobs());
		Assert.assertEquals(9, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check

		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 26);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(1, list.size());

		/*
		 * List<ContainerJobEntity> cjob2 = dao.getContainerJob(
		 * f2.getFusionJobId(), 3 );
		 */

		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 343);

		Assert.assertEquals(343, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.II, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertEquals(32, request.getJobInfo().getMaxCandidate());
		Assert.assertTrue(5.4f == request.getJobInfo()
				.getDynThreshPercentagePoint());
		Assert.assertTrue(200 == request.getJobInfo()
				.getDynThreshHitThreshold());
	}

	@Test
	public void testInquiry_1top_2fusionDUP_4containerjob_normal_TI()
			throws InvalidProtocolBufferException {
		// container id 1
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 1, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 1, 101, 200, 100, 1, 1, 100)");

		// container id 2
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(3, 7, 2, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(4, 7, 2, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TI).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder()
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setInquiryOptions(
						PBInquiryOptions
								.newBuilder()
								.setMinScore(121)
								.setInquiryPayload(
										PBInquiryPayload.newBuilder())
								.addFusionWeight(
										PBInquiryFusionWeight
												.newBuilder()
												.setInquirySet(
														FingerSetType.PC2_ROLLED)
												.setWeight(20)))
				.setKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_TI)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_ROLLED))
												.setTemplateBinary(
														ByteString
																.copyFrom(new byte[] {
																		0, 1 }))));
		PBFusionJobInput.Builder fusionJobBuilder1 = PBFusionJobInput
				.newBuilder()
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setInquiryOptions(
						PBInquiryOptions
								.newBuilder()
								.setMinScore(121)
								.setInquiryPayload(
										PBInquiryPayload.newBuilder())
								.addFusionWeight(
										PBInquiryFusionWeight
												.newBuilder()
												.setInquirySet(
														FingerSetType.PC2_ROLLED)
												.setWeight(20)))
				.setKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_TI)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_ROLLED))
												.setTemplateBinary(
														ByteString
																.copyFrom(new byte[] {
																		0, 1 }))));
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder)
				.addFusionJobInput(fusionJobBuilder1);
		try {
			aimInquiryService.inquiry(b.build(), false);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Inquiry Job (The combination of (key fingerPrintType) was duplicate.)",
					e.getMessage());
		}

	}

}
