package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobResultInternal;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.mm.common.TestLogger;
import jp.co.nec.aim.mm.constants.EventLogLevel;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.DefragDao;
import jp.co.nec.aim.mm.dao.MatchManagerDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.SystemConfigEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.extract.dispatch.ExtractJobResultCallBacker;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
import jp.co.nec.aim.mm.procedure.FindUnaggregatedJobProcedure;
import jp.co.nec.aim.mm.sessionbeans.pojo.EventSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExtractJobHandler;
import jp.co.nec.aim.mm.sessionbeans.pojo.InquiryJobHandler;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class PollBeanTest {
	@Resource
	private DataSource dataSource;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Resource
	private PollBean pollBean;

	private DateDao dateDao;
	private SystemConfigDao systemconfigdao;
	private long curTime;
	private static String message;

	@BeforeClass
	public static void beforeClass() {
		new MockUp<LoggerFactory>() {
			@Mock
			public Logger getLogger(String name) {
				return new TestLogger();
			}
		};
	}

	@AfterClass
	public static void afterClass() {
		mockit.Mockit.tearDownMocks();
	}

	@Before
	public void setUp() throws Exception {
		clearDB();
		dateDao = new DateDao(dataSource);
		systemconfigdao = new SystemConfigDao(entityManager);
		systemconfigdao.writeAllMissingProperties(dataSource);

		curTime = dateDao.getCurrentTimeMS();

		intsertUnit();
		insertFeJob();
		intsertInquiryJob();

		jdbcTemplate.execute("insert into SEGMENT_DEFRAGMENTATION("
				+ "CONTAINER_ID, START_TS, END_TS) values(1, "
				+ (curTime - 30 * 1000) + ", 0)");
		jdbcTemplate.execute("insert into MM_EVENTS(NAME, LAST_TS, MM_ID)"
				+ " values('STARTUP', 1421206612748, 1)");

		jdbcTemplate.execute("commit");
		entityManager.flush();

		Query q = entityManager.createNamedQuery("NQ::getConfigEntity");
		q.setParameter("name", "BEHAVIOR.MAX_EXTRACT_JOB_FAILURES");
		SystemConfigEntity e = (SystemConfigEntity) q.getResultList().get(0);
		e.setValue("2");
		entityManager.merge(e);

		setMockMethod();
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
		mockit.Mockit.tearDownMocks();
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TestLogger.message = "";
		TestLogger.level = "";
		TestLogger.isDebugEnabled = true;

		new MockUp<FeJobDoneLogger>() {
			@Mock
			public void info(long jobId) {
				return;
			}
		};

		new MockUp<ExtractJobResultCallBacker>() {
			@Mock
			public void asynchCallback(long jobId, PBExtractJobResult result) {
				return;
			}
		};

		new MockUp<EventSender>() {
			@Mock
			public void sendEvent(String reasonCode, String eventType,
					Long unitId, String description, EventLogLevel level,
					Date date) {
				return;
			}
		};

		new MockUp<ExceptionSender>() {
			@Mock
			private void send(String reasonCode, String msg, long jobId,
					long topLevelId, long unitId, Exception e) {
				message = msg;
				return;
			}
		};

		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object message) {
				return;
			}

		};
	}

	private void clearDB() {
		jdbcTemplate.update("UPDATE INQUIRY_TRAFFIC SET JOB_EXEC_COUNT = 0");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FUSION_JOBS");
		jdbcTemplate.execute("delete from CONTAINER_JOBS");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from FE_JOB_FAILURE_REASONS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from MM_EVENTS");
		jdbcTemplate.execute("delete from MATCH_MANAGERS");
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	private void intsertUnit() {
		for (int id = 1; id <= 3; id++) {
			jdbcTemplate.execute("insert into MATCH_MANAGERS(MM_ID, UNIQUE_ID,"
					+ " STATE, HEARTBEAT_TS) values(" + id + ", '" + id
					+ "', 'WORKING', " + curTime + ")");

			jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
					+ " RING_LOCATION, STATE) values(" + id + ", '" + id
					+ "', " + id + ", 'WORKING')");
			jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
					+ " values(" + id + ", " + curTime + ")");

			jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"
					+ " values(" + id + ", " + curTime + ")");
			jdbcTemplate.execute("insert into MU_EXTRACT_LOAD(MU_ID, PRESSURE,"
					+ " UPDATE_TS) values(" + id + ", 3, " + curTime + ")");

			jdbcTemplate.execute("insert into DATA_MANAGERS(DM_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into DM_CONTACTS(DM_ID, CONTACT_TS)"
					+ " values(" + id + ", " + curTime + ")");
		}
	}

	private void intsertInquiryJob() {
		String jqSQL = "insert into JOB_QUEUE(JOB_ID, PRIORITY, JOB_STATE,"
				+ " SUBMISSION_TS, ASSIGNED_TS, CALLBACK_STYLE, TIMEOUTS,"
				+ " FAILURE_COUNT, REMAIN_JOBS, FAMILY_ID)"
				+ " values(?, 5, ?, 1421206612748, ?, 0, 900000, ?, ?, ?)";

		String fjSQL = "insert into FUSION_JOBS(FUSION_JOB_ID, FUNCTION_ID,"
				+ " JOB_ID, SEARCH_REQUEST_INDEX) values(?, ?, ?, ?)";

		String cjSQL = "insert into CONTAINER_JOBS(CONTAINER_JOB_ID,"
				+ " CONTAINER_ID, FUSION_JOB_ID, MR_ID, ASSIGNED_TS, JOB_STATE,"
				+ " PLAN_ID) values(?, ?, ?, ?, ?, 1, ?)";

		for (int jobId = 1; jobId <= 3; jobId++) {
			jdbcTemplate.update(jqSQL, new Object[] { jobId, 1, curTime, 0, 4,
					jobId });
			jdbcTemplate.update("UPDATE INQUIRY_TRAFFIC SET JOB_EXEC_COUNT = 1"
					+ " WHERE FAMILY_ID=" + jobId);
			for (int fjId = 1; fjId <= 2; fjId++) {
				jdbcTemplate.update(fjSQL, new Object[] {
						(jobId - 1) * 2 + fjId, jobId, jobId, fjId });
				for (int cjId = 1; cjId <= 2; cjId++) {
					jdbcTemplate.update(cjSQL, new Object[] {
							(((jobId - 1) * 2 + fjId) - 1) * 2 + cjId, cjId,
							(jobId - 1) * 2 + fjId, jobId, curTime, jobId });
				}
			}
		}

		jdbcTemplate.update(jqSQL, new Object[] { 4, 1, curTime, 0, 4, 1 });
	}

	private void insertFeJob() {
		String fljSQL = "insert into FE_LOT_JOBS(LOT_JOB_ID, MU_ID,"
				+ " ASSIGNED_TS, TIMEOUTS) values(?, ?, ?, ?)";

		String fejSQL = "insert into FE_JOB_QUEUE(JOB_ID, LOT_JOB_ID, PRIORITY,"
				+ " FUNCTION_ID, JOB_STATE, SUBMISSION_TS, ASSIGNED_TS, MU_ID,"
				+ " CALLBACK_STYLE, CALLBACK_URL, FAILURE_COUNT) values(?, ?,"
				+ "  5,17, ?, 1421206612748, ?, ?, 1, 'test Url', ?)";

		for (int fljId = 1; fljId <= 3; fljId++) {
			jdbcTemplate.update(fljSQL, new Object[] { fljId, fljId, curTime,
					30 * 1000 });
			for (int fejId = 1; fejId <= 3; fejId++) {
				jdbcTemplate.update(fejSQL, new Object[] {
						(fljId - 1) * 3 + fejId, fljId, 1, curTime, fljId, 0 });
			}
		}
	}

	@Test
	public void test_NoTimeOut() {
		pollBean.poll();

		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE"
						+ " order by JOB_ID");
		assertEquals(9, listFeJ.size());
		for (int i = 0; i < listFeJ.size(); i++) {
			assertEquals("" + (i + 1), listFeJ.get(i).get("JOB_ID").toString());
			assertEquals("1", listFeJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + curTime, listFeJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertEquals("0", listFeJ.get(i).get("FAILURE_COUNT").toString());
		}

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " FAILURE_COUNT, REMAIN_JOBS from JOB_QUEUE"
						+ " order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < listTLJ.size(); i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("1", listTLJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + curTime, listTLJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertEquals("0", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("4", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			if (i < 3) {
				assertEquals("1", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			} else {
				assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT")
						.toString());
			}
		}

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, JOB_STATE, ASSIGNED_TS,"
						+ " PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNotNull(listCJ.get(i).get("MR_ID"));
			assertEquals("1", listCJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + curTime, listCJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNotNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(0, reasonCount.intValue());

		// Match Unit
		List<Map<String, Object>> listMUs = jdbcTemplate
				.queryForList("select MU_ID, STATE from MATCH_UNITS order by MU_ID");
		assertEquals(3, listMUs.size());
		for (int i = 0; i < listMUs.size(); i++) {
			assertEquals("" + (i + 1), listMUs.get(i).get("MU_ID").toString());
			assertEquals("WORKING", listMUs.get(i).get("STATE").toString());
		}

		// Map Reducer
		List<Map<String, Object>> listMRs = jdbcTemplate
				.queryForList("select MR_ID, RING_LOCATION, STATE"
						+ " from MAP_REDUCERS order by MR_ID");
		assertEquals(3, listMRs.size());
		for (int i = 0; i < listMRs.size(); i++) {
			assertEquals("" + (i + 1), listMRs.get(i).get("MR_ID").toString());
			assertEquals("" + (i + 1), listMRs.get(i).get("RING_LOCATION")
					.toString());
			assertEquals("WORKING", listMRs.get(i).get("STATE").toString());
		}

		// Data Manager
		List<Map<String, Object>> listDMs = jdbcTemplate
				.queryForList("select DM_ID, STATE from DATA_MANAGERS order by DM_ID");
		assertEquals(3, listDMs.size());
		for (int i = 0; i < listDMs.size(); i++) {
			assertEquals("" + (i + 1), listDMs.get(i).get("DM_ID").toString());
			assertEquals("WORKING", listDMs.get(i).get("STATE").toString());
		}

		// Match Manager
		List<Map<String, Object>> listMMs = jdbcTemplate
				.queryForList("select MM_ID, STATE from MATCH_MANAGERS order by MM_ID");
		assertEquals(3, listMMs.size());
		for (int i = 0; i < listMMs.size(); i++) {
			assertEquals("" + (i + 1), listMMs.get(i).get("MM_ID").toString());
			assertEquals("WORKING", listMMs.get(i).get("STATE").toString());
		}

		// Defrag
		Long defragID = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION", Long.class);
		assertEquals(1, defragID.intValue());
	}

	@Test
	public void test_TopLevelJobTimeOut_Retry() {
		jdbcTemplate.execute("update JOB_QUEUE set ASSIGNED_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " RESULT, RESULT_TS, FAILED_FLAG, FAILURE_COUNT,"
						+ " REMAIN_JOBS from JOB_QUEUE order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < 3; i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("0", listTLJ.get(i).get("JOB_STATE").toString());
			assertNull(listTLJ.get(i).get("ASSIGNED_TS"));
			assertNull(listTLJ.get(i).get("RESULT"));
			assertNull(listTLJ.get(i).get("RESULT_TS"));
			assertNull(listTLJ.get(i).get("FAILED_FLAG"));
			assertEquals("1", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("4", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		assertEquals("4", listTLJ.get(3).get("JOB_ID").toString());
		assertEquals("1", listTLJ.get(3).get("JOB_STATE").toString());
		assertEquals("" + (curTime - 1000000), listTLJ.get(3)
				.get("ASSIGNED_TS").toString());
		assertNull(listTLJ.get(3).get("RESULT"));
		assertNull(listTLJ.get(3).get("RESULT_TS"));
		assertNull(listTLJ.get(3).get("FAILED_FLAG"));
		assertEquals("0", listTLJ.get(3).get("FAILURE_COUNT").toString());
		assertEquals("4", listTLJ.get(3).get("REMAIN_JOBS").toString());

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT").toString());
		}

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, CONTAINER_JOB_RESULT, RESULT_TS,"
						+ " JOB_STATE, ASSIGNED_TS, PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNull(listCJ.get(i).get("MR_ID"));
			assertNull(listCJ.get(i).get("CONTAINER_JOB_RESULT"));
			assertNull(listCJ.get(i).get("RESULT_TS"));
			assertEquals("0", listCJ.get(i).get("JOB_STATE").toString());
			assertNull(listCJ.get(i).get("ASSIGNED_TS"));
			assertNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(0, reasonCount.intValue());

	}

	@Test
	public void test_TopLevelJobTimeOut_Done() {
		jdbcTemplate.execute("update JOB_QUEUE set ASSIGNED_TS = "
				+ (curTime - 1000000) + ", FAILURE_COUNT = 2");

		pollBean.poll();

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " RESULT, RESULT_TS, FAILED_FLAG, FAILURE_COUNT,"
						+ " REMAIN_JOBS from JOB_QUEUE order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < 3; i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("2", listTLJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + (curTime - 1000000),
					listTLJ.get(i).get("ASSIGNED_TS").toString());
			assertNotNull(listTLJ.get(i).get("RESULT"));
			assertNotNull(listTLJ.get(i).get("RESULT_TS"));
			assertEquals("1", listTLJ.get(i).get("FAILED_FLAG").toString());
			assertEquals("3", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("0", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		assertEquals("4", listTLJ.get(3).get("JOB_ID").toString());
		assertEquals("1", listTLJ.get(3).get("JOB_STATE").toString());
		assertEquals("" + (curTime - 1000000), listTLJ.get(3)
				.get("ASSIGNED_TS").toString());
		assertNull(listTLJ.get(3).get("RESULT"));
		assertNull(listTLJ.get(3).get("RESULT_TS"));
		assertNull(listTLJ.get(3).get("FAILED_FLAG"));
		assertEquals("2", listTLJ.get(3).get("FAILURE_COUNT").toString());
		assertEquals("4", listTLJ.get(3).get("REMAIN_JOBS").toString());

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT").toString());
		}

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, CONTAINER_JOB_RESULT, RESULT_TS,"
						+ " JOB_STATE, ASSIGNED_TS, PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNotNull(listCJ.get(i).get("MR_ID"));
			// assertNotNull(listCJ.get(i).get("CONTAINER_JOB_RESULT"));
			assertNotNull(listCJ.get(i).get("RESULT_TS"));
			assertEquals("2", listCJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + curTime, listCJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNotNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(12, reasonCount.intValue());

	}

	@Test
	public void test_ContainerJobTimeOut_Retry() {
		jdbcTemplate.execute("update CONTAINER_JOBS set ASSIGNED_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " RESULT, RESULT_TS, FAILED_FLAG, FAILURE_COUNT,"
						+ " REMAIN_JOBS from JOB_QUEUE order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < 3; i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("0", listTLJ.get(i).get("JOB_STATE").toString());
			assertNull(listTLJ.get(i).get("ASSIGNED_TS"));
			assertNull(listTLJ.get(i).get("RESULT"));
			assertNull(listTLJ.get(i).get("RESULT_TS"));
			assertNull(listTLJ.get(i).get("FAILED_FLAG"));
			assertEquals("1", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("4", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		assertEquals("4", listTLJ.get(3).get("JOB_ID").toString());
		assertEquals("1", listTLJ.get(3).get("JOB_STATE").toString());
		assertEquals("" + curTime, listTLJ.get(3).get("ASSIGNED_TS").toString());
		assertNull(listTLJ.get(3).get("RESULT"));
		assertNull(listTLJ.get(3).get("RESULT_TS"));
		assertNull(listTLJ.get(3).get("FAILED_FLAG"));
		assertEquals("0", listTLJ.get(3).get("FAILURE_COUNT").toString());
		assertEquals("4", listTLJ.get(3).get("REMAIN_JOBS").toString());

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT").toString());
		}

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, CONTAINER_JOB_RESULT, RESULT_TS,"
						+ " JOB_STATE, ASSIGNED_TS, PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNull(listCJ.get(i).get("MR_ID"));
			assertNull(listCJ.get(i).get("CONTAINER_JOB_RESULT"));
			assertNull(listCJ.get(i).get("RESULT_TS"));
			assertEquals("0", listCJ.get(i).get("JOB_STATE").toString());
			assertNull(listCJ.get(i).get("ASSIGNED_TS"));
			assertNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(0, reasonCount.intValue());

	}

	@Test
	public void test_ContainerJobTimeOut_Done() {
		jdbcTemplate.execute("update JOB_QUEUE set FAILURE_COUNT = 2");
		jdbcTemplate.execute("update CONTAINER_JOBS set ASSIGNED_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " RESULT, RESULT_TS, FAILED_FLAG, FAILURE_COUNT,"
						+ " REMAIN_JOBS from JOB_QUEUE order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < 3; i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("2", listTLJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + curTime, listTLJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNotNull(listTLJ.get(i).get("RESULT"));
			assertNotNull(listTLJ.get(i).get("RESULT_TS"));
			assertEquals("1", listTLJ.get(i).get("FAILED_FLAG").toString());
			assertEquals("3", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("0", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		assertEquals("4", listTLJ.get(3).get("JOB_ID").toString());
		assertEquals("1", listTLJ.get(3).get("JOB_STATE").toString());
		assertEquals("" + curTime, listTLJ.get(3).get("ASSIGNED_TS").toString());
		assertNull(listTLJ.get(3).get("RESULT"));
		assertNull(listTLJ.get(3).get("RESULT_TS"));
		assertNull(listTLJ.get(3).get("FAILED_FLAG"));
		assertEquals("2", listTLJ.get(3).get("FAILURE_COUNT").toString());
		assertEquals("4", listTLJ.get(3).get("REMAIN_JOBS").toString());

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT").toString());
		}

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, CONTAINER_JOB_RESULT, RESULT_TS,"
						+ " JOB_STATE, ASSIGNED_TS, PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNotNull(listCJ.get(i).get("MR_ID"));
			// assertNotNull(listCJ.get(i).get("CONTAINER_JOB_RESULT"));
			assertNotNull(listCJ.get(i).get("RESULT_TS"));
			assertEquals("2", listCJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + (curTime - 1000000),
					listCJ.get(i).get("ASSIGNED_TS").toString());
			assertNotNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(12, reasonCount.intValue());

	}

	@Test
	public void test_ExtractJobTimeOut_Retry() {
		jdbcTemplate.execute("update FE_JOB_QUEUE set ASSIGNED_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE order by JOB_ID");
		assertEquals(9, listFeJ.size());
		for (int i = 0; i < listFeJ.size(); i++) {
			assertEquals("" + (i + 1), listFeJ.get(i).get("JOB_ID").toString());
			assertNull(listFeJ.get(i).get("LOT_JOB_ID"));
			assertEquals("0", listFeJ.get(i).get("JOB_STATE").toString());
			assertNull(listFeJ.get(i).get("FAILED_FLAG"));
			assertNull(listFeJ.get(i).get("MU_ID"));
			assertNull(listFeJ.get(i).get("ASSIGNED_TS"));
			assertNull(listFeJ.get(i).get("RESULT_TS"));
			assertNull(listFeJ.get(i).get("RESULT"));
			assertEquals("1", listFeJ.get(i).get("FAILURE_COUNT").toString());
		}

		// Extract Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_FAILURE_REASONS", Long.class);
		assertEquals(9, reasonCount.intValue());

		// fe lot job Job failure reason
		Long fljCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_LOT_JOBS", Long.class);
		assertEquals(0, fljCount.intValue());

		// Mu PRESSURE
		List<Map<String, Object>> listMuLoad = jdbcTemplate
				.queryForList("select PRESSURE from MU_EXTRACT_LOAD");
		assertEquals(3, listMuLoad.size());
		for (int i = 0; i < listMuLoad.size(); i++) {
			assertEquals("2", listMuLoad.get(i).get("PRESSURE").toString());
		}
	}

	@Test
	public void test_ExtractJobTimeOut_Done() {
		jdbcTemplate.execute("update FE_JOB_QUEUE set FAILURE_COUNT = 1,"
				+ " ASSIGNED_TS = " + (curTime - 1000000));

		pollBean.poll();

		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE order by JOB_ID");
		assertEquals(9, listFeJ.size());
		for (int i = 0; i < listFeJ.size(); i++) {
			assertEquals("" + (i + 1), listFeJ.get(i).get("JOB_ID").toString());
			assertNull(listFeJ.get(i).get("LOT_JOB_ID"));
			assertEquals("2", listFeJ.get(i).get("JOB_STATE").toString());
			assertEquals("1", listFeJ.get(i).get("FAILED_FLAG").toString());
			assertEquals("" + (i / 3 + 1), listFeJ.get(i).get("MU_ID")
					.toString());
			assertEquals("" + (curTime - 1000000),
					listFeJ.get(i).get("ASSIGNED_TS").toString());
			assertNotNull(listFeJ.get(i).get("RESULT_TS"));
			assertNotNull(listFeJ.get(i).get("RESULT"));
			assertEquals("2", listFeJ.get(i).get("FAILURE_COUNT").toString());
		}

		// Extract Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_FAILURE_REASONS", Long.class);
		assertEquals(9, reasonCount.intValue());

		// fe lot job Job failure reason
		Long fljCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_LOT_JOBS", Long.class);
		assertEquals(0, fljCount.intValue());

		// Mu PRESSURE
		List<Map<String, Object>> listMuLoad = jdbcTemplate
				.queryForList("select PRESSURE from MU_EXTRACT_LOAD");
		assertEquals(3, listMuLoad.size());
		for (int i = 0; i < listMuLoad.size(); i++) {
			assertEquals("2", listMuLoad.get(i).get("PRESSURE").toString());
		}

	}

	@Test
	public void test_DMTimeOut() {
		jdbcTemplate.execute("update DM_CONTACTS set CONTACT_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Data Manager
		List<Map<String, Object>> listDMs = jdbcTemplate
				.queryForList("select DM_ID, STATE from DATA_MANAGERS order by DM_ID");
		assertEquals(3, listDMs.size());
		for (int i = 0; i < listDMs.size(); i++) {
			assertEquals("" + (i + 1), listDMs.get(i).get("DM_ID").toString());
			assertEquals("TIMED_OUT", listDMs.get(i).get("STATE").toString());
		}
	}

	@Test
	public void test_MMTimeOut() {
		jdbcTemplate.execute("update MATCH_MANAGERS set HEARTBEAT_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Match Manager
		List<Map<String, Object>> listDMs = jdbcTemplate
				.queryForList("select MM_ID, STATE from MATCH_MANAGERS order by MM_ID");
		assertEquals(3, listDMs.size());
		for (int i = 0; i < listDMs.size(); i++) {
			assertEquals("" + (i + 1), listDMs.get(i).get("MM_ID").toString());
			assertEquals("TIMED_OUT", listDMs.get(i).get("STATE").toString());
		}
	}
	
	@Test
	public void test_MMTimeOut_working_only() {
		jdbcTemplate.execute("update MATCH_MANAGERS set HEARTBEAT_TS = "
				+ (curTime - 1000000) + ", STATE = 'WORKING'");
		pollBean.poll();
		
		List<Map<String, Object>> listMMs = jdbcTemplate
				.queryForList("select MM_ID, STATE from MATCH_MANAGERS order by MM_ID");
		assertEquals(3, listMMs.size());
		for (int i = 0; i < listMMs.size(); i++) {
			assertEquals("" + (i + 1), listMMs.get(i).get("MM_ID").toString());
			assertEquals("TIMED_OUT", listMMs.get(i).get("STATE").toString());
		}
	}
	
	@Test
	public void test_MMTimeOut_not_timeout() {
		jdbcTemplate.execute("update MATCH_MANAGERS set HEARTBEAT_TS = "
				+ (curTime - 1000000) + ", STATE = 'EXITED'");
		pollBean.poll();
		
		List<Map<String, Object>> listMMs = jdbcTemplate
				.queryForList("select MM_ID, STATE from MATCH_MANAGERS order by MM_ID");
		assertEquals(3, listMMs.size());
		for (int i = 0; i < listMMs.size(); i++) {
			assertEquals("" + (i + 1), listMMs.get(i).get("MM_ID").toString());
			assertEquals("EXITED", listMMs.get(i).get("STATE").toString());
		}
	}	

	@Test
	public void test_DefragTimeOut() {
		jdbcTemplate.execute("update SEGMENT_DEFRAGMENTATION set START_TS = "
				+ (curTime - 2000000));

		pollBean.poll();

		// Defrag
		Long defragID = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION", Long.class);
		assertEquals(-1, defragID.intValue());
	}

	@Test
	public void test_MUTimeOut_JobRetry() {
		jdbcTemplate.execute("update MU_CONTACTS set CONTACT_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Match Unit
		List<Map<String, Object>> listMUs = jdbcTemplate
				.queryForList("select MU_ID, STATE from MATCH_UNITS order by MU_ID");
		assertEquals(3, listMUs.size());
		for (int i = 0; i < listMUs.size(); i++) {
			assertEquals("" + (i + 1), listMUs.get(i).get("MU_ID").toString());
			assertEquals("TIMED_OUT", listMUs.get(i).get("STATE").toString());
		}

		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE order by JOB_ID");
		assertEquals(9, listFeJ.size());
		for (int i = 0; i < listFeJ.size(); i++) {
			assertEquals("" + (i + 1), listFeJ.get(i).get("JOB_ID").toString());
			assertNull(listFeJ.get(i).get("LOT_JOB_ID"));
			assertEquals("0", listFeJ.get(i).get("JOB_STATE").toString());
			assertNull(listFeJ.get(i).get("FAILED_FLAG"));
			assertNull(listFeJ.get(i).get("MU_ID"));
			assertNull(listFeJ.get(i).get("ASSIGNED_TS"));
			assertNull(listFeJ.get(i).get("RESULT_TS"));
			assertNull(listFeJ.get(i).get("RESULT"));
			assertEquals("1", listFeJ.get(i).get("FAILURE_COUNT").toString());
		}

		// Extract Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_FAILURE_REASONS", Long.class);
		assertEquals(9, reasonCount.intValue());

		// fe lot job Job failure reason
		Long fljCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_LOT_JOBS", Long.class);
		assertEquals(0, fljCount.intValue());

		// Mu PRESSURE
		List<Map<String, Object>> listMuLoad = jdbcTemplate
				.queryForList("select PRESSURE from MU_EXTRACT_LOAD");
		assertEquals(3, listMuLoad.size());
		for (int i = 0; i < listMuLoad.size(); i++) {
			assertEquals("2", listMuLoad.get(i).get("PRESSURE").toString());
		}

	}

	@Test
	public void test_MUTimeOut_JobDone() {
		jdbcTemplate.execute("update FE_JOB_QUEUE set FAILURE_COUNT = 1");
		jdbcTemplate.execute("update MU_CONTACTS set CONTACT_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Match Unit
		List<Map<String, Object>> listMUs = jdbcTemplate
				.queryForList("select MU_ID, STATE from MATCH_UNITS order by MU_ID");
		assertEquals(3, listMUs.size());
		for (int i = 0; i < listMUs.size(); i++) {
			assertEquals("" + (i + 1), listMUs.get(i).get("MU_ID").toString());
			assertEquals("TIMED_OUT", listMUs.get(i).get("STATE").toString());
		}

		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE order by JOB_ID");
		assertEquals(9, listFeJ.size());
		for (int i = 0; i < listFeJ.size(); i++) {
			assertEquals("" + (i + 1), listFeJ.get(i).get("JOB_ID").toString());
			assertNull(listFeJ.get(i).get("LOT_JOB_ID"));
			assertEquals("2", listFeJ.get(i).get("JOB_STATE").toString());
			assertEquals("1", listFeJ.get(i).get("FAILED_FLAG").toString());
			assertEquals("" + (i / 3 + 1), listFeJ.get(i).get("MU_ID")
					.toString());
			assertEquals("" + curTime, listFeJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNotNull(listFeJ.get(i).get("RESULT_TS"));
			assertNotNull(listFeJ.get(i).get("RESULT"));
			assertEquals("2", listFeJ.get(i).get("FAILURE_COUNT").toString());
		}

		// Extract Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_FAILURE_REASONS", Long.class);
		assertEquals(9, reasonCount.intValue());

		// fe lot job Job failure reason
		Long fljCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_LOT_JOBS", Long.class);
		assertEquals(0, fljCount.intValue());

		// Mu PRESSURE
		List<Map<String, Object>> listMuLoad = jdbcTemplate
				.queryForList("select PRESSURE from MU_EXTRACT_LOAD");
		assertEquals(3, listMuLoad.size());
		for (int i = 0; i < listMuLoad.size(); i++) {
			assertEquals("2", listMuLoad.get(i).get("PRESSURE").toString());

		}

	}

	@Test
	public void test_MRTimeOut_JobRetry() {
		jdbcTemplate.execute("update MR_CONTACTS set CONTACT_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Map Reducer
		List<Map<String, Object>> listMRs = jdbcTemplate
				.queryForList("select MR_ID, RING_LOCATION, STATE"
						+ " from MAP_REDUCERS order by MR_ID");
		assertEquals(3, listMRs.size());
		for (int i = 0; i < listMRs.size(); i++) {
			assertEquals("" + (i + 1), listMRs.get(i).get("MR_ID").toString());
			assertNull(listMRs.get(i).get("RING_LOCATION"));
			assertEquals("TIMED_OUT", listMRs.get(i).get("STATE").toString());
		}

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " RESULT, RESULT_TS, FAILED_FLAG, FAILURE_COUNT,"
						+ " REMAIN_JOBS from JOB_QUEUE order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < 3; i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("0", listTLJ.get(i).get("JOB_STATE").toString());
			assertNull(listTLJ.get(i).get("ASSIGNED_TS"));
			assertNull(listTLJ.get(i).get("RESULT"));
			assertNull(listTLJ.get(i).get("RESULT_TS"));
			assertNull(listTLJ.get(i).get("FAILED_FLAG"));
			assertEquals("1", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("4", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		assertEquals("4", listTLJ.get(3).get("JOB_ID").toString());
		assertEquals("1", listTLJ.get(3).get("JOB_STATE").toString());
		assertEquals("" + curTime, listTLJ.get(3).get("ASSIGNED_TS").toString());
		assertNull(listTLJ.get(3).get("RESULT"));
		assertNull(listTLJ.get(3).get("RESULT_TS"));
		assertNull(listTLJ.get(3).get("FAILED_FLAG"));
		assertEquals("0", listTLJ.get(3).get("FAILURE_COUNT").toString());
		assertEquals("4", listTLJ.get(3).get("REMAIN_JOBS").toString());

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT").toString());
		}

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, CONTAINER_JOB_RESULT, RESULT_TS,"
						+ " JOB_STATE, ASSIGNED_TS, PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNull(listCJ.get(i).get("MR_ID"));
			assertNull(listCJ.get(i).get("CONTAINER_JOB_RESULT"));
			assertNull(listCJ.get(i).get("RESULT_TS"));
			assertEquals("0", listCJ.get(i).get("JOB_STATE").toString());
			assertNull(listCJ.get(i).get("ASSIGNED_TS"));
			assertNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(0, reasonCount.intValue());
	}

	@Test
	public void test_MRTimeOut_JobDone() {
		jdbcTemplate.execute("update JOB_QUEUE set FAILURE_COUNT = 2");
		jdbcTemplate.execute("update MR_CONTACTS set CONTACT_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		// Map Reducer
		List<Map<String, Object>> listMRs = jdbcTemplate
				.queryForList("select MR_ID, RING_LOCATION, STATE"
						+ " from MAP_REDUCERS order by MR_ID");
		assertEquals(3, listMRs.size());
		for (int i = 0; i < listMRs.size(); i++) {
			assertEquals("" + (i + 1), listMRs.get(i).get("MR_ID").toString());
			assertNull(listMRs.get(i).get("RING_LOCATION"));
			assertEquals("TIMED_OUT", listMRs.get(i).get("STATE").toString());
		}

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " RESULT, RESULT_TS, FAILED_FLAG, FAILURE_COUNT,"
						+ " REMAIN_JOBS from JOB_QUEUE order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < 3; i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("2", listTLJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + curTime, listTLJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNotNull(listTLJ.get(i).get("RESULT"));
			assertNotNull(listTLJ.get(i).get("RESULT_TS"));
			assertEquals("1", listTLJ.get(i).get("FAILED_FLAG").toString());
			assertEquals("3", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("0", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		assertEquals("4", listTLJ.get(3).get("JOB_ID").toString());
		assertEquals("1", listTLJ.get(3).get("JOB_STATE").toString());
		assertEquals("" + curTime, listTLJ.get(3).get("ASSIGNED_TS").toString());
		assertNull(listTLJ.get(3).get("RESULT"));
		assertNull(listTLJ.get(3).get("RESULT_TS"));
		assertNull(listTLJ.get(3).get("FAILED_FLAG"));
		assertEquals("2", listTLJ.get(3).get("FAILURE_COUNT").toString());
		assertEquals("4", listTLJ.get(3).get("REMAIN_JOBS").toString());

		// INQUIRY_TRAFFIC
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(9, listIT.size());
		for (int i = 0; i < listIT.size(); i++) {
			assertEquals("0", listIT.get(i).get("JOB_EXEC_COUNT").toString());
		}

		// Container Job
		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select MR_ID, CONTAINER_JOB_RESULT, RESULT_TS,"
						+ " JOB_STATE, ASSIGNED_TS, PLAN_ID from CONTAINER_JOBS");
		assertEquals(12, listCJ.size());
		for (int i = 0; i < listCJ.size(); i++) {
			assertNotNull(listCJ.get(i).get("MR_ID"));
			// assertNotNull(listCJ.get(i).get("CONTAINER_JOB_RESULT"));
			assertNotNull(listCJ.get(i).get("RESULT_TS"));
			assertEquals("2", listCJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + curTime, listCJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNotNull(listCJ.get(i).get("PLAN_ID"));
		}

		// Container Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(FAILURE_ID) from CONTAINER_JOB_FAILURE_REASONS",
				Long.class);
		assertEquals(12, reasonCount.intValue());
	}

	@Test
	public void test_defrag() {
		message = "";

		new MockUp<DefragDao>() {
			@Mock
			public void defrag(DataSource dataSource) {
				message = "defrag";
				return;
			}
		};

		pollBean.defrag();

		assertEquals("defrag", message);
	}

	@Test
	public void test_aggregateJob() {
		// Done all container job
		jdbcTemplate.execute("update JOB_QUEUE set REMAIN_JOBS = 0");
		jdbcTemplate.execute("update CONTAINER_JOBS set JOB_STATE = 2,"
				+ " RESULT_TS = " + (curTime - 90000));
		// container job failed reason
		jdbcTemplate.execute("insert into CONTAINER_JOB_FAILURE_REASONS("
				+ " FAILURE_ID, CODE, REASON, FAILURE_TIME, CONTAINER_JOB_ID)"
				+ " values(1, 'code', 'test aggregateJob', '2134234', 1)");
		jdbcTemplate.execute("insert into CONTAINER_JOB_FAILURE_REASONS("
				+ " FAILURE_ID, CODE, REASON, FAILURE_TIME, CONTAINER_JOB_ID)"
				+ " values(2, 'code', 'test aggregateJob', '2134234', 5)");
		jdbcTemplate.execute("insert into CONTAINER_JOB_FAILURE_REASONS("
				+ " FAILURE_ID, CODE, REASON, FAILURE_TIME, CONTAINER_JOB_ID)"
				+ " values(3, 'code', 'test aggregateJob', '2134234', 9)");

		PBInquiryJobResultInternal.Builder internal = PBInquiryJobResultInternal
				.newBuilder();
		internal.setServiceState(PBServiceState
				.newBuilder()
				.setState(ServiceStateType.SERVICE_STATE_ERROR)
				.setReason(
						PBServiceStateReason.newBuilder().setCode("code")
								.setDescription("test aggregateJob")
								.setTime("2134234")));
		jdbcTemplate
				.update("update CONTAINER_JOBS set CONTAINER_JOB_RESULT=? where CONTAINER_JOB_ID=?",
						new Object[] { internal.build().toByteArray(), 1 });
		jdbcTemplate
				.update("update CONTAINER_JOBS set CONTAINER_JOB_RESULT=? where CONTAINER_JOB_ID=?",
						new Object[] { internal.build().toByteArray(), 5 });
		jdbcTemplate
				.update("update CONTAINER_JOBS set CONTAINER_JOB_RESULT=? where CONTAINER_JOB_ID=?",
						new Object[] { internal.build().toByteArray(), 9 });

		// aggregateJob
		pollBean.aggregateJob();

		// Top Level Job
		List<Map<String, Object>> listTLJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " RESULT, RESULT_TS, FAILED_FLAG, FAILURE_COUNT,"
						+ " REMAIN_JOBS from JOB_QUEUE order by JOB_ID");
		assertEquals(4, listTLJ.size());
		for (int i = 0; i < 3; i++) {
			assertEquals("" + (i + 1), listTLJ.get(i).get("JOB_ID").toString());
			assertEquals("2", listTLJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + curTime, listTLJ.get(i).get("ASSIGNED_TS")
					.toString());
			assertNotNull(listTLJ.get(i).get("RESULT"));
			assertNotNull(listTLJ.get(i).get("RESULT_TS"));
			assertEquals("1", listTLJ.get(i).get("FAILED_FLAG").toString());
			assertEquals("0", listTLJ.get(i).get("FAILURE_COUNT").toString());
			assertEquals("0", listTLJ.get(i).get("REMAIN_JOBS").toString());
		}

		assertEquals("4", listTLJ.get(3).get("JOB_ID").toString());
		assertEquals("1", listTLJ.get(3).get("JOB_STATE").toString());
		assertEquals("" + curTime, listTLJ.get(3).get("ASSIGNED_TS").toString());
		assertNull(listTLJ.get(3).get("RESULT"));
		assertNull(listTLJ.get(3).get("RESULT_TS"));
		assertNull(listTLJ.get(3).get("FAILED_FLAG"));
		assertEquals("0", listTLJ.get(3).get("FAILURE_COUNT").toString());
		assertEquals("0", listTLJ.get(3).get("REMAIN_JOBS").toString());
	}

	private void setMockMethods() {
		new MockUp<MatchManagerDao>() {
			@Mock
			private String getMMUniqueId() {
				return "10.84.75.213";
			}
		};
	}

	@Test
	public void test_updateHeartBeatTS() {
		setMockMethods();
		try {
			jdbcTemplate.execute("insert into MATCH_MANAGERS(MM_ID, UNIQUE_ID,"
					+ " STATE, HEARTBEAT_TS) values(100, '10.84.75.213',"
					+ " 'WORKING', " + curTime + ")");
			entityManager.flush();

			pollBean.updateHeartBeatTS();

			// Match Manager
			Long heartbeatTs = jdbcTemplate
					.queryForObject(
							"select HEARTBEAT_TS"
									+ " from MATCH_MANAGERS where UNIQUE_ID = '10.84.75.213'",
							Long.class);

			assertTrue(curTime < heartbeatTs.longValue());
		} finally {
			mockit.Mockit.tearDownMocks();
		}
	}

	@Test
	public void test_purgeJobQueueByResultTs() {
		jdbcTemplate.execute("update FE_JOB_QUEUE set JOB_STATE = 2,"
				+ " RESULT_TS = " + (curTime - 73 * 3600000));
		jdbcTemplate.execute("update JOB_QUEUE set JOB_STATE = 2,"
				+ " RESULT_TS = " + (curTime - 73 * 3600000));

		entityManager.flush();

		pollBean.purgeJobQueueByResultTs();

		int jobCount = jdbcTemplate.queryForObject(
				"select count(*) from JOB_QUEUE", Integer.class);
		assertEquals(0, jobCount);

		int fejobCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_QUEUE", Integer.class);
		assertEquals(0, fejobCount);
	}

	// @Test
	// public void test_updateLastTS() {
	// jdbcTemplate.execute("insert into MATCH_MANAGERS(MM_ID, UNIQUE_ID,"
	// + " STATE, HEARTBEAT_TS) values(100, '10.84.75.213',"
	// + " 'WORKING', " + curTime + ")");
	// jdbcTemplate.execute("commit");
	// entityManager.flush();
	//
	// pollBean.updateLastTS(SchedulerEnum.PollSchedulable);
	//
	// Long lastTs = jdbcTemplate.queryForObject("select LAST_TS"
	// + " from MM_EVENTS where NAME = 'POLL'", Long.class);
	//
	// assertTrue(curTime < lastTs.longValue());
	// }

	@Test
	public void test_TopLevelJobTimeOut_AimRuntimeException() {
		message = "";

		new MockUp<InquiryJobHandler>() {
			@Mock
			public void failInquiryJob(long containerJobId, String errCode,
					String errReason, String errTime) {
				throw new AimRuntimeException();
			}
		};

		jdbcTemplate.execute("update JOB_QUEUE set ASSIGNED_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		assertTrue(message.contains(" is dead due to Top Level Job time out"));
	}

	@Test
	public void test_ContainerJobTimeOut_Exception() {
		message = "";

		new MockUp<InquiryJobHandler>() {
			@Mock
			public void failInquiryJob(long containerJobId, String errCode,
					String errReason, String errTime) {
				throw new AimRuntimeException();
			}
		};

		jdbcTemplate.execute("update CONTAINER_JOBS set ASSIGNED_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		assertTrue(message.contains(" during poll(): Container Job "));
		assertTrue(message.contains(" when time out."));
	}

	@Test
	public void test_ExtractJobTimeOut_Exception() {
		message = "";

		new MockUp<ExtractJobHandler>() {
			@Mock
			public int failExtractJob(FeJobQueueEntity eje, long muId,
					PBServiceStateReason reason, boolean timeout,
					Integer maxCount) {
				throw new AimRuntimeException();
			}
		};

		jdbcTemplate.execute("update FE_JOB_QUEUE set FAILURE_COUNT = 1,"
				+ " ASSIGNED_TS = " + (curTime - 1000000));

		pollBean.poll();

		assertTrue(message.contains(" during poll(): Extract job "));
		assertTrue(message.contains(" when timeout."));
	}

	@Test
	public void test_MUTimeOut_Exception() {
		message = "";

		new MockUp<ExtractJobHandler>() {
			@Mock
			public int failExtractJob(FeJobQueueEntity eje, long muId,
					PBServiceStateReason reason, boolean timeout,
					Integer maxCount) {
				jdbcTemplate.execute("update FE_JOB_QUEUE set JOB_STATE = 0");
				throw new AimRuntimeException();
			}
		};

		jdbcTemplate.execute("update MU_CONTACTS set CONTACT_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		assertTrue(message.contains(" during poll(): Extract job "));
		assertTrue(message.contains(" when MatchUnit "));
		assertTrue(message.contains(" heatbeat timeout."));
	}

	@Test
	public void test_MRTimeOut_Exception() {
		message = "";

		new MockUp<InquiryJobHandler>() {
			@Mock
			public void failInquiryJob(long containerJobId, String errCode,
					String errReason, String errTime) {
				jdbcTemplate.execute("update CONTAINER_JOBS set JOB_STATE = 0");
				throw new AimRuntimeException();
			}
		};

		jdbcTemplate.execute("update MR_CONTACTS set CONTACT_TS = "
				+ (curTime - 1000000));

		pollBean.poll();

		assertTrue(message.contains(" during poll(): ContainerJob "));
		assertTrue(message.contains(" when MapReducer "));
		assertTrue(message.contains(" heatbeat timeout."));
	}

	@Test
	public void test_aggregateJob_DataAccessException() {

		try {
			new MockUp<FindUnaggregatedJobProcedure>() {
				@Mock
				public List<Long> execute() {
					throw new IncorrectResultSizeDataAccessException(0);
				}
			};

			// aggregateJob
			pollBean.aggregateJob();
		} catch (AimRuntimeException e) {
			assertEquals("DataAccessException when Clear Map Reduces",
					e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_TopLevelJobTimeOut_DataAccessException() {
		message = "";

		new MockUp<InquiryJobHandler>() {
			@Mock
			public void failInquiryJob(long containerJobId, String errCode,
					String errReason, String errTime) {
				throw new IncorrectResultSizeDataAccessException(0);
			}
		};

		jdbcTemplate.execute("update JOB_QUEUE set ASSIGNED_TS = "
				+ (curTime - 1000000));
		jdbcTemplate.execute("update MM_EVENTS set LAST_TS = " + curTime
				+ " where NAME = 'STARTUP'");

		pollBean.poll();

		assertEquals("error", TestLogger.level);
		assertTrue(TestLogger.message
				.contains("DataAccessException when Top Level Job time out"));
	}

	@Test
	public void test_TopLevelJobTimeOut_SQLException() {
		message = "";

		new MockUp<InquiryJobHandler>() {
			@Mock
			public void failInquiryJob(long containerJobId, String errCode,
					String errReason, String errTime) throws SQLException {
				throw new SQLException();
			}
		};

		jdbcTemplate.execute("update JOB_QUEUE set ASSIGNED_TS = "
				+ (curTime - 1000000));
		jdbcTemplate.execute("update MM_EVENTS set LAST_TS = " + curTime
				+ " where NAME = 'STARTUP'");

		pollBean.poll();

		assertEquals("error", TestLogger.level);
		assertTrue(TestLogger.message
				.contains("SQLException when Top Level Job time out"));
	}

	@Test
	public void test_MM_NoAlived() {
		jdbcTemplate.execute("update MM_EVENTS set LAST_TS = " + curTime
				+ " where NAME = 'STARTUP'");

		pollBean.poll();

		assertEquals("debug", TestLogger.level);
		assertTrue(TestLogger.message.contains("It has not passed " + 60000
				+ " msec since MM started. Skip heartBeatTimeout()"));
	}

	@Test
	public void test_HEARTBEAT_MESSAGE_negative() {
		TestLogger.isDebugEnabled = false;

		jdbcTemplate.execute("update MM_EVENTS set LAST_TS = " + curTime
				+ " where NAME = 'STARTUP'");

		Query q = entityManager.createNamedQuery("NQ::getConfigEntity");
		q.setParameter("name", "TIMEOUTS.HEARTBEAT_MESSAGE");
		SystemConfigEntity e = (SystemConfigEntity) q.getResultList().get(0);
		e.setValue("-1");
		entityManager.merge(e);

		pollBean.poll();

		assertEquals("warn", TestLogger.level);
		assertTrue(TestLogger.message
				.contains(MMConfigProperty.HEARTBEAT_TIMEOUT.name()
						+ " is negative, " + -1));
	}

	@Test
	public void test_ExtractJobTimeOut_NULL_MUID_UNDO() {
		jdbcTemplate.execute("update FE_JOB_QUEUE set MU_ID = null,"
				+ " ASSIGNED_TS = " + (curTime - 1000000));

		pollBean.poll();

		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, JOB_STATE, ASSIGNED_TS,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE"
						+ " order by JOB_ID");
		assertEquals(9, listFeJ.size());
		for (int i = 0; i < listFeJ.size(); i++) {
			assertEquals("" + (i + 1), listFeJ.get(i).get("JOB_ID").toString());
			assertEquals("1", listFeJ.get(i).get("JOB_STATE").toString());
			assertEquals("" + (curTime - 1000000),
					listFeJ.get(i).get("ASSIGNED_TS").toString());
			assertEquals("0", listFeJ.get(i).get("FAILURE_COUNT").toString());
		}

		// Extract Job failure reason
		Long reasonCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_FAILURE_REASONS", Long.class);
		assertEquals(0, reasonCount.intValue());

		// fe lot job Job failure reason
		Long fljCount = jdbcTemplate.queryForObject(
				"select count(*) from FE_LOT_JOBS", Long.class);
		assertEquals(3, fljCount.intValue());

		// Mu PRESSURE
		List<Map<String, Object>> listMuLoad = jdbcTemplate
				.queryForList("select PRESSURE from MU_EXTRACT_LOAD");
		assertEquals(3, listMuLoad.size());
		for (int i = 0; i < listMuLoad.size(); i++) {
			assertEquals("3", listMuLoad.get(i).get("PRESSURE").toString());
		}
	}
}
