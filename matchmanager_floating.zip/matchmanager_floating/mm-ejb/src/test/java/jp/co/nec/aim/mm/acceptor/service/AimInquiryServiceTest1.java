package jp.co.nec.aim.mm.acceptor.service;

import static mockit.Mockit.tearDownMocks;

import java.net.URL;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryPayload;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager;
import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.FusionJobEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimInquiryServiceTest1 extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private AimInquiryService aimInquiryService;
	@Resource
	private JdbcTemplate jdbcTemplate;
	private ScriptManager manager = ScriptManager.getInstance();

	@Before
	public void setUp() {
		manager.clear();
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.execute("commit");
		setMockMethod();
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.execute("commit");
		tearDownMocks();
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object message) {
				return;
			}
		};
	}

	@Test
	public void testInquiry_1top_1fusion_2containerjob_normal_TI_NOSCOPE()
			throws InvalidProtocolBufferException {
		URL url2 = this.getClass().getResource("delete_containers.sql");
		executeSqlScript("file:///" + url2.getPath(), false);
		URL url = this.getClass().getResource("insert_containers.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		// container id 1
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(1, 7, 1001, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(2, 7, 1001, 101, 200, 100, 1, 1, 100)");

		// container id 2
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, CONTAINER_ID, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(3, 7, 1002, 1, 100, 100, 1, 1, 100)");
		jdbcTemplate
				.update("INSERT INTO SEGMENTS "
						+ "(SEGMENT_ID, VERSION, container_id, BIO_ID_START, BIO_ID_END,"
						+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, REVISION, BINARY_LENGTH_UNCOMPACTED)"
						+ " VALUES(4, 7, 1002, 101, 200, 100, 1, 1, 100)");

		PBInquiryJobRequest.Builder b = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder jobInfoBuilder = PBInquiryJobInfo.newBuilder()
				.setFunction(InquiryFunctionType.TI).setPriority(3)
				.setMaxCandidate(32).setDynThreshHitThreshold(200)
				.setDynThreshPercentagePoint(5.4f)
				.setCallBackUrl("http://192.168.1.83/callback");
		PBFusionJobInput.Builder fusionJobBuilder = PBFusionJobInput
				.newBuilder()
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setInquiryOptions(
						PBInquiryOptions
								.newBuilder()
								.setMinScore(121)
								.setInquiryPayload(
										PBInquiryPayload.newBuilder())
								.addFusionWeight(
										PBInquiryFusionWeight
												.newBuilder()
												.setInquirySet(
														FingerSetType.PC2_SLAP)
												.setWeight(20)))
				.setKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_TI)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_SLAP))
												.setTemplateBinary(
														ByteString
																.copyFrom(new byte[] {
																		0, 1 }))));
		b.setJobInfo(jobInfoBuilder).addFusionJobInput(fusionJobBuilder);

		PBInquiryJobResponse response = aimInquiryService.inquiry(b.build(),
				false);

		PBServiceState state = response.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				state.getState());

		long jobId = response.getJobId();

		// top level job check
		InquiryJobDao dao = new InquiryJobDao(entityManager, dataSource);
		JobQueueEntity job = dao.getTopLevelJob(jobId);
		Assert.assertTrue(job != null);

		Assert.assertEquals(CallbackStyle.XML, job.getCallbackStyle());
		Assert.assertEquals(JobState.QUEUED, job.getJobState());
		Assert.assertEquals(3, job.getPriority());
		Assert.assertEquals(32, job.getMaxCandidates().intValue());
		// Assert.assertEquals(121, job.getMinScore().intValue());
		Assert.assertEquals(200, job.getHitThreshold().intValue());
		Assert.assertTrue(5.4d == job.getPercentagePoint().doubleValue());
		Assert.assertEquals(0, job.getFailureCount());
		Assert.assertEquals(2, job.getRemainJobs());
		Assert.assertEquals(1, job.getFamilyId());
		Assert.assertEquals("http://192.168.1.83/callback",
				job.getCallbackUrl());
		Assert.assertNull(job.getResults());

		// fusion job check
		List<FusionJobEntity> fusionJob1s = dao.getFusionJob(jobId, 1);
		Assert.assertEquals(1, fusionJob1s.size());

		FusionJobEntity f1 = fusionJob1s.get(0);
		Assert.assertEquals(jobId, f1.getJobId());
		Assert.assertEquals(0, f1.getSearchRequestIndex());

		// container job check
		List<ContainerJobEntity> cjob1 = dao.getContainerJob(
				f1.getFusionJobId(), 1001);

		Assert.assertEquals(1001, cjob1.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob1.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob1.get(0).getJobState());

		List<ContainerJobEntity> cjob2 = dao.getContainerJob(
				f1.getFusionJobId(), 1002);
		Assert.assertEquals(1002, cjob2.get(0).getContainerId());
		Assert.assertEquals(f1.getFusionJobId(), cjob2.get(0).getFusionJobId());
		Assert.assertEquals(JobState.QUEUED, cjob2.get(0).getJobState());

		// InquiryJobData check
		PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(f1
				.getInquiryJobData());
		System.out.println(request);
		Assert.assertEquals(3, request.getJobInfo().getPriority());
		Assert.assertEquals(InquiryFunctionType.TI, request.getJobInfo()
				.getFunction());
		Assert.assertEquals("http://192.168.1.83/callback", request
				.getJobInfo().getCallBackUrl());
		Assert.assertTrue(request.hasJobInfo());
		PBInquiryScopeOptions scopeOptions = request.getFusionJobInput(0)
				.getScopes();
		// Assert.assertEquals(1, scopeOptions.getScopeCount());
		// Assert.assertEquals(1,
		// scopeOptions.getScopeList().get(0).intValue());
		Assert.assertEquals(2, scopeOptions.getTargetFingerPrintCount());
		URL url1 = this.getClass().getResource("delete_containers.sql");
		executeSqlScript("file:///" + url1.getPath(), false);
	}

}
