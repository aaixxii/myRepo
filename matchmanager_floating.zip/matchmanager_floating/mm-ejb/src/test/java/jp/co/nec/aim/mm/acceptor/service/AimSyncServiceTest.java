package jp.co.nec.aim.mm.acceptor.service;

import static mockit.Mockit.tearDownMocks;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncRequest;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncInsertPayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobResponse;
import jp.co.nec.aim.mm.common.HttpTestServer;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Queues;
import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:jp/co/nec/aim/mm/acceptor/service/AimSyncServiceTest-context.xml")
@Transactional
public class AimSyncServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private AimSyncService aimSyncService;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from SYSTEM_CONFIG");
		jdbcTemplate
				.update("INSERT INTO SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME, PROPERTY_VALUE) VALUES (1000, 'TEMPLATE_VALIDATION.ENABLED', 'false')");

		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.execute("commit");
		setMockMethod();
	}

	@After
	public void tearDown() {

		jdbcTemplate
				.update("update CONTAINERS set MAX_SEGMENT_SIZE = 20000000 ");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.execute("commit");
		tearDownMocks();
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}

		};
	}

	@Test
	public void testSyncDataInsertNewSegRDBT_EvetIdNull() {
		// jdbcTemplate.update("insert into segments (SEGMENT_ID,)");
		// segment_seq.NEXTVAL
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		// PersonBiometricEntity personBiometricEntity =
		// jdbcTemplate.queryForList("select * from PERSON_BIOMETRICS",PersonBiometricEntity.class).get(0);
		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(0, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}
		Integer cId = 1;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	// Insert
	@Test
	public void testSyncDataInsertNewSegRDBT() {
		// jdbcTemplate.update("insert into segments (SEGMENT_ID,)");
		// segment_seq.NEXTVAL
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		// PersonBiometricEntity personBiometricEntity =
		// jdbcTemplate.queryForList("select * from PERSON_BIOMETRICS",PersonBiometricEntity.class).get(0);
		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}
		Integer cId = 1;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegSDBT() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		// PersonBiometricEntity personBiometricEntity =
		// jdbcTemplate.queryForList("select * from PERSON_BIOMETRICS",PersonBiometricEntity.class).get(0);
		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}
		Integer cId = 2;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));

	}

	@Test
	public void testSyncDataInsertNewSegRDBTM() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> map = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(map.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(map.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(331,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) map.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 331;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegSDBTM() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(332,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}
		Integer cId = 332;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));

	}

	@Test
	public void testSyncDataInsertNewSegRDBL() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_THUMB);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(3,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 3;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegSDBL() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_SLAP_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(4,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 4;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegRDBLS() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_THUMB);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(323,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 323;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegRDBLSTwoSame() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_THUMB);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		try {
			@SuppressWarnings("unused")
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Sync Job (Specified key and indexer list in insertpayload or deletePayload was duplicate.)",
					e.getMessage());
		}
	}

	@Test
	public void testSyncDataInsertNewSegSDBLS() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_SLAP_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(324,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 324;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegRDBLM() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_THUMB);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(333,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 333;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegSDBLM() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_SLAP_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(334,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 334;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegRDBLX() {

		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLX);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		// PersonBiometricEntity personBiometricEntity =
		// jdbcTemplate.queryForList("select * from PERSON_BIOMETRICS",PersonBiometricEntity.class).get(0);
		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(341,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 341;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegPDB() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_PALM_LEFT_FULL);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(5,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 5;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	/*
	 * @Test public void testSyncDataInsertNewSegIDB() { //
	 * jdbcTemplate.update("insert into segments (SEGMENT_ID,)"); //
	 * segment_seq.NEXTVAL byte[] a = { 1, 2, 3 }; PBKeyedTemplate.Builder
	 * keyedTemBuilder = PBKeyedTemplate.newBuilder()
	 * .setTemplateBinary(ByteString.copyFrom(a))
	 * .setKey(TemplateFormatType.TEMPLATE_IDB); PBKeyedTemplateData.Builder
	 * keyedTemDataBuilder = PBKeyedTemplateData
	 * .newBuilder().setKeyedTemplate(keyedTemBuilder);
	 * PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
	 * .newBuilder().setScope(1) .addKeyedTemplateData(keyedTemDataBuilder);
	 * PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
	 * .setFunction(SyncFunctionType.INSERT).setEventId(1)
	 * .setExternalId("1").setInsertPayload(syncInsertPayload).build();
	 * 
	 * PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
	 * jdbcTemplate.execute("commit");
	 * 
	 * // PersonBiometricEntity personBiometricEntity = //
	 * jdbcTemplate.queryForList
	 * ("select * from PERSON_BIOMETRICS",PersonBiometricEntity.class).get(0);
	 * Map<String, Object> l = jdbcTemplate.queryForList(
	 * "select * from PERSON_BIOMETRICS").get(0);
	 * 
	 * Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
	 * Assert.assertEquals(1,
	 * Integer.parseInt(l.get("EXTERNAL_ID").toString()));
	 * Assert.assertEquals(343,
	 * Integer.parseInt(l.get("CONTAINER_ID").toString()));
	 * 
	 * byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
	 * Assert.assertEquals(a.length, bytes.length); int i = 0; for (byte b :
	 * bytes) { Assert.assertEquals(b, a[i++]); }
	 * 
	 * Integer cId = 343; Assert.assertEquals(cId, jdbcTemplate.queryForObject(
	 * "select CONTAINER_ID from segments", Integer.class)); }
	 */

	@Test
	public void testSyncDataInsertNewSegLDB() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDB);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(321,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 321;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegPLDB() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_PLDB);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(322,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 322;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegLDBS() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBS);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(326,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 326;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegLDBM() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBM);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(336,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 336;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegLDBX() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBX);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		jdbcTemplate.execute("commit");

		// PersonBiometricEntity personBiometricEntity =
		// jdbcTemplate.queryForList("select * from PERSON_BIOMETRICS",PersonBiometricEntity.class).get(0);
		Map<String, Object> l = jdbcTemplate.queryForList(
				"select * from PERSON_BIOMETRICS").get(0);

		Assert.assertEquals(1, Integer.parseInt(l.get("EVENT_ID").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(l.get("EXTERNAL_ID").toString()));
		Assert.assertEquals(342,
				Integer.parseInt(l.get("CONTAINER_ID").toString()));

		byte[] bytes = (byte[]) l.get("BIOMETRIC_DATA");
		Assert.assertEquals(a.length, bytes.length);
		int i = 0;
		for (byte b : bytes) {
			Assert.assertEquals(b, a[i++]);
		}

		Integer cId = 342;
		Assert.assertEquals(cId, jdbcTemplate.queryForObject(
				"select CONTAINER_ID from segments", Integer.class));
	}

	@Test
	public void testSyncDataInsertNewSegLDBX1() {
		jdbcTemplate.update("update CONTAINERS set MAX_SEGMENT_SIZE = 100 ");
		jdbcTemplate.update("commit");
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBX);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 2; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		Integer count = 2;
		Assert.assertEquals(count, jdbcTemplate.queryForObject(
				"select count(segment_id) from segments", Integer.class));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegLDBX() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBX);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegRDBT() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(1,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegRDBTM() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(331,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegRDBL() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_RIGHT_RING);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(3,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegRDBLS() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_RIGHT_RING);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(323,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegRDBLM() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_RIGHT_RING);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(333,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegRDBLX() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLX);

		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(341,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegPDB() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_PALM_RIGHT_FULL);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(5,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegFDB() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setIndex(1);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(335,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegLDB() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDB);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(321,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegPLDB() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_PLDB);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(322,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegLDBS() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBS);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(326,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	@Test
	public void testSyncDataInsertUpdSegLDBM() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBM);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(
				2,
				Integer.parseInt(map.get("BIO_ID_END").toString())
						- Integer.parseInt(map.get("BIO_ID_START").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from person_biometrics", Integer.class));
		Assert.assertEquals(336,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));
		jdbcTemplate.execute("commit");

	}

	// delete
	@Test
	public void testSyncDataDeleteNull_EventIdNull() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setInsertPayload(syncInsertPayload).build();
		aimSyncService.syncData(syncJobRequest);

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setInsertPayload(syncInsertPayload1).build();
		aimSyncService.syncData(syncJobRequest1);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(0).build(); // setting eventId to default

		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, list.size());
		Assert.assertEquals(0,
				Integer.parseInt(list.get(0).get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(list.get(1).get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(list.get(0).get("CONTAINER_ID").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(list.get(1).get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(0).get("CHANGE_TYPE")
						.toString()));
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(1).get("CHANGE_TYPE")
						.toString()));

	}

	// delete
	@Test
	public void testSyncDataDeleteNull_EventIdNull_moreOne() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setInsertPayload(syncInsertPayload).build();
		aimSyncService.syncData(syncJobRequest);

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setInsertPayload(syncInsertPayload1).build();
		aimSyncService.syncData(syncJobRequest1);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.build(); // no setting eventId

		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, list.size());
		Assert.assertEquals(0,
				Integer.parseInt(list.get(0).get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(list.get(1).get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(list.get(0).get("CONTAINER_ID").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(list.get(1).get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(0).get("CHANGE_TYPE")
						.toString()));
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(1).get("CHANGE_TYPE")
						.toString()));
	}

	@Test
	public void testSyncDataDeleteNull_EventIdNull_multiEvent() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setInsertPayload(syncInsertPayload).setEventId(2).build();
		aimSyncService.syncData(syncJobRequest);

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setInsertPayload(syncInsertPayload1).build();
		aimSyncService.syncData(syncJobRequest1);

		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.build(); // no setting eventId

		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, list.size());
		Assert.assertEquals(0,
				Integer.parseInt(list.get(0).get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(list.get(0).get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listChange = jdbcTemplate
				.queryForList("select * from segment_change_log order by segment_change_id");
		Assert.assertEquals(
				0,
				Integer.parseInt(listChange.get(0).get("CHANGE_TYPE")
						.toString()));
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(1).get("CHANGE_TYPE")
						.toString()));
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(2).get("CHANGE_TYPE")
						.toString()));

	}

	// delete
	@Test
	public void testSyncDataDeleteNull() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		aimSyncService.syncData(syncJobRequest);

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();
		aimSyncService.syncData(syncJobRequest1);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).build();

		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, list.size());
		Assert.assertEquals(0,
				Integer.parseInt(list.get(0).get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(list.get(1).get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(list.get(0).get("CONTAINER_ID").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(list.get(1).get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(0).get("CHANGE_TYPE")
						.toString()));
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(1).get("CHANGE_TYPE")
						.toString()));

	}

	@Test
	public void testSyncDataDeleteScopeIs1() {

		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		aimSyncService.syncData(syncJobRequest);

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_SLAP);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();
		aimSyncService.syncData(syncJobRequest1);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest
				.newBuilder()
				.setFunction(SyncFunctionType.DELETE)
				.setExternalId("1")
				.setEventId(1)
				.setDeletePayload(PBSyncDeletePayload.newBuilder().addScopes(1))
				.build();

		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));

		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, list.size());
		Assert.assertEquals(0,
				Integer.parseInt(list.get(0).get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(list.get(1).get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(list.get(0).get("CONTAINER_ID").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(list.get(1).get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(0).get("CHANGE_TYPE")
						.toString()));
		Assert.assertEquals(
				1,
				Integer.parseInt(listChange.get(1).get("CHANGE_TYPE")
						.toString()));

	}

	@Test
	public void testSyncDataDeleteNewSegRDBT() {
		// jdbcTemplate.update("insert into segments (SEGMENT_ID,)");
		// segment_seq.NEXTVAL
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();

		aimSyncService.syncData(syncJobRequest1);

		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBT);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(331,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, listSeg.size());
		Map<String, Object> mapSeg1 = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg1.get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg1.get("VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg1.get("CONTAINER_ID").toString()));
		Map<String, Object> mapSeg2 = listSeg.get(1);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg2.get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg2.get("VERSION").toString()));
		Assert.assertEquals(331,
				Integer.parseInt(mapSeg2.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Test
	public void testSyncDataDeleteNewSegRDBTM() {
		// jdbcTemplate.update("insert into segments (SEGMENT_ID,)");
		// segment_seq.NEXTVAL
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();

		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setFingerPrintType(
						FingerPrintType.FINGER_PRINT_ROLLED);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();

		aimSyncService.syncData(syncJobRequest1);

		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBTM);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(map.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, listSeg.size());
		Map<String, Object> mapSeg1 = listSeg.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg1.get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg1.get("VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg1.get("CONTAINER_ID").toString()));
		Map<String, Object> mapSeg2 = listSeg.get(1);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg2.get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg2.get("VERSION").toString()));
		Assert.assertEquals(331,
				Integer.parseInt(mapSeg2.get("CONTAINER_ID").toString()));

		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Test
	public void testSyncDataDeleteNewSegRDBL() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(3,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Test
	public void testSyncDataDeleteNewSegRDBLS() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();
		aimSyncService.syncData(syncJobRequest1);
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select change_type from segment_change_log", Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(3,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(323,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(3, listSegChange.size());
		/*
		 * Map<String, Object> mapSegChange = listSegChange.get(1);
		 * Assert.assertEquals(2, Integer.parseInt(mapSegChange.get(
		 * "SEGMENT_VERSION").toString())); Assert.assertEquals(1,
		 * Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
		 */
	}

	@Test
	public void testSyncDataDeleteNewSegRDBLM() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();
		aimSyncService.syncData(syncJobRequest1);
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select change_type from segment_change_log", Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLM);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(3,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(333,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log order by segment_change_id");
		Assert.assertEquals(3, listSegChange.size());
	}

	@Test
	public void testSyncDataDeleteNewSegRDBLMTwoSame() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();
		aimSyncService.syncData(syncJobRequest1);
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select change_type from segment_change_log", Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLM);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder)
				.addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		try {
			aimSyncService.syncData(syncJobRequestDel);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Sync Job (Specified key and indexer list in insertpayload or deletePayload was duplicate.)",
					e.getMessage());
		}
	}

	@Test
	public void testSyncDataDeleteNewSegRDBLX() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLX);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}

		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select max(change_type)  from segment_change_log",
				Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLX);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(5,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(341,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(5, listSegChange.size());
		/*
		 * Map<String, Object> mapSegChange = listSegChange.get(1);
		 * Assert.assertEquals(2, Integer.parseInt(mapSegChange.get(
		 * "SEGMENT_VERSION").toString())); Assert.assertEquals(0,
		 * Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
		 */
	}

	@Test
	public void testSyncDataDeleteNewSegPDB() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_PALM_LEFT_FULL);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();
		aimSyncService.syncData(syncJobRequest1);
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));

		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(333,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Test
	public void testSyncDataDeleteNewSegFDB() {
		byte[] a = { 1, 2, 3 };
		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder = PBKeyedTemplateIndexer
				.newBuilder().setPosition(
						ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_RDBLM)
				.setIndexer(keyTempIndexerBuilder);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		PBSyncJobResponse response = aimSyncService.syncData(syncJobRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, response
				.getServiceState().getState());

		PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder1 = PBKeyedTemplateIndexer
				.newBuilder().setIndex(1);
		PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(keyTempIndexerBuilder1);
		PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder1);
		PBSyncInsertPayload.Builder syncInsertPayload1 = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder1);
		PBSyncJobRequest syncJobRequest1 = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload1)
				.build();
		aimSyncService.syncData(syncJobRequest1);
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));

		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(2, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(333,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(0);
		Assert.assertEquals(1, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Test
	public void testSyncDataDeleteNewSegLDB_EventIdNull() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDB);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> listSeg1 = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg1.size());
		Map<String, Object> mapSeg1 = listSeg1.get(0);
		Assert.assertEquals(3,
				Integer.parseInt(mapSeg1.get("RECORD_COUNT").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg1.get("VERSION").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select max(change_type)  from segment_change_log",
				Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDB);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(5,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(321,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(5, listSegChange.size());
		/*
		 * Map<String, Object> mapSegChange = listSegChange.get(1);
		 * Assert.assertEquals(4, Integer.parseInt(mapSegChange.get(
		 * "SEGMENT_VERSION").toString())); Assert.assertEquals(1,
		 * Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
		 */
	}

	@Test
	public void testSyncDataDeleteNewSegLDB() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDB);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}
		List<Map<String, Object>> listSeg1 = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg1.size());
		Map<String, Object> mapSeg1 = listSeg1.get(0);
		Assert.assertEquals(3,
				Integer.parseInt(mapSeg1.get("RECORD_COUNT").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg1.get("VERSION").toString()));
		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select max(change_type)  from segment_change_log",
				Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDB);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(5,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(321,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(5, listSegChange.size());
		/*
		 * Map<String, Object> mapSegChange = listSegChange.get(1);
		 * Assert.assertEquals(4, Integer.parseInt(mapSegChange.get(
		 * "SEGMENT_VERSION").toString())); Assert.assertEquals(1,
		 * Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
		 */
	}

	@Test
	public void testSyncDataDeleteNewSegPLDB() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_PLDB);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}

		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select max(change_type)  from segment_change_log",
				Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PLDB);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(5,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(322,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(5, listSegChange.size());
		/*
		 * Map<String, Object> mapSegChange = listSegChange.get(1);
		 * Assert.assertEquals(2, Integer.parseInt(mapSegChange.get(
		 * "SEGMENT_VERSION").toString())); Assert.assertEquals(0,
		 * Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
		 */
	}

	@Test
	public void testSyncDataDeleteNewSegLDBS() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBS);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}

		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select max(change_type)  from segment_change_log",
				Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDBS);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(5,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(326,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(5, listSegChange.size());
		/*
		 * Map<String, Object> mapSegChange = listSegChange.get(1);
		 * Assert.assertEquals(2, Integer.parseInt(mapSegChange.get(
		 * "SEGMENT_VERSION").toString())); Assert.assertEquals(0,
		 * Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
		 */
	}

	@Test
	public void testSyncDataDeleteNewSegLDBM() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBM);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}

		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select max(change_type)  from segment_change_log",
				Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDBM);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(5,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(336,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(5, listSegChange.size());
		/*
		 * Map<String, Object> mapSegChange = listSegChange.get(1);
		 * Assert.assertEquals(2, Integer.parseInt(mapSegChange.get(
		 * "SEGMENT_VERSION").toString())); Assert.assertEquals(0,
		 * Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
		 */
	}

	@Test
	public void testSyncDataDeleteNewSegLDBX() {
		byte[] a = { 1, 2, 3 };

		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBX);
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setEventId(1)
				.setExternalId("1").setInsertPayload(syncInsertPayload).build();
		for (int i = 0; i < 3; i++) {
			PBSyncJobResponse response = aimSyncService
					.syncData(syncJobRequest);
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
					response.getServiceState().getState());
		}

		Assert.assertEquals(new Integer(3), jdbcTemplate.queryForObject(
				"select count(*) from PERSON_BIOMETRICS", Integer.class));
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from segments", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select max(change_type)  from segment_change_log",
				Integer.class));
		PBKeyedTemplate.Builder keyBuilder = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDBX);
		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.DELETE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(5,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(342,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(5, listSegChange.size());
		/*
		 * Map<String, Object> mapSegChange = listSegChange.get(1);
		 * Assert.assertEquals(2, Integer.parseInt(mapSegChange.get(
		 * "SEGMENT_VERSION").toString())); Assert.assertEquals(0,
		 * Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
		 */
	}

	@Test
	public void testSyncDataUpdateNewSegLDBX() {
		byte[] a = { 1, 2, 3, 4 };
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,342,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),3,'123',0,1,342)");
		jdbcTemplate.execute("commit");
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBX)
				.setTemplateBinary(ByteString.copyFrom(a));
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);

		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyedTemBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.UPDATE).setExternalId("1")
				.setEventId(1).setDeletePayload(delPayLoadBuilder)
				.setInsertPayload(syncInsertPayload).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(342,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(2, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(1);
		Assert.assertEquals(2, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Test
	public void testSyncDataUpdateNewSegLDBX_EvantIdNull() {
		byte[] a = { 1, 2, 3, 4 };
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,342,1,1,83,1,0,0,83)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),3,'123',0,0,342)");
		jdbcTemplate.execute("commit");
		PBKeyedTemplate.Builder keyedTemBuilder = PBKeyedTemplate.newBuilder()
				.setTemplateBinary(ByteString.copyFrom(a))
				.setKey(TemplateFormatType.TEMPLATE_LDBX)
				.setTemplateBinary(ByteString.copyFrom(a));
		PBKeyedTemplateData.Builder keyedTemDataBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedTemplate(keyedTemBuilder);
		PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
				.newBuilder().setScope(1)
				.addKeyedTemplateData(keyedTemDataBuilder);

		PBSyncDeletePayload.Builder delPayLoadBuilder = PBSyncDeletePayload
				.newBuilder().addScopes(1).addKeyedTemplate(keyedTemBuilder);
		PBSyncJobRequest syncJobRequestDel = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.UPDATE).setExternalId("1")
				.setDeletePayload(delPayLoadBuilder)
				.setInsertPayload(syncInsertPayload).build();
		aimSyncService.syncData(syncJobRequestDel);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1, list.size());

		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
		Assert.assertEquals(342,
				Integer.parseInt(mapSeg.get("CONTAINER_ID").toString()));
		List<Map<String, Object>> listSegChange = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(2, listSegChange.size());
		Map<String, Object> mapSegChange = listSegChange.get(1);
		Assert.assertEquals(2, Integer.parseInt(mapSegChange.get(
				"SEGMENT_VERSION").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapSegChange.get("CHANGE_TYPE").toString()));
	}

	@Ignore
	@Test
	public void testSyncDataAndPushData() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(65512);
			server.start(getMockHandler());

			URL url = this.getClass().getResource("SyncAndPush.sql");
			executeSqlScript("file:///" + url.getPath(), false);

			byte[] a = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
			PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder_roll = PBKeyedTemplateIndexer
					.newBuilder().setFingerPrintType(
							FingerPrintType.FINGER_PRINT_ROLLED);

			/*
			 * PBKeyedTemplateIndexer.Builder keyTempIndexerBuilder_slap =
			 * PBKeyedTemplateIndexer .newBuilder().setFingerPrintType(
			 * FingerPrintType.FINGER_PRINT_SLAP);
			 */

			PBKeyedTemplate.Builder keyedTemBuilder1 = PBKeyedTemplate
					.newBuilder().setTemplateBinary(ByteString.copyFrom(a))
					.setKey(TemplateFormatType.TEMPLATE_RDBT)
					.setIndexer(keyTempIndexerBuilder_roll);

			/*
			 * PBKeyedTemplate.Builder keyedTemBuilder2 = PBKeyedTemplate
			 * .newBuilder().setTemplateBinary(ByteString.copyFrom(a))
			 * .setKey(TemplateFormatType.TEMPLATE_RDBT)
			 * .setIndexer(keyTempIndexerBuilder_slap);
			 */

			// PBKeyedTemplate.Builder keyedTemBuilder3 = PBKeyedTemplate
			// .newBuilder().setTemplateBinary(ByteString.copyFrom(a))
			// .setKey(TemplateFormatType.TEMPLATE_RDBTM)
			// .setIndexer(keyTempIndexerBuilder_slap);

			PBKeyedTemplateData.Builder keyedTemDataBuilder1 = PBKeyedTemplateData
					.newBuilder().setKeyedTemplate(keyedTemBuilder1);

			// PBKeyedTemplateData.Builder keyedTemDataBuilder2 =
			// PBKeyedTemplateData
			// .newBuilder().setKeyedTemplate(keyedTemBuilder2);

			PBSyncInsertPayload.Builder syncInsertPayload = PBSyncInsertPayload
					.newBuilder().setScope(1)
					.addKeyedTemplateData(keyedTemDataBuilder1);
			PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
					.setFunction(SyncFunctionType.INSERT).setEventId(1)
					.setExternalId("1").setInsertPayload(syncInsertPayload)
					.build();
			aimSyncService.syncData(syncJobRequest);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Assert.assertEquals(4, q.size());
			if (server != null) {
				server.stop();
			}
		}
	}

	private static final Object LOCKER = new Object();
	private static final Queue<PBSegmentSyncRequest> q = Queues
			.newConcurrentLinkedQueue();

	/**
	 * getMockHandler
	 * 
	 * @return AbstractHandler
	 */
	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();

				System.out.println(baseRequest.getRequestURI());
				PBSegmentSyncRequest result = PBSegmentSyncRequest
						.parseFrom(request.getInputStream());
				System.out.println(baseRequest.getRequestURI());
				System.out.println(result.toString());

				q.add(result);

				if (q.size() == 4) {
					synchronized (LOCKER) {
						LOCKER.notify();
					}
				}

				response.setStatus(200);
				response.setContentType("application/octet-stream");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}

}
