package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Maps;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class RetryInquiryJobProcedureTest {
	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	private InquiryJobDao inquiryjobdao;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private RetryInquiryJobProcedure retryinquiryjobprocedure;

	private JdbcTemplateHelper helper = new JdbcTemplateHelper();

	@Before
	public void setUp() throws Exception {
		retryinquiryjobprocedure = new RetryInquiryJobProcedure(ds);
		inquiryjobdao = new InquiryJobDao(entityManager);

		helper.deleteInquiryJob(jdbcTemplate);
		helper.scene01(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		helper.deleteInquiryJob(jdbcTemplate);
	}

	@Test
	public void testRetryInquiryJob_JobId() {
		long jobId = 1000;
		long exec_count = retryinquiryjobprocedure.execute(1000);// JobId 1000
		assertEquals(1, exec_count);
		JobQueueEntity jobqueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(80, jobqueue.getRemainJobs());
		assertEquals(1, jobqueue.getFailureCount());
		assertEquals(JobState.QUEUED, jobqueue.getJobState());
		assertNull(jobqueue.getAssignedTs());// TODO AssignedTs==null
		List<ContainerJobEntity> containerjoblist = inquiryjobdao
				.getAllContainerJob(jobId);
		for (ContainerJobEntity containerjob : containerjoblist) {
			assertNull(containerjob.getMrId());
			assertNull(containerjob.getAssignedTs());
			assertNull(containerjob.getPlanId());
			assertNull(containerjob.getResultTs());
			assertNull(containerjob.getContainerJobResult());
			assertEquals(JobState.QUEUED, containerjob.getJobState());
		}

		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
				.getInquiryTraffic(jobId);
		assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());// Error
	}

	@Test
	public void testRetryInquiryJob_null() {
		new MockUp<StoredProcedure>() {
			@Mock
			public Map<String, Object> execute(Map<String, ?> inParams)
					throws DataAccessException {
				Map<String, Object> result = Maps.newHashMap();
				result.put("l_job_exec_count", null);
				return result;
			}
		};
		try {
			long exec_count = retryinquiryjobprocedure.execute(1000);// JobId
																		// 1000
			assertEquals(-2, exec_count);
		} finally {
			mockit.Mockit.tearDownMocks();
		}
	}
}
