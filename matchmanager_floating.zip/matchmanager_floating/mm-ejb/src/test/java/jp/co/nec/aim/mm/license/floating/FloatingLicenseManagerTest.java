package jp.co.nec.aim.mm.license.floating;


import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;





public class FloatingLicenseManagerTest {
	
	private String OPTIONS="TYPE=FULL;COMPONENT=MM;MODALTY=FINGER,FACE,PALM,IRIS";

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFeatureData() {
		String[] arrs = OPTIONS.split(";");
		Assert.assertEquals(3, arrs.length);		
		for (String one : arrs) {
			String[] subArrs = one.split("=");
			Assert.assertEquals(2, subArrs.length);
		}
		for (int i = 0 ; i < arrs.length; i++) {
			String[] subArrs = arrs[i].split("=");
			if (i == 0) {
				Assert.assertEquals(subArrs[0], "TYPE");
				Assert.assertEquals(subArrs[1], "FULL");
			}
			if (i == 1) {
				Assert.assertEquals(subArrs[0], "COMPONENT");
				Assert.assertEquals(subArrs[1], "MM");
			}
			if (i == 2) {
				Assert.assertEquals(subArrs[0], "MODALTY");
				Assert.assertEquals(subArrs[1], "FINGER,FACE,PALM,IRIS");
				String[] licenseInfo = subArrs[1].split(",");
				Assert.assertEquals(4, licenseInfo.length);
			}			
		}
	}
	
	@Test
	public void testFeatureLiceneInfoContain() {
		String[] arrs = OPTIONS.split(";");
		for (int i = 0 ; i < arrs.length; i++) {
			String[] subArrs = arrs[i].split("=");
			if (i == 2) {
				String[] licenseInfo = subArrs[1].split(",");
				for (String one : licenseInfo) {
					Assert.assertTrue(OPTIONS.contains(one));
				}				
			}
		}
	}
	
	@Test
	public void StringContain() {
		String Option_modatliy = "FINGER,FACE,PALM,IRIS";
		String modality ="finger,face,palm,iris";
		Assert.assertTrue(Option_modatliy.toUpperCase().equals(modality.toUpperCase()));
		
		String[] arrs = modality.split(",");
		for (String one : arrs) {
			Assert.assertTrue(OPTIONS.contains(one.toUpperCase()));
		}
	}	

}
