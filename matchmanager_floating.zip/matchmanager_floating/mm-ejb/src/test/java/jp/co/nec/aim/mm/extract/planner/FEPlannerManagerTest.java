package jp.co.nec.aim.mm.extract.planner;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.FEPlannerDAO;
import jp.co.nec.aim.mm.dao.FEPlannerDAOImpl;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.notifier.FEplanCreatedEventNotifier;
import mockit.Deencapsulation;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mockit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
@TransactionConfiguration(transactionManager = "transactionManager")
public class FEPlannerManagerTest {

	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;

	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	FEPlannerManager fEPlannerManager;
	FEPlannerDAO feDao;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from SYSTEM_INIT");
		jdbcTemplate.execute("delete from fe_lot_jobs");
		jdbcTemplate.execute("delete from mu_extract_load");
		jdbcTemplate.execute("delete from fe_job_queue");
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("commit");
		feDao = new FEPlannerDAOImpl(dataSource, entityManager);
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from SYSTEM_INIT");
		jdbcTemplate.execute("delete from fe_lot_jobs");
		jdbcTemplate.execute("delete from mu_extract_load");
		jdbcTemplate.execute("delete from fe_job_queue");
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testMakeFEPlans_OK() {
		new MockUp<FEplanCreatedEventNotifier>() {
			@Mock
			public boolean notify(long lotJobId) {
				return true;
			}
		};
		Deencapsulation.setField(fEPlannerManager, "maxMulots",
				new AtomicInteger(5));
		String insertSql = "insert into system_init (init_id, key_name, key_value) values "
				+ " (system_init_SEQ.nextval,'NUM_OF_MAX_FE_LOT','12')";
		jdbcTemplate.update(insertSql);
		jdbcTemplate.execute("commit");

		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}
		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * feJobIds.length;
		jdbcTemplate.execute("commit");

		fEPlannerManager.makeFEPlans();

		String selectFeLotJobSql = "select *  from fe_lot_jobs where mu_id = ?";
		List<Map<String, Object>> feLotJobs = jdbcTemplate.queryForList(
				selectFeLotJobSql, new Object[] { muIds[0] });
		Assert.assertTrue(feLotJobs.size() >= 1);
		Iterator<Map<String, Object>> it = feLotJobs.iterator();
		while (it.hasNext()) {
			Map<String, Object> tmp = it.next();
			Assert.assertNotNull(tmp.get("ASSIGNED_TS"));
			Assert.assertNotNull(tmp.get("LOT_JOB_ID"));
		}

		long feLotJobId = -999;
		long muId = -999;
		String selectFeJobSql = "select * from fe_job_queue fq where fq.lot_job_id = ?";
		for (int i = 0; i < feLotJobs.size(); i++) {
			feLotJobId = ((BigDecimal) feLotJobs.get(i).get("lot_job_id"))
					.longValue();
			muId = ((BigDecimal) feLotJobs.get(i).get("mu_id")).longValue();
			Assert.assertTrue(feLotJobs.get(i).get("ASSIGNED_TS") != null);

		}
		List<Map<String, Object>> feJobs = jdbcTemplate.queryForList(
				selectFeJobSql, new Object[] { new Long(feLotJobId) });
		for (int j = 0; j < feJobs.size(); j++) {
			Assert.assertTrue(feJobs.get(j).get("ASSIGNED_TS") != null);
			Assert.assertEquals(muId,
					((BigDecimal) feJobs.get(j).get("mu_id")).longValue());
		}
		int count = jdbcTemplate.queryForObject(
				"select count(*) from fe_lot_jobs", Integer.class);
		Assert.assertTrue(count > 0);
		Mockit.tearDownMocks();
	}
	
	@Test
	@Rollback(true)
	public void testMakeFEPlans_remainLot_null() {
		new MockUp<FEplanCreatedEventNotifier>() {
			@Mock
			public boolean notify(long lotJobId) {
				return true;
			}
		};
		Deencapsulation.setField(fEPlannerManager, "maxMulots",
				new AtomicInteger(5));
		String insertSql = "insert into system_init (init_id, key_name, key_value) values "
				+ " (system_init_SEQ.nextval,'NUM_OF_MAX_FE_LOT','12')";
		jdbcTemplate.update(insertSql);
		jdbcTemplate.execute("commit");

		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 0, 0, 0, 0, 0 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}
		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * feJobIds.length;
		jdbcTemplate.execute("commit");

		fEPlannerManager.makeFEPlans();
	
		Mockit.tearDownMocks();
	}

	@Test(expected = AimRuntimeException.class)
	public void testMakeFEPlans_RuntimeException() {
		new MockUp<FEplanCreatedEventNotifier>() {
			@Mock
			public boolean notify(long lotJobId) {
				return true;
			}
		};
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}
		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		String insertMaxLotSql = "insert into SYSTEM_INIT (INIT_ID, KEY_NAME, KEY_VALUE) values "
				+ " (SYSTEM_INIT_SEQ.nextval,'NUM_OF_MAX_FE_LOT','0')";
		jdbcTemplate.update(insertMaxLotSql);
		jdbcTemplate.execute("commit");
		fEPlannerManager.makeFEPlans();

		Mockit.tearDownMocks();
	}

	public void testMakeFEPlans_notifier_failed() {
		new MockUp<FEplanCreatedEventNotifier>() {
			@Mock
			public boolean notify(long lotJobId) {
				return false;
			}
		};
		String insertSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_MU_LOTS','12')";
		jdbcTemplate.update(insertSql);

		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		Integer muCpu = 4;
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
		}

		long assignedTS = System.currentTimeMillis();
		Long[] feJobIds = { 3000L, 3001L, 3002L, 3003L, 3004L };
		Integer[] priotity = { 2, 2, 2, 3, 2 };
		Integer[] states = { 0, 0, 0, 0, 0 };
		Integer[] failureCount = { 0, 1, 2, 2, 1 };

		String feJobSql = "insert into fe_job_queue(job_id,function_id,PRIORITY,job_state,failure_count,submission_ts,CALLBACK_STYLE)"
				+ " values(?,17,?,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
					priotity[i], states[i], failureCount[i],
					new Long(assignedTS) });
		}
		String topJobtimeOutValueSql = " SELECT top_level_job_timeouts"
				+ " FROM function_types " + " WHERE function_id = 17"
				+ "AND queue_type = 1";
		Long topJobtimeOutValue = jdbcTemplate.queryForObject(
				topJobtimeOutValueSql, Long.class);
		topJobtimeOutValue = topJobtimeOutValue * muCpu;
		jdbcTemplate.execute("commit");
		fEPlannerManager.makeFEPlans();
		String MaxFeLobJobIdSql = "select max(lot_job_id) from fe_lot_job";
		Long lotJobId = jdbcTemplate.queryForObject(MaxFeLobJobIdSql,
				Long.class);

		Integer result = feDao.getFeLotJobCount(lotJobId);
		Assert.assertEquals(null, result);
		String selFeJobSql = "select fq.lot_job_id,fq.mu_id,fq.assigned_ts from fe_job_queue fq where fq.lot_job_id = ?";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(
				selFeJobSql, new Object[] { lotJobId });
		for (int i = 0; i < results.size(); i++) {
			Assert.assertEquals(null, results.get(i).get("lot_job_id"));
			Assert.assertEquals(null, results.get(i).get("mu_id"));
			Assert.assertEquals(null, results.get(i).get("assigned_ts"));
		}
		Mockit.tearDownMocks();
	}
}
