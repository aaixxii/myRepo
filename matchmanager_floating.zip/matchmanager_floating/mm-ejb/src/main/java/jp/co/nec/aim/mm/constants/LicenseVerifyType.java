package jp.co.nec.aim.mm.constants;

public enum LicenseVerifyType {
	FLOATING, LOCAL;
}
