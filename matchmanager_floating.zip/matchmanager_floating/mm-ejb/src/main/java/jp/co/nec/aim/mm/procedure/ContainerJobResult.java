package jp.co.nec.aim.mm.procedure;

public class ContainerJobResult {
	byte[] containerJobsResult;

	/**
	 * @return the containerJobsResult
	 */
	public byte[] getContainerJobsResult() {
		return containerJobsResult;
	}

	/**
	 * @param containerJobsResult
	 *            the containerJobsResult to set
	 */
	public void setContainerJobsResult(byte[] containerJobsResult) {
		this.containerJobsResult = containerJobsResult;
	}

}
