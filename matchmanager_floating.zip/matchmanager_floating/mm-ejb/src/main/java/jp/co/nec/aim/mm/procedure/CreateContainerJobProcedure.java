package jp.co.nec.aim.mm.procedure;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleConnection;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.nativejdbc.CommonsDbcpNativeJdbcExtractor;

import com.google.common.collect.Maps;

/**
 * CreateContainerJobProcedure
 * 
 * @author liuyq
 * 
 */
public class CreateContainerJobProcedure extends StoredProcedure {
	private static final String SQL = "MATCH_MANAGER_API.CREATE_CONTAINER_JOB";

	private Long jobId; // top level job id
	private Integer searchRequestIndex; // search request index
	private Integer functionId; // function id
	private byte[] inquiryJobData; // inquiry job data
	private List<Integer> containerIds; // list of container id
	private Map<String, Object> resultMap; // result map

	/**
	 * CreateContainerJobProcedure
	 * 
	 * @param dataSource
	 *            the instance of DataSource
	 */
	public CreateContainerJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		getJdbcTemplate().setNativeJdbcExtractor(
				new CommonsDbcpNativeJdbcExtractor());
		setFunction(true); // Procedure is function
		// declare Output Parameter first
		declareParameter(new SqlOutParameter("l_fusion_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_search_request_index",
				Types.BIGINT));
		declareParameter(new SqlParameter("p_function_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_inquiry_job_data", Types.BINARY));
		declareParameter(new SqlParameter("p_container_list", Types.ARRAY,
				"NUM_TABLE_TYPE"));
		declareParameter(new SqlOutParameter("p_empty_job", Types.INTEGER));
		declareParameter(new SqlOutParameter("p_remain_job", Types.INTEGER));
		compile();
	}

	/**
	 * execute the Procedure create_container_job
	 */
	public void execute() {
		Map<String, Object> map = Maps.newHashMap();
		map.put("p_job_id", new Long(getJobId()));
		map.put("p_search_request_index", getSearchRequestIndex());
		map.put("p_function_id", getFunctionId());
		map.put("p_inquiry_job_data", getInquiryJobData());
		map.put("p_container_list", new AbstractSqlTypeValue() {
			public Object createTypeValue(Connection con, int sqlType,
					String typeName) throws SQLException {
				OracleConnection oraConn = con.unwrap(OracleConnection.class);
				return oraConn.createARRAY(typeName, containerIds.toArray());
			}
		});
		resultMap = execute(map);
	}

	public Long getFusionJobId() {
		return (Long) resultMap.get("l_fusion_job_id");
	}

	public Integer getEmptyJob() {
		return (Integer) resultMap.get("p_empty_job");
	}

	public Integer getRemainJob() {
		return (Integer) resultMap.get("p_remain_job");
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Integer getSearchRequestIndex() {
		return searchRequestIndex;
	}

	public void setSearchRequestIndex(Integer searchRequestIndex) {
		this.searchRequestIndex = searchRequestIndex;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public byte[] getInquiryJobData() {
		return inquiryJobData;
	}

	public void setInquiryJobData(byte[] inquiryJobData) {
		this.inquiryJobData = inquiryJobData;
	}

	public List<Integer> getContainerIds() {
		return containerIds;
	}

	public void setContainerIds(List<Integer> containerIds) {
		this.containerIds = containerIds;
	}
}
