package jp.co.nec.aim.mm.constants;

public enum LicenseType {
	TRIAL,FULL;
}
