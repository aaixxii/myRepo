package jp.co.nec.aim.mm.constants;

/**
 * Detail Code 1
 */
public enum D1 {
	AIMCOMMON("0"), OSDEPENDANT("1"), MIDDLEWARERELATED("2"), DATABASE("3"), APPLICATIONPROGRAMS(
			"4"), OTHER("5"), CLINET("6"),LICENSESERVER("7");
	private String errorCode; // error code

	private D1(String errorCode) {
		this.setErrorCode(errorCode);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}