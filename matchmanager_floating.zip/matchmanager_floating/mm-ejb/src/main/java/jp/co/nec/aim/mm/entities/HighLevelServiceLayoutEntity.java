package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * The persistent class for the HIGH_LEVEL_SERVICE_LAYOUTS database table.
 * 
 */
@Entity
@Table(name = "HIGH_LEVEL_SERVICE_LAYOUTS")
public class HighLevelServiceLayoutEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SCRIPT_ID")
	private long scriptId;

	private String name;

	@Lob
	@Column(name = "SCRIPT_XML")
	private String scriptXml;

	public HighLevelServiceLayoutEntity() {
	}

	public long getScriptId() {
		return this.scriptId;
	}

	public void setScriptId(long scriptId) {
		this.scriptId = scriptId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getScriptXml() {
		return this.scriptXml;
	}

	public void setScriptXml(String scriptXml) {
		this.scriptXml = scriptXml;
	}

}