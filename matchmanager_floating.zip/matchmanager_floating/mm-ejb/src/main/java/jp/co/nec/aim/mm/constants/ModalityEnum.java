package jp.co.nec.aim.mm.constants;

public enum ModalityEnum {
	FINGER, PALM, FACE, IRIS;
}
