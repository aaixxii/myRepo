package jp.co.nec.aim.mm.sessionbeans;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.xml.ws.http.HTTPException;

import jp.co.nec.aim.message.proto.AIMMessages.PBExtractJobResultInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.MuLoadDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.extract.dispatch.ExtractJobResultCallBacker;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExtractJobHandler;
import jp.co.nec.aim.mm.util.Deflater;
import jp.co.nec.aim.mm.util.KeyedIndexer;
import jp.co.nec.aim.mm.util.TimeHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.protobuf.InvalidProtocolBufferException;

/**
 * EJB to record search job results into DB.
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ExtractJobCompleteBean {
	private static final Logger log = LoggerFactory
			.getLogger(ExtractJobCompleteBean.class);
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	@EJB
	private ExtractJobResultCallBacker callBacker;

	private SystemConfigDao sysConfigDao;
	private MuLoadDao muLoadDao;
	private FEJobDao feJobDao;
	private DateDao dateDao;

	private ExtractJobHandler extractJobHandler;
	private FeJobDoneLogger feJobDoneLogger;
	private ExceptionSender exceptionSender;

	public ExtractJobCompleteBean() {
	}

	@PostConstruct
	public void init() {
		extractJobHandler = new ExtractJobHandler(manager, dataSource,
				callBacker);
		feJobDoneLogger = new FeJobDoneLogger(dataSource);
		exceptionSender = new ExceptionSender();

		sysConfigDao = new SystemConfigDao(manager);
		muLoadDao = new MuLoadDao(dataSource);
		feJobDao = new FEJobDao(manager);
		dateDao = new DateDao(dataSource);
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * Update for extract jobs
	 * 
	 * @param extactJobResult
	 * @throws InvalidProtocolBufferException
	 */
	public void completeExtractJobs(PBMuExtractJobResult extactJobResult)
			throws InvalidProtocolBufferException {
		long muId = extactJobResult.getMuId();
		long lotJobId = extactJobResult.getLotJobId();
		int updatedRecordCnt = 0;
		log.info("Ready to complete Lot Extract Jobs: {}, MU id: {}.",
				lotJobId, muId);
		try {
			Integer maxExtractJobFailures = sysConfigDao
					.getMMPropertyInt(MMConfigProperty.MAX_EXTRACT_JOB_FAILURES);

			for (PBMuExtractJobResultItem ejrItem : extactJobResult
					.getResultList()) {
				PBExtractJobResultInternal pbExInternal = PBExtractJobResultInternal
						.parseFrom(ejrItem.getResult());
				ServiceStateType stateType = pbExInternal.getServiceState()
						.getState();
				if (stateType.equals(ServiceStateType.SERVICE_STATE_SUCCESS)) {
					log.info("MU " + muId + " finishing extract job "
							+ ejrItem.getJobId());
					updatedRecordCnt = finishExtractJob(ejrItem.getJobId(),
							muId, pbExInternal, false);
				} else if (stateType
						.equals(ServiceStateType.SERVICE_STATE_ERROR)) {
					log.warn("MU " + muId + " failed extract job "
							+ ejrItem.getJobId());

					// The reason must be specified when service state is error
					// if not specified, throw IllegalArgumentException
					PBServiceState state = pbExInternal.getServiceState();
					if (!state.hasReason()) {
						throw new IllegalArgumentException(
								"The reason must be specified when service state is error..");
					}

					PBServiceStateReason reason = state.getReason();
					exceptionSender.sendAimException(reason.getCode(),
							reason.getDescription(), 0, ejrItem.getJobId(),
							muId, null);
					updatedRecordCnt = finishExtractJob(ejrItem.getJobId(),
							muId, pbExInternal, true);

				} else {
					PBServiceStateReason reason = pbExInternal
							.getServiceState().getReason();
					exceptionSender.sendAimException(reason.getCode(),
							reason.getDescription(), 0, ejrItem.getJobId(),
							muId, null);

					FeJobQueueEntity eje = manager.find(FeJobQueueEntity.class,
							new Long(ejrItem.getJobId()));
					manager.refresh(eje);
					if (eje == null || eje.getMuId() == null
							|| eje.getMuId() != muId) {
						log.warn("MU " + muId
								+ " attempting to report error reason '"
								+ reason.getCode() + " : "
								+ reason.getDescription()
								+ "' of nonexistant or unassigned job "
								+ ejrItem.getJobId() + ", ignoring...");
					} else {
						updatedRecordCnt = extractJobHandler
								.failExtractJob(eje, muId, reason, false,
										maxExtractJobFailures);
					}
				}

				/* send Jms to ExtractJobPlanner */
				JmsSender.getInstance().sendToFEJobPlanner(
						NotifierEnum.FEJobCompleteBean,
						"Recieve Extract Job " + ejrItem.getJobId());
			}
		} catch (SQLException | IOException e) {
			log.error(e.getMessage(), e);
			throw new AimRuntimeException(e.getMessage(), e);
		} finally {
			log.info("Ready to delete Lot Extract Jobs: {}"
					+ " and decrease ExtractLoad with MU id: {}.", lotJobId,
					muId);
			feJobDao.deleteLotJob(extactJobResult.getLotJobId());
			if (updatedRecordCnt > 0) {
				muLoadDao.decreaseExtractLoad(muId);
				// increaseExtractJobCompleteCount(updatedRecordCnt);
			}
		}
	}

	/**
	 * Finish extract job normally.
	 * 
	 * @param jobId
	 * @param muId
	 * @param itemResult
	 * @param failed
	 * @throws SQLException
	 * @throws IOException
	 * @throws HTTPException
	 */
	private int finishExtractJob(long jobId, long muId,
			PBExtractJobResultInternal itemResult, boolean failed)
			throws SQLException, IOException {
		TimeHelper th = new TimeHelper("finishExtractJob");
		th.t();
		int numCompleted = extractJobHandler.completeExtractJob(jobId, muId,
				itemResult, failed);

		if (0 < numCompleted) {
			if (!failed) {
				sendDuplicateKeyInfo(jobId, muId, itemResult);
			}
			PBExtractJobResult lastResut = unPressPayloadAndBuildPBExtractJobResult(itemResult);
			sendExtractCallback(jobId, lastResut);
		} else {
			log.warn("Extract job (Id:" + jobId
					+ ") is nonexistent or already-complete.");
		}

		th.t();
		if (log.isDebugEnabled()) {
			log.debug(th.message());
		}

		return numCompleted;
	}

	/**
	 * 
	 * @param jobId
	 * @param muId
	 * @param itemResult
	 */
	private void sendDuplicateKeyInfo(long jobId, long muId,
			PBExtractJobResultInternal itemResult) {
		Set<KeyedIndexer> keys = new HashSet<KeyedIndexer>();

		for (PBKeyedTemplate kt : itemResult.getKeyedTemplateList()) {
			KeyedIndexer newKI = new KeyedIndexer(kt.getKey(), kt.getIndexer());
			if (!keys.contains(newKI)) {
				keys.add(newKI);
			} else {
				String message = "Extraction job " + jobId
						+ " contained DUPLICATE key (" + newKI.toString()
						+ "), ignoring...";
				log.error(message);
				exceptionSender.sendAimException(
						AimError.EXTRACT_JOB_DUPLICATE_KEY.getErrorCode(),
						message, jobId, jobId, muId, null);
			}
		}
	}

	private void sendExtractCallback(long jobId, PBExtractJobResult itemResult) {
		feJobDoneLogger.info(jobId);
		boolean callbacksEnabled = sysConfigDao
				.getMMPropertyBool(MMConfigProperty.HTTP_CALLBACKS_ENABLED);
		if (callbacksEnabled) {
			callBacker.asynchCallback(jobId, itemResult);
		}
	}

	public void increaseExtractJobCompleteCount(int finishedFeJobs) {
		Long updateTime = dateDao.getCurrentTimeMS();
		String updateSql = "" + "UPDATE extract_complete_count "
				+ "SET complete_count = COMPLETE_COUNT + ?, "
				+ " complete_ts = ?";
		jdbcTemplate.update(updateSql, new Object[] {
				new Integer(finishedFeJobs), updateTime });
	}

	public PBExtractJobResult unPressPayloadAndBuildPBExtractJobResult(
			PBExtractJobResultInternal pbExInternal) throws IOException {
		byte[] compressedOutputPayload = null;
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult
				.newBuilder();
		if (pbExInternal.hasCompressedOutputPayload()) {
			compressedOutputPayload = pbExInternal.getCompressedOutputPayload()
					.toByteArray();
			byte[] uncompressedOutputPayload = Deflater
					.uncompress(compressedOutputPayload);
			pBExtractJobResult.setOutputPayload(PBExtractOutputPayload
					.parseFrom(uncompressedOutputPayload));
		}
		pBExtractJobResult.setServiceState(pbExInternal.getServiceState());
		pBExtractJobResult.setJobId(pbExInternal.getJobId());
		pBExtractJobResult.addAllKeyedTemplate(pbExInternal
				.getKeyedTemplateList());
		return pBExtractJobResult.build();
	}
}
