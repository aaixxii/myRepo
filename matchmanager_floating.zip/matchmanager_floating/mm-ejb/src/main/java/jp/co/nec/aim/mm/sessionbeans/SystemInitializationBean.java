package jp.co.nec.aim.mm.sessionbeans;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.mm.aggregator.Aggregator;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.AimInfo;
import jp.co.nec.aim.mm.constants.EventLogLevel;
import jp.co.nec.aim.mm.constants.LicenseVerifyType;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.constants.MMEventType;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.MMEventsDao;
import jp.co.nec.aim.mm.dao.MatchManagerDao;
import jp.co.nec.aim.mm.dao.SegmentDefragDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.MatchManagerEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.license.floating.FloatLicenseHandler;
import jp.co.nec.aim.mm.license.floating.FloatingLicenseManager;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.procedure.InitExecutingJobCountProcedure;
import jp.co.nec.aim.mm.scheduler.QuartzManager;
import jp.co.nec.aim.mm.segment.sync.SyncThreadExecutor;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.InquiryJobHandler;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * @author mozj
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SystemInitializationBean {
	private static Logger log = LoggerFactory.getLogger(SystemInitializationBean.class);
	@EJB
	private EventLogBean eventLog;
	@EJB
	private AMRReportBean amrReportBean;
	@EJB
	private PollBean pollBean;
	@EJB
	private Aggregator aggregator;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	private MatchManagerDao mmDao;
	private MMEventsDao mmeDao;
	private SystemConfigDao sysConfigDao;
	private SegmentDefragDao segDefragDao;;
	private InquiryJobDao jobDao;
	private DateDao dateDao;
	private ExceptionSender exceptionSender;
	private InquiryJobHandler inquiryJobHandler;
	private JdbcTemplate jdbcTemplate;

	public SystemInitializationBean() {

	}

	@PostConstruct
	public void init() {
		mmDao = new MatchManagerDao(entityManager);
		mmeDao = new MMEventsDao(entityManager);
		sysConfigDao = new SystemConfigDao(entityManager);
		segDefragDao = new SegmentDefragDao(dataSource);
		jobDao = new InquiryJobDao(entityManager, dataSource);
		dateDao = new DateDao(dataSource);
		exceptionSender = new ExceptionSender();
		inquiryJobHandler = new InquiryJobHandler(entityManager, dataSource, aggregator);
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void initializeAIM() {
		log.info("initializeAIM() called in SystemInitializationBean");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			MatchManagerEntity mm = setStartupTime();
			writeAllMissingProperties();
			calculatingExcutingJobCount();
			clearMapReduces(mm.getMmId());
			initCompletedJobCount();
			startScheduler();
			segDefragDao.initDefragContainerId();
			amrReportBean.startReport();
			if (sysConfigDao.getMMProperty(MMConfigProperty.LICENSE_VERIFY_TYPE)
					.equals(LicenseVerifyType.FLOATING.name())) {
				FloatingLicenseManager fm = FloatingLicenseManager.getInstance();
				fm.initLmx();
				FloatLicenseHandler.getInstance().initHeatbeatHandler(fm.getLmx());
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "initializeAIM", stopWatch.elapsedTime());
		}
	}

	private void writeAllMissingProperties() {
		sysConfigDao.writeAllMissingProperties(dataSource);
		entityManager.flush();
	}

	private void calculatingExcutingJobCount() {
		if (log.isDebugEnabled()) {
			log.debug("Calculating Excuting Job Count.");
		}
		try {
			InitExecutingJobCountProcedure initExcJobCount = new InitExecutingJobCountProcedure(dataSource);
			initExcJobCount.execute();
		} catch (DataAccessException ex) {
			String message = "DataAccessException when Init Executing Job Count";
			log.error(message, ex);
			throw new AimRuntimeException(message, ex);
		}
	}

	private void clearMapReduces(long mmId) {
		List<MatchManagerEntity> mmList = mmDao.listWorkingMMs();
		for (MatchManagerEntity mm : mmList) {
			if (mm.getMmId() != mmId) {
				return;
			}
		}

		if (log.isDebugEnabled()) {
			log.debug("clearMapReduces by MM (" + mmId + ").");
		}

		List<ContainerJobEntity> conjobs = jobDao.getWorkingContainerJobs();
		for (ContainerJobEntity job : conjobs) {
			String errReason = "Dead jobs : " + job.getContainerJobId() + " due to when MM (" + mmId
					+ ") restart clear Map Reduces.";
			if (log.isDebugEnabled()) {
				log.debug(errReason);
			}
			// call failContainerJob function
			try {
				inquiryJobHandler.failInquiryJob(job.getContainerJobId(), AimError.INQ_JOB_RETRY_OVER.getErrorCode(),
						errReason, dateDao.getReasonTime());
			} catch (AimRuntimeException e) {
				String message = "Exception: Container job " + job.getContainerJobId() + " when MM (" + mmId
						+ ") restart clear Map Reduces.";
				log.error(message, e);

				exceptionSender.sendAimException(AimError.INQ_INTERNAL.getErrorCode(), message, job.getContainerJobId(),
						0, job.getMrId(), e);
			}
		}

		if (log.isDebugEnabled()) {
			log.debug("Clear Map Reduces.");
		}
	}

	/**
	 * Starts Scheduler Service
	 */
	private void startScheduler() {
		if (log.isDebugEnabled()) {
			log.debug("Start All Schedulers.");
		}

		try {
			QuartzManager qzManager = QuartzManager.getInstance(entityManager);
			qzManager.startScheduler();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new AimRuntimeException(e);
		}
	}

	/**
	 * insert MM startUpTime into MM_EVENTS table.
	 */
	private MatchManagerEntity setStartupTime() {
		MatchManagerEntity mm = mmDao.createOrLookupVersion();
		mmeDao.setLast(mm.getMmId(), MMEventType.STARTUP);

		AimInfo info = AimInfo.MM_START_UP;
		String detail = String.format(info.getMessage(), mm.getUniqueId());
		eventLog.logEvent(info.getInfoCode(), info.getEventType(), mm.getMmId(), detail, EventLogLevel.INFO);
		return mm;
	}

	public void finalizeAIM() {
		MatchManagerEntity mm = mmDao.createOrLookupVersion();
		mm.setState(UnitState.EXITED);
		entityManager.merge(mm);
		entityManager.flush();

		try {
			QuartzManager qzManager = QuartzManager.getInstance(entityManager);
			qzManager.shutdownScheduler();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		try {
			final SyncThreadExecutor executor = SyncThreadExecutor.getInstance();
			executor.stopInternal();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		if (sysConfigDao.getMMProperty(MMConfigProperty.LICENSE_VERIFY_TYPE)
				.equals(LicenseVerifyType.FLOATING.name())) {
			FloatingLicenseManager mmLmx = FloatingLicenseManager.getInstance();
			if (mmLmx != null) {
				mmLmx.cleanAllLmcResource();
			}
		}
	}

	public void initCompletedJobCount() {
		String inqurySql = "UPDATE inquiry_traffic set JOB_COMPLETE_COUNT = 0";
		String extractSql = "UPDATE extract_complete_count set complete_count =0,complete_ts = 0";
		jdbcTemplate.update(inqurySql);
		jdbcTemplate.update(extractSql);
		jdbcTemplate.execute("commit");
	}

}