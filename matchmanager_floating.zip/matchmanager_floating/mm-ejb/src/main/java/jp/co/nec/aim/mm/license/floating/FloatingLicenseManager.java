package jp.co.nec.aim.mm.license.floating;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Enumeration;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xformation.lmx.Lmx;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxFeatureInfo;
import com.xformation.lmx.LmxHostidType;
import com.xformation.lmx.LmxSettings;

import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.constants.LicenseType;
import jp.co.nec.aim.mm.exception.LicenseException;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.DateUtil;
import jp.co.nec.aim.mm.util.StopWatch;

/*
 * FloatingLicenseManager:
 * 1. get license info from license server and save it to map.<br/>
 * 2. validate license while inquiry job is coming using license info in map.<br/>
 * 
 * @author xiazp
 */
public class FloatingLicenseManager {
	private final ConcurrentHashMap<String, String> mmLicenseMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger(FloatingLicenseManager.class);

	private static final String COMMA = ",";
	private static final String FEATURE_KEY = "afis";
	private static final String SEMICOLON = ";";
	private static final String EQUAL = "=";

	private static final String COMPONENT_MM = "MM";

	private static final String LICENSE_MODALITY = "FINGER,FACE,PALM,IRIS";

	private static final String KEY_LICENSE_TYPE = "licenseType";
	private static final String KEY_COMPONENT = "component";
	private static final String KEY_MODALITY = "modality";
	private static final String KEY_EXPIRED_DATE = "expired";
	private static final String KEY_DONGLE = "dongleSerialNumber";
	private static final String KEY_OPTION = "option";

	private static final String DATE_FORMART = "yyyy-MM-dd";

	private static final String DONGLE_INFO = "sm12x1111c000gbslll";
	

	private ReentrantLock managerLocker;

	private static final Lmx MM_LMX = new Lmx();

	private FloatingLicenseManager() {
		managerLocker = new ReentrantLock();
	}

	public Lmx getLmx() {
		return MM_LMX;
	}

	public void initLmx() throws LmxException {
		logger.info("Floating license manager init...");
		mmLicenseMap.clear();
		MM_LMX.init();
		// String mmUniqueId = getMMHostAddress();
		MM_LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_ATTEMPTS, -1);
		MM_LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_INTERVAL, 30);
		// MM_LMX.setOption(LmxSettings.LMX_OPT_BIND_ADDRESS, mmUniqueId);
	}

	public void clearLicenseInfoMap() {
		mmLicenseMap.clear();
	}

	private static final FloatingLicenseManager INSTANCE = new FloatingLicenseManager();

	public static FloatingLicenseManager getInstance() {
		return INSTANCE;
	}

	/*
	 * @param functionName the function name
	 * 
	 * @param now the current time
	 * 
	 * @throws LicenseException,LmxException
	 */
	public void checkFeature(String functionName, Date now) throws LicenseException, LmxException {
		logger.info("Floating license manager check feature at {}", now);
		AfisLowLevelFunctionEnum functionEnum = AfisLowLevelFunctionEnum.valueOf(functionName);
		String modality = functionEnum.getFunction().name();
		if (StringUtils.isBlank(modality)) {
			throw new LicenseException(AimError.INQ_FUNCTION_TYPE.getErrorCode(),
					AimError.INQ_FUNCTION_TYPE.getMessage(), String.valueOf(now.getTime()));
		}
		managerLocker.lock();
		try {

			if (mmLicenseMap.isEmpty()) {
				checkOutFromServer(now);
			}
			checkLicense(modality, now);
		} finally {
			managerLocker.unlock();
		}
	}

	/*
	 * @param now the current time
	 * 
	 * @throws LicenseException
	 */
	private void checkOutFromServer(Date now) throws LicenseException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		int checkOutTimes = 3;
		LmxFeatureInfo feature = null;
		try {
			MM_LMX.checkout(FEATURE_KEY, 1, 0, 1);
			feature = MM_LMX.getFeatureInfo(FEATURE_KEY);
			String dongleHostid = MM_LMX.getHostidSimple(LmxHostidType.LMX_HOSTID_DONGLE_HASPHL);
			saveFeatureToMap(feature, dongleHostid, now);
			PerformanceLogger.log(getClass().getSimpleName(), "checkOutFromServerAndSavetoMap",
					stopWatch.elapsedTime());
		} catch (Exception e) {
			logger.error("checkout time is:" + checkOutTimes + ". error messge is:" + e.getMessage(), e);
			while (checkOutTimes > 0 && feature == null) {
				try {
					MM_LMX.checkout(FEATURE_KEY, 1, 0, 1);
					feature = MM_LMX.getFeatureInfo(FEATURE_KEY);
				} catch (LmxException e1) {
					logger.error(e.getMessage(), e);
				} finally {
					checkOutTimes--;
				}
			}
		}
		if (feature == null) {
			String errMsg = String.format(
					"FLoating license server error occurred, Error message:can't get %s from license server", feature);
			throw new LicenseException(AimError.FLOATING_LICENSE_SERVER_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}
	}

	/*
	 * @param LmxFeatureInfo the lmx feature
	 * 
	 * @param now the current time
	 * 
	 * @throws LicenseException,LmxException
	 */
	private void saveFeatureToMap(LmxFeatureInfo feature, String dongleHostId, Date now)
			throws LicenseException, LmxException {

		if (StringUtils.isBlank(dongleHostId)) {
			String errMsg = String.format("Floating license validate %s has a error, Error message: %s is not set",
					KEY_DONGLE, KEY_DONGLE);
			throw new LicenseException(AimError.FLOATING_LICENSE_SERVER_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		if (!dongleHostId.equals(DONGLE_INFO)) {
			String errMsg = String.format("Floating license validate %s has a error, Error message: %s is miss match.",
					KEY_DONGLE, KEY_DONGLE);
			throw new LicenseException(AimError.FLOATING_LICENSE_SERVER_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		String featureDate = feature.getEndDate();
		if (StringUtils.isBlank(featureDate)) {
			String errMsg = String.format("Floating license validate %s has a error, Error message: %s is not set",
					"license expired date", "license expired date");

			throw new LicenseException(AimError.FLOATING_LICENSE_VALIDATE_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		featureDate = String.format(DATE_FORMART, featureDate);
		mmLicenseMap.putIfAbsent(KEY_EXPIRED_DATE, featureDate);

		String mmLicenseInfo = feature.getOptions();
		if (StringUtils.isBlank(mmLicenseInfo)) {
			String errMsg = String.format("FLoating license server error occurred, can't found license info from %s.",
					feature);
			throw new LicenseException(AimError.FLOATING_LICENSE_SERVER_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		mmLicenseMap.putIfAbsent(KEY_OPTION, mmLicenseInfo);

		String[] temp = mmLicenseInfo.split(SEMICOLON);
		for (String one : temp) {
			String[] oneArr = one.split(EQUAL);
			if (oneArr.length != 2) {
				String errMsg = "license file formart error";
				throw new LicenseException(AimError.FLOATING_LICENSE_VALIDATE_ERROR.getErrorCode(), errMsg,
						String.valueOf(now.getTime()));
			}
			switch (oneArr[0]) {
			case "TYPE":
				mmLicenseMap.putIfAbsent(KEY_LICENSE_TYPE, oneArr[1]);
				break;
			case "COMPONENT":
				mmLicenseMap.putIfAbsent(KEY_COMPONENT, oneArr[1]);
				break;
			case "MODALTY":
				mmLicenseMap.putIfAbsent(KEY_MODALITY, oneArr[1]);
				break;
			default:
			}
		}
	}

	/*
	 * @param modality modality data, such as FINGER,FACE,PALM,IRIS etc.
	 * 
	 * @param now the current time
	 */
	private void checkLicense(String modality, Date now) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		if (StringUtils.isBlank(mmLicenseMap.get(KEY_COMPONENT))) {
			String errMsg = String.format("Floating license validate %s has a error, Error message: %s is not set",
					"component", "component");
			throw new LicenseException(AimError.FLOATING_LICENSE_VALIDATE_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		if (!mmLicenseMap.get(KEY_COMPONENT).equals(COMPONENT_MM)) {
			String errMsg = String.format(
					"Floating license validate %s has a error, Error message: %s is not equal MM.", "component",
					"component");
			throw new LicenseException(AimError.FLOATING_LICENSE_VALIDATE_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		String licenseType = mmLicenseMap.get(KEY_LICENSE_TYPE);
		if (StringUtils.isBlank(licenseType)) {
			String errMsg = String.format("Floating license validate %s has a error, Error message: %s is not set",
					"license type", "license type");
			throw new LicenseException(AimError.FLOATING_LICENSE_VALIDATE_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		String expiredDateStr = mmLicenseMap.get(KEY_EXPIRED_DATE);

		if (StringUtils.isBlank(expiredDateStr)) {
			String errMsg = String.format("Floating license validate %s has a error, Error message: %s is not set",
					"license expired date", "license expired date");
			throw new LicenseException(AimError.FLOATING_LICENSE_VALIDATE_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		if (now.after(DateUtil.strToDate(expiredDateStr, DATE_FORMART))) {
			String errMsg = String.format(
					"Floating license validate %s has a error, Error message: it's out of end dete, expiredDate is: %s",
					"license expired date", expiredDateStr);
			throw new LicenseException(AimError.FLOATING_LICENSE_VALIDATE_ERROR.getErrorCode(), errMsg,
					String.valueOf(now.getTime()));
		}

		if (licenseType.equals(LicenseType.FULL.name())) {
			String[] modalityArr = mmLicenseMap.get(KEY_MODALITY).split(COMMA);
			for (String one : modalityArr) {
				if (!LICENSE_MODALITY.toUpperCase().contains(one.toUpperCase())) {
					String errMsg = String.format(
							"Floating license validate %s has a error, Error message: %s is not available.",
							"license modality", one);
					throw new LicenseException(AimError.FLOATING_LICENSE_VALIDATE_ERROR.getErrorCode(), errMsg,
							String.valueOf(now.getTime()));
				}
			}
		}
		PerformanceLogger.log(getClass().getSimpleName(), "checkLicense", stopWatch.elapsedTime());
	}

	@SuppressWarnings("unused")
	private String getMMHostAddress() {
		String mmUniqueId = ConfigProperties.getInstance().getPropertyValue(ConfigPropertyNames.MM_IP_ADDRESS);
		if (mmUniqueId == null) {
			try {
				mmUniqueId = InetAddress.getLocalHost().getHostName();
				Enumeration<NetworkInterface> interfaces = java.net.NetworkInterface.getNetworkInterfaces();
				while (interfaces.hasMoreElements()) {
					NetworkInterface ni = interfaces.nextElement();
					Enumeration<InetAddress> addrs = ni.getInetAddresses();
					while (addrs.hasMoreElements()) {
						InetAddress addr = addrs.nextElement();
						if (!addr.isLoopbackAddress()) {
							mmUniqueId = addr.getHostAddress();
						}
					}
				}
			} catch (SocketException e) {
				logger.error(
						"Got a socket exception while trying to enumerate machine network interfaces to determine MM unique ID, using default.",
						e);
			} catch (UnknownHostException e) {
				logger.error("Can't set the MM's unique ID to hostname due to unknown host exception", e);
			}
		}
		return mmUniqueId;
	}

	public void cleanAllLmcResource() {
		try {
			mmLicenseMap.clear();
			MM_LMX.checkin(FEATURE_KEY, Lmx.LMX_ALL_LICENSES);
			MM_LMX.free();
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		}
	}
}
