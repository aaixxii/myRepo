package jp.co.nec.aim.mm.identify.planner;

import java.util.Comparator;

import jp.co.nec.aim.mm.exception.AimRuntimeException;

public class MuSegmentMapKeyComparator implements Comparator<MuSegmentMapKey> {
	@Override
	public int compare(MuSegmentMapKey o1, MuSegmentMapKey o2) {
		if (o1.getContainerId() == null || o1.getFunctionId() == null
				|| o2.getContainerId() == null || o2.getContainerId() == null) {
			String errMsg = " one or more parameter is null!";
			throw new AimRuntimeException(errMsg);
		}
		int first = o1.getFunctionId().compareTo(o2.getFunctionId());
		int second = o1.getContainerId().compareTo(o2.getContainerId());
		return first != 0 ? first : second;
	}
}
