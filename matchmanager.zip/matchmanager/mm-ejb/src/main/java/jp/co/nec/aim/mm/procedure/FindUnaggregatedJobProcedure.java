package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;


import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Call MATCH_MANAGER_API.find_unaggregated_jobs() and returns list of job_id.
 * 
 * @author kurosu
 * 
 */
public class FindUnaggregatedJobProcedure extends StoredProcedure {
	private static final String SQL = "MATCH_MANAGER_API.find_unaggregated_jobs";

	public FindUnaggregatedJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
//		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
//				new CursorMapper()));
		compile();
	}

	/**
	 * call MATCH_MANAGER_API.find_unaggregated_jobs() and returns list of
	 * job_id
	 * 
	 * @return - List of job_id
	 */
	@SuppressWarnings("unchecked")
	public List<Long> execute() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = execute(new HashMap<String, Object>());
		List<Long> list = (List<Long>) map.get("p_refcursor");

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());

		return list;
	}

	private class CursorMapper implements RowMapper<Long> {
		@Override
		public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new Long(rs.getLong("JOB_ID"));
		}
	}

}
