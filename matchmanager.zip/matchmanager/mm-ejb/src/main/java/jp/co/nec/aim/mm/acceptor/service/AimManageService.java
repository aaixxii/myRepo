package jp.co.nec.aim.mm.acceptor.service;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.ManageService.PBCallbackRequest;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdRequest;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResponse;
import jp.co.nec.aim.mm.acceptor.Registration;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.sessionbeans.SystemInitializationBean;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.HttpResponseInfo;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The main work flow of manage <br>
 * 
 * Include following public method:
 * <p>
 * callbackTest, checkExternalId, initialize
 * <p>
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimManageService {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimManageService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@EJB
	private SystemInitializationBean initBean;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private Registration reg;
	private SystemConfigDao configDao;

	/**
	 * AimManageService constructor
	 */
	public AimManageService() {
	}

	@PostConstruct
	private void init() {
		reg = new Registration(dataSource, manager);
		configDao = new SystemConfigDao(manager);
	}

	/**
	 * check callback URL is alive or not
	 * 
	 * @param rquest
	 *            PBCallbackRequest instance
	 * @return HTTP response code (500 return when can not be reachable)
	 */
	public int callbackTest(PBCallbackRequest request) {
		HttpResponseInfo response = null;
		try {
			final String url = request.getCallbackURL();
			final byte[] body = null;

			if (log.isDebugEnabled()) {
				log.debug("ready to http post url: {}", url);
			}

			final int retryCount = configDao
					.getMMPropertyInt(MMConfigProperty.CLIENT_POST_COUNT);
			response = HttpPoster.post(url, body, retryCount);
		} catch (HttpPostException e) {
			return HttpStatus.SC_INTERNAL_SERVER_ERROR;
		}
		return response.getStatusCode();
	}

	/**
	 * checkExternalId
	 * 
	 * @param request
	 *            PBCheckExternalIdRequest instance
	 * @return PBCheckExternalIdResponse instance
	 */
	public PBCheckExternalIdResponse checkExternalId(
			PBCheckExternalIdRequest request) {
		final String externalId = request.getExternalId();
		final List<Integer> eventIds = request.getEventIdsList();
		final List<Integer> containerIds = request.getContainerIdsList();
		PBCheckExternalIdResponse response = reg.createCheckResults(externalId,
				eventIds, containerIds);
		return response;
	}

	/**
	 * initialize the AIM system
	 */
	public void initialize() {
		if (log.isDebugEnabled()) {
			log.debug("call initialize Aim");
		}
		initBean.initializeAIM();
		if (log.isDebugEnabled()) {
			log.debug("call initialize Aim successfully..");
		}
	}
}
