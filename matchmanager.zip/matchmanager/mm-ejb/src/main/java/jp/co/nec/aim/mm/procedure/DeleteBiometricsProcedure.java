package jp.co.nec.aim.mm.procedure;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;


import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.nativejdbc.CommonsDbcpNativeJdbcExtractor;

/**
 * DeleteBiometricsProcedure
 * 
 * @author liuyq
 * 
 */
public class DeleteBiometricsProcedure extends StoredProcedure {

	private static final String SQL = "MATCH_MANAGER_API.DELETE_BIOMETRICS";
	private static final String NUM_TABLE_TYPE = "NUM_TABLE_TYPE";
	private String externalId;
	private Integer eventId;
	private List<Integer> containerIds;

	/**
	 * DeleteBiometricsProcedure
	 * 
	 * @param dataSource
	 *            DataSource instance
	 */
	public DeleteBiometricsProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		// AbstractSqlTypeValue uses native Connection
		getJdbcTemplate().setNativeJdbcExtractor(
				new CommonsDbcpNativeJdbcExtractor());
		setFunction(true);
		// We must set SqlOutParameter FIRST!
		declareParameter(new SqlOutParameter("l_deleted_record_count",
				Types.BIGINT));

		declareParameter(new SqlParameter("p_external_id", Types.VARCHAR));
		declareParameter(new SqlParameter("p_event_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_container_ids", Types.ARRAY,
				NUM_TABLE_TYPE));

		declareParameter(new SqlOutParameter("p_seg_ids", Types.ARRAY,
				NUM_TABLE_TYPE));
		declareParameter(new SqlOutParameter("p_seg_versions", Types.ARRAY,
				NUM_TABLE_TYPE));
		declareParameter(new SqlOutParameter("p_template_ids", Types.ARRAY,
				NUM_TABLE_TYPE));
		compile();
	}

	/**
	 * call MATCH_MANAGER_API.delete_biometrics and returns
	 * l_deleted_record_count.
	 * 
	 * @throws SQLException
	 */
	public Long executeDeletion(Map<Long, List<SegSyncInfos>> syncMap)
			throws SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_external_id", getExternalId());
		map.put("p_event_id", getEventId());
		if (containerIds == null) {
			map.put("p_container_ids", null);
		} else {
			map.put("p_container_ids", null); 
		}
		Map<String, Object> resultMap = execute(map);
		Long count = (Long) resultMap.get("l_deleted_record_count");

		Array array1 = (Array) resultMap.get("p_seg_ids");
		Array array2 = (Array) resultMap.get("p_seg_versions");
		Array array3 = (Array) resultMap.get("p_template_ids");

		BigDecimal[] segIds = (BigDecimal[]) array1.getArray();
		BigDecimal[] segVersions = (BigDecimal[]) array2.getArray();
		BigDecimal[] templateIds = (BigDecimal[]) array3.getArray();

		for (int index = 0; index < segIds.length; index++) {
			long segId = segIds[index].longValue();
			long segVersion = segVersions[index].longValue();
			long templateId = templateIds[index].longValue();

			if (!syncMap.containsKey(segId)) {
				syncMap.put(segId, new ArrayList<SegSyncInfos>());
			}
			syncMap.get(segId)
					.add(new SegSyncInfos(segId, segVersion, templateId,
							SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE));
		}
		return count;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public List<Integer> getContainerIds() {
		return containerIds;
	}

	public void setContainerIds(List<Integer> containerIds) {
		this.containerIds = containerIds;
	}

}
