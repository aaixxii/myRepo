package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.SegmentDefragDao;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class BinDefragBean {
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	private SegmentDefragDao segDefragDao;

	public BinDefragBean() {
	}

	@PostConstruct
	public void init() {
		segDefragDao = new SegmentDefragDao(dataSource);
	}

	/**
	 * 
	 * @param binId
	 *            BIN_ID to start defrag.
	 */
	public int startBinDefrag(int binId) {
		int maitainBinId = segDefragDao.getDefragContainerId();
		if (maitainBinId == -1) {
			segDefragDao.setDefragContainerId(binId);
			return binId;
		} else {
			return -2;
		}
	}

	/**
	 * 
	 * @param binId
	 *            BIN_ID to stop defrag.
	 */
	public int stopBinDefrag(int binId) {
		int maitainBinId = segDefragDao.getDefragContainerId();
		if (maitainBinId == binId) {
			segDefragDao.setDefragContainerId(-1);
			return -1;
		} else {
			return maitainBinId;
		}
	}
}
