package jp.co.nec.aim.mm.sessionbeans.pojo;

import java.io.IOException;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMMessages.PBExtractJobResultInternal;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.extract.dispatch.ExtractJobResultCallBacker;
import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
import jp.co.nec.aim.mm.procedure.FailExtractJobProcedure;
import jp.co.nec.aim.mm.procedure.FinishExtractJobProcedure;
import jp.co.nec.aim.mm.procedure.RetryExtractJobProcedure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

/**
 * @author mozj
 */

public class ExtractJobHandler {
	private static Logger log = LoggerFactory
			.getLogger(ExtractJobHandler.class);

	private SystemConfigDao sysConfigDao;
	private DataSource dataSource;
	private FeJobDoneLogger feJobDoneLogger;
	private ExtractJobResultCallBacker callBacker;

	/**
	 * Constructor is called by Java EE Container.
	 */
	public ExtractJobHandler(EntityManager entityManager,
			DataSource dataSource, ExtractJobResultCallBacker callBacker) {
		this.dataSource = dataSource;
		this.sysConfigDao = new SystemConfigDao(entityManager);
		this.feJobDoneLogger = new FeJobDoneLogger(dataSource);
		this.callBacker = callBacker;
	}

	/**
	 * 
	 * @param eje
	 * @param muId
	 * @param reason
	 * @param timeout
	 * @param maxCount
	 */
	public int failExtractJob(FeJobQueueEntity eje, long muId,
			PBServiceStateReason reason, boolean timeout, Integer maxCount) {
        log.warn("Extract job " + ((timeout) ? "or MU timedout" : "failure")
                + ": (muId " + eje.getMuId() + ") Extract Job ID " 
                + eje.getId() + " failed for reason: '" + reason.getCode()
                + " : " + reason.getDescription() + "'");		

		Integer numFailures = (eje.getFailureCount() == null ? 0 : eje
				.getFailureCount().intValue());

		log.debug("Job " + eje.getId() + " has failed " + numFailures
				+ " times already.");

		if (numFailures >= maxCount - 1) {
			log.warn("Extract job id " + eje.getId()
					+ " failed too many times:" + (numFailures + 1)
					+ ", completing.");

			int numCompleted = 0;
			PBExtractJobResult result = createPBExtractJobResult(eje.getId(),
					reason);

			try {
				FailExtractJobProcedure failProcedure = new FailExtractJobProcedure(
						dataSource);

				numCompleted = failProcedure.execute(eje.getId(), muId, reason,
						result.toByteArray());
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Failing Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}

			if (0 < numCompleted) {
				feJobDoneLogger.info(eje.getId());
				boolean callbacksEnabled = sysConfigDao
						.getMMPropertyBool(MMConfigProperty.HTTP_CALLBACKS_ENABLED);
				if (callbacksEnabled) {
					callBacker.asynchCallback(eje.getId(), result);
				}
			} else {
				log.warn("complete_extract_job called against nonexistent or already-complete extract job Id "
						+ eje.getId());
			}
			return numCompleted;
		} else {
			try {
				log.warn("Extract job id " + eje.getId() + " failed, retry.");
				RetryExtractJobProcedure retryProcedure = new RetryExtractJobProcedure(
						dataSource);
				return retryProcedure.execute(eje.getId(), muId, reason);
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Retry Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		}
	}

	/**
	 * 
	 * @param reason
	 * @return
	 */
	private PBExtractJobResult createPBExtractJobResult(long jobId,
			PBServiceStateReason reason) {
		PBExtractJobResult.Builder result = PBExtractJobResult.newBuilder();
		result.setJobId(jobId);
		PBServiceState.Builder serviceState = PBServiceState.newBuilder();
		serviceState.setReason(reason);
		serviceState.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
		result.setServiceState(serviceState);

		return result.build();
	}

	/**
	 * 
	 * @param jobId
	 * @param muId
	 * @param result
	 * @param failed
	 * @return
	 * @throws SQLException
	 * @throws IOException
	 */
	public int completeExtractJob(long jobId, long muId,
			PBExtractJobResultInternal result, boolean failed)
			throws SQLException, IOException {
		// byte[] compressExResult = Deflater.compress(result.toByteArray());

		if (failed) {
			try {
				FailExtractJobProcedure failProcedure = new FailExtractJobProcedure(
						dataSource);

				int numCompleted = failProcedure.execute(jobId, muId, result
						.getServiceState().getReason(), result.toByteArray());

				return numCompleted;
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Failing Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		} else {
			try {
				FinishExtractJobProcedure finishProcedure = new FinishExtractJobProcedure(
						dataSource);

				int numCompleted = finishProcedure.execute(muId, jobId,
						result.toByteArray(), result.getKeyedTemplateList());

				return numCompleted;
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Finish Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		}
	}
}
