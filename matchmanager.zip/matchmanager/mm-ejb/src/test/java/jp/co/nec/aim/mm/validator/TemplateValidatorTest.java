package jp.co.nec.aim.mm.validator;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.mm.common.HttpTestServer;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class TemplateValidatorTest {

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource
	private TemplateValidator validator;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private DataSource dataSource;

	private static final PBSyncJobRequest request = PBSyncJobRequest
			.newBuilder().setFunction(SyncFunctionType.INSERT)
			.setExternalId("ex_id").build();

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from system_config");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from system_config");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testValidatorDisabled() {
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG(CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ "values(SYSTEM_CONFIG_SEQ.nextval,'TEMPLATE_VALIDATION.ENABLED','FALSE')");
		validator.validate(request);
	}

	@Test
	public void testValidatorException() {
		try {
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	public void testValidator_200_successfully() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(1));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testValidator_200_rollback() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(2));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testValidator_200_error_reasonisnotgiven() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(3));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testValidator_200_error_reasonisgiven() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(4));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testValidator_400() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(5));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testValidator_404() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(6));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testValidator_503() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(7));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testValidator_503_to_200_successfully() throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(8));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	public void testValidator_200_rollback_to_200_successfully()
			throws Exception {
		HttpTestServer server = null;
		try {
			server = new HttpTestServer(12345);
			server.start(getMockHandler(9));
			validator.validate(request);
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (server != null) {
				server.stop();
			}
		}
	}

	public Handler getMockHandler(final int caseNumber) {
		final AtomicInteger index = new AtomicInteger();
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();

				if (caseNumber == 1) {
					PBServiceState state = PBServiceState.newBuilder()
							.setState(ServiceStateType.SERVICE_STATE_SUCCESS)
							.build();
					response.setStatus(200);
					state.writeTo(response.getOutputStream());
				} else if (caseNumber == 2) {
					PBServiceState state = PBServiceState.newBuilder()
							.setState(ServiceStateType.SERVICE_STATE_ROLLBACK)
							.build();
					response.setStatus(200);
					state.writeTo(response.getOutputStream());
				} else if (caseNumber == 3) {
					PBServiceState state = PBServiceState.newBuilder()
							.setState(ServiceStateType.SERVICE_STATE_ERROR)
							.build();
					response.setStatus(200);
					state.writeTo(response.getOutputStream());
				} else if (caseNumber == 4) {
					PBServiceState state = PBServiceState
							.newBuilder()
							.setState(ServiceStateType.SERVICE_STATE_ERROR)
							.setReason(
									PBServiceStateReason.newBuilder()
											.setCode("12345")
											.setDescription("Internal Error")
											.setTime("05-05-2015 21:12:12"))
							.build();
					response.setStatus(200);
					state.writeTo(response.getOutputStream());
				} else if (caseNumber == 5) {
					response.setStatus(400);
				} else if (caseNumber == 6) {
					response.setStatus(404);
				} else if (caseNumber == 7) {
					response.setStatus(503);
				} else if (caseNumber == 8) {
					int i = index.incrementAndGet();
					if (i < 4)
						response.setStatus(503);
					else {
						PBServiceState state = PBServiceState
								.newBuilder()
								.setState(
										ServiceStateType.SERVICE_STATE_SUCCESS)
								.build();
						response.setStatus(200);
						state.writeTo(response.getOutputStream());
					}
				} else if (caseNumber == 9) {
					int i = index.incrementAndGet();
					if (i < 4) {
						PBServiceState state = PBServiceState
								.newBuilder()
								.setState(
										ServiceStateType.SERVICE_STATE_ROLLBACK)
								.build();
						response.setStatus(200);
						state.writeTo(response.getOutputStream());
					} else {
						PBServiceState state = PBServiceState
								.newBuilder()
								.setState(
										ServiceStateType.SERVICE_STATE_SUCCESS)
								.build();
						response.setStatus(200);
						state.writeTo(response.getOutputStream());
					}
				}

				response.setContentType("application/octet-stream");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}
}
