package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MAP_REDUCERS database table.
 * 
 */
@Entity
@Table(name = "MAP_REDUCERS")
public class MapReducerEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MR_ID")
	private long mrId;

	@Column(name = "CONTACT_URL")
	private String contactUrl;

	@Column(name = "RING_LOCATION")
	private Long ringLocation;

	@Column(name = "\"STATE\"")
	@Enumerated(EnumType.STRING)
	private UnitState state;

	@Column(name = "UNIQUE_ID")
	private String uniqueId;

	@Column(name = "\"VERSION\"")
	private String version;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "MR_ID")
	private MrContactEntity times;

	public MapReducerEntity() {
	}

	public MapReducerEntity(long mrId, String contactUrl) {
		this.mrId = mrId;
		this.contactUrl = contactUrl;
	}

	public long getMrId() {
		return this.mrId;
	}

	public void setMrId(long mrId) {
		this.mrId = mrId;
	}

	public String getContactUrl() {
		return this.contactUrl;
	}

	public void setContactUrl(String contactUrl) {
		this.contactUrl = contactUrl;
	}

	public Long getRingLocation() {
		return this.ringLocation;
	}

	public void setRingLocation(Long ringLocation) {
		this.ringLocation = ringLocation;
	}

	public UnitState getState() {
		return this.state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public String getUniqueId() {
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public MrContactEntity getTimes() {
		return times;
	}

	public void setTimes(MrContactEntity times) {
		this.times = times;
	}

}