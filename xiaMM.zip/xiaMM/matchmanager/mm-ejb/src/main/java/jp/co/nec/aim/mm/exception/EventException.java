package jp.co.nec.aim.mm.exception;

public class EventException extends AimErrorInfoException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2874681181709291204L;

	public EventException(String errorCode, String description,String time, String uidCode) {
		super(errorCode,description, time, uidCode);

	}

	public EventException(Throwable ex) {
		super(ex);
	}

	public EventException(String detail, Throwable ex) {
		super(detail, ex);
	}

}
