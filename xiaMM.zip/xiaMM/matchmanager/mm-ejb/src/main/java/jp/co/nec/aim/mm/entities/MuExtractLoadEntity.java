package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the MU_EXTRACT_LOAD database table.
 * 
 */
@Entity
@Table(name = "MU_EXTRACT_LOAD")
@NamedQuery(name = "MuExtractLoadEntity.findAll", query = "SELECT m FROM MuExtractLoadEntity m")
public class MuExtractLoadEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MU_ID")
	private long muId;

	private Long pressure;

	@Column(name = "UPDATE_TS")
	private Long updateTs;

	public MuExtractLoadEntity() {
	}

	public long getMuId() {
		return muId;
	}

	public void setMuId(long muId) {
		this.muId = muId;
	}

	public Long getPressure() {
		return this.pressure;
	}

	public void setPressure(Long pressure) {
		this.pressure = pressure;
	}

	public Long getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Long updateTs) {
		this.updateTs = updateTs;
	}

}