package jp.co.nec.aim.mm.aggregator;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponseAttribute;
import jp.co.nec.aim.mm.common.AimManager;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.sessionbeans.InquiryJobCompleteBean;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AggregatorTest {
	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private InquiryJobCompleteBean inquiryBean;
	

	private InquiryJobDao inquiryJobDao;
	private DateDao dateDao;

	private SystemConfigDao systemConfigDao;	
	
	MockUp<AimManager> mockUp1;

	@Before
	public void setUp() throws Exception {		
		inquiryJobDao = new InquiryJobDao(entityManager);		
		systemConfigDao = new SystemConfigDao(entityManager);		
		systemConfigDao.writeAllMissingProperties(ds);
		dateDao = new DateDao(ds);
		clearDB();
		setMockMethod();
	}
	
	public void clearDB() {		
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FUSION_JOBS");
		jdbcTemplate.execute("delete from CONTAINER_JOBS");		
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		jdbcTemplate.execute("delete from BATCH_JOB_INFO");
		jdbcTemplate.execute("commit");
	}
	
	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};		
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
		mockUp1.tearDown();
	}

	@Test
	@Ignore
	public void aggregation_nomal() {
	
		long topJobId = 1000;
		long fusionJobId = 10001;
		long  containerJobId =10001; 
		long planId = 3000;
		long mrId = 5000;
		long[] muIds = {111,222,333};
		long curTime = dateDao.getCurrentTimeMS();
		PBMapInquiryJobResult mrResult = buildMrResult(mrId, muIds, topJobId, planId, false);		
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,1,3000,0,0,1,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,0)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,plan_id,fusion_job_id,mr_id,RESULT_TS,job_state) "
				+ " values(?,1,?,?,?,?,1)";
		jdbcTemplate.update(jobQueueSql, new Object[] {topJobId});		
		jdbcTemplate.update(fusionJobSql, new Object[] {fusionJobId, topJobId});	
		
		jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
				+ " RING_LOCATION, STATE) values(" + mrId + ", '" + mrId
				+ "', " + mrId + ", 'WORKING')");
		jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
				+ " values(" + mrId+ ", " + curTime + ")");
	
	jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
			+ " ASSIGNED_TS) values(1, " + (curTime - 100000) + ")");
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId, planId, fusionJobId, mrId, dateDao.getCurrentTimeMS()});	
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId+1, planId, fusionJobId, mrId,  dateDao.getCurrentTimeMS()});
		
		BatchJobInfoEntity batch = new BatchJobInfoEntity();
		batch.setBatchJobId(11111);
		batch.setBatchType(BatchType.IDENTIFY.name());
		batch.setInternalJobId(topJobId);
		batch.setReqeustId("99999");
		entityManager.persist(batch);
		inquiryBean.completeJob(mrResult);
		List<Map<String, Object>> jobMap = jdbcTemplate.queryForList("select * from job_queue where job_id=?", new Object[] {1000});
		assertNotNull(jobMap);
	}	
	
	
	private  PBMapInquiryJobResult buildMrResult(long mrId, long[] muIds, long topLevelJobId,long planId, boolean setingFailed) {	
		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult.newBuilder();				
		builder.setMrId(mrId);
		builder.setPlanId(planId);	
		for (int i = 0; i < muIds.length; i++) {
			PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
			jobInfo.setTopLevelJobId(topLevelJobId);
			jobInfo.setRequestIndex(1);
			jobInfo.setContainerId(1);
			jobInfo.setMessageSequence(0);
			jobInfo.setJobTimeout(5000);
			jobInfo.setInternalMaxCandidates(10);
			jobInfo.setMuJobPopTime(7);		
			PBBusinessMessage result =  createPBBusinessMessage(setingFailed);
			builder.setResult(result);	
		}			
		return builder.build();
	}	
	
	private PBBusinessMessage createPBBusinessMessage(boolean setingFailed) {
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
		PBResponse.Builder ps = PBResponse.newBuilder();		
		if (!setingFailed) {			
			ps.setStatus("0:success");			
		} else {
			ps.setStatus("109faild");
			ps.setErrorMessage("testFaild");
			PBResponseAttribute.Builder attr = PBResponseAttribute.newBuilder();
			attr.setAttributeName("createdTimestamp");
			attr.setAttributeValue(String.valueOf(dateDao.getCurrentTimeMS()));
			ps.addResponseAttributes(attr.build());			
		}
		pbMsg.setResponse(ps);		
	
		PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 10; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("xia" + i);
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		
		Collections.shuffle(pbList); 		
		
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(false);
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}		
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		return pbMsg.build();
	}

	
	

}
