package jp.co.nec.aim.mm.util;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import jp.co.nec.aim.mm.exception.AimRuntimeException;

/**
 * @author mozj
 */
public class JAXBHelper {
	private JAXBContext jaxbContext;
	// private static final String AIM_NAMESPACE_URI = "urn:nec:aim";
	private static final String JAXB_CONTEXT = "jp.co.nec.aim.mm.jaxb";
	private static final JAXBContext aimContext = initContext(JAXB_CONTEXT);

	private static JAXBContext initContext(String context) {
		try {
			return JAXBContext.newInstance(context);
		} catch (JAXBException e) {
			throw new AimRuntimeException(e);
		}
	}

	public JAXBHelper() {
		this(aimContext);
	}

	public JAXBHelper(JAXBContext context) {
		this.jaxbContext = context;
	}

	// @SuppressWarnings({ "rawtypes", "unchecked" })
	// public static JAXBElement createElement(String name, Object o) {
	// return new JAXBElement(new QName(AIM_NAMESPACE_URI, name),
	// o.getClass(), o);
	// }
	//
	// public String marshal(Object jaxbObject, String elementName) {
	// try {
	// StringWriter sw = new StringWriter();
	// Marshaller m = jaxbContext.createMarshaller();
	// m.marshal(createElement(elementName, jaxbObject), sw);
	// return sw.toString();
	// } catch (JAXBException e) {
	// throw new AimRuntimeException(e);
	// }
	// }

	public String marshal(Object jaxbObject) {
		try {
			StringWriter sw = new StringWriter();
			Marshaller m = jaxbContext.createMarshaller();
			m.marshal(jaxbObject, sw);
			return sw.toString();
		} catch (JAXBException e) {
			throw new AimRuntimeException(e);
		}
	}
}
