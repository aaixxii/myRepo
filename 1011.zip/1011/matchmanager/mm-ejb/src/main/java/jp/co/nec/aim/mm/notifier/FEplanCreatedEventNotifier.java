package jp.co.nec.aim.mm.notifier;

import java.util.Date;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.util.JndiLookup;
import jp.co.nec.aim.mm.util.SafeCloseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * notify extract plan dispatcher that plans have been created
 * 
 * @author xiazp
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class FEplanCreatedEventNotifier {
	private static Logger logger = LoggerFactory
			.getLogger(FEplanCreatedEventNotifier.class);

	// @Resource(mappedName = "java:/JmsXA")
	// private ConnectionFactory cf;
	private ConnectionFactory jmsConnectionFactory;
	private static final String FE_PLANNER_DISPATCH_QUQUE = "java:/jms/queue/FeDispatchQueue";

	public FEplanCreatedEventNotifier() {
	}

	/**
	 * @param lotJobId
	 * 
	 */
	public boolean notify(long lotJobId) {
		logger.info("Send lotJobId:{} to queue:feDispatchQueue", lotJobId);
		if (this.jmsConnectionFactory == null) {
			jmsConnectionFactory = JndiLookup.lookUp(JNDIConstants.JmsFactory,
					ConnectionFactory.class);
		}
		Queue queue = JndiLookup.lookUp(FE_PLANNER_DISPATCH_QUQUE, Queue.class);
		Session session = null;
		MessageProducer producer = null;
		Connection connection = null;
		try {
			connection = jmsConnectionFactory.createConnection(
					JNDIConstants.Principal, JNDIConstants.Credentials);
			session = connection.createSession(false,
					Session.DUPS_OK_ACKNOWLEDGE);
			producer = session.createProducer(queue);
			TextMessage txtMessage = session.createTextMessage(String
					.valueOf(lotJobId));
			txtMessage.setJMSDeliveryTime(new Date().getTime());
			producer.send(txtMessage);
			if (logger.isDebugEnabled()) {
				logger.debug("Send message to Queue:"
						+ FE_PLANNER_DISPATCH_QUQUE + ", Message:"
						+ String.valueOf(lotJobId));
			}
			return true;

		} catch (JMSException e) {
			String errorMessage = "JMSException while queueing:"
					+ FE_PLANNER_DISPATCH_QUQUE;
			logger.error(errorMessage);
			return false;
		} finally {
			SafeCloseUtil.close(producer);
			SafeCloseUtil.close(session);
			SafeCloseUtil.close(connection);
		}
	}
}
