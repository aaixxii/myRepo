package jp.co.nec.aim.mm.identify.planner;

public class CombinedJobInfo {
	private Integer functionId;
	private Integer containerId;
	private Long contaierJobId;

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public Long getContaierJobId() {
		return contaierJobId;
	}

	public void setContaierJobId(Long contaierJobId) {
		this.contaierJobId = contaierJobId;
	}

	public CombinedJobInfo(Integer containerId, Integer functionId,
			Long containerJobId) {
		this.containerId = containerId;
		this.functionId = functionId;
		this.contaierJobId = containerJobId;
	}
}
