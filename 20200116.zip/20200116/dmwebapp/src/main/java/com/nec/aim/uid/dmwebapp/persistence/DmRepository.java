package com.nec.aim.uid.dmwebapp.persistence;

import org.springframework.data.cassandra.repository.CassandraRepository;

public interface DmRepository extends CassandraRepository<Dm, Short> {
	
//	 @Query("SELECT*FROM dm WHERE id=?0 AND id<?1 LIMIT ?2")
//	    Iterable<Dm> findByUserFrom(Short id, Short from, Integer limit);
}
