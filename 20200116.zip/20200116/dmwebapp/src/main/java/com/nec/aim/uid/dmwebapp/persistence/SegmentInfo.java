package com.nec.aim.uid.dmwebapp.persistence;

import java.io.Serializable;
import java.sql.Timestamp;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Table(value = "segment_info")
public class SegmentInfo implements Serializable {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = -3686490055450742690L;

	@PrimaryKeyColumn(name="seg_id",  type = PrimaryKeyType.PARTITIONED, ordering = Ordering.DESCENDING)    
    long segId;
    
    @Column(value = "last_ver")
    long lastVer;
    
    @Column(value = "last_offset")
    long lastOffset;
    
    @Column(value = "last_modified")
    Timestamp lastModified;
    
    @Column(value = "corrupted_flag")
    boolean corruptedFlag;
    
    @Column(value = "status")
    String status;   
    
    public SegmentInfo(Long id) {
    	this.setSegId(id);
    }
    
    @Override
    public boolean equals(Object obj) {
        return false;
    }
    @Override
    public int hashCode() {
        return 0;        
    }    
}
