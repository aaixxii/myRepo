package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Maps;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class DeleteBiometricsProcedureTest {
	@Resource
	private DataSource dataSource;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private DeleteBiometricsProcedure deleteBiometricsProcedure;

	@Before
	public void setUp() throws Exception {
		deleteBiometricsProcedure = new DeleteBiometricsProcedure(dataSource);
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testExecuteArgsNotNull() throws SQLException {
		jdbcTemplate
				.update("insert into person_biometrics(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),65,123,0,1,1)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		jdbcTemplate.execute("commit");
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		deleteBiometricsProcedure.setEventId(1);
		deleteBiometricsProcedure.setExternalId("1");
		deleteBiometricsProcedure.setContainerIds(containerIds);

		Map<Long, List<SegSyncInfos>> syncMap = Maps.newHashMap();
		deleteBiometricsProcedure.executeDeletion(syncMap);
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from person_biometrics");
		Assert.assertEquals(0, listPer.size());
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
	}

	@Test
	public void testExecuteContainerIdsIsNull() throws SQLException {
		jdbcTemplate
				.update("insert into person_biometrics(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),65,123,0,1,1)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		jdbcTemplate.execute("commit");
		deleteBiometricsProcedure.setEventId(1);
		deleteBiometricsProcedure.setExternalId("1");

		Map<Long, List<SegSyncInfos>> syncMap = Maps.newHashMap();
		deleteBiometricsProcedure.executeDeletion(syncMap);
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from person_biometrics");
		Assert.assertEquals(0, listPer.size());
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
	}

	@Test
	public void testExecuteEventIdIsNull() throws SQLException {
		jdbcTemplate
				.update("insert into person_biometrics(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),65,123,0,1,1)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		jdbcTemplate.execute("commit");
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		deleteBiometricsProcedure.setExternalId("1");
		deleteBiometricsProcedure.setContainerIds(containerIds);

		Map<Long, List<SegSyncInfos>> syncMap = Maps.newHashMap();
		deleteBiometricsProcedure.executeDeletion(syncMap);

		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from person_biometrics");
		Assert.assertEquals(0, listPer.size());
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
	}

	@Test
	public void testExecuteEventIdIsContainerIdsBothNull() throws SQLException {
		jdbcTemplate
				.update("insert into person_biometrics(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),65,123,0,1,1)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		jdbcTemplate.execute("commit");
		deleteBiometricsProcedure.setExternalId("1");
		Map<Long, List<SegSyncInfos>> syncMap = Maps.newHashMap();
		deleteBiometricsProcedure.executeDeletion(syncMap);
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from person_biometrics");
		Assert.assertEquals(0, listPer.size());
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from segment_change_log");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from segments");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
	}

}
