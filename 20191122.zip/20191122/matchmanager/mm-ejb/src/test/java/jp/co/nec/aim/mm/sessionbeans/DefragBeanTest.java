package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.DefragDao;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class DefragBeanTest {

	@Resource
	private DataSource dataSource;
	@Resource
	private DefragBean defragBean;

	private String message;

	@Before
	public void setUp() throws Exception {
		message = "";
		new MockUp<DefragDao>() {
			@Mock
			public void defrag(DataSource dataSource) {
				message = "defrag";
				return;
			}
		};
	}

	@After
	public void tearDown() throws Exception {		
	}

	@Test
	public void testDefrag() {

		defragBean.defrag();

		assertEquals("defrag", message);
	}

}
