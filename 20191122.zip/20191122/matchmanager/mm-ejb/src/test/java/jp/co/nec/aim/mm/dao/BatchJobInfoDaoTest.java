package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class BatchJobInfoDaoTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	private BatchJobInfoDao btDao;

	@Before
	public void setUp() throws Exception {
		this.btDao = new BatchJobInfoDao(entityManager);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetBatchJobInfo() {
		BatchJobInfoEntity entity = new BatchJobInfoEntity();
		entity.setBatchJobId(1000);
		entity.setBatchType(BatchType.ENROLL.name());
		entity.setReqeustId("1000");
		entity.setInternalJobId(2000);
		entityManager.persist(entity);
		List<BatchJobInfoEntity> result = btDao.getBatchJobInfo(2000);
		Assert.assertEquals(1, result.size());	
	}
	
	@Test
	public void testGetBatchJobInfo2() {
		BatchJobInfoEntity entity = new BatchJobInfoEntity();
		entity.setBatchJobId(1000);
		entity.setBatchType(BatchType.ENROLL.name());
		entity.setReqeustId("1000");
		entity.setInternalJobId(2001);
		entityManager.persist(entity);
		BatchJobInfoEntity entity2 = new BatchJobInfoEntity();
		entity2.setBatchJobId(1001);
		entity2.setBatchType(BatchType.IDENTIFY.name());
		entity2.setReqeustId("1000");
		entity2.setInternalJobId(2000);
		entityManager.persist(entity);
		List<BatchJobInfoEntity> result = btDao.getBatchJobInfo(2001);
		Assert.assertEquals(1, result.size());	
	}
	
	@Test
	public void testGetBatchJobInfo_no_data() {
		BatchJobInfoEntity entity = new BatchJobInfoEntity();
		entity.setBatchJobId(1000);
		entity.setBatchType(BatchType.ENROLL.name());
		entity.setReqeustId("1000");
		entity.setInternalJobId(2000);
		entityManager.persist(entity);
		List<BatchJobInfoEntity> result = btDao.getBatchJobInfo(2001);
		Assert.assertEquals(0, result.size());	
	}
	
	@Test
	public void testGetJobIdByRefId() {
		BatchJobInfoEntity entity = new BatchJobInfoEntity();
		entity.setBatchJobId(1000);
		entity.setBatchType(BatchType.IDENTIFY.name());
		entity.setEnrollmentId("enrollment100");
		entity.setReqeustId("1000");
		entity.setInternalJobId(2000);
		entityManager.persist(entity);
		List<BatchJobInfoEntity> result = btDao.getBatchJobInfo("enrollment100", BatchType.IDENTIFY.name());
		Assert.assertEquals(1, result.size());
	}

}
