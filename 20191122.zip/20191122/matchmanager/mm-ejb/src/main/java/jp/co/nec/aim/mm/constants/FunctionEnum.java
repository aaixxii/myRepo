package jp.co.nec.aim.mm.constants;

public enum FunctionEnum {
	FINGER, PALM, FACE;
}
