package com.nec.lmx.agent.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.event.EventAdapter;
import com.nec.lmx.agent.event.EventNotifier;

public class LmxSocket extends EventAdapter {	
	private SocketChannel socketChannel;
	private Object channelLocker;	
	
	
	private static Logger logger = LoggerFactory.getLogger(LmxSocket.class);
	
	private static final LmxSocket lmxSocket = new LmxSocket();
	
	public static LmxSocket getInstance() {
		return lmxSocket;
	}
	
	public LmxSocket() {
		this.channelLocker = new Object();
	}
	
	public void init(int port) {			
		try {
			InetSocketAddress hostAddress = new InetSocketAddress("localhost", port);
			socketChannel = SocketChannel.open(hostAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setKeepAlive(true);
			logger.info("Connecting to Server on port {}", port);
			EventNotifier.getInstance().addListener(this);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}
	
	@Override
	public void onMessage(String msg) {	
		sendLinceseInfo(msg);
	}	
	
	private void sendLinceseInfo(String licenseInfo) {		
		try {	
			byte[] bodys = licenseInfo.getBytes();
			int sizeOfBody = bodys.length;
			ByteBuffer sendBuff = ByteBuffer.allocate(sizeOfBody);					
			sendBuff.order(ByteOrder.BIG_ENDIAN);			
			sendBuff.put(bodys);			
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					socketChannel.write(sendBuff);
				}
			}
			sendBuff.clear();
			sendBuff = null;			
		} catch (IOException e) {
			logger.error(e.getMessage(), e);			
		}		
	}
}
