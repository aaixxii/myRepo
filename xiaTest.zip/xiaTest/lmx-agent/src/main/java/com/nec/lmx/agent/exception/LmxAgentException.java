package com.nec.lmx.agent.exception;

public class LmxAgentException extends RuntimeException {
	
	private static final long serialVersionUID = 3194924856583553665L;
	public LmxAgentException() {
	}

	public LmxAgentException(String detail) {
		super(detail);
	}

	public LmxAgentException(Throwable ex) {
		super(ex);
	}

	public LmxAgentException(String detail, Throwable ex) {
		super(detail, ex);
	}
}
