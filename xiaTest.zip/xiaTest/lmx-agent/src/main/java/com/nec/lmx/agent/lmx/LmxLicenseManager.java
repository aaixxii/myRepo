package com.nec.lmx.agent.lmx;

public class LmxLicenseManager {

}
