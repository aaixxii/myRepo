package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class MuLoadDaoTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private MuLoadDao dao;

	@Before
	public void setUp() throws Exception {
		clearDB();

		dao = new MuLoadDao(dataSource);
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from system_config");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void test_purgeByResultTs() {

		jdbcTemplate.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)"
				+ " values(1,'jkjk','WORKING')");

		jdbcTemplate.update("insert into MU_EXTRACT_LOAD values(1,2,1212010)");
		jdbcTemplate.update("commit");

		dao.decreaseExtractLoad(null);
		int count = jdbcTemplate.queryForObject(
				"select PRESSURE from MU_EXTRACT_LOAD", Integer.class);
		assertEquals(2, count);

		dao.decreaseExtractLoad(1l);
		count = jdbcTemplate.queryForObject(
				"select PRESSURE from MU_EXTRACT_LOAD", Integer.class);
		assertEquals(1, count);

		dao.decreaseExtractLoad(1l);
		count = jdbcTemplate.queryForObject(
				"select PRESSURE from MU_EXTRACT_LOAD", Integer.class);
		assertEquals(0, count);

		dao.decreaseExtractLoad(1l);
		count = jdbcTemplate.queryForObject(
				"select PRESSURE from MU_EXTRACT_LOAD", Integer.class);
		assertEquals(0, count);
	}
}
