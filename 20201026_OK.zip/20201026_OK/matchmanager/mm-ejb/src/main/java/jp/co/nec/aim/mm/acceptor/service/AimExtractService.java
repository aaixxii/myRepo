package jp.co.nec.aim.mm.acceptor.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.sql.DataSource;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.callbakSender.AmqExecutorManager;
import jp.co.nec.aim.mm.callbakSender.AmqSocketSender;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.constants.UidReasonCode;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.UiDaiValidatorException;
import jp.co.nec.aim.mm.exception.XmlException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;
import jp.co.nec.aim.mm.util.ObjectUtil;
import jp.co.nec.aim.mm.util.XmlUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

/**
 * AimExtractService <br>
 * The main work flow of Extract <br>
 *
 * Include following public method:
 * <p>
 * extract, getJobStatus, listJobIds, deleteJob clearJobs, getJobBinary,
 * getJobResult
 * <p>
 *
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimExtractService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimExtractService.class);
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private FunctionDao functionDao;
	private SystemConfigDao configDao;
	private FEJobDao feJobDao;
	// private DateDao dateDao;

	/**
	 * AimExtractService constructor
	 */
	public AimExtractService() {
	}

	@PostConstruct
	private void init() {
		functionDao = new FunctionDao(manager);
		configDao = new SystemConfigDao(manager);
		feJobDao = new FEJobDao(manager, dataSource);
		// dateDao = new DateDao(dataSource);
	}

	/**
	 * the main work flow of extract
	 *
	 * @param request PBExtractJobRequest instance
	 * @return PBExtractJobResponse instance
	 * @throws IOException
	 * @throws JAXBException
	 * @throws UnsupportedEncodingException
	 */

	public Long extract(String extractRequest, boolean isFromServlet) throws IOException {
		if (StringUtils.isBlank(extractRequest)) {
			throw new XmlException("extract request is empty");
		}
		if (log.isDebugEnabled()) {
			log.debug(extractRequest);
		}
		String requestId = XmlUtil.getRequestId(extractRequest);
		String cmd = XmlUtil.getXmlCmd(extractRequest);
		String refId = XmlUtil.getRefId(extractRequest, UidRequestType.Quality.name());
		String refUrl = XmlUtil.getUrl(extractRequest, UidRequestType.Quality.name());
		boolean retfyFlag = XmlUtil.checkRetryFlag(extractRequest);
		try {
			AcceptorValidator.checkExtractRequest(extractRequest, requestId, cmd, refId, refUrl);
		} catch (UiDaiValidatorException e) {
			sendInternalErr(requestId);
			throw e;
		}
		if (!retfyFlag) {
			return doExtract(extractRequest, requestId, refId);
		} else {
			FeJobQueueEntity feJobQueueEntity = feJobDao.isWaitOrExec(requestId);
			if (feJobQueueEntity == null) {
				feJobQueueEntity = feJobDao.hasResult(requestId);
				if (feJobQueueEntity != null) {
					// When JOB_STATE = 2 (DONE), get the result from DB and return it.
					log.info("For jobs with requestId ='{}' and retryFlag = true,"
							+ " since the extraction job has already been completed, only the result will be returned.",
							requestId);
					Integer port = AmqExecutorManager.getInstance().getCallbackIpPort("1");
					UidAimAmqResponse uidAimAmqResponse = new UidAimAmqResponse();
					uidAimAmqResponse.setRequestType(UidRequestType.Quality.name());
					uidAimAmqResponse.setRequestId(requestId);
					uidAimAmqResponse.setXmlResult(feJobQueueEntity.getResult());
					byte[] uidResData = ObjectUtil.serializeAmqResults(uidAimAmqResponse);
					AmqSocketSender sendTask = new AmqSocketSender(port, uidResData);
					AmqExecutorManager.getInstance().commitTask(sendTask);
					return feJobQueueEntity.getLotJobId();
				} else {
					// Normal operation
					log.info("For job with requestId ='{}' and retryFlag = true,"
							+ " normal operation is performed because the corresponding job does not exist in Bison.",
							requestId);
					return doExtract(extractRequest, requestId, refId);
				}
			} else {
				// Even if retfyFlag = true,
				// if JOB_STATE is WAIT or EXEC, the request is discarded.
				log.warn("For jobs with requestId = '{}' and retryFlag = true,"
						+ " the preceding job is discarded because it is WAIT or EXEC.", requestId);
				return feJobQueueEntity.getLotJobId();
			}
		}
	}

	private Long doExtract(String extractRequest, String requestId, String refId) throws IOException {
		try {
			final FeJobQueueEntity ejq = new FeJobQueueEntity();
			FunctionTypeEntity fte = functionDao.getExtractFunction();
			if (fte == null) {
				sendInternalErr(requestId);
				AimError aimErr = AimError.EXTRACT_FUNCTION_TYPE_NOT_FOUND;
				String errMsg = String.format(aimErr.getMessage() + " . Function Type is null.");
				aimErr.setMessage(errMsg);
				throw new DataBaseException(aimErr.getErrorCode(), aimErr.getMessage(),
						String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
			}
			ejq.setFunctionId((int) fte.getId());
			ejq.setReferenceId(refId);
			ejq.setStatus(JobState.QUEUED);
			ejq.setRequestId(requestId);
			ejq.setRequestType(UidRequestType.Quality.name());
			ejq.setFailureCount(0L);
			Integer priority = configDao.getMMPropertyInt(MMConfigProperty.EXTRACT_DEFAULTS_PRIORITY);
			ejq.setPriority(priority);
			ejq.setSubmissionTs(System.currentTimeMillis());
			manager.flush();
			manager.persist(ejq);

			FeJobPayloadEntity epe = new FeJobPayloadEntity();
			epe.setPayload(extractRequest);
			epe.setJobId(ejq.getId());
			manager.persist(epe);
			// send event to extract planner
			JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
					String.format("create extract job id: %s", ejq.getId()));
			Long efJobId = Long.valueOf(ejq.getId());
			return efJobId;
		} catch (PersistenceException e) {
			// Response to exceptions that occur during fulsh to DB.
			sendInternalErr(requestId);
			throw e;
		}
	}

	private void sendInternalErr(String requestId) throws IOException {
		UidAimAmqResponse response = XmlUtil.buildFaildXmlReespose(requestId, UidReasonCode.INTERNL_ERR.getUidCode());
		response.setRequestType(UidRequestType.Quality.toString());
		response.setRequestId(requestId);
		Integer port = AmqExecutorManager.getInstance().getCallbackIpPort("1");
		byte[] uidResData = ObjectUtil.serializeAmqResults(response);
		AmqSocketSender sendTask = new AmqSocketSender(port, uidResData);
		AmqExecutorManager.getInstance().commitTask(sendTask);
	}

	/**
	 * delete extract Job with specified job id
	 *
	 * @param request PBDeleteJobRequest instance
	 */
	public void deleteJob(String deleRequest) {
		if (StringUtils.isBlank(deleRequest)) {
			throw new XmlException("Delete request is empty");
		}
		String refId = null;
		refId = XmlUtil.getRefId(deleRequest, UidRequestType.Quality.name());

		if (StringUtils.isBlank(refId)) {
			AimError referIdErr = AimError.MISS_REFERENCE_ID_ERROR;
			String errMsg = String.format(referIdErr.getMessage() + " . Can not found referenceId in DeleteJobRequest");
			referIdErr.setMessage(errMsg);
			throw new ArgumentException(referIdErr.getErrorCode(), referIdErr.getMessage(),
					String.valueOf(System.currentTimeMillis()), referIdErr.getUidCode());
		}
		try {
			int deleteCout = feJobDao.delExtJobByRefId(refId);
			if (deleteCout < 1) {
				log.warn("delete count={}", deleteCout);
			} else {
				log.info("success delete extractJob,deleteCount={}", deleteCout);
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
	}

	/**
	 * clear all extract Jobs
	 */
	public void clearJobs() {
		try {
			int clearCount = feJobDao.clearJobs();
			log.info("clear job count={}", clearCount);
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
	}

}
