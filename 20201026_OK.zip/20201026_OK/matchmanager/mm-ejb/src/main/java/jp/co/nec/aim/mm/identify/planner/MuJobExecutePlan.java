package jp.co.nec.aim.mm.identify.planner;

import java.io.Serializable;

public class MuJobExecutePlan implements Serializable {
	private static final long serialVersionUID = -1099033399583195824L;
	private Long planId;
	private Long jobId;
	private Integer functionId;
	private Integer containerId;
	private String plan;
	private Integer planedCount;
	private long planedTs;

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public Integer getPlanedCount() {
		return planedCount;
	}

	public void setPlanedCount(Integer planedCount) {
		this.planedCount = planedCount;
	}

	public long getPlanedTs() {
		return planedTs;
	}

	public void setPlanedTs(long planedTs) {
		this.planedTs = planedTs;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public String toString() {
		return "[PlanId: " + String.valueOf(planId) + "JobId: "
				+ String.valueOf(jobId) + "FunctionId: "
				+ String.valueOf(functionId) + "ContainerId: "
				+ String.valueOf(containerId) + "Plan: " + plan
				+ "PlanedCount: " + String.valueOf(planedCount) + "PlanedTs: "
				+ String.valueOf(planedTs) + "]";
	}

}
