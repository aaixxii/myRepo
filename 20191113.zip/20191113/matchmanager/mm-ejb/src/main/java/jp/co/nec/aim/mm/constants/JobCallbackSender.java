package jp.co.nec.aim.mm.constants;

/**
 * @author jinxl
 */
public class JobCallbackSender {

	public static String generateURL(String callbackURI, long jobId) {
		if (callbackURI == null)
			return null;
		String connectionURL = null;
		if (callbackURI.endsWith("/")) {
			connectionURL = callbackURI + jobId;
		} else {
			connectionURL = callbackURI + "/" + jobId;
		}
		return connectionURL;
	}

}
