package jp.co.nec.aim.mm.acceptor.service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;

/**
 * AimExtractService <br>
 * The main work flow of Extract <br>
 * 
 * Include following public method:
 * <p>
 * extract, getJobStatus, listJobIds, deleteJob clearJobs, getJobBinary,
 * getJobResult
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimExtractService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimExtractService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private FunctionDao functionDao;
	private SystemConfigDao configDao;
	private FEJobDao feJobDao;
	private DateDao dateDao;	
	private ExceptionHelper exception;

	/**
	 * AimExtractService constructor
	 */
	public AimExtractService() {
	}

	@PostConstruct
	private void init() {
		functionDao = new FunctionDao(manager);
		configDao = new SystemConfigDao(manager);
		feJobDao = new FEJobDao(manager);
		dateDao = new DateDao(dataSource);		
		exception = new ExceptionHelper(dateDao);
	}

	/**
	 * the main work flow of extract
	 * 
	 * @param request
	 *            PBExtractJobRequest instance
	 * @return PBExtractJobResponse instance
	 */
	public String extract(ExtractRequest request, boolean isFromServlet) {
		long batchJobId = request.getBatchJobId();
		String batchType = request.getType().name();
		log.info("recevice extractjob.batchJobId:{},batchType:{}", batchJobId, batchType);
		if (!batchType.toUpperCase().equals(BatchType.EXTRACT.name())) {
			exception.throwArgException(AimError.EXTRACT_BATCH_TYPE_MISS_MATCH, null);
		}

		PBBusinessMessage pbm = null;
		try {
			pbm = PBBusinessMessage.parseFrom(request.getBusinessMessage(0));
		} catch (InvalidProtocolBufferException e) {
			exception.throwArgException(AimError.PROTOBUF_ERROR, e);
		}

		if (pbm.getRequest().hasEnrollmentId() && pbm.getRequest().getEnrollmentId().length() != 36) {
			exception.throwArgException(AimError.EXTRACT_REQUESET_ENROLLMENTID_SIZE_MISS, null);
		}

		if (StringUtils.isBlank(pbm.getRequest().getBiometricsData().getBiometricElement().getFilePath())) {
			exception.throwArgException(AimError.EXTRACT_REQUST_IMAGE_URL_NOT_SET, null);
		}

		if (StringUtils.isBlank(pbm.getRequest().getBiometricsData().getBiometricElement().getChecksum())) {
			exception.throwArgException(AimError.EXTRACT_REQUST_CHECK_SUM_NOT_SET, null);
		}

		final FeJobQueueEntity ejq = new FeJobQueueEntity();
		FunctionTypeEntity fte = functionDao.getExtractFunction();
		if (fte == null) {
			AimError dbErr = AimError.EXTRACT_DISPATCH_FE_JOB_NOT_FOUND;
			throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(), dateDao.getReasonTime(), dbErr.getUidCode());
		}
		try {
			ejq.setFunctionId((int) fte.getId());
			ejq.setReferenceId(pbm.getRequest().getEnrollmentId());
			ejq.setStatus(JobState.QUEUED);
			ejq.setFailureCount(0l);
			Integer priority = configDao.getMMPropertyInt(MMConfigProperty.EXTRACT_DEFAULTS_PRIORITY);
			ejq.setPriority(priority);
			ejq.setSubmissionTs(dateDao.getCurrentTimeMS());
			manager.persist(ejq);

			FeJobPayloadEntity epe = new FeJobPayloadEntity();
			epe.setPayload(pbm.toByteArray());
			epe.setJobId(ejq.getId());
			manager.persist(epe);
			manager.flush();
			BatchJobInfoEntity batchInfo = new BatchJobInfoEntity();
			batchInfo.setBatchJobId(request.getBatchJobId());
			batchInfo.setBatchType(request.getType().name());
			batchInfo.setReqeustId(pbm.getRequest().getRequestId());
			batchInfo.setInternalJobId(ejq.getId());
			manager.persist(batchInfo);
			manager.flush();
			
		} catch (Exception e) {
			AimError dbErr = AimError.EXTRACT_DB;
			String errMsg = String.format("%s", dbErr.getMessage(), e.getMessage());
			throw new DataBaseException(dbErr.getErrorCode(), errMsg, dateDao.getReasonTime(), dbErr.getUidCode());
		}

		// send event to extract planner
		JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
				String.format("create extract job id: %s", ejq.getId()));
		return String.valueOf(ejq.getId());
	}

	/**
	 * delete extract Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(PBDeleteJobRequest request) {
		String referenceId = null;
		if (request.hasReferenceId()) {
			referenceId = request.getReferenceId();
		} else {
			exception.throwArgException(AimError.MISS_REFERENCE_ID_ERROR, null);
		}
		try {
			feJobDao.delExtJobByRefId(referenceId);
		} catch (Exception ex) {			
			exception.throwDBException(AimError.EXTRACT_DB, ex, "extract service err");
		}
	}

	/**
	 * clear all extract Jobs
	 */
	public void clearJobs() {
		try {
			feJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.EXTRACT_DB, ex, "Exception occurred when clear extract job.");
		}
	}

	// public ExtractResponse unPressesPayloadExResult(
	// byte[] compressedPayloadExResut) throws IOException {
	// byte[] compressedOutputPayload = null;
	// ExtractResponse.Builder newPBExtractJobResult = ExtractResponse
	// .newBuilder();
	// PBMuExtractJobResult pbExInternal = PBMuExtractJobResult
	// .parseFrom(ByteString.copyFrom(compressedPayloadExResut));
	//
	//
	//
	// if (pbExInternal.hasCompressedOutputPayload()) {
	// compressedOutputPayload = pbExInternal.getCompressedOutputPayload()
	// .toByteArray();
	// byte[] uncompressedOutputPayload = Deflater
	// .uncompress(compressedOutputPayload);
	// newPBExtractJobResult.setOutputPayload(PBExtractOutputPayload
	// .parseFrom(uncompressedOutputPayload));
	// }
	// newPBExtractJobResult.setServiceState(pbExInternal.g);
	// newPBExtractJobResult.setJobId(pbExInternal.);
	// newPBExtractJobResult.addAllKeyedTemplate(pbExInternal
	// .getKeyedTemplateList());
	// return newPBExtractJobResult.build();
	// }
}
