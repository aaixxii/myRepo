package jp.co.nec.aim.mm.sessionbeans;

import static jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType.DATA_MANAGER;
import static jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType.MATCH_UNIT;
import static jp.co.nec.aim.mm.constants.AimError.COMPONENT_TYPE;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBExitRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBHeartBeatResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBInitialConfigInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncInfo;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.mm.aggregator.Aggregator;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.AimInfo;
import jp.co.nec.aim.mm.constants.EventLogLevel;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.CommitDao;
import jp.co.nec.aim.mm.dao.ContactTimesDao;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.RUCDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.DataManagerEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FusionJobEntity;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.entities.SystemManagerEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.segment.sync.SegReportManager;
import jp.co.nec.aim.mm.segment.sync.SegUpdatesManager;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;
import jp.co.nec.aim.mm.sessionbeans.pojo.EventSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExtractJobHandler;
import jp.co.nec.aim.mm.sessionbeans.pojo.InquiryJobHandler;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.validator.ComponentValidator;

/**
 * StatusManagerBean <br>
 * Include Component Enter, Exit and HeartBeat method.
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class StatusManagerBean {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(StatusManagerBean.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	@EJB
	private Aggregator aggregator;
	
	private ComponentValidator validator;
	private UnitDao unitDao;
	private RUCDao rucDao;
	private CommitDao commitDao;
	private SystemInitDao initDao;
	private SegReportManager reportManager;
	private SegUpdatesManager updatesManager;
	private FEJobDao feJobDao;
	private InquiryJobDao inquiryJobDao;
	private SystemConfigDao configDao;
	private ExtractJobHandler extractJobHandler;
	private InquiryJobHandler inquiryJobHandler;
	private ExceptionSender exceptionSender;
	private ContactTimesDao contactTimesDao;
	private DateDao dateDao;
	private EventSender eventSender;

	/** filter the segment that version is too old when MU DM enter **/
	private static final boolean ENTER_FILTER = true;

	/** filter the segment that version is too old when MU DM enter **/
	private static final boolean HEARTBEAT_FILTER = false;

	/**
	 * default constructor
	 */
	public StatusManagerBean() {
	}

	@PostConstruct
	private void init() {
		this.validator = new ComponentValidator(dataSource);
		this.unitDao = new UnitDao(manager);
		this.rucDao = new RUCDao(dataSource);
		this.commitDao = new CommitDao(dataSource);
		this.initDao = new SystemInitDao(manager);
		this.reportManager = new SegReportManager(manager, dataSource);
		this.updatesManager = new SegUpdatesManager(manager, dataSource);
		this.feJobDao = new FEJobDao(manager);
		this.inquiryJobDao = new InquiryJobDao(manager);
		this.configDao = new SystemConfigDao(manager);
		this.extractJobHandler = new ExtractJobHandler(manager, dataSource);
				
		this.inquiryJobHandler = new InquiryJobHandler(manager, dataSource,
				aggregator);
		this.exceptionSender = new ExceptionSender();
		this.contactTimesDao = new ContactTimesDao(dataSource);
		this.dateDao = new DateDao(dataSource);
		this.eventSender = new EventSender();
	}

	/**
	 * each component enter work flow
	 * 
	 * @param Component
	 * @return PBEnterResponse instance
	 */
	public PBEnterResponse enter(final PBComponentInfo component) {
		// check version uniqueId contactUrl is correct
		// if with error throw ArgumentException
		// and response 400 bad request
		validator.checkPBComponentInfo(component);

		final ComponentType type = component.getComponent();
		log.info(
				"Received enter() from unique id '{}', type '{}', at URL '{}'",
				new Object[] { component.getUniqueId(), type.name(),
						component.getContactUrl() });

		final PBEnterResponse.Builder builder = PBEnterResponse.newBuilder();
		switch (type) {
		case MATCH_UNIT:
			// 1. MU enter. 2. increaseRUC.
			// 3. rollbackExtJobs. 4. commit.
			// 5. send SLB event.
			long muId = muEnter(component);

			// 1. filter the segment that was too old
			// 2. update and sync the segment report version
			// (remove old segment record)
			// 3. flush entity manager
			updateUnitSegReport(component, muId, ENTER_FILTER);

			// 1. find the segment that was out of data
			// 2. set the segment that do not need to catchUp
			// 3. get the segment DIFF template with catchUp segment list
			List<PBSegmentSyncInfo> updateSegInfoList = getUnitSegUpdates(muId, type);
			for (int i = 0; i < updateSegInfoList.size(); i++) {
				builder.addSegmentUpdates(updateSegInfoList.get(i));
			}			
			builder.setId(muId);

			// set the wakeUp port into PBComponentInfo
			setWakeupPort(builder, MATCH_UNIT);

			// set the MU max lot number from system init
			setMuMaxLot(builder);
			break;
		case DATA_MANAGER:
			// 1. DM enter 2. commit.
			// 3. send SLB event.
			long dmId = dmEnter(component);

			// 1. filter the segment that was too old
			// 2. update and sync the segment report version
			// (remove old segment record)
			// 3. flush entity manager
			updateUnitSegReport(component, dmId, ENTER_FILTER);

			// 1. find the segment that was out of data
			// 2. set the segment that do not need to catchUp
			// 3. get the segment DIFF template with catchUp segment list
			List<PBSegmentSyncInfo> segUpdateList = getUnitSegUpdates(dmId, type);
			for (int i = 0; i< segUpdateList.size(); i++) {
				builder.addSegmentUpdates(segUpdateList.get(i));
			}			
			builder.setId(dmId);

			// set the wakeUp port into PBComponentInfo
			setWakeupPort(builder, DATA_MANAGER);
			break;
		case MAP_REDUCER:
			// 1. MR enter 2. rollBack Inquiry Jobs
			// 3. flush and commit.
			long mrId = mrEnter(component);
			builder.setId(mrId);
			break;
		case SYSTEM_MANAGER:
			long smId = smEnter(component);
			builder.setId(smId);
			break;
		default:
			final String error = String.format(COMPONENT_TYPE.getMessage(),
					type.name());
			throw new ArgumentException(COMPONENT_TYPE.getErrorCode(), error,
					String.valueOf(dateDao.getCurrentTimeMS()), COMPONENT_TYPE.getUidCode());
		}

		// send the event to infoQueue and SM will receive it
		AimInfo enterEvent = AimInfo.COMPONENT_ENTER_EVENT;
		String information = String.format(enterEvent.getMessage(),
				builder.getId(), type.name());
		eventSender.sendEvent(enterEvent.getInfoCode(),
				enterEvent.getEventType(), builder.getId(), information,
				EventLogLevel.INFO, dateDao.getDatabaseDate());

		return builder.build();
	}

	/**
	 * each component heartBeat work flow
	 * 
	 * @param request
	 *            the instance of PBComponentInfo
	 */
	public PBHeartBeatResponse heartbeat(final PBComponentInfo component) {
		// check version uniqueId contactUrl is correct
		// if with error throw ArgumentException
		// and response 400 bad request
		validator.checkPBComponentInfo(component);

		final ComponentType type = component.getComponent();
		if (log.isDebugEnabled()) {
			log.debug(
					"Received heartbeat() from unique id '{}', type '{}', at URL '{}'",
					new Object[] { component.getUniqueId(), type.name(),
							component.getContactUrl() });
		}

		final PBHeartBeatResponse.Builder builder = PBHeartBeatResponse
				.newBuilder();
		switch (type) {
		case MATCH_UNIT:
			// update MU contact and increase the RUC
			Long muId = muHeartbeat(component);
			// if MU is not exist and not in working state
			builder.setWrongState((muId == null));

			// heartBeat MU is exist and in working state
			if (muId != null) {
				// update and sync the segment report version
				// flush entity manager
				updateUnitSegReport(component, muId, HEARTBEAT_FILTER);

				// get the segment DIFF template with catchUp segment list
				List<PBSegmentSyncInfo> segUpdateList = getUnitSegUpdates(muId, type);
				for (int i = 0; i < segUpdateList.size(); i++) {
					builder.addSegmentUpdates(segUpdateList.get(i));
				}				
			} else {
				log.warn(
						"Skip update segment report and"
								+ " get segment updates due to Mu {} is in wrong state.",
						component.getUniqueId());
			}
			break;
		case DATA_MANAGER:
			// update DM contact
			Long dmId = dmHeartbeat(component);
			// if DM is not exist and not in working state
			builder.setWrongState((dmId == null));

			if (dmId != null) {
				// update and sync the segment report version
				// flush entity manager
				updateUnitSegReport(component, dmId, HEARTBEAT_FILTER);

				// get the segment DIFF template with catchUp segment list
				List<PBSegmentSyncInfo> updateSegInfoList = getUnitSegUpdates(dmId, type);			
				for (int i = 0; i < updateSegInfoList.size(); i++) {
					builder.addSegmentUpdates(updateSegInfoList.get(i));
				}
				
			} else {
				log.warn(
						"Skip update segment report and"
								+ " get segment updates due to Dm {} is in wrong state.",
						component.getUniqueId());
			}
			break;
		case MAP_REDUCER:
			Long mrId = mrHeartbeat(component);
			// if MR is not exist and not in working state
			builder.setWrongState((mrId == null));
			break;
		case SYSTEM_MANAGER:
			builder.setWrongState(false);
			break;
		default:
			final String error = String.format(COMPONENT_TYPE.getMessage(),
					type.name());
			throw new ArgumentException(COMPONENT_TYPE.getErrorCode(), error,
					String.valueOf(dateDao.getCurrentTimeMS()), COMPONENT_TYPE.getUidCode());
		}
		return builder.build();
	}

	/**
	 * each component exit work flow
	 * 
	 * @param request
	 *            the instance of PBExitRequest
	 */
	public void exit(final PBExitRequest request) {
		// check version uniqueId contactUrl is correct
		// if with error throw ArgumentException
		// and response 400 bad request
		validator.checkPBExitRequest(request);
		long unitId = request.getId();
		log.info("Received exit() from unit id '{}'", unitId);

		final ComponentType type = request.getComponent();
		switch (type) {
		case MATCH_UNIT:
			// set match unit to exit
			// rollBack the extract job
			muExit(unitId);
			break;
		case DATA_MANAGER:
			// set data manager to exit
			dmExit(unitId);
			break;
		case MAP_REDUCER:
			// set map reducer to exit
			// rollBack the inquiry job
			mrExit(unitId);
			break;
		case SYSTEM_MANAGER:
			// set System Manager to exit
			smExit(unitId);
			break;
		default:
			final String error = String.format(COMPONENT_TYPE.getMessage(),
					type.name());
			throw new ArgumentException(COMPONENT_TYPE.getErrorCode(), error,
					String.valueOf(dateDao.getCurrentTimeMS()), COMPONENT_TYPE.getUidCode());
		}

		// send the event to infoQueue and SM will receive it
		AimInfo exitEvent = AimInfo.COMPONENT_EXIT_EVENT;
		String information = String.format(exitEvent.getMessage(), unitId,
				type.name());
		eventSender.sendEvent(exitEvent.getInfoCode(),
				exitEvent.getEventType(), unitId, information,
				EventLogLevel.INFO, dateDao.getDatabaseDate());
	}

	// //////////////////////////////////////////////////////////////////////
	// /////////////////////////////MU related method////////////////////////
	// //////////////////////////////////////////////////////////////////////
	/**
	 * MU Enter main work flow
	 * 
	 * @param component
	 *            PBComponentInfo instance
	 */
	private long muEnter(final PBComponentInfo component) {
		final String uniqueId = component.getUniqueId();
		MatchUnitEntity mu = unitDao.searchMu(uniqueId);
		if (mu != null) {
			// MU is already exist
			unitDao.updateMu(mu, component);
		} else {
			// MU is not exist, add in the first time
			mu = unitDao.addMu(component);
			log.debug("NEW match unit has entered the system, adding default eligible containers.");
			unitDao.addMuEligibleContainers(mu.getMuId());
			log.debug("NEW match unit has entered the system, adding default eligible functions.");
			unitDao.addMuEligibleFunctions(mu.getMuId());
		}
		manager.flush();

		// increase the RUC
		rucDao.increaseRUC();

		// list dead extract job with MU id
		// and rollBack these jobs
		rollbackExtJobs(mu.getMuId());

		// flush and commit
		manager.flush();
		commitDao.commit();

		// send JMS event to SLB
		sendEventToSlb("MU : " + mu.getMuId() + " Enter.");

		return mu.getMuId();
	}

	/**
	 * MU heartBeat main work flow
	 * 
	 * @param component
	 *            the instance of PBComponentInfo
	 * @return MU id
	 */
	private Long muHeartbeat(final PBComponentInfo component) {
		final String uniqueId = component.getUniqueId();
		MatchUnitEntity mu = unitDao.searchMu(uniqueId);
		if (mu == null) {
			log.warn("findAndWarnState: (heartBeat) Match unit uniqueId: "
					+ uniqueId + " not found in database.");
			return null;
		}

		// HeartBeat MU state is not in working state
		if (mu.getState() != UnitState.WORKING) {
			log.warn("MU '{}' heartBeat state is not in working state",
					mu.getMuId());
			return null;
		}

		// update contact time
		int unitType = component.getComponent().ordinal();
		contactTimesDao.updateContact(mu.getMuId(), unitType);

		// segmentMapChanged is exist and true
		if (isSegMapChanged(component)) {
			// increase the RUC
			rucDao.increaseRUC();
		}

		return mu.getMuId();
	}

	/**
	 * MU Exit main work flow
	 * 
	 * @param muId
	 *            match unit id
	 */
	private void muExit(long muId) {
		final MatchUnitEntity mu = unitDao.findMU(muId);
		if (mu == null) {
			log.warn("Mu exit, but Mu {} is not exist in match unit..", muId);
			return;
		}

		// update MU state to Exit
		unitDao.updateMuExit(mu);

		// rollBack the extract job
		// with specified MU id
		rollbackExtJobs(muId);

		rucDao.increaseRUC();
		commitDao.commit();

		// send JMS event to FE job Planner
		JmsSender.getInstance().sendToFEJobPlanner(
				NotifierEnum.StatusManagerBean, "Mu: " + muId + " Exit.");

		// send JMS event to SLB
		sendEventToSlb("MU : " + mu.getMuId() + " Exit.");

	}

	/**
	 * Roll back the extract job with specified MU id
	 * 
	 * @param muId
	 *            MU id
	 */
	private void rollbackExtJobs(long muId) {
		List<FeJobQueueEntity> deadExtractJobs = feJobDao
				.listDeadExtractJobs(muId);
		if (CollectionsUtil.isEmpty(deadExtractJobs)) {
			if (log.isDebugEnabled()) {
				log.debug("mu id: {} can not found any "
						+ "dead extract jobs when enterd.", muId);
			}
			return;
		}

		// max failure count
		int maxExtractJobFailures = configDao
				.getMMPropertyInt(MMConfigProperty.MAX_EXTRACT_JOB_FAILURES);
		// loop each dead extract jobs
		for (final FeJobQueueEntity eje : deadExtractJobs) {
			try {
				final AimError aimError = AimError.COMPONENT_EXTRACT_JOB_RETRY_OVER;
				AimServiceState aimServiceState = new AimServiceState(aimError.getMessage(), aimError.getErrorCode(), dateDao.getReasonTime());
//				PBResponse.Builder errResponse = PBResponse.newBuilder();
//				errResponse.setErrorMessage(String.format(aimError.getMessage(),eje.getId()));
//				PBResponseAttribute.Builder ab = PBResponseAttribute.newBuilder();
//				ab.setAttributeName("createdTimestamp");
//				ab.setAttributeValue(dateDao.getReasonTime());	
			
				int count = extractJobHandler.failExtractJob(eje,
						eje.getMuId().longValue(),aimServiceState,  false, maxExtractJobFailures);
				if (count > 0) {
					// muLoadDao.decreaseExtractLoad(muId);
					feJobDao.deleteLotJob(eje.getLotJobId());
					commitDao.commit();
				}
			} catch (Exception e) {
				final AimError aimError = AimError.EXTRACT_JOB_RETRY;
				String message = String.format(aimError.getMessage(),
						eje.getId(), muId);
				log.error(message, e);
				exceptionSender.sendAimException(aimError.getErrorCode(),
						message, eje.getId(), eje.getId(), muId, e);
			}
		}
	}

	// //////////////////////////////////////////////////////////////////////
	// /////////////////////////////MR related method////////////////////////
	// //////////////////////////////////////////////////////////////////////
	/**
	 * mrEnter main work flow
	 * 
	 * @param component
	 *            PBComponentInfo instance
	 */
	private long mrEnter(final PBComponentInfo component) {
		final String uniqueId = component.getUniqueId();
		MapReducerEntity mr = unitDao.searchMr(uniqueId);
		if (mr != null) {
			// MR is already exist
			unitDao.updateMr(mr, component);
		} else {
			// MR is not exist, add in the first time
			mr = unitDao.addMr(component);
		}
		manager.flush();

		// Roll back the inquiry job with specified MR id
		rollbackInqJobs(mr.getMrId());

		// flush and commit
		manager.flush();
		commitDao.commit();
		return mr.getMrId();
	}

	/**
	 * MR heartBeat main work flow
	 * 
	 * @param component
	 *            the instance of PBComponentInfo
	 * @return MR id
	 */
	private Long mrHeartbeat(final PBComponentInfo component) {
		final String uniqueId = component.getUniqueId();
		MapReducerEntity mr = unitDao.searchMr(uniqueId);
		if (mr == null) {
			log.warn("findAndWarnState: (heartBeat) Map Reducer uniqueId: "
					+ uniqueId + " not found in database.");
			return null;
		}

		long mrId = mr.getMrId(); // MR id

		// HeartBeat MR state is not in working state
		if (mr.getState() != UnitState.WORKING) {
			log.warn("MR '{}' heartBeat state is not in working state", mrId);
			return null;
		}

		// update contact time
		int unitType = component.getComponent().ordinal();
		contactTimesDao.updateContact(mrId, unitType);

		// MR increase the RUC is not allowed
		return mrId;
	}

	/**
	 * MR Exit main work flow
	 * 
	 * @param muId
	 *            match unit id
	 */
	private void mrExit(long mrId) {
		final MapReducerEntity mr = unitDao.findMR(mrId);
		if (mr == null) {
			log.warn("MR exit, but MR {} is not exist in Map Reducer..", mrId);
			return;
		}

		// update MU state to Exit
		unitDao.updateMuExit(mr);

		// rollBack the extract job
		// with specified MU id
		rollbackInqJobs(mrId);
	}

	/**
	 * SM Exit main work flow
	 * 
	 * @param smId
	 */
	private void smExit(long smId) {
		final SystemManagerEntity sm = unitDao.findSM(smId);
		if (sm == null) {
			log.warn("SM exit, but SM {} is not exist in System Manager..",
					smId);
			return;
		}

		// update SM state to Exit
		unitDao.updateSmExit(sm);
	}

	/**
	 * Roll back the inquiry job with specified MR id
	 * 
	 * @param mrId
	 *            MR id
	 */
	public void rollbackInqJobs(long mrId) {
		List<ContainerJobEntity> deadJobs = inquiryJobDao.listDeadJobs(mrId);
		if (CollectionsUtil.isEmpty(deadJobs)) {
			if (log.isDebugEnabled()) {
				log.debug("mr id: {} could not found any dead inquiry jobs.",
						mrId);
			}
			return;
		}

		// loop each dead inquiry jobs
		for (final ContainerJobEntity job : deadJobs) {
			long containerJobId = job.getContainerJobId();
			try {
				final AimError aimError = AimError.INQ_JOB_RETRY_OVER;
				ContainerJobEntity cntJob = inquiryJobDao.getContainerJob(containerJobId);
				long funsionJobId = cntJob.getFusionJobId();
				List<FusionJobEntity> listFusionJob = inquiryJobDao.getFusionJob(funsionJobId, 1);
				FusionJobEntity fusionEntity = listFusionJob.get(0);
				byte[] data = fusionEntity.getInquiryJobData();
				PBBusinessMessage pbMsg = null;
				try {
					pbMsg = PBBusinessMessage.parseFrom(data);
				} catch (InvalidProtocolBufferException e) {
					//ToDo
				}				
			
				inquiryJobHandler.failInquiryJob(containerJobId, aimError
						.getErrorCode(), String.format(aimError.getMessage(),
						mrId, containerJobId), pbMsg,dateDao.getReasonTime());
			} catch (Exception e) {
				final AimError aimError = AimError.INQ_JOB_RETRY;
				String message = String.format(aimError.getMessage(),
						containerJobId, mrId);
				log.error(message, e);
				exceptionSender.sendAimException(aimError.getErrorCode(),
						message, containerJobId, containerJobId, mrId, e);
			}
		}
	}

	// //////////////////////////////////////////////////////////////////////
	// /////////////////////////////DM related method////////////////////////
	// //////////////////////////////////////////////////////////////////////
	/**
	 * DM Enter main work flow
	 * 
	 * @param component
	 *            PBComponentInfo instance
	 */
	private long dmEnter(final PBComponentInfo component) {
		final String uniqueId = component.getUniqueId();
		DataManagerEntity dm = unitDao.searchDm(uniqueId);
		if (dm != null) {
			// MR is already exist
			unitDao.updateDm(dm, component);
		} else {
			// MR is not exist, add in the first time
			dm = unitDao.addDm(component);
			log.debug("NEW Data Manager has entered the system, adding default eligible containers.");
			unitDao.addDmEligibleContainers(dm.getDmId());
		}

		// flush and commit
		manager.flush();
		commitDao.commit();

		// send JMS event to SLB
		sendEventToSlb("DM : " + dm.getDmId() + " Enter.");

		return dm.getDmId();
	}

	/**
	 * DM heartBeat main work flow
	 * 
	 * @param component
	 *            the instance of PBComponentInfo
	 * @return DM id
	 */
	private Long dmHeartbeat(final PBComponentInfo component) {
		final String uniqueId = component.getUniqueId();
		DataManagerEntity dm = unitDao.searchDm(uniqueId);
		if (dm == null) {
			log.warn("findAndWarnState: (heartBeat) Data manager uniqueId: "
					+ uniqueId + " not found in database.");
			return null;
		}

		long dmId = dm.getDmId(); // DM id

		// HeartBeat DM state is not in working state
		if (dm.getState() != UnitState.WORKING) {
			log.warn("DM '{}' heartBeat state is not in working state", dmId);
			return null;
		}

		// update contact time
		int unitType = component.getComponent().ordinal();
		contactTimesDao.updateContact(dmId, unitType);

		// DM increase the RUC is not allowed
		return dmId;
	}

	/**
	 * DM Exit main work flow
	 * 
	 * @param muId
	 *            match unit id
	 */
	private void dmExit(long dmId) {
		final DataManagerEntity dm = unitDao.findDM(dmId);
		if (dm == null) {
			log.warn("DM exit, but DM {} is not exist in Data Manager..", dmId);
			return;
		}

		// update MU state to Exit
		unitDao.updateDmExit(dm);

		// send JMS event to SLB
		sendEventToSlb("DM : " + dm.getDmId() + " Exit.");
	}

	// //////////////////////////////////////////////////////////////////////
	// /////////////////////////////SM related method////////////////////////
	// //////////////////////////////////////////////////////////////////////

	/**
	 * SM Enter main work flow
	 * 
	 * @return
	 */
	private long smEnter(final PBComponentInfo component) {
		final String uniqueId = component.getUniqueId();
		SystemManagerEntity sm = unitDao.searchSm(uniqueId);
		if (sm != null) {
			// SM is already exist
			unitDao.updateSm(sm, component);
		} else {
			// SM is not exist, add in the first time
			sm = unitDao.addSm(component);
		}

		// flush and commit
		manager.flush();
		commitDao.commit();
		return sm.getSmId();
	}

	// //////////////////////////////////////////////////////////////////////
	// /////////////////////////////Common method////////////////////////////
	// //////////////////////////////////////////////////////////////////////
	/**
	 * updateUnitSegReport
	 * 
	 * @param component
	 *            component instance
	 * @param unitId
	 *            unit id
	 * @param isMU
	 *            is MU or DM
	 * @param isFilter
	 *            is filter or not
	 */
	private void updateUnitSegReport(final PBComponentInfo component,
			long unitId, boolean isFilter) {
		// segmentInfos is not editable, read only
		// so create new editableList
		List<PBSegmentInfo> editableList = Lists.newArrayList();
		if (!component.hasResourceInfo()) {
			log.info("Component {} has no ResourceInfo. ",
					component.getUniqueId());
		} else {
			PBResourceInfo resourceInfo = component.getResourceInfo();
			final List<PBSegmentInfo> segmentInfos = resourceInfo
					.getSegmentInfoList();
			if (CollectionsUtil.isEmpty(segmentInfos)) {
				log.info("Component {} has no segmentInfo, ",
						component.getUniqueId());
			} else {
				editableList.addAll(segmentInfos);
			}
		}

		// first filter the segment that was
		// over max segment DIFF size
		// first mark the BadTemplates
		// then remove it from the editableList
		if (isFilter) {
			reportManager.filterSegmentInfos(editableList);
		}

		// update the MU segment report base on
		// latest Segment and reported MU segment
		// information
		if (component.getComponent() == ComponentType.MATCH_UNIT) {
			reportManager.updateMuSegReport(editableList, unitId);
		} else {
			reportManager.updateDmSegReport(editableList, unitId);
		}
	}

	/**
	 * getUnitSegUpdates
	 * 
	 * @param unitId
	 *            the unit id
	 * @param type
	 *            ComponentType (DM or MU)
	 * @param type
	 *            PBEnterResponse.Builder response Builder
	 */
	private List<PBSegmentSyncInfo> getUnitSegUpdates(final long unitId,
			final ComponentType type) {
		List<PBSegmentSyncInfo> builders = null;
		switch (type) {
		case MATCH_UNIT:
			builders = updatesManager.getMuSegUpdates(unitId);
			// b.addAllSegmentUpdates(builders); // set MU segment updates
			break;
		case DATA_MANAGER:
			builders = updatesManager.getDmSegUpdates(unitId);
			// b.addAllSegmentUpdates(builders); // set DM segment updates
			break;
		default:
			throw new AimRuntimeException("The ComponentType:" + type.name()
					+ " is not support for the getUnitSegUpdates..");
		}
		// b.setId(unitId); // set unit id
		return builders;
	}

	/**
	 * setWakeupPort
	 * 
	 * @param b
	 *            PBEnterResponse Builder
	 * @param type
	 *            ComponentType type
	 */
	private void setWakeupPort(final PBEnterResponse.Builder b,
			final ComponentType type) {
		Integer port = initDao.getUnitWakeupPort();
		if (port == null) {
			throw new AimRuntimeException(
					"Could not found wake up port from system init, type:"
							+ type.name());
		}
		b.setWakeUpNotifyPort(port);
	}

	/**
	 * set number of MU max lot
	 * 
	 * @param b
	 *            PBEnterResponse instance
	 */
	private void setMuMaxLot(final PBEnterResponse.Builder b) {
		Integer maxLot = initDao.getMuMaxLot();
		if (maxLot == null) {
			throw new AimRuntimeException(
					"Could not found mu max lot number from system init");
		}
		b.setInitialConfig(PBInitialConfigInfo.newBuilder()
				.setMaxExractLotNumber(maxLot));
	}

	/**
	 * sendEventToSlb
	 */
	private void sendEventToSlb(String message) {
		JmsSender.getInstance().sendToSLB(NotifierEnum.StatusManagerBean,
				message);
	}

	/**
	 * getSegMapChanged
	 * 
	 * @param component
	 *            the instance of PBComponentInfo
	 * @return is segment map changed
	 */
	private boolean isSegMapChanged(final PBComponentInfo component) {
		if (!component.hasResourceInfo()) {
			return false;
		}
		PBResourceInfo resource = component.getResourceInfo();
		if (!resource.hasSegmentMapChanged()) {
			return false;
		}
		return resource.getSegmentMapChanged();
	}

}
