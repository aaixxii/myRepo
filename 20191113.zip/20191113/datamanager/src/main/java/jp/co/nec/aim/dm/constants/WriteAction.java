package jp.co.nec.aim.dm.constants;

public enum WriteAction {
	NO_OP, CREATE, UPDATE, DELETE, COMPACTION, RE_CREATE;
}
