package jp.co.nec.aim.dm.persistence;


public class SegmentFileNoOp implements SegmentFileWriter {

	@Override
	public SegmentFileWriteResult execute(int segmentId, Integer version) {
		return SegmentFileWriteResult.constructNoOpResult();
	}

	public String getJobState() {
		return "(no details)";
	}

}
