package jp.co.nec.aim.dm.persistence;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.exception.SegmentFileWritingException;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.util.StopWatch;

import org.apache.commons.io.IOUtils;

public class SegmentFileCompactor implements SegmentFileWriter {
	private static int SIZE_SEGMENT_HEADER = 26;
	private static int SIZE_CHECK_SUM = 1;
	private static int SIZE_TEMPLATE_SIZE = 2;
	private static int SIZE_FILTER_FLAG = 8;
	private static int SIZE_TEMPLATE_ID = 8;

	public SegmentFileCompactor() {

	}

	public synchronized String getJobState() {
		return "(no details)";
	}

	@Override
	public SegmentFileWriteResult execute(int segmentId, Integer version) {
		return execute(segmentId);
	}

	public SegmentFileWriteResult execute(int segmentId) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		String segmentFileName = new SegmentFileName(segmentId).getName();

		StringBuffer tmpFileNameBuffer = new StringBuffer();
		tmpFileNameBuffer.append(segmentFileName).append(".tmp");
		String tmpFileName = tmpFileNameBuffer.toString();

		RandomAccessFile segFile = null;
		DataInputStream in = null;
		DataOutputStream out = null;
		try {
			segFile = new RandomAccessFile(segmentFileName, "r");
			int size = (int) segFile.length();
			byte[] segmentData = new byte[size];
			segFile.read(segmentData);

			in = new DataInputStream(new BufferedInputStream(
					new FileInputStream(segmentFileName)));
			in.read(segmentData);

			out = new DataOutputStream(new BufferedOutputStream(
					new FileOutputStream(tmpFileName)));

			int segmentDataSize = segmentData.length;

			out.write(segmentData, 0, SIZE_SEGMENT_HEADER);
			segmentDataSize -= SIZE_SEGMENT_HEADER;

			int segmentHeaderIndex = SIZE_SEGMENT_HEADER - 1;
			int writePosition = segmentHeaderIndex;

			while (segmentDataSize > 0) {
				int readPosition = writePosition;
				readPosition += SIZE_CHECK_SUM;

				ByteArrayInputStream bisTemplateSize = new ByteArrayInputStream(
						segmentData, readPosition, SIZE_TEMPLATE_SIZE);
				DataInputStream inTemplateSize = new DataInputStream(
						bisTemplateSize);
				int templateSize = inTemplateSize.readUnsignedShort();

				readPosition += SIZE_TEMPLATE_ID;
				readPosition += SIZE_FILTER_FLAG;

				byte deleteFlag = segmentData[readPosition];
				// TODO
				/**
				 * Remove outer 'if'loop --this prevents array indexoutofbounds
				 * In place to work with bad test data
				 * 
				 */
				if (segmentData.length >= writePosition + SIZE_CHECK_SUM
						+ templateSize) {
					if (deleteFlag == 0) {
						out.write(segmentData, writePosition, SIZE_CHECK_SUM
								+ templateSize);
					}
				}
				writePosition += SIZE_CHECK_SUM + templateSize;
				segmentDataSize -= SIZE_CHECK_SUM + templateSize;
			}
		} catch (FileNotFoundException e) {
			throw new SegmentFileWritingException(e);
		} catch (IOException e) {
			throw new SegmentFileWritingException(e);
		} finally {
			IOUtils.closeQuietly(segFile);
			IOUtils.closeQuietly(in);
			IOUtils.closeQuietly(out);
		}

		boolean success = new File(segmentFileName).delete();
		if (!success) {
			throw new SegmentFileWritingException(
					"Could not delete old segment file after compaction"
							+ segmentFileName);
		}

		boolean renamingSuccess = new File(tmpFileName).renameTo(new File(
				segmentFileName));
		if (!renamingSuccess) {
			throw new SegmentFileWritingException(
					"Could not rename segment file from " + tmpFileName
							+ " to " + segmentFileName);
		}

		stopWatch.stop();
		PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
				.getSimpleName(), LogConstants.FUNCTION_execute, stopWatch
				.elapsedTime());

		return SegmentFileWriteResult.constructCompactionResult();
	}

}
