package jp.co.nec.aim.dm.persistence;

public interface SegmentFileWriter {
	public SegmentFileWriteResult execute(int segmentId, Integer version);

	public String getJobState();
}
