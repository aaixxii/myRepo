package jp.co.nec.aim.dm.exception;


public class SegmentFileWritingException extends DataManagerException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8582855723063065636L;

	public SegmentFileWritingException(String message, Throwable cause) {
		super(message, cause);
	}

	public SegmentFileWritingException(Throwable cause) {
		super(cause);
	}

	public SegmentFileWritingException(String message) {
		super(message);
	}

}
