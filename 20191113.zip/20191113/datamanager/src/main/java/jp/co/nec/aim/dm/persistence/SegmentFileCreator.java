package jp.co.nec.aim.dm.persistence;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.dm.constants.DMConstants;
import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.exception.SegmentFileWritingException;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.manager.IndexManager;
import jp.co.nec.aim.dm.procedure.DownloadSegmentDataProcedure;
import jp.co.nec.aim.dm.procedure.TemplateData;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;
import jp.co.nec.aim.dm.util.SumFileUtil;
import jp.co.nec.aim.helper.TemplateHeaderHelper;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Class to create new Segment File.
 * 
 * @author kurosu
 * 
 */
public class SegmentFileCreator implements SegmentFileWriter,
		ApplicationContextAware {
	private static final Logger log = LoggerFactory
			.getLogger(SegmentFileCreator.class);
	public static final int AIM_VERSION = 2;

	private static final String HEADER_SQL = "select seg.SEGMENT_ID, seg.VERSION, seg.BIO_ID_START, "
			+ "seg.BIO_ID_END, seg.RECORD_COUNT, ft.FORMAT_ID as EMBEDDED_ID, c.MAX_SEGMENT_SIZE "
			+ "from SEGMENTS seg, CONTAINERS c, FORMAT_TYPES ft "
			+ "where seg.SEGMENT_ID=? and seg.container_id=c.container_id  "
			+ "and c.FORMAT_ID=ft.FORMAT_ID";
	
	private ApplicationContext appContext;

	private static enum SegmentFileCreateState {
		WAITING_TO_RUN, //
		STARTED, //
		EXECUTING_QUERY, //
		ITERATING, //
		DONE;
	}

	private SegmentFileCreateState state;
	private int recordNum;
	private Long nextTemplateId;

	public SegmentFileCreator() {
		state = SegmentFileCreateState.WAITING_TO_RUN;
	}

	// / methods to keep track of internal progress (state), and allow access to
	// that state.
	private synchronized void updateCreateJobState(SegmentFileCreateState state) {
		this.state = state;
	}

	private synchronized void updateCreateJobIterationState(long nextTemplateId) {
		this.state = SegmentFileCreateState.ITERATING;
		this.nextTemplateId = nextTemplateId;
		++recordNum;
	}

	public synchronized String getJobState() {
		if (state == SegmentFileCreateState.ITERATING) {
			return "Iterating: record " + recordNum + ", template id "
					+ nextTemplateId;
		} else {
			return state.name();
		}
	}

	@Override
	public SegmentFileWriteResult execute(int segmentId, Integer version) {
		return execute(segmentId);
	}

	private SegmentFileWriteResult execute(int segmentId) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		log.info("Segment file writer starting CREATE of segment: " + segmentId);
		updateCreateJobState(SegmentFileCreateState.STARTED);
		updateCreateJobState(SegmentFileCreateState.EXECUTING_QUERY);

		FileOutputStream fout = null;
		BufferedOutputStream bufOut = null;
		DataOutputStream dout = null;
		try {
			createSumFile(segmentId);
			SegmentFileName segFileName = new SegmentFileName(segmentId);
			fout = new FileOutputStream(segFileName.getName());
			bufOut = new BufferedOutputStream(fout, DMConstants.BYTE_BUFFER_SIZE);
			dout = new DataOutputStream(bufOut);
			
			SegmentInfo segmentInfo = fetchSegmentInfo(segmentId);
			writeSgmentFileHeader(dout, segmentInfo);

			long maxTemplates = Long.valueOf(DynamicProperties.getInstance().
					getPropertyValue(DynamicPropertyNames.MAX_TEMPLATES)).longValue();
			DownloadSegmentDataProcedure procedure 
				= new DownloadSegmentDataProcedure((DataSource) appContext.getBean("dataSource"),
						segmentInfo, maxTemplates);
			int recordCount = 0;
			List<TemplateData> templates = null;
			while (0 < (templates = procedure.execute()).size()) {
				log.info("Got {} templates of SegmentId = {} from DB", new Integer(templates.size()),
						new Integer(segmentId));
				for (int index = 0; index < templates.size(); index++) {
					TemplateData templateData = templates.get(index);
					updateCreateJobIterationState(templateData.getBiometricsId());
					byte[] template = templateData.getBiometricData();
					if (template == null) {
						log.warn("Templete of TEMPLATE_ID:{} is empty. Do nothing for {}.seg", 
								templateData.getBiometricsId(), new Integer(segmentId));
					} else {
						byte[] templateWithHeader = TemplateHeaderHelper
								.prependHeader(templateData.getBiometricsId(),
										template, templateData.getExternalId(), templateData.getEventId());
						dout.write(templateWithHeader);
						recordCount++;
						if(log.isDebugEnabled()) {
							log.debug("Add TEMPLATE_ID:{} into {}.seg", templateData.getBiometricsId(),
									new Integer(segmentId));
						}
					}
				}
			}

			dout.flush();
			IOUtils.closeQuietly(dout);
			IOUtils.closeQuietly(bufOut);
			IOUtils.closeQuietly(fout);
			
			updateRecordCount(segFileName, recordCount);

			IndexManager.getInstance().putIndexMap(segmentId);
			IndexManager.getInstance().saveIndex(segmentId);
			if (!SumFileUtil.remove(segmentId)) {
				log.warn("Can't remove [{}].sum file", segmentId);
			}
			stopWatch.stop();
			log.info("Created {}.seg, version:{}, record count:{}. Took {} msec", 
					new Object[] {new Integer(segmentId), new Integer(segmentInfo.getVersion()),
					new Integer(recordCount), new Long(stopWatch.getTime())});
			PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
					.getSimpleName(), Thread.currentThread().getStackTrace()[1].getMethodName(), 
					stopWatch.getTime());

			return SegmentFileWriteResult.constructCreateResult(new Integer(segmentInfo.getVersion()));
		} catch (IOException e) {
			throw new SegmentFileWritingException(
					"IOException while creating segment file", e);
		} finally {
			IOUtils.closeQuietly(dout);
			IOUtils.closeQuietly(bufOut);
			IOUtils.closeQuietly(fout);
			updateCreateJobState(SegmentFileCreateState.DONE);
		}
	}

	private SegmentInfo fetchSegmentInfo(int segmentId) {
		JdbcTemplate jdbcTemplate = (JdbcTemplate) appContext.getBean("jdbcTemplate");
		return jdbcTemplate.queryForObject(HEADER_SQL, new Object[] {new Integer(segmentId)},
				new BeanPropertyRowMapper<SegmentInfo>(SegmentInfo.class));
	}

	private void updateRecordCount(SegmentFileName segFileName, int recordCount) throws IOException {
		RandomAccessFile randFile = null;
		try {
			randFile = new RandomAccessFile(segFileName.getName(), "rw");
			// version:4byte, formatId:2byte, maxSize:8byte
			randFile.seek(14L);
			randFile.writeInt(recordCount);
		} finally {
			IOUtils.closeQuietly(randFile);
		}
	}

	private void createSumFile(int segmentId) throws IOException {
		if (SumFileUtil.exists(segmentId)) {
			log.warn("[{}].sum exists!!. I'll remove this.", segmentId);
			if (!SumFileUtil.remove(segmentId)) {
				String message = "Can't remove [" + segmentId + "].sum file";
				log.error(message);
				throw new SegmentFileWritingException(message);
			}
		}
		SumFileUtil.create(segmentId);
	}

	private void writeSgmentFileHeader(DataOutputStream dout,
			SegmentInfo segmentInfo) throws IOException {
		dout.writeInt(AIM_VERSION);
		log.debug("aim version=" + AIM_VERSION);

		int embeddedId = segmentInfo.getEmbeddedId();
		dout.writeShort(embeddedId);
		log.debug("formatId=" + embeddedId);

		long maxSegSize = segmentInfo.getMaxSegmentSize();
		dout.writeLong(maxSegSize);
		log.debug("maxSegSize=" + maxSegSize);

		dout.writeInt(segmentInfo.getRecordCount());
		log.debug("recordCountFromDb=" + segmentInfo.getRecordCount());

		log.debug("Setting segmentVersion to " + segmentInfo.getVersion());
		dout.writeLong((long)segmentInfo.getVersion());
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		appContext = applicationContext;
	}
}
