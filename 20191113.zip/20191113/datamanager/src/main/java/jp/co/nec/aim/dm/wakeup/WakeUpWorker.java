package jp.co.nec.aim.dm.wakeup;

import jp.co.nec.aim.dm.comm.CommunicationHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author liuyq
 * 
 */
public class WakeUpWorker implements Runnable {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(WakeUpWorker.class);

	private String message;
	private final Long unitId;
	private CommunicationHelper helper;

	/**
	 * WakeUpWorker default constructor
	 * 
	 * @param bytes
	 *            byte array receive from MM
	 * @param unitId
	 *            DM unit id after enter
	 * @param helper
	 *            the instance of CommunicationHelper
	 */
	public WakeUpWorker(String message, Long unitId, CommunicationHelper helper) {
		this.message = message;
		this.unitId = unitId;
		this.helper = helper;
	}

	@Override
	public void run() {
		try {
			if (unitId == null) {
				log.warn("UnitId is null in WakeUpWorker..");
				return;
			}

			if (isWakeUpMe(message)) {
				// WakeUp message includes myself
				// i will generate the PBComponentInfo
				// and post to MM heartBeat servLet immediately
				log.info(
						"WakeUp message includes myself, post to MM heartBeat."
								+ " message: {}, unitId: {}.", message, unitId);
				helper.sendHeartbeat();
			} else {
				// i receive the message but
				// notify destination is not me
				if (log.isDebugEnabled()) {
					log.debug("Receive message: {} from MM, but was not me..",
							message);
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred when send heartbeat"
					+ " to MM after wake up..", e);
		}
	}

	/**
	 * Is MM wake up me? <br>
	 * Check the message from MM is contain me
	 * 
	 * @param mgs
	 *            the message from MM
	 * @return Is MM wake up me or not
	 */
	private boolean isWakeUpMe(final String mgs) {
		final String[] ids = mgs.split(",");
		if (ids == null || ids.length <= 0) {
			log.warn("Received message is incorrect from MM.");
			return false;
		}

		String dmIdStr = String.valueOf(unitId);
		for (final String id : ids) {
			if (id.equalsIgnoreCase(dmIdStr)) {
				return true;
			}
		}
		return false;
	}
}
