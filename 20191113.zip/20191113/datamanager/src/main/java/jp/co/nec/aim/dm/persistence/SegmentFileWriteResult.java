package jp.co.nec.aim.dm.persistence;

import java.util.ArrayList;
import java.util.List;

public class SegmentFileWriteResult {
	private boolean setVersion;
	private Integer segmentVersion;
	private boolean clearNumDeleted;
	private int numDeleted;
	private boolean clearBadTemplates;
	private List<Long> badTemplateIds;

	public static SegmentFileWriteResult constructNoOpResult() {
		return new SegmentFileWriteResult(false, null, false, 0, false, null);
	}

	public static SegmentFileWriteResult constructCreateResult(
			Integer version) {
		return constructCreateResult(version, new ArrayList<Long>());
	}

	private static SegmentFileWriteResult constructCreateResult(Integer version,
			List<Long> badTemplateIds) {
		return new SegmentFileWriteResult(true, version, true, 0, true,
				badTemplateIds);
	}

	public static SegmentFileWriteResult constructCompactionResult() {
		return new SegmentFileWriteResult(false, null, true, 0, false, null);
	}

	public static SegmentFileWriteResult constructDeleteResult() {
		return new SegmentFileWriteResult(true, null, true, 0, false, null);
	}

	public static SegmentFileWriteResult constructUpdateResult(Integer version,
			int numDeletes, List<Long> badTemplateIds) {
		return new SegmentFileWriteResult(true, version, false, numDeletes,
				false, badTemplateIds);
	}

	private SegmentFileWriteResult(boolean setVersion, Integer segmentVersion,
			boolean clearNumDeleted, int numDeleted, boolean clearBadTemplates,
			List<Long> badTemplateIds) {
		this.setVersion = setVersion;
		this.segmentVersion = segmentVersion;
		this.clearNumDeleted = clearNumDeleted;
		this.numDeleted = numDeleted;
		this.clearBadTemplates = clearBadTemplates;
		this.badTemplateIds = badTemplateIds;
	}

	public List<Long> getBadTemplateIds() {
		return badTemplateIds;
	}

	public boolean isClearBadTemplates() {
		return clearBadTemplates;
	}

	public boolean isClearNumDeleted() {
		return clearNumDeleted;
	}

	public int getNumDeleted() {
		return numDeleted;
	}

	public Integer getSegmentVersion() {
		return segmentVersion;
	}

	public boolean isSetVersion() {
		return setVersion;
	}

}
