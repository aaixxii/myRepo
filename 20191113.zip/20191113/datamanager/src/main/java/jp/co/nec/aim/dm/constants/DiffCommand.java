package jp.co.nec.aim.dm.constants;

import jp.co.nec.aim.dm.exception.DataManagerException;

public enum DiffCommand {
	INSERT(0), DELETE(1);

	private int val;

	private DiffCommand(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}

	public static DiffCommand parseFromInt(int val) {
		for (DiffCommand d : DiffCommand.values()) {
			if (d.getVal() == val)
				return d;
		}
		throw new DataManagerException("Unknown diff command: " + val);
	}

}
