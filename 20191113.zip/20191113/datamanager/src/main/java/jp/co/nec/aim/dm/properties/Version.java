package jp.co.nec.aim.dm.properties;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Choosing version number from
 * META-INF/maven/jp.co.nec.aim.dm/aim-datamanager/pom.properties
 * 
 * @author f-kawakami
 * 
 */
public class Version {
	private static final Logger log = LoggerFactory.getLogger(Version.class);
	private static String version;

	/**
	 * Read version number from pom.propertis in the web archive file.
	 * 
	 * @return version number
	 */
	public static String getVersion() {
		return version;
	}

	public static void loadVersion(ServletContext sc) {
		InputStream is = sc.getResourceAsStream("/META-INF/maven/jp.co.nec.aim.dm/datamanager/pom.properties");
		Properties prop = new Properties();
		try {
			prop.load(is);
			version = prop.getProperty("version");
		} catch (IOException e) {
			log.error("Can't load pom.properties");
		}
	}

}
