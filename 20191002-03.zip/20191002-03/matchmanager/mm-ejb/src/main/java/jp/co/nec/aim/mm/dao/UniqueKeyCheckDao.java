package jp.co.nec.aim.mm.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.message.proto.AIMMessages.PBAbilityInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.DataManagerEntity;
import jp.co.nec.aim.mm.entities.DmContactEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.entities.MrContactEntity;
import jp.co.nec.aim.mm.entities.MuContactEntity;
import jp.co.nec.aim.mm.entities.MuEligibleFunctionEntity;
import jp.co.nec.aim.mm.entities.MuExtractLoadEntity;
import jp.co.nec.aim.mm.entities.MuInquiryLoadEntity;
import jp.co.nec.aim.mm.entities.PersonBiometricEntity;
import jp.co.nec.aim.mm.entities.QueueType;
import jp.co.nec.aim.mm.entities.SystemManagerEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.slb.loadbalance.UnitNote;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

public class UniqueKeyCheckDao {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(UniqueKeyCheckDao.class);
	private EntityManager em;

	public UniqueKeyCheckDao(EntityManager em) {
		this.em = em;
	}
	
	@SuppressWarnings("unchecked")
	public  List<BatchJobInfoEntity> checkBatchJobId(long batchJobId, String batchType) {
		Query q = em.createNamedQuery("NQ::batchjobInfo");
		q.setParameter("refId", batchJobId);
		q.setParameter("batchType", batchType);
		return (List<BatchJobInfoEntity>) q.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public  List<BatchJobInfoEntity> checkRequestId(long reqeustId, String batchType) {
		Query q = em.createNamedQuery("NQ::checkRequestId");
		q.setParameter("reqId", reqeustId);
		q.setParameter("batchType", batchType);
		return (List<BatchJobInfoEntity>) q.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public  List<PersonBiometricEntity> checkEnrollmentID(String enrollId) {
		Query q = em.createNamedQuery("NQ::checkEnrollmentID");
		q.setParameter("externalId ", enrollId);
	
		return (List<PersonBiometricEntity>) q.getResultList();
	}
	
	
	
	

	
}
