package jp.co.nec.aim.mm.procedure;

import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.segment.sync.CatchUpInfo;
import jp.co.nec.aim.mm.segment.sync.SegDiffPara;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;
import oracle.sql.NUMBER;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.object.StoredProcedure;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * Get the segment template history that version between <br>
 * latest and report version (batch fetch with MULTIP-SEGMENT ID)
 * 
 * @author liuyq
 * 
 */
public class GetSegCatupInfoProcedure extends StoredProcedure {

	/** SQL **/
	private static final String SQL = "MATCH_MANAGER_API.GET_SEG_CATCHUP_INFO";
	private List<SegDiffPara> segDiffParas = Lists.newArrayList(); // input
																	// parameter
	private int unitType;

	private static final String SEGDIFF_TABLE_TYPE = "SEGMENTDIFF_TABLE_TYPE";
	private static final String SEGDIFF_OBJECT = "SEGMENTDIFF";

	/**
	 * GetSegCatupInfoProcedure constructor
	 * 
	 * @param dataSource
	 *            DataSource instance
	 */
	public GetSegCatupInfoProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
				new CursorMapper()));
		declareParameter(new SqlParameter("p_component_type", Types.INTEGER));
		declareParameter(new SqlParameter("p_seg_diffs", Types.ARRAY,
				SEGDIFF_TABLE_TYPE));

		compile();
	}

	@SuppressWarnings("unchecked")
	public List<CatchUpInfo> execute() {
		if (CollectionsUtil.isEmpty(segDiffParas)) {
			throw new AimRuntimeException("segDiffParas is null or empty"
					+ " when call GetSegCatupInfoProcedure");
		}

		final Map<String, Object> map = Maps.newHashMap();
		map.put("p_component_type", getUnitType());
		map.put("p_seg_diffs", new AbstractSqlTypeValue() {
			public Object createTypeValue(Connection con, int sqlType,
					String typeName) throws SQLException {
				return createSegDiffType(con);
			}
		});
		return (List<CatchUpInfo>) (execute(map).get("p_refcursor"));
	}

	/**
	 * getSegDiffParas
	 * 
	 * @return SegDiffPara list
	 */
	public List<SegDiffPara> getSegDiffParas() {
		return segDiffParas;
	}

	/**
	 * create SEGMENTDIFF_TABLE_TYPE for MATCH_MANAGER_API.get_seg_catchup_info
	 * 
	 * @param con
	 *            the instance of Connection
	 * 
	 * @throws SQLException
	 */
	private Array createSegDiffType(Connection con) throws SQLException {
		OracleConnection oraConn = con.unwrap(OracleConnection.class);
		List<Struct> structs = Lists.newArrayList();
		for (SegDiffPara item : segDiffParas) {
			NUMBER segNumber = oraConn.createNUMBER(item.getSegmentId());
			NUMBER repNumber = oraConn.createNUMBER(item.getReportVersion());
			NUMBER latNumber = oraConn.createNUMBER(item.getLatestVersion());

			Struct struct = oraConn.createStruct(SEGDIFF_OBJECT, new Object[] {
					segNumber, repNumber, latNumber });
			structs.add(struct);
		}
		return oraConn.createARRAY(SEGDIFF_TABLE_TYPE, structs.toArray());
	}

	public int getUnitType() {
		return unitType;
	}

	public void setUnitType(int unitType) {
		this.unitType = unitType;
	}

	/**
	 * CursorMapper
	 * 
	 * @author liuyq
	 * 
	 */
	private class CursorMapper implements RowMapper<CatchUpInfo> {
		@Override
		public CatchUpInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			final CatchUpInfo catchup = new CatchUpInfo();
			long segId = rs.getLong("SEGMENT_ID");
			if (segId <= 0) {
				return null;
			}
			long templateId = rs.getLong("BIOMETRICS_ID");
			long version = rs.getLong("SEGMENT_VERSION");
			int type = rs.getInt("CHANGE_TYPE");
			byte[] templateBytes = rs.getBytes("BIOMETRIC_DATA");
			String externalId = rs.getString("EXTERNAL_ID");
			int eventId = rs.getInt("EVENT_ID");

			catchup.setEventId(eventId);
			catchup.setSegmentId(segId);
			catchup.setTemplateId(templateId);
			catchup.setVersion(version);
			catchup.setCommand(type);
			catchup.setBytes(templateBytes);
			catchup.setExternalId(externalId);
			return catchup;
		}
	}

}
