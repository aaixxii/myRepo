package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;

/**
 * @author Erik Vandekieft
 */
// sample code always seems to have primary keys implement Serializable...
// unsure why Hibernate would need this.
@SuppressWarnings("serial")
public class UnitSegReportPK implements Serializable {
	private long unitId;
	private long segmentId;

	@Column(name = "UNIT_ID")
	public long getUnitId() {
		return unitId;
	}

	public void setUnitId(long unitId) {
		this.unitId = unitId;
	}

	@Column(name = "SEGMENT_ID")
	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (obj == null || obj.getClass() != this.getClass())
			return false;
		UnitSegReportPK other = (UnitSegReportPK) obj;
		return other.getUnitId() == getUnitId()
				&& other.getSegmentId() == getSegmentId();
	}

	public int hashCode() {
		return (int) unitId + (int) segmentId;
	}
}
