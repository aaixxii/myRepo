package jp.co.nec.aim.mm.acceptor.service;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;

import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;
import jp.co.nec.aim.mm.common.AimManager;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UniqueKeyCheckDao;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeResultEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.Deflater;
import jp.co.nec.aim.mm.util.PBStateUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Sets;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

/**
 * AimExtractService <br>
 * The main work flow of Extract <br>
 * 
 * Include following public method:
 * <p>
 * extract, getJobStatus, listJobIds, deleteJob clearJobs, getJobBinary,
 * getJobResult
 * <p>
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimExtractService {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AimInquiryService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private FunctionDao functionDao;
	private SystemConfigDao configDao;
	private FEJobDao feJobDao;
	private AcceptorValidator validator;
	private DateDao dateDao;
	private UniqueKeyCheckDao uniqueKeyCheckDao;
	private ExceptionHelper exception;

	/**
	 * AimExtractService constructor
	 */
	public AimExtractService() {
	}

	@PostConstruct
	private void init() {
		functionDao = new FunctionDao(manager);
		configDao = new SystemConfigDao(manager);
		feJobDao = new FEJobDao(manager);
		validator = new AcceptorValidator(manager, dataSource);
		dateDao = new DateDao(dataSource);
		uniqueKeyCheckDao = new UniqueKeyCheckDao(manager);
		exception = new ExceptionHelper(dateDao);
	}

	/**
	 * the main work flow of extract
	 * 
	 * @param request
	 *            PBExtractJobRequest instance
	 * @return PBExtractJobResponse instance
	 */
	public Long extract(ExtractRequest request,
			boolean isFromServlet) {
		long batchJobId = request.getBatchJobId();
		String batchType = request.getType().name();
		if (!batchType.toUpperCase().equals(BatchType.EXTRACT.name())) {
			exception.throwArgException(AimError.EXTRACT_BATCH_TYPE_MISS_MATCH); //Xia
		}
		List<BatchJobInfoEntity> existList = uniqueKeyCheckDao.checkBatchJobId(batchJobId, "EXTRACT");
		if (existList.size() > 1 ) {
			exception.throwArgException(AimError.EXTRACT_BATCH_TYPE_MISS_MATCH); //Xia
		}
		PBBusinessMessage pbm = null;		
		try {
			pbm = PBBusinessMessage.parseFrom(request.getBusinessMessage(0));			
		} catch (InvalidProtocolBufferException e) {			
			exception.throwArgException(AimError.EXTRACT_BATCH_TYPE_MISS_MATCH); //Xia
		}
		
		try {
			if (Objects.isNull(pbm.getRequest().getBiometricsData().getBiometricElement().getFilePath())) {
				exception.throwArgException(AimError.EXTRACT_BATCH_TYPE_MISS_MATCH); //Xia
			}
		} catch (Exception e) {
			exception.throwArgException(AimError.EXTRACT_BATCH_TYPE_MISS_MATCH); //Xia
		}
		
		final FeJobQueueEntity ejq = new FeJobQueueEntity();
		FunctionTypeEntity fte = functionDao.getExtractFunction();
		if (fte == null) {
			throw new AimRuntimeException(
					"Extract function not registered in the database.");
		}
		ejq.setFunctionId((int) fte.getId());
		ejq.setReferenceId(pbm.getRequest().getEnrollmentId());//??
		ejq.setStatus(JobState.QUEUED);
		ejq.setFailureCount(0l);		
		ejq.setSubmissionTs(dateDao.getCurrentTimeMS());		
		manager.persist(ejq);

		FeJobPayloadEntity epe = new FeJobPayloadEntity();
		epe.setPayload(request.toByteArray());
		epe.setJobId(ejq.getId());
		manager.persist(epe);
		// manager.flush();
		BatchJobInfoEntity batchInfo = new BatchJobInfoEntity();
		batchInfo.setBatchJobId(request.getBatchJobId());
		batchInfo.setBatchType(request.getType().name());
		batchInfo.setReqeustId(pbm.getRequest().getRequestId());
		batchInfo.setInternalJobId(fte.getId());
		manager.persist(batchInfo);		

		// send event to extract planner
		JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
				String.format("create extract job id: %s", ejq.getId()));

		return Long.valueOf(fte.getId());
	}

	/**
	 * delete extract Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(PBDeleteJobRequest request) {
		try {
			feJobDao.deleteExtractJob(request.getJobId());
		} catch (Exception ex) {
			exception.throwDBException(AimError.EXTRACT_DB, ex,
					"Exception occurred when delete extract job.");
		}
	}

	/**
	 * clear all extract Jobs
	 */
	public void clearJobs() {
		try {
			feJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.EXTRACT_DB, ex,
					"Exception occurred when clear extract job.");
		}
	}



	/**
	 * throwFeResultNoFoundException
	 */
	private void throwFeResultNoFoundException() {
		final String error = "Extract result was not found in [FE_RESULT].";
		log.error(error);
		throw new AimRuntimeException(error);
	}

	/**
	 * confirm the TemplateIndex
	 * 
	 * @param t
	 * @return
	 */
	private int confirmTemplateIndex(final PBKeyedTemplate t) {
		PBKeyedTemplateIndexer indexr = t.getIndexer();
		int templateIndex = 0;
		if (indexr.hasFingerPrintType()) {
			templateIndex = indexr.getFingerPrintType().getNumber();
		} else if (indexr.hasPosition()) {
			templateIndex = indexr.getPosition().getNumber();
		} else if (indexr.hasIndex()) {
			templateIndex = indexr.getIndex();
		}
		return templateIndex;
	}

	/**
	 * setResponseWithjobId
	 * 
	 * @param b
	 *            Builder
	 * @param jobId
	 *            jobId
	 */
//	private void setKeyedTemplate(Builder b, List<FeResultEntity> results) {
//		if (CollectionsUtil.isNotEmpty(results)) {
//			for (FeResultEntity feResultEntity : results) {
//				PBKeyedTemplate.Builder builder = PBKeyedTemplate.newBuilder();
//				builder.setTemplateBinary(ByteString.copyFrom(feResultEntity
//						.getResultData()));
//				TemplateFormatType key = null;
//				try {
//					key = TemplateFormatType.valueOf(feResultEntity
//							.getTemplateKey());
//				} catch (Exception e) {
//					exception.throwArgException(
//							AimError.EXTRACT_RESULT_TEMPLATE_KEY,
//							feResultEntity.getTemplateKey());
//				}
//				builder.setKey(key);
//				int index = feResultEntity.getTemplateIndex();
//				if (index != 0) {
//					setIndexr(key, builder, index);
//				}
//				b.addKeyedTemplate(builder);
//			}
//		}
//	}

	/**
	 * set PBKeyedTemplateIndexer
	 * 
	 * @param request
	 *            TemplateFormatType key PBKeyedTemplate.Builder builder int
	 *            indexr
	 */
	private void setIndexr(TemplateFormatType key,
			PBKeyedTemplate.Builder builder, int indexr) {
		switch (key) {
		case TEMPLATE_TI:
		case TEMPLATE_TIM:
		case TEMPLATE_TLI:
		case TEMPLATE_TLIS:
		case TEMPLATE_TLIM:
		case TEMPLATE_RDBT:
		case TEMPLATE_RDBTM:
			if (indexr != FingerPrintType.FINGER_PRINT_ROLLED_VALUE
					&& indexr != FingerPrintType.FINGER_PRINT_SLAP_VALUE) {
				exception.throwArgException(AimError.EXTRACT_RESULT_INDEX,
						indexr);
			}
			builder.setIndexer(PBKeyedTemplateIndexer.newBuilder()
					.setFingerPrintType(FingerPrintType.valueOf(indexr)));
			break;
		case TEMPLATE_RDBL:
		case TEMPLATE_RDBLS:
		case TEMPLATE_RDBLM:
		case TEMPLATE_PDB:
			ImagePositionType[] positionTypes = ImagePositionType.values();
			Set<Integer> set = Sets.newHashSet();
			for (ImagePositionType positionType : positionTypes) {
				set.add(positionType.getNumber());
			}
			if (!set.contains(indexr)) {
				exception.throwArgException(AimError.EXTRACT_RESULT_INDEX,
						indexr);
			}
			builder.setIndexer(PBKeyedTemplateIndexer.newBuilder().setPosition(
					ImagePositionType.valueOf(indexr)));
			break;
		case TEMPLATE_FDB:
			builder.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(
					indexr));
			break;
		default:
			break;
		}
	}

//	public ExtractResponse unPressesPayloadExResult(
//			byte[] compressedPayloadExResut) throws IOException {
//		byte[] compressedOutputPayload = null;
//		ExtractResponse.Builder newPBExtractJobResult = ExtractResponse
//				.newBuilder();
//		PBMuExtractJobResult pbExInternal = PBMuExtractJobResult
//				.parseFrom(ByteString.copyFrom(compressedPayloadExResut));
//		
//		
//		
//		if (pbExInternal.hasCompressedOutputPayload()) {
//			compressedOutputPayload = pbExInternal.getCompressedOutputPayload()
//					.toByteArray();
//			byte[] uncompressedOutputPayload = Deflater
//					.uncompress(compressedOutputPayload);
//			newPBExtractJobResult.setOutputPayload(PBExtractOutputPayload
//					.parseFrom(uncompressedOutputPayload));
//		}
//		newPBExtractJobResult.setServiceState(pbExInternal.g);
//		newPBExtractJobResult.setJobId(pbExInternal.);
//		newPBExtractJobResult.addAllKeyedTemplate(pbExInternal
//				.getKeyedTemplateList());
//		return newPBExtractJobResult.build();
//	}
}
