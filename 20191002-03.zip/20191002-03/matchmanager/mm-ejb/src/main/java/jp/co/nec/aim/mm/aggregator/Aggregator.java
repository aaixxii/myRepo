package jp.co.nec.aim.mm.aggregator;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidateList;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidate;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateTemplate;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatistics;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatisticsAMR;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.mm.common.AimManager;
import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.constants.FunctionFamily;
import jp.co.nec.aim.mm.constants.JobCallbackSender;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.AggregatorDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.logger.JobDoneLogger;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.procedure.ContainerJobResult;
import jp.co.nec.aim.mm.result.DynamicThresholdParams;
import jp.co.nec.aim.mm.result.HitMarking;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.JAXBHelper;
import jp.co.nec.aim.mm.util.StopWatch;
import jp.co.nec.aim.mm.util.TimeHelper;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.protobuf.InvalidProtocolBufferException;

/**
 * 
 * @author jinxl
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class Aggregator {

	private static Logger log = LoggerFactory.getLogger(Aggregator.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource ds;
	private InquiryJobDao inquiryJobDao;
	private AggregatorDao aggregatorDao;
	private SystemConfigDao systemConfigDao;
	
	private final static String L_SUCCESS_PROCESS = "p_success_refcursor";

	@PostConstruct
	public void init() {
		inquiryJobDao = new InquiryJobDao(manager);
		aggregatorDao = new AggregatorDao(ds);
		systemConfigDao = new SystemConfigDao(manager);		
	}
	
	/**
	 * Aggregation main flow control
	 * 
	 * @param topJobId
	 */
	@Asynchronous	
	public void doAggregation(long jobId) {
		long threadId = Thread.currentThread().getId();
		boolean isSuccess = true;
		try {
			doAggregationCore(jobId);
		} catch (Throwable e) {
			isSuccess = false;
			String errMessg = String
					.format("Any exception occured during aggregation. jobId=%d threadId=%d",
							jobId, threadId);
			log.error(errMessg, e);
			throw new AimRuntimeException(e);
		} finally {
			if (isSuccess) {
				log.info(
						"Finished aggregation thread. jobId={} threadId={}",
					jobId, threadId);
			} else {
				log.warn(
						"Finished aggregation thread with unexpected exception. jobId={} threadId={}",
						jobId, threadId);
			}
		}
	}

	/**
	 * doAggregation
	 * 
	 * @param topLevelJobId
	 */
	public void doAggregationCore(long topLevelJobId) {
		long threadId = Thread.currentThread().getId();
		log.info("prepare aggregation top job(Id={}) results....",
				topLevelJobId);

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		
		JobQueueEntity jobQueue = null;
		if (log.isDebugEnabled()) {
			log.debug(
					"Fetch JOB_QUEUE record for aggregation. jobId={} threadId={}",
					topLevelJobId, threadId);
		}
		try {
			/* check topJob is or not exist */
			jobQueue = inquiryJobDao.getTopLevelJob(topLevelJobId);
			if (jobQueue == null) {
				log.warn(
						"Job {} queued for aggregation not found, skip aggaregation!",
						topLevelJobId);
				return;
			}

			if (jobQueue.getJobState().equals(JobState.DONE)) {
				log.warn("Job {} already be DONE, skip to aggregation.",
						topLevelJobId);
				return;
			}
		} catch (Exception ex) {
			String errMessg = String
					.format("An error occoured during find JOB_QUEUE record for aggregation. jobId=%d threadId=%d",
							topLevelJobId, threadId);
			throw new AimRuntimeException(errMessg, ex);
		}

		PBBusinessMessage.Builder lastPBBusinesMsg = PBBusinessMessage.newBuilder();
		List<PBCandidate> toBeAggregtedList = Lists.newArrayList();
		IdentifyResponse.Builder inquiryJobResult = IdentifyResponse.newBuilder();	

		boolean haveMerge = getAllContainerJobs(topLevelJobId,toBeAggregtedList, lastPBBusinesMsg.build());			

		if (haveMerge) {	
				if (log.isDebugEnabled()) {
					log.debug("Last merging. jobId={}, threadId={}.",
						topLevelJobId, threadId);
				}						
				toBeAggregtedList.stream().sorted(new SameCandidateMergeComparator());
				//Collections.sort(toBeAggregtedList, new SameCandidateMergeComparator());				
				final List<PBCandidate> samekeyMergedList = Lists.newArrayList();				
				Map<String, List<PBCandidate>> grpByType = toBeAggregtedList.stream().collect( Collectors.groupingBy(PBCandidate::getEnrollmentId));
		               
				grpByType.entrySet().parallelStream().forEach(entry -> {
					//Predicate<PBCandidate> predicate = one -> one.getScaledScore() > 0;
                   PBCandidate maxCandidate = entry.getValue().stream().sorted(new CandidateLastComparator()).findFirst().get();
                   samekeyMergedList.add(maxCandidate);
				});
				
				samekeyMergedList.stream().sorted(new CandidateLastComparator());
				buildClientIdentifyResponse(samekeyMergedList, );
				
			

				//merge to maxcandidate
	
			
		} else {
			//static only
			log.warn("No CandidateList found in search job results, "
							+ "skip aggregation and callback to client. jobId={} threadId={}",
					topLevelJobId, threadId);
		}

		doAfterMergeProcess(inquiryJobResult.build(), jobQueue);

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doAggregationCore",
				stopWatch.elapsedTime());
		return;
	}
	
	private void merge(List<PBCandidate> to) {
		
	}

	
	

	/**
	 * getAllContainerJobs
	 * 
	 * @param topJobId
	 * @param inquiryJobResultInternal
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean getAllContainerJobs(long topJobId,List<PBCandidate> toBeAggregtedList) {		
		boolean lastErr = false;
		if (log.isDebugEnabled()) {
			log.debug("getAllContainerJobs start... jobId={}", topJobId);
		}
		TimeHelper th = new TimeHelper("getAllContainerJobs");
		th.t();

		/* get all Container Job INFO */
		Map<String, Object> objs = aggregatorDao.getAllContainerJobs(topJobId);

		List<ContainerJobResult> conTainerJobResults = Lists.newArrayList();

		if (objs.get(L_SUCCESS_PROCESS) != null) {
			conTainerJobResults = (List<ContainerJobResult>) objs.get(L_SUCCESS_PROCESS);
		}

		if (CollectionsUtil.isEmpty(conTainerJobResults)) {	
			log.warn("ContainerJob data in topLevelJobId="
					+ topJobId
					+ " is incorrect! It's no containerJobResult and failureReason!");

			lastErr = true;
		}

		List<PBBusinessMessage> inquiryPbBnsMesgList = Lists.newArrayList();

		boolean bHasErr = getJobResultState(conTainerJobResults,inquiryPbBnsMesgList);
				 

		// container job with failure information(has error)
		if (bHasErr) {
			log.warn(
					"ContainerJob data in topLevelJobId="
							+ topJobId
							+ " is incorrect! There is {} in all containerJob result!");
			lastErr = true;	
			
		}
	
		// container job done successfully(without error)
		for (PBBusinessMessage pbMsg : inquiryPbBnsMesgList) {
			if (!emptyPbmsgIsSeted) {
				if (pbMsg.getResponse().getStatus().toLowerCase().contains("success")) {
					PBRequest.Builder request = PBRequest.parseFrom(pbMsg.getRequest().toByteArray())
					
					try {
						emptyPbmsg = PBBusinessMessage.parseFrom(pbMsg.toByteArray());
					} catch (InvalidProtocolBufferException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
						
				emptyPbmsg = pbMsg;
			}
			

//			if (!resultlist.hasStatistics()) {
//				if (log.isDebugEnabled()) {
//					log.debug(
//							"Statistics of InquiryJobResultInternal is null. jobId={}",
//							topJobId);
//				}
//				continue;
//			}
//
//			// get original Arm
//			PBInquiryResultStatisticsAMR origAmr = inquiryJobResultInternal
//					.getStatistics().getAmr();
//			// get superimposed Arm
//			PBInquiryResultStatisticsAMR superAmr = resultlist.getStatistics()
//					.getAmr();
//			long sumMatchCount = origAmr.getMatchCount()
//					+ superAmr.getMatchCount();
//			long sumReadCount = origAmr.getReadCount()
//					+ superAmr.getReadCount();
//
//			inquiryJobResultInternal.getStatisticsBuilder().getAmrBuilder()
//					.setMatchCount(sumMatchCount).setReadCount(sumReadCount);
//
//			if (!resultlist.hasCandidateList()) {
//				log.warn(
//						"ContainerJob result's candiateList is null or empty. topLevelJobId={}",
//						topJobId);
//				continue;
//			}
			if (!pbMsg.getResponse().getStatus().toLowerCase().contains("success")) {
				lastErr = true;
			}
			
			if (pbMsg.getDataBlock().hasCandidateList()) {
				PBCandidateList pbMsgCandites = pbMsg.getDataBlock().getCandidateList();
				toBeAggregtedList.addAll(pbMsgCandites.getCandidatesList());
			}
		}
	
		th.t();
		if (log.isDebugEnabled()) {
			log.debug(th.message());
			log.debug("getAllContainerJobs end. rtn=true. jobId={}", topJobId);
		}
		return lastErr;
	}

	private boolean getJobResultState(List<ContainerJobResult> containerJobResults, List<PBBusinessMessage> empityPbBsnMsgList) {			
		boolean hasErr = false;			
		for (ContainerJobResult containJob : containerJobResults) {
			PBBusinessMessage jobResultInternal = null;
			try {
				if (null == containJob.getContainerJobsResult()) {
					continue;
				}				
				jobResultInternal = PBBusinessMessage.parseFrom(containJob.getContainerJobsResult());
				empityPbBsnMsgList.add(jobResultInternal);
				if (jobResultInternal.getDataBlock().getDataGroupCount() > 0) {
					List<PBDataGroup> gpList = jobResultInternal.getDataBlock().getDataGroupList();	
					gpList.forEach(one -> {
						List<PBDataElement> dataElementList = one.getDataElementList();
					});
					//ToDo 
				}				
				if (!jobResultInternal.getResponse().getStatus().toLowerCase().contains("success")) {
					hasErr = true;
				}

			} catch (InvalidProtocolBufferException e) {
				throw new AimRuntimeException(
						"InvalidProtocolBufferException occurred "
								+ "when parseFrom PBInquiryJobResultInternal instance",
						e);
			}
		}	
		return hasErr;
	}

	private void doAfterMergeProcess(IdentifyResponse pBInquiryJobResult,
			JobQueueEntity jobQueue) {
		long threadId = Thread.currentThread().getId();
		if (log.isDebugEnabled()) {
			log.debug("doAfterMergeProcess start... jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}

		TimeHelper th = new TimeHelper("doAfterMergeProcess");
		th.t();

		byte[] inquiryJobResult = pBInquiryJobResult.toByteArray();

		if (log.isDebugEnabled()) {
			log.debug(
					"Setting final results to JOB_QUEUE record.. jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}
		PBBusinessMessage pbMsg = null;
		try {
			pbMsg = PBBusinessMessage.parseFrom(pBInquiryJobResult.getBusinessMessage(0).toByteArray());
		} catch (InvalidProtocolBufferException e) {
			// ToDo respose err
			
		}		
		boolean bState = pbMsg.getResponse().getStatus().toLowerCase().contains("success");

		aggregatorDao.callCompleteTopLevelJob(jobQueue.getJobId(),
				inquiryJobResult, !bState);

		manager.refresh(jobQueue);

		JobDoneLogger jobDoneLogger = new JobDoneLogger(ds);
		jobDoneLogger.info(jobQueue, pBInquiryJobResult,
				inquiryJobDao.findMinFunctionId(jobQueue.getJobId()));
		th.t();
		AimManager.responseInquiyJobResult(jobQueue.getJobId(), pBInquiryJobResult);
		AimManager.finishInquiryJob(jobQueue.getJobId());
		if (ConfigProperties.getInstance().isPropertyValue(
				ConfigPropertyNames.IS_PURGE_CONTAINER_JOBS)
				&& bState) {
			inquiryJobDao.clearAllContainerJob(jobQueue.getJobId());
		}

		/* send Jms to IdentifyPlanner */
		JmsSender.getInstance().sendToInquiryJobPlanner(
				NotifierEnum.Aggregator, "send Msg to IdentifyPlanner");
		th.t();

		if (log.isDebugEnabled()) {
			log.debug(th.message());
			log.debug("doAfterMergeProcess end... jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}
	}
}




class SameCandidateMergeComparator implements Comparator<PBCandidate> {
	@Override
	public int compare(PBCandidate o1,
			PBCandidate o2) {
		int first = o1.getEnrollmentId().compareTo(o2.getEnrollmentId());
		int second = first == 0 ? Integer.valueOf(o2.getScaledScore())
				.compareTo(Integer.valueOf(o1.getScaledScore())) : first;
		return second;
	}
}



class CandidateLastComparator implements Comparator<PBCandidate> {
	@Override
	public int compare(PBCandidate o1, PBCandidate o2) {
		int first = Integer.valueOf(o2.getScaledScore()).compareTo(
				Integer.valueOf(o1.getScaledScore()));
		int second = first == 0 ? o1.getEnrollmentId().compareTo(
				o2.getEnrollmentId()) : first;
		return second;
	}
}