package jp.co.nec.aim.mm.acceptor.script;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "deletion-script-item", propOrder = { "templateFormat",
		"fingerPrint", "position", "containerSpec" })
public class DeletionScriptItem {
	@XmlElement(required = true)
	protected String templateFormat;
	@XmlElement
	protected String fingerPrint;
	@XmlElement
	protected String position;

	@XmlElement(required = true)
	protected ContainerSpec containerSpec;

	/**
	 * getTemplateFormat
	 * 
	 * @return
	 */
	public String getTemplateFormat() {
		return templateFormat;
	}

	public void setTemplateFormat(String templateFormat) {
		this.templateFormat = templateFormat;
	}

	public String getFingerPrint() {
		return fingerPrint;
	}

	public void setFingerPrint(String fingerPrint) {
		this.fingerPrint = fingerPrint;
	}

	/**
	 * Gets the value of the containerSpec property.
	 * 
	 * @return possible object is {@link ContainerSpec }
	 * 
	 */
	public ContainerSpec getContainerSpec() {
		return containerSpec;
	}

	/**
	 * Sets the value of the containerSpec property.
	 * 
	 * @param value
	 *            allowed object is {@link ContainerSpec }
	 * 
	 */
	public void setContainerSpec(ContainerSpec value) {
		this.containerSpec = value;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

}
