CREATE USER 'g6db'@'%' IDENTIFIED BY 'g6db00';
grant all privileges on commondb.* to 'g6db'@'%';
grant all privileges on g6db.* to 'g6db'@'%';
flush privileges;
