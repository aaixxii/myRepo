create database commondb character set utf8mb4;
create database g6db character set utf8mb4;
create database ghs character set utf8mb4;