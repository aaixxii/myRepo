package jp.co.nec.aim.mm.sessionbeans.pojo;

public class AimServiceState {
	private String errMsg;
	private String errorcode;
	private String failureTime;
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	public String getFailureTime() {
		return failureTime;
	}
	public void setFailureTime(String failureTime) {
		this.failureTime = failureTime;
	}
	
	public AimServiceState (String errMsg, String errCode, String faileTime) {
		this.errMsg = errMsg;
		this.errorcode = errCode;
		this.failureTime = faileTime;
	}
	
	public AimServiceState() {
		
	}
}
