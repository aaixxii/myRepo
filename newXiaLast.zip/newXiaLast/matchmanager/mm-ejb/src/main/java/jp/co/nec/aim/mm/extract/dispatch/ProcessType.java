package jp.co.nec.aim.mm.extract.dispatch;

public enum ProcessType {
	UPDATE, EXTRACT, IDENTIFY, MANAGEMENY
}
