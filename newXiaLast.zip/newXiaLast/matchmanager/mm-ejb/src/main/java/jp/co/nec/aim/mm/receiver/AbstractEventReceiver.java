package jp.co.nec.aim.mm.receiver;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

import jp.co.nec.aim.mm.spring.jms.AsynchHTTPJMSMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;

/**
 * <ul>
 * AbstractEventReceiver
 * </ul>
 * 
 * The first event could be handle when multip-threading message is reached in
 * the Period. the other events will be dropped due to those events owns the
 * same function. If next Period events was reached again when previous event
 * was remain working, wait until Period event is done. Drop Next Period events
 * is not allowed..
 * 
 * @author liuyq
 * 
 */
public abstract class AbstractEventReceiver implements MessageListener {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AbstractEventReceiver.class);

	private static final SimpleDateFormat FORMAT = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss-SSS");

	/** lockManager used for save each class locker **/
	private static final Map<Class<? extends MessageListener>, LockTimer> lockManager = Maps
			.newConcurrentMap();

	/** ReentrantLock instance **/
	private final LockTimer lock;

	/**
	 * the default constructor
	 */
	public AbstractEventReceiver() {
		final Class<? extends MessageListener> clazz = this.getClass();
		// lock must be singleton category by class due to MDB has
		// mutilp-instance, one MDB own the one lock, for example
		// SlbEventReceiver own the locker and FePlannerEventReceiver own
		// another locker
		synchronized (clazz) {
			if (!lockManager.containsKey(clazz)) {
				lockManager.put(clazz, new LockTimer(true));
			}
			this.lock = lockManager.get(clazz);
		}
	}

	@Override
	public void onMessage(Message message) {
		// the Period message reached in mutlip-thread
		// once a thread get the locker, the other
		// threads tryLock will return false and
		// skip do dispatchEvent..
		if (lock.tryLock()) {
			try {
				lock.set(getCurrentTime());
				logMessage(message);
				dispatchEvent();
				// //////////////////////////////////////////////////////
				// only record for the count of event and planner execution
				// //////////////////////////////////////////////////////
				logEventCount(message);
				// //////////////////////////////////////////
			} catch (Exception e) {
				log.error("Exception occurred when dispatchEvent.", e);
			} finally {
				lock.unlock();
				synchronized (lock) {
					lock.notifyAll();
				}
			}
		} else {
			try {
				// if the new event reached and in another message Period->
				// deliveryTime >= first event reached time, call on message is
				// necessary, otherwise remove and consume this event due to
				// event owns the same function
				long deliveryTime = message.getJMSDeliveryTime();
				if (deliveryTime >= lock.get()) {
					if (log.isDebugEnabled()) {
						log.debug("the new event has reached, "
								+ "Ready to call onMessage again until previous event is done..");
					}

					long before = getCurrentTime();
					synchronized (lock) {
						try {
							lock.wait();
						} catch (InterruptedException e) {
							log.error("InterruptedException occurred.", e);
						}
					}
					long after = getCurrentTime();
					message.setJMSDeliveryTime(deliveryTime - (after - before));
					onMessage(message);
				} else {
					lock.increaseEventCount();
					if (log.isDebugEnabled()) {
						log.debug("Consume and Remove Message:{} ",
								message.getJMSMessageID());
					}
				}
			} catch (JMSException e) {
				log.error("JMSException occurred when getJMSMessageID..", e);
			}
		}
	}

	/**
	 * get current epoch time
	 * 
	 * @return current epoch time
	 */
	private long getCurrentTime() {
		return new Date().getTime();
	}

	/**
	 * log Message
	 * 
	 * @param message
	 *            the instance of Message
	 * @throws JMSException
	 *             JMSException
	 */
	private void logMessage(Message message) throws JMSException {
		if (message instanceof TextMessage) {
			TextMessage txtMsg = (TextMessage) message;
			if (log.isDebugEnabled()) {
				log.debug("Receive TextMessage: " + txtMsg.getText()
						+ ", message id:" + message.getJMSMessageID()
						+ ", Delivery Time:"
						+ formatDate(message.getJMSDeliveryTime()));
			}

			// if Re deliver message warn the message
			if (message.getJMSRedelivered()) {
				log.warn("This MDB message of " + txtMsg.getText()
						+ " was redelivered.");
			}
		} else {
			ObjectMessage objMsg = (ObjectMessage) message;
			AsynchHTTPJMSMessage asynchMessage = (AsynchHTTPJMSMessage) objMsg
					.getObject();
			if (log.isDebugEnabled()) {
				log.debug("Receive ObjectMessage: " + asynchMessage.toString()
						+ ", message id:" + message.getJMSMessageID()
						+ ", Delivery Time:"
						+ formatDate(message.getJMSDeliveryTime()));
			}

			// if Re deliver message warn the message
			if (message.getJMSRedelivered()) {
				log.warn("This MDB message of " + asynchMessage.toString()
						+ " was redelivered.");
			}
		}
	}

	/**
	 * Only record for the count of event and planner execution
	 * 
	 * @param message
	 *            the instance of Message
	 * @throws JMSException
	 */
	private void logEventCount(Message message) throws JMSException {
		lock.increaseAllCount();
		if (lock.get() > 0L) {
			if (log.isDebugEnabled()) {
				log.debug(
						"All event count: {}, Planner execute count: "
								+ "{} during the Period {} to {}.",
						new Object[] { lock.getEventCount(),
								lock.getPlanCount(),
								formatDate(message.getJMSDeliveryTime()),
								formatDate(getCurrentTime()) });
			}
			lock.clearCount(); // clear the execute count
		}
	}

	/**
	 * formatDate with epoch time
	 * 
	 * @param epoch
	 *            the epoch time
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	private String formatDate(long epoch) {
		return FORMAT.format(new Date(epoch));
	}

	/**
	 * Dispatcher event
	 * 
	 * @param event
	 */
	protected abstract void dispatchEvent();

	/**
	 * the locker for record the time
	 * 
	 * @author liuyq
	 * 
	 */
	static class LockTimer extends ExecuteCount {
		/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = 3426328681822819588L;
		/** used for save the first event time **/
		private final AtomicLong time;

		public LockTimer() {
			super();
			time = new AtomicLong(0);
		}

		public LockTimer(boolean isFair) {
			super(isFair);
			time = new AtomicLong(0);
		}

		public void set(long time) {
			this.time.set(time);
		}

		public long get() {
			return this.time.get();
		}
	}

	/**
	 * ExecuteCount for log the execute count of real event and planner
	 * 
	 * @author liuyq
	 * 
	 */
	static class ExecuteCount extends ReentrantLock {
		/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = 2757106621016634291L;
		private final AtomicInteger eventCount; // record the event count
												// in Period
		private final AtomicInteger planExecCount; // record the real execute
													// count in Period

		/**
		 * public constructor
		 */
		public ExecuteCount() {
			this.eventCount = new AtomicInteger(0);
			this.planExecCount = new AtomicInteger(0);
		}

		/**
		 * public constructor
		 */
		public ExecuteCount(boolean isFair) {
			super(isFair);
			this.eventCount = new AtomicInteger(0);
			this.planExecCount = new AtomicInteger(0);
		}

		/**
		 * 
		 */
		public void increaseEventCount() {
			this.eventCount.incrementAndGet();
		}

		/**
		 * 
		 */
		public void increasePlanCount() {
			this.planExecCount.incrementAndGet();
		}

		/**
		 * 
		 */
		public void increaseAllCount() {
			this.eventCount.incrementAndGet();
			this.planExecCount.incrementAndGet();
		}

		/**
		 * getEventCount
		 * 
		 * @return
		 */
		public int getEventCount() {
			return this.eventCount.get();
		}

		/**
		 * getPlanCount
		 * 
		 * @return
		 */
		public int getPlanCount() {
			return this.planExecCount.get();
		}

		/**
		 * clear the Count
		 */
		public void clearCount() {
			this.eventCount.set(0);
			this.planExecCount.set(0);
		}
	}

}
