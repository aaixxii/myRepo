package jp.co.nec.aim.mm.amq.service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

public class AmqServiceManager {	
	private  static final AmqServiceManager INSTANCE = new AmqServiceManager();	
	private static Logger logger = LoggerFactory.getLogger(AmqServiceManager.class);	
	public static AmqServiceManager getInstance() {
		return INSTANCE;
	}
	
	private final ConcurrentHashMap<String, Consumer<UidAimAmqResponse>> amqMap = new ConcurrentHashMap<>(); 	
	//private final  BlockingQueue<UidAimAmqResponse> amqQueue = new LinkedBlockingQueue<>(30);	
	
	public void registerAmqResGetter(String type, Consumer<UidAimAmqResponse> resGegger) {
		amqMap.put(type, resGegger);
	}
	
	public void addToAmqQueue(UidAimAmqResponse amqRes)  {	
	//boolean result = amqQueue.offer(amqRes);
		String type = amqRes.getRequestType();
	 amqMap.get(type).accept(amqRes);
	 logger.info("Call Amq UidAimAmqResponse Accept!");	 
	
	}	

	private final ConcurrentHashMap<String, Consumer<String>> amqXmlMap = new ConcurrentHashMap<>(); 
	//private final  BlockingQueue<String> amqXmlQueue = new LinkedBlockingQueue<>(30);
	
	public void registerXmlResGetter(String type, Consumer<String> xmlGegger) {
		amqXmlMap.put(type, xmlGegger);
	}
	
	public void addToAmqXmlQueue(String type, String amqRes)  {	
		//boolean result =  amqXmlQueue.offer(amqRes);
		amqXmlMap.get(type).accept(amqRes);
		logger.info("Call Amq Xml Response Accept!");		
	}
	
	public  String getAmqConfigFilePath() {
		String path = System.getProperty("jboss.server.config.dir") + "aim.mq.properties";	
		return path;
	}	
}
