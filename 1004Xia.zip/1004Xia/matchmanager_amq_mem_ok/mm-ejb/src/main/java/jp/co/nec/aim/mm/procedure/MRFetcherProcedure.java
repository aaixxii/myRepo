package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.entities.MapReducerEntity;

/**
 * MRFetcherProcedure
 * 
 * @author liuyq
 * 
 */
public class MRFetcherProcedure extends StoredProcedure {   
	/** sql **/
	private static final String SQL = "get_next_mr_position";

	/**
	 * MRFetcherProcedure constructor
	 * 
	 * @param dataSource
	 */
	public MRFetcherProcedure(DataSource dataSource) {		
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlOutParameter("o_mr_id", Types.INTEGER));	
		declareParameter(new SqlOutParameter("o_contact_url", Types.VARCHAR));	
		compile();		
	}

	/**
	 * execute
	 * 
	 * @return MapReducerEntity instance
	 */
	public MapReducerEntity execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> resultMap = execute(map);
		int mrId =  (int) resultMap.get("o_mr_id");
		String mrUrl = (String) resultMap.get("o_contact_url");			
		MapReducerEntity mp = new MapReducerEntity();
		mp.setMrId(mrId);
		mp.setContactUrl(mrUrl);
		return mp;	
	}

	/**
	 * CursorMapper
	 * 
	 * @author liuyq
	 * 
	 */
	@SuppressWarnings("unused")
	private class CursorMapper implements RowMapper<MapReducerEntity> {
		@Override
		public MapReducerEntity mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			long mrId = rs.getLong("MR_ID");
			if (mrId <= 0) {
				return null;
			}
			String contactUrl = rs.getString("CONTACT_URL");
			return new MapReducerEntity(mrId, contactUrl);
		}
	}

}
