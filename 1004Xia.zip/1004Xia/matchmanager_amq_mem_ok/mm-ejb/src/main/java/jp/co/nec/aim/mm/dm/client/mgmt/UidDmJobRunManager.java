package jp.co.nec.aim.mm.dm.client.mgmt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UidDmJobRunManager {

	private static Logger logger = LoggerFactory.getLogger(UidDmJobRunManager.class);
	private static ExecutorService dmJobExecutor = Executors.newCachedThreadPool();
	
	private static final ScheduledExecutorService httpHeatbeatScheduler = Executors.newScheduledThreadPool(1);
	private static ExecutorService socketHeatbeatExcutor;
	private static List<String> activeDmSeriveList = Collections.synchronizedList(new ArrayList<String>());
	private static final ConcurrentHashMap<String, String> dmsUrlMap = new ConcurrentHashMap<>(); //key is dmsId + methodName(dms1_sync), value is url like:http://ip:port/dm//dmSyncSegment
	private static ReentrantLock locker = new ReentrantLock();
	
	public static void putToDmsUrlMap(String key, String value) {
		dmsUrlMap.putIfAbsent(key, value);		
	}
	
	public static String getValueFromDmsUrlMap(String key) {
		return dmsUrlMap.get(key);
	}	
	
	public static void setSocketHeatbeatExector(int count) {
		socketHeatbeatExcutor = Executors.newFixedThreadPool(count);
	}

	public static void sumitSocketHeatbeatJobToMe(Runnable task) {
		socketHeatbeatExcutor.submit(task);
	}

	public static void httpHeatbeatSheduleTask(Runnable task, long rate) {
		httpHeatbeatScheduler.scheduleAtFixedRate(task, 0, rate, TimeUnit.MILLISECONDS);
	}

	public static void addActiveDmServiceTome(String baseUrl) {
		if (!activeDmSeriveList.contains(baseUrl)) {
			locker.lock();
			try {
				activeDmSeriveList.add(baseUrl);
			} finally {
				locker.unlock();
			}
		}
	}

	public static void removeDmServiceFromMe(String baseUrl) {
		if (activeDmSeriveList.contains(baseUrl)) {
			locker.lock();
			try {
				activeDmSeriveList.remove(baseUrl);
			} finally {
				locker.unlock();
			}
		}
	}

	public static int getActiveServiceCount() {
		locker.lock();
		try {
			return activeDmSeriveList.size();
		} finally {
			locker.unlock();
		}	
	}

	public static void updateActiveDmSeriveList(List<String> workingDms) {
		locker.lock();
		try {
			activeDmSeriveList.clear();
			activeDmSeriveList.addAll(workingDms);
		} finally {
			locker.unlock();
		}

	}

	public static String getOneActiveDm() {
		if (activeDmSeriveList.size() < 0)
			return null;
		locker.lock();
		try {
			Collections.shuffle(activeDmSeriveList);
			
			return activeDmSeriveList.get(0);
		} finally {
			locker.unlock();
		}	
	}

	public static void submitRunnable(Runnable task) {
		dmJobExecutor.submit(task);
	}

	public static Boolean sumitDmJob(Callable<Boolean> task) {
		Future<Boolean> future = dmJobExecutor.submit(task);
		try {
			return future.get();
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.FALSE;
		}
	}

	public static <T> CompletableFuture<T> callableAsync(Callable<T> c) {
		CompletableFuture<T> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());

			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf;
	}

	public static Boolean submit(Callable<Boolean> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Boolean> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

	public static byte[] submitGetRequest(Callable<byte[]> c) throws InterruptedException, ExecutionException {
		CompletableFuture<byte[]> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

	public static void shutdown() {
		dmJobExecutor.shutdownNow();
		while (!dmJobExecutor.isShutdown()) {
			try {
				dmJobExecutor.awaitTermination(100, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		httpHeatbeatScheduler.shutdownNow();
		while (!httpHeatbeatScheduler.isShutdown()) {
			try {
				httpHeatbeatScheduler.awaitTermination(100, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if (socketHeatbeatExcutor != null) {
			socketHeatbeatExcutor.shutdown();
		}
		activeDmSeriveList.clear();
	}
}
