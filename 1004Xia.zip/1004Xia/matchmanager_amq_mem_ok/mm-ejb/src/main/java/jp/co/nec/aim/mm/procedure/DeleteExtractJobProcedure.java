package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;


public class DeleteExtractJobProcedure extends StoredProcedure {

	private static final String SQL = "delete_extract_job";
	private Long feJobId;

	public DeleteExtractJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_extract_job_id", Types.BIGINT));		
		compile();
	}

	public void execute() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_extract_job_id", getFeJobId());		
		execute(map);
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());		
	}

	public Long getFeJobId() {
		return feJobId;
	}

	public void setFeJobId(Long feJobId) {
		this.feJobId = feJobId;
	}
	
}
