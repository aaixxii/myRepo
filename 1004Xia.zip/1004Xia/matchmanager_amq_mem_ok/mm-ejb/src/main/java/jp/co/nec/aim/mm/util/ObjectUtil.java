/**this is file ObjectUtil.java
 * @author xia
   @date 2020/07/21
 */
package jp.co.nec.aim.mm.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

/**
 * @author xia
 *
 */
public class ObjectUtil {	
	
	public static byte[] serializeAmqResults(UidAimAmqResponse uidRespose) throws IOException {
	      ByteArrayOutputStream bos = new ByteArrayOutputStream();
	      ObjectOutputStream oos = new ObjectOutputStream(bos);
	      oos.writeObject(uidRespose);
	      oos.flush();
	      byte [] data =bos.toByteArray();
	      return data;
	}	
	
	public static UidAimAmqResponse deserializeAmqResults(byte[] data) throws IOException, ClassNotFoundException {
	    ByteArrayInputStream in = new ByteArrayInputStream(data);
	    ObjectInputStream is = new ObjectInputStream(in);
	    UidAimAmqResponse uidRes = (UidAimAmqResponse) is.readObject();
	    in.close();
	    return uidRes;
	}
	
//	   public  byte[] getBytesFromObject(Serializable obj) throws Exception {
//	        if (obj == null) {
//	            return null;
//	        }
//	        ByteArrayOutputStream bo = new ByteArrayOutputStream();
//	        ObjectOutputStream oo = new ObjectOutputStream(bo);
//	        oo.writeObject(obj);
//	        return bo.toByteArray();
//	    }
//	   
//	   public  Object getObjectFromBytes(byte[] objBytes) throws Exception {
//	        if (objBytes == null || objBytes.length == 0) {
//	            return null;
//	        }
//	        ByteArrayInputStream bi = new ByteArrayInputStream(objBytes);
//	        ObjectInputStream oi = new ObjectInputStream(bi);
//	        return oi.readObject();
//	    }   
		
}
