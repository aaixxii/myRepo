package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;

/**
 * 
 * @author xiazp
 *
 */
public class GetMuPressureAbilityProcedure extends StoredProcedure {
	private static final String GET_MU_PRESSURE_ABILITY = "get_mu_pressure_ability";
	//private static final String NUM_TABLE_TYPE = "NUM_TABLE_TYPE";
	private String muIdStrs;
	private JdbcTemplate jdbcTemplate;

	public GetMuPressureAbilityProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(GET_MU_PRESSURE_ABILITY);
		declareParameter(new SqlParameter("p_mu_ids", Types.VARCHAR));		
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));
		compile();
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public String getMuIdStrs() {
		return muIdStrs;
	}

	public void setMuIdStrs(String muIdStrs) {
		this.muIdStrs = muIdStrs;
	}

	public static String getGetMuPressureAbility() {
		return GET_MU_PRESSURE_ABILITY;
	}

	/**
	 * 
	 * @param muId
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */	
	public List<MuCpuAndPressure> getMuPressureAndAbility(String muIds)
			throws DataAccessException, SQLException {
		if (StringUtils.isBlank(muIds)) {
			throw new IllegalArgumentException(
					"muIds == null when call getMuPressureAndAbility procedure");
		}		
		setMuIdStrs(muIds);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_ids", muIds);
		Map<String, Object> resultMap = execute(map);
		String tableName = (String) resultMap.get("tab_name");
		String sql = "select * from " + tableName;
		List<MuCpuAndPressure> results = jdbcTemplate.query(sql, new CursorMapper());		
		if (results == null || results.size() < 1) {
			return null;
		}		
		return results;
	}

	
	/**
	 * 
	 * @author xiazp
	 *
	 */
	private class CursorMapper implements RowMapper<MuCpuAndPressure> {
		@Override
		public MuCpuAndPressure mapRow(ResultSet rs, int row)
				throws SQLException {
			MuCpuAndPressure oneResult = new MuCpuAndPressure();
			oneResult.setMuId(rs.getInt("mu_id"));
			oneResult.setAbility(rs.getDouble("ability"));
			oneResult.setPressure(rs.getLong("pressure"));
			oneResult.setReportTs(rs.getLong("report_ts"));
			return oneResult;
		}
	}
}
