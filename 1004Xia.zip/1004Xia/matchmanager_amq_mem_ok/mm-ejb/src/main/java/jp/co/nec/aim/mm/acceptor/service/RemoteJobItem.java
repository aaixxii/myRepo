/**this is file SyncJobItem.java
 * @author xia
   @date 2020/09/25
 */
package jp.co.nec.aim.mm.acceptor.service;

import java.io.Serializable;

import jp.co.nec.aim.mm.constants.UidRequestType;

/**
 * @author xia
 *
 */
public class RemoteJobItem implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6219313284425487045L;
	Long feJobId;
	Long InqJobId;
	String requestId;
	String refId;
	String mmUrl;
	UidRequestType uidRequestType;	
	String requst;
	Boolean isFromServlet;
	String maxResults;	
	
	public Long getFeJobId() {
		return feJobId;
	}
	public void setFeJobId(Long feJobId) {
		this.feJobId = feJobId;
	}
	public Long getInqJobId() {
		return InqJobId;
	}
	public void setInqJobId(Long inqJobId) {
		InqJobId = inqJobId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public String getMmUrl() {
		return mmUrl;
	}
	public void setMmUrl(String mmUrl) {
		this.mmUrl = mmUrl;
	}
	public UidRequestType getUidRequestType() {
		return uidRequestType;
	}
	public void setUidRequestType(UidRequestType uidRequestType) {
		this.uidRequestType = uidRequestType;
	}
	public String getRequst() {
		return requst;
	}
	public void setRequst(String requst) {
		this.requst = requst;
	}
	public Boolean getIsFromServlet() {
		return isFromServlet;
	}
	public void setIsFromServlet(Boolean isFromServlet) {
		this.isFromServlet = isFromServlet;
	}
	public String getMaxResults() {
		return maxResults;
	}
	public void setMaxResults(String maxResults) {
		this.maxResults = maxResults;
	}	
}
