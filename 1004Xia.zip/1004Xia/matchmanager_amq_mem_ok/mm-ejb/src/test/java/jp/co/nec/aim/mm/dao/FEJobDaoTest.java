package jp.co.nec.aim.mm.dao;

import java.net.URL;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.mm.entities.FeJobQueueEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FEJobDaoTest extends AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {		
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_LOT_JOBS");
		jdbcTemplate.update("delete from MATCH_UNITS");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() {		
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_LOT_JOBS");
		jdbcTemplate.update("delete from MATCH_UNITS");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testFeJobById() {
		FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);
		URL url = this.getClass().getResource("insert_fe_job_queue.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		FeJobQueueEntity feJobQueueEntity = feJobDao.findFeJob(20);
		Assert.assertEquals(20, feJobQueueEntity.getId());
	}

	@Test
	public void testListAllJobIds() {
		FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);
		URL url = this.getClass().getResource("insert_fe_job_queue.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		List<Long> list = feJobDao.listAllJobIds();
		Assert.assertEquals(2, list.size());
		Assert.assertEquals(20, list.get(0).intValue());
		Assert.assertEquals(21, list.get(1).intValue());
	}

	@Test
	public void testClearJobs() {
		FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);
		URL url = this.getClass().getResource("insert_fe_job_queue.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		int count = jdbcTemplate.queryForObject(
				"select count(*) from fe_job_queue", Integer.class);
		Assert.assertEquals(2, count);
		feJobDao.clearJobs();
		int count1 = jdbcTemplate.queryForObject(
				"select count(*) from fe_job_queue", Integer.class);
		Assert.assertEquals(0, count1);
	}

	@Test
	public void testDeleteExtractJobByRefId() {
		jdbcTemplate.execute("DELETE FROM MATCH_UNITS");
		
		jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE) values(1,'192.168.1.1','WORKING')");		
		jdbcTemplate.execute("insert into FE_JOB_QUEUE (JOB_ID,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,FUNCTION_ID,REFERENCE_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,ASSIGNED_TS,CALLBACK_STYLE) values(20,'req1', 'extract',17,'test1',4,1,1,123,13,0)");
		jdbcTemplate.execute("insert into FE_JOB_QUEUE (JOB_ID,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,FUNCTION_ID,REFERENCE_ID,PRIORITY,JOB_STATE,MU_ID, SUBMISSION_TS,ASSIGNED_TS,CALLBACK_STYLE) values(21,'req2', 'extract',17,'test2',4,1,1,123,13,1)");
		
		FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);		
		int delCount = feJobDao.delExtJobByRefId("test1");		
		Assert.assertEquals(1, delCount);
		int delCount1 = feJobDao.delExtJobByRefId("test2");		
		Assert.assertEquals(1, delCount1);
		jdbcTemplate.execute("DELETE FROM MATCH_UNITS");
		feJobDao = null;
	}
	
	
	   @Test
	    public void testDeleteExtractJob_jobId() {
	        jdbcTemplate.execute("DELETE FROM MATCH_UNITS");
	        
	        jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE) values(1,'192.168.1.1','WORKING')");       
	        jdbcTemplate.execute("insert into FE_JOB_QUEUE (JOB_ID,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,FUNCTION_ID,REFERENCE_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,ASSIGNED_TS,CALLBACK_STYLE) values(20,'req1', 'extract',17,'test1',4,1,1,123,13,0)");
	        jdbcTemplate.execute("insert into FE_JOB_QUEUE (JOB_ID,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,FUNCTION_ID,REFERENCE_ID,PRIORITY,JOB_STATE,MU_ID, SUBMISSION_TS,ASSIGNED_TS,CALLBACK_STYLE) values(21,'req2', 'extract',17,'test2',4,1,1,123,13,1)");
	        
	        FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);        
	        feJobDao.deleteExtractJob(20);	       
	        jdbcTemplate.execute("DELETE FROM MATCH_UNITS");
	    } 
	   
       @Test
       public void testDeleteExtractJob_jobId_zero() {
           try {
               jdbcTemplate.execute("DELETE FROM MATCH_UNITS");
               
               jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE) values(1,'192.168.1.1','WORKING')");       
               jdbcTemplate.execute("insert into FE_JOB_QUEUE (JOB_ID,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,FUNCTION_ID,REFERENCE_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,ASSIGNED_TS,CALLBACK_STYLE) values(20,'req1', 'extract',17,'test1',4,1,1,123,13,0)");
               jdbcTemplate.execute("insert into FE_JOB_QUEUE (JOB_ID,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,FUNCTION_ID,REFERENCE_ID,PRIORITY,JOB_STATE,MU_ID, SUBMISSION_TS,ASSIGNED_TS,CALLBACK_STYLE) values(21,'req2', 'extract',17,'test2',4,1,1,123,13,1)");
               
               FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);        
               feJobDao.deleteExtractJob(-999); 
               feJobDao.deleteExtractJob(0); 
               jdbcTemplate.execute("DELETE FROM MATCH_UNITS");
               
           } catch (Exception e) {
               System.out.print("has a error");
           }
 
       } 
	

	@Test
	public void test_deleteLotJob() {
		URL url = this.getClass().getResource("insert_fe_job_queue.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);
		feJobDao.deleteLotJob(1l);

		int count = jdbcTemplate.queryForObject(
				"select count(*) from FE_LOT_JOBS", Integer.class);
		Assert.assertEquals(0, count);
	}

	@Test
	public void test_deleteLotJob_Null() {
		URL url = this.getClass().getResource("insert_fe_job_queue.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);
		feJobDao.deleteLotJob(null);

		int count = jdbcTemplate.queryForObject(
				"select count(*) from FE_LOT_JOBS", Integer.class);
		Assert.assertEquals(1, count);
	}

	@Test
	public void test_listTimedOutExtractJobs() {
		URL url = this.getClass().getResource("insert_fe_job_queue.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);
		List<FeJobQueueEntity> list = feJobDao.listTimedOutExtractJobs();
		Assert.assertEquals(2, list.size());
		Assert.assertEquals(20, list.get(0).getId());
		Assert.assertEquals(21, list.get(1).getId());
	}

	@Test
	public void test_listDeadExtractJobs() {
		URL url = this.getClass().getResource("insert_fe_job_queue.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		FEJobDao feJobDao = new FEJobDao(entityManager, dataSource);
		List<FeJobQueueEntity> list = feJobDao.listDeadExtractJobs(1);
		Assert.assertEquals(2, list.size());
		Assert.assertEquals(20, list.get(0).getId());
		Assert.assertEquals(21, list.get(1).getId());
	}
}
