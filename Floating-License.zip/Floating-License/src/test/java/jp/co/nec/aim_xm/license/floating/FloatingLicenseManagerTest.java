package jp.co.nec.aim_xm.license.floating;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.*;
import static org.junit.Assume.*;

import org.junit.experimental.runners.Enclosed;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.springframework.util.StringUtils;

import jp.co.nec.aim_xm.license.exception.InvalidFloatingLicenseException;

@RunWith(Enclosed.class)
public class FloatingLicenseManagerTest {
	@RunWith(Theories.class)
	public static class decompose {
		@DataPoints
		public static Fixture[] FIXTURES = {
			new Fixture(1, "VALID=TRUE;TYPE=FULL;SERVICE=SEARCH;MODALITY=FINGER"), new Fixture(2,
				"VALID=TRUE;TYPE=;SERVICE=SEARCH;MODALITY=FINGER"), new Fixture(3,
					"SERVICE=SEARCH;MODALITY=FINGER;VALID=TRUE"),

			new Fixture(4, "VALID=TRUE;TYPE=FULL;SERVICE=SEARCH,VERIFY;MODALITY=FINGER"), new Fixture(5,
				"VALID=TRUE;TYPE=FULL;SERVICE=SEARCH;MODALITY=FINGER"), new Fixture(6,
					"VALID=TRUE;TYPE=FULL;SERVICE=;MODALITY=FINGER"), new Fixture(7,
						"TYPE=FULL;MODALITY=FINGER;VALID=TRUE"),

			new Fixture(8, "VALID=TRUE;TYPE=FULL;SERVICE=SEARCH;MODALITY=FINGER,PALM,  FACE,IRIS  "),
			new Fixture(9, "VALID=TRUE;TYPE=FULL;SERVICE=SEARCH;MODALITY=FINGER"), new Fixture(10,
				"VALID=TRUE;TYPE=FULL;SERVICE=SEARCH;MODALITY="), new Fixture(11,
					"TYPE=FULL;SERVICE=SEARCH;VALID=TRUE"),

			new Fixture(12, "TYPE=FULL;SERVICE=SEARCH;MODALITY=FINGER;VALID=TRUE"), new Fixture(13,
				"VALID=TRUE;TYPE=FULL;SERVICE=SEARCH;MODALITY=FINGER"), new Fixture(14,
					"VALID=FALSE;ERROR_CODE=LMX_FEATURE_NOT_FOUND;ERROR_MESSAGE=TEST"),
		};

		@Theory
		public void decompose_error_message(Fixture fixture) {
			assumeTrue(14 == fixture.number);

			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();

			// exercise
			sut.decompose(fixture.license);

			// verify
			if (fixture.number == 13) {
				assertThat(sut.errorMessage, is("TEST"));
			}
		}

		@Theory
		public void decompose_error_code(Fixture fixture) {
			assumeTrue(14 == fixture.number);

			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();

			// exercise
			sut.decompose(fixture.license);

			// verify
			if (fixture.number == 13) {
				assertThat(sut.errorCode, is("LMX_FEATURE_NOT_FOUND"));
			}
		}

		@Theory
		public void decompose_valid(Fixture fixture) {
			assumeTrue(12 <= fixture.number && 14 <= fixture.number);

			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();

			// exercise
			sut.decompose(fixture.license);

			// verify
			if (fixture.number == 12) {
				assertThat(sut.isValid(), is(true));
			} else if (fixture.number == 13) {
				assertThat(sut.isValid(), is(true));
			} else if (fixture.number == 14) {
				assertThat(sut.isValid(), is(false));
			}
		}

		@Theory
		public void decompose_modality(Fixture fixture) {
			assumeTrue(8 <= fixture.number && fixture.number <= 12);

			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();

			// exercise
			sut.decompose(fixture.license);

			// verify
			if (fixture.number == 8) {
				assertThat(sut.modalityMap.containsKey("FINGER"), is(true));
				assertThat(sut.modalityMap.containsKey("FACE"), is(true));
				assertThat(sut.modalityMap.containsKey("IRIS"), is(true));
				assertThat(sut.modalityMap.containsKey("PALM"), is(true));
			} else if (fixture.number == 9) {
				assertThat(sut.modalityMap.containsKey("FINGER"), is(true));
			} else if (fixture.number == 10) {
				assertThat(sut.modalityMap.containsKey(""), is(true));
			} else if (fixture.number == 11) {
				assertThat(sut.modalityMap.size(), is(0));
			}
		}

		@Theory
		public void decompose_component(Fixture fixture) {
			assumeTrue(4 <= fixture.number && fixture.number <= 7);

			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();

			// exercise
			sut.decompose(fixture.license);

			// verify
			if (fixture.number == 4) {
				assertThat(sut.serviceMap.containsKey("SEARCH"), is(true));
				assertThat(sut.serviceMap.containsKey("VERIFY"), is(true));
			} else if (fixture.number == 5) {
				assertThat(sut.serviceMap.containsKey("SEARCH"), is(true));
			} else if (fixture.number == 6) {
				assertThat(sut.serviceMap.containsKey(""), is(true));
			} else if (fixture.number == 7) {
				assertThat(sut.serviceMap.size(), is(0));
			}
		}

		@Theory
		public void decompose_type(Fixture fixture) {
			assumeTrue(fixture.number <= 3);

			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();

			// exercise
			sut.decompose(fixture.license);

			// verify
			if (fixture.number == 1) {
				assertThat(sut.typeList.get(0), is("FULL"));
			} else if (fixture.number == 2) {
				assertThat(sut.typeList.get(0), is(""));
			} else if (fixture.number == 3) {
				assertThat(sut.typeList.size(), is(0));
			}
		}

		static class Fixture {
			public int number;

			public String license;

			public Fixture(int number, String license) {
				this.number = number;
				this.license = license;
			}
		}
	}

	@RunWith(Theories.class)
	public static class check_license {
		@DataPoints
		public static Fixture[] FIXTURES = {
			new Fixture(null, null), new Fixture("", null), new Fixture(null, ""), new Fixture("SEARCH",
				"FACE"),
		};

		@Theory
		public void throw_exception_if_invalid_license_has(Fixture fixture) {
			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();
			sut.valid = false;
			sut.errorCode = "TEST_CODE";
			sut.errorMessage = "TEST_MESSAGE";

			try {
				// exercise
				sut.checkLicense(fixture.search, fixture.modality);

				org.junit.Assert.fail();
			} catch (InvalidFloatingLicenseException ex) {
				// verify
				assertThat(ex.getCode(), is("TEST_CODE"));
				assertThat(ex.getMessage(), is("TEST_MESSAGE"));
			}
		}

		@Theory
		public void throw_exception_if_unmatch_component_has(Fixture fixture) {
			assumeTrue(!StringUtils.isEmpty(fixture.search) && !StringUtils.isEmpty(
				fixture.modality));

			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();
			sut.serviceMap.put("XX", "");
			sut.modalityMap.put("FACE", "");
			sut.valid = true;

			try {
				// exercise
				sut.checkLicense(fixture.search, fixture.modality);

				org.junit.Assert.fail();
			} catch (InvalidFloatingLicenseException ex) {
				// verify
				assertThat(ex.getMessage(), is("License is not enabled for service:"
					+ fixture.search));
			}
		}

		@Theory
		public void throw_exception_if_unmatch_modality_has(Fixture fixture) {
			assumeTrue(!StringUtils.isEmpty(fixture.search) && !StringUtils.isEmpty(
				fixture.modality));

			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();
			sut.serviceMap.put("SEARCH", "");
			sut.modalityMap.put("XYZ", "");
			sut.valid = true;

			try {
				// exercise
				sut.checkLicense(fixture.search, fixture.modality);

				org.junit.Assert.fail();
			} catch (InvalidFloatingLicenseException ex) {
				// verify
				assertThat(ex.getMessage(), is("License is not enabled for modality:"
					+ fixture.modality));
			}
		}

		@Theory
		public void no_throw_excpetion(Fixture fixture) {
			// setup
			FloatingLicenseManager sut = new FloatingLicenseManager();
			sut.serviceMap.put("SEARCH", "");
			sut.modalityMap.put("FACE", "");
			sut.valid = true;

			try {
				// exercise
				sut.checkLicense(fixture.search, fixture.modality);
			} catch (InvalidFloatingLicenseException ex) {
				// verify
				org.junit.Assert.fail();
			}
		}

		static class Fixture {
			public String search;

			public String modality;

			public Fixture(String component, String modality) {
				this.search = component;
				this.modality = modality;
			}
		}
	}
}
