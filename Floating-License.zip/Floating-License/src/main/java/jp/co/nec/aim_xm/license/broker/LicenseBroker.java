package jp.co.nec.aim_xm.license.broker;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.enterprise.concurrent.ContextService;

import org.apache.log4j.Logger;

import com.google.common.base.Throwables;

import jp.co.nec.aim_xm.license.floating.FloatingLicenseManager;

public class LicenseBroker {
	final Logger logger = Logger.getLogger(LicenseBroker.class);

	final ExecutorService brokerThreadExecutor = Executors.newSingleThreadExecutor();

	final ExecutorService agentThreadExecutor = Executors.newSingleThreadExecutor();

	ContextService contextService;

	FloatingLicenseManager floatingLicenseManager;

	LicenseBrokerServer licenseBrokerServer;
	
	String majorVersion;
	
	public void setContextService(ContextService contextService) {
		this.contextService = contextService;
	}

	public void setFloatingLicenseManager(FloatingLicenseManager floatingLicenseManager) {
		this.floatingLicenseManager = floatingLicenseManager;
	}

	public void setLicenseBrokerServer(LicenseBrokerServer licenseBrokerServer) {
		this.licenseBrokerServer = licenseBrokerServer;
	}

	private void execContextService() {
		agentThreadExecutor.submit(contextService.createContextualProxy(new LicenseAgentTask(),
			Runnable.class));
	}

	private class LicenseAgentTask implements Runnable {
		@Override
		public void run() {
			String homeDir = System.getProperty("jboss.home.dir");
			ProcessBuilder builder = new ProcessBuilder("./lmx-agent.sh",
				String.valueOf(licenseBrokerServer.getPort()), majorVersion, "AFIS");
			builder.directory(new File(homeDir + "/license/agent"));
			builder.redirectErrorStream(true);
			try {
				builder.start();
			} catch (IOException ex) {
				logger.error(Throwables.getRootCause(ex).getMessage());
				return;
			}
		}
	}

	public void init(String majorVersion) {
		this.majorVersion = majorVersion;
		execContextService();
	}
	
	public void init(int majorVersion) {
		this.majorVersion = String.valueOf(majorVersion);
		execContextService();
	}
}
