package jp.co.nec.aim.mm.dm.client.heartbeat;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dm.client.mgmt.UidDmJobRunManager;
import jp.co.nec.aim.mm.exception.UidDmClientException;



public class SocketHeatBeatSender implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(SocketHeatBeatSender.class);
	private String dmWebContent;
	private String dmIpandProt;
	private int dmSocketPort;
	private Selector mySelector;	
	private long WRITTING_LATENCY;
	private int socketTimeout = 5 * 1000;
	private static boolean stop = false;

	public SocketHeatBeatSender(String dmWebContent, String allDmUrl, String dmSocketPort, long interval) {
		this.dmWebContent = dmWebContent;
		this.dmIpandProt = allDmUrl;
		this.WRITTING_LATENCY = interval;
		try {
			this.dmSocketPort = Integer.parseInt(dmSocketPort);
		} catch (NumberFormatException e) {
			throw e;
		}
		if (this.dmSocketPort < 0) {
			throw new UidDmClientException("DM Service socket port can't be minus.");
		}
		init();
	}

	private void init() {
		String ip = this.dmIpandProt.split(":")[0];
		if (ip == null || ip.isEmpty()) {
			throw new UidDmClientException("DM Service ip not setting in config file or it's empty.");
		}

		InetSocketAddress hostAddress = new InetSocketAddress(ip, Integer.valueOf(dmSocketPort).intValue());
		try {
			SocketChannel socketChannel = SocketChannel.open(hostAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setReuseAddress(true);
			socketChannel.socket().setKeepAlive(true);
			socketChannel.socket().setSoTimeout(socketTimeout);
			socketChannel.socket().setOOBInline(false);
			mySelector = Selector.open();
			socketChannel.register(mySelector, SelectionKey.OP_WRITE | SelectionKey.OP_READ);
		} catch (IOException e) {
			logger.warn("Can not connection to DM!!");
		}
	}

	@Override
	public void run() {
		start();		
	}
	
	private void start() {
		try {
			runOneEntry();
		} catch (IOException e) {			
		}
	}

	public void runOneEntry() throws IOException  {	
		SelectionKey key = null;		
			while (mySelector.select() > 0 && !stop) {
				try {
					Set<SelectionKey> keys = mySelector.selectedKeys();
					Iterator<SelectionKey> keyIterator = keys.iterator();
					while (keyIterator.hasNext()) {
						key = (SelectionKey) keyIterator.next();
						keyIterator.remove();
						if (!key.isValid()) {
							continue;
						}
					}
					if (key.isReadable()) {
					}
					if (key.isWritable()) {
						String baseUrl = "http://" + dmIpandProt + "/" + dmWebContent;
						SocketChannel myClient = (SocketChannel) key.channel();
						if (isServerClosed(myClient.socket())) {
							logger.warn("Socket Channel(url={}) may be Closed!", baseUrl);							
							UidDmJobRunManager.removeDmServiceFromMe(baseUrl);
							init();
						} else {
							UidDmJobRunManager.addActiveDmServiceTome(baseUrl);					
							logger.info("{} is active!", baseUrl);
						}									
					}
					try {
						Thread.sleep(WRITTING_LATENCY);
					} catch (InterruptedException e) {						
					}					
					logger.info("Active dm sevice count={}", UidDmJobRunManager.getActiveServiceCount() );			
				} catch (Exception e) {	
					init();
				}
			}	
	}

	private boolean isServerClosed(Socket socket) {
		try {
			socket.sendUrgentData(0xff);
			return false;
		} catch (IOException e) {
			return true;
		}
	}

	public static void stop() {
		stop = true;
	}
}
