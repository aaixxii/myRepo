
package jp.co.nec.aim.mm.hazelcast;

import static jp.co.nec.aim.mm.constants.Constants.extJobResultMapName;
import static jp.co.nec.aim.mm.constants.Constants.extLockMapName;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hazelcast.config.ClasspathXmlConfig;
import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;


public class HazelcastService {
	private static Logger logger = LoggerFactory.getLogger(HazelcastService.class);	
	private HazelcastInstance hInstance;
	//private ITopic<String> uidTopic;
	
	private static HazelcastService INSTANCE = new HazelcastService();
	
	public static HazelcastService getInstance() {
		return INSTANCE;
	}	
	
	public HazelcastService() {			
	}
	
	public void init() {
		//String hazecastConfigPath = AimManager.getValueFromUidMMSettingMap(hazelcastConfigPath);
		Config config = new ClasspathXmlConfig("hazelcast.xml");
		//NetworkConfig netConfig = config.getNetworkConfig();		
		hInstance = Hazelcast.newHazelcastInstance(config);
	   // hInstance.getMap(extJobResultMapName);
		//hInstance.getMap(extLockMapName);
		logger.info("HazelcastService started!");
		//uidTopic = instance.getTopic("UidNotifyTopic");
	}
	
	public  void saveToExtractLockQueue(String key, Long obj) {
		IMap<String, Long> extLockMap = hInstance.getMap(extLockMapName);
		extLockMap.put(key, obj);	
		logger.info("extLockMap size= {}", extLockMap.size());
	}
	
	public  void saveToExtractJobResutQueue(String key, PBMuExtractJobResultItem oneFejobResut) {
		IMap<String, PBMuExtractJobResultItem> extractJobResutMap = hInstance.getMap(extJobResultMapName);
		extractJobResutMap.put(key, oneFejobResut);
		logger.info("extractJobResutMap size= {}", extractJobResutMap.size());
		IMap<String, Long> extLockMap = hInstance.getMap(extLockMapName);
		logger.info("extLockMap size= {}", extLockMap.size());
		Long locker = extLockMap.get(key);
		synchronized (locker) {			
			locker.notify();
			logger.info("extract job:{} is completed. notified to AimSyncService.", key);
		}		
	}
	
	public PBMuExtractJobResultItem getExtractJobResult(String feJobId) {		
		IMap<String, PBMuExtractJobResultItem> extractJobResutMap =  hInstance.getMap(extJobResultMapName);
		logger.info("extractJobResutMap size= {}", extractJobResutMap.size());
		return Optional.of(extractJobResutMap.get(feJobId)).orElse(null);
	}
	
	public  void finishExtractJob(String extJobId) {
		IMap<String, Long> extractLockQueue = hInstance.getMap(extLockMapName);
		IMap<String, PBMuExtractJobResultItem> extractJobResutQueue = hInstance.getMap(extJobResultMapName);
		try {
			extractLockQueue.remove(extJobId);
			extractJobResutQueue.remove(extJobId);
		} catch (Exception e) {
			logger.warn("Object associated with key:{} may be removed!", extJobId);
		}	
	}
	
	public void shutdown() {
		hInstance.shutdown();
	}
}
