package jp.co.nec.aim.mm.acceptor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncRequest;
import jp.co.nec.aim.mm.common.HttpTestServer;
//import jp.co.nec.aim.mm.util.JmsSender;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class RegistrationTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	private Registration reg;

	@Before
	public void setUp() {
		reg = new Registration(dataSource, entityManager);
		jdbcTemplate.update("delete from mu_segments");
		jdbcTemplate.update("delete from match_units");	
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.update("delete from SEGMENT_VACANCIES");
		jdbcTemplate.execute("commit");
		map.clear();

		setMockMethod();
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from mu_segments");
		jdbcTemplate.update("delete from match_units");		
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.update("delete from SEGMENT_VACANCIES");
		jdbcTemplate.execute("commit");
		map.clear();		
	}

	@BeforeClass
	public static void init() throws Exception {
		// _server = new HttpTestServer(65521);
		// _server.start(getMockHandler());
	}

	@AfterClass
	public static void after() throws Exception {

		// if (_server != null) { _server.stop(); }

	}

	@Test
	public void testInsert1_NewSeg() throws Exception {
		List<AimSyncRequest> syncRequests = Lists.newArrayList();
		byte[] binary = { 1, 2, 2 };
		Record record = new Record(binary, true);
		AimSyncRequest syncRequest = new AimSyncRequest(1, record);		
		syncRequests.add(syncRequest);		
		Map<Long, List<SegSyncInfos>> result = reg.insert("1", syncRequests);		
		result.values().forEach(e -> {
			Assert.assertEquals(e.get(0).isUpdateSegment(),false);			
			Assert.assertEquals(e.get(0).getExternalId(), "1");
			Assert.assertEquals(e.get(0).getCommand(), SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
			Assert.assertEquals(e.get(0).getSegVersion().longValue(), -1);		
		});
	}
	
	@Test
	public void testInsert1_NewSeg_test() throws Exception {		
		byte[] binary = { 1, 2, 2 };
		Record record = new Record(binary, true);
		AimSyncRequest syncRequest = new AimSyncRequest(1, record);	
		SegSyncInfos result = reg.insert("1", syncRequest);	
		Assert.assertEquals(result.isUpdateSegment(), false);
		Assert.assertEquals(result.getExternalId(), "1");
		Assert.assertEquals(result.getCommand(), SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
		Assert.assertEquals(result.getSegVersion().longValue(), -1);		
		
	}
	

	@Test	
	public void testDelete1() throws Exception {

		jdbcTemplate
				.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)VALUES(1,1,1,1,26,1,10,1)");
		jdbcTemplate.update("commit");		
		List<SegSyncInfos> delSyncList = new ArrayList<>();
		reg.delete("1",1, delSyncList);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from RESOURCE_UPDATE_COUNT");
		Assert.assertEquals(0, list.size());
	}

	@Test	
	public void testDelete_Push_OneContainerId() throws Exception {
		HttpTestServer server = null;

		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(1, "testDelete_Push_OneContainerId"));
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)VALUES(1,1,1,1,26,1,10,1)");
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,REGISTED_TS,CORRUPTED_FLAG,CONTAINER_ID)values(1,'1',111,0,1)");
			jdbcTemplate.update("commit");
			
			List<SegSyncInfos> delSyncList = new ArrayList<>();
			reg.delete("1",1, delSyncList);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Thread.sleep(5000);
			Assert.assertEquals(1, map.size());

			PBSegmentSyncRequest request1 = map
					.get("/1/matchunit/SegmentUpdateJob");
			Assert.assertEquals(1, request1.getSegmentUpdatesCount());

			List<PBSegmentSyncInfo> syncInfos = request1
					.getSegmentUpdatesList();
			for (PBSegmentSyncInfo syncInfo : syncInfos) {
				Assert.assertEquals(1, syncInfo.getSyncItem().getCatUpInfo()
						.getCatchUpItemsCount());
			}
			if (server != null) {
				server.stop();
			}
		}
	}

	@Test
	@Ignore
	public void testDelete_Push_ThreeContainerId_TwoMU_OneDM() throws Exception {
		HttpTestServer server = null;

		try {
			server = new HttpTestServer(65521);

			server.start(getMockHandler(3,
					"testDelete_Push_ThreeContainerId_TwoMU_OneDM"));
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(1,1,1,1,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(2,1,2,2,26,1,10,1,26)");
			jdbcTemplate
					.update("INSERT INTO segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)VALUES(3,1,3,3,26,1,10,1,26)");
			jdbcTemplate
					.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1,1,'http://127.0.0.1:65521/1','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(2,1,'http://127.0.0.1:65521/2','WORKING')");
			jdbcTemplate
					.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE)values(3,1,'http://127.0.0.1:65521/3','WORKING')");
			jdbcTemplate
					.update("insert into mu_segments(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(2,2,1)");
			jdbcTemplate
					.update("insert into dm_segments(DM_ID,SEGMENT_ID,RANK)values(3,3,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,'1',TO_BLOB('111'),3,111,0,1,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(2,'1',TO_BLOB('111'),3,111,0,1,1)");
			jdbcTemplate
					.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(3,'1',TO_BLOB('111'),3,111,0,1,1)");
			jdbcTemplate.update("commit");
			List<SegSyncInfos> delSyncList = new ArrayList<>();
			reg.delete("1",1, delSyncList);
		} catch (Exception e) {
			throw e;
		} finally {
			synchronized (LOCKER) {
				LOCKER.wait(10000);
			}
			Thread.sleep(5000);
			Assert.assertEquals(3, map.size());

			PBSegmentSyncRequest request1 = map
					.get("/1/matchunit/SegmentUpdateJob");
			Assert.assertEquals(1, request1.getSegmentUpdatesCount());

			List<PBSegmentSyncInfo> syncInfos = request1
					.getSegmentUpdatesList();
			for (PBSegmentSyncInfo syncInfo : syncInfos) {
				Assert.assertEquals(1, syncInfo.getSyncItem().getCatUpInfo()
						.getCatchUpItemsCount());
			}

			if (server != null) {
				server.stop();
			}
		}
	}
	


	@Test
	public void testInsert() throws Exception {
		byte[] binary = { 1, 2, 3 };
		Record record = new Record(binary, true);
		AimSyncRequest syncReq = new AimSyncRequest(1, record);
		List<AimSyncRequest> syncReqs = new ArrayList<AimSyncRequest>();
		syncReqs.add(syncReq);
		reg.insert("123", syncReqs);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Thread.sleep(5000);
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(map.get("CONTAINER_ID"), mapSeg.get("CONTAINER_ID"));

	}

	@Test
	public void testDelete() throws Exception {
		jdbcTemplate
				.update("insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)values(1,1,1,1,83,1,0,0)");
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS (BIOMETRICS_ID,EXTERNAL_ID,REGISTED_TS,CORRUPTED_FLAG,CONTAINER_ID)values(1,'1','1234',0,1)");
		List<SegSyncInfos> delSyncList = new ArrayList<>();
		reg.delete("1",1, delSyncList);
		jdbcTemplate.execute("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Thread.sleep(5000);
		Assert.assertEquals(0, list.size());
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(0,
				Integer.parseInt(mapSeg.get("RECORD_COUNT").toString()));
		Assert.assertFalse(mapSeg.get("BINARY_LENGTH").equals(83));

	}

	

	private final Object LOCKER = new Object();
	private static final Map<String, PBSegmentSyncRequest> map = Maps
			.newConcurrentMap();

	/**
	 * getMockHandler
	 * 
	 * @return AbstractHandler
	 */
	public Handler getMockHandler(final Integer a, final String... name) {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();

				PBSegmentSyncRequest result = PBSegmentSyncRequest
						.parseFrom(request.getInputStream());
				// System.out.println(baseRequest.getRequestURI());
				// System.out.println(result.toString());

				map.put(baseRequest.getRequestURI(), result);

				System.out.println("ThreadName:"
						+ Thread.currentThread().getId() + "=================="
						+ ((name == null || name.length == 0) ? "" : name[0])
						+ "==================" + "result->\n"
						+ result.toString());

				// q.add(result);

				if (map.size() == a) {
					synchronized (LOCKER) {
						LOCKER.notify();
					}
				}
				response.setStatus(200);
				response.setContentType("application/octet-stream");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}
}