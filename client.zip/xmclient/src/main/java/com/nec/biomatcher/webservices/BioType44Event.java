
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType44Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType44Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="algorithmType" type="{http://webservices.biomatcher.nec.com/}algorithmType" minOccurs="0"/>
 *         &lt;element name="feType" type="{http://webservices.biomatcher.nec.com/}bioFeType" minOccurs="0"/>
 *         &lt;element name="fingerNumbers" type="{http://webservices.biomatcher.nec.com/}imagePosition" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="latentPatterns" type="{http://webservices.biomatcher.nec.com/}patternType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="manualEditFlag" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="latentFeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType44Event", propOrder = {
    "algorithmType",
    "feType",
    "fingerNumbers",
    "latentPatterns",
    "manualEditFlag",
    "latentFeatureData"
})
public class BioType44Event
    extends BioTemplateEvent
{

    @XmlSchemaType(name = "string")
    protected AlgorithmType algorithmType;
    @XmlSchemaType(name = "string")
    protected BioFeType feType;
    @XmlElement(nillable = true)
    @XmlSchemaType(name = "string")
    protected List<ImagePosition> fingerNumbers;
    @XmlElement(nillable = true)
    @XmlSchemaType(name = "string")
    protected List<PatternType> latentPatterns;
    protected Boolean manualEditFlag;
    protected byte[] latentFeatureData;

    /**
     * Gets the value of the algorithmType property.
     * 
     * @return
     *     possible object is
     *     {@link AlgorithmType }
     *     
     */
    public AlgorithmType getAlgorithmType() {
        return algorithmType;
    }

    /**
     * Sets the value of the algorithmType property.
     * 
     * @param value
     *     allowed object is
     *     {@link AlgorithmType }
     *     
     */
    public void setAlgorithmType(AlgorithmType value) {
        this.algorithmType = value;
    }

    /**
     * Gets the value of the feType property.
     * 
     * @return
     *     possible object is
     *     {@link BioFeType }
     *     
     */
    public BioFeType getFeType() {
        return feType;
    }

    /**
     * Sets the value of the feType property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioFeType }
     *     
     */
    public void setFeType(BioFeType value) {
        this.feType = value;
    }

    /**
     * Gets the value of the fingerNumbers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fingerNumbers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFingerNumbers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ImagePosition }
     * 
     * 
     */
    public List<ImagePosition> getFingerNumbers() {
        if (fingerNumbers == null) {
            fingerNumbers = new ArrayList<ImagePosition>();
        }
        return this.fingerNumbers;
    }

    /**
     * Gets the value of the latentPatterns property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the latentPatterns property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLatentPatterns().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PatternType }
     * 
     * 
     */
    public List<PatternType> getLatentPatterns() {
        if (latentPatterns == null) {
            latentPatterns = new ArrayList<PatternType>();
        }
        return this.latentPatterns;
    }

    /**
     * Gets the value of the manualEditFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isManualEditFlag() {
        return manualEditFlag;
    }

    /**
     * Sets the value of the manualEditFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setManualEditFlag(Boolean value) {
        this.manualEditFlag = value;
    }

    /**
     * Gets the value of the latentFeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getLatentFeatureData() {
        return latentFeatureData;
    }

    /**
     * Sets the value of the latentFeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setLatentFeatureData(byte[] value) {
        this.latentFeatureData = value;
    }

}
