
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioFeType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="bioFeType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="A"/>
 *     &lt;enumeration value="B"/>
 *     &lt;enumeration value="C"/>
 *     &lt;enumeration value="E"/>
 *     &lt;enumeration value="P"/>
 *     &lt;enumeration value="L"/>
 *     &lt;enumeration value="CMLaF"/>
 *     &lt;enumeration value="CML"/>
 *     &lt;enumeration value="ELFT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "bioFeType")
@XmlEnum
public enum BioFeType {

    A("A"),
    B("B"),
    C("C"),
    E("E"),
    P("P"),
    L("L"),
    @XmlEnumValue("CMLaF")
    CM_LA_F("CMLaF"),
    CML("CML"),
    ELFT("ELFT");
    private final String value;

    BioFeType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static BioFeType fromValue(String v) {
        for (BioFeType c: BioFeType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
