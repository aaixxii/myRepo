
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType1Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType1Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="quality" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="faceS17FeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType1Event", propOrder = {
    "quality",
    "faceS17FeatureData"
})
public class BioType1Event
    extends BioTemplateEvent
{

    protected Integer quality;
    protected byte[] faceS17FeatureData;

    /**
     * Gets the value of the quality property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getQuality() {
        return quality;
    }

    /**
     * Sets the value of the quality property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setQuality(Integer value) {
        this.quality = value;
    }

    /**
     * Gets the value of the faceS17FeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getFaceS17FeatureData() {
        return faceS17FeatureData;
    }

    /**
     * Sets the value of the faceS17FeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setFaceS17FeatureData(byte[] value) {
        this.faceS17FeatureData = value;
    }

}
