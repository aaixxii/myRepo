
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for patternType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="patternType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="A"/>
 *     &lt;enumeration value="T"/>
 *     &lt;enumeration value="R"/>
 *     &lt;enumeration value="L"/>
 *     &lt;enumeration value="W"/>
 *     &lt;enumeration value="S"/>
 *     &lt;enumeration value="N"/>
 *     &lt;enumeration value="U"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "patternType")
@XmlEnum
public enum PatternType {

    A,
    T,
    R,
    L,
    W,
    S,
    N,
    U;

    public String value() {
        return name();
    }

    public static PatternType fromValue(String v) {
        return valueOf(v);
    }

}
