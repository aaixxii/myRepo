
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioTemplateEvent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioTemplateEvent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="eventId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioTemplateEvent", propOrder = {
    "eventId"
})
@XmlSeeAlso({
    BioType37Event.class,
    BioType2Event.class,
    BioType35Event.class,
    BioType38Event.class,
    BioType40Event.class,
    BioType1Event.class,
    BioType42Event.class,
    BioType11Event.class,
    BioType48Event.class,
    BioType33Event.class,
    BioType39Event.class,
    BioType36Event.class,
    BioType31Event.class,
    BioType45Event.class,
    BioType46Event.class,
    BioType43Event.class,
    BioType32Event.class,
    BioType34Event.class,
    BioType12Event.class,
    BioType41Event.class,
    BioType47Event.class,
    BioType44Event.class
})
public class BioTemplateEvent {

    protected String eventId;

    /**
     * Gets the value of the eventId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEventId() {
        return eventId;
    }

    /**
     * Sets the value of the eventId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEventId(String value) {
        this.eventId = value;
    }

}
