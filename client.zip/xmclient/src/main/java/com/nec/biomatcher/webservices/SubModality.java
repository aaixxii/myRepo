
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for subModality.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="subModality">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="SUB_MODAL_FINGER_ROLL"/>
 *     &lt;enumeration value="SUB_MODAL_FINGER_SLAP"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "subModality")
@XmlEnum
public enum SubModality {

    SUB_MODAL_FINGER_ROLL,
    SUB_MODAL_FINGER_SLAP;

    public String value() {
        return name();
    }

    public static SubModality fromValue(String v) {
        return valueOf(v);
    }

}
