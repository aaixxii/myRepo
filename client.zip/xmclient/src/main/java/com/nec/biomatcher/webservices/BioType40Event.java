
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType40Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType40Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="partNumbers" type="{http://webservices.biomatcher.nec.com/}imagePosition" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="latentPc3FeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType40Event", propOrder = {
    "partNumbers",
    "latentPc3FeatureData"
})
public class BioType40Event
    extends BioTemplateEvent
{

    @XmlElement(nillable = true)
    @XmlSchemaType(name = "string")
    protected List<ImagePosition> partNumbers;
    protected byte[] latentPc3FeatureData;

    /**
     * Gets the value of the partNumbers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the partNumbers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPartNumbers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ImagePosition }
     * 
     * 
     */
    public List<ImagePosition> getPartNumbers() {
        if (partNumbers == null) {
            partNumbers = new ArrayList<ImagePosition>();
        }
        return this.partNumbers;
    }

    /**
     * Gets the value of the latentPc3FeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getLatentPc3FeatureData() {
        return latentPc3FeatureData;
    }

    /**
     * Sets the value of the latentPc3FeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setLatentPc3FeatureData(byte[] value) {
        this.latentPc3FeatureData = value;
    }

}
