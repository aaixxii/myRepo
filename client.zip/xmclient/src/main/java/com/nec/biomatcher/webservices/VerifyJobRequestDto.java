
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for verifyJobRequestDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="verifyJobRequestDto">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioMatcherJobRequest">
 *       &lt;sequence>
 *         &lt;element name="probeBiomericData" type="{http://webservices.biomatcher.nec.com/}verifyBiometricData" minOccurs="0"/>
 *         &lt;element name="galleryBiomericDataList" type="{http://webservices.biomatcher.nec.com/}verifyBiometricData" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="matchInputParameterList" type="{http://webservices.biomatcher.nec.com/}matchInputParameter" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="jobTimeoutMill" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="jobMode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="callbackUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="priority" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "verifyJobRequestDto", propOrder = {
    "probeBiomericData",
    "galleryBiomericDataList",
    "matchInputParameterList",
    "jobTimeoutMill",
    "jobMode",
    "callbackUrl",
    "priority"
})
public class VerifyJobRequestDto
    extends BioMatcherJobRequest
{   
	@XmlElement(required = false, nillable = true)
	protected VerifyBiometricData probeBiomericData;
    @XmlElement(nillable = true)
    protected List<VerifyBiometricData> galleryBiomericDataList;
    @XmlElement(nillable = true)
    protected List<MatchInputParameter> matchInputParameterList;
    protected Long jobTimeoutMill;
    protected String jobMode;
    protected String callbackUrl;
    @XmlElementRef(name = "priority", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> priority;

    /**
     * Gets the value of the probeBiomericData property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link VerifyBiometricData }{@code >}
     *     
     */
    
    public VerifyJobRequestDto() {
    	
    }
    
	public VerifyJobRequestDto(VerifyBiometricData probeBiomericData, List<VerifyBiometricData> galleryBiomericDataList,
			List<MatchInputParameter> matchInputParameterList, String callbackUrl, Long jobTimeoutMill,
			String jobMode) {
		this.probeBiomericData = probeBiomericData;
		this.galleryBiomericDataList = galleryBiomericDataList;
		this.matchInputParameterList = matchInputParameterList;
		this.callbackUrl = callbackUrl;
		this.jobTimeoutMill = jobTimeoutMill;
		this.jobMode = jobMode;

	}	
  

    public VerifyBiometricData getProbeBiomericData() {
		return probeBiomericData;
	}




	public void setProbeBiomericData(VerifyBiometricData probeBiomericData) {
		this.probeBiomericData = probeBiomericData;
	}




	public void setGalleryBiomericDataList(List<VerifyBiometricData> galleryBiomericDataList) {
		this.galleryBiomericDataList = galleryBiomericDataList;
	}




	public void setMatchInputParameterList(List<MatchInputParameter> matchInputParameterList) {
		this.matchInputParameterList = matchInputParameterList;
	}




	/**
     * Gets the value of the galleryBiomericDataList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the galleryBiomericDataList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGalleryBiomericDataList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VerifyBiometricData }
     * 
     * 
     */
    public List<VerifyBiometricData> getGalleryBiomericDataList() {
        if (galleryBiomericDataList == null) {
            galleryBiomericDataList = new ArrayList<VerifyBiometricData>();
        }
        return this.galleryBiomericDataList;
    }

    /**
     * Gets the value of the matchInputParameterList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the matchInputParameterList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMatchInputParameterList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MatchInputParameter }
     * 
     * 
     */
    public List<MatchInputParameter> getMatchInputParameterList() {
        if (matchInputParameterList == null) {
            matchInputParameterList = new ArrayList<MatchInputParameter>();
        }
        return this.matchInputParameterList;
    }

    /**
     * Gets the value of the jobTimeoutMill property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getJobTimeoutMill() {
        return jobTimeoutMill;
    }

    /**
     * Sets the value of the jobTimeoutMill property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setJobTimeoutMill(Long value) {
        this.jobTimeoutMill = value;
    }

    /**
     * Gets the value of the jobMode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobMode() {
        return jobMode;
    }

    /**
     * Sets the value of the jobMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobMode(String value) {
        this.jobMode = value;
    }

    /**
     * Gets the value of the callbackUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCallbackUrl() {
        return callbackUrl;
    }

    /**
     * Sets the value of the callbackUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCallbackUrl(String value) {
        this.callbackUrl = value;
    }

    /**
     * Gets the value of the priority property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getPriority() {
        return priority;
    }

    /**
     * Sets the value of the priority property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setPriority(JAXBElement<Integer> value) {
        this.priority = value;
    }

}
