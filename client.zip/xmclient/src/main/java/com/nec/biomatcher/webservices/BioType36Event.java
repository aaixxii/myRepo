
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType36Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType36Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="matchConfig" type="{http://www.w3.org/2001/XMLSchema}byte"/>
 *         &lt;element name="rolledFingerQualities" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="slapFingerQualities" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="rolledCmlFeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="slapCmlFeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType36Event", propOrder = {
    "matchConfig",
    "rolledFingerQualities",
    "slapFingerQualities",
    "rolledCmlFeatureData",
    "slapCmlFeatureData"
})
public class BioType36Event
    extends BioTemplateEvent
{

    protected byte matchConfig;
    @XmlElement(nillable = true)
    protected List<Integer> rolledFingerQualities;
    @XmlElement(nillable = true)
    protected List<Integer> slapFingerQualities;
    protected byte[] rolledCmlFeatureData;
    protected byte[] slapCmlFeatureData;

    /**
     * Gets the value of the matchConfig property.
     * 
     */
    public byte getMatchConfig() {
        return matchConfig;
    }

    /**
     * Sets the value of the matchConfig property.
     * 
     */
    public void setMatchConfig(byte value) {
        this.matchConfig = value;
    }

    /**
     * Gets the value of the rolledFingerQualities property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rolledFingerQualities property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRolledFingerQualities().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getRolledFingerQualities() {
        if (rolledFingerQualities == null) {
            rolledFingerQualities = new ArrayList<Integer>();
        }
        return this.rolledFingerQualities;
    }

    /**
     * Gets the value of the slapFingerQualities property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the slapFingerQualities property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSlapFingerQualities().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getSlapFingerQualities() {
        if (slapFingerQualities == null) {
            slapFingerQualities = new ArrayList<Integer>();
        }
        return this.slapFingerQualities;
    }

    /**
     * Gets the value of the rolledCmlFeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getRolledCmlFeatureData() {
        return rolledCmlFeatureData;
    }

    /**
     * Sets the value of the rolledCmlFeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setRolledCmlFeatureData(byte[] value) {
        this.rolledCmlFeatureData = value;
    }

    /**
     * Gets the value of the slapCmlFeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getSlapCmlFeatureData() {
        return slapCmlFeatureData;
    }

    /**
     * Sets the value of the slapCmlFeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setSlapCmlFeatureData(byte[] value) {
        this.slapCmlFeatureData = value;
    }

}
