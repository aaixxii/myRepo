
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType47Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType47Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="interDigitalRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="thenarRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="hypothenarRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="interDigitalLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="thenarLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="hypothenarLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="writerRight" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *         &lt;element name="writerLeft" type="{http://webservices.biomatcher.nec.com/}bioPalmFeatureInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType47Event", propOrder = {
    "interDigitalRight",
    "thenarRight",
    "hypothenarRight",
    "interDigitalLeft",
    "thenarLeft",
    "hypothenarLeft",
    "writerRight",
    "writerLeft"
})
public class BioType47Event
    extends BioTemplateEvent
{

    protected BioPalmFeatureInfo interDigitalRight;
    protected BioPalmFeatureInfo thenarRight;
    protected BioPalmFeatureInfo hypothenarRight;
    protected BioPalmFeatureInfo interDigitalLeft;
    protected BioPalmFeatureInfo thenarLeft;
    protected BioPalmFeatureInfo hypothenarLeft;
    protected BioPalmFeatureInfo writerRight;
    protected BioPalmFeatureInfo writerLeft;

    /**
     * Gets the value of the interDigitalRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getInterDigitalRight() {
        return interDigitalRight;
    }

    /**
     * Sets the value of the interDigitalRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setInterDigitalRight(BioPalmFeatureInfo value) {
        this.interDigitalRight = value;
    }

    /**
     * Gets the value of the thenarRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getThenarRight() {
        return thenarRight;
    }

    /**
     * Sets the value of the thenarRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setThenarRight(BioPalmFeatureInfo value) {
        this.thenarRight = value;
    }

    /**
     * Gets the value of the hypothenarRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getHypothenarRight() {
        return hypothenarRight;
    }

    /**
     * Sets the value of the hypothenarRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setHypothenarRight(BioPalmFeatureInfo value) {
        this.hypothenarRight = value;
    }

    /**
     * Gets the value of the interDigitalLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getInterDigitalLeft() {
        return interDigitalLeft;
    }

    /**
     * Sets the value of the interDigitalLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setInterDigitalLeft(BioPalmFeatureInfo value) {
        this.interDigitalLeft = value;
    }

    /**
     * Gets the value of the thenarLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getThenarLeft() {
        return thenarLeft;
    }

    /**
     * Sets the value of the thenarLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setThenarLeft(BioPalmFeatureInfo value) {
        this.thenarLeft = value;
    }

    /**
     * Gets the value of the hypothenarLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getHypothenarLeft() {
        return hypothenarLeft;
    }

    /**
     * Sets the value of the hypothenarLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setHypothenarLeft(BioPalmFeatureInfo value) {
        this.hypothenarLeft = value;
    }

    /**
     * Gets the value of the writerRight property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getWriterRight() {
        return writerRight;
    }

    /**
     * Sets the value of the writerRight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setWriterRight(BioPalmFeatureInfo value) {
        this.writerRight = value;
    }

    /**
     * Gets the value of the writerLeft property.
     * 
     * @return
     *     possible object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public BioPalmFeatureInfo getWriterLeft() {
        return writerLeft;
    }

    /**
     * Sets the value of the writerLeft property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioPalmFeatureInfo }
     *     
     */
    public void setWriterLeft(BioPalmFeatureInfo value) {
        this.writerLeft = value;
    }

}
