package com.nec.biomatcher.client.manager;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.request.EventRegistrationRequester;
import com.nec.biomatcher.webservices.SyncJobResultDto;

public class OneCircleSyncInsertRunner implements Runnable {
	private int jobCount;
	private String reqeustFileFullName;
	private File[] files;
	private static Logger logger = LoggerFactory.getLogger(OneCircleSyncInsertRunner.class);
	
	public OneCircleSyncInsertRunner(int jobCount, String reqFileFullPath) {
		this.jobCount = jobCount;
		this.reqeustFileFullName = reqFileFullPath;
		this.files = null;
	}
	
	public OneCircleSyncInsertRunner(File[] fileList) {	
		this.files = fileList;
		this.reqeustFileFullName = null;
	}
	
	public void runCircleJobByFileList() {	
		int count = files.length;
		//long oneCircleStart = System.currentTimeMillis();		
		for (File one : files) {
			if (!one.exists() || !one.isFile())
				return;
			EventRegistrationRequester rigester = new EventRegistrationRequester(one.getAbsolutePath());
			SyncJobResultDto result = rigester.submitSyncInsertJob();
			if (result != null && result.getJobId() != null) {
				logger.info("success get one job results.");						
			} else if (result == null) {
				logger.info("One job is faild!");
			}
			rigester = null;
			result = null;
		}
		logger.info("Success finished run one circle sync insert jobs. jobCount={}", count);		
		//PerformanceLogger.trace(OneCircleSyncInsertRunner.class.getSimpleName(), "runOneCircleJobs", null, String.valueOf(count), System.currentTimeMillis() - oneCircleStart);
	}
	
	
	
	public void runOneCircleJobs() {
		//long oneCircleStart = System.currentTimeMillis();
		int originalJobCount = this.jobCount;
		while(jobCount > 0) {
			EventRegistrationRequester rigester = new EventRegistrationRequester(reqeustFileFullName);
			SyncJobResultDto result = rigester.submitSyncInsertJob();
			if (result != null && result.getJobId() !=null) {
				logger.info("success get one job results.");							
			} else if (result == null){
				logger.info("One job is faild!");
			}
			jobCount--;	
			rigester = null;
			result = null;
		}
		logger.info("Success finished run one circle sync insert jobs. jobCount={}", originalJobCount);		
		//PerformanceLogger.trace(OneCircleSyncInsertRunner.class.getSimpleName(), "runOneCircleJobs", null,String.valueOf(originalJobCount), System.currentTimeMillis() - oneCircleStart);
	}

	@Override
	public void run() {
		if (this.files != null) {
			runCircleJobByFileList();
		} else if (this.reqeustFileFullName != null && this.jobCount > 0) {
			runOneCircleJobs();
		}		
	}
}
