
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for image complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="image">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="data" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/>
 *         &lt;element name="lobUri" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dpi" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="width" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="height" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="cropInfo" type="{http://webservices.biomatcher.nec.com/}bioCropInfo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="modality" type="{http://webservices.biomatcher.nec.com/}modality" minOccurs="0"/>
 *         &lt;element name="manualData" type="{http://webservices.biomatcher.nec.com/}extractManualData" minOccurs="0"/>
 *         &lt;element name="keyValueGroupList" type="{http://webservices.biomatcher.nec.com/}bioParameterGroupDto" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="type" use="required" type="{http://webservices.biomatcher.nec.com/}imageFormat" />
 *       &lt;attribute name="isBlackOnWhite" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="position" type="{http://webservices.biomatcher.nec.com/}imagePosition" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "image", propOrder = {
    "data",
    "lobUri",
    "dpi",
    "width",
    "height",
    "cropInfo",
    "modality",
    "manualData",
    "keyValueGroupList"
})
public class Image {

    @XmlElement(required = true)
    protected byte[] data;
    protected String lobUri;
    @XmlElementRef(name = "dpi", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> dpi;
    @XmlElementRef(name = "width", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> width;
    @XmlElementRef(name = "height", type = JAXBElement.class, required = false)
    protected JAXBElement<Integer> height;
    @XmlElement(nillable = true)
    protected List<BioCropInfo> cropInfo;
    @XmlElementRef(name = "modality", type = JAXBElement.class, required = false)
    protected JAXBElement<Modality> modality;
    @XmlElementRef(name = "manualData", type = JAXBElement.class, required = false)
    protected JAXBElement<ExtractManualData> manualData;
    @XmlElement(nillable = true)
    protected List<BioParameterGroupDto> keyValueGroupList;
    @XmlAttribute(name = "type", required = true)
    protected ImageFormat type;
    @XmlAttribute(name = "isBlackOnWhite")
    protected Boolean isBlackOnWhite;
    @XmlAttribute(name = "position")
    protected ImagePosition position;

    /**
     * Gets the value of the data property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getData() {
        return data;
    }

    /**
     * Sets the value of the data property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setData(byte[] value) {
        this.data = value;
    }

    /**
     * Gets the value of the lobUri property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLobUri() {
        return lobUri;
    }

    /**
     * Sets the value of the lobUri property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLobUri(String value) {
        this.lobUri = value;
    }

    /**
     * Gets the value of the dpi property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getDpi() {
        return dpi;
    }

    /**
     * Sets the value of the dpi property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setDpi(JAXBElement<Integer> value) {
        this.dpi = value;
    }

    /**
     * Gets the value of the width property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getWidth() {
        return width;
    }

    /**
     * Sets the value of the width property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setWidth(JAXBElement<Integer> value) {
        this.width = value;
    }

    /**
     * Gets the value of the height property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getHeight() {
        return height;
    }

    /**
     * Sets the value of the height property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setHeight(JAXBElement<Integer> value) {
        this.height = value;
    }

    /**
     * Gets the value of the cropInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cropInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCropInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BioCropInfo }
     * 
     * 
     */
    public List<BioCropInfo> getCropInfo() {
        if (cropInfo == null) {
            cropInfo = new ArrayList<BioCropInfo>();
        }
        return this.cropInfo;
    }

    /**
     * Gets the value of the modality property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Modality }{@code >}
     *     
     */
    public JAXBElement<Modality> getModality() {
        return modality;
    }

    /**
     * Sets the value of the modality property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Modality }{@code >}
     *     
     */
    public void setModality(JAXBElement<Modality> value) {
        this.modality = value;
    }

    /**
     * Gets the value of the manualData property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ExtractManualData }{@code >}
     *     
     */
    public JAXBElement<ExtractManualData> getManualData() {
        return manualData;
    }

    /**
     * Sets the value of the manualData property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ExtractManualData }{@code >}
     *     
     */
    public void setManualData(JAXBElement<ExtractManualData> value) {
        this.manualData = value;
    }

    /**
     * Gets the value of the keyValueGroupList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the keyValueGroupList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getKeyValueGroupList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BioParameterGroupDto }
     * 
     * 
     */
    public List<BioParameterGroupDto> getKeyValueGroupList() {
        if (keyValueGroupList == null) {
            keyValueGroupList = new ArrayList<BioParameterGroupDto>();
        }
        return this.keyValueGroupList;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link ImageFormat }
     *     
     */
    public ImageFormat getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link ImageFormat }
     *     
     */
    public void setType(ImageFormat value) {
        this.type = value;
    }

    /**
     * Gets the value of the isBlackOnWhite property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsBlackOnWhite() {
        return isBlackOnWhite;
    }

    /**
     * Sets the value of the isBlackOnWhite property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsBlackOnWhite(Boolean value) {
        this.isBlackOnWhite = value;
    }

    /**
     * Gets the value of the position property.
     * 
     * @return
     *     possible object is
     *     {@link ImagePosition }
     *     
     */
    public ImagePosition getPosition() {
        return position;
    }

    /**
     * Sets the value of the position property.
     * 
     * @param value
     *     allowed object is
     *     {@link ImagePosition }
     *     
     */
    public void setPosition(ImagePosition value) {
        this.position = value;
    }

}
