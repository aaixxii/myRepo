
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for verifyBiometricData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="verifyBiometricData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="containerId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="featureDataList" type="{http://webservices.biomatcher.nec.com/}featureData" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="templateInfoList" type="{http://webservices.biomatcher.nec.com/}templateInfo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="imageList" type="{http://webservices.biomatcher.nec.com/}featureExtractInputImage" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="candidateId" use="required" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "verifyBiometricData", propOrder = {
    "containerId",
    "featureDataList",
    "templateInfoList",
    "imageList"
})
public class VerifyBiometricData {

    protected Integer containerId;
    @XmlElement(nillable = true)
    protected List<FeatureData> featureDataList;
    @XmlElement(nillable = true)
    protected List<TemplateInfo> templateInfoList;
    @XmlElement(nillable = true)
    protected List<FeatureExtractInputImage> imageList;
    @XmlAttribute(name = "candidateId", required = true)
    protected String candidateId;

    /**
     * Gets the value of the containerId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getContainerId() {
        return containerId;
    }

    /**
     * Sets the value of the containerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setContainerId(Integer value) {
        this.containerId = value;
    }

    /**
     * Gets the value of the featureDataList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the featureDataList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFeatureDataList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeatureData }
     * 
     * 
     */
    public List<FeatureData> getFeatureDataList() {
        if (featureDataList == null) {
            featureDataList = new ArrayList<FeatureData>();
        }
        return this.featureDataList;
    }

    /**
     * Gets the value of the templateInfoList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the templateInfoList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTemplateInfoList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TemplateInfo }
     * 
     * 
     */
    public List<TemplateInfo> getTemplateInfoList() {
        if (templateInfoList == null) {
            templateInfoList = new ArrayList<TemplateInfo>();
        }
        return this.templateInfoList;
    }

    /**
     * Gets the value of the imageList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the imageList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getImageList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link FeatureExtractInputImage }
     * 
     * 
     */
    public List<FeatureExtractInputImage> getImageList() {
        if (imageList == null) {
            imageList = new ArrayList<FeatureExtractInputImage>();
        }
        return this.imageList;
    }

    /**
     * Gets the value of the candidateId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCandidateId() {
        return candidateId;
    }

    /**
     * Sets the value of the candidateId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCandidateId(String value) {
        this.candidateId = value;
    }

}
