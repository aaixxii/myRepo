package com.nec.biomatcher.client.priority;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType11Event;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.SearchItemInputPayloadDto;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchOptionsDto;
import com.nec.biomatcher.webservices.SearchRequestItemDto;

public class IIPriorityJobReqeustCreater {	
	private static final  String FunctionId = "II";
	private static final  Integer binIds[]  = {11};	
	
	private String leftDataFile = "IRIS_NEC_LEFT_IRIS.dat";
	private String rightDataFile = "IRIS_NEC_RIGHT_IRIS.dat";
	
	String templateType = "TEMPLATE_TYPE_11";
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(120);
	
	int MAX_HIT_CANDIDATES = 20;
	int MIN_HIT_SCORE_THRESHOLD = 1;
	
	public static GenderEnum searchGender = GenderEnum.M;
	public static Integer searchYob = 1977;
	public static Integer searchYobRange = 10;
	public static char searchRace = 'B';
	public static String searchRegionFlags = "32";
	public static String searchUserFlags = "iris1234";	
	Random rnd = new Random();
	
	private Integer priority;
	private Integer jobCount;	
	
	public IIPriorityJobReqeustCreater(Integer priority, Integer jobCount, String templatePath) {		
		this.priority = priority;
		this.jobCount = jobCount;
		this.leftDataFile = templatePath + "/" + leftDataFile;
		this.rightDataFile = templatePath + "/" + rightDataFile;
	}
	
	public List<SearchJobRequestDto> createSeachJobRequest() {
		List<SearchJobRequestDto> jobRequests = new ArrayList<>();
		for (int i = 0; i < jobCount; i++) {
			SearchJobRequestDto searchRq =  buildSeachJobRequest();
			jobRequests.add(searchRq);
		}
		return jobRequests;		
	}

	public SearchJobRequestDto buildSeachJobRequest() {		
		SearchJobRequestDto searchJobRequestDto = new SearchJobRequestDto();	
		String callbackUrl = "http://" + "192.168.22.118" + ":" + "5679";
		searchJobRequestDto.setCallbackUrl(callbackUrl);		
		ObjectFactory objectFactory = new ObjectFactory();		
		JAXBElement<Integer> rqPriority = objectFactory.createSearchJobRequestDtoPriority(priority);		
		searchJobRequestDto.setPriority(rqPriority);
		searchJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		searchJobRequestDto.setJobMode("live");
		JAXBElement<String> functionId = objectFactory.createSearchJobRequestDtoSearchFunctionId(FunctionId);
		searchJobRequestDto.setSearchFunctionId(functionId);		
		SearchRequestItemDto searchRequestItemDto = new SearchRequestItemDto();
		searchRequestItemDto.setSearchItemPayloadDto(buildSearchItemInputPayload());
		searchRequestItemDto.getBinIdList().addAll(Arrays.asList(binIds));
		searchJobRequestDto.getSearchRequestItemList().add(searchRequestItemDto);
		return searchJobRequestDto;
	}

	public SearchItemInputPayloadDto buildSearchItemInputPayload() {
		int exteralId = rnd.nextInt();
		int eventId = rnd.nextInt();
		SearchItemInputPayloadDto searchItemInputPayloadDto = new SearchItemInputPayloadDto();
		searchItemInputPayloadDto.setFunctionId(FunctionId);
		searchItemInputPayloadDto.setTemplateType(templateType);
		searchItemInputPayloadDto.setMaxHitCount(MAX_HIT_CANDIDATES);
		searchItemInputPayloadDto.setMinScoreThreshold(MIN_HIT_SCORE_THRESHOLD);		

		SearchOptionsDto searchOption = new SearchOptionsDto();		
		MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
		metaInfoCommon.setGender(searchGender);
		metaInfoCommon.setRace(String.valueOf(searchRace));
		ObjectFactory objectFactory = new ObjectFactory();			
		JAXBElement<Long> jaxLong = objectFactory.createMetaInfoCommonRegionFlags(Long.valueOf(searchRegionFlags));
		metaInfoCommon.setRegionFlags(jaxLong);		
		JAXBElement<String> userFlags = objectFactory.createMetaInfoCommonUserFlags("false");
		metaInfoCommon.setUserFlags(userFlags);		
		JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(searchYob);
		metaInfoCommon.setYob(yob);
		JAXBElement<Integer> yobRange = objectFactory.createMetaInfoCommonYobRange(searchYobRange);
		metaInfoCommon.setYobRange(yobRange);		
		searchOption.setMetaInfoCommon(metaInfoCommon);					
		searchItemInputPayloadDto.setSearchOptions(searchOption);		
		
		BioTemplatePayload bioTemplatePayload = new BioTemplatePayload();
		BioTemplateHeader bioTemplateHeader = new BioTemplateHeader();
		bioTemplateHeader.setExternalId(String.valueOf(exteralId));
		bioTemplateHeader.setGender(searchGender);
		bioTemplateHeader.setRace((byte)searchRace);
		bioTemplateHeader.setRegionFlags( searchRegionFlags.getBytes());
		bioTemplateHeader.setUserFlags(searchUserFlags.getBytes());
		bioTemplateHeader.setYob(searchYob.shortValue());
		bioTemplatePayload.setTemplateHeader(bioTemplateHeader);
		
		BioType11Event bioEvent = new BioType11Event();
		bioEvent.setEventId(String.valueOf(eventId));
		FileUtil fu = new FileUtil();		
		byte[] leftData = fu.getDataFromFile(leftDataFile);
		bioEvent.setIrisLeftNecFeatureData(leftData);		
		byte[] rightData = fu.getDataFromFile(rightDataFile);
		bioEvent.setIrisRightNecFeatureData(rightData);
		bioEvent.setIrisLeftQuality(50);
		bioEvent.setIrisRightQuality(60);		
		bioTemplatePayload.getEvents().add(bioEvent);		
		searchItemInputPayloadDto.setTemplatePayload(bioTemplatePayload);	
		return searchItemInputPayloadDto;
	}
}
