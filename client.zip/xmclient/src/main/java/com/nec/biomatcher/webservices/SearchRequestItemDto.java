
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for searchRequestItemDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="searchRequestItemDto">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestItemKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="binIdList" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="searchItemPayloadDto" type="{http://webservices.biomatcher.nec.com/}searchItemInputPayloadDto" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "searchRequestItemDto", propOrder = {
    "requestItemKey",
    "binIdList",
    "searchItemPayloadDto"
})
public class SearchRequestItemDto {

    protected String requestItemKey;
    @XmlElement(nillable = true)
    protected List<Integer> binIdList;
    protected SearchItemInputPayloadDto searchItemPayloadDto;

    /**
     * Gets the value of the requestItemKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestItemKey() {
        return requestItemKey;
    }

    /**
     * Sets the value of the requestItemKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestItemKey(String value) {
        this.requestItemKey = value;
    }

    /**
     * Gets the value of the binIdList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the binIdList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBinIdList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getBinIdList() {
        if (binIdList == null) {
            binIdList = new ArrayList<Integer>();
        }
        return this.binIdList;
    }

    /**
     * Gets the value of the searchItemPayloadDto property.
     * 
     * @return
     *     possible object is
     *     {@link SearchItemInputPayloadDto }
     *     
     */
    public SearchItemInputPayloadDto getSearchItemPayloadDto() {
        return searchItemPayloadDto;
    }

    /**
     * Sets the value of the searchItemPayloadDto property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchItemInputPayloadDto }
     *     
     */
    public void setSearchItemPayloadDto(SearchItemInputPayloadDto value) {
        this.searchItemPayloadDto = value;
    }

}
