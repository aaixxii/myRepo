
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioType32Event complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="bioType32Event">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioTemplateEvent">
 *       &lt;sequence>
 *         &lt;element name="rolledFingerQualities" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="slapFingerQualities" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="rolledCmlafFeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="slapCmlafFeatureData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "bioType32Event", propOrder = {
    "rolledFingerQualities",
    "slapFingerQualities",
    "rolledCmlafFeatureData",
    "slapCmlafFeatureData"
})
public class BioType32Event
    extends BioTemplateEvent
{

    @XmlElement(nillable = true)
    protected List<Integer> rolledFingerQualities;
    @XmlElement(nillable = true)
    protected List<Integer> slapFingerQualities;
    protected byte[] rolledCmlafFeatureData;
    protected byte[] slapCmlafFeatureData;

    /**
     * Gets the value of the rolledFingerQualities property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rolledFingerQualities property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRolledFingerQualities().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getRolledFingerQualities() {
        if (rolledFingerQualities == null) {
            rolledFingerQualities = new ArrayList<Integer>();
        }
        return this.rolledFingerQualities;
    }

    /**
     * Gets the value of the slapFingerQualities property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the slapFingerQualities property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSlapFingerQualities().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getSlapFingerQualities() {
        if (slapFingerQualities == null) {
            slapFingerQualities = new ArrayList<Integer>();
        }
        return this.slapFingerQualities;
    }

    /**
     * Gets the value of the rolledCmlafFeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getRolledCmlafFeatureData() {
        return rolledCmlafFeatureData;
    }

    /**
     * Sets the value of the rolledCmlafFeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setRolledCmlafFeatureData(byte[] value) {
        this.rolledCmlafFeatureData = value;
    }

    /**
     * Gets the value of the slapCmlafFeatureData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getSlapCmlafFeatureData() {
        return slapCmlafFeatureData;
    }

    /**
     * Sets the value of the slapCmlafFeatureData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setSlapCmlafFeatureData(byte[] value) {
        this.slapCmlafFeatureData = value;
    }

}
