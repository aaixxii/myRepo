
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for syncJobResultDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="syncJobResultDto">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}bioMatcherJobResult">
 *       &lt;sequence>
 *         &lt;element name="jobId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="errorList" type="{http://webservices.biomatcher.nec.com/}errorMessageDto" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="status" type="{http://webservices.biomatcher.nec.com/}bioJobStatus" minOccurs="0"/>
 *         &lt;element name="successfulEventSyncTypeDtoList" type="{http://webservices.biomatcher.nec.com/}biometricEventSyncTypeDto" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "syncJobResultDto", propOrder = {
    "jobId",
    "errorList",
    "status",
    "successfulEventSyncTypeDtoList"
})
public class SyncJobResultDto
    extends BioMatcherJobResult
{

    protected String jobId;
    @XmlElement(nillable = true)
    protected List<ErrorMessageDto> errorList;
    @XmlSchemaType(name = "string")
    protected BioJobStatus status;
    @XmlElement(nillable = true)
    protected List<BiometricEventSyncTypeDto> successfulEventSyncTypeDtoList;

    /**
     * Gets the value of the jobId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getJobId() {
        return jobId;
    }

    /**
     * Sets the value of the jobId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setJobId(String value) {
        this.jobId = value;
    }

    /**
     * Gets the value of the errorList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the errorList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getErrorList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ErrorMessageDto }
     * 
     * 
     */
    public List<ErrorMessageDto> getErrorList() {
        if (errorList == null) {
            errorList = new ArrayList<ErrorMessageDto>();
        }
        return this.errorList;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link BioJobStatus }
     *     
     */
    public BioJobStatus getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioJobStatus }
     *     
     */
    public void setStatus(BioJobStatus value) {
        this.status = value;
    }

    /**
     * Gets the value of the successfulEventSyncTypeDtoList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the successfulEventSyncTypeDtoList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSuccessfulEventSyncTypeDtoList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link BiometricEventSyncTypeDto }
     * 
     * 
     */
    public List<BiometricEventSyncTypeDto> getSuccessfulEventSyncTypeDtoList() {
        if (successfulEventSyncTypeDtoList == null) {
            successfulEventSyncTypeDtoList = new ArrayList<BiometricEventSyncTypeDto>();
        }
        return this.successfulEventSyncTypeDtoList;
    }

}
