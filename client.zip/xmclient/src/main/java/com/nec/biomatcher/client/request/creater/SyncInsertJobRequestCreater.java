package com.nec.biomatcher.client.request.creater;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_IP;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.InsertTemplateInfo;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncInsertJobRequestCreater {	
	String templateType = "TEMPLATE_TYPE_35";	
	public SyncInsertJobRequestCreater() {		
	}
	
	public SyncJobRequestDto buildSyncInsertRequest(String templateFileName) {
		String callbackIp = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_IP);
		String callbackPort = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT);
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;		
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);			
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(3600000L);		
		List<BiometricEventSyncTypeDto>  syncList = new ArrayList<>();
		syncList.add(buildInsertBiometricEventDto(templateFileName));
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;		
	}
	
	private InsertBiometricEventDto buildInsertBiometricEventDto(String templateFileName) {
		InsertBiometricEventDto ibeDto = new InsertBiometricEventDto();
		 Random rnd = new Random();
		 ibeDto.setExternalId(String.valueOf(rnd.nextInt()));
		 ibeDto.setEventId(String.valueOf(rnd.nextInt()));
		 ibeDto.setUpdateFlag(false);
		 InsertTemplateInfo template = new InsertTemplateInfo();
		 template.setBinId(35);
		 template.setTemplateType(templateType);	
		 FileUtil fu = new FileUtil();
		byte[] data = fu.getDataFromFile(templateFileName);
		template.setTemplateData(data);
		List<InsertTemplateInfo> tepList = new ArrayList<>();
		 tepList.add(template);
		 ibeDto.getInsertTemplateInfoList().addAll(tepList);
		 fu = null;
		return ibeDto;
	}
}
