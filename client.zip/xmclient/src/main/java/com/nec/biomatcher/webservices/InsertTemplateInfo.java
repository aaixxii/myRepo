
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for insertTemplateInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="insertTemplateInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="binId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="templateType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="templateData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="templatePayload" type="{http://webservices.biomatcher.nec.com/}bioTemplatePayload" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "insertTemplateInfo", propOrder = {
    "binId",
    "templateType",
    "templateData",
    "templatePayload"
})
public class InsertTemplateInfo {

    protected int binId;
    protected String templateType;
    protected byte[] templateData;
    protected BioTemplatePayload templatePayload;

    /**
     * Gets the value of the binId property.
     * 
     */
    public int getBinId() {
        return binId;
    }

    /**
     * Sets the value of the binId property.
     * 
     */
    public void setBinId(int value) {
        this.binId = value;
    }

    /**
     * Gets the value of the templateType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTemplateType() {
        return templateType;
    }

    /**
     * Sets the value of the templateType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTemplateType(String value) {
        this.templateType = value;
    }

    /**
     * Gets the value of the templateData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getTemplateData() {
        return templateData;
    }

    /**
     * Sets the value of the templateData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setTemplateData(byte[] value) {
        this.templateData = value;
    }

    /**
     * Gets the value of the templatePayload property.
     * 
     * @return
     *     possible object is
     *     {@link BioTemplatePayload }
     *     
     */
    public BioTemplatePayload getTemplatePayload() {
        return templatePayload;
    }

    /**
     * Sets the value of the templatePayload property.
     * 
     * @param value
     *     allowed object is
     *     {@link BioTemplatePayload }
     *     
     */
    public void setTemplatePayload(BioTemplatePayload value) {
        this.templatePayload = value;
    }

}
