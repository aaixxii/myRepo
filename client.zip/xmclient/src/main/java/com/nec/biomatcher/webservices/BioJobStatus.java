
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for bioJobStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="bioJobStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PENDING"/>
 *     &lt;enumeration value="COMPLETED"/>
 *     &lt;enumeration value="NOT_FOUND"/>
 *     &lt;enumeration value="FAILD"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "bioJobStatus")
@XmlEnum
public enum BioJobStatus {

    PENDING,
    COMPLETED,
    NOT_FOUND,
    FAILD;

    public String value() {
        return name();
    }

    public static BioJobStatus fromValue(String v) {
        return valueOf(v);
    }

}
