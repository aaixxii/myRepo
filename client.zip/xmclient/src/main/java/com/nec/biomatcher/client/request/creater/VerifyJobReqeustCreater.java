package com.nec.biomatcher.client.request.creater;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_IP;
import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;

import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.manager.XmClientManager;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.VerifyJobRequestDto;

public class VerifyJobReqeustCreater {	
	private static Logger logger = LoggerFactory.getLogger(SearchJobReqeustCreater.class);
	long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(60);


	public VerifyJobReqeustCreater() {		
	}

	public VerifyJobRequestDto buildVerifyJobRequest(String dataFile) {	
		VerifyJobRequestDto verifyJobRequestDto = new VerifyJobRequestDto();		
		String callbackIp = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_IP);
		String callbackPort = XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT);
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;
		verifyJobRequestDto.setCallbackUrl(callbackUrl);
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<Integer> priority = objectFactory.createExtractJobRequestDtoPriority(10);
		verifyJobRequestDto.setPriority(priority);
		verifyJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		verifyJobRequestDto.setJobMode("live");
		logger.info("ToDo");
		//ToDo

		return verifyJobRequestDto;
	}
}
