package com.nec.biomatcher.client.priority;

import java.util.ArrayList;
import java.util.List;

import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.SearchJobRequestDto;

public class TILIPriorityJobReqeustCreater {
	private String xmlFile = "search_type_44vs42.xml";	
	private Integer jobCount;	
	String templateType = "TEMPLATE_TYPE_42";
	
	public TILIPriorityJobReqeustCreater(Integer jobCount, String templatePath) {		
		this.jobCount = jobCount;
		this.xmlFile = templatePath + "/" + xmlFile;
	}
	
	public List<SearchJobRequestDto> createSeachJobRequest() {
		List<SearchJobRequestDto> jobRequests = new ArrayList<>();
		for (int i = 0; i < jobCount; i++) {
			SearchJobRequestDto searchRq =  buildSeachJobRequest();
			jobRequests.add(searchRq);
		}
		return jobRequests;		
	}
	public SearchJobRequestDto buildSeachJobRequest() {
		JaxBUtil<SearchJobRequestDto> jaxbUtil = new JaxBUtil<SearchJobRequestDto>();
		SearchJobRequestDto searchJobRequest = jaxbUtil.unmarshalFromFile(SearchJobRequestDto.class, xmlFile);
		return searchJobRequest;	
	}
}
