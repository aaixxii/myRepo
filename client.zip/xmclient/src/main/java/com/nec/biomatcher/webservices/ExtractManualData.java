
package com.nec.biomatcher.webservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for extractManualData complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="extractManualData">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="editedMinutia" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *         &lt;element name="markup" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "extractManualData", propOrder = {
    "editedMinutia",
    "markup"
})
public class ExtractManualData {

    protected byte[] editedMinutia;
    protected byte[] markup;

    /**
     * Gets the value of the editedMinutia property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getEditedMinutia() {
        return editedMinutia;
    }

    /**
     * Sets the value of the editedMinutia property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setEditedMinutia(byte[] value) {
        this.editedMinutia = value;
    }

    /**
     * Gets the value of the markup property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getMarkup() {
        return markup;
    }

    /**
     * Sets the value of the markup property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setMarkup(byte[] value) {
        this.markup = value;
    }

}
