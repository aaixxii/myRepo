
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for irisExtractInputImage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="irisExtractInputImage">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}extractInputImage">
 *       &lt;sequence>
 *         &lt;element name="leftEyeImage" type="{http://webservices.biomatcher.nec.com/}image" minOccurs="0"/>
 *         &lt;element name="rightEyeImage" type="{http://webservices.biomatcher.nec.com/}image" minOccurs="0"/>
 *         &lt;element name="extractionParameters" type="{http://webservices.biomatcher.nec.com/}extractInputParameter" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "irisExtractInputImage", propOrder = {
    "leftEyeImage",
    "rightEyeImage",
    "extractionParameters"
})
public class IrisExtractInputImage
    extends ExtractInputImage
{

    protected Image leftEyeImage;
    protected Image rightEyeImage;
    @XmlElement(nillable = true)
    protected List<ExtractInputParameter> extractionParameters;

    /**
     * Gets the value of the leftEyeImage property.
     * 
     * @return
     *     possible object is
     *     {@link Image }
     *     
     */
    public Image getLeftEyeImage() {
        return leftEyeImage;
    }

    /**
     * Sets the value of the leftEyeImage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Image }
     *     
     */
    public void setLeftEyeImage(Image value) {
        this.leftEyeImage = value;
    }

    /**
     * Gets the value of the rightEyeImage property.
     * 
     * @return
     *     possible object is
     *     {@link Image }
     *     
     */
    public Image getRightEyeImage() {
        return rightEyeImage;
    }

    /**
     * Sets the value of the rightEyeImage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Image }
     *     
     */
    public void setRightEyeImage(Image value) {
        this.rightEyeImage = value;
    }

    /**
     * Gets the value of the extractionParameters property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the extractionParameters property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getExtractionParameters().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ExtractInputParameter }
     * 
     * 
     */
    public List<ExtractInputParameter> getExtractionParameters() {
        if (extractionParameters == null) {
            extractionParameters = new ArrayList<ExtractInputParameter>();
        }
        return this.extractionParameters;
    }

}
