
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for verifyCandidateResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="verifyCandidateResult">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="candidateId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fusionScore" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/>
 *         &lt;element name="modalScoreList" type="{http://webservices.biomatcher.nec.com/}verifyModalScore" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="success" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "verifyCandidateResult", propOrder = {
    "candidateId",
    "fusionScore",
    "modalScoreList",
    "success"
})
public class VerifyCandidateResult {

    protected String candidateId;
    protected Double fusionScore;
    @XmlElement(nillable = true)
    protected List<VerifyModalScore> modalScoreList;
    protected boolean success;

    /**
     * Gets the value of the candidateId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCandidateId() {
        return candidateId;
    }

    /**
     * Sets the value of the candidateId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCandidateId(String value) {
        this.candidateId = value;
    }

    /**
     * Gets the value of the fusionScore property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getFusionScore() {
        return fusionScore;
    }

    /**
     * Sets the value of the fusionScore property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setFusionScore(Double value) {
        this.fusionScore = value;
    }

    /**
     * Gets the value of the modalScoreList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the modalScoreList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getModalScoreList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link VerifyModalScore }
     * 
     * 
     */
    public List<VerifyModalScore> getModalScoreList() {
        if (modalScoreList == null) {
            modalScoreList = new ArrayList<VerifyModalScore>();
        }
        return this.modalScoreList;
    }

    /**
     * Gets the value of the success property.
     * 
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * Sets the value of the success property.
     * 
     */
    public void setSuccess(boolean value) {
        this.success = value;
    }

}
