
package com.nec.biomatcher.webservices;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateBiometricEventUserFlagDto complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateBiometricEventUserFlagDto">
 *   &lt;complexContent>
 *     &lt;extension base="{http://webservices.biomatcher.nec.com/}biometricEventSyncTypeDto">
 *       &lt;sequence>
 *         &lt;element name="updateUserFlagMode" type="{http://webservices.biomatcher.nec.com/}updateUserFlagMode" minOccurs="0"/>
 *         &lt;element name="binIdList" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="userFlags" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateBiometricEventUserFlagDto", propOrder = {
    "updateUserFlagMode",
    "binIdList",
    "userFlags"
})
public class UpdateBiometricEventUserFlagDto
    extends BiometricEventSyncTypeDto
{

    @XmlSchemaType(name = "string")
    protected UpdateUserFlagMode updateUserFlagMode;
    @XmlElement(nillable = true)
    protected List<Integer> binIdList;
    protected String userFlags;

    /**
     * Gets the value of the updateUserFlagMode property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateUserFlagMode }
     *     
     */
    public UpdateUserFlagMode getUpdateUserFlagMode() {
        return updateUserFlagMode;
    }

    /**
     * Sets the value of the updateUserFlagMode property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateUserFlagMode }
     *     
     */
    public void setUpdateUserFlagMode(UpdateUserFlagMode value) {
        this.updateUserFlagMode = value;
    }

    /**
     * Gets the value of the binIdList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the binIdList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBinIdList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getBinIdList() {
        if (binIdList == null) {
            binIdList = new ArrayList<Integer>();
        }
        return this.binIdList;
    }

    /**
     * Gets the value of the userFlags property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserFlags() {
        return userFlags;
    }

    /**
     * Sets the value of the userFlags property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserFlags(String value) {
        this.userFlags = value;
    }

}
