package com.nec.biomatcher.client.request.creater;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.xml.bind.JAXBException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.BiometricEventSyncTypeDto;
import com.nec.biomatcher.webservices.InsertBiometricEventDto;
import com.nec.biomatcher.webservices.InsertTemplateInfo;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncInsert36RequestCreaterTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBuildSyncUpdateRequest() throws JAXBException {		
		SyncJobRequestDto insertRequest =buildSyncInsertRequest();
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		jaxb.marshalToFile(SyncJobRequestDto.class, insertRequest, "/C:/Users/000001A006PBP/Desktop/test/sync_insert_request_36.xml");
		System.out.println("OKOKOK");
	}
	
	public SyncJobRequestDto buildSyncInsertRequest() {
		String callbackIp = "192.168.22.118";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;		
		SyncJobRequestDto syncJobRequestDto = new SyncJobRequestDto();
		syncJobRequestDto.setCallbackUrl(callbackUrl);			
		syncJobRequestDto.setJobMode("strict");
		syncJobRequestDto.setJobTimeoutMill(3600000L);		
		List<BiometricEventSyncTypeDto>  syncList = new ArrayList<>();
		syncList.add(buildInsertBiometricEventDto());
		syncJobRequestDto.getEventSyncDtoList().addAll(syncList);
		return syncJobRequestDto;		
	}
	
	private InsertBiometricEventDto buildInsertBiometricEventDto() {
		InsertBiometricEventDto ibeDto = new InsertBiometricEventDto();
		 Random rnd = new Random();
		 ibeDto.setExternalId(String.valueOf(rnd.nextInt()));
		 ibeDto.setEventId(String.valueOf(rnd.nextInt()));
		 ibeDto.setUpdateFlag(false);
		 InsertTemplateInfo template = new InsertTemplateInfo();
		 template.setBinId(36);
		 template.setTemplateType("TEMPLATE_TYPE_36");	
		 FileUtil fu = new FileUtil();
		byte[] data = fu.getDataFromFile("/C:/Users/000001A006PBP/Desktop/test/TEMPLATE_TYPE_36_0.dat");
		template.setTemplateData(data);
		List<InsertTemplateInfo> tepList = new ArrayList<>();
		 tepList.add(template);
		 ibeDto.getInsertTemplateInfoList().addAll(tepList);
		 fu = null;
		return ibeDto;
	}	
}
