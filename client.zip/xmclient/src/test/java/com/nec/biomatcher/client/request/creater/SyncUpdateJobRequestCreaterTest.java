package com.nec.biomatcher.client.request.creater;

import javax.xml.bind.JAXBException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.SyncJobRequestDto;

public class SyncUpdateJobRequestCreaterTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBuildSyncUpdateRequest() throws JAXBException {
		SyncUpdateJobRequestCreater creater = new SyncUpdateJobRequestCreater(null);
		SyncJobRequestDto updateRequest = creater.buildSyncUpdateRequest();
		JaxBUtil<SyncJobRequestDto> jaxb = new JaxBUtil<SyncJobRequestDto>();
		jaxb.marshalToFile(SyncJobRequestDto.class, updateRequest, "/C:/Users/000001A006PBP/Desktop/test/sync_update_request_1.xml");
		System.out.println("OKOKOK");
	}
}
