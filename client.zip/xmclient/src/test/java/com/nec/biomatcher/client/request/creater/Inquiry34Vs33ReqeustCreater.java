package com.nec.biomatcher.client.request.creater;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.junit.Test;

import com.nec.biomatcher.client.util.FileUtil;
import com.nec.biomatcher.client.util.JaxBUtil;
import com.nec.biomatcher.webservices.AlgorithmType;
import com.nec.biomatcher.webservices.BioFeType;
import com.nec.biomatcher.webservices.BioTemplateEvent;
import com.nec.biomatcher.webservices.BioTemplateHeader;
import com.nec.biomatcher.webservices.BioTemplatePayload;
import com.nec.biomatcher.webservices.BioType34Event;
import com.nec.biomatcher.webservices.GenderEnum;
import com.nec.biomatcher.webservices.ImagePosition;
import com.nec.biomatcher.webservices.MetaInfoCommon;
import com.nec.biomatcher.webservices.ObjectFactory;
import com.nec.biomatcher.webservices.PatternType;
import com.nec.biomatcher.webservices.SearchItemInputPayloadDto;
import com.nec.biomatcher.webservices.SearchJobRequestDto;
import com.nec.biomatcher.webservices.SearchOptionsDto;
import com.nec.biomatcher.webservices.SearchRequestItemDto;


public class Inquiry34Vs33ReqeustCreater {
	private static final String outputDir = "/C:/Users/xia/Desktop/test/";	
	private static final  Integer priority = 4;
	private static final  Integer jobCount = 10;
	private static final  String FunctionId = "LI";
	private static final  Integer binIds[]  = {33};
	private static final  String dataFileFMP5= "/C:/Users/000001A006PBP/Desktop/test/LDB_LE_FMP5_C.minutia.dat";
	private static final  String dataFilePC2= "/C:/Users/000001A006PBP/Desktop/test/RDBLS_PC2_SATOM_E.minutia.dat";
	
	public static GenderEnum searchGender = GenderEnum.M;
	public static Integer searchYob = 1977;
	public static Integer searchYobRange = 10;
	public static  char searchRace = 'B';
	public static String searchRegionFlags = "32";
	public static String searchUserFlags = "LI34VS33";
	
	public static int USER_FLAGS_MAX_BYTE_SIZE = 8;
	public static int MAX_HIT_CANDIDATES = 20;
	public static int MIN_HIT_SCORE_THRESHOLD = 1;
	public static Random rnd = new Random();
	
	String templateType = "TEMPLATE_TYPE_34";
	
	private  ImagePosition selectedFingers[] = { ImagePosition.ROLL_RTHUMB, ImagePosition.ROLL_RINDEX,
			ImagePosition.ROLL_RMIDDLE, ImagePosition.ROLL_RRING, ImagePosition.ROLL_RLITTLE,
			ImagePosition.ROLL_LTHUMB, ImagePosition.ROLL_LINDEX, ImagePosition.ROLL_LMIDDLE,
			ImagePosition.ROLL_LRING, ImagePosition.ROLL_LLITTLE };
	
	private   PatternType selectedPattern []  = { PatternType.A, PatternType.T, PatternType.R,
			PatternType.L, PatternType.W, PatternType.S, PatternType.N };

	@Test
	public void testBuildSeachJobRequest() throws JAXBException {
		for (int i = 0; i < jobCount; i++) {
			SearchJobRequestDto searchRq =  buildSeachJobRequest();
			JaxBUtil<SearchJobRequestDto> jaxb = new JaxBUtil<SearchJobRequestDto>();
			String outputFileName = "search_request" + "_" + FunctionId + "_" + priority + "_" + i + ".xml";
			String outputFullName = outputDir + outputFileName;
			jaxb.marshalToFile(SearchJobRequestDto.class, searchRq, outputFullName);
			System.out.println("OKOKOK");
		}
	}


	public SearchJobRequestDto buildSeachJobRequest() {		
		SearchJobRequestDto searchJobRequestDto = new SearchJobRequestDto();	
		String callbackUrl = "http://" + "192.168.22.118" + ":" + "5679";
		searchJobRequestDto.setCallbackUrl(callbackUrl);		
		ObjectFactory objectFactory = new ObjectFactory();		
		JAXBElement<Integer> rqPriority = objectFactory.createSearchJobRequestDtoPriority(priority);		
		searchJobRequestDto.setPriority(rqPriority);
		searchJobRequestDto.setJobTimeoutMill(3600000L);
		searchJobRequestDto.setJobMode("live");
		JAXBElement<String> functionId = objectFactory.createSearchJobRequestDtoSearchFunctionId(FunctionId);
		searchJobRequestDto.setSearchFunctionId(functionId);
		SearchRequestItemDto searchRequestItemDto = new SearchRequestItemDto();
		searchRequestItemDto.setSearchItemPayloadDto(buildSearchItemInputPayload());
		searchRequestItemDto.getBinIdList().addAll(Arrays.asList(binIds));
		searchJobRequestDto.getSearchRequestItemList().add(searchRequestItemDto);
		return searchJobRequestDto;
	}
	
	public SearchItemInputPayloadDto buildSearchItemInputPayload() {
		SearchItemInputPayloadDto searchItemInputPayloadDto = new SearchItemInputPayloadDto();
		//searchItemInputPayloadDto.setFunctionId(FunctionId);
		searchItemInputPayloadDto.setTemplateType(templateType);
		searchItemInputPayloadDto.setMaxHitCount(MAX_HIT_CANDIDATES);
		searchItemInputPayloadDto.setMinScoreThreshold(MIN_HIT_SCORE_THRESHOLD);		

		SearchOptionsDto searchOptions = new SearchOptionsDto();
		MetaInfoCommon metaInfoCommon = new MetaInfoCommon();
		metaInfoCommon.setGender(searchGender);
		metaInfoCommon.setRace(String.valueOf(searchRace));
		ObjectFactory objectFactory = new ObjectFactory();		
		
		JAXBElement<Long> jaxLong = objectFactory.createMetaInfoCommonRegionFlags(1L);
		metaInfoCommon.setRegionFlags(jaxLong);
		
		JAXBElement<String> userFlags = objectFactory.createMetaInfoCommonUserFlags("false");
		metaInfoCommon.setUserFlags(userFlags);
		
		JAXBElement<Integer> yob = objectFactory.createMetaInfoCommonYob(searchYob);
		metaInfoCommon.setYob(yob);
		JAXBElement<Integer> yobRange = objectFactory.createMetaInfoCommonYobRange(searchYobRange);
		metaInfoCommon.setYobRange(yobRange);		
		searchOptions.setMetaInfoCommon(metaInfoCommon);					
		searchItemInputPayloadDto.setSearchOptions(searchOptions);		
		searchItemInputPayloadDto.setTemplatePayload(buildbioTemplatePayload());		
		return searchItemInputPayloadDto;
	}
	
	public  BioTemplatePayload buildbioTemplatePayload() {
		FileUtil fu = new FileUtil();
		BioTemplatePayload bioTemplatePayload = new BioTemplatePayload();
		BioTemplateHeader bioTemplateHeader = new BioTemplateHeader();
		int exteralId = rnd.nextInt();	
		exteralId = exteralId > 0 ? exteralId : -1 * exteralId;
		int eventId = rnd.nextInt();
		eventId = eventId > 0 ? eventId : -1 * eventId;
		bioTemplateHeader.setExternalId(String.valueOf(exteralId));
		bioTemplateHeader.setGender(searchGender);
		bioTemplateHeader.setYob(searchYob.shortValue());
		bioTemplateHeader.setRace((byte)searchRace);
		bioTemplateHeader.setRegionFlags(searchRegionFlags.getBytes());
		bioTemplateHeader.setUserFlags(searchUserFlags.getBytes());			
		bioTemplatePayload.setTemplateHeader(bioTemplateHeader);		
		List<BioTemplateEvent> templateEventList = new ArrayList<>();
		
		BioType34Event bioEventfmp5 = new BioType34Event();
		bioEventfmp5.setEventId(String.valueOf(eventId));
		bioEventfmp5.setAlgorithmType(AlgorithmType.FINGER_FMP_5);
		bioEventfmp5.setFeType(BioFeType.C);	
		bioEventfmp5.getFingerNumbers().addAll(Arrays.asList(selectedFingers));
		bioEventfmp5.getLatentPatterns().addAll(Arrays.asList(selectedPattern));
		byte[] tempalteDataFMP5 = fu.getDataFromFile(dataFileFMP5);
		bioEventfmp5.setLatentFeatureData(tempalteDataFMP5);	
		templateEventList.add(bioEventfmp5);		
	
		BioType34Event bioEventPC2 = new BioType34Event();
		bioEventPC2.setEventId(String.valueOf(eventId));
		bioEventPC2.setAlgorithmType(AlgorithmType.FINGER_PC_2);
		bioEventPC2.setFeType(BioFeType.E);
		bioEventPC2.getFingerNumbers().addAll(Arrays.asList(selectedFingers));
		bioEventPC2.getLatentPatterns().addAll(Arrays.asList(selectedPattern));
		byte[] tempalteDataPC2 = fu.getDataFromFile(dataFilePC2);
		bioEventPC2.setLatentFeatureData(tempalteDataPC2);
		templateEventList.add(bioEventPC2);		
		bioTemplatePayload.getEvents().addAll(templateEventList);		
		return bioTemplatePayload;
	}
}
