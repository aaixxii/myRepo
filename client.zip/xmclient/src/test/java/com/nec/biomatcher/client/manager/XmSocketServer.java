package com.nec.biomatcher.client.manager;

import static com.nec.biomatcher.client.common.XmClientConstants.CLIENT_CALLBACK_PORT;
import static com.nec.biomatcher.client.common.XmClientConstants.CLINET_CALLBACK_PATH;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.exception.XmClientException;

/**
 * @author xiazp <br/>
 *  Socket Server accept connections from megha<br/>
 */
public class XmSocketServer implements Runnable {
	private int callbackPort;
	private static String outPath;
	private static Logger logger = LoggerFactory.getLogger("XmSocketServer");
	private ServerSocketChannel serverSocketChannel ;
	private Selector selector;
	
	public XmSocketServer() throws IOException {
		init();
	}

	/**
	 * Socket Server initialize and startup
	 */
	private void init() {
		outPath = XmClientManager.getInstance().getValue(CLINET_CALLBACK_PATH);
		outPath = outPath.endsWith("/") ? outPath : outPath + "/";
		callbackPort = Integer.valueOf(XmClientManager.getInstance().getValue(CLIENT_CALLBACK_PORT));
		try {
			selector = Selector.open();
			serverSocketChannel = ServerSocketChannel.open();
			serverSocketChannel.socket().setReuseAddress(true);
			serverSocketChannel.socket().setSoTimeout(6000);
			serverSocketChannel.configureBlocking(false);
			serverSocketChannel.socket().bind(new InetSocketAddress(callbackPort));
		} catch (IOException e) {
			String errmsg = "Can't starting MMR socket server!";
			throw new XmClientException(errmsg, e.getCause());
		}
		logger.info("Calllback Server is started!");
	}
		
	

	/**
	 * Socket Server accept client connection
	 * 
	 * @author xiazp
	 * @param
	 * @return
	 * @throws IOException
	 */
	public void service() throws IOException {
		serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
		while (selector.select() > 0) {
			Set<SelectionKey> readyKeys = selector.selectedKeys();
			Iterator<SelectionKey> it = readyKeys.iterator();
			while (it.hasNext()) {
				SelectionKey key = null;
				try {
					key = (SelectionKey) it.next();
					it.remove();
					if (key.isAcceptable()) {
						SocketChannel socketChannel = serverSocketChannel.accept();
						socketChannel.configureBlocking(false);
						logger.info("Megha is connectecd to me! ip:{}", socketChannel.getRemoteAddress());
						SelectionKey clientKey = socketChannel.register(selector, SelectionKey.OP_READ);
						if (clientKey.isReadable()) {
//							 CallbackWriterNew cw = new CallbackWriterNew(socketChannel, outPath);
//							 Thread writeTask = new Thread(cw);
//							 writeTask.start();
						}
					}
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
					try {
						if (key != null) {
							key.cancel();
							key.channel().close();
						}
					} catch (Exception ex) {
						logger.error(e.getMessage(), e);
					}
				}
			} // #while
		} // #while
	}

	@Override
	public void run() {		
		try {
			service();
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}
	


}