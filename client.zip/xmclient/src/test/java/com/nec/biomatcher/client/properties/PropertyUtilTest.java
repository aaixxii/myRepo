package com.nec.biomatcher.client.properties;


import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.Assert;
import org.junit.Test;

import com.nec.biomatcher.client.properties.PropertyUtil;



public class PropertyUtilTest {
	@Test
	public void testGetPropertyLongValue() {
		URL url = Thread.currentThread().getContextClassLoader().getResource("xm.client.properties");		
		PropertyUtil pu = new PropertyUtil(url.getPath());
		String result = pu.getPropertyValue("MEGHA_WS_PORT_NUM");
		Assert.assertEquals("8080", result);		
	}

	@Test
	public void testSetPropertyValue() {
		URL url = Thread.currentThread().getContextClassLoader().getResource("xm.client.properties");		
		PropertyUtil pu = new PropertyUtil(url.getPath());
		int result = pu.getPropertyCount();
		Assert.assertEquals(6, result);		
	}
	
	@Test
	public void testTime() {	
		LocalDateTime now = LocalDateTime.now();
		 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
		 String formatDateTime = now.format(formatter);
	        System.out.println( formatDateTime);

		
	}

}
