package com.nec.biomatcher.client.util;

import static com.nec.biomatcher.client.common.XmClientConstants.JOB_RESULT_PATH_XLSX;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.biomatcher.client.manager.XmClientManager;

public class ExcelWriterForTester {
	private String sheetName;
	private XSSFWorkbook workbook;
	private XSSFSheet sheet;
	private int lastRow = 0;
	private String jobId;

	private static Logger logger = LoggerFactory.getLogger(ExcelWriter.class);

	public ExcelWriterForTester(String jobId) {
		this.jobId = jobId;
		this.sheetName = jobId + ".xlsx";
		init();
	}

	private void init() {
		workbook = new XSSFWorkbook();
		sheet = workbook.createSheet(sheetName);
	}

	public void prepareExcellData(Object[] objectArrarys) {
		for (int i = 0; i < objectArrarys.length; i++) {
			String[][] temp = (String[][]) objectArrarys[i];
			if (temp != null && temp.length > 0) {
				createExcellData(temp);
			}			
		}
		writeToFile();
	}

	public void createExcellData(String[][] datas) {
		lastRow += 1;
		for (String[] oneRow : datas) {
			Row row = sheet.createRow(lastRow++);
			int colNum = 1;
			for (String oneCell : oneRow) {
				Cell cell = row.createCell(colNum++);
				cell.setCellValue(oneCell);
			}
		}
	}

	public void writeToFile() {
		String resultPath =  XmClientManager.getInstance().getValue(JOB_RESULT_PATH_XLSX);	
		try {
			FileOutputStream outputStream = new FileOutputStream(resultPath + sheetName);
			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
			logger.info("Sucess writing data to excel for job({}).", jobId);
			System.out.println("Succed to create excel!");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}

}
