#insert init data todm_info table
use DMDEMO;
insert into dm_info(dm_id,server_type,server_hostname, connection_url) values('dm_service1','dm_service','sv06','http://192.168.22.106:8080/dm');
insert into dm_info(dm_id,server_type,server_hostname, connection_url) values('dm_service2','dm_service','sv07','http://192.168.22.107:8080/dm');

insert into dm_info(dm_id,server_type,server_hostname, connection_url) values('dm_master1','master','sv02','http://192.168.22.102:8080');
insert into dm_info(dm_id,server_type,server_hostname, connection_url) values('dm_master2','master','sv02','http://192.168.22.102:8081');
insert into dm_info(dm_id,server_type,server_hostname, connection_url) values('dm_master3','master','sv02','http://192.168.22.102:8082');

insert into dm_info(dm_id,server_type,server_hostname, connection_url) values('dm_storage1','node_storage','sv09','http://192.168.22.109:8080');
insert into dm_info(dm_id,server_type,server_hostname, connection_url) values('dm_storage2','node_storage','sv09','http://192.168.22.109:8081');
insert into dm_info(dm_id,server_type,server_hostname, connection_url) values('dm_storage3','node_storage','sv09','http://192.168.22.109:8082');

insert into node_storage(storage_id,dm_storage_id,url, disk_size, space,status, update_ts) values(1,'dm_storage1','http://192.168.22.109:8080',200000,500000,0,CURRENT_TIMESTAMP());
insert into node_storage(storage_id,dm_storage_id,url, disk_size, space,status, update_ts) values(2,'dm_storage2','http://192.168.22.109:8081',200000,500000,0,CURRENT_TIMESTAMP());
insert into node_storage(storage_id,dm_storage_id,url, disk_size, space,status, update_ts) values(3,'dm_storage3','http://192.168.22.109:8082',200000,500000,0,CURRENT_TIMESTAMP());


#for election leader
insert into master(master_id,dm_master_id, one_time_interval, last_ts) values(0,'dm_master1',100,CURRENT_TIMESTAMP());

insert into dm_config_info(key_name, key_value) values('redundancy',3);
insert into dm_config_info(key_name, key_value) values('max_segment_size',100000000);
insert into dm_config_info(key_name, key_value) values('node_storage_heatbeat_interval',6000);

COMMIT;
