CREATE DEFINER = `aimuser`@`%` PROCEDURE `delete_extract_job` (IN p_extract_job_id int)
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DELETE
    FROM fe_job_queue
  WHERE job_id = p_extract_job_id;
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
END