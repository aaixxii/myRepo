CREATE DEFINER = `aimuser`@`%` PROCEDURE `check_container` (IN p_container_id int)
BEGIN
  DECLARE l_count int;
  DECLARE fetch_state int DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION SET fetch_state = 1;
  SELECT
    COUNT(c.container_id) INTO l_count
  FROM containers c
  WHERE c.container_id = p_container_id;
  IF l_count <= 0 THEN
    SET fetch_state = 1;
  END IF;
  SELECT
    @my_error;
END