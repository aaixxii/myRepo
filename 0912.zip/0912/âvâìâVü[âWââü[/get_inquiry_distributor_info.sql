CREATE DEFINER = `aimuser`@`%` PROCEDURE `get_inquiry_distributor_info` (IN p_job_id int,
IN p_function_id int,
IN p_plan_id int)
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SELECT
    jq.failure_count,
    fj.search_request_index,
    fj.inquiry_job_data,
    ft.container_job_timeouts,
    GREATEST(jq.max_candidates, nvl(ft.internal_candidate_size, 0)) AS internal_candidate_size,
    cj.container_job_id
  FROM job_queue jq,
       fusion_jobs fj,
       function_types ft,
       container_jobs cj
  WHERE jq.job_id = fj.job_id
  AND fj.function_id = ft.function_id
  AND fj.fusion_job_id = cj.fusion_job_id
  AND jq.job_id = p_job_id
  AND fj.function_id = p_function_id
  AND cj.plan_id = p_plan_id;
END