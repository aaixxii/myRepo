CREATE DEFINER = `aimuser`@`%` PROCEDURE `delete_job` (p_job_id int)
BEGIN
  DELETE
    FROM job_queue
  WHERE job_id = p_job_id;
END