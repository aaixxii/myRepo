CREATE PROCEDURE `garbage_seg_change_log` (
out r_count int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
mylable:BEGIN
   declare  l_count int default 0;
   declare  l_bottom int;
   declare   l_max_diff int;
   declare   l_version int;
   declare  l_deleted int;
    declare v_id int;  
   declare cur cursor for  SELECT id from l_segment_ids;
 DECLARE t_error INTEGER DEFAULT 0; 
 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; 
 	DROP TEMPORARY TABLE IF EXISTS l_segment_ids;
	create temporary table l_segment_ids(id long  NOT NULL PRIMARY KEY UNIQUE) engine=memory; 
    insert into l_segment_ids  SELECT segment_id  FROM segments ORDER BY segment_id;
    select count(id) into l_count from l_segment_ids;
       IF l_count = 0 THEN       
         leave mylable;
      END IF;
       SELECT CAST(property_value AS UNSIGNED INTEGER) INTO l_max_diff FROM system_config
      WHERE property_name = 'BEHAVIOR.MAX_SEGMENT_DIFFS';
      open cur;
       lable_loop: loop
        FETCH cur INTO v_id;
         SELECT version INTO l_version FROM segments WHERE segment_id = v_id;
        set l_bottom = l_version - l_max_diff;
        set l_deleted := 1;
         WHILE (0 < l_deleted) do
            DELETE FROM segment_change_log WHERE segment_change_id IN (
            SELECT segment_change_id FROM (
              (SELECT segment_change_id, row_number() OVER (ORDER BY segment_change_id) as rn
                FROM segment_change_log WHERE segment_id = l_segment_ids(i)
                  AND segment_version < l_bottom)  WHERE rn <= 10000)
            );
            
                
         
         
         end while;
        

       
       end loop;
       close cur;
      

 
 
 

END
