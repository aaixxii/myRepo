﻿CREATE DEFINER = `aimuser`@`%` PROCEDURE `get_seg_catchup_info` (IN p_component_type int,
IN p_seg_diffs json)
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  -- p_seg_diffs= '{segmentId:1000,reportVersion:1,lastVersion:5},{segmentId:1000,reportVersion:1, lastVersion:5},{segmentId:1000,reportVersion:1, lastVersion:5}';
  DECLARE i int DEFAULT 0;
  DECLARE one_json varchar(32);
  DECLARE seg_diff varchar(32);
  DECLARE v_segmentId int(38);
  DECLARE v_reportVersion int(38);
  DECLARE v_latestVersion int(38);
  DECLARE t_error integer DEFAULT 0;
  DECLARE cur CURSOR FOR
  SELECT
    *
  FROM segment_diffs;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS list_tmp;
  CREATE TEMPORARY TABLE history_ids (
    id int(38)
  ) ENGINE = MEMORY;
  DROP TEMPORARY TABLE IF EXISTS list_tmp;
  CREATE TEMPORARY TABLE segment_diffs (
    segmentId int(38),
    reportVersion int(38),
    latestVersion int(38)
  ) ENGINE = MEMORY;
  WHILE i < JSON_LENGTH(p_seg_diffs) DO
    SET one_json = CONCAT("’$[", i, "]’");
    SELECT
      JSON_EXTRACT(p_seg_diffs, CONCAT('$[', i, ']')) INTO seg_diff;
    INSERT INTO segment_diffs (segmentId, reportVersion, latestVersion)
      VALUES (seg_diff ->> "$.segmentId", seg_diff ->> "$.reportVersion", seg_diff ->> "$.latestVersion");
    SET i = i + 1;
  END WHILE;
  OPEN cur;
lable_loop:
  LOOP
    FETCH cur INTO v_segmentId, v_reportVersion, v_latestVersion;
    INSERT INTO history_ids (id)
      VALUES ((SELECT segment_change_id FROM segment_change_log c WHERE segment_id = v_segmentId AND segment_version <= v_latestVersion AND segment_version > v_reportVersion ORDER BY c.segment_change_id, c.segment_version));
  END LOOP;
  CLOSE cur;
  IF (p_component_type = 3) THEN
    SELECT
      scl.SEGMENT_ID,
      scl.BIOMETRICS_ID,
      scl.SEGMENT_VERSION,
      scl.CHANGE_TYPE,
      CASE WHEN scl.CHANGE_TYPE = 1 THEN NULL ELSE pb.BIOMETRIC_DATA END AS BIOMETRIC_DATA,
      pb.EXTERNAL_ID,
      pb.EVENT_ID
    FROM segment_change_log scl
      RIGHT JOIN person_biometrics pb
        ON scl.biometrics_id = pb.biometrics_id
    WHERE scl.segment_change_id IN (SELECT
        id
      FROM l_history_ids)
    ORDER BY scl.segment_id, scl.segment_change_id;
  ELSEIF (p_component_type = 1) THEN
    SELECT
      SEGMENT_ID,
      BIOMETRICS_ID,
      SEGMENT_VERSION,
      CHANGE_TYPE,
      NULL AS BIOMETRIC_DATA,
      NULL AS EXTERNAL_ID,
      NULL AS EVENT_ID
    FROM segment_change_log
    WHERE segment_change_id IN (SELECT
        id l_history_ids)
    ORDER BY segment_id, segment_change_id;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
END