CREATE DEFINER = `aimuser`@`%` PROCEDURE `get_limited_jobs_by_familiy` ()
READS SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE l_family_id int;
  DECLARE l_job_limit_count int;
  DECLARE t_error integer DEFAULT 0;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE v_id int;
  DECLARE cur CURSOR FOR
  SELECT
    id
  FROM l_container_ids;
  DECLARE limit_job_cur CURSOR FOR
  SELECT
    family_id,
    job_limit_count - job_exec_count AS limit_count
  FROM inquiry_traffic
  WHERE (job_limit_count - job_exec_count) > 0;

  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TEMPORARY TABLE IF EXISTS l_job_id_tab;
  CREATE TEMPORARY TABLE l_job_id_tab (
    id int
  ) ENGINE = MEMORY;
  OPEN cur;
lable_loop:
  LOOP
    FETCH cur INTO l_family_id, l_job_limit_count;
    INSERT INTO l_job_id_tab (id)
      VALUES ((SELECT job_id FROM job_queue WHERE family_id = l_family_id AND job_state = 0 ORDER BY priority, failure_count DESC, job_id LIMIT l_job_limit_count));
  END LOOP;
  CLOSE cur;
  SELECT
    *
  FROM l_job_id_tab;
END