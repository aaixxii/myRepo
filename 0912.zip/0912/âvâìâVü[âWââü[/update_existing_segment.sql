CREATE DEFINER = `aimuser`@`%` PROCEDURE `update_existing_segment` (IN p_binary_length_compacted long,
IN p_binary_length_uncompacted long,
IN p_record_count long,
IN p_version long,
IN p_revision long,
IN p_segment_id long,
IN p_data_len long,
OUT o_seg_version long,
OUT o_seg_id long)
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE l_new_binary_len_comp long;
  DECLARE l_new_binary_len_uncomp long;
  DECLARE l_new_rec_count long;
  DECLARE l_new_version long;
  DECLARE l_new_revision long;
  DECLARE l_new_end long;
  DECLARE t_error integer DEFAULT 0;
  DECLARE not_found integer DEFAULT 0;
  DECLARE EXIT HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
  SET l_new_binary_len_comp = p_binary_length_compacted + l_data_len + 54;
  SET l_new_binary_len_uncomp = p_binary_length_uncompacted + 54;
  SET l_new_rec_count = seg_rec.record_count + 1;
  SET l_new_version = seg_rec.version + 1;
  SET l_new_revision = seg_rec.revision + 1;
  IF l_biometrics_id > p_bio_id_end THEN
    SET l_new_end := l_biometrics_id;
  ELSE
    SET l_new_end = p_bio_id_end;
  END IF;
  UPDATE segments
  SET binary_length_compacted = l_new_binary_len_comp,
      binary_length_uncompacted = l_new_binary_len_uncomp,
      record_count = l_new_rec_count,
      version = l_new_version,
      revision = l_new_revision,
      bio_id_end = l_new_end
  WHERE segment_id = p_segment_id
  AND revision = p_revision;
  IF not_found = 1 THEN
    SET t_error = 1;
  END IF;
  INSERT INTO segment_change_log (segment_id,
  segment_version,
  change_type,
  biometrics_id)
    VALUES (seg_rec.segment_id, l_new_version, 0, l_biometrics_id);
  SET o_seg_version := l_new_version;
  SET o_seg_id := p_segment_id;
END