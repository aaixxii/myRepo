CREATE DEFINER = `aimuser`@`%` PROCEDURE `get_epoch_time_num()` ()
BEGIN
  SELECT
    UNIX_TIMESTAMP(NOW());
END