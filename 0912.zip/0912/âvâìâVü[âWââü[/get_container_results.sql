CREATE DEFINER = `aimuser`@`%` PROCEDURE `get_container_results` (IN p_job_id int)
READS SQL DATA
SQL SECURITY INVOKER
BEGIN
  SELECT
    cj.container_job_result
  FROM container_jobs cj,
       fusion_jobs fj,
       job_queue jq
  WHERE cj.fusion_job_id = fj.fusion_job_id
  AND fj.job_id = jq.job_id
  AND jq.job_id = p_job_id
  AND cj.job_state = 2
  AND jq.job_state = 'WORKING'
  ORDER BY cj.container_job_id;
END