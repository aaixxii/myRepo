CREATE DEFINER = `aimuser`@`%` PROCEDURE `delete_biometrics` (IN p_external_id varchar(20),
IN p_event_id int,
IN p_container_ids varchar(1024),
OUT r_deleted_record_count int)
MODIFIES SQL DATA
SQL SECURITY INVOKER
BEGIN
  DECLARE l_person_id long;
  DECLARE l_new_binary_len_comp long;
  DECLARE l_new_rec_count int;
  DECLARE l_new_version long;
  DECLARE l_new_revision long;
  DECLARE tmp_biometrics_id long;
  DECLARE tmp_container_id int;
  DECLARE tmp_biometric_data_len long;
  DECLARE l_deleted_record_count int DEFAULT 0;
  DECLARE l_count int DEFAULT 0;
  DECLARE tp_segment_id long;
  DECLARE tp_record_count long;
  DECLARE tp_binary_length_compacted long;
  DECLARE tp_version long;
  DECLARE tp_revision long;
  DECLARE del_count int;
  DECLARE not_found int DEFAULT 0;
  DECLARE t_error integer DEFAULT 0;
  DECLARE v_idx int DEFAULT 999;
  DECLARE v_tmp_str varchar(20);
  DECLARE v_id int;
  DECLARE cur CURSOR FOR
  SELECT
    id
  FROM tmp_person_biometrics;
  DECLARE C1 CURSOR FOR
  SELECT
    *
  FROM seg_container FOR UPDATE;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
  DROP TEMPORARY TABLE IF EXISTS tmp_person_biometrics;
  CREATE TEMPORARY TABLE tmp_person_biometrics (
    biometrics_id long,
    container_id int,
    biometric_data_len long
  );
  DROP TEMPORARY TABLE IF EXISTS tmp_container_ids;
  CREATE TEMPORARY TABLE tmp_container_ids (
    id int
  ) ENGINE = MEMORY;
  DROP TEMPORARY TABLE IF EXISTS seg_container;
  CREATE TEMPORARY TABLE seg_container (
    segment_id long,
    record_count long,
    binary_length_compacted long,
    version long,
    revision long
  ) ENGINE = MEMORY;
  WHILE v_idx > 0 DO
    SET v_idx = INSTR(p_container_ids, ',');
    SET v_tmp_str = SUBSTR(p_container_ids, 0, t_idx - 1);
    INSERT INTO tmp_container_ids (id)
      VALUES (CAST(v_tmp_str AS UNSIGNED));
    SET p_container_ids = SUBSTR(p_container_ids, v_idx + 1, LENGTH(p_container_ids));
  END WHILE;
  IF (p_event_id IS NOT NULL)
    AND (p_container_ids IS NOT NULL) THEN
    INSERT INTO tmp_person_biometrics
      VALUES ((SELECT biometrics_id, container_id, biometric_data_len FROM person_biometrics WHERE external_id = p_external_id AND event_id = p_event_id AND container_id IN (SELECT id FROM tmp_container_ids) ORDER BY container_id, biometrics_id));
  ELSEIF (p_event_id IS NOT NULL)
    AND (p_container_ids IS NULL) THEN
    INSERT INTO tmp_person_biometrics
      VALUES ((SELECT biometrics_id, container_id, biometric_data_len FROM person_biometrics WHERE external_id = p_external_id AND event_id = p_event_id ORDER BY container_id, biometrics_id));
  ELSEIF (p_event_id IS NULL)
    AND (p_container_ids IS NOT NULL) THEN
    INSERT INTO tmp_person_biometrics
      VALUES ((SELECT biometrics_id, container_id, biometric_data_len FROM person_biometrics WHERE external_id = p_external_id ORDER BY container_id, biometrics_id));
  END IF;

  OPEN cur;
lable_loop:
  LOOP
    FETCH cur INTO tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len;
    IF not_found != 1 THEN
      DELETE
        FROM person_biometrics
      WHERE BIOMETRICS_ID = tmp_biometrics_id;
      SELECT
        ROW_COUNT() INTO del_count;
      IF del_count = 1 THEN
        SET l_deleted_record_count := l_deleted_record_count + 1;
        INSERT INTO seg_container
          VALUES ((SELECT segment_id, record_count, binary_length_compacted, version, revision FROM segments s, containers c WHERE s.container_id = c.container_id AND (tmp_container_id BETWEEN s.bio_id_start AND s.bio_id_end) AND (c.container_id = tmp_container_id.container_id)));
        OPEN C1;
        LOOP
          FETCH cur INTO tp_segment_id, tp_record_count, tp_binary_length_compacted, tp_version, tp_revision;
          SET l_new_rec_count = c1.record_count - 1;
          SET l_new_binary_len_comp := tp_binary_length_compacted - tmp_biometric_data_len - 54;
          SET l_new_version = tp_version + 1;
          SET l_new_revision = tp_revision + 1;
          UPDATE segments
          SET record_count = l_new_rec_count,
              binary_length_compacted = l_new_binary_len_comp,
              version = l_new_version,
              revision = l_new_revision
          WHERE segment_id = c1.segment_id
          AND revision = tp_version;
          INSERT INTO segment_change_log (segment_id,
          segment_version,
          change_type,
          biometrics_id)
            VALUES (tp_segment_id, l_new_version, 1, tmp_biometrics_id);
          SET l_count := l_count + 1;
        END LOOP;
        CLOSE C1;
      END IF;
    END IF;
  END LOOP;
  CLOSE cur;
  SET r_deleted_record_count = l_deleted_record_count;
  IF t_error = 1 THEN
    ROLLBACK;
    SET r_deleted_record_count = -1;
  ELSE
    COMMIT;
  END IF;
END