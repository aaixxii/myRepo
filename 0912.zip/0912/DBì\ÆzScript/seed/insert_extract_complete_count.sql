USE AIMDB;
INSERT INTO extract_complete_count (complete_count, complete_ts)
  VALUES (0, 0);
COMMIT;


