package jp.co.nec.aim.mm.aggregator;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidateList;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBProcessInfo;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.AggregatorDao;
import jp.co.nec.aim.mm.dao.BatchJobInfoDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.logger.JobDoneLogger;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.procedure.ContainerJobResult;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.StopWatch;
import jp.co.nec.aim.mm.util.TimeHelper;

/**
 * 
 * @author jinxl
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class Aggregator {

	private static Logger log = LoggerFactory.getLogger(Aggregator.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource ds;
	private InquiryJobDao inquiryJobDao;
	private AggregatorDao aggregatorDao;
	private SystemConfigDao systemConfigDao;
	private BatchJobInfoDao batchJobInfoDao;
	
	private final static String L_SUCCESS_PROCESS = "p_success_refcursor";

	@PostConstruct
	public void init() {
		inquiryJobDao = new InquiryJobDao(manager);
		aggregatorDao = new AggregatorDao(ds);
		systemConfigDao = new SystemConfigDao(manager);	
		batchJobInfoDao = new BatchJobInfoDao(manager);
	}
	
	/**
	 * Aggregation main flow control
	 * 
	 * @param topJobId
	 */
	@Asynchronous	
	public void doAggregation(long jobId) {
		long threadId = Thread.currentThread().getId();
		boolean isSuccess = true;
		try {
			doAggregationCore(jobId);
		} catch (Throwable e) {
			isSuccess = false;
			String errMessg = String
					.format("Any exception occured during aggregation. jobId=%d threadId=%d",
							jobId, threadId);
			log.error(errMessg, e);
			throw new AimRuntimeException(e);
		} finally {
			if (isSuccess) {
				log.info(
						"Finished aggregation thread. jobId={} threadId={}",
					jobId, threadId);
			} else {
				log.warn(
						"Finished aggregation thread with unexpected exception. jobId={} threadId={}",
						jobId, threadId);
			}
		}
	}

	/**
	 * doAggregation
	 * 
	 * @param topLevelJobId
	 */
	public void doAggregationCore(long topLevelJobId) {
		long threadId = Thread.currentThread().getId();
		log.info("prepare aggregation top job(Id={}) results....", topLevelJobId);

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		JobQueueEntity jobQueue = null;
		if (log.isDebugEnabled()) {
			log.debug("Fetch JOB_QUEUE record for aggregation. jobId={} threadId={}", topLevelJobId, threadId);
		}
		try {
			/* check topJob is or not exist */
			jobQueue = inquiryJobDao.getTopLevelJob(topLevelJobId);
			if (jobQueue == null) {
				log.warn("Job {} queued for aggregation not found, skip aggaregation!", topLevelJobId);
				return;
			}

			if (jobQueue.getJobState().equals(JobState.DONE)) {
				log.warn("Job {} already be DONE, skip to aggregation.", topLevelJobId);
				return;
			}
		} catch (Exception ex) {
			String errMessg = String.format(
					"An error occoured during find JOB_QUEUE record for aggregation. jobId=%d threadId=%d",
					topLevelJobId, threadId);
			throw new AimRuntimeException(errMessg, ex);
		}

		List<PBBusinessMessage> inquiryPbBnsMesgList = Lists.newArrayList();
		List<PBBusinessMessage> erroPbBnsMesgList = Lists.newArrayList();
		
		boolean haveErr = getAllContainerJobs(topLevelJobId, inquiryPbBnsMesgList, erroPbBnsMesgList);
		IdentifyResponse.Builder lastIdentifyResponse = IdentifyResponse.newBuilder();
		List<BatchJobInfoEntity> batchInfo = null;
		try {
			batchInfo = batchJobInfoDao.getBatchJobInfo(topLevelJobId);
			lastIdentifyResponse.setBatchJobId(batchInfo.get(0).getBatchJobId());
			lastIdentifyResponse.setType(BatchType.IDENTIFY);
		} catch (Exception e) {
			log.warn("Can't get batch job info from BatchJob table");
			return;
		}	

		if (haveErr) {
			log.warn("No CandidateList found in search job results, "
					+ "skip aggregation and respose to client. jobId={} threadId={}", topLevelJobId, threadId);
			PBDataBlock.Builder errPBDataBlock = PBDataBlock.newBuilder();
			List<PBDataGroup> lastPBDataGroupList = Lists.newArrayList();
			for (PBBusinessMessage pbMsg : inquiryPbBnsMesgList) {
				if (pbMsg.hasDataBlock() && pbMsg.getDataBlock().getDataGroupCount() > 0) {
					final List<PBDataGroup> dataGroupList = pbMsg.getDataBlock().getDataGroupList();
					for (PBDataGroup pg : dataGroupList) {
						PBDataGroup newpg = calculatePBDataGroupAmr(pg);
						lastPBDataGroupList.add(newpg);
					}
				}
			}
			
			for (PBBusinessMessage errPbMsg : erroPbBnsMesgList) {
				if (errPbMsg.hasDataBlock() && errPbMsg.getDataBlock().getDataGroupCount() > 0) {
					final List<PBDataGroup> dataGroupList = errPbMsg.getDataBlock().getDataGroupList();
					for (PBDataGroup pg : dataGroupList) {
						PBDataGroup newpg = calculatePBDataGroupAmr(pg);
						lastPBDataGroupList.add(newpg);
					}
				}
				
			}
			
			PBResponse.Builder errPBResponse = PBResponse.newBuilder();
			PBBusinessMessage muPbmsg = erroPbBnsMesgList.get(0);
			if (muPbmsg.hasResponse() && muPbmsg.getResponse().hasErrorMessage()) {
				errPBResponse.setErrorMessage(muPbmsg.getResponse().getErrorMessage());
			} else {
				errPBResponse.setErrorMessage(AimError.INQ_JOB_RESULT_ERR.getErrorCode());
			}
			if (muPbmsg.hasResponse() && muPbmsg.getResponse().hasStatus()) {
				errPBResponse.setStatus(muPbmsg.getResponse().getStatus());
			} else {
				errPBResponse.setStatus("1");
			}					
			errPBDataBlock.addAllDataGroup(lastPBDataGroupList);
			PBBusinessMessage.Builder errPBBusinessMessage = PBBusinessMessage.newBuilder();
			if (erroPbBnsMesgList.get(0).hasRequest()) {
				errPBBusinessMessage.setRequest(erroPbBnsMesgList.get(0).getRequest());
			}
			if (errPBBusinessMessage.hasDataBlock()) {
				errPBBusinessMessage.setDataBlock(errPBDataBlock);
			}
			errPBBusinessMessage.setResponse(errPBResponse);
			lastIdentifyResponse.addBusinessMessage(errPBBusinessMessage.build().toByteString());

		} else {

			Integer clientMaxCantidates = jobQueue.getMaxCandidates();
			int maxCandidate = clientMaxCantidates == null
					? systemConfigDao.getMMPropertyInt(MMConfigProperty.DEFAULT_MAX_CANDIDATES)
					: clientMaxCantidates.intValue();
			PBDataBlock lastDataBlock = buildDataBlock(inquiryPbBnsMesgList, maxCandidate);
			PBResponse.Builder lastPBResponse = PBResponse.newBuilder();
			lastPBResponse.setStatus("success");
			PBBusinessMessage.Builder lastPBBusinessMessage = PBBusinessMessage.newBuilder();
			lastPBBusinessMessage.setRequest(inquiryPbBnsMesgList.get(0).getRequest());
			lastPBBusinessMessage.setResponse(lastPBResponse);
			lastPBBusinessMessage.setDataBlock(lastDataBlock);
			lastIdentifyResponse.addBusinessMessage(lastPBBusinessMessage.build().toByteString());
			log.debug(lastIdentifyResponse.toString());
		}

		doAfterMergeProcess(lastIdentifyResponse.build(), jobQueue);

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doAggregationCore", stopWatch.elapsedTime());
		return;
	}
	
	private PBDataBlock buildDataBlock(List<PBBusinessMessage> inquiryPbBnsMesgList, int maxCandidate) {		
		List<PBCandidate> toBeAggregtedList = Lists.newArrayList();
		for (PBBusinessMessage pbMsg : inquiryPbBnsMesgList) {
			if (pbMsg.hasDataBlock() && pbMsg.getDataBlock().hasCandidateList()) {
				PBCandidateList pbMsgCandites = pbMsg.getDataBlock().getCandidateList();
				toBeAggregtedList.addAll(pbMsgCandites.getCandidatesList());
			}
		}		
		
		final PBDataBlock.Builder pBDataBlock = PBDataBlock.newBuilder();
		final List<PBDataGroup> lastPbDataGroupList = Lists.newArrayList();
		inquiryPbBnsMesgList.forEach(pm -> {
			if (pm.hasDataBlock() && pm.getDataBlock().getDataGroupCount() > 0 ) {				
				pm.getDataBlock().getDataGroupList().forEach(gp -> {
					final PBDataGroup newPbGrData = calculatePBDataGroupAmr(gp);
					if (!Objects.isNull(newPbGrData)) {
						lastPbDataGroupList.add(newPbGrData);
					}					
				});				
			}		
		});
		for (int i = 0; i < lastPbDataGroupList.size(); i++) {
			 pBDataBlock.addDataGroup(i, lastPbDataGroupList.get(i));
		}
		
		inquiryPbBnsMesgList.forEach(one -> {
			if (one.hasDataBlock() && one.getDataBlock().hasProcessMetric()) {								
				final List<PBProcessInfo> prcessList = one.getDataBlock().getProcessMetric().getProcessMetricList();				
				pBDataBlock.getProcessMetricBuilder().addAllProcessMetric(prcessList);	
			}
		});
		
		 if (toBeAggregtedList != null && toBeAggregtedList.size() > 0)  {
			 List<PBCandidate> sortedAndSameKeyMerged = mergeCandidates(toBeAggregtedList);	
			 if (sortedAndSameKeyMerged.size() > maxCandidate) {
				 sortedAndSameKeyMerged = sortedAndSameKeyMerged.subList(0, maxCandidate);
			 }			 
			 pBDataBlock.getCandidateListBuilder().addAllCandidates(sortedAndSameKeyMerged);			 
			    //pBDataBlock.getCandidateListBuilder().setMore(false);
		 }
		 
		 Predicate<PBBusinessMessage>  predicateMore = one -> one.hasDataBlock() && one.getDataBlock().hasCandidateList() &&
				 one.getDataBlock().getCandidateList().getMore() == true;
		 
		 if (inquiryPbBnsMesgList.stream().anyMatch(predicateMore)) {
			 pBDataBlock.getCandidateListBuilder().setMore(true);
		 } else {
			 pBDataBlock.getCandidateListBuilder().setMore(false);
		 }	
		
		return pBDataBlock.build();
	}
	
	private List<PBCandidate> mergeCandidates(List<PBCandidate> toBeMergeList) {		
		Collections.sort(toBeMergeList, new SameCandidateMergeComparator());				
		final List<PBCandidate> samekeyMergedAndSortedList = Lists.newArrayList();				
		Map<String, List<PBCandidate>> grpByType = toBeMergeList.stream().collect( Collectors.groupingBy(PBCandidate::getEnrollmentId));               
		grpByType.entrySet().stream().forEach(entry -> {
			//Predicate<PBCandidate> predicate = one -> one.getScaledScore() > 0;
			Optional<PBCandidate> test = entry.getValue().stream().sorted(new CandidateLastComparator()).findFirst();
			if (test.isPresent()) {
			   PBCandidate maxCandidate = entry.getValue().stream().sorted(new CandidateLastComparator()).findFirst().get();
		       samekeyMergedAndSortedList.add(maxCandidate);
			}          
		});	
		Collections.sort(samekeyMergedAndSortedList, new CandidateLastComparator());
		return samekeyMergedAndSortedList;		
	}
	
	private PBDataGroup calculatePBDataGroupAmr(PBDataGroup pBDataGroup) {
		 PBDataGroup.Builder newPBDataGroup = PBDataGroup.newBuilder();
		 newPBDataGroup.setGroupName(pBDataGroup.getGroupName());
		final List<PBDataElement> edList = pBDataGroup.getDataElementList();
		if (edList.isEmpty()) return null;
		final List<PBDataElement> newList = Lists.newArrayList();
		//Collections.sort(edList,new PBDataElementComparator());
		Map<String, List<PBDataElement>> deMap = edList.stream().collect(Collectors.groupingBy(PBDataElement::getElementName));
		final PBDataElement.Builder newPBDataElement = PBDataElement.newBuilder();
		 deMap.entrySet().forEach(de -> {
			 String name = de.getKey();
			final List<PBDataElement> elList = de.getValue();
			int sum = elList.stream().mapToInt(e -> Integer.valueOf(e.getElementValue())).sum();
			newPBDataElement.setElementName(name);
			newPBDataElement.setElementValue(String.valueOf(sum));	
			newList.add(newPBDataElement.build());
		 });
	
		 for (int i = 0; i < newList.size(); i++) {
			 newPBDataGroup.addDataElement(i, newList.get(i));	 
		 }			
		return newPBDataGroup.build();		
	}	

	/**
	 * getAllContainerJobs
	 * 
	 * @param topJobId
	 * @param inquiryJobResultInternal
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private boolean getAllContainerJobs(long topJobId,List<PBBusinessMessage> inquiryPbBnsMesgList, List<PBBusinessMessage> errPbBnsMesgList) {		
		boolean isErr = false;
		if (log.isDebugEnabled()) {
			log.debug("getAllContainerJobs start... jobId={}", topJobId);
		}
		TimeHelper th = new TimeHelper("getAllContainerJobs");
		th.t();

		/* get all Container Job INFO */
		Map<String, Object> objs = null;
		try {
			objs = aggregatorDao.getAllContainerJobs(topJobId);
			List<ContainerJobResult> conTainerJobResults = Lists.newArrayList();
			if (objs.get(L_SUCCESS_PROCESS) != null) {
				conTainerJobResults = (List<ContainerJobResult>) objs.get(L_SUCCESS_PROCESS);
			}
			if (CollectionsUtil.isEmpty(conTainerJobResults)) {	
				log.warn("ContainerJob data in topLevelJobId="
						+ topJobId
						+ " is incorrect! It's no containerJobResult and failureReason!");
				isErr = true;
				return isErr;
			}			
			boolean hasResposeErr = getJobResultState(conTainerJobResults,inquiryPbBnsMesgList, errPbBnsMesgList);
			if (hasResposeErr == true) {
				isErr =true;
			}

		} catch (Exception e) {
			isErr =true;
		}	
		
		if (isErr) {
			log.warn(
					"ContainerJob data in topLevelJobId="
							+ topJobId
							+ " is incorrect! There is {} in all containerJob result!");				
			
		}	
		// container job done successfully(without error)
		th.t();
		if (log.isDebugEnabled()) {
			log.debug(th.message());
			log.debug("getAllContainerJobs end. rtn=true. jobId={}", topJobId);
		}
		return isErr;
	}

	private boolean getJobResultState(List<ContainerJobResult> containerJobResults, List<PBBusinessMessage> empityPbBsnMsgList, List<PBBusinessMessage> errPbBsnMsgList) {			
		boolean hasErr = false;			
		for (ContainerJobResult containJob : containerJobResults) {
			PBBusinessMessage jobResultInternal = null;
			try {
				if (null == containJob.getContainerJobsResult()) {
					continue;
				}				
				jobResultInternal = PBBusinessMessage.parseFrom(containJob.getContainerJobsResult());				
				if (jobResultInternal.hasResponse() && jobResultInternal.getResponse().getStatus().toLowerCase().equals("0")) {
					empityPbBsnMsgList.add(jobResultInternal);
				} else {
					errPbBsnMsgList.add(jobResultInternal);
					hasErr = true;
					return hasErr;
				}		

			} catch (InvalidProtocolBufferException e) {
				throw new AimRuntimeException(
						"InvalidProtocolBufferException occurred "
								+ "when parseFrom PBInquiryJobResultInternal instance",
						e);
			}
		}	
		return hasErr;
	}

	private void doAfterMergeProcess(IdentifyResponse pBInquiryJobResult,
			JobQueueEntity jobQueue) {
		long threadId = Thread.currentThread().getId();
		if (log.isDebugEnabled()) {
			log.debug("doAfterMergeProcess start... jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}

		TimeHelper th = new TimeHelper("doAfterMergeProcess");
		th.t();

		byte[] inquiryJobResult = pBInquiryJobResult.toByteArray();

		if (log.isDebugEnabled()) {
			log.debug(
					"Setting final results to JOB_QUEUE record.. jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}
		PBBusinessMessage pbMsg = null;
		try {
			pbMsg = PBBusinessMessage.parseFrom(pBInquiryJobResult.getBusinessMessage(0).toByteArray());
		} catch (InvalidProtocolBufferException e) {			
			//Todo send err respose
		}		
		boolean bState = pbMsg.getResponse().getStatus().toLowerCase().equals("0");

		aggregatorDao.callCompleteTopLevelJob(jobQueue.getJobId(),
				inquiryJobResult, !bState);

		manager.refresh(jobQueue);

		JobDoneLogger jobDoneLogger = new JobDoneLogger(ds);
		jobDoneLogger.info(jobQueue, pBInquiryJobResult,
				inquiryJobDao.findMinFunctionId(jobQueue.getJobId()));
		th.t();
		  AimManager.saveInquryClientJobResult(String.valueOf(jobQueue.getJobId()), pBInquiryJobResult);		 
		if (ConfigProperties.getInstance().isPropertyValue(
				ConfigPropertyNames.IS_PURGE_CONTAINER_JOBS)
				&& bState) {
			inquiryJobDao.clearAllContainerJob(jobQueue.getJobId());
		}

		/* send Jms to IdentifyPlanner */
		JmsSender.getInstance().sendToInquiryJobPlanner(
				NotifierEnum.Aggregator, "send Msg to IdentifyPlanner");
		th.t();

		if (log.isDebugEnabled()) {
			log.debug(th.message());
			log.debug("doAfterMergeProcess end... jobId={} threadId={}",
					jobQueue.getJobId(), threadId);
		}
	}
}


class PBDataElementComparator implements Comparator<PBDataElement> {
	@Override
	public int compare(PBDataElement o1, PBDataElement o2) {
		int first = o1.getElementName().compareTo(o2.getElementName());
		return first == 0 ? Integer.valueOf(o1.getElementValue()).compareTo(Integer.valueOf(o2.getElementValue())) : first;
	}	
}

class SameCandidateMergeComparator implements Comparator<PBCandidate> {
	@Override
	public int compare(PBCandidate o1,
			PBCandidate o2) {
		int first = o1.getEnrollmentId().compareTo(o2.getEnrollmentId());
		int second = first == 0 ? Integer.valueOf(o2.getScaledScore())
				.compareTo(Integer.valueOf(o1.getScaledScore())) : first;
		return second;
	}
}


class CandidateLastComparator implements Comparator<PBCandidate> {
	@Override
	public int compare(PBCandidate o1, PBCandidate o2) {
		int first = Integer.valueOf(o2.getScaledScore()).compareTo(
				Integer.valueOf(o1.getScaledScore()));
		int second = first == 0 ? o1.getEnrollmentId().compareTo(
				o2.getEnrollmentId()) : first;
		return second;
	}
}