package com.nec.aim.uid.dmwebapp.segments;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;
import java.util.stream.Stream;



public class SequenceIdCreator {	
	private static AtomicLong segment_change_log_id;
	
	public static void init() {
		String sequenceFilePath = UidCommonManager.getValue(SEQUENCE_PATH);
		String batchIdFile = sequenceFilePath + "/batchJobIds.dat";
		String requestIdFile = sequenceFilePath + "/reqeustIds.dat";
		String enrollmentIdFile = sequenceFilePath + "/enrollmentIds.dat";
		String os = System.getProperty("os.name").toLowerCase();
		if (os.indexOf("windows") >= 0 ) {
			if (batchIdFile.startsWith("/")) {
				batchIdFile = batchIdFile.substring(1, batchIdFile.length());
			}
			if (requestIdFile.startsWith("/")) {
				requestIdFile = requestIdFile.substring(1, requestIdFile.length());
			}
			if (enrollmentIdFile.startsWith("/")) {
				enrollmentIdFile = enrollmentIdFile.substring(1, enrollmentIdFile.length());
			}	
		}	
		try (Stream<String> batchIdstrm = Files.lines(Paths.get(batchIdFile))) {
			String lastBatchId = batchIdstrm.map(String::toUpperCase).collect(Collectors.toList()).get(0);
			if (!lastBatchId.isEmpty()) {
				lastBatchJobId =  new AtomicLong(Long.valueOf(lastBatchId));
			} else {
				lastBatchJobId =  new AtomicLong(0);
			}				
		} catch (IOException e) {
			throw new UidClientException("read last batchId from file error", e);
		}
		
		try (Stream<String> requstIdstrm = Files.lines(Paths.get(requestIdFile))) {
			String lastRqeustId = requstIdstrm.map(String::toUpperCase).collect(Collectors.toList()).get(0);
			if (!lastRqeustId.isEmpty()) {
				lastReqeustId =  new AtomicLong(Long.valueOf(lastRqeustId));
			} else {
				lastReqeustId =  new AtomicLong(0);
			}				
		} catch (IOException e) {
			throw new UidClientException("read last requestId from file error", e);
		}	
		try (Stream<String> enrollmentIdFilestrm = Files.lines(Paths.get(enrollmentIdFile))) {
			String lastEnrollId = enrollmentIdFilestrm.map(String::toUpperCase).collect(Collectors.toList()).get(0);
			if (!lastEnrollId.isEmpty()) {
				lastEnrollmentId =  new AtomicLong(Long.valueOf(lastEnrollId));
			} else {
				lastEnrollmentId=  new AtomicLong(0);
			}
			
		} catch (IOException e) {
			throw new UidClientException("read last requestId from file error", e);
		}	
	}	
	
	public static synchronized long createNextSequence(SequenceIdType type) {		
		switch (type){
		case BATCHJOB_ID:
			return lastBatchJobId.incrementAndGet();
		case REQUST_ID:
			return lastReqeustId.incrementAndGet();
		 default:
			 return -1;
		}		
	}
	
	public static synchronized String createNextEnrollmentId() {
		long value = lastEnrollmentId.incrementAndGet();
		 String reqValue = "REQ_" + String.format("%032d", value);			
		return reqValue;
	}
	
	public static void saveLastSequence() {
		String sequenceFilePath = UidCommonManager.getValue(SEQUENCE_PATH);
		String batchIdFile = sequenceFilePath + "/batchJobIds.dat";
		String requestIdFile = sequenceFilePath + "/reqeustIds.dat";
		String enrollmentIdFile = sequenceFilePath + "/enrollmentIds.dat";
		String os = System.getProperty("os.name").toLowerCase();
		if (os.indexOf("windows") >= 0 ) {
			if (batchIdFile.startsWith("/")) {
				batchIdFile = batchIdFile.substring(1, batchIdFile.length());
			}
			if (requestIdFile.startsWith("/")) {
				requestIdFile = requestIdFile.substring(1, requestIdFile.length());
			}
			if (enrollmentIdFile.startsWith("/")) {
				enrollmentIdFile = enrollmentIdFile.substring(1, enrollmentIdFile.length());
			}
		}		
		try {
			Files.write(Paths.get(batchIdFile), String.valueOf(lastBatchJobId.longValue()).getBytes(), StandardOpenOption.WRITE);
		} catch (IOException e) {
			throw new UidClientException("write last batchId to file error", e);
		}		
		try {
			Files.write(Paths.get(requestIdFile), String.valueOf(lastReqeustId.longValue()).getBytes(), StandardOpenOption.WRITE);
		} catch (IOException e) {
			throw new UidClientException("write last batchId to file error", e);
		}
		try {
			Files.write(Paths.get(enrollmentIdFile), String.valueOf(lastEnrollmentId.longValue()).getBytes(), StandardOpenOption.WRITE);
		} catch (IOException e) {
			throw new UidClientException("write last batchId to file error", e);
		}
		System.out.println("Save sequence value to file OK");
	}
}
