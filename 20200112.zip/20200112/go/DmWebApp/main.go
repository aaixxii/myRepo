package main

import (
	"fmt"
	"log"
	"net/http"
)

func HelloServer(w http.ResponseWriter, r *http.Request) {
	fmt.Println("path:", r.URL.Path)
	fmt.Fprintf(w, "Hello Go Web")
}

func HomeHandler(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	fmt.Println(r.Form)
	fmt.Println("path:", r.URL.Path)
	fmt.Fprintf(w, "Welcome to home")
}

func registerHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println("path:", r.URL.Path)
	fmt.Fprintf(w, "Welcome to register")
}

func main() {
	http.HandleFunc("/", HelloServer)
	err := http.ListenAndServe("127.0.0.1:9090", nil) //设置要监听的Ip和端口
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
	fmt.Println("DM server is run:http://127.0.0.1:9090")
}
