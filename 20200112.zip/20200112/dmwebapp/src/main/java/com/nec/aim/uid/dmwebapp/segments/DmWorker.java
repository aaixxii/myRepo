package com.nec.aim.uid.dmwebapp.segments;

import java.nio.ByteBuffer;
import java.util.concurrent.Callable;

public class DmWorker implements Callable {
	private ByteBuffer segBuffer;
	private byte[] data;
	private long bioId;
	private String extId; 
	private long segId;
	private long segVer;
	

	@Override
	public Boolean call() throws Exception {
		 
		return null;
	}	

}

//Callable<Boolean> call = () -> {
//return newSegment(segBuf, templateData, bioId, externalId, segId, segVer);
//};			
//Future<Boolean> result = SegmentManager.getExcutor().submit(call);