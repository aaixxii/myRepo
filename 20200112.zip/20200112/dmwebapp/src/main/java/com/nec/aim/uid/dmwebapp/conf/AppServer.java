
package com.nec.aim.uid.dmwebapp.conf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

/**
 * @author xiazp
 *
 */
@ComponentScan("info.vishrantgupta.chatbot")
@EnableAutoConfiguration
@SpringBootApplication
@PropertySource("classpath:application.yml")
public class AppServer {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(AppServer.class, args);
	}
}
