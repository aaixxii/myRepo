
package com.nec.aim.uid.dmwebapp.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nec.aim.uid.dmwebapp.model.AIMLModel;

/**
 * @author xiazp
 *
 */
@RestController
// @RequestMapping(value="/bot")
public class NotUseController {

	@RequestMapping(value = "train")
	public void trainChatbot(
			@RequestParam(required = true, defaultValue = "{}") AIMLModel trainData) {

		if (trainData != null) {

		}

	}

	@RequestMapping(value = "chat")
	public ResponseEntity<?> chat() {

		return ResponseEntity.ok("success");
	}

}
