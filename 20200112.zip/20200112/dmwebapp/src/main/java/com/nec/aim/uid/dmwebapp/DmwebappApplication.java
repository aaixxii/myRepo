package com.nec.aim.uid.dmwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DmwebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmwebappApplication.class, args);
	}

}
