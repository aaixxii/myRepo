package com.nec.aim.uid.dmwebapp.controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Vishrant Gupta
 *
 */
@RestController
public class HomeController {

	@RequestMapping("/")
	public String home() {
		return "Hello from chatbot";
	}

}
