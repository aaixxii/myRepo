package com.nec.aim.uid.dmwebapp.persistence;

import org.springframework.data.cassandra.repository.CassandraRepository;

public interface ChatbotDataRepository extends CassandraRepository<ChatbotData, ChatbotData> {

}
