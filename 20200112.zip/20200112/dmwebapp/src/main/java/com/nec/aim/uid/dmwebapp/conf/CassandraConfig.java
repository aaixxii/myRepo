
package com.nec.aim.uid.dmwebapp.conf;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.core.cql.keyspace.CreateKeyspaceSpecification;
import org.springframework.data.cassandra.core.cql.keyspace.KeyspaceOption;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

/**
 * @author xiazp
 *
 */
@Configuration
@PropertySource(value = { "classpath:cassandra.yml" })
@ConfigurationProperties("spring.data.cassandra")
@EnableCassandraRepositories(basePackages = "com.nec.aim.uid.dmwebapp.persistence")
public class CassandraConfig extends AbstractCassandraConfiguration {

	@Value("${keyspacename}")
	protected String keyspaceName;

	@Override
	protected String getKeyspaceName() {
		return this.keyspaceName;
	}

	@Override
	protected List<CreateKeyspaceSpecification> getKeyspaceCreations() {
		return Collections.singletonList(CreateKeyspaceSpecification
				.createKeyspace(keyspaceName).ifNotExists()
				.with(KeyspaceOption.DURABLE_WRITES, true)
				.withSimpleReplication());
	}

	/*
	 * Creating keyspace if does not exists
	 */
	@Override
	protected List<String> getStartupScripts() {
		return Collections.singletonList("CREATE KEYSPACE IF NOT EXISTS "
				+ keyspaceName + " WITH replication = {"
				+ " 'class': 'SimpleStrategy', "
				+ " 'replication_factor': '3' " + "};");

	}
}
