package com.nec.aim.uid.dmwebapp.persistence;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table
public class ChatbotData {

	@PrimaryKeyColumn(name = "isbn", ordinal = 2, type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
	private UUID id;
	
	@PrimaryKeyColumn(name = "publisher", ordinal = 1, type = PrimaryKeyType.PARTITIONED)
	private String publisher;
	
	@Column
	private Set<String> tags = new HashSet<>();
	
	@PrimaryKeyColumn(name = "title", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
	private String title;

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		ChatbotData other = (ChatbotData) obj;
		if (this.id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!this.id.equals(other.id)) {
			return false;
		}
		if (this.publisher == null) {
			if (other.publisher != null) {
				return false;
			}
		} else if (!this.publisher.equals(other.publisher)) {
			return false;
		}
		if (this.tags == null) {
			if (other.tags != null) {
				return false;
			}
		} else if (!this.tags.equals(other.tags)) {
			return false;
		}
		if (this.title == null) {
			if (other.title != null) {
				return false;
			}
		} else if (!this.title.equals(other.title)) {
			return false;
		}
		return true;
	}

	public UUID getId() {
		return this.id;
	}

	public String getPublisher() {
		return this.publisher;
	}

	public Set<String> getTags() {
		return this.tags;
	}

	public String getTitle() {
		return this.title;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((this.id == null) ? 0 : this.id.hashCode());
		result = prime * result
				+ ((this.publisher == null) ? 0 : this.publisher.hashCode());
		result = prime * result
				+ ((this.tags == null) ? 0 : this.tags.hashCode());
		result = prime * result
				+ ((this.title == null) ? 0 : this.title.hashCode());
		return result;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public void setTags(Set<String> tags) {
		this.tags = tags;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	// standard getters and setters
	@Override
	public String toString() {
		return "ChatbotData [id=" + this.id + ", title=" + this.title
				+ ", publisher=" + this.publisher + ", tags=" + this.tags + "]";
	}

}
