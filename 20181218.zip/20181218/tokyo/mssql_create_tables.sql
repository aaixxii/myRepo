USE XMDB
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_EVENT_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_EVENT_INFO]
(
   [BIOMETRIC_ID] numeric(20, 0)  NOT NULL,
   [EXTERNAL_ID] varchar(36)  NOT NULL,
   [EVENT_ID] varchar(36)  NULL,
   [BIN_ID] numeric(10, 0)  NOT NULL,
   [STATUS] varchar(15)  NOT NULL,
   [PHASE] varchar(15)  NOT NULL,
   [CREATE_DATETIME] datetime2(6)  NOT NULL,
   [UPDATE_DATETIME] datetime2(6)  NULL,
   [TEMPLATE_DATA_KEY] varchar(60)  NULL,
   [TEMPLATE_SIZE] numeric(10, 0)  NULL,
   [DATA_VERSION] numeric(20, 0)  NULL,
   [ASSIGNED_SEGMENT_ID] numeric(10, 0)  NULL,
   [SEGMENT_SYNC_DATETIME] datetime2(6)  NULL,
   [SITE_ID] varchar(36)  NULL,
   [ERROR_DATETIME] datetime2(6)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIOMETRIC_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'BIOMETRIC_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.EXTERNAL_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'EXTERNAL_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.EVENT_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'EVENT_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIN_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'BIN_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.STATUS',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'STATUS'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.PHASE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'PHASE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.CREATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'CREATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.UPDATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'UPDATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.TEMPLATE_DATA_KEY',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'TEMPLATE_DATA_KEY'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.TEMPLATE_SIZE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'TEMPLATE_SIZE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.DATA_VERSION',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'DATA_VERSION'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.ASSIGNED_SEGMENT_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'ASSIGNED_SEGMENT_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.SEGMENT_SYNC_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'SEGMENT_SYNC_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.SITE_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'SITE_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.ERROR_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'COLUMN', N'ERROR_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_IDENTIFIER_DETAIL_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_IDENTIFIER_DETAIL_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO]
(
   [BIOMETRIC_ID] numeric(20, 0)  NOT NULL,
   [BIN_ID] numeric(10, 0)  NOT NULL,
   [SEGMENT_ID] numeric(10, 0)  NOT NULL,
   [REUSE_FLAG] varchar(1)  NOT NULL,
   [ACQUIRED_HOST] varchar(128)  NULL,
   [ACQUIRED_DATETIME] datetime2(6)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.BIOMETRIC_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'COLUMN', N'BIOMETRIC_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.BIN_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'COLUMN', N'BIN_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.SEGMENT_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'COLUMN', N'SEGMENT_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.REUSE_FLAG',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'COLUMN', N'REUSE_FLAG'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.ACQUIRED_HOST',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'COLUMN', N'ACQUIRED_HOST'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.ACQUIRED_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'COLUMN', N'ACQUIRED_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_IDENTIFIER_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_IDENTIFIER_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_IDENTIFIER_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_IDENTIFIER_INFO]
(
   [SEGMENT_ID] numeric(10, 0)  NOT NULL,
   [BIN_ID] numeric(10, 0)  NOT NULL,
   [START_BIOMETRIC_ID] numeric(20, 0)  NOT NULL,
   [END_BIOMETRIC_ID] numeric(20, 0)  NOT NULL,
   [CURR_BIOMETRIC_ID] numeric(20, 0)  NOT NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.SEGMENT_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'COLUMN', N'SEGMENT_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.BIN_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'COLUMN', N'BIN_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.START_BIOMETRIC_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'COLUMN', N'START_BIOMETRIC_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.END_BIOMETRIC_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'COLUMN', N'END_BIOMETRIC_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.CURR_BIOMETRIC_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'COLUMN', N'CURR_BIOMETRIC_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_LOCK_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_LOCK_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_LOCK_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_LOCK_INFO]
(
   [LOCK_KEY] varchar(128)  NOT NULL,
   [LOCK_HOST] varchar(56)  NULL,
   [LOCK_ACQUIRE_MILLI] numeric(20, 0)  NULL,
   [LOCK_TIMEOUT_MILLI] numeric(20, 0)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_LOCK_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_LOCK_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_LOCK_INFO.LOCK_KEY',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_LOCK_INFO',
        N'COLUMN', N'LOCK_KEY'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_LOCK_INFO.LOCK_HOST',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_LOCK_INFO',
        N'COLUMN', N'LOCK_HOST'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_LOCK_INFO.LOCK_ACQUIRE_MILLI',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_LOCK_INFO',
        N'COLUMN', N'LOCK_ACQUIRE_MILLI'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_LOCK_INFO.LOCK_TIMEOUT_MILLI',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_LOCK_INFO',
        N'COLUMN', N'LOCK_TIMEOUT_MILLI'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_BIN_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'XMDB_USER_BIN_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[XMDB_USER_BIN_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[XMDB_USER_BIN_INFO]
(
   [BIN_ID] numeric(10, 0)  NOT NULL,
   [TEMPLATE_TYPE] varchar(20)  NOT NULL,
   [DATA_PRIORITY] numeric(10, 0)  NOT NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_BIN_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_BIN_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_BIN_INFO.BIN_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_BIN_INFO',
        N'COLUMN', N'BIN_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_BIN_INFO.TEMPLATE_TYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_BIN_INFO',
        N'COLUMN', N'TEMPLATE_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_BIN_INFO.DATA_PRIORITY',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_BIN_INFO',
        N'COLUMN', N'DATA_PRIORITY'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_NODE_SEGMENT_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'XMDB_USER_NODE_SEGMENT_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
(
   [MATCHER_NODE_ID] varchar(15)  NOT NULL,
   [SEGMENT_ID] numeric(10, 0)  NOT NULL,
   [ASSIGNED_FLAG] varchar(1)  NOT NULL,
   [SEGMENT_VERSION] numeric(20, 0)  NOT NULL,
   [UPDATE_DATETIME] datetime2(6)  NOT NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.MATCHER_NODE_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'COLUMN', N'MATCHER_NODE_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.SEGMENT_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'COLUMN', N'SEGMENT_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.ASSIGNED_FLAG',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'COLUMN', N'ASSIGNED_FLAG'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.SEGMENT_VERSION',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'COLUMN', N'SEGMENT_VERSION'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.UPDATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'COLUMN', N'UPDATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_SEGMENT_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'XMDB_USER_SEGMENT_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[XMDB_USER_SEGMENT_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[XMDB_USER_SEGMENT_INFO]
(
   [SEGMENT_ID] numeric(10, 0)  NOT NULL,
   [BIN_ID] numeric(10, 0)  NOT NULL,
   [SEGMENT_VERSION] numeric(20, 0)  NOT NULL,
   [UPDATE_DATETIME] datetime2(6)  NOT NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_SEGMENT_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_SEGMENT_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_SEGMENT_INFO.SEGMENT_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_SEGMENT_INFO',
        N'COLUMN', N'SEGMENT_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_SEGMENT_INFO.BIN_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_SEGMENT_INFO',
        N'COLUMN', N'BIN_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_SEGMENT_INFO.SEGMENT_VERSION',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_SEGMENT_INFO',
        N'COLUMN', N'SEGMENT_VERSION'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_SEGMENT_INFO.UPDATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_SEGMENT_INFO',
        N'COLUMN', N'UPDATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_MESSAGE_INFO_LOG'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_MESSAGE_INFO_LOG'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_MESSAGE_INFO_LOG]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_MESSAGE_INFO_LOG]
(
   [MESSAGE_ID] varchar(36)  NOT NULL,
   [MESSAGE_TYPE] varchar(15)  NOT NULL,
   [MESSAGE_CODE] varchar(15)  NOT NULL,
   [MESSAGE_INFO] varchar(500)  NOT NULL,
   [MESSAGE_DETAIL] varchar(3000)  NULL,
   [REFERENCE_KEY_TYPE1] varchar(36)  NULL,
   [REFERENCE_KEY_VALUE1] varchar(36)  NULL,
   [REFERENCE_KEY_TYPE2] varchar(36)  NULL,
   [REFERENCE_KEY_VALUE2] varchar(36)  NULL,
   [CREATE_DATETIME] datetime2(6)  NOT NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.MESSAGE_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'MESSAGE_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.MESSAGE_TYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'MESSAGE_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.MESSAGE_CODE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'MESSAGE_CODE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.MESSAGE_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'MESSAGE_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.MESSAGE_DETAIL',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'MESSAGE_DETAIL'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.REFERENCE_KEY_TYPE1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'REFERENCE_KEY_TYPE1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.REFERENCE_KEY_VALUE1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'REFERENCE_KEY_VALUE1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.REFERENCE_KEY_TYPE2',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'REFERENCE_KEY_TYPE2'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.REFERENCE_KEY_VALUE2',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'REFERENCE_KEY_VALUE2'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.CREATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'COLUMN', N'CREATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_PARAMETER_SCOPE'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_PARAMETER_SCOPE'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_PARAMETER_SCOPE]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_PARAMETER_SCOPE]
(
   [SCOPE_NAME] varchar(128)  NOT NULL,
   [DESCRIPTION] varchar(128)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETER_SCOPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETER_SCOPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETER_SCOPE.SCOPE_NAME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETER_SCOPE',
        N'COLUMN', N'SCOPE_NAME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETER_SCOPE.DESCRIPTION',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETER_SCOPE',
        N'COLUMN', N'DESCRIPTION'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_PARAMETERS'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_PARAMETERS'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_PARAMETERS]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_PARAMETERS]
(
   [NAME] varchar(128)  NOT NULL,
   [SCOPE] varchar(128)  NOT NULL,
   [VALUE] varchar(max)  NULL,
   [DESCRIPTION] varchar(128)  NULL,
   [DATATYPE] varchar(128)  NULL,
   [CREATE_DATETIME] datetime2(6)  NOT NULL,
   [UPDATE_DATETIME] datetime2(6)  NULL,
   [CREATEBY] varchar(128)  NOT NULL,
   [UPDATEBY] varchar(128)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS."NAME"',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'NAME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS."SCOPE"',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'SCOPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS."VALUE"',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'VALUE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.DESCRIPTION',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'DESCRIPTION'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.DATATYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'DATATYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.CREATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'CREATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.UPDATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'UPDATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.CREATEBY',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'CREATEBY'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.UPDATEBY',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'COLUMN', N'UPDATEBY'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_REMOTE_SITE_SYNC_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_REMOTE_SITE_SYNC_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO]
(
   [SITE_ID] varchar(36)  NOT NULL,
   [SEGMENT_ID] numeric(10, 0)  NOT NULL,
   [INSERT_SEGMENT_VERSION] numeric(20, 0)  NOT NULL,
   [DELETE_SEGMENT_VERSION] numeric(20, 0)  NOT NULL,
   [UPDATE_DATETIME] datetime2(6)  NOT NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO.SITE_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO',
        N'COLUMN', N'SITE_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO.SEGMENT_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO',
        N'COLUMN', N'SEGMENT_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO.INSERT_SEGMENT_VERSION',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO',
        N'COLUMN', N'INSERT_SEGMENT_VERSION'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO.DELETE_SEGMENT_VERSION',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO',
        N'COLUMN', N'DELETE_SEGMENT_VERSION'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO.UPDATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO',
        N'COLUMN', N'UPDATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SEQUENCES'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_SEQUENCES'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_SEQUENCES]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_SEQUENCES]
(
   [SEQUENCE_NAME] varchar(128)  NOT NULL,
   [SEQUENCE_GROUP] varchar(128)  NOT NULL,
   [SEQUENCE_VALUE] numeric(20, 0)  NOT NULL,
   [RESET_POLICY] numeric(10, 0)  NULL,
   [MIN_NUMBER] numeric(20, 0)  NOT NULL,
   [DATETIME_CREATE] datetime2(6)  NOT NULL,
   [DATETIME_LAST_RESET] datetime2(6)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES.SEQUENCE_NAME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES',
        N'COLUMN', N'SEQUENCE_NAME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES.SEQUENCE_GROUP',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES',
        N'COLUMN', N'SEQUENCE_GROUP'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES.SEQUENCE_VALUE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES',
        N'COLUMN', N'SEQUENCE_VALUE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES.RESET_POLICY',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES',
        N'COLUMN', N'RESET_POLICY'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES.MIN_NUMBER',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES',
        N'COLUMN', N'MIN_NUMBER'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES.DATETIME_CREATE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES',
        N'COLUMN', N'DATETIME_CREATE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES.DATETIME_LAST_RESET',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES',
        N'COLUMN', N'DATETIME_LAST_RESET'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SERVER_CONNECTION_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_SERVER_CONNECTION_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_SERVER_CONNECTION_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_SERVER_CONNECTION_INFO]
(
   [SERVER_ID] varchar(15)  NOT NULL,
   [COMPONENT_TYPE] varchar(15)  NOT NULL,
   [CONNECTION_TYPE] varchar(15)  NOT NULL,
   [PROTOCOL_TYPE] varchar(15)  NOT NULL,
   [CONNECTION_URL] varchar(500)  NOT NULL,
   [CONNECTION_PROPERTIES] varchar(1024)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO.SERVER_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO',
        N'COLUMN', N'SERVER_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO.COMPONENT_TYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO',
        N'COLUMN', N'COMPONENT_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO.CONNECTION_TYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO',
        N'COLUMN', N'CONNECTION_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO.PROTOCOL_TYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO',
        N'COLUMN', N'PROTOCOL_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO.CONNECTION_URL',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO',
        N'COLUMN', N'CONNECTION_URL'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO.CONNECTION_PROPERTIES',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO',
        N'COLUMN', N'CONNECTION_PROPERTIES'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SERVER_GROUP_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_SERVER_GROUP_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_SERVER_GROUP_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_SERVER_GROUP_INFO]
(
   [GROUP_ID] varchar(15)  NOT NULL,
   [COMPONENT_TYPE] varchar(15)  NOT NULL,
   [DESCRIPTION] varchar(500)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_GROUP_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_GROUP_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_GROUP_INFO.GROUP_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_GROUP_INFO',
        N'COLUMN', N'GROUP_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_GROUP_INFO.COMPONENT_TYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_GROUP_INFO',
        N'COLUMN', N'COMPONENT_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_GROUP_INFO.DESCRIPTION',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_GROUP_INFO',
        N'COLUMN', N'DESCRIPTION'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SERVER_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_SERVER_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_SERVER_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_SERVER_INFO]
(
   [SERVER_ID] varchar(15)  NOT NULL,
   [SERVER_HOSTNAME] varchar(128)  NOT NULL,
   [SERVER_TYPE] varchar(15)  NOT NULL,
   [SERVER_STATE] varchar(15)  NOT NULL,
   [COMPONENT_TYPE] varchar(15)  NOT NULL,
   [SERVER_GROUP_ID] varchar(15)  NULL,
   [SUB_SYSTEM_GROUP_ID] varchar(15)  NULL,
   [MAX_JOB_COUNT] numeric(10, 0)  NOT NULL,
   [SERVER_PROPERTIES] varchar(1024)  NULL,
   [CREATE_DATETIME] datetime2(6)  NOT NULL,
   [UPDATE_DATETIME] datetime2(6)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.SERVER_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'SERVER_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.SERVER_HOSTNAME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'SERVER_HOSTNAME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.SERVER_TYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'SERVER_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.SERVER_STATE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'SERVER_STATE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.COMPONENT_TYPE',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'COMPONENT_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.SERVER_GROUP_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'SERVER_GROUP_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.SUB_SYSTEM_GROUP_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'SUB_SYSTEM_GROUP_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.MAX_JOB_COUNT',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'MAX_JOB_COUNT'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.SERVER_PROPERTIES',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'SERVER_PROPERTIES'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.CREATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'CREATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.UPDATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'COLUMN', N'UPDATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_TEMPLATE_DATA_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_TEMPLATE_DATA_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_TEMPLATE_DATA_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_TEMPLATE_DATA_INFO]
(
   [TEMPLATE_DATA_ID] varchar(60)  NOT NULL,
   [TEMPLATE_DATA] varbinary(max)  NULL,
   [CREATE_DATETIME] datetime2(6)  NOT NULL,
   [UPDATE_DATETIME] datetime2(6)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_DATA_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_DATA_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_DATA_INFO.TEMPLATE_DATA_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_DATA_INFO',
        N'COLUMN', N'TEMPLATE_DATA_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_DATA_INFO.TEMPLATE_DATA',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_DATA_INFO',
        N'COLUMN', N'TEMPLATE_DATA'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_DATA_INFO.CREATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_DATA_INFO',
        N'COLUMN', N'CREATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_DATA_INFO.UPDATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_DATA_INFO',
        N'COLUMN', N'UPDATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_TEMPLATE_STORAGE_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_TEMPLATE_STORAGE_INFO'  AND sc.name = N'XMDB_USER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDB_USER].[BIO_TEMPLATE_STORAGE_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDB_USER].[BIO_TEMPLATE_STORAGE_INFO]
(
   [STORAGE_ID] numeric(10, 0)  NOT NULL,
   [ROOT_PATH] varchar(128)  NOT NULL,
   [ACTIVE_FLAG] varchar(1)  NOT NULL,
   [CREATE_DATETIME] datetime2(6)  NOT NULL,
   [UPDATE_DATETIME] datetime2(6)  NULL
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_STORAGE_INFO',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_STORAGE_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_STORAGE_INFO.STORAGE_ID',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_STORAGE_INFO',
        N'COLUMN', N'STORAGE_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_STORAGE_INFO.ROOT_PATH',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_STORAGE_INFO',
        N'COLUMN', N'ROOT_PATH'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_STORAGE_INFO.ACTIVE_FLAG',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_STORAGE_INFO',
        N'COLUMN', N'ACTIVE_FLAG'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_STORAGE_INFO.CREATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_STORAGE_INFO',
        N'COLUMN', N'CREATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_STORAGE_INFO.UPDATE_DATETIME',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_STORAGE_INFO',
        N'COLUMN', N'UPDATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_EVENT_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_EVENT_INFO] DROP CONSTRAINT [BIO_EVENT_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_EVENT_INFO]
 ADD CONSTRAINT [BIO_EVENT_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([BIOMETRIC_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'CONSTRAINT', N'BIO_EVENT_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_IDENTIFIER_DETAIL_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO] DROP CONSTRAINT [BIO_IDENTIFIER_DETAIL_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO]
 ADD CONSTRAINT [BIO_IDENTIFIER_DETAIL_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([BIOMETRIC_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.BIO_IDENTIFIER_DETAIL_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'CONSTRAINT', N'BIO_IDENTIFIER_DETAIL_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_IDENTIFIER_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_INFO] DROP CONSTRAINT [BIO_IDENTIFIER_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_INFO]
 ADD CONSTRAINT [BIO_IDENTIFIER_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([SEGMENT_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.BIO_IDENTIFIER_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'CONSTRAINT', N'BIO_IDENTIFIER_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_LOCK_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_LOCK_INFO] DROP CONSTRAINT [BIO_LOCK_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_LOCK_INFO]
 ADD CONSTRAINT [BIO_LOCK_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([LOCK_KEY] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_LOCK_INFO.BIO_LOCK_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_LOCK_INFO',
        N'CONSTRAINT', N'BIO_LOCK_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_BIN_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[XMDB_USER_BIN_INFO] DROP CONSTRAINT [XMDB_USER_BIN_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[XMDB_USER_BIN_INFO]
 ADD CONSTRAINT [XMDB_USER_BIN_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([BIN_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_BIN_INFO.XMDB_USER_BIN_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_BIN_INFO',
        N'CONSTRAINT', N'XMDB_USER_BIN_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_NODE_SEGMENT_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO] DROP CONSTRAINT [XMDB_USER_NODE_SEGMENT_PK]
 GO



ALTER TABLE [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
 ADD CONSTRAINT [XMDB_USER_NODE_SEGMENT_PK]
   PRIMARY KEY
   CLUSTERED ([MATCHER_NODE_ID] ASC, [SEGMENT_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.XMDB_USER_NODE_SEGMENT_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'CONSTRAINT', N'XMDB_USER_NODE_SEGMENT_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_SEGMENT_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[XMDB_USER_SEGMENT_INFO] DROP CONSTRAINT [XMDB_USER_SEGMENT_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[XMDB_USER_SEGMENT_INFO]
 ADD CONSTRAINT [XMDB_USER_SEGMENT_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([SEGMENT_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_SEGMENT_INFO.XMDB_USER_SEGMENT_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_SEGMENT_INFO',
        N'CONSTRAINT', N'XMDB_USER_SEGMENT_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_MESSAGE_INFO_LOG_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_MESSAGE_INFO_LOG] DROP CONSTRAINT [BIO_MESSAGE_INFO_LOG_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_MESSAGE_INFO_LOG]
 ADD CONSTRAINT [BIO_MESSAGE_INFO_LOG_PK]
   PRIMARY KEY
   CLUSTERED ([MESSAGE_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.BIO_MESSAGE_INFO_LOG_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'CONSTRAINT', N'BIO_MESSAGE_INFO_LOG_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_PARAMETER_SCOPE_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_PARAMETER_SCOPE] DROP CONSTRAINT [BIO_PARAMETER_SCOPE_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_PARAMETER_SCOPE]
 ADD CONSTRAINT [BIO_PARAMETER_SCOPE_PK]
   PRIMARY KEY
   CLUSTERED ([SCOPE_NAME] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETER_SCOPE.BIO_PARAMETER_SCOPE_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETER_SCOPE',
        N'CONSTRAINT', N'BIO_PARAMETER_SCOPE_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_PARAMETERS_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_PARAMETERS] DROP CONSTRAINT [BIO_PARAMETERS_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_PARAMETERS]
 ADD CONSTRAINT [BIO_PARAMETERS_PK]
   PRIMARY KEY
   CLUSTERED ([NAME] ASC, [SCOPE] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.BIO_PARAMETERS_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'CONSTRAINT', N'BIO_PARAMETERS_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_REMOTE_SITE_SYNC_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO] DROP CONSTRAINT [BIO_REMOTE_SITE_SYNC_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO]
 ADD CONSTRAINT [BIO_REMOTE_SITE_SYNC_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([SITE_ID] ASC, [SEGMENT_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO.BIO_REMOTE_SITE_SYNC_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO',
        N'CONSTRAINT', N'BIO_REMOTE_SITE_SYNC_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SEQUENCES_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_SEQUENCES] DROP CONSTRAINT [BIO_SEQUENCES_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_SEQUENCES]
 ADD CONSTRAINT [BIO_SEQUENCES_PK]
   PRIMARY KEY
   CLUSTERED ([SEQUENCE_NAME] ASC, [SEQUENCE_GROUP] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SEQUENCES.BIO_SEQUENCES_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SEQUENCES',
        N'CONSTRAINT', N'BIO_SEQUENCES_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SERVER_CONNECTION_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_SERVER_CONNECTION_INFO] DROP CONSTRAINT [BIO_SERVER_CONNECTION_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_SERVER_CONNECTION_INFO]
 ADD CONSTRAINT [BIO_SERVER_CONNECTION_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([SERVER_ID] ASC, [COMPONENT_TYPE] ASC, [CONNECTION_TYPE] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO.BIO_SERVER_CONNECTION_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO',
        N'CONSTRAINT', N'BIO_SERVER_CONNECTION_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SERVER_GROUP_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_SERVER_GROUP_INFO] DROP CONSTRAINT [BIO_SERVER_GROUP_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_SERVER_GROUP_INFO]
 ADD CONSTRAINT [BIO_SERVER_GROUP_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([GROUP_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_GROUP_INFO.BIO_SERVER_GROUP_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_GROUP_INFO',
        N'CONSTRAINT', N'BIO_SERVER_GROUP_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SERVER_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_SERVER_INFO] DROP CONSTRAINT [BIO_SERVER_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_SERVER_INFO]
 ADD CONSTRAINT [BIO_SERVER_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([SERVER_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_INFO.BIO_SERVER_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_INFO',
        N'CONSTRAINT', N'BIO_SERVER_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_TEMPLATE_DATA_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_TEMPLATE_DATA_INFO] DROP CONSTRAINT [BIO_TEMPLATE_DATA_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_TEMPLATE_DATA_INFO]
 ADD CONSTRAINT [BIO_TEMPLATE_DATA_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([TEMPLATE_DATA_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_DATA_INFO.BIO_TEMPLATE_DATA_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_DATA_INFO',
        N'CONSTRAINT', N'BIO_TEMPLATE_DATA_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_TEMPLATE_STORAGE_INFO_PK'  AND sc.name = N'XMDB_USER'  AND type in (N'PK'))
ALTER TABLE [XMDB_USER].[BIO_TEMPLATE_STORAGE_INFO] DROP CONSTRAINT [BIO_TEMPLATE_STORAGE_INFO_PK]
 GO



ALTER TABLE [XMDB_USER].[BIO_TEMPLATE_STORAGE_INFO]
 ADD CONSTRAINT [BIO_TEMPLATE_STORAGE_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([STORAGE_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_TEMPLATE_STORAGE_INFO.BIO_TEMPLATE_STORAGE_INFO_PK',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_TEMPLATE_STORAGE_INFO',
        N'CONSTRAINT', N'BIO_TEMPLATE_STORAGE_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_EVENT_INFO_IX01' AND so.type in (N'U'))
   DROP INDEX [BIO_EVENT_INFO_IX01] ON [XMDB_USER].[BIO_EVENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_EVENT_INFO_IX01] ON [XMDB_USER].[BIO_EVENT_INFO]
(
   [EXTERNAL_ID] ASC,
   [EVENT_ID] ASC,
   [BIN_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_IX01',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'INDEX', N'BIO_EVENT_INFO_IX01'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_EVENT_INFO_IX02' AND so.type in (N'U'))
   DROP INDEX [BIO_EVENT_INFO_IX02] ON [XMDB_USER].[BIO_EVENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_EVENT_INFO_IX02] ON [XMDB_USER].[BIO_EVENT_INFO]
(
   [BIN_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_IX02',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'INDEX', N'BIO_EVENT_INFO_IX02'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_EVENT_INFO_IX03' AND so.type in (N'U'))
   DROP INDEX [BIO_EVENT_INFO_IX03] ON [XMDB_USER].[BIO_EVENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_EVENT_INFO_IX03] ON [XMDB_USER].[BIO_EVENT_INFO]
(
   [STATUS] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_IX03',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'INDEX', N'BIO_EVENT_INFO_IX03'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_EVENT_INFO_IX04' AND so.type in (N'U'))
   DROP INDEX [BIO_EVENT_INFO_IX04] ON [XMDB_USER].[BIO_EVENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_EVENT_INFO_IX04] ON [XMDB_USER].[BIO_EVENT_INFO]
(
   [PHASE] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_IX04',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'INDEX', N'BIO_EVENT_INFO_IX04'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_EVENT_INFO_IX05' AND so.type in (N'U'))
   DROP INDEX [BIO_EVENT_INFO_IX05] ON [XMDB_USER].[BIO_EVENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_EVENT_INFO_IX05] ON [XMDB_USER].[BIO_EVENT_INFO]
(
   [DATA_VERSION] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_IX05',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'INDEX', N'BIO_EVENT_INFO_IX05'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_EVENT_INFO_IX06' AND so.type in (N'U'))
   DROP INDEX [BIO_EVENT_INFO_IX06] ON [XMDB_USER].[BIO_EVENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_EVENT_INFO_IX06] ON [XMDB_USER].[BIO_EVENT_INFO]
(
   [ASSIGNED_SEGMENT_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_IX06',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'INDEX', N'BIO_EVENT_INFO_IX06'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_EVENT_INFO_IX07' AND so.type in (N'U'))
   DROP INDEX [BIO_EVENT_INFO_IX07] ON [XMDB_USER].[BIO_EVENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_EVENT_INFO_IX07] ON [XMDB_USER].[BIO_EVENT_INFO]
(
   [UPDATE_DATETIME] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_IX07',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'INDEX', N'BIO_EVENT_INFO_IX07'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_EVENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_EVENT_INFO_IX08' AND so.type in (N'U'))
   DROP INDEX [BIO_EVENT_INFO_IX08] ON [XMDB_USER].[BIO_EVENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_EVENT_INFO_IX08] ON [XMDB_USER].[BIO_EVENT_INFO]
(
   [SITE_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_IX08',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'INDEX', N'BIO_EVENT_INFO_IX08'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_IDENTIFIER_DETAIL_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_IDENTIFIER_DETAIL_IX01' AND so.type in (N'U'))
   DROP INDEX [BIO_IDENTIFIER_DETAIL_IX01] ON [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_IDENTIFIER_DETAIL_IX01] ON [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO]
(
   [BIN_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.BIO_IDENTIFIER_DETAIL_IX01',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'INDEX', N'BIO_IDENTIFIER_DETAIL_IX01'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_IDENTIFIER_DETAIL_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_IDENTIFIER_DETAIL_IX02' AND so.type in (N'U'))
   DROP INDEX [BIO_IDENTIFIER_DETAIL_IX02] ON [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_IDENTIFIER_DETAIL_IX02] ON [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO]
(
   [SEGMENT_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.BIO_IDENTIFIER_DETAIL_IX02',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'INDEX', N'BIO_IDENTIFIER_DETAIL_IX02'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_IDENTIFIER_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_IDENTIFIER_INFO_IX01' AND so.type in (N'U'))
   DROP INDEX [BIO_IDENTIFIER_INFO_IX01] ON [XMDB_USER].[BIO_IDENTIFIER_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_IDENTIFIER_INFO_IX01] ON [XMDB_USER].[BIO_IDENTIFIER_INFO]
(
   [BIN_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.BIO_IDENTIFIER_INFO_IX01',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'INDEX', N'BIO_IDENTIFIER_INFO_IX01'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'XMDB_USER_BIN_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'XMDB_USER_BIN_INFO_IX01' AND so.type in (N'U'))
   DROP INDEX [XMDB_USER_BIN_INFO_IX01] ON [XMDB_USER].[XMDB_USER_BIN_INFO] 
GO
CREATE NONCLUSTERED INDEX [XMDB_USER_BIN_INFO_IX01] ON [XMDB_USER].[XMDB_USER_BIN_INFO]
(
   [TEMPLATE_TYPE] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_BIN_INFO.XMDB_USER_BIN_INFO_IX01',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_BIN_INFO',
        N'INDEX', N'XMDB_USER_BIN_INFO_IX01'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'XMDB_USER_NODE_SEGMENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'XMDB_USER_NODE_SEGMENT_IX01' AND so.type in (N'U'))
   DROP INDEX [XMDB_USER_NODE_SEGMENT_IX01] ON [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [XMDB_USER_NODE_SEGMENT_IX01] ON [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
(
   [SEGMENT_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.XMDB_USER_NODE_SEGMENT_IX01',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'INDEX', N'XMDB_USER_NODE_SEGMENT_IX01'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'XMDB_USER_SEGMENT_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'XMDB_USER_SEGMENT_INFO_IX01' AND so.type in (N'U'))
   DROP INDEX [XMDB_USER_SEGMENT_INFO_IX01] ON [XMDB_USER].[XMDB_USER_SEGMENT_INFO] 
GO
CREATE NONCLUSTERED INDEX [XMDB_USER_SEGMENT_INFO_IX01] ON [XMDB_USER].[XMDB_USER_SEGMENT_INFO]
(
   [BIN_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_SEGMENT_INFO.XMDB_USER_SEGMENT_INFO_IX01',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_SEGMENT_INFO',
        N'INDEX', N'XMDB_USER_SEGMENT_INFO_IX01'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_MESSAGE_INFO_LOG'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_MESSAGE_INFO_LOG_IX01' AND so.type in (N'U'))
   DROP INDEX [BIO_MESSAGE_INFO_LOG_IX01] ON [XMDB_USER].[BIO_MESSAGE_INFO_LOG] 
GO
CREATE NONCLUSTERED INDEX [BIO_MESSAGE_INFO_LOG_IX01] ON [XMDB_USER].[BIO_MESSAGE_INFO_LOG]
(
   [MESSAGE_TYPE] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.BIO_MESSAGE_INFO_LOG_IX01',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'INDEX', N'BIO_MESSAGE_INFO_LOG_IX01'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_MESSAGE_INFO_LOG'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_MESSAGE_INFO_LOG_IX02' AND so.type in (N'U'))
   DROP INDEX [BIO_MESSAGE_INFO_LOG_IX02] ON [XMDB_USER].[BIO_MESSAGE_INFO_LOG] 
GO
CREATE NONCLUSTERED INDEX [BIO_MESSAGE_INFO_LOG_IX02] ON [XMDB_USER].[BIO_MESSAGE_INFO_LOG]
(
   [REFERENCE_KEY_TYPE1] ASC,
   [REFERENCE_KEY_VALUE1] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.BIO_MESSAGE_INFO_LOG_IX02',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'INDEX', N'BIO_MESSAGE_INFO_LOG_IX02'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_MESSAGE_INFO_LOG'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_MESSAGE_INFO_LOG_IX03' AND so.type in (N'U'))
   DROP INDEX [BIO_MESSAGE_INFO_LOG_IX03] ON [XMDB_USER].[BIO_MESSAGE_INFO_LOG] 
GO
CREATE NONCLUSTERED INDEX [BIO_MESSAGE_INFO_LOG_IX03] ON [XMDB_USER].[BIO_MESSAGE_INFO_LOG]
(
   [REFERENCE_KEY_TYPE2] ASC,
   [REFERENCE_KEY_VALUE2] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_MESSAGE_INFO_LOG.BIO_MESSAGE_INFO_LOG_IX03',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_MESSAGE_INFO_LOG',
        N'INDEX', N'BIO_MESSAGE_INFO_LOG_IX03'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_PARAMETERS'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_PARAMETERS_FK1' AND so.type in (N'U'))
   DROP INDEX [BIO_PARAMETERS_FK1] ON [XMDB_USER].[BIO_PARAMETERS] 
GO
CREATE NONCLUSTERED INDEX [BIO_PARAMETERS_FK1] ON [XMDB_USER].[BIO_PARAMETERS]
(
   [SCOPE] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.BIO_PARAMETERS_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'INDEX', N'BIO_PARAMETERS_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_REMOTE_SITE_SYNC_INFO'  AND sc.name = N'XMDB_USER'  AND si.name = N'BIO_REMOTE_SITE_SYNC_INFO_IX01' AND so.type in (N'U'))
   DROP INDEX [BIO_REMOTE_SITE_SYNC_INFO_IX01] ON [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_REMOTE_SITE_SYNC_INFO_IX01] ON [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO]
(
   [SEGMENT_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO.BIO_REMOTE_SITE_SYNC_INFO_IX01',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO',
        N'INDEX', N'BIO_REMOTE_SITE_SYNC_INFO_IX01'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_EVENT_INFO_FK1'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_EVENT_INFO] DROP CONSTRAINT [BIO_EVENT_INFO_FK1]
 GO


/* 
*   SSMA error messages:
*   O2SS0362: ON DELETE CASCADE references have multiple cascade paths. This foreign key conflicts with BIO_EVENT_INFO_FK2. CASCADE was changed to NO ACTION.
*/


ALTER TABLE [XMDB_USER].[BIO_EVENT_INFO]
 ADD CONSTRAINT [BIO_EVENT_INFO_FK1]
 FOREIGN KEY 
   ([BIN_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[XMDB_USER_BIN_INFO]     ([BIN_ID])
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'CONSTRAINT', N'BIO_EVENT_INFO_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO

IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_EVENT_INFO_FK2'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_EVENT_INFO] DROP CONSTRAINT [BIO_EVENT_INFO_FK2]
 GO


/* 
*   SSMA error messages:
*   O2SS0362: ON DELETE CASCADE references have multiple cascade paths. This foreign key conflicts with BIO_EVENT_INFO_FK1. CASCADE was changed to NO ACTION.
*/


ALTER TABLE [XMDB_USER].[BIO_EVENT_INFO]
 ADD CONSTRAINT [BIO_EVENT_INFO_FK2]
 FOREIGN KEY 
   ([ASSIGNED_SEGMENT_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[XMDB_USER_SEGMENT_INFO]     ([SEGMENT_ID])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_EVENT_INFO.BIO_EVENT_INFO_FK2',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_EVENT_INFO',
        N'CONSTRAINT', N'BIO_EVENT_INFO_FK2'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_IDENTIFIER_DETAIL_FK1'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO] DROP CONSTRAINT [BIO_IDENTIFIER_DETAIL_FK1]
 GO


/* 
*   SSMA error messages:
*   O2SS0362: ON DELETE CASCADE references have multiple cascade paths. This foreign key conflicts with BIO_IDENTIFIER_DETAIL_FK2. CASCADE was changed to NO ACTION.
*/


ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO]
 ADD CONSTRAINT [BIO_IDENTIFIER_DETAIL_FK1]
 FOREIGN KEY 
   ([BIN_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[XMDB_USER_BIN_INFO]     ([BIN_ID])
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.BIO_IDENTIFIER_DETAIL_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'CONSTRAINT', N'BIO_IDENTIFIER_DETAIL_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO

IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_IDENTIFIER_DETAIL_FK2'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO] DROP CONSTRAINT [BIO_IDENTIFIER_DETAIL_FK2]
 GO


/* 
*   SSMA error messages:
*   O2SS0362: ON DELETE CASCADE references have multiple cascade paths. This foreign key conflicts with BIO_IDENTIFIER_DETAIL_FK1. CASCADE was changed to NO ACTION.
*/


ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO]
 ADD CONSTRAINT [BIO_IDENTIFIER_DETAIL_FK2]
 FOREIGN KEY 
   ([SEGMENT_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[BIO_IDENTIFIER_INFO]     ([SEGMENT_ID])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_DETAIL_INFO.BIO_IDENTIFIER_DETAIL_FK2',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_DETAIL_INFO',
        N'CONSTRAINT', N'BIO_IDENTIFIER_DETAIL_FK2'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_IDENTIFIER_INFO_FK1'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_INFO] DROP CONSTRAINT [BIO_IDENTIFIER_INFO_FK1]
 GO


/* 
*   SSMA error messages:
*   O2SS0362: ON DELETE CASCADE references have multiple cascade paths. This foreign key conflicts with BIO_IDENTIFIER_INFO_FK2. CASCADE was changed to NO ACTION.
*/


ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_INFO]
 ADD CONSTRAINT [BIO_IDENTIFIER_INFO_FK1]
 FOREIGN KEY 
   ([BIN_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[XMDB_USER_BIN_INFO]     ([BIN_ID])
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.BIO_IDENTIFIER_INFO_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'CONSTRAINT', N'BIO_IDENTIFIER_INFO_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO

IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_IDENTIFIER_INFO_FK2'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_INFO] DROP CONSTRAINT [BIO_IDENTIFIER_INFO_FK2]
 GO


/* 
*   SSMA error messages:
*   O2SS0362: ON DELETE CASCADE references have multiple cascade paths. This foreign key conflicts with BIO_IDENTIFIER_INFO_FK1. CASCADE was changed to NO ACTION.
*/


ALTER TABLE [XMDB_USER].[BIO_IDENTIFIER_INFO]
 ADD CONSTRAINT [BIO_IDENTIFIER_INFO_FK2]
 FOREIGN KEY 
   ([SEGMENT_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[XMDB_USER_SEGMENT_INFO]     ([SEGMENT_ID])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_IDENTIFIER_INFO.BIO_IDENTIFIER_INFO_FK2',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_IDENTIFIER_INFO',
        N'CONSTRAINT', N'BIO_IDENTIFIER_INFO_FK2'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_NODE_SEGMENT_FK1'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO] DROP CONSTRAINT [XMDB_USER_NODE_SEGMENT_FK1]
 GO



ALTER TABLE [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
 ADD CONSTRAINT [XMDB_USER_NODE_SEGMENT_FK1]
 FOREIGN KEY 
   ([MATCHER_NODE_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[BIO_SERVER_INFO]     ([SERVER_ID])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.XMDB_USER_NODE_SEGMENT_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'CONSTRAINT', N'XMDB_USER_NODE_SEGMENT_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO

IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_NODE_SEGMENT_FK2'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO] DROP CONSTRAINT [XMDB_USER_NODE_SEGMENT_FK2]
 GO



ALTER TABLE [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
 ADD CONSTRAINT [XMDB_USER_NODE_SEGMENT_FK2]
 FOREIGN KEY 
   ([SEGMENT_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[XMDB_USER_SEGMENT_INFO]     ([SEGMENT_ID])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_NODE_SEGMENT_INFO.XMDB_USER_NODE_SEGMENT_FK2',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_NODE_SEGMENT_INFO',
        N'CONSTRAINT', N'XMDB_USER_NODE_SEGMENT_FK2'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'XMDB_USER_SEGMENT_INFO_FK1'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[XMDB_USER_SEGMENT_INFO] DROP CONSTRAINT [XMDB_USER_SEGMENT_INFO_FK1]
 GO



ALTER TABLE [XMDB_USER].[XMDB_USER_SEGMENT_INFO]
 ADD CONSTRAINT [XMDB_USER_SEGMENT_INFO_FK1]
 FOREIGN KEY 
   ([BIN_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[XMDB_USER_BIN_INFO]     ([BIN_ID])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.XMDB_USER_SEGMENT_INFO.XMDB_USER_SEGMENT_INFO_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'XMDB_USER_SEGMENT_INFO',
        N'CONSTRAINT', N'XMDB_USER_SEGMENT_INFO_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_PARAMETERS_FK1'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_PARAMETERS] DROP CONSTRAINT [BIO_PARAMETERS_FK1]
 GO



ALTER TABLE [XMDB_USER].[BIO_PARAMETERS]
 ADD CONSTRAINT [BIO_PARAMETERS_FK1]
 FOREIGN KEY 
   ([SCOPE])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[BIO_PARAMETER_SCOPE]     ([SCOPE_NAME])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_PARAMETERS.BIO_PARAMETERS_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_PARAMETERS',
        N'CONSTRAINT', N'BIO_PARAMETERS_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_REMOTE_SITE_SYNC_INFO_FK1'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO] DROP CONSTRAINT [BIO_REMOTE_SITE_SYNC_INFO_FK1]
 GO



ALTER TABLE [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO]
 ADD CONSTRAINT [BIO_REMOTE_SITE_SYNC_INFO_FK1]
 FOREIGN KEY 
   ([SEGMENT_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[XMDB_USER_SEGMENT_INFO]     ([SEGMENT_ID])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_REMOTE_SITE_SYNC_INFO.BIO_REMOTE_SITE_SYNC_INFO_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_REMOTE_SITE_SYNC_INFO',
        N'CONSTRAINT', N'BIO_REMOTE_SITE_SYNC_INFO_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_SERVER_CONNECTION_INFO_FK1'  AND sc.name = N'XMDB_USER'  AND type in (N'F'))
ALTER TABLE [XMDB_USER].[BIO_SERVER_CONNECTION_INFO] DROP CONSTRAINT [BIO_SERVER_CONNECTION_INFO_FK1]
 GO



ALTER TABLE [XMDB_USER].[BIO_SERVER_CONNECTION_INFO]
 ADD CONSTRAINT [BIO_SERVER_CONNECTION_INFO_FK1]
 FOREIGN KEY 
   ([SERVER_ID])
 REFERENCES 
   [XMDB_USER].[XMDB_USER].[BIO_SERVER_INFO]     ([SERVER_ID])
    ON DELETE CASCADE
    ON UPDATE NO ACTION
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDB_USER.BIO_SERVER_CONNECTION_INFO.BIO_SERVER_CONNECTION_INFO_FK1',
        N'SCHEMA', N'XMDB_USER',
        N'TABLE', N'BIO_SERVER_CONNECTION_INFO',
        N'CONSTRAINT', N'BIO_SERVER_CONNECTION_INFO_FK1'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_EVENT_INFO]
 ADD DEFAULT sysdatetimeoffset() FOR [CREATE_DATETIME]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_IDENTIFIER_DETAIL_INFO]
 ADD DEFAULT 'N' FOR [REUSE_FLAG]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_IDENTIFIER_INFO]
 ADD DEFAULT -1 FOR [CURR_BIOMETRIC_ID]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
 ADD DEFAULT 'Y' FOR [ASSIGNED_FLAG]
GO

ALTER TABLE  [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
 ADD DEFAULT -1 FOR [SEGMENT_VERSION]
GO

ALTER TABLE  [XMDB_USER].[XMDB_USER_NODE_SEGMENT_INFO]
 ADD DEFAULT sysdatetimeoffset() FOR [UPDATE_DATETIME]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[XMDB_USER_SEGMENT_INFO]
 ADD DEFAULT -1 FOR [SEGMENT_VERSION]
GO

ALTER TABLE  [XMDB_USER].[XMDB_USER_SEGMENT_INFO]
 ADD DEFAULT sysdatetimeoffset() FOR [UPDATE_DATETIME]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_MESSAGE_INFO_LOG]
 ADD DEFAULT sysdatetimeoffset() FOR [CREATE_DATETIME]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_PARAMETERS]
 ADD DEFAULT sysdatetimeoffset() FOR [CREATE_DATETIME]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO]
 ADD DEFAULT -1 FOR [INSERT_SEGMENT_VERSION]
GO

ALTER TABLE  [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO]
 ADD DEFAULT -1 FOR [DELETE_SEGMENT_VERSION]
GO

ALTER TABLE  [XMDB_USER].[BIO_REMOTE_SITE_SYNC_INFO]
 ADD DEFAULT sysdatetimeoffset() FOR [UPDATE_DATETIME]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_SEQUENCES]
 ADD DEFAULT sysdatetimeoffset() FOR [DATETIME_CREATE]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_SERVER_INFO]
 ADD DEFAULT 0 FOR [MAX_JOB_COUNT]
GO

ALTER TABLE  [XMDB_USER].[BIO_SERVER_INFO]
 ADD DEFAULT sysdatetimeoffset() FOR [CREATE_DATETIME]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_TEMPLATE_DATA_INFO]
 ADD DEFAULT sysdatetimeoffset() FOR [CREATE_DATETIME]
GO


USE XMDB_USER
GO
ALTER TABLE  [XMDB_USER].[BIO_TEMPLATE_STORAGE_INFO]
 ADD DEFAULT sysdatetimeoffset() FOR [CREATE_DATETIME]
GO

