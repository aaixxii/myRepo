-- Note template storage paths should be accessiable by all VC's, EC's and MC's 
USE [BIOMATCHERDB]
GO

Insert into BIO_MATCHER.BIO_TEMPLATE_STORAGE_INFO
   (STORAGE_ID, ROOT_PATH, ACTIVE_FLAG, CREATE_DATETIME)
 Values
   (1, 'C:\home\megha\storage\templates\storage01', 'Y', CURRENT_TIMESTAMP);
GO
