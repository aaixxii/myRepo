#create uid dm database

DROP DATABASE IF EXISTS DMDEMO;
CREATE DATABASE DMDEMO character set utf8mb4;
