package com.nec.aim.dm.nodostorage.segments;

import static com.nec.aim.dm.nodostorage.segments.DmConstants.SEGMENT_HEADER_SIZE;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_CHECKSUM;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_EMBEDDED_ID;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_MAX_SEGMENT;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_TEMPLATE_ID;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_TSZ;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_VERSION;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.sql.SQLException;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.springframework.beans.factory.annotation.Autowired;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.exception.NodeStroageException;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.DmConfigRepository;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class SegmentWriter {
	private Long segmentId;
	private Long segmentVerStart;
	private Long bioIdStart;	
	private ReadWriteLock locker;	
	private boolean corrupted;
	private final Lock readLock; 
    private final Lock writeLock;
    private  File myFile;  
    private int oneTemplateSize;
    
    @Autowired
    ConfigProperties config;
    
    @Autowired
    DmConfigRepository dmConfigRepository;

	
	public SegmentWriter(Long segmentId, Long bioIdStart) throws IOException, SQLException {
		this.segmentId = segmentId;
		this.bioIdStart = bioIdStart;
		this.segmentVerStart = 0l;		
		this.myFile = new File(config.getPath() + "/" + String.valueOf(this.segmentId));
		myFile.createNewFile();
		this.locker = new ReentrantReadWriteLock();			
		this.readLock = locker.readLock();
		this.writeLock = locker.writeLock();
		this.corrupted = false;			
		this.oneTemplateSize = dmConfigRepository.getOneTempalteSize();		
	}	
	
	public boolean writeSegmentHead()  {
		ByteBuffer segBuffer = ByteBuffer.allocate(DmConstants.SEGMENT_HEADER_SIZE);
		FileOutputStream outputStream = null;
		boolean sucess = false;		
			try {
				outputStream = new FileOutputStream(myFile);				
				segBuffer.position(0);
				segBuffer.putInt(DmConstants.AIM_VERSION);
				segBuffer.putShort(DmConstants.FORMAT_ID);
				segBuffer.putLong(DmConstants.MAX_SEGMENT_SIZE);
				segBuffer.putInt(0); //recordCount
				segBuffer.putLong(segmentVerStart);
				NodeStorageManager.saveToQueue(this.segmentId, this);			
				sucess = true;
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				sucess = false;
				myFile.delete();				
			} finally {						
				if (outputStream != null) {
					try {
						outputStream.close();
					} catch (IOException e) {
						log.error(e.getMessage());
						sucess = false;
					}				}									
				segBuffer.clear();
				segBuffer = null;
			}
		return sucess;		
	}
	
	public boolean writeTemplate(PBDmSyncRequest dmSegReq) throws InterruptedException, ExecutionException {
		Callable<Boolean> oneTemplateWrite = () -> {
			long bioIdEnd = dmSegReq.getBioIdEnd();
			PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
			String externalId = null;
			byte[] templateData = null;
			if (templateInfo.hasReferenceId()) {
				externalId = templateInfo.getReferenceId();
			}
			if (templateInfo.hasData()) {
				templateData = templateInfo.getData().toByteArray();
			}
			if (externalId == null || templateData == null || templateData.length < 0) {
				log.error(externalId == null ? "externalId can't null!" : "template data can't null!");
				return false;
			}
			long segId = dmSegReq.getTargetSegment().getId();
			long segVer = dmSegReq.getTargetSegment().getVersion();
			
			boolean success = false;
			SegmentWriter segWrite = NodeStorageManager.getSegmentWriter(segmentId);
			if (segWrite == null) {
				log.error("SegmentFile is not found! segmentId={}", segmentId);
				return false;
			}
			writeLock.tryLock();			
			try {
				byte[] templateWithHeader = TemplateHeaderHelper.prependHeader(bioIdEnd, templateData, externalId, 1);			
				RandomAccessFile randomFile = new RandomAccessFile(myFile, "rw");
				randomFile.seek(SIZE_VERSION + SIZE_EMBEDDED_ID + SIZE_MAX_SEGMENT);
				int recordCount = (int)bioIdEnd - this.bioIdStart.intValue() + 1;
				randomFile.writeInt( recordCount);				
				randomFile.writeLong(segVer);
				int beginPosition = DmConstants.SEGMENT_HEADER_SIZE + (int) ((bioIdEnd - this.bioIdStart) * oneTemplateSize) + 1;				
				randomFile.seek(beginPosition);
				randomFile.write(templateWithHeader);
				randomFile.close();				
				log.info("Success saved tempate data to segment file, segmentId={}", segId);

			} finally {
				writeLock.unlock();
			}
			return success;
		};
		return NodeStorageManager.submit(oneTemplateWrite);
	}
	
	public Boolean deleteTemplate(Long segId, Long segVer, Long bioId, String extId)
			throws InterruptedException, ExecutionException, IOException {
		Callable<Boolean> delTemplateTask = () -> {	
			SegmentWriter segWrite = NodeStorageManager.getSegmentWriter(segId);
			if (segWrite == null) {
				log.warn("There are some wrong, the file:{} is not exist!", segId);
				return false;
			}
			
			RandomAccessFile randomFile = null;
			boolean deleted = false;
			writeLock.tryLock();
			try {
				randomFile = new RandomAccessFile(segWrite.getMyFile(), "rw");
				byte b = 1;				
				int seekPosition = SEGMENT_HEADER_SIZE + (bioId.intValue() - this.getBioIdStart().intValue()) * dmConfigRepository.getOneTempalteSize() + SIZE_CHECKSUM + SIZE_TSZ;
				randomFile.seek(seekPosition);
				long templateId = randomFile.readLong();
				if (templateId == bioId.longValue()) {
					randomFile.seek(seekPosition + SIZE_TEMPLATE_ID);
					randomFile.writeByte(b);
					int recordCount = (bioId.intValue() - this.bioIdStart.intValue()) - 1;
					updateSegmentHead(randomFile, recordCount, segVer);
					deleted = true;
				} else {
					throw new NodeStroageException("Template Id(" + String.valueOf(bioId) + ") not found bioId");
				}				
		
			} catch (Exception e) {
				deleted = false;
				log.error(e.getMessage(), e);
			} finally {
				writeLock.unlock();
				randomFile.close();
			}
			return  Boolean.valueOf(deleted);
		};
		return NodeStorageManager.submit(delTemplateTask);
	}
	
	private void updateSegmentHead(RandomAccessFile randomFile, int recordCount, long segVer) throws IOException {
		randomFile.seek(SIZE_VERSION + SIZE_EMBEDDED_ID + SIZE_MAX_SEGMENT);
		randomFile.writeInt(recordCount);		
		randomFile.writeLong(segVer);		
	}
	
	public boolean isFileExists(long segmentId) {
		if (this.segmentId == segmentId &&  this.myFile != null && myFile.exists()) {
			return true;
		} else {
			return false;
		}			
	}	
}
