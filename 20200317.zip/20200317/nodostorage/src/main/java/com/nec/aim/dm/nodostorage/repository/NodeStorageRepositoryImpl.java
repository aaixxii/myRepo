package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.entity.NodeStorage;



@Repository
public class NodeStorageRepositoryImpl implements NodeStorageRepository{
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private ConfigProperties config;	
	
	private static final String updateMyInfoSql = "update node_storage  set status =1, update_ts=CURRENT_TIMESTAMP() where  storage_id =? and dm_storage_id=?";
	private static final String getmyMailFalg = "update node_storage set mail_flag = ''  where storage_id =? and dm_storage_id = ? and mail_flag = 'signal';";
	
	RowMapper<NodeStorage> nodeRowMapper = (rs, rowNum) -> {
	    NodeStorage node = new NodeStorage();
	    node.setStorageId(rs.getInt("storage_id"));
	    node.setDmStorageid(rs.getString("dm_storage_id"));
	    node.setUrl(rs.getString("url"));
	    node.setDiskSize(rs.getInt("disk_size"));
	    node.setSpace(rs.getInt("space"));
	    node.setStatus(rs.getInt("status"));
	    node.setUpdateTs(rs.getTimestamp("update_ts"));
	    return node;
	};	

	@Override
	public void heatbeat() throws SQLException {
		jdbcTemplate.update(updateMyInfoSql, new Object[] {config.getId(), config.getDmId()});	
	}

	@Override
	public int getMyMailFlag()  throws SQLException  {
		int falgCount = jdbcTemplate.update(getmyMailFalg, new Object[] {config.getId(), config.getDmId()}, Integer.class);
		return falgCount;
	}

}
