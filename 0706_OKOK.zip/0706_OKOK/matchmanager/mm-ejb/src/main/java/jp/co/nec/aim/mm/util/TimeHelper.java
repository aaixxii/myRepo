package jp.co.nec.aim.mm.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Erik Vandekieft
 */
public class TimeHelper {
	private String prefix;
	private List<Long> times;

	public TimeHelper(String prefix) {
		this.prefix = prefix;
		times = new ArrayList<Long>();
	}

	public void t() {
		times.add(System.nanoTime());
	}

	public String message() {
		StringBuffer buf = new StringBuffer("TIMEHELPER : " + prefix
				+ " times: ");
		if (1 < times.size()) {
			for (int i = 0; i < times.size() - 1; ++i) {
				long t1 = times.get(i);
				long t2 = times.get(i + 1);
				double elapsedMS = (double) (t2 - t1) / (double) 1000000;
				buf.append(elapsedMS);
				buf.append(", ");
			}
			buf.delete(buf.length() - ", ".length(), buf.length());
		}
		return buf.toString();
	}

	public static boolean isTime(Date lastTime, Integer intervalMS) {
		return lastTime == null
				|| lastTime.getTime() + intervalMS < System.currentTimeMillis();
	}

}
