package jp.co.nec.aim.mm.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.extract.dispatch.FEPlanDispatcher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Listening and receive jms that sent to FeDispatchQueue
 * 
 * @author xiazp
 *
 */
@MessageDriven(name = "FEplanCreatedEventReceiver", activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = JNDIConstants.EXTRACT_JOB_DISPATCH_QUEUE),
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge") })
public class FEplanCreatedEventReceiver implements MessageListener {
	private static Logger logger = LoggerFactory
			.getLogger(FEplanCreatedEventReceiver.class);
	@EJB
	private FEPlanDispatcher fEPlanDispatcher;

	/**
	 * @param rcvMessage
	 */
	@Override
	public void onMessage(Message rcvMessage) {
		Long feLotJobId = -999L;
		String meg = null;
		if (rcvMessage == null || (!(rcvMessage instanceof TextMessage))) {
			logger.warn("Received an empty message or rong messege type! process will stop!");
			return;
		}
		TextMessage txMsg = (TextMessage) rcvMessage;
		try {
			meg = txMsg.getText();
			feLotJobId = Long.valueOf(meg);
		} catch (JMSException e) {
			logger.error(e.getMessage(), e);
			return;
		}
		if (feLotJobId == null || feLotJobId < 0L) {
			logger.warn("Received wrong feLotJobId({})", feLotJobId);
			return;
		}
		logger.info("Received Message from FeDispatchQueue: " + feLotJobId);

		if (!fEPlanDispatcher.doDispatch(feLotJobId)) {
			String errMsg = "FePlannDispatcher is failed to process felotJob({})";
			logger.error(errMsg, feLotJobId);
		} else {
			logger.info(
					"FEPlanDispatcher from JMS is successed. feLotJobId={}",
					feLotJobId);
		}
	}
}
