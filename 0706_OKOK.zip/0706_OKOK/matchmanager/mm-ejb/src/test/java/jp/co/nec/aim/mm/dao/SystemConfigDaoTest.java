package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.util.EnumSet;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.MMConfigProperty;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class SystemConfigDaoTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	private Properties properties = new Properties();
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	private SystemConfigDao sysConDao;

	@Before
	public void setUp() throws IOException {
		jdbcTemplate.update("delete from system_config");
		sysConDao = new SystemConfigDao(entityManager);
		sysConDao.writeAllMissingProperties(dataSource);
		InputStream is = MMConfigProperty.class.getClassLoader()
				.getResourceAsStream("default.mm.properties");
		properties.load(is);
		is.close();
	}

	@After
	public void setDown() {
		jdbcTemplate.update("delete from system_config");
		jdbcTemplate.update("commit");
	}

	/**
	 * Check whether key-values in default.mm.properties are existed in
	 * SYSTEM_CONFIG table.
	 */
	@Test
	public void testWriteAllMissingProperties() {
		Set<Entry<Object, Object>> entrySet = properties.entrySet();
		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			String value = properties.getProperty(key);
			assertEquals(value, sysConDao.getMMProperty(key));
		}
	}

	/**
	 * Get MM Property test
	 */
	@Test
	public void testGetMMProperty() {
		Set<Entry<Object, Object>> entrySet = properties.entrySet();

		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			for (MMConfigProperty mm : EnumSet.allOf(MMConfigProperty.class)) {
				if (mm.getName().equals(key)) {
					assertEquals(properties.getProperty(key),
							sysConDao.getMMProperty(mm));
				}
			}
		}
	}

	/**
	 * MMConfigProperty must have same number of member as properties
	 */
	@Test
	public void testMMPConfigPropertySize() {
		assertEquals(properties.size(),//
				EnumSet.allOf(MMConfigProperty.class).size());
	}
}
