package jp.co.nec.aim.mm.jms;

import java.util.Properties;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.exception.AimRuntimeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Lockup Jndi object for processing jms
 * 
 * @author xiazp
 *
 */
public class JndiObjectLookuper {
	private static Logger logger = LoggerFactory
			.getLogger(JndiObjectLookuper.class);
	private static final JndiObjectLookuper INSTANCE = new JndiObjectLookuper();

	private static final String INITIAL_CONTEXT_FACTORY = "org.jboss.naming.remote.client.InitialContextFactory";
	private static final String DEFAULT_CONNECTION_FACTORY = "jms/RemoteConnectionFactory";
	private static final String FE_PLANNER_QUQUE = "java:/jms/queue/FEPlannerQueue";
	private static final String IDENTIFY_PLANNER_QUQUE = "java:/jms/queue/IdentifyPlanerQueue";
	private static final String FE_PLANNER_DISPATCH_QUQUE = "java:/jms/queue/FeDispatchQueue";
	private static final String IDENTIFY_PLANNER_DISPATCH_QUQUE = "java:/jms/queue/IdentifyDispatchQueue";
	private static final String PROVIDER_URL = "http-remoting://localhost:8080";
	private static String WILDFLY_MANAGEMENT_USER;
	private static String WILDFLY_MANAGEMENT_PASSWORD;
	// one instance,it must not get it per call
	private static ConnectionFactory connectionFactory;
	private Context context;

	/**
	 * MANAGEMENT_USER,MANAGEMENT_PASSWORD must not get it per call. Constructor
	 */
	public JndiObjectLookuper() {
		intiContextEnv();
		connectionFactory = lookupDefaultConnectionFactory();
		WILDFLY_MANAGEMENT_USER = ConfigProperties.getInstance()
				.getPropertyValue(ConfigPropertyNames.WILDFLY_MANAGEMENT_USER);
		WILDFLY_MANAGEMENT_PASSWORD = ConfigProperties.getInstance()
				.getPropertyValue(
						ConfigPropertyNames.WILDFLY_MANAGEMENT_PASSWORD);
	}

	public static JndiObjectLookuper getInstance() {
		return INSTANCE;
	}

	public ConnectionFactory lookupDefaultConnectionFactory() {
		String connectionFactoryString = System.getProperty(
				"connection.factory", DEFAULT_CONNECTION_FACTORY);
		try {
			return (ConnectionFactory) context.lookup(connectionFactoryString);
		} catch (NamingException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	public static ConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}

	public Object looup(String jndiName) throws NamingException {
		return context.lookup(jndiName);
	}

	public void intiContextEnv() {
		final Properties env = new Properties();
		env.put(Context.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY);
		env.put(Context.PROVIDER_URL,
				System.getProperty(Context.PROVIDER_URL, PROVIDER_URL));
		env.put(Context.SECURITY_PRINCIPAL,
				System.getProperty("username", WILDFLY_MANAGEMENT_USER));
		env.put(Context.SECURITY_CREDENTIALS,
				System.getProperty("password", WILDFLY_MANAGEMENT_PASSWORD));
		try {
			context = new InitialContext(env);
		} catch (NamingException e) {
			logger.error(e.getMessage(), e);
			throw new AimRuntimeException(e);
		}
	}

	public Connection lookupDefaultConnection() throws JMSException {
		return connectionFactory.createConnection(
				System.getProperty("username", WILDFLY_MANAGEMENT_USER),
				System.getProperty("password", WILDFLY_MANAGEMENT_PASSWORD));
	}

	public Destination lookupFePlannerQueue() throws NamingException {
		return (Destination) context.lookup(FE_PLANNER_QUQUE);
	}

	public Destination lookupIdentifyPlannerQueue() throws NamingException {
		return (Destination) context.lookup(IDENTIFY_PLANNER_QUQUE);
	}

	public Queue lookupFeDispatcherPlannerQueue() throws NamingException {
		return (Queue) context.lookup(FE_PLANNER_DISPATCH_QUQUE);
	}

	public Queue lookupIdentifyDispatcherPlannerQueue() throws NamingException {
		return (Queue) context.lookup(IDENTIFY_PLANNER_DISPATCH_QUQUE);
	}
}
