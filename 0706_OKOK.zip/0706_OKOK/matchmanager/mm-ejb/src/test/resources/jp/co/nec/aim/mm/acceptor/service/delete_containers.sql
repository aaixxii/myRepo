
UPDATE HIGH_LEVEL_SERVICE_LAYOUTS t set t.script_xml = replace(t.script_xml,'<scope>2</scope>','<scope>1</scope>')where script_id=1;
UPDATE HIGH_LEVEL_SERVICE_LAYOUTS t set t.script_xml = replace(t.script_xml,'<scope>2</scope>','<scope>1</scope>')where script_id=2;
UPDATE HIGH_LEVEL_SERVICE_LAYOUTS t set t.script_xml = replace(t.script_xml,'<scope>2</scope>','<scope>1</scope>')where script_id=3;
delete from PERSON_BIOMETRICS where CONTAINER_ID=1001;
delete from PERSON_BIOMETRICS where CONTAINER_ID=1331;
delete from SEGMENTS where CONTAINER_ID=1001;
delete from SEGMENTS where CONTAINER_ID=1002;
delete from CONTAINER_JOBS where CONTAINER_ID=1001;
delete from CONTAINER_JOBS where CONTAINER_ID=1002;
delete from "CONTAINERS" where CONTAINER_ID=1001; 
delete from "CONTAINERS" where CONTAINER_ID=1002; 
delete from "CONTAINERS" where CONTAINER_ID=1331; 
delete from SCOPES where SCOPE_ID=2;
commit;