package com.nec.lmx.agent.lmx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xformation.lmx.Lmx;
import com.xformation.lmx.Lmx.HeartbeatCheckoutSuccessCallback;
import com.xformation.lmx.LmxException;

/*
 * FloatLicenseHandler is called after failed in license server heartbeat.<br/>
 * @author xiazp
 * 
 */
public class LicenseHandler {

	private static Logger logger = LoggerFactory.getLogger(LicenseHandler.class);
	private static final LicenseHandler INSTANCE = new LicenseHandler();

	public static LicenseHandler getInstance() {
		return INSTANCE;
	}

	public void initHeatbeatHandler(Lmx lmx) throws LmxException {
		lmx.setHeartbeatCheckoutSuccessCallback(HeartbeatCheckoutSuccessConsumer);
		lmx.setHeartbeatConnectionLostCallback(heartbeatConnectionLostConsumer);
		lmx.setHeartbeatCheckoutFailureCallback(heartbeatCheckoutFailureConsumer);
		lmx.setHeartbeatRetryFailureCallback(heartbeatRetryFailureConsumer);
		lmx.setHeartbeatExitCallback(heartbeatExitConsumer);
	}

	static Lmx.HeartbeatConnectionLostCallback heartbeatConnectionLostConsumer = (host, port, failedHeartbeats) -> {
		logger.warn("Heartbeat connection is lost. host:{}, port:{}", host, port);
		LicenseManager.getInstance().clearLicenseInfoMap();

	};

	static Lmx.HeartbeatCheckoutFailureCallback heartbeatCheckoutFailureConsumer = (featureName, used, status) -> {
		logger.warn("HeartbeatCheckoutFailured. featureName:{}, status:{}", featureName, status.name());
		LicenseManager.getInstance().clearLicenseInfoMap();

	};

	static Lmx.HeartbeatRetryFailureCallback heartbeatRetryFailureConsumer = (featureName, usedLicCount) -> {
		logger.warn("HeartbeatRetryFailure. feature:{}", featureName);
		LicenseManager.getInstance().clearLicenseInfoMap();
	};

	static Lmx.HeartbeatExitCallback heartbeatExitConsumer = () -> {
		LicenseManager.getInstance().cleanAllLmxResource();
	};

	static HeartbeatCheckoutSuccessCallback HeartbeatCheckoutSuccessConsumer = (featureName, usedLicCount) -> {
		logger.warn("Heartbeat successed. feature:{}", featureName);
	};
}
