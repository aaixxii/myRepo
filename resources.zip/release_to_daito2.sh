#!/bin/sh

#####################################################
#
#       REPLACEMENT CONFIG (Daito2)
#
#####################################################

DIFFFILE="copy_result.txt"

####
# file copy and output diff
###
copy_file(){
  echo "copy [" $1 "]->[" $2 "]"
  cp -p -f $1 $2
  diff -s $1 $2 >> $DIFFFILE
}


####
#  main
####

SCRIPT_DIR=$(cd $(dirname $0); pwd)

cd $SCRIPT_DIR

echo "---------------------------------"
echo "change setting to Daito2"
echo "---------------------------------"

echo "execute in [" $SCRIPT_DIR "]"

if [[ -f $DIFFFILE ]]; then
  echo "clean old file"
  rm $DIFFFILE
fi

echo ""

echo "=== start copy"
copy_file DbPropAp.xml.Daito2 DbPropAp.xml
copy_file DbPropApG5.xml.Daito2 DbPropApG5.xml
copy_file DbPropApGhs.xml.Daito2 DbPropApGhs.xml
copy_file application.properties.Daito2 application.properties
copy_file config.properties.Daito2 config.properties
echo "=== end"

echo ""

echo "=== check diff start"
cat $DIFFFILE
echo "=== end"

echo ""

