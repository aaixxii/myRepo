package com.nec.lmx.agent.lmx;

import java.lang.reflect.Type;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class FloatingLicenseManagerTest {
	private final ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSendLicenseInfo() {
		licenseMap.put("AFIS", "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS");
		licenseMap.put("EXPIRED", "false");
		licenseMap.put("DIFFERENT", "false");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		Type mapType = new TypeToken<Map<String, String>>() {}.getType();		
		String licesneInfo = gson.toJson(licenseMap, mapType);
		System.out.println(licesneInfo);		
	}
	
	@Test
	public void testBuilderSendString() {
		licenseMap.put("AFIS", "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS");
		licenseMap.put("EXPIRED", "false");
		String option = licenseMap.get("AFIS");
		String expired = licenseMap.get("EXPIRED");
		StringBuilder sb = new StringBuilder();
		sb.append(option);
		sb.append(";");
		sb.append("EXPIRED");
		sb.append("=");
		sb.append(expired);	
		System.out.println(sb.toString());
	}

	@Test
	public void testCheckEndDate() {		
	}

}
