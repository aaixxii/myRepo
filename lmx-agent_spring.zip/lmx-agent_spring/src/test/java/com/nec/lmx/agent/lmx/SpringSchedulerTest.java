package com.nec.lmx.agent.lmx;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@Configuration
@EnableScheduling
public class SpringSchedulerTest {

	@Scheduled(cron = "0/1 * * * * *")
	private void lmxHeartbeat() {
		System.out.println("Run heatbeat!!");
	}

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringSchedulerTest.class);
		try {
			Thread.sleep(12000 * 3);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			context.close();
		}
	}

}
