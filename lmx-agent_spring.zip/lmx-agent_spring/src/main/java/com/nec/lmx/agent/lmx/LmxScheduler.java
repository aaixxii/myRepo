package com.nec.lmx.agent.lmx;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.nec.lmx.agent.event.EventNotifier;
import com.xformation.lmx.Lmx;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxFeatureInfo;
import com.xformation.lmx.LmxHostidType;
import com.xformation.lmx.LmxSettings;
import com.xformation.lmx.LmxStatus;

@Configuration
@EnableScheduling
public class LmxScheduler {
	private final ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger("LmxAgentLogger");

	private static final String FEATURE_NAME = "AFIS";
	private static final String EXPIRED = "EXPIRED";
	private static final String ERROR = "ERROR";
	private Lmx MM_LMX = new Lmx();

	private final int VER_MAJOR = 5;
	private final int VER_MINOR = 0;
	private final int LMX_OPTION = 1;

	private static int numServer = 1;

	private boolean isFirst;
	
	private AnnotationConfigApplicationContext context;

	@PostConstruct
	public void setup() {
		context = new AnnotationConfigApplicationContext(LmxScheduler.class);
		try {
			initLmx();
			isFirst = true;
			setUpEventHandler();
			logger.info("Floating license manager sucese intialiized.");
			checkOutFromServer();
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
			sendError(e);
		}
	}

	private void initLmx() throws LmxException {
		MM_LMX.init();
		MM_LMX.setOption(LmxSettings.LMX_OPT_HOSTID_DISABLED, LmxHostidType.LMX_HOSTID_ALL);
	}

	@Scheduled(cron = "0 */1 * * * *")
	private void lmxHeartbeat() {
		logger.info("LMX heatbeat at:" + new Date());
		try {
			MM_LMX.heartbeat(FEATURE_NAME);
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Scheduled(cron = "0 1 0 * * *")
	private void checkEndDate() {
		logger.info("LMX check expired date at:" + new Date());
		try {
			licenseMap.clear();
			MM_LMX.checkin(FEATURE_NAME, Lmx.LMX_ALL_LICENSES);
			logger.info("Checked in " + FEATURE_NAME + ".");
			checkOutFromServer();
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
			sendError(e);
		}
	}

	private void setUpEventHandler() throws LmxException {
		MM_LMX.setHeartbeatRetryFailureCallback((featureName, usedLicCount) -> {
			logger.warn("Failed to retry heartbeat by " + featureName + ".");
			clearLicenseInfoMap();
		});

		MM_LMX.setHeartbeatConnectionLostCallback((host, port, failedHeartbeats) -> {
			logger.warn("Connection to " + host + " on port " + port + " is lost.");
			if (numServer == 1) {
				clearLicenseInfoMap();
			}
		});

		MM_LMX.setHeartbeatCheckoutFailureCallback((featureName, used, lmxStat) -> {
			logger.warn("Failed to checkout " + featureName + ".");

			try {
				initLmx();
			} catch (LmxException ex) {
				logger.error(ex.getMessage(), ex);
			}
		});

		MM_LMX.setHeartbeatCheckoutSuccessCallback((feature, usedLicCount) -> {
		});
	}

	/*
	 * @param now the current time
	 * 
	 * @throws LicenseException
	 */
	public void checkOutFromServer() {
		logger.info("Check feature from license server.");
		LmxFeatureInfo feature = null;
		try {
			MM_LMX.checkout(FEATURE_NAME, this.VER_MAJOR, this.VER_MINOR, this.LMX_OPTION);
			feature = MM_LMX.getFeatureInfo(FEATURE_NAME);
			saveFeatureToMap(feature);
			if (isFirst) {
				sendLicenseInfo();
				isFirst = false;
			}
		} catch (LmxException e) {
			sendError(e);
		}
	}

	/*
	 * @param LmxFeatureInfo the lmx feature
	 * 
	 * @param now the current time
	 * 
	 * @throws LicenseException,LmxException
	 */
	private void saveFeatureToMap(LmxFeatureInfo feature) {
		String licenseInfo = feature.getOptions();
		if (licenseInfo == null || licenseInfo.isEmpty()) {
			String errMsg = String.format("FLoating license server error occurred, can't found license info from %s.",
					feature);
			logger.warn(errMsg);
			return;
		}
		licenseMap.putIfAbsent(FEATURE_NAME, licenseInfo);
	}

	private void sendLicenseInfo() {
		String option = licenseMap.get(FEATURE_NAME);
		String expired = licenseMap.get(EXPIRED);
		StringBuilder sb = new StringBuilder();
		sb.append(option);
		sb.append(";");
		sb.append(EXPIRED);
		sb.append("=");
		sb.append(expired);
		EventNotifier.getInstance().fireOnMessage(sb.toString());
	}

	private void sendError(LmxException e) {
		LmxStatus status = e.getErrorCode();
		if (!status.equals(LmxStatus.LMX_SUCCESS)) {
			StringBuilder sb = new StringBuilder();
			sb.append(ERROR);
			sb.append("=");
			sb.append(e.getMessage());
			sb.append(";");
			sb.append("STATUS");
			sb.append("=");
			sb.append(e.getErrorCode());
			EventNotifier.getInstance().fireOnError(sb.toString());
		}
	}

	public void clearLicenseInfoMap() {
		try {
			MM_LMX = null;
			MM_LMX = new Lmx();
			MM_LMX.init();			
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		}
		licenseMap.clear();
	}

	@PreDestroy
	public void cleanAllLmxResource() {		
		logger.info("Clear all resource at:" + new Date());
		licenseMap.clear();
		context.close();
		MM_LMX.free();
	}
}
