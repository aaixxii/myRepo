package com.nec.lmx.agent.lmx;

import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.event.EventNotifier;
import com.xformation.lmx.Lmx;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxFeatureInfo;
import com.xformation.lmx.LmxHostidType;
import com.xformation.lmx.LmxSettings;
import com.xformation.lmx.LmxStatus;

/*
 * FloatingLicenseManager:
 * 1. get license info from license server and save it to map.<br/>
 * 2. validate license while inquiry job is coming using license info in map.<br/>
 * 
 * @author xiazp
 */
public class LicenseManager {
	private final ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger(LicenseManager.class);

	private static final String FEATURE_NAME = "AFIS";
	private static final String EXPIRED = "EXPIRED";
	private static final String ERROR = "ERROR";
	private static final long INTERVAL_ONE_DAY = 86400000;
	private static final long INTERVAL_OF_HEATBEAT = 30 * 1000;

	private Lmx MM_LMX = new Lmx();

	private final int VER_MAJOR = 5;
	private final int VER_MINOR = 0;
	private final int LMX_OPTION = 1;

	private String floatingServeerPath;
	// private ReentrantLock managerLocker;

	private boolean isFirst;

	private static ScheduledExecutorService heatBeatExecutor = Executors.newSingleThreadScheduledExecutor();
	private static ScheduledExecutorService experiedExecutor = Executors.newSingleThreadScheduledExecutor();

	private LicenseManager() {
	}

	public void initLmx(String floatingSeverInfo) {
		this.floatingServeerPath = floatingSeverInfo;
		try {
			logger.info("License server url: {}", floatingSeverInfo);
			MM_LMX.init();
			isFirst = true;
			MM_LMX.setOption(LmxSettings.LMX_OPT_LICENSE_PATH, floatingSeverInfo);
			MM_LMX.setOption(LmxSettings.LMX_OPT_HOSTID_DISABLED, LmxHostidType.LMX_HOSTID_ALL);
			LicenseHandler.getInstance().initHeatbeatHandler(MM_LMX);
			experiedExecutor.scheduleAtFixedRate(new Thread(CheckExpiredTask), INTERVAL_ONE_DAY, INTERVAL_ONE_DAY,
					TimeUnit.MILLISECONDS);
			heatBeatExecutor.scheduleAtFixedRate(new Thread(HeatBeatTask), INTERVAL_OF_HEATBEAT, INTERVAL_OF_HEATBEAT,
					TimeUnit.MILLISECONDS);
			logger.info("Floating license manager sucese intialiized.");
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
			sendError(e);
		}
	}

	private static final LicenseManager INSTANCE = new LicenseManager();

	public static LicenseManager getInstance() {
		return INSTANCE;
	}

	/*
	 * @param now the current time
	 * 
	 * @throws LicenseException
	 */
	public void checkOutFromServer() {
		logger.info("Check feature from license server.");
		LmxFeatureInfo feature = null;
		try {
			MM_LMX.checkout(FEATURE_NAME, this.VER_MAJOR, this.VER_MINOR, this.LMX_OPTION);
			feature = MM_LMX.getFeatureInfo(FEATURE_NAME);
			saveFeatureToMap(feature);
			if (isFirst) {
				sendLicenseInfo();
				isFirst = false;
			}
		} catch (LmxException e) {
			sendError(e);
		}
	}

	/*
	 * @param LmxFeatureInfo the lmx feature
	 * 
	 * @param now the current time
	 * 
	 * @throws LicenseException,LmxException
	 */
	private void saveFeatureToMap(LmxFeatureInfo feature) {
		String licenseInfo = feature.getOptions();
		if (licenseInfo == null || licenseInfo.isEmpty()) {
			String errMsg = String.format("FLoating license server error occurred, can't found license info from %s.",
					feature);
			logger.warn(errMsg);
			return;
		}
		licenseMap.putIfAbsent(FEATURE_NAME, licenseInfo);
	}

	private void sendLicenseInfo() {
		String option = licenseMap.get(FEATURE_NAME);
		String expired = licenseMap.get(EXPIRED);
		StringBuilder sb = new StringBuilder();
		sb.append(option);
		sb.append(";");
		sb.append(EXPIRED);
		sb.append("=");
		sb.append(expired);
		EventNotifier.getInstance().fireOnMessage(sb.toString());
	}

	private void sendError(LmxException e) {
		LmxStatus status = e.getErrorCode();
		if (!status.equals(LmxStatus.LMX_SUCCESS)) {
			StringBuilder sb = new StringBuilder();
			sb.append(ERROR);
			sb.append("=");
			sb.append(e.getMessage());
			sb.append(";");
			sb.append("STATUS");
			sb.append("=");
			sb.append(e.getErrorCode());
			EventNotifier.getInstance().fireOnError(sb.toString());
		}
	}

	public void clearLicenseInfoMap() {
		try {
			MM_LMX = null;
			MM_LMX = new Lmx();
			MM_LMX.init();
			MM_LMX.setOption(LmxSettings.LMX_OPT_LICENSE_PATH, this.floatingServeerPath);
			LicenseHandler.getInstance().initHeatbeatHandler(MM_LMX);
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		}
		licenseMap.clear();
	}

	public void cleanAllLmxResource() {
		logger.info("Clear all resource at:" + new Date());
		try {
			heatBeatExecutor.shutdown();
			experiedExecutor.shutdown();
			licenseMap.clear();
			MM_LMX.checkin(FEATURE_NAME, Lmx.LMX_ALL_LICENSES);
			MM_LMX.free();
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private void checkEndDate() {
		logger.info("LMX check expired date at:" + new Date());
		try {
			licenseMap.clear();
			MM_LMX.checkin(FEATURE_NAME, Lmx.LMX_ALL_LICENSES);
			logger.info("Checked in " + FEATURE_NAME + ".");
			checkOutFromServer();
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
			sendError(e);
		}
	}

	private void lmxHeartbeat() {
		logger.info("LMX heatbeat at:" + new Date());
		try {
			MM_LMX.heartbeat(FEATURE_NAME);
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		}
	}

	private Runnable CheckExpiredTask = () -> {
		checkEndDate();
	};

	private Runnable HeatBeatTask = () -> {
		lmxHeartbeat();
	};
}
