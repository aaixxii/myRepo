package com.nec.biomatcher.core.framework.license.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.DateUtil;
import com.nec.biomatcher.core.framework.license.exception.InvalidLicenseException;
import com.xformation.lmx.Lmx;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxFeatureInfo;
import com.xformation.lmx.LmxHostidType;
import com.xformation.lmx.LmxSettings;

/**
 * License Control Manager to load the license information from the license key.
 * Currently, it is implemented based on License3j API which provides the
 * underlying functions to create and assert license files. This implementation
 * uses assymetric cryptography which uses different key to encode and decode
 * the license and thus making the application more secure. Currently, the
 * license information is only limited to the followings:
 * 1) Valid Start Date (Issue Date) 2) Valid End Date (Expiry Date) 3) Maximum
 * Client Allowed. This controls the number of workstations that can be defined
 * in the system.
 * 
 * @author Alvin Chua
 * @since 15 Sep 2011
 * @version 1.0
 */

/*
 * Modification History:
 * 29 Sep 2011 (Alvin Chua): Add checkServerValidity() to validate the server
 * MAC and IP addresses.
 */
public class LicenseManager {
    
    /** The license control policy. */
    private static final ConcurrentHashMap<String, LocalLicenseControlPolicy> localLicenseControlPolicyMap = new ConcurrentHashMap<>();
    
    private final ConcurrentHashMap<String, LmxFeatureInfo> floatingLicenseMap = new ConcurrentHashMap<>(); // key is templete type
    
    /** The Constant logger. */
    private static final Logger logger = Logger.getLogger(LicenseManager.class);
    
    private boolean isFoatingLicense;
    
    private ReentrantLock liceseLocker;
    
    private volatile boolean isInitialize;
    
    private static final Lmx LMX = new Lmx();
    
    private static final LicenseManager INSTANCE = new LicenseManager();
    
    private static ScheduledExecutorService executor;
    
    private static final long INTERVAL_ONE_DAY = 86400000;
    
    private static String TEMPLATE_TYPE_KEY = "TEMPLATE_TYPE_";
    
    public LicenseManager() {
        this.isFoatingLicense = false;
        liceseLocker = new ReentrantLock();
        isInitialize = false;
    }
    
    public static LicenseManager getInstance() {
        return INSTANCE;
    }
    
    public void initLicenseManager(String foatingLicenseServerPath) {
        if (isInitialize) {
            logger.info("License manager has been initialized, skip!");
            return;
        }
        liceseLocker.lock();
        try {
            LMX.init();
            if (!StringUtils.isBlank(foatingLicenseServerPath)) {
                isFoatingLicense = true;
                LMX.setOption(LmxSettings.LMX_OPT_LICENSE_PATH, foatingLicenseServerPath);
                LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_ATTEMPTS, -1);
                LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_INTERVAL, 30);
                LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_INTERVAL, 30);
                LMX.setHeartbeatCheckoutFailureCallback(heartbeatCheckoutFailureConsumer);
                FloatLicenseHandler.getInstance().initHeatbeatHandler(LMX);
                logger.info("Foating LicenseServer Url: " + foatingLicenseServerPath);
                // executor = Executors.newSingleThreadScheduledExecutor();
                // executor.scheduleAtFixedRate(new LmxTask(), 0, INTERVAL_ONE_DAY, TimeUnit.MILLISECONDS);
            }
            String lmxLibPath = System.getProperty("java.library.path");
            if (StringUtils.isBlank(lmxLibPath)) {
                String wildflyHome = System.getProperty("jboss.home.dir");
                if (StringUtils.isBlank(wildflyHome))
                    return;
                String path = "license/lmx/linux_x64";
                lmxLibPath = wildflyHome.endsWith("/") ? wildflyHome + path : wildflyHome + "/" + path;
                System.setProperty("java.library.path", lmxLibPath);
                System.loadLibrary("liblmxjava.so");
            }
            isInitialize = true;
            logger.info("Sucess initializes license manager!");
            logger.info("Lmx lib path: " + lmxLibPath);
            
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            liceseLocker.unlock();
        }
    }
    
    static Lmx.HeartbeatConnectionLostCallback heartbeatConnectionLostConsumer = (host, port, failedHeartbeats) -> {
        System.out.println("Connection to " + host + " on port " + port + " is lost.");
    };
    
    static Lmx.HeartbeatCheckoutFailureCallback heartbeatCheckoutFailureConsumer = (featureName, used, lmxStat) -> {
        System.out.println("Checkout of feature " + featureName + " failed. Status " + lmxStat.name());
    };
    
    public void checkFeatureLicense(String featureId) throws InvalidLicenseException {
        if (!isFoatingLicense) {
            checkLocalFeatureLicense(featureId);
        } else {
            checkFloatFeatureLicense(featureId);
        }
    }
    
    private void checkLocalFeatureLicense(String featureId) throws InvalidLicenseException {
        LocalLicenseControlPolicy licenseControlPolicy = localLicenseControlPolicyMap.get(featureId);
        if (licenseControlPolicy == null) {
            licenseControlPolicy = localLicenseControlPolicyMap.computeIfAbsent(featureId,
                featureIdKey -> readFeature(featureIdKey));
        }
        
        if (!licenseControlPolicy.isFeatureEnabled()) {
            throw new InvalidLicenseException("License is not enabled for featureId: " + featureId + ", errorCode: "
                + licenseControlPolicy.getErrorCode() + ", errorMessage: "
                + licenseControlPolicy.getErrorMessage());
        }
        
        if (licenseControlPolicy.getValidStartDate() != null && licenseControlPolicy.getValidEndDate() != null) {
            long currentTimeMilli = System.currentTimeMillis();
            if (currentTimeMilli < licenseControlPolicy.getValidStartDate().getTime()
                || currentTimeMilli > licenseControlPolicy.getValidEndDate().getTime()) {
                throw new InvalidLicenseException("License is not enabled for featureId: " + featureId + ", startDate: "
                    + DateUtil.parseDate(licenseControlPolicy.getValidStartDate(), DateUtil.FORMAT_DATE)
                    + ", endDate: "
                    + DateUtil.parseDate(licenseControlPolicy.getValidEndDate(), DateUtil.FORMAT_DATE));
            }
        }
    }
    
    private void checkFloatFeatureLicense(String templeteType) throws InvalidLicenseException {
        if (StringUtils.isBlank(templeteType)) {
            throw new InvalidLicenseException("TempleteType is null or empty!.");
        }
        LmxFeatureInfo feature = null;
        try {
            
            LMX.checkout(templeteType, 1, 0, 1);
            feature = LMX.getFeatureInfo(templeteType);
            LMX.checkin(templeteType, Lmx.LMX_ALL_LICENSES);
        } catch (LmxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        // LmxFeatureInfo feature = floatingLicenseMap.get(templeteType);
        if (feature == null) {
            floatingLicenseMap.computeIfAbsent(String.format(templeteType), (templetekey) -> checkOutFromServer(templetekey));
        }
        checkFloatLicenseDetail(templeteType);
        
    }
    
    private void checkFloatLicenseDetail(String templateType) throws InvalidLicenseException {
        LmxFeatureInfo feature = floatingLicenseMap.get(templateType);
        if (feature == null || feature.getEndDate() == null || feature.getKey() == null) {
            throw new InvalidLicenseException("Can't found feature data or it's key is invalid.");
        }
    }
    
    public LmxFeatureInfo checkOutFromServer(String featureId) {
        LmxFeatureInfo feature = null;
        liceseLocker.lock();
        try {
            LMX.checkout(featureId, 1, 0, 1);
            feature = LMX.getFeatureInfo(featureId);
        } catch (Exception e) {
            logger.error("Error messge is:" + e.getMessage(), e);
        } finally {
            liceseLocker.unlock();
        }
        return feature;
    }
    
    private LocalLicenseControlPolicy readFeature(String featureId) {
        long startTimeMilli = System.currentTimeMillis();
        liceseLocker.lock();
        try {
            String strHostid = LMX.getHostidSimple(LmxHostidType.LMX_HOSTID_ETHERNET);
            logger.info("Ethernet hostid for this system is: " + strHostid);
            try {
                logger.info("Before checking feature license for featureId: " + featureId);
                
                LMX.checkout(featureId, 1, 0, 1);
                
                LocalLicenseControlPolicy licenseControlPolicy = new LocalLicenseControlPolicy(featureId);
                licenseControlPolicy.setFeatureEnabled(true);
                
                // Get information about the license
                LmxFeatureInfo lmxFeatureInfo = LMX.getFeatureInfo(featureId);
                
                licenseControlPolicy.setMaxClientAllowed((long) lmxFeatureInfo.getAvailableLicCount());
                
                if (StringUtils.isNotBlank(lmxFeatureInfo.getStartDate())) {
                    Date date = DateUtil.strToDate(lmxFeatureInfo.getStartDate(), DateUtil.FORMAT_DATE);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    cal.set(Calendar.HOUR_OF_DAY, 0);
                    cal.set(Calendar.MINUTE, 0);
                    cal.set(Calendar.SECOND, 0);
                    licenseControlPolicy.setValidStartDate(cal.getTime());
                }
                
                if (StringUtils.isNotBlank(lmxFeatureInfo.getEndDate())) {
                    Date date = DateUtil.strToDate(lmxFeatureInfo.getEndDate(), DateUtil.FORMAT_DATE);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    cal.set(Calendar.HOUR_OF_DAY, 23);
                    cal.set(Calendar.MINUTE, 59);
                    cal.set(Calendar.SECOND, 59);
                    licenseControlPolicy.setValidEndDate(cal.getTime());
                }
                
                LMX.checkin(featureId, Lmx.LMX_ALL_LICENSES);
                
                return licenseControlPolicy;
            } catch (LmxException ex) {
                logger.error(
                    "Error during checking feature license for featureId: " + featureId + ", errorCode: "
                        + ex.getErrorCode() + ", errorMessage: " + ex.getErrorStr() + " : " + ex.getMessage(),
                    ex);
                LocalLicenseControlPolicy licenseControlPolicy = new LocalLicenseControlPolicy(featureId);
                licenseControlPolicy.setFeatureEnabled(false);
                licenseControlPolicy.setErrorCode(ex.getErrorCode() == null ? "0" : ex.getErrorCode().name());
                licenseControlPolicy.setErrorMessage(ex.getErrorStr());
                return licenseControlPolicy;
            }
        } catch (Exception ex) {
            logger.error("Error in readFeature for featureId: " + featureId + " : " + ex.getMessage(), ex);
            LocalLicenseControlPolicy licenseControlPolicy = new LocalLicenseControlPolicy(featureId);
            licenseControlPolicy.setFeatureEnabled(false);
            licenseControlPolicy.setErrorCode("0");
            licenseControlPolicy
                .setErrorMessage("Error in readFeature for featureId: " + featureId + " : " + ex.getMessage());
            return licenseControlPolicy;
        } finally {
            liceseLocker.unlock();
            long timeTakenMilli = System.currentTimeMillis() - startTimeMilli;
            logger.info("In readFeature for featureId: " + featureId + ", TimeTakenMilli: " + timeTakenMilli);
        }
    }
    
    public void checkEndDate() {
        liceseLocker.lock();
        try {
            floatingLicenseMap.clear();
            TemplateType[] allType = TemplateType.values();
            for (TemplateType type : allType) {
                LMX.checkin(type.name(), Lmx.LMX_ALL_LICENSES);
            }
        } catch (LmxException e) {
            logger.error(e.getMessage(), e);
        } finally {
            liceseLocker.unlock();
        }
    }
    
    public void cleanAllLmxResource() {
        if (executor != null)
            executor.shutdown();
        localLicenseControlPolicyMap.clear();
        floatingLicenseMap.clear();
        TemplateType[] allType = TemplateType.values();
        for (TemplateType type : allType) {
            try {
                LMX.checkin(type.name(), Lmx.LMX_ALL_LICENSES);
            } catch (LmxException e) {
                logger.error(e.getMessage(), e);
            }
        }
        LMX.free();
    }
    
    @SuppressWarnings("unused")
    private synchronized String setTepmeleteTypeKey(String templeteType) {
        String last = templeteType.substring(templeteType.length() - 1, templeteType.length());
        TEMPLATE_TYPE_KEY = TEMPLATE_TYPE_KEY + last;
        return TEMPLATE_TYPE_KEY.toUpperCase();
    }
}
