package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import com.nec.aim.dm.dmservice.entity.SegmentInfo;

public interface SegmentRepository {
	public void updateSegment(SegmentInfo segInfo)  throws SQLException;		
	
}
