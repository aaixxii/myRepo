package com.nec.aim.dm.dmservice.dispatch;


import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.dmservice.entity.NodeStorage;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.NodeStorageRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class Dispatcher {
	
	@Autowired
	NodeStorageRepository nodeRepository;
	
	public Boolean dispatchPostRequest(PBDmSyncRequest dmSegReq) {
 		List<NodeStorage> activeList = null;
		try {
			String changeType = dmSegReq.getCmd().name().toUpperCase();
			long bioId = dmSegReq.getBioId();
			PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
				String externalId = null;
	  			byte[] templateData = null;
	  			if (templateInfo.hasReferenceId()) {
	  				externalId = templateInfo.getReferenceId();
	  			}
	  			if (templateInfo.hasData()) {
	  				templateData = templateInfo.getData().toByteArray();
	  			} 
			long segId = dmSegReq.getTargetSegments().getId();
			long segVer = dmSegReq.getTargetSegments().getVersion();
			= nodeRepository.findNeedNodeByRedundancy(templateSize, redundancy)
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
		if (activeList == null ||  activeList .size() < 1) {
			return Boolean.valueOf(false);
		}
		boolean result = true;
		for (NodeStorage one : activeList) {
			 boolean oneResult = HttpPoster.post(one.getUrl(), dmSegReq);
			 result = result && oneResult;
		}	
		return Boolean.valueOf(result);
	}
	
	public byte[] dispatchGetRequest(Long segId) throws InterruptedException, ExecutionException {
		List<NodeStorage> activeList = nodeRepository.findAll();
		if (activeList == null ||  activeList .size() < 1) {
			throw new DmServiceException("No active dm stroage node for process");
		}
		Collections.shuffle(activeList);
		byte[] result = HttpPoster.getSegment(activeList.get(0).getUrl(), segId);
		return result;
	}
}
