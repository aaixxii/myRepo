package jp.co.nec.aim.mm.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.mm.acceptor.AimInquiryRequest;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.Constants;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.ContainerJobFailureReasonEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.FusionJobEntity;
import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.procedure.CreateContainerJobProcedure;
import jp.co.nec.aim.mm.procedure.DeleteJobProcedure;
import jp.co.nec.aim.mm.procedure.MrJobPlansProcedures;
import jp.co.nec.aim.mm.util.CollectionsUtil;

public class InquiryJobDao {
	private static Logger log = LoggerFactory.getLogger(InquiryJobDao.class);
	private EntityManager entityManager;
	private DataSource dataSource;
	private DateDao dateDao;

	public InquiryJobDao(EntityManager entityManager, DataSource dataSource) {
		this.entityManager = entityManager;
		this.dataSource = dataSource;
		this.dateDao = new DateDao(dataSource);
	}

	public InquiryJobDao(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public long getContainerJobId(Long topJobId) {
		String sql = "select cj.CONTAINER_JOB_ID  from JOB_QUEUE jq, FUSION_JOBS fj, CONTAINER_JOBS cj"
				+ " where jq.JOB_ID = fj.JOB_ID and fj.FUSION_JOB_ID = cj.FUSION_JOB_ID and jq.JOB_ID = ?";
		JdbcTemplate jdbcTemplate = new JdbcTemplate(this.dataSource);
		BigInteger jobId = BigInteger.valueOf(topJobId);
		BigInteger containerJobId = jdbcTemplate.queryForObject(sql, new Object[] { jobId }, BigInteger.class);
		return containerJobId.longValue();
	}

	@SuppressWarnings("unchecked")
	public List<Long> listAllJobIds() {
		Query q = entityManager.createNamedQuery("NQ::allJobIds");
		return q.getResultList();
	}

	/**
	 * clearJobs
	 */
	public void clearJobs() {
		Query q = entityManager.createNamedQuery("NQ::clearJobs");
		q.executeUpdate();
	}

	public Long insertMrPlan(long mrId) throws SQLException {
		MrJobPlansProcedures mrPlanprocedure = new MrJobPlansProcedures(dataSource);
		Long batchPlanId = mrPlanprocedure.createNewMrJob(mrId);
		return batchPlanId;
	}

	public void deleteMrPlan(int mrId, long planId) {
		Query q = entityManager.createNamedQuery("NQ::delMrPlanById");
		q.setParameter("planId", planId);
		q.setParameter("mrId", mrId);
		q.executeUpdate();
	}

	/**
	 * deleteJob
	 * 
	 * @param jobId
	 *            jobId
	 */
	public void deleteJob(long jobId) {
		if (log.isDebugEnabled()) {
			log.debug("Calling delete_job stored procedure for job: " + jobId);
		}
		DeleteJobProcedure procedure = new DeleteJobProcedure(dataSource);
		procedure.setJobId(new Long(jobId));
		procedure.execute();
	}

	/**
	 * getTopLevelJob
	 * 
	 * @param jobId
	 * @return
	 */
	public JobQueueEntity getTopLevelJob(long jobId) {
		return entityManager.find(JobQueueEntity.class, jobId);
	}

	@SuppressWarnings("unchecked")
	public JobQueueEntity getTopJobByRequestId(String requestId) {
		Query q = entityManager.createNamedQuery("NQ::getJobInfoByReqId");
		q.setParameter("reqId", requestId);
		List<JobQueueEntity> list = q.getResultList();
		if (list == null || list.isEmpty()) {
			return null;
		} else {
			return list.get(0);
		}
	}

	public int deleteJobByRequstId(String requstId) {
		Query q = entityManager.createNamedQuery("NQ::delBioUsingEnrollId");
		q.setParameter("requestId", requstId);
		return q.executeUpdate();
	}

	/**
	 * findFusionJob
	 * 
	 * @param jobId
	 * @param searchIndex
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<FusionJobEntity> getFusionJob(Long fusionJobId, int functionId) {
		Query q = entityManager.createNamedQuery("NQ::getFusionJob");
		q.setParameter("fusionJobId", fusionJobId);
		q.setParameter("functionId", functionId);
		return q.getResultList();
	}

	/**
	 * 
	 * @param fusionJob
	 * @param containerId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ContainerJobEntity> getContainerJob(Long fusionJob, int containerId) {
		Query q = entityManager.createNamedQuery("NQ::getContainerJob");
		q.setParameter("fusionJob", fusionJob);
		q.setParameter("containerId", containerId);
		return q.getResultList();
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ContainerJobEntity> getWorkingContainerJobs() {
		Query q = entityManager.createNamedQuery("NQ::getWorkingContainerJobs");
		return (List<ContainerJobEntity>) q.getResultList();
	}

	/**
	 * getContainerJobId
	 * 
	 * @param planId
	 *            plan id
	 * @return container job id
	 */
	public Long getContainerJobId(long planId) {
		Query query = entityManager.createNamedQuery("NQ::getContainerJobId");
		query.setParameter("planId", planId);

		@SuppressWarnings("unchecked")
		List<BigDecimal> list = query.getResultList();
		if (CollectionsUtil.isEmpty(list)) {
			return null;
		}
		return CollectionsUtil.getFirst(list).longValue();
	}

	public JobQueueEntity getJobQueue(long containerjobid) {
		Query query = entityManager.createNamedQuery("NQ::getJobQueueByContainerJobId");
		query.setParameter("containerJobId", containerjobid);
		@SuppressWarnings("unchecked")
		List<JobQueueEntity> list = query.getResultList();
		if (CollectionsUtil.isEmpty(list)) {
			return null;
		}
		JobQueueEntity jobQueue = (JobQueueEntity) CollectionsUtil.getFirst(list);
		return jobQueue;
	}

	public ContainerJobEntity getContainerJob(long containerJobId) {
		ContainerJobEntity containerjob = entityManager.find(ContainerJobEntity.class, containerJobId);
		if (containerjob == null) {
			return null;
		}
		return containerjob;
	}

	public ContainerJobFailureReasonEntity getContainerJobFailureReason(long failureId) {
		ContainerJobFailureReasonEntity containerjobfailurereason = entityManager
				.find(ContainerJobFailureReasonEntity.class, failureId);
		if (containerjobfailurereason == null) {
			return null;
		}
		return containerjobfailurereason;
	}

	public InquiryTrafficEntity getInquiryTraffic(long jobId) {
		Query query = entityManager.createNamedQuery("NQ::getInquiryTraffic");
		query.setParameter("jobId", jobId);
		@SuppressWarnings("unchecked")
		List<InquiryTrafficEntity> list = query.getResultList();
		if (list == null || list.isEmpty()) {
			return null;
		}
		InquiryTrafficEntity inquirytraffic = (InquiryTrafficEntity) list.get(0);
		return inquirytraffic;
	}

	public List<ContainerJobEntity> getAllContainerJob(long jobId) {
		Query query = entityManager.createNamedQuery("NQ::GetAllContainerJob");
		query.setParameter("jobId", jobId);
		@SuppressWarnings("unchecked")
		List<ContainerJobEntity> list = query.getResultList();
		return list;
	}

	public void clearAllContainerJob(long jobId) {
		Query query = entityManager.createNamedQuery("NQ::clearAllContainerJobs");
		query.setParameter("jobId", jobId);
		query.executeUpdate();
	}

	/**
	 * lock the container job with id
	 * 
	 * @param containerJobId
	 *            the container Job Id
	 */
	public long lockContainerJob(long containerJobId) {
		Query query = entityManager.createNamedQuery("NQ:lockContainerJob");
		query.setParameter("cJobId", containerJobId);
		BigInteger result = (BigInteger) query.getSingleResult();
		return result.longValue();
	}

	/**
	 * updateContainerJob
	 * 
	 * @param plan
	 * @param planId
	 * @param mrEntity
	 * @param fusionJob
	 */
	public void updateContainerJob(long mrId, long containerJobId) {
		ContainerJobEntity containerJob = getContainerJob(containerJobId);
		if (containerJob == null) {
			throw new AimRuntimeException(
					"Can not found ContainerJob with specified container job id: " + containerJobId + " when update..");
		}
		containerJob.setAssignedTs(dateDao.getCurrentTimeMS());
		containerJob.setMrId(mrId);
		// containerJobs.setPlanId(planId);
		// containerJobs.setJobState(JobState.WORKING);
		entityManager.persist(containerJob);
		entityManager.flush();
		log.info("Success update containerJob:{}", containerJobId);
	}

	/**
	 * 
	 * @param functionName
	 * @return
	 */
	public List<ContainerJobEntity> listTimedOutJobs(String functionName) {
		Query query = entityManager.createNamedQuery("NQ::listTimedOutJobs");
		query.setParameter("functionName", functionName);
		query.setParameter("rownum", Constants.MAX_TIMED_OUT_JOB_BATCH);
		@SuppressWarnings("unchecked")
		List<ContainerJobEntity> list = query.getResultList();
		return list;
	}

	/**
	 * 
	 * @param deadMRs
	 * @return
	 */
	public List<ContainerJobEntity> listDeadContainerJobs(List<MapReducerEntity> deadMRs) {
		if (CollectionsUtil.isEmpty(deadMRs)) {
			return new ArrayList<ContainerJobEntity>();
		}
		List<Long> mrIds = new ArrayList<Long>();
		for (MapReducerEntity mr : deadMRs) {
			mrIds.add(mr.getMrId());
		}

		Query query = entityManager.createNamedQuery("NQ::listDeadContainerJobs");
		query.setParameter("mrIds", mrIds);
		@SuppressWarnings("unchecked")
		List<ContainerJobEntity> list = query.getResultList();
		return list;
	}

	// find out the list of ContainerJobs with the MR id
	@SuppressWarnings("unchecked")
	public List<ContainerJobEntity> listDeadJobs(long mrId) {
		Query q = entityManager.createNamedQuery("NQ::deadContainerJobs");
		q.setParameter("mrId", mrId);
		return q.getResultList();
	}

	/**
	 * Create Fusion and Container Job
	 * 
	 * @param jobId
	 *            top level job id
	 * @param index
	 *            search request index
	 * @param fte
	 *            FunctionTypeEntity instance
	 * @param containerIds
	 *            list of container id
	 * @param inquiryRequest
	 *            inquiryRequest instance
	 * @param remainJob
	 *            AtomicInteger instance
	 * @param emptyFusionJobs
	 *            empty FusionJobs list
	 * @return fusion Job Id
	 */
	public Long callCreateContainerJob(long jobId, int index, FunctionTypeEntity fte, Integer containerId,
			AimInquiryRequest inquiryRequest, Set<Long> emptyFusionJobs, AtomicInteger remainJob,
			ExceptionHelper exception) {
		if (log.isDebugEnabled()) {
			log.debug("calling create_conatiner_job(" + fte.getFunctionName() + ", jobId " + jobId + ") -> "
					+ containerId.toString());
		}
		try {
			CreateContainerJobProcedure procedure = new CreateContainerJobProcedure(dataSource);
			procedure.setJobId(jobId);
			procedure.setSearchRequestIndex(index);
			procedure.setFunctionId((int) fte.getId());
			procedure.setInquiryRequestXml(inquiryRequest.getRequest());
			procedure.setInquiryProbeData(inquiryRequest.getProbeData());
			procedure.setContainerId(inquiryRequest.getContainerId());
			procedure.execute();
			Long fusionJobId = procedure.getFusionJobId();

			// set emptyJob
			// emptyJob = 1 -> There is no record in SEGMENTS for Container_jobs
			long emptyJob = procedure.getEmptyJob();
			if (emptyJob == 1) {
				// this fusionJob has no segment to work
				emptyFusionJobs.add(fusionJobId);
			}
			// increase the remain job
			remainJob.getAndAdd(procedure.getRemainJob());
			if (log.isDebugEnabled()) {
				log.debug("created fusion job: " + fusionJobId);
			}
			return fusionJobId.longValue();
		} catch (DataAccessException e) {
			exception.throwDBException(AimError.INQ_DB, e,
					"DataAccessException occurred when callCreateContainerJob procedure..");
		} catch (Exception e) {
			throw new AimRuntimeException("Exception occurred when callCreateContainerJob procedure..", e);
		}
		return null;
	}

	/**
	 * countUnfinishedForJob
	 * 
	 * @param jobId
	 *            top level job id
	 * @return unfinished inquiry job count
	 */
	public long countUnfinishedForJob(long jobId) {
		Query q = entityManager.createNamedQuery("NQ::countUnfinishedForJob");
		q.setParameter("jobId", jobId);
		BigInteger result = (BigInteger) q.getSingleResult();
		return result.longValue();
	}

	/**
	 * 
	 * @param jobId
	 * @return
	 */
	public Integer findMinFunctionId(long jobId) {
		Query q = entityManager.createNamedQuery("NQ::findMinFunctionId");
		q.setParameter("jobId", jobId);
		BigInteger result = (BigInteger) q.getSingleResult();
		if (result == null) {
			return null;
		} else {
			return new Integer(result.intValue());
		}
	}
}
