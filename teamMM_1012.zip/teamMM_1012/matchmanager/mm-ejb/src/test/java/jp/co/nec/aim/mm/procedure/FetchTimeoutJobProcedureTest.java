package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.mm.dao.DateDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FetchTimeoutJobProcedureTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private DateDao dateDao;
	

	@Before
	public void setUp() throws Exception {
		dateDao = new DateDao(dataSource);
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("commit");
		
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testExecute_timeOut_1() throws SQLException {
		long time = dateDao.getCurrentTimeMS();
		String sql = "INSERT INTO JOB_QUEUE(JOB_ID, UIDAI_REQUEST_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,assigned_ts,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) "
				+ "VALUES(20,'test',5,1,123,?,0,1000,0,0,1)";
		jdbcTemplate.update(sql, new Object[] {time - 1500});
		FetchTimeoutJobProcedure procedure = new FetchTimeoutJobProcedure(
				dataSource);
		List<Long> list = procedure.execute();

		assertEquals(1, list.size());

		assertEquals(20, list.get(0).intValue());
	}
	@Test
	public void testExecute_timeOut_0() throws SQLException {
		long time = dateDao.getCurrentTimeMS();
		String sql = "INSERT INTO JOB_QUEUE(JOB_ID,  UIDAI_REQUEST_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,assigned_ts,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) "
				+ "VALUES(20,'test', 5,0,123,?,0,1000,0,0,1)";
		jdbcTemplate.update(sql, new Object[] {time - 1500});
		FetchTimeoutJobProcedure procedure = new FetchTimeoutJobProcedure(
				dataSource);
		List<Long> list = procedure.execute();
		assertEquals(0, list.size());
		
	}

}
