package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

public interface DmConfigRepository {

	/**
	 * @return
	 * @throws SQLException
	 */
	public int getRedundancy() throws SQLException;

	/**
	 * @return
	 * @throws SQLException
	 */
	public String getSyncMode() throws SQLException;

}
