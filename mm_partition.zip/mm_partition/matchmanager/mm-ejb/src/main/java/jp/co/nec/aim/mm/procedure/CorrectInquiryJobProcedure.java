package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Spring StoredProcedure class to call complete_inquiryjob()
 * 
 * @author jinxl
 * 
 */
public class CorrectInquiryJobProcedure extends StoredProcedure {
	private static final String SQL = "complete_inquiryjob";

	public CorrectInquiryJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);		
		setSql(SQL);	
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_container_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_sequence", Types.INTEGER));
		declareParameter(new SqlParameter("p_result", Types.VARCHAR));
		declareParameter(new SqlParameter("p_dignostics", Types.BLOB));
		declareParameter(new SqlOutParameter("l_remain_jobs", Types.BIGINT));
		compile();
	}

	/**
	 * Returns JOB_QUEUE.REMAIN_JOBS if succeeded update MU_JOBS to DONE
	 * 
	 * @param jobId
	 *            JOB_ID
	 * @param messageSequence
	 * @param containerJobId
	 * @param result
	 * @return JOB_QUEUE.REMAIN_JOBS if succeeded. -1 If it failed
	 */
	public long action(long jobId, int messageSequence, long containerJobId, String xmlResult, byte[] dignosticst) {			
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", jobId);
		map.put("p_container_job_id", containerJobId);
		map.put("p_sequence", messageSequence);
		map.put("p_result", xmlResult);
		map.put("p_dignostics", new SqlLobValue(dignosticst));
		Map<String, Object> resultMap = execute(map);
		Long remainJobs = (Long) resultMap.get("l_remain_jobs");
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "action",
				stopWatch.elapsedTime());
		return remainJobs.longValue();
	}

}
