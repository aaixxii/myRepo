package jp.co.nec.aim.mm.sessionbeans;

import java.sql.Date;
import java.time.LocalDate;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class CreateNextDayPartitionBean  {
		
	private static final Logger logger = LoggerFactory.getLogger(CreateNextDayPartitionBean.class);
	
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	
	@PersistenceContext(unitName = "AIMDB")
    private EntityManager manager;
	
	private PartitionDao partitionDao;
	 private SystemInitDao systemInitDao;
	
	public CreateNextDayPartitionBean() {
	    partitionDao = new PartitionDao(dataSource);
	    systemInitDao = new SystemInitDao(manager);
	}
	
	public void execute()  {
	    Long saveDays = systemInitDao.getSegChangeLogSaveDays();        
		LocalDate now = LocalDate.now();
		LocalDate nextDay = now.plusDays(1);
		long hashValue = PartitionUtil.getInstance().caculateHashAtThisToday(nextDay);		
		partitionDao.insertPno(hashValue, Date.valueOf(nextDay));
		if (hashValue <= saveDays) {
		    partitionDao.createPartition(hashValue);
		} else {
		    
		}
		
		logger.info("Success create partition(p_no={}) for day({}) ", hashValue, LocalDate.now());
	}

}
