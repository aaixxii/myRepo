package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;

/**
 * AddBiometricsProcedure
 * 
 * @author liuyq
 * 
 */
public class AddBiometricsProcedure extends StoredProcedure {
	/** the name of add_biometrics Procedure **/
	private static final String SQL = "add_biometrics";
	//private static final int UPDATE_EXIST_SEG = 0; // update exist segment
	private String externalId; // externalId	
	private Integer containerId; // containerId
	private byte[] biometricsData; // template data
	private long pNo;

	/**
	 * AddBiometricsProcedure constructor
	 * 
	 * @param dataSource
	 *            the instance of DataSource
	 */
	public AddBiometricsProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_external_id", Types.VARCHAR));		
		declareParameter(new SqlParameter("p_container_id", Types.INTEGER));
		declareParameter(new SqlParameter("p_biometric_data", Types.BLOB));
		declareParameter(new SqlParameter("p_no", Types.BIGINT));
		declareParameter(new SqlOutParameter("p_biometric_id", Types.BIGINT));
		declareParameter(new SqlOutParameter("p_seg_id", Types.BIGINT));
		declareParameter(new SqlOutParameter("p_seg_version", Types.BIGINT));	
		declareParameter(new SqlOutParameter("p_new_seg_created", Types.BOOLEAN));
		compile();
	}

	/**
	 * execute the Procedure add_biometrics
	 * 
	 * @return is new segment generated
	 */
	public SegSyncInfos execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_external_id", getExternalId());		
		map.put("p_container_id", getContainerId());
		map.put("p_biometric_data", new SqlLobValue(getBiometricsData()));
		map.put("p_no", getpNo());
		Map<String, Object> resultMap = execute(map);
		Long biometricId = (Long) resultMap.get("p_biometric_id");
		Long segmentId = (Long) resultMap.get("p_seg_id");
		Long segVersion = (Long) resultMap.get("p_seg_version");
		Boolean segCreated = (Boolean) resultMap.get("p_new_seg_created");	
		SegSyncInfos segSyncInfo = new SegSyncInfos();
		segSyncInfo.setSegmentId(segmentId);
		segSyncInfo.setSegVersion(segVersion);
		segSyncInfo.setExternalId(externalId);
		segSyncInfo.setTemplateId(biometricId);
		segSyncInfo.setIsUpdateSegment(!segCreated);
		if (segCreated) {
			segSyncInfo.setCommand(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);			
		} else {
			segSyncInfo.setCommand(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
		}
		
		return segSyncInfo;
	
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public byte[] getBiometricsData() {
		return biometricsData;
	}

	public void setBiometricsData(byte[] biometricsData) {
		this.biometricsData = biometricsData;
	}

	public long getpNo() {
		return pNo;
	}

	public void setpNo(long pNo) {
		this.pNo = pNo;
	}
	
}
