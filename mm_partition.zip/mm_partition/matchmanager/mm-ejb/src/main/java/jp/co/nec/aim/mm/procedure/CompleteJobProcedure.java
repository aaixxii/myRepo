package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.util.StopWatch;

public class CompleteJobProcedure extends StoredProcedure {

	private static final String SQL = "complete_top_level_job";

	public CompleteJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		//setFunction(true);
		setSql(SQL);		
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_failed", Types.INTEGER));
		declareParameter(new SqlParameter("p_result", Types.BLOB));
		declareParameter(new SqlOutParameter("l_job_exec_count", Types.BIGINT));
		compile();
	}

	/**
	 * action
	 * 
	 * @param jobId
	 * @param result
	 * @param failed
	 */
	public void action(long jobId, String xmlRes, byte[] dignostics, boolean failed) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		long failResult = failed == true ? 1 : 0;

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", jobId);
		map.put("p_result", new SqlLobValue(dignostics));
		map.put("p_failed", failResult);
		execute(map);
		stopWatch.stop();

		return;
	}
}
