package jp.co.nec.aim.mm.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMMessages.PBAbilityInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
import jp.co.nec.aim.mm.entities.DmServiceEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.entities.MrContactEntity;
import jp.co.nec.aim.mm.entities.MuContactEntity;
import jp.co.nec.aim.mm.entities.MuEligibleFunctionEntity;
import jp.co.nec.aim.mm.entities.MuExtractLoadEntity;
import jp.co.nec.aim.mm.entities.MuInquiryLoadEntity;
import jp.co.nec.aim.mm.entities.QueueType;
import jp.co.nec.aim.mm.entities.SystemManagerEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.slb.loadbalance.UnitNote;

public class UnitDao {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(UnitDao.class);
	private EntityManager em;

	public UnitDao(EntityManager em) {
		this.em = em;
	}

	/**
	 * findSM
	 * 
	 * @param id
	 * @return SystemManagerEntity instance
	 */
	public SystemManagerEntity findSM(Long id) {
		return em.find(SystemManagerEntity.class, id);
	}

	/**
	 * findDM
	 * 
	 * @param id
	 * @return DataManagerEntity instance
	 */
	public DmServiceEntity findDM(Long id) {
		return em.find(DmServiceEntity.class, id);
	}

	/**
	 * findMU
	 * 
	 * @param id
	 * @return MatchUnitEntity instance
	 */
	public MatchUnitEntity findMU(Long id) {
		return em.find(MatchUnitEntity.class, id);
	}

	/**
	 * findMR
	 * 
	 * @param id
	 * @return MapReducerEntity instance
	 */
	public MapReducerEntity findMR(Long id) {
		return em.find(MapReducerEntity.class, id);
	}

	/**
	 * get number of working MR
	 * 
	 * @return the number of working MR
	 */
	public int getWorkingMRCount() {
		Query query = em.createNamedQuery("NQ::getWorkingMRCount");
		Integer result = (Integer) query.getSingleResult();
		return result.intValue();
	}

	/**
	 * List all Working MatchUnitEntity which is eligible for containerId
	 * 
	 * @param containerId
	 * 
	 * @return List of MatchUnitEntity order by id.
	 */
	@SuppressWarnings("unchecked")
	public List<UnitNote> listEligibleMUs(long containerId) {
		Query query = em.createNamedQuery("NQ::listEligibleMUs");
		query.setParameter("containerId", new Long(containerId));
		List<MatchUnitEntity> muList = query.getResultList();

		List<UnitNote> unitList = new ArrayList<UnitNote>();
		for (MatchUnitEntity mu : muList) {
			UnitNote note = new UnitNote();
			note.setUnitID((long) mu.getMuId());
			note.setType(0);
			note.setCpuNum(mu.getNumberOfMatchers());
			note.setFactor(mu.getReportedPerformanceFactor());

			unitList.add(note);
		}

		return unitList;
	}

	/**
	 * 
	 * @param mrId
	 * @param caller
	 * @return
	 */
	public MapReducerEntity findAndWarnState(long mrId, String caller) {
		MapReducerEntity mr = em.find(MapReducerEntity.class, mrId);
		if (mr == null) {
			log.warn("findAndWarnState: (" + caller + ") Map Reducer id: "
					+ mrId + " not found in database.");
		}
		return mr;
	}

	/**
	 * 
	 * @param uniqueId
	 * @return
	 */
	public MatchUnitEntity searchMu(String uniqueId) {
		Query query = em.createNamedQuery("NQ::lookupMU");
		query.setParameter("uniqueId", uniqueId);
		@SuppressWarnings("unchecked")
		List<MatchUnitEntity> results = query.getResultList();
		if (CollectionsUtil.isEmpty(results)) {
			return null;
		}
		return CollectionsUtil.getFirst(results);
	}

	/**
	 * 
	 * @param
	 * @return boolean
	 */
	public boolean isExistWorkingMu() {
		Query query = em.createNamedQuery("NQ::listWorkingMUs");
		@SuppressWarnings("unchecked")
		List<MatchUnitEntity> results = query.getResultList();
		if (CollectionsUtil.isEmpty(results)) {
			return false;
		}
		return true;
	}

	/**
	 * update Match unit and contacts
	 * 
	 * @param mu
	 *            MatchUnitEntity instance
	 * @param component
	 *            PBComponentInfo instance
	 */
	public void updateMu(final MatchUnitEntity mu,
			final PBComponentInfo component) {
		em.refresh(mu);
		mu.setContactUrl(component.getContactUrl());
		mu.setState(UnitState.WORKING);
		mu.setVersion(component.getVersion());
		// update abilityInfo
		setOptionalParams(mu, component);
		em.merge(mu);
		em.flush();

		Query query = em.createNamedQuery("NQ:updateMuContacts");
		query.setParameter("muId", mu.getMuId());
		query.executeUpdate();
		em.refresh(mu);

		MuInquiryLoadEntity inquiryLoad = mu.getInquiryLoad();
		if (inquiryLoad == null) {
			// INIT MuInquiryLoad to 0
			initMuInquiryLoad(mu);
		} else {
			inquiryLoad.setPressure(0L);
		}

		MuExtractLoadEntity extractLoad = mu.getExtractLoad();
		if (extractLoad == null) {
			// INIT MuMuExtractLoad to 0
			initMuExtractLoad(mu);
		} else {
			extractLoad.setPressure(0L);
		}
		em.merge(mu);
	}

	/**
	 * addMu
	 * 
	 * @param component
	 *            PBComponentInfo instance
	 * @return MatchUnitEntity instance
	 */
	public MatchUnitEntity addMu(final PBComponentInfo component) {
		log.debug("Couldn't find unique id '" + component.getUniqueId()
				+ "', will create a new match unit");

		MatchUnitEntity mu = new MatchUnitEntity();
		mu.setUniqueId(component.getUniqueId());
		mu.setContactUrl(component.getContactUrl());
		mu.setState(UnitState.WORKING);

		setOptionalParams(mu, component);
		mu.setVersion(component.getVersion());
		em.persist(mu);
		em.flush();

		// insert MU Contacts
		Query query = em.createNamedQuery("NQ:createMuContacts");
		query.setParameter("muId", mu.getMuId());
		query.executeUpdate();
		MuContactEntity times = em.find(MuContactEntity.class, mu.getMuId());
		mu.setTimes(times);

		// INIT MuInquiryLoad to 0
		initMuInquiryLoad(mu);

		// INIT MuExtractLoad to 0
		initMuExtractLoad(mu);

		em.refresh(mu);
		return mu;
	}

	/**
	 * initMuExtractLoad
	 * 
	 * @param mu
	 */
	private void initMuExtractLoad(MatchUnitEntity mu) {
		Query eLoadQuery = em.createNamedQuery("NQ:createMuExtractLoad");
		eLoadQuery.setParameter("muId", mu.getMuId());
		eLoadQuery.executeUpdate();
		MuExtractLoadEntity extractLoad = em.find(MuExtractLoadEntity.class,
				mu.getMuId());
		mu.setExtractLoad(extractLoad);
	}

	/**
	 * initMuInquiryLoad
	 * 
	 * @param mu
	 */
	private void initMuInquiryLoad(MatchUnitEntity mu) {
		// insert MU inquiry and extract load
		Query iLoadQuery = em.createNamedQuery("NQ:createMuInquiryLoad");
		iLoadQuery.setParameter("muId", mu.getMuId());
		iLoadQuery.executeUpdate();
		MuInquiryLoadEntity inquiryLoad = em.find(MuInquiryLoadEntity.class,
				mu.getMuId());
		mu.setInquiryLoad(inquiryLoad);
	}

	/**
	 * update MU state to Exit
	 * 
	 * @param mu
	 *            match unit instance
	 */
	public void updateMuExit(MatchUnitEntity mu) {
		mu.setState(UnitState.EXITED);
		em.merge(mu);
		em.flush();
	}

	/**
	 * setOptionalParams
	 * 
	 * @param mu
	 *            MatchUnitEntity instance
	 * @param component
	 *            PBComponentInfo instance
	 */
	private void setOptionalParams(MatchUnitEntity mu, PBComponentInfo component) {
		if (!component.hasResourceInfo()) {
			log.warn("PBComponentInfo has no ResourceInfo..");
			return;
		}

		PBResourceInfo resource = component.getResourceInfo();
		if (!resource.hasAbilityInfo()) {
			log.warn("PBComponentInfo has no PBAbilityInfo..");
			return;
		}

		PBAbilityInfo ability = resource.getAbilityInfo();
		mu.setPrimarySize(ability.getPrimarySize());
		mu.setSecondarySize(ability.getSecondarySize());
		mu.setReportedPerformanceFactor(Double.valueOf(ability
				.getPerformanceFactor()));
		mu.setNumberOfMatchers(ability.getNumOfMatchers());	
		mu.setNumberOfExtractors(ability.getNumOfExtractors());	
	}

	/**
	 * addMuEligibleContainers
	 * 
	 * @param mu
	 */
	public void addMuEligibleContainers(long muId) {
		log.debug("Marking ALL containers as eligible for match unit " + muId);
		addAllMuContainers(muId);
	}

	/**
	 * addAllMuContainers
	 * 
	 * @param muId
	 */
	private void addAllMuContainers(long muId) {
		Query q = em.createNamedQuery("NQ::addMuEligibleContainers");
		q.setParameter("muId", muId);
		q.executeUpdate();
	}

	/**
	 * addDmEligibleContainers
	 * 
	 * @param mu
	 */
	public void addDmEligibleContainers(long dmId) {
		log.debug("Marking ALL containers as eligible for Data Manager: "
				+ dmId);
		addAllDmContainers(dmId);
	}

	/**
	 * addAllDmContainers
	 * 
	 * @param muId
	 */
	private void addAllDmContainers(long dmId) {
		Query q = em.createNamedQuery("NQ::addDmEligibleContainers");
		q.setParameter("dmId", dmId);
		q.executeUpdate();
	}

	public void addMuEligibleFunctions(long muId) {
		addAllSearchFunctions(muId);
		addExtractionFunction(muId);
	}

	/**
	 * addExtractionFunction
	 * 
	 * @param muId
	 *            match unit id
	 */
	private void addExtractionFunction(long muId) {
		Query q = em.createNamedQuery("NQ::getFunctionByType");
		q.setParameter("type", QueueType.EXTRACT);
		@SuppressWarnings("unchecked")
		List<FunctionTypeEntity> results = q.getResultList();
		if (results.isEmpty()) {
			// extraction unit entering system but extraction not configured on
			// this box. reject enter() from FEU.
			throw new AimRuntimeException(
					"The extraction function has not been configured on this system.");
		} else {
			FunctionTypeEntity extractFunc = results.get(0);
			MuEligibleFunctionEntity mfe = new MuEligibleFunctionEntity();
			mfe.setMuId(muId);
			mfe.setFunctionId(extractFunc.getId());
			em.persist(mfe);
		}

	}

	/**
	 * addAllSearchFunctions
	 * 
	 * @param muId
	 *            match unit id
	 */
	private void addAllSearchFunctions(long muId) {
		Query q = em.createNamedQuery("NQ::getFunctionByType");
		q.setParameter("type", QueueType.INQUIRY);
		@SuppressWarnings("unchecked")
		List<FunctionTypeEntity> allSearchFunctions = q.getResultList();
		for (FunctionTypeEntity fe : allSearchFunctions) {
			MuEligibleFunctionEntity msfe = new MuEligibleFunctionEntity();
			msfe.setMuId(muId);
			msfe.setFunctionId(fe.getId());
			em.persist(msfe);
		}
	}

	/**
	 * searchMr
	 * 
	 * @param uniqueId
	 * @return MapReducerEntity instance
	 */
	public MapReducerEntity searchMr(String uniqueId) {
		Query query = em.createNamedQuery("NQ::lookupMR");
		query.setParameter("uniqueId", uniqueId);
		@SuppressWarnings("unchecked")
		List<MapReducerEntity> results = query.getResultList();
		if (CollectionsUtil.isEmpty(results)) {
			return null;
		}
		return CollectionsUtil.getFirst(results);
	}

	/**
	 * update MR and contacts
	 * 
	 * @param mr
	 *            MapReducerEntity instance
	 * @param component
	 *            PBComponentInfo instance
	 */
	public void updateMr(final MapReducerEntity mr,
			final PBComponentInfo component) {
		em.refresh(mr);
		mr.setRingLocation(mr.getMrId());
		mr.setContactUrl(component.getContactUrl());
		mr.setState(UnitState.WORKING);
		mr.setVersion(component.getVersion());
		em.merge(mr);
		em.flush();

		Query query = em.createNamedQuery("NQ:updateMrContacts");
		query.setParameter("mrId", mr.getMrId());
		query.executeUpdate();
		em.refresh(mr);
	}

	/**
	 * add Map reducer record
	 * 
	 * @param component
	 *            PBComponentInfo instance
	 * @return MatchUnitEntity instance
	 */
	public MapReducerEntity addMr(final PBComponentInfo component) {
		log.debug("Couldn't find unique id '" + component.getUniqueId()
				+ "', will create a new Map Reducer");

		MapReducerEntity mr = new MapReducerEntity();
		// mr.setRingLocation(ringLocation);
		mr.setUniqueId(component.getUniqueId());
		mr.setContactUrl(component.getContactUrl());
		mr.setState(UnitState.WORKING);
		mr.setVersion(component.getVersion());
		em.persist(mr);
		em.flush();

		// update RingLocation
		mr.setRingLocation(mr.getMrId());
		em.persist(mr);
		em.flush();

		// insert MU Contacts
		Query query = em.createNamedQuery("NQ:createMrContacts");
		query.setParameter("mrId", mr.getMrId());
		query.executeUpdate();
		MrContactEntity times = em.find(MrContactEntity.class, mr.getMrId());
		mr.setTimes(times);
		return mr;
	}

	/**
	 * update MR state to Exit
	 * 
	 * @param mr
	 *            map reducer instance
	 */
	public void updateMuExit(MapReducerEntity mr) {
		mr.setState(UnitState.EXITED);
		em.merge(mr);
		em.flush();
	}

	/**
	 * searchDm
	 * 
	 * @param uniqueId
	 * @return DataManagerEntity instance
	 */
	public DmServiceEntity searchDm(String uniqueId) {
		Query query = em.createNamedQuery("NQ::lookupDM");
		query.setParameter("uniqueId", uniqueId);
		@SuppressWarnings("unchecked")
		List<DmServiceEntity> results = query.getResultList();
		if (CollectionsUtil.isEmpty(results)) {
			return null;
		}
		return CollectionsUtil.getFirst(results);
	}

	/**
	 * update DM and contacts
	 * 
	 * @param dm
	 *            DataManagerEntity instance
	 * @param component
	 *            PBComponentInfo instance
	 */
	public void updateDm(final DmServiceEntity dm,
			final PBComponentInfo component) {
		em.refresh(dm);
		dm.setContactUrl(component.getContactUrl());
		dm.setState(UnitState.WORKING);
		dm.setVersion(component.getVersion());
		em.merge(dm);
		em.flush();

		Query query = em.createNamedQuery("NQ:updateDmContacts");
		query.setParameter("dmId", dm.getDmId());
		query.executeUpdate();
		em.refresh(dm);
	}

	/**
	 * addDm
	 * 
	 * @param component
	 *            PBComponentInfo instance
	 * @return DataManagerEntity instance
	 */
	public DmServiceEntity addDm(final PBComponentInfo component) {
		log.debug("Couldn't find unique id '" + component.getUniqueId()
				+ "', will create a new Data Manager");

		DmServiceEntity dm = new DmServiceEntity();
		dm.setUniqueId(component.getUniqueId());
		dm.setContactUrl(component.getContactUrl());
		dm.setState(UnitState.WORKING);
		dm.setVersion(component.getVersion());
		em.persist(dm);
		em.flush();

		// insert DM Contacts
		Query query = em.createNamedQuery("NQ:createDmContacts");
		query.setParameter("dmId", dm.getDmId());
		query.executeUpdate();
		return dm;
	}

	/**
	 * update DM state to Exit
	 * 
	 * @param dm
	 *            data manager instance
	 */
	public void updateDmExit(DmServiceEntity dm) {
		dm.setState(UnitState.EXITED);
		em.merge(dm);
		em.flush();
	}

	/**
	 * searchSm
	 * 
	 * @param uniqueId
	 *            uniqueId
	 * @return SystemManagerEntity instance
	 */
	public SystemManagerEntity searchSm(String uniqueId) {
		Query query = em.createNamedQuery("NQ::lookupSM");
		query.setParameter("uniqueId", uniqueId);
		@SuppressWarnings("unchecked")
		List<SystemManagerEntity> results = query.getResultList();
		assert (results.size() <= 1);
		if (results.size() == 0) {
			return null;
		} else {
			// one result.
			return results.get(0);
		}
	}

	/**
	 * update SM and contacts
	 * 
	 * @param sm
	 *            SystemManagerEntity instance
	 * @param component
	 *            PBComponentInfo instance
	 */
	public void updateSm(final SystemManagerEntity sm,
			final PBComponentInfo component) {
		em.refresh(sm);
		sm.setContactUrl(component.getContactUrl());
		sm.setState(UnitState.WORKING);
		sm.setVersion(component.getVersion());
		em.merge(sm);
		em.flush();

		// Query query = em.createNamedQuery("NQ:updateDmContacts");
		// query.setParameter("dmId", dm.getDmId());
		// query.executeUpdate();
		em.refresh(sm);
	}

	/**
	 * addSm
	 * 
	 * @param component
	 *            PBComponentInfo instance
	 * @return DataManagerEntity instance
	 */
	public SystemManagerEntity addSm(final PBComponentInfo component) {
		log.debug("Couldn't find unique id '" + component.getUniqueId()
				+ "', will create a new Data Manager");

		SystemManagerEntity sm = new SystemManagerEntity();
		sm.setUniqueId(component.getUniqueId());
		sm.setContactUrl(component.getContactUrl());
		sm.setState(UnitState.WORKING);
		sm.setVersion(component.getVersion());
		em.persist(sm);
		em.flush();

		// insert SM Contacts
		// Query query = em.createNamedQuery("NQ:createDmContacts");
		// query.setParameter("dmId", dm.getDmId());
		// query.executeUpdate();
		// DmContactEntity times = em.find(DmContactEntity.class, dm.getDmId());
		// dm.setTimes(times);
		return sm;
	}

	/**
	 * update SM state to Exit
	 * 
	 * @param sm
	 *            system manager instance
	 */
	public void updateSmExit(SystemManagerEntity sm) {
		sm.setState(UnitState.EXITED);
		em.merge(sm);
		em.flush();
	}

	/**
	 * 
	 * @param currentTime
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<MapReducerEntity> listTimedOutMRs() {
		Query query = em.createNamedQuery("NQ::listTimedOutMRs");
		return query.getResultList();
	}

	/**
	 * 
	 * @param currentTime
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<MatchUnitEntity> listTimedOutMUs() {
		Query query = em.createNamedQuery("NQ::listTimedOutMUs");
		return query.getResultList();
	}

	/**
	 * 
	 * @param currentTime
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<DmServiceEntity> listTimedOutDMs() {
		Query query = em.createNamedQuery("NQ::listTimedOutDMs");
		return query.getResultList();
	}



	/**
	 * List all Working MatchUnitEntity which is eligible for containerId
	 * 
	 * @param containerId
	 * 
	 * @return List of MatchUnitEntity order by id.
	 */
	@SuppressWarnings("unchecked")
	public List<Long> listEligibleMUIDs(long containerId) {
		Query query = em.createNamedQuery("NQ::listEligibleMUs");
		query.setParameter("containerId", new Long(containerId));
		List<MatchUnitEntity> muList = query.getResultList();

		List<Long> muIdList = Lists.newArrayList();
		for (MatchUnitEntity mu : muList) {
			muIdList.add(mu.getMuId());
		}

		return muIdList;
	}
}
