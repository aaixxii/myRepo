package jp.co.nec.aim.mm.common;

import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * Mock a UDP listening server for receive a message from client
 * 
 * @author liuyq
 * 
 */
public class SocketReceiveUtil extends Thread {

	private int PORT = 1234;
	public int TIMEOUT = 10000;
	private DatagramSocket socket;

	private DatagramPacket receivePkg;

	public int getPORT() {
		return PORT;
	}

	/**
	 * public constructor
	 */
	public SocketReceiveUtil(int port) {
		super();
		this.setName("UDP-Server-Listening-Thread");
		this.setDaemon(true);
		PORT = port;
		this.start();
	}

	@Override
	public void run() {
		try {
			socket = new DatagramSocket(PORT);
			socket.setSoTimeout(TIMEOUT);

			byte[] bytes = new byte[1024];
			receivePkg = new DatagramPacket(bytes, bytes.length);
			socket.receive(receivePkg);
		} catch (Exception ex) {
			String exceptionStr = ex.getMessage();
			receivePkg.setData(exceptionStr.getBytes());
		} finally {
			closeSocket();
		}
	}

	public String getDatagramPacketMsg() {
		try {
			return new String(receivePkg.getData(), "UTF-8").substring(0,
					receivePkg.getLength());
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	public int getDatagramPacketLen() {
		return receivePkg.getLength();
	}

	public void closeSocket() {
		if (socket != null && !socket.isClosed()) {
			socket.close();
		}
	}

}
