package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.mm.common.TestLogger;
import jp.co.nec.aim.mm.entities.ContainerEntity;
import jp.co.nec.aim.mm.entities.UnitSegMap;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class LoadBalancerDaoTest {
	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private LoadBalancerDao dao;

	@BeforeClass
	public static void BeforeClass() {
		new MockUp<LoggerFactory>() {
			@Mock
			public Logger getLogger(String name) {
				return new TestLogger();
			}
		};
	}

	@AfterClass
	public static void tearAfterClass() {		
	}

	@Before
	public void setUp() throws Exception {
		clearDB();

		TestLogger.isDebugEnabled = false;
		TestLogger.level = "";
		TestLogger.message = "";

		dao = new LoadBalancerDao(entityManager, dataSource);
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from DM_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_FUNCTIONS");
		jdbcTemplate.execute("delete from DM_SEG_REPORTS");
		jdbcTemplate.execute("delete from MU_SEG_REPORTS");
		jdbcTemplate.execute("delete from DM_SEGMENTS");
		jdbcTemplate.execute("delete from MU_SEGMENTS");
		jdbcTemplate.execute("delete from SEGMENTS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("commit");
	}

	private void insertUnit(int unitCount) {
		for (int id = 1; id <= unitCount; id++) {
			jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"
					+ " values(" + id + ", 1421206612748)");

			jdbcTemplate.execute("insert into DATA_MANAGERS(DM_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into DM_CONTACTS(DM_ID, CONTACT_TS)"
					+ " values(" + id + ", 1421206612748)");
		}
	}

	private void insertSegments(int segCount, long containerId) {
		for (int id = 1; id <= segCount; id++) {
			jdbcTemplate.execute("insert into SEGMENTS(SEGMENT_ID,"
					+ " CONTAINER_ID, BIO_ID_START, BIO_ID_END, RECORD_COUNT,"
					+ " VERSION, REVISION, BINARY_LENGTH_COMPACTED,"
					+ " BINARY_LENGTH_UNCOMPACTED) values(" + id + ", "
					+ containerId + ", 1, 100, 100, 100, 100, 10000, 10000)");

		}
	}

	private void insertMuSeg(boolean[][] matrix) {
		for (int unitId = 1; unitId <= matrix.length; unitId++) {
			for (int segId = 1; segId <= matrix[0].length; segId++) {
				if (matrix[unitId - 1][segId - 1] == true) {
					jdbcTemplate.execute("insert into MU_SEGMENTS(MU_ID, "
							+ " SEGMENT_ID, RANK) values(" + unitId + ", "
							+ segId + ", 0)");

					jdbcTemplate.execute("insert into DM_SEGMENTS(DM_ID, "
							+ " SEGMENT_ID, RANK) values(" + unitId + ", "
							+ segId + ", 0)");
				}
			}
		}
	}

	private void insertMuSegReport(boolean[][] matrix) {
		for (int unitId = 1; unitId <= matrix.length; unitId++) {
			for (int segId = 1; segId <= matrix[0].length; segId++) {
				if (matrix[unitId - 1][segId - 1] == true) {
					jdbcTemplate.execute("insert into MU_SEG_REPORTS(MU_ID, "
							+ " SEGMENT_ID, STATUS, SEGMENT_VERSION, "
							+ "SEGMENT_QUEUED_VERSION) values(" + unitId + ", "
							+ segId + ", 0, 100, 100)");
					jdbcTemplate.execute("insert into DM_SEG_REPORTS(DM_ID, "
							+ " SEGMENT_ID, STATUS, SEGMENT_VERSION) values("
							+ unitId + ", " + segId + ", 0, 100)");
				}
			}
		}
	}

	@Test
	public void test_getSegmentIds() {
		long containerId = 1;
		insertSegments(10, containerId);

		List<Long> segList = dao.getSegmentIds(containerId);

		assertEquals(10, segList.size());
		for (int i = 0; i < segList.size(); i++) {
			assertEquals((i + 1), segList.get(i).intValue());
		}

		segList = dao.getSegmentIds(containerId + 1);
		assertEquals(0, segList.size());
	}

	@Test
	public void test_listContainers() {
		List<ContainerEntity> containerList = dao.listContainers();
		int con[] = new int[] { 1 };
		assertEquals(1, containerList.size());
		for (int i = 0; i < containerList.size(); i++) {
			assertEquals(con[i], containerList.get(i).getContainerId());
		}
	}

	@Test
	public void test_getUnitSegmetMaps_MU() {
		long containerId = 1;
		insertSegments(10, containerId);
		insertUnit(6);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSegReport(matrix);

		List<Long> unitIdList = new ArrayList<Long>();
		for (int i = 0; i < 5; i++) {
			unitIdList.add(new Long(i + 1));
		}
		List<UnitSegMap> unitSegMap = dao.getUnitSegmetMaps(unitIdList,
				ComponentType.MATCH_UNIT);

		assertEquals(17, unitSegMap.size());
		int unitIds[] = new int[] { 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4,
				5, 5, 5 };
		int segIds[] = new int[] { 1, 2, 7, 8, 2, 3, 8, 9, 3, 4, 9, 4, 5, 10,
				1, 5, 6 };
		for (int i = 0; i < unitSegMap.size(); i++) {
			assertEquals(unitIds[i], unitSegMap.get(i).getUnitId());
			assertEquals(segIds[i], unitSegMap.get(i).getSegmentId());
		}
	}

	@Test
	public void test_getUnitSegmetMaps_DM() {
		long containerId = 1;
		insertSegments(10, containerId);
		insertUnit(6);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSegReport(matrix);

		List<Long> unitIdList = new ArrayList<Long>();
		for (int i = 0; i < 5; i++) {
			unitIdList.add(new Long(i + 1));
		}
		List<UnitSegMap> unitSegMap = dao.getUnitSegmetMaps(unitIdList,
				ComponentType.DATA_MANAGER);

		assertEquals(17, unitSegMap.size());
		int unitIds[] = new int[] { 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4,
				5, 5, 5 };
		int segIds[] = new int[] { 1, 2, 7, 8, 2, 3, 8, 9, 3, 4, 9, 4, 5, 10,
				1, 5, 6 };
		for (int i = 0; i < unitSegMap.size(); i++) {
			assertEquals(unitIds[i], unitSegMap.get(i).getUnitId());
			assertEquals(segIds[i], unitSegMap.get(i).getSegmentId());
		}
	}

	@Test
	public void test_persistUnitSegMaps_MU() {
		long containerId = 1;
		insertSegments(10, containerId);
		insertUnit(6);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSeg(matrix);

		boolean[][] newMatrix = new boolean[][] {//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};

		List<Long> unitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			unitsList.add(new Long(i + 1));
		}
		List<Long> segIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			segIdsList.add(new Long(i + 1));
		}

		dao.persistUnitSegMaps(newMatrix, matrix, segIdsList, unitsList,
				ComponentType.MATCH_UNIT, containerId);

		List<Map<String, Object>> listResult = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");

		assertEquals(20, listResult.size());
		int unitIds[] = new int[] { 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 4, 5, 10, 1, 5, 6, 1, 2, 7, 8, 2, 3, 8, 9,
				3, 4, 9, 6, 7, 10 };
		for (int i = 0; i < listResult.size(); i++) {
			assertEquals("" + unitIds[i], listResult.get(i).get("MU_ID")
					.toString());
			assertEquals("" + segIds[i], listResult.get(i).get("SEGMENT_ID")
					.toString());
		}
	}

	@Test
	public void test_persistUnitSegMaps_DM() {
		long containerId = 1;
		insertSegments(10, containerId);
		insertUnit(6);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSeg(matrix);

		boolean[][] newMatrix = new boolean[][] {//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};

		List<Long> unitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			unitsList.add(new Long(i + 1));
		}
		List<Long> segIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			segIdsList.add(new Long(i + 1));
		}

		dao.persistUnitSegMaps(newMatrix, matrix, segIdsList, unitsList,
				ComponentType.DATA_MANAGER, containerId);

		List<Map<String, Object>> listResult = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");

		assertEquals(20, listResult.size());
		int unitIds[] = new int[] { 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 4, 5, 10, 1, 5, 6, 1, 2, 7, 8, 2, 3, 8, 9,
				3, 4, 9, 6, 7, 10 };
		for (int i = 0; i < listResult.size(); i++) {
			assertEquals("" + unitIds[i], listResult.get(i).get("DM_ID")
					.toString());
			assertEquals("" + segIds[i], listResult.get(i).get("SEGMENT_ID")
					.toString());
		}
	}

	@Test
	public void test_persistUnitSegMaps_MU_IDChange() {
		long containerId = 1;
		insertSegments(10, containerId);
		insertUnit(8);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSeg(matrix);

		boolean[][] newMatrix = new boolean[][] {//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};

		List<Long> unitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			unitsList.add(new Long(i + 3));
		}
		List<Long> segIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			segIdsList.add(new Long(i + 1));
		}

		dao.persistUnitSegMaps(newMatrix, matrix, segIdsList, unitsList,
				ComponentType.MATCH_UNIT, containerId);

		List<Map<String, Object>> listResult = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");

		assertEquals(20, listResult.size());
		int unitIds[] = new int[] { 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 4, 5, 10, 1, 5, 6, 1, 2, 7, 8, 2, 3, 8, 9,
				3, 4, 9, 6, 7, 10 };
		for (int i = 0; i < listResult.size(); i++) {
			assertEquals("" + (unitIds[i] + 2), listResult.get(i).get("MU_ID")
					.toString());
			assertEquals("" + segIds[i], listResult.get(i).get("SEGMENT_ID")
					.toString());
		}
	}

	@Test
	public void test_persistUnitSegMaps_DM_IDChange() {
		long containerId = 1;
		insertSegments(10, containerId);
		insertUnit(8);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSeg(matrix);

		boolean[][] newMatrix = new boolean[][] {//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};

		List<Long> unitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			unitsList.add(new Long(i + 3));
		}
		List<Long> segIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			segIdsList.add(new Long(i + 1));
		}

		dao.persistUnitSegMaps(newMatrix, matrix, segIdsList, unitsList,
				ComponentType.DATA_MANAGER, containerId);

		List<Map<String, Object>> listResult = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");

		assertEquals(20, listResult.size());
		int unitIds[] = new int[] { 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 4, 5, 10, 1, 5, 6, 1, 2, 7, 8, 2, 3, 8, 9,
				3, 4, 9, 6, 7, 10 };
		for (int i = 0; i < listResult.size(); i++) {
			assertEquals("" + (unitIds[i] + 2), listResult.get(i).get("DM_ID")
					.toString());
			assertEquals("" + segIds[i], listResult.get(i).get("SEGMENT_ID")
					.toString());
		}
	}

	@Test
	public void test_getUnitSegmetMaps_ComponentType() {
		try {
			dao.getUnitSegmetMaps(null, ComponentType.MAP_REDUCER);
		} catch (IllegalArgumentException e) {
			assertEquals("type must be MATCH_UNIT or DATA_MANAGER.",
					e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_getUnitSegmetMaps_UnitIDs() {
		try {
			dao.getUnitSegmetMaps(null, ComponentType.DATA_MANAGER);
		} catch (IllegalArgumentException e) {
			assertEquals("unitIds must no be null or empty.", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_persistUnitSegMaps_matrix() {
		try {
			dao.persistUnitSegMaps(null, new boolean[1][1],
					new ArrayList<Long>(), new ArrayList<Long>(),
					ComponentType.DATA_MANAGER, 1);
		} catch (IllegalArgumentException e) {
			assertEquals("matrix is null.", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_persistUnitSegMaps_preMatrix() {
		try {
			dao.persistUnitSegMaps(new boolean[1][1], null,
					new ArrayList<Long>(), new ArrayList<Long>(),
					ComponentType.DATA_MANAGER, 1);
		} catch (IllegalArgumentException e) {
			assertEquals("preMatrix is null.", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_persistUnitSegMaps_segIds() {
		try {
			dao.persistUnitSegMaps(new boolean[1][1], new boolean[1][1], null,
					new ArrayList<Long>(), ComponentType.DATA_MANAGER, 1);
		} catch (IllegalArgumentException e) {
			assertEquals("segIds is null.", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_persistUnitSegMaps_units() {
		try {
			dao.persistUnitSegMaps(new boolean[1][1], new boolean[1][1],
					new ArrayList<Long>(), null, ComponentType.DATA_MANAGER, 1);
		} catch (IllegalArgumentException e) {
			assertEquals("units is null.", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_persistUnitSegMaps_type() {
		try {
			dao.persistUnitSegMaps(new boolean[1][1], new boolean[1][1],
					new ArrayList<Long>(), new ArrayList<Long>(), null, 1);
		} catch (IllegalArgumentException e) {
			assertEquals("type is null.", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_persistUnitSegMaps_type_2() {
		try {
			dao.persistUnitSegMaps(new boolean[1][1], new boolean[1][1],
					new ArrayList<Long>(), new ArrayList<Long>(),
					ComponentType.MAP_REDUCER, 1);
		} catch (IllegalArgumentException e) {
			assertEquals("type must be MATCH_UNIT or DATA_MANAGER.",
					e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_persistUnitSegMaps_units_Size() {
		try {
			dao.persistUnitSegMaps(new boolean[1][1], new boolean[1][1],
					new ArrayList<Long>(), new ArrayList<Long>(),
					ComponentType.DATA_MANAGER, 1);
		} catch (IllegalArgumentException e) {
			assertEquals("matrix.length != units.size()", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_persistUnitSegMaps_matrix_length() {
		TestLogger.level = "";
		TestLogger.message = "";

		dao.persistUnitSegMaps(new boolean[0][0], new boolean[1][1],
				new ArrayList<Long>(), new ArrayList<Long>(),
				ComponentType.DATA_MANAGER, 1);
		assertEquals("info", TestLogger.level);
		assertEquals("matrix.length == 0", TestLogger.message);
	}

	@Test
	public void test_persistUnitSegMaps_segIds_size() {
		TestLogger.level = "";
		TestLogger.message = "";

		List<Long> unitIds = new ArrayList<Long>();
		unitIds.add(1l);
		dao.persistUnitSegMaps(new boolean[1][1], new boolean[1][1],
				new ArrayList<Long>(), unitIds, ComponentType.DATA_MANAGER, 1);
		assertEquals("info", TestLogger.level);
		assertEquals("segIds.size() == 0", TestLogger.message);
	}
}
