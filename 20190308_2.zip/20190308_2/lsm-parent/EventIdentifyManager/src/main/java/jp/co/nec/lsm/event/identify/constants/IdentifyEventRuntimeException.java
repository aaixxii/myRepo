package jp.co.nec.lsm.event.identify.constants;

/**
 * @author liuyq <br>
 * 
 */
public class IdentifyEventRuntimeException extends RuntimeException {

	private static final long serialVersionUID = 7157356057817916135L;

	public IdentifyEventRuntimeException(String message) {
		super(message);
	}

	public IdentifyEventRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public IdentifyEventRuntimeException(Throwable cause) {
		super(cause);
	}

}
