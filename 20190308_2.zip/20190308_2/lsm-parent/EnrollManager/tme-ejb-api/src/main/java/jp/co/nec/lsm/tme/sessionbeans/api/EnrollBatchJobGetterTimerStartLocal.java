package jp.co.nec.lsm.tme.sessionbeans.api;

import javax.ejb.Local;

/**
 *@author xia <br>
 *        start getEnrollBatchJobNormalTimer.
 */
@Local
public interface EnrollBatchJobGetterTimerStartLocal {

	public void startTimer();

}
