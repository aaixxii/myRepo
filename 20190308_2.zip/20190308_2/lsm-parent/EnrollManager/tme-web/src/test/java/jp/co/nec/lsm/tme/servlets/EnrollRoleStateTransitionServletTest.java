package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.transition.RoleStateTransition;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollRecoveryServiceBean;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollRoleStateTransitionServletTest {
	@Resource
	private EnrollRoleStateTransitionServlet servlet;

	private String recoveryString;

	@Test
	public void testDoGet_RoleStateTransition_Servlet_OK_Fadeout()
			throws Exception {

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		req.setParameter("command", "fadeout");
		servlet.doPost(req, resp);

		assertEquals(resp.getStatus(), HttpServletResponse.SC_OK);
	}

	@Test
	public void testDoGet_RoleStateTransition_Servlet_OK_Wakeup()
			throws Exception {

		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.PASSIVE);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		req.setParameter("command", "wakeup");
		servlet.doPost(req, resp);

		assertEquals(resp.getStatus(), HttpServletResponse.SC_OK);
	}

	@Test
	public void testDoGet_RoleStateTransition_Servlet_OK_Quickview()
			throws Exception {

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		req.setParameter("command", "quickview");
		servlet.doPost(req, resp);

		assertEquals(resp.getStatus(), HttpServletResponse.SC_OK);
	}

	@Test
	public void testDoGet_RoleStateTransition_Servlet_Error_Empty()
			throws Exception {

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		servlet.doPost(req, resp);

		assertEquals(resp.getStatus(), HttpServletResponse.SC_BAD_REQUEST);
	}

	@Test
	public void testDoGet_RoleStateTransition_Servlet_Error_Unkonw()
			throws Exception {

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		req.setParameter("command", "sasd");
		servlet.doPost(req, resp);

		assertEquals(resp.getStatus(),
				HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	}

	@Test
	public void testDoGet_RoleStateTransition_Servlet_RecoveryJob()
			throws Exception {
		recoveryString = "errorString";
		setJMSMockMethod();

		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.PASSIVE);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		req.setParameter("command", "wakeup");
		req.setParameter("recovery", "true");
		servlet.doPost(req, resp);

		assertEquals(recoveryString, "recoveryString");
		assertEquals(resp.getStatus(), HttpServletResponse.SC_OK);
	}

	@Test
	public void testDoGet_RoleStateTransition_Servlet_Not_RecoveryJob_1()
			throws Exception {
		recoveryString = "errorString";
		setJMSMockMethod();
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.PASSIVE);
		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		req.setParameter("command", "wakeup");
		req.setParameter("recovery", "false");
		servlet.doPost(req, resp);

		assertEquals(recoveryString, "unRecoverBatchJob");
		assertEquals(resp.getStatus(), HttpServletResponse.SC_OK);
	}

	@Test
	public void testDoGet_RoleStateTransition_Servlet_Not_RecoveryJob_2()
			throws Exception {
		recoveryString = "errorString";
		setJMSMockMethod();

		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		jobGetter.setStop(false);
		jobGetter.setTransitionState(RoleStateTransition.ACTIVE);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		req.setParameter("command", "quickview");
		req.setParameter("recovery", "true");
		servlet.doPost(req, resp);

		assertEquals(recoveryString, "errorString");
		assertEquals(resp.getStatus(), HttpServletResponse.SC_OK);
	}

	/**
	 * setMockMethod
	 */
	public void setJMSMockMethod() {
		new MockUp<EnrollRecoveryServiceBean>() {
			@Mock
			public void recoverUnCompletedBatchJob() {
				recoveryString = "recoveryString";
			}

			@Mock
			public void unRecoverBatchJob() {
				recoveryString = "unRecoverBatchJob";
			}
		};
	}
}
