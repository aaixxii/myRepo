package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;
import jp.co.nec.lsm.tme.core.clientapi.response.EnrollResultRequestBuilder;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollResponseQueue;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShot;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShotDetail;
import jp.co.nec.lsm.tme.util.TMETestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollBatchJobsSnapshotsBeanTest {

	@Resource
	EnrollBatchJobsSnapshotsBean batchJobsSnapshots;
	@Resource
	DataSource dataSource;
	JdbcTemplate template;

	@Before
	public void setUp() {
		template = new JdbcTemplate(dataSource);
		cleanMemoryQueue();
	}

	@After
	public void tearDown() {
		cleanMemoryQueue();
	}

	/**
	 * 
	 */
	private void cleanMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = deletionJobManager
				.getDeletionJobQueue();

		for (LocalDeletionJob deletionJob : deletionJobQueue) {
			deletionJobQueue.remove(deletionJob);
		}
		INSTANCE.clearAll();
	}

	private void clearDB() {
		template.execute("delete FROM ENROLL_JOB_QUEUE");
		template.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
	}

	/**
	 * prepare data for method EnrollJobQueue
	 */
	private void prepareEnrollJobQueue() {
		String enrollJobQueueSql = "insert into ENROLL_JOB_QUEUE (BATCHJOB_ID, JOB_INDEX, REQUEST_ID,"
				+ "REFERENCE_ID,RETURN_CODE, ERROR_CODE, ERROR_MESSAGE, RESENDABLE, REQUEST, RESPONSE)"
				+ " values(:BATCHJOB_ID,  :JOB_INDEX, :REQUEST_ID,"
				+ ":REFERENCE_ID, :RETURN_CODE, :ERROR_CODE, :ERROR_MESSAGE, 1, '0', '0')";
		{
			// insert into ENROLL_JOB_QUEUE, JOB_INDEX=1
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("JOB_INDEX", new Integer(1));
			argMap.put("REQUEST_ID", new Long(22));
			argMap.put("REFERENCE_ID", new String("abcd12"));
			argMap.put("RETURN_CODE",
					new Integer(ReturnCode.JobSuccess.ordinal()));
			argMap.put("ERROR_CODE", new Integer(11 % 3).toString());
			argMap.put("ERROR_MESSAGE", new Integer(11).toString());
			template.update(enrollJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_JOB_QUEUE, JOB_INDEX=2
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("JOB_INDEX", new Integer(2));
			argMap.put("REQUEST_ID", new Long(10));
			argMap.put("REFERENCE_ID", new String("abcd13"));
			argMap.put("RETURN_CODE", ReturnCode.JobSuccess.ordinal());
			argMap.put("ERROR_CODE", new Integer(12 % 3).toString());
			argMap.put("ERROR_MESSAGE", new Integer(12).toString());			
			template.update(enrollJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_JOB_QUEUE, BATCHJOB_ID=5
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("JOB_INDEX", new Integer(3));
			argMap.put("REQUEST_ID", new Long(10));
			argMap.put("REFERENCE_ID", new String("abcd14"));
			argMap.put("RETURN_CODE", ReturnCode.JobFailed.ordinal());
			argMap.put("ERROR_CODE", new Integer(13 % 3).toString());
			argMap.put("ERROR_MESSAGE", new Integer(13).toString());
			template.update(enrollJobQueueSql, argMap);
		}
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 */
	private void prepareEnrollBatchJobQueue() {
		String enrollBatchJobQueueSql = "insert into ENROLL_BATCH_JOB_QUEUE ("
				+ "BATCHJOB_ID,BATCHJOB_STATUS,START_TS, ENQUEUE_TS, END_TS)"
				+ " values(:BATCHJOB_ID,  :BATCHJOB_STATUS,:START_TS, :ENQUEUE_TS, :END_TS)";
		{
			Date now = DateUtil.getCurrentDate();
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=3
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.RETURNED.getIntValues()));
			argMap.put("ENQUEUE_TS", now);
			argMap.put("START_TS", now);
			argMap.put("END_TS", new Date(now.getTime() + 2000));
			template.update(enrollBatchJobQueueSql, argMap);
		}
	}

	/**
	 * 
	 */
	@Test
	public void testGetBatchJobSnapShot() {
		clearDB();

		prepareEnrollBatchJobQueue();
		prepareEnrollJobQueue();
		addBatchJob(3L, 1);

		EnrollBatchJobSnapShot jobSnapShot = batchJobsSnapshots
				.GetBatchJobSnapShot("10");
		List<EnrollBatchJobSnapShotDetail> list = jobSnapShot.getDetailList();

		assertEquals(1, jobSnapShot.getResponseCount());
		assertEquals(1, list.size());
		assertEquals(3, list.get(0).getBatchJobId());
		assertEquals(3, list.get(0).getJobCount());
		assertEquals(EnrollBatchJobStatus.SYNCHRONIZED, list.get(0).getStatus());
		assertEquals(3, list.get(0).getTemplatesCount());
		assertEquals(2000, list.get(0).getHoldingTime());

		clearDB();
	}

	private static final EnrollResponseQueue INSTANCE = EnrollResponseQueue
			.getInstance();

	/**
	 * addBatchJob
	 * 
	 * @param beginBatchJobId
	 */
	private void addBatchJob(long beginBatchJobId, int max) {
		final int count = 3;
		for (int index = 0; index < max; index++) {
			LocalEnrollBatchJob batchJob = TMETestUtil
					.prepareDateforEnrollResultRequest(beginBatchJobId + index,
							count);
			for (int i = 1; i <= count; i++) {
				LocalExtractJobInfo extractJobInfo = batchJob
						.getExtractJobInfo(i);
				extractJobInfo.setReturnCode(ReturnCode.JobSuccess);
			}

			EnrollResultRequest enrollResultRequest = EnrollResultRequestBuilder
					.createEnrollResultRequest(batchJob);
			INSTANCE.add(enrollResultRequest);
		}
	}
}
