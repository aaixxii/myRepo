package jp.co.nec.lsm.tme.timer;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.EndPointEnum;
import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.db.dao.EnrollBatchJobQueueDao;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

/**
 * @author xia <br>
 *         Control the get enroll batch jobs from transformer.
 */

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class EnrollBatchJobGetterPollBean {
		
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	
	private EnrollSystemConfigDao systemConfigDao;
	
	private EnrollBatchJobQueueDao batchJobQueue;

	private static Logger log = LoggerFactory
			.getLogger(EnrollBatchJobGetterPollBean.class);

	public EnrollBatchJobGetterPollBean() {
	}
	
	@PostConstruct
	public void init() {
		systemConfigDao = new EnrollSystemConfigDao(entityManager, dataSource);
		batchJobQueue = new EnrollBatchJobQueueDao(entityManager);
	}
	
	public void poll() {
		log.info("EnrollBatchJobGetterPollBean poll start.");

		StopWatch t = new StopWatch();
		t.start();

		Integer highLevelEnrollBatchJobs = systemConfigDao
				.getHighLevelEnrollBatchJobs();
		Integer lowLevelEnrollBatchJobs = systemConfigDao
				.getLowLevelEnrollBatchJobs();
		Double highLevelLimitJobs = EnrollConstants.DEFAULT_JOB_MULTIPLE
				* highLevelEnrollBatchJobs;

		Integer highInterval = systemConfigDao.getIntervalForEnrollHighLevel();
		Integer normalInterval = systemConfigDao.getIntervalForEnrollNormal();
		Integer lowInterval = systemConfigDao.getIntervalForEnrollLowLevel();

		EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
				.getInstance();
		Date nextGetJobTime = batchJobGetterTimer.getNextGetJobTime();

		Date now = DateUtil.getCurrentDate();
		if (nextGetJobTime == null) {
			nextGetJobTime = calculateNextGetJobTimeAndStore(now,
					highLevelLimitJobs, highLevelEnrollBatchJobs, highInterval,
					lowLevelEnrollBatchJobs, lowInterval, normalInterval,
					batchJobGetterTimer);
		}

		long diff = now.getTime() - nextGetJobTime.getTime();
		if (diff >= 0
				|| (diff >= EnrollConstants.DEFAULT_OFFSET_DIFF && diff < 0)) {
			try {
				if (!batchJobGetterTimer.isOverHighLevelLimit()) {
					String transformerURL = createBatchJobGetURL();
					printLogMessage("send request URL: " + transformerURL);
					sendRequestTotransformer(transformerURL);
				} else {
					int noCompleteJobs = batchJobGetterTimer
							.getNotCompleteJobs();
					log.info("memory batch job count:{} is over high Level"
							+ " Jobs limit:{}, stop send request job to "
							+ "transformer until job number is under the "
							+ "high Level Jobs limit.", noCompleteJobs,
							highLevelLimitJobs);
					return;
				}
			} finally {
				calculateNextGetJobTimeAndStore(now, highLevelLimitJobs,
						highLevelEnrollBatchJobs, highInterval,
						lowLevelEnrollBatchJobs, lowInterval, normalInterval,
						batchJobGetterTimer);
			}
			t.stop();
			PerformanceLogger.performanceOutput(
					LogConstants.COMPONENT_GETJOB_POLL_BEAN,
					LogConstants.FUNCTION_POLL, t.getTime(), "highLevelJobs",
					highLevelEnrollBatchJobs.toString(), "lowLevelJobs",
					lowLevelEnrollBatchJobs.toString(), "highInterval",
					highInterval.toString(), "normalInterval", normalInterval
							.toString(), "lowInterval", lowInterval.toString());
		} else {
			if (log.isInfoEnabled()) {
				log.info("There is not Time for send BatchJobGetterRequest:"
						+ " now: {} < nextGetJobTime: {}, diff: {}ms.",
						new Object[] { DateUtil.formatDate(now),
								DateUtil.formatDate(nextGetJobTime),
								(nextGetJobTime.getTime() - now.getTime()) });
			}
		}
		log.info("EnrollBatchJobGetterPollBean poll end.");
	}

	/**
	 * 
	 * @param now
	 * @param highLevelJobs
	 * @param highInterval
	 * @param lowLevelJobs
	 * @param lowInterval
	 * @param normalInterval
	 * @return
	 */
	private Date calculateNextGetJobTimeAndStore(Date now,
			Double highLevelLimitJobs, Integer highLevelJobs,
			Integer highInterval, Integer lowLevelJobs, Integer lowInterval,
			Integer normalInterval,
			EnrollBatchJobGetterTimer batchJobGetterTimer) {
		int intervalTime = getJobGetterInterval(highLevelLimitJobs,
				highLevelJobs, highInterval, lowLevelJobs, lowInterval,
				normalInterval, batchJobGetterTimer);
		Date nextGetJobTime = new Date(now.getTime() + intervalTime);

		if (log.isInfoEnabled()) {
			log.info("now: {}, nextGetJobTime: {}, jobGetInterval: {}, "
					+ "highLevelJobs: {}, lowLevelJobs: {}, highInterval: {}, "
					+ "normalInterval: {}, lowInterval: {}", new Object[] {
					DateUtil.formatDate(now),
					DateUtil.formatDate(nextGetJobTime), intervalTime,
					highLevelJobs, lowLevelJobs, highInterval, normalInterval,
					lowInterval });
		}
		batchJobGetterTimer.setNextGetJobTime(nextGetJobTime);
		return nextGetJobTime;
	}

	/**
	 * 
	 * @return
	 */
	private String createBatchJobGetURL() {
		// construct transformer endpoint url
		String trURL = systemConfigDao.getBatchJobFromTransformerUrl();
		String jobCount = systemConfigDao.getJobCountToTransformer();
		String batchJobCount = systemConfigDao.getBatchJobCountToTransformer();
		String turnAroundTime = systemConfigDao.getTurnAroundTime();

		if (trURL == null) {
			String errorMessage = "transformer end Point is not given.";
			throw new EnrollRuntimeException(errorMessage);
		}
		String acceptUrl = systemConfigDao.getTmeBatchJobReceiverUrl();
		StringBuilder requestUrl = new StringBuilder();
		requestUrl.append(trURL);
		requestUrl.append(Constants.HTTP_CONNECTION_INTERROGATION);

		requestUrl.append(EndPointEnum.FUNCTION_TYPE.getName());
		requestUrl.append(Constants.HTTP_CONNECTION_EQUAL);
		requestUrl.append(encodeValue(BatchType.ENROLL.name().toLowerCase()));

		requestUrl.append(Constants.HTTP_CONNECTION_AND);

		requestUrl.append(EndPointEnum.BATCHJOB_COUNT.getName());
		requestUrl.append(Constants.HTTP_CONNECTION_EQUAL);
		requestUrl.append(encodeValue(batchJobCount));

		requestUrl.append(Constants.HTTP_CONNECTION_AND);

		requestUrl.append(EndPointEnum.JOB_COUNT.getName());
		requestUrl.append(Constants.HTTP_CONNECTION_EQUAL);
		requestUrl.append(encodeValue(jobCount));

		requestUrl.append(Constants.HTTP_CONNECTION_AND);
		requestUrl.append(EndPointEnum.TURNAROUNDTIME.getName());
		requestUrl.append(Constants.HTTP_CONNECTION_EQUAL);
		requestUrl.append(encodeValue(turnAroundTime));

		requestUrl.append(Constants.HTTP_CONNECTION_AND);

		requestUrl.append(EndPointEnum.POST_URL.getName());
		requestUrl.append(Constants.HTTP_CONNECTION_EQUAL);
		requestUrl.append(encodeValue(acceptUrl));

		return requestUrl.toString();
	}

	/**
	 * 
	 * @param value
	 * @return
	 */
	private String encodeValue(String value) {
		try {
			return URLEncoder.encode(value, Constants.ENCODING_UTF8);
		} catch (UnsupportedEncodingException e) {
			log.warn("URLEncoder encode requestUrl [{}] error.", value, e);
		}
		return value;
	}

	/**
	 * sendRequestTotransformer
	 * 
	 * @param endPoint
	 * @throws IOException
	 */
	private void sendRequestTotransformer(String transformerURL) {
		HttpRequestSender httpRequestSender = new HttpRequestSender();
		try {
			if (log.isInfoEnabled()) {
				log.info("Send get batch job request to transformer: {}",
						transformerURL);
			}
			httpRequestSender.sendGetRequest(transformerURL);
		} catch (IOException e) {
			log.error("Send get batch job request to transformer error.", e);
		}
	}

	/**
	 * getJobGetterInterval
	 * 
	 * @return
	 */
	private int getJobGetterInterval(double highLevelLimitJobs,
			Integer highLevelJobs, Integer highInterval, Integer lowLevelJobs,
			Integer lowInterval, Integer normalInterval,
			EnrollBatchJobGetterTimer batchJobGetterTimer) {

		int notCompletedBatchJobs = getNotCompletedBatchJobCount();
		batchJobGetterTimer.setOverHighLevelLimit(false);
		batchJobGetterTimer.setNotCompleteJobs(notCompletedBatchJobs);

		Integer JobGetterInterval = 0;
		if (notCompletedBatchJobs >= highLevelLimitJobs) {
			batchJobGetterTimer.setOverHighLevelLimit(true);
			JobGetterInterval = highInterval;
		} else if ((notCompletedBatchJobs >= highLevelJobs)
				&& (notCompletedBatchJobs < highLevelLimitJobs)) {
			JobGetterInterval = highInterval;
		} else if ((notCompletedBatchJobs < highLevelJobs)
				&& (notCompletedBatchJobs > lowLevelJobs)) {
			JobGetterInterval = normalInterval;
		} else {
			JobGetterInterval = lowInterval;
		}

		return JobGetterInterval;
	}

	/**
	 * get undone job count
	 * 
	 * @return undone batchjob count
	 * @throws
	 */
	private Integer getNotCompletedBatchJobCount() {
		List<EnrollBatchJobQueueEntity> unCompletedjobs = batchJobQueue
				.getAllUnReturnedBatchJob();
		if (unCompletedjobs != null)
			return unCompletedjobs.size();
		return 0;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
