package jp.co.nec.lsm.tme.db.dao;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.db.common.entityhelpers.ContactTimesSPHelper;

/**
 * @author liuj <br>
 * 
 */

public class EnrollContactTimesSPDao  {
	
	private EntityManager manager;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollContactTimesSPDao.class);
	
	public EnrollContactTimesSPDao (EntityManager manager) {
		this.manager = manager;
		printLogMessage("EnrollContactTimesSPDao init");
	}	

	/***
	 * The method used to update MU_CONTACTS table.
	 * 
	 * @param dataSource
	 * @param muId
	 * @param updateLastHeartbeatFlag
	 * @param updateLastReportFlag
	 */	
	public void updateContactTimes(long muId, boolean updateLastHeartbeatFlag,
			boolean updateLastReportFlag) {

		ContactTimesSPHelper.updateContactTimes(manager, muId,
				updateLastHeartbeatFlag, updateLastReportFlag);

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
