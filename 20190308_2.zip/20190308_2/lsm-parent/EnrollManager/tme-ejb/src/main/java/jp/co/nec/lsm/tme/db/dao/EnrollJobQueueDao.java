package jp.co.nec.lsm.tme.db.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entityhelpers.EnrollJobQueueHelper;
import jp.co.nec.lsm.tm.db.enroll.procedure.ExctractJobInsertProcedure;
import jp.co.nec.lsm.tm.db.enroll.procedure.ExctractJobUpdateProcedure;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;

/**
 * @author liuj <br>
 * 
 */

public class EnrollJobQueueDao  {	
	
	private DataSource dataSource;

	private EnrollJobQueueHelper jobQueueHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollJobQueueDao.class);
	
	public  EnrollJobQueueDao (EntityManager manager, DataSource dataSource) {
		this.dataSource = dataSource;		
		jobQueueHelper = new EnrollJobQueueHelper(manager);
		printLogMessage("EnrollJobQueueDao init");
	}

	/**
	 * get all Extract Job Information.
	 * 
	 * @param batchJobId
	 *            batch Job Id
	 * @return list of EnrollJobQueueEntity
	 */	
	public List<EnrollJobQueueEntity> getAllExtractJobInfo(long batchJobId) {
		printLogMessage("start public function getAllExtractJobInfo()..");

		// persist all extract job information of batchJobId into database
		List<EnrollJobQueueEntity> jobQueues = jobQueueHelper
				.getAllExtractJobInfo(batchJobId);

		printLogMessage("end public function getAllExtractJobInfo()..");

		return jobQueues;
	}

	/**
	 * insert extract job info into ENROLL_JOB_QUEUE
	 * 
	 * @param extractJobEntityList
	 *            List of EnrollJobQueueEntity
	 */
	public void insertExctractJobQueue(
			List<EnrollJobQueueEntity> extractJobEntityList) {
		printLogMessage("start public function insertExctractJobQueue");
		if (extractJobEntityList == null) {
			log.warn("extractJobEntityList list is null.");
			return;
		} else if (extractJobEntityList.isEmpty()) {
			log.warn("extractJobEntityList list is empty.");
			return;
		}
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		ExctractJobInsertProcedure insertProcedure = new ExctractJobInsertProcedure(
				dataSource);
		insertProcedure.setQueryTimeout(EnrollConstants.QUERY_TIMEOUT);
		insertProcedure.execute(extractJobEntityList);

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_ENROLL_JOB_QUEUE_DAO,
				LogConstants.FUNCTION_INSERT_EXTRACTJOB_QUEUE, stopWatch
						.getTime());
		printLogMessage("end public function insertExctractJobQueue");
	}

	/**
	 * update extract job result into ENROLL_JOB_QUEUE
	 * 
	 * @param extractJobEntityList
	 *            List of EnrollJobQueueEntity
	 */
	public void updateExctractJobQueue(
			List<EnrollJobQueueEntity> extractJobEntityList) {
		printLogMessage("start public function updateExctractJobQueue");
		if (extractJobEntityList == null) {
			log.warn("extractJobEntityList list is null.");
			return;
		} else if (extractJobEntityList.isEmpty()) {
			log.warn("extractJobEntityList list is empty.");
			return;
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		ExctractJobUpdateProcedure updateProcedure = new ExctractJobUpdateProcedure(
				dataSource);
		updateProcedure.setQueryTimeout(EnrollConstants.QUERY_TIMEOUT);
		updateProcedure.execute(extractJobEntityList);

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_ENROLL_JOB_QUEUE_DAO,
				LogConstants.FUNCTION_UPDATE_EXTRACTJOB_QUEUE, stopWatch
						.getTime());
		printLogMessage("end public function updateExctractJobQueue");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
