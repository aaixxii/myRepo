package jp.co.nec.lsm.tme.service.sessionbean;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.common.util.ResponseMessageBuilder;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.db.dao.EnrollBatchJobQueueDao;
import jp.co.nec.lsm.tme.db.dao.EnrollJobQueueDao;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollRecoveryServiceBean  {
	private static final Logger log = LoggerFactory
			.getLogger(EnrollRecoveryServiceBean.class);

	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private EnrollBatchJobQueueDao batchJobQueueDao;
	
	private EnrollJobQueueDao jobQueueDao;
	
	public EnrollRecoveryServiceBean() {		
	}
	
	@PostConstruct
	public void init() {		
		jobQueueDao = new EnrollJobQueueDao(entityManager, dataSource);
		batchJobQueueDao = new EnrollBatchJobQueueDao(entityManager);
	}

	/**
	 * Recover uncompleted enrollBatchJob.
	 */	
	public void recoverUnCompletedBatchJob() {
		printLogMessage("start private function recoverUnCompletedBatchJob()..");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		// Recover uncompleted enrollBatchJob.
		try {
			RestoreEnrollBatchJob();
		} catch (NumberFormatException e) {
			String message = "NumberFormatException WHEN CALL RestoreEnrollBatchJob.";
			printLogMessage(message);
			throw new EnrollRuntimeException(message, e);
		} catch (InvalidProtocolBufferException e) {
			String message = "InvalidProtocolBufferException WHEN CALL RestoreEnrollBatchJob.";
			printLogMessage(message);
			throw new EnrollRuntimeException(message, e);
		}

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_RECOVERY_BEAN,
				LogConstants.FUNCTION_RECOVERY_UNCOMPLETED_BATCH_JOB, stopWatch
						.getTime());

		printLogMessage("end private function recoverUnCompletedBatchJob()..");

	}

	/**
	 * Recover uncompleted enrollBatchJob.
	 * 
	 * @throws InvalidProtocolBufferException
	 * @throws NumberFormatException
	 * 
	 */
	private void RestoreEnrollBatchJob() throws NumberFormatException,
			InvalidProtocolBufferException {
		// BatchJobs for notifying to EnrollResponseServiceBean
		List<Long> regBatchJobs = new ArrayList<Long>();
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		// get all uncompleted enroll Batch Job from DB
		List<EnrollBatchJobQueueEntity> batchJobs = batchJobQueueDao
				.getAllUnReturnedBatchJob();

		// loop to Recover uncompleted enrollBatchJob.
		printLogMessage("loop to Recover uncompleted enrollBatchJob.");

		for (EnrollBatchJobQueueEntity ebjqe : batchJobs) {
			LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
			long batchjobId = ebjqe.getBatchjobId();

			if (queueManage.getEnrollBatchJobById(batchjobId) != null) {
				log.warn("BatchJob(Id: {}) is existed in memory, skip.",
						batchjobId);
				continue;
			}

			EnrollBatchJobStatus status = EnrollBatchJobStatus
					.getBatchJobStatus(ebjqe.getBatchjobStatus());

			// get all extract jobs of enroll Batch Job
			List<EnrollJobQueueEntity> extractjobs = jobQueueDao
					.getAllExtractJobInfo(batchjobId);

			printLogMessage(
					"loop to Recover Extract Jobs of enrollBatchJob: {}",
					batchjobId);

			// loop to Recover Extract Jobs of enrollBatchJob
			for (EnrollJobQueueEntity ejqe : extractjobs) {

				LocalExtractJobInfo extractJobInfo = prepareExtractJobInfo(ejqe);
				if (ejqe.getReturnCode() != ReturnCode.NotUsed
						&& status != EnrollBatchJobStatus.REGISTERED) {
					status = EnrollBatchJobStatus.EXTRACTING;
				}

				// add Extract Jobs map into enroll Batch job
				enrollBatchJob.putExtractJobInfo(extractJobInfo);
			}

			Long regBatchjobId = setEnrollBatchJobInfo(enrollBatchJob, ebjqe,
					status);

			if (regBatchjobId != null) {
				regBatchJobs.add(regBatchjobId);
			}

			printLogMessage(
					"Recover Batch job(BatchjobId: {}) into local enroll queue.",
					batchjobId);

			// add enroll Batch Job into local enroll queue
			queueManage.addEnrollBatchJob(enrollBatchJob);
		}

		for (Long batchjobId : regBatchJobs) {
			// notify to EnrollResponseServiceBean
			EnrollEventBus.notifyResponse(batchjobId,
					EnrollNotifierEnum.EnrollSystemInitializationBean);
		}
	}

	/***
	 * prepare enrollBatchJobInfo
	 * 
	 * @param status
	 * @param ejqe
	 * @return
	 * @throws InvalidProtocolBufferException
	 */
	private LocalExtractJobInfo prepareExtractJobInfo(EnrollJobQueueEntity ejqe)
			throws InvalidProtocolBufferException {

		LocalExtractJobInfo extractJobInfo = new LocalExtractJobInfo();
		// other information of Extract Job
		extractJobInfo.setJobId(ejqe.getJobIndex());
		extractJobInfo.setReferenceId(ejqe.getReferenceId());
		extractJobInfo.setRequestId(ejqe.getRequestId());
		extractJobInfo.setReturnCode(ejqe.getReturnCode());
		extractJobInfo.setErrorCode(ejqe.getErrorCode());
		extractJobInfo.setReSendable(ejqe.isReSendable());
		extractJobInfo.setErrorMessage(ejqe.getErrorMessage());

		byte[] requestBytes = ejqe.getRequest();
		CPBBusinessMessage businessRequest = CPBBusinessMessage
				.parseFrom(requestBytes);
		extractJobInfo.setRequest(businessRequest);

		// if Batch Job's Status is QUEUED, extract Job will reassign.
		if (ejqe.getReturnCode() == ReturnCode.NotUsed) {
			extractJobInfo.setStatus(LocalExtractJobStatus.READY);
			extractJobInfo.setFailureCount(0);
		} else {
			extractJobInfo.setStatus(LocalExtractJobStatus.DONE);

			CPBBusinessMessage businessMessage;

			byte[] responseBytes = ejqe.getResponse();
			if (responseBytes != null && responseBytes.length != 0) {
				businessMessage = CPBBusinessMessage.parseFrom(responseBytes);
			} else {
				businessMessage = ResponseMessageBuilder
						.createBusinessMessageByRequest(businessRequest
								.getRequest(), ejqe.getReturnCode(), ejqe
								.getErrorCode(), ejqe.getErrorMessage(),
								extractJobInfo.getReSendable());
			}
			extractJobInfo.setResponse(businessMessage);
		}

		return extractJobInfo;
	}

	/**
	 * 
	 * @param enrollBatchJob
	 * @param ebjqe
	 * @param jobCount
	 * @param status
	 * @return
	 */
	private Long setEnrollBatchJobInfo(LocalEnrollBatchJob enrollBatchJob,
			EnrollBatchJobQueueEntity ebjqe, EnrollBatchJobStatus status) {
		Long regBatchjobId = null;
		long batchjobId = ebjqe.getBatchjobId();

		// Recover enroll Batch job information.
		enrollBatchJob.setBatchJobType(BatchType.ENROLL);
		enrollBatchJob.setBatchJobId(batchjobId);
		enrollBatchJob.setBatchJobStatus(status);
		enrollBatchJob.setEnqueueTS(ebjqe.getEnqueueTs());
		enrollBatchJob.setBatchJob_start_TS(ebjqe.getStartTs());

		// if Batch Job's Status is not QUEUED, notify to
		// EnrollResponseServiceBean
		if (status == EnrollBatchJobStatus.REGISTERED) {
			List<SegmentPosition> segPosList = prepareSegmentPosition(ebjqe);
			enrollBatchJob.setSegmentPosition(segPosList);
			enrollBatchJob.setSyncEndTS(DateUtil.getCurrentDate());
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.SYNCHRONIZED);

			if (log.isInfoEnabled()) {
				BatchJobStatusLogger.outputBatchJobStatus(
						LogConstants.STATUS_CATEGORY_TME, enrollBatchJob
								.getBatchJobId(),
						EnrollBatchJobStatus.SYNCHRONIZED.name());
			}

			printLogMessage(
					"notify Batch job(BatchjobId: ) to EnrollResponseService.",
					batchjobId);

			// add batchjobId into regBatchJobs for notifying to
			// EnrollResponseServiceBean
			regBatchjobId = batchjobId;

		} else {
			enrollBatchJob.setBatchJobStatus(status);

			if (log.isInfoEnabled()) {
				BatchJobStatusLogger.outputBatchJobStatus(
						LogConstants.STATUS_CATEGORY_TME, enrollBatchJob
								.getBatchJobId(), status.name());
			}
		}

		return regBatchjobId;
	}

	/**
	 * 
	 * @param ebjqe
	 * @return
	 */
	private List<SegmentPosition> prepareSegmentPosition(
			EnrollBatchJobQueueEntity ebjqe) {
		List<SegmentPosition> segPosList = new ArrayList<SegmentPosition>();

		SegmentPosition segPos1st = new SegmentPosition();
		segPos1st.setSegmentId(ebjqe.getSegmentId1st());
		segPos1st.setVersion(ebjqe.getVersion1st());
		segPos1st.setIndexStart(ebjqe.getIndexStart1st());
		segPos1st.setIndexEnd(ebjqe.getIndexEnd1st());

		segPosList.add(segPos1st);

		SegmentPosition segPos2nd = new SegmentPosition();
		segPos2nd.setSegmentId(ebjqe.getSegmentId2nd());
		segPos2nd.setVersion(ebjqe.getVersion2nd());
		segPos2nd.setIndexStart(ebjqe.getIndexStart2nd());
		segPos2nd.setIndexEnd(ebjqe.getIndexEnd2nd());

		segPosList.add(segPos2nd);

		SegmentPosition segPos3rd = new SegmentPosition();
		segPos3rd.setSegmentId(ebjqe.getSegmentId3rd());
		segPos3rd.setVersion(ebjqe.getVersion3rd());
		segPos3rd.setIndexStart(ebjqe.getIndexStart3rd());
		segPos3rd.setIndexEnd(ebjqe.getIndexEnd3rd());

		segPosList.add(segPos3rd);

		return segPosList;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

	/**
	 * delete all unreturned batch jobs from database
	 */	
	public void unRecoverBatchJob() {
		batchJobQueueDao.deleteUnReturnedBatchJobs();
	}
}
