package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.db.common.entityhelpers.DateHelper;

/**
 * @author liuj <br>
 * 
 */

public class EnrollDateDao  {
	private DateHelper dateHelper;
	
	public EnrollDateDao(DataSource dataSource) {		
		dateHelper = new DateHelper(dataSource);
		printLogMessage("EnrollDateDao init");
	}

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollDateDao.class);
	
	public Date getDatabaseDate() {
		printLogMessage("start function getDatabaseDate to get Database Date.");
		return dateHelper.getDatabaseDate();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
