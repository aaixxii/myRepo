package jp.co.nec.lsm.tma.core.clientapi.response;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import java.io.Serializable;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.communication.ReSendable;

import org.jboss.util.Strings;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBScore;
import com.nec.everest.proto.protobuf.BusinessMessage.E_MODALITY_TYPE;

/**
 *@author dongqk <br>
 */
public class IdentifyJobResult implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int jobIndex;
	private String requestId;
	private String referenceId;
	private int maxCandidate;
	private ReturnCode returnCode;
	private ObjectArrayList<Candidate> candidates;
	private boolean isOverMaxCandidates;
	private String startTime = Strings.EMPTY;
	private String endTime = Strings.EMPTY;
	private String errorCode = Strings.EMPTY;
	private String errorMessage = Strings.EMPTY;
	private AMRState aMRState = new AMRState();
	private ReSendable resendable = ReSendable.EMPTY;

	/**
	 * constructor
	 */
	public IdentifyJobResult() {
		super();
	}

	/**
	 * constructor
	 * 
	 * @param jobIndex
	 * @param requestId
	 * @param referenceId
	 * @param maxCandidate
	 */
	public IdentifyJobResult(int jobIndex, String requestId, String referenceId, int maxCandidate,
			ReturnCode returnCode, String errorCode, String errorMessage, ReSendable resendable) {
		this.jobIndex = jobIndex;
		this.requestId = requestId;
		this.referenceId = referenceId;
		this.maxCandidate = maxCandidate;
		this.returnCode = returnCode;
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.resendable = resendable;
		initCandidates(maxCandidate + 1);
	}

	/**
	 * constructor
	 * 
	 * @param jobIndex
	 * @param requestId
	 * @param referenceId
	 * @param maxCandidate
	 * @param returnCode
	 * @param uidFailureReason
	 * @param candidates
	 */
	public IdentifyJobResult(int jobIndex, String requestId, String referenceId, int maxCandidate,
			ReturnCode returnCode, ObjectArrayList<Candidate> candidates, String errorCode, String errorMessage,
			ReSendable resendable) {
		super();
		this.jobIndex = jobIndex;
		this.requestId = requestId;
		this.referenceId = referenceId;
		this.maxCandidate = maxCandidate;
		this.returnCode = returnCode;
		this.candidates = candidates;
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.resendable = resendable;
	}

	/**
	 * initialize Candidate List
	 * 
	 * @param size
	 */
	private void initCandidates(int size) {
		this.candidates = new ObjectArrayList<Candidate>(size);
		for (int i = 0; i < size; i++) {
			Candidate.Builder candidateBuilder = Candidate.newBuilder().setReferenceId("").setScaledScore(Integer.MIN_VALUE);
			candidateBuilder.getModalScoreBuilder().setEnrollmentId("")
				.addScore(
					CPBScore.newBuilder().setModalityType(E_MODALITY_TYPE.FACE).setValue(String.valueOf(Integer.MIN_VALUE))
						.setModalitySubType("").setBufferValue1("").build())
				.addScore(
					CPBScore.newBuilder().setModalityType(E_MODALITY_TYPE.FINGER).setValue(String.valueOf(Integer.MIN_VALUE))
						.setModalitySubType("").setBufferValue1("").build())
				.addScore(
					CPBScore.newBuilder().setModalityType(E_MODALITY_TYPE.IRIS).setValue(String.valueOf(Integer.MIN_VALUE))
						.setModalitySubType("").setBufferValue1("").build());
			this.candidates.add(candidateBuilder.build());
		}
	}

	/**
	 * @return the jobIndex
	 */
	public int getJobIndex() {
		return jobIndex;
	}

	/**
	 * @param jobIndex
	 *            the jobIndex to set
	 */
	public void setJobIndex(int jobIndex) {
		this.jobIndex = jobIndex;
	}

	/**
	 * @return the returnCode
	 */
	public ReturnCode getReturnCode() {
		return returnCode;
	}

	/**
	 * @param returnCode
	 *            the returnCode to set
	 */
	public void setReturnCode(ReturnCode returnCode) {
		this.returnCode = returnCode;
	}

	/**
	 * @return the candidates
	 */
	public ObjectArrayList<Candidate> getCandidates() {
		if (null == candidates) {
			initCandidates(maxCandidate + 1);
		}
		return candidates;
	}

	/**
	 * @param candidates
	 *            the candidates to set
	 */
	public void setCandidates(ObjectArrayList<Candidate> candidates) {
		this.candidates = candidates;
	}

	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId
	 *            the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the referenceId
	 */
	public String getReferenceId() {
		return referenceId;
	}

	/**
	 * @param referenceId
	 *            the referenceId to set
	 */
	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	/**
	 * @return the maxCandidate
	 */
	public int getMaxCandidate() {
		return maxCandidate;
	}

	/**
	 * @param maxCandidate
	 *            the maxCandidate to set
	 */
	public void setMaxCandidate(int maxCandidate) {
		this.maxCandidate = maxCandidate;
	}

	/**
	 * @return the isOverMaxCandidates
	 */
	public boolean isOverMaxCandidates() {
		return isOverMaxCandidates;
	}

	/**
	 * @param isOverMaxCandidates
	 *            the isOverMaxCandidates to set
	 */
	public void setOverMaxCandidates(boolean isOverMaxCandidates) {
		this.isOverMaxCandidates = isOverMaxCandidates;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	

	/**
	 * getaMRState
	 * @return
	 */
	public AMRState getaMRState() {
		return aMRState;
	}
	

	public ReSendable getResendable() {
		return resendable;
	}

	public void setResendable(ReSendable resendable) {
		this.resendable = resendable;
	}
}
