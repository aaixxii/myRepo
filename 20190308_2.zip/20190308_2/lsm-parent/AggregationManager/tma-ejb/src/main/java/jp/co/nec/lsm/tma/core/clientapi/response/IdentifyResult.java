package jp.co.nec.lsm.tma.core.clientapi.response;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.longs.LongArraySet;

import java.io.Serializable;

/**
 * @author dongqk <br>
 * IdentifyResult from MU
 * 
 */
public class IdentifyResult implements Serializable {
	public void setReadCount(long readCount) {
		this.readCount = readCount;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long batchJobId;
	private Int2ObjectArrayMap<IdentifyJobResult> searchJobResults;
	private LongArraySet segmentIds;
	private long readCount;

	/**
	 * constructor
	 */
	public IdentifyResult() {
		super();
		this.searchJobResults = new Int2ObjectArrayMap<IdentifyJobResult>();
		this.segmentIds = new LongArraySet();
	}

	/**
	 * constructor
	 * 
	 * @param batchJobId
	 * @param segmentIds
	 * @param searchJobResults
	 */
	public IdentifyResult(long batchJobId, LongArraySet segmentIds,
			Int2ObjectArrayMap<IdentifyJobResult> searchJobResults, long readCount) {
		super();
		this.batchJobId = batchJobId;
		this.segmentIds = segmentIds;
		this.searchJobResults = searchJobResults;
		this.readCount = readCount;
	}

	/**
	 * @return the batchJobId
	 */
	public long getBatchJobId() {
		return batchJobId;
	}

	/**
	 * @param batchJobId
	 *            the batchJobId to set
	 */
	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}

	/**
	 * @return the searchJobResults
	 */
	public Int2ObjectArrayMap<IdentifyJobResult> getSearchJobResults() {
		if (null == searchJobResults) {
			searchJobResults = new Int2ObjectArrayMap<IdentifyJobResult>();
		}
		return searchJobResults;
	}

	/**
	 * @param searchJobResults
	 *            the searchJobResults to set
	 */
	public void setSearchJobResults(Int2ObjectArrayMap<IdentifyJobResult> searchJobResults) {
		this.searchJobResults = searchJobResults;
	}

	/**
	 * @return the segmentIds
	 */
	public LongArraySet getSegmentIds() {
		if (null == segmentIds) {
			segmentIds = new LongArraySet();
		}
		return segmentIds;
	}

	/**
	 * @param segmentIds
	 *            the segmentIds to set
	 */
	public void setSegmentIds(LongArraySet segmentIds) {
		this.segmentIds = segmentIds;
	}

	/**
	 * @return the readCount
	 */
	public long getReadCount() {
		return readCount;
	}

	/**
	 * @param readCount the readCount to set
	 */
	public void addReadCount(long readCount) {
		this.readCount += readCount;
	}

}
