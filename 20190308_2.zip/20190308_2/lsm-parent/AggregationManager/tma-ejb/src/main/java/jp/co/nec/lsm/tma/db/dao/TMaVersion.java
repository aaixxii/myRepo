package jp.co.nec.lsm.tma.db.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Read version property in pom.properties
 * 
 * @author mozj
 * 
 */
public class TMaVersion {
	private static final Logger log = LoggerFactory.getLogger(TMaVersion.class);
	private static final String PATH = "META-INF/maven/jp.co.nec.lsm.tma.ejb/tma-ejb/pom.properties";
	private static String version; 

	/**
	 * Read version number from pom.propertis in the ejb archive file.
	 * 
	 * @return version number
	 */
	public static String readVersion() {
		if (version == null) {
			Properties prop = new Properties();
			InputStream in = TMaVersion.class.getClassLoader()
					.getResourceAsStream(PATH);
			if (in == null) {
				log.error("Can't find " + PATH);
				return null;
			}
			try {
				prop.load(in);
				version = prop.getProperty("version");
				System.out.println("############"+ version);
				return version;
			} catch (IOException e) {
				log.error("Can't load " + PATH);
				return null;
			}
		} else {
			return version;
		}
	}
}
