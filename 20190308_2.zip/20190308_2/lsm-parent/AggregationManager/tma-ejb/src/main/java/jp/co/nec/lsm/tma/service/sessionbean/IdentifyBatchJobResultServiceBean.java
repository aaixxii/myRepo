package jp.co.nec.lsm.tma.service.sessionbean;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tma.common.util.AggregationEventBus;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.db.dao.AggregationSystemConfigDao;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;

/**
 * @author dongqk <br>
 *         TMA -> TMI<br>
 *         TMA -> Transformer<br>
 *         remove data(had done)
 * 
 */
@Stateless
public class IdentifyBatchJobResultServiceBean {

	private static Logger log = LoggerFactory
			.getLogger(IdentifyBatchJobResultServiceBean.class);
	
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager entityManager;
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private AggregationSystemConfigDao systemConfigDao;

	public IdentifyBatchJobResultServiceBean() {		
	}
	
	@PostConstruct
	public void init() {
		printLogMessage("CNTR: BatchSegmentJobMapInitializerBean init");
		systemConfigDao = new AggregationSystemConfigDao(entityManager, dataSource);
	}

	/**
	 * the Batch had been done<br>
	 * 1. Find in IdentifyResultMap has disposed of BatchJob, stored in
	 * IdentifyResponse.<br>
	 * 2. send IdentifyResponse Object to Transformer.<br>
	 * 3. the BatchSegmentJobMap treated by AggregationService has been sent to
	 * TMI through by JMS.<br>
	 * 4. remove BatchSegmetnJobMap and IdentifyResult from MemoryQueue that
	 * which BatchJob had operated done.<br>
	 * 
	 * @param batchJobId
	 *            which has been operated done
	 */
	public void notifyBatchJobDone(long batchJobId) {
		printLogMessage("start public function notifyBatchJobDone()...");

		StopWatch t = new StopWatch();
		t.start();
		BatchSegmentJobManager queueManager = BatchSegmentJobManager
				.getInstance();

		// 1. Find in IdentifyResultMap has disposed of BatchJob
		IdentifyResult identifyResult = queueManager
				.getIdentifyResult(batchJobId);
		if (null == identifyResult) {
			String message = "error according to the batchJobId, doesnot find IdentifyResult from TMA queue...";
			log.error(message);
			throw new AggregationRuntimeException(message);
		}
		// Find in BatchSegmentJobMap has disposed of BatchJob
		BatchSegmentJobMap batchSegmentJobMap = queueManager
				.getBatchSegmentJobMap(batchJobId);
		if (null == batchSegmentJobMap) {
			String message = "error according to the batchJobId, doesnot find BatchSegmentJobMap from TMA queue...";
			log.error(message);
			throw new AggregationRuntimeException(message);
		}

		// set all SearchJobResult's OverMaxCandidates
		queueManager.setOverMaxCandidatesTrue(batchJobId);

		if (BatchJobMapStatus.TMA_WORKING_DONE == queueManager
				.getBatchSegmentJobMapStatus(batchJobId)) {
			String endPoint = systemConfigDao.getPostToTransformerUrl();
			Integer timeout = systemConfigDao.getTransformerPostTimeout();

			// 2. send IdentifyResponse Object to Transformer
			boolean isSendTransformerSuccess = AggregationEventBus
					.sendIdentifyResponseToTransformer(identifyResult,
							endPoint, timeout);
			if (isSendTransformerSuccess) {
				// set Status to NOTIFY_TRANSFORMER_DONE
				queueManager.setBatchSegmentJobMapStatusDone(batchJobId,
						BatchJobMapStatus.NOTIFY_TRANSFORMER_DONE);
			} else {
				String message = "BatchJobId: " + batchJobId
						+ ", send IdentifyResponse to Transformer error.";
				log.error(message);
				throw new AggregationRuntimeException(message);
			}
		}

		if (BatchJobMapStatus.NOTIFY_TRANSFORMER_DONE == queueManager
				.getBatchSegmentJobMapStatus(batchJobId)) {
			// 3. send BatchSegmentJobMap which had done to TMI by JMS
			String tmiIpAddress = systemConfigDao.getTmiIpAddress();
			boolean isSendTMISuccess = AggregationEventBus
					.sendBatchSegmentJobMapToTMI(batchSegmentJobMap,
							tmiIpAddress);
			if (isSendTMISuccess) {
				// set Status to NOTIFY_TMI_DONE
				queueManager.setBatchSegmentJobMapStatusDone(batchJobId,
						BatchJobMapStatus.NOTIFY_TMI_DONE);
			} else {
				String message = "BatchJobId: "
						+ batchJobId
						+ ", send BatchSegmentJobMap to TMI error, when this BatchSegmentJobMap has been done.";
				log.error(message);
				throw new AggregationRuntimeException(message);
			}
		}

		// 4. remove BatchSegmetnJobMap and IdentifyResult from MemeryQueue that
		// which BatchJob had operated done.
		if (queueManager.getBatchSegmentJobMapStatus(batchJobId) == BatchJobMapStatus.NOTIFY_TMI_DONE) {
			queueManager.remove(batchJobId);
		}

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_BATCHJOBRESULT_SERVICE_BEAN,
				LogConstants.FUNCTION_NOTIFY_BATCH_JOB_DONE, t.getTime(),
				LogConstants.KEY_BATCH_JOB_ID, new Long(batchJobId).toString());

		printLogMessage("end public function notifyBatchJobDone()...");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
