package com.nec.aim.audio.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.nec.aim.audio.service.FileUtil;
import com.nec.aim.audio.service.JaxBUtil;
import com.nec.aim.audio.service.Speakers;
import com.nec.wrapper.SpeakerDiarizationWrapper;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class RestDownloadController {

	@Value("${audio.wave.file.path}")
	private String waveFilelPath;

	@Value("${audio.tool.config.path}")
	private String configPath;
	
	private String configPathBase64;

	@Value("${audio.xml.save.path}")
	private String xmlFileSavePath;	
	
	private static final Charset charset = StandardCharsets.UTF_8;
	
	
	@PostConstruct
	public void init() {
		  byte[] configPath64 = Base64.getEncoder().encode(configPath.getBytes(charset));
		  configPathBase64 =  new String( configPath64, charset);	   
	}
	

	@GetMapping("/download")
	public ResponseEntity<InputStreamResource> getAudioData(@RequestParam String fileName) throws IOException {
		URL url = Thread.currentThread().getContextClassLoader().getResource("wave/" + fileName);
		File audioFile = new File(url.getPath());
		InputStream in = new FileInputStream(audioFile);
		return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM).body(new InputStreamResource(in));
	}

	@GetMapping("/getMp3Path")
	public String getMp3Path(@RequestParam String fileName) {
		URL url = Thread.currentThread().getContextClassLoader().getResource("wave/" + fileName);
		return url.getPath();
	}

	@GetMapping("/getWavePath")
	public String getWavFilePath() {
		File file = new File(waveFilelPath);
		URI url = file.toURI();
		return url.toString();
	}

	@GetMapping(value = "/openTool", produces = MediaType.APPLICATION_JSON_VALUE)
	public Speakers openToolByJsonP(@RequestParam("path") String wavePath) {		
		Speakers result = null;
		if (this.configPathBase64 == null || configPathBase64.isEmpty()) {
			configPathBase64 = encodeBase64(configPath);
		}
		SpeakerDiarizationWrapper SDWrap = new SpeakerDiarizationWrapper();
		String strXml = SDWrap.Diariztion(wavePath, configPathBase64);		
		if (xmlFileSavePath != null && !xmlFileSavePath.isEmpty()) {
			try {
				saveStringXmlToFile(strXml, xmlFileSavePath);
				JaxBUtil<Speakers> jaxb = new JaxBUtil<Speakers>();
				result = jaxb.unmarshalFromFile(Speakers.class, xmlFileSavePath);				
				log.info("Saved result to: " + xmlFileSavePath);
				
			} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {
				e.printStackTrace();
			}
		}		
		JaxBUtil<Speakers> jaxb = new JaxBUtil<Speakers>();
		try {
			result = jaxb.unmarshal(Speakers.class, strXml);
		} catch (JAXBException e) {			
			e.printStackTrace();
		}	
			return result;		
	}

	@RequestMapping(value = "/getXml", produces = MediaType.APPLICATION_XML_VALUE)
	public String testGetXml() {
		String result = null;
		FileUtil fu = new FileUtil();
		try {
			result = fu.readStringFromDat("C:/Users/xia/Desktop/" + "DiarizationResult.xml");
			System.out.print(result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "result";
	}

	private void saveStringXmlToFile(final String xmlStr, String xmlFilePath)
			throws SAXException, IOException, ParserConfigurationException, TransformerException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		Document doc = factory.newDocumentBuilder().parse(new InputSource(new StringReader(xmlStr)));
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		javax.xml.transform.Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(xmlFilePath));
		transformer.transform(source, result);
	}
	
	private String encodeBase64(String str) {
		 byte[] base64 = Base64.getEncoder().encode(str.getBytes(charset));
		  return new String(base64, charset);
	}
	
	@SuppressWarnings("unused")
	private String decodeBase64(String str) {
		byte[] tmp = Base64.getDecoder().decode(str.getBytes(charset));
		String tmpStr = new String(tmp,charset);
		System.out.println(tmpStr);	
		return tmpStr;
		
	}
}
