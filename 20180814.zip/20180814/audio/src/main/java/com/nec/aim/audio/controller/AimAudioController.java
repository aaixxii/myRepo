package com.nec.aim.audio.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nec.aim.audio.persistence.entity.User;
import com.nec.aim.audio.persistence.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class AimAudioController {

	@Autowired
	private UserRepository userRepository;

	@GetMapping({ "/", "/login" })
	public String index() {
		return "login";
	}

	@PostMapping("/login")
	public String logininmain(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("username") String username, @RequestParam("password") String password) {
		AtomicBoolean sucess = new AtomicBoolean(false);
		List<User> listUser = userRepository.findAll();
		listUser.forEach(one -> {
			if (one.getUsername().equals(username) && one.getPassword().equals(password)) {
				sucess.set(true);
				request.getSession().setAttribute(username, password);
			}
		});

		if (sucess.get()) {
			return "audio";
		} else {
			return "login";
		}
	}
	
	@GetMapping("/logOut")
	public String logOut() {
		return "logout";
	}


	@GetMapping("/demo")
	public String getAudio() {
		return "audio";
	}
	
	@PostMapping("/logOut")
	public void exit(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("username") String username, @RequestParam("password") String password) {
		AtomicBoolean sucess = new AtomicBoolean(false);
		List<User> listUser = userRepository.findAll();
		listUser.forEach(one -> {
			if (one.getUsername().equals(username) && one.getPassword().equals(password)) {
				sucess.set(true);
				request.getSession().removeAttribute(username);
			}
		});	
		if (sucess.get()) {
			log.info("success removed user info in session.");
		} else {
			log.info("user is not exist in session.");
		}
		response.setStatus(200);
		try {
			response.getWriter().write("sucess logout!");
			response.setStatus(200);
		} catch (IOException e) {
			try {
				response.sendError(500, e.getMessage());
				response.setStatus(500);
			} catch (IOException e1) {				
				e1.printStackTrace();
			}
		}
	}

	@GetMapping(value = "/get-image-with-media-type", produces = MediaType.IMAGE_JPEG_VALUE)
	public @ResponseBody byte[] getImageWithMediaType() throws IOException {
		InputStream in = getClass().getResourceAsStream("/com/baeldung/produceimage/image.jpg");
		return IOUtils.toByteArray(in);
	}

}
