package com.nec.aim.uid.client.manager;

import static com.nec.aim.uid.client.common.UidClientConstants.COMMON_PROPERTY_FULL_NAME;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_CONCURRENT_COUNT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_NOBLOCKING;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_POST_TIMEOUT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_SERVICES_URLS;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_WEB_CONTENT;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_REQUEST_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_RESULT_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_TEMPLATES_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.MONITOR_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_HEATBEAT_INTERVAL;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_SOCKET_PORT;

import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.proerties.PropertyNames;
import com.nec.aim.uid.client.proerties.PropertyUtil;

public class UidCommonManager {
	public static final UidCommonManager manager = new UidCommonManager();
	private static final ConcurrentHashMap<String, String> keyValueMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger(UidCommonManager.class);
	
	//private static final Random sRandom = new Random(System.currentTimeMillis());

	public UidCommonManager() {		
	}

	public static UidCommonManager getInstance() {
		return manager;
	}	
	
	public int getMapSize() {
		return keyValueMap.size();
	}

	public void putData(String key, String value) {
		keyValueMap.putIfAbsent(key, value);
	}

	public static String getValue(String key) {
		return keyValueMap.get(key);
	}	

	
	public void getBasePath() {
		String myPath = UidCommonManager.class.getProtectionDomain().getCodeSource().getLocation().getPath();		
		String dmBaseDir = myPath.substring(0, myPath.length() - 17);			
		//URL myUrl = Thread.currentThread().getContextClassLoader().getResource(""); it's ok too
		//URL configUrl = Thread.currentThread().getContextClassLoader().getResource("config");		
		String commonProperyFullPath = dmBaseDir + "/" + "config" + "/" + "dm.common.properties";
		String loggerPath =  dmBaseDir + "/" + "config" + "/" + "log4j.properties";
		PropertyConfigurator.configure(loggerPath);		
		String jobReqeustPath = dmBaseDir + "/" + "jobrequests";		
		String templatesPath = dmBaseDir + "/" + "templates";		
		String jobresultPath = dmBaseDir + "/" + "jobresults";
		String monitorPath = dmBaseDir + "/" + "monitor";
		keyValueMap.putIfAbsent(COMMON_PROPERTY_FULL_NAME, commonProperyFullPath);		
		keyValueMap.putIfAbsent(JOB_REQUEST_PATH, jobReqeustPath);
		keyValueMap.putIfAbsent(JOB_RESULT_PATH, jobresultPath);
		keyValueMap.putIfAbsent(MONITOR_PATH, monitorPath);
		keyValueMap.putIfAbsent(JOB_TEMPLATES_PATH, templatesPath);	
	}	

	public boolean getAllProperties() {
		getBasePath();		
		try {
			String propertyFileFullName = keyValueMap.get(COMMON_PROPERTY_FULL_NAME);	
			PropertyUtil util = new PropertyUtil(propertyFileFullName);		
			//for dm	       
	            String dmWebContent = util.getPropertyValue(PropertyNames.DM_WEB_CONTENT.name());
	            if (Objects.isNull(dmWebContent)) {
	                logger.error("mm web content is empty!");               
	                return false;
	            }
	            keyValueMap.putIfAbsent(DM_WEB_CONTENT , dmWebContent);
			String dmConnectionString = util.getPropertyValue(PropertyNames.DM_SERVICE_CONN_STR.name());
			if (!dmConnectionString.isEmpty()) {
				keyValueMap.putIfAbsent(DM_SERVICES_URLS , dmConnectionString);
			}
			String dmSocketPort = util.getPropertyValue(PropertyNames.DM_SOCKET_PORT.name());
			if (!dmSocketPort.isEmpty()) {
				keyValueMap.putIfAbsent(DM_SOCKET_PORT , dmSocketPort);
			}
			String dmConcurrentCount = util.getPropertyValue(PropertyNames.DM_CONCURRENT_COUNT.name());
			if (dmConcurrentCount != null && !dmConcurrentCount.isEmpty()) {
				keyValueMap.putIfAbsent(DM_CONCURRENT_COUNT , dmConcurrentCount);
			}
			
			String isBlocking = util.getPropertyValue(PropertyNames.DM_NOBLOCKING.name());
			if (isBlocking != null && !isBlocking.isEmpty()) {
				keyValueMap.putIfAbsent(DM_NOBLOCKING , isBlocking);
			}
			
			String postTimeout = util.getPropertyValue(PropertyNames.DM_POST_TIMEOUT.name());
			if (postTimeout != null && !postTimeout.isEmpty()) {
				keyValueMap.putIfAbsent(DM_POST_TIMEOUT , postTimeout);
			}
			
			String heabeatInval = util.getPropertyValue(PropertyNames.DM_HEATBEAT_INTERVAL.name());
			if (heabeatInval != null && !heabeatInval.isEmpty()) {
				keyValueMap.putIfAbsent(DM_HEATBEAT_INTERVAL , heabeatInval);
			}			

			return true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return false;
		} finally {			
		}
	}
	
	public void shutdown() {
		keyValueMap.clear();
	}
}
