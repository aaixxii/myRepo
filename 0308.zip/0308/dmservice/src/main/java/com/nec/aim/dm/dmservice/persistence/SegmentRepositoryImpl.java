package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.SegmentInfo;

@Repository
public class SegmentRepositoryImpl implements SegmentRepository {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	private static final String insertSql = "insert into segments_info(external_id,bio_id_start, bio_id_end, binary_length, record_count, version , update_ts) values (?,?,?,?,?,?,CURRENT_TIMESTAMP()";			
	private static final String updateSql = "update segments_info set bio_id_end=? ,binary_length=binary_length + ?, record_count=record_count+1, version =version +1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
	private static final String delBioSql = "delete from segments_info where segment_id =? and bio_id_start <= ? and bio_id_end >= ? and external_id = ?";	
	private static final String updateAfterDelSql = "update segments_info binary_length=binary_length - ?, record_count=record_count-1, version =version +1, update_ts =CURRENT_TIMESTAMP() where segment_id =?";
	private static final String setFaildSegmentVer = "update segments_info  set version = -9, update_ts =CURRENT_TIMESTAMP() where segment_id =? and external_id=?";
	private static final String setSuccessSegmentVer = "update segments_info  set version = -1, update_ts =CURRENT_TIMESTAMP() where segment_id =0 and external_id=''";
	
	@Override
	public void insertSegment(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.update(insertSql, new Object[] {segInfo.getExternalId(),segInfo.getBioIdStart(), segInfo.getBioIdEnd(), segInfo.getBinaryLegth(),segInfo.getRecordCount(),segInfo.getVersion()});
	}

	@Override
	public void updateSegment(SegmentInfo segInfo) {
		jdbcTemplate.update(updateSql, new Object[] {segInfo.getBioIdEnd(), segInfo.getBinaryLegth(), segInfo.getSegmentId()});		
	}

	@Override
	public void deleteBioFromSegment(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.update(delBioSql, new Object[] {segInfo.getSegmentId(), segInfo.getBioIdStart(), segInfo.getBioIdEnd(), segInfo.getBinaryLegth(), segInfo.getExternalId()});
	}

	@Override
	public void updateSegmentAfterDelete(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.update(updateAfterDelSql, new Object[] {segInfo.getBinaryLegth(), segInfo.getSegmentId()});
	}
	
	@Override
	public void setFaildSegmentVer(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.update(setFaildSegmentVer, new Object[] {segInfo.getSegmentId(), segInfo.getExternalId()});
	}

	@Override
	public void setSuccessSegmentVer(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.update(setSuccessSegmentVer, new Object[] {segInfo.getSegmentId(), segInfo.getExternalId()});
	}

	@Override
	public void updateAfterNew(boolean faild, long segmentId) throws SQLException {
		// TODO Auto-generated method stub
		
	}
}
