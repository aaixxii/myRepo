package com.nec.aim.dm.dmservice.dispatch;


import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.dmservice.entity.NodeStorage;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentLoadRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class Dispatcher {
	
	@Autowired
	NodeStorageRepository nodeRepository;
	
	@Autowired
	DmConfigRepository dmConfigRepository;
	
	@Autowired
	SegmentLoadRepository segmentLoadRepository;
	
	@Autowired
	SegmentRepository segmentRepository;	
	
	
	public Boolean handlePostRequest(PBDmSyncRequest dmSegReq) throws SQLException {
 		PBTemplateInfo templateInfo = null;
 		String changeType = null;
 		long bioId = -9999;
 		String externalId = null;
 		byte[] templateData = null;
 		long segId = -9999;
 		long segVer = -9999;
		try {
			changeType = dmSegReq.getCmd().name().toUpperCase();
			bioId = dmSegReq.getBioId();
			if (dmSegReq.hasTemplateData()) {
				templateInfo = dmSegReq.getTemplateData();
				if (templateInfo.hasReferenceId()) {
					externalId = templateInfo.getReferenceId();
				}				
				if (templateInfo.hasData()) {
					templateData = templateInfo.getData().toByteArray();
				}				
			}			
			segId = dmSegReq.getTargetSegments().getId();
			segVer = dmSegReq.getTargetSegments().getVersion();			
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
		
		if (changeType == null || changeType.isEmpty() || Objects.isNull(templateData) || bioId < 0 || segId  < 0 || segVer < 0) {
			throw new DmServiceException("Reqeust parameter invaild!");
		}
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(segId);
		segInfo.setBioIdStart(bioId);
		segInfo.setBioIdEnd(bioId);
		segInfo.setExternalId(externalId);
		segInfo.setVersion(segVer);
		segInfo.setBinaryLegth(templateData.length);
		
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segId);
		segLoading.setDataSize(templateData.length);
		segLoading.setLastVersion(segVer);		
		segLoading.setStatus(0);
		
	   int redundancy = dmConfigRepository.getRedundancy();		
		List<NodeStorage> activeNodeStorages = nodeRepository.findNeedNodeByRedundancy(templateData.length, redundancy);
		if (activeNodeStorages == null ||  activeNodeStorages .size() < 1) {
			return Boolean.valueOf(false);
		}
		
		if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) {
			activeNodeStorages.forEach(one -> {				
				segLoading.setStorage_id(one.getStorageId());
				try {
					segmentRepository.insertSegment(segInfo);
					segmentLoadRepository.insertSegmentLoad(segLoading);					
				} catch (Exception e) {
					throw new DmServiceException(e);
					
				}
			});
			
		} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
            activeNodeStorages.forEach(one -> {
            	segLoading.setStorage_id(one.getStorageId());
            	try {
					segmentRepository.updateSegment(segInfo);
					segmentLoadRepository.updateSegmentLoadNoMailFlag(segLoading);
				} catch (SQLException e) {
					throw new DmServiceException(e);
				}
			});
			
		} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) {			
            activeNodeStorages.forEach(one -> {
            	segLoading.setStorage_id(one.getStorageId());
            	try {
					segmentRepository.deleteBioFromSegment(segInfo);
					segmentRepository.updateSegmentAfterDelete(segInfo);
					segmentLoadRepository.delBioFromSegmentLoadNoMailFlag(segLoading);
				} catch (SQLException e) {
					throw new DmServiceException(e);
				}
			});			
		}
		
		boolean lastResut = true;
		 
		for (NodeStorage one : activeNodeStorages) {
			 boolean oneResult = HttpPoster.post(one.getUrl(), dmSegReq);
			 lastResut = lastResut || oneResult;
			if (oneResult == false) {
				nodeRepository.setMailFlag(one.getStorageId(), one.getDmStorageid());
				segmentRepository.setFaildSegmentVer(segInfo);
			} else {
				segmentRepository.setSuccessSegmentVer(segInfo);
			}
		}	
		return Boolean.valueOf(lastResut);
	}
	
	public byte[] dispatchGetRequest(Long segId) throws InterruptedException, ExecutionException, SQLException {
		List<NodeStorage> activeList = nodeRepository.findAll();
		if (activeList == null ||  activeList .size() < 1) {
			throw new DmServiceException("No active dm stroage node for process");
		}
		Collections.shuffle(activeList);
		byte[] result = HttpPoster.getSegment(activeList.get(0).getUrl(), segId);
		return result;
	}
}
