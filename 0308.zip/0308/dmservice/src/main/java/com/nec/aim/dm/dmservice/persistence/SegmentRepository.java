package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import com.nec.aim.dm.dmservice.entity.SegmentInfo;

public interface SegmentRepository {
	
	public void insertSegment(SegmentInfo segInfo)  throws SQLException;
	public void updateSegment(SegmentInfo segInfo)  throws SQLException;	
	public void deleteBioFromSegment(SegmentInfo segInfo)  throws SQLException;
	public void updateSegmentAfterDelete(SegmentInfo segInfo)  throws SQLException;	
	public void setFaildSegmentVer(SegmentInfo segInfo) throws SQLException;
	public void setSuccessSegmentVer(SegmentInfo segInfo) throws SQLException;
	public void updateAfterNew(boolean faild, long segmentId)throws SQLException;
}
