package com.nec.aim.uid.client.common;

public class UidClientConstants {
	
	public static final String COMMON_PROPERTY_FULL_NAME = "dm.common.properties";	 //fullName with path	
	public static final String JOB_REQUEST_PATH = "jobReqeustPath";	
	public static final String JOB_TEMPLATES_PATH = "jobTemplatesPath";		
	public static final String JOB_RESULT_PATH = "jobresultPath";
	public static final String MONITOR_PATH = "monitorPath";
	
	public static final String  DM_WEB_CONTENT = "dmWebContent";    
	public static final String  DM_SERVICES_URLS = "dmServiceUrls";
	public static final String  DM_CONCURRENT_COUNT = "dmConcurrentThreadCount";
	
	public static final String  DM_REQ_CMD = "dmReqCmd";
	public static final String  DM_REQ_BIO_ID = "dmReqBioId";
	public static final String  DM_REQ_REF_ID = "dmReqExternalId";
	public static final String  DM_REQ_TEMPLATE_DATA_PATH = "dmReqTemplateDataPath";
	public static final String  DM_REQ_SEG_ID = "dmReqSegID";
	public static final String  DM_REQ_SEG_VER = "dmReqSegVer";
	public static final String  DM_DOWNLOAD_SEG_ID = "dmDownloadSegId";
	public static final String  DM_NOBLOCKING = "dmNoblocking";
	public static final String  DM_POST_TIMEOUT = "dmPostTimeOut";
	
	public static final String SLASH = "/";	

}
