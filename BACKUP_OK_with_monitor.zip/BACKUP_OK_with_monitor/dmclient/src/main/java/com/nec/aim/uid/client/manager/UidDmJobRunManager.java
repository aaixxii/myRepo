package com.nec.aim.uid.client.manager;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UidDmJobRunManager {

	private static Logger logger = LoggerFactory.getLogger(UidDmJobRunManager.class);
	private static ExecutorService dmJobExecutor = Executors.newCachedThreadPool();
	private static ExecutorService monitorExecutor = Executors.newSingleThreadExecutor();

	public static void submitRunnable(Runnable task) {
		dmJobExecutor.submit(task);
	}

	public static void commitMonitorTask(Runnable task) {
		monitorExecutor.submit(task);
	}

	public static Boolean sumitDmJob(Callable<Boolean> task) {
		Future<Boolean> future = dmJobExecutor.submit(task);
		try {
			return future.get();
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.FALSE;
		}
	}

	public static <T> CompletableFuture<T> callableAsync(Callable<T> c) {
		CompletableFuture<T> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());

			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf;
	}

	public static Boolean submit(Callable<Boolean> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Boolean> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

	public static byte[] submitGetRequest(Callable<byte[]> c) throws InterruptedException, ExecutionException {
		CompletableFuture<byte[]> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

	public static void shutdown() {
		dmJobExecutor.shutdown();
	}
}
