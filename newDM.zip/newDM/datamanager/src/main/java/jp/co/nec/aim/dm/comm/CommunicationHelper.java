package jp.co.nec.aim.dm.comm;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jp.co.nec.aim.dm.constants.SegmentStatusValue;
import jp.co.nec.aim.dm.manager.SegmentFileManager;
import jp.co.nec.aim.dm.manager.SegmentFileStateSnapshot;
import jp.co.nec.aim.dm.util.HttpPoster;
import jp.co.nec.aim.dm.util.HttpResponseInfo;
import jp.co.nec.aim.dm.wakeup.WakeUpEventDispatcher;
import jp.co.nec.aim.dm.wakeup.WakeUpThreadExecutor;
import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBAbilityInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBExitRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBHeartBeatResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentInfo;

import org.apache.http.HttpException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The helper of Communication
 * 
 * @author liuyq
 * 
 */
public class CommunicationHelper {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(CommunicationHelper.class);

	private SegmentFileManager sfm; // segment file manage
	private ExecutorService service; // new thread listen UDP port
	private WakeUpEventDispatcher dispatcher; // event dispatcher
	private final String uniqueId; // uniqueId
	private final String urlBase; // urlBase
	private final String enterURL; // "/matchmanager/Enter"
	private final String heartbeatURL; // "/matchmanager/HeartBeat"
	private final String contactURL; // DM contact URL
	private final String version; // version
	private final int soTimeOut; // socket timeout
	private Long unitId; // DM unit id after enter
	private SegmentCatchUp catchUp; // the common of segment catch up

	/**
	 * CommunicationHelper default constructor
	 */
	public CommunicationHelper(String uniqueId, String urlBase,
			String enterURL, String heartbeatURL, String contactURL,
			String version, int soTimeOut) {
		this.sfm = SegmentFileManager.getInstance();
		this.catchUp = new SegmentCatchUp();
		this.uniqueId = uniqueId;
		this.urlBase = urlBase;
		this.enterURL = enterURL;
		this.heartbeatURL = heartbeatURL;
		this.contactURL = contactURL;
		this.version = version;
		this.soTimeOut = soTimeOut;
	}

	/**
	 * send Enter event to MM
	 * 
	 * @return the DM id from MM
	 */
	public Long sendEnter() {
		final PBComponentInfo info = createComponentInfo();
		try {
			HttpResponseInfo httpResponse = HttpPoster.post(enterURL,
					info.toByteArray(), true, soTimeOut);
			// 200 HTTP SC_OK
			if (httpResponse.isOK()) {
				final PBEnterResponse response = PBEnterResponse
						.parseFrom(httpResponse.getBytes());
				log.debug("Successful enter() call, received temp id: "
						+ response.getId());

				// must catch up the segment differences
				catchUp.segmentCatchUp(response.getSegmentUpdatesList());

				// set unit id when entered successfully
				this.unitId = response.getId();

				// Listening UDP wakeUp port asynchronously
				wakeupListener(response);

				return response.getId();
			} else {
				log.error("Bad HTTP return code from MM: "
						+ httpResponse.getStatusCode());
			}
		} catch (HttpException e) {
			log.error("HttpException in DM communication thread", e);
		} catch (IOException e) {
			log.error("IOException in DM communication thread", e);
		}
		return null;
	}

	/**
	 * send heartBeat
	 */
	public boolean sendHeartbeat() {
		final PBComponentInfo info = createComponentInfo();
		try {
			HttpResponseInfo httpResponse = HttpPoster.post(heartbeatURL,
					info.toByteArray(), true, soTimeOut);
			if (httpResponse.isOK()) {
				final PBHeartBeatResponse response = PBHeartBeatResponse
						.parseFrom(httpResponse.getBytes());
				if (response.getWrongState()) {
					log.error("Received WRONG STATE error, re-entering...");
					return true; // force re-enter on next iteration.
				}

				log.debug("Successful heartbeat() call.");

				log.debug("Ready to catch up the segment..");
				catchUp.segmentCatchUp(response.getSegmentUpdatesList());
			} else {
				log.error("Bad HTTP return code from MM: "
						+ httpResponse.getStatusCode());
			}
			// lastReportTime = new Date();
		} catch (HttpException e) {
			log.error("HttpException in DM communication thread", e);
		} catch (IOException e) {
			log.error("IOException in DM communication thread", e);
		}
		return false;
	}

	/**
	 * send request to MM exit servlet
	 */
	public void sendExit() {
		try {
			String exitUrl = urlBase + "/Exit";

			PBExitRequest.Builder builder = PBExitRequest.newBuilder();
			builder.setComponent(ComponentType.DATA_MANAGER);
			builder.setId(unitId);
			HttpResponseInfo response = HttpPoster.post(exitUrl, builder
					.build().toByteArray(), true, soTimeOut);
			if (response.isOK()) {
				if (log.isDebugEnabled()) {
					log.debug("Successful exit() call" + exitUrl);
				}
			} else {
				log.error("Bad HTTP return code from MM: "
						+ response.getStatusCode());
			}
		} catch (HttpException e) {
			log.error("HttpException at sending Exit", e);
		}
	}

	/**
	 * Create new thread to listening UDP wakeUp port, Once new connection is
	 * reached, create new thread to hander, we receive the information like
	 * [1,2,3,4]. if notify information contains this DM id, generate the
	 * PBComponentInfo and push it to MM immediately
	 * 
	 * @param response
	 *            the instance of PBEnterResponse
	 */
	private void wakeupListener(final PBEnterResponse response) {
		if (dispatcher != null && dispatcher.isListening()) {
			if (log.isDebugEnabled()) {
				log.debug("dispatcher already running, skip listening UDP port..");
			}
			return;
		}

		if (response.hasWakeUpNotifyPort()) {
			final int port = response.getWakeUpNotifyPort();
			if (port <= 0 || port > 65535) {
				log.error("Wake Up UDP Notify Port: {}" + " is out of range..",
						port);
				return;
			}

			// Create a new thread to listening UDP wakeUp port
			// Once new connection is reached, create new thread
			// to hander, we receive the information like [1,2,3,4]
			// if notify information contains this DM id, generate
			// the PBComponentInfo and push it to MM immediately
			service = Executors.newSingleThreadExecutor();
			dispatcher = new WakeUpEventDispatcher(port, unitId, this);
			service.execute(dispatcher);// DM contact URL;
		} else {
			log.warn("Wake Up UDP Notify Port is not specified from MM..");
		}
	}

	/**
	 * construct SegmentReport
	 * 
	 * @param snapShots
	 *            SegmentFileStateSnapshot list
	 * @return constructed PBSegmentInfo instance
	 */
	private static List<PBSegmentInfo> constructSegmentReport(
			Collection<SegmentFileStateSnapshot> snapShots) {
		List<PBSegmentInfo> segmentInfos = new ArrayList<PBSegmentInfo>();
		for (SegmentFileStateSnapshot snapShot : snapShots) {
			SegmentStatusValue statusVal = snapShot.getStatusValue();

			// We will not send the segment information
			// that status is in NOT_REPORTED
			if (statusVal.isStateAllowed()) {
				PBSegmentInfo.Builder segmentInfo = PBSegmentInfo.newBuilder();
				segmentInfo.setId(snapShot.getSegmentId());
				setSegState(statusVal, segmentInfo);
				Integer version = snapShot.getVersion();
				version = (version == null ? -1 : version);
				segmentInfo.setVersion(version);
				segmentInfo.setQueuedVersion(version);
				segmentInfos.add(segmentInfo.build());
			} else {
				log.info("Segment in State: {}, skip construct SegmentReport.",
						statusVal.name());
			}
		}
		return segmentInfos;
	}

	/**
	 * set segment state
	 * 
	 * @param statusVal
	 *            SegmentStatusValue
	 * @param segmentInfo
	 *            PBSegmentInfo builder
	 */
	private static void setSegState(SegmentStatusValue statusVal,
			PBSegmentInfo.Builder segmentInfo) {

		switch (statusVal) {
		case IN_MEMORY:
			segmentInfo.setState(SegmentStateType.SEGMENT_STATE_MEMORY);
			break;
		case ON_DISK:
			segmentInfo.setState(SegmentStateType.SEGMENT_STATE_DISK);
			break;
		case CURRENTLY_DOWNLOADING:
			segmentInfo.setState(SegmentStateType.SEGMENT_STATE_DOWNLOADING);
			break;
		case QUEUED_FOR_DOWNLOAD:
			segmentInfo
					.setState(SegmentStateType.SEGMENT_STATE_DOWNLOADQUEUING);
			break;
		default:
			log.warn("The segment status {} is not support.", statusVal.name());
			return;
		}
	}

	/**
	 * construct ResourceReport
	 * 
	 * @return the instance of PBAbilityInfo
	 */
	public static PBAbilityInfo constructResourceReport() {
		PBAbilityInfo.Builder b = PBAbilityInfo.newBuilder();
		b.setPrimarySize(0L);
		b.setSecondarySize(0L);
		return b.build();
	}

	/**
	 * create ComponentInfo
	 * 
	 * @return PBComponentInfo instance
	 */
	private PBComponentInfo createComponentInfo() {
		final PBComponentInfo.Builder info = PBComponentInfo.newBuilder();
		info.setComponent(ComponentType.DATA_MANAGER); // DATA_MANAGER
		info.setUniqueId(uniqueId); // uniqueId
		info.setContactUrl(contactURL); // contactURL
		info.setVersion(version); // version

		// segmentMapChanged is always false when enter
		PBResourceInfo.Builder resourceInfo = info.getResourceInfoBuilder()
				.setSegmentMapChanged(false);
		// abilityInfo
		resourceInfo.setAbilityInfo(CommunicationHelper
				.constructResourceReport());
		// segmentInfo
		Collection<SegmentFileStateSnapshot> snapShots = sfm.getSnapshots();
		resourceInfo.addAllSegmentInfo(CommunicationHelper
				.constructSegmentReport(snapShots));
		return info.build();
	}

	/**
	 * setUnitId
	 * 
	 * @param unitId
	 */
	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

	/**
	 * close the dispatcher and service
	 */
	public void close() {
		if (dispatcher != null) {
			dispatcher.closeSocket();
		}

		WakeUpThreadExecutor.getInstance().stopInternal();

		if (service != null) {
			service.shutdown();
		}
	}

}
