package jp.co.nec.aim.dm.manager;

import java.io.File;
import java.io.FilenameFilter;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.nec.aim.dm.constants.DMConstants;
import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.exception.DataManagerException;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SegmentFileInventory {

	private static Logger log = LoggerFactory.getLogger(SegmentFileInventory.class);

	public static ConcurrentHashMap<Integer, SegmentFileState> initializeSegFileStates() {
		// populate hash map
		boolean validateSegmentsOnStartup = readValidateOnStartUp();
		log.info("Datamanager validate segments on startup is " + validateSegmentsOnStartup);
		File[] segFiles = fetchSegmentFiles("Datamanager about to initialize segment files");
		ConcurrentHashMap<Integer, SegmentFileState> stateMap = new ConcurrentHashMap<Integer, SegmentFileState>();
		if (segFiles != null) {
			int numCorrectFiles = 0;
			int numErroredFiles = 0;
			for (File segFile : segFiles) {
				Integer segId = SegmentFileName.getSegmentIdFromName(segFile
						.getName());
				try {
					Long segVersion = SegmentFileIntegrityChecker.checkFile(
							segFile, segId, validateSegmentsOnStartup);
					if (segVersion != null) {
						numCorrectFiles++;
						log.debug("Datamanager loading segment from disk: "
								+ segId);
						SegmentFileState state = SegmentFileState.newInstance(
								segId, segVersion.intValue());
						stateMap.put(segId, state);
					} else {
						log.warn("Skipping load of segment " + segId
								+ ", because file is corrupt");
						segFile.delete();
						numErroredFiles++;
					}
				} catch (DataManagerException e) {
					log.warn("DataManagerException while reading segment "
							+ segId
							+ " during initial segment inventory... treating file as corrupt.",
							e);
					segFile.delete();
					numErroredFiles++;
				}

			}
			log.debug("Successfully initialized " + numCorrectFiles
					+ " files from disk. Found " + numErroredFiles
					+ " errored files while reading from disk.");
		}
		return stateMap;
	}

	static File[] fetchSegmentFiles(String message) {
		String dirName = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		log.info(message + " in directory: '" + dirName);
		Validate.isTrue(StringUtils.isNotBlank(dirName),
				"Segment file directory name cannot be blank");
		File dir = new File(dirName);
		FilenameFilter segFileFilter = new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.endsWith(DMConstants.SEG_FILE_EXTENSION);
			}
		};
		return dir.listFiles(segFileFilter);
	}

	private static boolean readValidateOnStartUp() {
		boolean validateSegmentsOnStartup = false;
		String validateProp = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.VALIDATE_SEGMENTS_ON_STARTUP, false);
		if (validateProp != null) {
			validateSegmentsOnStartup = Boolean.parseBoolean(validateProp);
		}
		return validateSegmentsOnStartup;
	}
}
