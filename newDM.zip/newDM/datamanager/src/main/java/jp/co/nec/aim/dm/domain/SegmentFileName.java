package jp.co.nec.aim.dm.domain;

import jp.co.nec.aim.dm.constants.DMConstants;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;

import org.apache.commons.lang.StringUtils;

public class SegmentFileName {

	private String name;

	public SegmentFileName(Integer segmentId) {
		String directory = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		StringBuffer segFilename = new StringBuffer();
		segFilename.append(directory);
		if (!directory.endsWith("/")) {
			segFilename.append("/");
		}
		segFilename.append(segmentId);
		segFilename.append(DMConstants.SEG_FILE_EXTENSION);
		this.name = segFilename.toString();
	}

	public String getName() {
		return name;
	}

	public static Integer getSegmentIdFromName(String name) {
		return new Integer(StringUtils.removeEnd(name,
				DMConstants.SEG_FILE_EXTENSION));
	}

	public String toString() {
		return name;
	}

	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final SegmentFileName other = (SegmentFileName) obj;
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}

}
