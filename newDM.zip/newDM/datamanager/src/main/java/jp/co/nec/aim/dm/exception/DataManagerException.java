/**
 * 
 */
package jp.co.nec.aim.dm.exception;

/**
 * @author RKumarak
 * 
 */
public class DataManagerException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1287506188023072691L;

	/**
	 * @param message
	 */
	public DataManagerException(String message) {
		super(message);

	}

	/**
	 * @param cause
	 */
	public DataManagerException(Throwable cause) {
		super(cause);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public DataManagerException(String message, Throwable cause) {
		super(message, cause);

	}

}
