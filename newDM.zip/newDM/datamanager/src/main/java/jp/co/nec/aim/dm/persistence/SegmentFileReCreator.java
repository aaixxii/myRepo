package jp.co.nec.aim.dm.persistence;

import jp.co.nec.aim.dm.exception.SegmentFileWritingException;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.util.StopWatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * this class is used for reCreate the segment.. while the version different
 * between server and file is over than max_segment_diff threshold value <br>
 * first delete the segment if exist <br>
 * secondly reCreate the specified segment <br>
 */
public class SegmentFileReCreator implements SegmentFileWriter,
		ApplicationContextAware {

	private static final Logger log = LoggerFactory
			.getLogger(SegmentFileReCreator.class);
	private SegmentFileWriter segmentFileDeleter;
	private SegmentFileWriter segmentFileCreator;

	public SegmentFileReCreator() {
	}

	public synchronized String getJobState() {
		return segmentFileCreator.getJobState();
	}

	@Override
	public SegmentFileWriteResult execute(int segmentId, Integer version) {
		return execute(segmentId);
	}

	public SegmentFileWriteResult execute(int segmentId)
			throws SegmentFileWritingException {
		log.info("start to re create the segment id: {} due to "
				+ "the version different is over than "
				+ "max_segment_diff threshold value..", segmentId);
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		// first delete the specified segment
		segmentFileDeleter.execute(segmentId, null);
		stopWatch.stop();
		long delElapsedTime = stopWatch.elapsedTime();
		log.info("delete segment excute time {} ms..", delElapsedTime);

		// second create the segment with specified segment id
		SegmentFileWriteResult result = segmentFileCreator.execute(segmentId, null);
		stopWatch.stop();
		long reCreateElapsedTime = stopWatch.elapsedTime();
		log.info("create segment excute time {} ms..", reCreateElapsedTime - delElapsedTime);

		log.info("reCreate the segment id: {} successfully..", segmentId);

		PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
				.getSimpleName(), LogConstants.FUNCTION_execute, reCreateElapsedTime);

		return result;
	}

	@Override
	public void setApplicationContext(ApplicationContext context)
			throws BeansException {
		this.segmentFileCreator = (SegmentFileCreator) context
				.getBean("segmentFileCreator");
		this.segmentFileDeleter = (SegmentFileDeleter) context
				.getBean("segmentFileDeleter");
	}
}
