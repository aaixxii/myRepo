package jp.co.nec.aim.dm.manager;

import java.io.File;
import java.util.Map;

import jp.co.nec.aim.dm.domain.IndexFile;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.util.StopWatch;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;

public class IndexFileCreator {
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");
	private static final String FILE_SEPARATOR = System.getProperty("file.separator");
	
	@Option(name="-f", metaVar="segmentFile", usage="specify the segmentFile path") 
	private String segmentFile;
	
	@Option(name="-h", aliases="--help", usage="print usage message and exit")
	private boolean usageFlag;

	public static void main(String[] args) {
		IndexFileCreator creator = new IndexFileCreator();
		CmdLineParser parser = new CmdLineParser(creator);
        try {
            parser.parseArgument(args);
        } catch (CmdLineException e) {
            e.printStackTrace();
        	printUsage();
            return;
        }
        
        if(creator.usageFlag) {
        	printUsage();
        	return;
        }
        creator.saveIndexFiles();
	}

	private static  void printUsage() {
		StringBuffer sb = new StringBuffer();
		sb.append("Usage:");
		sb.append(LINE_SEPARATOR);
		sb.append(" IndexFileCreator -f (segment file path)");
		sb.append(LINE_SEPARATOR);
		sb.append(" search (segment file directory) and create .index.* into it");
		System.out.println(sb.toString());
	}

	private void saveIndexFiles() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		File segFile = new File(segmentFile);
		String name = segFile.getName();
		int lastIndex = name.lastIndexOf(".");
		Map<Long, Long> indexMap = IndexManager.getInstance().createIndexMap(segFile.getPath());
		int segmentId = Integer.valueOf(name.substring(0, lastIndex)).intValue();
		
		String segFilePath = segFile.getPath();
		int index = segFilePath.lastIndexOf(FILE_SEPARATOR);
		String indexFilePath = segFilePath.substring(0, index) + FILE_SEPARATOR + "."
				+ String.format(IndexFile.FORMAT, segmentId) + "." + IndexFile.SUFFIX;
		IndexManager.getInstance().saveIndexMap(indexMap, indexFilePath);

		stopWatch.stop();
		PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass().getSimpleName(),
				Thread.currentThread().getStackTrace()[1].getMethodName(), stopWatch.elapsedTime());
	}

}
