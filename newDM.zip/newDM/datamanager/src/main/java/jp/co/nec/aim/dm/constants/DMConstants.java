package jp.co.nec.aim.dm.constants;

public class DMConstants {
	private static final int ONE_MEGABYTE = 1048576;
	public static final String JAXB_CONTEXT = "jp.co.nec.aim.mm.jaxb";
	public static final String JAXB_VIEW_CONTEXT = "jp.co.nec.aim.dm.jaxb.view";
	public static String SEG_FILE_EXTENSION = ".seg";
	public static final int BYTE_BUFFER_SIZE = 10 * ONE_MEGABYTE;

	public static final int MAX_PACKET_SIZE = 1024;
}
