package jp.co.nec.aim.dm.util;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import jp.co.nec.aim.dm.properties.DynamicProperties;

/**
 * DownLoadLimiter
 * 
 * @author liuyq
 * 
 */
public class DownLoadLimiter {
	private final Integer limit; // max limit value
	private final AtomicInteger current; // current

	/**
	 * default DownLoadLimiter constructor
	 */
	private DownLoadLimiter() {
		this.limit = DynamicProperties.getInstance().getDownloadLimit();
		this.current = new AtomicInteger(0);
	}

	/**
	 * 
	 * @param limit
	 */
	private DownLoadLimiter(int limit) {
		this.limit = limit;
		this.current = new AtomicInteger(0);
	}

	public Integer getCurrent() {
		return this.current.get();
	}

	/**
	 * Is allow to download
	 * 
	 * @return
	 */
	public boolean isAllowable() {
		return (current.incrementAndGet() < limit);
	}

	/**
	 * finished
	 */
	public void finished() {
		current.decrementAndGet();
	}

	/**
	 * get value of max limit
	 * 
	 * @return max limit
	 */
	public Integer getLimit() {
		return limit;
	}

	/**
	 * SingletonHolder
	 * 
	 * @author liuyq
	 * 
	 */
	static class SingletonHolder {
		public static final DownLoadLimiter DOWNLOAD_LIMITER = new DownLoadLimiter();
	}

	public static DownLoadLimiter getInstance() {
		return SingletonHolder.DOWNLOAD_LIMITER;
	}

	/**
	 * only for test
	 * 
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		final DownLoadLimiter limiter = new DownLoadLimiter(50);
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(100);
			List<Callable<Boolean>> tasks = new ArrayList<Callable<Boolean>>();
			for (int i = 0; i < 10000; i++) {
				tasks.add(new Callable<Boolean>() {
					@Override
					public Boolean call() throws Exception {
						if (!limiter.isAllowable()) {
							// System.out.println("Thread name: "
							// + Thread.currentThread().getName()
							// + " alreay over limit: "
							// + limiter.getLimit() + ", Current: "
							// + limiter.getCurrent());
							return false;
						}
						try {

							System.out.println("Thread name: "
									+ Thread.currentThread().getName()
									+ " not over limit: " + limiter.getLimit()
									+ ", Current: " + limiter.getCurrent());

							return true;
						} finally {
							// Random random = new Random();
							// Thread.sleep(random.nextInt(100));
							limiter.finished();
						}
					}
				});
			}
			service.invokeAll(tasks);
		} finally {
			if (service != null) {
				service.shutdown();
			}
		}
	}
}
