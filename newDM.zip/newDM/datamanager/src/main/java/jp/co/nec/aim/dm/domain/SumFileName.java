package jp.co.nec.aim.dm.domain;

import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;


public class SumFileName {
	private final static int NAME_LENGTH = 6;
	private final static String FORMAT = String.format("%%0%dd",
			NAME_LENGTH);
	public static final String EXTENTION = ".sum";

	private String name;

	public SumFileName(long segmentId) {
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		StringBuffer sb = new StringBuffer();
		sb.append(dir);
		if (!dir.endsWith("/")) {
			sb.append("/");
		}
		sb.append(".");
		sb.append(String.format(FORMAT, segmentId));
		sb.append(EXTENTION);
		this.name = sb.toString();
	}

	public String getName() {
		return name;
	}

}
