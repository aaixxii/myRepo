/**
 * 
 */
package jp.co.nec.aim.dm.persistence;

import org.junit.Ignore;

import junit.framework.TestCase;

/**
 * @author RKumarak
 * 
 */
@Ignore
public class SegmentFileCompactorTest extends TestCase {

	public void testExecute() {

		SegmentFileCompactor segFileCompaction = new SegmentFileCompactor();
		int id = 109867;
		SegmentFileWriteResult fwr = segFileCompaction.execute(id);
		assertTrue(fwr != null);

	}

}