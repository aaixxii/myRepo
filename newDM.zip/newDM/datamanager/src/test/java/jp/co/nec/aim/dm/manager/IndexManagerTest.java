package jp.co.nec.aim.dm.manager;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import jp.co.nec.aim.dm.domain.IndexFile;
import jp.co.nec.aim.dm.persistence.SegmentFileCreator;
import jp.co.nec.aim.dm.persistence.SegmentFileUpdater;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;
import jp.co.nec.aim.dm.util.SegmentUtil;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class IndexManagerTest extends AbstractTransactionalJUnit4SpringContextTests {
	private static final String SEPARATOR = System.getProperty("line.separator");
	
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private SegmentFileUpdater segmentFileUpdater;
	@Resource
	private SegmentFileCreator segmentFileCreator;

	@SuppressWarnings("deprecation")
	@Before
	public void before() {
		jdbcTemplate.update("delete from person_biometrics");
		jdbcTemplate.update("delete from segments");
		SegmentUtil.createDir();
		clearDirecotry();
		// No Segment File. Clear IndexRepositor. 
		IndexManager.getInstance().clear();
	}

	private void clearDirecotry() {
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		File directory = new File(dir);
		File[] files = directory.listFiles();
		for(File file : files) {
			if(file.isFile()) {
				file.delete();
			}
		}
	}

	@After
	public void after() {
		clearDirecotry();
	}

	@Test
	public void testCreateRepositoryMap_5Records() throws IOException {
		URL url = this.getClass().getResource("insert-5records.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		int segmentId = 1;
		IndexFile indexFile = new IndexFile(1L);
		File file = new File(indexFile.getName()); 
		assertFalse(file.exists());
		
		segmentFileCreator.execute(segmentId, new Integer(0));
		IndexManager manager = IndexManager.getInstance();
		// empty map
		assertEquals(27, manager.getPosition(1, 1));
		assertTrue(file.exists());
		List<String> lines = FileUtils.readLines(file);
		for(String line : lines) {
			assertEquals("\"1\",\"27\"", line);
		}
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testLoadAndAddIndex() throws IOException {
		int records = 5;
		int segmentId = 1;
		insertPersonBio(records);
		jdbcTemplate
				.update("INSERT INTO SEGMENTS (SEGMENT_ID, container_id, BIO_ID_START, BIO_ID_END, "
						+ "BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED) "
						+ "VALUES(1, 1, 1, ?, 1626, ?, ?, 1, 100)",
						new Integer(records), new Integer(records),
						new Integer(records - 1));
		insertSegmentChangeLog(records);
		
		// Creates 1.seg and .1.index
		segmentFileCreator.execute(segmentId, new Integer(0));
		// Clear indexMap to load index file
		IndexManager.getInstance().clear();
		IndexFile indexFile = new IndexFile(segmentId);
		File file = new File(indexFile.getName());
		FileUtils.writeStringToFile(file, "\"1\",\"27\"");
		// segemntFileUpdater loads index file
		segmentFileUpdater.execute(segmentId, new Integer(records-1));
		
		// add 50 templates, Each template is 56 byte. expect add index.
		insertPersonBio(records+1, 50);
		insertSegmentChangeLog(records+1, 50);
		segmentFileUpdater.execute(segmentId, new Integer(records-1));
		List<String> lines = FileUtils.readLines(file);
		// INDEX_BLANK=280 bytes, Each Template is 56bytes. Index appears for each 5 templates.
		assertEquals(11, lines.size());
		assertEquals("\"1\",\"27\"", lines.get(0));
		assertEquals("\"6\",\"307\"", lines.get(1));
		assertEquals("\"11\",\"587\"", lines.get(2));
		assertEquals("\"16\",\"867\"", lines.get(3));
		assertEquals("\"21\",\"1147\"", lines.get(4));
		assertEquals("\"26\",\"1427\"", lines.get(5));
		assertEquals("\"31\",\"1707\"", lines.get(6));
		assertEquals("\"36\",\"1987\"", lines.get(7));
		assertEquals("\"41\",\"2267\"", lines.get(8));
		assertEquals("\"46\",\"2547\"", lines.get(9));
		assertEquals("\"51\",\"2827\"", lines.get(10));
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testCreateIndexInUpdate() throws IOException {
		int records = 5;
		int segmentId = 1;
		insertPersonBio(records);
		jdbcTemplate
				.update("INSERT INTO SEGMENTS (SEGMENT_ID, container_id, BIO_ID_START, BIO_ID_END, "
						+ "BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED) "
						+ "VALUES(1, 1, 1, ?, 1626, ?, ?, 1, 100)",
						new Integer(records), new Integer(records),
						new Integer(records - 1));
		insertSegmentChangeLog(records);
		
		// Creates 1.seg and .1.index
		segmentFileCreator.execute(segmentId, new Integer(0));
		// Clear indexMap to load index file
		IndexManager.getInstance().clear();
		IndexFile indexFile = new IndexFile(segmentId);
		File file = new File(indexFile.getName());
		file.delete();
		segmentFileUpdater.execute(segmentId, new Integer(records-1));
		FileUtils.writeStringToFile(file, "\"1\",\"27\"");
		
		IndexManager.getInstance().clear();
		file.delete();
		// add 50 templates, expect add index.
		insertPersonBio(records+1, 50);
		insertSegmentChangeLog(records+1, 50);
		segmentFileUpdater.execute(segmentId, new Integer(records-1));
		List<String> lines = FileUtils.readLines(file);
		assertEquals(11, lines.size());
		assertEquals("\"1\",\"27\"", lines.get(0));
		assertEquals("\"6\",\"307\"", lines.get(1));
		assertEquals("\"11\",\"587\"", lines.get(2));
		assertEquals("\"16\",\"867\"", lines.get(3));
		assertEquals("\"21\",\"1147\"", lines.get(4));
		assertEquals("\"26\",\"1427\"", lines.get(5));
		assertEquals("\"31\",\"1707\"", lines.get(6));
		assertEquals("\"36\",\"1987\"", lines.get(7));
		assertEquals("\"41\",\"2267\"", lines.get(8));
		assertEquals("\"46\",\"2547\"", lines.get(9));
		assertEquals("\"51\",\"2827\"", lines.get(10));
	}

	
	@Test
	public void testCreateIndexMap_100Records() throws IOException {
		int records = 100;
		int segmentId = 1;
		insertPersonBio(records);
		jdbcTemplate
				.update("INSERT INTO SEGMENTS (SEGMENT_ID, container_id, BIO_ID_START, BIO_ID_END, "
						+ "BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED) "
						+ "VALUES(1, 1, 1, ?, 1626, ?, ?, 1, 100)",
						new Integer(records), new Integer(records),
						new Integer(records - 1));
		insertSegmentChangeLog(records);
		segmentFileCreator.execute(segmentId, new Integer(0));

		IndexManager manager = IndexManager.getInstance();
		// TemplateSize = 15bit, SIZE_CHECK_SUM= 1bit 
		assertEquals(27L, manager.getPosition(segmentId, 1L));
		assertEquals(27, manager.getPosition(segmentId, 2L));
		assertEquals(2547L, manager.getPosition(segmentId, 50L));
		assertEquals(2827, manager.getPosition(segmentId, 51L));
		assertEquals(5347L, manager.getPosition(segmentId, 99L));
		assertEquals(5347L, manager.getPosition(segmentId, 100L));
		// IndexMananger does not know index of SEGMENT_ID=2; In such Case he
		// tells 1st record pointer
		assertEquals(27L, manager.getPosition(2, 1L));
	}

	@Test
	public void testCreateRepositoryMap_isValidIndex_1000Records() throws IOException {
		int records = 1000;
		int segmentId = 1;
		insertPersonBio(records);
		jdbcTemplate
				.update("INSERT INTO SEGMENTS (SEGMENT_ID, container_id, BIO_ID_START, BIO_ID_END, "
						+ "BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED) "
						+ "VALUES(1, 1, 1, ?, 16026, ?, ?, 1, 100)",
						new Integer(records), new Integer(records),
						new Integer(records - 1));
		insertSegmentChangeLog(records);
		segmentFileCreator.execute(segmentId, new Integer(0));

		IndexManager manager = IndexManager.getInstance();
		manager.putIndexMap(segmentId);
		// template is 16bytes. SUM_CHECK is 1 byte
		assertEquals(27L, manager.getPosition(segmentId, 1L));

		assertEquals(2547L, manager.getPosition(segmentId, 50L));
		assertEquals(2827L, manager.getPosition(segmentId, 51L));
		assertEquals(5347L, manager.getPosition(segmentId, 100L));
		assertEquals(5627L, manager.getPosition(segmentId, 101L));
		assertEquals(55747L, manager.getPosition(segmentId, 999L));
		assertEquals(55747L, manager.getPosition(segmentId, 1000L));
		assertEquals(55747L, manager.getPosition(segmentId, 1001L));

		Map<Long, Long> indexMap = new HashMap<Long, Long>();
		indexMap.put(1L, 27L);
		indexMap.put(51L, 2827L);
		assertTrue(manager.isValidIndex(segmentId, indexMap));
		// put incorrect index
		indexMap.put(51L, 2826L);
		assertFalse(manager.isValidIndex(segmentId, indexMap));
	}

	private void insertSegmentChangeLog(int records) {
		insertSegmentChangeLog(1, records);
	}

	private void insertSegmentChangeLog(int startId, int records) {
		String sql = "INSERT INTO SEGMENT_CHANGE_LOG (SEGMENT_CHANGE_ID, SEGMENT_ID, SEGMENT_VERSION, "
				+ "BIOMETRICS_ID, CHANGE_TYPE) VALUES(?, 1, ?, ?, 0)";
		for (int id = startId; id < (startId + records); id++) {
			jdbcTemplate.update(sql, new Integer(id), new Integer(id - 1),
					new Integer(id));
		}
	}


	private void insertPersonBio(int records) {
		insertPersonBio(1, records);
	}

	/**
	 * Insert record into PERSON_BIOMETRICS, externalId="external-%04d"
	 * @param startId
	 * @param records
	 */
	private void insertPersonBio(int startId, int records) {
		String sql = "INSERT INTO PERSON_BIOMETRICS"
				+ "(BIOMETRICS_ID, EXTERNAL_ID, EVENT_ID, container_id, CORRUPTED_FLAG, BIOMETRIC_DATA, BIOMETRIC_DATA_LEN, registed_ts) "
				+ "VALUES (?, ?, 1, 1, 0, TO_BLOB('1111'), 4, 123)";
		for (int id = startId; id < (startId+records); id++) {
			jdbcTemplate.update(sql, new Integer(id),
					"external-" + String.format("%04d", id));
		}
	}


	@Test
	public void testLoadIndxRepository_1000Records() throws IOException {
		int records = 1000;
		int segmentId = 1;
		insertPersonBio(records);
		jdbcTemplate
				.update("INSERT INTO SEGMENTS (SEGMENT_ID, container_id, BIO_ID_START, BIO_ID_END, "
						+ "BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED) "
						+ "VALUES(1, 1, 1, ?, 16026, ?, ?, 1, 100)",
						new Integer(records), new Integer(records),
						new Integer(records - 1));
		insertSegmentChangeLog(records);
		segmentFileCreator.execute(segmentId, new Integer(0));

		IndexManager manager = IndexManager.getInstance();
		assertEquals(27L, manager.getPosition(1, 1L));
		assertEquals(27L, manager.getPosition(1, 2L));
		
		assertEquals(2547L, manager.getPosition(1, 50L));
		assertEquals(2827L, manager.getPosition(1, 51L));
		assertEquals(2827L, manager.getPosition(1, 52L));
		assertEquals(5347L, manager.getPosition(1, 100L));
		assertEquals(5627L, manager.getPosition(1, 101L));
		assertEquals(52947L, manager.getPosition(1, 950L));
		assertEquals(53227L, manager.getPosition(1, 951L));
	}

	@Test
	public void testConvertAndSaveIndexMap() throws IOException {
		IndexFile indexFile = new IndexFile(1L);
		File file = new File(indexFile.getName());
		FileUtils.writeStringToFile(file, "1,27", true);
		FileUtils.writeStringToFile(file, SEPARATOR, true);
		FileUtils.writeStringToFile(file, "2,127", true);
		FileUtils.writeStringToFile(file, SEPARATOR, true);
		FileUtils.writeStringToFile(file, "3,227", true);
		IndexManager manager = IndexManager.getInstance();
		Map<Long, Long> map = manager.readIndexFile(1L);
		assertEquals(3, map.keySet().size());
		assertEquals(27L, map.get(new Long(1)).longValue());
		assertEquals(127L, map.get(new Long(2)).longValue());
		assertEquals(227L, map.get(new Long(3)).longValue());
		
		IndexManager.getInstance().saveAllIndex();
		map = manager.readIndexFile(1L);
		assertEquals(3, map.keySet().size());
		assertEquals(27L, map.get(new Long(1)).longValue());
		assertEquals(127L, map.get(new Long(2)).longValue());
		assertEquals(227L, map.get(new Long(3)).longValue());
	}
}
