package jp.co.nec.aim.dm.procedure;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.dm.persistence.SegmentInfo;
import jp.co.nec.aim.dm.util.SegmentUtil;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class DownloadSegmentDataProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	private static final Logger log = LoggerFactory
			.getLogger(DownloadSegmentDataProcedureTest.class);
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private DataSource dataSource;

	@Before
	public void before() {
		jdbcTemplate.execute("delete from person_biometrics");
		// jdbcTemplate.execute("delete from mu_jobs");
		jdbcTemplate.execute("delete from segments");
	}

	@Test
	public void testExecute_Download25000Templates() {
		int records = 25000;
		int unit = 30000;
		int templateSize = 10;
		long segmentId = 1L;
		long startId = 1L;
		SegmentUtil.insertSegmentRecords(records, unit, templateSize,
				jdbcTemplate);

		SegmentInfo info = new SegmentInfo();
		info.setSegmentId(segmentId);
		info.setBioIdStart(1);
		info.setBioIdEnd(records);
		DownloadSegmentDataProcedure procedure = new DownloadSegmentDataProcedure(
				dataSource, info, 100000);
		assertEquals(
				records,
				jdbcTemplate
						.queryForInt("select count(BIOMETRICS_ID) from person_biometrics"));
		assertEquals(
				1L,
				jdbcTemplate
						.queryForLong("select MIN(BIOMETRICS_ID) from person_biometrics"));
		assertEquals(
				(long) records,
				jdbcTemplate
						.queryForLong("select MAX(BIOMETRICS_ID) from person_biometrics"));
		List<TemplateData> templates = procedure.execute();
		assertEquals(records, templates.size());
		assertEquals(1L, templates.get(0).getBiometricsId());
		assertEquals((long) records, templates.get(templates.size() - 1)
				.getBiometricsId());

		procedure = new DownloadSegmentDataProcedure(dataSource, info, 10000);
		startId = 1L;
		int count = 0;
		while (0 < (templates = procedure.execute()).size()) {
			log.info("downloaded {} records", templates.size());
			assertEquals(startId, templates.get(0).getBiometricsId());
			assertEquals((long) (startId + templates.size() - 1), templates
					.get(templates.size() - 1).getBiometricsId());
			startId = templates.get(templates.size() - 1).getBiometricsId() + 1L;
			count += templates.size();
		}
		assertEquals(records, count);
	}

	@Test
	public void testExecute_3Segments() {
		// 1 segment has 100 records.
		int records = 250;
		int unit = 100;
		SegmentUtil.insertSegmentRecords(records, unit, 100, jdbcTemplate);
		SegmentInfo info = new SegmentInfo();
		info.setSegmentId(1);
		info.setBioIdStart(1L);
		info.setBioIdEnd(100L);
		info.setRecordCount(100);
		DownloadSegmentDataProcedure procedure = new DownloadSegmentDataProcedure(
				dataSource, info, 10000);
		List<TemplateData> dataList = procedure.execute();
		assertEquals(100, dataList.size());
		assertEquals(1L, dataList.get(0).getBiometricsId());
		assertEquals(100L, dataList.get(99).getBiometricsId());

		TemplateData segData = dataList.get(0);
		assertEquals(unit, segData.getBiometricData().length);
		segData = dataList.get(99);
		assertEquals(100, segData.getBiometricData().length);

		info.setSegmentId(2L);
		info.setBioIdStart(101L);
		info.setBioIdEnd(200L);
		procedure = new DownloadSegmentDataProcedure(dataSource, info, 10000);
		dataList = procedure.execute();
		assertEquals(100, dataList.size());
		assertEquals(101L, dataList.get(0).getBiometricsId());
		assertEquals(200L, dataList.get(99).getBiometricsId());

		info.setSegmentId(3L);
		info.setBioIdStart(201L);
		info.setBioIdEnd(250L);
		procedure = new DownloadSegmentDataProcedure(dataSource, info, 10000);
		dataList = procedure.execute();
		assertEquals(50, dataList.size());
		segData = dataList.get(0);
		assertEquals(100, segData.getBiometricData().length);
		assertEquals(201L, dataList.get(0).getBiometricsId());
		assertEquals(250L, dataList.get(49).getBiometricsId());

		info.setSegmentId(4L);
		info.setBioIdStart(1L);
		info.setBioIdEnd(250L);
		procedure = new DownloadSegmentDataProcedure(dataSource, info, 10000);
		dataList = procedure.execute();
		assertEquals(0, dataList.size());
	}

	@Test
	public void testExecute_SegmentHasNotAllTemplates() {
		int templates = 100;
		// Each Segment has 50 records
		int unit = 50;
		int templateSize = 75;
		SegmentUtil.insertSegmentRecords(templates, unit, templateSize,
				jdbcTemplate);

		// delete 4 records in SEGMENT_ID=1
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 10");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 20");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 30");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 40");

		// delete 8 records in SEGMENT_ID=2
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 55");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 60");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 65");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 70");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 75");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 80");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 85");
		jdbcTemplate
				.update("delete from PERSON_BIOMETRICS where BIOMETRICS_ID = 90");

		SegmentInfo info = new SegmentInfo();
		info.setSegmentId(1);
		info.setBioIdStart(1L);
		info.setBioIdEnd(50L);
		info.setVersion(53);
		info.setRecordCount(46);
		// SEGMENT_ID=1 start from BIOMETRICS_ID=1 to BIOMETRICS_ID=50
		DownloadSegmentDataProcedure procedure = new DownloadSegmentDataProcedure(
				dataSource, info, 10000);
		List<TemplateData> records = procedure.execute();
		assertEquals(46, records.size());

		// SEGMENT_ID=2 start from BIOMETRICS_ID=51 to BIOMETRICS_ID=100
		info.setSegmentId(2);
		info.setBioIdStart(51);
		info.setBioIdEnd(100);
		info.setVersion(107);
		info.setRecordCount(53);
		procedure = new DownloadSegmentDataProcedure(dataSource, info, 10000);
		records = procedure.execute();
		assertEquals(42, records.size());
	}

	/**
	 * TestCase for Redmine #1337. Confirm templates are order by templateId
	 * http://10.84.75.229/redmine/issues/1337
	 */
	@Test
	public void testExecuteOrderByBioId() {
		int records = 1000;
		for (int i = 0; i < 20; i++) {
			before();
			insertPersonBio(records);
			jdbcTemplate
					.update("INSERT INTO SEGMENTS (SEGMENT_ID, container_id, BIO_ID_START, BIO_ID_END, "
							+ "BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, REVISION, BINARY_LENGTH_UNCOMPACTED) "
							+ "VALUES(1, 1, 1, ?, 16026, ?, ?, 1, 100)",
							new Integer(records), new Integer(records),
							new Integer(records - 1));
			insertSegmentChangeLog(records);

			SegmentInfo info = new SegmentInfo();
			info.setSegmentId(1);
			DownloadSegmentDataProcedure procedure = new DownloadSegmentDataProcedure(
					dataSource, info, 10000);
			List<TemplateData> segDataList = null;
			while (0 < (segDataList = procedure.execute()).size()) {
				log.info("downloaded {} segmentData", segDataList.size());
				for (int index = 0; index < segDataList.size() - 1; index++) {
					assertEquals("index = " + index, segDataList.get(index)
							.getBiometricsId(), segDataList.get(index + 1)
							.getBiometricsId() - 1L);
				}
			}
			log.info("Finished {} th Test. No problem", i);
		}
	}

	/**
	 * DownloadSegmentDataProcedure gets 500 records in each execute().
	 */
	@Test
	public void testExecute_MaxTemplates500() {
		int records = 1340;
		int unit = 2000;
		int templateSize = 10;
		SegmentUtil.insertSegmentRecords(records, unit, templateSize,
				jdbcTemplate);

		SegmentInfo info = new SegmentInfo();
		info.setSegmentId(1);
		info.setBioIdStart(1L);
		info.setBioIdEnd(records);
		info.setRecordCount(records);
		DownloadSegmentDataProcedure procedure = new DownloadSegmentDataProcedure(
				dataSource, info, 500);
		List<TemplateData> dataList = procedure.execute();
		assertEquals(500, dataList.size());
		assertEquals(1L, dataList.get(0).getBiometricsId());
		assertEquals(500L, dataList.get(499).getBiometricsId());

		dataList = procedure.execute();
		assertEquals(500, dataList.size());
		assertEquals(501L, dataList.get(0).getBiometricsId());
		assertEquals(1000L, dataList.get(499).getBiometricsId());

		dataList = procedure.execute();
		assertEquals(340, dataList.size());
		assertEquals(1001L, dataList.get(0).getBiometricsId());
		assertEquals(1340, dataList.get(339).getBiometricsId());
	}

	@Test
	public void testExecute_startBioId_51() {
		int records = 250;
		int unit = 500;
		int templateSize = 10;
		SegmentUtil.insertSegmentRecords(records, unit, templateSize,
				jdbcTemplate, 51L);

		SegmentInfo info = new SegmentInfo();
		info.setSegmentId(1);
		info.setBioIdStart(1L);
		info.setBioIdEnd(500L);
		info.setRecordCount(250);
		DownloadSegmentDataProcedure procedure = new DownloadSegmentDataProcedure(
				dataSource, info, 500);
		List<TemplateData> dataList = procedure.execute();
		assertEquals(250, dataList.size());
		assertEquals(51L, dataList.get(0).getBiometricsId());
		assertEquals(300L, dataList.get(249).getBiometricsId());
	}

	private void insertPersonBio(int records) {
		String sql = "INSERT INTO PERSON_BIOMETRICS"
				+ "(BIOMETRICS_ID, EXTERNAL_ID, EVENT_ID, container_id, CORRUPTED_FLAG, BIOMETRIC_DATA, BIOMETRIC_DATA_LEN, registed_ts) "
				+ "VALUES (?, ?, 1, 1, 0, TO_BLOB('1111'), 4, 123)";
		for (int id = records; 1 <= id; id--) {
			jdbcTemplate.update(sql, new Integer(id),
					"external-" + String.format("%04d", id));
		}
	}

	private void insertSegmentChangeLog(int records) {
		String sql = "INSERT INTO SEGMENT_CHANGE_LOG (SEGMENT_CHANGE_ID, SEGMENT_ID, SEGMENT_VERSION, "
				+ "BIOMETRICS_ID, CHANGE_TYPE) VALUES(?, 1, ?, ?, 0)";
		for (int id = 1; id <= records; id++) {
			jdbcTemplate.update(sql, new Integer(id), new Integer(id - 1),
					new Integer(id));
		}
	}

}
