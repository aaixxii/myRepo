/**
 * 
 */
package jp.co.nec.aim.dm.properties;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * @author f-kawakami
 * 
 */
public class DynamicPropertiesTest {
	/**
	 * Test method for
	 * {@link jp.co.nec.aim.dm.properties.DynamicProperties#getPropertyValue(jp.co.nec.aim.dm.properties.DynamicPropertyNames)}
	 * .
	 */
	@Test
	public void testGetPropertyValueDynamicPropertyNames() {
		DynamicProperties properties = DynamicProperties.getInstance();
		String soTimeOut = properties
				.getPropertyValue(DynamicPropertyNames.SO_TIME_OUT);
		assertEquals("5000", soTimeOut);
	}
}
