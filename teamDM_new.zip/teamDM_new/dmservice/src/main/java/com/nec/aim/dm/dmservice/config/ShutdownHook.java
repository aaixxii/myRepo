package com.nec.aim.dm.dmservice.config;

import java.util.concurrent.Semaphore;

import com.nec.aim.dm.dmservice.socket.HeartBeatSocketServer;


public class ShutdownHook  {
	/** The Constant shutdownSemaphore. */
	private static final Semaphore shutdownSemaphore = new Semaphore(0);	

	Runnable shutdownListener = () -> {
		System.out.println("Dm will shutdown ...");
		wiatForShutdown();
		System.out.println("Dm is shutdown!");
	};

	/**
	 * Instantiates a new shutdown hook.
	 */
	public ShutdownHook() {		
		Runtime.getRuntime().addShutdownHook(new Thread(shutdownListener));
		System.out.println("Core ShutdownHook is registered");
	}

	/**
	 * Wiat for shutdown.
	 */
	public static void wiatForShutdown() {
		HeartBeatSocketServer.getInstance().close();
		shutdownSemaphore.acquireUninterruptibly();
		shutdownSemaphore.release();
	}

}
