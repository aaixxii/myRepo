package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import com.nec.aim.dm.dmservice.entity.NodeStorage;

public interface NodeStorageRepository {
	public List<NodeStorage> findAll()  throws SQLException;
	public NodeStorage findById(Long id, String dmStorageId)  throws SQLException;	
	public List<NodeStorage>  findNeedNodeByRedundancy(int redundancy)  throws SQLException;
	public void setSignalMailFlag(int storageId, String dmSstorageId);	
	public List<NodeStorage> getNodeStorgeBySegmentId(Long segmentId) throws SQLException;
}
