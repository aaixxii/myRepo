package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import com.nec.aim.dm.dmservice.entity.SegmentLoading;

public interface SegmentLoadRepository {	
	public void insertSegmentLoad(SegmentLoading segLoad)  throws SQLException;
	public void updateSegmentLoadWithMailFlag(SegmentLoading segLoad)  throws SQLException;	
	public void updateSegmentLoadNoMailFlag(SegmentLoading segLoad)  throws SQLException;
	public void updateAfterDelWithNoMailFlag(SegmentLoading segLoad)  throws SQLException;
	public void updateAfterNew(long version, int storage_id, long segmentId) throws SQLException;
	public long getLastVersion(int storageId, long segmentId) throws SQLException;	
}
