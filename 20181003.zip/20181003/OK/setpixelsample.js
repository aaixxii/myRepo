﻿var SetPixelSample;
(function (SetPixelSample) {
    var Program = (function () {
        function Program() {
        }
        Program.run = function () {
            var canvas = document.querySelector("canvas");
            var context = canvas.getContext("2d");
            var imageData = context.createImageData(canvas.width, canvas.height);

            // ImageData にランダムにピクセルを置く
            Program.setRandomPixels(canvas, imageData);

            // ImageData を描画
            context.putImageData(imageData, 0, 0);
        };

        // ImageData のランダムな座標のピクセルをランダムな色にする
        Program.setRandomPixels = function (canvas, imageData) {
            for (var index = 0; index < 100000; index++) {
                var x = Program.randomInteger(canvas.height);
                var y = Program.randomInteger(canvas.width);
                var red = Program.randomInteger(0x100);
                var green = Program.randomInteger(0x100);
                var blue = Program.randomInteger(0x100);
                Program.setPixel(imageData, x, y, red, green, blue);
            }
        };

        // 疑似乱数 (0 から value 未満の整数)
        Program.randomInteger = function (value) {
            return Math.floor(value * Math.random());
        };

        // ImageData の指定した座標の 1 ピクセルを指定した色にする
        Program.setPixel = function (imageData, x, y, red, green, blue, alpha) {
            if (typeof alpha === "undefined") { alpha = 0xff; }
            // 指定した座標のピクセルが ImageData の data のどの位置にあるかを計算
            var index = (x + y * imageData.width) * 4;

            // その位置から、赤、緑、青、アルファ値の順で1バイトずつ書き込むことで、ピクセルがその色になる
            imageData.data[index + 0] = red;
            imageData.data[index + 1] = green;
            imageData.data[index + 2] = blue;
            imageData.data[index + 3] = alpha;
        };
        return Program;
    })();
    SetPixelSample.Program = Program;
})(SetPixelSample || (SetPixelSample = {}));
//# sourceMappingURL=setpixelsample.js.map