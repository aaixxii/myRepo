package com.nec.aim.client.user.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.nec.aim.client.entity.PersonBioMetrics;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

@RequestMapping("/client")
@RestController
@Slf4j
public class PersonBioMetricsController {
	
	private static final String url1 = "http://localhost:8000/pernsonBio/";
	private static final String url2 = "http://localhost:8001/pernsonBio/";

	private static final AtomicBoolean usedFirst = new AtomicBoolean(false);
	private final ReentrantLock lock = new ReentrantLock();


	@Autowired
	private RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "findByIdFallback")
	@GetMapping("/pernsonBio/{id}")
	public PersonBioMetrics findById(@PathVariable Long id) {
		PersonBioMetrics personBio = null;
		lock.lock();
		try {
			if (!usedFirst.get()) {
				personBio = this.restTemplate.getForObject(url1 + "{id}", PersonBioMetrics.class, id);
				usedFirst.set(true);
			} else {
				personBio = this.restTemplate.getForObject(url2 + "{id}", PersonBioMetrics.class, id);
				usedFirst.set(false);
			}

		} finally {
			lock.unlock();
		}		
				
		return personBio;
	}

	@SuppressWarnings("unchecked")
	@GetMapping("/pernsonBio/all")
	public List<PersonBioMetrics> findAll() {
		List<PersonBioMetrics> pList = null;
		lock.lock();
		try {
			if (!usedFirst.get()) {
				pList = this.restTemplate.getForObject(url1 + "all", new ArrayList<PersonBioMetrics>().getClass());
				usedFirst.set(true);
			} else {
				pList = this.restTemplate.getForObject(url2 + "all", new ArrayList<PersonBioMetrics>().getClass());
				usedFirst.set(false);
			}

		} finally {
			lock.unlock();
		}	
		
		//this.restTemplate.getForObject("http:/aim-service/pernsonBio/all", new ArrayList<PersonBioMetrics>().getClass());
				
		return pList;
	}

	public PersonBioMetrics findByIdFallback(Long id, Throwable throwable) {
		log.error("fallbak called", throwable);
		return new PersonBioMetrics(id, "default external", "default data", 0, new BigDecimal(1));		
	}	

}
