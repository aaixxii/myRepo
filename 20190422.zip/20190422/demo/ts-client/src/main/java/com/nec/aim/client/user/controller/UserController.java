package com.nec.aim.client.user.controller;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.nec.aim.client.entity.User;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

@RequestMapping("/client")
@RestController
@Slf4j
public class UserController {

	@Autowired
	private RestTemplate restTemplate;

	private static final String url1 = "http://localhost:8000/users/";
	private static final String url2 = "http://localhost:8001/users/";

	private static final AtomicBoolean usedFirst = new AtomicBoolean(false);
	private final ReentrantLock lock = new ReentrantLock();

	@HystrixCommand(fallbackMethod = "findByIdFallback")
	@GetMapping("/users/{id}")
	public User findById(@PathVariable Long id) {
		User user = null;
		lock.lock();
		try {
			if (!usedFirst.get()) {
				user = this.restTemplate.getForObject(url1 + "{id}", User.class, id);
				usedFirst.set(true);
			} else {
				user = this.restTemplate.getForObject(url2 + "{id}", User.class, id);
				usedFirst.set(false);
			}

		} finally {
			lock.unlock();
		}

		return user;
	}

	public User findByIdFallback(Long id, Throwable throwable) {
		log.error("fallbak called", throwable);
		return new User(id, "default user", "default user", 0, new BigDecimal(1));
	}

}
