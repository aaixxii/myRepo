package jp.co.nec.aim.mm.procedure;

import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.planner.JobInfoFromDB;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class GetJobInfoForCreatePlansProcedure extends StoredProcedure {
	private static final String GET_JOB_INFO_FOR_CREATE_PLANS = "MATCH_MANAGER_API.get_job_info_for_create_plans";
	private static final String NUM_TABLE_TYPE = "NUM_TABLE_TYPE";
	private Long[] jobIdArray;

	public GetJobInfoForCreatePlansProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(GET_JOB_INFO_FOR_CREATE_PLANS);
		declareParameter(new SqlParameter("limited_job_ids", Types.ARRAY,
				NUM_TABLE_TYPE));
		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
				new CursorMapper()));
		compile();
	}

	/**
	 * 
	 * @param jobIdList
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	@SuppressWarnings({ "unchecked" })
	public List<JobInfoFromDB> getJobInfoFromDB(Long[] jobIds)
			throws SQLException {
		if (jobIds == null) {
			throw new IllegalArgumentException("jobIds == null");
		}
		setJobIdArray(jobIds);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("limited_job_ids", new AbstractSqlTypeValue() {
			public Object createTypeValue(Connection con, int sqlType,
					String typeName) throws SQLException {
				return createJobIdsArrayType(con);
			}
		});
		Map<String, Object> resultMap = execute(map);
		List<JobInfoFromDB> jobInfoFromDBlist = (List<JobInfoFromDB>) resultMap
				.get("p_refcursor");
		return jobInfoFromDBlist;
	}

	public Long[] getJobIdArray() {
		return jobIdArray;
	}

	public void setJobIdArray(Long[] jobIdArray) {
		this.jobIdArray = jobIdArray;
	}

	/**
	 * 
	 * @author xiazp
	 *
	 */
	private class CursorMapper implements RowMapper<JobInfoFromDB> {
		@Override
		public JobInfoFromDB mapRow(ResultSet rs, int row) throws SQLException {
			JobInfoFromDB oneResult = new JobInfoFromDB();
			oneResult.setTopJobId(rs.getLong("job_id"));
			oneResult.setFamilyId(rs.getInt("family_id"));
			oneResult.setFunctionId(rs.getInt("function_id"));
			oneResult.setContainerId(rs.getInt("container_id"));
			oneResult.setContainerJobId(rs.getLong("container_job_id"));
			return oneResult;
		}
	}

	private Array createJobIdsArrayType(Connection con) throws SQLException {
		OracleConnection oraConn = con.unwrap(OracleConnection.class);
		return oraConn.createARRAY(NUM_TABLE_TYPE, getJobIdArray());
	}
}
