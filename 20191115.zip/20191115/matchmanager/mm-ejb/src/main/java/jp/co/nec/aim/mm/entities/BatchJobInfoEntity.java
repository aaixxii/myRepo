package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the CONTAINER_JOBS database table.
 * 
 */
@Entity
@Table(name = "BATCH_JOB_INFO")
public class BatchJobInfoEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id	
	@Column(name = "BATCH_JOB_ID", unique = true)	
	private long batchJobId;
	
	@Column(name = "REQUEST_ID " , unique = true)
	private String reqeustId;
	
	@Column(name = "ENROLLMENT_ID " , unique = true)
	private String enrollmentId;
	
	@Column(name = "INTERNAL_JOB_ID ")
	private long internalJobId; 

	
	@Column(name = "BATCH_TYPE")	
	private String batchType;
	
	
	@Column(name = "PBRESPONSE_ERR")
	private byte[] pbResErr;


	public long getBatchJobId() {
		return batchJobId;
	}

	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}	

	public String getReqeustId() {
		return reqeustId;
	}

	public void setReqeustId(String reqeustId) {
		this.reqeustId = reqeustId;
	}

	public long getInternalJobId() {
		return internalJobId;
	}

	public void setInternalJobId(long internalJobId) {
		this.internalJobId = internalJobId;
	}
	

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}	

	public byte[] getPbResErr() {
		return pbResErr;
	}

	public void setPbResErr(byte[] pbResErr) {
		this.pbResErr = pbResErr;
	}

	public String getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}	
}