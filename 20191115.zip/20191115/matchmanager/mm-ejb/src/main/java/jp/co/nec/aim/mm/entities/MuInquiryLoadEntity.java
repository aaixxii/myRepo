package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MU_INQUIRY_LOAD database table.
 * 
 */
@Entity
@Table(name = "MU_INQUIRY_LOAD")
@NamedQuery(name = "MuInquiryLoadEntity.findAll", query = "SELECT m FROM MuInquiryLoadEntity m")
public class MuInquiryLoadEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MU_INQUIRY_LOAD_MUID_GENERATOR", sequenceName = "MU_INQUIRY_LOAD", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MU_INQUIRY_LOAD_MUID_GENERATOR")
	@Column(name = "MU_ID")
	private long muId;

	private Long pressure;

	@Column(name = "REPORT_TS")
	private Long reportTs;

	public MuInquiryLoadEntity() {
	}

	public long getMuId() {
		return this.muId;
	}

	public void setMuId(long muId) {
		this.muId = muId;
	}

	public Long getPressure() {
		return this.pressure;
	}

	public void setPressure(Long pressure) {
		this.pressure = pressure;
	}

	public Long getReportTs() {
		return this.reportTs;
	}

	public void setReportTs(Long reportTs) {
		this.reportTs = reportTs;
	}

}