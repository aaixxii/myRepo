package jp.co.nec.aim.mm.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.loadbalancer.LoadBalancerBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.SLB_QUEUE)
/*
 * ,
 * 
 * @ActivationConfigProperty(propertyName = "maxSession", propertyValue = "1"),
 * 
 * @ ActivationConfigProperty ( propertyName = "transactionTimeout" ,
 * propertyValue = JNDIConstants . SLB_TIMEOUT ) ,
 * 
 * @ ActivationConfigProperty ( propertyName = "messageSelector" , propertyValue
 * = "messageReceiver = 'TemplateManagerBean'" )
 */})
public class SlbEventReceiver extends AbstractEventReceiver {
	private static Logger log = LoggerFactory.getLogger("slb");

	@EJB
	private LoadBalancerBean loadBalancer;

	@Override
	protected void dispatchEvent() {
		try {
			loadBalancer.executeSLB();
		} catch (Exception e) {
			log.error("Exception when do SLB.", e);
		}
	}
}
