package jp.co.nec.aim.mm.exception;

public class DistributorExcception extends AimErrorInfoException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2191304681764962498L;

	public DistributorExcception(String errorCode, String description,
			String time, String uidCode) {
		super(errorCode,description, time, uidCode);
	}

	public DistributorExcception(Throwable ex) {
		super(ex);
	}

	public DistributorExcception(String detail, Throwable ex) {
		super(detail, ex);
	}

}
