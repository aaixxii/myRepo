package jp.co.nec.aim.mm.sessionbeans;

import java.sql.Date;
import java.time.LocalDate;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class CreateNextDayPartitionBean  {
		
	private static final Logger logger = LoggerFactory.getLogger(CreateNextDayPartitionBean.class);
	
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private PartitionDao partitionDao;
	
	public CreateNextDayPartitionBean() {		
	}
	
	public void execute()  {
		LocalDate now = LocalDate.now();
		LocalDate nextDay = now.plusDays(2);
		long hashValue = PartitionUtil.getInstance().caculateHashAtThisToday(nextDay);
		partitionDao.insertPno(hashValue, Date.valueOf(nextDay));
		partitionDao.createPartition(hashValue);
		logger.info("Success create partition(p_no={}) for day({}) ", hashValue, LocalDate.now());
	}

}
