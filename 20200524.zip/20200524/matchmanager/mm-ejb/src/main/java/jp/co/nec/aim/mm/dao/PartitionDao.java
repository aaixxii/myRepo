package jp.co.nec.aim.mm.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

public class PartitionDao {
	private static Logger logger = LoggerFactory.getLogger(PartitionDao.class);
	private JdbcTemplate jdbcTemplate;

	private static String getCountSql = "select count(p_no) from segment_change_log";
	private static String insertTodayPnoSql = "insert into segment_change_log(p_no,update_ts) value(?, ?)";
	private static String getTodayPnoSql = "select p_no from where update_ts=CURDATE()";
	private static String insertPnoWithDateSql = "insert into segment_change_log(p_no,update_ts) value(?, ?)";

	public PartitionDao(DataSource ds) {		
		jdbcTemplate = new JdbcTemplate(ds);
	}
	
	public void initPartition(long hashValue) {
		String initSql = "ALTER TABLE segment_change_log"
				      + " PARTITION BY LIST (p_no)"
				      + " (PARTITION p0 VALUES IN (0))";
		
		insertPno(hashValue, new Date(System.currentTimeMillis()));		
		jdbcTemplate.execute(initSql);		
	}

	public int getPatitionPnoCount() {
		return jdbcTemplate.queryForObject(getCountSql, Integer.class);
	}
	
	public long getCurrentHashValue() {
		return jdbcTemplate.queryForObject(getTodayPnoSql, Long.class);
	}

	public int setTodayPno(long pNo) {
		return jdbcTemplate.update(insertTodayPnoSql, new Object[] { Long.valueOf(pNo), new Date(System.currentTimeMillis())});
	}
	
	public int insertPno(long pNo,  Date firstAddDay) {
		return jdbcTemplate.update(insertPnoWithDateSql, new Object[] { Long.valueOf(pNo), firstAddDay });
	}
	

	public void createPartitions(long[] pNos) {
		StringBuilder sb = new StringBuilder();
		int last = pNos.length - 1;
		sb.append("ALTER TABLE segment_change_log　ADD PARTITION  (");
		for (int i = 0; i < pNos.length; i++) {
			sb.append("PARTITION p");
			sb.append(pNos[i]);
			sb.append("  VALUES IN (");
			sb.append(pNos[i]);
			if (i != last) {
				sb.append("),");
			} else {
				sb.append(")");
			}
		}
		sb.append(")");
		jdbcTemplate.execute(sb.toString());
	}

	public void createPartition(long intPNo) {		
		String addPatitionSql = "ALTER TABLE segment_change_logg ADD PARTITION ( PARTITION p" + String.valueOf(intPNo)
				+ " VALUES IN (" + String.valueOf(intPNo) + "))";		
		jdbcTemplate.execute(addPatitionSql);
	}

	public void clearPartitionDatas(long[] intPNo) {
		// List<long[]> tmp = Arrays.asList(intPNo);
		String joinStr = Arrays.stream(intPNo).boxed().map(i -> i.toString()).collect(Collectors.joining(","));
		StringBuilder sb = new StringBuilder();
		sb.append("ALTER TABLE segment_change_log TRUNCATE PARTITION ");
		sb.append(joinStr);
		jdbcTemplate.execute(sb.toString());
	}

	public void clearPartitionData(long intPNo) {
		String clearPartitionSql = "ALTER TABLE segment_change_log TRUNCATE PARTITION p" + String.valueOf(intPNo);
		jdbcTemplate.execute(clearPartitionSql);
	}

	public void deletePartition(long intPNo) {
		String clearPartitionSql = "ALTER TABLE segment_change_log DROP PARTITION p" + String.valueOf(intPNo);
		jdbcTemplate.execute(clearPartitionSql);
	}

	public void deletePartitions(long[] intPNo) {
		String joinStr = Arrays.stream(intPNo).boxed().map(i -> i.toString()).collect(Collectors.joining(","));
		StringBuilder sb = new StringBuilder();
		sb.append("LTER TABLE segment_change_log DROP PARTITION ");
		sb.append(joinStr);
		jdbcTemplate.execute(sb.toString());
	}

	public int getDataCountByPNo(Integer intPNo) {
		String getCountInOnePartionSQL = "SELECT * FROM segment_change_log PARTITION (p" + intPNo.toString() + ")";
		return jdbcTemplate.queryForObject(getCountInOnePartionSQL, Integer.class);
	}

}
