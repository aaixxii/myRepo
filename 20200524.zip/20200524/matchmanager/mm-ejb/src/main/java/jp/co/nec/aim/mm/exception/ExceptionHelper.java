package jp.co.nec.aim.mm.exception;

import java.sql.SQLException;

import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.w3c.dom.Document;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSSerializer;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.DateDao;

/**
 * the helper of Exception
 * 
 * @author liuyq
 * 
 */
public class ExceptionHelper {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(ExceptionHelper.class);

	private static final String AIMFAULT_ELEMENT = "AIMFault";
	private static final String NS2 = "ns2";
	private static final String NS2_NAMESPACE = "http://ws.mm.aim.nec.co.jp/";

	private static final String NS3 = "ns3";
	private static final String NS3_NAMESPACE = "urn:nec:aim";

	private static final String STATE_ELEMENT = "state";
	private static final String CODE_ELEMENT = "code";
	private static final String DESCRIPTION_ELEMENT = "description";

	private static final String ROLLBACK_STATE = "ROLLBACK";
	private static final String ERROR_STATE = "ERROR";

	/** DateDao instance **/
	private DateDao dateDao;

	/**
	 * default constructor
	 */
	public ExceptionHelper() {
	}

	/**
	 * ExceptionUtil default constructor
	 * 
	 * @param dateDao
	 */
	public ExceptionHelper(DateDao dateDao) {
		this.dateDao = dateDao;
	}

	/**
	 * throwInqDBException
	 * 
	 * @param ex
	 *            exception instance
	 * @param error
	 *            error information
	 */
	public void throwDBException(AimError aimError, Exception ex, String error) {
		final String errorTime = String.valueOf(dateDao.getCurrentTimeMS());
		final String errorMsg = String.format(aimError.getMessage(),ex.getMessage());
		throw new DataBaseException(aimError.getErrorCode(), errorMsg,
				errorTime, aimError.getUidCode());
	}

	/**
	 * throwArgException
	 * 
	 * @param error
	 *            AimError instance
	 */
	public void throwArgException(final AimError error, Throwable e) {
		final String code = error.getErrorCode();
		String message = null;
		if (e != null) {
			message = String.format(error.getMessage(), e.getCause().getMessage());
		} else {
			message =  String.format(error.getMessage(), "");
		}						
		final String failTime = String.valueOf(System.currentTimeMillis());
		log.error(message);
		throw new ArgumentException(code, message, failTime, error.getUidCode());
	}

	/**
	 * throwOracleException
	 * 
	 * @param e
	 *            SQLException
	 */
	public void throwOracleException(SQLException e, AimError error) {
		// Retrieve a vendor-specific error code
		// identifying the reason for the exception.
		int errorCode = e.getErrorCode();
		String message = "Wrapping Oracle Exception. Error code: " + errorCode;
		log.error(message);
		throwDBException(error, e, message);
	}
	
//	public AimError getAimErrorType(Exception e) {
//		AimError jpaErr = null;
//		if (e instanceof EntityExistsException) {
//			
//		} else if (e instanceof NonUniqueResultException) {
//			
//		} else if (e instanceof EntityNotFoundException) {
//			
//		} else if (e instanceof NoResultException) {
//			
//		} else if (e instanceof QueryTimeoutException) {
//			
//		} else if (e instanceof  DataAccessException) {				
//		}
//		return null;
//		
//		 //01403:NO_DATA_FOUND
//		 //ORA-00001: DUP_VAL_ON_INDEX
//	}
	
	

	/**
	 * createSOAPFault
	 * 
	 * @param e
	 *            the instance of Throwable
	 * @return the instance of SOAPFault
	 * @throws SOAPException
	 *             the exception of SOAPException
	 */
	public SOAPFault createSOAPFault(final Throwable e) {
		try {
			Throwable cause = (e.getCause() == null) ? e : e.getCause();
			final SOAPFactory factory = SOAPFactory
					.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
			final SOAPFault soapFault = factory.createFault();
			final Detail detail = soapFault.addDetail();
			final Name faultName = factory.createName(AIMFAULT_ELEMENT, NS2,
					NS2_NAMESPACE);
			final DetailEntry detailEntry = detail.addDetailEntry(faultName);

			// add ns2 and ns3 nameSpace
			detailEntry.addNamespaceDeclaration(NS2, NS2_NAMESPACE);
			detailEntry.addNamespaceDeclaration(NS3, NS3_NAMESPACE);

			// create state code and description element
			SOAPElement stateEle = detailEntry.addChildElement(STATE_ELEMENT);
			SOAPElement codeEle = detailEntry.addChildElement(CODE_ELEMENT);
			SOAPElement descriptionEle = detailEntry
					.addChildElement(DESCRIPTION_ELEMENT);

			// set the AIMFault state
			stateEle.addTextNode(isNeedToRollback(e) ? ROLLBACK_STATE
					: ERROR_STATE);

			// get the code and description
			String description = null;
			String code = null;
			if (cause instanceof AimErrorInfoException) {
				AimErrorInfoException ex = ((AimErrorInfoException) cause);
				code = ex.getErrorCode();
				description = ex.getDescription();
			
			} else {
				final AimError error = AimError.INTERNAL_ERROR;
				code = error.getErrorCode();
				description = String.format(error.getMessage(),
						getDescription(cause));
			}

			// set the code the code element
			codeEle.addTextNode(code);
			// set the description to description element
			descriptionEle.addTextNode(description);
			// set the FaultString
			soapFault.setFaultString(description);

			return soapFault;
		} catch (SOAPException ex) {
			throw new AimRuntimeException(
					"SOAPException occurred when createSOAPFault.", ex);
		}
	}

	/**
	 * get the Throwable Description
	 * 
	 * @param e
	 *            the instance of Throwable
	 * @return error Description
	 */
	public String getDescription(final Throwable e) {
		if (e == null) {
			return StringUtils.EMPTY;
		}
		final String error = ExceptionUtils.getMessage(e);
		return StringUtils.isBlank(error) ? String.format("%s occurred..", e
				.getClass().getSimpleName()) : error;
	}

	/**
	 * Is need to set the service state to ROLLBACK, include following
	 * 
	 * <ol>
	 * <li>SQLException</li>
	 * <li>DataBaseException</li>
	 * <li>DataAccessException</li>
	 * </ol>
	 * 
	 * @param e
	 *            THROWABLE instance
	 * @return is need To set the service state to ROLLBACK
	 */
	public boolean isNeedToRollback(final Throwable e) {
		return (e instanceof SQLException || e instanceof DataBaseException || e instanceof DataAccessException);
	}

	/**
	 * this is only for test
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		ExceptionHelper helper = new ExceptionHelper();
		SOAPFault fault = helper.createSOAPFault(new ArgumentException(
				"111111", "description", "121212", "unknown"));

		Document document = fault.getOwnerDocument();
		DOMImplementationLS domImplLS = (DOMImplementationLS) document
				.getImplementation();
		LSSerializer serializer = domImplLS.createLSSerializer();
		String str = serializer.writeToString(fault);

		System.out.println(str);
	}

}
