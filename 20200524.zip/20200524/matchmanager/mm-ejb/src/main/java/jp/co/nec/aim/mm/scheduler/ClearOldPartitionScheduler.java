package jp.co.nec.aim.mm.scheduler;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.sessionbeans.ClearOldPartitionBean;
import jp.co.nec.aim.mm.util.JndiLookup;


@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class ClearOldPartitionScheduler implements Job{

	private static final Logger logger = LoggerFactory.getLogger(ClearOldPartitionScheduler.class);
	
	ClearOldPartitionBean clearOldPartitionBean;
	
	public ClearOldPartitionScheduler() {
		clearOldPartitionBean = JndiLookup.lookUp(
				JNDIConstants.CLEAROLDPARTITIONBEAN,ClearOldPartitionBean.class);
	}
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		clearOldPartitionBean.execute();
	}

}
