package jp.co.nec.aim.mm.exception;

/**
 * 
 * If Any exception occurred while notify MU, it will throw UDPNotifyException
 * 
 * @author jinxl
 */
public class UDPNotifyException extends AimErrorInfoException {

	private static final long serialVersionUID = -2684065299346069656L;

	/**
	 * UDPNotifyException
	 * 
	 * @param msg
	 */
	public UDPNotifyException(String errorCode, String description,String time, String uidCode) {
		super(errorCode,description, time, uidCode);
	}	

	/**
	 * UDPNotifyException
	 * 
	 * @param msg
	 *            the message
	 * @param e
	 *            exception instance
	 */
	public UDPNotifyException(String msg, Throwable e) {
		super(msg, e);
	}
}
