package jp.co.nec.aim.mm.sessionbeans;

import java.time.LocalDate;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ClearOldPartitionBean {
	
	private PartitionDao partitionDao;
	 private SystemInitDao systemInitDao;
	
	public ClearOldPartitionBean(DataSource dataSource, EntityManager entityManager) {
		systemInitDao = new SystemInitDao(entityManager);	
		partitionDao = new PartitionDao(dataSource);		
	}
	
	public void execute()  {
		Long saveDays = systemInitDao.getSegChangeLogSaveDays();
		LocalDate now = LocalDate.now();
		LocalDate deleteDay = now.minusDays(saveDays);	
//		if (skipDays.contains(deleteDay)) {
//			return;
//		}	
		long todayHashValue = PartitionUtil.getInstance().caculateHashAtThisToday(deleteDay);
		partitionDao.deletePartition(todayHashValue);
	}
}
