package jp.co.nec.aim.mm.util;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;

public class PBStateUtil {

	/**
	 * creatSuccessState
	 * 
	 * @return PBServiceState.Builder
	 */
	public static PBServiceState.Builder creatSuccessState() {
		return PBServiceState.newBuilder().setState(
				ServiceStateType.SERVICE_STATE_SUCCESS);
	}

	/**
	 * creatErrorState
	 * 
	 * @return PBServiceState.Builder
	 */
	public static PBServiceState.Builder creatErrorState(
			ServiceStateType state, String code, String description, String time) {
		PBServiceStateReason.Builder reason = PBServiceStateReason.newBuilder();
		return PBServiceState
				.newBuilder()
				.setState(state)
				.setReason(
						reason.setCode(code).setTime(time)
								.setDescription(description));
	}
}
