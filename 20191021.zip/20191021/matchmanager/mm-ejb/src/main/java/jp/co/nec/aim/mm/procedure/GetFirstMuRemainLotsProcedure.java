package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.extract.planner.MuRemainLots;
import oracle.jdbc.OracleTypes;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * pickup one mu that is best fit to assign job to it
 * 
 * @author xiazp
 */
public class GetFirstMuRemainLotsProcedure extends StoredProcedure {
	private static final String SQL = "MATCH_MANAGER_API.get_first_mu_remain_lots";
	private Integer maxLot;

	public GetFirstMuRemainLotsProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_max_lot", Types.INTEGER));
		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
				new MuRemainLotsRowMapper()));
		compile();
	}

	@SuppressWarnings("unchecked")
	public MuRemainLots getfirstMuRemainLots(int maxMuLot)
			throws DataAccessException, SQLException {
		if (maxMuLot < 0) {
			throw new IllegalArgumentException("Max Mu Lot is null or empty"
					+ " when call getfirstMuRemainLots");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_max_lot", maxMuLot);
		Map<String, Object> resultMap = execute(map);
		if (resultMap.values().toString().equals("[[]]")) {
			return null;
		}
		List<MuRemainLots> results = (List<MuRemainLots>) resultMap
				.get("p_refcursor");
		return results.get(0);
	}

	public Integer getMaxLot() {
		return maxLot;
	}

	public void setMaxLot(Integer maxLot) {
		this.maxLot = maxLot;
	}
}
