package jp.co.nec.aim.mm.wakeup;

import java.util.Set;

import javax.persistence.EntityManager;

import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.UDPNotifyException;
import jp.co.nec.aim.mm.util.UDPNotifyHelper;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReportWakeUp {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(UDPNotifyHelper.class);

	private UDPNotifyHelper notifyhelper;
	private SystemInitDao systeminitdao;

	public ReportWakeUp(EntityManager entityManager) {
		systeminitdao = new SystemInitDao(entityManager);
		notifyhelper = new UDPNotifyHelper();
		setBroadCastIpAndPort();
	}

	public void notifyMessage(Set<Long> unitIds) {
		String message = UDPNotifyHelper.convert(unitIds);

		try {
			if (StringUtils.isNotEmpty(message)) {
				notifyhelper.notifyCompoent(message);
			}
		} catch (UDPNotifyException ex) {
			final String error = "UDPNotifyException occurred while notify.";
			log.error(error, ex);
			throw new AimRuntimeException(error, ex);
		} catch (Exception e) {
			final String error = "Exception occurred while notify.";
			log.error(error, e);
			throw new AimRuntimeException(error, e);
		}
	}

	private void setBroadCastIpAndPort() {
		notifyhelper.clearIPAddress();
		Integer unitPort = systeminitdao.getUnitWakeupPort();
		if (unitPort == null) {
			log.warn("Unit wake up notify port is null..");
			return;
		}
		String unitIpSegments = systeminitdao.getUnitNetWorkSegment();
		if (StringUtils.isEmpty(unitIpSegments)) {
			log.warn("Unit wake up notify IP is null or empty..");
			return;
		}

		notifyhelper.addIPAddress(unitIpSegments, unitPort);
	}
}
