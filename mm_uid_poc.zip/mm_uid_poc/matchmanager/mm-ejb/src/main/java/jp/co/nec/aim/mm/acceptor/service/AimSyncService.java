package jp.co.nec.aim.mm.acceptor.service;

import static jp.co.nec.aim.mm.constants.MMConfigProperty.INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;
import jp.co.nec.aim.mm.acceptor.AimSyncRequest;
import jp.co.nec.aim.mm.acceptor.Record;
import jp.co.nec.aim.mm.acceptor.Registration;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.BatchJobInfoDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.ProtobufException;
import jp.co.nec.aim.mm.exception.TemplateException;
import jp.co.nec.aim.mm.exception.UidTimeoutException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.logger.ProtobufDumpLogger;
import jp.co.nec.aim.mm.procedure.BatchJobInfoProcedures;
import jp.co.nec.aim.mm.procedure.FeJobProcedures;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

/**
 * The main work flow of Sync <br>
 * Include following public method:
 * <p>
 * syncData
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimSyncService {
    /** log instance **/
    private static Logger log = LoggerFactory.getLogger(AimSyncService.class);
    private static Logger probufDumpLog = LoggerFactory.getLogger("probufdump");
    
    @PersistenceContext(unitName = "aim-db")
    private EntityManager manager;
    
    @Resource(mappedName = "java:jboss/OracleDS")
    private DataSource dataSource;
    
    private Registration reg;
    
    private AcceptorValidator validator;
    
    private FEJobDao feJobDao;
    
    private SystemConfigDao sysConfigDao;
    
    private FunctionDao functionDao;
    
    private FeJobProcedures feJobProcedures;
    
    private BatchJobInfoProcedures batchJobInfoProcedures;
    private BatchJobInfoDao batchJobInfoDao;
    
    @EJB
    private AimExtractService aimExService;
    
    /**
     * default constructor
     */
    public AimSyncService() {
    }
    
    @PostConstruct
    private void init() {
        this.reg = new Registration(dataSource, manager);
        this.validator = new AcceptorValidator(manager, dataSource);
        this.feJobDao = new FEJobDao(manager);
        this.functionDao = new FunctionDao(manager);
        this.sysConfigDao = new SystemConfigDao(manager);
        feJobProcedures = new FeJobProcedures(dataSource);
        batchJobInfoProcedures = new BatchJobInfoProcedures(dataSource);
        batchJobInfoDao = new BatchJobInfoDao(manager);
    }
    
    /**
     * The main work flow of syncData
     * 
     * @param request
     *            PBSyncJobRequest instance
     * @return the instance of PBSyncJobResponse
     */
    public SyncResponse syncData(final SyncRequest request) {
        return syncData(request, null);
    }
    
    /**
     * The main work flow of syncData
     * 
     * @param syncRequest
     *            PBSyncJobRequest instance
     * @param delCount
     *            delete count
     * @return PBSyncJobResponse instance
     */
    public SyncResponse syncData(final SyncRequest request,
        final AtomicInteger delCount) {
        if (probufDumpLog.isDebugEnabled()) {
            probufDumpLog.debug(request.toString());
        }
        PBBusinessMessage pbm = validator.checkSyncJobRequest(request);
        ProtobufDumpLogger.trace("IdentifyRequest", request.getBatchJobId(), request.getType().toString(), pbm);
        final String externalId = pbm.getRequest().getEnrollmentId();
        String syncType = pbm.getRequest().getRequestType().name();
        log.info("received sync request, externalId = {}", externalId);
        
        switch (syncType.toUpperCase()) {
        case "INSERT_REFID_DEFAULT":
            log.info("syncData insert by refernceId begin..");
            FeJobQueueEntity feEntity = null;
            try {
                String refernceId = pbm.getRequest().getEnrollmentId();
                List<FeJobQueueEntity> resultList = feJobDao.getExResult(refernceId);
                if (resultList.isEmpty()) {
                    AimError temErr = AimError.SYNC_INSERT_BY_REFID_NO_REF_DATA;
                    throw new TemplateException(
                        temErr.getErrorCode(), temErr.getMessage(), String.valueOf(System.currentTimeMillis()), temErr.getUidCode());
                }
                feEntity = resultList.get(0);
            } catch (Exception e) {
                throw e;
            }
            
            final List<AimSyncRequest> aimRequestList = new ArrayList<>();
            Record record = new Record(feEntity.getResult());
            AimSyncRequest aimReq = new AimSyncRequest(Integer.valueOf(1), record);
            aimRequestList.add(aimReq);
            reg.insert(0, externalId, aimRequestList);
            try {
                String refId = pbm.getRequest().hasEnrollmentId() ? pbm.getRequest().getEnrollmentId() : null;
                log.info("batchJobId={}, reqeustId={}, eenrollmentId={}",request.getBatchJobId(), pbm.getRequest().getRequestId(), refId);
                batchJobInfoProcedures.createNewBatchJobInfo(request.getBatchJobId(), pbm.getRequest().getRequestId(), refId, request.getType().name(), -1);                   
                log.info("success insert batch job info to DB.");
            } catch (Exception e2) {
                log.warn("faild to insert batchJobinfo to db.");
            }
            
            SyncResponse.Builder insByRefIdRes = SyncResponse.newBuilder();
            insByRefIdRes.setBatchJobId(request.getBatchJobId());
            insByRefIdRes.setType(request.getType());
            PBBusinessMessage.Builder newPbMes = PBBusinessMessage.newBuilder();
            newPbMes.setRequest(pbm.getRequest());
            PBResponse.Builder refIdPbRespose = PBResponse.newBuilder();
            refIdPbRespose.setStatus("0");
            newPbMes.setResponse(refIdPbRespose);
            insByRefIdRes.addBusinessMessage(newPbMes.build().toByteString());
            ProtobufDumpLogger.trace("SyncResponse", insByRefIdRes.getBatchJobId(), insByRefIdRes.getType().toString(), newPbMes.build());
            return insByRefIdRes.build();
        
        case "INSERT_REFURL_DEFAULT":
            log.info("syncData insert by url begin..");
            // final FeJobQueueEntity feJob = new FeJobQueueEntity();           
            FunctionTypeEntity fte = functionDao.getExtractFunction();
            if (fte == null) {
                AimError dbErr = AimError.SYNC_FUNCTIONTYPE;
                throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(), String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
            }
            Long newFeJobId = null;
            
            try {
                newFeJobId = feJobProcedures.createNewFeJob(externalId, pbm.toByteArray());
                log.info("************new feJobId for INSERT_REFURL_DEFAULT:{}*******", newFeJobId); 
                String refId = pbm.getRequest().hasEnrollmentId() ? pbm.getRequest().getEnrollmentId() : null;
                batchJobInfoProcedures.createNewBatchJobInfo(request.getBatchJobId(), pbm.getRequest().getRequestId(), refId, request.getType().name(), newFeJobId);
                log.info("Insert into batchJobInfo table referenceId:{},feJobId:{}", refId, newFeJobId);     
            } catch (SQLException e1) { 
                feJobDao.deleteExtractJob(newFeJobId);
                batchJobInfoDao.deleteBatchJobInfoByJobId(newFeJobId);                
                Throwable cause = e1.getCause();
                Throwable lastCause = null;
                while (cause != null) {
                    cause = cause.getCause();
                    if (cause != null) {
                        lastCause = cause;
                    }
                }
                String errMsg = lastCause.getMessage();
                AimError dbErr = AimError.SYNC_DB;
                errMsg = StringUtils.isNoneEmpty(errMsg) ? errMsg : String.format(dbErr.getMessage(), e1.getCause().getMessage());
                dbErr.setMessage(errMsg);
                throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(), String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
            }
            
            JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
                String.format("create extract job id: %s", newFeJobId));
            Integer syncJobWaitTime = sysConfigDao.getMMPropertyInt(INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT);
            if (Objects.isNull(syncJobWaitTime) || syncJobWaitTime < 0) {
                syncJobWaitTime = 100000;
            }            
            String key = String.valueOf(newFeJobId.longValue());
            Object extractJoblocker = new Object();
            AimManager.saveToExtractLockQueue(key, extractJoblocker);
            Optional<PBMuExtractJobResultItem> onejobResult = null;
            synchronized (extractJoblocker) {
                long startGetExtResultTime = System.currentTimeMillis();
                try {
                    extractJoblocker.wait(syncJobWaitTime);
                } catch (InterruptedException e) {
                    log.error(e.getMessage(), e);
                    Thread.currentThread().interrupt();
                }
                try {
                    onejobResult = Optional.ofNullable(AimManager.getExtractJobResult(key));
                } catch (NullPointerException e) {
                    log.warn("can't get extractResponse, it may be timeout.");
                    AimError timeoutErr = AimError.JOB_TIMEOUT;
                    String errMsg = String.format(timeoutErr.getMessage(), "sync insert by url job timeout.");
                    timeoutErr.setMessage(errMsg);
                    throw new UidTimeoutException(timeoutErr.getErrorCode(), timeoutErr.getMessage(), String.valueOf(System.currentTimeMillis()), timeoutErr.getUidCode());     
                }
                if (onejobResult.isPresent()) {
                    log.info("Get insert by url jobId({}) result success", newFeJobId);
                    long endGetResultTime = System.currentTimeMillis();
                    log.info("*****MM get insert by url job results used time = {}****",
                        endGetResultTime - startGetExtResultTime);
                } else {
                    log.warn("Got empty PBMuExtractJobResultItem, key={}", key); 
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - startGetExtResultTime >= syncJobWaitTime) {
                        log.warn(
                            "Timeout is happend! the waiting time = ({}), jobId({})",
                            currentTime - startGetExtResultTime, newFeJobId.longValue());
                        AimError timeoutErr = AimError.JOB_TIMEOUT;
                        String errMsg = String.format(timeoutErr.getMessage(), "sync insert by url job timeout.");
                        timeoutErr.setMessage(errMsg);
                        throw new UidTimeoutException(timeoutErr.getErrorCode(), timeoutErr.getMessage(), String.valueOf(System.currentTimeMillis()), timeoutErr.getUidCode());                       
                    }
                }
            }
            AimManager.finishExtractJob(key);
            PBBusinessMessage pbExtMes = null;
            try {               
                pbExtMes = PBBusinessMessage.parseFrom(onejobResult.get().getResult());                
            } catch (InvalidProtocolBufferException e) {                
                feJobDao.deleteExtractJob(newFeJobId);
                batchJobInfoDao.deleteBatchJobInfoByJobId(newFeJobId);
                log.info("PBMuExtractJobResultItem deserialize faild");                
                AimError aimErr = AimError.PROTOBUF_ERROR;
                String errMsg = String.format(aimErr.getMessage(), e.getCause().getMessage());
                aimErr.setMessage(errMsg);
                throw new ProtobufException(aimErr.getErrorCode(), aimErr.getMessage(), String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
            }
            if (!pbExtMes.getResponse().getStatus().equals("0") || !pbExtMes.hasDataBlock() || pbExtMes.hasDataBlock() && !pbExtMes.getDataBlock().hasTemplateInfo()) {
                return makeFailedSyncRes(request, pbExtMes); 
            } 
            PBTemplateInfo exTemplateData = pbExtMes.getDataBlock().getTemplateInfo();
            final List<AimSyncRequest> aimRequestByExtList = new ArrayList<>();
            Record recordByExt = new Record(exTemplateData.getData().toByteArray());
            AimSyncRequest aimReqExt = new AimSyncRequest(Integer.valueOf(1), recordByExt);
            aimRequestByExtList.add(aimReqExt);
            reg.insert(0, externalId, aimRequestByExtList);
            SyncResponse.Builder insByUrlRes = SyncResponse.newBuilder();
            insByUrlRes.setBatchJobId(request.getBatchJobId());
            insByUrlRes.setType(request.getType());
            insByUrlRes.addBusinessMessage(pbExtMes.toByteString());
            ProtobufDumpLogger.trace("SyncResponse", insByUrlRes.getBatchJobId(), insByUrlRes.getType().toString(), pbExtMes);
            return insByUrlRes.build();
        case "DELETE_REFID":
            if (log.isDebugEnabled()) {
                log.debug("syncData delete begin..");
            }
            int count = reg.delete(0, externalId, Lists.newArrayList(new Integer[] {1}));            
            if (delCount != null) {
                delCount.set(count);
            }
            try {
                String refId = pbm.getRequest().hasEnrollmentId() ? pbm.getRequest().getEnrollmentId() : null;
                batchJobInfoProcedures.createNewBatchJobInfo(request.getBatchJobId(), pbm.getRequest().getRequestId(), refId, request.getType().name(), -1);
                log.info("success insert batch job info to DB.");
            } catch (Exception e2) {
                log.warn("faild to insert batchJobInfo to db.");
            }
            SyncResponse.Builder delRes = SyncResponse.newBuilder();
            delRes.setBatchJobId(request.getBatchJobId());
            delRes.setType(request.getType());
            PBBusinessMessage oldPbMes = null;
            PBBusinessMessage.Builder dlePbMes = PBBusinessMessage.newBuilder();
            try {
                oldPbMes = PBBusinessMessage.parseFrom(request.getBusinessMessage(0));
                dlePbMes.setRequest(oldPbMes.getRequest());
                PBResponse.Builder delPbRespose = PBResponse.newBuilder();
                delPbRespose.setStatus("0");
                dlePbMes.setResponse(delPbRespose);
            } catch (InvalidProtocolBufferException e) {
                AimError protoErr = AimError.PROTOBUF_ERROR;
                String errMsg = String.format(protoErr.getMessage(), e.getCause().getMessage());
                protoErr.setMessage(errMsg);
                throw new ProtobufException(protoErr.getErrorCode(), protoErr.getMessage(), String.valueOf(System.currentTimeMillis()), protoErr.getUidCode());                          
            }
            delRes.addBusinessMessage(dlePbMes.build().toByteString());
            ProtobufDumpLogger.trace("SyncResponse", delRes.getBatchJobId(), delRes.getType().toString(), dlePbMes.build());
            return delRes.build();
        
        default:
            throw new IllegalArgumentException("E_REQUESET_TYPE:" + syncType
                + " is not support.");
        }
    }
    
   
    private SyncResponse makeFailedSyncRes(final SyncRequest request, PBBusinessMessage pbm) {
        SyncResponse.Builder faildSyncRes = SyncResponse.newBuilder();
        faildSyncRes.setBatchJobId(request.getBatchJobId());
        faildSyncRes.setType(request.getType());
        faildSyncRes.addBusinessMessage(pbm.toByteString());
        ProtobufDumpLogger.trace("SyncResponse", request.getBatchJobId(), request.getType().toString(), pbm);
        return faildSyncRes.build();
    }
}
