package jp.co.nec.aim.license.lmx;

import static java.nio.channels.SelectionKey.OP_ACCEPT;
import static java.nio.channels.SelectionKey.OP_READ;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LicenseSokectServer  {
	private static Logger logger = LoggerFactory.getLogger(LicenseSokectServer.class);

	final ExecutorService threadExecutor = Executors.newSingleThreadExecutor();
	

	ServerSocketChannel serverChannel;	
	
	public LicenseSokectServer() throws IOException {
		 initServer();
	}
	
	int port;
	
	public int getPort() {
		return port;
	}	

	private interface Handler {
		public void handle(SelectionKey key);
	}

	private class AcceptHandler implements Handler {
		@Override
		public void handle(SelectionKey key) {
			try {
				if (key.isAcceptable()) {
					logger.debug("accepted");

					SocketChannel channel = ((ServerSocketChannel)(key.channel())).accept();

					channel.configureBlocking(false);
					channel.register(key.selector(), OP_READ, new IoHandler());
					
					serverChannel.close();
				}
			} catch (IOException ex) {
				logger.error(ex.getMessage(), ex);
			}
		}
	}

	private class IoHandler implements Handler {
		final static int BUFFER_SIZE = 512;
		
		@Override
		public void handle(SelectionKey key) {
			FloatingLicenseManager manager = FloatingLicenseManager.getInstance();
			if (!key.isReadable()) {
				return;
			}

			SocketChannel channel = null;
			try {
				channel = (SocketChannel)key.channel();
				ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
				int numRead = channel.read(buffer);
				if (numRead < 0) {
					logger.error("License agent has stopped.");

					channel.close();
					manager.clearAllLicense();					
					return;
				}

				buffer.flip();
				String license = new String(buffer.array(), 0, numRead, "UTF-8");
				logger.debug("Got a license, " + license);
				
				manager.decompose(license);
			} catch (IOException ex) {
				logger.error(ex.getMessage(), ex);
			}
		}
	}

	private class Server implements Runnable {
		@Override
		public void run() {
			try (Selector selector = Selector.open()) {
				serverChannel.register(selector, OP_ACCEPT, new AcceptHandler());

				Set<SelectionKey> keys = null;
				while (true) {
					selector.select();
					keys = selector.selectedKeys();
					if (keys.size() < 1) {
						continue;
					}
					for (Iterator<SelectionKey> ite = keys.iterator(); ite.hasNext();) {
						SelectionKey key = ite.next();
						ite.remove();

						Handler handler = (Handler)key.attachment();
						handler.handle(key);
					}
				}
			} catch (Exception ex) {
				logger.error(ex.getMessage(), ex);
				return;
			} finally {
				threadExecutor.shutdown();
			}
		}
	}	

	private void initServer()
		throws IOException {
		serverChannel = ServerSocketChannel.open();
		serverChannel.configureBlocking(false);
		serverChannel.setOption(StandardSocketOptions.SO_REUSEADDR, Boolean.TRUE);
		serverChannel.socket().bind(new InetSocketAddress("localhost", 0));
		port = serverChannel.socket().getLocalPort();
		threadExecutor.submit(new Server());
		logger.info("License broker server port is " + port);
	}
}
