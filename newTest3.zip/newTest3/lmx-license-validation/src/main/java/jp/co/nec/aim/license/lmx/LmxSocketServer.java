package jp.co.nec.aim.license.lmx;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.function.Consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Throwables;

public class LmxSocketServer implements Runnable {
	private ServerSocketChannel serverSocketChannel = null;
	private Selector selector;	
	private int port;
	private int serverSocketTimeout = 6000000;
	final static int BUFFER_SIZE = 512;
	private static Logger logger = LoggerFactory.getLogger(LmxSocketServer.class);

	public LmxSocketServer() throws IOException {
		init();
	}

	private void init() throws IOException {				
			selector = Selector.open();
			serverSocketChannel = ServerSocketChannel.open();
			serverSocketChannel.socket().setReuseAddress(true);
			serverSocketChannel.socket().setSoTimeout(serverSocketTimeout);
			serverSocketChannel.configureBlocking(false);
			serverSocketChannel.socket().bind(new InetSocketAddress("localhost", 0));
			serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT, accept);
			this.port = serverSocketChannel.socket().getLocalPort();
			logger.info("Lmx Socket Server is started.");
			logger.info("Lmx Socket Server port is " + port);		 
	}
	
	public int getPort() {
		return port;
	}
	
	Consumer<SelectionKey> accept = (key) -> {
		try {
			if (key.isAcceptable()) {
				SocketChannel socketChannel = serverSocketChannel.accept();				
				socketChannel.configureBlocking(false);
				logger.info("LmxAget connected to me: " + socketChannel.socket().getInetAddress() + ":"
						+ socketChannel.socket().getPort());
				socketChannel.register(selector, SelectionKey.OP_READ);	
				//serverSocketChannel.close();
			}
		} catch (IOException ex) {
			logger.error(Throwables.getRootCause(ex).getMessage());
		}
	};	
	
	Consumer<SelectionKey> readData = (key) -> {
		if (!key.isReadable()) {
			return;
		}
		SocketChannel channel = null;
		FloatingLicenseManager manger = FloatingLicenseManager.getInstance();
		try {
			channel = (SocketChannel) key.channel();
			ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
			int numRead = channel.read(buffer);
			if (numRead < 0) {
				logger.error("License agent has stopped.");
				channel.close();
				manger.clearAllLicense();
				releaseAll();
				return;
			}
			buffer.flip();
			String license = new String(buffer.array(), 0, numRead, "UTF-8");
			logger.info("Got a license, " + license);
			manger.decompose(license);
			buffer.clear();
		} catch (IOException ex) {
			logger.error(Throwables.getRootCause(ex).getMessage());
		}
	};	

	public void service() throws IOException {
		int acceptCount = 0;
		while (selector.select() > 0) {
			Set<SelectionKey> readyKeys = selector.selectedKeys();
			Iterator<SelectionKey> it = readyKeys.iterator();
			while (it.hasNext()) {
				SelectionKey key = null;
				key = (SelectionKey) it.next();
				it.remove();
				if (!key.isValid()) {
					continue;
				}
				 if (key.isAcceptable() && acceptCount < 1) {
					 accept.accept(key);
					 acceptCount++;
				 }
				if (key.isReadable()) {
					readData.accept(key);
				}
			}
		}
	}

	@Override
	public void run() {	
		try{
			service();
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}
	
	private void releaseAll() {
		try {
			if (serverSocketChannel != null) {
				serverSocketChannel.close();
			}
			
			if (selector != null) {
				selector.close();				
			}
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}	
	}
}
