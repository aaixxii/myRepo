package jp.co.nec.aim.mm.util;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterOutputStream;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Deflater {

	private static Logger log = LoggerFactory.getLogger(Deflater.class);

	/**
	 * uncompress from deflated byte array to byte array
	 * 
	 * @param zipedBytes
	 * @return
	 * @throws IOException
	 */
	public static byte[] uncompress(byte[] zipedBytes) throws IOException {
		ByteArrayOutputStream baos = null;
		InflaterOutputStream out = null;
		try {
			baos = new ByteArrayOutputStream();
			out = new InflaterOutputStream(baos);
			out.write(zipedBytes, 0, zipedBytes.length);
			out.flush();
			return baos.toByteArray();
		} finally {
			close(out);
			close(baos);
		}
	}

	/**
	 * compress from deflated byte array to byte array
	 * 
	 * @param unzipedBytes
	 * @return
	 * @throws IOException
	 */
	public static byte[] compress(byte[] unzipedBytes) throws IOException {
		ByteArrayOutputStream baos = null;
		DeflaterOutputStream out = null;
		try {
			baos = new ByteArrayOutputStream();
			out = new DeflaterOutputStream(baos);
			out.write(unzipedBytes, 0, unzipedBytes.length);
			out.flush();
			out.finish();
			return baos.toByteArray();
		} finally {
			close(out);
			close(baos);
		}
	}

	private static void close(Closeable closeable) {
		try {
			if (closeable != null) {
				closeable.close();
				closeable = null;
			}
		} catch (IOException e) {
			log.debug(e.getMessage(), e);
		}
	}

	/**
	 * Check if this string is deflated. <br>
	 * If return value is null, you can judge this string is not deflated text.
	 * 
	 * @param base64string
	 * @return null:this is not deflated. byte array:inflated binary array
	 */
	public static byte[] uncompress(String base64string) {
		try {
			byte[] deflateBinary = Base64.decodeBase64(base64string
					.getBytes("UTF-8"));
			return Deflater.uncompress(deflateBinary);
		} catch (UnsupportedEncodingException e) {
			log.debug("This string is not base64encoded.", e);
			return null;
		} catch (IOException e) {
			log.debug("This string is not deflated.", e);
			return null;
		}
	}
}
