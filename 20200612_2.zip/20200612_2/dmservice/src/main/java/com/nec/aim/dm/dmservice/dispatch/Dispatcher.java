package com.nec.aim.dm.dmservice.dispatch;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.nec.aim.dm.dmservice.config.ConfigProperties;
import com.nec.aim.dm.dmservice.entity.NodeStorageManager;
import com.nec.aim.dm.dmservice.entity.SegChangeLog;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.log.PerformanceLogger;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageManagerRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentLoadRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncRequest;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBTemplateInfo;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class Dispatcher {

	@Autowired
	NodeStorageManagerRepository nodeRepository;

	@Autowired
	DmConfigRepository dmConfigRepository;

	@Autowired
	SegmentLoadRepository segmentLoadRepository;

	@Autowired
	SegmentRepository segmentRepository;

	@Autowired
	ConfigProperties config;

	/**
	 * @param activeNodeStorages
	 * @param dmSegReq
	 * @param segInfo
	 * @return
	 */
	@Transactional
	public boolean handlePostRequest(List<NodeStorageManager> activeNodeStorages, String syncMode, PBDmSyncRequest dmSegReq, SegmentInfo segInfo) {
		String changeType = dmSegReq.getCmd().name().toUpperCase();
		boolean mmReturnValue = true;
		try {
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) { // add segment
				mmReturnValue = processNewSegment(activeNodeStorages, syncMode, segInfo, dmSegReq);
			} else {
				if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) { // insert template
					mmReturnValue = processTempalteInsert(activeNodeStorages, syncMode, segInfo, dmSegReq);
				} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) { // delete template
					mmReturnValue = processTempalteDelete(activeNodeStorages, syncMode, segInfo, dmSegReq);
				}
			}
		} catch (SQLException e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			log.error(e.getMessage());
		}
		return mmReturnValue;
	}

	/**
	 * @param changeType
	 * @param segId
	 * @return
	 */
	public List<NodeStorageManager> getActiveNodeStorages(String changeType, Long segId) {
		StopWatch t = new StopWatch();
		t.start();
		List<NodeStorageManager> activeNodeStorages = null;
		int redundancy = DmServiceManager.getRedundancy().get();
		if (redundancy < 1) {
			log.warn("redundancy is less 1! Can't continue process.");
			return null;
		}
		try {
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) {
				activeNodeStorages = nodeRepository.findNeedNodeByRedundancy(redundancy);
				if (null == activeNodeStorages || activeNodeStorages.size() < 1) {
					log.warn("No active node storages! skip process and return.");
				}
			} else {
				activeNodeStorages = nodeRepository.getNodeStorgeBySegmentId(segId, Integer.valueOf(redundancy));
				if (activeNodeStorages == null || activeNodeStorages.size() < 1) {
					log.warn("No active storage manager which asigned semgent(" + segId + "). Can't continue process.");
				}
			}
			log.info("activeNodeStorages=" + activeNodeStorages.size());
			t.stop();
			PerformanceLogger.trace("getActiveNodeStorages", segId.toString(), null, t.elapsedTime());
		} catch (SQLException e) {			
			log.error(e.getMessage());
		}
		return activeNodeStorages;
	}

	public String getDmSyncMode() throws SQLException {
		return dmConfigRepository.getSyncMode();
	}

	/**
	 * @param activeNodeStorages
	 * @param segInfo
	 * @param dmSegReq
	 * @return
	 * @throws SQLException
	 */
	public boolean processNewSegment(List<NodeStorageManager> activeNodeStorages, String syncMode, SegmentInfo segInfo, PBDmSyncRequest dmSegReq) throws SQLException {
		if (segInfo.getBioIdStart() == null || segInfo.getBioIdEnd() == null) {
			throw new DmServiceException("In new segment, bio_id_start and bio_id_end can't be null");
		}
		StopWatch t = new StopWatch();
		t.start();
		boolean mmLastReturnValue = false;
		boolean mmAnyReturnValue = false;
		boolean mmAllReturnValue = true;
		boolean lastSegmentUpdateSuccess = true;
		boolean lastSegmentLoadUpdateSuccess = true;
		boolean mustSetMailFlag = false;
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		if (segInfo.getVersion() != null) {
			segLoading.setLastVersion(segInfo.getVersion());
		} else {
			segInfo.setVersion(-1L);
		}
		try {
			segmentRepository.insertSegment(segInfo);
			boolean segmentUpdateSuccess = true;
			lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
		} catch (Exception e) {
			boolean segmentUpdateSuccess = false;
			lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
			log.error(e.getMessage(), e);
			if (e instanceof DuplicateKeyException) {
				log.warn("segment({}) is already exists, skip process.", segInfo.getSegmentId());
				return true;
			}
		}
		for (int i = 0; i < activeNodeStorages.size(); i++) {
			NodeStorageManager one = activeNodeStorages.get(i);
			segLoading.setNsmId(one.getNsmId());
			segLoading.setStatus(0);
			try {
				segmentLoadRepository.insertSegmentLoad(segLoading);
				boolean segmentLoadUpdateSuccess = true;
				lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
			} catch (Exception e) {
				boolean segmentLoadUpdateSuccess = false;
				lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
			}
			String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(one.getNsmId());
			nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmSyncMethod();
			log.debug("post url is {}", nodeUrl);
			Boolean result = HttpPoster.post(nodeUrl, dmSegReq);
			if (result.booleanValue()) {
				try {
					segmentRepository.updateAfterNew(-1, segInfo.getSegmentId());
					boolean segmentUpdateSuccess = true;
					lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
				} catch (Exception e) {
					mustSetMailFlag = true;
					boolean segmentUpdateSuccess = false;
					lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
				}
				try {
					segmentLoadRepository.updateAfterNew(-1, one.getNsmId(), segInfo.getSegmentId());
					boolean segmentLoadUpdateSuccess = true;
					lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
				} catch (Exception e) {
					mustSetMailFlag = true;
					boolean segmentLoadUpdateSuccess = false;
					lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
				}

			} else {
				try {
					segmentRepository.updateAfterNew(-9, segInfo.getSegmentId());
					boolean segmentUpdateSuccess = true;
					lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
				} catch (Exception e) {
					mustSetMailFlag = true;
					boolean segmentUpdateSuccess = false;
					lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
				}
				try {
					segmentLoadRepository.updateAfterNew(-9, one.getNsmId(), segInfo.getSegmentId());
					boolean segmentLoadUpdateSuccess = true;
					lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
				} catch (Exception e) {
					mustSetMailFlag = true;
					boolean segmentLoadUpdateSuccess = false;
					lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
				}
				mustSetMailFlag = true;
			}

			if (mustSetMailFlag) {
				try {
					segmentRepository.updateAfterNew(-9, segInfo.getSegmentId());
					boolean segmentUpdateSuccess = true;
					lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
				} catch (Exception e) {
					boolean segmentUpdateSuccess = false;
					lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
				}
				try {
					segmentLoadRepository.updateAfterNew(-9, one.getNsmId(), segInfo.getSegmentId());
					boolean segmentLoadUpdateSuccess = true;
					lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
				} catch (Exception e) {
					boolean segmentLoadUpdateSuccess = false;
					lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
				}
				try {
					nodeRepository.setSignalMailFlag(one.getNsmId());
				} catch (Exception e) {
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				}				
			}
			mmAnyReturnValue = mmAnyReturnValue || result.booleanValue();
			mmAllReturnValue = mmAllReturnValue && result.booleanValue();

		} // end loop
		if (syncMode.equals("LOG")) {
			mmLastReturnValue = lastSegmentUpdateSuccess;
		} else if (syncMode.equals("ANY")) {
			mmLastReturnValue = lastSegmentUpdateSuccess && lastSegmentLoadUpdateSuccess && mmAnyReturnValue;
		} else if (syncMode.equals("ALL")) {
			mmLastReturnValue = lastSegmentUpdateSuccess && lastSegmentLoadUpdateSuccess && mmAllReturnValue;
		}
		t.stop();
		PerformanceLogger.trace("processNewSegment", segInfo.getSegmentId().toString(), segInfo.getBioIdEnd().toString(), t.elapsedTime());
		return mmLastReturnValue;
	}

	/**
	 * @param targetNodeStorages
	 * @param segInfo
	 * @param dmSegReq
	 * @return
	 * @throws SerialException
	 * @throws SQLException
	 */
	public boolean processTempalteInsert(List<NodeStorageManager> targetNodeStorages, String syncMode, SegmentInfo segInfo, PBDmSyncRequest dmSegReq) throws SerialException, SQLException {
		StopWatch t = new StopWatch();
		t.start();
		String externalId = null;
		byte[] templateData = null;
		if (dmSegReq.hasTemplateData()) {
			PBTemplateInfo tmpData = dmSegReq.getTemplateData();
			externalId = tmpData.getReferenceId();
			templateData = tmpData.getData().toByteArray();
		}
		if (segInfo.getBioIdEnd() == null || externalId == null || templateData == null) {
			throw new DmServiceException("In insert template,  bio_id_end, external id, template data can't be null");
		}
		boolean mmLastReturnValue = false;
		boolean mmAnyReturnValue = false;
		boolean mmAllReturnValue = true;
		boolean lastSegmentUpdateSuccess = true;
		boolean lastSegmentLoadUpdateSuccess = true;
		boolean mustSetMailFlag = false;

		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		SegChangeLog changeLog = new SegChangeLog();
		changeLog.setBiometricsId(segInfo.getBioIdEnd());
		changeLog.setChangeType(1);
		changeLog.setExternalId(externalId);
		changeLog.setSegmentId(segInfo.getSegmentId());
		changeLog.setSegmentVersion(segInfo.getVersion());
		Blob blob = new SerialBlob(templateData);
		changeLog.setTemplateData(blob);
		boolean needUpdateSegement = true;
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			NodeStorageManager one = targetNodeStorages.get(i);
			segLoading.setNsmId(one.getNsmId());
			Boolean result = null;
			long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getNsmId(), segInfo.getSegmentId());
			if (segInfo.getVersion() == nodoSegmentVersion + 1) {
				if (needUpdateSegement) {
					try {
						segmentRepository.updateSegment(segInfo);
						needUpdateSegement = false;
						boolean segmentUpdateSuccess = true;
						lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
					} catch (Exception e) {
						mustSetMailFlag = true;
						boolean segmentUpdateSuccess = false;
						lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
					}
				}

				String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(one.getNsmId());
				nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmSyncMethod();
				log.debug("nodeUrl= {}", nodeUrl);
				result = HttpPoster.post(nodeUrl, dmSegReq);
				if (result.booleanValue()) {
					StopWatch t2 = new StopWatch();
					t2.start();
					segLoading.setLastVersion(segInfo.getVersion());
					try {
						segmentLoadRepository.updateSegmentLoadNoMailFlag(segLoading);
						boolean segmentLoadUpdateSuccess = true;
						lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
					} catch (Exception e) {
						mustSetMailFlag = true;
						boolean segmentLoadUpdateSuccess = false;
						lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
					}

					t2.stop();
					PerformanceLogger.trace("updateSegmentLoadNoMailFlag", segInfo.getSegmentId().toString(), segInfo.getBioIdEnd().toString(), t2.elapsedTime());
				} else {
					log.warn("Http poster result is false. segmentId={}, semgnetVersion={}", segInfo.getSegmentId(), segInfo.getVersion());
					log.info("Result if false,setting mail falg");
					result = Boolean.FALSE;
					mustSetMailFlag = true;
				}
			} else {
				log.warn("segment version({}) +1 in segment_loading table is not equeal the verion from mm, segmentId={}", nodoSegmentVersion, segInfo.getSegmentId());
				result = Boolean.FALSE;
				log.info("Version not equal,setting mail falg");
				mustSetMailFlag = true;
			}

			if (mustSetMailFlag) {
				try {
					nodeRepository.setSignalMailFlag(one.getNsmId());
				} catch (Exception e) {
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				}
			}
			mmAnyReturnValue = mmAnyReturnValue || result.booleanValue();
			mmAllReturnValue = mmAllReturnValue && result.booleanValue();
		} // end loop
		if (syncMode.equals("LOG")) {
			mmLastReturnValue = lastSegmentUpdateSuccess;
		} else if (syncMode.equals("ANY")) {
			mmLastReturnValue = lastSegmentUpdateSuccess && lastSegmentLoadUpdateSuccess && mmAnyReturnValue;
		} else if (syncMode.equals("ALL")) {
			mmLastReturnValue = lastSegmentUpdateSuccess && lastSegmentLoadUpdateSuccess && mmAllReturnValue;
		}
		t.stop();
		PerformanceLogger.trace("processTempalteInsert", segInfo.getSegmentId().toString(), segInfo.getBioIdEnd().toString(), t.elapsedTime());
		return mmLastReturnValue;
	}

	/**
	 * @param targetNodeStorages
	 * @param segInfo
	 * @param dmSegReq
	 * @return
	 * @throws SQLException
	 */
	public boolean processTempalteDelete(List<NodeStorageManager> targetNodeStorages, String syncMode, SegmentInfo segInfo, PBDmSyncRequest dmSegReq) throws SQLException {
		StopWatch t = new StopWatch();
		t.start();
		String externalId = null;
		if (dmSegReq.hasTemplateData()) {
			PBTemplateInfo tmpData = dmSegReq.getTemplateData();
			externalId = tmpData.getReferenceId();
		}
		if (segInfo.getBioIdEnd() == null) {
			throw new DmServiceException("In delete template,  bio_id_end, can't be null");
		}
		// boolean mmReturnValue = false;
		boolean mmLastReturnValue = false;
		boolean mmAnyReturnValue = false;
		boolean mmAllReturnValue = true;
		boolean lastSegmentUpdateSuccess = true;
		boolean lastSegmentLoadUpdateSuccess = true;
		boolean mustSetMailFlag = false;

		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		SegChangeLog changeLog = new SegChangeLog();
		changeLog.setBiometricsId(segInfo.getBioIdEnd());
		changeLog.setChangeType(2);
		changeLog.setExternalId(externalId);
		changeLog.setSegmentId(segInfo.getSegmentId());
		changeLog.setSegmentVersion(segInfo.getVersion());

		boolean needUpdateSegement = true;
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			NodeStorageManager one = targetNodeStorages.get(i);
			segLoading.setNsmId(one.getNsmId());
			Boolean result = null;
			long nodoSegmentVersion = segmentLoadRepository.getLastVersion(one.getNsmId(), segInfo.getSegmentId());
			if (segInfo.getVersion() == nodoSegmentVersion + 1) {
				if (needUpdateSegement) {
					try {
						segmentRepository.updateSegmentAfterDelete(segInfo);
						needUpdateSegement = false;
						boolean segmentUpdateSuccess = true;
						lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
					} catch (Exception e) {
						mustSetMailFlag = true;
						boolean segmentUpdateSuccess = false;
						lastSegmentUpdateSuccess = lastSegmentUpdateSuccess && segmentUpdateSuccess;
					}
				}
				String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(one.getNsmId());
				nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmSyncMethod();
				result = HttpPoster.post(nodeUrl, dmSegReq);
				if (result.booleanValue()) {
					StopWatch t2 = new StopWatch();
					t2.start();
					segLoading.setLastVersion(segInfo.getVersion());
					try {
						segmentLoadRepository.updateAfterDelWithNoMailFlag(segLoading);
						boolean segmentLoadUpdateSuccess = true;
						lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
					} catch (Exception e) {
						mustSetMailFlag = true;
						boolean segmentLoadUpdateSuccess = false;
						lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess && segmentLoadUpdateSuccess;
					}

					t2.stop();
					PerformanceLogger.trace("updateAfterDelWithNoMailFlag", segInfo.getSegmentId().toString(), segInfo.getBioIdEnd().toString(), t2.elapsedTime());
				} else {
					log.info("Result if false,setting mail falg");
					mustSetMailFlag = true;

				}
			} else {
				log.info("Version not equal,setting mail falg");
				mustSetMailFlag = true;
				result = Boolean.FALSE;
			}
			if (mustSetMailFlag) {
				result = Boolean.FALSE;
				try {
					nodeRepository.setSignalMailFlag(one.getNsmId());
				} catch (Exception e) {
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				}
			}
			mmAnyReturnValue = mmAnyReturnValue || result.booleanValue();
			mmAllReturnValue = mmAllReturnValue && result.booleanValue();
		}
		if (syncMode.equals("LOG")) {
			mmLastReturnValue = lastSegmentUpdateSuccess;
		} else if (syncMode.equals("ANY")) {
			mmLastReturnValue = lastSegmentUpdateSuccess && lastSegmentLoadUpdateSuccess && mmAnyReturnValue;
		} else if (syncMode.equals("ALL")) {
			mmLastReturnValue = lastSegmentUpdateSuccess && lastSegmentLoadUpdateSuccess && mmAllReturnValue;
		}
		t.stop();
		PerformanceLogger.trace("processTempalteDelete", segInfo.getSegmentId().toString(), segInfo.getBioIdEnd().toString(), t.elapsedTime());
		return mmLastReturnValue;
	}

	/**
	 * @param segId
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public byte[] dispatchDownloadReqeust(Long segId) throws InterruptedException, ExecutionException {
		StopWatch t = new StopWatch();
		t.start();
		List<NodeStorageManager> activeList = null;
		Integer rdundancy = Integer.valueOf(DmServiceManager.getRedundancy().get());
		try {
			activeList = nodeRepository.getNodeStorgeBySegmentId(segId, rdundancy);
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		;
		if (activeList == null || activeList.size() < 1) {
			throw new DmServiceException("No active dm stroage node manager for process");
		}
		Collections.shuffle(activeList);
		String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(activeList.get(0).getNsmId());
		nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmDownloadMeghod() + segId;
		log.info(nodeUrl);
		byte[] result = HttpPoster.getSegment(nodeUrl, segId);
		if (null == result) {
			throw new DmServiceException("faild to get template from " + nodeUrl + ". segId=" + segId);
		}
		t.stop();
		PerformanceLogger.trace("dispatchDownloadReqeust", segId.toString(), null, t.elapsedTime());
		return result;
	}
}
