package com.nec.aim.dm.dmservice.entity;

import lombok.Data;

@Data
public class SegBioNsmUrl {
	 private String url;
	 private Long segmentId;
	 private Long bioId;

}
