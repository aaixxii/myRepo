CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_contact_time`(
IN p_unit_id int,
IN p_unit_type int)
BEGIN
    DECLARE l_current_epoch_time BIGINT;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SET  @@autocommit=0; 
  SELECT UNIX_TIMESTAMP(NOW()) into l_current_epoch_time;  
  IF p_unit_type = 3 THEN
    UPDATE MU_CONTACTS
    SET CONTACT_TS =  l_current_epoch_time
    WHERE MU_ID = p_unit_id;

  ELSEIF p_unit_type = 1 THEN
    UPDATE DM_CONTACTS
    SET CONTACT_TS =  l_current_epoch_time
    WHERE DM_ID = p_unit_id;

  ELSEIF p_unit_type = 2 THEN
    UPDATE DM_CONTACTS
    SET CONTACT_TS =  l_current_epoch_time
    WHERE DM_ID = p_unit_id;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
END