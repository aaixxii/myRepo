CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_inquiry_load`(
IN p_mu_id int,
IN p_inquiry_load BIGINT
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_count int;
   DECLARE l_current_epoch_time BIGINT;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  SET  @@autocommit=0; 
  SELECT UNIX_TIMESTAMP(NOW()) into l_current_epoch_time; 
  SELECT
    COUNT(PRESSURE) INTO l_count
  FROM MU_INQUIRY_LOAD
  WHERE MU_ID = p_mu_id;
  IF l_count = 0 THEN
    INSERT INTO MU_INQUIRY_LOAD (MU_ID,
    PRESSURE,
    REPORT_TS)
      VALUES (p_mu_id, p_inquiry_load, l_current_epoch_time);
  ELSE
    UPDATE MU_INQUIRY_LOAD
    SET PRESSURE = p_inquiry_load,
        REPORT_TS = l_current_epoch_time
    WHERE MU_ID = p_mu_id;
    SELECT
      ROW_COUNT() INTO l_count; 
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;  
  ELSE
    COMMIT;
  END IF;
END