CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_after_planned`(
IN p_job_id BIGINT(38),
IN p_container_id int,
IN p_container_job_id BIGINT(38),
IN p_function_id int,
IN p_plans_string varchar(1024),
OUT r_plan_id BIGINT(38))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_current_time int;
  DECLARE l_failure_count int;
  DECLARE t_error integer DEFAULT 0; 
  DECLARE  not_found integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
  SET  @@autocommit=0;
  SELECT
    FAILURE_COUNT INTO l_failure_count
  FROM JOB_QUEUE
  WHERE JOB_ID = p_job_id;
  SET l_failure_count = l_failure_count + 1;
  SELECT UNIX_TIMESTAMP(NOW()) into l_current_time;

  INSERT INTO MU_JOB_EXECUTE_PLANS (PLANED_TS,
  CONTAINER_ID,
  FUNCTION_ID,
  PLAN,
  PLANED_COUNT,
  JOB_ID)
    VALUES (l_current_time, p_container_id, p_function_id, p_plans_string, l_failure_count, p_job_id);
    
  SELECT MAX(PLAN_ID) INTO r_plan_id from MU_JOB_EXECUTE_PLANS;
  UPDATE JOB_QUEUE
  SET JOB_STATE = 1,
      ASSIGNED_TS = l_current_time
  WHERE JOB_ID = p_job_id
  AND JOB_STATE = 0;

UPDATE CONTAINER_JOBS
SET    JOB_STATE = 1,
       PLAN_ID = r_plan_id
WHERE  CONTAINER_ID = p_container_id
       AND CONTAINER_JOB_ID = p_container_job_id; 
  IF t_error = 1 THEN
    ROLLBACK;
  ELSE
    COMMIT;
  END IF;
END