package com.nec.aim.client.freign.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nec.aim.client.freign.AimFreignClient;
import com.nec.aim.client.freign.entity.PersonBioMetrics;


@RequestMapping("/client")
@RestController
//@Slf4j
public class PersonBioMetricsController {
	
	@Autowired
	private AimFreignClient aimFreignClient;

	
	@GetMapping("/pernsonBio/{id}")
	public PersonBioMetrics findById(@PathVariable Long id) {
		return this.aimFreignClient.findPersonById(id);	
	}

	
	@GetMapping("/pernsonBio/all")
	public List<PersonBioMetrics> findAll() {
		return this.aimFreignClient.findAll();		
	}
}
