package com.nec.aim.client.freign.entity;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class PersonBioMetrics {	
	  private Long biometricsId;	  
	  private String externalId;	  
	  private String biometricData;	 
	  private Integer size;	
	  private BigDecimal containerId;  

}
