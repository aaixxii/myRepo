package com.nec.aim.client.freign.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nec.aim.client.freign.AimFreignClient;

@RequestMapping("/client")
@RestController
//@Slf4j
public class AimServerController {

	@Autowired
	private AimFreignClient aimFreignClient;
	
	@GetMapping("/serverStatus")
	public String getAimServerStatus() {
		return this.aimFreignClient.getAimServerStatus();
	
	}


}
