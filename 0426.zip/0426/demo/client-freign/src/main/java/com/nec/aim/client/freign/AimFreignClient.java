package com.nec.aim.client.freign;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nec.aim.client.freign.AimFeignClientFallback.AimFeignClientFallbackFactory;
import com.nec.aim.client.freign.entity.PersonBioMetrics;
import com.nec.aim.client.freign.entity.User;

import feign.hystrix.FallbackFactory;


@FeignClient(name = "aim-service", fallbackFactory = AimFeignClientFallbackFactory.class)
public interface AimFreignClient {
	@GetMapping("/users/{id}")
	User findById(@PathVariable("id") Long id);

	@GetMapping("/serverStatus")
	public String getAimServerStatus();

	@GetMapping("/pernsonBio/{id}")
	public PersonBioMetrics findPersonById(@PathVariable Long id);

	@GetMapping("/pernsonBio/all")
	public List<PersonBioMetrics> findAll();

}

@Component
class AimFeignClientFallback implements AimFreignClient {

	@Override
	public User findById(Long id) {
		return new User(id, "default user", "default user", 0, new BigDecimal(1));
	}

	@Override
	public String getAimServerStatus() {		
		return "Localhost status is unknown.";
	}

	@Override
	public PersonBioMetrics findPersonById(Long id) {		
		return new PersonBioMetrics(id, "default external", "default data", 0, new BigDecimal(1));
	}

	@Override
	public List<PersonBioMetrics> findAll() {
		return null;
	}

	@Component
	class AimFeignClientFallbackFactory implements FallbackFactory<AimFreignClient> {
		@Override
		public AimFreignClient create(Throwable cause) {			
			return new  AimFreignClient() {

				@Override
				public User findById(Long id) {
					return new User(id, "default user", "default user", 0, new BigDecimal(1));
				}

				@Override
				public String getAimServerStatus() {
					return "Localhost status is unknown.";
				}

				@Override
				public PersonBioMetrics findPersonById(Long id) {
					return new PersonBioMetrics(id, "default external", "default data", 0, new BigDecimal(1));
				}

				@Override
				public List<PersonBioMetrics> findAll() {
					List<PersonBioMetrics> pbList = new ArrayList<>();
					return pbList;					
				}				
			};
		}
	}
}
