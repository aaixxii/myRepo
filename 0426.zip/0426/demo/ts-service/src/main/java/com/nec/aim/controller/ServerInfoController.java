package com.nec.aim.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServerInfoController {	
	
	@Autowired
	Environment environment;
	
	@GetMapping("/serverStatus")
	public String healthStatus() {		
		String serverPort = environment.getProperty("local.server.port");
		String msg =  " my host : localhost, my port : " + serverPort + ",my status : OK" ;
		return msg;
	}
}
