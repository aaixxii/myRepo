CREATE DEFINER=`aimuser`@`%` PROCEDURE `find_unaggregated_jobs`(
    out  tab_name VARCHAR(50)
)
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE l_epoch_time long;
  DECLARE l_detect_time long;
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DROP TABLE IF EXISTS unaggregated_jobs;
 CREATE TABLE unaggregated_jobs(id bigint(38)) engine=InnoDB;
  SET l_epoch_time := UNIX_TIMESTAMP(NOW());  
  SELECT
    CAST(PROPERTY_VALUE AS UNSIGNED)  INTO l_detect_time
  FROM SYSTEM_CONFIG
  WHERE PROPERTY_NAME = 'JOB_AGGREGATION.AUTO_DETECT_TIME';
  INSERT INTO unaggregated_jobs(id)
  SELECT
    jq.JOB_ID
  FROM JOB_QUEUE jq
  WHERE jq.JOB_STATE = 1
  AND jq.REMAIN_JOBS = 0
  -- check if TopLevelJob has a record in container_jobs 
  AND EXISTS (SELECT
      cj.CONTAINER_JOB_ID
    FROM FUSION_JOBS fj,
         CONTAINER_JOBS cj
    WHERE fj.JOB_ID = jq.JOB_ID
    AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID)
  -- check if all container_jobs record is DONE. 
  AND NOT EXISTS (SELECT
      cj.CONTAINER_JOB_ID
    FROM FUSION_JOBS fj,
         CONTAINER_JOBS cj
    WHERE fj.JOB_ID = jq.JOB_ID
    AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID
    AND cj.JOB_STATE != 2)
  -- select TopLevelJob whose CONTAINER_JOBS are DONE but not aggregated for l_detect_time/1000 second  
  AND EXISTS (SELECT
      MAX(cj.RESULT_TS)
    FROM FUSION_JOBS fj,
         CONTAINER_JOBS cj
    WHERE jq.JOB_ID = fj.JOB_ID
    AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID
    GROUP BY jq.JOB_ID
     HAVING MAX(cj.RESULT_TS) < l_epoch_time - l_detect_time)      
  ORDER BY jq.JOB_ID;
   set tab_name =  'unaggregated_jobs';
  	IF t_error=1 THEN	  
        set tab_name =  '';
    ELSE
       commit;
	END IF;  
END