package jp.co.nec.aim.mm.procedure;

import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;
import jp.co.nec.aim.mm.logger.PerformanceLogger;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.object.StoredProcedure;

import com.google.common.base.Joiner;

/**
 * 
 * @author xiazp
 *
 */
public class GetMuPressureAbilityProcedure extends StoredProcedure {
	private static final String GET_MU_PRESSURE_ABILITY = "get_mu_pressure_ability";
	private JdbcTemplate jdbcTemplate;
	private Integer[] muIdArray;
	private String muIdStr;

	public GetMuPressureAbilityProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(GET_MU_PRESSURE_ABILITY);
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));		
		declareParameter(new SqlParameter("p_mu_ids", Types.VARCHAR));
		compile();
	}

	public Integer[] getMuIdArray() {
		return muIdArray;
	}

	public void setMuIdArray(Integer[] muIdArray) {
		this.muIdArray = muIdArray;
	}
	
	

	/**
	 * 
	 * @param muId
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	@SuppressWarnings("unchecked")
	public List<MuCpuAndPressure> getMuPressureAndAbility(Integer[] muIds)
			throws DataAccessException, SQLException {
		if (muIds.length < 1) {
			throw new IllegalArgumentException(
					"muIds == null when call getMuPressureAndAbility procedure");
		}
		this.muIdStr = Joiner.on(",").skipNulls().join(muIds);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_ids", muIdStr);
		Map<String, Object> resultMap = execute(new HashMap<String, Object>());		
		String tableName = (String) map.get("tab_name");
		String sql = "select * from " + tableName;
		List<Long> timeOutJobList = jdbcTemplate.queryForList(sql, Long.class);		
		jdbcTemplate.execute("DROP TABLE IF EXISTS " +  tableName);
		List<MuCpuAndPressure> muCpuandPressureList = (List<MuCpuAndPressure>) resultMap
				.get("p_refcursor");
		return muCpuandPressureList;
	}

	public String getMuIds() {
		return muIdStr;
	}

	public void setMuIds(String muIds) {
		this.muIdStr = muIds;
	}

	/**
	 * 
	 * @author xiazp
	 *
	 */
	@SuppressWarnings("unused")
	private class CursorMapper implements RowMapper<MuCpuAndPressure> {
		@Override
		public MuCpuAndPressure mapRow(ResultSet rs, int row)
				throws SQLException {
			MuCpuAndPressure oneResult = new MuCpuAndPressure();
			oneResult.setMuId(rs.getInt("mu_id"));
			oneResult.setAbility(rs.getDouble("ability"));
			oneResult.setPressure(rs.getLong("pressure"));
			oneResult.setReportTs(rs.getLong("report_ts"));
			return oneResult;
		}
	}
}
