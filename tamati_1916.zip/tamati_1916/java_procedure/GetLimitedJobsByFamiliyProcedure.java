package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * 
 * @author xiazp
 *
 */
public class GetLimitedJobsByFamiliyProcedure extends StoredProcedure {
	private static final String GET_LIMITED_JOBS_BY_FAMILIY = "get_limited_jobs_by_familiy";
	private JdbcTemplate jdbcTemplate;

	public GetLimitedJobsByFamiliyProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);		
		setSql(GET_LIMITED_JOBS_BY_FAMILIY);
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));
		compile();
	}

	/**
	 * 
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	public List<Long> getLimitedJobsByFamiliy() throws DataAccessException,
			SQLException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		Map<String, Object> map = execute(new HashMap<String, Object>());		
		String tableName = (String) map.get("tab_name");
		if (StringUtils.isBlank(tableName)) return null;
		String sql = "select * from " + tableName;
		List<Long> limitJobList = jdbcTemplate.queryForList(sql, Long.class);
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());
		jdbcTemplate.execute("DROP TABLE IF EXISTS " +  tableName);
		return limitJobList;		
	}
}
