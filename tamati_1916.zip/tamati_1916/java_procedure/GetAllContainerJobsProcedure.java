package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

public class GetAllContainerJobsProcedure extends StoredProcedure {
	private static final String SQL = "get_container_results";
	private JdbcTemplate jdbcTemplate;

	public GetAllContainerJobsProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_job_id", Types.NUMERIC));
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));
		compile();
	}

	/**
	 * Returns JOB_QUEUE.REMAIN_JOBS if succeeded update MU_JOBS to DONE
	 * 
	 * @param jobId
	 *            JOB_ID
	 * @param containerJobId
	 * @param result
	 * @return JOB_QUEUE.REMAIN_JOBS if succeeded. -1 If it failed
	 */
	public List<byte[]> action(long topleveljob) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", topleveljob);
		Map<String, Object> resultMap = execute(map);
		String tableName = (String) resultMap.get("tab_name");
		String sql = "select * from " + tableName;
		List<byte[]> cJobResultList = jdbcTemplate.queryForList(sql, byte[].class);		
		//String sql = "select * from " + tableName;		
		jdbcTemplate.execute("DROP TABLE IF EXISTS " +  tableName);
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute", stopWatch.elapsedTime());
		stopWatch.stop();
		return cJobResultList;
	}

	@SuppressWarnings("unused")
	private class SuccessCursorMapper implements RowMapper<ContainerJobResult> {
		@Override
		public ContainerJobResult mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			ContainerJobResult containerJobResult = new ContainerJobResult();

			containerJobResult.setContainerJobsResult(rs
					.getBytes("CONTAINER_JOB_RESULT"));
			return containerJobResult;
		}
	}
}
