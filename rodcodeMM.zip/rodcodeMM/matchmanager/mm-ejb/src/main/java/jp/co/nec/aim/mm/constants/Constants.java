package jp.co.nec.aim.mm.constants;

public class Constants {

	public static final String ENCODING_UTF8 = "UTF-8";

	public static final int MAX_TIMED_OUT_JOB_BATCH = 1000;

	public static final String PLAN_MAX_SESSION = "50";

	public static final int SM_SEND_TIMEOUT = 10000;
	
	public static final String dmGetTemplate = "getTemplate";
	
	public static final String dmSync = "dmSyncSegment";
	
	public static final String dmGetTemplateByRefId = "getTemplateByRefId";
	
	public static final String EXT_REQ_ID = "extReqSetting";		
	public static final String EXT_RES_ID = "extResSetting";	
	public static final String INQ_REQ_ID = "inqReqSetting";
	public static final String INQ_RES_IDE = "inqtResSetting";
	public static final String SYNC_REQ_ID = "syncReqSetting";
	public static final String SYNC_RES_ID = "syncResSetting";
	
	public static final String  SEGMENT_CHANGE_LOG_PRIFFIX = "SEGMENT_CHANGE_LOG_"; 
	public static final String  SEGMENT_CHANGE_LOG_SAVE_DAYS = "SEGMENT_CHANGE_LOG_SAVE_DAYS"; 
	public static final String  IN_USING_ADJUST = "IN_USING_ADJUST";
	
	public static final String extLockMapName = "extractLocktMap";
	public static final String extJobResultMapName = "extractJobResutMap";
	public static final String maxSegmetRecordCount = "maxSegmetRecordCount";
	public static final String oneTemplateSize = "oneTemplateSize";
	public static final String personBioLockKey = "personBioLockKey";
	public static final String segmentLockKey = "segmentLockKey";
	public static final String segChangeLogLockKey = "segChangeLogLockKey";
	
}
