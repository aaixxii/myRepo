package jp.co.nec.aim.mm.dao;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author mozj
 * 
 */
public class JobPurgerDao {
	private static Logger log = LoggerFactory.getLogger(JobPurgerDao.class);
	private EntityManager entityManager;

	public JobPurgerDao(EntityManager manager) {
		this.entityManager = manager;
	}

	/**
	 * Delete from job_queue table where result_ts < limitDate by system_config.<br>
	 * Delete from fe_job_queue table where result_ts < limitDate by
	 * system_config.
	 * 
	 * limitDate = system_date - PURGE_JOB_QUEUE.PERIOD_HOUR in system_config.<br>
	 * 
	 * @return purge number of total.
	 */
	public int purgeByResultTs() {
		int purgeResultNum = purgeJobQueue();
		int purgeFeResultNum = purgeFeJobQueue();
		if (log.isInfoEnabled()) {
			StringBuilder sb = new StringBuilder(20);
			sb.append("PURGE FE_JOB_QUEUE : ");
			sb.append(purgeFeResultNum);
			sb.append(" PURGE JOB_QUEUE : ");
			sb.append(purgeResultNum);
			log.info(sb.toString());
		}
		return purgeResultNum + purgeFeResultNum;
	}

	private int purgeJobQueue() {
		Query q = entityManager.createNamedQuery("NQ::clearJobQueueByResultTs");
		return q.executeUpdate();
	}

	private int purgeFeJobQueue() {
		Query q = entityManager
				.createNamedQuery("NQ::clearFeJobQueueByResultTs");
		return q.executeUpdate();
	}

}
