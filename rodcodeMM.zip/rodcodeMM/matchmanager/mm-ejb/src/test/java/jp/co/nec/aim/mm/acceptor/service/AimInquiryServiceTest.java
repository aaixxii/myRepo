package jp.co.nec.aim.mm.acceptor.service;

import static org.junit.Assert.fail;

import java.io.IOException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.util.XmlUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimInquiryServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private AimInquiryService aimInquiryService;
	@Resource
	private JdbcTemplate jdbcTemplate;
	
	@Before
	public void setUp() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FUSION_JOBS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");		
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.execute("commit");
		setMockMethod();		
	}

	@After
	public void tearDown() {

		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FUSION_JOBS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");		
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.execute("commit");

	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};		

	}
	
	@Test
	public void inquiryByTemplateTest() throws IOException {
		String inquiryRequests = XmlUtil.buildInquiryRequest("request1", "refId1", "http://localhost");
		 Boolean result = aimInquiryService.inquiry(inquiryRequests, true);		
		Assert.assertNotNull(result);
	}
	
	@Test
	public void inquiryByReferIdTest() throws IOException {
		String identifyRequests = XmlUtil.buildInquiryRequest("request1", "refId1", "http://localhost");
		Boolean result = aimInquiryService.inquiry(identifyRequests, true);
	
		String sql = "insert into FE_JOB_QUEUE (JOB_ID,UIDAI_REQUEST_ID, UID_REQUEST_TYPE, FUNCTION_ID,REFERENCE_ID,JOB_STATE,SUBMISSION_TS, RESULT) "
				+ "values(2000,'test', 'Identify', 17,'enrollId1',1, 333, ?)";
		jdbcTemplate.update(sql, new Object[] {result});
		
		Boolean resultd = aimInquiryService.inquiry(identifyRequests, true);		
		Assert.assertNotNull(resultd);
	}

	
	@Test(expected = Exception.class)
	public void inquiryByTemplateTestHaveProtobufErr() throws IOException {
		String identifyRequests = XmlUtil.buildInquiryRequest("request1", "refId1", "http://localhost");
		Boolean result = aimInquiryService.inquiry(identifyRequests, true);	
		aimInquiryService.inquiry(identifyRequests, true);
		
	}
	
	@Test
	public void testDeleteJob() throws IOException {
		jdbcTemplate
				.update("INSERT INTO JOB_QUEUE(JOB_ID,UIDAI_REQUEST_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,'test',5,0,123,1,0,123,0,0,1)");
		jdbcTemplate
				.update("INSERT INTO JOB_QUEUE(JOB_ID, UIDAI_REQUEST_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(25,'tet1',5,0,123,1,0,123,0,0,1)");
		jdbcTemplate.execute("commit");
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from job_queue", Integer.class));	
		String deleteJobReq = XmlUtil.buildDeleteRequest("request1", "refId1");
		aimInquiryService.deleteJob(deleteJobReq);
		
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from job_queue", Integer.class));

	}

	@Test
	public void testDeleteJobNull() throws IOException {		
		String deleteJobReq = XmlUtil.buildDeleteRequest("request1", "refId1");
		aimInquiryService.deleteJob(deleteJobReq);
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from job_queue", Integer.class));
	}

	@Test
	public void testClearJobs() {
		aimInquiryService.clearJobs();
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from job_queue", Integer.class));
	}

	@Test
	public void testClearJobsDataBaseException() {
		new MockUp<InquiryJobDao>() {
			@Mock
			public void clearJobs() {
				throw new DataBaseException("1",
						"Exception occurred when clear inquiry job.", "111111", "unknown");
			}
		};
		try {
			aimInquiryService.clearJobs();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof DataBaseException);
			DataBaseException exception = (DataBaseException) e;
			Assert.assertEquals(
					"Inquiry Service (DataBase error occurred, error:Exception occurred when clear inquiry job.)",
					exception.getDescription());
			Assert.assertEquals(AimError.INQ_DB.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Service (DataBase error occurred, error:Exception occurred when clear inquiry job.)",
					e.getMessage());
			return;
		} finally {
			
		}
		fail();

	}


}
