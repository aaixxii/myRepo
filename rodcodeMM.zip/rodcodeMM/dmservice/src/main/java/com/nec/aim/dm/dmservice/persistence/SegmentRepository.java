package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import com.nec.aim.dm.dmservice.entity.SegmentInfo;

public interface SegmentRepository {
	
	/**
	 * @param segInfo
	 * @throws SQLException
	 */
	public void insertSegment(SegmentInfo segInfo)  throws SQLException;
	//public void updateForSegmentCreated(SegmentInfo segInfo)  throws SQLException;	
	/**
	 * @param segInfo
	 * @throws SQLException
	 */
	public void updateSegment(SegmentInfo segInfo)  throws SQLException;
	//public void deleteBioFromSegment(SegmentInfo segInfo)  throws SQLException;
	/**
	 * @param segInfo
	 * @throws SQLException
	 */
	public void updateSegmentAfterDelete(SegmentInfo segInfo)  throws SQLException;	
	/**
	 * @param segInfo
	 * @throws SQLException
	 */
	public void setFaildSegmentVer(SegmentInfo segInfo) throws SQLException;
	/**
	 * @param segInfo
	 * @throws SQLException
	 */
	public void setSuccessSegmentVer(SegmentInfo segInfo) throws SQLException;
	/**
	 * @param version
	 * @param segmentId
	 * @throws SQLException
	 */
	public void updateAfterNew(long version, long segmentId)throws SQLException;
}
