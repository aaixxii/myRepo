package com.nec.aim.dm.dmservice.entity;

import java.sql.Blob;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class SegChangeLog {
	Long segmentChangId;	
	Long  biometricsId;
	String externalId;
	Blob templateData;
	Long segmentId;
	Long segmentVersion;
	Integer changeType; //new:0,insert:1,delete:2,update:3 
	Timestamp lastTs;
}
