﻿解压后复制Protection-4.6.jar到soapui安装的lib目录下面,替换原来的文件即可；
直接打开bin\soapui-pro.bat批处理文件,然后再导入scz.key文件。


or 

 https://github.com/gyk001/soapui-pro-crack/releases


 or

 https://pan.baidu.com/s/1bpDCKNX#list/path=%2F