package jp.co.alsok.g6;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import jp.co.alsok.g6.common.log.ApplicationLog;
import jp.co.alsok.g6.zwu.web.constants.SZWUCommonConstants;

@EnableTransactionManagement
@ComponentScan("jp.co.alsok.g6, jp.co.alsok.g6.common,jp.co.alsok.g6.zzw")
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class,DataSourceTransactionManagerAutoConfiguration.class})
public class AlsokG6AppApplication {

    @Bean
    public PlatformTransactionManager comTransactionManager(@Qualifier("com") DataSource comDataSource) {
        return new DataSourceTransactionManager(comDataSource);
    }

    @Bean
    public PlatformTransactionManager g6TransactionManager(@Qualifier("g6") DataSource g6DataSource) {
        return new DataSourceTransactionManager(g6DataSource);
    }

    @Bean
    public PlatformTransactionManager ghsTransactionManager(@Qualifier("ghs") DataSource ghsDataSource) {
        return new DataSourceTransactionManager(ghsDataSource);
    }

    public static void main(String[] args) {
        try {
            ApplicationLog.readConfigurations(SZWUCommonConstants.LOG_SETTING_XML);
        } catch (Exception e) {
            e.printStackTrace();
        }

        SpringApplication.run(AlsokG6AppApplication.class, args);
    }
}
