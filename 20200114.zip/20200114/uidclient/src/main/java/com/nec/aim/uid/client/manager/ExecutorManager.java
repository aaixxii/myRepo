package com.nec.aim.uid.client.manager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorManager {	
	private  static final ExecutorManager INSTANCE = new ExecutorManager();	
	private ExecutorService uidJobExecutor;
	private ExecutorService resultWriteExecutor;
	private ExecutorService monitorExecutor;
	
	public ExecutorManager() {
		uidJobExecutor = Executors.newCachedThreadPool();
		resultWriteExecutor = Executors.newCachedThreadPool();
		monitorExecutor = Executors.newSingleThreadExecutor();
	}
	
	public static ExecutorManager getInstance() {
		return INSTANCE;
	}
	
	public void commitPostJobTask(Runnable task) {
		uidJobExecutor.submit(task);
	}

	public void commitWriteTask(Runnable task) {
		resultWriteExecutor.submit(task);
	}
	public void commitMonitorTask(Runnable task) {
		monitorExecutor.submit(task);
	}
	
	public void shutdown () {		
		uidJobExecutor.shutdown();
		resultWriteExecutor.shutdown();	
		 monitorExecutor.shutdown();
	}
}
