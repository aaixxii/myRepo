package com.nec.aim.uid.client.poster;

import static com.nec.aim.uid.client.common.UidClientConstants.DEFALUT_MM_BASE_URL;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.common.SequenceIdCreator;
import com.nec.aim.uid.client.common.SequenceIdType;
import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.logger.PerformanceLogger;
import com.nec.aim.uid.client.manager.ExecutorManager;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.result.writer.ExtractResultWriter;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBParameterGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequestParameter;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequestParameters;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;


public class ExtractJobPoster implements Runnable {
	private String extParaFilePath;
	private Long extJobTimeOut;	
	private String mmBaseUrl;
	private long batchId;
	private String requestId;
	private Properties prop = new Properties();
	private static Logger logger = LoggerFactory.getLogger("HttpPostLogger");	
	private static final String EXTRACT_URL = "AIMExtractService/extract";
	//"http://localhost:8080/matchmanager/AIMExtractService/extract"
	 private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
	public ExtractJobPoster(String paraFilePath ) {
		this.extParaFilePath = paraFilePath;
	}	

	@Override
	public void run() {			
		ExtractResponse extRes = null;
		ExtractRequest extReq = buildExtractRequest();
		mmBaseUrl = UidCommonManager.getValue(DEFALUT_MM_BASE_URL);	
		String extPostUrl = mmBaseUrl.endsWith("/") ? mmBaseUrl + EXTRACT_URL: mmBaseUrl +"/" + EXTRACT_URL;
		// NumberFormat nfNum = NumberFormat.getNumberInstance();
		// nfNum.setMinimumIntegerDigits(64);
		// nfNum.setGroupingUsed(false);
		//logger.info("prepare post extract job batchJobId={}, requestId={}",nfNum.format(batchId), requestId);
		logger.trace("prepare post extract job batchJobId={}, requestId={}",batchId, requestId);
		OkHttpClient client = new OkHttpClient();
		client.setConnectTimeout(extJobTimeOut/4, TimeUnit.MILLISECONDS); 
		client.setReadTimeout(extJobTimeOut/4, TimeUnit.SECONDS); 
		client.setWriteTimeout(extJobTimeOut/2, TimeUnit.SECONDS); 
		final StopWatch t = new StopWatch();
		t.start();
		  Request request = new Request.Builder()
			      .url(extPostUrl)
			      .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.toByteArray()))
			      .build();
		  try {
			Response response = client.newCall(request).execute();
			t.stop();
			PerformanceLogger.trace("extractPost", batchId, requestId, t.elapsedTime());
			extRes = ExtractResponse.parseFrom(response.body().bytes());
			ExtractResultWriter writeTask = new ExtractResultWriter(extRes.toBuilder());
			ExecutorManager.getInstance().commitWriteTask(writeTask);
			logger.trace("batchJobId:{} http status:{}", this.batchId, response.code());			
		  } catch (Exception e) {
			  logger.error(e.getMessage(), e);
		  }		
	}
	
	private ExtractRequest buildExtractRequest() {
		ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
		batchId = SequenceIdCreator.createNextSequence(SequenceIdType.BATCHJOB_ID);				
		extReq.setBatchJobId(batchId);
		PBBusinessMessage.Builder extPbMsg = PBBusinessMessage.newBuilder();
		PBRequest.Builder req = PBRequest.newBuilder();
		requestId = String.valueOf(SequenceIdCreator.createNextSequence(SequenceIdType.REQUST_ID));
		req.setRequestId(requestId);		
		try (InputStream input = new FileInputStream(extParaFilePath)) {
			prop.load(input);					
			extJobTimeOut = Long.valueOf(prop.getProperty("EXTRACT_JOB_TIME_OUT"));			
			String batchJobType = prop.getProperty("BATCH_TYPE");
			extReq.setType(BatchType.valueOf(batchJobType));
			String refernceId = UUID.randomUUID().toString().toUpperCase();
			String imageFileUrl = prop.getProperty("IMAGE_FILE_URL");
			String checkSum = prop.getProperty("CHECKSUM");	
			String eRequestType = prop.getProperty("E_REQUESET_TYPE");
			req.setRequestType(E_REQUESET_TYPE.valueOf(eRequestType));			
			req.setEnrollmentId(refernceId);
			PBBiometricsData.Builder bioData = PBBiometricsData.newBuilder();
			String bioDataFormat = prop.getProperty("E_BIOMETRIC_DATA_FORMAT");
			if (batchJobType == null || bioDataFormat == null) {
				throw new UidClientException("batchJobType or bioDataFormat is null!");				
			}
			bioData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.valueOf(bioDataFormat));
			PBBiometricElement.Builder bioElement = PBBiometricElement.newBuilder();
			bioElement.setFilePath(imageFileUrl);
			bioElement.setChecksum(checkSum);
			bioData.setBiometricElement(bioElement.build());
			req.setBiometricsData(bioData.build());
			PBRequestParameters.Builder extReqParam = PBRequestParameters.newBuilder();			
			Integer groupNameCount = Integer.valueOf(prop.getProperty("GROUP_NAME_COUNT"));
			for (int i = 1; i <= groupNameCount; i++) {
				String requestParamters = prop.getProperty("REQUEST_PARAMETER" + i);
				String[] paramArr = requestParamters.split("#");
				String gpName = paramArr[0];
				String keyValusList = paramArr[1];
				String[] keyValueArr = keyValusList.split(",");
				PBParameterGroup.Builder pbPG = PBParameterGroup.newBuilder();
				pbPG.setGroupName(gpName);
				for (int j = 0; j < keyValueArr.length; j++) {
					PBRequestParameter.Builder pbParam = PBRequestParameter.newBuilder();
					String[] tmp = keyValueArr[j].split(":");
					pbParam.setParameterName(tmp[0]);
					pbParam.setParameterValue(tmp[1]);
					pbPG.addRequestParameter(pbParam.build());
				}
				extReqParam.addParameterGroup(pbPG.build());
			}	
			req.setRequestParameters(extReqParam.build());
			extPbMsg.setRequest(req.build());
			extReq.addBusinessMessage(extPbMsg.build().toByteString());			
			logger.info("created extract request, batchJobId={}, batchtype={}", batchId, batchJobType);
		} catch (Exception e) {
			throw new UidClientException(e.getMessage(), e);			
		}		
		return extReq.build();
	}
}
