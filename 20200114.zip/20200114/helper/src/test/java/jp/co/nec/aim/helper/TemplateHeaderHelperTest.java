package jp.co.nec.aim.helper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import jp.co.nec.aim.helper.DataAdapterException;
import jp.co.nec.aim.helper.SegmentFileConstants;
import jp.co.nec.aim.helper.TemplateHeaderHelper;

import org.junit.Test;


/**
 * Test class for TemplateHeaderHelper
 * @author kurosu
 *
 */
public class TemplateHeaderHelperTest {
	
	@Test
	public void testPrependHeader() {
		byte[] data = new byte[10];
		String externalId =  "external-00001"; 
		try {
			TemplateHeaderHelper.prependHeader(-1L, data, externalId, 1);
			fail("IllegalArgumentException should be thrown");
		} catch (IllegalArgumentException e) {
		}
		
		try {
			TemplateHeaderHelper.prependHeader(1L, null,  externalId, 1);
			fail("IllegalArgumentException should be thrown");
		} catch (IllegalArgumentException e) {
		}
		
		try {
			TemplateHeaderHelper.prependHeader(1L, data, null, 1);
			fail("IllegalArgumentException should be thrown");
		} catch (IllegalArgumentException e) {
		}
		
		try {
			TemplateHeaderHelper.prependHeader(1L, data, externalId, -1);
			fail("IllegalArgumentException should be thrown");
		} catch (IllegalArgumentException e) {
		}
		 
		try {
			TemplateHeaderHelper.prependHeader(1L, data, "0123456789012345678901234567890123456789", 1);
			fail("IllegalArgumentException should be thrown");
		} catch (IllegalArgumentException e) {
		}
		 
		
		byte[] header = TemplateHeaderHelper.prependHeader(1L, data, externalId, 1);
		assertEquals(1 + SegmentFileConstants.SIZE_TEMPLATE_HEADER + data.length, header.length);
		
		byte[] header1 = TemplateHeaderHelper.prependHeader(1L, data, externalId, 0);
		assertEquals(1 + SegmentFileConstants.SIZE_TEMPLATE_HEADER + data.length, header1.length);
	}
	
	@Test
	public void TestCheckSum() {
		byte[] data = new byte[10];
		String externalId =  "external-00001"; 
		try {
			TemplateHeaderHelper.validateChecksum(1L, data, 1, externalId, (byte)0);
			fail("DataAdapterException should be thrown");
		} catch (DataAdapterException e) {
		}
		
		byte[] header = TemplateHeaderHelper.prependHeader(1L, data, externalId, 1);
		TemplateHeaderHelper.validateChecksum(1L, data, 1, externalId, header[0]);
	}
	
	@Test
	public void testCheckSum() {
		byte[] templateHead = "abcdefjhijklmopqrstuvwxyz".getBytes();
		templateHead[0] = TemplateHeaderHelper.getCheckSum(templateHead, 1);
	    byte result = templateHead[0];	   
		System.out.println(result);
		int real = templateHead.length;
		System.out.println(real);
		
	}

}
