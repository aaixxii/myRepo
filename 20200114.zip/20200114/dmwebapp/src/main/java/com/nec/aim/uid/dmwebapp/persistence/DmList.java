package com.nec.aim.uid.dmwebapp.persistence;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "dmlist")
public class DmList {
    @PrimaryKeyColumn(name="dm_id", ordinal = 0, type = PrimaryKeyType.PARTITIONED, ordering = Ordering.DESCENDING) 
    int dmId;
    
    @Column(value = "url")
    String url;
    
    @Column(value = "status")
    String status;

    public int getDmId() {
        return dmId;
    }

    public void setDmId(int dmId) {
        this.dmId = dmId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    } 
    
    @Override
    public boolean equals(Object obj) {
        return false;
    }
   
    @Override
    public int hashCode() {
        return 0;        
    }
    
}
