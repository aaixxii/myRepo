
package com.nec.aim.uid.dmwebapp.conf;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.config.CassandraClusterFactoryBean;
import org.springframework.data.cassandra.config.CassandraSessionFactoryBean;
import org.springframework.data.cassandra.core.CassandraAdminTemplate;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;

import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.PlainTextAuthProvider;
import com.datastax.driver.core.QueryOptions;
import com.datastax.driver.core.policies.DefaultRetryPolicy;

/**
 * @author xiazp
 *
 */
@Configuration
@PropertySource(value = { "classpath:cassandra.yml" })
@ConfigurationProperties("spring.data.cassandra")
@EnableCassandraRepositories(basePackages = "com.nec.aim.uid.dmwebapp.persistence")
public class CassandraConfig extends AbstractCassandraConfiguration {
    
    @Value("${cassandra.keyspace-name}")
    private String keyspaceName;
    
    @Value("${cassandra.contact-points}")
    private String hosts;
    
    @Value("${cassandra.port}")
    private int port;
    
    @Value("${cassandra.cluster-name}")
    private String clusterName;
    
    @Value("${cassandra.username}")
    private String userName;
    
    @Value("${cassandra.password}")
    private String password;	

	@Override
	protected String getKeyspaceName() {
		return this.keyspaceName;
	}
	
//	  @Bean
//	    public CassandraClusterFactoryBean cluster() {
//	        CassandraClusterFactoryBean cluster = new CassandraClusterFactoryBean();
//	        cluster.setUsername(userName);
//	        cluster.setPassword(password);
//	        cluster.setContactPoints(hosts);
//	        return cluster;
//	    }
	
	  @Override
	    @PrimaryKey
	    @Bean(name = "cassandraTemplate")
	    public CassandraAdminTemplate cassandraTemplate() {
	        return new CassandraAdminTemplate(Objects.requireNonNull(session().getObject()), cassandraConverter());
	    }	
	  
	    @Bean(name = "cluster")
	    public CassandraClusterFactoryBean cluster() {
	        CassandraClusterFactoryBean cluster = new CassandraClusterFactoryBean();
	        PlainTextAuthProvider plainTextAuthProvider = new PlainTextAuthProvider(userName,password);

	        cluster.setContactPoints(hosts);
	        cluster.setPort(port);
	        cluster.setRetryPolicy(DefaultRetryPolicy.INSTANCE);
	        cluster.setAuthProvider(plainTextAuthProvider);
	        return cluster;
	    }	  
	  

	    
	    @Override
	    @Bean(name = "Session")
	    public CassandraSessionFactoryBean session() {

	        CassandraSessionFactoryBean session = new CassandraSessionFactoryBean();

	        session.setCluster(Objects.requireNonNull(cluster().getObject()));
	        session.setConverter(cassandraConverter());
	        session.setKeyspaceName(getKeyspaceName());
	        session.setSchemaAction(getSchemaAction());
	        session.setStartupScripts(getStartupScripts());
	        session.setShutdownScripts(getShutdownScripts());

	        return session;
	    }

	    
	    @Override
	    public QueryOptions getQueryOptions() {
	        QueryOptions queryOptions = new QueryOptions();
	        queryOptions.setConsistencyLevel(ConsistencyLevel.QUORUM);
	        return queryOptions;
	    }
	
}
