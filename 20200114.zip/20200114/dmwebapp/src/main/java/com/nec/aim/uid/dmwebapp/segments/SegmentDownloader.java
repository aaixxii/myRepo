package com.nec.aim.uid.dmwebapp.segments;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Transactional
@Slf4j
public class SegmentDownloader {
	
	public byte[] getSegmentData(long segmentId) {
		
		
		log.info("");
		return null;
		
	}
	
	

}
