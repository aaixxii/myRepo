package com.nec.aim.uid.dmwebapp.persistence;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Session;

public class CassandraConnector implements AutoCloseable {
    
    private static final CassandraConnector CASSANDRA_CONNECTOR = new CassandraConnector();
    private Cluster cluster;
    private Session pooledSession;
    
    private CassandraConnector() {        
    }
    
    public static CassandraConnector getInstance() {
        return CASSANDRA_CONNECTOR;
    }
    
    public Session getPooledSession () {
        
        return pooledSession;
        
    }
    
    
    private void closeSession() {
        if (pooledSession != null) {
            try {
                pooledSession.close();
            } catch (Throwable th) {
            } finally {
                pooledSession = null;
            }
        }
    }

    private void closeCluster() {
        if (cluster != null) {
            try {
                cluster.close();
            } catch (Throwable th) {
            } finally {
                cluster = null;
            }
        }
    }

    @Override
    public void close() throws Exception {
        closeSession();
        closeCluster();        
    }
    
}
