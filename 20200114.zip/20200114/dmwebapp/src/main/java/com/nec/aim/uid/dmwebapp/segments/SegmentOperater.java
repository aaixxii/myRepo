package com.nec.aim.uid.dmwebapp.segments;

import static com.nec.aim.uid.dmwebapp.segments.DmConstants.SEGMENT_HEADER_SIZE;
import static com.nec.aim.uid.dmwebapp.segments.DmConstants.SIZE_TEMPLATE_HEADER;

import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Transactional
@Slf4j
public class SegmentOperater {
	public static final int AIM_VERSION = 2;
	public static final short FORMAT_ID = 1;
	public static long MAX_SEGMENT_SIZE = 20000000;
	public Boolean handerRequest(PBDmSyncRequest dmSegRequest)
			throws InvalidProtocolBufferException, InterruptedException, ExecutionException {
		PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(dmSegRequest.toByteString());
		String changeType = dmSegReq.getCmd().name().toUpperCase();
		long bioId = dmSegReq.getBioId();
		PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
		String externalId = templateInfo.getReferenceId();
		byte[] templateData = templateInfo.getData().toByteArray();
		long segId = dmSegReq.getTargetSegments().getId();
		long segVer = dmSegReq.getTargetSegments().getVersion();		
		if (Objects.isNull(templateData) || templateData.length < 0) {
			log.warn("");
			return false;
		}	
		boolean resulst = false;
		SegmentInfo segInfo = SegmentManager.getSegmentInfo(segId);		
		if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
			if (Objects.isNull(segInfo)) {
				int tSize = SEGMENT_HEADER_SIZE + SIZE_TEMPLATE_HEADER + templateData.length;			
				ByteBuffer segBuf = ByteBuffer.allocate(tSize);
				resulst = newSegment(segBuf, templateData, bioId, externalId, segId, segVer);
			} else {				
				int tSize = segInfo.getLastPosition() + templateData.length;
				//ByteBuffer segBuf = ByteBuffer.allocate(tSize);
				resulst = updateSegment(segInfo, templateData, bioId, externalId, segId, segVer);
			}
		} else {
			if (Objects.isNull(segInfo)) {
              log.warn("can't found segment data{}");
			} else {
				resulst = deleteTemplate(segId, externalId);
			}
		}
		return Boolean.valueOf(resulst);
	}

	private Boolean newSegment(ByteBuffer segBuffer, byte[] data, long bioId, String extId, long segId, long segVer)
			throws InterruptedException, ExecutionException {
		Callable<Boolean> newSegmentTask = () -> {
			SegmentInfo newSeg = new SegmentInfo(segId);
			newSeg.setSegId(segId);
			newSeg.getLocker().writeLock().lock();
			try {
				segBuffer.position(0);
				segBuffer.putInt(AIM_VERSION);
				segBuffer.putShort(FORMAT_ID);
				segBuffer.putLong(MAX_SEGMENT_SIZE);
				segBuffer.putInt(1);
				segBuffer.putLong(segVer);
				byte[] templateWithHeader = TemplateHeadBuilder.prependHeader(bioId, data, extId, 1);
				segBuffer.put(templateWithHeader);
				newSeg.setRecordcount(1);
				segBuffer.position();
				newSeg.setLastPosition(segBuffer.position() -1);
				SegmentManager.saveToQueue(Long.valueOf(segId), newSeg);
				//Save to cassandra				
				
			} finally {
				newSeg.getLocker().writeLock().unlock();
			}
			return true;
		};
		return SegmentManager.submit(newSegmentTask);
	}

	private Boolean updateSegment(SegmentInfo segInfo, byte[] data, long bioId, String extId, long segId, long segVer)
			throws InterruptedException, ExecutionException {
		Callable<Boolean> updateSegmentTask = () -> {
			//ToDo get segmentData from cassandra
			byte[] templateWithHeader = TemplateHeadBuilder.prependHeader(bioId, data, extId, 1);
			segInfo.setRecordcount(segInfo.getRecordcount() + 1);
			segInfo.setLastPosition(segInfo.getLastPosition() + templateWithHeader.length);
			//add data to ca
			return true;
		};
		return SegmentManager.submit(updateSegmentTask);
	}

	private Boolean deleteTemplate(long segId, String extId) throws InterruptedException, ExecutionException {
		Callable<Boolean> delTemplateTask = () -> {
			//ToDo
			return true;
		};
		return SegmentManager.submit(delTemplateTask);
	}	


}
