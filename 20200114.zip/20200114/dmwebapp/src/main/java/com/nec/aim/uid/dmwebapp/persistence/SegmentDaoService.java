package com.nec.aim.uid.dmwebapp.persistence;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.HostDistance;
import com.datastax.driver.core.PoolingOptions;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

public class SegmentDaoService {
    private String insertSql = "insert into BIO_TEMPLATE_DATA_INFO (TEMPLATE_DATA_ID, CREATE_DATETIME, UPDATE_DATETIME, TEMPLATE_DATA) values (?, ?, ?, ?)";
    private String selectSql = "select TEMPLATE_DATA from BIO_TEMPLATE_DATA_INFO where TEMPLATE_DATA_ID=?";
    private String deleteSql = "delete from BIO_TEMPLATE_DATA_INFO where TEMPLATE_DATA_ID=?";
    
    public boolean insert() {
        Cluster cluster = Cluster.builder()
            .withClusterName("myCluster")
            .addContactPoints(new String[] {"192.168.22.106,192.168.21.10"})
            .build();
        Session session = cluster.connect("myKeyspace");
        ResultSet result = session.execute("select * from myTable where id = 1");        
        session.execute("select * from otherKeyspace.otherTable where id = 1");
        Row row = session.execute("select first_name, last_name from users where id = 1").one();
        String firstName = row.getString("first_name");
        
        String keyspace = "bio_matcher";
        int coreConnectionsPerHost = 4;
        int maxConnectionsPerHost = 10;
        int maxRequestsPerLocalConnection = 32768;
        int maxRequestsPerRemoteConnection = 2000;
        int heartbeatIntervalSeconds = 120;
        
        PoolingOptions poolingOptions = new PoolingOptions();
        poolingOptions.setCoreConnectionsPerHost(HostDistance.LOCAL, coreConnectionsPerHost)
        .setMaxConnectionsPerHost(HostDistance.LOCAL, maxConnectionsPerHost)
        .setMaxRequestsPerConnection(HostDistance.LOCAL, maxRequestsPerLocalConnection)
        .setMaxRequestsPerConnection(HostDistance.REMOTE, maxRequestsPerRemoteConnection)
         .setHeartbeatIntervalSeconds(heartbeatIntervalSeconds);
        Cluster cluster1 = Cluster.builder()
            .addContactPoints(new String[] {"192.168.22.106,192.168.21.10"})
            .withPort(9042)
            .withPoolingOptions(poolingOptions)
            .build();
        
        return false;
        
    }
    
}
