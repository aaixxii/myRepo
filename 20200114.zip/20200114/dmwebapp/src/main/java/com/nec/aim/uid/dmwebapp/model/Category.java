package com.nec.aim.uid.dmwebapp.model;

public class Category {

	private Pattern pattern;
	private Template template;

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		Category other = (Category) obj;
		if (this.pattern == null) {
			if (other.pattern != null) {
				return false;
			}
		} else if (!this.pattern.equals(other.pattern)) {
			return false;
		}
		if (this.template == null) {
			if (other.template != null) {
				return false;
			}
		} else if (!this.template.equals(other.template)) {
			return false;
		}
		return true;
	}

	public Pattern getPattern() {
		return this.pattern;
	}

	public Template getTemplate() {
		return this.template;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((this.pattern == null) ? 0 : this.pattern.hashCode());
		result = prime * result
				+ ((this.template == null) ? 0 : this.template.hashCode());
		return result;
	}

	public void setPattern(Pattern pattern) {
		this.pattern = pattern;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}

	@Override
	public String toString() {
		return "Category [pattern=" + this.pattern + ", template="
				+ this.template + "]";
	}

}
