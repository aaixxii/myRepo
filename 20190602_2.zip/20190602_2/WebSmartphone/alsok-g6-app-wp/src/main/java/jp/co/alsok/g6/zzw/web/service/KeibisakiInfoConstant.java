package jp.co.alsok.g6.zzw.web.service;

public interface KeibisakiInfoConstant {
    /** ログインユーザ検索DBフラグ(全て) */
    public static final int systemAll = 0;
    /** ログインユーザ検索DBフラグ(次期) */
    public static final int systemG6 = 1;
    /** ログインユーザ検索DBフラグ(GHS) */
    public static final int systemGhs = 2;
    /** ログインユーザ検索DBフラグ(GV) */
    public static final int systemGv = 3;
    /** ログインユーザ検索DBフラグ(次期、GHS) */
    public static final int systemG6Ghs = 4;
    /** ログインユーザ検索DBフラグ(次期、GV) */
    public static final int systemG6Gv = 5;
    /** ログインユーザ検索DBフラグ(ERROR:全てない場合) */
    public static final int systemError = 9;

    /** 検索DBフラグ(全て) */
    public static final int selectDbAll = 0;
    /** 検索DBフラグ(次期のみ) */
    public static final int selectDbG6 = 1;
    /** 検索DBフラグ(GHSのみ) */
    public static final int selectDbGhs = 2;

    /** 次期用:文字列「/」 */
    public static final String pathSlash = "/";

    /** 次期用:論理番号の桁数(20桁) */
    public static final int NUM_LENGTH = 20;

    /** 次期用:「/」の桁数(1桁) */
    public static final int PATH_SLASH_LENGTH = 1;

    /** 次期用:パス情報の桁数(警備先論理番号)41桁 */
    public static final int KEIBI_LENGTH = NUM_LENGTH + PATH_SLASH_LENGTH + NUM_LENGTH;
}
