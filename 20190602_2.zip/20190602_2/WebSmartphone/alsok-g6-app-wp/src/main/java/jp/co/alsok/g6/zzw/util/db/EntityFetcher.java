package jp.co.alsok.g6.zzw.util.db;

import java.io.Closeable;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.NoSuchElementException;

import jp.co.alsok.g6.common.exception.KeibiSystemException;
import jp.co.alsok.g6.common.util.db.entity.AbstractSuperEntity;
import jp.co.alsok.g6.common.util.db.mapper.StatementResultSet;
import jp.co.alsok.g6.common.util.db.mapper.SuperEntityMapper;

/**
 * SELECTの結果を一件ずつ取得するための機能を提供します。
 */
public class EntityFetcher
        implements Iterable<AbstractSuperEntity>, Iterator<AbstractSuperEntity>, Closeable {

    /**
     * ResultSetとPreparedStatementを管理するオブジェクトです。
     */
    private StatementResultSet statementResultSet = new StatementResultSet();

    /**
     * エンティティへのマッパーオブジェクトです。
     */
    private SuperEntityMapper mapper;

    /**
     * ResultSetを最後まで読み込んでいた場合にtrueとなるフラグです。
     */
    private boolean finishedReading;

    /**
     * このクラスのインスタンスを生成します。
     *
     * @param statementResultSet ResultSetとPreparedStatementを管理するオブジェクトです。
     * @param mapper エンティティへのマッパーオブジェクトです。
     * @throws SQLException データベース・アクセス・エラーが発生した場合、またはこのメソッドがクローズされた結果セットで呼び出された場合にスローします。
     */
    public EntityFetcher(StatementResultSet statementResultSet, SuperEntityMapper mapper)
            throws SQLException {
        this.statementResultSet = statementResultSet;
        this.mapper = mapper;

        forwardPointer();
    }

    /**
     * ResultSetのカーソルを一つ進めます。
     *
     * @throws SQLException データベース・アクセス・エラーが発生した場合、またはこのメソッドがクローズされた結果セットで呼び出された場合にスローします。
     */
    private void forwardPointer() throws SQLException {
        finishedReading = !this.statementResultSet.getResultSet().next();
    }

    /**
     * Entityを取得するためのイテレータを返します。
     *
     * @return Entityを取得するためのイテレータです
     */
    @Override
    public Iterator<AbstractSuperEntity> iterator() {
        return this;
    }

    /**
     * 次の要素が存在するかどうかを返します。
     *
     * @return 次の要素が存在する場合trueを返します。
     */
    @Override
    public boolean hasNext() {
        return !finishedReading;
    }

    /**
     * 次のEntityを返します。
     *
     * @return 次のEntityです。
     */
    public AbstractSuperEntity next() {
        if (hasNext()) {
            try {
                AbstractSuperEntity entity = mapper.doBuildEntity(statementResultSet);
                forwardPointer();
                return entity;
            } catch (Exception e) {
                throw new KeibiSystemException(e);
            }
        } else {
            throw new NoSuchElementException("No next entity.");
        }
    }

    /**
     * リソースの解放を行います。
     */
    @Override
    public void close() {
        statementResultSet.close();
    }
}
