package jp.co.alsok.g6.zzw.web.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.xml.bind.DatatypeConverter;

import org.springframework.stereotype.Service;

import jp.co.alsok.g6.zzw.util.StringUtil;
import jp.co.alsok.g6.zzw.web.constants.CommonComponentConstants;

/**
 * 共通関数 - パスワード暗号化.<br>
 */
@Service
public class EncryptionService {

	/**
	 * 文字列に特定文字列を付与し、暗号化を行い返却する.
	 * @param str 暗号化対象
	 * @return 特定文字列付与後の暗号化文字列（40桁）
	 * @throws NoSuchAlgorithmException 暗号アルゴリズムが要求されたにもかかわらず、現在の環境では使用可能でない場合にスローされます。
	 */
	public String convStringToCipher(String str) throws NoSuchAlgorithmException {

		// 必須チェックを行う.
		if (StringUtil.isNullOrEmpty(str)) {
			throw new RuntimeException();
		}

		// インスタンス生成.
		MessageDigest md = MessageDigest.getInstance(CommonComponentConstants.ENCRYPT_HASH_STYLE);

		// 暗号化対象文字列の生成
		String target = str + CommonComponentConstants.ENCRYPT_SALT;

		// 暗号化
		byte[] bytes = md.digest(target.getBytes(StandardCharsets.UTF_8));
		String result = DatatypeConverter.printHexBinary(bytes);

		return result;
	}
}
