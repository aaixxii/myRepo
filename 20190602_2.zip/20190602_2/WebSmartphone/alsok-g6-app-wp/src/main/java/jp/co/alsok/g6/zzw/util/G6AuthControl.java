package jp.co.alsok.g6.zzw.util;

import java.util.List;

public interface G6AuthControl {
    /**
     * 契約先情報
     * @author SSC
     */
    public static class Keiyk {
        /**
         * LN_契約先論理番号
         */
        public String lnKeiyk;
        /**
         * 警備先一覧
         */
        public List<Keibi> keibiList;
        /**
         * @return the lnKeiyk
         */
        public String getLnKeiyk() {
            return lnKeiyk;
        }
        /**
         * @return the keibiList
         */
        public List<Keibi> getKeibiList() {
            return keibiList;
        }
    }
    
    /**
     * 警備先情報
     * @author SSC
     */
    public static class Keibi {
        /**
         * LN_警備先論理番号
         */
        public String lnKeibi;
        /**
         * 警備先地区一覧
         */
        public List<String> chikuList;
        /**
         * @return the lnKeibi
         */
        public String getLnKeibi() {
            return lnKeibi;
        }
        /**
         * @return the chikuList
         */
        public List<String> getChikuList() {
            return chikuList;
        }
    }
}
