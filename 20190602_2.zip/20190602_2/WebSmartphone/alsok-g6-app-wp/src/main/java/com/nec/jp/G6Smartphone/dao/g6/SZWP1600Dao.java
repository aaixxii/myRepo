package com.nec.jp.G6Smartphone.dao.g6;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class SZWP1600Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	public String getScreenInfoList(String lnKbInf) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	videoFileName");
		strBuilder.append(" FROM	EKbInfModel");
		strBuilder.append(" WHERE	lnKbInf = :lnKbInf");
		strBuilder.append(" ORDER BY sigHasseiTs DESC");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("lnKbInf", lnKbInf);

		return query.getSingleResult().toString();
	}
}
