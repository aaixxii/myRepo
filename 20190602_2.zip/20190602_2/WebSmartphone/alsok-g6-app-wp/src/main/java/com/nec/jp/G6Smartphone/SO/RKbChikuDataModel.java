package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

public class RKbChikuDataModel {

	private String lnKbChiku;		// 警備先地区.LN_警備先地区論理番号
	private String sdKobetuNm;		// 警備先地区.警備地区名称
	private String n0f0Flg;			// 警備先地区状態.N0F0状態フラグ
	private String empStsFlg;		// 警備先地区状態.空室在室状態フラグ
	private String tojimariSts;		// 戸締り確認※GHSの場合、「-」
	private List<String> areaItem;	// 警備エリアが存在するフラグ
	private String subAddr;
	private String chiku;

	public RKbChikuDataModel() {
		this.lnKbChiku = "";
		this.sdKobetuNm = "";
		this.n0f0Flg = "";
		this.empStsFlg = "";
		this.tojimariSts = "";
		this.areaItem = new ArrayList<String>();
		this.subAddr = "";
		this.chiku = "";
	}

	public RKbChikuDataModel(String lnKbChiku, String sdKobetuNm, String n0f0Flg, String empStsFlg) {
		this.lnKbChiku = lnKbChiku;
		this.sdKobetuNm = sdKobetuNm;
		this.n0f0Flg = n0f0Flg;
		this.empStsFlg = empStsFlg;
		this.areaItem = new ArrayList<String>();
	}

	public RKbChikuDataModel(String lnKbChiku, String sdKobetuNm, String n0f0Flg, String empStsFlg, List<String> areaItem) {
		this.lnKbChiku = lnKbChiku;
		this.sdKobetuNm = sdKobetuNm;
		this.n0f0Flg = n0f0Flg;
		this.empStsFlg = empStsFlg;
		this.areaItem = areaItem;
	}
	
	public RKbChikuDataModel(String lnKbChiku, String subAddr, String sdKobetuNm, String chiku,String n0f0Flg, String empStsFlg) {
		this.lnKbChiku = lnKbChiku;
		this.subAddr = subAddr;
		this.sdKobetuNm = sdKobetuNm;
		this.chiku = chiku;
		this.n0f0Flg = n0f0Flg;
		this.empStsFlg = empStsFlg;
		this.areaItem = new ArrayList<String>();
	}

	public String getTojimariSts() {
		return tojimariSts;
	}
	public void setTojimariSts(String tojimariSts) {
		this.tojimariSts = tojimariSts;
	}
	public String getLnKbChiku() {
		return lnKbChiku;
	}
	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}
	public String getSdKobetuNm() {
		return sdKobetuNm;
	}
	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}
	public String getN0f0Flg() {
		return n0f0Flg;
	}
	public void setN0f0Flg(String n0f0Flg) {
		this.n0f0Flg = n0f0Flg;
	}
	public String getEmpStsFlg() {
		return empStsFlg;
	}
	public void setEmpStsFlg(String empStsFlg) {
		this.empStsFlg = empStsFlg;
	}

	public List<String> getAreaItem() {
		return areaItem;
	}

	public void setAreaItem(List<String> areaItem) {
		this.areaItem = areaItem;
	}

	public String getSubAddr() {
		return subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public String getChiku() {
		return chiku;
	}

	public void setChiku(String chiku) {
		this.chiku = chiku;
	}
}
