package com.nec.jp.G6Smartphone.utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

public class DateTimeCommon {

	public static String getCurrentDateTime() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();

		return dtf.format(now);
	}

	public static String getShortCurrentDateTime() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		LocalDateTime now = LocalDateTime.now();

		return dtf.format(now);
	}

	public static String getShortCurrentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
		LocalDateTime now = LocalDateTime.now();

		return dtf.format(now);
	}
	
	public static Date getCurrentDate() throws ApplicationException {
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

			return sdf.parse(dtf.format(now));
		} catch (Exception e) {
			// 日時例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_PARSE_DATETIME.getValue(), errorMsg);
		}
	}

	public static String getCurrentShortDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDateTime now = LocalDateTime.now();

		return dtf.format(now);
	}

	public static Date getDateCurrentShortDate() throws ApplicationException {
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
			LocalDateTime now = LocalDateTime.now();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");

			return sdf.parse(dtf.format(now));
		} catch (Exception e) {
			// 日時例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_PARSE_DATETIME.getValue(), errorMsg);
		}
	}

	public static String formatDateTime(String strDate) {
		try {
			return strDate.toString().replaceAll("-", "/").trim().substring(0, 19);
		} catch (Exception e) {
			return "";
		}
	}

	public static Date stringToDate(String date) throws ApplicationException  {
		try {
			return new SimpleDateFormat("yyyy/MM/dd").parse(date);

		} catch (Exception e) {
			// 日時例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_PARSE_DATETIME.getValue(), errorMsg);
		}
	}
	public static Date stringToDateTime(String date) throws ApplicationException  {
		try {
			return new SimpleDateFormat("yyyy/MM/dd HH:mm").parse(date);

		} catch (Exception e) {
			// 日時例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_PARSE_DATETIME.getValue(), errorMsg);
		}
	}
	public static Date getDateInPast(Date date, int dayInPast) throws ApplicationException {
		try {
			DateFormat dtf = new SimpleDateFormat("yyyy/MM/dd");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);

			if (dayInPast > 0) {
				cal.add(Calendar.DATE, -dayInPast + 1);
			} else {
				cal.add(Calendar.DATE, 0);
			}

			return sdf.parse(dtf.format(cal.getTime()));

		} catch (Exception e) {
			// 日時例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_PARSE_DATETIME.getValue(), errorMsg);
		}
	}
	public static Date datePlusMinute(Date date, int minute) throws ApplicationException {
		try {
			DateFormat dtf = new SimpleDateFormat("yyyy/MM/dd HH:mm");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm");
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.add(Calendar.MINUTE, minute);
			return sdf.parse(dtf.format(cal.getTime()));

		} catch (Exception e) {
			// 日時例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_PARSE_DATETIME.getValue(), errorMsg);
		}
	}
	public static String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS"); // 17
		return sdf.format(new Date());
	}
	public static String toMediaServerFormat(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(date);
	}
	public static float getDuration(Date startTime, Date endTime ) {
		float dur =  (endTime.getTime() - startTime.getTime())/1000;
		return dur;
	}
	
	public static String dateToString(Date date) throws ApplicationException {
		try {
			return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(date);

		} catch (Exception e) {
			// 日時例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_PARSE_DATETIME.getValue(), errorMsg);
		}
	}
}
