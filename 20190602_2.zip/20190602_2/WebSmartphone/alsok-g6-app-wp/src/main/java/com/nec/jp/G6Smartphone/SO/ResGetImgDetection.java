package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetImgDetection implements ErrorHandler {

	private String errorCode;
	private String errorMsg;
	private String picInf;
	private String videoFileName;
	private String acntID;
	
	public ResGetImgDetection() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.picInf = "";
		this.videoFileName = "";
		this.acntID = "";
	}
	public ResGetImgDetection(String errorCode, String errorMsg, String picInf, String videoFileName) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.picInf = picInf;
		this.videoFileName = videoFileName;
		this.acntID = "";
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getPicInf() {
		return picInf;
	}
	public void setPicInf(String picInf) {
		this.picInf = picInf;
	}
	public String getVideoFileName() {
		return videoFileName;
	}
	public void setVideoFileName(String videoFileName) {
		this.videoFileName = videoFileName;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
