package com.nec.jp.G6Smartphone.service.ghs;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.DistrictGHSInfoModel;
import com.nec.jp.G6Smartphone.SO.RKeibiGHSModel;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP1100GhsDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1100GhsService {

	@Autowired
	SZWP1100GhsDao sZWP1100GhsDao;

	public String getElectricNum(String lnKeibi) throws ApplicationException {
		try {
			return sZWP1100GhsDao.getElectricNum(lnKeibi);
		} catch (NoResultException noResultE) {
			return "";
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public RKeibiGHSModel getGoukiSerial(String lnKeibi) throws ApplicationException {
		try {
			return sZWP1100GhsDao.getGoukiSerial(lnKeibi);
		} catch (NoResultException noResultE) {
			return new RKeibiGHSModel();
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public DistrictGHSInfoModel getDistrictInfo(String lnKeibi) throws ApplicationException {
		try {
			return sZWP1100GhsDao.getDistrictInfo(lnKeibi);
		} catch (NoResultException noResultE) {
			return new DistrictGHSInfoModel();
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getDeviceSts(String lnDev) throws ApplicationException {
		try {
			String deviceSts = sZWP1100GhsDao.getDeviceSts(lnDev);
			
			return (deviceSts == null) ? "" : deviceSts;
		} catch (NoResultException noResultE) {
			return "";

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getCmdSts(String cmdSeqNum) throws ApplicationException {
		try {
			return sZWP1100GhsDao.getCmdSts(cmdSeqNum);
		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
