package com.nec.jp.G6Smartphone.SO;


public class RDenkeiMngInfoModel implements DataModelHandler {

	private String lnDenkeiMng;
	private String denkei;
	
	public RDenkeiMngInfoModel() {
		this.lnDenkeiMng = "";
		this.denkei = "";
	}
	
	public RDenkeiMngInfoModel(String lnDenkeiMng, String denkei) {
		this.lnDenkeiMng = lnDenkeiMng;
		this.denkei = denkei;
	}

	public String getLnDenkeiMng() {
		return lnDenkeiMng;
	}

	public void setLnDenkeiMng(String lnDenkeiMng) {
		this.lnDenkeiMng = lnDenkeiMng;
	}

	public String getDenkei() {
		return denkei;
	}

	public void setDenkei(String denkei) {
		this.denkei = denkei;
	}
}
