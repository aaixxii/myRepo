package com.nec.jp.G6Smartphone.utility;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import jp.co.alsok.g6.common.log.ApplicationLog;

public class IgnoreSsl {
    
    private static final ApplicationLog appLog = new ApplicationLog(G6DataSocket.class);
    
    public IgnoreSsl() {
        disableSslVerification();
    }

    public void disableSslVerification() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
                @Override
                public void checkClientTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
                        throws CertificateException {
                }
                @Override
                public void checkServerTrusted(java.security.cert.X509Certificate[] arg0, String arg1)
                        throws CertificateException {
                }
            }};
            // Install the all-trusting trust manager
            final SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            // Create all-trusting host name verifier
            final HostnameVerifier allHostsValid = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (NoSuchAlgorithmException e) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 
        } catch (KeyManagementException e) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 
        } catch (Exception e) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 
        }
    }
}
