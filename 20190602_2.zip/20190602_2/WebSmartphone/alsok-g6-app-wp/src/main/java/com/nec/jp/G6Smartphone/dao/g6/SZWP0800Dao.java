package com.nec.jp.G6Smartphone.dao.g6;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;

@Repository
public class SZWP0800Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;
    
	public RCtlDevDataSubModel getSecureInfo(String lnKbChiku) {
		final StringBuilder strBuilder = new StringBuilder();
		
		// START: Update as the same getSecureInfo of SZWP0400Dao
//		strBuilder.append(" SELECT	IFNULL(chiku.LN_KEIBI, '') as lnKeibi,");
//		strBuilder.append("			IFNULL(chiku.SUB_ADDR, '') as subAddr,");
//		strBuilder.append("			IFNULL(ctl.GOUKI, '') as gouKi,");
//		strBuilder.append("			IFNULL(ctl.SERIAL_NUM, '') as serialNum,");
//		strBuilder.append("         IFNULL(ctl.SD_LINE_KIND, '') as sdLineKind,");
//		strBuilder.append("			keibi.CUSTOMER_NUM1 as customerNum1");
//		strBuilder.append(" FROM	R_KB_CHIKU chiku");
//		strBuilder.append("			INNER JOIN R_DEV dev ON chiku.LN_KB_CHIKU = dev.LN_KB_CHIKU");
//		strBuilder.append("			INNER JOIN R_KEIBI keibi ON chiku.LN_KEIBI = keibi.LN_KEIBI");
//		strBuilder.append("			INNER JOIN R_CTL_DEV ctl ON dev.LN_DEV = ctl.LN_DEV");
//		strBuilder.append(" WHERE	chiku.LN_KB_CHIKU = :lnKbChiku");
//		strBuilder.append("			AND keibi.DEL_FLG = :delFlg");
//		strBuilder.append("			AND chiku.DEL_FLG = :delFlg");
//		strBuilder.append("			AND dev.DEL_FLG = :delFlg");
//		strBuilder.append("			AND ctl.DEL_FLG = :delFlg");
//	
//		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RCtlDevDataSubModel800Result");
//		query.setParameter("lnKbChiku", lnKbChiku);
//		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
//		query.setMaxResults(1);
		
		strBuilder.append(" SELECT * FROM (");
        strBuilder.append("    SELECT");
        strBuilder.append("        IFNULL(R1.LN_KEIBI, '') as lnKeibi,");
        strBuilder.append("        IFNULL(R1.SUB_ADDR, '') as subAddr,");
        strBuilder.append("        IFNULL(R5.GOUKI, '') as gouKi,");
        strBuilder.append("        IFNULL(R5.SERIAL_NUM, '') as serialNum,");
        strBuilder.append("        IFNULL(R5.SD_LINE_KIND, '') as sdLineKind,");
        strBuilder.append("        R2.CUSTOMER_NUM1 as customerNum1");
        strBuilder.append("    FROM R_KB_CHIKU R1 ");
        strBuilder.append("    INNER JOIN R_KEIBI R2 ON R1.LN_KEIBI = R2.LN_KEIBI");
        strBuilder.append("    INNER JOIN R_DEV R3 ON R1.LN_KB_CHIKU = R3.LN_KB_CHIKU");
        strBuilder.append("    INNER JOIN R_DEV_DEV R4 ON R3.LN_DEV = R4.LN_DEV_PAR");
        strBuilder.append("    INNER JOIN R_CTL_DEV R5 ON R4.LN_CTL_DEV = R5.LN_CTL_DEV");
        strBuilder.append("    WHERE R1.DEL_FLG = '0'");
        strBuilder.append("    AND R2.DEL_FLG = '0'");
        strBuilder.append("    AND R3.DEL_FLG = '0'");
        strBuilder.append("    AND R4.DEL_FLG = '0'");
        strBuilder.append("    AND R1.LN_KB_CHIKU = :lnKbChiku");
        strBuilder.append("    UNION");
        strBuilder.append("    SELECT");
        strBuilder.append("        IFNULL(R1.LN_KEIBI, '') as lnKeibi,");
        strBuilder.append("        IFNULL(R1.SUB_ADDR, '') as subAddr,");
        strBuilder.append("        IFNULL(R5.GOUKI, '') as gouKi,");
        strBuilder.append("        IFNULL(R5.SERIAL_NUM, '') as serialNum,");
        strBuilder.append("        IFNULL(R5.SD_LINE_KIND, '') as sdLineKind,");
        strBuilder.append("        R2.CUSTOMER_NUM1 as customerNum1");
        strBuilder.append("    FROM R_KB_CHIKU R1 ");
        strBuilder.append("    INNER JOIN R_KEIBI R2 ON R1.LN_KEIBI = R2.LN_KEIBI");
        strBuilder.append("    INNER JOIN R_DEV R3 ON R1.LN_KB_CHIKU = R3.LN_KB_CHIKU");
        strBuilder.append("    INNER JOIN R_DEV_DEV R4 ON R3.LN_DEV = R4.LN_DEV_CHI");
        strBuilder.append("    INNER JOIN R_CTL_DEV R5 ON R4.LN_CTL_DEV = R5.LN_CTL_DEV");
        strBuilder.append("    WHERE R1.DEL_FLG = '0'");
        strBuilder.append("    AND R2.DEL_FLG = '0'");
        strBuilder.append("    AND R3.DEL_FLG = '0'");
        strBuilder.append("    AND R4.DEL_FLG = '0'");
        strBuilder.append("    AND R1.LN_KB_CHIKU = :lnKbChiku) T");

        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "RCtlDevDataSubModel800Result");
        query.setParameter("lnKbChiku", lnKbChiku);
        query.setMaxResults(1);
        // END: Update as the same getSecureInfo of SZWP0400Dao
        
		return (RCtlDevDataSubModel) query.getSingleResult();
	}

	public ControlQueueStatusModel getControlQueueStsInfo(String cmdSeqNum) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(c.STS, '') as sts,");
		strBuilder.append("			c.SOAP_MSG as soapMsg");
		strBuilder.append(" FROM	C_QUE_CTRL_SIG c");
		strBuilder.append(" WHERE	c.CMD_SEQ_NUM = :cmdSeqNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "ControlQueueStatusModelResult");
		query.setParameter("cmdSeqNum", cmdSeqNum);
		query.setMaxResults(1);
		return (ControlQueueStatusModel) query.getSingleResult();
	}
	
	
}
