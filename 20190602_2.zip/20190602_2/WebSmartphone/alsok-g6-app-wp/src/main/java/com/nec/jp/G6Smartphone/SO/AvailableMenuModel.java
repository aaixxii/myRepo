package com.nec.jp.G6Smartphone.SO;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.nec.jp.G6Smartphone.utility.G6Constant;

@JsonPropertyOrder({ "errorCode", "errorMsg", "acntID", "H_CHK", "H_CHK_KEIBI", "H_CHK_EVENT", "H_CHK_RPERS", "H_CHK_MPERS", "K_OPE", "R_OPE", "G_MEN", "G_MEN_LIVEV", "G_MEN_ACCUM", "A_NOT", "A_ASK" })
public class AvailableMenuModel implements ErrorHandler {
	
	@JsonProperty("errorCode")
	private String errorCode;	// エラーコード

	@JsonProperty("errorMsg")
	private String errorMsg;	// エラーメッセージ

	@JsonProperty("acntID")
	private String acntID;		// アカウントID
	
	@JsonProperty("H_CHK")
	private String hChk;		// 履歴の確認
	
	@JsonProperty("H_CHK_KEIBI")
	private String hChkKeibi;	// 警備履歴一覧画面
	
	@JsonProperty("H_CHK_EVENT")
	private String hChkEvent;	// イベント画像情報画面
	
	@JsonProperty("H_CHK_RPERS")
	private String hChkRpers;	// 登録人物検知履歴画面
	
	@JsonProperty("H_CHK_MPERS")
	private String hChkMpers;	// 重要犯罪者認証検知履歴画面
	
	@JsonProperty("K_OPE")
	private String kOpe;		// 警備操作先一覧画面
	
	@JsonProperty("R_OPE")
	private String rOpe;		// 遠隔設備操作画面
	
	@JsonProperty("G_MEN")
	private String gMen;		// 画像メニュー
	
	@JsonProperty("G_MEN_LIVEV")
	private String gMenLivev;	// ライブ閲覧
	
	@JsonProperty("G_MEN_ACCUM")
	private String gMenAccum;	// 蓄積画像閲覧
	
	@JsonProperty("A_NOT")
	private String aNot;		// お知らせ一覧画面
	
	@JsonProperty("A_ASK")
	private String aAsk;		// お問い合わせ画面

	public AvailableMenuModel() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.acntID = "";
		this.hChk = "";
		this.hChkKeibi = "";
		this.hChkEvent = "";
		this.hChkRpers = "";
		this.hChkMpers = "";
		this.kOpe = "";
		this.rOpe = "";
		this.gMen = "";
		this.gMenLivev = "";
		this.gMenAccum = "";
		this.aNot = "";
		this.aAsk = "";
	}

	public AvailableMenuModel(String errorCode, String errorMsg) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.acntID = "";
	}

	@JsonProperty("errorCode")
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@JsonProperty("errorMsg")
	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	@JsonProperty("acntID")
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}

	@JsonProperty("H_CHK")
	public String getHChk() {
		return hChk;
	}

	public void setHChk(String hChk) {
		this.hChk = hChk;
	}

	@JsonProperty("H_CHK_KEIBI")
	public String getHChkKeibi() {
		return hChkKeibi;
	}

	public void setHChkKeibi(String hChkKeibi) {
		this.hChkKeibi = hChkKeibi;
	}

	@JsonProperty("H_CHK_EVENT")
	public String getHChkEvent() {
		return hChkEvent;
	}

	public void setHChkEvent(String hChkEvent) {
		this.hChkEvent = hChkEvent;
	}

	@JsonProperty("H_CHK_PPERS")
	public String getHChkRpers() {
		return hChkRpers;
	}

	public void setHChkRpers(String hChkRpers) {
		this.hChkRpers = hChkRpers;
	}

	@JsonProperty("H_CHK_MPERS")
	public String getHChkMpers() {
		return hChkMpers;
	}

	public void setHChkMpers(String hChkMpers) {
		this.hChkMpers = hChkMpers;
	}

	@JsonProperty("K_OPE")
	public String getKOpe() {
		return kOpe;
	}

	public void setKOpe(String kOpe) {
		this.kOpe = kOpe;
	}

	@JsonProperty("R_OPE")
	public String getROpe() {
		return rOpe;
	}

	public void setROpe(String rOpe) {
		this.rOpe = rOpe;
	}

	@JsonProperty("G_MEN")
	public String getGMen() {
		return gMen;
	}

	public void setGMen(String gMen) {
		this.gMen = gMen;
	}

	@JsonProperty("G_MEN_LIVEV")
	public String getGMenLivev() {
		return gMenLivev;
	}

	public void setGMenLivev(String gMenLivev) {
		this.gMenLivev = gMenLivev;
	}

	@JsonProperty("G_MEN_ACCUM")
	public String getGMenAccum() {
		return gMenAccum;
	}

	public void setGMenAccum(String gMenAccum) {
		this.gMenAccum = gMenAccum;
	}

	@JsonProperty("A_NOT")
	public String getANot() {
		return aNot;
	}

	public void setANot(String aNot) {
		this.aNot = aNot;
	}

	@JsonProperty("A_ASK")
	public String getAAsk() {
		return aAsk;
	}

	public void setAAsk(String aAsk) {
		this.aAsk = aAsk;
	}
}
