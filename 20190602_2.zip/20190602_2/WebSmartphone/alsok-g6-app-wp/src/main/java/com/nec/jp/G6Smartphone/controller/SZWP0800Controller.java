package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;
import com.nec.jp.G6Smartphone.SO.ErrorDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RDenkeiMngInfoModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuInfoModel;
import com.nec.jp.G6Smartphone.SO.RKbInfoModel;
import com.nec.jp.G6Smartphone.SO.WKbChikuRmInfoModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.dao.ghs.CommonGhsDao;
import com.nec.jp.G6Smartphone.model.EQueCtrlModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP0800Service;
import com.nec.jp.G6Smartphone.service.ghs.CommonGhsService;
import com.nec.jp.G6Smartphone.service.ghs.SZWP0800GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.StringUtils;

import jp.co.alsok.g6.common.log.ApplicationLog;

import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

@Controller
public class SZWP0800Controller {

    private static final ApplicationLog appLog = new ApplicationLog(SZWP0800Controller.class);
    //JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
    @Autowired
    SZWP0800Service sZWP0800Service;
	@Autowired
	SZWP0800GhsService sZWP0800GhsService;
    @Autowired
    CommonService commonService;
    @Autowired
    CommonComService commonComService;
    @Autowired
    CommonGhsDao mCommonGhsDao;
    @Autowired
	CommonGhsService commonGhsService;

    @Value("${timeout}")
    Integer timeout;
    @Value("${cmdVer}")
    String cmdVer;
    @Value("${cmdVer2}")
    String cmdVer2;
    @Value("${timeSleep}")
    Integer timeSleep;
    @Value("${host_name}")
    String hostName;
    @Value("${ignoreTimeRmSet}")
    String ignoreTimeRmSet;
    @Value("${szwp0800.overTime}")
    String overTime;
    @Value("${szwp0800.sleepTime}")
    String sleepTime;
    
    private static final String SUB_ADDR = "sub_adr";

    /*
     * Get data from R_CTL_DEV, R_KB_CHIKU, R_DENKEI_MNG table
     * 
     * @param: acntID, acntNm, lnKeibi, lnKbChiku, (shoriKubun is 3, 4)
     * lnKbArea, shoriKubun return: object errorDataModel as JSON
     */
    @RequestMapping(value = "/deleteKeibiStart", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public @ResponseBody String deleteKeibiStart(@RequestBody String strParam) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0800Controller.deleteKeibiStart()");
        String jsonResult = "";
        String acntLanguage = G6CodeConsts.CD238.JAPANESE;
        ErrorDataModel errorDataModel = new ErrorDataModel();
        Map<String, Object> mapParam = new HashMap<String, Object>();
        String acntType = null;

        try {
            Map<String, Boolean> lstRequiredParam = null;

            // リクエスト情報からパラメータを取得する
            mapParam = G6Common.readParam(strParam);
            
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStart()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStart()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
           
            if (null != mapParam.get(RequestParam.acntID.getValue())
                    && !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
                // 選択言語種別の取得
                acntLanguage = commonComService
                        .getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
            }

            // リクエスト情報を検証する
            if (mapParam.size() != 7 || null == mapParam.get(RequestParam.shoriKubun.getValue())
                    || "".equals(mapParam.get(RequestParam.shoriKubun.getValue()))) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStart()");
                return jsonResult;
            }

            // リクエスト情報検証
            List<String> chkArrParam = new ArrayList<String>() {
                private static final long serialVersionUID = 1L;
                {
                    add(RequestParam.lnKbArea.getValue());
                }
            };

            // リクエスト情報から処理区分を取得する
            String shoriKubun = mapParam.get(RequestParam.shoriKubun.getValue()).toString();

            if ((G6Constant.MYCD001.UNDER_SECURITY).equals(shoriKubun)
                    || (G6Constant.MYCD001.UNPROTECTING).equals(shoriKubun)) {
                // Build require parameters
                lstRequiredParam = new HashMap<String, Boolean>() {
                    private static final long serialVersionUID = 1L;
                    {
                        put(RequestParam.acntID.getValue(), true);
                        put(RequestParam.acntNm.getValue(), true);
                        put(RequestParam.lnKeibi.getValue(), true);
                        put(RequestParam.lnKbChiku.getValue(), true);
                        put(RequestParam.lnKbArea.getValue(), false);
                        put(RequestParam.shoriKubun.getValue(), true);
                        put(RequestParam.acntSbt.getValue(), true);
                    }
                };

            } else if ((G6Constant.MYCD001.UNDER_SECURITY_IN_ROOM).equals(shoriKubun)
                    || (G6Constant.MYCD001.UNPROTECTING_IN_ROOM).equals(shoriKubun)) {
                lstRequiredParam = new HashMap<String, Boolean>() {
                    private static final long serialVersionUID = 1L;
                    {
                        put(RequestParam.acntID.getValue(), true);
                        put(RequestParam.acntNm.getValue(), true);
                        put(RequestParam.lnKeibi.getValue(), true);
                        put(RequestParam.lnKbChiku.getValue(), true);
                        put(RequestParam.lnKbArea.getValue(), true);
                        put(RequestParam.shoriKubun.getValue(), true);
                        put(RequestParam.acntSbt.getValue(), true);
                    }
                };

            } else {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStart()");
                return jsonResult;
            }

            if (!G6Common.checkRequire(mapParam, lstRequiredParam, chkArrParam)) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStart()");
                return jsonResult;
            }
            
            acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
 			if (null == acntType) {
 				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

 				// 処理終了
 				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStart()");
 				return jsonResult;
 			}

            // unused: リクエスト情報取得

            // TODO SZWP0800：利用者の権限検証
            // ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
            // 共通関数「利用者権限チェック関数」にて、チェックを行う
            G6Common.invalidateAcntRole(mapParam);
            
            if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
            	// G6
				jsonResult = doSecurityProcess(errorDataModel, mapParam, acntLanguage, tokenMapParam);
			
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				// GHS
				jsonResult = doSecurityProcessGhs(errorDataModel, mapParam, acntType, acntLanguage, tokenMapParam);
			}
        } catch (ApplicationException e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD, e.getExceptionCode(),
                    e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
            if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
                jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD,
                        ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e),
                        acntLanguage);
            } else {
                jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD,
                        ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
            }
        }

        // 処理終了
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStart()");
        return jsonResult;
    }

    
    /**
     *  G6 ===============================================================================================
     */
    private String doSecurityProcess(ErrorDataModel errorDataModel, Map<String, Object> mapParam, String acntLanguage, Map<String, String> tokenMapParam) 
    		throws ApplicationException, JWTCreationException {
    	String jsonResult = "";
    	// Handling send queue timeout
        boolean isTimeout = false;
    	
    	String lnKbChiku = mapParam.get(RequestParam.lnKbChiku.getValue()).toString();
    	String shoriKubun = mapParam.get(RequestParam.shoriKubun.getValue()).toString();
    	String acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
    	String acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
    	
    	// コマンドシーケンス番号
        // String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
        final String cmdSeqNum = commonService.getCmdSeq();
        // 警備先情報取得処理
        // 8-2.A)警備先情報の取得
        RCtlDevDataSubModel rCtlDevDataSubModel = sZWP0800Service
                .getSecureInfo(lnKbChiku);

		// 警備先情報が取得出来なかった場合
        if (null == rCtlDevDataSubModel) {
            // エラーメッセージを取得する。 error.keibi.notFound
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
                    ErrorKey.NO_SECURITY_DISTRICT_INFO_LIST.getValue(), acntLanguage);

            // 処理終了
            return jsonResult;

            // 警備先情報が取得出来た場合
            // シリアル番号が設定されていなかった場合
        } else if ("".equals(rCtlDevDataSubModel.getSerialNum().trim())) {
            // エラーメッセージを取得する。 error.command.serialNumNotFound
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
                    ErrorKey.ERROR_SERIALNUM_NOT_FOUND.getValue(), acntLanguage);

            // 処理終了
            return jsonResult;
        }
        final String transNo = commonService.getTranSeq();
        String subAddr = rCtlDevDataSubModel.getSubAddr();
        if (subAddr == null || "".equals(subAddr.trim())) {
            subAddr = "    ";
        }
        // 警備開始／警備解除処理
        // リクエスト情報から処理区分を取得する
        // 処理区分が「警備開始」の場合
        // 警備開始処理を行う
        // 8-1.警備開始処理詳細
        if ((G6Constant.MYCD001.UNDER_SECURITY).equals(shoriKubun)) {
//            Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum,
//                    G6CodeConsts.CD055.N0);
            Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.N0, transNo, subAddr);
            final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
            // 警備開始処理
            // 警備開始要求を制御信号キューに登録する
            // 8-3.警備開始処理ＤＢ更新内容
            String soapMsg = this.getSecurityStatusCmdOut(mapSoap);

            mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
            mapSoap.put(RequestParam.acntID.getValue(), acntID);
            mapSoap.put(RequestParam.acntNm.getValue(), acntNm);

            commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

            long beginTime = System.currentTimeMillis();
            int countSleep = 0;

            // プロパティファイルから取得した「タイムアウト時間」までループ
            // start loop
            while (true) {
                // checking timeout
                if (G6Common.isTimeOut(timeout.intValue(), beginTime)) {
                    isTimeout = true;
                    break;
                }

                // 制御信号キューを検索する。
                // 8-2.B) 警備設定処理終了確認
                ControlQueueStatusModel controlQueueStatusModel = sZWP0800Service.getControlQueueStsInfo(cmdSeqNum);

                if (null == controlQueueStatusModel) {
                    jsonResult = G6Common.messageUpdateLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD,
                            ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

                    // 処理終了
                    return jsonResult;
                }

                // 状態が「S：成功」の場合
                if (G6CodeConsts.CD179.SUCCESS.equals(controlQueueStatusModel.getSts())) {
//                    // 取得したSOAP電文からkbstset_rspタグ内の実行結果(<cmd_rslt>タグ)を取得する
//                    String execResult = "";
//                    execResult = G6Common.getElementByTagName(controlQueueStatusModel.getSoapMsg(),
//                            G6Constant.CMD_RESULT);
//
//                    // 「実行結果」により処理結果を判定する
//                    // 0：OK の場合
//                    if (G6CodeConsts.CD185.OK.equals(execResult)) {
                        errorDataModel.setErrorCode(G6Constant.SUCCESS_CD);
                        break;
//
//                        // 2：排他エラー の場合
//                    } else if (G6CodeConsts.CD185.EXCLUSION_ERROR.equals(execResult)) {
//                        errorDataModel.setErrorCode(G6Constant.FAIL_DUPLICATE_CD);
//                        break;
//
//                        // 上記以外の場合
//                    } else {
//                        break;
//                    }

                    // 状態が「0：未送信」の場合
                } else {
                    // 待機時間が経過するまで待機する
                    G6Common.sleepOperation(timeout.intValue(), timeSleep.intValue(), countSleep);
                    countSleep++;
                }
            }
            // end loop

            // 処理区分が「警備解除」の場合
            // 警備解除処理を行う
            // 9-1.警備削除処理詳細
        } else if ((G6Constant.MYCD001.UNPROTECTING).equals(shoriKubun)) {
//            Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum,
//                    G6CodeConsts.CD055.F0);
            Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.F0, transNo, subAddr); 
            final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
            // 警備解除処理
            // 警備解除要求を制御信号キューに登録する
            // 9-2.警備解除処理ＤＢ更新内容
            String soapMsg = this.getSecurityStatusCmdOut(mapSoap);

            mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
            mapSoap.put(RequestParam.acntID.getValue(), acntID);
            mapSoap.put(RequestParam.acntNm.getValue(), acntNm);

            commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

            long beginTime = System.currentTimeMillis();
            int countSleep = 0;

            // プロパティファイルから取得した「タイムアウト時間」までループ
            // start loop
            while (true) {
                // checking timeout
                if (G6Common.isTimeOut(timeout.intValue(), beginTime)) {
                	isTimeout = true;
                    break;
                }
                // 制御信号キューを検索する。
                // 8-2.B) 警備解除処理終了確認
                ControlQueueStatusModel controlQueueStatusModel = sZWP0800Service.getControlQueueStsInfo(cmdSeqNum);

                if (null == controlQueueStatusModel) {
                    jsonResult = G6Common.messageUpdateLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD,
                            ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

                    // 処理終了
                    return jsonResult;
                }

                // 状態が「S：成功」の場合
                if (G6CodeConsts.CD179.SUCCESS.equals(controlQueueStatusModel.getSts())) {
//                    // 取得したSOAP電文からkbstset_rspタグ内の実行結果(<cmd_rslt>タグ)を取得する
//                    String execResult = "";
//                    execResult = G6Common.getElementByTagName(controlQueueStatusModel.getSoapMsg(),
//                            G6Constant.CMD_RESULT);
//
//                    // 「実行結果」により処理結果を判定する
//                    // 0：OK の場合
//                    if (G6CodeConsts.CD185.OK.equals(execResult)) {
                        errorDataModel.setErrorCode(G6Constant.SUCCESS_CD);
                        break;
//
//                        // 2：排他エラー の場合
//                    } else if (G6CodeConsts.CD185.EXCLUSION_ERROR.equals(execResult)) {
//                        errorDataModel.setErrorCode(G6Constant.FAIL_DUPLICATE_CD);
//                        break;
//
//                        // 上記以外の場合
//                    } else {
//                        break;
//                    }

                    // 状態が「0：未送信」の場合
                } else {
                    // 待機時間が経過するまで待機する
                    G6Common.sleepOperation(timeout.intValue(), timeSleep.intValue(), countSleep);
                    countSleep++;
                }
            }
            // end loop

            // 処理区分が「在室警備開始/在室警備解除」の場合
            // 在室警備処理を行う
            // 10-1.在室警備処理詳細
        } else if ((G6Constant.MYCD001.UNDER_SECURITY_IN_ROOM).equals(shoriKubun)
                || (G6Constant.MYCD001.UNPROTECTING_IN_ROOM).equals(shoriKubun)) {
            // リクエスト情報の警備エリア番号を取得する
            List<String> lnKbAreaList = G6Common.readParamToArrayObject(mapParam, RequestParam.lnKbArea.getValue());

            String soapMsg = "";
            Map<String, String> mapSoap = null;

            // 在室警備開始処理、
            if ((G6Constant.MYCD001.UNDER_SECURITY_IN_ROOM).equals(shoriKubun)) {
//                mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.ZN0);
                mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.ZN0, transNo, subAddr);
                // リクエスト情報に処理区分が「在室警備開始｣の警備エリアが存在する場合
                // 在室警備開始要求を制御信号キューに登録する
                // 10-2.在室警備開始処理ＤＢ更新内容
                soapMsg = this.getSecurityStatusCmdIn(mapSoap, lnKbAreaList);

                // 在室警備解除処理
            } else if ((G6Constant.MYCD001.UNPROTECTING_IN_ROOM).equals(shoriKubun)) {
//                mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.ZF0);
                mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.ZF0, transNo, subAddr);
                // リクエスト情報に処理区分が「在室警備解除｣の警備エリアが存在する場合
                // 在室警備解除要求を制御信号キューに登録する
                // 10-3.在室警備解除処理ＤＢ更新内容
                soapMsg = this.getSecurityStatusCmdIn(mapSoap, lnKbAreaList);
            }
            final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
            mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
            mapSoap.put(RequestParam.acntID.getValue(), acntID);
            mapSoap.put(RequestParam.acntNm.getValue(), acntNm);

            commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

            long beginTime = System.currentTimeMillis();
            int countSleep = 0;

            // プロパティファイルから取得した「タイムアウト時間」までループ
            // start loop
            while (true) {
                // checking timeout
                if (G6Common.isTimeOut(timeout.intValue(), beginTime)) {
                	isTimeout = true;
                    break;
                }
                // 制御信号キューを検索する。
                // 8-2.B) 警備解除処理終了確認
                ControlQueueStatusModel controlQueueStatusModel = sZWP0800Service.getControlQueueStsInfo(cmdSeqNum);

                if (null == controlQueueStatusModel) {
                    jsonResult = G6Common.messageUpdateLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD,
                            ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

                    // 処理終了
                    return jsonResult;
                }

                // 状態が「S：成功」の場合
                if (G6CodeConsts.CD179.SUCCESS.equals(controlQueueStatusModel.getSts())) {
//                    // 取得したSOAP電文からkbstset_rspタグ内の実行結果(<cmd_rslt>タグ)を取得する
//                    String execResult = "";
//                    execResult = G6Common.getElementByTagName(controlQueueStatusModel.getSoapMsg(),
//                            G6Constant.CMD_RESULT);
//
//                    // 「実行結果」により処理結果を判定する
//                    // 開始処理、解除処理両方が 0：OK の場合
//                    if (G6CodeConsts.CD185.OK.equals(execResult)) {
                        errorDataModel.setErrorCode(G6Constant.SUCCESS_CD);
                        break;
//
//                        // 開始処理、解除処理の片方でも 2：排他エラー の場合
//                    } else if (G6CodeConsts.CD185.EXCLUSION_ERROR.equals(execResult)) {
//                        errorDataModel.setErrorCode(G6Constant.FAIL_DUPLICATE_CD);
//                        break;
//
//                        // 上記以外の場合
//                    } else {
//                        break;
//                    }

                    // 開始処理、解除処理の状態が片方でも「0：未送信」の場合
                } else {
                    // 待機時間が経過するまで待機する
                    G6Common.sleepOperation(timeout.intValue(), timeSleep.intValue(), countSleep);
                    countSleep++;
                }
            }
            // end loop
        }
        if (isTimeout) {
            // タイムアウト発生時
            // 共通「メッセージ取得処理」を呼び出し、エラーメッセージを取得する。
            jsonResult = G6Common.messageHandler(errorDataModel, 
                    G6Constant.FAIL_POPUP_CD,
                    ErrorKey.ERROR_SERVER_TIMEOUT.getValue(), 
                    acntLanguage);
        } else {
        	
        	//デコード済acntIDを設定したJWT認証トークンを付与
        	errorDataModel.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
            
            jsonResult = G6Common.parseJSON(errorDataModel, acntLanguage);
        }
        
        return jsonResult;
    }    
    
//    private Map<String, String> createParamForSoap(RCtlDevDataSubModel rCtlDevDataSubModel, String cmdsqNo,
//            String noStat) {
    private Map<String, String> createParamForSoap(RCtlDevDataSubModel rCtlDevDataSubModel, String cmdsqNo,
            String noStat, String transNo, String subAdrr) {        
        
        Map<String, String> mapSoap = new HashMap<String, String>();

//        mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer);
        mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer2);
//        mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
        mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, transNo); 
        mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
        mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataSubModel.getSerialNum());
        mapSoap.put(G6Constant.MYCD003.DENKEINO, rCtlDevDataSubModel.getCustomerNum1());
        mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataSubModel.getGouKi());
//        mapSoap.put(G6Constant.MYCD003.SUBADDRESS, rCtlDevDataSubModel.getSubAddr());
        mapSoap.put(G6Constant.MYCD003.SUBADDRESS, subAdrr); 
//        mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
        mapSoap.put(G6Constant.MYCD003.LINETYPE, rCtlDevDataSubModel.getSdLineKind());
        mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
        mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.KBSTSET);
        mapSoap.put(G6Constant.MYCD003.NOSTAT, noStat);
//        mapSoap.put(G6Constant.MYCD003.KNSTAT, G6Constant.EMPTY);
//        mapSoap.put(G6Constant.MYCD003.DNSTAT, G6Constant.EMPTY);
//        mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);

        mapSoap.put(G6Constant.MYCD003.HOSTNM, hostName);
        mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
        mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
        mapSoap.put(G6Constant.MYCD003.DEVNUM, G6Constant.MYCD006.SU000);
        mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
        mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.KBSTSET);
        mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.UNSENT);

        return mapSoap;
    }

    private String getSecurityStatusCmdOut(Map<String, String> mapSoap) {
        StringBuffer builder = new StringBuffer();

        // ヘッダ部作成
        builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
        // データ部作成
        // 共通項目タグ設定
        // 電文バージョン
        builder.append("<command_version>");
        builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
        builder.append("<transaction_no>");
        builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
        builder.append("<generation_time>");
        builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
        builder.append("<transmitter_id>");
        builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
        builder.append("<denkei_no>");
        builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
        builder.append("<gouki_no>");
        builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
        builder.append("<sub_address>");
        builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
        builder.append("<line_type>");
        builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
        // 共通クラスから取得したコマンドシーケンス番号
        builder.append("<cmdsq_no>");
        builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
        builder.append("<execmd>");
        builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
        builder.append("<sub_adr>");
        builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_adr>");
//        builder.append("<kszinf>");
//        builder.append("<kbzn_no>");
//        builder.append("</kbzn_no>");
//        builder.append("</kszinf>");
        builder.append("<n0_stat>");
        builder.append(mapSoap.get(G6Constant.MYCD003.NOSTAT) + "</n0_stat>");
//        builder.append("<kn_stat>");
//        builder.append(mapSoap.get(G6Constant.MYCD003.KNSTAT) + "</kn_stat>");
//        builder.append("<dn_stat>");
//        builder.append(mapSoap.get(G6Constant.MYCD003.DNSTAT) + "</dn_stat>");
//        builder.append("<result>");
//        builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
        // フッター部作成
        builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

        return builder.toString();
    }

    private String getSecurityStatusCmdIn(Map<String, String> mapSoap, List<String> lnKbAreaList) {
        StringBuffer builder = new StringBuffer();

        // ヘッダ部作成
        builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
        // データ部作成
        // 共通項目タグ設定
        // 電文バージョン
        builder.append("<command_version>");
        builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
        builder.append("<transaction_no>");
        builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
        builder.append("<generation_time>");
        builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
        builder.append("<transmitter_id>");
        builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
        builder.append("<denkei_no>");
        builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
        builder.append("<gouki_no>");
        builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
        builder.append("<sub_address>");
        builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
        builder.append("<line_type>");
        builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
        // 共通クラスから取得したコマンドシーケンス番号
        builder.append("<cmdsq_no>");
        builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
        builder.append("<execmd>");
        builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
        builder.append("<sub_adr>");
        builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_adr>");
        for (String lnKbArea : lnKbAreaList) {
            builder.append("<kszinf>");
            builder.append("<kbzn_no>");
            builder.append(lnKbArea + "</kbzn_no>");
            builder.append("</kszinf>");
        }
        builder.append("<n0_stat>");
        builder.append(mapSoap.get(G6Constant.MYCD003.NOSTAT) + "</n0_stat>");
//        builder.append("<kn_stat>");
//        builder.append(mapSoap.get(G6Constant.MYCD003.KNSTAT) + "</kn_stat>");
//        builder.append("<dn_stat>");
//        builder.append(mapSoap.get(G6Constant.MYCD003.DNSTAT) + "</dn_stat>");
//        builder.append("<result>");
//        builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
        // フッター部作成
        builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

        return builder.toString();
    }
    
    
    /**
     *  GHS ===============================================================================================
     */
    private String doSecurityProcessGhs(ErrorDataModel errorDataModel, Map<String, Object> mapParam, String acntType, String acntLanguage, Map<String, String> tokenMapParam) 
    		throws ApplicationException, JWTCreationException {
    	String jsonResult = "";
    	String lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
    	String lnKbChiku = mapParam.get(RequestParam.lnKbChiku.getValue()).toString();
    	String acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
    	String acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
    	String shoriKubun = mapParam.get(RequestParam.shoriKubun.getValue()).toString();
        
        // 警備先情報取得処理
        // 8-4.A)警備先情報の取得
        RKbInfoModel rKbInfoModel = sZWP0800GhsService.selectRKeibiInfoGhs(lnKeibi);
		// ◇警備先情報が取得出来なかった場合
        // エラーメッセージを取得する。
        if (null == rKbInfoModel) {
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.NO_SECURITY_DISTRICT_INFO_LIST.getValue(), acntLanguage);
                    
            // 処理終了
            return jsonResult;

        //◇シリアル番号が設定されていなかった場合
        //エラーメッセージを取得する。
        } else if ("".equals(rKbInfoModel.getSerialNum().trim())) {
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_SERIALNUM_NOT_FOUND.getValue(), acntLanguage);
                    
            // 処理終了
            return jsonResult;
        }
        
        //警備地区情報を取得する
        //8-4.B)警備地区情報の取得
        RKbChikuInfoModel rKbChikuInfoModel = sZWP0800GhsService.searchRKbChikuGhs(lnKbChiku);
        //◇警備地区情報が取得出来なかった場合
        //エラーメッセージを取得する。
        if (null == rKbChikuInfoModel) {
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.NO_SECURITY_DISTRICT_INFO_LIST.getValue(), acntLanguage);
                    
            // 処理終了
            return jsonResult;
        }
        
        //電計番号を取得する
        //8-4.C)電計番号の取得
        RDenkeiMngInfoModel rDenkeiMngInfoModel = sZWP0800GhsService.searchRDenkeiMngGhs(lnKeibi);

        //　警備状態情報確認処理
        //システム警備状態変更予約情報を取得する
        //8-4.D)システム警備状態変更予約情報の取得
        WKbChikuRmInfoModel wKbChikuRmInfoModel = sZWP0800GhsService.searchWKbChikuRmSetGhs(lnKbChiku);
        
        // タイムアウト時間
        long outTime = Long.parseLong(ignoreTimeRmSet);
        // ◇他ユーザーによる予約情報がある場合
        if (wKbChikuRmInfoModel != null) {
            long sysTime = System.currentTimeMillis();
            long rmSetDate = DateTimeCommon.stringToDate(wKbChikuRmInfoModel.getRmSetTs()).getTime();           ;
            
            // ◇リモートセット日時が一定時間経過している場合（時間は設定ファイル）
            // システム警備状態変更予約情報を削除する
            if (sysTime - rmSetDate > outTime) {
            	//8-5.A)システム警備状態変更予約情報の削除
            	sZWP0800GhsService.deleteWKbChikuRmSet(lnKbChiku);
                
        	// コミット
            } else {
            	// ◇リモートセット日時が一定時間経過していない場合（時間は設定ファイル）
            	// 他ユーザー警備操作設定中画面のHTMLを作成する
                jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_OTHER_USER.getValue(), acntLanguage);
                
                // 処理終了
                return jsonResult;
            }
        }
        
        // コマンドシーケンス番号
        final String cmdSeqNum = commonGhsService.getCmdSeq();
        final String lnQueCtrlSig = commonGhsService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL);
        //制御キューに設定する「N:N0(外出警備セット状態)」のsoap電文を作成する
        // 8-5.C)警備状態設定コマンド(外出警備セット)
        String noStat = "";
        if ((G6Constant.MYCD001.UNDER_SECURITY).equals(shoriKubun)) {
        	// N0/F0状態
        	noStat = G6CodeConsts.CD055.N0;
        } else {
        	// N0/F0状態
        	noStat = G6CodeConsts.CD055.F0;
        }
        Map<String, String> eQueCtrlMapSoap = createEQueCtrlParamForSoap(rKbInfoModel, rDenkeiMngInfoModel.getDenkei(), cmdSeqNum, rKbChikuInfoModel.getSubAddr(), noStat);
        
		//制御キューに情報を登録する
		// 8-5.B)警備状態設定要求
        long overTimeNum = Long.parseLong(overTime);
        long sleepTimeNum = Long.parseLong(sleepTime);
		String eQueCtrlDSoapMsg = createEQueCtrlSoapMsg(eQueCtrlMapSoap);
		eQueCtrlMapSoap.put(G6Constant.MYCD003.SOAPMSG, eQueCtrlDSoapMsg);
		eQueCtrlMapSoap.put(RequestParam.acntID.getValue(), acntID);
		eQueCtrlMapSoap.put(RequestParam.acntNm.getValue(), acntNm);
		commonGhsService.saveEQueCtrlModel(eQueCtrlMapSoap, DateTimeCommon.getCurrentDate(), lnQueCtrlSig);
		
		//外出警備操作の設定を行う
		//8-5.D)外出警備操作の設定
		String userKindNo = "";
		String kbSetStsn0 = "";
		if(acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
			userKindNo = G6CodeConsts.CD248.GHS_CONTRACT_DESTINATION;
		} else if(acntType.equals(G6CodeConsts.CD027.GHS_THE_USER)) {
			userKindNo = G6CodeConsts.CD248.GHS_THE_USER;
		}
		if ((G6Constant.MYCD001.UNDER_SECURITY).equals(shoriKubun)) {
            // N0/F0状態
			kbSetStsn0 = G6CodeConsts.CD055.N0;
        } else {
            // N0/F0状態
        	kbSetStsn0 = G6CodeConsts.CD055.F0;
        }
		boolean flg =  sZWP0800GhsService.insertWKbChikuRmSet(cmdSeqNum, lnKbChiku, acntID, acntNm, lnQueCtrlSig, userKindNo, kbSetStsn0,  DateTimeCommon.getCurrentDate());
		
		//○コミットを行う
		if (!flg) {
         	// ◇リモートセット日時が一定時間経過していない場合（時間は設定ファイル）
         	// 他ユーザー警備操作設定中画面のHTMLを作成する
             jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_OUT_ALSOK_ERROR.getValue(), acntLanguage);
             
             // 処理終了
             return jsonResult;
        }	
				
		//システム警備状態変更予約情報を確認する
		//○プロパティファイルから取得した「タイムアウト時間」までループ
		long beginTime = System.currentTimeMillis();

		// start loop
		while (true) {
	         long nowTime = System.currentTimeMillis();
	         if ((nowTime - beginTime) > overTimeNum) {
	        	 jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.EXCEPTION_ROOT.getValue(), acntLanguage);
	                
	        	 // 処理終了
	        	 return jsonResult;
	         }
	         
	         // 制御キューの状態を確認する
             // 8-4.F)制御キュー状態情報の取得
	         EQueCtrlModel eQueCtrlModel = sZWP0800GhsService.searchEQueCtrlGhs(cmdSeqNum);
	         String sts = eQueCtrlModel.getSts();
	         
	         // ◇状態が(S:成功)の場合
	         if(G6CodeConsts.CD179.SUCCESS.equals(sts)) {
	        	 // 警備先地区リモート操作のレコードを確認する
	        	 // 8-4.E)システム警備状態変更予約情報の取得
                 String lnkeibi = sZWP0800GhsService.searchSysKbChikuGhs(lnKbChiku, cmdSeqNum);
               
                 // ◇レコードが取得できなかった場合
                 if (StringUtils.isEmpty(lnkeibi)) {
                     if ((G6Constant.MYCD001.UNDER_SECURITY).equals(shoriKubun)) {
                         // 警備操作メッセージに「警備を開始します。」を表示する
        	        	 jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_MSG_KEIBI_START.getValue(), acntLanguage);
     	                
        	        	 // 処理終了
        	        	 return jsonResult;
                     } else {
                         // 警備操作メッセージに「警備を終了します。」を表示する
        	        	 jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_MSG_KEIBI_END.getValue(), acntLanguage);
     	                
        	        	 // 処理終了
        	        	 return jsonResult;
                     }
                 } else {
                 	errorDataModel.setErrorCode(G6Constant.SUCCESS_CD);
                 	
                 	//デコード済acntIDを設定したJWT認証トークンを付与
                 	errorDataModel.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
                	
                 	jsonResult = G6Common.parseJSON(errorDataModel, acntLanguage);
                    break;
                 }
             // 取得失敗の場合(3:レスポンス受理(OK以外) E:エラー T：タイムアウト)
	         } else if(G6CodeConsts.CD179.RESPONSE_ACCEPTANCE_BESIDES_OK.equals(sts) || 
						G6CodeConsts.CD179.ERROR.equals(sts) || 
						G6CodeConsts.CD179.TIME_OUT.equals(sts)) {
	        	// エラーメッセージを設定する
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.EXCEPTION_ROOT.getValue(), acntLanguage);

				// 処理終了
				return jsonResult;
             }
	         
	         // プロパティファイルから取得「待機時間」の分、一定時間待機し、監視を継続
             try {
                 Thread.sleep(sleepTimeNum);
             } catch (InterruptedException e) {
            	// 例外発生時にログ出力
            	 appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
            	 
            	// エラーメッセージを設定する
 				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.EXCEPTION_ROOT.getValue(), acntLanguage);

 				// 処理終了
 				return jsonResult;
             }
		}
		
        return jsonResult;
	}

	private Map<String, String> createEQueCtrlParamForSoap(RKbInfoModel rKbInfoModel, String denkei, String cmdsqNo, String subAddr, String noStat) {
		Map<String, String> mapSoap = new HashMap<String, String>();
		
        if (subAddr == null || "".equals(subAddr.trim())) {
            subAddr = "    ";
        }	
		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rKbInfoModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, denkei);
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rKbInfoModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, subAddr);
		mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.KBSTSET);
		mapSoap.put(SUB_ADDR, subAddr);
		mapSoap.put(G6Constant.MYCD003.KSZINF, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.KBZNNO, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.NOSTAT, noStat);
		mapSoap.put(G6Constant.MYCD003.KNSTAT, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);
		
		mapSoap.put(G6Constant.MYCD003.HOSTNM, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.KBSTSET_GHS);
		mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.UNSENT);
		
		return mapSoap;
	}

	private String createEQueCtrlSoapMsg(Map<String, String> mapSoap) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeaderForGhs());
		
		// データ部作成
		// 共通項目タグ設定
		builder.append("<HostName>");
		builder.append(mapSoap.get(G6Constant.MYCD003.HOSTNM) + "</HostName>");
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		
		// 共通クラスから取得したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<priority_level>");
		builder.append(G6Constant.EMPTY + "</priority_level>");
		builder.append("<timeout_sec>");
		builder.append(G6Constant.EMPTY + "</timeout_sec>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<sub_adr>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_adr>");
		builder.append("<n0_stat>");
		builder.append(mapSoap.get(G6Constant.MYCD003.NOSTAT) + "</n0_stat>");
		builder.append("<result>");
		builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		
		// フッター部作成
		builder.append(G6Common.createSoapFooterForGhs());

		return builder.toString();
	}
}
