package com.nec.jp.G6Smartphone.utility;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.json.JSONObject;

import jp.co.alsok.g6.common.log.ApplicationLog;

public class G6DataSocket {

    private static final ApplicationLog appLog = new ApplicationLog(G6DataSocket.class);

    public G6DataSocket() {

    }

    /**
     * Convert data String to JSON object
     * 
     * @param errorCode
     * @param errorMsg
     * @param status
     * @param index
     * @param data
     * @return a JSON object
     */
    public JSONObject convertData(String errorCode, String errorMsg, String status, int index, String data) {
        final JSONObject result = new JSONObject();
        try {
            result.put(G6Constant.ResponseParam.errorCode.getValue(), errorCode);
            result.put(G6Constant.ResponseParam.errorMsg.getValue(), errorMsg);
            result.put(G6Constant.ResponseParam.status.getValue(), status);
            result.put(G6Constant.ResponseParam.index.getValue(), index);
            result.put(G6Constant.ResponseParam.data.getValue(), data);
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return result;
    }

    /**
     * Get message error from message.properties Convert data String to JSON
     * object
     * 
     * @param language
     * @return a JSON object
     */
    public JSONObject getDataError(String language) {
        String errorMsg = "";
        try {
            errorMsg = MessageCommon.getMessage("exception.processing.socket", language);
        } catch (ApplicationException e) {
            errorMsg = e.getMessage();
        }
        return convertData(G6Constant.FAIL_POPUP_CD, errorMsg, G6Constant.MYCD008.STATUS_FAILED, -1, "");
    }

    /**
     * Create a folder belong to key of a connection socket
     * 
     * @param key
     * @return a string object
     */
    public String createFolder(String key) {
        try {
            final String path = getPathFolder(key);
            final File file = new File(path);
            if (file != null && !file.exists()) {
                if (file.mkdirs()) {
                    return path;
                } else {
                    return "";
                }
            }
            return path;
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
            return "";
        }
    }

    /**
     * get path folder stored template file
     * @param key
     * @return
     */
    public String getPathFolder(String key) {
        final String defaultFolder = getValueSetting(G6Constant.PATH_TEMPLATE);
        try {
            return smoothFolder(defaultFolder + "/" + key); 
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return defaultFolder;
    }
    
    /**
     * Create a file name belong to index of data received
     * 
     * @param key
     * @param index
     * @return a string object
     */
    public String createFileName(String key, int index) {
        String result = "";
        try {
            final String path = createFolder(key);
            final String defaultExtension = getValueSetting(G6Constant.FILE_EXTENSION);
            final String fileName = smoothExtension("file_" + index + "." + defaultExtension);
            result = path + "/" + fileName;
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return result;
    }

    /**
     * delete a folder (include sub-folder)
     * 
     * @param path
     */
    public void removeFolder(String path) {
        try {
            recursiveDelete(new File(path));
        } catch (Exception e) {
        }
    }

    /**
     * delete a file existed
     * 
     * @param path
     */
    public void removeFile(String path) {
        try {
            final File file = new File(path);
            if (file != null) {
                file.delete();
            }
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
    }

    /**
     * get value config file from setting.properties file
     * @return
     */
    public int getBlockSize() {
        int result = G6Constant.MYCD008.WRITE_BLOCK;
        try {
            final String size = getValueSetting(G6Constant.BLOCK_SIZE_STORED_DATA);
            if (size != null && !"".equals(size)) {
                if (Integer.parseInt(size) > G6Constant.MYCD008.WRITE_BLOCK) {
                    result = Integer.parseInt(size);
                }
            }
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return result;
    }
    
    /**
     * get value belong to key in setting.properties file
     * 
     * @param key
     * @return a string object
     */
    public String getValueSetting(String key) {
        String result = "";
        final Properties prop = new Properties();
        InputStream input = null;
        try {
            input = this.getClass().getClassLoader().getResourceAsStream("setting.properties");
            // load a properties file
            prop.load(input);
            result = prop.getProperty(key);
        } catch (IOException ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 
                }
            }
        }
        return result;
    }

    /**
     * replace double comma(//) to a single comma(/)
     * 
     * @param str
     * @return a string object
     */
    public String smoothPath(String str) {
        String result = str;
        try {
            if (str != null) {
                result = str.replaceAll("//", "/").replaceAll("\\..", ".");
            }
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return result;
    }

    /**
     * replace double comma(..) to a single comma(.)
     * 
     * @param str
     * @return
     */
    public String smoothExtension(String str) {
        String result = str;
        try {
            if (str != null) {
                result = str.replaceAll("\\..", ".");
            }
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return result;
    }

    /**
     * 
     * replace double comma(//) to a single comma(/)
     * 
     * @param str
     * @return a string object
     */
    public String smoothFolder(String str) {
        String result = str;
        try {
            if (str != null) {
                result = str.replaceAll("//", "/");
            }
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return result;
    }

    private void recursiveDelete(File file) {
        try {
            if (file != null) {
                // to end the recursive loop
                if (!file.exists()) {
                    return;
                }
                // if directory, go inside and call recursively
                if (file.isDirectory()) {
                    for (File f : file.listFiles()) {
                        // call recursively
                        recursiveDelete(f);
                    }
                }
                // call delete to delete files and empty directory
                file.delete();
            }
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
    }
}
