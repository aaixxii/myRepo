package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.KbInfDataModel;
import com.nec.jp.G6Smartphone.SO.ResGetCriminalDetectionList;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP3800Service;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;

@Controller
public class SZWP3800Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP3800Controller.class);

	//JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
    @Autowired
	CommonService commonService;
    
	@Autowired
	CommonComService commonComService;
	
	@Autowired
	SZWP3800Service sZWP3800Service;

	@Value("${maxHistoryShowDays}")
	Integer MAX_HISTORY_DAYS;
	
	@Value("${limit_row_num}")
	int limit_row_num;
	
	/*
	 * Get data from E_KB_INF,R_AUTH_PIC_INF, R_KEIYK, R_KEIBI, E_KB_NOTICE table
	 * @param: acntID, lnKeibi, dateFrom, dateTo, nickName, keiykNm, keibiName, devNm
	 * return: object ResGetCriminalDetectionList as JSON
	 */
	@RequestMapping(value = "/getCriminalDetectionList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getCriminalDetectionList(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP3800Controller.getCriminalDetectionList()");
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		String jsonResult = "";
		Map<String, Object> mapParam = new HashMap<String, Object>();
		ResGetCriminalDetectionList resGetCriminalDetectionList = new ResGetCriminalDetectionList();
		List<KbInfDataModel> kbInfDataModel = new ArrayList<KbInfDataModel>();
		Date dateFrom = null;
		Date dateTo = null;
		String acntID = "";
		String lnKeibi = "";
		String nickName = "";
		String keiykNm = "";
		String keibiName = "";
		String devNm = "";
		int totalRow = 0;
		int totalPage = 0;
		int offset = 0;
		int pageNo = 0;

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetCriminalDetectionList, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP3800Controller.getCriminalDetectionList()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetCriminalDetectionList, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP3800Controller.getCriminalDetectionList()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 9) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetCriminalDetectionList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP3800Controller.getCriminalDetectionList()");
				return jsonResult;
			}
			// Build require parameters
			Map<String, Boolean> lstRequiredParam = new HashMap<String, Boolean>() ;
			lstRequiredParam.put(RequestParam.acntID.getValue(), true);
			lstRequiredParam.put(RequestParam.dateFrom.getValue(), false);
			lstRequiredParam.put(RequestParam.dateTo.getValue(), false);
			lstRequiredParam.put(RequestParam.nickName.getValue(), false);
			lstRequiredParam.put(RequestParam.keiykNm.getValue(), false);
			lstRequiredParam.put(RequestParam.keibiName.getValue(), false);
			lstRequiredParam.put(RequestParam.devNm.getValue(), false);
			lstRequiredParam.put(RequestParam.lnKeibi.getValue(), false);
			lstRequiredParam.put(RequestParam.pageNo.getValue(), true);

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetCriminalDetectionList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP3800Controller.getCriminalDetectionList()");
				return jsonResult;
			}
			
			//Verify pageNo RequestParam
			pageNo = Integer.parseInt(mapParam.get(RequestParam.pageNo.getValue()).toString());
			if(pageNo < 0) {
				jsonResult = G6Common.messageHandler(resGetCriminalDetectionList, G6Constant.FAIL_POPUP_CD, 
						ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
					
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP3800Controller.getCriminalDetectionList()");
				return jsonResult;
			}

			// TODO SZWP3800：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 年月日(From)が入力されていない場合
			if (mapParam.get(RequestParam.dateFrom.getValue()) == null || "".equals(mapParam.get(RequestParam.dateFrom.getValue()))) {
				// 年月日(From)にシステム日付の最大表示日数分過去の日付を設定する
				dateFrom = DateTimeCommon.getDateInPast(DateTimeCommon.getDateCurrentShortDate(), MAX_HISTORY_DAYS);
			} else {
				dateFrom = DateTimeCommon.stringToDate(mapParam.get(RequestParam.dateFrom.getValue()).toString());
			}

			acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
			// 年月日(To)が入力されていない場合
			if (mapParam.get(RequestParam.dateTo.getValue()) == null || "".equals(mapParam.get(RequestParam.dateTo.getValue()))) {
				// 年月日(To)にシステム日付を設定する
				dateTo = DateTimeCommon.getDateCurrentShortDate();
			} else {
				dateTo = DateTimeCommon.stringToDate(mapParam.get(RequestParam.dateTo.getValue()).toString());
			}

			if ( null != mapParam.get(RequestParam.lnKeibi.getValue())) {
			    lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
			}
			if ( null != mapParam.get(RequestParam.nickName.getValue())) {
				nickName = mapParam.get(RequestParam.nickName.getValue()).toString();
			}
			if (null != mapParam.get(RequestParam.keiykNm.getValue())) {
				keiykNm = mapParam.get(RequestParam.keiykNm.getValue()).toString();
			}
			if (null != mapParam.get(RequestParam.keibiName.getValue())) {
				keibiName = mapParam.get(RequestParam.keibiName.getValue()).toString();
			}
			if (null != mapParam.get(RequestParam.devNm.getValue())) {
				devNm = mapParam.get(RequestParam.devNm.getValue()).toString();
			}
			
			//get total row
			totalRow = sZWP3800Service.getTotalRow(acntID, lnKeibi, dateFrom, dateTo, nickName, keiykNm, keibiName, devNm);
			if(totalRow > 0) {
				//calculate total of pages
				totalPage = G6Common.calculateTotalPages(totalRow, limit_row_num);
				//Verify pageNo can not bigger than totalPage
				if(pageNo >  totalPage) {
					jsonResult = G6Common.messageHandler(resGetCriminalDetectionList, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
						
					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP3800Controller.getCriminalDetectionList()");
					return jsonResult;
				}
				
				//calculate offset
				offset = G6Common.calculateOffSet(pageNo, limit_row_num);
				
				kbInfDataModel = sZWP3800Service.getCriminalDetectionList(acntID, lnKeibi, dateFrom, dateTo, nickName, keiykNm, keibiName, devNm, offset, limit_row_num);
			}
			
			if (kbInfDataModel.size() == 0) {
				jsonResult = G6Common.messageSearchHandler(resGetCriminalDetectionList, 
						G6Constant.FAIL_POPUP_CD, ErrorKey.NO_SEARCH_RESULT_FOUND.getValue(), ErrorKey.SCREEN_TITLE_SZWP3800.getValue(), acntLanguage);
			} else {
				// 取得内容を応答する
				resGetCriminalDetectionList.setErrorCode(G6Constant.SUCCESS_CD);
				resGetCriminalDetectionList.setTotalPage(String.valueOf(totalPage));
				resGetCriminalDetectionList.setKbInfItem(kbInfDataModel);
				
				//デコード済acntIDを設定したJWT認証トークンを付与
				resGetCriminalDetectionList.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));

				jsonResult = G6Common.parseJSON(resGetCriminalDetectionList, acntLanguage);
			}
		} catch(ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetCriminalDetectionList, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetCriminalDetectionList, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetCriminalDetectionList, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			jsonResult = G6Common.messageLogHandler(resGetCriminalDetectionList, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP3800Controller.getCriminalDetectionList()");
		return jsonResult;
	}
}
