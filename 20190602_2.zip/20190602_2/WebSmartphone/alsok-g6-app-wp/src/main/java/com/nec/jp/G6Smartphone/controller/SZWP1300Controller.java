package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ResInitHistorySearch;
import com.nec.jp.G6Smartphone.SO.SdKobetuDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP1300Service;
import com.nec.jp.G6Smartphone.service.ghs.SZWP1300GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;
import com.nec.jp.G6Smartphone.utility.StringUtils;

import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWP1300Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP1300Controller.class);
    //JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;

	@Autowired
	SZWP1300Service sZWP1300Service;
	@Autowired
	SZWP1300GhsService sZWP1300GhsService;
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;

	@Value("${keibiSrchHistoryGSMChiku}")
	String keibiSrchHistoryGSMChiku;
	@Value("${mainGSMSubaddr}")
	String mainGSMSubaddr;
	@Value("${managerRoomGSMSubaddr}")
	String managerRoomGSMSubaddr;
	@Value("${setubiGSMSubaddr}")
	String setubiGSMSubaddr;
	@Value("${commonGSMSubaddr}")
	String commonGSMSubaddr;
	@Value("${ctrGSMSubaddr}")
	String ctrGSMSubaddr;
	@Value("${ctrOtherGSMSubaddr}")
	String ctrOtherGSMSubaddr;
	@Value("${jukoGSMSubaddr}")
	String jukoGSMSubaddr;

	/*
	 * Get data from R_KB_CHIKU table
	 * @param: acntID, lnKeibi 
	 * return: object ResInitHistorySearch as JSON
	 */
	@RequestMapping(value = "/initHistorySearch", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String initHistorySearch(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1300Controller.initHistorySearch()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResInitHistorySearch resInitHistorySearch = new ResInitHistorySearch();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntType = "";
		String acntNm = "";

		try {
			// 検索条件のToに設定するため、サーバーシステム日付を取得する
			resInitHistorySearch.setDtTo(DateTimeCommon.getCurrentShortDate());

			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

         // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resInitHistorySearch, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1300Controller.initHistorySearch()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resInitHistorySearch, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1300Controller.initHistorySearch()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 4) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resInitHistorySearch, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1300Controller.initHistorySearch()");
				return jsonResult;
			}

			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.acntSbt.getValue());
					add(RequestParam.lnKeibi.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resInitHistorySearch, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1300Controller.initHistorySearch()");
				return jsonResult;
			}

			// リクエスト情報取得
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();

			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resInitHistorySearch, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1300Controller.initHistorySearch()");
				return jsonResult;
			}

			// TODO SZWP1300：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 初期表示情報の取得処理
			List<SdKobetuDataModel> lstSdKobetuItem = null;

			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// 7-2.初期表示ＤＢ検索内容(次期警備用）
				lstSdKobetuItem = sZWP1300Service.getDistrictPulldownInfo(mapParam.get(RequestParam.acntID.getValue()).toString(), mapParam.get(RequestParam.lnKeibi.getValue()).toString());

			// リクエスト情報から取得したアカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				// プロパティファイルから取得したR_警備先地区.サブアドレス
				List<String> kbChikuSubAddrList = new ArrayList<String>();
				String serviceType = commonService.getServiceType(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				if (G6CodeConsts.CD035.GSM.equals(serviceType)) {
					kbChikuSubAddrList = this.setSubAddr(keibiSrchHistoryGSMChiku);
				}

				// 7-3.初期表示ＤＢ検索内容(GHS用）
				lstSdKobetuItem = sZWP1300GhsService.getDistrictPulldownInfoGHS(mapParam.get(RequestParam.lnKeibi.getValue()).toString(), kbChikuSubAddrList);

			// リクエスト情報から取得したアカウント種別が、ＧⅤの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GV)) {
				// TODO: 7-4.初期表示ＤＢ検索内容(GV用）

			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//			// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//			final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//			hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP1300.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(),  acntNm, DateTimeCommon.getCurrentDate());
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());										// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);														// アカウント名
			hUserOperationLogModel.setLnKeibi(mapParam.get(RequestParam.lnKeibi.getValue()).toString());	// 警備先論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP1300.getValueForOperationLog());					// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, acntType);
			
			// 応答
			resInitHistorySearch.setErrorCode(G6Constant.SUCCESS_CD);
			resInitHistorySearch.setSdKobetuItem(lstSdKobetuItem);
			
			//デコード済acntIDを設定したJWT認証トークンを付与
			resInitHistorySearch.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
			jsonResult = G6Common.parseJSON(resInitHistorySearch, acntLanguage);

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resInitHistorySearch, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resInitHistorySearch, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resInitHistorySearch, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
		} catch (Exception e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resInitHistorySearch, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resInitHistorySearch, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1300Controller.initHistorySearch()");
		return jsonResult;
	}

	/**
	* プロパティファイルから取得したR_警備先地区.サブアドレス.
	*
	* @param form
	*		  警備履歴一覧画面用フォーム
	*/
	 private List<String> setSubAddr(String keibiSrchHistoryGSMChiku) {
		// サブアドレス
		String[] keibiSrchHistoryGSMChikuArr = keibiSrchHistoryGSMChiku.split(G6Constant.COMMA);
		StringBuilder subAddr = new StringBuilder();

		if (keibiSrchHistoryGSMChikuArr.length > 0) {
			for (int i = 0; i < keibiSrchHistoryGSMChikuArr.length; i++) {
				String sub = null;
				if (G6Constant.SUBADDR_1.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = mainGSMSubaddr;
				} else if (G6Constant.SUBADDR_2.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = managerRoomGSMSubaddr;
				} else if (G6Constant.SUBADDR_3.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = setubiGSMSubaddr;
				} else if (G6Constant.SUBADDR_4.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = commonGSMSubaddr;
				} else if (G6Constant.SUBADDR_5.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = ctrGSMSubaddr;
				} else if (G6Constant.SUBADDR_6.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = ctrOtherGSMSubaddr;
				} else if (G6Constant.SUBADDR_7.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = jukoGSMSubaddr;
				} else {
					subAddr = null;
					break;
				}
				StringBuilder subAddrNew = new StringBuilder();
				String[] subArray = sub.split(G6Constant.COMMA);
				for (int j = 0; j < subArray.length; j++) {
					if (!subArray[j].contains(G6Constant.HYPHEN)) {
						subAddrNew.append(subArray[j]);
						subAddrNew.append(G6Constant.COMMA);
						continue;
					}
					String[] str = subArray[j].split(G6Constant.HYPHEN);
					if (str.length != G6Constant.NO_2) {
						continue;
					}
					int bf = Integer.parseInt(str[0]);
					int ls = Integer.parseInt(str[1]);
					if (bf >= ls) {
						continue;
					}
					for (int k = bf; k <= ls; k++) {
						subAddrNew.append(StringUtils.addCharForStrL(String.valueOf(k), '0', G6Constant.NO_4));
						subAddrNew.append(G6Constant.COMMA);
					}
				}
				sub = subAddrNew.substring(0, subAddrNew.length() - G6Constant.NO_1);
				if (StringUtils.isBlank(sub)) {
					subAddr.append(StringUtils.space(G6Constant.NO_4));
				} else {
					subAddr.append(sub);
				}
				if (i < keibiSrchHistoryGSMChikuArr.length - G6Constant.NO_1) {
					subAddr.append(G6Constant.COMMA);
				}
			}
		}

		if (subAddr != null && !StringUtils.isEmpty(subAddr.toString())) {
			return G6Common.stringToArray(subAddr.toString());
		} else {
			return new ArrayList<String>();
		}
	}
}
