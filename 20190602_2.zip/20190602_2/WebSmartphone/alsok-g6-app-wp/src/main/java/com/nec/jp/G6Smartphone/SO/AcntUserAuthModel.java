package com.nec.jp.G6Smartphone.SO;

public class AcntUserAuthModel implements DataModelHandler {

	private String flgKbSetDisp;		
	private String flgKbHstDisp;
	private String flgRmtKbSetDisp;		
	private String flgKnrnDisp;
	private String flgWasureDisp;		
	private String flgKusituDisp;
	private String flgCardDisp;
	
	
	public AcntUserAuthModel() {
		this.flgKbSetDisp = "";
		this.flgKbHstDisp = "";
		this.flgRmtKbSetDisp = "";
		this.flgKnrnDisp = "";
		this.flgWasureDisp = "";
		this.flgKusituDisp = "";
		this.flgCardDisp = "";
	}
	
	public AcntUserAuthModel(String flgKbSetDisp, String flgKbHstDisp, String flgRmtKbSetDisp, String flgKnrnDisp, String flgWasureDisp, String flgKusituDisp, String flgCardDisp) {
		this.flgKbSetDisp = flgKbSetDisp;
		this.flgKbHstDisp = flgKbHstDisp;
		this.flgRmtKbSetDisp = flgRmtKbSetDisp;
		this.flgKnrnDisp = flgKnrnDisp;
		this.flgWasureDisp = flgWasureDisp;
		this.flgKusituDisp = flgKusituDisp;
		this.flgCardDisp = flgCardDisp;
	}
	
	public String getFlgKbSetDisp() {
		return flgKbSetDisp;
	}
	public void setFlgKbSetDisp(String flgKbSetDisp) {
		this.flgKbSetDisp = flgKbSetDisp;
	}
	public String getFlgKbHstDisp() {
		return flgKbHstDisp;
	}
	public void setFlgKbHstDisp(String flgKbHstDisp) {
		this.flgKbHstDisp = flgKbHstDisp;
	}
	public String getFlgRmtKbSetDisp() {
		return flgRmtKbSetDisp;
	}
	public void setFlgRmtKbSetDisp(String flgRmtKbSetDisp) {
		this.flgRmtKbSetDisp = flgRmtKbSetDisp;
	}
	public String getFlgKnrnDisp() {
		return flgKnrnDisp;
	}
	public void setFlgKnrnDisp(String flgKnrnDisp) {
		this.flgKnrnDisp = flgKnrnDisp;
	}
	public String getFlgWasureDisp() {
		return flgWasureDisp;
	}
	public void setFlgWasureDisp(String flgWasureDisp) {
		this.flgWasureDisp = flgWasureDisp;
	}
	public String getFlgKusituDisp() {
		return flgKusituDisp;
	}
	public void setFlgKusituDisp(String flgKusituDisp) {
		this.flgKusituDisp = flgKusituDisp;
	}
	public String getFlgCardDisp() {
		return flgCardDisp;
	}
	public void setFlgCardDisp(String flgCardDisp) {
		this.flgCardDisp = flgCardDisp;
	}
}
