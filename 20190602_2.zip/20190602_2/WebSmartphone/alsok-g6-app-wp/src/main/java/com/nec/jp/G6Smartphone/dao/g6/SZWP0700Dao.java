package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.AreaDataModel;

@Repository
public class SZWP0700Dao {

    @PersistenceContext(unitName = "g6Persistence")
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    public List<AreaDataModel> getArea(String lnKbChiku) {
        // StringBuilder strBuilder = new StringBuilder();
        //
        // strBuilder.append(" SELECT a.LN_KB_AREA as lnKbArea,");
        // strBuilder.append(" IFNULL(a.KB_AREA_NUM, '') as kbAreaNum,");
        // strBuilder.append(" IFNULL(a.KB_AREA_NM, '') as kbAreaNm");
        // strBuilder.append(" FROM R_KB_AREA a");
        // strBuilder.append(" WHERE a.LN_KB_CHIKU = :lnKbChiku");
        // strBuilder.append(" AND a.DEL_FLG = :delFlg");
        // strBuilder.append(" ORDER BY a.KB_AREA_NUM ASC");
        //
        // Query query = entityManager.createNativeQuery(strBuilder.toString(),
        // "AreaDataModelResult");
        // query.setParameter("lnKbChiku", lnKbChiku);
        // query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
        //
        // return (List<AreaDataModel>) query.getResultList();

        final StringBuilder strBuilder = new StringBuilder();
        strBuilder.append(" SELECT A.LN_KB_AREA as lnKbArea,");
        strBuilder.append("    IFNULL(A.KB_AREA_NUM, '') as kbAreaNum,");
        strBuilder.append("    IFNULL(A.KB_AREA_NM, '') as kbAreaNm");
        strBuilder.append(" FROM R_KB_AREA A");
        strBuilder.append(" INNER JOIN R_KB_AREA_SELECT_STS S ON A.LN_KB_AREA = S.LN_KB_AREA");
        strBuilder.append(" INNER JOIN R_ZAITAKU_KEIBI_STS R ON A.LN_KB_CHIKU = R.LN_KB_CHIKU");
        strBuilder.append(" WHERE A.LN_KB_CHIKU = :lnKbChiku");
        strBuilder.append(" AND A.DEL_FLG  = '0'");
        strBuilder.append(" AND S.KBZN_STS = '1'");
        strBuilder.append(" ORDER BY A.KB_AREA_NUM ASC");

        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "AreaDataModelResult");
        query.setParameter("lnKbChiku", lnKbChiku);

        return (List<AreaDataModel>) query.getResultList();
    }
}
