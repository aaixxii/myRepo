package com.nec.jp.G6Smartphone.SO;

import javax.persistence.ColumnResult;

public class KeibisakiInfo {

	private String lnKeibi;
	private String keibiNm;
	private String keibiAddr;
	private String lnKeiyk;
	private String keiykNm;
	
	
    private String keibiNm1;
	private String lnAcntUserCommon;
	private String pathSlash;
	private String systemId;
	private String keibiLength;
	private String numLength;
	
	public KeibisakiInfo() {
		this.lnKeibi = "";
		this.keibiNm = "";
		this.keibiAddr = "";
		this.lnKeiyk = "";
		this.keiykNm = "";
		this.keibiNm1 = "";
		this.lnAcntUserCommon = "";
		this.pathSlash = "";
		this.systemId = "";
		this.keibiLength = "";
		this.numLength = "";
	}
	
	
	public KeibisakiInfo(String lnKeibi, String keibiNm, String keibiAddr, String lnKeiyk, String keiykNm) {
		this.lnKeibi = lnKeibi;
		this.keibiNm = keibiNm;
		this.keibiAddr = keibiAddr;
		this.lnKeiyk = lnKeiyk;
		this.keiykNm = keiykNm;
	}
	
   public KeibisakiInfo(String lnKeibi, String keibiNm, String keibiAddr, String lnKeiyk, String keiykNm, String lnAcntUserCommon, String systemId) {
        this.lnKeibi = lnKeibi;
        this.keibiNm = keibiNm;
        this.keibiAddr = keibiAddr;
        this.lnKeiyk = lnKeiyk;
        this.keiykNm = keiykNm;
        this.lnAcntUserCommon = lnAcntUserCommon;
        this.systemId = systemId;
    }
	
	public KeibisakiInfo(String lnKeibi, String keibiNm1, String keibiAddr, String lnKeiyk, String keiykNm,
	           String lnAcntUserCommon, String pathSlash, String systemId, String keibiLength, String numLength) {
        this.lnKeibi = lnKeibi;
        this.keibiNm1 = keibiNm1;
        this.keibiAddr = keibiAddr;
        this.lnKeiyk = lnKeiyk;
        this.keiykNm = keiykNm;
        this.lnAcntUserCommon = lnAcntUserCommon;
        this.pathSlash = pathSlash;
        this.systemId = systemId;
        this.keibiLength = keibiLength;
        this.numLength = numLength;
    }
	
	public String getLnKeibi() {
		return lnKeibi;
	}
	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}
	public String getKeibiNm() {
		return keibiNm;
	}
	public void setKeibiNm(String keibiNm) {
		this.keibiNm = keibiNm;
	}
	public String getKeibiAddr() {
		return keibiAddr;
	}
	public void setKeibiAddr(String keibiAddr) {
		this.keibiAddr = keibiAddr;
	}
	public String getLnKeiyk() {
		return lnKeiyk;
	}
	public void setLnKeiyk(String lnKeiyk) {
		this.lnKeiyk = lnKeiyk;
	}
	public String getKeiykNm() {
		return keiykNm;
	}
	public void setKeiykNm(String keiykNm) {
		this.keiykNm = keiykNm;
	}
	public String getKeibiNm1() {
        return keibiNm1;
    }


    public void setKeibiNm1(String keibiNm1) {
        this.keibiNm1 = keibiNm1;
    }


    public String getLnAcntUserCommon() {
        return lnAcntUserCommon;
    }


    public void setLnAcntUserCommon(String lnAcntUserCommon) {
        this.lnAcntUserCommon = lnAcntUserCommon;
    }


    public String getPathSlash() {
        return pathSlash;
    }


    public void setPathSlash(String pathSlash) {
        this.pathSlash = pathSlash;
    }


    public String getSystemId() {
        return systemId;
    }


    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }


    public String getKeibiLength() {
        return keibiLength;
    }


    public void setKeibiLength(String keibiLength) {
        this.keibiLength = keibiLength;
    }


    public String getNumLength() {
        return numLength;
    }


    public void setNumLength(String numLength) {
        this.numLength = numLength;
    }
}
