package com.nec.jp.G6Smartphone.service.ghs;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.ResGetOtherInfo;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP2000GhsDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP2000GhsService {

	@Autowired
	private SZWP2000GhsDao sZWP2000Dao;

	public ResGetOtherInfo getALSOKGuardCenterInfoGHS(String lnKeibi) throws ApplicationException {
		try {
			return sZWP2000Dao.getALSOKGuardCenterInfoGHS(lnKeibi);
		} catch (NoResultException noResultE) {
			return new ResGetOtherInfo();
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getDenkeiNumGHS(String lnKeibi) throws ApplicationException {
		try {
			return sZWP2000Dao.getDenkeiNumGHS(lnKeibi);
		} catch (NoResultException noResultE) {
			return "";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
