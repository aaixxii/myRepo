package com.nec.jp.G6Smartphone.utility;

import java.net.URL;

public class FileUtils {
//    private static final String FILE_ROOT_PATH_IMAGE = Config.getString(ConfigKey.FILE_ROOT_PATH_IMAGE);
//
//    private static String[] includeExtensions = {"jpg", "gif", "png"};
    
    /**
     * @param imageName
     *            ファイル名
     * @param path
     *            ファイルパス
     *
     * @return String ファイルパス+ファイル名
     *
     */
    public static String getImagePath(String imageName, String path, URL url) {
        String imagePath = "";
//        URL url = SZWU1200Controller.class.getClassLoader().getResource("");
        if (!StringUtils.isEmpty(path)) {
            imagePath = url.getFile().concat(path).concat(imageName);
        } else {
            imagePath = url.getFile().concat(imageName);
        }
        return imagePath;
    }
}
