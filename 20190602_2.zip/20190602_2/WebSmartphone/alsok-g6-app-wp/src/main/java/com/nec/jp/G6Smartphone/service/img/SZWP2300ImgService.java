package com.nec.jp.G6Smartphone.service.img;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.ResDisplayLiveImage;
import com.nec.jp.G6Smartphone.dao.img.SZWP2300ImgDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP2300ImgService {

	@Autowired
	private SZWP2300ImgDao sZWP2300Dao;

	public ResDisplayLiveImage getLiveImageSound(String lnDev) throws ApplicationException {
		try {
			ResDisplayLiveImage camera = sZWP2300Dao.getLiveImageSound(lnDev);

			return camera;

		} catch (NoResultException noResultE) {
			return new ResDisplayLiveImage();

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
