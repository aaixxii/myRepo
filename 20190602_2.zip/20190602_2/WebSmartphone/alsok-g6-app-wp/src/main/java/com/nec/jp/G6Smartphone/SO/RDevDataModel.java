package com.nec.jp.G6Smartphone.SO;

public class RDevDataModel implements DataModelHandler {

	private String lnDev;		// 設置機器.LN_設置機器論理番号
	private String sdDevNm;		// 設置機器.装置名称
	private String sdDevNum;	// 設置機器.装置番号

	public RDevDataModel() {}

	public RDevDataModel(String lnDev, String sdDevNm, String sdDevNum) {
		this.lnDev = lnDev;
		this.sdDevNm = sdDevNm;
		this.sdDevNum = sdDevNum;
	}

	public String getLnDev() {
		return lnDev;
	}

	public void setLnDev(String lnDev) {
		this.lnDev = lnDev;
	}

	public String getSdDevNm() {
		return sdDevNm;
	}

	public void setSdDevNm(String sdDevNm) {
		this.sdDevNm = sdDevNm;
	}

	public String getSdDevNum() {
		return sdDevNum;
	}

	public void setSdDevNum(String sdDevNum) {
		this.sdDevNum = sdDevNum;
	}
}
