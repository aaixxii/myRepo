package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResLoginScreen implements ErrorHandler {

	private String errorCode;			// エラーコード
	private String errorMsg;			// エラーメッセージ
	private String acntID;				// 利用者アカウント共通.LN_利用者アカウント共通論理番号
	private String acntNm;				// 利用者アカウント共通.アカウント名称
	private String lastLoginTs;			// 利用者アカウント.前回ログイン日時
	private String acntUserKbn;			// 利用者アカウント共通.利用者アカウント区分
	private String selectLang;			// 利用者ログイン状態.選択言語種別
	private String pcURL;				// PC用ページ
	private String shopURL;				// 通販ショップ
	private String maxHistoryShowDays;	// 日数(履歴の表示は93日までです。)
	private String smartphoneServerHost; // スマホ情報提供サーバIPアドレス
	private String smartphoneServerPort; // スマホ情報提供サーバソケット通信用port
	private List<RKeibiDataModel> rKeibiItem;
	private String acntSbt; //アカウント種別(0：次期警備システム、1：GⅤ、2：GHS(利用者)、3：GHS(契約先)) 
	private String ghsAcntNo;			//GHSアカウント論理番号
	private String lnKeiyk;				//LN_契約先論理番号
	private String mlAddr;				//利用者アカウント共通.メールアドレス
	private String totalPage; 			//トタルページ
	private String errorTitle;
	
	public ResLoginScreen() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.acntID = "";
		this.acntNm = "";
		this.lastLoginTs = "";
		this.acntUserKbn = "";
		this.selectLang = "";
		this.pcURL = "";
		this.shopURL = "";
		this.maxHistoryShowDays = "";
		this.smartphoneServerHost = "";
		this.smartphoneServerPort = "";
		this.rKeibiItem = new ArrayList<RKeibiDataModel>();
		this.acntSbt = "";
		this.ghsAcntNo = "";
		this.lnKeiyk = "";
		this.mlAddr = "";
		this.totalPage = "0";
		this.errorTitle = "1";
	}
	
	public String getLnKeiyk() {
		return lnKeiyk;
	}

	public String getErrorTitle() {
		return errorTitle;
	}

	public void setErrorTitle(String errorTitle) {
		this.errorTitle = errorTitle;
	}

	public void setLnKeiyk(String lnKeiyk) {
		this.lnKeiyk = lnKeiyk;
	}
	public String getAcntSbt() {
		return acntSbt;
	}
	public void setAcntSbt(String acntSbt) {
		this.acntSbt = acntSbt;
	}
	public String getMlAddr() {
		return mlAddr;
	}
	public void setMlAddr(String mlAddr) {
		this.mlAddr = mlAddr;
	}
	public String getGhsAcntNo() {
		return ghsAcntNo;
	}
	public void setGhsAcntNo(String ghsAcntNo) {
		this.ghsAcntNo = ghsAcntNo;
	}
	public String getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(String totalPage) {
		this.totalPage = totalPage;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}

	public String getAcntNm() {
		return acntNm;
	}

	public void setAcntNm(String acntNm) {
		this.acntNm = acntNm;
	}

	public String getLastLoginTs() {
		return lastLoginTs;
	}

	public void setLastLoginTs(String lastLoginTs) {
		this.lastLoginTs = lastLoginTs;
	}

	public String getAcntUserKbn() {
		return acntUserKbn;
	}
	public void setAcntUserKbn(String acntUserKbn) {
		this.acntUserKbn = acntUserKbn;
	}
	public List<RKeibiDataModel> getrKeibiItem() {
		return rKeibiItem;
	}

	public void setrKeibiItem(List<RKeibiDataModel> rKeibiItem) {
		this.rKeibiItem = rKeibiItem;
	}

	public String getSelectLang() {
		return selectLang;
	}

	public void setSelectLang(String selectLang) {
		this.selectLang = selectLang;
	}

	public String getPcURL() {
		return pcURL;
	}

	public void setPcURL(String pcURL) {
		this.pcURL = pcURL;
	}

	public String getShopURL() {
		return shopURL;
	}

	public void setShopURL(String shopURL) {
		this.shopURL = shopURL;
	}

	public String getSmartphoneServerHost() {
		return smartphoneServerHost;
	}

	public void setSmartphoneServerHost(String smartphoneServerHost) {
		this.smartphoneServerHost = smartphoneServerHost;
	}

	public String getSmartphoneServerPort() {
		return smartphoneServerPort;
	}

	public void setSmartphoneServerPort(String smartphoneServerPort) {
		this.smartphoneServerPort = smartphoneServerPort;
	}
	
	public String getMaxHistoryShowDays() {
		return maxHistoryShowDays;
	}

	public void setMaxHistoryShowDays(String maxHistoryShowDays) {
		this.maxHistoryShowDays = maxHistoryShowDays;
	}
}
