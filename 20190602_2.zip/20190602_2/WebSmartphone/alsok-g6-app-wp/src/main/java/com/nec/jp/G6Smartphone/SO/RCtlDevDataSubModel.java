package com.nec.jp.G6Smartphone.SO;

public class RCtlDevDataSubModel {

	private String lnCtlDev;		// 
	private String gouKi;			// 制御装置.号機番号
	private String serialNum;		// 制御装置.シリアル番号
	private String lnKeibi;			// 警備先地区.LN_警備先論理番号
	private String subAddr;			// 警備先地区.サブアドレス
	private String customerNum1;	// 警備先.お客様番号1
	private String sdLineKind;
	private String lnDev;
	
	public RCtlDevDataSubModel() {
		this.lnCtlDev = "";
		this.gouKi = "";
		this.serialNum = "";
	}

	public RCtlDevDataSubModel(String lnKeibi, String subAddr, String gouKi, String serialNum,
			String customerNum1) {
		this.lnKeibi = lnKeibi;
		this.subAddr = subAddr;
		this.gouKi = gouKi;
		this.serialNum = serialNum;
		this.customerNum1 = customerNum1;
	}

	public RCtlDevDataSubModel(String lnKeibi, String subAddr, String gouKi, String serialNum, String sdLineKind, String customerNum1) {
	        this.gouKi = gouKi;
	        this.serialNum = serialNum;
	        this.lnKeibi = lnKeibi;
	        this.subAddr = subAddr;
	        this.sdLineKind = sdLineKind;
	        this.customerNum1 = customerNum1;
	}
	
	public RCtlDevDataSubModel(String lnKeibi, String subAddr, String gouKi, String serialNum, String sdLineKind, String customerNum1, String lnDev) {
        this.gouKi = gouKi;
        this.serialNum = serialNum;
        this.lnKeibi = lnKeibi;
        this.subAddr = subAddr;
        this.sdLineKind = sdLineKind;
        this.customerNum1 = customerNum1;
        this.lnDev = lnDev;
	}
	
	public RCtlDevDataSubModel(String lnCtlDev, String gouKi, String serialNum) {
		this.lnCtlDev = lnCtlDev;
		this.gouKi = gouKi;
		this.serialNum = serialNum;
	}

   public RCtlDevDataSubModel(String lnCtlDev, String gouKi, String serialNum, String sdLineKind) {
        this.lnCtlDev = lnCtlDev;
        this.gouKi = gouKi;
        this.serialNum = serialNum;
        this.sdLineKind = sdLineKind;
    }
	   
	public String getLnCtlDev() {
		return lnCtlDev;
	}

	public void setLnCtlDev(String lnCtlDev) {
		this.lnCtlDev = lnCtlDev;
	}

	public String getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getGouKi() {
		return gouKi;
	}

	public void setGouKi(String gouKi) {
		this.gouKi = gouKi;
	}

	public String getLnKeibi() {
		return lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getSubAddr() {
		return subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public String getCustomerNum1() {
		return customerNum1;
	}

	public void setCustomerNum1(String customerNum1) {
		this.customerNum1 = customerNum1;
	}
	
   public String getSdLineKind() {
        return sdLineKind;
    }

    public void setSdLineKind(String sdLineKind) {
        this.sdLineKind = sdLineKind;
    }
    
    public String getLnDev() {
		return lnDev;
	}

	public void setLnDev(String lnDev) {
		this.lnDev = lnDev;
	}
}
