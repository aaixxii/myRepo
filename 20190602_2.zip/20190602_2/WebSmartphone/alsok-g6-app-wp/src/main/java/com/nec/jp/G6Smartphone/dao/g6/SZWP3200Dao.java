package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.HEventInfoDataModel;

@Repository
public class SZWP3200Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<HEventInfoDataModel> getEventImgInfo(String lnEventInfoHst) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT		DATE_FORMAT(heventinfo.HASSEI_TS, '%Y/%m/%d %H:%i:%s') as hasseiTs");
		strBuilder.append(",					heventinfo.CHIKU_NM as chikuNm");
		strBuilder.append(",					heventinfo.KENCHI_NAIYOU as kenchiNaiyou");
		strBuilder.append(",					IFNULL(cast(heventinfo.VFILE_INFO as character),'') as vfileInfo");
		strBuilder.append(",					heventinfo.LN_EVENT_INFO_HST as lnEventInfoHst");
		strBuilder.append(",					cast(heventinfo.VIDE_LK_FLG as character) as videLkFlg");
		strBuilder.append(" FROM			H_EVENT_INFO heventinfo");
		strBuilder.append(" WHERE		heventinfo.LN_EVENT_INFO_HST = :lnEventInfoHst");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "HEventInfoDataModelResult");
		query.setParameter("lnEventInfoHst", lnEventInfoHst);

		return (List<HEventInfoDataModel>) query.getResultList();
	}
}
