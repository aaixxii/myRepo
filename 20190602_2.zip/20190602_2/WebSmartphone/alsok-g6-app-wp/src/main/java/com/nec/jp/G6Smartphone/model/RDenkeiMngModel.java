package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.ResDeleteKeibiStart;


/**
 * The persistent class for the R_DENKEI_MNG database table.
 * 
 */
@SqlResultSetMapping(name="ResDeleteKeibiStartResult",
	classes = {
		@ConstructorResult(
			targetClass = ResDeleteKeibiStart.class,
			columns = {
				@ColumnResult(name = "denkei")
			}
		)
	}
)
@Entity
@Table(name="R_DENKEI_MNG")
@NamedQuery(name="RDenkeiMngModel.findAll", query="SELECT r FROM RDenkeiMngModel r")
public class RDenkeiMngModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_DENKEI_MNG")
	private String lnDenkeiMng;

	@Column(name="DEL_FLG")
	private String delFlg;

	@Column(name="DENKEI")
	private String denkei;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="LAST_FLG")
	private String lastFlg;

	@Column(name="LN_KEIBI")
	private String lnKeibi;

	@Column(name="RCV_FLG")
	private String rcvFlg;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public RDenkeiMngModel() {
	}

	public String getLnDenkeiMng() {
		return this.lnDenkeiMng;
	}

	public void setLnDenkeiMng(String lnDenkeiMng) {
		this.lnDenkeiMng = lnDenkeiMng;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getDenkei() {
		return this.denkei;
	}

	public void setDenkei(String denkei) {
		this.denkei = denkei;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getLastFlg() {
		return this.lastFlg;
	}

	public void setLastFlg(String lastFlg) {
		this.lastFlg = lastFlg;
	}

	public String getLnKeibi() {
		return this.lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getRcvFlg() {
		return this.rcvFlg;
	}

	public void setRcvFlg(String rcvFlg) {
		this.rcvFlg = rcvFlg;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}