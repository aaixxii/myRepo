package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.CameraDataModel;
import com.nec.jp.G6Smartphone.SO.CameraDataSubModel;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.SO.RDevNameDataModel;
import com.nec.jp.G6Smartphone.SO.ResDisplayLiveImage;


/**
 * The persistent class for the R_DEV database table.
 * 
 */
@SqlResultSetMappings({
	@SqlResultSetMapping(name="RDevDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = RDevDataModel.class,
				columns = {
					@ColumnResult(name = "lnDev"),
					@ColumnResult(name = "sdDevNm"),
					@ColumnResult(name = "sdDevNum")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RDevNameDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = RDevNameDataModel.class,
				columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "lnDev"),
					@ColumnResult(name = "sdDevNm")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RDevFullDataModelResult",
	classes = {
		@ConstructorResult(
			targetClass = RDevNameDataModel.class,
			columns = {
				@ColumnResult(name = "lnKbChiku"),
				@ColumnResult(name = "lnDev"),
				@ColumnResult(name = "sdDevNm"),
				@ColumnResult(name = "sdDevNum")
			}
		)
	}
),
	@SqlResultSetMapping(name="CameraDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = CameraDataModel.class,
				columns = {
					@ColumnResult(name = "lnDev"),
					@ColumnResult(name = "sdDevNm"),
					@ColumnResult(name = "sdDevNum")
				}
			)
		}
	),
	@SqlResultSetMapping(name="CameraDataSubModelResult",
		classes = {
			@ConstructorResult(
				targetClass = CameraDataSubModel.class,
				columns = {
					@ColumnResult(name = "lnImgVoc"),
					@ColumnResult(name = "savePath"),
					@ColumnResult(name = "fileNm")
				}
			)
		}
	),
	@SqlResultSetMapping(name="ResDisplayLiveImageResult",
		classes = {
			@ConstructorResult(
				targetClass = ResDisplayLiveImage.class,
				columns = {
					@ColumnResult(name = "savePath"),
					@ColumnResult(name = "fileNm")
				}
			)
		}
	)
})

@Entity
@Table(name="R_DEV")
@NamedQuery(name="RDevModel.findAll", query="SELECT r FROM RDevModel r")
public class RDevModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_DEV")
	private String lnDev;

	@Column(name="CHIKU")
	private String chiku;

	@Column(name="DEL_FLG")
	private String delFlg;

	@Column(name="DEV_SERIAL_NUM")
	private String devSerialNum;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="LN_KB_AREA")
	private String lnKbArea;

	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;

	@Column(name="LN_KEIBI")
	private String lnKeibi;

	@Column(name="SD_DEV_KIND_CD")
	private String sdDevKindCd;

	@Column(name="SD_DEV_NM")
	private String sdDevNm;

	@Column(name="SD_DEV_NUM")
	private String sdDevNum;
	
	@Column(name="DEV_KIND")
	private String devKind;

	@Column(name="SD_INPUT_KIND")
	private String sdInputKind;

	@Column(name="SD_KEIBI_KIND")
	private String sdKeibiKind;

	@Column(name="SD_RM_KIND")
	private String sdRmKind;

	@Column(name="SD_SENSOR_GRP_NUM")
	private String sdSensorGrpNum;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public RDevModel() {
	}

	public String getLnDev() {
		return this.lnDev;
	}

	public void setLnDev(String lnDev) {
		this.lnDev = lnDev;
	}

	public String getChiku() {
		return this.chiku;
	}

	public void setChiku(String chiku) {
		this.chiku = chiku;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getDevSerialNum() {
		return this.devSerialNum;
	}

	public void setDevSerialNum(String devSerialNum) {
		this.devSerialNum = devSerialNum;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getLnKbArea() {
		return this.lnKbArea;
	}

	public void setLnKbArea(String lnKbArea) {
		this.lnKbArea = lnKbArea;
	}

	public String getLnKbChiku() {
		return this.lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getLnKeibi() {
		return this.lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getSdDevKindCd() {
		return this.sdDevKindCd;
	}

	public void setSdDevKindCd(String sdDevKindCd) {
		this.sdDevKindCd = sdDevKindCd;
	}

	public String getSdDevNm() {
		return this.sdDevNm;
	}

	public void setSdDevNm(String sdDevNm) {
		this.sdDevNm = sdDevNm;
	}

	public String getSdDevNum() {
		return this.sdDevNum;
	}

	public void setSdDevNum(String sdDevNum) {
		this.sdDevNum = sdDevNum;
	}
	
	public String getDevKind() {
		return this.devKind;
	}

	public void setDevKind(String devKind) {
		this.devKind = devKind;
	}

	public String getSdInputKind() {
		return this.sdInputKind;
	}

	public void setSdInputKind(String sdInputKind) {
		this.sdInputKind = sdInputKind;
	}

	public String getSdKeibiKind() {
		return this.sdKeibiKind;
	}

	public void setSdKeibiKind(String sdKeibiKind) {
		this.sdKeibiKind = sdKeibiKind;
	}

	public String getSdRmKind() {
		return this.sdRmKind;
	}

	public void setSdRmKind(String sdRmKind) {
		this.sdRmKind = sdRmKind;
	}

	public String getSdSensorGrpNum() {
		return this.sdSensorGrpNum;
	}

	public void setSdSensorGrpNum(String sdSensorGrpNum) {
		this.sdSensorGrpNum = sdSensorGrpNum;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}