package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;


/**
 * The persistent class for the C_QUE_CTRL_SIG database table.
 * 
 */
@SqlResultSetMappings ({
	@SqlResultSetMapping(name="ControlQueueStatusModelResult",
		classes = {
			@ConstructorResult(
				targetClass = ControlQueueStatusModel.class,
				columns = {
					@ColumnResult(name = "sts"),
					@ColumnResult(name = "soapMsg")
				}
			)
		}
	),
		@SqlResultSetMapping(name="ControlQueueSendStatusModelResult",
		classes = {
			@ConstructorResult(
				targetClass = ControlQueueStatusModel.class,
				columns = {
					@ColumnResult(name = "sts")
				}
			)
		}
	)
})
@Entity
@Table(name="C_QUE_CTRL_SIG")
@NamedQuery(name="CQueCtrlSigModel.findAll", query="SELECT c FROM CQueCtrlSigModel c")
public class CQueCtrlSigModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_QUE_CTRL_SIG")
	private String lnQueCtrlSig;

	@Column(name="CENTER_ERR_DTL")
	private String centerErrDtl;

	@Column(name="CMD_CD")
	private String cmdCd;

	@Column(name="CMD_SEQ_NUM")
	private String cmdSeqNum;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CMD_TIMEOUT_TM")
	private Date cmdTimeoutTm;

	@Column(name="CONN_DEV_NUM")
	private String connDevNum;

	@Column(name="CTL_CMD_RSLT")
	private String ctlCmdRslt;

	@Column(name="CTL_RESULT_CD")
	private String ctlResultCd;

	@Column(name="DENKEI")
	private String denkei;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DEQ_ABL_TS")
	private Date deqAblTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DEQ_TS")
	private Date deqTs;

	@Column(name="DEV_NUM")
	private String devNum;

	@Column(name="DIR_NM")
	private String dirNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ENQ_TS")
	private Date enqTs;

	@Column(name="EXEC_CMD")
	private String execCmd;

	@Lob
	@Column(name="FILE_KIND")
	private String fileKind;

	@Column(name="GOUKI")
	private String gouki;

	@Column(name="HOST_NM")
	private String hostNm;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="PRIORITY")
	private String priority;

	@Column(name="PROCESS_NUM")
	private String processNum;

	@Column(name="RM_ERR_CD")
	private String rmErrCd;

	@Column(name="RM_RESULT")
	private String rmResult;

	@Column(name="SERIAL_NUM")
	private String serialNum;

	@Lob
	@Column(name="SOAP_MSG")
	private String soapMsg;

	@Column(name="STS")
	private String sts;

	@Column(name="SUB_ADDR")
	private String subAddr;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public CQueCtrlSigModel() {
	}

	public String getLnQueCtrlSig() {
		return this.lnQueCtrlSig;
	}

	public void setLnQueCtrlSig(String lnQueCtrlSig) {
		this.lnQueCtrlSig = lnQueCtrlSig;
	}

	public String getCenterErrDtl() {
		return this.centerErrDtl;
	}

	public void setCenterErrDtl(String centerErrDtl) {
		this.centerErrDtl = centerErrDtl;
	}

	public String getCmdCd() {
		return this.cmdCd;
	}

	public void setCmdCd(String cmdCd) {
		this.cmdCd = cmdCd;
	}

	public String getCmdSeqNum() {
		return this.cmdSeqNum;
	}

	public void setCmdSeqNum(String cmdSeqNum) {
		this.cmdSeqNum = cmdSeqNum;
	}

	public Date getCmdTimeoutTm() {
		return this.cmdTimeoutTm;
	}

	public void setCmdTimeoutTm(Date cmdTimeoutTm) {
		this.cmdTimeoutTm = cmdTimeoutTm;
	}

	public String getConnDevNum() {
		return this.connDevNum;
	}

	public void setConnDevNum(String connDevNum) {
		this.connDevNum = connDevNum;
	}

	public String getCtlCmdRslt() {
		return this.ctlCmdRslt;
	}

	public void setCtlCmdRslt(String ctlCmdRslt) {
		this.ctlCmdRslt = ctlCmdRslt;
	}

	public String getCtlResultCd() {
		return this.ctlResultCd;
	}

	public void setCtlResultCd(String ctlResultCd) {
		this.ctlResultCd = ctlResultCd;
	}

	public String getDenkei() {
		return this.denkei;
	}

	public void setDenkei(String denkei) {
		this.denkei = denkei;
	}

	public Date getDeqAblTs() {
		return this.deqAblTs;
	}

	public void setDeqAblTs(Date deqAblTs) {
		this.deqAblTs = deqAblTs;
	}

	public Date getDeqTs() {
		return this.deqTs;
	}

	public void setDeqTs(Date deqTs) {
		this.deqTs = deqTs;
	}

	public String getDevNum() {
		return this.devNum;
	}

	public void setDevNum(String devNum) {
		this.devNum = devNum;
	}

	public String getDirNm() {
		return this.dirNm;
	}

	public void setDirNm(String dirNm) {
		this.dirNm = dirNm;
	}

	public Date getEnqTs() {
		return this.enqTs;
	}

	public void setEnqTs(Date enqTs) {
		this.enqTs = enqTs;
	}

	public String getExecCmd() {
		return this.execCmd;
	}

	public void setExecCmd(String execCmd) {
		this.execCmd = execCmd;
	}

	public String getFileKind() {
		return this.fileKind;
	}

	public void setFileKind(String fileKind) {
		this.fileKind = fileKind;
	}

	public String getGouki() {
		return this.gouki;
	}

	public void setGouki(String gouki) {
		this.gouki = gouki;
	}

	public String getHostNm() {
		return this.hostNm;
	}

	public void setHostNm(String hostNm) {
		this.hostNm = hostNm;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getPriority() {
		return this.priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getProcessNum() {
		return this.processNum;
	}

	public void setProcessNum(String processNum) {
		this.processNum = processNum;
	}

	public String getRmErrCd() {
		return this.rmErrCd;
	}

	public void setRmErrCd(String rmErrCd) {
		this.rmErrCd = rmErrCd;
	}

	public String getRmResult() {
		return this.rmResult;
	}

	public void setRmResult(String rmResult) {
		this.rmResult = rmResult;
	}

	public String getSerialNum() {
		return this.serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getSoapMsg() {
		return this.soapMsg;
	}

	public void setSoapMsg(String soapMsg) {
		this.soapMsg = soapMsg;
	}

	public String getSts() {
		return this.sts;
	}

	public void setSts(String sts) {
		this.sts = sts;
	}

	public String getSubAddr() {
		return this.subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}