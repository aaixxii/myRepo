package com.nec.jp.G6Smartphone.utility;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator.Builder;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

public abstract class AbstractJWTVerifier {
	
	
	/**
	 * JWT認証トークンの固定鍵を取得する
	 * @return String 固定鍵
	 */
	abstract public String getSecret();
	
	/**
	 * JWT認証トークンの発行元を取得する
	 * @return String 発行元
	 */
	abstract public String getIssuer();
	
	/**
	 * JWT認証トークンの有効期限を取得する(分)
	 * @return int 有効期限(分)
	 */
	abstract public int getExpireMinute();
	
	/**
	 * JWT認証トークンを発行する
	 * @param claims JWTトークンに含めるプライベートクレーム
	 * @return String JWT認証トークン
	 * @throws JWTCreationException　JWT認証トークンの生成エラー
	 */
	public String createToken(Map<String, String> claims) throws JWTCreationException {
		
		// 有効期限の算出
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MINUTE, getExpireMinute());
		Date expiredAt = calendar.getTime();
		
		try {
			Builder token = JWT.create().withIssuer(getIssuer()).withExpiresAt(expiredAt);
			// プライベートクレームの埋め込み
			for(Map.Entry<String, String> entry : claims.entrySet()) {
				token.withClaim(entry.getKey(), entry.getValue());
			}
			return token.sign(Algorithm.HMAC256(getSecret()));
		}
		catch(IllegalArgumentException e) {
			throw new JWTCreationException(e.getMessage(),e.getCause());
		}
	}
	
	/**
	 * JWT認証トークンをデコードして返却する
	 * @param token JWT認証トークン
	 * @return DecodedJWT デコード済JWT認証トークン
	 * @throws JWTVerificationException JWT認証トークンの検証エラー
	 */
	public DecodedJWT verifyToken(String token) throws JWTVerificationException {
		try {
			return JWT.require(Algorithm.HMAC256(getSecret())).withIssuer(getIssuer()).build().verify(token);
		}
		catch(IllegalArgumentException e) {
			throw new JWTVerificationException(e.getMessage(),e.getCause());
		}
	}
	
	/**
	 * デコード済JWTから指定されたプライベートクレームを取り出す
	 * プライベートクレームが存在しない場合、ブランクを返す
	 * @param decordedJWT デコード済JWT認証トークン
	 * @param name プライベートクレーム名
	 * @return String プライベートクレーム値
	 */
	public String getClaim(DecodedJWT decordedJWT, String name) {
		if(decordedJWT == null) {
			return "";
		}
		Map<String, Claim> claims = decordedJWT.getClaims();
		Claim claim = claims.get(name);
		if(claim == null) {
			return "";
		}
		return claim.asString();
	}
}
