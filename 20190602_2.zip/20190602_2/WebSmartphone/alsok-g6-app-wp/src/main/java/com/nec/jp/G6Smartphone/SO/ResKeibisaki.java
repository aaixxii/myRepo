package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResKeibisaki implements ErrorHandler {

	private String errorCode;						// エラーコード
	private String errorMsg;						// エラーメッセージ
	private String acntID;							// アカウント論理番号
	private String totalPage; 						// トータルページ
	private List<RKeibiDataModel> rKeibiItem;



	public ResKeibisaki() {
		this.errorCode  = G6Constant.FAIL_POPUP_CD;
		this.errorMsg   = "";
		this.acntID     = "";
		this.totalPage  = "0";
		this.rKeibiItem = new ArrayList<RKeibiDataModel>();
	}

	public ResKeibisaki(String errorCode, String errorMsg, List<HistoryDataModel> historyItem, String totalPage, List<RKeibiDataModel> rKeibiItem) {
		this.errorCode  = errorCode;
		this.errorMsg   = errorMsg;
		this.acntID     = "";
		this.totalPage  = totalPage;
		this.rKeibiItem = rKeibiItem;
	}
	
	public List<RKeibiDataModel> getrKeibiItem() {
		return rKeibiItem;
	}

	public void setrKeibiItem(List<RKeibiDataModel> rKeibiItem) {
		this.rKeibiItem = rKeibiItem;
	}

	public String getTotalPage() {
		return totalPage;
	}
	
	public void setTotalPage(String totalPage) {
		this.totalPage = totalPage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
