package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResControlCamera implements ErrorHandler {

	private String errorCode;			// エラーコード
	private String errorMsg;			// エラーメッセージ
	private String has_ope_auth;		// 要求者の操作権限取得情報
	private String acnt_type_for_ope;	// 操作権限保持者のアカウント種別
	private String acnt_name; 			// 操作権限保持者のアカウント名称              
	private String acntID;				// アカウント論理番号
	
	public ResControlCamera() {
		this.errorCode 			= G6Constant.FAIL_POPUP_CD;
		this.errorMsg 			= "";
		this.has_ope_auth 		= "";
		this.acnt_type_for_ope 	= "";
		this.acnt_name 			= "";
		this.acntID 			= "";
	}

	public ResControlCamera(String errorCode, String errorMsg, String has_ope_auth, String acnt_type_for_ope, String acnt_name) {
		this.errorCode 			= errorCode;
		this.errorMsg 			= errorMsg;
		this.has_ope_auth 		= has_ope_auth;
		this.acnt_type_for_ope 	= acnt_type_for_ope;
		this.acnt_name 			= acnt_name;
		this.acntID 			= "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getHas_ope_auth() {
		return has_ope_auth;
	}

	public void setHas_ope_auth(String has_ope_auth) {
		this.has_ope_auth = has_ope_auth;
	}

	public String getAcnt_type_for_ope() {
		return acnt_type_for_ope;
	}

	public void setAcnt_type_for_ope(String acnt_type_for_ope) {
		this.acnt_type_for_ope = acnt_type_for_ope;
	}

	public String getAcnt_name() {
		return acnt_name;
	}

	public void setAcnt_name(String acnt_name) {
		this.acnt_name = acnt_name;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
	
}
