package com.nec.jp.G6Smartphone.SO;

public class CameraDataSubModel {

	private String lnImgVoc;	// LN_蓄積画像音声論理番号
	private String savePath;		// 保存先
	private String fileNm;			// ファイル名

	public CameraDataSubModel(String savePath, String fileNm) {
		this.savePath = savePath;
		this.fileNm = fileNm;
	}

	public CameraDataSubModel(String lnImgVoc, String savePath, String fileNm) {
		this.lnImgVoc = lnImgVoc;
		this.savePath = savePath;
		this.fileNm = fileNm;
	}

	public String getLnImgVoc() {
		return lnImgVoc;
	}

	public void setLnImgVoc(String lnImgVoc) {
		this.lnImgVoc = lnImgVoc;
	}

	public String getSavePath() {
		return savePath;
	}

	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}

	public String getFileNm() {
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
}
