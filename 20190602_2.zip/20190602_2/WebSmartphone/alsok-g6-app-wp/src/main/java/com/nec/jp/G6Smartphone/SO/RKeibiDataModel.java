package com.nec.jp.G6Smartphone.SO;

public class RKeibiDataModel {

	private String lnKeibi;		// 警備先.LN_警備先論理番号
	private String keibiName1;	// 警備先.警備先名1
	private String keibiAddr1;	// 警備先.警備先住所１

	public RKeibiDataModel() {}

	public RKeibiDataModel(String lnKeibi, String keibiName1, String keibiAddr1) {
		this.lnKeibi = lnKeibi;
		this.keibiName1 = keibiName1;
		this.keibiAddr1 = keibiAddr1;
	}

	public String getLnKeibi() {
		return lnKeibi;
	}
	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}
	public String getKeibiName1() {
		return keibiName1;
	}
	public void setKeibiName1(String keibiName1) {
		this.keibiName1 = keibiName1;
	}
	public String getKeibiAddr1() {
		return keibiAddr1;
	}
	public void setKeibiAddr1(String keibiAddr1) {
		this.keibiAddr1 = keibiAddr1;
	}
}
