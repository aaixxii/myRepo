package com.nec.jp.G6Smartphone.dao.ghs;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nec.jp.G6Smartphone.SO.UserOperationChikuInfoModel;
import com.nec.jp.G6Smartphone.model.CSequenceManagerModel;
import com.nec.jp.G6Smartphone.model.EQueCtrlModel;

@Repository
public class CommonGhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;
    
	public String getMaxCmdSeqNumGHS(String seqId) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	c.CMD_SEQ_NUM");
		strBuilder.append(" FROM	E_QUE_CTRL c");
		strBuilder.append(" ORDER BY c.CMD_SEQ_NUM DESC");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setMaxResults(1);

		return query.getSingleResult().toString();
	}
	
	public BigInteger findCmdSeqNum(String cmdSeqNum) {
		try {
			StringBuilder strBuilder = new StringBuilder();

			strBuilder.append(" SELECT COUNT(*)");
			strBuilder.append(" FROM	E_QUE_CTRL c");
			strBuilder.append(" WHERE c.CMD_SEQ_NUM = :cmdSeqNum");

			final Query query = entityManager.createNativeQuery(strBuilder.toString());
			query.setParameter("cmdSeqNum", cmdSeqNum);
			return (BigInteger) query.getSingleResult();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return BigInteger.ZERO;
	}
	
	@Transactional("transactionManagerGhs")
	public Boolean saveEQueCtrlModel(EQueCtrlModel entity) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" INSERT INTO E_QUE_CTRL");
		strBuilder.append("		(LN_QUE_CTRL, HOST_NM, DENKEI, GOUKI, SERIAL_NUM,");
		strBuilder.append("		CONN_DEV_NUM, DEV_NUM, SUB_ADDR, PRIORITY, CMD_SEQ_NUM,");
		strBuilder.append("		PROCESS_NUM, CMD_CD, EXEC_CMD, SOAP_MSG, ENQ_TS,");
		strBuilder.append("		DEQ_ABL_TM, STS, ID_INSERT, INSERT_NM, INSERT_TS,");
		strBuilder.append("		ID_UPDATE, UPDATE_NM, UPDATE_TS)");
		strBuilder.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter(1, entity.getLnQueCtrl());
		query.setParameter(2, entity.getHostNm());
		query.setParameter(3, entity.getDenkei());
		query.setParameter(4, entity.getGouki());
		query.setParameter(5, entity.getSerialNum());
		query.setParameter(6, entity.getConnDevNum());
		query.setParameter(7, entity.getDevNum());
		query.setParameter(8, entity.getSubAddr());
		query.setParameter(9, entity.getPriority());
		query.setParameter(10, entity.getCmdSeqNum());
		query.setParameter(11, entity.getProcessNum());
		query.setParameter(12, entity.getCmdCd());
		query.setParameter(13, entity.getExecCmd());
		query.setParameter(14, entity.getSoapMsg());
		query.setParameter(15, entity.getEnqTs());
		query.setParameter(16, entity.getDeqAblTm());
		query.setParameter(17, entity.getSts());
		query.setParameter(18, entity.getIdInsert());
		query.setParameter(19, entity.getInsertNm());
		query.setParameter(20, entity.getInsertTs());
		query.setParameter(21, entity.getIdUpdate());
		query.setParameter(22, entity.getUpdateNm());
		query.setParameter(23, entity.getUpdateTs());

		if (query.executeUpdate() > 0) {
            return true;
        }
        return false;
	}

	@Transactional("transactionManagerGhs")
	public int insertCSequenceManagerModel(CSequenceManagerModel entity) {
		int result = -1;
		final StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" INSERT INTO C_SEQUENCE_MANAGER (SEQ_ID, SEQ_CNT, MAX_SEQ_CNT)");
		strBuilder.append(" VALUES (?,?,?)");

		final Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter(1, entity.getSeqId());
		query.setParameter(2, entity.getSeqCnt());
		query.setParameter(3, entity.getMaxSeqCnt());
		result = query.executeUpdate();
		return result;
	}
	
	public void insertCSequenceManagerModel2(CSequenceManagerModel entity) {
		entityManager.persist(entity);
	}
	
	/**
	 * get sequence in table C_Sequence_Manager
	 * @param cmdSeqNum
	 * @return max number
	 */
	public long getSeq(String cmdSeqNum) {
		String result = "";
		final StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("GET_SEQUENCE")
                .registerStoredProcedureParameter(1 , String.class , ParameterMode.IN)
                .registerStoredProcedureParameter(2 , String.class, ParameterMode.OUT);
        storedProcedure.setParameter(1, cmdSeqNum);
        storedProcedure.execute();
        result = (String)storedProcedure.getOutputParameterValue(2);
		return Long.parseLong(result);
	}
	
    public UserOperationChikuInfoModel getChikuInfoForUserOperation(String lnKeibi, String lnKbChiku) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(LN_KEIYK, '') as lnKeiyk, ");
        strBuilder.append("     IFNULL(KEIBI_NM, '') as keibiNm,");
        strBuilder.append("     IFNULL(SD_KOBETU_NM, '') as sdKobetuNm");
        strBuilder.append(" FROM R_BUKKEN bkn"); 
        strBuilder.append("  INNER JOIN R_KEIBI kb"); 
        strBuilder.append("   on bkn.LN_BUKKEN = kb.LN_BUKKEN"); 
        strBuilder.append("  LEFT JOIN R_KB_CHIKU chk"); 
        strBuilder.append("    ON kb.LN_KEIBI = chk.LN_KEIBI"); 
        strBuilder.append("    AND chk.LN_KB_CHIKU = :lnKbChiku"); 
        strBuilder.append(" where kb.LN_KEIBI = :lnKeibi");
        
        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "UserOperationChikuInfoModelResult");
        
        query.setParameter("lnKeibi", lnKeibi);
        query.setParameter("lnKbChiku", lnKbChiku);
        
        query.setMaxResults(1);
        return (UserOperationChikuInfoModel) query.getSingleResult();
    }
    
    public String getLnKeibiFromLnKbChiku(String lnKbChiku) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(chk.LN_KEIBI, '') as lnKeibi ");
        strBuilder.append(" FROM R_KB_CHIKU chk"); 
        strBuilder.append(" where chk.LN_KB_CHIKU = :lnKbChiku");
        
        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnKbChiku", lnKbChiku);
        
        query.setMaxResults(1);
        return (String) query.getSingleResult();
    }
    
    public UserOperationChikuInfoModel getChikuInfoFromKbinf(String lnKbInf) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(kbCh.LN_KEIBI, '') as lnKeibi, ");
        strBuilder.append("     IFNULL(kbCh.LN_KB_CHIKU , '') as lnKbChiku");
        strBuilder.append(" FROM E_KB_NOTICE kbNt"); 
        strBuilder.append("  INNER JOIN R_KB_CHIKU kbCh"); 
        strBuilder.append("   ON kbNt.LN_KB_CHIKU = kbCh.LN_KB_CHIKU");  
        strBuilder.append(" WHERE kbNt.LN_KB_INF = :lnKbInf");

        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "UserOperationChikuInfoFromKeibInfModelResult");
        
        query.setParameter("lnKbInf", lnKbInf);
        
        query.setMaxResults(1);
        return (UserOperationChikuInfoModel) query.getSingleResult();
    }
    
    public String getAcntTypeFromAcntKeiyk(String lnAcntKeiyk) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(actKy.ACNT_TYPE, '') as acntType");
        strBuilder.append(" FROM R_ACNT_KEIYK actKy"); 
        strBuilder.append(" WHERE actKy.LN_ACNT_KEIYK = :lnAcntKeiyk");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        
        query.setParameter("lnAcntKeiyk", lnAcntKeiyk);
        return (String) query.getSingleResult();
    }
    
    public String getAcntTypeFromAcntUser(String lnAcntUser) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(actUs.ACNT_TYPE, '') as acntType");
        strBuilder.append(" FROM R_ACNT_USER actUs"); 
        strBuilder.append(" WHERE actUs.LN_ACNT_USER = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        
        query.setParameter("lnAcntUser", lnAcntUser);
        return (String) query.getSingleResult();
    }
    
    public String getLnKbChikuFromChiku(String lnKeibi, String chiku) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     ck.LN_KB_CHIKU as lnKbChiku");
        strBuilder.append(" FROM R_KB_CHIKU ck"); 
        strBuilder.append(" WHERE ck.LN_KEIBI = :lnKeibi");
        strBuilder.append(" AND ck.CHIKU = :chiku");
        
        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        
        query.setParameter("lnKeibi", lnKeibi);
        query.setParameter("chiku", chiku);
        
        query.setMaxResults(1);
        return (String) query.getSingleResult();
    }
    
    public Date getKiyLastLoginTs(String lnAcntUser) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT	ckls.LAST_LOGIN_TS as lastLoginTs");
        strBuilder.append(" FROM	C_KEIYK_LOGIN_STS ckls");
        strBuilder.append(" WHERE	ckls.LN_ACNT_KEIYK = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUser", lnAcntUser);

        return (Date)query.getSingleResult();
    }
    
    public Date getLiyLastLoginTs(String lnAcntUser) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT	culs.LAST_LOGIN_TS as lastLoginTs");
        strBuilder.append(" FROM	C_USER_LOGIN_STS culs");
        strBuilder.append(" WHERE	culs.LN_ACNT_USER = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUser", lnAcntUser);

        return (Date)query.getSingleResult();
    }
    
    public Date getKiyLastModifyAcntTs(String lnAcntUser) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT	rak.UPDATE_TS as updateTs");
        strBuilder.append(" FROM	R_ACNT_KEIYK rak");
        strBuilder.append(" WHERE	rak.LN_ACNT_KEIYK = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUser", lnAcntUser);

        return (Date)query.getSingleResult();
    }
    
    public Date getLiyLastModifyAcntTs(String lnAcntUser) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT	rau.UPDATE_TS as updateTs");
        strBuilder.append(" FROM	R_ACNT_USER rau");
        strBuilder.append(" WHERE	rau.LN_ACNT_USER = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUser", lnAcntUser);

        return (Date)query.getSingleResult();
    }
}
