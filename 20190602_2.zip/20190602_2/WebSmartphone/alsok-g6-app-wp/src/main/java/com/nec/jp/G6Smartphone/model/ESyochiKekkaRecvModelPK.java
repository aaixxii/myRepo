package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the E_SYOCHI_KEKKA_RECV database table.
 * 
 */
@Embeddable
public class ESyochiKekkaRecvModelPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="SYS_KBN")
	private String sysKbn;

	@Column(name="SRC_GYOUMU_CD")
	private String srcGyoumuCd;

	@Column(name="SRC_HOST_NUM")
	private String srcHostNum;

	@Column(name="RECV_TS")
	private String recvTs;

	@Column(name="PROGRAM_ID")
	private String programId;

	@Column(name="SEQ_NUM")
	private String seqNum;

	public ESyochiKekkaRecvModelPK() {
	}
	public String getSysKbn() {
		return this.sysKbn;
	}
	public void setSysKbn(String sysKbn) {
		this.sysKbn = sysKbn;
	}
	public String getSrcGyoumuCd() {
		return this.srcGyoumuCd;
	}
	public void setSrcGyoumuCd(String srcGyoumuCd) {
		this.srcGyoumuCd = srcGyoumuCd;
	}
	public String getSrcHostNum() {
		return this.srcHostNum;
	}
	public void setSrcHostNum(String srcHostNum) {
		this.srcHostNum = srcHostNum;
	}
	public String getRecvTs() {
		return this.recvTs;
	}
	public void setRecvTs(String recvTs) {
		this.recvTs = recvTs;
	}
	public String getProgramId() {
		return this.programId;
	}
	public void setProgramId(String programId) {
		this.programId = programId;
	}
	public String getSeqNum() {
		return this.seqNum;
	}
	public void setSeqNum(String seqNum) {
		this.seqNum = seqNum;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ESyochiKekkaRecvModelPK)) {
			return false;
		}
		ESyochiKekkaRecvModelPK castOther = (ESyochiKekkaRecvModelPK)other;
		return 
			this.sysKbn.equals(castOther.sysKbn)
			&& this.srcGyoumuCd.equals(castOther.srcGyoumuCd)
			&& this.srcHostNum.equals(castOther.srcHostNum)
			&& this.recvTs.equals(castOther.recvTs)
			&& this.programId.equals(castOther.programId)
			&& this.seqNum.equals(castOther.seqNum);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.sysKbn.hashCode();
		hash = hash * prime + this.srcGyoumuCd.hashCode();
		hash = hash * prime + this.srcHostNum.hashCode();
		hash = hash * prime + this.recvTs.hashCode();
		hash = hash * prime + this.programId.hashCode();
		hash = hash * prime + this.seqNum.hashCode();
		
		return hash;
	}
}