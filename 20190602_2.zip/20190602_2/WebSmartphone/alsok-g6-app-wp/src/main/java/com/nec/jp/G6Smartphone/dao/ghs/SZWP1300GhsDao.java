package com.nec.jp.G6Smartphone.dao.ghs;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.SdKobetuDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP1300GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<SdKobetuDataModel> getDistrictPulldownInfoGHS(String lnKeibi, List<String> kbChikuSubAddrList) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	SD_KOBETU_NM as sdKobetuNm,");
		strBuilder.append("			CHIKU as chiku,");
		strBuilder.append("			'' as subAddr");
		strBuilder.append(" FROM	R_KB_CHIKU");
		strBuilder.append(" WHERE	LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND ENTRY_STS = :entrySts");
		if (kbChikuSubAddrList.size() > 0) {
			strBuilder.append("		AND SUB_ADDR IN :kbChikuSubAddrList");
		}
		strBuilder.append(" ORDER BY SUB_ADDR ASC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "SdKobetuDataModelResult");
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("entrySts", G6CodeConsts.CD031.REGISTERED);
		if (kbChikuSubAddrList.size() > 0) {
			query.setParameter("kbChikuSubAddrList", kbChikuSubAddrList);
		}

		return (List<SdKobetuDataModel>) query.getResultList();
	}
}
