package com.nec.jp.G6Smartphone.dao.ghs;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.HistoryDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP1400GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	private StringBuilder getDistrictPulldownInfoSql(Set<String> type1, String ghsType) {
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append(" SELECT DATE_FORMAT(a.SEND_TM, '%Y/%m/%d %H:%i:%s') as sendTs,");
		strBuilder.append("		b.SD_KOBETU_NM as sdKobetuNm,");
		strBuilder.append("		a.SIG_TYPE_2 as sigKind2,");
		strBuilder.append("		a.SIG_TYPE_1 as sigKind1,");
		strBuilder.append("		IFNULL(a.OPERATION_USER, '') as operationUser,");
		if (G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION.equals(ghsType)) {
			strBuilder.append("	IFNULL((SELECT c.LN_KB_INF FROM E_KEIYK_KB_NOTICE_ML_TGT c WHERE c.LN_KB_INF = a.LN_KB_INF LIMIT 1), '') as lnKbInf,");
		} else if (G6CodeConsts.CD027.GHS_THE_USER.equals(ghsType)) {
			strBuilder.append("	IFNULL((SELECT c.LN_KB_INF FROM E_KB_NOTICE_ML_TGT c WHERE c.LN_KB_INF = a.LN_KB_INF LIMIT 1), '') as lnKbInf,");
		}
		strBuilder.append("		IFNULL(a.BODY, '') as body,");
		strBuilder.append("		CAST(a.RM_TYPE as CHARACTER) as rmKind,");
		strBuilder.append("		IFNULL(a.SIG_NM, '') as sigNm,");
		strBuilder.append("		'' AS kbAreaNm,");
		strBuilder.append("		IFNULL(d.CARD_KOTEI_ID, '') as cardKoteiID,");
		strBuilder.append("		'' AS lnJian");
		strBuilder.append(" FROM	E_KB_NOTICE a");
		strBuilder.append("		INNER JOIN R_KB_CHIKU b ON a.LN_KB_CHIKU = b.LN_KB_CHIKU");
		strBuilder.append("		LEFT JOIN E_KB_INF_HTBL d ON d.LN_KB_INF = a.LN_KB_INF");
		strBuilder.append(" WHERE	(DATE_FORMAT(a.SEND_TM, '%Y%m%d') BETWEEN :dtFrom AND :dtTo)");
		strBuilder.append("		AND b.LN_KEIBI = :lnKeibi");
		strBuilder.append("		AND b.CHIKU = :chiku");
		if(type1.size() > 0) {
			strBuilder.append("	AND a.SIG_TYPE_1 IN :type1");
		}
		strBuilder.append(" ORDER BY a.SEND_TM DESC,");
		strBuilder.append(" 		a.LN_KB_INF DESC");
		
		return strBuilder;
	}

	public BigInteger getTotalRow(String lnKeibi, String chiku, Date dtFrom, Date dtTo, Set<String> type1, String ghsType) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append("SELECT COUNT(*) FROM (");
		strBuilder.append(getDistrictPulldownInfoSql(type1, ghsType).toString());
		strBuilder.append(") DistrictPulldownInfo");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("chiku", chiku);
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		if(type1.size() > 0) {
			query.setParameter("type1", type1);
		}
		
		return (BigInteger)query.getSingleResult();
	}
	
	@SuppressWarnings("unchecked")
	public List<HistoryDataModel> getDistrictPulldownInfoGHS(String lnKeibi, String chiku, Date dtFrom, Date dtTo, Set<String> type1, String ghsType, int offset, int limitRowNum ) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append(getDistrictPulldownInfoSql(type1, ghsType).toString());
		strBuilder.append(" LIMIT :offset, :limitRowNum");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString(), "HistoryDataModelResult");
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("chiku", chiku);
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		if(type1.size() > 0) {
			query.setParameter("type1", type1);
		}
		query.setParameter("offset", offset);
		query.setParameter("limitRowNum", limitRowNum);

		return (List<HistoryDataModel>) query.getResultList();
	}
}
