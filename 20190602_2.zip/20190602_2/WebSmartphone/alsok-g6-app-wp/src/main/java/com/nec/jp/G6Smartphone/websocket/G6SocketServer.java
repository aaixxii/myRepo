package com.nec.jp.G6Smartphone.websocket;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.java_websocket.util.Base64;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.MYCD008;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6DataSocket;

import jp.co.alsok.g6.common.log.ApplicationLog;

public class G6SocketServer extends WebSocketServer {

    private static final ApplicationLog appLog = new ApplicationLog(G6SocketServer.class);
    

    private volatile Set<WebSocket> conns;
    private volatile HashMap<String, List<String>> mFiles;
    private final String FIRST_MSG = "-1";
    
    public G6SocketServer(int port) {
        super(new InetSocketAddress(port));
    	appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketServer()");
        conns = new HashSet<>();
        mFiles = new HashMap<String, List<String>>();
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketServer()");
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        if (conn != null) {
            try {
                conns.add(conn);
                final String key = keyWebSocket(conn);
                mFiles.put(key, new ArrayList<String>());
            } catch (Exception ex) {
            	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
            }
        }
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        if (conn != null) {
            try {
                final String ip = conn.getRemoteSocketAddress().getAddress().getHostAddress();
                removeDataSocket(conn);
                conns.remove(conn);
            } catch (Exception ex) {
            	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
            }
        }
    }

    @Autowired(required = false)
    @Override
    public void onMessage(WebSocket conn, String message) {
        try {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketServer.onMessage");
            final JSONObject obj = convertStringToJson(message);
            final G6DataSocket g6Obj = new G6DataSocket();
            final String key = keyWebSocket(conn);
            if (conn != null && conn.isOpen() && obj != null) {
                final String liveIP = (String) obj.get(RequestParam.liveIP.getValue());
                final String downloadPort = (String) obj.get(RequestParam.downloadPort.getValue());
                final String index = (String) obj.get(RequestParam.index.getValue());
                final String language = (String) obj.get(RequestParam.language.getValue());
                try {
                    // open socket client to Media server
                    if (FIRST_MSG.equals(index)) {
                        initSocketClient(conn, liveIP, Integer.parseInt(downloadPort), key, language);
                    } else {
                        nextSendData(conn, index, key, language);
                    }
                } catch (Exception ex) {
                    sendFailure(conn, g6Obj, key, language);
                    appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
                }
            } else {
                sendFailure(conn, g6Obj, key, G6CodeConsts.CD238.JAPANESE);
            }
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketServer.onMessage");
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
        }
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketServer.onError");
        if (conn != null) {
            try {
                // do some thing if required
                final String ip = conn.getRemoteSocketAddress().getAddress().getHostAddress();
                // remove data received
                removeDataSocket(conn);
                conns.remove(conn);
            } catch (Exception e) {
            	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
            }
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketServer.onError");
    }

    @Override
    public void onStart() {
    }

    /**
     * open a socket to Media server belong to ip & port received
     * 
     * @param webSock
     * @param liveIP
     * @param downloadPort
     * @param key
     * @param language
     */
    private synchronized void initSocketClient(WebSocket webSock, 
                                                String liveIP, 
                                                int downloadPort, 
                                                String key,
                                                String language) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketServer.initSocketClient");
    	
    	try {
            final Thread thread = new Thread(key) {
                public synchronized void run() {
                    final G6DataSocket g6Obj = new G6DataSocket();
                    try {
                        final G6SocketClient client = new G6SocketClient();
                        if (client != null) {
                            client.downloadExecute(webSock, liveIP, downloadPort, language, key, findFiles(webSock));
                        }
                    } catch (Exception e) {
                        sendFailure(webSock, g6Obj, key, language);
                        appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
                    } finally {
                        try {
                            if (key.equals(Thread.currentThread().getName())) {
                                Thread.currentThread().interrupt();
                            }
                        } catch (Exception ex) {
                        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
                        }
                    }
                }
            };
            thread.start();
        } catch(Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketServer.initSocketClient");
    }

    @Autowired
    private void nextSendData(WebSocket webSock, String index, String key, String language) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketServer.nextSendData");
        final List<String> client = findFiles(webSock);
        final G6DataSocket g6Obj = new G6DataSocket();
        final String extension = g6Obj.getValueSetting(G6Constant.FILE_EXTENSION);
        final String fileName = g6Obj.smoothExtension(index + "." + extension);

        String file = "";
        int nextIndex = 0;
        try {
            if (client != null && client.size() > 0) {
                String[] arr;
                String name;
                for (int i = 0; i < client.size(); i++) {
                    arr = client.get(i).split("_");
                    name = arr[arr.length - 1];
                    if (fileName.equals(name)) {
                        file = client.get(i);
                        if (i < client.size() - 1) {
                            arr = client.get(i + 1).split("_");
                            name = arr[arr.length - 1];
                            nextIndex = nextIndexFile(name);
                        }
                        break;
                    }
                }
            }

            if ("".equals(file)) {
                sendSucceed(webSock, g6Obj, key);
            } else {
                sendDataFromTempFiles(webSock, file, language, Integer.parseInt(index), nextIndex, key);
            }
        } catch (Exception ex) {
            sendFailure(webSock, g6Obj, key, language);
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketServer.nextSendData");
    }

    /**
     * get next index
     * 
     * @param nextFile
     * @return
     */
    private int nextIndexFile(String nextFile) {
        int result = 0;
        try {
            final String[] arr = nextFile.split("\\.");
            result = Integer.parseInt(arr[0]);
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return result;
    }

    /**
     * convert a String to json object
     * 
     * @param message
     * @return
     */
    private JSONObject convertStringToJson(String message) {
        JSONObject result = null;
        try {
            if (message != null && !"".equals(message)) {
                result = new JSONObject(message);
            }
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);         }
        return result;
    }

    /**
     * delete a socket client connected
     * 
     * @param sock
     */
    private void removeDataSocket(WebSocket sock) {
        try {
            final String key = keyWebSocket(sock);
            if (key != null) {
                removeDataTmp(key);
            }
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
    }

    /**
     * find a List template file stored
     * 
     * @param sock
     * @return
     */
    private List<String> findFiles(WebSocket sock) {
        try {
            final String key = keyWebSocket(sock);
            return mFiles.get(key);
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return null;
    }

    /**
     * Create a key for websocket client
     * 
     * @param sock
     * @return a key
     */
    private String keyWebSocket(WebSocket sock) {
        final StringBuilder s = new StringBuilder();
        try {
            if (sock != null) {
                s.append(sock.toString().replaceAll("\\.", "").replaceAll("\\@", "")
                        .replaceAll("orgjava_websocketWebSocketImpl", "G6DataTmp_")).append("_").append(sock.hashCode())
                        .append("_")
                        .append(sock.getRemoteSocketAddress().getAddress().getHostAddress().replaceAll("\\.", ""))
                        .append("_").append(sock.getRemoteSocketAddress().getPort());
            }
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        return s.toString();
    }

    /**
     * Read data from template file in /var/tmp/... folder
     * 
     * @param webSock
     * @param file
     * @param language
     * @param index
     * @param nextIndex
     * @param key
     */
    private void sendDataFromTempFiles(WebSocket webSock, 
                                        String file, 
                                        String language, 
                                        int index, 
                                        int nextIndex,
                                        String key) {
    	appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "WebSocketServer#sendDataFromTempFiles");
        final G6DataSocket g6Obj = new G6DataSocket();
        JSONObject obj;
        try {
            final BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
            byte[] buffer = new byte[MYCD008.BUFFER_SIZE];
            int count = index;
            while (in.read(buffer) != -1) {
                count += 1;
                obj = g6Obj.convertData(G6Constant.SUCCESS_CD, "", MYCD008.STATUS_RUN, count,
                        Base64.encodeBytes(buffer));
                webSock.send(obj.toString());
            }
            if (nextIndex == 0) {
                sendSucceed(webSock, g6Obj, key);
            } else {
                obj = g6Obj.convertData(G6Constant.SUCCESS_CD, "", MYCD008.STATUS_WRITER, nextIndex, "");
                webSock.send(obj.toString());
            }
            in.close();
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "sendDataFromTempFiles#index>>>");
        } catch (Exception e) {
            sendFailure(webSock, g6Obj, key, language);
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        } finally {
            g6Obj.removeFile(file);
        }
    }

    /**
     * send status succeed to client
     * 
     * @param webSock
     * @param g6Obj
     * @param key
     */
    private void sendSucceed(WebSocket webSock, G6DataSocket g6Obj, String key) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketServer.sendSucceed()");
        try {
            if (webSock != null && g6Obj != null) {
                JSONObject obj = g6Obj.convertData(G6Constant.SUCCESS_CD, "", MYCD008.STATUS_END, -1, "");
                webSock.send(obj.toString());
            }
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
        } finally {
            removeDataTmp(key);
            closeSocket(webSock);
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketServer.sendSucceed()");
    }

    /**
     * send status failure to client
     * 
     * @param webSock
     * @param g6Obj
     * @param key
     * @param language
     */
    private void sendFailure(WebSocket webSock, G6DataSocket g6Obj, String key, String language) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketServer.sendFailure()");
        try {
            if (webSock != null && g6Obj != null) {
                final JSONObject obj = g6Obj.getDataError(language);
                webSock.send(obj.toString());
            }
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
        } finally {
            removeDataTmp(key);
            closeSocket(webSock);
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketServer.sendFailure()");
    }

    /**
     * remove all file in folder stored in template file
     * 
     * @param key
     */
    private void removeFolder(String key) {
        try {
            final G6DataSocket g6Obj = new G6DataSocket();
            final String path = g6Obj.smoothFolder(g6Obj.getValueSetting(G6Constant.PATH_TEMPLATE) + "/" + key);
            g6Obj.removeFolder(path);
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
        }
    }

    /**
     * remove all data related to socket closed
     * 
     * @param key
     */
    private void removeDataTmp(String key) {
        try {
            if (key != null && !"".equals(key)) {
                // remove folder created
                removeFolder(key);
                // remove list file added
                if (mFiles != null && mFiles.size() > 0) {
                    final List<String> lst = mFiles.get(key);
                    if (lst != null) {
                        lst.clear();
                    }
                    mFiles.remove(key);
                }
            }
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
        }
    }
    
    private void closeSocket(WebSocket webSock) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketServer.closeSocket()");
        try {
            if (webSock != null) {
                webSock.close();
            }
        } catch (Exception ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketServer.closeSocket()");
    }
}