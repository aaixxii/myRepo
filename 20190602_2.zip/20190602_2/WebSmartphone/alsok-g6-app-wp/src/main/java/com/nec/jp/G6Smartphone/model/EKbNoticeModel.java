package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.HistoryDataModel;


/**
 * The persistent class for the E_KB_NOTICE database table.
 * 
 */
@SqlResultSetMappings({
	@SqlResultSetMapping(name="HistoryDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = HistoryDataModel.class,
				columns = {
					@ColumnResult(name = "sendTs"),
					@ColumnResult(name = "sdKobetuNm"),
					@ColumnResult(name = "sigKind2"),
					@ColumnResult(name = "sigKind1"),
					@ColumnResult(name = "operationUser"),
					@ColumnResult(name = "rmKind"),
					@ColumnResult(name = "body"),
					@ColumnResult(name = "sigNm"),
					@ColumnResult(name = "lnKbInf"),
					@ColumnResult(name = "kbAreaNm"),
					@ColumnResult(name = "cardKoteiID"),
					@ColumnResult(name = "lnJian")
				}
			)
		}
	)
})
@Entity
@Table(name="E_KB_NOTICE")
@NamedQuery(name="EKbNoticeModel.findAll", query="SELECT e FROM EKbNoticeModel e")
public class EKbNoticeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_KB_INF")
	private String lnKbInf;

	@Lob
	@Column(name="BODY")
	private String body;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;

	@Column(name="LN_TENANT_MNG")
	private String lnTenantMng;

	@Column(name="OPERATION_USER")
	private String operationUser;

	@Column(name="RM_KIND")
	private String rmKind;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SEND_TS")
	private Date sendTs;

	@Column(name="SENDER_NM")
	private String senderNm;

	@Column(name="SIG_KIND_1")
	private String sigKind1;

	@Column(name="SIG_KIND_2")
	private String sigKind2;

	@Column(name="SIG_NM")
	private String sigNm;

	@Column(name="TITLE")
	private String title;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public EKbNoticeModel() {
	}

	public String getLnKbInf() {
		return this.lnKbInf;
	}

	public void setLnKbInf(String lnKbInf) {
		this.lnKbInf = lnKbInf;
	}

	public String getBody() {
		return this.body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getLnKbChiku() {
		return this.lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getLnTenantMng() {
		return this.lnTenantMng;
	}

	public void setLnTenantMng(String lnTenantMng) {
		this.lnTenantMng = lnTenantMng;
	}

	public String getOperationUser() {
		return this.operationUser;
	}

	public void setOperationUser(String operationUser) {
		this.operationUser = operationUser;
	}

	public String getRmKind() {
		return this.rmKind;
	}

	public void setRmKind(String rmKind) {
		this.rmKind = rmKind;
	}

	public Date getSendTs() {
		return this.sendTs;
	}

	public void setSendTs(Date sendTs) {
		this.sendTs = sendTs;
	}

	public String getSenderNm() {
		return this.senderNm;
	}

	public void setSenderNm(String senderNm) {
		this.senderNm = senderNm;
	}

	public String getSigKind1() {
		return this.sigKind1;
	}

	public void setSigKind1(String sigKind1) {
		this.sigKind1 = sigKind1;
	}

	public String getSigKind2() {
		return this.sigKind2;
	}

	public void setSigKind2(String sigKind2) {
		this.sigKind2 = sigKind2;
	}

	public String getSigNm() {
		return this.sigNm;
	}

	public void setSigNm(String sigNm) {
		this.sigNm = sigNm;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}