package com.nec.jp.G6Smartphone.SO;

public interface DataModelHandler {

}
