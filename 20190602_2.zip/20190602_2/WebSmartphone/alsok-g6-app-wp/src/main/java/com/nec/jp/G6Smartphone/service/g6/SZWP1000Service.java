package com.nec.jp.G6Smartphone.service.g6;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.KbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataModel;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP1000Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1000Service {

	@Autowired
	SZWP1000Dao sZWP1000Dao;

	public List<KbChikuDataModel> getListSecurityDistrict(String acntID, String lnKeibi, List<String> remoteGSMChiku) throws ApplicationException {
		try {
			List<KbChikuDataModel> kbChikuDataModelList = sZWP1000Dao.getListSecurityDistrict(acntID, lnKeibi, remoteGSMChiku);

			return kbChikuDataModelList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

   public List<RDevDataModel> getListDevice(String lnKeibi, String lnKbChiku) throws ApplicationException {
        try {
            List<RDevDataModel> rDevDataModelList =  sZWP1000Dao.getListDevice(lnKeibi, lnKbChiku);
            return rDevDataModelList;

        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
        }
    }
	   
//	public List<RDevDataModel> getListDevice(String lnKeibi, String lnKbChiku, List<String> drctSdRmKind) throws ApplicationException {
//		try {
//			 List<RDevDataModel> rDevDataModelList =  sZWP1000Dao.getListDevice(lnKeibi, lnKbChiku, drctSdRmKind);
//		    
//			return rDevDataModelList;
//
//		} catch (Exception e) {
//			// DBアクセス例外
//			String errorMsg = G6Common.printStackTraceToString(e);
//
//			// 処理終了
//			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
//		}
//	}

	public List<String> getListElectricNum(String lnKeibi) throws ApplicationException {
		try {
			List<String> resultList = sZWP1000Dao.getListElectricNum(lnKeibi);

			return resultList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

//	public List<RCtlDevDataModel> getListGoukiSerial(String lnDev) throws ApplicationException {
//		try {
//			List<RCtlDevDataModel> resultList = sZWP1000Dao.getListGoukiSerial(lnDev);
//	
//			return resultList;
//		} catch (Exception e) {
//			// DBアクセス例外
//			String errorMsg = G6Common.printStackTraceToString(e);
//
//			// 処理終了
//			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
//		}
//	}

   public List<RCtlDevDataModel> getListGoukiSerial(String lnDev, String lnKbChiku) throws ApplicationException {
        try {
            List<RCtlDevDataModel> resultList = sZWP1000Dao.getListGoukiSerial(lnDev, lnKbChiku);
    
            return resultList;
        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
        }
    }
	   
	public String getControlQueueSts(String cmdSeqNum) throws ApplicationException {
		try {
			String result = sZWP1000Dao.getControlQueueSts(cmdSeqNum);

			return result;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getDeviceSts(String lnDev) throws ApplicationException {
		try {
			String result = sZWP1000Dao.getDeviceSts(lnDev);

			return (result == null) ? "" : result;

		} catch (NoResultException ex) {
			return "";

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
