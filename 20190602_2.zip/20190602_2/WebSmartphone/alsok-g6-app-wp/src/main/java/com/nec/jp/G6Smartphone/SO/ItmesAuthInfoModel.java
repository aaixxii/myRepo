package com.nec.jp.G6Smartphone.SO;

public class ItmesAuthInfoModel {

	private String menupassInf;		
	private String userAcntAuthNm;	
	private String menuAuth;
	
	public ItmesAuthInfoModel() {
		this.menupassInf = "";
		this.userAcntAuthNm = "";
		this.menuAuth = "";
	}
			
	public ItmesAuthInfoModel(String menupassInf, String userAcntAuthNm, String menuAuth) {
		this.menupassInf = menupassInf;
		this.userAcntAuthNm = userAcntAuthNm;
		this.menuAuth = menuAuth;
	}

	public String getMenupassInf() {
		return menupassInf;
	}

	public void setMenupassInf(String menupassInf1) {
		this.menupassInf = menupassInf1;
	}

	public String getUserAcntAuthNm() {
		return userAcntAuthNm;
	}

	public void setUserAcntAuthNm(String userAcntAuthNm) {
		this.userAcntAuthNm = userAcntAuthNm;
	}

	public String getMenuAuth() {
		return menuAuth;
	}

	public void setMenuAuth(String menuAuth) {
		this.menuAuth = menuAuth;
	}		
}
