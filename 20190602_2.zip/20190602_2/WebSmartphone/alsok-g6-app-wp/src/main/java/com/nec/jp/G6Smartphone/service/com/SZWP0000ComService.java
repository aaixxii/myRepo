package com.nec.jp.G6Smartphone.service.com;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.jp.G6Smartphone.dao.com.CommonComDao;
import com.nec.jp.G6Smartphone.dao.com.SZWP0000ComDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP0000ComService {

	@Autowired
	private SZWP0000ComDao sZWP0000Dao;
	@Autowired
	private CommonComDao commonDao;

	public Integer getLoginFailureTimes(String lnAcntUserCommon) throws ApplicationException {
		try {
			return Integer.valueOf(sZWP0000Dao.getLoginFailureTimes(lnAcntUserCommon));

		} catch (NoResultException noResultE) {
			return -1;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getLanguageType(String lnAcntUserCommon, String acntLanguage) throws ApplicationException {
		try {
			String lang = commonDao.getLanguageType(lnAcntUserCommon);

			if (lang == null || "".equals(lang)) {
				lang = acntLanguage;
			}
			return lang;

		} catch (NoResultException noResultE) {
			return acntLanguage;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	@Transactional("transactionManagerCom")
	public Boolean updateLoginFailureTimes(String lnAcntUserCommon, String acntNm, String failureTimes)
			throws ApplicationException {
		try {
			return sZWP0000Dao.updateLoginFailureTimes(lnAcntUserCommon, acntNm, failureTimes);
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	@Transactional("transactionManagerCom")
	public Boolean updateLoginStatus(String lnAcntUserCommon, String acntNm) throws ApplicationException {
		try {
			return sZWP0000Dao.updateLoginStatus(lnAcntUserCommon, acntNm);
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
