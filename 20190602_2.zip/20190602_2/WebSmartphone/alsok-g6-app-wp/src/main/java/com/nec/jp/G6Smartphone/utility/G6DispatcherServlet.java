package com.nec.jp.G6Smartphone.utility;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.servlet.DispatcherServlet;

import com.nec.jp.G6Smartphone.websocket.G6SocketServer;

import jp.co.alsok.g6.common.log.ApplicationLog;

public class G6DispatcherServlet  extends DispatcherServlet implements ServletContextListener, WebApplicationInitializer{

    static{
        try {
            // ログメッセージ定義ファイルの読み込み
            ApplicationLog.readConfigurations("zwp_appLog.xml");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Value("${smartphone_server_port}") String smartphoneServerPort;
    private static final ApplicationLog appLog = new ApplicationLog(G6DispatcherServlet.class);
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private G6SocketServer mG6SocketServer = null;
    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SmartphoneDispatcherServlet#onStartup");
        try {
            // ignore ssl certificate
            new IgnoreSsl();
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SmartphoneDispatcherServlet#onStartup");
    }

    @Override
    public void contextInitialized(ServletContextEvent arg0) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SmartphoneDispatcherServlet#contextInitialized");

        try {
            if (this.mG6SocketServer == null) {
                if (smartphoneServerPort == null || "".equals(smartphoneServerPort)) {
                    final G6DataSocket g6Obj = new G6DataSocket();
                    smartphoneServerPort = g6Obj.getValueSetting(G6Constant.SMARTPHONE_SERVER_PORT);
                    if (smartphoneServerPort == null || "".equals(smartphoneServerPort)) {
                        smartphoneServerPort = "38088";
                    }
                }
                this.mG6SocketServer = new G6SocketServer(Integer.parseInt(smartphoneServerPort));
                if (this.mG6SocketServer != null) {
                    this.mG6SocketServer.start();
                }             
            }
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SmartphoneDispatcherServlet#contextInitialized");
        } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
    }
    
    @Override
    public void contextDestroyed(ServletContextEvent arg0) { 
        try {
            if (this.mG6SocketServer != null) {
                this.mG6SocketServer.stop();
            }
        } catch (IOException ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        } catch (InterruptedException ex) {
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        } finally {
            this.mG6SocketServer = null;
        }
    }
}
