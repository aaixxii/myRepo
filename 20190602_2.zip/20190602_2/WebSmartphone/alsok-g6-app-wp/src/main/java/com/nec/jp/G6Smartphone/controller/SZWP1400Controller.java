package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.HistoryDataModel;
import com.nec.jp.G6Smartphone.SO.ResSearchHistory;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP1400Service;
import com.nec.jp.G6Smartphone.service.ghs.SZWP1400GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;
import com.nec.jp.G6Smartphone.utility.G6Constant.SignalKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.SignalType;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWP1400Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP1400Controller.class);
    //JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;

	@Autowired
	SZWP1400Service sZWP1400Service;
	@Autowired
	SZWP1400GhsService sZWP1400GhsService;
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;

	@Value("${maxHistoryShowDays}")
	Integer MAX_HISTORY_DAYS;
	@Value("${GHS_KB_OPE}")
	String GHS_KB_OPE;
	@Value("${GHS_KB_ALM}")
	String GHS_KB_ALM;
	@Value("${limit_row_num}")
	int limit_row_num;
	

	/*
	 * Get data from E_KB_NOTICE, R_KB_CHIKU table
	 * @param: acntID, lnKeibi, chiku, dtFrom, dtTo, operation, start, presence,
	 * 			release, vacancy, alarm, prevent, emergency, rescue, facility, fire, gas,
	 * 			acum, patrol 
	 * return: object ResSearchHistory as JSON
	 */
	@RequestMapping(value = "/searchHistory", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String searchHistory(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1400Controller.searchHistory()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResSearchHistory resSearchHistory = new ResSearchHistory();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntType = "";
		int totalRow = 0;
		int totalPage = 0;
		int offset = 0;
		int pageNo = 0;
		String acntNm = "";

		try {
			Date dtFrom = null;
			Date dtTo = null;
			List<HistoryDataModel> historyDataModelList = new ArrayList<HistoryDataModel>();
			Set<String> setType1 = new HashSet<String>();
			List<String> signalList = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(SignalKey.operation.getValue());
					add(SignalKey.alarm.getValue());
				}
			};

			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

         // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 21) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
				return jsonResult;
			}

			// Build require parameters
			Map<String, Boolean> lstRequiredParam = new HashMap<String, Boolean>() {
				private static final long serialVersionUID = 1L;
				{
					put(RequestParam.acntID.getValue(), true);
					put(RequestParam.acntNm.getValue(), true);
					put(RequestParam.acntSbt.getValue(), true);
					put(RequestParam.lnKeibi.getValue(), true);
					put(RequestParam.chiku.getValue(), false);
					put(RequestParam.dtFrom.getValue(), false);
					put(RequestParam.dtTo.getValue(), false);
					put(SignalKey.operation.getValue(), false);
					put(SignalKey.start.getValue(), false);
					put(SignalKey.presence.getValue(), false);
					put(SignalKey.release.getValue(), false);
					put(SignalKey.vacancy.getValue(), false);
					put(SignalKey.alarm.getValue(), false);
					put(SignalKey.prevent.getValue(), false);
					put(SignalKey.emergency.getValue(), false);
					//put(SignalKey.rescue.getValue(), false);
					put(SignalKey.facility.getValue(), false);
					put(SignalKey.fire.getValue(), false);
					put(SignalKey.gas.getValue(), false);
					put(SignalKey.acum.getValue(), false);
					put(SignalKey.patrol.getValue(), false);
					put(RequestParam.pageNo.getValue(), true);
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
				return jsonResult;
			}

			// リクエスト情報取得
			// リクエスト情報からアカウントID、検索条件、ページ、アカウント種別を取得する
			acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();

			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
				return jsonResult;
			}
			
			//Verify pageNo RequestParam
			pageNo = Integer.parseInt(mapParam.get(RequestParam.pageNo.getValue()).toString());
			if(pageNo < 0) {
				jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.FAIL_POPUP_CD, 
						ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
					
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
				return jsonResult;
			}

			// TODO SZWP1400：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 検索範囲補正
			// 年月日(From)が入力されていない場合
			if (null == mapParam.get(RequestParam.dtFrom.getValue()) || "".equals(mapParam.get(RequestParam.dtFrom.getValue()))) {
				// 年月日(From)にシステム日付の最大表示日数分過去の日付を設定する
				dtFrom = DateTimeCommon.getDateInPast(DateTimeCommon.getDateCurrentShortDate(), MAX_HISTORY_DAYS);
			} else {
				dtFrom = DateTimeCommon.stringToDate(mapParam.get(RequestParam.dtFrom.getValue()).toString());
			}

			// 年月日(To)が入力されていない場合
			if (null == mapParam.get(RequestParam.dtTo.getValue()) || "".equals(mapParam.get(RequestParam.dtTo.getValue()))) {
				// 年月日(To)にシステム日付を設定する
				dtTo = DateTimeCommon.getDateCurrentShortDate();
			} else {
				dtTo = DateTimeCommon.stringToDate(mapParam.get(RequestParam.dtTo.getValue()).toString());
			}

			// 履歴情報検索処理
			// アカウント種別が、次期警備の場合
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				List<Set<String>> listType1 = new ArrayList<Set<String>>();
				List<Set<String>> listType2 = new ArrayList<Set<String>>();

				// チェックボックスにチェックがある場合
				// チェックされた項目によって、信号種別1及び信号種別2の検索条件に各々の値を追加する
				// 8-1.信号種別検索条件
				listType1 = G6Common.getSignalType(mapParam, G6Constant.signalCheckList, SignalType.type1.getValue());
				listType2 = G6Common.getSignalType(mapParam, G6Constant.signalCheckList, SignalType.type2.getValue());

				//get total row
				totalRow = sZWP1400Service.getTotalRow(
						mapParam.get(RequestParam.lnKeibi.getValue()).toString(),
						mapParam.get(RequestParam.chiku.getValue()).toString(),
						dtFrom, dtTo, listType1, listType2);
				
				if(totalRow > 0) {
					//calculate total of pages
					totalPage = G6Common.calculateTotalPages(totalRow, limit_row_num);
					//Verify pageNo can not bigger than totalPage
					if(pageNo >  totalPage) {
						jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
						
						// 処理終了
						appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
						return jsonResult;
					}
					
					//calculate offset
					offset = G6Common.calculateOffSet(pageNo, limit_row_num);
					// 7-2.A)警備お知らせの取得
					// 7-2.B)警備エリア名称の取得
					// 7-2.C)カード番号の取得
					// 7-2.D)事案論理番号の取得
					historyDataModelList = sZWP1400Service.getDistrictPulldownInfo(
							mapParam.get(RequestParam.lnKeibi.getValue()).toString(),
							mapParam.get(RequestParam.chiku.getValue()).toString(),
							dtFrom, dtTo, listType1, listType2,
							offset,
							limit_row_num);
				}

			// リクエスト情報から取得したアカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				for (Map.Entry<String, Object> entry : mapParam.entrySet()) {
					if (signalList.contains(entry.getKey()) && G6Constant.MYCD002.CHECKED.equals(entry.getValue())) {
						// 「警備操作」のチェックボックスにチェックがある場合
						if ((SignalKey.operation.getValue()).equals(entry.getKey())) {
							// 信号種別1の検索条件に「01」を追加する
							setType1.add(GHS_KB_OPE);

						// 「警報」のチェックボックスにチェックがある場合
						} else if ((SignalKey.alarm.getValue()).equals(entry.getKey())) {
							// 信号種別1の検索条件に「11」を追加する
							setType1.add(GHS_KB_ALM);
						}
					}
				}

				if (setType1.size() == 0) {
					jsonResult = G6Common.messageSearchHandler(resSearchHistory, 
							G6Constant.FAIL_POPUP_CD, ErrorKey.NO_SEARCH_RESULT_FOUND.getValue(), ErrorKey.SCREEN_TITLE_SZWP1400.getValue(), acntLanguage);

					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
					return jsonResult;
				}

				// 7-3.A)警備お知らせの取得
				// 7-3.D)カード番号の取得
				if (acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
					//get total row
					totalRow = sZWP1400GhsService.getTotalRow(
							mapParam.get(RequestParam.lnKeibi.getValue()).toString(),
							mapParam.get(RequestParam.chiku.getValue()).toString(),
							dtFrom, dtTo, setType1, G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION);
					
					if(totalRow > 0) {
						//calculate total of pages
						totalPage = G6Common.calculateTotalPages(totalRow, limit_row_num);
						//Verify pageNo can not bigger than totalPage
						if(pageNo > totalPage) {
							jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
									
							// 処理終了
							appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
							return jsonResult;
						}
						
						//calculate offset
						offset = G6Common.calculateOffSet(pageNo, limit_row_num);
						// 7-3.B)(契約者)メール送信対象情報の取得
						historyDataModelList = sZWP1400GhsService.getDistrictPulldownInfoGHS(
								mapParam.get(RequestParam.lnKeibi.getValue()).toString(),
								mapParam.get(RequestParam.chiku.getValue()).toString(),
								dtFrom, dtTo, setType1, G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION,
								offset,
								limit_row_num);
					}
					

				} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER)) {
					//Get total page
					totalRow = sZWP1400GhsService.getTotalRow(
							mapParam.get(RequestParam.lnKeibi.getValue()).toString(),
							mapParam.get(RequestParam.chiku.getValue()).toString(),
							dtFrom, dtTo, setType1, G6CodeConsts.CD027.GHS_THE_USER);
					
					if(totalRow > 0) {
						//calculate total of pages
						totalPage = G6Common.calculateTotalPages(totalRow, limit_row_num);
						//Verify pageNo can not bigger than totalPage
						if(pageNo > totalPage) {
							jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
									
							// 処理終了
							appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
							return jsonResult;
						}
						
						//calculate offset
						offset = G6Common.calculateOffSet(pageNo, limit_row_num);
						// 7-3.C)(利用者)メール送信対象情報の取得
						historyDataModelList = sZWP1400GhsService.getDistrictPulldownInfoGHS(
								mapParam.get(RequestParam.lnKeibi.getValue()).toString(),
								mapParam.get(RequestParam.chiku.getValue()).toString(),
								dtFrom, dtTo, setType1, G6CodeConsts.CD027.GHS_THE_USER,
								offset,
								limit_row_num);
					}
				}

			// リクエスト情報から取得したアカウント種別が、ＧⅤの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GV)) {
			}
			
			// 検索結果（メール送信対象情報）が0件の場合
			if (historyDataModelList.size() == 0) {
				jsonResult = G6Common.messageSearchHandler(resSearchHistory, 
						G6Constant.FAIL_POPUP_CD, ErrorKey.NO_SEARCH_RESULT_FOUND.getValue(), ErrorKey.SCREEN_TITLE_SZWP1400.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
				return jsonResult;
			}
			
			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
			if(pageNo == 0) {
//				HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//				// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//				final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//				hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//				hUserOperationLogModel.setDispId(ScreenID.SZWP1400.getSlashValue());
//				hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//				commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm, DateTimeCommon.getCurrentDate());
				
				String lnKbChiku = commonService.getLnKbChikuFromChiku(acntType, mapParam.get(RequestParam.lnKeibi.getValue()).toString(), mapParam.get(RequestParam.chiku.getValue()).toString());
				
				HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
				hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());	// アカウントID
				hUserOperationLogModel.setInsertNm(acntNm);														// アカウント名
				hUserOperationLogModel.setLnKeibi(mapParam.get(RequestParam.lnKeibi.getValue()).toString());	// 警備先論理番号
				hUserOperationLogModel.setLnKbChiku(lnKbChiku);													// 警備先地区論理番号
				hUserOperationLogModel.setDispId(ScreenID.SZWP1400.getValueForOperationLog());					// 操作画面ID
				hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
				commonService.entryUserOperation(hUserOperationLogModel, acntType);
			}

			// 応答
			resSearchHistory.setErrorCode(G6Constant.SUCCESS_CD);
			resSearchHistory.setTotalPage(String.valueOf(totalPage));
			resSearchHistory.setHistoryItem(historyDataModelList);

			//デコード済acntIDを設定したJWT認証トークンを付与
			resSearchHistory.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
			jsonResult = G6Common.parseJSON(resSearchHistory, acntLanguage);

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resSearchHistory, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resSearchHistory, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
		} catch (Exception e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resSearchHistory, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resSearchHistory, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1400Controller.searchHistory()");
		return jsonResult;
	}

}
