package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetHistory implements ErrorHandler {

	private String errorCode;				// エラーコード
	private String errorMsg;				// エラーメッセージ
	private String recvMsg;					// 処置結果(事案情報).受信電文
	private List<SensorHistoryDataModel> sensorHistoryItem;
	private String acntID;

	public ResGetHistory() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.recvMsg = "";
		this.sensorHistoryItem = new ArrayList<SensorHistoryDataModel>();
		this.acntID = "";
	}

	public ResGetHistory(String errorCode, String errorMsg, String recvMsg, List<SensorHistoryDataModel> sensorHistoryItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.recvMsg = recvMsg;
		this.sensorHistoryItem = sensorHistoryItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<SensorHistoryDataModel> getSensorHistoryItem() {
		return sensorHistoryItem;
	}

	public void setSensorHistoryItem(List<SensorHistoryDataModel> sensorHistoryItem) {
		this.sensorHistoryItem = sensorHistoryItem;
	}

	public String getRecvMsg() {
		return recvMsg;
	}

	public void setRecvMsg(String recvMsg) {
		this.recvMsg = recvMsg;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
