package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetNoticeDetail implements ErrorHandler {

	private String errorCode;
	private String errorMsg;
	private String send_ts;
	private String title;
	private String insertNm;
	private String body;
	private String acntID;
	
	public ResGetNoticeDetail() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.send_ts = "";
		this.title = "";
		this.insertNm = "";
		this.body = "";
		this.acntID = "";
	}

	public ResGetNoticeDetail(String errorCode, String errorMsg, String send_ts, String title, String insertNm,
			String body) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.send_ts = send_ts;
		this.title = title;
		this.insertNm = insertNm;
		this.body = body;
		this.acntID = "";
	}

	public ResGetNoticeDetail(String send_ts, String title, String insertNm, String body) {
		this.errorCode = G6Constant.SUCCESS_CD;
		this.errorMsg = "";
		this.send_ts = send_ts;
		this.title = title;
		this.insertNm = insertNm;
		this.body = body;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getSend_ts() {
		return send_ts;
	}

	public void setSend_ts(String send_ts) {
		this.send_ts = send_ts;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getInsertNm() {
		return insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
	
}
