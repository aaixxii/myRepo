package com.nec.jp.G6Smartphone.service.g6;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.HEventInfoDataModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP3100Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP3100Service {

	@Autowired
	SZWP3100Dao sZWP3100Dao;

	public List<HEventInfoDataModel> getEventInfoSearchResult(String acntID, String lnKeibi, String lnKbChiku, Date dateFrom, Date dateTo, int offset, int limitRowNum) throws ApplicationException {
		try {
			return sZWP3100Dao.getEventInfoSearchResult(acntID, lnKeibi, lnKbChiku, dateFrom, dateTo, offset, limitRowNum);
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public int getTotalRow(String acntID, String lnKeibi, String lnKbChiku, Date dateFrom, Date dateTo) throws ApplicationException {
		try {
			return Integer.parseInt(sZWP3100Dao.getTotalRow(acntID, lnKeibi, lnKbChiku, dateFrom, dateTo));
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
