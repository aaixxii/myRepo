package com.nec.jp.G6Smartphone.service.g6;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ResGetKeibiStatus;
import com.nec.jp.G6Smartphone.SO.UserOperationChikuInfoModel;
import com.nec.jp.G6Smartphone.SO.YukoAcntUserInf;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.controller.SZWP0000Controller;
import com.nec.jp.G6Smartphone.dao.com.CommonComDao;
import com.nec.jp.G6Smartphone.dao.g6.CommonDao;
import com.nec.jp.G6Smartphone.dao.ghs.CommonGhsDao;
import com.nec.jp.G6Smartphone.model.CQueCtrlSigModel;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModelPK;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.ConvUtil;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.StringUtils;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;
import jp.co.alsok.g6.zzw.util.G6AuthControl.Keibi;
import jp.co.alsok.g6.zzw.util.G6AuthControl.Keiyk;

@Service
public class CommonService {
	
	@Autowired
	private CommonDao commonDao;
	@Autowired
	private CommonComDao commonComDao;
	@Autowired
	private CommonGhsDao commonGhsDao;
	
//	/**
//	 * get next cmd sequence number
//	 * @param seqId
//	 * @return
//	 * @throws ApplicationException
//	 */
//	public String getCmdSeq(String seqId) throws ApplicationException {
//		String result = G6Constant.INIT_CMD_SEQ_NUM;
//		try {
//		    result = getCmdSeq(seqId, 12);
//		} catch (NoResultException noResultE) {
//			return G6Constant.INIT_CMD_SEQ_NUM;
//		} catch (Exception e) {
//			// DBアクセス例外
//			String errorMsg = G6Common.printStackTraceToString(e);
//			// 処理終了
//			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
//		}
//		return result;
//	}
	
    /**
     * 指定SEQUENSE_IDの論理番号を取得する<br>
     *
     * @param seqId シーケンスID
     * @return 論理番号
     * @throws SQLException
     */
//    public String getLn(String seqId) throws ApplicationException {
//        try {
//            final long sequenceNo = Long.parseLong(commonDao.getNextCmdSeqNum(seqId));
//            final DecimalFormat df = new DecimalFormat();
//            final SimpleDateFormat sdf = new SimpleDateFormat("");
//            final Date dt = new Date();
//            sdf.setLenient(false);
//            sdf.applyPattern("yyyyMMddHHmmssSSS");
//            if (seqId.equals(G6Constant.CD_SEQUENCE.LN_QUE_KB_SIG_SEQ_NAME)) {
//                // 警備信号の場合のみシーケンスは二桁とし、末尾は0として返却
//                df.applyPattern("00");
//                return sdf.format(dt) + df.format(sequenceNo) + "0";
//            }
//            if (seqId.equals(G6Constant.CD_SEQUENCE.LN_QUE_MST_SEND_SEQ_NAME)
//                    || seqId.equals(G6Constant.CD_SEQUENCE.LN_SYNC_SALE_SYS)) {
//                // マスタ配信キューのみシーケンスは六桁とし、末尾は0として返却
//                // 通常はDBトリガにて設定するが、ミリ秒が取得できないためシーケンス番号で対応
//                sdf.applyPattern("yyyyMMddHHmmss");
//                df.applyPattern("000000");
//                return sdf.format(dt) + df.format(sequenceNo);
//            }
//            if (G6Constant.CD_SEQUENCE.LN_KB_CHIKU_SEQ_NAME.equals(seqId)
//                    || G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_SEQ_NAME.equals(seqId)
//                    || G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_DOKYO_SEQ_NAME.equals(seqId)
//                    || G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_KYUKYU_SEQ_NAME.equals(seqId)
//                    || G6Constant.CD_SEQUENCE.LN_LIVE_IMGVOC_SEQ_NAME.equals(seqId)
//                    || G6Constant.CD_SEQUENCE.LN_ACUM_IMGVOC_SEQ_NAME.equals(seqId)
//                    || G6Constant.CD_SEQUENCE.LN_SGN_IMGVOC_SEQ_NAME.equals(seqId)
//                    || G6Constant.CD_SEQUENCE.LN_RECORD_IMGVOC_SEQ_NAME.equals(seqId)
//                    || G6Constant.CD_SEQUENCE.LN_AI_IMGVOC_SEQ_NAME.equals(seqId)) {
//                // 論理番号4桁対象の場合
//                df.applyPattern("0000");
//                return sdf.format(dt).substring(0, 16) + df.format(sequenceNo);
//            }
//            df.applyPattern("000");
//            return sdf.format(dt) + df.format(sequenceNo);
//        } catch (NoResultException noResultE) {
//            return G6Constant.INIT_CMD_SEQ_NUM;
//        } catch (Exception e) {
//            // DBアクセス例外
//            String errorMsg = G6Common.printStackTraceToString(e);
//            // 処理終了
//            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
//        }
//    }
    
//	 /**
//     * get next cmd sequence number
//     * @param seqId
//     * @return
//     * @throws ApplicationException
//     */
//    private String getCmdSeq(String seqId, int len) {
//        final String maxSeqNum = commonDao.getNextCmdSeqNum(seqId);
//        final long sequenceNo = Long.parseLong(maxSeqNum);
//        final DecimalFormat df = new DecimalFormat();
//        final StringBuilder sb = new StringBuilder();
//        for (int i = 0; i < len; i++) {
//            sb.append("0");
//        }
//        df.applyPattern(sb.toString());
//        return df.format(sequenceNo);
//    }
	
	@Transactional("transactionManagerG6")
	public void saveCQueCtrlSigModel(Map<String, String> mapSoap, Date dateTime, String seqNo) throws ApplicationException {
		try {
			// 制御キューに情報を登録する
			// init data 警備状態設定要求
		    final CQueCtrlSigModel cQueCtrlSigModel = new CQueCtrlSigModel();
//			final String seqNo = getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
			cQueCtrlSigModel.setLnQueCtrlSig(seqNo);
			cQueCtrlSigModel.setHostNm(mapSoap.get(G6Constant.MYCD003.HOSTNM));
			cQueCtrlSigModel.setDenkei(mapSoap.get(G6Constant.MYCD003.DENKEINO));
			cQueCtrlSigModel.setGouki(mapSoap.get(G6Constant.MYCD003.GOUKINO));
			cQueCtrlSigModel.setSerialNum(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID));
			cQueCtrlSigModel.setConnDevNum(mapSoap.get(G6Constant.MYCD003.CONNDEVNUM));
			cQueCtrlSigModel.setDevNum(mapSoap.get(G6Constant.MYCD003.DEVNUM));
			cQueCtrlSigModel.setSubAddr(mapSoap.get(G6Constant.MYCD003.SUBADDRESS));
			cQueCtrlSigModel.setPriority(mapSoap.get(G6Constant.MYCD003.PRIORITY));
			cQueCtrlSigModel.setCmdSeqNum(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM));
			cQueCtrlSigModel.setProcessNum(mapSoap.get(G6Constant.MYCD003.PROCESSNUM));
			cQueCtrlSigModel.setCmdCd(mapSoap.get(G6Constant.MYCD003.CMDCD));
			cQueCtrlSigModel.setExecCmd(mapSoap.get(G6Constant.MYCD003.EXECCMD));
			cQueCtrlSigModel.setSoapMsg(mapSoap.get(G6Constant.MYCD003.SOAPMSG));
			cQueCtrlSigModel.setEnqTs(dateTime);
			cQueCtrlSigModel.setDeqAblTs(dateTime);
			cQueCtrlSigModel.setSts(mapSoap.get(G6Constant.MYCD003.STS));
			cQueCtrlSigModel.setInsertId(mapSoap.get(RequestParam.acntID.getValue()));
			cQueCtrlSigModel.setInsertNm(mapSoap.get(RequestParam.acntNm.getValue()));
			cQueCtrlSigModel.setInsertTs(dateTime);
			cQueCtrlSigModel.setUpdateId(mapSoap.get(RequestParam.acntID.getValue()));
			cQueCtrlSigModel.setUpdateNm(mapSoap.get(RequestParam.acntNm.getValue()));
			cQueCtrlSigModel.setUpdateTs(dateTime);

			commonDao.saveCQueCtrlSigModel(cQueCtrlSigModel);

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	/**
	 * 利用者操作履歴テーブルにレコードを登録する。
	 * @param hUserOperationLogModel
	 * @param acntSbt
	 * @throws ApplicationException
	 */
	@Transactional("transactionManagerG6")
	public void entryUserOperation(HUserOperationLogModel hUserOperationLogModel, String acntSbt) throws ApplicationException{
		try {
			// 操作履歴レコード登録に必要な情報を取得
			UserOperationChikuInfoModel chikuInfoModel = new UserOperationChikuInfoModel();
			String acntUserKbn;
			
			// 次期警備
			if (acntSbt.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// 警備先論理番号が設定されている場合は、警備先名/地区名を取得
				if (hUserOperationLogModel.getLnKeibi() != null && hUserOperationLogModel.getLnKeibi().length() > 0) {
					chikuInfoModel = commonDao.getChikuInfoForUserOperation(hUserOperationLogModel.getLnKeibi(), hUserOperationLogModel.getLnKbChiku());					
				}
				// 利用者アカウント区分を取得
				acntUserKbn = commonComDao.getAcntUserKbn(hUserOperationLogModel.getInsertId());
			
			// GHS利用者
			} else if (acntSbt.equals(G6CodeConsts.CD027.GHS_THE_USER)) {
				// 警備先論理番号が設定されている場合は、警備先名/地区名を取得
				if (hUserOperationLogModel.getLnKeibi() != null && hUserOperationLogModel.getLnKeibi().length() > 0) {
					chikuInfoModel = commonGhsDao.getChikuInfoForUserOperation(hUserOperationLogModel.getLnKeibi(), hUserOperationLogModel.getLnKbChiku());
				}
				// アカウント区分を取得
				acntUserKbn = commonGhsDao.getAcntTypeFromAcntUser(hUserOperationLogModel.getInsertId());

			// GHS契約者
			} else {
				// 警備先論理番号が設定されている場合は、警備先名/地区名を取得
				if (hUserOperationLogModel.getLnKeibi() != null && hUserOperationLogModel.getLnKeibi().length() > 0) {
					chikuInfoModel = commonGhsDao.getChikuInfoForUserOperation(hUserOperationLogModel.getLnKeibi(), hUserOperationLogModel.getLnKbChiku());
				}
				// アカウント区分を取得
				acntUserKbn = commonGhsDao.getAcntTypeFromAcntKeiyk(hUserOperationLogModel.getInsertId());
			}
			
			// 利用者操作履歴テーブル PKオブジェクト作成
			HUserOperationLogModelPK hUserOperationLogModelPk = new HUserOperationLogModelPK();
			
			// PK採番
		    String lnLogUserOperation = this.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
		    // PKオブジェクト作成
		    hUserOperationLogModelPk.setLnKeiyk(chikuInfoModel.getLnKeiyk());
		    hUserOperationLogModelPk.setLnLogUserOperation(lnLogUserOperation);
		    hUserOperationLogModel.setId(hUserOperationLogModelPk);
		    
		    // モデルオブジェクトの項目を補完
		    hUserOperationLogModel.setUseDay(DateTimeCommon.getShortCurrentDate());
		    hUserOperationLogModel.setKeibiNm(chikuInfoModel.getKeibiNm());
		    hUserOperationLogModel.setSdKobetuNm(chikuInfoModel.getSdKobetuNm());
			hUserOperationLogModel.setUserNm(hUserOperationLogModel.getInsertNm());
		    hUserOperationLogModel.setAcntUserKbn(acntUserKbn);
			hUserOperationLogModel.setInsertTs(DateTimeCommon.getCurrentDate());
			hUserOperationLogModel.setUpdateId(hUserOperationLogModel.getInsertId());
			hUserOperationLogModel.setUpdateNm(hUserOperationLogModel.getInsertNm());
			hUserOperationLogModel.setUpdateTs(DateTimeCommon.getCurrentDate());

			commonDao.entryUserOperation(hUserOperationLogModel);
			
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public String getLnKeibiFromLnKbChiku(String acntSbt, String lnKbChiku) throws ApplicationException{
		try {
			// ログレコード登録に必要な情報を取得
			String lnKeibi;
			if (acntSbt.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				lnKeibi = commonDao.getLnKeibiFromLnKbChiku(lnKbChiku);
			} else {
				lnKeibi = commonGhsDao.getLnKeibiFromLnKbChiku(lnKbChiku);
			}
			return lnKeibi;
			
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public UserOperationChikuInfoModel getChikuInfoFromKbinf(String acntSbt, String lnKbInf) throws ApplicationException{
		try {
			// ログレコード登録に必要な情報を取得
			UserOperationChikuInfoModel chikuInfoModel;
			if (acntSbt.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				chikuInfoModel = commonDao.getChikuInfoFromKbinf(lnKbInf);
			} else {
				chikuInfoModel = commonGhsDao.getChikuInfoFromKbinf(lnKbInf);
			}
			return chikuInfoModel;
			
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public UserOperationChikuInfoModel getChikuInfoFromLnDev(String lnDev) throws ApplicationException{
		try {
			// ログレコード登録に必要な情報を取得
			UserOperationChikuInfoModel chikuInfoModel = commonDao.getChikuInfoFromLnDev(lnDev);
			return chikuInfoModel;
			
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public String getLnKbChikuFromChiku(String acntSbt, String lnKeibi, String chiku) throws ApplicationException{
		try {
			// ログレコード登録に必要な情報を取得
			String lnKbChiku;
			if (acntSbt.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				lnKbChiku = commonDao.getLnKbChikuFromChiku(lnKeibi, chiku);
			} else {
				lnKbChiku = commonGhsDao.getLnKbChikuFromChiku(lnKeibi, chiku);
			}
			return lnKbChiku;
			
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
    /**
     * 指定PROP_KEYのプロパティ設定値を取得する<br>
     *
     * @param section
     * @param propKey
     * @return プロパティ設定値
     * @throws ApplicationException
     */
	public String getPropVal(String section, String propKey) throws ApplicationException {
		try {
			String val = commonDao.getPropVal(section, propKey);
			return val;

		} catch (NoResultException noResultE) {
			return "";

		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getServiceType(String lnKeibi) throws ApplicationException {
		try {
			String serviceType = commonDao.getServiceType(lnKeibi);
			return serviceType;

		} catch (NoResultException noResultE) {
			return "";

		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	/**
	 * get menu pass
	 * @param lnAcntUserCommon
	 * @return
	 * @throws ApplicationException
	 */
	public List<Keiyk> getUserOperationHani(String lnAcntUserCommon) throws ApplicationException {
	    final List<Keiyk> keiykList = new ArrayList<>();
	    try {
	        final List<String> lstMenu  = commonDao.getUserOperationHani(lnAcntUserCommon);
	        if (lstMenu != null) {
	            String[] trio;
	            for (int i = 0; i < lstMenu.size(); i++) {
	                trio = lstMenu.get(i).split("/");
	                Keiyk keiyk = new Keiyk();
	                Keibi keibi = new Keibi();
	                if (trio.length > 0) {
	                    if (!isDuplicate(keiykList, trio[0], "lnKeiyk")) {
	                        keiyk.lnKeiyk = trio[0];
	                        keiyk.keibiList = new ArrayList<>();
	                        keiykList.add(keiyk);
	                    }
	                }
	                if (trio.length > 1) {
	                    if (!isDuplicate(keiykList, trio[0], "lnKeibi")) {
	                        keibi.lnKeibi = trio[1];
	                        keibi.chikuList = new ArrayList<>();
	                        keiyk.keibiList.add(keibi);
	                    }
	                }
	                if (trio.length > 2) {
	                    keibi.chikuList.add(trio[2]);
	                }
	            }
	        }
	        return keiykList;
	    } catch (Exception ex) {
	     // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(ex);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
	    }
	}
	
	/**
	 * get user auth in g6 
	 * @param lnAcntUserCommon
	 * @param lnKeiyk
	 * @param lnKeibi
	 * @param lnKbChiku
	 * @param dispId
	 * @return
	 * @throws ApplicationException
	 */
	 public int getAuth(String lnAcntUserCommon,
	            String lnKeiyk, 
	            String lnKeibi,
	            String lnKbChiku, 
	            String dispId) throws ApplicationException {
	     try {
	            final int auth = Integer.parseInt(commonDao.getAuth(lnAcntUserCommon, lnKeiyk, lnKeibi, lnKbChiku, dispId));
	            return auth;

	        } catch (NoResultException noResultE) {
	            return 0;

	        } catch(Exception e) {
	            // DBアクセス例外
	            String errorMsg = G6Common.printStackTraceToString(e);

	            // 処理終了
	            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
	        }
	 }
	
	private boolean isDuplicate( List<Keiyk> keiykList, String value, String type) {
	    boolean result = false;
	    try {
	        if (type == "lnKeiyk") {
	            for (int i = 0; i < keiykList.size(); i++) {
	                if (keiykList.get(i).getLnKeiyk() == value) {
	                    result = true;
	                    break;
	                }
	            }
	        } else if (type == "lnKeibi") {
	               for (int i = 0; i < keiykList.size(); i++) {
	                   final List<Keibi> keibi = keiykList.get(i).getKeibiList();
	                   for (int j = 0; j < keibi.size(); j++) {
	                        if (keibi.get(j).getLnKeibi() == value) {
	                            result = true;
	                            break;
	                        }
	                   }
	                }
	        }
	    } catch (Exception ex) {
	        
	    }
	    return result;
	}
	
    /**
     * <pre>
     *     
     * 利用者アカウント区分チェック       
     * ・アカウント区分により利用可能な画面かどうかを判断する。
     * </pre>
     * 
     * @param model
     * @param dispId
     * @return 利用不可(0),利用可（2),個別権限(3)
     */
	public YukoAcntUserInf getYukoAcntUserKbnInf(String dispId) throws ApplicationException {
        try {
            final YukoAcntUserInf result = commonDao.getYukoAcntUserKbnInf(dispId);
            return result;

        } catch (NoResultException noResultE) {
            return null;
        } catch(Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
        }
    }
	
	/**
	 * コマンドシーケンス番号を返す
	 * 
	 * @return
	 * @throws ApplicationException
	 */
    @Transactional("transactionManagerG6")
	public String getCmdSeq() throws ApplicationException {
		return this.getSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM, 12);
	}
	
	/**
	 * トランザクション番号を返す
	 * 
	 * @return
	 * @throws ApplicationException
	 */
    @Transactional("transactionManagerG6")
	public String getTranSeq() throws ApplicationException {
		return this.getSeq(G6Constant.CD_SEQUENCE.TRAN_SEQ_NUM, 12);
	}
	
	/**
	 * 指定したIDのシーケンス番号を返す<br>
	 * （lenで指定した桁数で先頭０埋め編集を行う）
	 * 
	 * @param sequenceId
	 * @param len
	 * @return
	 * @throws ApplicationException
	 */
	private String getSeq(String sequenceId, int len) throws ApplicationException {
		
		// DBよりシーケンスを採番
		long sequence = this.getSeqFromDb(sequenceId);
		
		// 0パディング編集
		DecimalFormat df = new DecimalFormat();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < len; i++) {
			sb.append("0");
		}
		df.applyPattern(sb.toString());
		
		// 結果を返す
		return df.format(sequence);
	}

    /**
     * 指定したIDの論理番号を返す
     *
     * @param sequenceId シーケンスID
     * @return 論理番号
     */
    @Transactional("transactionManagerG6")
    public String getLn(String sequenceId) throws ApplicationException {
    	// DBよりシーケンスを採番
        long sequenceNo = this.getSeqFromDb(sequenceId);
        
        // フォーマット用オブジェクトを作成
        DecimalFormat df = new DecimalFormat();
        SimpleDateFormat sdf = new SimpleDateFormat("");
        java.util.Date dt = new java.util.Date();
        sdf.setLenient(false);
        sdf.applyPattern("yyyyMMddHHmmssSSS");
        
        if (sequenceId.equals(G6Constant.CD_SEQUENCE.LN_QUE_KB_SIG_SEQ_NAME)) {
            // 警備信号の場合のみシーケンスは二桁とし、末尾は0として返却
            df.applyPattern("00");
            return sdf.format(dt) + df.format(sequenceNo) + "0";
        }
        if (sequenceId.equals(G6Constant.CD_SEQUENCE.LN_QUE_MST_SEND_SEQ_NAME) || sequenceId.equals(G6Constant.CD_SEQUENCE.LN_SYNC_SALE_SYS)) {
            // マスタ配信キューのみシーケンスは六桁とし、末尾は0として返却
            // 通常はDBトリガにて設定するが、ミリ秒が取得できないためシーケンス番号で対応
            sdf.applyPattern("yyyyMMddHHmmss");
            df.applyPattern("000000");
            return sdf.format(dt) + df.format(sequenceNo);
        }
        if (sequenceId.equals(G6Constant.CD_SEQUENCE.LN_KB_CHIKU_SEQ_NAME)
                || sequenceId.equals(G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_SEQ_NAME)
                || sequenceId.equals(G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_DOKYO_SEQ_NAME)
                || sequenceId.equals(G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_KYUKYU_SEQ_NAME)
                || G6Constant.CD_SEQUENCE.LN_LIVE_IMGVOC_SEQ_NAME.equals(sequenceId)
                || G6Constant.CD_SEQUENCE.LN_ACUM_IMGVOC_SEQ_NAME.equals(sequenceId)
                || G6Constant.CD_SEQUENCE.LN_SGN_IMGVOC_SEQ_NAME.equals(sequenceId)
                || G6Constant.CD_SEQUENCE.LN_RECORD_IMGVOC_SEQ_NAME.equals(sequenceId)
                || G6Constant.CD_SEQUENCE.LN_AI_IMGVOC_SEQ_NAME.equals(sequenceId)) {
            // 論理番号4桁対象の場合
            df.applyPattern("0000");
            return sdf.format(dt).substring(0, 16) + df.format(sequenceNo);
        }
        df.applyPattern("000");
        return sdf.format(dt) + df.format(sequenceNo);
    }
    
	/**
	 * 指定したIDをDBより採番する
	 * @param sequenceId
	 * @return
	 * @throws ApplicationException
	 */
	private long getSeqFromDb(String sequenceId) throws ApplicationException {
    
		// DBよりシーケンスを採番
		try {
			long seq = commonDao.getSeq(sequenceId);
			System.out.println("sequenceId->" + sequenceId);
			System.out.println("seq->" + seq);
			return seq;
		}  catch(Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
        }
	}
	
	public String getKeiykServiceInfo(String lnKeibi, String lnKbServiceTeikyoMst)throws ApplicationException {
		try {
			return commonDao.getKeiykServiceInfo(lnKeibi, lnKbServiceTeikyoMst);
		} catch (NoResultException noResultE) {
			return "0";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public String getChikuCountExcMain(String lnKeibi)throws ApplicationException {
		try {
			return commonDao.getChikuCountExcMain(lnKeibi);
		} catch (NoResultException noResultE) {
			return "0";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	/**
	 * ログイン状態が有効であるかをチェックする。
	 * 
	 * 引数で受け取った「ログイン日時」、「アカウント情報最終更新日時」とDBの値を比較し、
	 * 差異が無ければ有効なログイン状態、差異があれば無効なログイン状態である事を返す。
	 * 
	 * @param mapParam トークン、アカウント種別を保持したMapオブジェクト
	 * @param tokenMapParam トークンを復号し取得した項目を返すためのMapオブジェクト
	 * @param jwtverifier JWT認証を行うための共通オブジェクト
	 * @return ログイン状態チェック結果
	 * @throws JWTVerificationException
	 * @throws Exception
	 */
	public String checkValidLoginSts(Map<String, Object> mapParam, Map<String, String> tokenMapParam, G6JWTVerifier jwtverifier) throws JWTVerificationException, Exception {
		
		// トークンを取得
		String token = ConvUtil.convToString(mapParam.get(RequestParam.acntID.getValue()));
		
		// トークンより各項目値を取得
        String acntId = jwtverifier.verifyAndGetAcuntID(token);						// アカウントID
        String loginTs = jwtverifier.verifyAndGetLoginTs(token);					// ログイン日時
        String lastModifyAcntTs = jwtverifier.verifyAndGetLastModifyAcntTs(token);	// アカウント情報最終更新日時（ログイン時）
        String lnAcntUserCommon = jwtverifier.verifyAndGetLnAcntUserCommon(token);
        String lnAcntUser = jwtverifier.verifyAndGetLnAcntUser(token);
        String lnAcntKeiyk = jwtverifier.verifyAndGetLnAcntKeiyk(token);
        String acntSbtOfSelectedKeibi = jwtverifier.verifyAndGetAcntSbt(token); // 選択した警備先のアカウント種別
        
        // 呼び出し元にトークン内の項目値を戻すため、Mapオブジェクトに格納
        tokenMapParam.put(RequestParam.acntID.getValue(), acntId);
        tokenMapParam.put(RequestParam.loginTs.getValue(), loginTs);
        tokenMapParam.put(RequestParam.lastModifyAcntTs.getValue(), lastModifyAcntTs);
        tokenMapParam.put(RequestParam.acntSbt.getValue(), acntSbtOfSelectedKeibi);
        tokenMapParam.put(RequestParam.ln_acnt_user_common.getValue(), lnAcntUserCommon);
        tokenMapParam.put(RequestParam.ln_acnt_user.getValue(), lnAcntUser);
        tokenMapParam.put(RequestParam.ln_acnt_keiyk.getValue(), lnAcntKeiyk);
                
        // アカウント種別を取得
        String acntSbt = ConvUtil.convToString(mapParam.get(RequestParam.acntSbt.getValue()));
                
        // DBからの取得項目
        String lastLoginTsDB = "";		// 最終ログイン日時
        String lastModifyAcntTsDB = "";	// アカウント情報最終更新日時
        
        if (!StringUtils.isBlank(acntId)) {
        	
        	// DBより最終ログイン日時、アカウント情報最終更新日時を取得
			if (acntSbt.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM) || StringUtils.isBlank(acntSbt)) {
				//G6 (GV機能ではアカウント種別ブランクが渡されるため次期警備と判断）
				lastLoginTsDB = DateTimeCommon.dateToString(commonDao.getLastLoginTs(lnAcntUserCommon));
				lastModifyAcntTsDB = DateTimeCommon.dateToString(commonComDao.getLastModifyAcntTs(lnAcntUserCommon));

			} else if (acntSbt.equals(G6CodeConsts.CD027.GHS_THE_USER)) {
				//GHSユーザ
				lastLoginTsDB = DateTimeCommon.dateToString(commonGhsDao.getLiyLastLoginTs(lnAcntUser));
				lastModifyAcntTsDB = DateTimeCommon.dateToString(commonGhsDao.getLiyLastModifyAcntTs(lnAcntUser));
				
			} else if(acntSbt.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				//GHS契約
				lastLoginTsDB = DateTimeCommon.dateToString(commonGhsDao.getKiyLastLoginTs(lnAcntKeiyk));
				lastModifyAcntTsDB = DateTimeCommon.dateToString(commonGhsDao.getKiyLastModifyAcntTs(lnAcntKeiyk));
			}

			// 引数で受け取った日付と、DBから取得した日付を比較し状態をチェック
			if (!lastModifyAcntTs.equals(lastModifyAcntTsDB)) {
				// ユーザ情報が変更された場合
				return G6Constant.LOGIN_STS_USER_INF_MODIFIED;
				
			} if (!loginTs.equals(lastLoginTsDB)) {
				// 同一ユーザでログインされた場合
				return G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED;
				
			} else {
				// 有効なログイン状態の場合
		        // 選択している警備先のアカウント種別でリクエストからのパラメータ値を上書き
				if (!StringUtils.isBlank(acntSbtOfSelectedKeibi) && !StringUtils.isBlank(acntSbt)) {
					mapParam.put(RequestParam.acntSbt.getValue(), acntSbtOfSelectedKeibi);
				}
				return G6Constant.LOGIN_STS_VALID;
			}
			
        } else {
        	return G6Constant.LOGIN_STS_VALID;
        }
	}
	
	/**
	 * アカウント情報の最終更新日時を取得する。
	 * 引数「lnAcnt」をキーに下記を返す。
	 * 　次期警備　：　K_ACNT_USER_COMMON.UPDATE_TS
	 * 　GHSユーザ　：　R_ACNT_USER.UPDATE_TS
	 * 　GHS契約　：　R_ACNT_KEIYK.UPDATE_TS
	 * @param lnAcnt
	 * @param acntSbt
	 * @return アカウント情報の最終更新日時
	 * @throws ApplicationException
	 */
	public String getLastModifyAcntTs(String lnAcnt, String acntSbt) throws ApplicationException {
        try {
        	String lastModifyAcntTs = "";
			if (acntSbt.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				//G6
				lastModifyAcntTs = DateTimeCommon.dateToString(commonComDao.getLastModifyAcntTs(lnAcnt));

			} else if (acntSbt.equals(G6CodeConsts.CD027.GHS_THE_USER)) {
				//GHSユーザ
				lastModifyAcntTs = DateTimeCommon.dateToString(commonGhsDao.getLiyLastModifyAcntTs(lnAcnt));
				
			} else if(acntSbt.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				//GHS契約
				lastModifyAcntTs = DateTimeCommon.dateToString(commonGhsDao.getKiyLastModifyAcntTs(lnAcnt));
			}
			return lastModifyAcntTs;
			
        } catch (NoResultException noResultE) {
            return null;
        } catch(Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
        }
    }
	
	/**
	 * 選択されている警備先が次期警備／GHSであるかを判断し、アカウント情報（acntID、acntSbt）を切り替える。
	 * @param mapParam
	 * @param tokenMapParam
	 * @throws ApplicationException
	 */
	public void convertAcntInfo(Map<String, Object> mapParam, Map<String, String> tokenMapParam) throws ApplicationException {
		
		// ログイン時に取得したアカウントIDを取得
		// 次期警備アカウント
		String lnAcntUserCommon = (String)tokenMapParam.get(RequestParam.ln_acnt_user_common.getValue());
		// GHS利用者アカウント
		String lnAcntUser = (String)tokenMapParam.get(RequestParam.ln_acnt_user.getValue());
		// GHS契約者アカウント
		String lnAcntKeiyk = (String)tokenMapParam.get(RequestParam.ln_acnt_keiyk.getValue());
		
		// 選択している警備先論理番号を取得
		String lnKeibi = (String)mapParam.get(RequestParam.lnKeibi.getValue());
		
		// 次期警備の警備先であるかをチェック
		int cntLnKeibi = commonDao.countLnKeibi(lnAcntUserCommon, lnKeibi);
		
		// アカウント情報を切り替える
		if (cntLnKeibi > 0) {
			// 次期警備の警備先の場合
			tokenMapParam.put(RequestParam.acntID.getValue(), lnAcntUserCommon);
			tokenMapParam.put(RequestParam.acntSbt.getValue(), G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);
			mapParam.put(RequestParam.acntSbt.getValue(), G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);
			
		} else if (!StringUtils.isBlank(lnAcntUser)){
			// GHS利用者の警備先の場合
			tokenMapParam.put(RequestParam.acntID.getValue(), lnAcntUser);
			tokenMapParam.put(RequestParam.acntSbt.getValue(), G6CodeConsts.CD027.GHS_THE_USER);
			mapParam.put(RequestParam.acntSbt.getValue(), G6CodeConsts.CD027.GHS_THE_USER);
			
		} else if (!StringUtils.isBlank(lnAcntKeiyk)){
			// GHS契約者の警備先の場合
			tokenMapParam.put(RequestParam.acntID.getValue(), lnAcntKeiyk);
			tokenMapParam.put(RequestParam.acntSbt.getValue(), G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION);
			mapParam.put(RequestParam.acntSbt.getValue(), G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION);
		}
	}
}
