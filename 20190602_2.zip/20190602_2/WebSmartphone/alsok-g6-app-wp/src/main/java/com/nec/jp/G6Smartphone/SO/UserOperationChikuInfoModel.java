package com.nec.jp.G6Smartphone.SO;

public class UserOperationChikuInfoModel {

	private String lnKeiyk;
	private String lnKeibi;
	private String keibiNm;
	private String lnKbChiku;
	private String sdKobetuNm;

	public UserOperationChikuInfoModel() {
		this.lnKeiyk = "";
		this.lnKeibi = "";
		this.keibiNm = "";
		this.lnKbChiku = "";
		this.sdKobetuNm = "";
	}

	public UserOperationChikuInfoModel(String lnKeiyk, String keibiNm, String sdKobetuNm) {
		super();
		this.lnKeiyk = lnKeiyk;
		this.keibiNm = keibiNm;
		this.sdKobetuNm = sdKobetuNm;
	}

	public UserOperationChikuInfoModel(String lnKeibi, String lnKbChiku) {
		super();
		this.lnKeibi = lnKeibi;
		this.lnKbChiku = lnKbChiku;
	}
	
	public String getLnKeiyk() {
		return lnKeiyk;
	}

	public void setLnKeiyk(String lnKeiyk) {
		this.lnKeiyk = lnKeiyk;
	}

	public String getLnKeibi() {
		return lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getKeibiNm() {
		return keibiNm;
	}

	public void setKeibiNm(String keibiNm) {
		this.keibiNm = keibiNm;
	}

	public String getLnKbChiku() {
		return lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getSdKobetuNm() {
		return sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}
}
