package com.nec.jp.G6Smartphone.SO;

public class RKbInfoModel implements DataModelHandler {

	private String lnKeibi;		
	private String gouKi;		
	private String serialNum;	
	private String sdKeiykType;	

	public RKbInfoModel() {
		this.lnKeibi = "";
		this.gouKi = "";
		this.serialNum = "";
		this.sdKeiykType = "";
	}

	public RKbInfoModel(String lnKeibi, String gouKi, String serialNum,  String sdKeiykType) {
		this.lnKeibi = lnKeibi;
		this.gouKi = gouKi;
		this.serialNum = serialNum;
		this.sdKeiykType = sdKeiykType;
	}

	public String getLnKeibi() {
		return lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getGouKi() {
		return gouKi;
	}

	public void setGouKi(String gouKi) {
		this.gouKi = gouKi;
	}

	public String getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getSdKeiykType() {
		return sdKeiykType;
	}

	public void setSdKeiykType(String sdKeiykType) {
		this.sdKeiykType = sdKeiykType;
	}
}
