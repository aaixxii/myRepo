package com.nec.jp.G6Smartphone.SO;

public class SdKobetuNmDataModel {

	private String lnKbChiku;
	private String sdKobetuNm;
	public SdKobetuNmDataModel() {
		this.lnKbChiku = "";
		this.sdKobetuNm = "";
	}
	public SdKobetuNmDataModel(String lnKbChiku, String sdKobetuNm) {
		this.lnKbChiku = lnKbChiku;
		this.sdKobetuNm = sdKobetuNm;
	}
	public String getLnKbChiku() {
		return lnKbChiku;
	}
	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}
	public String getSdKobetuNm() {
		return sdKobetuNm;
	}
	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}
}
