package com.nec.jp.G6Smartphone.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

public class G6Constant {
	
	// FLG codes
	public static final String FLG_DISABLE       = "0";
	public static final String FLG_ENABLE        = "1";

	// Message codes
	public static final String SUCCESS_CD        = "0";
	public static final String FAIL_POPUP_CD     = "1";
	public static final String FAIL_HTML_CD      = "2";
	public static final String FAIL_DUPLICATE_CD = "3";
	public static final String TOKEN_ERROR       = "4";
	public static final String VALID_LOGIN       = "5";
	
	// PROP_KEY For JWT Property
	public static final String SECITON              = "SZWP";
	public static final String P_KEY_SECRET         = "JWT_SECRET";
	public static final String P_KEY_ISSUER         = "JWT_ISSUER";
	public static final String P_KEY_EXPIRE_MINUTES = "JWT_EXPIRE_MINUTES";

	// Symbols
	public static final String COMMA = ",";
	public static final String HYPHEN = "-";
	public static final String COLON = ":";
	public static final String NEW_LINE_CHAR = "\n";
	public static final String OPEN_SQR_BRACKET = "[";
	public static final String CLOSE_SQR_BRACKET = "]";
	public static final String OPEN_XML_TAG = "<";
	public static final String CLOSE_XML_TAG = ">";
	  /**
     * 左括弧(半角)
     */
    public static final String LEFT_BRACKET_HALF = "(";
    /**
     * 右括弧(半角)
     */
    public static final String RIGHT_BRACKET_HALF = ")";
    /**
     * 記号単引用符
     */
    public static final String SINGLE_QUOTE_MARK = "'";
	public static final Integer NO_1 = 1;
	public static final Integer NO_2 = 2;
	public static final Integer NO_3 = 3;
	public static final Integer NO_4 = 4;
	public static final String SUBADDR_1 = "1";
	public static final String SUBADDR_2 = "2";
	public static final String SUBADDR_3 = "3";
	public static final String SUBADDR_4 = "4";
	public static final String SUBADDR_5 = "5";
	public static final String SUBADDR_6 = "6";
	public static final String SUBADDR_7 = "7";
	public static final String EMPTY = "";
	public static final String FOURSPACE = "    ";

	public static final String SERVICE_CONTEXT = "G6Smartphone.service";
	public static final String UTILITY_CONTEXT = "G6Smartphone.utility";

	public static final String LOGIN_ERROR_COUNT = "0";
	public static final String LOGIN_STATUS_FLG = "1";

	/** 基本 */
	public static final String BASE = "";
	/** 斜線 */
	public static final String SLASH = BASE + "/";
	/** 次期用:論理番号の桁数(20桁) */
	public static final int NUM_LENGTH = 20;
	/** 種別 */
	public static final String KIND = "99";

	public static final String INIT_CMD_SEQ_NUM = "000000000001";
	public static final String INIT_CMD_SEQ_NUM_20 = "00000000000000000001";
	public static final String INIT_SEQ_CNT_DEF = "1";
	public static final String INIT_MAX_SEQ_NUM = "999999999999";
	public static final String INIT_MAX_SEQ_NUM_20 = "99999999999999999999";
	
	
	/** 警備状態設定要求（レスポンス）タグ */
	public static final String CMD_RESULT = "<cmd_rslt>";
	/** センサー状態（レスポンス）タグ */
	public static final String LGTM_ST = "<lgtm_st>";

	public static final String SMARTPHONE_SERVER_HOST = "smartphone_server_host";
    public static final String SMARTPHONE_SERVER_PORT = "smartphone_server_port";
    public static final String PATH_TEMPLATE = "path_template";
    public static final String FILE_EXTENSION = "file_extension";
    public static final String BLOCK_SIZE_STORED_DATA = "block_size_stored_data";
    /**
     * アカウント情報:「次期警備」
     */
    public static final String ACOUNT_NEXT_TERM_GUARD = "1";
    /**
     * アカウント情報:「次期警備」＋「GS」
     */
    public static final String ACOUNT_NEXT_TERM_GUARD_GS = "3";
    /**
     * アカウント情報:「次期警備」＋「HS」
     */
    public static final String ACOUNT_NEXT_TERM_GUARD_HS = "5";
    /**
     * アカウント情報:「GS」
     */
    public static final String ACOUNT_GS = "2";
    /**
     * アカウント情報:「HS」
     */
    public static final String ACOUNT_HS = "4";
    /**
     * GHS契約者/利用者ユーザ区分 ： 1（契約者）
     */
    public static final String USER_KBN_1 = "1";

    /** 検索DBフラグ(全て). */
    public static final int SELECTDB_ALL = 0;

    /** 検索DBフラグ(G6のみ). */
    public static final int SELECTDB_G6 = 1;

    /** 検索DBフラグ(GHSのみ). */
    public static final int SELECTDB_GHS = 2;
    
    /** ログインユーザ検索DBフラグ(次期). */
    public static final int SYSTEM_G6 = 1;

    /** ログインユーザ検索DBフラグ(GHS). */
    public static final int SYSTEM_GHS = 2;
    
    /** メニューパス情報:'01' */
    public static final String MENU_PASSINF_01 = "01";

    /** メニューパス情報:'02' */
    public static final String MENU_PASSINF_02 = "02";

    /** メニューパス情報:'03' */
    public static final String MENU_PASSINF_03 = "03";

    /** メニューパス情報:'04' */
    public static final String MENU_PASSINF_04 = "04";

    /** メニューパス情報:'05' */
    public static final String MENU_PASSINF_05 = "05";

    /** メニューパス情報:'06' */
    public static final String MENU_PASSINF_06 = "06";

    /** メニューパス情報:'07' */
    public static final String MENU_PASSINF_07 = "07";
    /**
     * 定数0
     */
    public static final String STR_0 = "0";
    /**
     * 定数7
     */
    public static final String STR_7 = "7";
    /**
     * 定数8
     */
    public static final String STR_8 = "8";
    /**
     * 定数10
     */
    public static final String STR_10 = "10";
    /**
     * 定数11
     */
    public static final String STR_11 = "11";
    /**
     * 定数12
     */
    public static final String STR_12 = "12";
    /**
     * 定数13
     */
    public static final String STR_13 = "13";
    /**
     * 定数14
     */
    public static final String STR_14 = "14";
    /**
     * 定数15
     */
    public static final String STR_15 = "15";
    /**
     * 定数16
     */
    public static final String STR_16 = "16";
    /**
     * 定数17
     */
    public static final String STR_17 = "17";
    /**
     * 定数18
     */
    public static final String STR_18 = "18";
    /**
     * 定数19
     */
    public static final String STR_19 = "19";
    /**
     * 定数20
     */
    public static final String STR_20 = "20";
    /**
     * 定数21
     */
    public static final String STR_21 = "21";
    /**
     * アカウント権限(0:非表示)
     */
    public static final int ACNT_AUTH_0 = 0;
    /**
     * アカウント権限(1:閲覧のみ)
     */
    public static final int ACNT_AUTH_1 = 1;
    /**
     * アカウント権限(2:閲覧・設定)
     */
    public static final int ACNT_AUTH_2 = 2;
    
    /** メニューパス情報:'0201' */
    public static final String MENU_PASSINF_0201 = "0201";

    /** メニューパス情報:'0202' */
    public static final String MENU_PASSINF_0202 = "0202";

    /** メニューパス情報:'0203' */
    public static final String MENU_PASSINF_0203 = "0203";

    /** メニューパス情報:'0204' */
    public static final String MENU_PASSINF_0204 = "0204";

    /** メニューパス情報:'0401' */
    public static final String MENU_PASSINF_0401 = "0401";

    /** メニューパス情報:'0402' */
    public static final String MENU_PASSINF_0402 = "0402";

    /** メニューパス情報:'0403' */
    public static final String MENU_PASSINF_0403 = "0403";

    /** メニューパス情報:'0702' */
    public static final String MENU_PASSINF_0702 = "0702";

    /** メニューパス情報:'0703' */
    public static final String MENU_PASSINF_0703 = "0703";

    /** メニューパス情報:'0704' */
    public static final String MENU_PASSINF_0704 = "0704";

    /** メニューパス情報:'0705' */
    public static final String MENU_PASSINF_0705 = "0705";

    /** メニューパス情報:'0706' */
    public static final String MENU_PASSINF_0706 = "0706";

    /** メニューパス情報:'0707' */
    public static final String MENU_PASSINF_0707 = "0707";

    /** メニューパス情報:'0708' */
    public static final String MENU_PASSINF_0708 = "0708";

    /** メニューパス情報:'0709' */
    public static final String MENU_PASSINF_0709 = "0709";

    /** メニューパス情報:'0710' */
    public static final String MENU_PASSINF_0710 = "0710";
    
    /**
     * GHS契約者/利用者ユーザ区分 ： 2（利用者）
     */
    public static final String USER_KBN_2 = "2";
    
    /**
     * 信号種別１: 01(警備開始／在室警備／警備解除)
     */
    public static final String SIG_KIND_1_01 = "01";
    /**
     * 信号種別１: 04(警備ｾｯﾄ忘れ)
     */
    public static final String SIG_KIND_1_04 = "04";
    /**
     * 信号種別２: 24(警備ｾｯﾄ忘れ)警備解除
     */
    public static final String SIG_KIND_2_24 = "24";
    /**
     * 信号種別１: 50(空室通知)
     */
    public static final String SIG_KIND_1_50 = "50";
    /**
     * 信号種別１: 11(防犯／非常／設備／火災／ガス）
     */
    public static final String SIG_KIND_1_11 = "11";
    /**
     * 信号種別１: 21(画像蓄積情報）
     */
    public static final String SIG_KIND_1_21 = "21";
    /**
     * 信号種別2: 03(警備開始、ホールドアップ警報、設備）
     */
    public static final String SIG_KIND_2_03 = "03";
    /**
     * 信号種別2: 11(強制警備）
     */
    public static final String SIG_KIND_2_11 = "11";
    /**
     * 信号種別2: 23(警備開始）
     */
    public static final String SIG_KIND_2_23 = "23";
    /**
     * 信号種別2: 09(在室警備）
     */
    public static final String SIG_KIND_2_09 = "09";
    /**
     * 信号種別2: 29(在室警備）
     */
    public static final String SIG_KIND_2_29 = "29";
    /**
     * 信号種別2: 30(在室警備）
     */
    public static final String SIG_KIND_2_30 = "30";
    /**
     * 信号種別2: 02(警備ｾｯﾄ忘れ、非常）
     */
    public static final String SIG_KIND_2_02 = "02";
    /**
     * 信号種別2: 00(空室／空室解除）
     */
    public static final String SIG_KIND_2_00 = "00";
    /**
     * 信号種別2: 01(防犯施錠）
     */
    public static final String SIG_KIND_2_01 = "01";
    /**
     * 信号種別2: 08(火災）
     */
    public static final String SIG_KIND_2_08 = "08";
    /**
     * 信号種別2: 10(ガス）
     */
    public static final String SIG_KIND_2_10 = "10";

    /** 04(在室警備） */
    public static final String SIG_KIND_2_04 = "04";

    /** 07(警備警報復旧） */
    public static final String SIG_KIND_1_07 = "07";

    /** 22(画像蓄積情報） */
    public static final String SIG_KIND_1_22 = "22";

    /** IP(画像巡回） */
    public static final String SIG_KIND_1_IP = "IP";

    /** C1(遠隔撮像要求） */
    public static final String SIG_KIND_2_C1 = "C1";

    /** C2(周辺機器撮像要求） */
    public static final String SIG_KIND_2_C2 = "C2";

    /** GS 1：利用者 */
    public static final String THE_USER = "1";

    /** GS 2：サブ管理 */
    public static final String SUB_ADMINISTRATOR = "2";
    
    /**
      *    信号種別2: 70(SD保存） 
     */
    public static final String SIG_KIND_2_70 = "70";
    /**
     *   信号種別2: 71(SDニアフル）
     */
    public static final String SIG_KIND_2_71 = "71";
    /**
     *  信号種別2: 72(SDフル）
     */
    public static final String SIG_KIND_2_72 = "72";
    /**
     * ログメッセージID：　処理開始
     */
    public static final String LOG_MESSAGE_LZWP2000 = "LZWP2000";
    /**
     * ログメッセージID：　処理終了
     */
    public static final String LOG_MESSAGE_LZWP2001 = "LZWP2001";
    /**
     * ログメッセージID：　システムエラー発生
     */
    public static final String LOG_MESSAGE_LZWP2002 = "LZWP2002";
    /**
     * ログメッセージID：　警告エラー発生
     */
    public static final String LOG_MESSAGE_LZWP2003 = "LZWP2003";    

    /**
     * ログインステータス　チェック結果:　有効
     */
    public static final String LOGIN_STS_VALID = "0";
    
    /**
     * ログインステータス　チェック結果:　同一ユーザによるログイン
     */
    public static final String LOGIN_STS_ANOTHER_SESSION_LOGINED = "1";
    
    /**
     * ログインステータス　チェック結果:　ユーザ情報変更
     */
    public static final String LOGIN_STS_USER_INF_MODIFIED = "2";
    
    
    public static final Map<String, Map<String, List<String>>> signalTypeMap = new HashMap<String, Map<String, List<String>>>() {
		private static final long serialVersionUID = 1L;
		{
			put(SignalKey.operation.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("01");
							add("04");
							add("50");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("03,11,23,09,29,04,24,10,30");
							add("02,03");
							add("00,01");
						}
					});
				}
			});
			put(SignalKey.start.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("01");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("03,11,23");
						}
					});
				}
			});
			put(SignalKey.presence.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("01");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("09,29");
						}
					});
				}
			});
			put(SignalKey.release.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("01");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("04,24");
						}
					});
				}
			});
			put(SignalKey.presenceRelease.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("01");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("10,30");
						}
					});
				}
			});
			put(SignalKey.vacancy.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("04");
							add("50");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("02,03");
							add("00,01");
						}
					});
				}
			});
			put(SignalKey.alarm.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("07");
							add("11");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("01");
							add("01,02,03,08,10");
						}
					});
				}
			});
			put(SignalKey.prevent.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("11");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("01");
						}
					});
				}
			});
			put(SignalKey.emergency.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("11");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("02");
						}
					});
				}
			});
			//TODO: 
//			put(SignalKey.rescue.getValue(), new HashMap<String, List<String>>() {
//				private static final long serialVersionUID = 1L;
//				{
//					put(SignalType.type1.getValue(), new ArrayList<String>() {
//						private static final long serialVersionUID = 1L;
//						{
//						}
//					});
//					put(SignalType.type2.getValue(), new ArrayList<String>() {
//						private static final long serialVersionUID = 1L;
//						{
//						}
//					});
//				}
//			});
			put(SignalKey.facility.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("11");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("03");
						}
					});
				}
			});
			put(SignalKey.fire.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("11");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("08");
						}
					});
				}
			});
			put(SignalKey.gas.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("11");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("10");
						}
					});
				}
			});
			put(SignalKey.acum.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("21");
							add("22");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("70,71,72");
							add("70");
						}
					});
				}
			});
			put(SignalKey.patrol.getValue(), new HashMap<String, List<String>>() {
				private static final long serialVersionUID = 1L;
				{
					put(SignalType.type1.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("IP");
						}
					});
					put(SignalType.type2.getValue(), new ArrayList<String>() {
						private static final long serialVersionUID = 1L;
						{
							add("C1,C2");
						}
					});
				}
			});
		}
	};

	public static final List<String> signalCheckList = new ArrayList<String>() {
		private static final long serialVersionUID = 1L;
		{
			add(SignalKey.operation.getValue());
			add(SignalKey.start.getValue());
			add(SignalKey.presence.getValue());
			add(SignalKey.release.getValue());
			add(SignalKey.vacancy.getValue());
			add(SignalKey.alarm.getValue());
			add(SignalKey.prevent.getValue());
			add(SignalKey.emergency.getValue());
			//add(SignalKey.rescue.getValue());
			add(SignalKey.facility.getValue());
			add(SignalKey.fire.getValue());
			add(SignalKey.gas.getValue());
			add(SignalKey.acum.getValue());
			add(SignalKey.patrol.getValue());
		}
	};

	public static enum SignalKey {
		operation("operation"),
		start("start"),
		presence("presence"),
		release("release"),
		vacancy("vacancy"),
		alarm("alarm"),
		prevent("prevent"),
		presenceRelease("presenceRelease"),
		emergency("emergency"),
		//rescue("rescue"),
		facility("facility"),
		fire("fire"),
		gas("gas"),
		acum("acum"),
		patrol("patrol");

		private final String signalKey;

		private SignalKey(String signalKey) {
			this.signalKey = signalKey;
		}

		public String getValue() {
			return this.signalKey;
		}
	}

	// Request parameters
	public static enum RequestParam {
		loginId("loginId"),
		passwd("passwd"),
		language("language"),
		acntID("acntID"),
		loginTs("loginTs"),
		lastModifyAcntTs("lastModifyAcntTs"),
		acntSbt("acntSbt"),
		acntNm("acntNm"),
		lnKeibi("lnKeibi"),
		lnKbChiku("lnKbChiku"),
		lnKbArea("lnKbArea"),
		screenID("screenID"),
		denkei("denkei"),
		subAddr("subAddr"),
		kbAreaNum("kbAreaNum"),
		rCtlDevItem("rCtlDevItem"),
		gshsFlg("gshsFlg"),
		lnHAlsokNotice("lnHAlsokNotice"),
		rDevItem("rDevItem"),
		lnDev("lnDev"),
		sdDevNum("sdDevNum"),
		cntrSt("cntrSt"),
		dtTo("dtTo"),
		dtFrom("dtFrom"),
		dtStart("dtStart"),
		cdTime("cdTime"),
		chiku("chiku"),
		nickName("nickName"),
		lnEventInfoHst("lnEventInfoHst"),
		lnRAuthPicInf("lnRAuthPicInf"),
		dateFrom("dateFrom"),
		dateTo("dateTo"),
		lnKbInf("lnKbInf"),
		lnJian("lnJian"),
		keiykNm("keiykNm"),
		keibiName("keibiName"),
		devNm("devNm"),
		process("process"),
		screenSize("screenSize"),
		frameRate("frameRate"),
		preset("preset"),
		shoriKubun("shoriKubun"),
		pathInf("pathInf"),
		ln_acnt_user_common("ln_acnt_user_common"),
		ln_acnt_user("ln_acnt_user"),
		ln_acnt_keiyk("ln_acnt_keiyk"),
		screen_id("screen_id"),
		ope_form_id("ope_form_id"),
		ln_dev("ln_dev"),
		baseInfos("baseInfos"),
		base_infos("base_infos"),
		viewing_interval("viewing_interval"),
		viewingInterval("viewingInterval"),
		url("url"),
		mem_data_list("mem_data_list"),
		liveIP("liveIP"),
		downloadPort("downloadPort"),
		download_bgn_period("download_bgn_period"),
		download_end_period("download_end_period"),
		ln_dev_list("ln_dev_list"),
		accum_list_tm("accum_list_tm"),
		accum_list_intereval("accum_list_intereval"),
		result("result"),
		dialogSt("dialogSt"),
		ope_form_add_info("ope_form_add_info"),
		ln_kb_chiku("ln_kb_chiku"),
		al_camera_lst("al_camera_lst"),
		ply_camera_lst("ply_camera_lst"),
		dsp_camera_num("dsp_camera_num"),
		dsp_camera_lst("dsp_camera_lst"),
		img_quality("img_quality"),
		frame_rate("frame_rate"),
		ln_dev_lst("ln_dev_lst"),
		ln_acnt_user_common_for_ope("ln_acnt_user_common_for_ope"),
		acnt_type_for_ope("acnt_type_for_ope"),
		selected_for_dialog("selected_for_dialog"),
		pan("pan"),
		tilt("tilt"),
		zoom("zoom"),
		preset_num("preset_num"),
		control_kbn("control_kbn"),
		downloadBgnPeriod("downloadBgnPeriod"),
		downloadEndPeriod("downloadEndPeriod"),
		live_ip("live_ip"),
		download_port("download_port"),
		command("command"),
		host("host"),
		port("port"),
		request("request"),
		imgQuality("imgQuality"),
		presetNum("presetNum"),
		controlKbn("controlKbn"),
		opeFormAddInfo("opeFormAddInfo"),
		status("status"),
		index("index"),
		dispId("dispId"),
		imageId("imageId"),
		pageNo("pageNo"),
		ghsAcntNo("ghsAcntNo"),
		lnKeiyk("lnKeiyk"),
		mlAddr("mlAddr");
		private final String param;

		private RequestParam(String param) {
			this.param = param;
		}

		public String getValue() {
			return this.param;
		}
	}
	public static enum ResponseParam {
		ptz_enable_flg("ptz_enable_flg"),
		preset_status("preset_status"),
		frame_rate("frame_rate"),
		img_quality("img_quality"),
		param_set_flg("param_set_flg"),
		has_ope_auth("has_ope_auth"),
		result("result"),
		result_list("result_list"),
		acnt_type_for_ope("acnt_type_for_ope"),
		ln_acnt_user_common_for_ope("ln_acnt_user_common_for_ope"),
		url("url"),
		img_ip("img_ip"),
		acnt_name("acnt_name"),
		trans_flg("trans_flg"),
		errorCode("errorCode"),
		errorMsg("errorMsg"),
		status("status"),
		index("index"),
		data("data"),
		alive_monitor("alive_monitor");
		private final String param;

		private ResponseParam(String param) {
			this.param = param;
		}

		public String getValue() {
			return this.param;
		}
	}
	
	// DispID
	public static enum DispID {
		P0400("P0400"),
		P0700("P0700"),
		P1000("P1000");
		private final String dispID;
		private DispID(String dispID) {
			this.dispID = dispID;
		}

		public String getValue() {
			return this.dispID;
		}
	}
	
	// Screen ID
	public static enum ScreenID {
		SZWP0000("SZWP0000"),
		SZWP0400("SZWP0400"),
		SZWP0700("SZWP0700"),
		SZWP1000("SZWP1000"),
		SZWP1100("SZWP1100"),
		SZWP1300("SZWP1300"),
		SZWP1400("SZWP1400"),
		SZWP1500("SZWP1500"),
		SZWP1600("SZWP1600"),
		SZWP1700("SZWP1700"),
		SZWP1800("SZWP1800"),
		SZWP1900("SZWP1900"),
		SZWP2000("SZWP2000"),
		SZWP2200("SZWP2200"),
		SZWP2300("SZWP2300"),
		SZWP2600("SZWP2600"),
		SZWP2700("SZWP2700"), 
		SZWP2800("SZWP2800"), 
		SZWP3000("SZWP3000"), 
		SZWP3400("SZWP3400"), 
		SZWP3700("SZWP3700"), 
		SZWP3100("SZWP3100"), 
		SZWP3500("SZWP3500"), 
		SZWP3800("SZWP3800"),
		SZWU3200("SZWU3200");

		private final String screenID;

		private ScreenID(String screenID) {
			this.screenID = screenID;
		}

		public String getValue() {
			return this.screenID;
		}

		public String getSlashValue() {
			return SLASH + this.screenID;
		}
		
		public String getValueForOperationLog() {
			return this.screenID.substring(3);
		}
	}

	public static enum OpeFromID {
		SZWP2300_000("SZWP2900_000"),
		SZWP2300_001("SZWP2900_001"),
		SZWP2300_002("SZWP2900_002"),
		SZWP2300_003("SZWP2900_003"),
		SZWP2300_004("SZWP2900_004"),
		SZWP2300_005("SZWP2900_005"),
		SZWP2300_006("SZWP2900_006"),
		SZWP2300_007("SZWP2900_007"),
		SZWP2300_008("SZWP2900_008"),
		SZWP2300_009("SZWP2900_009"),
		SZWP2300_010("SZWP2900_010"),
		SZWP2300_011("SZWP2900_011"),
		SZWU3200_001("SZWU3200_001"),
		SZWU3200_002("SZWU3200_002");
		private final String opeFromID;
		private OpeFromID(String opeFromID) {
			this.opeFromID = opeFromID;
		}

		public String getValue() {
			return this.opeFromID;
		}
	}
	// Error key properties
	public static final Map<String, Map<String, String>> LocalMessage = new HashMap<String, Map<String, String>>(){
		private static final long serialVersionUID = 1L;
		{
			put(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue(), new HashMap<String, String>(){
				private static final long serialVersionUID = 1L;
				{
					put(G6CodeConsts.CD238.JAPANESE, "メッセージプロパティファイルを読み取ることができません。");
					put(G6CodeConsts.CD238.ENGLISH, "Can not read the message properties file.");
					put(G6CodeConsts.CD238.CHINESE, "我无法读取消息属性文件。");
				}
			});
			put(ErrorKey.CANNOT_PROCESSING_JSON.getValue(), new HashMap<String, String>(){
				private static final long serialVersionUID = 1L;
				{
					put(G6CodeConsts.CD238.JAPANESE, "JSON処理例外があります。 管理者に連絡してください。");
					put(G6CodeConsts.CD238.ENGLISH, "There is a JSON processing exception. Please contact the administrator.");
					put(G6CodeConsts.CD238.CHINESE, "有一个JSON处理异常。 请联系管理员。");
				}
			});
		}
	};
	public static enum ErrorKey {
		EXCEPTION_ROOT("exception.root"),
		EXCEPTION_DB_ACCESS("exception.db.access"),
		EXCEPTION_PARSE_DATETIME("exception.parse.datetime"),
		EXCEPTION_PARSE_JSON("exception.parse.json"),
		EXCEPTION_PROCESSING_JSON("exception.processing.json"),
		EXCEPTION_MEDIA_COMMUNICATION("exception.media.communication"),
		EXCEPTION_PROCESSING_SOCKET("exception.processing.socket"),
		EXCEPTION_LIMIT_ROW("exception.limit.row"),
		EXCEPTION_VERIFY_JSON("exception.verify.jsontoken"),
		EXCEPTION_CREATE_JSON("exception.create.jsontoken"),

		PASSWORD_INVALID("password.invalid"),
		PASSWORD_LOCKED("password.locked"),

		LOGIN_WHEN_EMAIL_NOTI_DISABLED("login.when.email.noti.disabled"),
		LOGIN_NOT_ALLOWED("login.not.allowed"),

		CANNOT_READ_MESSAGE_FILE("CANNOT_READ_MESSAGE_FILE"),
		CANNOT_PROCESSING_JSON("CANNOT_PROCESSING_JSON"),

		NO_SECURITY_INFO("no.security.info"),
		NO_USER_FOUND("no.user.found"),
		NO_ROW_FOUND("no.row.found"),
		NO_ACNT_TYPE_FOUND("no.acnt.type.found"),
		NO_SECURITY_DISTRICT_INFO_LIST("no.security.district.info"),
		NO_LOCKIN_STS_INFO("no.lockin.sts.info"),
		NO_SECURITY_AREA_INFO("no.security.area.info"),
		NO_MENU_PATH_FOUND("no.menu.path.found"),
		NO_RESULT_FOUND("no.result.found"),
		NO_SEARCH_RESULT_FOUND("no.search.result.found"),
		NO_PERMISSION("common.auth.permission"),
		COMMON_AUTH_EXCEPTION("common.auth.exception"),
		
		ERROR_REQUEST_VALIDATION("error.request.validation"),
		ERROR_RESPONSE_VALIDATION("error.response.validation"),
		ERROR_DENKEI_NOT_FOUND("error.denkei.notFound"),
		ERROR_SERIALNUM_NOT_FOUND("error.command.serialNumNotFound"),
		ERROR_DUPLICATE_PRIMARY_KEY("error.duplicate.primary.key"),
		ERROR_SERVER_TIMEOUT("error.server.timeout"),
		ERROR_MLSTS_CHKSTS_NOT_EXIST("error.mlSts.chkSts.not.exist"),
		ERROR_REGISTEREDKEIBI_NOT_FOUND("error.registeredKeibi.notFound"),
		ERROR_DELIVERYSETTING_READTIMEOUT("error.deliverySetting.readTimeout"),
		ERROR_CONTROL_QUEUE_STATUS("error.control.queue.status"),
		ERROR_USERID_CANNOTLOGIN("error.userId.canNotLogin"),
		ERROR_PAGE_NO_INVALID("error.page_no_invalid"),
		ERROR_OTHER_USER("error.otherUser"),
		ERROR_AUTH_ERROR_MESSAGE("common.auth.errorMessage"),
		ERROR_OUT_ALSOK_ERROR("error.alsok.outAlsokError"),
		ERROR_MSG_KEIBI_START("Error.msg.keibi.Start"),
		ERROR_MSG_KEIBI_END("Error.msg.keibi.End"),
		ERROR_USER_INF_MODIFIED("error.user.inf.modified"),
		ERROR_ANOTHER_SESSION_LOGINED("error.another.session.logined"),

		SCREEN_TITLE_SZWP0100("screen.title.SZWP0100"),
		SCREEN_TITLE_SZWP1400("screen.title.SZWP1400"),
		SCREEN_TITLE_SZWP1800("screen.title.SZWP1800"),
		SCREEN_TITLE_SZWP1900("screen.title.SZWP1900"),
		SCREEN_TITLE_SZWP3100("screen.title.SZWP3100"),
		SCREEN_TITLE_SZWP3500("screen.title.SZWP3500"),
		SCREEN_TITLE_SZWP3800("screen.title.SZWP3800"),

		OPERATION_FAIL("operation.fail"),
		GET_LOGIN_FAILURE_TIMES("get.login.failure.times"),
		GET_QUEUE_STATUS("get.queue.status"),
		UPDATE_LOGIN_FAILURE_TIMES("update.login.failure.times"),
		UPDATE_LOGIN_STATUS("update.login.status"),
		UPDATE_SELECTED_LANG("update.selected.lang"),
		UPDATE_CONFIRM_STATUS("update.confirm.status"),
		UPDATE_REGIS_STATUS("update.regis.status"),
		UPDATE_LAST_LOGIN_DATE("update.last.login.date"),
		ERROR_MEDIA_RESPONSE("error.media.response"),
		ERROR_MEDIA_RESULT("error.media.result"),
		ERROR_MEDIA_FAILURE("error.media.failure"),
		ERROR_USERID_NOTFOUND("error.userId.notFound"),
		ERROR_AVAILABLE_KEIBI("error.available.keibi");

		private final String errorKey;

		private ErrorKey(String errorKey) {
			this.errorKey = errorKey;
		}

		public String getValue() {
			return this.errorKey;
		}
	}

	public static enum SignalType {
		type1("type1"),
		type2("type2");

		private final String type;

		private SignalType(String type) {
			this.type = type;
		}

		public String getValue() {
			return this.type;
		}
	}

	public static int getTimeRage(String cdtime) {
		int result = 0;
		switch (cdtime) {
		case "0":
			result = 480; //8h
			break;
		case "1":
			result =120; //2h
			break;
		case "2":
			result = 10; //10m
			break;
		case "3":
			result = 1; //1m
			break;
		default:
			result = 0; //0m
			break;
		}
		return result;
	}

	/**
     * 警備開始／警備解除処理
     * 在室警備開始/在室警備解除
     */
    public static class MYCD001 {
        /**
         * 警備開始
         */
        public static final String UNDER_SECURITY = "1";
        /**
         * 警備解除
         */
        public static final String UNPROTECTING = "2";
        /**
         * 在室警備開始
         */
        public static final String UNDER_SECURITY_IN_ROOM = "3";
        /**
         * 在室警備解除
         */
        public static final String UNPROTECTING_IN_ROOM = "4";
    }

    /**
     * 信号チェック
     */
    public static class MYCD002 {
        /**
         * チェックがある
         */
        public static final String CHECKED = "1";
        /**
         * チェックがない
         */
        public static final String UNCHECK = "0";
    }

    /**
     * SOAP key
     */
    public static class MYCD003 {
    	/** キー:電文バージョン. */
        public static final String COMMANDVERSION = "command_version";
        /** キー:トランザクション番号. */
        public static final String TRANSACTIONNO = "transaction_no";
        /** キー:発生時刻. */
        public static final String GENERATIONTIME = "generation_time";
        /** キー:送信機ID. */
        public static final String TRANSMITTERID = "transmitter_id";
        /** キー:電計番号. */
        public static final String DENKEINO = "denkei_no";
        /** キー:号機番号. */
        public static final String GOUKINO = "gouki_no";
        /** キー:サブアドレス. */
        public static final String SUBADDRESS = "sub_address";
        /** キー:回線種別. */
        public static final String LINETYPE = "line_type";
        /** キー:実行コマンド. */
        public static final String EXECCMD = "execmd";
        /** キー:在室警備区域情報. */
        public static final String KSZINF = "kszinf";
        /** キー:在室警備区域番号. */
        public static final String KBZNNO = "kbzn_no";
        /** キー:N0/F0状態. */
        public static final String NOSTAT = "n0_stat";
        /** キー:KN/KF状態. */
        public static final String KNSTAT = "kn_stat";
        /** キー:DN0/DF0状態. */
        public static final String DNSTAT = "dn_stat";
        /** キー:エラーコード. */
        public static final String TERMNO = "term_no";
        /** キー:エラーコード. */
        public static final String CNTRST = "cntr_st";
        /** キー:エラーコード. */
        public static final String RESULT = "result";
        /** キー:コマンドシーケンス番号. */
        public static final String CMDSEQNUM = "cmd_seq_num";
        /** キー:SOAP電文. */
        public static final String SOAPMSG = "soap_msg";
        /** キー:通信先装置番号. */
        public static final String CONNDEVNUM = "conn_dev_num";
        /** キー:装置番号. */
        public static final String DEVNUM = "dev_num";
        /** キー:処理通番. */
        public static final String PROCESSNUM = "process_num";
        /** キー:発信元ホスト名. */
        public static final String HOSTNM = "host_nm";
        /** キー:優先度. */
        public static final String PRIORITY = "priority";
        /** キー:コマンドコード. */
        public static final String CMDCD = "cmd_cd";
        /** キー:状態. */
        public static final String STS = "sts";
    }

    /**
     * 実行コマンド
     */
    public static class MYCD004 {
        /** 警備状態設定要求. */
        public static final String KBSTSET = "kbstset";
        /** ループ状態読出し. */
        public static final String LPINFRD = "lpinfrd";
        /** 制御状態読出要求. */
        public static final String DRCTRD = "drct_rd";
        /** ダイレクト制御. */
        public static final String DRCTSET = "drctset";
    }

    /**
     * 処理通番
     */
    public static class MYCD005 {
        /** . */
        public static final String START = "01";
    }

    /**
     * 通信先装置番号
     */
    public static class MYCD006 {
        /** . */
        public static final String SU000 = "SU000";
    }

    /**
     * Exception
     */
    public static class MYCD007 {
        /** . */
        public static final String DataIntegrityViolationException = "DataIntegrityViolationException";
    }

    public static class MYCD008 {
        /** . */
        public static final String STATUS_END = "E";  
        public static final String STATUS_RUN = "R";
        public static final String STATUS_FAILED = "F";
        public static final String STATUS_WRITER = "W";
        public static final String STATUS_EXIT = "exit";
        public static final String COMMAND_REQ = "request";
        public static final String COMMAND_EXT = "exit";
        public static final String DOWNLOAD_EXEC = "d";
        public static final String DOWNLOAD_REQ = "r";
        public static final String DOWNLOAD_EXT = "e";
        
        public static final int BUFFER_SIZE = 4096;
        public static final int WRITE_BLOCK = 1024;
    }
    public static class SZWP2300 {
    	public static final String RESULT_OK = "0";
    	public static final String PROCESS_ID_SEPARATOR = "_";
    	public static final String DSP_CAMERA_NUM = "1";
    	public static final String PLY_CAMERA_LST = "[]";
    	public static final String ACNT_TYPE_FOR_OPE = "1";
    }
    public static class CD_SEQUENCE {
        /** コマンドシーケンス番号 */
        public static final String CMD_SEQ_NUM = "CMD_SEQ_NUM";
        /** トランシーケンス番号 */
        public static final String TRAN_SEQ_NUM = "TRAN_SEQ_NUM";
        /** 警備信号論理番号用シーケンス番号名 */
        public static final String LN_QUE_KB_SIG_SEQ_NAME = "LN_QUE_KB_SIG";
        /** マスタ配信キュー論理番号用シーケンス番号名 */
        public static final String LN_QUE_MST_SEND_SEQ_NAME = "LN_QUE_MST_SEND";
        /** W_GS営業システム連携、W_HS営業システム連携 LN_営業システム連携論理番号 */
        public static final String LN_SYNC_SALE_SYS = "LN_SYNC_SALE_SYS";
        /** R_警備先地区 LN_警備先地区論理番号用シーケンス番号名 */
        public static final String LN_KB_CHIKU_SEQ_NAME = "LN_KB_CHIKU";
        /** R_緊急連絡先名簿 LN_緊急連絡先名簿論理番号用シーケンス番号名 */
        public static final String LN_KNRN_MEIBO_SEQ_NAME = "LN_KNRN_MEIBO";
        /** R_緊急連絡先名簿_同居家族 LN_緊急連絡先名簿_同居家族論理番号シーケンス番号名 */
        public static final String LN_KNRN_MEIBO_DOKYO_SEQ_NAME = "LN_KNRN_MEIBO_DOKYO";
        /** R_緊急連絡先名簿_救急情報 LN_緊急連絡先名簿_救急情報論理番号シーケンス番号名 */
        public static final String LN_KNRN_MEIBO_KYUKYU_SEQ_NAME = "LN_KNRN_MEIBO_KYUKYU";
        // LN_アカウント関連メール配信トリガ論理番号 = シーケンス値
        public static final String LN_QUE_AC_ML_TRIG = "LN_QUE_AC_ML_TRIG";
        /** ライブ画像音声 LN_ライブ画像音声論理番号シーケンス番号名 */
        public static final String LN_LIVE_IMGVOC_SEQ_NAME = "LN_LIVE_IMGVOC";

        /** 蓄積画像音声 LN_蓄積画像音声論理番号シーケンス番号名 */
        public static final String LN_ACUM_IMGVOC_SEQ_NAME = "LN_ACUM_IMGVOC";

        /** 信号画像音声 LN_信号画像音声論理番号シーケンス番号名 */
        public static final String LN_SGN_IMGVOC_SEQ_NAME = "LN_SGN_IMGVOC";

        /** 記録画像音声 LN_記録画像音声論理番号シーケンス番号名 */
        public static final String LN_RECORD_IMGVOC_SEQ_NAME = "LN_RECORD_IMGVOC";

        /** AI画像音声 LN_AI画像音声論理番号シーケンス番号名 */
        public static final String LN_AI_IMGVOC_SEQ_NAME = "LN_AI_IMGVOC"; 
        
        public static final String LN_QUE_CTRL_SIG = "LN_QUE_CTRL_SIG";
        
        public static final String LN_QUE_CTRL = "LN_QUE_CTRL";
        
        /** 利用者操作履歴 シーケンスID */
        public static final String LN_LOG_USER_OPERATION = "LN_LOG_USER_OPERATION";
    }
    
    public static class CD_SERVICE_TEIKYO {
    	/** 機械警備サービス(LN_警備サービス提供種別マスター論理番号) */
        public static final String KEIBI_SERVICE = "20190208000010001";
        
        /** 遠隔設備操作(LN_警備サービス提供種別マスター論理番号) */
        public static final String REMOTE_OPERATION = "20190208000010002";
        
        /** イベント画像サービス(LN_警備サービス提供種別マスター論理番号) */
        public static final String EVENT_PICTURE = "20190208000010006";
        
        /** リモートエスコート(LN_警備サービス提供種別マスター論理番号) */
        public static final String REMOTE_ESCORT = "20190208000010007";
        
        /** 画像蓄積サービス(LN_警備サービス提供種別マスター論理番号) */
        public static final String ACCUM_PICTURE = "20190208000010008";
        
        /** 登録人物情報サービス(LN_警備サービス提供種別マスター論理番号) */
        public static final String RPERS_SERVICE = "20190208000010009";
        
        /** 重要犯罪者情報サービス(LN_警備サービス提供種別マスター論理番号) */
        public static final String MPERS_SERVICE = "20190208000010010";
    }
    
    public static class CD_ACNT_AUTH_MST {
        /** 警備開始/解除(利用者アカウント権限ID) */
        public static final String K_OPE       = "20000101010100000000";
        
        /** 警備履歴一覧(利用者アカウント権限ID) */
        public static final String H_CHK_KEIBI = "20000101020100000000";
        
        /** 登録人物検知履歴(利用者アカウント権限ID) */
        public static final String H_CHK_RPERS = "20000101020200000000";
        
        /** 重要犯罪者認証検知履歴(利用者アカウント権限ID) */
        public static final String H_CHK_MPERS = "20000101020300000000";
        
        /** イベント画像情報(利用者アカウント権限ID) */
        public static final String H_CHK_EVENT = "20000101020400000000";
        
        /** 遠隔設備操作(利用者アカウント権限ID) */
        public static final String R_OPE       = "20000101030100000000";
        
        /** ライブ閲覧(利用者アカウント権限ID) */
        public static final String G_MEN_LIVEV = "20000101040100000000";
        
        /** ライブ閲覧(利用者アカウント権限ID) */
        public static final String G_MEN_ACCUM = "20000101040200000000";
    }
}
