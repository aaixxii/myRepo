package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.HAlsokNoticeDataModel;
import com.nec.jp.G6Smartphone.SO.ResGetNoticeDetail;


/**
 * The persistent class for the H_ALSOK_NOTICE database table.
 * 
 */
@SqlResultSetMappings({
	@SqlResultSetMapping(name="ResGetNoticeDetailResult",
		classes = {
			@ConstructorResult(
				targetClass = ResGetNoticeDetail.class,
				columns = {
					@ColumnResult(name = "send_ts"),
					@ColumnResult(name = "title"),
					@ColumnResult(name = "insertNm"),
					@ColumnResult(name = "body")
				}
			)
		}
	),
	@SqlResultSetMapping(name="HAlsokNoticeDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = HAlsokNoticeDataModel.class,
				columns = {
					@ColumnResult(name = "lnHAlsokNotice"),
					@ColumnResult(name = "sendTs"),
					@ColumnResult(name = "title")
				}
			)
		}
	)
})
@Entity
@Table(name="H_ALSOK_NOTICE")
@NamedQuery(name="HAlsokNoticeModel.findAll", query="SELECT h FROM HAlsokNoticeModel h")
public class HAlsokNoticeModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_H_ALSOK_NOTICE")
	private String lnHAlsokNotice;

	@Lob
	@Column(name="BODY")
	private String body;

	@Column(name="FLG_ML_SEND_SVC_KIND")
	private String flgMlSendSvcKind;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="LN_ML_TRIG")
	private String lnMlTrig;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="RGST_TS")
	private Date rgstTs;

	@Column(name="SEND_METHOD")
	private String sendMethod;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SEND_TS")
	private Date sendTs;

	@Column(name="SEND_TYPE")
	private String sendType;

	@Column(name="TITLE")
	private String title;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public HAlsokNoticeModel() {
	}

	public String getLnHAlsokNotice() {
		return this.lnHAlsokNotice;
	}

	public void setLnHAlsokNotice(String lnHAlsokNotice) {
		this.lnHAlsokNotice = lnHAlsokNotice;
	}

	public String getBody() {
		return this.body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getFlgMlSendSvcKind() {
		return this.flgMlSendSvcKind;
	}

	public void setFlgMlSendSvcKind(String flgMlSendSvcKind) {
		this.flgMlSendSvcKind = flgMlSendSvcKind;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getLnMlTrig() {
		return this.lnMlTrig;
	}

	public void setLnMlTrig(String lnMlTrig) {
		this.lnMlTrig = lnMlTrig;
	}

	public Date getRgstTs() {
		return this.rgstTs;
	}

	public void setRgstTs(Date rgstTs) {
		this.rgstTs = rgstTs;
	}

	public String getSendMethod() {
		return this.sendMethod;
	}

	public void setSendMethod(String sendMethod) {
		this.sendMethod = sendMethod;
	}

	public Date getSendTs() {
		return this.sendTs;
	}

	public void setSendTs(Date sendTs) {
		this.sendTs = sendTs;
	}

	public String getSendType() {
		return this.sendType;
	}

	public void setSendType(String sendType) {
		this.sendType = sendType;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}