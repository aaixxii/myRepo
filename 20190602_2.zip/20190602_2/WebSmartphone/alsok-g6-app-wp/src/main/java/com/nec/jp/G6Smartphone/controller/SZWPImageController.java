package com.nec.jp.G6Smartphone.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nec.jp.G6Smartphone.utility.Config;
import com.nec.jp.G6Smartphone.utility.ConfigKey;
import com.nec.jp.G6Smartphone.utility.FileUtils;
import com.nec.jp.G6Smartphone.utility.G6Constant;

import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWPImageController {

private static final ApplicationLog appLog = new ApplicationLog(SZWPImageController.class);
    
    @RequestMapping(value = "getImage", method = RequestMethod.GET)
    @ResponseBody
    public void getImage(@RequestParam("imageId") String imageId, final HttpServletResponse response)
            throws Exception {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWPImageController.getImage()");
        outImage(imageId, response);
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWPImageController.getImage()");
    }
    
    /**
     * 画像を出力.
     *
     * @param imagePath
     *            画像パス
     * @param response
     *            レスポンス
     * @throws IOException
     *             読み書き異常流
     */
    private void outImage(String imagePath, final HttpServletResponse response) throws Exception {
        String fullPath = imagePath;
        File file = new File(fullPath);
        try (FileInputStream fis = new FileInputStream(file)) {
            int len;
            byte[] byteArray = new byte[1024];
            OutputStream out = response.getOutputStream();
            while ((len = fis.read(byteArray)) != -1) {
                out.write(byteArray, 0, len);
            }
        } catch (IOException e) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 
            try {
                URL url = SZWP3500Controller.class.getClassLoader().getResource("");
                String noImagePath = FileUtils.getImagePath(Config.getString(ConfigKey.NOT_FIND_IMAGE_PATH), null, url);
                if (noImagePath.equals(imagePath)) {
                    response.setStatus(404);
                    throw e;
                } else {
                    this.outImage(noImagePath, response);
                }
            } catch (Exception ex) {
            	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
            }
        }
    }
}
