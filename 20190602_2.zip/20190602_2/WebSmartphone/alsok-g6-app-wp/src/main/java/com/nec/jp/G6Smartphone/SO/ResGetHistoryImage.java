package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetHistoryImage implements ErrorHandler {

	private String errorCode;		// エラーコード
	private String errorMsg;		// エラーメッセージ
	private String videoFileName;	// 警備情報.画像ファイル名
	private String acntID;

	public ResGetHistoryImage() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.videoFileName = "";
		this.acntID = "";
	}

	public ResGetHistoryImage(String errorCode, String errorMsg, String videoFileName) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.videoFileName = videoFileName;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getVideoFileName() {
		return videoFileName;
	}

	public void setVideoFileName(String videoFileName) {
		this.videoFileName = videoFileName;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
