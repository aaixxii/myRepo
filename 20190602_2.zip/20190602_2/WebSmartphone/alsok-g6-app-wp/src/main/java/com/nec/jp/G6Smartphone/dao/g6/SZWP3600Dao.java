package com.nec.jp.G6Smartphone.dao.g6;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP3600Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	public String getRegistrationImageInfo(String lnRAuthPicInf) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT		IFNULL(rauthpicinf.PIC_INF, '')");
		strBuilder.append(" FROM			R_AUTH_PIC_INF rauthpicinf");
		strBuilder.append(" WHERE		rauthpicinf.DEL_FLG = :delFlg");
		strBuilder.append(" 					AND rauthpicinf.LN_R_AUTH_PIC_INF = :lnRAuthPicInf");

		Query query = entityManager.createNativeQuery(strBuilder.toString());

		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		query.setParameter("lnRAuthPicInf", lnRAuthPicInf);

		return query.getSingleResult().toString();
	}

	public String getDetectedImageInfo(String lnKbInf) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT		CAST(ekbinf.VIDEO_FILE_NAME AS CHARACTER)");
		strBuilder.append(" FROM			E_KB_INF ekbinf");
		strBuilder.append(" WHERE		ekbinf.LN_KB_INF = :lnKbInf");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKbInf", lnKbInf);
		return query.getSingleResult().toString();
	}
}
