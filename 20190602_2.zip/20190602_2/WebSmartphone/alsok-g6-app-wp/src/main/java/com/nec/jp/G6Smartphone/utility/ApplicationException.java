package com.nec.jp.G6Smartphone.utility;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;


/**
 * The Class ApplicationExceptions.
 */
public class ApplicationException extends Exception {

    private static final long serialVersionUID = -4276791776137640818L;

    @Autowired
    MessageSource messageSource;

    protected transient List<SummaryItem> summaryItems = new ArrayList<SummaryItem>();

    /**
     * The Class SummaryItem.
     */
    protected class SummaryItem {
        public transient String errorContext;
        public transient String exceptionCode;
        public transient String exceptionMsg;

        /**
         * Instantiates a new summary item.
         * 
         * @param contextCode
         *            the context code
         * @param exceptionCode
         *            the exception code
         * @param exceptionMsg
         *            the exception message
         */
        public SummaryItem(final String contextCode, final String exceptionCode,
                final String exceptionMsg) {

            this.errorContext = contextCode;
            this.exceptionCode = exceptionCode;
            this.exceptionMsg = exceptionMsg;
        }
    }

    /**
     * Instantiates a new application exception.
     * 
     * @param errorContext
     *            the error context
     * @param exceptionCode
     *            the exception code
     * @param exceptionMessage
     *            the exception message
     */
    public ApplicationException(final String errorContext,
            final String exceptionCode, final String exceptionMsg) {
        super();
        addInfo(errorContext, exceptionCode, exceptionMsg);
    }

    /**
     * Instantiates a new application exception.
     * 
     * @param errorContext
     *            the error context
     * @param exceptionCode
     *            the exception code
     * @param exceptionMessage
     *            the exception message
     * @param cause
     *            the cause
     */
    public ApplicationException(final String errorContext,
            final String exceptionCode, final String exceptionMsg, final Throwable cause) {
        super(cause);
        addInfo(errorContext, exceptionCode, exceptionMsg);
    }

    /**
     * Adds the info.
     * 
     * @param errorContext
     *            the error context
     * @param exceptionCode
     *            the exception code
     * @param exceptionMsg
     *            the exception message
     * @return the application exception
     */
    public final ApplicationException addInfo(final String errorContext,
            final String exceptionCode, final String exceptionMsg) {

        this.summaryItems
                .add(new SummaryItem(errorContext, exceptionCode, exceptionMsg));
        return this;
    }

    /**
     * Append exception.
     * 
     * @param builder
     *            the builder
     * @param throwable
     *            the throwable
     */
    private void appendException(final StringBuilder builder,
            final Throwable throwable) {
        if (throwable == null) {
            return;
        }
        appendException(builder, throwable.getCause());
        builder.append(throwable.toString());
        builder.append(G6Constant.NEW_LINE_CHAR);
    }

    /**
     * Gets the code.
     * 
     * @return the code
     */
    public final String getCode() {
        final StringBuilder builder = new StringBuilder();

        // builder.append(G6Constant.OPEN_SQR_BRACKET);
        final int length = this.summaryItems.size() - 1;
        for (int i = length; i >= 0; i--) {
            final SummaryItem info = this.summaryItems.get(i);
            builder.append(info.exceptionCode);
            if (i != 0) {
                builder.append(G6Constant.COLON);
            }
        }
        // builder.append(G6Constant.CLOSE_SQR_BRACKET);

        return builder.toString();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Throwable#toString()
     */
    @Override
    public final String toString() {
        final StringBuilder builder = new StringBuilder();

        builder.append(getCode());
        builder.append(G6Constant.NEW_LINE_CHAR);

        // append additional context information.
        for (int i = this.summaryItems.size() - 1; i >= 0; i--) {
            final SummaryItem info = this.summaryItems.get(i);
            builder.append(G6Constant.OPEN_SQR_BRACKET);
            builder.append(info.errorContext);
            builder.append(G6Constant.CLOSE_SQR_BRACKET);
            builder.append(G6Constant.OPEN_SQR_BRACKET);
            builder.append(info.exceptionCode);
            builder.append(G6Constant.COLON);
            String messageText = info.exceptionMsg;
            builder.append(messageText);
            builder.append(G6Constant.CLOSE_SQR_BRACKET);
            if (i > 0) {
                builder.append(G6Constant.NEW_LINE_CHAR);
            }
        }

        // append root causes and text from this exception first.
        if (getMessage() != null) {
            builder.append(G6Constant.NEW_LINE_CHAR);
            if (getCause() == null) {
                builder.append(getMessage());
            } else if (!getMessage().equals(getCause().toString())) {
                builder.append(getMessage());
            }
        }
        appendException(builder, getCause());

        return builder.toString();
    }

    public String getExceptionCode() {
        String errorCode = "";
        if (summaryItems.size() > 0) {
            errorCode = summaryItems.get(0).exceptionCode;
        }
        return errorCode;
    }
    
    public String getExceptionMsg() {
        String errorCode = "";
        if (summaryItems.size() > 0) {
            errorCode = summaryItems.get(0).exceptionMsg;
        }
        return errorCode;
    }

}
