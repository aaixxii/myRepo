package com.nec.jp.G6Smartphone.service.g6;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.CameraDataModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuNmDataModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP2200Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP2200Service {

	@Autowired
	private SZWP2200Dao sZWP2200Dao;

	public List<RKbChikuNmDataModel> getSecurityDistrictList(String acntID, String lnKeibi, Boolean dispMainChikuFlg) throws ApplicationException {
		try {
			List<RKbChikuNmDataModel> rKbChikuNmList = sZWP2200Dao.getSecurityDistrictList(acntID, lnKeibi, dispMainChikuFlg);

			return rKbChikuNmList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public List<CameraDataModel> getDeviceList(String lnKbChiku) throws ApplicationException {
		try {
			List<CameraDataModel> cameraList = sZWP2200Dao.getDeviceList(lnKbChiku);

			return cameraList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
