package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.JianDataModel;


/**
 * The persistent class for the E_JIAN database table.
 * 
 */
@SqlResultSetMapping(name="JianDataModelResult",
classes = {
	@ConstructorResult(
		targetClass = JianDataModel.class,
		columns = {
			@ColumnResult(name = "insertTs"),
			@ColumnResult(name = "videoFileName"),
			@ColumnResult(name = "nickName"),
			@ColumnResult(name = "sdKobetuNm"),
			@ColumnResult(name = "devNm"),
			@ColumnResult(name = "lnRAuthPicInf"),
			@ColumnResult(name = "lnKbInf"),
			@ColumnResult(name = "lnImgNump")
		}
	)
}
)
@Entity
@Table(name="E_JIAN")
@NamedQuery(name="EJianModel.findAll", query="SELECT e FROM EJianModel e")
public class EJianModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_JIAN")
	private String lnJian;

	@Column(name="BUZZ_FLG")
	private String buzzFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="END_TS")
	private Date endTs;

	@Column(name="FIRST_JIAN_HYOUJI_DEV_KIND")
	private String firstJianHyoujiDevKind;

	@Column(name="GC_SENT_FLG")
	private String gcSentFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="GC_SENT_TS")
	private Date gcSentTs;

	@Column(name="GENIN_ID")
	private String geninId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="GENIN_TS")
	private Date geninTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="HASSEI_TS")
	private Date hasseiTs;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="INTP_STS")
	private String intpSts;

	@Column(name="JIAN_CAUSE_FLG")
	private String jianCauseFlg;

	@Column(name="JIAN_END_USER_NM")
	private String jianEndUserNm;

	@Column(name="JIAN_FUKKYU_FLG")
	private String jianFukkyuFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="JIAN_HASSEI_TS")
	private Date jianHasseiTs;

	@Column(name="JIAN_HYOJI_FLG")
	private String jianHyojiFlg;

	@Column(name="JIAN_MAKE_USER_NM")
	private String jianMakeUserNm;

	@Column(name="JIAN_OPE_AUTH_DEV_KIND")
	private String jianOpeAuthDevKind;

	@Column(name="JIAN_TANTO_FLG")
	private String jianTantoFlg;

	@Column(name="JIGYOU_ID")
	private String jigyouId;

	@Column(name="KEIBI_GENIN_NAIYOU")
	private String keibiGeninNaiyou;

	@Column(name="KYLESS_ST")
	private String kylessSt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LASTUPD_TS")
	private Date lastupdTs;

	@Column(name="LIMIT_EXT_MAX_SS")
	private String limitExtMaxSs;

	@Column(name="LIMIT_EXT_SS")
	private String limitExtSs;

	@Column(name="LIVE_VIEWER_FLG")
	private String liveViewerFlg;

	@Column(name="LN_FILE_SEND")
	private String lnFileSend;

	@Column(name="LN_GENIN")
	private String lnGenin;

	@Column(name="LN_JIAN_END_USER_ID")
	private String lnJianEndUserId;

	@Column(name="LN_JIAN_MAKE_USER")
	private String lnJianMakeUser;

	@Column(name="LN_JITAI")
	private String lnJitai;

	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;

	@Column(name="LN_KB_INF_CUST1")
	private String lnKbInfCust1;

	@Column(name="LN_KB_INF1")
	private String lnKbInf1;

	@Column(name="LN_KB_INF1_RM")
	private String lnKbInf1Rm;

	@Column(name="LN_KB_INF2")
	private String lnKbInf2;

	@Column(name="LN_KB_INF2_RM")
	private String lnKbInf2Rm;

	@Column(name="LN_KB_INF3")
	private String lnKbInf3;

	@Column(name="LN_KB_INF3_RM")
	private String lnKbInf3Rm;

	@Column(name="LN_LAST_NF_SIG")
	private String lnLastNfSig;

	@Column(name="LN_LAST_SIG")
	private String lnLastSig;

	@Column(name="LN_LAST_SIG_RM")
	private String lnLastSigRm;

	@Column(name="LN_TOROKU_KIND_NUM")
	private String lnTorokuKindNum;

	@Column(name="NET_GENIN_CD")
	private String netGeninCd;

	@Column(name="OPERATOR_ID")
	private String operatorId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="PRE_JIAN_HASSEI_TS")
	private Date preJianHasseiTs;

	@Column(name="PRIORITY")
	private String priority;

	@Column(name="PROCESS_NUM")
	private String processNum;

	@Column(name="RAKUCHAKU_FLG")
	private String rakuchakuFlg;

	@Column(name="RM_BUZZ_NOTICE_FLG")
	private String rmBuzzNoticeFlg;

	@Column(name="RM_DISP_FLG")
	private String rmDispFlg;

	@Column(name="RM_SIG_SEND_FLG")
	private String rmSigSendFlg;

	@Column(name="SGS_GENIN_CD")
	private String sgsGeninCd;

	@Column(name="SINPO_JISSI_FLG")
	private String sinpoJissiFlg;

	@Column(name="SINPO_KIDOU_FLG")
	private String sinpoKidouFlg;

	@Column(name="SINPO_REASON_FLG")
	private String sinpoReasonFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="TIMEOUT_TS")
	private Date timeoutTs;

	@Column(name="TOROKU_KIND")
	private String torokuKind;

	@Column(name="TOROKU_KIND_CD")
	private String torokuKindCd;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public EJianModel() {
	}

	public String getLnJian() {
		return this.lnJian;
	}

	public void setLnJian(String lnJian) {
		this.lnJian = lnJian;
	}

	public String getBuzzFlg() {
		return this.buzzFlg;
	}

	public void setBuzzFlg(String buzzFlg) {
		this.buzzFlg = buzzFlg;
	}

	public Date getEndTs() {
		return this.endTs;
	}

	public void setEndTs(Date endTs) {
		this.endTs = endTs;
	}

	public String getFirstJianHyoujiDevKind() {
		return this.firstJianHyoujiDevKind;
	}

	public void setFirstJianHyoujiDevKind(String firstJianHyoujiDevKind) {
		this.firstJianHyoujiDevKind = firstJianHyoujiDevKind;
	}

	public String getGcSentFlg() {
		return this.gcSentFlg;
	}

	public void setGcSentFlg(String gcSentFlg) {
		this.gcSentFlg = gcSentFlg;
	}

	public Date getGcSentTs() {
		return this.gcSentTs;
	}

	public void setGcSentTs(Date gcSentTs) {
		this.gcSentTs = gcSentTs;
	}

	public String getGeninId() {
		return this.geninId;
	}

	public void setGeninId(String geninId) {
		this.geninId = geninId;
	}

	public Date getGeninTs() {
		return this.geninTs;
	}

	public void setGeninTs(Date geninTs) {
		this.geninTs = geninTs;
	}

	public Date getHasseiTs() {
		return this.hasseiTs;
	}

	public void setHasseiTs(Date hasseiTs) {
		this.hasseiTs = hasseiTs;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getIntpSts() {
		return this.intpSts;
	}

	public void setIntpSts(String intpSts) {
		this.intpSts = intpSts;
	}

	public String getJianCauseFlg() {
		return this.jianCauseFlg;
	}

	public void setJianCauseFlg(String jianCauseFlg) {
		this.jianCauseFlg = jianCauseFlg;
	}

	public String getJianEndUserNm() {
		return this.jianEndUserNm;
	}

	public void setJianEndUserNm(String jianEndUserNm) {
		this.jianEndUserNm = jianEndUserNm;
	}

	public String getJianFukkyuFlg() {
		return this.jianFukkyuFlg;
	}

	public void setJianFukkyuFlg(String jianFukkyuFlg) {
		this.jianFukkyuFlg = jianFukkyuFlg;
	}

	public Date getJianHasseiTs() {
		return this.jianHasseiTs;
	}

	public void setJianHasseiTs(Date jianHasseiTs) {
		this.jianHasseiTs = jianHasseiTs;
	}

	public String getJianHyojiFlg() {
		return this.jianHyojiFlg;
	}

	public void setJianHyojiFlg(String jianHyojiFlg) {
		this.jianHyojiFlg = jianHyojiFlg;
	}

	public String getJianMakeUserNm() {
		return this.jianMakeUserNm;
	}

	public void setJianMakeUserNm(String jianMakeUserNm) {
		this.jianMakeUserNm = jianMakeUserNm;
	}

	public String getJianOpeAuthDevKind() {
		return this.jianOpeAuthDevKind;
	}

	public void setJianOpeAuthDevKind(String jianOpeAuthDevKind) {
		this.jianOpeAuthDevKind = jianOpeAuthDevKind;
	}

	public String getJianTantoFlg() {
		return this.jianTantoFlg;
	}

	public void setJianTantoFlg(String jianTantoFlg) {
		this.jianTantoFlg = jianTantoFlg;
	}

	public String getJigyouId() {
		return this.jigyouId;
	}

	public void setJigyouId(String jigyouId) {
		this.jigyouId = jigyouId;
	}

	public String getKeibiGeninNaiyou() {
		return this.keibiGeninNaiyou;
	}

	public void setKeibiGeninNaiyou(String keibiGeninNaiyou) {
		this.keibiGeninNaiyou = keibiGeninNaiyou;
	}

	public String getKylessSt() {
		return this.kylessSt;
	}

	public void setKylessSt(String kylessSt) {
		this.kylessSt = kylessSt;
	}

	public Date getLastupdTs() {
		return this.lastupdTs;
	}

	public void setLastupdTs(Date lastupdTs) {
		this.lastupdTs = lastupdTs;
	}

	public String getLimitExtMaxSs() {
		return this.limitExtMaxSs;
	}

	public void setLimitExtMaxSs(String limitExtMaxSs) {
		this.limitExtMaxSs = limitExtMaxSs;
	}

	public String getLimitExtSs() {
		return this.limitExtSs;
	}

	public void setLimitExtSs(String limitExtSs) {
		this.limitExtSs = limitExtSs;
	}

	public String getLiveViewerFlg() {
		return this.liveViewerFlg;
	}

	public void setLiveViewerFlg(String liveViewerFlg) {
		this.liveViewerFlg = liveViewerFlg;
	}

	public String getLnFileSend() {
		return this.lnFileSend;
	}

	public void setLnFileSend(String lnFileSend) {
		this.lnFileSend = lnFileSend;
	}

	public String getLnGenin() {
		return this.lnGenin;
	}

	public void setLnGenin(String lnGenin) {
		this.lnGenin = lnGenin;
	}

	public String getLnJianEndUserId() {
		return this.lnJianEndUserId;
	}

	public void setLnJianEndUserId(String lnJianEndUserId) {
		this.lnJianEndUserId = lnJianEndUserId;
	}

	public String getLnJianMakeUser() {
		return this.lnJianMakeUser;
	}

	public void setLnJianMakeUser(String lnJianMakeUser) {
		this.lnJianMakeUser = lnJianMakeUser;
	}

	public String getLnJitai() {
		return this.lnJitai;
	}

	public void setLnJitai(String lnJitai) {
		this.lnJitai = lnJitai;
	}

	public String getLnKbChiku() {
		return this.lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getLnKbInfCust1() {
		return this.lnKbInfCust1;
	}

	public void setLnKbInfCust1(String lnKbInfCust1) {
		this.lnKbInfCust1 = lnKbInfCust1;
	}

	public String getLnKbInf1() {
		return this.lnKbInf1;
	}

	public void setLnKbInf1(String lnKbInf1) {
		this.lnKbInf1 = lnKbInf1;
	}

	public String getLnKbInf1Rm() {
		return this.lnKbInf1Rm;
	}

	public void setLnKbInf1Rm(String lnKbInf1Rm) {
		this.lnKbInf1Rm = lnKbInf1Rm;
	}

	public String getLnKbInf2() {
		return this.lnKbInf2;
	}

	public void setLnKbInf2(String lnKbInf2) {
		this.lnKbInf2 = lnKbInf2;
	}

	public String getLnKbInf2Rm() {
		return this.lnKbInf2Rm;
	}

	public void setLnKbInf2Rm(String lnKbInf2Rm) {
		this.lnKbInf2Rm = lnKbInf2Rm;
	}

	public String getLnKbInf3() {
		return this.lnKbInf3;
	}

	public void setLnKbInf3(String lnKbInf3) {
		this.lnKbInf3 = lnKbInf3;
	}

	public String getLnKbInf3Rm() {
		return this.lnKbInf3Rm;
	}

	public void setLnKbInf3Rm(String lnKbInf3Rm) {
		this.lnKbInf3Rm = lnKbInf3Rm;
	}

	public String getLnLastNfSig() {
		return this.lnLastNfSig;
	}

	public void setLnLastNfSig(String lnLastNfSig) {
		this.lnLastNfSig = lnLastNfSig;
	}

	public String getLnLastSig() {
		return this.lnLastSig;
	}

	public void setLnLastSig(String lnLastSig) {
		this.lnLastSig = lnLastSig;
	}

	public String getLnLastSigRm() {
		return this.lnLastSigRm;
	}

	public void setLnLastSigRm(String lnLastSigRm) {
		this.lnLastSigRm = lnLastSigRm;
	}

	public String getLnTorokuKindNum() {
		return this.lnTorokuKindNum;
	}

	public void setLnTorokuKindNum(String lnTorokuKindNum) {
		this.lnTorokuKindNum = lnTorokuKindNum;
	}

	public String getNetGeninCd() {
		return this.netGeninCd;
	}

	public void setNetGeninCd(String netGeninCd) {
		this.netGeninCd = netGeninCd;
	}

	public String getOperatorId() {
		return this.operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public Date getPreJianHasseiTs() {
		return this.preJianHasseiTs;
	}

	public void setPreJianHasseiTs(Date preJianHasseiTs) {
		this.preJianHasseiTs = preJianHasseiTs;
	}

	public String getPriority() {
		return this.priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getProcessNum() {
		return this.processNum;
	}

	public void setProcessNum(String processNum) {
		this.processNum = processNum;
	}

	public String getRakuchakuFlg() {
		return this.rakuchakuFlg;
	}

	public void setRakuchakuFlg(String rakuchakuFlg) {
		this.rakuchakuFlg = rakuchakuFlg;
	}

	public String getRmBuzzNoticeFlg() {
		return this.rmBuzzNoticeFlg;
	}

	public void setRmBuzzNoticeFlg(String rmBuzzNoticeFlg) {
		this.rmBuzzNoticeFlg = rmBuzzNoticeFlg;
	}

	public String getRmDispFlg() {
		return this.rmDispFlg;
	}

	public void setRmDispFlg(String rmDispFlg) {
		this.rmDispFlg = rmDispFlg;
	}

	public String getRmSigSendFlg() {
		return this.rmSigSendFlg;
	}

	public void setRmSigSendFlg(String rmSigSendFlg) {
		this.rmSigSendFlg = rmSigSendFlg;
	}

	public String getSgsGeninCd() {
		return this.sgsGeninCd;
	}

	public void setSgsGeninCd(String sgsGeninCd) {
		this.sgsGeninCd = sgsGeninCd;
	}

	public String getSinpoJissiFlg() {
		return this.sinpoJissiFlg;
	}

	public void setSinpoJissiFlg(String sinpoJissiFlg) {
		this.sinpoJissiFlg = sinpoJissiFlg;
	}

	public String getSinpoKidouFlg() {
		return this.sinpoKidouFlg;
	}

	public void setSinpoKidouFlg(String sinpoKidouFlg) {
		this.sinpoKidouFlg = sinpoKidouFlg;
	}

	public String getSinpoReasonFlg() {
		return this.sinpoReasonFlg;
	}

	public void setSinpoReasonFlg(String sinpoReasonFlg) {
		this.sinpoReasonFlg = sinpoReasonFlg;
	}

	public Date getTimeoutTs() {
		return this.timeoutTs;
	}

	public void setTimeoutTs(Date timeoutTs) {
		this.timeoutTs = timeoutTs;
	}

	public String getTorokuKind() {
		return this.torokuKind;
	}

	public void setTorokuKind(String torokuKind) {
		this.torokuKind = torokuKind;
	}

	public String getTorokuKindCd() {
		return this.torokuKindCd;
	}

	public void setTorokuKindCd(String torokuKindCd) {
		this.torokuKindCd = torokuKindCd;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}