package com.nec.jp.G6Smartphone.SO;

public class AcntUserInfoModel implements DataModelHandler {

	private String acntUserKbn;		
	private String lnUserRole;		

	public AcntUserInfoModel() {
		this.acntUserKbn = "";
		this.lnUserRole =  "";
	}

	public AcntUserInfoModel(String acntUserKbn, String lnUserRole) {
		this.acntUserKbn = acntUserKbn;
		this.lnUserRole = lnUserRole;
	}

	public String getAcntUserKbn() {
		return acntUserKbn;
	}

	public void setAcntUserKbn(String acntUserKbn) {
		this.acntUserKbn = acntUserKbn;
	}

	public String getLnUserRole() {
		return lnUserRole;
	}

	public void setLnUserRole(String lnUserRole) {
		this.lnUserRole = lnUserRole;
	}
}
