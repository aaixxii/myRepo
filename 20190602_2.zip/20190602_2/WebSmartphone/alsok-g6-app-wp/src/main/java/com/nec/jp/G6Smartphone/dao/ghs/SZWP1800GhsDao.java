package com.nec.jp.G6Smartphone.dao.ghs;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.HAlsokNoticeDataModel;

@Repository
public class SZWP1800GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	private static final String LIST_KEIYK = "Notice Info List Keiyk";
	private static final String LIST_USER = "Notice Info List User";
	
	private StringBuilder getNoticeInfoListSql(String listType) {
		StringBuilder strBuilder = new StringBuilder();
		
		if(listType.equals(LIST_KEIYK)) {
			strBuilder.append(" SELECT	b.LN_ALSOK_NOTICE as lnHAlsokNotice,");
			strBuilder.append(" 		DATE_FORMAT(b.RGST_TS, '%Y/%m/%d %H:%i:%s') as rgstTs,");
			strBuilder.append("			IFNULL(b.TITLE, '') as title,");
			strBuilder.append(" 		b.SENDER_NM as senderNm,");
			strBuilder.append("			DATE_FORMAT(b.SEND_TM, '%Y/%m/%d %H:%i:%s') as sendTs,");
			strBuilder.append(" 		CAST(b.FLG_ML_SEND as CHARACTER) as flgMlSend,");
			strBuilder.append(" 		a.LN_ACNT_KEIYK as lnAcnt");
			strBuilder.append(" FROM	E_ALSOK_NOTICE b ");
			strBuilder.append("			LEFT JOIN E_KEIYAKU_ALSOK_NOTICE_ML_TGT a ON b.LN_ALSOK_NOTICE = a.LN_ALSOK_NOTICE");
			strBuilder.append("			AND (a.LN_ACNT_KEIYK = :acntID");
			strBuilder.append("			OR a.LN_ACNT_KEIYK IS NULL)");
			strBuilder.append(" WHERE	(DATE_FORMAT(b.SEND_TM, '%Y%m%d') BETWEEN :dtFrom AND :dtTo)");
			strBuilder.append(" ORDER BY b.RGST_TS DESC,");
			strBuilder.append("			 b.LN_ALSOK_NOTICE DESC");
		} 
		
		else if(listType.equals(LIST_USER)) {
			strBuilder.append(" SELECT	b.LN_ALSOK_NOTICE as lnHAlsokNotice,");
			strBuilder.append(" 		DATE_FORMAT(b.RGST_TS, '%Y/%m/%d %H:%i:%s') as rgstTs,");
			strBuilder.append("			IFNULL(b.TITLE, '') as title,");
			strBuilder.append(" 		b.SENDER_NM as senderNm,");
			strBuilder.append("			DATE_FORMAT(b.SEND_TM, '%Y/%m/%d %H:%i:%s') as sendTs,");
			strBuilder.append(" 		CAST(b.FLG_ML_SEND as CHARACTER) as flgMlSend,");
			strBuilder.append(" 		a.LN_ACNT_USER as lnAcnt");
			strBuilder.append(" FROM	E_ALSOK_NOTICE b");
			strBuilder.append("			LEFT JOIN E_ALSOK_NOTICE_ML_TGT a ON b.LN_ALSOK_NOTICE = a.LN_ALSOK_NOTICE");
			strBuilder.append("			AND (a.LN_ACNT_USER = :acntID");
			strBuilder.append("			OR a.LN_ACNT_USER IS NULL)");
			strBuilder.append(" WHERE	(DATE_FORMAT(b.SEND_TM, '%Y%m%d') BETWEEN :dtFrom AND :dtTo)");
			strBuilder.append(" ORDER BY b.RGST_TS DESC,");
			strBuilder.append("			 b.LN_ALSOK_NOTICE DESC");
		}
		
		return strBuilder;
	}
	
	public String getTotalRowListKeiyk(Date dtFrom, Date dtTo, String acntID) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append("SELECT COUNT(*) FROM (");
		strBuilder.append(getNoticeInfoListSql(LIST_KEIYK).toString());
		strBuilder.append(") NoticeInfoList");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		query.setParameter("acntID", acntID);
		
		return query.getSingleResult().toString();
	}
	
	public String getTotalRowListUser(Date dtFrom, Date dtTo, String acntID) {
		StringBuilder builder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		builder.append("SELECT COUNT(*) FROM (");
		builder.append(getNoticeInfoListSql(LIST_USER).toString());
		builder.append(") NoticeInfoList");

		Query query = entityManager.createNativeQuery(builder.toString());
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		query.setParameter("acntID", acntID);
		
		return query.getSingleResult().toString();
	}
	
	@SuppressWarnings("unchecked")
	public List<HAlsokNoticeDataModel> getNoticeInfoListKeiyk(Date dtFrom, Date dtTo, String acntID, int offset, int limitRowNum) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append(getNoticeInfoListSql(LIST_KEIYK).toString());
		strBuilder.append(" LIMIT :offset, :limitRowNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "HAlsokNoticeDataModelResult");
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		query.setParameter("acntID", acntID);
		query.setParameter("offset", offset);
		query.setParameter("limitRowNum", limitRowNum);

		return (List<HAlsokNoticeDataModel>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<HAlsokNoticeDataModel> getNoticeInfoListUser(Date dtFrom, Date dtTo, String acntID, int offset, int limitRowNum) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append(getNoticeInfoListSql(LIST_USER).toString());
		strBuilder.append(" LIMIT :offset, :limitRowNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "HAlsokNoticeDataModelResult");
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		query.setParameter("acntID", acntID);
		query.setParameter("offset", offset);
		query.setParameter("limitRowNum", limitRowNum);

		return (List<HAlsokNoticeDataModel>) query.getResultList();
	}
}
