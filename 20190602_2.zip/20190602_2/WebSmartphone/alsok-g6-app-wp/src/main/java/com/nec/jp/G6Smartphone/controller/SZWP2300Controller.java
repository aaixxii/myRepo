package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ResControlCamera;
import com.nec.jp.G6Smartphone.SO.ResDisplayLiveImage;
import com.nec.jp.G6Smartphone.SO.SZWP2300JsonModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;

@Controller
public class SZWP2300Controller {
	
	private static final ApplicationLog appLog = new ApplicationLog(SZWP2300Controller.class);

	//JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;

	@Value("${media_api_2300_009}")
	String MEDIA_API_2300_009;
	@Value("${media_api_2300_camctrl}")
	String MEDIA_API_2300_CAMCTRL;

	/*
	 * Get data from I_MNG_LIVE table
	 * @param: acntID, lnDev, lnKbChiku, sdDevNum, dialogSt, process
	 * return: object ResDisplayLiveImage as JSON
	 */
    @RequestMapping(value = "/displayLiveImage", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String displayLiveImage(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2300Controller.displayLiveImage()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResDisplayLiveImage resDisplayLiveImage = new ResDisplayLiveImage();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntID = "";
		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
			            
			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 6) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
				return jsonResult;
			}
			// Build require parameters
			Map<String, Boolean> lstRequiredParam = new HashMap<String, Boolean>() ;
			lstRequiredParam.put(RequestParam.acntID.getValue(), true);
			lstRequiredParam.put(RequestParam.lnDev.getValue(), true);
			lstRequiredParam.put(RequestParam.lnKbChiku.getValue(), true);
			lstRequiredParam.put(RequestParam.sdDevNum.getValue(), true);
			lstRequiredParam.put(RequestParam.dialogSt.getValue(), false);
			lstRequiredParam.put(RequestParam.process.getValue(), true);
			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
				return jsonResult;
			}

			// リクエスト情報取得
			// unused: リクエスト情報からアカウント種別を取得する
			// TODO SZWP2300：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);
			acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
			String lnDev = mapParam.get(RequestParam.lnDev.getValue()).toString();
			List<String> sdDevNum = G6Common.readParamToArrayObject(mapParam, RequestParam.sdDevNum.getValue());
			String selectedForDialog = mapParam.get(RequestParam.dialogSt.getValue()).toString();
			String opeFormId = G6Constant.ScreenID.SZWP2300.getValue() + G6Constant.SZWP2300.PROCESS_ID_SEPARATOR + mapParam.get(RequestParam.process.getValue()).toString();
			String lnKbChiku = mapParam.get(RequestParam.lnKbChiku.getValue()).toString();

			SZWP2300JsonModel jsonModel = new SZWP2300JsonModel();
			
			// 利用者アカウント共通論理番号
			jsonModel.setLn_acnt_user_common(acntID);
			
			// 画面ID
			jsonModel.setScreen_id( G6Constant.ScreenID.SZWP2300.getValue());
			
			// 操作フォームID
			jsonModel.setOpe_form_id(opeFormId);
			
			// LN_設置機器論理番号
			jsonModel.setLn_dev(lnDev);
			
			// LN_警備先地区論理番号
			jsonModel.setLn_kb_chiku(lnKbChiku);
			
			switch (G6Constant.OpeFromID.valueOf(opeFormId)) {
			case SZWP2300_000:	// 死活監視
			case SZWP2300_001:	// ライブ閲覧開始
			case SZWP2300_002:	// ライブ閲覧終了
			case SZWP2300_010:	// ライブ閲覧（更新）
//				// アカウント種別（操作権限保持者)
//				jsonModel.setAcnt_type_for_ope(G6Constant.SZWU2900.ACNT_TYPE_FOR_OPE);
				break;
			case SZWP2300_011:	// 操作権限剥奪
//				// アカウント種別（操作権限保持者)
//				jsonModel.setAcnt_type_for_ope(G6Constant.SZWU2900.ACNT_TYPE_FOR_OPE);
				// 操作権限剥奪
				jsonModel.setSelected_for_dialog(selectedForDialog);
				break;
			default:
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
				return jsonResult;
			}
			JSONObject jsonObject = new JSONObject(jsonModel);
			String postJsonData = jsonObject.toString();
			
			// Send post request
			String strResponse = G6Common.sendJsonMsg(postJsonData, MEDIA_API_2300_009);
			Map<String, ?> checkedJson = null;
			
			// 死活監視用
			String strResponseAliveMonitor = null;
			Map<String, ?> checkedJsonAliveMonitor = null;
			
			// JSONデータのnull設定チェック
			if(strResponse != null) {
			    checkedJson = G6Common.jsonValueCheck(strResponse);
            }
			
			if (checkedJson == null) {
				// JSON置換失敗
				jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_RESPONSE_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
				return jsonResult;
			}
			
			if (opeFormId.equals("SZWP2300_000")) {
				strResponseAliveMonitor = checkedJson.get(G6Constant.ResponseParam.alive_monitor.getValue()).toString();
				
				// JSONデータのnull設定チェック(死活監視)
				if(strResponseAliveMonitor != null) {
					checkedJsonAliveMonitor = G6Common.jsonValueCheck(strResponse);
	            }
				
				if (checkedJsonAliveMonitor == null) {
					// JSON置換失敗
					jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.FAIL_POPUP_CD,
							ErrorKey.ERROR_RESPONSE_VALIDATION.getValue(), acntLanguage);
					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
					return jsonResult;
				}
			
				@SuppressWarnings("unchecked")
				ArrayList<HashMap<String, Object>> resultArray = (ArrayList<HashMap<String, Object>>)checkedJsonAliveMonitor.get(G6Constant.ResponseParam.alive_monitor.getValue());
				checkedJsonAliveMonitor = (Map<String, ?>)resultArray.get(0);
				// 取得内容を応答する(死活監視の場合、入れ子の情報をパースする)
				if(G6Constant.SZWP2300.RESULT_OK.equals(checkedJsonAliveMonitor.get(G6Constant.ResponseParam.result.getValue()).toString())) {
	
					// 要求者の操作権限取得情報
					resDisplayLiveImage
					.setHas_ope_auth(checkedJsonAliveMonitor.get(G6Constant.ResponseParam.has_ope_auth.getValue()).toString());
					
					// 操作権限保持者のアカウント種別
					resDisplayLiveImage.setAcnt_type_for_ope(
							checkedJsonAliveMonitor.get(G6Constant.ResponseParam.acnt_type_for_ope.getValue()).toString());
					
					// アカウント論理番号（操作権限保持者）
					if (checkedJsonAliveMonitor.get(G6Constant.ResponseParam.ln_acnt_user_common_for_ope.getValue()) != null) {
						resDisplayLiveImage.setLn_acnt_user_common_for_ope(
								checkedJsonAliveMonitor.get(G6Constant.ResponseParam.ln_acnt_user_common_for_ope.getValue()).toString());
					}
					
					// 操作権限保持者のアカウント名称
					if (checkedJsonAliveMonitor.get(G6Constant.ResponseParam.acnt_name.getValue()) != null) {
						resDisplayLiveImage
						.setAcnt_name(checkedJsonAliveMonitor.get(G6Constant.ResponseParam.acnt_name.getValue()).toString());
					}
					resDisplayLiveImage.setErrorCode(G6Constant.SUCCESS_CD);
				
				} else {
					jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.FAIL_POPUP_CD,
							ErrorKey.ERROR_MEDIA_RESULT.getValue(), acntLanguage);
					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
					return jsonResult;
				}
			}else if (G6Constant.SZWP2300.RESULT_OK.equals(checkedJson.get(G6Constant.ResponseParam.result.getValue()).toString())) {
				resDisplayLiveImage.setErrorCode(G6Constant.SUCCESS_CD);
				switch (G6Constant.OpeFromID.valueOf(opeFormId)) {
				case SZWP2300_001:	// ライブ閲覧開始
				case SZWP2300_010:	// ライブ閲覧（更新）
				case SZWP2300_011:	// 操作権限剥奪
					// PTZ制御の有無
					resDisplayLiveImage.setPtz_enable_flg(
							checkedJson.get(G6Constant.ResponseParam.ptz_enable_flg.getValue()).toString());
					
					// PTZプリセット登録状況
					resDisplayLiveImage.setPreset_status(
							checkedJson.get(G6Constant.ResponseParam.preset_status.getValue()).toString());
					
					// フレームレート
					resDisplayLiveImage
					.setFrame_rate(checkedJson.get(G6Constant.ResponseParam.frame_rate.getValue()).toString());
					
					// 解像度
					resDisplayLiveImage
					.setImg_quality(checkedJson.get(G6Constant.ResponseParam.img_quality.getValue()).toString());
					
					// 映像パラメータ設定可否フラグ
					resDisplayLiveImage.setParam_set_flg(
							checkedJson.get(G6Constant.ResponseParam.param_set_flg.getValue()).toString());
					
					// 要求者の操作権限取得情報
					resDisplayLiveImage
					.setHas_ope_auth(checkedJson.get(G6Constant.ResponseParam.has_ope_auth.getValue()).toString());
					
					// 操作権限保持者のアカウント種別
					resDisplayLiveImage.setAcnt_type_for_ope(
							checkedJson.get(G6Constant.ResponseParam.acnt_type_for_ope.getValue()).toString());
					
					// アカウント論理番号（操作権限保持者）
					resDisplayLiveImage.setLn_acnt_user_common_for_ope(
							checkedJson.get(G6Constant.ResponseParam.ln_acnt_user_common_for_ope.getValue()).toString());
					
					// 操作権限保持者のアカウント名称              
					resDisplayLiveImage
					.setAcnt_name(checkedJson.get(G6Constant.ResponseParam.acnt_name.getValue()).toString());
					
					// URL
					resDisplayLiveImage
							.setUrl(checkedJson.get(G6Constant.ResponseParam.url.getValue()).toString());
					break;
				case SZWP2300_002:	// ライブ閲覧終了
					break;
				default:
					jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.FAIL_POPUP_CD,
							ErrorKey.ERROR_MEDIA_RESULT.getValue(), acntLanguage);
					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
					return jsonResult;
				}
			} else {
				jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_MEDIA_RESULT.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
				return jsonResult;
			}
			
			// デコード済acntIDを設定したJWT認証トークンを付与
			resDisplayLiveImage.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
							
			jsonResult = G6Common.parseJSON(resDisplayLiveImage, acntLanguage);
			
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resDisplayLiveImage, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resDisplayLiveImage, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			jsonResult = G6Common.messageLogHandler(resDisplayLiveImage, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
		}
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.displayLiveImage()");
		return jsonResult;
	}

	/*
	 * コントローラにライブカメラ指定コマンド送信
	 * @param: acntID, sdDevNum, process, screenSize, frameRate, preset
	 * return: object ErrorDataModel as JSON
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/controlCamera", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String controlCamera(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2300Controller.controlCamera()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResControlCamera resControlCamera = new ResControlCamera();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntID = "";
		String acntNm = "";
		
		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
            
			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
				acntLanguage = commonComService.getLanguageType(acntID);
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 13) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
				return jsonResult;
			}
			// Build require parameters
			if (!mapParam.containsKey(RequestParam.process.getValue())) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
				return jsonResult;
			}
			String opeFormId = G6Constant.ScreenID.SZWP2300.getValue() + G6Constant.SZWP2300.PROCESS_ID_SEPARATOR + mapParam.get(RequestParam.process.getValue()).toString();
			
			Map<String, Boolean> lstRequiredParam = new HashMap<String, Boolean>();
			lstRequiredParam.put(RequestParam.acntID.getValue(), true);
			lstRequiredParam.put(RequestParam.acntNm.getValue(), true);
			lstRequiredParam.put(RequestParam.lnDev.getValue(), true);
			lstRequiredParam.put(RequestParam.lnKbChiku.getValue(), false);
			lstRequiredParam.put(RequestParam.sdDevNum.getValue(), true);
			lstRequiredParam.put(RequestParam.process.getValue(), true);
			lstRequiredParam.put(RequestParam.imgQuality.getValue(), false);
			lstRequiredParam.put(RequestParam.frameRate.getValue(), false);
			lstRequiredParam.put(RequestParam.pan.getValue(), false);
			lstRequiredParam.put(RequestParam.tilt.getValue(), false);
			lstRequiredParam.put(RequestParam.zoom.getValue(), false);
			lstRequiredParam.put(RequestParam.presetNum.getValue(), false);
			lstRequiredParam.put(RequestParam.controlKbn.getValue(), false);
			
			switch (G6Constant.OpeFromID.valueOf(opeFormId)) {
			case SZWP2300_003:
			case SZWP2300_004:
			case SZWP2300_005:
				lstRequiredParam.put(RequestParam.pan.getValue(), true);
				lstRequiredParam.put(RequestParam.tilt.getValue(), true);
				lstRequiredParam.put(RequestParam.zoom.getValue(), true);
				lstRequiredParam.put(RequestParam.controlKbn.getValue(), true);
				break;
			case SZWP2300_006:	// 解像度変更
			case SZWP2300_007:	// フレームレート変更
				lstRequiredParam.put(RequestParam.imgQuality.getValue(), true);
				lstRequiredParam.put(RequestParam.frameRate.getValue(), true);
				break;
			case SZWP2300_008:	// プリセット（制御）
			case SZWP2300_009:	// プリセット（登録）
//				// アカウント種別（操作権限保持者)
//				jsonModel.setAcnt_type_for_ope(G6Constant.SZWU2900.ACNT_TYPE_FOR_OPE);
				// プリセット情報（プリセット番号）
				lstRequiredParam.put(RequestParam.presetNum.getValue(), true);
				// プリセット情報（制御区分）
				lstRequiredParam.put(RequestParam.controlKbn.getValue(), true);
				break;
			default:
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
				return jsonResult;
			}
			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
				return jsonResult;
			}
			// リクエスト情報取得
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			
			// unused: リクエスト情報からアカウント種別を取得する

			// TODO SZWP2300：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);
			String lnDev = mapParam.get(RequestParam.lnDev.getValue()).toString();
			List<String> sdDevNumList = G6Common.readParamToArrayObject(mapParam, RequestParam.sdDevNum.getValue());
			String sdDevNum = sdDevNumList.get(0);
			String lnKbChiku = commonService.getChikuInfoFromLnDev(lnDev).getLnKbChiku();
			
			SZWP2300JsonModel jsonModel = new SZWP2300JsonModel();
			// 利用者アカウント共通論理番号
			jsonModel.setLn_acnt_user_common(acntID);
			// 画面ID
			jsonModel.setScreen_id( G6Constant.ScreenID.SZWP2300.getValue());
			// 操作フォームID
			jsonModel.setOpe_form_id(opeFormId);
			// LN_警備先地区論理番号
			jsonModel.setLn_kb_chiku(lnKbChiku);
			// 解像度
			jsonModel.setImg_quality(mapParam.get(RequestParam.imgQuality.getValue()).toString());
			// フレームレート
			jsonModel.setFrame_rate(mapParam.get(RequestParam.frameRate.getValue()).toString());
			// LN_設置機器論理番号
			jsonModel.setLn_dev(lnDev);
			// PTZ情報（パン）
			jsonModel.setPan(mapParam.get(RequestParam.pan.getValue()).toString());
			// PTZ情報（チルト）
			jsonModel.setTilt(mapParam.get(RequestParam.tilt.getValue()).toString());
			// PTZ情報（ズーム）
			jsonModel.setZoom(mapParam.get(RequestParam.zoom.getValue()).toString());
			// プリセット情報（プリセット番号）
			jsonModel.setPreset_num(mapParam.get(RequestParam.presetNum.getValue()).toString());
			// プリセット情報（制御区分）
			jsonModel.setControl_kbn(mapParam.get(RequestParam.controlKbn.getValue()).toString());
			// カメラ番号
			jsonModel.setCamera_num(sdDevNum);
			
			JSONObject jsonObject = new JSONObject(jsonModel);
			String postJsonData = jsonObject.toString();
			// Send post request
			String strResponse = G6Common.sendJsonMsg(postJsonData, MEDIA_API_2300_CAMCTRL);
			Map<String, ?> checkedJson = null;
			if(strResponse != null) {
				checkedJson = G6Common.jsonValueCheck(strResponse);
            }
			if ( checkedJson == null) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_RESPONSE_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
				return jsonResult;
			}
			if (G6Constant.SZWP2300.RESULT_OK.equals(checkedJson.get(G6Constant.ResponseParam.result.getValue()).toString())) {
				resControlCamera.setErrorCode(G6Constant.SUCCESS_CD);
				// 要求者の操作権限取得情報
				resControlCamera.setHas_ope_auth(checkedJson.get(G6Constant.ResponseParam.has_ope_auth.getValue()).toString());
				// 操作権限保持者のアカウント種別
				resControlCamera.setAcnt_type_for_ope(checkedJson.get(G6Constant.ResponseParam.acnt_type_for_ope.getValue()).toString());
				// 操作権限保持者のアカウント名称               
				resControlCamera.setAcnt_name(checkedJson.get(G6Constant.ResponseParam.acnt_name.getValue()).toString());
			} else {
				jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_MEDIA_RESULT.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
				return jsonResult;
			}
			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//			// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//			final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//			hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP2300.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm, DateTimeCommon.getCurrentDate());
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());	// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);														// アカウント名
			hUserOperationLogModel.setLnKeibi(mapParam.get(RequestParam.lnKeibi.getValue()).toString());	// 警備先論理番号
			hUserOperationLogModel.setLnKbChiku(mapParam.get(RequestParam.lnKbChiku.getValue()).toString());// 警備先地区論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP2300.getValueForOperationLog());					// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);
			
			// デコード済acntIDを設定したJWT認証トークンを付与
			resControlCamera.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
						
			jsonResult = G6Common.parseJSON(resControlCamera, acntLanguage);
			
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resControlCamera, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resControlCamera, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resControlCamera, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resControlCamera, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2300Controller.controlCamera()");
		return jsonResult;
	}
}
