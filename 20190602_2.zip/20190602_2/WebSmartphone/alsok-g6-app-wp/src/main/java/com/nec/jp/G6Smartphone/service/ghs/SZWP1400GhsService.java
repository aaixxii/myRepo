package com.nec.jp.G6Smartphone.service.ghs;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.HistoryDataModel;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP1400GhsDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1400GhsService {

	@Autowired
	SZWP1400GhsDao sZWP1400Dao;

	public List<HistoryDataModel> getDistrictPulldownInfoGHS(String lnKeibi, String chiku, Date dtFrom, Date dtTo, Set<String> type1, String ghsType, int offset, int limitRowNum) throws ApplicationException {
		try {
			List<HistoryDataModel> historyDataModelList = sZWP1400Dao.getDistrictPulldownInfoGHS(lnKeibi, chiku, dtFrom, dtTo, type1, ghsType, offset, limitRowNum);

			return historyDataModelList;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public int getTotalRow(String lnKeibi, String chiku, Date dtFrom, Date dtTo, Set<String> type1, String ghsType) throws ApplicationException {
		try {
			return sZWP1400Dao.getTotalRow(lnKeibi, chiku, dtFrom, dtTo, type1, ghsType).intValue();
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
