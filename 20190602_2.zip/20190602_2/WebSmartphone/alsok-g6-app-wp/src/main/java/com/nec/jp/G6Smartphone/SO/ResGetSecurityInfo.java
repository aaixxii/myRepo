package com.nec.jp.G6Smartphone.SO;

public class ResGetSecurityInfo {

	private String juchuJigyouCd;
	private String jisshiJigyouCd;
	private String gcCd;
	private String customerNum;
	private String picSurveillanceFlg;
	public ResGetSecurityInfo() {
		this.juchuJigyouCd = "";
		this.jisshiJigyouCd = "";
		this.gcCd = "";
		this.customerNum = "";
		this.picSurveillanceFlg = "";
	}
	public ResGetSecurityInfo(String juchuJigyouCd, String jisshiJigyouCd, String gcCd, String customerNum, String picSurveillanceFlg) {
		this.juchuJigyouCd = juchuJigyouCd;
		this.jisshiJigyouCd = jisshiJigyouCd;
		this.gcCd = gcCd;
		this.customerNum = customerNum;
		this.picSurveillanceFlg = picSurveillanceFlg;
	}
	public String getJuchuJigyouCd() {
		return juchuJigyouCd;
	}
	public void setJuchuJigyouCd(String juchuJigyouCd) {
		this.juchuJigyouCd = juchuJigyouCd;
	}
	public String getJisshiJigyouCd() {
		return jisshiJigyouCd;
	}
	public void setJisshiJigyouCd(String jisshiJigyouCd) {
		this.jisshiJigyouCd = jisshiJigyouCd;
	}
	public String getGcCd() {
		return gcCd;
	}
	public void setGcCd(String gcCd) {
		this.gcCd = gcCd;
	}
	public String getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(String customerNum) {
		this.customerNum = customerNum;
	}
	public String getPicSurveillanceFlg() {
		return picSurveillanceFlg;
	}
	public void setPicSurveillanceFlg(String picSurveillanceFlg) {
		this.picSurveillanceFlg = picSurveillanceFlg;
	}
}
