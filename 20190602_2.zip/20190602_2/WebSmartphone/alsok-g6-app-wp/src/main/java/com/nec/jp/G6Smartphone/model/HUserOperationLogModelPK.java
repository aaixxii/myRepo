package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;

/**
 * The primary key class for the H_USER_OPERATION_LOG database table.
 * 
 */
@Embeddable
public class HUserOperationLogModelPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="LN_KEIYK")
	private String lnKeiyk;
	
	@Column(name="LN_LOG_USER_OPERATION")
	private String lnLogUserOperation;

	public String getLnKeiyk() {
		return lnKeiyk;
	}

	public void setLnKeiyk(String lnKeiyk) {
		this.lnKeiyk = lnKeiyk;
	}

	public String getLnLogUserOperation() {
		return lnLogUserOperation;
	}

	public void setLnLogUserOperation(String lnLogUserOperation) {
		this.lnLogUserOperation = lnLogUserOperation;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof HUserOperationLogModelPK)) {
			return false;
		}
		HUserOperationLogModelPK castOther = (HUserOperationLogModelPK)other;
		return 
			this.lnKeiyk.equals(castOther.lnKeiyk)
			&& this.lnLogUserOperation.equals(castOther.lnLogUserOperation);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.lnKeiyk.hashCode();
		hash = hash * prime + this.lnLogUserOperation.hashCode();
		
		return hash;
	}
}