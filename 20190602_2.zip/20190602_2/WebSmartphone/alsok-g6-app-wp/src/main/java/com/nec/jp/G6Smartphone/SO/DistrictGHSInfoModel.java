package com.nec.jp.G6Smartphone.SO;

import javax.persistence.ColumnResult;

public class DistrictGHSInfoModel {
	private String lnKbChiku;
	private String subAddr;
	private String sdKobetuNm;
	
	public DistrictGHSInfoModel() {
		this.lnKbChiku = "";
		this.subAddr = "";
		this.sdKobetuNm = "";
	}
	
	public DistrictGHSInfoModel(String lnKbChiku, String subAddr, String sdKobetuNm) {
		this.lnKbChiku = lnKbChiku;
		this.subAddr = subAddr;
		this.sdKobetuNm = sdKobetuNm;
	}

	public String getLnKbChiku() {
		return lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getSubAddr() {
		return subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public String getSdKobetuNm() {
		return sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}
}
