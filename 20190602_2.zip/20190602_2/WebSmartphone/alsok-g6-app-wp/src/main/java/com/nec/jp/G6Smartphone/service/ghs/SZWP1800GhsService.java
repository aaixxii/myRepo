package com.nec.jp.G6Smartphone.service.ghs;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.HAlsokNoticeDataModel;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP1800GhsDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1800GhsService {

	@Autowired
	SZWP1800GhsDao sZWP1800Dao;

	public List<HAlsokNoticeDataModel> getNoticeInfoListKeiyk(Date dtFrom, Date dtTo, String acntID, int offset, int limitRowNum) throws ApplicationException {
		try {
			List<HAlsokNoticeDataModel> eAlsokNoticeDataModelLst = sZWP1800Dao.getNoticeInfoListKeiyk(dtFrom, dtTo, acntID, offset, limitRowNum);

			return eAlsokNoticeDataModelLst;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public List<HAlsokNoticeDataModel> getNoticeInfoListUser(Date dtFrom, Date dtTo, String acntID, int offset, int limitRowNum) throws ApplicationException {
		try {
			List<HAlsokNoticeDataModel> eAlsokNoticeDataModelLst = sZWP1800Dao.getNoticeInfoListUser(dtFrom, dtTo, acntID, offset, limitRowNum);

			return eAlsokNoticeDataModelLst;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public int getTotalRowListKeiyk(Date dtFrom, Date dtTo, String acntID) throws ApplicationException {
		try {
			return Integer.parseInt(sZWP1800Dao.getTotalRowListKeiyk(dtFrom, dtTo, acntID));
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public int getTotalRowListUser(Date dtFrom, Date dtTo, String acntID) throws ApplicationException {
		try {
			return Integer.parseInt(sZWP1800Dao.getTotalRowListUser(dtFrom, dtTo, acntID));
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
