package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the R_KB_CHIKU_STS database table.
 * 
 */
@Entity
@Table(name="R_KB_CHIKU_STS")
@NamedQuery(name="RKbChikuStModel.findAll", query="SELECT r FROM RKbChikuStModel r")
public class RKbChikuStModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;

	@Column(name="AUTO_KB_SET_STS")
	private String autoKbSetSts;

	@Column(name="AUTO_SET_MAIL_FLG")
	private String autoSetMailFlg;

	@Column(name="DEL_FLG")
	private String delFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DF0_TS")
	private Date df0Ts;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DN0_TS")
	private Date dn0Ts;

	@Column(name="DN0DF0_FLG")
	private String dn0df0Flg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EMP_STS_CHANGE_TS")
	private Date empStsChangeTs;

	@Column(name="EMP_STS_FLG")
	private String empStsFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EMP_TS")
	private Date empTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="EMPR_TS")
	private Date emprTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="F0_TS")
	private Date f0Ts;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="KF_TS")
	private Date kfTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="KN_TS")
	private Date knTs;

	@Column(name="KNKF_FLG")
	private String knkfFlg;

	@Column(name="LAST_KB_MAIL_FLG")
	private String lastKbMailFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_KEIHOU_RCV_TS")
	private Date lastKeihouRcvTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_SENSOR_INF_RCV_TS")
	private Date lastSensorInfRcvTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_SIG_RCV_TS")
	private Date lastSigRcvTs;

	@Column(name="LN_KB_INF_DF0")
	private String lnKbInfDf0;

	@Column(name="LN_KB_INF_DN0")
	private String lnKbInfDn0;

	@Column(name="LN_KB_INF_EMP")
	private String lnKbInfEmp;

	@Column(name="LN_KB_INF_EMPR")
	private String lnKbInfEmpr;

	@Column(name="LN_KB_INF_F0")
	private String lnKbInfF0;

	@Column(name="LN_KB_INF_KF")
	private String lnKbInfKf;

	@Column(name="LN_KB_INF_KN")
	private String lnKbInfKn;

	@Column(name="LN_KB_INF_N0")
	private String lnKbInfN0;

	@Column(name="LN_KB_INF_ZF0")
	private String lnKbInfZf0;

	@Column(name="LN_KB_INF_ZN0")
	private String lnKbInfZn0;

	@Column(name="LN_LAST_KEIHOU")
	private String lnLastKeihou;

	@Column(name="LN_LAST_SENSOR_INF_HIS")
	private String lnLastSensorInfHis;

	@Column(name="LN_LAST_SIG")
	private String lnLastSig;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LOOP_BREAK_SET_TS")
	private Date loopBreakSetTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LOOP_MAKE_SET_TS")
	private Date loopMakeSetTs;

	@Column(name="LOOP_STS")
	private String loopSts;

	@Column(name="MUJIN_MAIL_FLG")
	private String mujinMailFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="N0_TS")
	private Date n0Ts;

	@Column(name="N0F0_FLG")
	private String n0f0Flg;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ZF0_TS")
	private Date zf0Ts;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="ZN0_TS")
	private Date zn0Ts;

	public RKbChikuStModel() {
	}

	public String getLnKbChiku() {
		return this.lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getAutoKbSetSts() {
		return this.autoKbSetSts;
	}

	public void setAutoKbSetSts(String autoKbSetSts) {
		this.autoKbSetSts = autoKbSetSts;
	}

	public String getAutoSetMailFlg() {
		return this.autoSetMailFlg;
	}

	public void setAutoSetMailFlg(String autoSetMailFlg) {
		this.autoSetMailFlg = autoSetMailFlg;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public Date getDf0Ts() {
		return this.df0Ts;
	}

	public void setDf0Ts(Date df0Ts) {
		this.df0Ts = df0Ts;
	}

	public Date getDn0Ts() {
		return this.dn0Ts;
	}

	public void setDn0Ts(Date dn0Ts) {
		this.dn0Ts = dn0Ts;
	}

	public String getDn0df0Flg() {
		return this.dn0df0Flg;
	}

	public void setDn0df0Flg(String dn0df0Flg) {
		this.dn0df0Flg = dn0df0Flg;
	}

	public Date getEmpStsChangeTs() {
		return this.empStsChangeTs;
	}

	public void setEmpStsChangeTs(Date empStsChangeTs) {
		this.empStsChangeTs = empStsChangeTs;
	}

	public String getEmpStsFlg() {
		return this.empStsFlg;
	}

	public void setEmpStsFlg(String empStsFlg) {
		this.empStsFlg = empStsFlg;
	}

	public Date getEmpTs() {
		return this.empTs;
	}

	public void setEmpTs(Date empTs) {
		this.empTs = empTs;
	}

	public Date getEmprTs() {
		return this.emprTs;
	}

	public void setEmprTs(Date emprTs) {
		this.emprTs = emprTs;
	}

	public Date getF0Ts() {
		return this.f0Ts;
	}

	public void setF0Ts(Date f0Ts) {
		this.f0Ts = f0Ts;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public Date getKfTs() {
		return this.kfTs;
	}

	public void setKfTs(Date kfTs) {
		this.kfTs = kfTs;
	}

	public Date getKnTs() {
		return this.knTs;
	}

	public void setKnTs(Date knTs) {
		this.knTs = knTs;
	}

	public String getKnkfFlg() {
		return this.knkfFlg;
	}

	public void setKnkfFlg(String knkfFlg) {
		this.knkfFlg = knkfFlg;
	}

	public String getLastKbMailFlg() {
		return this.lastKbMailFlg;
	}

	public void setLastKbMailFlg(String lastKbMailFlg) {
		this.lastKbMailFlg = lastKbMailFlg;
	}

	public Date getLastKeihouRcvTs() {
		return this.lastKeihouRcvTs;
	}

	public void setLastKeihouRcvTs(Date lastKeihouRcvTs) {
		this.lastKeihouRcvTs = lastKeihouRcvTs;
	}

	public Date getLastSensorInfRcvTs() {
		return this.lastSensorInfRcvTs;
	}

	public void setLastSensorInfRcvTs(Date lastSensorInfRcvTs) {
		this.lastSensorInfRcvTs = lastSensorInfRcvTs;
	}

	public Date getLastSigRcvTs() {
		return this.lastSigRcvTs;
	}

	public void setLastSigRcvTs(Date lastSigRcvTs) {
		this.lastSigRcvTs = lastSigRcvTs;
	}

	public String getLnKbInfDf0() {
		return this.lnKbInfDf0;
	}

	public void setLnKbInfDf0(String lnKbInfDf0) {
		this.lnKbInfDf0 = lnKbInfDf0;
	}

	public String getLnKbInfDn0() {
		return this.lnKbInfDn0;
	}

	public void setLnKbInfDn0(String lnKbInfDn0) {
		this.lnKbInfDn0 = lnKbInfDn0;
	}

	public String getLnKbInfEmp() {
		return this.lnKbInfEmp;
	}

	public void setLnKbInfEmp(String lnKbInfEmp) {
		this.lnKbInfEmp = lnKbInfEmp;
	}

	public String getLnKbInfEmpr() {
		return this.lnKbInfEmpr;
	}

	public void setLnKbInfEmpr(String lnKbInfEmpr) {
		this.lnKbInfEmpr = lnKbInfEmpr;
	}

	public String getLnKbInfF0() {
		return this.lnKbInfF0;
	}

	public void setLnKbInfF0(String lnKbInfF0) {
		this.lnKbInfF0 = lnKbInfF0;
	}

	public String getLnKbInfKf() {
		return this.lnKbInfKf;
	}

	public void setLnKbInfKf(String lnKbInfKf) {
		this.lnKbInfKf = lnKbInfKf;
	}

	public String getLnKbInfKn() {
		return this.lnKbInfKn;
	}

	public void setLnKbInfKn(String lnKbInfKn) {
		this.lnKbInfKn = lnKbInfKn;
	}

	public String getLnKbInfN0() {
		return this.lnKbInfN0;
	}

	public void setLnKbInfN0(String lnKbInfN0) {
		this.lnKbInfN0 = lnKbInfN0;
	}

	public String getLnKbInfZf0() {
		return this.lnKbInfZf0;
	}

	public void setLnKbInfZf0(String lnKbInfZf0) {
		this.lnKbInfZf0 = lnKbInfZf0;
	}

	public String getLnKbInfZn0() {
		return this.lnKbInfZn0;
	}

	public void setLnKbInfZn0(String lnKbInfZn0) {
		this.lnKbInfZn0 = lnKbInfZn0;
	}

	public String getLnLastKeihou() {
		return this.lnLastKeihou;
	}

	public void setLnLastKeihou(String lnLastKeihou) {
		this.lnLastKeihou = lnLastKeihou;
	}

	public String getLnLastSensorInfHis() {
		return this.lnLastSensorInfHis;
	}

	public void setLnLastSensorInfHis(String lnLastSensorInfHis) {
		this.lnLastSensorInfHis = lnLastSensorInfHis;
	}

	public String getLnLastSig() {
		return this.lnLastSig;
	}

	public void setLnLastSig(String lnLastSig) {
		this.lnLastSig = lnLastSig;
	}

	public Date getLoopBreakSetTs() {
		return this.loopBreakSetTs;
	}

	public void setLoopBreakSetTs(Date loopBreakSetTs) {
		this.loopBreakSetTs = loopBreakSetTs;
	}

	public Date getLoopMakeSetTs() {
		return this.loopMakeSetTs;
	}

	public void setLoopMakeSetTs(Date loopMakeSetTs) {
		this.loopMakeSetTs = loopMakeSetTs;
	}

	public String getLoopSts() {
		return this.loopSts;
	}

	public void setLoopSts(String loopSts) {
		this.loopSts = loopSts;
	}

	public String getMujinMailFlg() {
		return this.mujinMailFlg;
	}

	public void setMujinMailFlg(String mujinMailFlg) {
		this.mujinMailFlg = mujinMailFlg;
	}

	public Date getN0Ts() {
		return this.n0Ts;
	}

	public void setN0Ts(Date n0Ts) {
		this.n0Ts = n0Ts;
	}

	public String getN0f0Flg() {
		return this.n0f0Flg;
	}

	public void setN0f0Flg(String n0f0Flg) {
		this.n0f0Flg = n0f0Flg;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public Date getZf0Ts() {
		return this.zf0Ts;
	}

	public void setZf0Ts(Date zf0Ts) {
		this.zf0Ts = zf0Ts;
	}

	public Date getZn0Ts() {
		return this.zn0Ts;
	}

	public void setZn0Ts(Date zn0Ts) {
		this.zn0Ts = zn0Ts;
	}

}