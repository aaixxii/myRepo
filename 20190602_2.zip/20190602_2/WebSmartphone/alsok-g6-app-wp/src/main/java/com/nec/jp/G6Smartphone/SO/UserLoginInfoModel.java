package com.nec.jp.G6Smartphone.SO;

public class UserLoginInfoModel extends SZWP0000Info{

	private String lnAcntUserCommon;		// 利用者アカウント共通.LN_利用者アカウント共通論理番号
	private String acntNm;					// 利用者アカウント共通.アカウント名称
	private String passwd;
	private String mlSendSts;
	private String checkSts;
	private String lastLoginTs;				// 利用者アカウント.前回ログイン日時
	private String acntUserKbn;	
	private String acntSbt;
	private String mlAddr; //メールアドレス

	public UserLoginInfoModel() {
		this.lnAcntUserCommon = "";
		this.acntNm = "";
		this.passwd = "";
		this.mlSendSts = "";
		this.checkSts = "";
		this.lastLoginTs = "";
		this.acntUserKbn = "";
		this.acntSbt = "";
		this.mlAddr = "";
	}

	public UserLoginInfoModel(String lnAcntUserCommon, String acntNm, String passwd, String mlSendSts, String checkSts,
			String lastLoginTs, String acntUserKbn, String acntSbt) {
		this.lnAcntUserCommon = lnAcntUserCommon;
		this.acntNm = acntNm;
		this.passwd = passwd;
		this.mlSendSts = mlSendSts;
		this.checkSts = checkSts;
		this.lastLoginTs = lastLoginTs;
		this.acntUserKbn = acntUserKbn;
		this.acntSbt = acntSbt;
		this.mlAddr = "";
	}
	
	

	public UserLoginInfoModel(String lnAcntUserCommon, String acntNm, String mlAddr, String passwd, String mlSendSts, String checkSts,
			String lastLoginTs, String acntUserKbn, String acntSbt) {
		this.lnAcntUserCommon = lnAcntUserCommon;
		this.acntNm = acntNm;
		this.mlAddr = mlAddr;
		this.passwd = passwd;
		this.mlSendSts = mlSendSts;
		this.checkSts = checkSts;
		this.lastLoginTs = lastLoginTs;
		this.acntUserKbn = acntUserKbn;
		this.acntSbt = acntSbt;
	}

	public String getMlAddr() {
		return mlAddr;
	}
	public void setMlAddr(String mlAddr) {
		this.mlAddr = mlAddr;
	}
	public String getLnAcntUserCommon() {
		return lnAcntUserCommon;
	}

	public void setLnAcntUserCommon(String lnAcntUserCommon) {
		this.lnAcntUserCommon = lnAcntUserCommon;
	}

	public String getAcntNm() {
		return acntNm;
	}

	public void setAcntNm(String acntNm) {
		this.acntNm = acntNm;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getMlSendSts() {
		return mlSendSts;
	}

	public void setMlSendSts(String mlSendSts) {
		this.mlSendSts = mlSendSts;
	}

	public String getCheckSts() {
		return checkSts;
	}

	public void setCheckSts(String checkSts) {
		this.checkSts = checkSts;
	}

	public String getLastLoginTs() {
		return lastLoginTs;
	}

	public void setLastLoginTs(String lastLoginTs) {
		this.lastLoginTs = lastLoginTs;
	}

	public String getAcntUserKbn() {
		return acntUserKbn;
	}

	public void setAcntUserKbn(String acntUserKbn) {
		this.acntUserKbn = acntUserKbn;
	}

	public String getAcntSbt() {
		return acntSbt;
	}

	public void setAcntSbt(String acntSbt) {
		this.acntSbt = acntSbt;
	}
}
