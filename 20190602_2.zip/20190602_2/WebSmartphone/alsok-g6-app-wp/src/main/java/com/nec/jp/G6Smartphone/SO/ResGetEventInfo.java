package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetEventInfo  implements ErrorHandler {
	
	private String errorCode;			// エラーコード
	private String errorMsg;			// エラーメッセージ
	private List<HEventInfoDataModel> hEventInfoItem;
	private String acntID;
	private String totalPage; 			//トタルページ
	
	public ResGetEventInfo() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.hEventInfoItem = new ArrayList<HEventInfoDataModel>();
		this.acntID = "";
	}
	
	public ResGetEventInfo(String errorCode, String errorMsg, List<HEventInfoDataModel> hEventInfoDataModel, String totalPage) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.hEventInfoItem = hEventInfoDataModel;
		this.acntID = "";
		this.totalPage = totalPage;
	}
	
	public String getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(String totalPage) {
		this.totalPage = totalPage;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public List<HEventInfoDataModel> gethEventInfoItem() {
		return hEventInfoItem;
	}
	public void sethEventInfoItem(List<HEventInfoDataModel> hEventInfoItem) {
		this.hEventInfoItem = hEventInfoItem;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
