package com.nec.jp.G6Smartphone.SO;

public interface ErrorHandler {

	public String getErrorCode();

	public void setErrorCode(String errorCode);

	public String getErrorMsg();

	public void setErrorMsg(String errorMsg);
}
