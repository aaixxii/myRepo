package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.AcntUserAuthModel;
import com.nec.jp.G6Smartphone.SO.AcntUserInfoModel;
import com.nec.jp.G6Smartphone.SO.ItmesAuthInfoModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RDenkeiMngInfoModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuInfoModel;
import com.nec.jp.G6Smartphone.SO.RKbInfoModel;
import com.nec.jp.G6Smartphone.SO.RKeibiGHSModel;
import com.nec.jp.G6Smartphone.SO.WKbChikuRmInfoModel;


/**
 * The persistent class for the R_CTL_DEV database table.
 * 
 */
@SqlResultSetMappings ({
	@SqlResultSetMapping(name="RCtlDevDataSubModelResult",
		classes = {
			@ConstructorResult(
				targetClass = RCtlDevDataSubModel.class,
				columns = {
					@ColumnResult(name = "lnCtlDev"),
					@ColumnResult(name = "gouKi"),
					@ColumnResult(name = "serialNum"),
					@ColumnResult(name = "sdLineKind")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RCtlDevDataSubModel1100Result",
		classes = {
			@ConstructorResult(
				targetClass = RKeibiGHSModel.class,
				columns = {
					@ColumnResult(name = "gouKi"),
					@ColumnResult(name = "serialNum"),
				}
			)
		}
	),
	@SqlResultSetMapping(name="RCtlDevDataSubModel400Result",
		classes = {
			@ConstructorResult(
				targetClass = RCtlDevDataSubModel.class,
				columns = {
					@ColumnResult(name = "lnKeibi"),
					@ColumnResult(name = "subAddr"),
					@ColumnResult(name = "gouKi"),
					@ColumnResult(name = "serialNum"),
					@ColumnResult(name = "sdLineKind"),
					@ColumnResult(name = "customerNum1"),
					@ColumnResult(name = "lnDev")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RCtlDevDataSubModel800Result",
		classes = {
			@ConstructorResult(
				targetClass = RCtlDevDataSubModel.class,
				columns = {
					@ColumnResult(name = "lnKeibi"),
					@ColumnResult(name = "subAddr"),
					@ColumnResult(name = "gouKi"),
					@ColumnResult(name = "serialNum"),
					@ColumnResult(name = "sdLineKind"),
					@ColumnResult(name = "customerNum1")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RKbInfoModel0800GHSResult",
		classes = {
			@ConstructorResult(
				targetClass = RKbInfoModel.class,
				columns = {
					@ColumnResult(name = "lnKeibi"),
					@ColumnResult(name = "gouKi"),
					@ColumnResult(name = "serialNum"),
					@ColumnResult(name = "sdKeiykType")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RKbChikuInfoModel0800GHSResult",
		classes = {
			@ConstructorResult(
				targetClass = RKbChikuInfoModel.class,
				columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "lnKeibi"),
					@ColumnResult(name = "chiku"),
					@ColumnResult(name = "subAddr"),
					@ColumnResult(name = "sdKobetuNm"),
					@ColumnResult(name = "gyoumuCd"),
					@ColumnResult(name = "hosokuCd")
				}
			)
		}
	),
	@SqlResultSetMapping(name="AcntUserInfoModelResult",
		classes = {
			@ConstructorResult(
				targetClass = AcntUserInfoModel.class,
				columns = {
					@ColumnResult(name = "acntUserKbn"),
					@ColumnResult(name = "lnUserRole")
				}
			)
		}
	),
	@SqlResultSetMapping(name="ItmesAuthInfoModelResult",
		classes = {
			@ConstructorResult(
				targetClass = ItmesAuthInfoModel.class,
				columns = {
					@ColumnResult(name = "menupassInf"),
					@ColumnResult(name = "userAcntAuthNm"),
					@ColumnResult(name = "menuAuth")
				}
			)
		}
	),
	@SqlResultSetMapping(name="AcntUserAuthModelResult",
		classes = {
			@ConstructorResult(
				targetClass = AcntUserAuthModel.class,
				columns = {
					@ColumnResult(name = "flgKbSetDisp"),
					@ColumnResult(name = "flgKbHstDisp"),
					@ColumnResult(name = "flgRmtKbSetDisp"),
					@ColumnResult(name = "flgKnrnDisp"),
					@ColumnResult(name = "flgWasureDisp"),
					@ColumnResult(name = "flgKusituDisp"),
					@ColumnResult(name = "flgCardDisp")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RDenkiMngInfo0800GHSModel",
		classes = {
			@ConstructorResult(
				targetClass = RDenkeiMngInfoModel.class,
				columns = {
					@ColumnResult(name = "lnDenkeiMng"),
					@ColumnResult(name = "denkei")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RKbChikuRmSetInfo0800GHSModel",
		classes = {
			@ConstructorResult(
				targetClass = WKbChikuRmInfoModel.class,
				columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "kbSetStsNo"),
					@ColumnResult(name = "rmSetTs")
				}
			)
		}
	),
	@SqlResultSetMapping(name="EQueCtrlInfo0800GHSModel",
		classes = {
			@ConstructorResult(
				targetClass = EQueCtrlModel.class,
				columns = {
					@ColumnResult(name = "lnQueCtrl"),
					@ColumnResult(name = "sts")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RCtlDevDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = RCtlDevDataModel.class,
				columns = {
					@ColumnResult(name = "serialNum"),
					@ColumnResult(name = "gouKi"),
					@ColumnResult(name = "sdLineKind")
				}
			)
		}
	)
})
@Entity
@Table(name="R_CTL_DEV")
@NamedQuery(name="RCtlDevModel.findAll", query="SELECT r FROM RCtlDevModel r")
public class RCtlDevModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_CTL_DEV")
	private String lnCtlDev;

	@Column(name="DANSEN_BACKUP_FLG")
	private String dansenBackupFlg;

	@Column(name="DANSEN_MEIN_FLG")
	private String dansenMeinFlg;

	@Column(name="DEL_FLG")
	private String delFlg;

	@Column(name="GOUKI")
	private String gouki;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="KOBETSU_DAN_INT_IP")
	private String kobetsuDanIntIp;

	@Column(name="KOBETSU_DAN_INT_LTE")
	private String kobetsuDanIntLte;

	@Column(name="LN_DEV")
	private String lnDev;

	@Column(name="SD_LINE_KIND")
	private String sdLineKind;

	@Column(name="SD_WL_APN_NUM")
	private String sdWlApnNum;

	@Column(name="SERIAL_NUM")
	private String serialNum;

	@Column(name="TEIHATU_FLG")
	private String teihatuFlg;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public RCtlDevModel() {
	}

	public String getLnCtlDev() {
		return this.lnCtlDev;
	}

	public void setLnCtlDev(String lnCtlDev) {
		this.lnCtlDev = lnCtlDev;
	}

	public String getDansenBackupFlg() {
		return this.dansenBackupFlg;
	}

	public void setDansenBackupFlg(String dansenBackupFlg) {
		this.dansenBackupFlg = dansenBackupFlg;
	}

	public String getDansenMeinFlg() {
		return this.dansenMeinFlg;
	}

	public void setDansenMeinFlg(String dansenMeinFlg) {
		this.dansenMeinFlg = dansenMeinFlg;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getGouki() {
		return this.gouki;
	}

	public void setGouki(String gouki) {
		this.gouki = gouki;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getKobetsuDanIntIp() {
		return this.kobetsuDanIntIp;
	}

	public void setKobetsuDanIntIp(String kobetsuDanIntIp) {
		this.kobetsuDanIntIp = kobetsuDanIntIp;
	}

	public String getKobetsuDanIntLte() {
		return this.kobetsuDanIntLte;
	}

	public void setKobetsuDanIntLte(String kobetsuDanIntLte) {
		this.kobetsuDanIntLte = kobetsuDanIntLte;
	}

	public String getLnDev() {
		return this.lnDev;
	}

	public void setLnDev(String lnDev) {
		this.lnDev = lnDev;
	}

	public String getSdLineKind() {
		return this.sdLineKind;
	}

	public void setSdLineKind(String sdLineKind) {
		this.sdLineKind = sdLineKind;
	}

	public String getSdWlApnNum() {
		return this.sdWlApnNum;
	}

	public void setSdWlApnNum(String sdWlApnNum) {
		this.sdWlApnNum = sdWlApnNum;
	}

	public String getSerialNum() {
		return this.serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getTeihatuFlg() {
		return this.teihatuFlg;
	}

	public void setTeihatuFlg(String teihatuFlg) {
		this.teihatuFlg = teihatuFlg;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}