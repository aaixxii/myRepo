package com.nec.jp.G6Smartphone.SO;

public class AreaSensorDataModel {

	private String areaNm;		// 警備エリア.警備エリア名称
	private String devNm;		// 設置機器.装置名称

	public AreaSensorDataModel() {
		this.areaNm = "";
		this.devNm = "";
	}

	public AreaSensorDataModel(String areaNm, String devNm) {
		this.areaNm = areaNm;
		this.devNm = devNm;
	}

	public String getAreaNm() {
		return areaNm;
	}

	public void setAreaNm(String areaNm) {
		this.areaNm = areaNm;
	}

	public String getDevNm() {
		return devNm;
	}

	public void setDevNm(String devNm) {
		this.devNm = devNm;
	}
}
