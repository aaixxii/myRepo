package com.nec.jp.G6Smartphone.SO;

public class AcumImageDataModel {

	private String lnLiveImgVoc;
	private String shotSttTstm;
	private String shotEndTstm;
	private String savePath;
	private String fileNm;
	private String fileSize;
	private String pxSize;
	public AcumImageDataModel() {
		this.lnLiveImgVoc = "";
		this.shotSttTstm = "";
		this.shotEndTstm = "";
		this.savePath = "";
		this.fileNm = "";
		this.fileSize = "";
		this.pxSize = "";
	}
	public AcumImageDataModel(String lnLiveImgVoc, String shotSttTstm, String shotEndTstm, String savePath,
			String fileNm, String fileSize, String pxSize) {
		this.lnLiveImgVoc = lnLiveImgVoc;
		this.shotSttTstm = shotSttTstm;
		this.shotEndTstm = shotEndTstm;
		this.savePath = savePath;
		this.fileNm = fileNm;
		this.fileSize = fileSize;
		this.pxSize = pxSize;
	}
	public AcumImageDataModel(String lnLiveImgVoc) {
		this.lnLiveImgVoc = lnLiveImgVoc;
	}
	public String getLnLiveImgVoc() {
		return lnLiveImgVoc;
	}
	public void setLnLiveImgVoc(String lnLiveImgVoc) {
		this.lnLiveImgVoc = lnLiveImgVoc;
	}
	public String getShotSttTstm() {
		return shotSttTstm;
	}
	public void setShotSttTstm(String shotSttTstm) {
		this.shotSttTstm = shotSttTstm;
	}
	public String getShotEndTstm() {
		return shotEndTstm;
	}
	public void setShotEndTstm(String shotEndTstm) {
		this.shotEndTstm = shotEndTstm;
	}
	public String getSavePath() {
		return savePath;
	}
	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}
	public String getFileNm() {
		return fileNm;
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	public String getPxSize() {
		return pxSize;
	}
	public void setPxSize(String pxSize) {
		this.pxSize = pxSize;
	}
}
