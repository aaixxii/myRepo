package com.nec.jp.G6Smartphone.dao.g6;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.HEventInfoDataModel;

@Repository
public class SZWP3100Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;
	
	
	private StringBuilder getEventInfoSearchResultSql(String lnKbChiku) {
		StringBuilder strBuilder = new StringBuilder();
	
		strBuilder.append(" SELECT			DATE_FORMAT(heventinfo.HASSEI_TS, '%Y/%m/%d %H:%i:%s') as hasseiTs,");
		strBuilder.append("						heventinfo.CHIKU_NM as chikuNm,");
		strBuilder.append("						heventinfo.KENCHI_NAIYOU as kenchiNaiyou,");
		strBuilder.append("						IFNULL(cast(heventinfo.VFILE_INFO as character),'') as vfileInfo,");
		strBuilder.append("						heventinfo.LN_EVENT_INFO_HST as lnEventInfoHst,");
		strBuilder.append("						cast(heventinfo.VIDE_LK_FLG as character) as videLkFlg");
		strBuilder.append(" FROM				H_EVENT_INFO heventinfo");
		strBuilder.append(" 		INNER JOIN	R_KB_CHIKU rkbchiku ON heventinfo.CHIKU_NM = rkbchiku.SD_KOBETU_NM");
		strBuilder.append("			INNER JOIN A_USER_OPERATION_HANI A ON A.LN_ACNT_USER_COMMON = :acntID");
        strBuilder.append("			AND ( A.PATH_INF = rkbchiku.PATH_INF");
        strBuilder.append("			   OR A.PATH_INF = LEFT(rkbchiku.PATH_INF, 41)");
        strBuilder.append("			   OR A.PATH_INF = LEFT(rkbchiku.PATH_INF, 20) )");
		strBuilder.append(" WHERE			rkbchiku.LN_KEIBI = :lnKeibi");
		if (!lnKbChiku.isEmpty()) {
			strBuilder.append(" 					AND rkbchiku.LN_KB_CHIKU = :lnKbChiku");
		}
		strBuilder.append(" 						AND (DATE_FORMAT(heventinfo.HASSEI_TS, '%Y%m%d%H%i%s') BETWEEN :dateFrom AND :dateTo)");
		strBuilder.append(" ORDER BY		heventinfo.HASSEI_TS DESC");
		strBuilder.append(",						heventinfo.CHIKU_NM ASC");
		
		return strBuilder;
	}
	
	public String getTotalRow(String acntID, String lnKeibi, String lnKbChiku, Date dateFrom, Date dateTo) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append("SELECT COUNT(*) FROM (");
		strBuilder.append(getEventInfoSearchResultSql(lnKbChiku).toString());
		strBuilder.append(") EventInfoSearchResult");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("acntID", acntID);
		query.setParameter("lnKeibi", lnKeibi);
		if (!lnKbChiku.isEmpty()) {
			query.setParameter("lnKbChiku", lnKbChiku);
		}
		query.setParameter("dateFrom", sdf.format(dateFrom));
		query.setParameter("dateTo", sdf.format(dateTo));
		
		return query.getSingleResult().toString();
	}
	
	@SuppressWarnings("unchecked")
	public List<HEventInfoDataModel> getEventInfoSearchResult(String acntID, String lnKeibi, String lnKbChiku, Date dateFrom, Date dateTo, int offset, int limitRowNum ) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append(getEventInfoSearchResultSql(lnKbChiku).toString());
		strBuilder.append(" LIMIT :offset, :limitRowNum");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString(), "HEventInfoDataModelResult");
		query.setParameter("acntID", acntID);
		query.setParameter("lnKeibi", lnKeibi);
		if (!lnKbChiku.isEmpty()) {
			query.setParameter("lnKbChiku", lnKbChiku);
		}
		query.setParameter("dateFrom", sdf.format(dateFrom));
		query.setParameter("dateTo", sdf.format(dateTo));
		query.setParameter("offset", offset);
		query.setParameter("limitRowNum", limitRowNum);
		
		return (List<HEventInfoDataModel>) query.getResultList();
	}
}
