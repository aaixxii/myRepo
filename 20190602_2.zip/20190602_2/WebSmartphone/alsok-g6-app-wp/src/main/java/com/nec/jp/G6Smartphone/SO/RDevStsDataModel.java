package com.nec.jp.G6Smartphone.SO;

public class RDevStsDataModel {

	private String lnDev;			// 設置機器.LN_設置機器論理番号
	private String sdDevNm;			// 設置機器.装置名称
	private String sdDevNum;		// 設置機器.装置番号
	private String drctsetCntrSts;	// 設置機器状態.ダイレクト操作ON/OFF状態

	public RDevStsDataModel() {
		this.lnDev = "";
		this.sdDevNm = "";
		this.sdDevNum = "";
		this.drctsetCntrSts = "";
	}

	public RDevStsDataModel(String lnDev, String sdDevNm, String sdDevNum, String drctsetCntrSts) {
		this.lnDev = lnDev;
		this.sdDevNm = sdDevNm;
		this.sdDevNum = sdDevNum;
		this.drctsetCntrSts = drctsetCntrSts;
	}

	public String getLnDev() {
		return lnDev;
	}

	public void setLnDev(String lnDev) {
		this.lnDev = lnDev;
	}

	public String getSdDevNm() {
		return sdDevNm;
	}

	public void setSdDevNm(String sdDevNm) {
		this.sdDevNm = sdDevNm;
	}

	public String getSdDevNum() {
		return sdDevNum;
	}

	public void setSdDevNum(String sdDevNum) {
		this.sdDevNum = sdDevNum;
	}

	public String getDrctsetCntrSts() {
		return drctsetCntrSts;
	}

	public void setDrctsetCntrSts(String drctsetCntrSts) {
		this.drctsetCntrSts = drctsetCntrSts;
	}
}
