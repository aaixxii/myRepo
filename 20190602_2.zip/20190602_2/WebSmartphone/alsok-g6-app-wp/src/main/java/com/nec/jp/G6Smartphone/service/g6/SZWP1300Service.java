package com.nec.jp.G6Smartphone.service.g6;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.SdKobetuDataModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP1300Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1300Service {

	@Autowired
	SZWP1300Dao sZWP1300Dao;

	public List<SdKobetuDataModel> getDistrictPulldownInfo(String acntID, String lnKeibi) throws ApplicationException {
		try {
			List<SdKobetuDataModel> sdKobetuDataModelList = sZWP1300Dao.getDistrictPulldownInfo(acntID, lnKeibi);

			return sdKobetuDataModelList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
