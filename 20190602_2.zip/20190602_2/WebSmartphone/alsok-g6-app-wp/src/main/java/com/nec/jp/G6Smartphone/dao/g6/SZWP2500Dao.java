package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.RDevNameDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP2500Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<RDevNameDataModel> getAllEquipmentInfo(String lnKeibi, List<String> lnKbChiku) {
		StringBuilder strBuilder = new StringBuilder();
				
		strBuilder.append(" SELECT     dev.LN_KB_CHIKU as lnKbChiku,");
		strBuilder.append("            dev.LN_DEV as lnDev,");
		strBuilder.append("            IFNULL(dev.SD_DEV_NM, '') as sdDevNm,");
		strBuilder.append("            dev.SD_DEV_NUM as sdDevNum");
		strBuilder.append(" FROM       R_DEV dev");
		strBuilder.append(" INNER JOIN R_KB_CHIKU chiku ");
		strBuilder.append(" ON         dev.LN_KB_CHIKU = chiku.LN_KB_CHIKU");
		strBuilder.append(" WHERE      dev.LN_KEIBI = :lnKeibi");
		strBuilder.append(" AND        chiku.LN_KB_CHIKU IN (:lnKbChiku)");
		strBuilder.append(" AND        dev.DEL_FLG = :delFlg");
		strBuilder.append(" AND        (dev.SD_DEV_NUM LIKE 'GS%'");
		strBuilder.append("              OR dev.SD_DEV_NUM LIKE 'CM%'");
		strBuilder.append("              OR dev.SD_DEV_NUM LIKE 'RC%'");
		strBuilder.append("              OR dev.SD_DEV_NUM LIKE 'CU___-CM%')");
		strBuilder.append(" ORDER BY   dev.SD_DEV_NUM ASC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RDevFullDataModelResult");

		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("lnKbChiku", lnKbChiku);

		return (List<RDevNameDataModel>) query.getResultList();
	}
}
