package com.nec.jp.G6Smartphone.SO;

public class SZWP0000Info{

	private String passwd;
	private String mlSendSts;
	private String acntSbt;
	
	//G6
	private String lnAcntUserCommon;		// 利用者アカウント共通.LN_利用者アカウント共通論理番号
	private String acntNm;					// 利用者アカウント共通.アカウント名称
	private String checkSts;
	private String lastLoginTs;				// 利用者アカウント.前回ログイン日時
	private String acntUserKbn;	
	
	//common Kiy, LiyGS
	private String mlAddr; //メールアドレス
	private String acntType; //アカウント区分
	private String userNm; //ユーザー氏名
	private String loginSts; //ログイン許可状態
	private String rgstSts; //登録状態
	private String updateTs; //更新日時
	
	//Kiy
	private String lnAcntKeiyk; //LN_契約先アカウント論理番号
	private String lnKeiyk; //LN_契約先論理番号
	
	//LiyGS
	private String lnAcntUser; //LN_利用者アカウント論理番号
	private String lnTenantMng; //LN_入居管理論理番号
	private String gsHsType; //GSHS区分

	
	
	public String getMlAddr() {
		return mlAddr;
	}
	public void setMlAddr(String mlAddr) {
		this.mlAddr = mlAddr;
	}
	public String getAcntType() {
		return acntType;
	}
	public void setAcntType(String acntType) {
		this.acntType = acntType;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getLoginSts() {
		return loginSts;
	}
	public void setLoginSts(String loginSts) {
		this.loginSts = loginSts;
	}
	public String getRgstSts() {
		return rgstSts;
	}
	public void setRgstSts(String rgstSts) {
		this.rgstSts = rgstSts;
	}
	public String getUpdateTs() {
		return updateTs;
	}
	public void setUpdateTs(String updateTs) {
		this.updateTs = updateTs;
	}
	public String getLnAcntKeiyk() {
		return lnAcntKeiyk;
	}
	public void setLnAcntKeiyk(String lnAcntKeiyk) {
		this.lnAcntKeiyk = lnAcntKeiyk;
	}
	public String getLnKeiyk() {
		return lnKeiyk;
	}
	public void setLnKeiyk(String lnKeiyk) {
		this.lnKeiyk = lnKeiyk;
	}
	public String getLnAcntUser() {
		return lnAcntUser;
	}
	public void setLnAcntUser(String lnAcntUser) {
		this.lnAcntUser = lnAcntUser;
	}
	public String getLnTenantMng() {
		return lnTenantMng;
	}
	public void setLnTenantMng(String lnTenantMng) {
		this.lnTenantMng = lnTenantMng;
	}
	public String getGsHsType() {
		return gsHsType;
	}
	public void setGsHsType(String gsHsType) {
		this.gsHsType = gsHsType;
	}
	public String getLnAcntUserCommon() {
		return lnAcntUserCommon;
	}
	public void setLnAcntUserCommon(String lnAcntUserCommon) {
		this.lnAcntUserCommon = lnAcntUserCommon;
	}
	public String getAcntNm() {
		return acntNm;
	}
	public void setAcntNm(String acntNm) {
		this.acntNm = acntNm;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getMlSendSts() {
		return mlSendSts;
	}
	public void setMlSendSts(String mlSendSts) {
		this.mlSendSts = mlSendSts;
	}
	public String getCheckSts() {
		return checkSts;
	}
	public void setCheckSts(String checkSts) {
		this.checkSts = checkSts;
	}
	public String getLastLoginTs() {
		return lastLoginTs;
	}
	public void setLastLoginTs(String lastLoginTs) {
		this.lastLoginTs = lastLoginTs;
	}
	public String getAcntUserKbn() {
		return acntUserKbn;
	}
	public void setAcntUserKbn(String acntUserKbn) {
		this.acntUserKbn = acntUserKbn;
	}
	public String getAcntSbt() {
		return acntSbt;
	}
	public void setAcntSbt(String acntSbt) {
		this.acntSbt = acntSbt;
	}
}
