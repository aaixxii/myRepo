package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.DistrictGHSInfoModel;
import com.nec.jp.G6Smartphone.SO.KbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuNmDataModel;
import com.nec.jp.G6Smartphone.SO.SdKobetuDataModel;
import com.nec.jp.G6Smartphone.SO.SdKobetuNmDataModel;
import com.nec.jp.G6Smartphone.SO.UserOperationChikuInfoModel;


/**
 * The persistent class for the R_KB_CHIKU database table.
 * 
 */
@SqlResultSetMappings({
	@SqlResultSetMapping(name="KbChikuDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = KbChikuDataModel.class,
				columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "subAddr"),
					@ColumnResult(name = "sdKobetuNm")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RKbChikuDataModelTempResult",
		classes = {
			@ConstructorResult(
				targetClass = RKbChikuDataSubModel.class,
				columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "lnKeibi"),
					@ColumnResult(name = "chiku"),
					@ColumnResult(name = "subAddr"),
					@ColumnResult(name = "sdKobetuNm"),
					@ColumnResult(name = "gyoumuCd"),
					@ColumnResult(name = "hosokuCd"),
					@ColumnResult(name = "gshsFlg")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RKbChikuDataModel1100GHSTempResult",
		classes = {
			@ConstructorResult(
				targetClass = DistrictGHSInfoModel.class,
				columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "subAddr"),
					@ColumnResult(name = "sdKobetuNm"),
				}
			)
		}
	),
	@SqlResultSetMapping(name="SdKobetuDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = SdKobetuDataModel.class,
				columns = {
					@ColumnResult(name = "sdKobetuNm"),
					@ColumnResult(name = "chiku"),
					@ColumnResult(name = "subAddr")
				}
			)
		}
	),
	@SqlResultSetMapping(name="SdKobetuNmDataModelResult",
	classes = {
		@ConstructorResult(
			targetClass = SdKobetuNmDataModel.class,
			columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "sdKobetuNm")
				}
			)
		}
	),
	@SqlResultSetMapping(name="RKbChikuDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = RKbChikuDataModel.class,
				columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "sdKobetuNm"),
					@ColumnResult(name = "n0f0Flg"),
					@ColumnResult(name = "empStsFlg")
				}
			)
		}
	),
	
	//sZWP0400Ghs
	@SqlResultSetMapping(name="RKbChikuDataGHS0400GhsModelResult",
	   classes = {
		   @ConstructorResult(
		       targetClass = RKbChikuDataModel.class,
		       columns = {
		           @ColumnResult(name = "lnKbChiku"),
		           @ColumnResult(name = "subAddr"),
		           @ColumnResult(name = "sdKobetuNm"),
		           @ColumnResult(name = "chiku"),
		           @ColumnResult(name = "n0f0Flg"),
		           @ColumnResult(name = "empStsFlg")
		           }
		       )
		   }
	),
	
	@SqlResultSetMapping(name="RKbChikuNmDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = RKbChikuNmDataModel.class,
				columns = {
					@ColumnResult(name = "lnKbChiku"),
					@ColumnResult(name = "sdKobetuNm")
				}
			)
		}
	),
	
	@SqlResultSetMapping(name="UserOperationChikuInfoModelResult",
		classes = {
			@ConstructorResult(
				targetClass = UserOperationChikuInfoModel.class,
				columns = {
					@ColumnResult(name = "lnKeiyk"),
					@ColumnResult(name = "keibiNm"),
					@ColumnResult(name = "sdKobetuNm")
				}
			)
		}
	),
	
	@SqlResultSetMapping(name="UserOperationChikuInfoFromKeibInfModelResult",
		classes = {
			@ConstructorResult(
				targetClass = UserOperationChikuInfoModel.class,
				columns = {
					@ColumnResult(name = "lnKeibi"),
					@ColumnResult(name = "lnKbChiku")
				}
			)
		}
	)
})
@Entity
@Table(name="R_KB_CHIKU")
@NamedQuery(name="RKbChikuModel.findAll", query="SELECT r FROM RKbChikuModel r")
public class RKbChikuModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;

	@Column(name="ADDR_CD1_ID")
	private String addrCd1Id;

	@Column(name="ADDR_CD2_ID")
	private String addrCd2Id;

	@Column(name="ADDR_CD3_ID")
	private String addrCd3Id;

	@Column(name="ADDR_CD4_ID")
	private String addrCd4Id;

	@Column(name="ADDR_CD5_ID")
	private String addrCd5Id;

	@Column(name="ADDR_CD6_ID")
	private String addrCd6Id;

	@Column(name="ADDR_KANA_NM")
	private String addrKanaNm;

	@Column(name="ADDR_OPT1")
	private String addrOpt1;

	@Column(name="ADDR_OPT2")
	private String addrOpt2;

	@Column(name="AUTO_TAIKAN_CK_FLG")
	private String autoTaikanCkFlg;

	@Column(name="BLD_KOZO_KIND")
	private String bldKozoKind;

	@Column(name="BLD_STAT")
	private String bldStat;

	@Column(name="CHIKU")
	private String chiku;

	@Column(name="CHIKU_ABBR_NM")
	private String chikuAbbrNm;

	@Column(name="CHIKU_ADDR")
	private String chikuAddr;

	@Column(name="DEL_FLG")
	private String delFlg;

	@Column(name="ENTRY_STS")
	private String entrySts;

	@Column(name="F0_BASE")
	private String f0Base;

	@Column(name="F0_SYUKUJITU")
	private String f0Syukujitu;

	@Column(name="F0_TEIKYU")
	private String f0Teikyu;

	@Column(name="FW_VER")
	private String fwVer;

	@Column(name="GYOUMU_CD")
	private String gyoumuCd;

	@Column(name="HOSOKU_CD")
	private String hosokuCd;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="KF_BASE")
	private String kfBase;

	@Column(name="KF_SYUKUJITU")
	private String kfSyukujitu;

	@Column(name="KF_TEIKYU")
	private String kfTeikyu;

	@Column(name="KN_BASE")
	private String knBase;

	@Column(name="KN_SYUKUJITU")
	private String knSyukujitu;

	@Column(name="KN_TEIKYU")
	private String knTeikyu;

	@Column(name="KYORI")
	private String kyori;

	@Column(name="LN_KEIBI")
	private String lnKeibi;

	@Column(name="N0_BASE")
	private String n0Base;

	@Column(name="N0_SYUKUJITU")
	private String n0Syukujitu;

	@Column(name="N0_TEIKYU")
	private String n0Teikyu;

	@Column(name="PATH_INF")
	private String pathInf;

	@Column(name="POST_NUM")
	private String postNum;

	@Column(name="ROTEI")
	private String rotei;

	@Column(name="SD_KOBETU_NM")
	private String sdKobetuNm;

	@Column(name="SERVICE")
	private String service;

	@Column(name="SINPO_FLG")
	private String sinpoFlg;

	@Column(name="SUB_ADDR")
	private String subAddr;

	@Column(name="SYOYOU")
	private String syoyou;

	@Column(name="TEL_NUM")
	private String telNum;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public RKbChikuModel() {
	}

	public String getLnKbChiku() {
		return this.lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getAddrCd1Id() {
		return this.addrCd1Id;
	}

	public void setAddrCd1Id(String addrCd1Id) {
		this.addrCd1Id = addrCd1Id;
	}

	public String getAddrCd2Id() {
		return this.addrCd2Id;
	}

	public void setAddrCd2Id(String addrCd2Id) {
		this.addrCd2Id = addrCd2Id;
	}

	public String getAddrCd3Id() {
		return this.addrCd3Id;
	}

	public void setAddrCd3Id(String addrCd3Id) {
		this.addrCd3Id = addrCd3Id;
	}

	public String getAddrCd4Id() {
		return this.addrCd4Id;
	}

	public void setAddrCd4Id(String addrCd4Id) {
		this.addrCd4Id = addrCd4Id;
	}

	public String getAddrCd5Id() {
		return this.addrCd5Id;
	}

	public void setAddrCd5Id(String addrCd5Id) {
		this.addrCd5Id = addrCd5Id;
	}

	public String getAddrCd6Id() {
		return this.addrCd6Id;
	}

	public void setAddrCd6Id(String addrCd6Id) {
		this.addrCd6Id = addrCd6Id;
	}

	public String getAddrKanaNm() {
		return this.addrKanaNm;
	}

	public void setAddrKanaNm(String addrKanaNm) {
		this.addrKanaNm = addrKanaNm;
	}

	public String getAddrOpt1() {
		return this.addrOpt1;
	}

	public void setAddrOpt1(String addrOpt1) {
		this.addrOpt1 = addrOpt1;
	}

	public String getAddrOpt2() {
		return this.addrOpt2;
	}

	public void setAddrOpt2(String addrOpt2) {
		this.addrOpt2 = addrOpt2;
	}

	public String getAutoTaikanCkFlg() {
		return this.autoTaikanCkFlg;
	}

	public void setAutoTaikanCkFlg(String autoTaikanCkFlg) {
		this.autoTaikanCkFlg = autoTaikanCkFlg;
	}

	public String getBldKozoKind() {
		return this.bldKozoKind;
	}

	public void setBldKozoKind(String bldKozoKind) {
		this.bldKozoKind = bldKozoKind;
	}

	public String getBldStat() {
		return this.bldStat;
	}

	public void setBldStat(String bldStat) {
		this.bldStat = bldStat;
	}

	public String getChiku() {
		return this.chiku;
	}

	public void setChiku(String chiku) {
		this.chiku = chiku;
	}

	public String getChikuAbbrNm() {
		return this.chikuAbbrNm;
	}

	public void setChikuAbbrNm(String chikuAbbrNm) {
		this.chikuAbbrNm = chikuAbbrNm;
	}

	public String getChikuAddr() {
		return this.chikuAddr;
	}

	public void setChikuAddr(String chikuAddr) {
		this.chikuAddr = chikuAddr;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getEntrySts() {
		return this.entrySts;
	}

	public void setEntrySts(String entrySts) {
		this.entrySts = entrySts;
	}

	public String getF0Base() {
		return this.f0Base;
	}

	public void setF0Base(String f0Base) {
		this.f0Base = f0Base;
	}

	public String getF0Syukujitu() {
		return this.f0Syukujitu;
	}

	public void setF0Syukujitu(String f0Syukujitu) {
		this.f0Syukujitu = f0Syukujitu;
	}

	public String getF0Teikyu() {
		return this.f0Teikyu;
	}

	public void setF0Teikyu(String f0Teikyu) {
		this.f0Teikyu = f0Teikyu;
	}

	public String getFwVer() {
		return this.fwVer;
	}

	public void setFwVer(String fwVer) {
		this.fwVer = fwVer;
	}

	public String getGyoumuCd() {
		return this.gyoumuCd;
	}

	public void setGyoumuCd(String gyoumuCd) {
		this.gyoumuCd = gyoumuCd;
	}

	public String getHosokuCd() {
		return this.hosokuCd;
	}

	public void setHosokuCd(String hosokuCd) {
		this.hosokuCd = hosokuCd;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getKfBase() {
		return this.kfBase;
	}

	public void setKfBase(String kfBase) {
		this.kfBase = kfBase;
	}

	public String getKfSyukujitu() {
		return this.kfSyukujitu;
	}

	public void setKfSyukujitu(String kfSyukujitu) {
		this.kfSyukujitu = kfSyukujitu;
	}

	public String getKfTeikyu() {
		return this.kfTeikyu;
	}

	public void setKfTeikyu(String kfTeikyu) {
		this.kfTeikyu = kfTeikyu;
	}

	public String getKnBase() {
		return this.knBase;
	}

	public void setKnBase(String knBase) {
		this.knBase = knBase;
	}

	public String getKnSyukujitu() {
		return this.knSyukujitu;
	}

	public void setKnSyukujitu(String knSyukujitu) {
		this.knSyukujitu = knSyukujitu;
	}

	public String getKnTeikyu() {
		return this.knTeikyu;
	}

	public void setKnTeikyu(String knTeikyu) {
		this.knTeikyu = knTeikyu;
	}

	public String getKyori() {
		return this.kyori;
	}

	public void setKyori(String kyori) {
		this.kyori = kyori;
	}

	public String getLnKeibi() {
		return this.lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getN0Base() {
		return this.n0Base;
	}

	public void setN0Base(String n0Base) {
		this.n0Base = n0Base;
	}

	public String getN0Syukujitu() {
		return this.n0Syukujitu;
	}

	public void setN0Syukujitu(String n0Syukujitu) {
		this.n0Syukujitu = n0Syukujitu;
	}

	public String getN0Teikyu() {
		return this.n0Teikyu;
	}

	public void setN0Teikyu(String n0Teikyu) {
		this.n0Teikyu = n0Teikyu;
	}

	public String getPathInf() {
		return this.pathInf;
	}

	public void setPathInf(String pathInf) {
		this.pathInf = pathInf;
	}

	public String getPostNum() {
		return this.postNum;
	}

	public void setPostNum(String postNum) {
		this.postNum = postNum;
	}

	public String getRotei() {
		return this.rotei;
	}

	public void setRotei(String rotei) {
		this.rotei = rotei;
	}

	public String getSdKobetuNm() {
		return this.sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}

	public String getService() {
		return this.service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getSinpoFlg() {
		return this.sinpoFlg;
	}

	public void setSinpoFlg(String sinpoFlg) {
		this.sinpoFlg = sinpoFlg;
	}

	public String getSubAddr() {
		return this.subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public String getSyoyou() {
		return this.syoyou;
	}

	public void setSyoyou(String syoyou) {
		this.syoyou = syoyou;
	}

	public String getTelNum() {
		return this.telNum;
	}

	public void setTelNum(String telNum) {
		this.telNum = telNum;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}