package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.RKeibiDataModel;
import com.nec.jp.G6Smartphone.SO.ResKeibisaki;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP0000Service;
import com.nec.jp.G6Smartphone.service.ghs.SZWP0000GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;

import jp.co.alsok.g6.zzw.util.StringUtil;
import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWP0100Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP0100Controller.class);

	//JWT認証トークン
    private G6JWTVerifier jwtverifier;
    
	@Autowired
	SZWP0000Service sZWP0000Service;

	@Autowired
	SZWP0000GhsService sZWP0000GhsService;

	@Autowired
	CommonService commonService;

	@Autowired
	CommonComService commonComService;

	@Value("${limit_row_num}")
	Integer limit_row_num;
	
	@RequestMapping(value = "/changeKeibiSaki", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String changeKeibiSaki(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0100Controller.changeKeibiSaki()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		Map<String, Object> mapParam = new HashMap<String, Object>();
		ResKeibisaki resKeibisaki = new ResKeibisaki();
		List<RKeibiDataModel> rKeibiDataModelList = new ArrayList<RKeibiDataModel>();
		int totalRow = 0;
		int totalPage = 0;
		int offset = 0;
		int pageNo = 0;

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resKeibisaki, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0100Controller.changeKeibiSaki()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resKeibisaki, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0100Controller.changeKeibiSaki()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
            
			// リクエスト情報から選択言語種別を取得する
			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService
						.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 6) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resKeibisaki, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0100Controller.changeKeibiSaki()");
				return jsonResult;
			}

			// Build require parameters
			Map<String, Boolean> lstRequiredParam = new HashMap<String, Boolean>() {
				private static final long serialVersionUID = 1L;
				{
					put(RequestParam.acntID.getValue(), true);
					put(RequestParam.acntSbt.getValue(), true);
					put(RequestParam.keibiName.getValue(), false);
					put(RequestParam.pageNo.getValue(), true);
					put(RequestParam.ghsAcntNo.getValue(), false);
					put(RequestParam.mlAddr.getValue(), true);
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resKeibisaki, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0100Controller.changeKeibiSaki()");
				return jsonResult;
			}

			// リクエストより警備先名検索条件を取得
			String keibiName = mapParam.get(RequestParam.keibiName.getValue()).toString();
			
			// リクエストより表示対象ページ番号を取得
			pageNo = Integer.parseInt(mapParam.get(RequestParam.pageNo.getValue()).toString());

			// 次期警備アカウントIDを取得
			String g6LnAcntUserCommon = tokenMapParam.get(RequestParam.ln_acnt_user_common.getValue());
			// GHS契約者のアカウントIDを取得
			String ghsLnAcntKeiyk = tokenMapParam.get(RequestParam.ln_acnt_keiyk.getValue());
			// GHS利用者のアカウントIDを取得
			String ghsLnAcntUser = tokenMapParam.get(RequestParam.ln_acnt_user.getValue());
			
			// 次期警備の警備先を取得　（アカウントが存在する場合のみ）
			if (StringUtil.isNotNullOrEmpty(g6LnAcntUserCommon)) {
				rKeibiDataModelList.addAll(sZWP0000Service.getSecurityName(g6LnAcntUserCommon, keibiName));
			}
			
            // GHS契約者の警備先を取得　（アカウントが存在する場合のみ）
            if (StringUtil.isNotNullOrEmpty(ghsLnAcntKeiyk)) {
            	rKeibiDataModelList.addAll(sZWP0000GhsService.getSecurityNameKeiyk(ghsLnAcntKeiyk, keibiName));
            }
            
            // GHS利用者の警備先を取得　（アカウントが存在する場合のみ）
            if (StringUtil.isNotNullOrEmpty(ghsLnAcntUser)) {
            	RKeibiDataModel dataModel = sZWP0000GhsService.getSecurityNameLiy(ghsLnAcntUser, keibiName);
            	if (dataModel != null) {
            		rKeibiDataModelList.add(dataModel);
            	}
            }
            
            //警備先名称、警備先論理番号の昇順で並び替え
            rKeibiDataModelList = rKeibiDataModelList.stream().sorted(Comparator.comparing(RKeibiDataModel::getKeibiName1)
            											.thenComparing(RKeibiDataModel::getLnKeibi)).collect(Collectors.toList());
            
            totalRow = rKeibiDataModelList.size();
            
            // 警備先が取得できた場合、ページング編集を行う
			if(totalRow > 0) {
				// 総ページ数を計算
    			totalPage = G6Common.calculateTotalPages(totalRow, limit_row_num);
    			
    			// 表示ページが総ページ数を超えていた場合エラーとする。
    			if(pageNo >  totalPage) {
    				jsonResult = G6Common.messageHandler(resKeibisaki, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
    				return jsonResult;
    			}
    			
				// ページング表示するための開始/終了インデックスを計算
				offset = G6Common.calculateOffSet(pageNo, limit_row_num);
				int limit = G6Common.calculateLimit(offset, limit_row_num, rKeibiDataModelList);

				// 表示用リストを抽出
                rKeibiDataModelList = rKeibiDataModelList.subList(offset, limit);
                		                
			} else {
				// 警備先名称が取得できなかった場合
				jsonResult = G6Common.messageHandler(resKeibisaki, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_AVAILABLE_KEIBI.getValue(), acntLanguage);
			}

			// 応答
			resKeibisaki.setErrorCode(G6Constant.SUCCESS_CD);
			resKeibisaki.setTotalPage(String.valueOf(totalPage));
			resKeibisaki.setrKeibiItem(rKeibiDataModelList);
			
			//デコード済acntIDを設定したJWT認証トークンを付与
			resKeibisaki.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));

			jsonResult = G6Common.parseJSON(resKeibisaki, acntLanguage);
			
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resKeibisaki, G6Constant.FAIL_HTML_CD, e.getExceptionCode(),
					e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resKeibisaki, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resKeibisaki, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resKeibisaki, G6Constant.FAIL_HTML_CD,
						ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e),
						acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resKeibisaki, G6Constant.FAIL_HTML_CD,
						ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0100Controller.changeKeibiSaki()");
		return jsonResult;
	}
}
