package com.nec.jp.G6Smartphone.service.img;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.CameraDataSubModel;
import com.nec.jp.G6Smartphone.dao.img.SZWP2600ImgDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP2600ImgService {

	@Autowired
	SZWP2600ImgDao sZWP2600Dao;

	public CameraDataSubModel getAccumulatedImageSound(String lnDev) throws ApplicationException {
		try {
			CameraDataSubModel camera = sZWP2600Dao.getAccumulatedImageSound(lnDev);

			return camera;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
