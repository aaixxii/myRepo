package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the A_ACNT_USER_ROLE database table.
 * 
 */
@Embeddable
public class AAcntUserRoleModelPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="LN_ACNT_USER_COMMON")
	private String lnAcntUserCommon;

	@Column(name="LN_USER_ROLE")
	private String lnUserRole;

	@Column(name="PATH_INF")
	private String pathInf;

	public AAcntUserRoleModelPK() {
	}
	public String getLnAcntUserCommon() {
		return this.lnAcntUserCommon;
	}
	public void setLnAcntUserCommon(String lnAcntUserCommon) {
		this.lnAcntUserCommon = lnAcntUserCommon;
	}
	public String getLnUserRole() {
		return this.lnUserRole;
	}
	public void setLnUserRole(String lnUserRole) {
		this.lnUserRole = lnUserRole;
	}
	public String getPathInf() {
		return this.pathInf;
	}
	public void setPathInf(String pathInf) {
		this.pathInf = pathInf;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AAcntUserRoleModelPK)) {
			return false;
		}
		AAcntUserRoleModelPK castOther = (AAcntUserRoleModelPK)other;
		return 
			this.lnAcntUserCommon.equals(castOther.lnAcntUserCommon)
			&& this.lnUserRole.equals(castOther.lnUserRole)
			&& this.pathInf.equals(castOther.pathInf);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.lnAcntUserCommon.hashCode();
		hash = hash * prime + this.lnUserRole.hashCode();
		hash = hash * prime + this.pathInf.hashCode();
		
		return hash;
	}
}