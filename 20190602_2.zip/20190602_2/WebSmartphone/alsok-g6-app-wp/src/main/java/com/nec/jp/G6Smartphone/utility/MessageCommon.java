package com.nec.jp.G6Smartphone.utility;

import java.util.Locale;
import java.util.ResourceBundle;

import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

public class MessageCommon {

//	public static String acntLanguage = G6CodeConsts.CD238.JAPANESE;
	private static final Locale localeJa = new Locale("ja", "JP");
	private static final Locale localeEn = new Locale("en", "EN");
	private static final Locale localeCn = new Locale("cn", "CN");

	public static String getMessage(String errorKey, String acntLanguage) throws ApplicationException {
		String msg = "";

		try {
			switch (acntLanguage) {
			case G6CodeConsts.CD238.ENGLISH:
				msg = ResourceBundle.getBundle("messages", localeEn).getString(errorKey);
				break;
			case G6CodeConsts.CD238.JAPANESE:
				msg = ResourceBundle.getBundle("messages", localeJa).getString(errorKey);
				break;
			case G6CodeConsts.CD238.CHINESE:
				msg = ResourceBundle.getBundle("messages", localeCn).getString(errorKey);
				break;
			default:
				msg = ResourceBundle.getBundle("messages", localeJa).getString(errorKey);
				break;
			}
		} catch (Exception e) {
			// ファイルアクセス例外
			String exceptionMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.UTILITY_CONTEXT, ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue(), exceptionMsg);
		}

		return msg;
	}
}
