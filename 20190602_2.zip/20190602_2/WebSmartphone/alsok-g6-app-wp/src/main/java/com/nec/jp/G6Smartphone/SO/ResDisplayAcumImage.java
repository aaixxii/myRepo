package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResDisplayAcumImage implements ErrorHandler {
	private String errorCode;						// エラーコード
	private String errorMsg;						// エラーメッセージ
	private String url;
	private List<String> memDataList;
	private String acntID;
	
	public ResDisplayAcumImage() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.url = "";
		this.memDataList = new ArrayList<String>();
		this.acntID = "";
	}
	public ResDisplayAcumImage(String errorCode, String errorMsg, String url, List<String> memDataList) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.url = url;
		this.memDataList = memDataList;
		this.acntID = "";
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public List<String> getMemDataList() {
		return memDataList;
	}
	public void setMemDataList(List<String> memDataList) {
		this.memDataList = memDataList;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
