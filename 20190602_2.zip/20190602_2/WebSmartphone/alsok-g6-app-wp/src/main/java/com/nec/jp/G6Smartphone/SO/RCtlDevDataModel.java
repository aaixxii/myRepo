package com.nec.jp.G6Smartphone.SO;

public class RCtlDevDataModel {

	private String serialNum;		// 制御装置.シリアル番号
	private String gouKi;			// 制御装置.号機番号
	private String sdLineKind;

    public RCtlDevDataModel() {
		this.serialNum = "";
		this.gouKi = "";
		this.sdLineKind = "";
	}

	public RCtlDevDataModel(String serialNum, String gouKi, String sdLineKind) {
		this.serialNum = serialNum;
		this.gouKi = gouKi;
		this.sdLineKind = sdLineKind;
	}

	public String getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getGouKi() {
		return gouKi;
	}

	public void setGouKi(String gouKi) {
		this.gouKi = gouKi;
	}
	
   public String getSdLineKind() {
        return sdLineKind;
    }

    public void setSdLineKind(String sdLineKind) {
        this.sdLineKind = sdLineKind;
    }
}
