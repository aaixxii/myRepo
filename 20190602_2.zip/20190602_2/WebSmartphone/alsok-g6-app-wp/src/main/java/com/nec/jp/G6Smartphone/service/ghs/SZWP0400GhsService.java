package com.nec.jp.G6Smartphone.service.ghs;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.RKbChikuDataModel;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP0400GhsDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP0400GhsService {

	@Autowired
	SZWP0400GhsDao sZWP0400GhsDao;

	public String getFlgKbSetDispByAcntId(String AcntID) throws ApplicationException {
		try {
			return sZWP0400GhsDao.getFlgKbSetDispByAcntId(AcntID);
		} catch (NoResultException noResultE) {
			return "";
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String selectGshsFlgInfo(String lnKeibi) throws ApplicationException {
		try {
			return sZWP0400GhsDao.selectGshsFlgInfo(lnKeibi);
		} catch (NoResultException noResultE) {
			return "";
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	/**
	 * A)警備操作先一覧の取得
	 *
	 * @param form フォーム
	 * @return 警備操作先一覧情報
	 * @throws Exception ＤＢアクセス例外
	 */
	public List<RKbChikuDataModel> searchGhsListInfo(String lnKeibi, List<String> subAddr) throws ApplicationException {
        try {
        	return sZWP0400GhsDao.searchGhsListInfo(lnKeibi, subAddr);
        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
        }
        
	}
}
