package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.SensorHistoryDataModel;

@Repository
public class SZWP1500Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	public String getProcessResult(String lnKbInf) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	recvMsg");
		strBuilder.append(" FROM	ESyochiKekkaRecvModel");
		strBuilder.append(" WHERE	lnKbInf = :lnKbInf");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("lnKbInf", lnKbInf);
		query.setMaxResults(1);

		return (String) query.getSingleResult();
	}

	@SuppressWarnings("unchecked")
	public List<SensorHistoryDataModel> getSensorHistoryList(String lnJian) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	DATE_FORMAT(inf.SIG_HASSEI_TS, '%Y/%m/%d') AS hasseiDate,");
		strBuilder.append("			DATE_FORMAT(inf.SIG_HASSEI_TS, '%H:%i') AS hasseiTime,");
		strBuilder.append("			IFNULL(area.KB_AREA_NM, '') AS kbAreaNm,");
		strBuilder.append("			IFNULL(inf.DEV_NM, '') AS devNm,");
		strBuilder.append("			CAST(inf.VIDEO_FILE_NAME as CHARACTER) AS videoFileName,");
		strBuilder.append("			IFNULL(notice.LN_KB_INF, '') AS lnKbInf");
		strBuilder.append(" FROM	E_JIAN jian");
		strBuilder.append("			INNER JOIN E_KB_INF inf ON (jian.LN_KB_INF1 = inf.LN_KB_INF");
		strBuilder.append("				OR jian.LN_KB_INF2 = inf.LN_KB_INF");
		strBuilder.append("				OR jian.LN_KB_INF3 = inf.LN_KB_INF");
		strBuilder.append("				OR jian.LN_KB_INF_CUST1 = inf.LN_KB_INF");
		strBuilder.append("				OR jian.LN_KB_INF1_RM = inf.LN_KB_INF");
		strBuilder.append("				OR jian.LN_KB_INF2_RM = inf.LN_KB_INF");
		strBuilder.append("				OR jian.LN_KB_INF3_RM = inf.LN_KB_INF)");
		strBuilder.append("			INNER JOIN E_KB_NOTICE notice ON inf.LN_KB_INF = notice.LN_KB_INF");
		strBuilder.append("			INNER JOIN R_DEV dev ON inf.DEV_NUM  = dev.SD_DEV_NUM");
		strBuilder.append("			INNER JOIN R_KB_AREA area ON dev.LN_KB_AREA = area.LN_KB_AREA");
		strBuilder.append(" WHERE	jian.LN_JIAN = :lnJian");
		strBuilder.append(" ORDER BY inf.SIG_HASSEI_TS DESC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "SensorHistoryDataModelResult");
		query.setParameter("lnJian", lnJian);

		return (List<SensorHistoryDataModel>) query.getResultList();
	}
}
