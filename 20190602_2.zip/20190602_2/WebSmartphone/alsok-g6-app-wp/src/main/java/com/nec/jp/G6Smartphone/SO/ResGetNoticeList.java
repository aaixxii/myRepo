package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetNoticeList implements ErrorHandler {

	private String errorCode;			// エラーコード
	private String errorMsg;			// エラーメッセージ
	private List<HAlsokNoticeDataModel> hAlsokNoticeItem;
	private String acntID;
	private String totalPage; 			// トタルページ


	public ResGetNoticeList() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.hAlsokNoticeItem = new ArrayList<HAlsokNoticeDataModel>();
		this.acntID = "";
	}

	public ResGetNoticeList(String errorCode, String errorMsg, List<HAlsokNoticeDataModel> hAlsokNoticeItem, String totalPage) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.hAlsokNoticeItem = hAlsokNoticeItem;
		this.acntID = "";
		this.totalPage = totalPage;
	}

	public String getTotalPage() {
		return totalPage;
	}
	
	public void setTotalPage(String totalPage) {
		this.totalPage = totalPage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<HAlsokNoticeDataModel> gethAlsokNoticeItem() {
		return hAlsokNoticeItem;
	}

	public void sethAlsokNoticeItem(List<HAlsokNoticeDataModel> hAlsokNoticeItem) {
		this.hAlsokNoticeItem = hAlsokNoticeItem;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
