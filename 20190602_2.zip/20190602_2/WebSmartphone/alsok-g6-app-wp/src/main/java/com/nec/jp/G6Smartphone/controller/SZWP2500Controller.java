package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ErrorDataModel;
import com.nec.jp.G6Smartphone.SO.RDevNameDataModel;
import com.nec.jp.G6Smartphone.SO.ResGetDevList;
import com.nec.jp.G6Smartphone.SO.SZWP2300JsonModel;
import com.nec.jp.G6Smartphone.SO.UserOperationChikuInfoModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP2500Service;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.ConvUtil;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;

@Controller
public class SZWP2500Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP2500Controller.class);

	//JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
    @Autowired
	CommonService commonService;
    
	@Autowired
	CommonComService commonComService;
	
	@Autowired
	SZWP2500Service sZWP2500Service;
	
	@Value("${media_api_2500_stopLiveImage}")
	String MEDIA_API_2500_StopLiveImage;
	
	/*
	 * Get data from R_DEV table
	 * @param: acntID, lnKeibi, lnKbChiku
	 * return: object ResGetDevList as JSON
	 */
	@RequestMapping(value = "/getLiveDevList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getLiveDevList(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2500Controller.getLiveDevList()");
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		String jsonResult = "";
		Map<String, Object> mapParam = new HashMap<String, Object>();
		ResGetDevList resGetDevList = new ResGetDevList();
		List<RDevNameDataModel> rDevNameDataModel= new ArrayList<RDevNameDataModel>();

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetDevList, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.getLiveDevList()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetDevList, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.getLiveDevList()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 3) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetDevList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.getLiveDevList()");
				return jsonResult;
			}

			// Build require parameters
			Map<String, Boolean> lstRequiredParam = new HashMap<String, Boolean>() {
				private static final long serialVersionUID = 1L;
				{
					put(RequestParam.acntID.getValue(), true);
					put(RequestParam.lnKeibi.getValue(), true);
					put(RequestParam.lnKbChiku.getValue(), true);
				}
			};
			List<String> chkArrParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.lnKbChiku.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam, chkArrParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetDevList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.getLiveDevList()");
				return jsonResult;
			}

			// TODO SZWP2500：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// リクエスト情報から取得したすべての地区について、設置機器情報を取得する
			List<String> listKbChiku = G6Common.readParamToArrayObject(mapParam, RequestParam.lnKbChiku.getValue());

			// 7-2.A)設置機器の取得
			rDevNameDataModel = sZWP2500Service.getAllEquipmentInfo(
					mapParam.get(RequestParam.lnKeibi.getValue()).toString(), listKbChiku);

			// 取得内容を応答する
			resGetDevList.setErrorCode(G6Constant.SUCCESS_CD);
			resGetDevList.setrDevNameItem(rDevNameDataModel);
			
			// デコード済acntIDを設定したJWT認証トークンを付与
			resGetDevList.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
			
			jsonResult = G6Common.parseJSON(resGetDevList, acntLanguage);
			
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetDevList, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetDevList, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetDevList, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			jsonResult = G6Common.messageLogHandler(resGetDevList, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.getLiveDevList()");
		return jsonResult;
	}
	/*
	 * Get data from I_MNG_LIVE table
	 * @param: acntID, lnDev
	 * return: object ResDisplayLiveImage as JSON
	 */
	@RequestMapping(value = "/stopLiveImage", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String stopLiveImage(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2500Controller.stopLiveImage()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ErrorDataModel errorDataModel = new ErrorDataModel();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntID = "";
		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.stopLiveImage()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.stopLiveImage()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
            
			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 3) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.stopLiveImage()");
				return jsonResult;
			}
			// Build require parameters
			Map<String, Boolean> mapRequireParam = new HashMap<String, Boolean>() ;
			mapRequireParam.put(RequestParam.acntID.getValue(), true);
			mapRequireParam.put(RequestParam.lnDev.getValue(), true);
			mapRequireParam.put(RequestParam.sdDevNum.getValue(), true);
			if (!G6Common.checkRequire(mapParam, mapRequireParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.stopLiveImage()");
				return jsonResult;
			}

			// リクエスト情報取得
			// unused: リクエスト情報からアカウント種別を取得する
			// TODO SZWP2300：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);
			acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
			String lnDev = ((List)mapParam.get(RequestParam.lnDev.getValue())).get(0).toString();
			String lnKbChiku = commonService.getChikuInfoFromLnDev(lnDev).getLnKbChiku();
			//List<String> sdDevNum = G6Common.readParamToArrayObject(mapParam, RequestParam.sdDevNum.getValue());
			
			//ライブ画像(停止)処理を行う
			SZWP2300JsonModel jsonModel = new SZWP2300JsonModel();
			jsonModel.setLn_acnt_user_common(acntID);
			jsonModel.setScreen_id( G6Constant.ScreenID.SZWP2300.getValue());
			jsonModel.setOpe_form_id(G6Constant.OpeFromID.SZWP2300_002.getValue());
			//jsonModel.setAl_camera_lst(new JSONArray(sdDevNum));
			//jsonModel.setPly_camera_lst(new JSONArray(sdDevNum));
			//jsonModel.setDsp_camera_lst(new JSONArray(sdDevNum));
			jsonModel.setLn_dev(lnDev);
			jsonModel.setLn_kb_chiku(lnKbChiku);
			JSONObject jsonObject = new JSONObject(jsonModel);
			String postJsonData = jsonObject.toString();
			// Send post request
			String strResponse = G6Common.sendJsonMsg(postJsonData, MEDIA_API_2500_StopLiveImage);
			//レスポンスのresultが0以外場合
			Map<String, ?> checkedJson = null;
			if(strResponse != null) {
				checkedJson = G6Common.jsonValueCheck(strResponse);
            }
			if (checkedJson == null) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_RESPONSE_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.stopLiveImage()");
				return jsonResult;
			}
			//取得内容を応答する
			if ("0".equals(ConvUtil.convToString(checkedJson.get(G6Constant.ResponseParam.result.getValue())))) {
				errorDataModel.setErrorCode(G6Constant.SUCCESS_CD);
			} else {
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_MEDIA_RESULT.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.stopLiveImage()");
				return jsonResult;
			}
			
			// デコード済acntIDを設定したJWT認証トークンを付与
			errorDataModel.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
						
			jsonResult = G6Common.parseJSON(errorDataModel, acntLanguage);
			
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
		}
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2500Controller.stopLiveImage()");
		return jsonResult;
	}
}
