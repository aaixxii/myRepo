package com.nec.jp.G6Smartphone.service.ghs;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.AcntUserAuthModel;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP0200GhsDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;


@Service
public class SZWP0200GhsService {
	
    @Autowired
    private SZWP0200GhsDao sZWP0200GhsDao;
    
    public AcntUserAuthModel getMenuDisplayAuthorityByAcntId(String AcntID) throws ApplicationException {
		try {
			return sZWP0200GhsDao.getMenuDisplayAuthorityByAcntId(AcntID);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
    
    public String getSdLineKind(String lnkeibi) throws ApplicationException {
    	try {
			return sZWP0200GhsDao.getSdLineKind(lnkeibi);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
    
    public String getKeiykServiceInfo(String lnKeibi) throws ApplicationException {
    	try {
			return sZWP0200GhsDao.getKeiykServiceInfo(lnKeibi);
		} catch (NoResultException noResultE) {
			return "0";
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
    
	public String getKeibiSetPrivilegeInfo(String lnAcntUser, String lnKeibi)throws ApplicationException {
		try {
			return sZWP0200GhsDao.getKeibiSetPrivilegeInfo(lnAcntUser, lnKeibi);
		} catch (NoResultException noResultE) {
			return "0";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public String getKeibiHstPrivilegeInfo(String lnAcntUser, String lnKeibi)throws ApplicationException {
		try {
			return sZWP0200GhsDao.getKeibiHstPrivilegeInfo(lnAcntUser, lnKeibi);
		} catch (NoResultException noResultE) {
			return "0";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public String getRmtSetPrivilegeInfo(String lnAcntUser, String lnKeibi)throws ApplicationException {
		try {
			return sZWP0200GhsDao.getRmtSetPrivilegeInfo(lnAcntUser, lnKeibi);
		} catch (NoResultException noResultE) {
			return "0";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
