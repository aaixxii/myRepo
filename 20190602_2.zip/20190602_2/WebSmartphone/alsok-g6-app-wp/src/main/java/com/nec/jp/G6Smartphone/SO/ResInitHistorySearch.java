package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResInitHistorySearch implements ErrorHandler {

	private String errorCode;						// エラーコード
	private String errorMsg;						// エラーメッセージ
	private String dtTo;							// 年月日(To) 半角 YYYY/MM/DD形式
	private List<SdKobetuDataModel> sdKobetuItem;	// 
	private String acntID;

	public ResInitHistorySearch() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.dtTo = "";
		this.sdKobetuItem = new ArrayList<SdKobetuDataModel>();
		this.acntID = "";
	}

	public ResInitHistorySearch(String errorCode, String errorMsg, String dtTo, List<SdKobetuDataModel> sdKobetuItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.dtTo = dtTo;
		this.sdKobetuItem = sdKobetuItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getDtTo() {
		return dtTo;
	}

	public void setDtTo(String dtTo) {
		this.dtTo = dtTo;
	}

	public List<SdKobetuDataModel> getSdKobetuItem() {
		return sdKobetuItem;
	}

	public void setSdKobetuItem(List<SdKobetuDataModel> sdKobetuItem) {
		this.sdKobetuItem = sdKobetuItem;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
