package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;


/**
 * The persistent class for the C_QUE_CTRL_SIG database table.
 * 
 */
public class EQueCtrlModel implements Serializable {
	private static final long serialVersionUID = 1L;

	private String lnQueCtrl;
	private String hostNm;
	private String denkei;
	private String gouki;
	private String serialNum;
	private String connDevNum;
	private String devNum;
	private String subAddr;
	private String priority;
	private String cmdSeqNum;
	private String processNum;
	private String cmdCd;
	private String execCmd;
	private String fileType;
	private String dirNm;
	private String soapMsg;
	private Date enqTs;
	private Date deqAblTm;
	private Date deqTs;
	private String sts;
	private String centerErrDtl;
	private String rmResult;
	private String rmErrCd;
	private String ctlResult;
	private String ctlCmdRslt;
	private Date cmdTimeoutTm;
	private String idInsert;
	private String insertNm;
	private Date insertTs;
	private String idUpdate;
	private String updateNm;
	private Date updateTs;

	public EQueCtrlModel() {
	}
	
	public EQueCtrlModel(String lnQueCtrl, String sts) {
		super();
		this.lnQueCtrl = lnQueCtrl;
		this.sts = sts;
	}

	public String getLnQueCtrl() {
		return lnQueCtrl;
	}

	public void setLnQueCtrl(String lnQueCtrl) {
		this.lnQueCtrl = lnQueCtrl;
	}

	public String getHostNm() {
		return hostNm;
	}

	public void setHostNm(String hostNm) {
		this.hostNm = hostNm;
	}

	public String getDenkei() {
		return denkei;
	}

	public void setDenkei(String denkei) {
		this.denkei = denkei;
	}

	public String getGouki() {
		return gouki;
	}

	public void setGouki(String gouki) {
		this.gouki = gouki;
	}

	public String getSerialNum() {
		return serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getConnDevNum() {
		return connDevNum;
	}

	public void setConnDevNum(String connDevNum) {
		this.connDevNum = connDevNum;
	}

	public String getDevNum() {
		return devNum;
	}

	public void setDevNum(String devNum) {
		this.devNum = devNum;
	}

	public String getSubAddr() {
		return subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getCmdSeqNum() {
		return cmdSeqNum;
	}

	public void setCmdSeqNum(String cmdSeqNum) {
		this.cmdSeqNum = cmdSeqNum;
	}

	public String getProcessNum() {
		return processNum;
	}

	public void setProcessNum(String processNum) {
		this.processNum = processNum;
	}

	public String getCmdCd() {
		return cmdCd;
	}

	public void setCmdCd(String cmdCd) {
		this.cmdCd = cmdCd;
	}

	public String getExecCmd() {
		return execCmd;
	}

	public void setExecCmd(String execCmd) {
		this.execCmd = execCmd;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getDirNm() {
		return dirNm;
	}

	public void setDirNm(String dirNm) {
		this.dirNm = dirNm;
	}

	public String getSoapMsg() {
		return soapMsg;
	}

	public void setSoapMsg(String soapMsg) {
		this.soapMsg = soapMsg;
	}

	public Date getEnqTs() {
		return enqTs;
	}

	public void setEnqTs(Date enqTs) {
		this.enqTs = enqTs;
	}

	public Date getDeqAblTm() {
		return deqAblTm;
	}

	public void setDeqAblTm(Date deqAblTm) {
		this.deqAblTm = deqAblTm;
	}

	public Date getDeqTs() {
		return deqTs;
	}

	public void setDeqTs(Date deqTs) {
		this.deqTs = deqTs;
	}

	public String getSts() {
		return sts;
	}

	public void setSts(String sts) {
		this.sts = sts;
	}

	public String getCenterErrDtl() {
		return centerErrDtl;
	}

	public void setCenterErrDtl(String centerErrDtl) {
		this.centerErrDtl = centerErrDtl;
	}

	public String getRmResult() {
		return rmResult;
	}

	public void setRmResult(String rmResult) {
		this.rmResult = rmResult;
	}

	public String getRmErrCd() {
		return rmErrCd;
	}

	public void setRmErrCd(String rmErrCd) {
		this.rmErrCd = rmErrCd;
	}

	public String getCtlResult() {
		return ctlResult;
	}

	public void setCtlResult(String ctlResult) {
		this.ctlResult = ctlResult;
	}

	public String getCtlCmdRslt() {
		return ctlCmdRslt;
	}

	public void setCtlCmdRslt(String ctlCmdRslt) {
		this.ctlCmdRslt = ctlCmdRslt;
	}

	public Date getCmdTimeoutTm() {
		return cmdTimeoutTm;
	}

	public void setCmdTimeoutTm(Date cmdTimeoutTm) {
		this.cmdTimeoutTm = cmdTimeoutTm;
	}

	public String getIdInsert() {
		return idInsert;
	}

	public void setIdInsert(String idInsert) {
		this.idInsert = idInsert;
	}

	public String getInsertNm() {
		return insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getIdUpdate() {
		return idUpdate;
	}

	public void setIdUpdate(String idUpdate) {
		this.idUpdate = idUpdate;
	}

	public String getUpdateNm() {
		return updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}