package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the E_SYOCHI_KEKKA_RECV database table.
 * 
 */
@Entity
@Table(name="E_SYOCHI_KEKKA_RECV")
@NamedQuery(name="ESyochiKekkaRecvModel.findAll", query="SELECT e FROM ESyochiKekkaRecvModel e")
public class ESyochiKekkaRecvModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ESyochiKekkaRecvModelPK id;

	@Column(name="DATA_GOUKI")
	private String dataGouki;

	@Column(name="DATA_SUB_ADDR")
	private String dataSubAddr;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;

	@Column(name="LN_KB_INF")
	private String lnKbInf;

	@Lob
	@Column(name="RECV_MSG")
	private String recvMsg;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public ESyochiKekkaRecvModel() {
	}

	public ESyochiKekkaRecvModelPK getId() {
		return this.id;
	}

	public void setId(ESyochiKekkaRecvModelPK id) {
		this.id = id;
	}

	public String getDataGouki() {
		return this.dataGouki;
	}

	public void setDataGouki(String dataGouki) {
		this.dataGouki = dataGouki;
	}

	public String getDataSubAddr() {
		return this.dataSubAddr;
	}

	public void setDataSubAddr(String dataSubAddr) {
		this.dataSubAddr = dataSubAddr;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getLnKbChiku() {
		return this.lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getLnKbInf() {
		return this.lnKbInf;
	}

	public void setLnKbInf(String lnKbInf) {
		this.lnKbInf = lnKbInf;
	}

	public String getRecvMsg() {
		return this.recvMsg;
	}

	public void setRecvMsg(String recvMsg) {
		this.recvMsg = recvMsg;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}