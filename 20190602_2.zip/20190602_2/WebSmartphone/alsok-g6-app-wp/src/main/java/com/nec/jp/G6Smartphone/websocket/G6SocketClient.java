package com.nec.jp.G6Smartphone.websocket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.List;

import org.java_websocket.WebSocket;
import org.java_websocket.util.Base64;
import org.json.JSONObject;

import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.MYCD008;
import com.nec.jp.G6Smartphone.utility.G6DataSocket;

import jp.co.alsok.g6.common.log.ApplicationLog;

public class G6SocketClient {
    private static final ApplicationLog appLog = new ApplicationLog(G6SocketClient.class);

    public G6SocketClient() {
    	appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketClient.G6SocketClient()");
    	appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketClient.G6SocketClient()");
    }
    
    /**
     * preparing server media for downloading
     * @param liveIp
     * @param portServerSocket
     * @param command
     * @return a value received from media server
     * @throws ApplicationException 
     */
    public String downloadProcess(String liveIp, String portServerSocket, String command) throws ApplicationException {
    	appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketClient.downloadProcess()");
        // 画面に通知するJSON用Map
        String status = "";
        // ソケット
        Socket sock = null;
        // 読込み
        InputStream is = null;
        InputStreamReader isr = null;
        // 書込み
        OutputStream os = null;
        int len;
        
        try {
            // ソケットサーバに接続
            sock = new Socket(liveIp,Integer.parseInt(portServerSocket));
            // 読込み用Stream取得
            is = sock.getInputStream();
            isr = new InputStreamReader(is);
            // 書込み用Stream取得
            os = sock.getOutputStream();
            // 画面からのコマンドがRequestの場合
            if (MYCD008.COMMAND_REQ.equals(command)) {
                // サーバにリクエスト要求を送信
                os.write(MYCD008.DOWNLOAD_REQ.getBytes());
                os.flush();
                // waiting data from Media server
                while (is.available() == 0);
                // read data from Media server
                len = isr.read();
                final String progress = "" + (char) len;
                
                if (progress.equals(MYCD008.STATUS_END)) { // 実行終了
                    // ステータス設定
                    status = MYCD008.STATUS_END;
                } else if (progress.equals(MYCD008.STATUS_FAILED)) { // 実行失敗
                    // ステータス設定
                    status = MYCD008.STATUS_FAILED;
                } else if (progress.equals(MYCD008.STATUS_RUN)) { // 実行中
                    // ステータス設定
                    status = MYCD008.STATUS_RUN;
                }
            // 画面からのコマンドがExitの場合
            } else if (MYCD008.COMMAND_EXT.equals(command)) {
                // サーバにExit要求を送信
                // os.write("e".getBytes());
                os.write(MYCD008.DOWNLOAD_EXT.getBytes());
                os.flush();
                // ステータス設定
                status = MYCD008.COMMAND_EXT;
            }
        } catch (Exception e) {
            String errorLogMsg = G6Common.printStackTraceToString(e);
			throw new ApplicationException(G6Constant.UTILITY_CONTEXT,
					ErrorKey.EXCEPTION_PROCESSING_SOCKET.getValue(), errorLogMsg);
        } finally {
            // クローズ処理
            try {
                if(isr != null) {
                    isr.close();
                }
                if(os != null) {
                    os.close();
                }
                if (sock != null) {
                    sock.close();
                }
            } catch (Exception e) {
            	 appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
            }
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketClient.downloadProcess()");
        // サーバからの応答を画面に通知
        return status;
    }
    
    /**
     * download video from media server
     * in case file larger than 4mb, divide data to more sub-file(4mb) and template save in server
     * @param sockWeb
     * @param liveIp
     * @param portServerSocket
     * @param language
     * @param key
     * @param lst
     */
    public synchronized void downloadExecute(WebSocket sockWeb, 
                                            String liveIp, 
                                            int portServerSocket, 
                                            String language,
                                            String key,
                                            List<String> lst) {
    	appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "G6SocketClient.downloadExecute()");

    	// ソケット
        Socket sock = null;
        // 読込み
        InputStream is = null;
        BufferedInputStream bis = null;
        // 書込み
        OutputStream os = null;
        OutputStream resOs = null;
        DataOutputStream dos = null;
        BufferedOutputStream out = null;
        JSONObject obj;
        final G6DataSocket g6Obj = new G6DataSocket();
        
        try {
            // ソケット
            sock = new Socket(liveIp, portServerSocket);
            // 読込み用Stream取得
            is = sock.getInputStream();
            // 書込み用Stream取得
            os = sock.getOutputStream();
            // サーバにダウンロード要求を送信
            os.write(MYCD008.DOWNLOAD_EXEC.getBytes());
            os.flush();
            // waiting data from Media server
            while (is.available() == 0);

            // get data from socket server
            bis = new BufferedInputStream(is);
            byte[] buffer = new byte[MYCD008.BUFFER_SIZE];
            int index = -1;
            int len = 0;
            final int sizeStoredBuffer = g6Obj.getBlockSize();
            String fileName = "";
            
            while ((len = bis.read(buffer))  != -1) {
                index += 1;
                if (index < sizeStoredBuffer) {
                    // send block size 4mb
                    obj = g6Obj.convertData(G6Constant.SUCCESS_CD, "", MYCD008.STATUS_RUN, index, Base64.encodeBytes(buffer));
                    sockWeb.send(obj.toString());
                } else if (index == sizeStoredBuffer) {
                    // send command to client first start write data
                    obj = g6Obj.convertData(G6Constant.SUCCESS_CD, "", MYCD008.STATUS_WRITER, index, "");
                    sockWeb.send(obj.toString());
                    // Keeping data while waiting client write data
                    fileName = g6Obj.createFileName(key, index);
                    lst.add(fileName);
                    out =  new BufferedOutputStream(new FileOutputStream(fileName));
                    out.write(buffer, 0, len);
                    out.flush();
                } else {
                    // Keeping data while waiting client write data
                    if (index % sizeStoredBuffer == 0) {
                        if (out != null) {
                            out.flush();
                            out.close();
                        }
                        fileName = g6Obj.createFileName(key, index);
                        lst.add(fileName);
                        out =  new BufferedOutputStream(new FileOutputStream(fileName));
                        // write data into template file
                        out.write(buffer, 0, len);
                        out.flush();
                    } else {
                        if (out != null) {
                            // write data into template file
                            out.write(buffer, 0, len);
                            out.flush();
                        }
                    }
                }
            }

            if (index < sizeStoredBuffer) {
                obj = g6Obj.convertData(G6Constant.SUCCESS_CD, "", MYCD008.STATUS_END, -1, "");
                sockWeb.send(obj.toString());
            }
        } catch (Exception e) {
            obj = g6Obj.getDataError(language);
            sockWeb.send(obj.toString());
            // delete all file in key folder
            g6Obj.removeFolder(g6Obj.getPathFolder(key));
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 
        } finally {
            // クローズ処理
            try {
                if (out != null) {
                    out.flush();
                    out.close();
                }
                if (os != null) {
                    os.close();
                }
                if(bis != null) {
                    bis.close();
                }
                if (dos != null) {
                    dos.close();
                }
                if (resOs != null) {
                    resOs.close();
                }
                if (sock != null) {
                    sock.close();
                }
            } catch (Exception e) {
           	 	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 
            }
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "G6SocketClient.downloadExecute()");
    }
}