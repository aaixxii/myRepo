package com.nec.jp.G6Smartphone.dao.img;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.CameraDataSubModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP2600ImgDao {

	@PersistenceContext(unitName="imgPersistence")
	private EntityManager entityManager;

	public CameraDataSubModel getAccumulatedImageSound(String lnDev) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(T1.SAVE_PATH, '') as savePath,");
		strBuilder.append("			IFNULL(T1.FILE_NM, '') as fileNm,");
		strBuilder.append("			T1.LN_ACUM_IMGVOC as lnImgVoc");
		strBuilder.append(" FROM	I_MNG_ACCUMULATE T1");
		strBuilder.append(" WHERE	T1.DEL_FLG = :delFlg");
		strBuilder.append("			AND T1.LN_DEV = :lnDev");
		strBuilder.append(" ORDER BY T1.SHOT_STT_TSTM DESC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "CameraDataSubModelResult");
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		query.setParameter("lnDev", lnDev);
		query.setMaxResults(1);

		return (CameraDataSubModel) query.getSingleResult();
	}
}
