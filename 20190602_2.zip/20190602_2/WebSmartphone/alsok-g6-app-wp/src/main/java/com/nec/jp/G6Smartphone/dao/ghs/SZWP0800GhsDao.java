package com.nec.jp.G6Smartphone.dao.ghs;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;
import com.nec.jp.G6Smartphone.SO.KbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RDenkeiMngInfoModel;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuInfoModel;
import com.nec.jp.G6Smartphone.SO.RKbInfoModel;
import com.nec.jp.G6Smartphone.SO.WKbChikuRmInfoModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.EQueCtrlModel;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Constant;

@Repository
public class SZWP0800GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	public RKbInfoModel selectRKeibiInfoGhs(String lnKeibi) {
		final StringBuilder strBuilder = new StringBuilder();
		
        strBuilder.append(" SELECT IFNULL(rKeibi.LN_KEIBI, '') as lnKeibi,");
        strBuilder.append("        	IFNULL(rKeibi.GOUKI, '') as gouKi,");
        strBuilder.append("        	IFNULL(rKeibi.SERIAL_NUM, '') as serialNum,");
        strBuilder.append("        	IFNULL(rKeibi.SD_KEIYK_TYPE, '') as sdKeiykType");
        strBuilder.append(" FROM R_KEIBI rKeibi ");
        strBuilder.append(" 		INNER JOIN R_TENANT_MNG rTenantMng ON rKeibi.LN_KEIBI =  rTenantMng.LN_KEIBI");
		strBuilder.append(" WHERE	rTenantMng.LN_KEIBI = :lnKeibi");
		strBuilder.append(" 		AND rTenantMng.TENANT_STS ='1'");
        
        Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKbInfoModel0800GHSResult");
        query.setParameter("lnKeibi", lnKeibi);
        query.setMaxResults(1);
        
		return (RKbInfoModel) query.getSingleResult();
	}

	public RKbChikuInfoModel searchRKbChikuGhs(String lnKbChiku) {
		final StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append(" SELECT  IFNULL(rKbChiku.LN_KB_CHIKU, '') as lnKbChiku,");
        strBuilder.append("  		IFNULL(rKbChiku.LN_KEIBI, '') as lnKeibi,");
        strBuilder.append("  		IFNULL(rKbChiku.CHIKU, '') as chiku,");
        strBuilder.append("  		IFNULL(rKbChiku.SUB_ADDR, '') as subAddr,");
        strBuilder.append("        	IFNULL(rKbChiku.SD_KOBETU_NM, '') as sdKobetuNm,");
        strBuilder.append("        	IFNULL(rKbChiku.GYOUMU_CD, '') as gyoumuCd,");
        strBuilder.append("        	IFNULL(rKbChiku.HOSOKU_CD, '') as hosokuCd");
        strBuilder.append(" FROM R_KB_CHIKU rKbChiku ");
        strBuilder.append(" 		INNER JOIN R_KEIBI rKeibi ON rKbChiku.LN_KEIBI = rKeibi.LN_KEIBI");
		strBuilder.append(" WHERE	rKbChiku.LN_KB_CHIKU = :lnKbChiku");
        
        Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKbChikuInfoModel0800GHSResult");
        query.setParameter("lnKbChiku", lnKbChiku);
        query.setMaxResults(1);
        
		return (RKbChikuInfoModel) query.getSingleResult();
	}
	
	public RDenkeiMngInfoModel searchRDenkeiMngGhs(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(rDenkeiMng.LN_DENKEI_MNG, '') as lnDenkeiMng,");
		strBuilder.append(" 		IFNULL(rDenkeiMng.DENKEI, '') as denkei");
		strBuilder.append(" FROM	R_DENKEI_MNG rDenkeiMng");
		strBuilder.append(" WHERE	rDenkeiMng.LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND rDenkeiMng.FLG_LAST = :lastFlg");

		 Query query = entityManager.createNativeQuery(strBuilder.toString(), "RDenkiMngInfo0800GHSModel");
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("lastFlg", G6CodeConsts.CD009.LATEST);
		query.setMaxResults(1);

		return (RDenkeiMngInfoModel) query.getSingleResult();
	}

	public WKbChikuRmInfoModel searchWKbChikuRmSetGhs(String lnKbChiku) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(wKbChikuRmSet.LN_KB_CHIKU, '') as lnKbChiku,");
		strBuilder.append(" 		IFNULL(wKbChikuRmSet.KB_SET_STS_N0, '') as kbSetStsNo,");
		strBuilder.append(" 		DATE_FORMAT(wKbChikuRmSet.RM_SET_TS, '%Y/%m/%d %H:%i:%s') as rmSetTs");
		strBuilder.append(" FROM	W_KB_CHIKU_RM_SET wKbChikuRmSet");
		strBuilder.append(" WHERE	wKbChikuRmSet.LN_KB_CHIKU = :lnKbChiku");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKbChikuRmSetInfo0800GHSModel");
		query.setParameter("lnKbChiku", lnKbChiku);
		query.setMaxResults(1);

		return (WKbChikuRmInfoModel) query.getSingleResult();
	}

	@Transactional("transactionManagerGhs")
	public boolean deleteWKbChikuRmSet(String lnKbChiku) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" delete from	W_KB_CHIKU_RM_SET");
		strBuilder.append(" where ln_kb_chiku = :lnKbChiku");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKbChiku", lnKbChiku);
		
		if(query.executeUpdate() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	@Transactional("transactionManagerGhs")
	public boolean insertWKbChikuRmSet(String cmdSeqNum, String lnKbChiku, String acntID, String acntNm, String lnQueCtrlSig, String KbSetStsn0, String userKindNo, Date dateTime) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" INSERT INTO W_KB_CHIKU_RM_SET");
		strBuilder.append("		(LN_KB_CHIKU, LN_SET_USER, USER_KIND_N0, LN_QUE_CTRL, CMD_SEQ_NUM, KB_SET_STS_N0, RM_SET_TS, ID_INSERT, INSERT_NM, INSERT_TS)");
		strBuilder.append(" VALUES (?,?,?,?,?,?,?,?,?,?)");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter(1, lnKbChiku);
		query.setParameter(2, acntID);
		query.setParameter(3, userKindNo);
		query.setParameter(4, lnQueCtrlSig);
		query.setParameter(5, cmdSeqNum);
		query.setParameter(6, KbSetStsn0);
		query.setParameter(7, dateTime);
		query.setParameter(8, acntID);
		query.setParameter(9, acntNm);
		query.setParameter(10, dateTime);

		if (query.executeUpdate() > 0) {
            return true;
        }
        return false;
	}
	
	public EQueCtrlModel searchEQueCtrlGhs(String comSeqNo) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(eQueCtrl.LN_QUE_CTRL, '') as lnQueCtrl,");
		strBuilder.append(" 		IFNULL(eQueCtrl.STS, '') as sts");
		strBuilder.append(" FROM	E_QUE_CTRL eQueCtrl");
		strBuilder.append(" WHERE	eQueCtrl.CMD_SEQ_NUM = :comSeqNo");
		strBuilder.append("			AND eQueCtrl.EXEC_CMD = 'kbstset'");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "EQueCtrlInfo0800GHSModel");
		query.setParameter("comSeqNo", comSeqNo);
		query.setMaxResults(1);

		return (EQueCtrlModel) query.getSingleResult();
	}
	
	

	public String searchSysKbChikuGhs(String lnKbChiku, String cmdSeqNum) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	wKbChikuRmSet.LN_KB_CHIKU as lnKbChiku");
		strBuilder.append(" FROM	W_KB_CHIKU_RM_SET wKbChikuRmSet");
		strBuilder.append(" WHERE	wKbChikuRmSet.LN_KB_CHIKU = :lnKbChiku");
		strBuilder.append("			AND wKbChikuRmSet.CMD_SEQ_NUM = :cmdSeqNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKbChiku", lnKbChiku);
		query.setParameter("cmdSeqNum", cmdSeqNum);

		return query.getSingleResult().toString();
	}
}
