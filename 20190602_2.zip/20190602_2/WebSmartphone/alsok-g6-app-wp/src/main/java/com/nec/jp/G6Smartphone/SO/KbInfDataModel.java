package com.nec.jp.G6Smartphone.SO;

public class KbInfDataModel {

	private String sigHasseiTs;
	private String nickName;
	private String keiykNm;
	private String keibiName;
	private String devNm;
	private String cntLnKbInf;
	private String lnRAuthPicInf;
	private String lnKbInf;
	public KbInfDataModel() {
		this.sigHasseiTs = "";
		this.nickName = "";
		this.keiykNm = "";
		this.keibiName = "";
		this.devNm = "";
		this.cntLnKbInf = "";
		this.lnRAuthPicInf = "";
		this.lnKbInf = "";
	}
	public KbInfDataModel(String sigHasseiTs, String nickName, String keiykNm, String keibiName, String devNm,
			String cntLnKbInf, String lnRAuthPicInf, String lnKbInf) {
		this.sigHasseiTs = sigHasseiTs;
		this.nickName = nickName;
		this.keiykNm = keiykNm;
		this.keibiName = keibiName;
		this.devNm = devNm;
		this.cntLnKbInf = cntLnKbInf;
		this.lnRAuthPicInf = lnRAuthPicInf;
		this.lnKbInf = lnKbInf;
	}
	public String getSigHasseiTs() {
		return sigHasseiTs;
	}
	public void setSigHasseiTs(String sigHasseiTs) {
		this.sigHasseiTs = sigHasseiTs;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getKeiykNm() {
		return keiykNm;
	}
	public void setKeiykNm(String keiykNm) {
		this.keiykNm = keiykNm;
	}
	public String getKeibiName() {
		return keibiName;
	}
	public void setKeibiName(String keibiName) {
		this.keibiName = keibiName;
	}
	public String getDevNm() {
		return devNm;
	}
	public void setDevNm(String devNm) {
		this.devNm = devNm;
	}
	public String getCntLnKbInf() {
		return cntLnKbInf;
	}
	public void setCntLnKbInf(String cntLnKbInf) {
		this.cntLnKbInf = cntLnKbInf;
	}
	public String getLnRAuthPicInf() {
		return lnRAuthPicInf;
	}
	public void setLnRAuthPicInf(String lnRAuthPicInf) {
		this.lnRAuthPicInf = lnRAuthPicInf;
	}
	public String getLnKbInf() {
		return lnKbInf;
	}
	public void setLnKbInf(String lnKbInf) {
		this.lnKbInf = lnKbInf;
	}
}
