package com.nec.jp.G6Smartphone.dao.com;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.ResGetOtherInfo;

@Repository
public class SZWP2000ComDao {

	@PersistenceContext(unitName="comPersistence")
	private EntityManager entityManager;

	public String getALSOKGuardCenterInfo(String keibiGcCd) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT		kgc.GC_TEL_NUM");
		strBuilder.append(" FROM		K_GC kgc");
		strBuilder.append(" WHERE		kgc.GC_CD = :keibiGcCd");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("keibiGcCd", keibiGcCd);

		return query.getSingleResult().toString();
	}

	public String getBusinessInfo(String jisshiJigyouCd) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT		IFNULL(kjigyou.JIGYOU_TEL_NUM, '')");
		strBuilder.append(" FROM		K_JIGYOU kjigyou");
		strBuilder.append(" WHERE		kjigyou.JIGYOU_CD = :jisshiJigyouCd");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("jisshiJigyouCd", jisshiJigyouCd);

		return query.getSingleResult().toString();
	}

	public ResGetOtherInfo getOtherInfo(String juchuJigyouCd) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT		IFNULL(kjigyou.JIGYOU_TEL_NUM, '') as telNum");
		strBuilder.append(" ,			IFNULL(kjigyou.JIGYOU_NM, '') as jigyouNm");
		strBuilder.append(" FROM		K_JIGYOU kjigyou");
		strBuilder.append(" WHERE		kjigyou.JIGYOU_CD = :juchuJigyouCd");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "ResGetOtherInfoResult");
		query.setParameter("juchuJigyouCd", juchuJigyouCd);

		return (ResGetOtherInfo)query.getSingleResult();
	}
}
