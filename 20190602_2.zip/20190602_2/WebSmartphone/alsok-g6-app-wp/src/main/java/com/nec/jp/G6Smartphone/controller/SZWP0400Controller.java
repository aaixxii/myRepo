package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;
import com.nec.jp.G6Smartphone.SO.LockedStatusDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.ResGetKeibiStatus;
import com.nec.jp.G6Smartphone.SO.ResGetLockedStatus;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP0400Service;
import com.nec.jp.G6Smartphone.service.ghs.SZWP0400GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;

import jp.co.alsok.g6.common.log.ApplicationLog;

import com.nec.jp.G6Smartphone.utility.G6Constant.DispID;
import com.nec.jp.G6Smartphone.utility.StringUtils;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

@Controller
public class SZWP0400Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP0400Controller.class);
	
    //JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
	@Autowired
	SZWP0400Service sZWP0400Service;
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;
	@Autowired
	SZWP0400GhsService sZWP0400GhsService;

	@Value("${cmdVer2}")
	String cmdVer2;
	
	@Value("${timeout}")
	Integer timeout;
	
	@Value("${timeSleep}")
	Integer timeSleep;
	
	@Value("${host_name}")
	String hostName;
	
	@Value("${mainGSMSubaddr}")
	String mainGSMSubaddr;
	
	@Value("${keibiSrchHistoryGSMChiku}")
	String keibisakiViewGSMChiku;
	
	@Value("${managerRoomGSMSubaddr}")
	String managerRoomGSMSubaddr;
	
	@Value("${setubiGSMSubaddr}")
	String setubiGSMSubaddr;
	
	@Value("${commonGSMSubaddr}")
	String commonGSMSubaddr;
	
	@Value("${ctrGSMSubaddr}")
	String ctrGSMSubaddr;
	
	@Value("${ctrOtherGSMSubaddr}")
	String ctrOtherGSMSubaddr;
	
	@Value("${jukoGSMSubaddr}")
	String jukoGSMSubaddr;
	
	@Value("${mainChiku}")
	String mainChiku;
	
	
	/*
	 * Get data from R_KB_CHIKU, R_KB_CHIKU_STS table
	 * @param: acntID, lnKeibi
	 * return: object ResGetKeibiStatus as JSON
	 */
	@RequestMapping(value = "/getKeibiStatus", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getKeibiStatus(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0400Controller.getKeibiStatus()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetKeibiStatus resGetKeibiStatus = new ResGetKeibiStatus();
		
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntType = "";
		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getKeibiStatus()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getKeibiStatus()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 4) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getKeibiStatus()");
				return jsonResult;
			}

			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.lnKeibi.getValue());
					add(RequestParam.acntSbt.getValue());
					add(RequestParam.lnKeiyk.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getKeibiStatus()");
				return jsonResult;
			}

			// リクエスト情報取得
			// unused: リクエスト情報からアカウント種別を取得する

			// TODO SZWP0400：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);
			
			acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				//G6
				jsonResult = doKeibi(mapParam, resGetKeibiStatus, acntLanguage, tokenMapParam);
			
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				//GHS
				jsonResult = doIjyo(mapParam, acntType, acntLanguage, tokenMapParam);
			}
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetKeibiStatus, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			jsonResult = G6Common.messageLogHandler(resGetKeibiStatus, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getKeibiStatus()");
		return jsonResult;
	}

	/*
	 * Get data from R_KB_CHIKU, R_KB_CHIKU_STS table
	 * @param: acntID, acntNm, lnKbChiku
	 * return: object ResGetLockedStatus as JSON
	 */
	@RequestMapping(value = "/getLockedStatus", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getLockedStatus(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0400Controller.getLockedStatus()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetLockedStatus resGetLockedStatus = new ResGetLockedStatus();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntType = "";

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatus()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatus()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 5) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatus()");
				return jsonResult;
			}

			// Build require parameters
			Map<String, Boolean> mapRequireParam = new HashMap<String, Boolean>() {
				private static final long serialVersionUID = 1L;
				{
					put(RequestParam.acntID.getValue(), true);
					put(RequestParam.acntNm.getValue(), true);
					put(RequestParam.lnKbChiku.getValue(), true);
					put(RequestParam.lnKeibi.getValue(), true);
					put(RequestParam.acntSbt.getValue(), true);
				}
			};
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.lnKbChiku.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, mapRequireParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatus()");
				return jsonResult;
			}

			// unused: リクエスト情報取得

			// TODO SZWP0400：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);
			
			acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				//G6
				jsonResult = update(mapParam, acntLanguage, tokenMapParam);
				
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				//GHS
				jsonResult = doIjyo(mapParam, acntType, acntLanguage, tokenMapParam);
			}
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetLockedStatus, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetLockedStatus, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetLockedStatus, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatus()");
		return jsonResult;
	}


	
	
	/**
	 * G6======================================================================================================
	 */
	private String doKeibi(Map<String, Object> mapParam, ResGetKeibiStatus resGetKeibiStatus, String acntLanguage, Map<String, String> tokenMapParam) throws ApplicationException {
		String jsonResult = "";
		String acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
		String lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
		String lnKeiyk = mapParam.get(RequestParam.lnKeiyk.getValue()).toString();
		String lnKbChiku = "";
		String dispID = DispID.P0400.getValue();
		List<RKbChikuDataModel> rKbChikuDataModelList = new ArrayList<RKbChikuDataModel>();
		
		// 初期表示情報の取得
		// 使用可能警備地区情報を取得する
		// 7-2.A)操作可能警備地区情報の取得
		rKbChikuDataModelList = sZWP0400Service.getOperableSecureAreaInfo(acntID, lnKeibi);

		// 使用可能警備地区情報が取得できた場合
		if (rKbChikuDataModelList.size() > 0) {
			// 取得した使用可能警備地区情報数分、以下の処理を繰り返す。
			// 警備エリア情報を取得する
			// 7-2.B)警備エリア情報の取得
			for (RKbChikuDataModel rKbChikuDataModel : rKbChikuDataModelList) {
				if ("".equals(lnKbChiku)) {
					lnKbChiku = rKbChikuDataModel.getLnKbChiku();
				}
	            // 警備エリア.LN_警備エリア論理番号
				List<String> areaItemList = sZWP0400Service.getKeibiAreaInfoList(rKbChikuDataModel.getLnKbChiku());
				rKbChikuDataModel.setAreaItem(areaItemList);
			}
			// アカウント区分による権限チェック
			int userAuth = 0;
            int acntResult = G6Common.invalidateUserAcntKbn(commonComService, commonService, acntID, dispID);
            if (0 == acntResult) {
            	userAuth = 0;
            } else if (2 == acntResult) {
            	userAuth = 2;
            } else {
	            String firstword = dispID.substring(0, 1);
	            if ("P".equals(firstword)) {
	                userAuth = commonService.getAuth(acntID, lnKeiyk, lnKeibi, lnKbChiku, dispID);
	            } else {
	                userAuth = commonService.getAuth(acntID, lnKeiyk, lnKeibi, lnKbChiku, "P" + dispID);
	            }
            }
            resGetKeibiStatus.setUserAuth(String.valueOf(userAuth));

		// 使用可能警備地区情報が取得できなかった場合
		} else {
			jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REGISTEREDKEIBI_NOT_FOUND.getValue(), acntLanguage);

			// 処理終了
			return jsonResult;
		}

		resGetKeibiStatus.setErrorCode(G6Constant.SUCCESS_CD);
		resGetKeibiStatus.setrKbChikuItem(rKbChikuDataModelList);
	
		//デコード済acntIDを設定したJWT認証トークンを付与
		resGetKeibiStatus.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
		
		jsonResult = G6Common.parseJSON(resGetKeibiStatus, acntLanguage);
		return jsonResult;
		
	}
	
	private String update(Map<String, Object> mapParam, String acntLanguage, Map<String, String> tokenMapParam) 
			throws ApplicationException, JWTCreationException {
		// 戸締り状態表示情報の取得
		String jsonResult ="";
		List<String> cmdSeqNumList = new ArrayList<String>();
		List<LockedStatusDataModel> lockedStatusDataModelList = new ArrayList<LockedStatusDataModel>();
		ResGetLockedStatus resGetLockedStatus = new ResGetLockedStatus();
		int remainCmdSq = 0;
		
		List<String> lnKbChikuList = G6Common.readParamToArrayObject(mapParam, RequestParam.lnKbChiku.getValue());
		String acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
		String acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
		HashMap<String, List<String>> targetDevMap = new HashMap<String, List<String>>();

		// リクエスト情報の警備先地区論理番号の件数分ループ
		for (String lnKbChiku : lnKbChikuList) {
			// 制御信号登録用情報を取得する。
			// 8-2.戸締り状態処理ＤＢ検索内容
			RCtlDevDataSubModel rCtlDevDataSubModel = sZWP0400Service.getSecureInfo(lnKbChiku);
			List<String> tmpLnDevList = sZWP0400Service.getLnDevLpList(lnKbChiku);
			
			if (null != rCtlDevDataSubModel) {
				// コマンドシーケンス番号
				// String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
			    final String cmdSeqNum = commonService.getCmdSeq();
			    final String transNo = commonService.getTranSeq();
			    final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
			    String subAddr = rCtlDevDataSubModel.getSubAddr(); 
			    if (subAddr == null || "".equals(subAddr.trim())) { 
			        subAddr = "    "; 
			    } 
				// Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum);
			    Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, transNo, subAddr);
				// 戸締り状態取得要求コマンドを発行する
				// 8-3.戸締り状態取得要求処理'
				String soapMsg = this.createSoapMsg(mapSoap);

				mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
				mapSoap.put(RequestParam.acntID.getValue(), acntID);
				mapSoap.put(RequestParam.acntNm.getValue(), acntNm);

				commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

				cmdSeqNumList.add(cmdSeqNum);
				targetDevMap.put(cmdSeqNum, tmpLnDevList);
				remainCmdSq++;
			} else {
				cmdSeqNumList.add("");
			}

			lockedStatusDataModelList.add(new LockedStatusDataModel(lnKbChiku, ""));
		}

		long beginTime = System.currentTimeMillis();
		int countSleep = 0;

		// プロパティファイルから取得した「タイムアウト時間」までループ
		// start loop
		while (true) {
            // checking timeout
            if (G6Common.isTimeOut(timeout.intValue(), beginTime)) {
                break;
            }

			// リクエスト情報の警備先地区論理番号の件数分ループ
			for (int i = 0; i < cmdSeqNumList.size(); i++) {
				if (!"".equals(cmdSeqNumList.get(i))) {
					// 制御信号キューの状態を確認する
					// 8-4.戸締り状態取得処理'
					ControlQueueStatusModel controlQueueStatusModel = sZWP0400Service.getControlQueueStsInfo(cmdSeqNumList.get(i));

					if (null == controlQueueStatusModel) {
						jsonResult = G6Common.messageUpdateLogHandler(resGetLockedStatus, G6Constant.FAIL_HTML_CD, 
								ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

						// 処理終了
						return jsonResult;
					}

					// 状態が「成功」の場合
					if (G6CodeConsts.CD179.SUCCESS.equals(controlQueueStatusModel.getSts())) {
					 // 8-4)で取得したSOAP電文より、
                        // ループ状態通知（レスポンス）タグ <lpinfrd_rsp>の中の
                        // 下記タグ（タグ名称<tag>）の内容を取得する。
                        // ②センサー状態<lgtm_st>
                        //String execResult = "";
                        //execResult = G6Common.getElementByTagName(controlQueueStatusModel.getSoapMsg(), G6Constant.LGTM_ST);
						
						// センサー状態
						String sensSts = "";
						// cmdSeqNumより対象のln_devを取得する
						List<String> targertDevList = targetDevMap.get(cmdSeqNumList.get(i));
						// 対象機器の最新の状態を取得する。
						for (String targetLnDev : targertDevList) {
							ControlQueueStatusModel loopInfo = sZWP0400Service.getLoopStsDtlInfo(targetLnDev);
							
	                        // 戸締り状態の項目設定
	                        // 戸締り状態情報が取得できた場合
							if (null != loopInfo) {
								// 複数機器で１つでも異常があれば異常とする。
								if ("".equals(sensSts) || G6CodeConsts.CD001.ABNORMAL.equals(loopInfo.getSts())) {
									sensSts = loopInfo.getSts();
								}
		                    // 戸締り状態情報が取得できなかった場合
	                        } else {
	                            // 共通「エラーメッセージ取得処理」を呼び出し、エラーメッセージを取得する。
	                            jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.FAIL_POPUP_CD,
	                                    ErrorKey.NO_LOCKIN_STS_INFO.getValue(), acntLanguage);

	                            // 処理終了
	                            return jsonResult;
	                        }							
						}
						
						lockedStatusDataModelList.get(i).setLockedSts(sensSts);

                        // 制御状態読出要求のコマンドシーケンス番号を削除する
                        cmdSeqNumList.set(i, "");
                        remainCmdSq--;
					} else {//状態が「成功」の以外場合
					    // 次のリストへ移る
                        continue;
					}
				}
			}

			// 制御状態読出要求のコマンドシーケンス番号が残っていない場合
			if (0 == remainCmdSq) {
				resGetLockedStatus.setErrorCode(G6Constant.SUCCESS_CD);
				resGetLockedStatus.setLockedStatusItem(lockedStatusDataModelList);
				
				//デコード済acntIDを設定したJWT認証トークンを付与
				resGetLockedStatus.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
				
				jsonResult = G6Common.parseJSON(resGetLockedStatus, acntLanguage);

				// 処理終了
				return jsonResult;
			}

			// プロパティファイルから取得「待機時間」の分、一定時間待機し、監視を継続
			G6Common.sleepOperation(timeout.intValue(), timeSleep.intValue(), countSleep);
			countSleep++;
		}
		// end loop

		// タイムアウト発生時
		// 共通「メッセージ取得処理」を呼び出し、エラーメッセージを取得する。
		jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.FAIL_POPUP_CD,
				ErrorKey.ERROR_SERVER_TIMEOUT.getValue(), acntLanguage);
		
		return jsonResult;
	}
	
	private Map<String, String> createParamForSoap(RCtlDevDataSubModel rCtlDevDataSubModel, String cmdsqNo, String transNo, String subAddr) { 
		Map<String, String> mapSoap = new HashMap<String, String>();

		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer2);
//		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, transNo); 
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataSubModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, rCtlDevDataSubModel.getCustomerNum1());
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataSubModel.getGouKi());
//		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, rCtlDevDataSubModel.getSubAddr());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, subAddr); 
//		mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.LINETYPE, rCtlDevDataSubModel.getSdLineKind());
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.LPINFRD);

		mapSoap.put(G6Constant.MYCD003.HOSTNM, hostName);
//		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_9_LOW);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.LPINFRD);
		mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.UNSENT);

		return mapSoap;
	}

	private String createSoapMsg(Map<String, String> mapSoap) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
		// データ部作成
		// 共通項目タグ設定
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 共通クラスから取得したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");

		// フッター部作成
		builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

		return builder.toString();
	}
	
	
	
	/**
	 * GHS======================================================================================================
	 */
	private String doIjyo(Map<String, Object> mapParam, String acntType, String acntLanguage, Map<String, String> tokenMapParam) throws NumberFormatException, ApplicationException {
		String jsonResult = "";
		String acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
		String lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
		ResGetKeibiStatus resGetKeibiStatus = new ResGetKeibiStatus();
		
		if(acntType.equals(G6CodeConsts.CD027.GHS_THE_USER)) {
			//◇ログインユーザーの権限を取得する
			//7-3.B)権限の取得
			String auth = sZWP0400GhsService.getFlgKbSetDispByAcntId(acntID);
			if(StringUtils.isEmpty(auth)) {
				jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_AUTH_ERROR_MESSAGE.getValue(), acntLanguage);

				return jsonResult;
			}
		}
		
		// GSHSフラグ情報の取得
		//7-3.C)GSHSフラグ情報の取得
		String gshsFlg = sZWP0400GhsService.selectGshsFlgInfo(lnKeibi);
		
		// ◇GSHSフラグが「2：GSM」の場合
		List<String>  subAddr = new ArrayList<String>();
		if (G6CodeConsts.CD259.S_860M_GSM.equals(gshsFlg)) {
			subAddr = setSubAddr();
        }
		
		//◇警備先地区の警備状態／空室状態情報を取得する	
		//7-3.A)操作可能警備地区情報の取得
		List<RKbChikuDataModel> infoList = getGhsInfoList(lnKeibi, subAddr);
		if (infoList == null || infoList.size() == 0) {
            jsonResult = G6Common.messageHandler(resGetKeibiStatus, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REGISTEREDKEIBI_NOT_FOUND.getValue(), acntLanguage);

			return jsonResult;
        }
		
		resGetKeibiStatus.setErrorCode(G6Constant.SUCCESS_CD);
		resGetKeibiStatus.setrKbChikuItem(infoList);
		
		//デコード済acntIDを設定したJWT認証トークンを付与
		resGetKeibiStatus.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
		
		// GHSの場合、権限2設定
		resGetKeibiStatus.setUserAuth("2");
        
		jsonResult = G6Common.parseJSON(resGetKeibiStatus, acntLanguage);
		
		return jsonResult;
	}

	private List<RKbChikuDataModel> getGhsInfoList(String lnKeibi, List<String> subAddr) throws ApplicationException {

        List<RKbChikuDataModel> infoList = new ArrayList<RKbChikuDataModel>();
        List<RKbChikuDataModel> infoListMain = new ArrayList<RKbChikuDataModel>();
        List<RKbChikuDataModel> infoListSub = new ArrayList<RKbChikuDataModel>();
        
        // 操作可能警備地区情報の取得.
        infoList = sZWP0400GhsService.searchGhsListInfo(lnKeibi, subAddr);

        for (RKbChikuDataModel item : infoList) {
            // 地区
            // 警備操作先一覧の取得で取得した個別名称。メイン地区の場合は「メイン地区」を表示。
            if (StringUtils.isEmpty(item.getLnKbChiku())) {
                item.setSdKobetuNm(mainChiku);
            }

            // 戸締り確認※GHSの場合、「-」
            item.setTojimariSts(G6Constant.HYPHEN);
            
            // メイン地区判断
            if (item.getSubAddr() == null || item.getSubAddr().isEmpty()) {
                item.setSdKobetuNm(mainChiku);
                infoListMain.add(item);
            } else {
                infoListSub.add(item);
            }
        }

        // 警備先の地区がメイン地区のみの場合は「メイン地区」を表示する。
        // メイン地区以外の地区が存在する場合は「メイン地区」を表示しない。
        if (infoListMain.size() > 0 && infoListSub.size() == 0) {
            return infoListMain;
        } else {
            return infoListSub;
        }
    }
	
	private List<String> setSubAddr() {
		// ファイル名：[setting.properties]
        // キー名：[keibisakiViewGSMChiku]"
        // " プロパティファイルから取得した表示対象の警備先地区に対するサブアドレス区分を取得する
        // ファイル名：[setting.properties]
        // キー名：[XXXXGSMSubaddr] ※XXXX:対象のサブアドレス区分"
		StringBuilder subAddr = new StringBuilder();
		
        String[] keibiSrchHistoryGSMChiku = keibisakiViewGSMChiku.split(G6Constant.COMMA);
        
        if (keibiSrchHistoryGSMChiku.length > 0) {
//            subAddr.append(G6Constant.LEFT_BRACKET_HALF);
            for (int i = 0; i < keibiSrchHistoryGSMChiku.length; i++) {
                String sub = null;
                if (G6Constant.SUBADDR_1.equals(keibiSrchHistoryGSMChiku[i])) {
                    sub = mainGSMSubaddr;
                } else if (G6Constant.SUBADDR_2.equals(keibiSrchHistoryGSMChiku[i])) {
                    sub = managerRoomGSMSubaddr;
                } else if (G6Constant.SUBADDR_3.equals(keibiSrchHistoryGSMChiku[i])) {
                    sub = setubiGSMSubaddr;
                } else if (G6Constant.SUBADDR_4.equals(keibiSrchHistoryGSMChiku[i])) {
                    sub = commonGSMSubaddr;
                } else if (G6Constant.SUBADDR_5.equals(keibiSrchHistoryGSMChiku[i])) {
                    sub = ctrGSMSubaddr;
                } else if (G6Constant.SUBADDR_6.equals(keibiSrchHistoryGSMChiku[i])) {
                    sub = ctrOtherGSMSubaddr;
                } else if (G6Constant.SUBADDR_7.equals(keibiSrchHistoryGSMChiku[i])) {
                    sub =jukoGSMSubaddr;
                } else {
                    subAddr = null;
                    break;
                }
                StringBuilder subAddrNew = new StringBuilder();
                String[] subArray = sub.split(G6Constant.COMMA);
                for (int j = 0; j < subArray.length; j++) {
                    if (!subArray[j].contains(G6Constant.HYPHEN)) {
                        subAddrNew.append(subArray[j]);
                        subAddrNew.append(G6Constant.COMMA);
                        continue;
                    }
                    String[] str = subArray[j].split(G6Constant.HYPHEN);
                    if (str.length != G6Constant.NO_2) {
                        continue;
                    }
                    int bf = Integer.parseInt(str[0]);
                    int ls = Integer.parseInt(str[1]);
                    if (bf >= ls) {
                        continue;
                    }
                    for (int k = bf; k <= ls; k++) {
                        subAddrNew.append(StringUtils.addCharForStrL(String.valueOf(k), '0', G6Constant.NO_4));
                        subAddrNew.append(G6Constant.COMMA);
                    }
                }
                sub = subAddrNew.substring(0, subAddrNew.length() - G6Constant.NO_1);
                if (StringUtils.isBlank(sub)) {
                    subAddr.append(StringUtils.space(G6Constant.NO_4));
                } else {
                    subAddr.append(sub);
                }
                if (i < keibiSrchHistoryGSMChiku.length - G6Constant.NO_1) {
                    subAddr.append(G6Constant.COMMA);
                }
            }
//            if (subAddr != null) {
//                subAddr.append(G6Constant.RIGHT_BRACKET_HALF);
//            }
        }
        
        if (subAddr != null && !StringUtils.isEmpty(subAddr.toString())) {
			return G6Common.stringToArray(subAddr.toString());
		} else {
			return new ArrayList<String>();
		}
	}
}
