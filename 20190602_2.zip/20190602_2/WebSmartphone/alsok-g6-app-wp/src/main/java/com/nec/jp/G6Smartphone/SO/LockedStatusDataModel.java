package com.nec.jp.G6Smartphone.SO;

public class LockedStatusDataModel {

	private String lnKbChiku;		// 警備先地区.LN_警備先地区論理番号
	private String lockedSts;		// ループ状態読出コマンドにて戸締り状態（正常／異常）を取得する。

	public LockedStatusDataModel(String lnKbChiku, String lockedSts) {
		this.lnKbChiku = lnKbChiku;
		this.lockedSts = lockedSts;
	}

	public String getLnKbChiku() {
		return lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getLockedSts() {
		return lockedSts;
	}

	public void setLockedSts(String lockedSts) {
		this.lockedSts = lockedSts;
	}
}
