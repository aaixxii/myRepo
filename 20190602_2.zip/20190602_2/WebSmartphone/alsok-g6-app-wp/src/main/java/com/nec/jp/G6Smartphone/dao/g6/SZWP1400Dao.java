package com.nec.jp.G6Smartphone.dao.g6;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.HistoryDataModel;

@Repository
public class SZWP1400Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	
	private StringBuilder getDistrictPulldownInfoSql(List<Set<String>> type1, List<Set<String>> type2) {
		StringBuilder builder = new StringBuilder();

		builder.append(" SELECT DATE_FORMAT(a.SEND_TS, '%Y/%m/%d %H:%i:%s') as sendTs,");
		builder.append("		IFNULL(b.SD_KOBETU_NM, '') as sdKobetuNm,");
		builder.append("		a.SIG_KIND_2 as sigKind2,");
		builder.append("		a.SIG_KIND_1 as sigKind1,");
		builder.append("		IFNULL(a.OPERATION_USER, '') as operationUser,");
		builder.append("		CAST(a.RM_KIND as CHARACTER) as rmKind,");
		builder.append("		IFNULL(a.BODY, '') as body,");
		builder.append("		a.SIG_NM as sigNm,");
		builder.append("		a.LN_KB_INF as lnKbInf,");
		builder.append("		b.LN_KB_CHIKU as lnKbChiku,");
		builder.append("		IFNULL((SELECT c.KB_AREA_NM FROM R_KB_AREA c WHERE c.LN_KB_CHIKU = b.LN_KB_CHIKU LIMIT 1), '') AS kbAreaNm,");
		builder.append("		IFNULL(d.CARD_KOTEI_ID, '') as cardKoteiID,");
		builder.append("		IFNULL((SELECT e.LN_JIAN FROM E_KB_INF_JIAN e WHERE e.LN_KB_INF = a.LN_KB_INF LIMIT 1), '') AS lnJian");
		builder.append(" FROM	E_KB_NOTICE a");
		builder.append("		INNER JOIN R_KB_CHIKU b ON a.LN_KB_CHIKU = b.LN_KB_CHIKU");
		builder.append("		LEFT JOIN E_KB_INF d ON d.LN_KB_INF = a.LN_KB_INF");
		builder.append(" WHERE	(DATE_FORMAT(a.SEND_TS, '%Y%m%d') BETWEEN :dtFrom AND :dtTo)");
		builder.append("		AND b.LN_KEIBI = :lnKeibi");
		builder.append("		AND b.CHIKU = :chiku");
		if(type1.size() > 0 && type2.size() > 0) {
			builder.append("	AND (");

			for (int i = 0; i < type1.size(); i++) {
				if (type1.get(i).size() == 0 && type2.get(i).size() == 0) {
					continue;
				}
				builder.append("	(");
				if (type1.get(i).size() > 0) {
					builder.append("	a.SIG_KIND_1 IN :type1" + i);
				}
				if (type1.get(i).size() > 0 && type2.get(i).size() > 0) {
					builder.append("	AND a.SIG_KIND_2 IN :type2" + i);
				} else if(type2.get(i).size() > 0) {
					builder.append("	a.SIG_KIND_2 IN :type2" + i);
				}
				builder.append("	)");

				if (i < type1.size() - 1) {
					if (type1.get(i + 1).size() > 0 || type2.get(i + 1).size() > 0) {
						builder.append("	OR");
					}
				}
			}

			builder.append(")");
		}
		builder.append(" ORDER BY a.SEND_TS DESC,");
		builder.append(" 		a.LN_KB_INF DESC");
		
		return builder;
	}
	
	public BigInteger getTotalRow(String lnKeibi, String chiku, Date dtFrom, Date dtTo, List<Set<String>> type1, List<Set<String>> type2) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append("SELECT COUNT(*) FROM (");
		strBuilder.append(getDistrictPulldownInfoSql(type1, type2).toString());
		strBuilder.append(") DistrictPulldownInfo");

		final Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("chiku", chiku);
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		if(type1.size() > 0 && type2.size() > 0) {
			for (int i = 0; i < type1.size(); i++) {
				if (type1.get(i).size() == 0 && type2.get(i).size() == 0) {
					continue;
				}
				if (type1.get(i).size() > 0) {
					query.setParameter("type1" + i, type1.get(i));
				}
				if (type2.get(i).size() > 0) {
					query.setParameter("type2" + i, type2.get(i));
				}
			}
		}
		
		return (BigInteger)query.getSingleResult();
	}
	
	@SuppressWarnings("unchecked")
	public List<HistoryDataModel> getDistrictPulldownInfo(String lnKeibi, String chiku, Date dtFrom, Date dtTo, List<Set<String>> type1, List<Set<String>> type2, int offset, int limitRowNum ) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append(getDistrictPulldownInfoSql(type1, type2).toString());
		strBuilder.append(" LIMIT :offset, :limitRowNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString().replace("AND ()", ""), "HistoryDataModelResult");
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("chiku", chiku);
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		if(type1.size() > 0 && type2.size() > 0) {
			for (int i = 0; i < type1.size(); i++) {
				if (type1.get(i).size() == 0 && type2.get(i).size() == 0) {
					continue;
				}
				if (type1.get(i).size() > 0) {
					query.setParameter("type1" + i, type1.get(i));
				}
				if (type2.get(i).size() > 0) {
					query.setParameter("type2" + i, type2.get(i));
				}
			}
		}
		query.setParameter("offset", offset);
		query.setParameter("limitRowNum", limitRowNum);

		return (List<HistoryDataModel>) query.getResultList();
	}
}
