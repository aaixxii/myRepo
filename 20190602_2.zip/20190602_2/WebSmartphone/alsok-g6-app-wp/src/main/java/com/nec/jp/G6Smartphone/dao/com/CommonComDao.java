package com.nec.jp.G6Smartphone.dao.com;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class CommonComDao {

	@PersistenceContext(unitName="comPersistence")
	private EntityManager entityManager;

	public String getLanguageType(String lnAcntUserCommon) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	kauls.SELECT_LANG as selectLang");
		strBuilder.append(" FROM	K_ACNT_USER_LOGIN_STS kauls");
		strBuilder.append(" WHERE	kauls.LN_ACNT_USER_COMMON = :lnAcntUserCommon");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);

		return query.getSingleResult().toString();
	}

	public String getUserName(String lnAcntUserCommon) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	kauc.ACNT_NM as acntNm");
		strBuilder.append(" FROM	K_ACNT_USER_COMMON kauc");
		strBuilder.append(" WHERE	kauc.LN_ACNT_USER_COMMON = :lnAcntUserCommon");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);

		return query.getSingleResult().toString();
	}

	public String getAccountType(String userId) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	k.ACNT_KIND");
		strBuilder.append(" FROM	K_ACNT_USER_COMMON_ACNT_USER k");
		strBuilder.append(" WHERE	k.LN_ACNT_USER_COMMON = :userId");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("userId", userId);
		query.setMaxResults(1);

		return query.getSingleResult().toString();
	}
	
    public String getAcntUserKbn(String lnAcntUserCommon) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(ACNT_USER_KBN, '') as acntUserKbn");
        strBuilder.append(" FROM K_ACNT_USER_COMMON");
        strBuilder.append(" WHERE LN_ACNT_USER_COMMON = :lnAcntUserCommon");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
        query.setMaxResults(1);
        return query.getSingleResult().toString();
    }
    
	public Date getLastModifyAcntTs(String lnAcntUserCommon) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT");
		strBuilder.append("			kauc.UPDATE_TS as updateTs");
		strBuilder.append(" FROM	K_ACNT_USER_COMMON kauc");
		strBuilder.append(" WHERE	kauc.LN_ACNT_USER_COMMON = :lnAcntUserCommon");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);

		return (Date)query.getSingleResult();
	}
}
