package com.nec.jp.G6Smartphone.dao.ghs;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.ResGetOtherInfo;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP2000GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	public ResGetOtherInfo getALSOKGuardCenterInfoGHS(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT	a.GC_TEL_NUM as telNum,");
		strBuilder.append("			b.JIGYOU_NM as jigyouNm");
		strBuilder.append(" FROM	M_GC a");
		strBuilder.append("			INNER JOIN M_JIGYOU b ON a.GC_CD = b.GC_CD");
		strBuilder.append("			INNER JOIN R_KEIBI c ON b.JIGYOU_CD = c.JISSHI_JIGYOU_CD");
		strBuilder.append(" WHERE	c.LN_KEIBI = :lnKeibi");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "ResGetOtherInfoResult");
		query.setParameter("lnKeibi", lnKeibi);

		return (ResGetOtherInfo) query.getSingleResult();
	}

	public String getDenkeiNumGHS(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT	a.DENKEI");
		strBuilder.append(" FROM	R_DENKEI_MNG a");
		strBuilder.append("			INNER JOIN R_KEIBI b ON a.LN_DENKEI_MNG = b.LN_KEIBI");
		strBuilder.append(" WHERE	b.LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND a.FLG_LAST = :flgLast");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("flgLast", G6CodeConsts.CD009.LATEST);

		return query.getSingleResult().toString();
	}
}
