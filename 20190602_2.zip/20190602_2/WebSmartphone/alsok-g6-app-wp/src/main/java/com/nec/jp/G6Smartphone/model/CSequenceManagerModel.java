package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

@NamedStoredProcedureQuery(
    name="GET_SEQUENCE",
    procedureName="GET_SEQUENCE",
    parameters={
        @StoredProcedureParameter(name="p1", type=String.class, mode=ParameterMode.IN),
        @StoredProcedureParameter(name="p2", type=String.class, mode=ParameterMode.OUT)
    }
)

@Entity
@Table(name="C_SEQUENCE_MANAGER")
@NamedQuery(name="CSequenceManagerModel.findAll", query="SELECT c FROM CSequenceManagerModel c")
public class CSequenceManagerModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SEQ_ID")
	private String seqId;

	@Column(name="SEQ_CNT")
	private String seqCnt;

	@Column(name="MAX_SEQ_CNT")
	private String maxSeqCnt;
	
	public CSequenceManagerModel() {
	}


	public String getSeqId() {
		return seqId;
	}

	public void setSeqId(String seqId) {
		this.seqId = seqId;
	}

	public String getSeqCnt() {
		return seqCnt;
	}

	public void setSeqCnt(String seqCnt) {
		this.seqCnt = seqCnt;
	}

	public String getMaxSeqCnt() {
		return maxSeqCnt;
	}

	public void setMaxSeqCnt(String maxSeqCnt) {
		this.maxSeqCnt = maxSeqCnt;
	}
}
