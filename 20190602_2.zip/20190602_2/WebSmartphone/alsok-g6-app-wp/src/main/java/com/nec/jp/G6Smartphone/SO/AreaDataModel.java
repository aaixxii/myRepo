package com.nec.jp.G6Smartphone.SO;

public class AreaDataModel {

	private String lnKbArea;		// 警備エリア.LN_警備エリア論理番号
	private String kbAreaNum;		// 警備エリア.警備エリア番号
	private String kbAreaNm;		// 警備エリア.警備エリア名称

	public AreaDataModel() {
		this.lnKbArea = "";
		this.kbAreaNum = "";
		this.kbAreaNm = "";
	}

	public AreaDataModel(String lnKbArea, String kbAreaNum, String kbAreaNm) {
		this.lnKbArea = lnKbArea;
		this.kbAreaNum = kbAreaNum;
		this.kbAreaNm = kbAreaNm;
	}

	public String getLnKbArea() {
		return lnKbArea;
	}
	public void setLnKbArea(String lnKbArea) {
		this.lnKbArea = lnKbArea;
	}
	public String getKbAreaNum() {
		return kbAreaNum;
	}
	public void setKbAreaNum(String kbAreaNum) {
		this.kbAreaNum = kbAreaNum;
	}
	public String getKbAreaNm() {
		return kbAreaNm;
	}
	public void setKbAreaNm(String kbAreaNm) {
		this.kbAreaNm = kbAreaNm;
	}
}
