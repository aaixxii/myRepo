package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.KbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataModel;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP1000Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<KbChikuDataModel> getListSecurityDistrict(String acntID, String lnKeibi, List<String> remoteGSMChiku) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	rkc.LN_KB_CHIKU as lnKbChiku,");
		strBuilder.append("			IFNULL(rkc.SUB_ADDR, '') as subAddr,");
		strBuilder.append("			IFNULL(rkc.SD_KOBETU_NM, '') as sdKobetuNm");
		strBuilder.append(" FROM	R_KB_CHIKU rkc");
		strBuilder.append("			INNER JOIN R_KEIBI rk ON rkc.LN_KEIBI = rk.LN_KEIBI");
		strBuilder.append("			INNER JOIN A_USER_OPERATION_HANI A ON A.LN_ACNT_USER_COMMON = :acntID");
        strBuilder.append("			AND ( A.PATH_INF = rkc.PATH_INF");
        strBuilder.append("			   OR A.PATH_INF = LEFT(rkc.PATH_INF, 41)");
        strBuilder.append("			   OR A.PATH_INF = LEFT(rkc.PATH_INF, 20) )");
		strBuilder.append(" WHERE	rk.LN_KEIBI = :lnKeibi");
		strBuilder.append("         AND rkc.CHIKU <> ''");
		strBuilder.append("			AND rkc.ENTRY_STS = :entrySts");
		if (remoteGSMChiku.size() > 0) {
			strBuilder.append("			AND rkc.SUB_ADDR IN :remoteGSMChiku");
		}
		strBuilder.append(" ORDER BY rkc.CHIKU ASC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "KbChikuDataModelResult");
		query.setParameter("acntID", acntID);
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("entrySts", G6CodeConsts.CD031.REGISTERED);
		if (remoteGSMChiku.size() > 0) {
			query.setParameter("remoteGSMChiku", remoteGSMChiku);
		}

		return (List<KbChikuDataModel>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
    public List<RDevDataModel> getListDevice(String lnKeibi, String lnKbChiku) {
        StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT D.LN_DEV AS lnDev,");
        strBuilder.append("     D.SD_DEV_NM AS sdDevNm,");
        strBuilder.append("     D.SD_DEV_NUM AS sdDevNum");
        strBuilder.append(" FROM R_KB_CHIKU C ");
        strBuilder.append("     INNER JOIN R_DEV D ON D.LN_KB_CHIKU = C.LN_KB_CHIKU");
        strBuilder.append(" WHERE C.LN_KEIBI = :lnKeibi");
        strBuilder.append("   AND C.LN_KB_CHIKU = :lnKbChiku");
        strBuilder.append("   AND (D.SD_DEV_NUM LIKE 'SU000-RM%'");
        strBuilder.append("   OR D.SD_DEV_NUM LIKE 'SU000-EK%'");
        strBuilder.append("   OR D.SD_DEV_NUM LIKE 'SU000-RF%')");
        strBuilder.append("   AND D.SD_RM_KIND = '16'");
        strBuilder.append("   AND D.DEL_FLG = '0'  ");
        strBuilder.append(" ORDER BY D.SD_DEV_NM ASC");

        Query query = entityManager.createNativeQuery(strBuilder.toString(), "RDevDataModelResult");
        query.setParameter("lnKeibi", lnKeibi);
        query.setParameter("lnKbChiku", lnKbChiku);
        return (List<RDevDataModel>) query.getResultList();
    }
	   
//	@SuppressWarnings("unchecked")
//	public List<RDevDataModel> getListDevice(String lnKeibi, String lnKbChiku, List<String> drctSdRmKind) {
//		StringBuilder strBuilder = new StringBuilder();
//
//		strBuilder.append(" SELECT rd.LN_DEV as lnDev,");
//		strBuilder.append("     rd.SD_DEV_NM as sdDevNm,");
//		strBuilder.append("     rd.SD_DEV_NUM as sdDevNum");
//		strBuilder.append(" FROM R_KB_CHIKU rk ");
//		strBuilder.append("     INNER JOIN R_DEV rd ON rd.LN_KB_CHIKU = rk.LN_KB_CHIKU");
//		strBuilder.append("     INNER JOIN R_CTL_DEV rc ON rc.LN_DEV = rd.LN_DEV");
//		strBuilder.append(" WHERE rk.LN_KEIBI = :lnKeibi");
//		strBuilder.append(" AND rk.LN_KB_CHIKU = :lnKbChiku");
//		strBuilder.append(" AND rd.DEV_KIND IN :drctSdRmKind");
//		strBuilder.append(" AND rd.DEL_FLG = '0'");
//		strBuilder.append(" AND rc.DEL_FLG = '0'");
//		strBuilder.append(" ORDER BY rd.SD_DEV_NM ASC");
//
//		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RDevDataModelResult");
//		query.setParameter("lnKeibi", lnKeibi);
//		query.setParameter("lnKbChiku", lnKbChiku);
//		query.setParameter("drctSdRmKind", drctSdRmKind);
//
//		return (List<RDevDataModel>) query.getResultList(); 
//	}
	  
	@SuppressWarnings("unchecked")
	public List<String> getListElectricNum(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	denkei");
		strBuilder.append(" FROM	RDenkeiMngModel");
		strBuilder.append(" WHERE	lnKeibi = :lnKeibi");
		strBuilder.append("			AND delFlg = :delFlg");
		strBuilder.append("			AND lastFlg = :lastFlg");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		query.setParameter("lastFlg", G6CodeConsts.CD009.LATEST);

		return (List<String>) query.getResultList();
	}

//	@SuppressWarnings("unchecked")
//	public List<RCtlDevDataModel> getListGoukiSerial(String lnDev) {
//		StringBuilder strBuilder = new StringBuilder();
//
//		strBuilder.append(" SELECT IFNULL(GOUKI, '') as gouKi,");
//		strBuilder.append("    IFNULL(SERIAL_NUM, '') as serialNum,");
//		strBuilder.append("    IFNULL(SD_LINE_KIND, '') as sdLineKind");
//		strBuilder.append(" FROM	R_CTL_DEV");
//		strBuilder.append(" WHERE LN_DEV = :lnDev");
//
//		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RCtlDevDataModelResult");
//		query.setParameter("lnDev", lnDev);
//
//		return (List<RCtlDevDataModel>) query.getResultList();
//	}
	
	@SuppressWarnings("unchecked")
	public List<RCtlDevDataModel> getListGoukiSerial(String lnDev, String lnKbChiku) {
	     StringBuilder strBuilder = new StringBuilder();
	     strBuilder.append(" SELECT IFNULL(R5.GOUKI, '') as gouKi,");
	     strBuilder.append("   IFNULL(R5.SERIAL_NUM, '') as serialNum,");
	     strBuilder.append("   IFNULL(R5.SD_LINE_KIND, '') as sdLineKind");
	     strBuilder.append(" FROM R_KB_CHIKU R1");
	     strBuilder.append(" INNER JOIN R_KEIBI R2 ON R1.LN_KEIBI = R2.LN_KEIBI");
	     strBuilder.append("   INNER JOIN R_DEV R3 ON R1.LN_KB_CHIKU = R3.LN_KB_CHIKU");
	     strBuilder.append("   INNER JOIN R_DEV_DEV R4 ON  R4.LN_DEV_CHI = R3.LN_DEV");
	     strBuilder.append("   INNER JOIN R_CTL_DEV R5 ON R4.LN_CTL_DEV=R5.LN_CTL_DEV");
	     strBuilder.append(" WHERE");
	     strBuilder.append("   R1.DEL_FLG = '0'");
	     strBuilder.append(" AND R2.DEL_FLG = '0'");
	     strBuilder.append(" AND R3.DEL_FLG = '0'");
	     strBuilder.append(" AND R4.DEL_FLG = '0'");
	     strBuilder.append(" AND R5.DEL_FLG = '0'");
	     strBuilder.append(" AND R1.LN_KB_CHIKU = :lnKbChiku");
	     strBuilder.append(" AND R3.LN_DEV = :lnDev");
	     strBuilder.append(" LIMIT 1");

	     Query query = entityManager.createNativeQuery(strBuilder.toString(), "RCtlDevDataModelResult");
	     query.setParameter("lnKbChiku", lnKbChiku);
	     query.setParameter("lnDev", lnDev);

	     return (List<RCtlDevDataModel>) query.getResultList();
	}

	public String getControlQueueSts(String cmdSeqNum) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	sts");
		strBuilder.append(" FROM	CQueCtrlSigModel");
		strBuilder.append(" WHERE	cmdSeqNum = :cmdSeqNum");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("cmdSeqNum", cmdSeqNum);
		query.setMaxResults(1);
		return (String) query.getSingleResult();
	}

	public String getDeviceSts(String lnDev) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	drctsetCntrSts");
		strBuilder.append(" FROM	RDevStModel");
		strBuilder.append(" WHERE	lnDev = :lnDev");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("lnDev", lnDev);

		return (String) query.getSingleResult();
	}
}
