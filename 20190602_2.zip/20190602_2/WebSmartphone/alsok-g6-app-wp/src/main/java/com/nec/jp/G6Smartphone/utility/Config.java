package com.nec.jp.G6Smartphone.utility;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.nec.jp.G6Smartphone.utility.ConvUtil;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

public final class Config extends PropertyPlaceholderConfigurer {

    private static Config m_instance = new Config();

    /**
     * config.propeties。
     */
    private static Properties m_props = new Properties();

//  @Override
//    protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props) throws BeansException {
//        super.processProperties(beanFactoryToProcess, props);
//        m_props = props;
//    }

    static{
        try {
            m_props.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("setting.properties"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Config() {
    }

    public static Config getInstance() {
        return m_instance;
    }

    public static String getString(String key) {
        if (!m_props.containsKey(key)) {
            throw new RuntimeException(key + "定義がない。");
        }
        return m_props.getProperty(key);
    }

    public static boolean getBoolean(String key)  {
        return ConvUtil.convToBool(getString(key));
    }

    public static int getInt(String key)  {
        String property = getString(key);
        if (property == null || property.equals("")) {
            throw new RuntimeException(key + "の値は指定できません。");
        }
        int i = 0;
        try {
            i = Integer.parseInt(property);
        } catch (NumberFormatException e) {
            throw new RuntimeException(key + "の値は指定できません。", e);
        }
        return i;
    }

    public static long getLong(String key)  {
        String property = getString(key);
        if (property == null || property.equals("")) {
            throw new RuntimeException(key + "の値は指定できません。");
        }
        long l = 0;
        try {
            l = Long.parseLong(property);
        } catch (NumberFormatException e) {
            throw new RuntimeException(key + "の値は指定できません。", e);
        }
        return l;
    }

    public static String[] getStringArray(String key)  {
        if (!m_props.containsKey(key)) {
            throw new RuntimeException(key + "定義がない。");
        }
        String property = m_props.getProperty(key);
        String[] array = property.split(",", -1);
        return array;
    }
}
