package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.KbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataModel;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.SO.RDevStsDataModel;
import com.nec.jp.G6Smartphone.SO.ResChangeDisplayChiku;
import com.nec.jp.G6Smartphone.SO.ResGetKbChikuList;
import com.nec.jp.G6Smartphone.SO.ResGetKeibiSetteiStatus;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP1000Service;
import com.nec.jp.G6Smartphone.service.ghs.CommonGhsService;
import com.nec.jp.G6Smartphone.service.ghs.SZWP1000GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.DispID;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;
import com.nec.jp.G6Smartphone.utility.StringUtils;

import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWP1000Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP1000Controller.class);
	
    //JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;

	@Autowired
	SZWP1000Service sZWP1000Service;
	@Autowired
	SZWP1000GhsService sZWP1000GhsService;
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;
	@Autowired
	CommonGhsService commonGhsService;

	@Value("${remoteGSMChiku}")
	String remoteGSMChiku;
	@Value("${mainGSMSubaddr}")
	String mainGSMSubaddr;
	@Value("${managerRoomGSMSubaddr}")
	String managerRoomGSMSubaddr;
	@Value("${setubiGSMSubaddr}")
	String setubiGSMSubaddr;
	@Value("${commonGSMSubaddr}")
	String commonGSMSubaddr;
	@Value("${ctrGSMSubaddr}")
	String ctrGSMSubaddr;
	@Value("${ctrOtherGSMSubaddr}")
	String ctrOtherGSMSubaddr;
	@Value("${jukoGSMSubaddr}")
	String jukoGSMSubaddr;
	@Value("${timeout}")
	Integer timeout;
	@Value("${cmdVer}")
	String cmdVer;
    @Value("${cmdVer2}")
    String cmdVer2;
	@Value("${timeSleep}")
	Integer timeSleep;
	@Value("${host_name}")
	String hostName;

	/*
	 * Get data from R_KB_CHIKU, R_DEV table
	 * @param: acntID, lnKeibi
	 * return: object ResGetKbChikuList as JSON
	 */
	@RequestMapping(value = "/getKbChikuList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getKbChikuList(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1000Controller.getKbChikuList()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetKbChikuList resGetKbChikuList = new ResGetKbChikuList();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		int userAuth = 0;

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

         // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetKbChikuList, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKbChikuList()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetKbChikuList, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKbChikuList()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 5) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetKbChikuList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKbChikuList()");
				return jsonResult;
			}

			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.lnKeibi.getValue());
					add(RequestParam.acntSbt.getValue());
					add(RequestParam.lnKeiyk.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetKbChikuList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKbChikuList()");
				return jsonResult;
			}

			// リクエスト情報取得
			String acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
			String acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			String lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
			String acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
			String lnKeiyk = mapParam.get(RequestParam.lnKeiyk.getValue()).toString();
			String dispID = DispID.P1000.getValue();
			List<KbChikuDataModel> kbChikuDataModelList = new ArrayList<KbChikuDataModel>();
			List<RDevDataModel> rDevDataModelList = new ArrayList<RDevDataModel>();
			
			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resGetKbChikuList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKbChikuList()");
				return jsonResult;
			}

			// TODO SZWP1000：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 警備先地区一覧情報取得処理
			// アカウント種別が次期警備の場合
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// 警備先地区一覧情報を取得
				// 7-2.A)警備先地区一覧の取得
				List<String> remoteGSMChikuList = new ArrayList<String>();
				String serviceType = commonService.getServiceType(lnKeibi);

				if (G6CodeConsts.CD035.GSM.equals(serviceType)) {
					remoteGSMChikuList = this.setSubAddr(remoteGSMChiku);
				}

				kbChikuDataModelList = sZWP1000Service.getListSecurityDistrict(acntID, lnKeibi, remoteGSMChikuList);

				if (kbChikuDataModelList.size() > 0) {
					// Default lnKbChiku is the first item
					String lnKbChiku = kbChikuDataModelList.get(0).getLnKbChiku();
					// 先頭の警備先地区の設置機器一覧情報を取得
					// 7-2.B)設置機器一覧の取得
//					List<String> drctSdRmKindList = G6Common.stringToArray(drctSdRmKind);
//					rDevDataModelList = sZWP1000Service.getListDevice(mapParam.get(RequestParam.lnKeibi.getValue()).toString(),
//							kbChikuDataModelList.get(0).getLnKbChiku(), drctSdRmKindList);
					rDevDataModelList = sZWP1000Service.getListDevice(lnKeibi, lnKbChiku);
					
					// アカウント区分による権限チェック
		            int acntResult = G6Common.invalidateUserAcntKbn(commonComService, commonService, acntID, dispID);
		            if (0 == acntResult) {
		            	userAuth = 0;
		            } else if (2 == acntResult) {
		            	userAuth = 2;
		            } else {
			            String firstword = dispID.substring(0, 1);
			            if ("P".equals(firstword)) {
			                userAuth = commonService.getAuth(acntID, lnKeiyk, lnKeibi, lnKbChiku, dispID);
			            } else {
			                userAuth = commonService.getAuth(acntID, lnKeiyk, lnKeibi, lnKbChiku, "P" + dispID);
			            }
		            }
				}

			// アカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				// 警備先地区一覧情報を取得
				// 7-3.A)警備先地区一覧の取得
				kbChikuDataModelList = sZWP1000GhsService
						.getListSecurityDistrictGHS(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				if (kbChikuDataModelList.size() > 0) {
					// 先頭の警備先地区の設置機器一覧情報を取得
					// 7-3.B)設置機器一覧の取得
					rDevDataModelList = sZWP1000GhsService.getListDeviceGHS(kbChikuDataModelList.get(0).getLnKbChiku());
				}
				// GHSの場合、権限2設定
				userAuth = 2;
			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			this.saveUserOperationLog(acntID , acntNm, lnKeiyk, lnKeibi, null);
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(acntID);										// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);										// アカウント名
			hUserOperationLogModel.setLnKeibi(lnKeibi);										// 警備先論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP1000.getValueForOperationLog());	// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, acntType);

			resGetKbChikuList.setErrorCode(G6Constant.SUCCESS_CD);
			resGetKbChikuList.setKbChikuItem(kbChikuDataModelList);
			resGetKbChikuList.setrDevItem(rDevDataModelList);
			
			//デコード済acntIDを設定したJWT認証トークンを付与
			resGetKbChikuList.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));

			resGetKbChikuList.setUserAuth(String.valueOf(userAuth));
			
			jsonResult = G6Common.parseJSON(resGetKbChikuList, acntLanguage);

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetKbChikuList, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetKbChikuList, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetKbChikuList, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
		} catch (Exception e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetKbChikuList, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetKbChikuList, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKbChikuList()");
		return jsonResult;
	}

	/*
	 * Get data from R_DEV table
	 * @param: acntID, lnKbChiku
	 * return: object ResChangeDisplayChiku as JSON
	 */
	@RequestMapping(value = "/changeDisplayChiku", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String changeDisplayChiku(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1000Controller.changeDisplayChiku()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResChangeDisplayChiku resChangeDisplayChiku = new ResChangeDisplayChiku();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		int userAuth = 0;

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resChangeDisplayChiku, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.changeDisplayChiku()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resChangeDisplayChiku, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.changeDisplayChiku()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 6) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resChangeDisplayChiku, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.changeDisplayChiku()");
				return jsonResult;
			}

			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.lnKeibi.getValue());
					add(RequestParam.lnKbChiku.getValue());
					add(RequestParam.acntSbt.getValue());
					add(RequestParam.lnKeiyk.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resChangeDisplayChiku, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.changeDisplayChiku()");
				return jsonResult;
			}

			// リクエスト情報取得
			String acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
			String acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			String lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
			String lnKbChiku = mapParam.get(RequestParam.lnKbChiku.getValue()).toString();
			String acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
			String lnKeiyk = mapParam.get(RequestParam.lnKeiyk.getValue()).toString();
			String dispID = DispID.P1000.getValue();
			
			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resChangeDisplayChiku, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.changeDisplayChiku()");
				return jsonResult;
			}
						
			// TODO SZWP1000：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 次期警備 - 設置機器一覧情報取得処理
			// アカウント種別が次期警備の場合
			List<RDevDataModel> rDevDataModelList = new ArrayList<RDevDataModel>();

			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// 選択された地区の設置機器一覧情報を取得する
				// 7-2.B)設置機器一覧の取得
//				List<String> drctSdRmKindList = G6Common.stringToArray(drctSdRmKind);
//				rDevDataModelList = sZWP1000Service
//						.getListDevice(mapParam.get(RequestParam.lnKeibi.getValue()).toString(), 
//						        mapParam.get(RequestParam.lnKbChiku.getValue()).toString(), 
//						        drctSdRmKindList);
				rDevDataModelList = sZWP1000Service.getListDevice(lnKeibi, lnKbChiku);
				
				// アカウント区分による権限チェック
	            int acntResult = G6Common.invalidateUserAcntKbn(commonComService, commonService, acntID, dispID);
	            if (0 == acntResult) {
	            	userAuth = 0;
	            } else if (2 == acntResult) {
	            	userAuth = 2;
	            } else {
		            String firstword = dispID.substring(0, 1);
		            if ("P".equals(firstword)) {
		                userAuth = commonService.getAuth(acntID, lnKeiyk, lnKeibi, lnKbChiku, dispID);
		            } else {
		                userAuth = commonService.getAuth(acntID, lnKeiyk, lnKeibi, lnKbChiku, "P" + dispID);
		            }
	            }

			// ＧＨＳ - 設置機器一覧情報取得処理
			// アカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				// 選択された地区の設置機器一覧情報を取得する
				// 7-3.B)設置機器一覧の取得
				rDevDataModelList = sZWP1000GhsService.getListDeviceGHS(lnKbChiku);
				// GHSの場合、権限2設定
				userAuth = 2;
			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			this.saveUserOperationLog(acntID, acntNm, lnKeiyk, lnKeibi, lnKbChiku);
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(acntID);										// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);										// アカウント名
			hUserOperationLogModel.setLnKeibi(lnKeibi);										// 警備先論理番号
			hUserOperationLogModel.setLnKbChiku(lnKbChiku);									// 警備先地区論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP1000.getValueForOperationLog());	// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, acntType);

			resChangeDisplayChiku.setErrorCode(G6Constant.SUCCESS_CD);
			resChangeDisplayChiku.setrDevItem(rDevDataModelList);
			
			//デコード済acntIDを設定したJWT認証トークンを付与
			resChangeDisplayChiku.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));

			resChangeDisplayChiku.setUserAuth(String.valueOf(userAuth));
			
			jsonResult = G6Common.parseJSON(resChangeDisplayChiku, acntLanguage);

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resChangeDisplayChiku, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resChangeDisplayChiku, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resChangeDisplayChiku, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
		} catch (Exception e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resChangeDisplayChiku, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resChangeDisplayChiku, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.changeDisplayChiku()");
		return jsonResult;
	}

	/*
	 * Get data from R_DEV_STS table
	 * @param: acntID, acntNm, lnKeibi, (ＧＨＳの場合) subAddr, rDevItem 
	 * return: object ResGetKeibiSetteiStatus as JSON
	 */
	@RequestMapping(value = "/getKeibiSetteiStatus", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getKeibiSetteiStatus(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1000Controller.getKeibiSetteiStatus()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetKeibiSetteiStatus resGetKeibiSetteiStatus = new ResGetKeibiSetteiStatus();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntType = "";
		// Handling send queue timeout
        boolean isTimeout = false;
        String acntNm = "";

		try {
			Map<String, Boolean> lstRequiredParam = null;
			RDevDataModel[] rDevDataModelArr = null;
			List<String> denkeiList = null;
			List<String> cmdSqList = new ArrayList<String>();
			List<RDevStsDataModel> rDevStsDataModelList = new ArrayList<RDevStsDataModel>();
			int remainCmdSq = 0;

			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}
			
			// リクエスト情報を検証する
			if (mapParam.size() != 7) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
				return jsonResult;
			}
			
			if (null != mapParam.get(RequestParam.acntSbt.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntSbt.getValue()))) {
				acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
			}

			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
				return jsonResult;
			}

			// アカウント種別が次期警備の場合
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// Build require parameters
				lstRequiredParam = new HashMap<String, Boolean>() {
					private static final long serialVersionUID = 1L;
					{
						put(RequestParam.acntID.getValue(), true);
						put(RequestParam.acntSbt.getValue(), true);
						put(RequestParam.acntNm.getValue(), true);
						put(RequestParam.lnKeibi.getValue(), true);
						put(RequestParam.subAddr.getValue(), false);
						put(RequestParam.rDevItem.getValue(), false);
						put(RequestParam.lnKbChiku.getValue(), false);
					}
				};

			// アカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				// Build require parameters
				lstRequiredParam = new HashMap<String, Boolean>() {
					private static final long serialVersionUID = 1L;
					{
						put(RequestParam.acntID.getValue(), true);
						put(RequestParam.acntSbt.getValue(), true);
						put(RequestParam.acntNm.getValue(), true);
						put(RequestParam.lnKeibi.getValue(), true);
//						put(RequestParam.subAddr.getValue(), true);
						put(RequestParam.subAddr.getValue(), false);
						put(RequestParam.rDevItem.getValue(), false);
						put(RequestParam.lnKbChiku.getValue(), false);
					}
				};
			}

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
				return jsonResult;
			}

			rDevDataModelArr = (RDevDataModel[]) G6Common.readParamToArrayObject(mapParam, RequestParam.rDevItem.getValue(), "RDevDataModel", acntLanguage);
			final String lnKbChiku = mapParam.get(RequestParam.lnKbChiku.getValue()).toString();
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			
			if (null == rDevDataModelArr || 0 == rDevDataModelArr.length) {
				// 操作履歴の出力
				// 利用者の操作履歴を出力する。
				// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//				this.saveUserOperationLog(mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm);
				HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
				hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());	// アカウントID
				hUserOperationLogModel.setInsertNm(acntNm);														// アカウント名
				hUserOperationLogModel.setLnKeibi(mapParam.get(RequestParam.lnKeibi.getValue()).toString());	// 警備先論理番号
				hUserOperationLogModel.setLnKbChiku(lnKbChiku);													// 警備先地区論理番号
				hUserOperationLogModel.setDispId(ScreenID.SZWP1000.getValueForOperationLog());					// 操作画面ID
				hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
				commonService.entryUserOperation(hUserOperationLogModel, acntType);

				resGetKeibiSetteiStatus.setErrorCode(G6Constant.SUCCESS_CD);
				resGetKeibiSetteiStatus.setDatetime(DateTimeCommon.getCurrentDateTime());
				resGetKeibiSetteiStatus.setrDevStsItem(rDevStsDataModelList);
				
				//デコード済acntIDを設定したJWT認証トークンを付与
				resGetKeibiSetteiStatus.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
	            
				jsonResult = G6Common.parseJSON(resGetKeibiSetteiStatus, acntLanguage);
				
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
				return jsonResult;
			}

			// TODO SZWP1000：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			rDevStsDataModelList = this.mappingData(rDevDataModelArr);

			// 更新処理（次期警備の場合）
			// アカウント種別が次期警備の場合
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// 9-2.A)電計番号の取得
				denkeiList = sZWP1000Service.getListElectricNum(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				if (denkeiList.size() == 0) {
					denkeiList.add("");
				}

				// /ループ1　リクエスト情報のLN_設置機器論理番号の数だけ繰り返す
				for (int i = 0; i < rDevDataModelArr.length; i++) {
					// 9-2.B)号機番号、シリアル番号の取得
//					List<RCtlDevDataModel> rCtlDevDataModelList = sZWP1000Service.getListGoukiSerial(rDevDataModelArr[i].getLnDev());
				    List<RCtlDevDataModel> rCtlDevDataModelList = sZWP1000Service.getListGoukiSerial(rDevDataModelArr[i].getLnDev(), lnKbChiku);

					if(rCtlDevDataModelList.size() == 0) {
						rCtlDevDataModelList.add(new RCtlDevDataModel());
					}

					// 共通クラスから取得したコマンドシーケンス番号
					// String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
					final String cmdSeqNum = commonService.getCmdSeq();
					final String transNo = commonService.getTranSeq();
					String sdDevNum = G6Constant.MYCD006.SU000; // rDevDataModelArr[i].getSdDevNum();
					if (sdDevNum == null || sdDevNum.length() < 11) {
					    sdDevNum = sdDevNum + "            ";
					    sdDevNum = sdDevNum.substring(0, 11);
					}
					Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataModelList.get(0), denkeiList.get(0), cmdSeqNum,
							G6Constant.FOURSPACE, sdDevNum, transNo, rCtlDevDataModelList.get(0).getSdLineKind());

					// 制御状態読出要求用のSOAP電文を作成する
					// 9-3.B)制御状態読出要求コマンド
					String soapMsg = this.createSoapMsg(mapSoap, "");

					mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
					mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
					mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());
					
					final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
					// 制御状態読出要求コマンドを登録する
					// 9-3.A)制御状態読出要求登録
					// コミットを行う
					commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

					cmdSqList.add(cmdSeqNum);
					remainCmdSq++;
				}
				// /ループ1　終了

				long beginTime = System.currentTimeMillis();
				int countSleep = 0;

				// /ループ2　タイムアウトするまで繰り返す
				while (true) {
	                // タイムアウト時間を超過している場合
	                if (G6Common.isTimeOut(timeout.intValue(), beginTime)) {
	                    isTimeout = true;
	                    // ループ2を抜ける
	                    break;
	                }
					// /ループ3　制御状態読出要求のコマンドシーケンス番号の数だけ繰り返す
					for(int i = 0; i < cmdSqList.size(); i++) {
						if(!"".equals(cmdSqList.get(i))) {
							// 制御状態読出要求コマンドの実行状態を取得する
							// 9-2.C)コマンド状態の取得
							String controlQueueSts = sZWP1000Service.getControlQueueSts(cmdSqList.get(i));

							if (null == controlQueueSts) {
								jsonResult = G6Common.messageUpdateLogHandler(resGetKeibiSetteiStatus, 
										G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

								// 処理終了
								appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
								return jsonResult;
							}

	                        // FIX BUG No.71 -> Changed as below
                            // コマンドが「0：未送信」「1：リクエスト送信中」以外の場合
                            // ↓
                            // コマンドが「S：成功」の場合
                            // 機器の状態を取得する
						   // if(!G6CodeConsts.CD179.UNSENT.equals(controlQueueSts) && !G6CodeConsts.CD179.A_REQUEST_IS_BEING_SENT.equals(controlQueueSts)) {
						   if(G6CodeConsts.CD179.SUCCESS.equals(controlQueueSts)) {
								// 機器の状態を取得する
								// 9-2.D)設置機器状態の取得
								String drctsetCntrSts = sZWP1000Service.getDeviceSts(rDevDataModelArr[i].getLnDev());

								rDevStsDataModelList.get(i).setDrctsetCntrSts(drctsetCntrSts);

								// 制御状態読出要求のコマンドシーケンス番号を削除する
								cmdSqList.set(i, "");
								remainCmdSq--;
							}
						}
					}
					// /ループ3　終了

					// 制御状態読出要求のコマンドシーケンス番号が残っていない場合
					if(0 == remainCmdSq) {
						// ループ2を抜ける
						break;
					}

					// 一定時間sleep後、ループ2の先頭へ
					G6Common.sleepOperation(timeout.intValue(), timeSleep.intValue(), countSleep);
					countSleep++;
				}
				// /ループ2　終了

			// 更新処理（ＧＨＳの場合）
			// アカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				// 9-4.A)電計番号の取得
				denkeiList = sZWP1000GhsService.getListElectricNumGHS(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				if (denkeiList.size() == 0) {
					denkeiList.add("");
				}

				// 9-4.B)号機番号、シリアル番号の取得
				RCtlDevDataModel rCtlDevDataModel = sZWP1000GhsService.getGoukiSerialGHS(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				// 共通クラスから取得したコマンドシーケンス番号
			    final String cmdSeqNum = commonGhsService.getCmdSeq();
			    final String transNo = G6Constant.EMPTY;
                
				Map<String, String> mapSoap = this.createGHSParamForSoap(rCtlDevDataModel, denkeiList.get(0), cmdSeqNum,
						mapParam.get(RequestParam.subAddr.getValue()).toString(), transNo, G6Constant.EMPTY);

				// 制御状態読出要求用のSOAP電文を作成する
				// 9-5.B)制御状態読出要求コマンド
				String soapMsg = this.createGHSSoapMsg(mapSoap, G6Constant.ACOUNT_HS);

				mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
				mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
				mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());

				// 制御状態読出要求コマンドを登録する
				// 9-5.A)制御状態読出要求登録
				// コミットを行う
				final String seqNo = commonGhsService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL);
				commonGhsService.saveEQueCtrlModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

				long beginTime = System.currentTimeMillis();
				int countSleep = 0;

				// /ループ1　タイムアウトするまで繰り返す
				while (true) {
                    // タイムアウト時間を超過している場合
                    if (G6Common.isTimeOut(timeout.intValue(), beginTime)) {
                        isTimeout = true;
                        // ループ2を抜ける
                        break;
                    }

					// 制御状態読出要求コマンドの実行状態を取得する
					// 9-4.C)コマンド状態の取得
					String controlQueueSts = sZWP1000GhsService.getControlQueueStsGHS(cmdSeqNum);

					if (null == controlQueueSts) {
						jsonResult = G6Common.messageUpdateLogHandler(resGetKeibiSetteiStatus, 
								G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

						// 処理終了
						appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
						return jsonResult;
					}

					// コマンドが「S：成功」の場合、機器の状態を取得する
					if(G6CodeConsts.CD179.SUCCESS.equals(controlQueueSts)) {
						// 機器の状態を取得する
						// 9-4.D)設置機器状態の取得
						for (int i = 0; i < rDevDataModelArr.length; i++) {
							String drctsetCntrSts = sZWP1000GhsService.getDeviceStsGHS(rDevDataModelArr[i].getLnDev());
							rDevStsDataModelList.get(i).setDrctsetCntrSts(drctsetCntrSts);
						}
						break;
					}

					// 一定時間sleep後、ループ1の先頭へ
					G6Common.sleepOperation(timeout.intValue(), timeSleep.intValue(), countSleep);
					countSleep++;
				}
				// /ループ1　終了
			}
			if (isTimeout) {
                // タイムアウト発生時
                // 共通「メッセージ取得処理」を呼び出し、エラーメッセージを取得する。
                jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, 
                        G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_SERVER_TIMEOUT.getValue(), 
                        acntLanguage);
            } else {
                // 操作履歴の出力
                // 利用者の操作履歴を出力する。
                // 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//                this.saveUserOperationLog(mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm);
				HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
				hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());	// アカウントID
				hUserOperationLogModel.setInsertNm(acntNm);														// アカウント名
				hUserOperationLogModel.setLnKeibi(mapParam.get(RequestParam.lnKeibi.getValue()).toString());	// 警備先論理番号
				hUserOperationLogModel.setLnKbChiku(lnKbChiku);													// 警備先地区論理番号
				hUserOperationLogModel.setDispId(ScreenID.SZWP1000.getValueForOperationLog());					// 操作画面ID
				hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
				commonService.entryUserOperation(hUserOperationLogModel, acntType);

                resGetKeibiSetteiStatus.setErrorCode(G6Constant.SUCCESS_CD);
                resGetKeibiSetteiStatus.setDatetime(DateTimeCommon.getCurrentDateTime());
                resGetKeibiSetteiStatus.setrDevStsItem(rDevStsDataModelList);
                
                //デコード済acntIDを設定したJWT認証トークンを付与
                resGetKeibiSetteiStatus.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));

                jsonResult = G6Common.parseJSON(resGetKeibiSetteiStatus, acntLanguage);
                
            }
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
		} catch (Exception e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatus()");
		return jsonResult;
	}

//	private void saveUserOperationLog(String acntId, String acntNm, String lnKeiyk, String lnKeibi, String lnKbChiku) throws ApplicationException {
//		HUserOperationLogModelPK hUserOperationLogModelPk = new HUserOperationLogModelPK();
//		HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//		// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//	    final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//	    
//	    // PKオブジェクト作成
//	    hUserOperationLogModelPk.setLnKeiyk(lnKeiyk);
//	    hUserOperationLogModelPk.setLnLogUserOperation(lnLogUserOperation);
//	    hUserOperationLogModel.setId(hUserOperationLogModelPk);
//	    
//	    // モデルオブジェクト作成
//	    hUserOperationLogModel.setLnKeibi(lnKeibi);
//	    hUserOperationLogModel.setLnKbChiku(lnKbChiku);
//		hUserOperationLogModel.setDispId(ScreenID.SZWP1000.getValueForOperationLog());
//		hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//		commonService.entryUserOperation(hUserOperationLogModel, acntId, acntNm, DateTimeCommon.getCurrentDate());
//		
//	}

	private List<RDevStsDataModel> mappingData(RDevDataModel[] rDevDataModelArr) {
		List<RDevStsDataModel> rDevStsDataModelList = new ArrayList<RDevStsDataModel>();

		for (RDevDataModel obj : rDevDataModelArr) {
			RDevStsDataModel rDev = new RDevStsDataModel();
			rDev.setLnDev(obj.getLnDev());
			rDev.setSdDevNm(obj.getSdDevNm());
			rDev.setSdDevNum(obj.getSdDevNum());

			rDevStsDataModelList.add(rDev);
		}

		return rDevStsDataModelList;
	}

	private Map<String, String> createParamForSoap(RCtlDevDataModel rCtlDevDataModel, String denkei, String cmdsqNo,
			String subAddr, String termNo, String transNo, String lineType) {
		Map<String, String> mapSoap = new HashMap<String, String>();

		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer2);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, transNo);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, denkei);
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, subAddr);
		mapSoap.put(G6Constant.MYCD003.LINETYPE, lineType);
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.DRCTRD);
		mapSoap.put(G6Constant.MYCD003.TERMNO, termNo);
		mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);

		mapSoap.put(G6Constant.MYCD003.HOSTNM, hostName);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, termNo);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.DRCT_RD);
		mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.UNSENT);

		return mapSoap;
	}

	private String createSoapMsg(Map<String, String> mapSoap, String type) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
		// データ部作成
		// 共通項目タグ設定
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 9-3.-A)に設定したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<term_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TERMNO) + "</term_no>");
		// START: fixed bug No.30 -->> remove column Result.
		if (G6Constant.ACOUNT_HS.equals(type)) {
		       builder.append("<result>");
		       builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		}
		// END: fixed bug No.30 -->> remove column Result.
		// フッター部作成
		builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

		return builder.toString();
	}

	/**
	 * GHS向けSoap電文作成用のデータを返す
	 * 
	 * @param rCtlDevDataModel
	 * @param denkei
	 * @param cmdsqNo
	 * @param subAddr
	 * @param termNo
	 * @param transNo
	 * @param lineType
	 * @return
	 */
	private Map<String, String> createGHSParamForSoap(RCtlDevDataModel rCtlDevDataModel, String denkei, String cmdsqNo,
			String subAddr, String transNo, String lineType) {
		Map<String, String> mapSoap = new HashMap<String, String>();

		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, transNo);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, denkei);
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, G6Constant.FOURSPACE);
		mapSoap.put(G6Constant.MYCD003.LINETYPE, lineType);
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.DRCTRD);
		mapSoap.put(G6Constant.MYCD003.TERMNO, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);

		mapSoap.put(G6Constant.MYCD003.HOSTNM, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.DRCT_RD_GHS);
		mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.UNSENT);

		return mapSoap;
	}
	
	/**
	 * GHS向けSoap電文を作成する
	 * 
	 * @param rCtlDevDataModel
	 * @param denkei
	 * @param cmdsqNo
	 * @param subAddr
	 * @param termNo
	 * @param transNo
	 * @param lineType
	 * @return
	 */
	private String createGHSSoapMsg(Map<String, String> mapSoap, String type) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeaderForGhs());
		// データ部作成
		// 共通項目タグ設定
		builder.append("<HostName>");
		builder.append(mapSoap.get(G6Constant.MYCD003.HOSTNM) + "</HostName>");
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 9-3.-A)に設定したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<priority_level>");
		builder.append(G6Constant.EMPTY + "</priority_level>");
		builder.append("<timeout_sec>");
		builder.append(G6Constant.EMPTY + "</timeout_sec>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<term_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TERMNO) + "</term_no>");
		if (G6Constant.ACOUNT_HS.equals(type)) {
		       builder.append("<result>");
		       builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		}
		// フッター部作成
		builder.append(G6Common.createSoapFooterForGhs());

		return builder.toString();
	}
	
	/**
	* プロパティファイルから取得したR_警備先地区.サブアドレス.
	*
	* @param form
	*		  警備履歴一覧画面用フォーム
	*/
	 private List<String> setSubAddr(String keibiSrchHistoryGSMChiku) {
		// サブアドレス
		String[] keibiSrchHistoryGSMChikuArr = keibiSrchHistoryGSMChiku.split(G6Constant.COMMA);
		StringBuilder subAddr = new StringBuilder();

		if (keibiSrchHistoryGSMChikuArr.length > 0) {
			for (int i = 0; i < keibiSrchHistoryGSMChikuArr.length; i++) {
				String sub = null;
				if (G6Constant.SUBADDR_1.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = mainGSMSubaddr;
				} else if (G6Constant.SUBADDR_2.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = managerRoomGSMSubaddr;
				} else if (G6Constant.SUBADDR_3.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = setubiGSMSubaddr;
				} else if (G6Constant.SUBADDR_4.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = commonGSMSubaddr;
				} else if (G6Constant.SUBADDR_5.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = ctrGSMSubaddr;
				} else if (G6Constant.SUBADDR_6.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = ctrOtherGSMSubaddr;
				} else if (G6Constant.SUBADDR_7.equals(keibiSrchHistoryGSMChikuArr[i])) {
					sub = jukoGSMSubaddr;
				} else {
					subAddr = null;
					break;
				}
				StringBuilder subAddrNew = new StringBuilder();
				String[] subArray = sub.split(G6Constant.COMMA);
				for (int j = 0; j < subArray.length; j++) {
					if (!subArray[j].contains(G6Constant.HYPHEN)) {
						subAddrNew.append(subArray[j]);
						subAddrNew.append(G6Constant.COMMA);
						continue;
					}
					String[] str = subArray[j].split(G6Constant.HYPHEN);
					if (str.length != G6Constant.NO_2) {
						continue;
					}
					int bf = Integer.parseInt(str[0]);
					int ls = Integer.parseInt(str[1]);
					if (bf >= ls) {
						continue;
					}
					for (int k = bf; k <= ls; k++) {
						subAddrNew.append(StringUtils.addCharForStrL(String.valueOf(k), '0', G6Constant.NO_4));
						subAddrNew.append(G6Constant.COMMA);
					}
				}
				sub = subAddrNew.substring(0, subAddrNew.length() - G6Constant.NO_1);
				if (StringUtils.isBlank(sub)) {
					subAddr.append(StringUtils.space(G6Constant.NO_4));
				} else {
					subAddr.append(sub);
				}
				if (i < keibiSrchHistoryGSMChikuArr.length - G6Constant.NO_1) {
					subAddr.append(G6Constant.COMMA);
				}
			}
		}

		if (subAddr != null && !StringUtils.isEmpty(subAddr.toString())) {
			return G6Common.stringToArray(subAddr.toString());
		} else {
			return new ArrayList<String>();
		}
	}
}
