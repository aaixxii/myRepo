package com.nec.jp.G6Smartphone.dao.ghs;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.DistrictGHSInfoModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKeibiGHSModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP1100GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	public String getElectricNum(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	rDenkiMng.DENKEI");
		strBuilder.append(" FROM	R_DENKEI_MNG rDenkiMng");
		strBuilder.append(" WHERE	rDenkiMng.LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND rDenkiMng.FLG_LAST = :lastFlg");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("lastFlg", G6CodeConsts.CD009.LATEST);
		query.setMaxResults(1);

		return (String) query.getSingleResult();
	}

	public RKeibiGHSModel getGoukiSerial(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT");
		strBuilder.append("     IFNULL(rKeibi.GOUKI, '') as gouKi,");
		strBuilder.append("     IFNULL(rKeibi.SERIAL_NUM, '') as serialNum");
		strBuilder.append(" FROM	R_KEIBI rKeibi");
		strBuilder.append(" WHERE rKeibi.LN_KEIBI = :lnKeibi");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RCtlDevDataSubModel1100Result");
		query.setParameter("lnKeibi", lnKeibi);
		query.setMaxResults(1);

		return (RKeibiGHSModel) query.getSingleResult();
	}

	public DistrictGHSInfoModel getDistrictInfo(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	rKbChiku.LN_KB_CHIKU as lnKbChiku,");
		strBuilder.append("			IFNULL(rKbChiku.SUB_ADDR, '') as subAddr,");
		strBuilder.append("			IFNULL(rKbChiku.SD_KOBETU_NM, '') as sdKobetuNm");
		strBuilder.append(" FROM	R_KB_CHIKU rKbChiku");
		strBuilder.append("			INNER JOIN R_KEIBI rKeibi ON rKbChiku.LN_KEIBI = rKeibi.LN_KEIBI");
		strBuilder.append(" WHERE	rKeibi.LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND rKbChiku.ENTRY_STS = '1'");
		strBuilder.append(" ORDER BY rKbChiku.LN_KB_CHIKU,");
		strBuilder.append(" 		rKbChiku.SUB_ADDR");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKbChikuDataModel1100GHSTempResult");
		query.setParameter("lnKeibi", lnKeibi);
		query.setMaxResults(1);

		return (DistrictGHSInfoModel) query.getSingleResult();
	}

	public String getCmdSts(String cmdSeqNum) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(eQueCtrl.STS, '')");
		strBuilder.append("	FROM	E_QUE_CTRL eQueCtrl");
		strBuilder.append("	WHERE	eQueCtrl.CMD_SEQ_NUM = :cmdSeqNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("cmdSeqNum", cmdSeqNum);
		query.setMaxResults(1);
		return (String) query.getSingleResult();
	}

	public String getDeviceSts(String lnDev) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	cDevSts.DRCTSET_CNTR_ST");
		strBuilder.append(" FROM	C_DEV_STS cDevSts");
		strBuilder.append(" WHERE	cDevSts.LN_DEV = :lnDev");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnDev", lnDev);
		query.setMaxResults(1);

		return (String) query.getSingleResult();
	}

	
}
