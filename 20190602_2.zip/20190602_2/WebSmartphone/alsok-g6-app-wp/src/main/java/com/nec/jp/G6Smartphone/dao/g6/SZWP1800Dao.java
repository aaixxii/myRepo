package com.nec.jp.G6Smartphone.dao.g6;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.HAlsokNoticeDataModel;

@Repository
public class SZWP1800Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	private StringBuilder getNoticeListSql() {
		final StringBuilder strBuilder = new StringBuilder();
		
		// START: Change table H_ALSOK_NOTICE -> R_ALSOK_NOTICE
//		strBuilder.append(" SELECT	a.LN_H_ALSOK_NOTICE as lnHAlsokNotice,");
//		strBuilder.append("			IFNULL(DATE_FORMAT(a.SEND_TS, '%Y/%m/%d %H:%i:%s'), '') as sendTs,");
//		strBuilder.append("			IFNULL(a.TITLE, '') as title");
//		strBuilder.append(" FROM	H_ALSOK_NOTICE a");
//		strBuilder.append(" WHERE	(DATE_FORMAT(a.SEND_TS, '%Y%m%d') BETWEEN :dtFrom AND :dtTo)");
//		strBuilder.append(" ORDER BY a.SEND_TS DESC, a.LN_H_ALSOK_NOTICE DESC");
		
		strBuilder.append(" SELECT a.LN_ALSOK_NOTICE as lnHAlsokNotice,");
		strBuilder.append("   IFNULL(DATE_FORMAT(a.SEND_TS, '%Y/%m/%d %H:%i:%s'), '') as sendTs,");
		strBuilder.append("   IFNULL(a.TITLE, '') as title");
        strBuilder.append(" FROM R_ALSOK_NOTICE a");
        strBuilder.append(" WHERE (a.FLG_SEND_SVC_KIND LIKE CONCAT('%','201','%')");
        strBuilder.append("   OR a.FLG_SEND_SVC_KIND LIKE CONCAT('%','202','%') )");
        strBuilder.append(" AND (a.SEND_FLG = '0'");
        strBuilder.append("   OR a.SEND_STS = '3')");
        strBuilder.append(" AND a.DEL_FLG = '0'");
        strBuilder.append(" AND (DATE_FORMAT(a.SEND_TS, '%Y%m%d') BETWEEN :dtFrom AND :dtTo)");
        strBuilder.append(" ORDER BY a.SEND_TS DESC, a.LN_ALSOK_NOTICE DESC");
        // END: Change table H_ALSOK_NOTICE -> R_ALSOK_NOTICE
        
        return strBuilder;
	}
	
	public String getTotalRow(Date dtFrom, Date dtTo) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append("SELECT COUNT(*) FROM (");
		strBuilder.append(getNoticeListSql().toString());
		strBuilder.append(") NoticeList");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		
		return query.getSingleResult().toString();
	}
	
	@SuppressWarnings("unchecked")
	public List<HAlsokNoticeDataModel> getNoticeList(Date dtFrom, Date dtTo, int offset, int limitRowNum) {
		final StringBuilder strBuilder = new StringBuilder();
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		
		strBuilder.append(getNoticeListSql().toString());
		strBuilder.append(" LIMIT :offset, :limitRowNum");
        
		final Query query = entityManager.createNativeQuery(strBuilder.toString(), "HAlsokNoticeDataModelResult");
		query.setParameter("dtFrom", sdf.format(dtFrom));
		query.setParameter("dtTo", sdf.format(dtTo));
		query.setParameter("offset", offset);
		query.setParameter("limitRowNum", limitRowNum);

		return (List<HAlsokNoticeDataModel>) query.getResultList();
	}
}
