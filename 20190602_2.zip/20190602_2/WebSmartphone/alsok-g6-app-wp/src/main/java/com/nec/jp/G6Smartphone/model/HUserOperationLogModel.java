package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the H_USER_OPERATION_LOG database table.
 * 
 */
@Entity
@Table(name="H_USER_OPERATION_LOG")
@NamedQuery(name="HUserOperationLogModel.findAll", query="SELECT h FROM HUserOperationLogModel h")
public class HUserOperationLogModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private HUserOperationLogModelPK id;
	
	@Column(name="ACNT_USER_KBN")
	private String acntUserKbn;

	@Column(name="BIKOU")
	private String bikou;

	@Column(name="DISP_ID")
	private String dispId;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="KEIBI_NM")
	private String keibiNm;

	@Column(name="SD_KOBETU_NM")
	private String sdKobetuNm;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	@Column(name="USER_NM")
	private String userNm;

	@Column(name="USER_OPERATION_NAIYOU")
	private String userOperationNaiyou;

	@Column(name="USER_OPERATION_NAIYOU_CD")
	private String userOperationNaiyouCd;

	public HUserOperationLogModelPK getId() {
		return id;
	}

	public void setId(HUserOperationLogModelPK id) {
		this.id = id;
	}

	public String getUseDay() {
		return useDay;
	}

	public void setUseDay(String useDay) {
		this.useDay = useDay;
	}

	public String getLnKeibi() {
		return lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getLnKbChiku() {
		return lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	@Column(name="USE_DAY")
	private String useDay;
	
	@Column(name="LN_KEIBI")
	private String lnKeibi;
	
	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;
	
	public HUserOperationLogModel() {
	}

	public String getAcntUserKbn() {
		return this.acntUserKbn;
	}

	public void setAcntUserKbn(String acntUserKbn) {
		this.acntUserKbn = acntUserKbn;
	}

	public String getBikou() {
		return this.bikou;
	}

	public void setBikou(String bikou) {
		this.bikou = bikou;
	}

	public String getDispId() {
		return this.dispId;
	}

	public void setDispId(String dispId) {
		this.dispId = dispId;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getKeibiNm() {
		return this.keibiNm;
	}

	public void setKeibiNm(String keibiNm) {
		this.keibiNm = keibiNm;
	}

	public String getSdKobetuNm() {
		return this.sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public String getUserNm() {
		return this.userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getUserOperationNaiyou() {
		return this.userOperationNaiyou;
	}

	public void setUserOperationNaiyou(String userOperationNaiyou) {
		this.userOperationNaiyou = userOperationNaiyou;
	}

	public String getUserOperationNaiyouCd() {
		return this.userOperationNaiyouCd;
	}

	public void setUserOperationNaiyouCd(String userOperationNaiyouCd) {
		this.userOperationNaiyouCd = userOperationNaiyouCd;
	}

}