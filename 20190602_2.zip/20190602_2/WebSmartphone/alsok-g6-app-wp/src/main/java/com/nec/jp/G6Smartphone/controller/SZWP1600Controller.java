package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ResGetHistoryImage;
import com.nec.jp.G6Smartphone.SO.UserOperationChikuInfoModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP1600Service;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWP1600Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP1600Controller.class);

    //JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
	
	@Autowired
	SZWP1600Service sZWP1600Service;
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;

	/*
	 * Get data from E_KB_INF table
	 * @param: acntID, lnKbInf 
	 * return: object resGetHistoryImageImage as JSON
	 */
	@RequestMapping(value = "/getHistoryImage", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getHistoryImage(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1600Controller.getHistoryImage()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetHistoryImage resGetHistoryImage = new ResGetHistoryImage();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntType = "";
		String acntNm = "";

		try {
			String screenInfo = "";

			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetHistoryImage, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1600Controller.getHistoryImage()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetHistoryImage, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1600Controller.getHistoryImage()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 4) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetHistoryImage, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1600Controller.getHistoryImage()");
				return jsonResult;
			}

			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.acntSbt.getValue());
					add(RequestParam.lnKbInf.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetHistoryImage, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1600Controller.getHistoryImage()");
				return jsonResult;
			}

			// リクエスト情報取得
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();

			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resGetHistoryImage, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1600Controller.getHistoryImage()");
				return jsonResult;
			}

			// TODO SZWP1600：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 初期表示情報の取得
			// リクエスト情報から取得したアカウント種別が、次期警備の場合
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// 画面情報を取得する
				// 7-2.初期表示処理ＤＢ検索内容
				screenInfo = sZWP1600Service.getScreenInfoList(mapParam.get(RequestParam.lnKbInf.getValue()).toString());
			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//			final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//			hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP1600.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm, DateTimeCommon.getCurrentDate());
			UserOperationChikuInfoModel chikuInfo = commonService.getChikuInfoFromKbinf(acntType, mapParam.get(RequestParam.lnKbInf.getValue()).toString());
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());										// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);										// アカウント名
			hUserOperationLogModel.setLnKeibi(chikuInfo.getLnKeibi());						// 警備先論理番号
			hUserOperationLogModel.setLnKbChiku(chikuInfo.getLnKbChiku());					// 警備先地区論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP1600.getValueForOperationLog());	// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, acntType);
			
			// 応答
			resGetHistoryImage.setErrorCode(G6Constant.SUCCESS_CD);
			resGetHistoryImage.setVideoFileName(screenInfo);
			
			//デコード済acntIDを設定したJWT認証トークンを付与
			resGetHistoryImage.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
			
			jsonResult = G6Common.parseJSON(resGetHistoryImage, acntLanguage);

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetHistoryImage, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetHistoryImage, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetHistoryImage, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
		} catch (Exception e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetHistoryImage, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetHistoryImage, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1600Controller.getHistoryImage()");
		return jsonResult;
	}
}
