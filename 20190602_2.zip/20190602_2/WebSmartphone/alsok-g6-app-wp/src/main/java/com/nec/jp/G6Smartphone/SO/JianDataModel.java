package com.nec.jp.G6Smartphone.SO;

public class JianDataModel {

	private String insertTs;
	private String videoFileName;
	private String nickName;
	private String sdKobetuNm;
	private String devNm;
	private String lnRAuthPicInf;
	private String lnKbInf;
	private String lnImgNump;
	
    public JianDataModel() {
		this.insertTs = "";
		this.videoFileName = "";
		this.nickName = "";
		this.sdKobetuNm = "";
		this.devNm = "";
		this.lnRAuthPicInf = "";
		this.lnKbInf = "";
		this.lnImgNump = "";
	}
	public JianDataModel(String insertTs, String videoFileName, String nickName, String sdKobetuNm, String devNm,
			String lnRAuthPicInf, String lnKbInf, String lnImgNump) {
		this.insertTs = insertTs;
		this.videoFileName = videoFileName;
		this.nickName = nickName;
		this.sdKobetuNm = sdKobetuNm;
		this.devNm = devNm;
		this.lnRAuthPicInf = lnRAuthPicInf;
		this.lnKbInf = lnKbInf;
		this.lnImgNump = lnImgNump;
	}
	public String getInsertTs() {
		return insertTs;
	}
	public void setInsertTs(String insertTs) {
		this.insertTs = insertTs;
	}
	public String getVideoFileName() {
		return videoFileName;
	}
	public void setVideoFileName(String videoFileName) {
		this.videoFileName = videoFileName;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getSdKobetuNm() {
		return sdKobetuNm;
	}
	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}
	public String getDevNm() {
		return devNm;
	}
	public void setDevNm(String devNm) {
		this.devNm = devNm;
	}
	public String getLnRAuthPicInf() {
		return lnRAuthPicInf;
	}
	public void setLnRAuthPicInf(String lnRAuthPicInf) {
		this.lnRAuthPicInf = lnRAuthPicInf;
	}
	public String getLnKbInf() {
		return lnKbInf;
	}
	public void setLnKbInf(String lnKbInf) {
		this.lnKbInf = lnKbInf;
	}
   public String getLnImgNump() {
        return lnImgNump;
    }
    public void setLnImgNump(String lnImgNump) {
        this.lnImgNump = lnImgNump;
    }
}
