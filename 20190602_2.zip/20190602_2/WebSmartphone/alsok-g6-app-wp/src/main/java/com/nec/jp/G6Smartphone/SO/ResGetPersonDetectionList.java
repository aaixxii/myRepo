package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetPersonDetectionList implements ErrorHandler {

	private String errorCode;			// エラーコード
	private String errorMsg;			// エラーメッセージ
	private List<JianDataModel> jianItem;
	private String acntID;
	private String totalPage; 			//トタルページ
	
	public ResGetPersonDetectionList() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.jianItem = new ArrayList<JianDataModel>();
		this.acntID = "";
	}
	
	public ResGetPersonDetectionList(String errorCode, String errorMsg, List<JianDataModel> jianItem, String totalPage) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.jianItem = jianItem;
		this.acntID = "";
		this.totalPage = totalPage;
	}
	
	public String getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(String totalPage) {
		this.totalPage = totalPage;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public List<JianDataModel> getJianItem() {
		return jianItem;
	}
	public void setJianItem(List<JianDataModel> jianItem) {
		this.jianItem = jianItem;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
