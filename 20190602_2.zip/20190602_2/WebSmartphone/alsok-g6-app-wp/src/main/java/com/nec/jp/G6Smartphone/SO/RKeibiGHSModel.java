package com.nec.jp.G6Smartphone.SO;

public class RKeibiGHSModel {
	private String gouKi;
	private String serialNum;
	
	public RKeibiGHSModel() {
		this.gouKi = "";
		this.serialNum ="";
	}
	
	public RKeibiGHSModel(String gouKi,String serialNum) {
		this.gouKi = gouKi;
		this.serialNum = serialNum;
	}
	
	public String getGouKi() {
		return gouKi;
	}
	public void setGouKi(String gouKi) {
		this.gouKi = gouKi;
	}
	public String getSerialNum() {
		return serialNum;
	}
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}
}
