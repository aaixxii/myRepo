package com.nec.jp.G6Smartphone.SO;

public class HEventInfoDataModel {

	private String lnEventInfoHst;
	private String hasseiTs;
	private String chikuNm;
	private String kenchiNaiyou;
	private String videLkFlg;
	private String vfileInfo;
	public HEventInfoDataModel() {
		this.lnEventInfoHst = "";
		this.hasseiTs = "";
		this.chikuNm = "";
		this.kenchiNaiyou = "";
		this.videLkFlg = "";
		this.vfileInfo = "";
	}
	public HEventInfoDataModel(String lnEventInfoHst, String hasseiTs, String chikuNm, String kenchiNaiyou,
			String videLkFlg, String vfileInfo) {
		this.lnEventInfoHst = lnEventInfoHst;
		this.hasseiTs = hasseiTs;
		this.chikuNm = chikuNm;
		this.kenchiNaiyou = kenchiNaiyou;
		this.videLkFlg = videLkFlg;
		this.vfileInfo = vfileInfo;
	}
	public String getLnEventInfoHst() {
		return lnEventInfoHst;
	}
	public void setLnEventInfoHst(String lnEventInfoHst) {
		this.lnEventInfoHst = lnEventInfoHst;
	}
	public String getHasseiTs() {
		return hasseiTs;
	}
	public void setHasseiTs(String hasseiTs) {
		this.hasseiTs = hasseiTs;
	}
	public String getChikuNm() {
		return chikuNm;
	}
	public void setChikuNm(String chikuNm) {
		this.chikuNm = chikuNm;
	}
	public String getKenchiNaiyou() {
		return kenchiNaiyou;
	}
	public void setKenchiNaiyou(String kenchiNaiyou) {
		this.kenchiNaiyou = kenchiNaiyou;
	}
	public String getVideLkFlg() {
		return videLkFlg;
	}
	public void setVideLkFlg(String videLkFlg) {
		this.videLkFlg = videLkFlg;
	}
	public String getVfileInfo() {
		return vfileInfo;
	}
	public void setVfileInfo(String vfileInfo) {
		this.vfileInfo = vfileInfo;
	}
}
