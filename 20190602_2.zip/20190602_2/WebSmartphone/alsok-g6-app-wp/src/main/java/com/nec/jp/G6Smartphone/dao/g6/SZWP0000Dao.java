package com.nec.jp.G6Smartphone.dao.g6;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nec.jp.G6Smartphone.SO.G6ACntModel;
import com.nec.jp.G6Smartphone.SO.KeibisakiInfo;
import com.nec.jp.G6Smartphone.SO.RKeibiDataModel;
import com.nec.jp.G6Smartphone.SO.UserLoginInfoModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

import jp.co.alsok.g6.zzw.web.service.KeibisakiInfoConstant;

@Repository
public class SZWP0000Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;
	
	public UserLoginInfoModel getUserLoginInfo(String loginId) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT 	kauc.LN_ACNT_USER_COMMON as lnAcntUserCommon,");
		strBuilder.append("			kauc.ACNT_NM as acntNm,");
		strBuilder.append("			kauc.ACNT_NM_KANA as acntNmKana,");
		strBuilder.append("			CAST(kauc.ML_ADDR AS CHARACTER) as mlAddr,");
		strBuilder.append("			kauc.PASSWD as passwd,");
		strBuilder.append("			IFNULL(aau.ML_SEND_STS, '') as mlSendSts,");
		strBuilder.append("			IFNULL(aau.CHECK_STS, '') as checkSts,");
		strBuilder.append("			IFNULL(DATE_FORMAT(aau.LAST_LOGIN_TS, '%Y/%m/%d %H:%i:%s'), '') as lastLoginTs,");
		strBuilder.append("			CAST(kauc.ACNT_USER_KBN AS CHARACTER) as acntUserKbn,");
		strBuilder.append("  			:acntSbt as acntSbt");
		strBuilder.append(" FROM	commondb.K_ACNT_USER_COMMON kauc INNER JOIN A_ACNT_USER aau");
		strBuilder.append("			ON kauc.LN_ACNT_USER_COMMON = aau.LN_ACNT_USER_COMMON");
		strBuilder.append(" WHERE	kauc.ACNT_ID = :loginId");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "UserLoginInfoModelResult2");
		query.setParameter("loginId", loginId);
		query.setParameter("acntSbt", G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);

		return (UserLoginInfoModel) query.getSingleResult();
	}
	
	@SuppressWarnings("unchecked")
	public List<RKeibiDataModel> getSecurityName(String lnAcntUserCommon, String keibiName) {
		final StringBuilder strBuilder = new StringBuilder();
		
        strBuilder.append(" SELECT");
        strBuilder.append("     IFNULL(KEIBI.LN_KEIBI, '') AS lnKeibi");
        strBuilder.append("   , IFNULL(KEIBI.KEIBI_NAME1, '') AS keibiName1");
        strBuilder.append("   , IFNULL(KEIBI.KEIBI_NAME2, '') AS keibiName2");
        strBuilder.append("   , IFNULL(KEIBI.KEIBI_ADDR_1, '') as keibiAddr1");
        strBuilder.append(" FROM");
        strBuilder.append("    A_USER_OPERATION_HANI AS HANI");
        strBuilder.append(" INNER JOIN R_KEIBI AS KEIBI");
        strBuilder.append("    ON HANI.LN_ACNT_USER_COMMON = :lnAcntUserCommon");
        strBuilder.append("    AND ( KEIBI.PATH_INF = LEFT(HANI.PATH_INF, :keibiLength)");
        strBuilder.append("    OR HANI.PATH_INF = LEFT(KEIBI.PATH_INF, :numLength))");
        strBuilder.append("    AND KEIBI.DEL_FLG = '0'");
        strBuilder.append(" INNER JOIN R_KEIYK AS KEIYAKU");
        strBuilder.append("    ON KEIYAKU.LN_KEIYK = LEFT(KEIBI.PATH_INF, :numLength)");
        strBuilder.append("    AND KEIYAKU.DEL_FLG = '0'");
		strBuilder.append(" INNER JOIN R_TENANT_MNG RTM");
		strBuilder.append("    ON KEIBI.LN_KEIBI = RTM.LN_KEIBI");
        strBuilder.append("    AND RTM.WEB_USE_FLG = '1'");
		
		if (keibiName != null && keibiName.length() > 0) {
			strBuilder.append(" WHERE");
			strBuilder.append(" KEIBI.KEIBI_NAME1 LIKE :keibiName");
		}
        strBuilder.append(" GROUP BY lnKeibi, keibiName1, keibiName2, keibiAddr1");
        strBuilder.append(" ORDER BY keibiName1, keibiName2");

        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKeibiDataModelResult");
        query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
        query.setParameter("keibiLength", KeibisakiInfoConstant.KEIBI_LENGTH);
        query.setParameter("numLength", KeibisakiInfoConstant.NUM_LENGTH);
		if (keibiName != null && keibiName.length() > 0) {
			query.setParameter("keibiName", "%"+keibiName+"%");
		}
        return (List<RKeibiDataModel>) query.getResultList();
	}
	
	public Boolean updateConfirmStatus(String lnAcntUserCommon, String acntNm, Date updateTs) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" UPDATE	AAcntUserModel aaum");
		strBuilder.append(" SET		aaum.checkSts = :checkSts,");
		strBuilder.append("			aaum.updateId = :lnAcntUserCommon,");
		strBuilder.append("			aaum.updateNm = :updateNm,");
		strBuilder.append("			aaum.updateTs = :updateTs");
		strBuilder.append(" WHERE	aaum.lnAcntUserCommon = :lnAcntUserCommon");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("checkSts", G6CodeConsts.CD077.STOP);
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
		query.setParameter("updateNm", acntNm);
		query.setParameter("updateTs", updateTs);

		if(query.executeUpdate() > 0) {
			return true;
		}

		return false;
	}

	public Boolean updateRegisStatus(String lnAcntUserCommon) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" UPDATE	AAcntUserModel aaum");
		strBuilder.append(" SET		aaum.mlSts = :mlSts,");
		strBuilder.append("			aaum.checkSts = :checkSts");
		strBuilder.append(" WHERE	aaum.lnAcntUserCommon = :lnAcntUserCommon");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("mlSts", G6CodeConsts.CD032.POSSIBLE);
		query.setParameter("checkSts", G6CodeConsts.CD077.COMPLETING_REGISTRATION);
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);

		if(query.executeUpdate() > 0) {
			return true;
		}

		return false;
	}

	public Boolean updateLastLoginDate(String lnAcntUserCommon, String acntNm, Date updateTs) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" UPDATE	AAcntUserModel aaum");
		strBuilder.append(" SET		aaum.lastLoginTs = :lastLoginTs,");
		strBuilder.append("			aaum.updateId = :lnAcntUserCommon,");
		strBuilder.append("			aaum.updateNm = :updateNm,");
		strBuilder.append("			aaum.updateTs = :updateTs");
		strBuilder.append(" WHERE	aaum.lnAcntUserCommon = :lnAcntUserCommon");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("lastLoginTs", updateTs);
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
		query.setParameter("updateNm", acntNm);
		query.setParameter("updateTs", updateTs);

		if(query.executeUpdate() > 0) {
			return true;
		}

		return false;
	}
	
	public String getLnKeiykFromLnKeibi(String lnKeibi) {
		final StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT");
		strBuilder.append("   IFNULL(RKK.LN_KEIYK, '') as lnKeiyk");
		strBuilder.append(" FROM");
		strBuilder.append(" R_KEIYK RKK");
		strBuilder.append(" INNER JOIN R_KEIYK_BUKKEN RKB");
		strBuilder.append(" ON RKK.LN_KEIYK = RKB.LN_KEIYK");
		strBuilder.append(" INNER JOIN R_KEIBI RKI");
		strBuilder.append(" ON RKB.LN_BUKKEN = RKI.LN_BUKKEN");
		strBuilder.append(" WHERE");
		strBuilder.append(" RKK.DEL_FLG = '0'");
		strBuilder.append(" AND RKB.DEL_FLG = '0'");
		strBuilder.append(" AND RKI.DEL_FLG = '0'");
	    strBuilder.append(" AND RKI.LN_KEIBI = :lnKeibi");
		
        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnKeibi", lnKeibi);

        return query.getSingleResult().toString();
	}
}
