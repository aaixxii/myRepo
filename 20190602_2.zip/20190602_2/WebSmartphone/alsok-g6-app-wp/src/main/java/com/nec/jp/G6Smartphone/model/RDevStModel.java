package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the R_DEV_STS database table.
 * 
 */
@Entity
@Table(name="R_DEV_STS")
@NamedQuery(name="RDevStModel.findAll", query="SELECT r FROM RDevStModel r")
public class RDevStModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_DEV")
	private String lnDev;

	@Column(name="BKDW_ST")
	private String bkdwSt;

	@Column(name="BTCKCMP_RQ_RSLT")
	private String btckcmpRqRslt;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="BTCKCMP_RQ_RSLT_TS")
	private Date btckcmpRqRsltTs;

	@Column(name="CHK_RSLT_FLG")
	private String chkRsltFlg;

	@Column(name="CONN_NUM")
	private String connNum;

	@Column(name="CTSTCMP_RQ_FLG")
	private String ctstcmpRqFlg;

	@Column(name="CTSTCMP_RQ_RSLT_BACK")
	private String ctstcmpRqRsltBack;

	@Column(name="CTSTCMP_RQ_RSLT_MAIN")
	private String ctstcmpRqRsltMain;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CTSTCMP_RQ_RSLT_TS_BACK")
	private Date ctstcmpRqRsltTsBack;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CTSTCMP_RQ_RSLT_TS_MAIN")
	private Date ctstcmpRqRsltTsMain;

	@Column(name="DEL_FLG")
	private String delFlg;

	@Column(name="DOUSA_KIND")
	private String dousaKind;

	@Column(name="DRCTSET_CNTR_STS")
	private String drctsetCntrSts;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="DRCTSET_CNTR_STS_TS")
	private Date drctsetCntrStsTs;

	@Column(name="DROP_STS")
	private String dropSts;

	@Column(name="DSTB_STS")
	private String dstbSts;

	@Column(name="ENVI_STS")
	private String enviSts;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_ALARM_TS")
	private Date lastAlarmTs;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_CHK_TS")
	private Date lastChkTs;

	@Column(name="LEDL_ST")
	private String ledlSt;

	@Column(name="LWVL_ST")
	private String lwvlSt;

	@Column(name="POST_STS")
	private String postSts;

	@Column(name="PWFL_STS")
	private String pwflSts;

	@Column(name="SENS_STS")
	private String sensSts;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SHNT_END_DAY")
	private Date shntEndDay;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SHNT_SET_DAY")
	private Date shntSetDay;

	@Column(name="SHNTSET_CNTR_STS")
	private String shntsetCntrSts;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SHNTSET_CNTR_STS_TS")
	private Date shntsetCntrStsTs;

	@Column(name="TANP_STS")
	private String tanpSts;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	@Column(name="WAKE_ST")
	private String wakeSt;

	@Column(name="WRBK_STS")
	private String wrbkSts;

	public RDevStModel() {
	}

	public String getLnDev() {
		return this.lnDev;
	}

	public void setLnDev(String lnDev) {
		this.lnDev = lnDev;
	}

	public String getBkdwSt() {
		return this.bkdwSt;
	}

	public void setBkdwSt(String bkdwSt) {
		this.bkdwSt = bkdwSt;
	}

	public String getBtckcmpRqRslt() {
		return this.btckcmpRqRslt;
	}

	public void setBtckcmpRqRslt(String btckcmpRqRslt) {
		this.btckcmpRqRslt = btckcmpRqRslt;
	}

	public Date getBtckcmpRqRsltTs() {
		return this.btckcmpRqRsltTs;
	}

	public void setBtckcmpRqRsltTs(Date btckcmpRqRsltTs) {
		this.btckcmpRqRsltTs = btckcmpRqRsltTs;
	}

	public String getChkRsltFlg() {
		return this.chkRsltFlg;
	}

	public void setChkRsltFlg(String chkRsltFlg) {
		this.chkRsltFlg = chkRsltFlg;
	}

	public String getConnNum() {
		return this.connNum;
	}

	public void setConnNum(String connNum) {
		this.connNum = connNum;
	}

	public String getCtstcmpRqFlg() {
		return this.ctstcmpRqFlg;
	}

	public void setCtstcmpRqFlg(String ctstcmpRqFlg) {
		this.ctstcmpRqFlg = ctstcmpRqFlg;
	}

	public String getCtstcmpRqRsltBack() {
		return this.ctstcmpRqRsltBack;
	}

	public void setCtstcmpRqRsltBack(String ctstcmpRqRsltBack) {
		this.ctstcmpRqRsltBack = ctstcmpRqRsltBack;
	}

	public String getCtstcmpRqRsltMain() {
		return this.ctstcmpRqRsltMain;
	}

	public void setCtstcmpRqRsltMain(String ctstcmpRqRsltMain) {
		this.ctstcmpRqRsltMain = ctstcmpRqRsltMain;
	}

	public Date getCtstcmpRqRsltTsBack() {
		return this.ctstcmpRqRsltTsBack;
	}

	public void setCtstcmpRqRsltTsBack(Date ctstcmpRqRsltTsBack) {
		this.ctstcmpRqRsltTsBack = ctstcmpRqRsltTsBack;
	}

	public Date getCtstcmpRqRsltTsMain() {
		return this.ctstcmpRqRsltTsMain;
	}

	public void setCtstcmpRqRsltTsMain(Date ctstcmpRqRsltTsMain) {
		this.ctstcmpRqRsltTsMain = ctstcmpRqRsltTsMain;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getDousaKind() {
		return this.dousaKind;
	}

	public void setDousaKind(String dousaKind) {
		this.dousaKind = dousaKind;
	}

	public String getDrctsetCntrSts() {
		return this.drctsetCntrSts;
	}

	public void setDrctsetCntrSts(String drctsetCntrSts) {
		this.drctsetCntrSts = drctsetCntrSts;
	}

	public Date getDrctsetCntrStsTs() {
		return this.drctsetCntrStsTs;
	}

	public void setDrctsetCntrStsTs(Date drctsetCntrStsTs) {
		this.drctsetCntrStsTs = drctsetCntrStsTs;
	}

	public String getDropSts() {
		return this.dropSts;
	}

	public void setDropSts(String dropSts) {
		this.dropSts = dropSts;
	}

	public String getDstbSts() {
		return this.dstbSts;
	}

	public void setDstbSts(String dstbSts) {
		this.dstbSts = dstbSts;
	}

	public String getEnviSts() {
		return this.enviSts;
	}

	public void setEnviSts(String enviSts) {
		this.enviSts = enviSts;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public Date getLastAlarmTs() {
		return this.lastAlarmTs;
	}

	public void setLastAlarmTs(Date lastAlarmTs) {
		this.lastAlarmTs = lastAlarmTs;
	}

	public Date getLastChkTs() {
		return this.lastChkTs;
	}

	public void setLastChkTs(Date lastChkTs) {
		this.lastChkTs = lastChkTs;
	}

	public String getLedlSt() {
		return this.ledlSt;
	}

	public void setLedlSt(String ledlSt) {
		this.ledlSt = ledlSt;
	}

	public String getLwvlSt() {
		return this.lwvlSt;
	}

	public void setLwvlSt(String lwvlSt) {
		this.lwvlSt = lwvlSt;
	}

	public String getPostSts() {
		return this.postSts;
	}

	public void setPostSts(String postSts) {
		this.postSts = postSts;
	}

	public String getPwflSts() {
		return this.pwflSts;
	}

	public void setPwflSts(String pwflSts) {
		this.pwflSts = pwflSts;
	}

	public String getSensSts() {
		return this.sensSts;
	}

	public void setSensSts(String sensSts) {
		this.sensSts = sensSts;
	}

	public Date getShntEndDay() {
		return this.shntEndDay;
	}

	public void setShntEndDay(Date shntEndDay) {
		this.shntEndDay = shntEndDay;
	}

	public Date getShntSetDay() {
		return this.shntSetDay;
	}

	public void setShntSetDay(Date shntSetDay) {
		this.shntSetDay = shntSetDay;
	}

	public String getShntsetCntrSts() {
		return this.shntsetCntrSts;
	}

	public void setShntsetCntrSts(String shntsetCntrSts) {
		this.shntsetCntrSts = shntsetCntrSts;
	}

	public Date getShntsetCntrStsTs() {
		return this.shntsetCntrStsTs;
	}

	public void setShntsetCntrStsTs(Date shntsetCntrStsTs) {
		this.shntsetCntrStsTs = shntsetCntrStsTs;
	}

	public String getTanpSts() {
		return this.tanpSts;
	}

	public void setTanpSts(String tanpSts) {
		this.tanpSts = tanpSts;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public String getWakeSt() {
		return this.wakeSt;
	}

	public void setWakeSt(String wakeSt) {
		this.wakeSt = wakeSt;
	}

	public String getWrbkSts() {
		return this.wrbkSts;
	}

	public void setWrbkSts(String wrbkSts) {
		this.wrbkSts = wrbkSts;
	}

}