package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetDevList implements ErrorHandler {

	private String errorCode; // エラーコード
	private String errorMsg; // エラーメッセージ
	private List<RDevNameDataModel> rDevNameItem;
	private String acntID;
	
	public ResGetDevList() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.rDevNameItem = new ArrayList<RDevNameDataModel>();
		this.acntID = "";
	}
	public ResGetDevList(String errorCode, String errorMsg, List<RDevNameDataModel> rDevNameItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.rDevNameItem = rDevNameItem;
		this.acntID = "";
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public List<RDevNameDataModel> getrDevNameItem() {
		return rDevNameItem;
	}
	public void setrDevNameItem(List<RDevNameDataModel> rDevNameItem) {
		this.rDevNameItem = rDevNameItem;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
