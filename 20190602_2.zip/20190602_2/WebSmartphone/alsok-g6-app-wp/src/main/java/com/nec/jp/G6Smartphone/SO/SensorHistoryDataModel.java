package com.nec.jp.G6Smartphone.SO;

public class SensorHistoryDataModel {

	private String hasseiDate;			// センサー検知履歴日付
	private String hasseiTime;			// センサー検知履歴時刻
	private String kbAreaNm;			// センサー検知履歴警備エリア
	private String devNm;				// センサー検知履歴機器名称
	private String videoFileName;		// センサー検知履歴画像
	private String lnKbInf;				// センサー検知履歴メール

	public SensorHistoryDataModel() {
		this.hasseiDate = "";
		this.hasseiTime = "";
		this.kbAreaNm = "";
		this.devNm = "";
		this.videoFileName = "";
		this.lnKbInf = "";
	}

	public SensorHistoryDataModel(String hasseiDate, String hasseiTime, String kbAreaNm, String devNm,
			String videoFileName, String lnKbInf) {
		this.hasseiDate = hasseiDate;
		this.hasseiTime = hasseiTime;
		this.kbAreaNm = kbAreaNm;
		this.devNm = devNm;
		this.videoFileName = videoFileName;
		this.lnKbInf = lnKbInf;
	}

	public String getHasseiDate() {
		return hasseiDate;
	}

	public void setHasseiDate(String hasseiDate) {
		this.hasseiDate = hasseiDate;
	}

	public String getHasseiTime() {
		return hasseiTime;
	}

	public void setHasseiTime(String hasseiTime) {
		this.hasseiTime = hasseiTime;
	}

	public String getKbAreaNm() {
		return kbAreaNm;
	}

	public void setKbAreaNm(String kbAreaNm) {
		this.kbAreaNm = kbAreaNm;
	}

	public String getDevNm() {
		return devNm;
	}

	public void setDevNm(String devNm) {
		this.devNm = devNm;
	}

	public String getVideoFileName() {
		return videoFileName;
	}

	public void setVideoFileName(String videoFileName) {
		this.videoFileName = videoFileName;
	}

	public String getLnKbInf() {
		return lnKbInf;
	}

	public void setLnKbInf(String lnKbInf) {
		this.lnKbInf = lnKbInf;
	}
}
