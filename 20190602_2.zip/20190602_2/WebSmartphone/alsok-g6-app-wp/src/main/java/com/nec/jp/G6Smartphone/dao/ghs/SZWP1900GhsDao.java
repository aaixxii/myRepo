package com.nec.jp.G6Smartphone.dao.ghs;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.ResGetNoticeDetail;

@Repository
public class SZWP1900GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	public ResGetNoticeDetail getNoticeDetailGHSKeiyk(String lnAlsokNotice, String acntID) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	a.LN_ALSOK_NOTICE as lnAlsokNotice,");
		strBuilder.append(" 		CAST(a.TITLE as CHARACTER) as title,");
		strBuilder.append(" 		a.SENDER_NM as insertNm,");
		strBuilder.append(" 		a.BODY as body,");
		strBuilder.append(" 		DATE_FORMAT(a.SEND_TM, '%Y/%m/%d %H:%i:%s') as send_ts,");
		strBuilder.append(" 		CAST(a.FLG_ML_SEND as CHARACTER) as flgMlSend,");
		strBuilder.append(" 		b.LN_ACNT_KEIYK as lnAcnt");
		strBuilder.append(" FROM	E_ALSOK_NOTICE a");
		strBuilder.append("			INNER JOIN E_KEIYAKU_ALSOK_NOTICE_ML_TGT b ON a.LN_ALSOK_NOTICE = b.LN_ALSOK_NOTICE");
		strBuilder.append(" WHERE	a.LN_ALSOK_NOTICE = :lnAlsokNotice");
		strBuilder.append("			AND b.LN_ACNT_KEIYK = :acntID");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "ResGetNoticeDetailResult");
		query.setParameter("lnAlsokNotice", lnAlsokNotice);
		query.setParameter("acntID", acntID);

		return (ResGetNoticeDetail) query.getSingleResult();
	}

	public ResGetNoticeDetail getNoticeDetailGHSUser(String lnAlsokNotice, String acntID) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	a.LN_ALSOK_NOTICE as lnAlsokNotice,");
		strBuilder.append(" 		CAST(a.TITLE as CHARACTER) as title,");
		strBuilder.append(" 		a.SENDER_NM as insertNm,");
		strBuilder.append(" 		a.BODY as body,");
		strBuilder.append(" 		DATE_FORMAT(a.SEND_TM, '%Y/%m/%d %H:%i:%s') as send_ts,");
		strBuilder.append(" 		CAST(a.FLG_ML_SEND as CHARACTER) as flgMlSend,");
		strBuilder.append(" 		b.LN_ACNT_USER as lnAcnt");
		strBuilder.append(" FROM	E_ALSOK_NOTICE a");
		strBuilder.append("			INNER JOIN E_ALSOK_NOTICE_ML_TGT b ON a.LN_ALSOK_NOTICE = b.LN_ALSOK_NOTICE");
		strBuilder.append(" WHERE	a.LN_ALSOK_NOTICE = :lnAlsokNotice");
		strBuilder.append("			AND b.LN_ACNT_USER = :acntID");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "ResGetNoticeDetailResult");
		query.setParameter("lnAlsokNotice", lnAlsokNotice);
		query.setParameter("acntID", acntID);

		return (ResGetNoticeDetail) query.getSingleResult();
	}
}
