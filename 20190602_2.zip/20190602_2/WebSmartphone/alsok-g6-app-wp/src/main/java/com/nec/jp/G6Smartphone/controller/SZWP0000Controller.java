package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.nec.jp.G6Smartphone.SO.KiyLoginInfoModel;
import com.nec.jp.G6Smartphone.SO.LiyGSLoginInfoModel;
import com.nec.jp.G6Smartphone.SO.RKeibiDataModel;
import com.nec.jp.G6Smartphone.SO.ResLoginScreen;
import com.nec.jp.G6Smartphone.SO.SZWP0000Info;
import com.nec.jp.G6Smartphone.SO.UserLoginInfoModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.model.WQueAcMlTrigModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.com.SZWP0000ComService;
import com.nec.jp.G6Smartphone.service.com.SZWP0200ComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP0000Service;
import com.nec.jp.G6Smartphone.service.ghs.CommonGhsService;
import com.nec.jp.G6Smartphone.service.ghs.SZWP0000GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;
import jp.co.alsok.g6.zzw.web.service.EncryptionService;

@Controller
public class SZWP0000Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP0000Controller.class);
    
    //JWT認証トークン
    private G6JWTVerifier jwtverifier;
    
    @Autowired
    SZWP0000Service sZWP0000Service;
    @Autowired
    SZWP0000GhsService sZWP0000GhsService;
    @Autowired
    SZWP0000ComService sZWP0000ComService;
    @Autowired
    CommonService commonService;
    @Autowired
    CommonComService commonComService;
    @Autowired
    EncryptionService encryptionService;
    @Autowired
    CommonGhsService commonGhsService;
    @Autowired
    SZWP0200ComService sZWP0200ComService;
    
	@Value("${noGhsDbConnectionMode}")
	String noGhsDbConnectionMode;
    
    @Value("${maxLoginFailureTimes}")
    Integer MAX_LOGIN_FAILURE_TIMES;
    @Value("${pcURL}")
    String pcURL;
    @Value("${shopURL}")
    String shopURL;
    @Value("${maxHistoryShowDays}")
    String MAX_HISTORY_DAYS;
    // スマホ情報提供サーバIPアドレス
    @Value("${smartphone_server_host}")
    String smartphoneServerHost;
    // スマホ情報提供サーバソケット通信用port
    @Value("${smartphone_server_port}")
    String smartphoneServerPort;
    @Value("${limit_row_num}")
    Integer limit_row_num;
    

    /*
     * Get data from K_ACNT_USER_COMMON, A_ACNT_USER table
     * 
     * @param: loginId, password, language return: object ResLoginScreen as JSON
     */
    @RequestMapping(value = "/loginScreen", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public @ResponseBody String loginScreen(@RequestBody String strParam) {
    	appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0000Controller.loginScreen()");
        String jsonResult = "";
        String acntLanguage = G6CodeConsts.CD238.JAPANESE;
        ResLoginScreen resLoginScreen = new ResLoginScreen();
        Map<String, Object> mapParam = new HashMap<String, Object>();
        List<RKeibiDataModel> rKeibiDataModel = new ArrayList<RKeibiDataModel>();
        String passwd = "";
        int pageNo  = 0;
        SZWP0000Info szwp0000Info = new SZWP0000Info();
        
        try {
            // リクエスト情報からパラメータを取得する
            mapParam = G6Common.readParam(strParam);
            
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // リクエスト情報から選択言語種別を取得する
            if (null != mapParam.get(RequestParam.language.getValue())
                    && !"".equals(mapParam.get(RequestParam.language.getValue()))) {
                acntLanguage = mapParam.get(RequestParam.language.getValue()).toString();
            }

            // リクエスト情報を検証する
            if (mapParam.size() != 4) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0000Controller.loginScreen()");
                return jsonResult;
            }

            // Build require parameters
            List<String> lstRequiredParam = new ArrayList<String>() {
                private static final long serialVersionUID = 1L;
                {
                    add(RequestParam.loginId.getValue());
                    add(RequestParam.passwd.getValue());
                    add(RequestParam.language.getValue());
                    add(RequestParam.pageNo.getValue());
                    
                }
            };

            if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0000Controller.loginScreen()");
                return jsonResult;
            }
            
            //Verify pageNo RequestParam
            pageNo = Integer.parseInt(mapParam.get(RequestParam.pageNo.getValue()).toString());
    		if(pageNo < 0) {
    			jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
    					ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
    				
    			// 処理終了
    			appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0000Controller.loginScreen()");
    			return jsonResult;
    		}
            
            passwd = mapParam.get(RequestParam.passwd.getValue()).toString();
            // リクエスト情報からアカウント種別を取得する
            // アカウント情報区分
            String accountKubun = null;
            // ログイン処理
            // ログイン画面のINFO
            UserLoginInfoModel g6Info = new UserLoginInfoModel();
            KiyLoginInfoModel kiyInfo = new KiyLoginInfoModel();
            LiyGSLoginInfoModel liyGSInfo = new LiyGSLoginInfoModel();
            // 次期警備のアカウント情報を検索する
            // 8-2.A)利用者アカウント情報の取得
            try {
                g6Info = sZWP0000Service
                        .getUserLoginInfo(mapParam.get(RequestParam.loginId.getValue()).toString());
            } catch (Exception ex) {
                // アカウント権限例外
            	g6Info = null;
                // 例外発生時にログ出力
            	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
            }
            

            //GHSDB 接続制限フラグを確認
            if (!noGhsDbConnectionMode.equals(G6Constant.FLG_ENABLE)) {
	            // 契約者アカウント情報の検索
	            // 8-4 A)契約者アカウント情報の取得
	            try {
	                kiyInfo = sZWP0000GhsService.getKiyLoginInfo(mapParam.get(RequestParam.loginId.getValue()).toString(), null);
	            } catch (Exception ex) {
	                // アカウント権限例外
	            	kiyInfo = null;
	                // 例外発生時にログ出力
	            	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
	            }
	            
	            // 利用者アカウント情報の検索
	            // 8-4 B)利用者アカウント(GS)情報の取得
	            try {
	                liyGSInfo = sZWP0000GhsService.getLiyGSLoginInfo(
	                        mapParam.get(RequestParam.loginId.getValue()).toString(), null, G6CodeConsts.CD046.GS);
	            } catch (Exception ex) {
	                // アカウント権限例外
	            	liyGSInfo = null;
	                // 例外発生時にログ出力
	            	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex);
	            }
            }else {
            	kiyInfo = null;
            	liyGSInfo = null;		
            }
            
            // アカウント情報が1件も取得できなかった場合
            if (g6Info == null && kiyInfo == null && liyGSInfo == null) {
            	// 共通「エラーメッセージ取得処理」を呼び出し、エラーメッセージを取得する。
                jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.NO_USER_FOUND.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0000Controller.loginScreen()");
                return jsonResult;
            }

            // アカウント情報あり
            if (g6Info != null) {
                if (kiyInfo != null) {
                    // 「次期警備」＋「GS契約者」
                    accountKubun = G6Constant.ACOUNT_NEXT_TERM_GUARD_GS;
                } else if (liyGSInfo != null) {
                    // 「次期警備」＋「GS利用者」
                    accountKubun = G6Constant.ACOUNT_NEXT_TERM_GUARD_HS;
                } else {
                    // 「次期警備」
                    accountKubun = G6Constant.ACOUNT_NEXT_TERM_GUARD;
                }
                
                szwp0000Info = (SZWP0000Info)g6Info;
            } else {
                if (kiyInfo != null) {
                    szwp0000Info = (SZWP0000Info)kiyInfo;

                } else if (liyGSInfo != null) {
                	szwp0000Info = (SZWP0000Info)liyGSInfo;
                }
            }
            
            // 「次期警備」、「次期警備」＋「GS契約者」、「次期警備」＋「GS利用者」の場合
            if (G6Constant.ACOUNT_NEXT_TERM_GUARD.equals(accountKubun)
                    || G6Constant.ACOUNT_NEXT_TERM_GUARD_GS.equals(accountKubun)
                    || G6Constant.ACOUNT_NEXT_TERM_GUARD_HS.equals(accountKubun)) {
                // Only compare password in case G6 belong to Web application.
                final String strPass = encryptionService.convStringToCipher(passwd);
                jsonResult = handleG6Login(resLoginScreen, rKeibiDataModel, g6Info, kiyInfo, liyGSInfo, strPass, passwd, acntLanguage, pageNo, accountKubun);
            } else if (kiyInfo != null) {
                // 「GS契約者」ありの場合
                jsonResult = handleKiyLogin(g6Info, kiyInfo, resLoginScreen, rKeibiDataModel, passwd, acntLanguage, pageNo);
            } else if (liyGSInfo != null) {
                // 「GS利用者」ありの場合
                jsonResult = handleLiyGSLogin(g6Info, liyGSInfo, resLoginScreen, rKeibiDataModel, passwd, acntLanguage, pageNo);
            }
        } catch (ApplicationException e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            jsonResult = G6Common.messageLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD, e.getExceptionCode(),
                    e.getExceptionMsg(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
                jsonResult = G6Common.messageLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                        ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e),
                        acntLanguage);
            } else {
                jsonResult = G6Common.messageLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                        ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
            }
        }
        // 処理終了
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0000Controller.loginScreen()");
        return jsonResult;
    }

    /**
     * 「アカウント区分」がACOUNT_NEXT_TERM_GUARD(1) OR ACOUNT_NEXT_TERM_GUARD_GS(3) OR
     * ACOUNT_NEXT_TERM_GUARD_HS(5)の場合
     * 
     * @param resLoginScreen
     * @param rKeibiDataModel
     * @param SZWP0000Info G6info
     * @param strPass
     * @param passwd
     * @param acntLanguage
     * @param pageNo
     * @param accountKubun
     * @return
     * @throws ApplicationException
     */
    private String handleG6Login(ResLoginScreen resLoginScreen, List<RKeibiDataModel> rKeibiDataModel,
    		SZWP0000Info g6Info, KiyLoginInfoModel kiyInfo, LiyGSLoginInfoModel liyGSInfo, String strPass, String passwd, String acntLanguage, int pageNo, String accountKubun) throws ApplicationException, JWTCreationException {
    	String jsonResult = "";
        String lnKeiyk = "";
        int totalRow = 0;
		int totalPage = 0;
		int offset = 0;
        
        if (!strPass.equals(g6Info.getPasswd())) {
            int loginFailureTimes = 0;
            // ログイン失敗回数を取得する
            // 8-2.B)ログイン失敗回数の取得
            loginFailureTimes = sZWP0000ComService.getLoginFailureTimes(g6Info.getLnAcntUserCommon());
            if (loginFailureTimes == -1) {
                jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                        ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_LOGIN_FAILURE_TIMES.getValue(), acntLanguage);

                // 処理終了
                return jsonResult;
            }
            // ログイン失敗回数をチェックする
            // ログイン失敗回数上限値の値が0の場合
            if ((loginFailureTimes == 0) || (loginFailureTimes < MAX_LOGIN_FAILURE_TIMES)) {
                // 8-3.A)ログインエラー回数更新
                jsonResult = updateLoginFailureTimes(resLoginScreen, G6Constant.ACOUNT_NEXT_TERM_GUARD,
                        g6Info.getLnAcntUserCommon(), g6Info.getAcntNm(), loginFailureTimes, acntLanguage);
            } else if (loginFailureTimes >= MAX_LOGIN_FAILURE_TIMES) {
                // ログイン失敗回数がログイン失敗回数上限値に達した場合
                // 8-3.B)確認状態更新
                jsonResult = updatePasswordLock(resLoginScreen, G6Constant.ACOUNT_NEXT_TERM_GUARD,
                        g6Info.getLnAcntUserCommon(), g6Info.getAcntNm(), null, acntLanguage);
                // 処理終了
                return jsonResult;
            }
        } else {

            // 確認状態が'4':「タイムアウト」、'5':「停止」の場合
            if ((G6CodeConsts.CD077.TIME_OUT).equals(g6Info.getCheckSts())
                    || (G6CodeConsts.CD077.STOP).equals(g6Info.getCheckSts())) {
                // メール通知許可状態が'0'、'9'：メール通知不可の場合
                if (((G6CodeConsts.CD032.CONFIRMATION_WAITING).equals(g6Info.getMlSendSts()))
                        || ((G6CodeConsts.CD032.ERROR).equals(g6Info.getMlSendSts()))) {
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.LOGIN_WHEN_EMAIL_NOTI_DISABLED.getValue(), acntLanguage);

                    // メール通知許可状態が'1'：メール通知可の場合
                } else if ((G6CodeConsts.CD032.POSSIBLE).equals(g6Info.getMlSendSts())) {
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.LOGIN_NOT_ALLOWED.getValue(), acntLanguage);

                } else {
                    // spec does not mention
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.ERROR_MLSTS_CHKSTS_NOT_EXIST.getValue(), acntLanguage);
                }

                // 処理終了
                return jsonResult;

                // 確認状態が'1':「確認待ち」、'2':「登録完了」の場合
            } else if ((G6CodeConsts.CD077.CONFIRMATION_WAITING).equals(g6Info.getCheckSts())
                    || (G6CodeConsts.CD077.COMPLETING_REGISTRATION).equals(g6Info.getCheckSts())) {
                // 利用者ログイン状態のログイン状態フラグ、ログイン失敗回数を更新する
                // 8-3.C)ログイン状態更新
            	
                Boolean updateSts = sZWP0000ComService.updateLoginStatus(g6Info.getLnAcntUserCommon(),
                        g6Info.getAcntNm());

                if (!updateSts) {
                    jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                            ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_LOGIN_STATUS.getValue(), acntLanguage);

                    // 処理終了
                    return jsonResult;
                }

                // 確認状態が'1':「確認待ち」の場合
                if ((G6CodeConsts.CD077.CONFIRMATION_WAITING).equals(g6Info.getCheckSts())) {
                	resLoginScreen.setErrorTitle("0");
                	
                    // アカウントを本登録状態に更新する
                    // 8-3.D)本登録状態に更新
                    // fix bug No.36
//                    updateSts = sZWP0000Service.updateRegisStatus(g6Info.getLnAcntUserCommon());
//                    if (!updateSts) {
//                        jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD, ErrorKey.UPDATE_REGIS_STATUS.getValue(), acntLanguage);
//                        // 処理終了
//                        return jsonResult;
//                    }
                    jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD, ErrorKey.UPDATE_REGIS_STATUS.getValue(), acntLanguage);
                    // 処理終了
                    return jsonResult;
                }
                
                String ghsAcntNo = "";
            	if(G6CodeConsts.CD077.COMPLETING_REGISTRATION.equals(g6Info.getCheckSts())) {
                    if (G6Constant.ACOUNT_NEXT_TERM_GUARD_GS.equals(accountKubun)) {
                        // ・GHSアカウント論理番号 ： LN_契約者アカウント論理番号
                    	ghsAcntNo = g6Info.getLnAcntUserCommon();
                    } else if (G6Constant.ACOUNT_NEXT_TERM_GUARD_HS.equals(accountKubun)) {
                        // ◇「GS利用者」の場合
                        // ・GHSアカウント論理番号 ： LN_利用者アカウント論理番号
                    	ghsAcntNo = g6Info.getLnAcntUserCommon();
                    }
            	}
            	
            	//ログイン画面で指定した言語設定で更新する。
        		String selectLang = acntLanguage;
        		// 言語選択ＤＢ更新内容
        		sZWP0200ComService.updateSelectedLanguage(g6Info.getLnAcntUserCommon(), g6Info.getAcntNm(), acntLanguage);
                
                // 操作履歴情報にログイン操作を登録する(共通処理)
                if(pageNo == 0) {
//                	insertUserOperation(g6Info.getLnAcntUserCommon(), g6Info.getAcntNm());
            		HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
            		hUserOperationLogModel.setInsertId(resLoginScreen.getAcntID());			// アカウントID
            		hUserOperationLogModel.setInsertNm(resLoginScreen.getAcntNm());			// アカウント名
            		hUserOperationLogModel.setLnKeibi(null);								// 警備先論理番号
            		hUserOperationLogModel.setLnKbChiku(null);								// 警備先地区論理番号
            		hUserOperationLogModel.setDispId(ScreenID.SZWP0000.getValueForOperationLog());	// 操作画面ID
            		hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
            		commonService.entryUserOperation(hUserOperationLogModel, G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);
                }

                // 現在時刻を前回ログイン日時に登録する
                // 8-3.E)前回ログイン日時の更新
    			Date loginTs = DateTimeCommon.getCurrentDate();
                updateSts = sZWP0000Service.updateLastLoginDate(g6Info.getLnAcntUserCommon(), g6Info.getAcntNm(), loginTs);

                if (!updateSts) {
                    jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                            ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_LAST_LOGIN_DATE.getValue(),
                            acntLanguage);

                    // 処理終了
                    return jsonResult;
                }

                // 8-2.D)警備先名称の取得
                String keibiName = null;

                // 次期警備の警備先一覧を取得
                rKeibiDataModel = sZWP0000Service.getSecurityName(g6Info.getLnAcntUserCommon(), keibiName);
                
                // 警備先論理番号から契約先論理番号を取得
                if (rKeibiDataModel.size() > 0) {
                    lnKeiyk = sZWP0000Service.getLnKeiykFromLnKeibi(rKeibiDataModel.get(0).getLnKeibi());
                }

                // GHSからの警備先一覧を取得
                if (G6Constant.ACOUNT_NEXT_TERM_GUARD_GS.equals(accountKubun)) {
                	// GHS契約者アカウントの場合
                	rKeibiDataModel.addAll(sZWP0000GhsService.getSecurityNameKeiyk(kiyInfo.getLnAcntKeiyk(), keibiName));
                	
                } else if (G6Constant.ACOUNT_NEXT_TERM_GUARD_HS.equals(accountKubun)) {
                	// GHS利用者アカウントの場合
                	RKeibiDataModel dataModel = sZWP0000GhsService.getSecurityNameLiy(liyGSInfo.getLnAcntUser(), keibiName);
                	if (dataModel != null) {
                		rKeibiDataModel.add(dataModel);
                	}
                }
                
                //警備先名称、警備先論理番号の昇順で並び替え
                rKeibiDataModel = rKeibiDataModel.stream().sorted(Comparator.comparing(RKeibiDataModel::getKeibiName1)
                											.thenComparing(RKeibiDataModel::getLnKeibi)).collect(Collectors.toList());
                
                totalRow = rKeibiDataModel.size();
                
                // 警備先が取得できた場合、ページング編集を行う
    			if(totalRow > 0) {
	    			//calculate total of pages
	    			totalPage = G6Common.calculateTotalPages(totalRow, limit_row_num);
	    			
	    			//Verify pageNo can not bigger than totalPage
	    			if(pageNo >  totalPage) {
	    				jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
	    				return jsonResult;
	    			}
					// ページング表示するための開始/終了インデックスを計算
					offset = G6Common.calculateOffSet(pageNo, limit_row_num);
					int limit = G6Common.calculateLimit(offset, limit_row_num, rKeibiDataModel);

					// 表示用リストを抽出
	                List<RKeibiDataModel> dispList = rKeibiDataModel.subList(offset, limit);
	                		
                    // Set data to SO
                    resLoginScreen = this.mapDataToServiceObject(g6Info, ghsAcntNo);
                                        
                    // 返却用JSONを編集する
                    String loinTsStr = DateTimeCommon.dateToString(loginTs);
                    jsonResult = setLoginScreen(resLoginScreen, dispList, g6Info.getLnAcntUserCommon(),
                            g6Info.getAcntNm(), selectLang, G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM,
                            acntLanguage, totalPage, g6Info.getMlAddr(), lnKeiyk, loinTsStr, g6Info, kiyInfo, liyGSInfo);
	                
				} else {
					// 警備先名称が取得できなかった場合、エラーメッセージを返す
					jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_AVAILABLE_KEIBI.getValue(), acntLanguage);
				}

                // 処理終了
                return jsonResult;
            } else {
                // メール通知許可状態がメール通知不可の場合
                if (((G6CodeConsts.CD032.CONFIRMATION_WAITING).equals(g6Info.getMlSendSts()))
                        || ((G6CodeConsts.CD032.ERROR).equals(g6Info.getMlSendSts()))) {
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.LOGIN_WHEN_EMAIL_NOTI_DISABLED.getValue(), acntLanguage);

                    // メール通知許可状態がメール通知可の場合
                } else if ((G6CodeConsts.CD032.POSSIBLE).equals(g6Info.getMlSendSts())) {
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.LOGIN_NOT_ALLOWED.getValue(), acntLanguage);
                } else {
                    // spec does not mention
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.ERROR_MLSTS_CHKSTS_NOT_EXIST.getValue(), acntLanguage);
                }
                // 処理終了
                return jsonResult;
            }
        }
        return jsonResult;
    }

    /**
     * 「GS契約者」ありの場合
     * 
     * @param kiyInfo
     * @param resLoginScreen
     * @param rKeibiDataModel
     * @param g6Info
     * @param passwd
     * @param acntLanguage
     * @param pageNo 
     * @return
     * @throws ApplicationException
     */
    private String handleKiyLogin(SZWP0000Info g6Info, KiyLoginInfoModel kiyInfo, ResLoginScreen resLoginScreen,
            List<RKeibiDataModel> rKeibiDataModel, String passwd, String acntLanguage, int pageNo) throws ApplicationException, JWTCreationException {
    	String jsonResult = "";
        int loginFailureTimes = 0;
        int totalRow = 0;
		int totalPage = 0;
		int offset = 0;
        
        // パスワードロック状態の場合
        if (G6CodeConsts.CD020.STOP.equals(kiyInfo.getLoginSts())) {
            // 共通「エラーメッセージ取得処理」を呼び出し、エラーメッセージを取得する。
            jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                    ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.ERROR_USERID_CANNOTLOGIN.getValue(), acntLanguage);
            // 処理終了
            return jsonResult;
        }
        // 「GS契約者」のパスワードの一致判定をする
        // 一致しない
        if (!kiyInfo.getPasswd().equals(passwd)) {
            // ログイン失敗回数を取得する
            // 8-4.C)ログイン失敗回数の取得
            loginFailureTimes = sZWP0000GhsService.getKiyLoginFailureTimes(kiyInfo.getLnAcntKeiyk());

            // ログイン失敗回数をチェックする
            if (loginFailureTimes == -1) {
                jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                        ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_LOGIN_FAILURE_TIMES.getValue(), acntLanguage);

                // 処理終了
                return jsonResult;
            }
            // ログイン失敗回数上限値の値が0の場合 (CNT_LOGIN_ERR = 0 OR < 5)
            if ((loginFailureTimes == 0) || (loginFailureTimes < MAX_LOGIN_FAILURE_TIMES)) {
                // 契約者アカウントのログインエラー回数を更新する
                // 8-5.C)ログインエラー回数更新
                jsonResult = updateLoginFailureTimes(resLoginScreen, G6Constant.ACOUNT_NEXT_TERM_GUARD_GS,
                        kiyInfo.getLnAcntKeiyk(), kiyInfo.getUserNm(), loginFailureTimes, acntLanguage);
            } else if (loginFailureTimes >= MAX_LOGIN_FAILURE_TIMES) {
                // 契約者アカウントをパスワードロックする
                // 8-5.A)パスワードロック更新
                jsonResult = updatePasswordLock(resLoginScreen, G6Constant.ACOUNT_NEXT_TERM_GUARD_GS,
                        kiyInfo.getLnAcntKeiyk(), kiyInfo.getUserNm(), kiyInfo.getLoginSts(), acntLanguage);
            }
            // 処理終了
            return jsonResult;

            // 一致する
        } else {
            // ログイン許可状態が「ログイン可」でない場合
            // fix bug No.91
//            if (G6CodeConsts.CD020.POSSIBLE.equals(kiyInfo.getLoginSts())) {
            if (!G6CodeConsts.CD020.POSSIBLE.equals(kiyInfo.getLoginSts())) {
                // メール通知可能フラグがメール通知不可の場合
                if (((G6CodeConsts.CD032.CONFIRMATION_WAITING).equals(kiyInfo.getMlSendSts()))
                        || ((G6CodeConsts.CD032.ERROR).equals(kiyInfo.getMlSendSts()))) {
                    // 「メール通知不可の場合のログイン未許可」のエラーメッセージをプロパティファイルから取得する。
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.LOGIN_WHEN_EMAIL_NOTI_DISABLED.getValue(), acntLanguage);
                    return jsonResult;

                    // メール通知可能フラグがメール通知可の場合
                } else if ((G6CodeConsts.CD032.POSSIBLE).equals(kiyInfo.getMlSendSts())) {
                    // 「ログイン未許可」のエラーメッセージをプロパティファイルから取得する。
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.LOGIN_NOT_ALLOWED.getValue(), acntLanguage);
                    return jsonResult;
                }
            }
            // 契約者アカウントのログイン状態を更新する
            // 8-5.E)ログイン状態更新
			Date updateTs = DateTimeCommon.getCurrentDate();
            Boolean updateSts = sZWP0000GhsService.updateKiyLoginFailureTimes(kiyInfo.getLnAcntKeiyk(),
                    kiyInfo.getUserNm(), String.valueOf(loginFailureTimes), G6CodeConsts.CD020.POSSIBLE, updateTs);
            if (!updateSts) {
                jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                        ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_LOGIN_FAILURE_TIMES.getValue(),
                        acntLanguage);
                return jsonResult;
            }
            // アカウントが初回ログイン待ちの場合
            if (G6CodeConsts.CD031.TEMPORARY_REGISTRATION.equals(kiyInfo.getRgstSts())) {
//                // アカウントを本登録状態に更新する
//                // 8-5 G)本登録に更新
//                updateSts = sZWP0000GhsService.updateKiyPasswordLock(kiyInfo.getLnAcntKeiyk(), kiyInfo.getUserNm(),
//                        G6CodeConsts.CD020.POSSIBLE, G6CodeConsts.CD031.REGISTERED, G6CodeConsts.CD032.POSSIBLE);
//                if (!updateSts) {
//                    jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
//                            ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_LOGIN_FAILURE_TIMES.getValue(),
//                            acntLanguage);
//                    return jsonResult;
//                }
            	
                // 本登録メール配信依頼を登録する
                // 8-5. I)メール送信依頼の登録
                insertMail(G6CodeConsts.CD046.GS, kiyInfo.getLnAcntKeiyk(), kiyInfo.getUserNm(), G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION);
                
                // 初回ログイン未実施のメッセージを表示
                jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD, ErrorKey.UPDATE_REGIS_STATUS.getValue(), acntLanguage);
                return jsonResult;
            }
            
            //ログイン画面で指定した言語設定で更新する。
	       	String selectLang = acntLanguage;
        	// 言語選択ＤＢ更新内容
            sZWP0200ComService.updateSelectedLanguage(kiyInfo.getLnAcntKeiyk(), kiyInfo.getUserNm(), acntLanguage);

            // 操作履歴情報にログイン操作を登録する(共通処理)
            if(pageNo == 0) {
//            	insertUserOperation(kiyInfo.getLnAcntKeiyk(), kiyInfo.getUserNm());
        		HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
        		hUserOperationLogModel.setInsertId(resLoginScreen.getAcntID());			// アカウントID
        		hUserOperationLogModel.setInsertNm(resLoginScreen.getAcntNm());			// アカウント名
        		hUserOperationLogModel.setLnKeibi(null);								// 警備先論理番号
        		hUserOperationLogModel.setLnKbChiku(null);								// 警備先地区論理番号
        		hUserOperationLogModel.setDispId(ScreenID.SZWP0000.getValueForOperationLog());	// 操作画面ID
        		hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
        		commonService.entryUserOperation(hUserOperationLogModel, G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION);
            }
            // 警備先名称を取得する
            // 8-4.E)警備先名称の取得
            String keibiName = null;
            
            // GHS警備先を取得
         	rKeibiDataModel = sZWP0000GhsService.getSecurityNameKeiyk(kiyInfo.getLnAcntKeiyk(), keibiName);
         	totalRow = rKeibiDataModel.size();
         	
			if(totalRow > 0) {
				//calculate total of pages
				totalPage = G6Common.calculateTotalPages(totalRow, limit_row_num);
				//Verify pageNo can not bigger than totalPage
				if(pageNo >  totalPage) {
					jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_PAGE_NO_INVALID.getValue(), acntLanguage);
					
					// 処理終了
					return jsonResult;
				}
				// リストをページング表示するためのインデックスを計算
				offset = G6Common.calculateOffSet(pageNo, limit_row_num);
				int limit = G6Common.calculateLimit(offset, limit_row_num, rKeibiDataModel);

				// ページング表示するための開始/終了インデックスを計算
                List<RKeibiDataModel> dispList = rKeibiDataModel.subList(offset, limit);
                		
                // 返却用JSONを編集する
                String loinTsStr = DateTimeCommon.dateToString(updateTs);
                jsonResult = setLoginScreen(resLoginScreen, dispList, kiyInfo.getLnAcntKeiyk(),
                        kiyInfo.getUserNm(), selectLang, G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION, acntLanguage, totalPage, kiyInfo.getMlAddr(), kiyInfo.getLnKeiyk(), loinTsStr, g6Info, kiyInfo, null);
                
                
			} else {
				// 警備先名称が取得できなかった場合
				jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_AVAILABLE_KEIBI.getValue(), acntLanguage);
			}
        }
        return jsonResult;
    }

    /**
     * 「GS利用者」ありの場合
     * 
     * @param liyGSInfo
     * @param resLoginScreen
     * @param rKeibiDataModel
     * @param g6Info
     * @param passwd
     * @param acntLanguage
     * @param pageNo 
     * @return
     * @throws ApplicationException
     */
    private String handleLiyGSLogin(SZWP0000Info g6Info, LiyGSLoginInfoModel liyGSInfo, ResLoginScreen resLoginScreen,
            List<RKeibiDataModel> rKeibiDataModelList, String passwd, String acntLanguage, int pageNo) throws ApplicationException, JWTCreationException  {
    	String jsonResult = "";
        String lnKeiyk = "";
		int totalPage = 0;
        
        // パスワードロック状態の場合
        // 共通「エラーメッセージ取得処理」を呼び出し、エラーメッセージを取得する。
        int loginFailureTimes = 0;
        // パスワードロック状態の場合
        if (G6CodeConsts.CD020.STOP.equals(liyGSInfo.getLoginSts())) {
            // 共通「エラーメッセージ取得処理」を呼び出し、エラーメッセージを取得する。
            jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                    ErrorKey.ERROR_USERID_CANNOTLOGIN.getValue(), ErrorKey.ERROR_USERID_CANNOTLOGIN.getValue(), acntLanguage);
            // 処理終了
            return jsonResult;
        }
        // 「GS利用者」パスワードの一致判定をする
        // 一致しない
        if (!liyGSInfo.getPasswd().equals(passwd)) {
            // ログイン失敗回数を取得する
            // 8-4.D)ログイン失敗回数の取得
            loginFailureTimes = sZWP0000GhsService.getLiyGSLoginFailureTimes(liyGSInfo.getLnAcntUser());
            // ログイン失敗回数をチェックする
            if (loginFailureTimes == -1) {
                jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                        ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_LOGIN_FAILURE_TIMES.getValue(), acntLanguage);
                // 処理終了
                return jsonResult;
            }
            // ログイン失敗回数上限値の値が0の場合 (CNT_LOGIN_ERR = 0 OR < 5)
            if ((loginFailureTimes == 0) || (loginFailureTimes < MAX_LOGIN_FAILURE_TIMES)) {
                // 契約者アカウントのログインエラー回数を更新する
                // 8-5.F)ログインエラー回数更新
                jsonResult = updateLoginFailureTimes(resLoginScreen, G6Constant.ACOUNT_NEXT_TERM_GUARD_HS,
                        liyGSInfo.getLnAcntUser(), liyGSInfo.getUserNm(), loginFailureTimes, acntLanguage);
            } else if (loginFailureTimes >= MAX_LOGIN_FAILURE_TIMES) {
                // 契約者アカウントをパスワードロックする
                // 8-5.B)パスワードロック更新
                jsonResult = updatePasswordLock(resLoginScreen, G6Constant.ACOUNT_NEXT_TERM_GUARD_HS,
                        liyGSInfo.getLnAcntUser(), liyGSInfo.getUserNm(), liyGSInfo.getLoginSts(), acntLanguage);
            }
            // 処理終了
            return jsonResult;
            // 一致する
        } else {
            // ログイン許可状態が「ログイン可」でない場合
            // fix bug No.91
//            if (G6CodeConsts.CD020.POSSIBLE.equals(liyGSInfo.getLoginSts())) {
            if (!G6CodeConsts.CD020.POSSIBLE.equals(liyGSInfo.getLoginSts())) {
                // メール通知可能フラグがメール通知不可の場合
                if (((G6CodeConsts.CD032.CONFIRMATION_WAITING).equals(liyGSInfo.getMlSendSts()))
                        || ((G6CodeConsts.CD032.ERROR).equals(liyGSInfo.getMlSendSts()))) {
                    // 「メール通知不可の場合のログイン未許可」のエラーメッセージをプロパティファイルから取得する。
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.LOGIN_WHEN_EMAIL_NOTI_DISABLED.getValue(), acntLanguage);
                    return jsonResult;

                    // メール通知可能フラグがメール通知可の場合
                } else if ((G6CodeConsts.CD032.POSSIBLE).equals(liyGSInfo.getMlSendSts())) {
                    // 「ログイン未許可」のエラーメッセージをプロパティファイルから取得する。
                    jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                            ErrorKey.LOGIN_NOT_ALLOWED.getValue(), acntLanguage);
                    return jsonResult;
                }
            }
            // 契約者アカウントのログイン状態を更新する
            // 8-5.F)ログイン状態更新
			Date updateTs = DateTimeCommon.getCurrentDate();
            Boolean updateSts = sZWP0000GhsService.updateLiyGSLoginFailureTimes(liyGSInfo.getLnAcntUser(),
                    liyGSInfo.getUserNm(), String.valueOf(loginFailureTimes), G6CodeConsts.CD020.POSSIBLE, updateTs);
            if (!updateSts) {
                jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                        ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_LOGIN_FAILURE_TIMES.getValue(),
                        acntLanguage);
                return jsonResult;
            }
            // アカウントが初回ログイン待ちの場合
            if (G6CodeConsts.CD031.TEMPORARY_REGISTRATION.equals(liyGSInfo.getRgstSts())) {
//                // アカウントを本登録状態に更新する
//                // 8-5 H)本登録に更新
//                updateSts = sZWP0000GhsService.updateLiyGSPasswordLock(liyGSInfo.getLnAcntUser(),
//                        liyGSInfo.getUserNm(), G6CodeConsts.CD020.POSSIBLE, G6CodeConsts.CD031.REGISTERED,
//                        G6CodeConsts.CD032.POSSIBLE);
//                if (!updateSts) {
//                    jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
//                            ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_LOGIN_FAILURE_TIMES.getValue(),
//                            acntLanguage);
//                    return jsonResult;
//                }
            	
                // 本登録メール配信依頼を登録する
                // 8-5. I)メール送信依頼の登録
                insertMail(liyGSInfo.getGsHsType(), liyGSInfo.getLnAcntUser(), liyGSInfo.getUserNm(), G6CodeConsts.CD027.GHS_THE_USER);
                
                // 初回ログイン未実施のメッセージを表示
                jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD, ErrorKey.UPDATE_REGIS_STATUS.getValue(), acntLanguage);
                return jsonResult;
            }
            
            //ログイン画面で指定した言語設定で更新する。
	       	String selectLang = acntLanguage;
        	// 言語選択ＤＢ更新内容
            sZWP0200ComService.updateSelectedLanguage(liyGSInfo.getLnAcntKeiyk(), liyGSInfo.getUserNm(), acntLanguage);

            // 操作履歴情報にログイン操作を登録する(共通処理)
            if(pageNo == 0) {
//            	insertUserOperation(liyGSInfo.getLnAcntUser(), liyGSInfo.getUserNm());
        		HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
        		hUserOperationLogModel.setInsertId(liyGSInfo.getLnAcntUser());	// アカウントID
        		hUserOperationLogModel.setInsertNm(liyGSInfo.getAcntNm());														// アカウント名
        		hUserOperationLogModel.setLnKeibi(null);	// 警備先論理番号
        		hUserOperationLogModel.setLnKbChiku(null);														// 警備先地区論理番号
        		hUserOperationLogModel.setDispId(ScreenID.SZWP0000.getValueForOperationLog());					// 操作画面ID
        		hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
        		commonService.entryUserOperation(hUserOperationLogModel, G6CodeConsts.CD027.GHS_THE_USER);
            }
            // 警備先名称を取得する
            // 8-4.E)警備先名称の取得
            String keibiName = null;

            // GHS警備先を取得
            RKeibiDataModel rKeibiDataModel = sZWP0000GhsService.getSecurityNameLiy(liyGSInfo.getLnAcntUser(), keibiName);
			if(rKeibiDataModel != null) {				
				rKeibiDataModelList.add(rKeibiDataModel);
				
				// 警備先論理番号から契約先論理番号を取得
				lnKeiyk = sZWP0000GhsService.getLnKeiykFromLnKeibi(rKeibiDataModel.getLnKeibi());
				
				// GHS利用者の場合はページ数を１とする。（警備先一覧を経由しないため）
				totalPage = 1;
				
				// 返却用JSONを編集する
                String loinTsStr = DateTimeCommon.dateToString(updateTs);
                jsonResult = setLoginScreen(resLoginScreen, rKeibiDataModelList, liyGSInfo.getLnAcntUser(),
                        liyGSInfo.getUserNm(), selectLang, G6CodeConsts.CD027.GHS_THE_USER,
                        acntLanguage, totalPage, liyGSInfo.getMlAddr(), lnKeiyk, loinTsStr,
                        g6Info, null, liyGSInfo);
                
			} else {
				// 警備先名称が取得できなかった場合
				jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_AVAILABLE_KEIBI.getValue(), acntLanguage);
			}
        }
        return jsonResult;
    }

    /**
     * ログインエラー回数更新
     * 
     * @param resLoginScreen
     * @param g6Info
     * @param loginFailureTimes
     * @param acntLanguage
     * @return
     * @throws ApplicationException
     */
    private String updateLoginFailureTimes(ResLoginScreen resLoginScreen, String accountKubun, String lnAcnt, String UserNm,
            int loginFailureTimes, String acntLanguage) throws ApplicationException {
        String jsonResult = "";
		Date updateTs = DateTimeCommon.getCurrentDate();

        Boolean updateSts = false;
        if (G6Constant.ACOUNT_NEXT_TERM_GUARD_HS.equals(accountKubun)) {
            // 「次期警備」＋「GS利用者」(liyGSInfo)
            updateSts = sZWP0000GhsService.updateLiyGSLoginFailureTimes(lnAcnt, UserNm,
                    String.valueOf(loginFailureTimes + 1), null, updateTs);
        } else if (G6Constant.ACOUNT_NEXT_TERM_GUARD_GS.equals(accountKubun)) {
            // 「次期警備」＋「GS契約者」(kiyInfo)
            // 契約者アカウントのログインエラー回数を更新する
            // 8-5.C)ログインエラー回数更新
            updateSts = sZWP0000GhsService.updateKiyLoginFailureTimes(lnAcnt, UserNm,
                    String.valueOf(loginFailureTimes + 1), null, updateTs);
        } else {
            // 8-3.A)ログインエラー回数更新
            updateSts = sZWP0000ComService.updateLoginFailureTimes(lnAcnt, UserNm,
                    String.valueOf(loginFailureTimes + 1));
        }
        if (!updateSts) {
            jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                    ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_LOGIN_FAILURE_TIMES.getValue(), acntLanguage);
        } else {
            // 「パスワード不正」のエラーメッセージをプロパティファイルから取得する。
            jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                    ErrorKey.PASSWORD_INVALID.getValue(), acntLanguage);
        }
        return jsonResult;
    }

    /**
     * ログイン失敗回数がログイン失敗回数上限値に達した場合
     * 
     * @param resLoginScreen
     * @param type
     * @param lnAcnt
     * @param UserNm
     * @param loginSts
     * @param acntLanguage
     * @return
     * @throws ApplicationException
     */
    private String updatePasswordLock(ResLoginScreen resLoginScreen, String accountKubun, String lnAcnt, String UserNm,
            String loginSts, String acntLanguage) throws ApplicationException {
        String jsonResult = "";
        Boolean updateSts = false;

        if (G6Constant.ACOUNT_NEXT_TERM_GUARD_HS.equals(accountKubun)) {
            // 「次期警備」＋「GS利用者」(liyGSInfo)
            // 8-5.B)パスワードロック更新
            updateSts = sZWP0000GhsService.updateLiyGSPasswordLock(lnAcnt, UserNm, loginSts, null, null);
        } else if (G6Constant.ACOUNT_NEXT_TERM_GUARD_GS.equals(accountKubun)) {
            // 契約者アカウントをパスワードロックする
            // 8-5.A)パスワードロック更新
            updateSts = sZWP0000GhsService.updateKiyPasswordLock(lnAcnt, UserNm, loginSts, null, null);
        } else {
            // ログイン失敗回数がログイン失敗回数上限値に達した場合
            // 8-3.B)確認状態更新
            updateSts = sZWP0000Service.updateConfirmStatus(lnAcnt, UserNm);
        }

        if (!updateSts) {
            jsonResult = G6Common.messageUpdateLogHandler(resLoginScreen, G6Constant.FAIL_HTML_CD,
                    ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_CONFIRM_STATUS.getValue(), acntLanguage);
        } else {
            // 「パスワードロック」のエラーメッセージをプロパティファイルから取得する。
            jsonResult = G6Common.messageHandler(resLoginScreen, G6Constant.FAIL_POPUP_CD,
                    ErrorKey.PASSWORD_LOCKED.getValue(), acntLanguage);
        }
        return jsonResult;
    }

    /**
     * 本登録メール配信依頼を登録する
     * 
     * @param gsHsType
     * @param lnAcnt
     * @param UserNm
     * @throws ApplicationException
     */
    private void insertMail(String gsHsType, String lnAcnt, String UserNm, String acntType) throws ApplicationException {
        // 8-5. I)メール送信依頼の登録
        // String seqNum = commonGhsService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_AC_ML_TRIG);
        final String seqNum = commonGhsService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_AC_ML_TRIG);
        
        WQueAcMlTrigModel wQueAcMlTrigModel = new WQueAcMlTrigModel();
        // LN_アカウント関連メール配信トリガ論理番号 = シーケンス値
        wQueAcMlTrigModel.setLnQueAcMlTrig(seqNum);
        // アカウント種別 = 契約先：2(契約先アカウント)
        wQueAcMlTrigModel.setAcntType(acntType);
        // アカウント情報取得時のLN_アカウント論理番号
        wQueAcMlTrigModel.setLnAcnt(lnAcnt);
        // メール種別 = GSの場合 62：ユーザー本登録(GS)
        // GSHS区分
        if (G6CodeConsts.CD046.GS.equals(gsHsType)) {
            // メール種別 = GSの場合 62：ユーザー本登録(GS)
            wQueAcMlTrigModel.setMlKind(G6CodeConsts.CD188.THE_USER_REGISTRATION_GS);
        } else {
            // メール種別 = HSの場合 66：ユーザー本登録(HS)
            wQueAcMlTrigModel.setMlKind(G6CodeConsts.CD188.THE_USER_REGISTRATION_HS);
        }
        // LN_処理対象論理番号 = null
        wQueAcMlTrigModel.setLnSendTgt(null);
        // 状態 = 0(未処理)
        wQueAcMlTrigModel.setSts(G6CodeConsts.CD189.UNPROCESSED);
        // アカウント情報取得時の社員名
        wQueAcMlTrigModel.setInsertNm(UserNm);
        // システム日時
        wQueAcMlTrigModel.setInsertTs(DateTimeCommon.getCurrentDate());
        if (sZWP0000GhsService != null) {
            sZWP0000GhsService.insertMailTrig(wQueAcMlTrigModel);
        }
    }

//    /**
//     * 操作履歴情報にログイン操作を登録する(共通処理)
//     * 
//     * @param lnAcnt
//     * @throws ApplicationException
//     */
//    private void insertUserOperation(String lnAcnt, String acntNm) throws ApplicationException {
//        // 操作履歴情報にログイン操作を登録する(共通処理)
//        final HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//        final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//        //hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//        hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//        hUserOperationLogModel.setDispId(ScreenID.SZWP0000.getSlashValue());
//        hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//        if (commonService != null) {
//            commonService.entryUserOperation(hUserOperationLogModel, lnAcnt, acntNm, DateTimeCommon.getCurrentDate());
//        }
//    }
    
    /**
     * set data to reponsed client
     * 
     * @param resLoginScreen
     * @param rKeibiDataModel
     * @param lnAcnt
     * @param userNm
     * @param selectLang
     * @param typeDestination
     * @param acntLanguage
     * @param totalPage
     * @param mlAddr 
     * @return
     * @throws ApplicationException
     */
    private String setLoginScreen(ResLoginScreen resLoginScreen, List<RKeibiDataModel> rKeibiDataModel, String lnAcnt,
            String userNm, String selectLang, String typeDestination, String acntLanguage, int totalPage, String mlAddr, String lnKeiyk, String loginTs,
            SZWP0000Info g6Info, KiyLoginInfoModel kiyInfo, LiyGSLoginInfoModel liyGSInfo) throws ApplicationException, JWTCreationException {
    	String jsonResult = "";
        final ResLoginScreen res = resLoginScreen;
        res.setErrorCode(G6Constant.SUCCESS_CD);
        res.setSelectLang(selectLang);
        res.setPcURL(pcURL);
        res.setShopURL(shopURL);
        res.setMaxHistoryShowDays(MAX_HISTORY_DAYS);
        res.setSmartphoneServerHost(smartphoneServerHost);
        res.setSmartphoneServerPort(smartphoneServerPort);
        res.setrKeibiItem(rKeibiDataModel);
        if (G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM.equals(typeDestination)) {
            resLoginScreen.setAcntSbt(typeDestination);
        } else {
            res.setAcntNm(userNm);
            res.setLastLoginTs(DateTimeCommon.getCurrentDateTime());
            res.setAcntUserKbn(G6Constant.USER_KBN_1);
            res.setAcntSbt(typeDestination);
        }
        res.setLnKeiyk(lnKeiyk);
        res.setMlAddr(mlAddr);
        res.setTotalPage(String.valueOf(totalPage));
        
        // アカウント情報の変更有無をチェックするため、最終更新日時を取得
        String lastModifyAcntTs = commonService.getLastModifyAcntTs(lnAcnt, typeDestination);
        //デコード済acntIDを設定したJWT認証トークンを付与
        String lnAcntUserCommon = (g6Info==null)? null : g6Info.getLnAcntUserCommon();
        String lnAcntKeiyk = (kiyInfo==null)? null : kiyInfo.getLnAcntKeiyk();
        String lnAcntUser = (liyGSInfo==null)? null : liyGSInfo.getLnAcntUser();
        
        res.setAcntID(jwtverifier.createToken(lnAcnt, loginTs, lastModifyAcntTs, lnAcntUserCommon, lnAcntKeiyk, lnAcntUser));
        
        jsonResult = G6Common.parseJSON(res, acntLanguage);
        
        return jsonResult;
    }

    /**
     * set data mapping to services
     * 
     * @param szwp0000Info
     * @return
     */
    private ResLoginScreen mapDataToServiceObject(SZWP0000Info szwp0000Info, String ghsAcntNo) {
        final ResLoginScreen resLoginScreen = new ResLoginScreen();

        //resLoginScreen.setAcntID(szwp0000Info.getLnAcntUserCommon());
        resLoginScreen.setAcntNm(szwp0000Info.getAcntNm());
        resLoginScreen.setLastLoginTs(szwp0000Info.getLastLoginTs());
        resLoginScreen.setAcntUserKbn(szwp0000Info.getAcntUserKbn());
        resLoginScreen.setGhsAcntNo(ghsAcntNo);
        
        return resLoginScreen;
    }
}
