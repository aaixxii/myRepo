package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetChikuList implements ErrorHandler {

	private String errorCode;			// エラーコード
	private String errorMsg;			// エラーメッセージ
	private List<RKbChikuNmDataModel> rKbChikuNmItem;
	private List<CameraDataModel> cameraItem;
	private String acntID;

	public ResGetChikuList() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.rKbChikuNmItem = new ArrayList<RKbChikuNmDataModel>();
		this.cameraItem = new ArrayList<CameraDataModel>();
		this.acntID = "";
	}

	public ResGetChikuList(String errorCode, String errorMsg, List<RKbChikuNmDataModel> rKbChikuNmItem,
			List<CameraDataModel> cameraItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.rKbChikuNmItem = rKbChikuNmItem;
		this.cameraItem = cameraItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<RKbChikuNmDataModel> getrKbChikuNmItem() {
		return rKbChikuNmItem;
	}

	public void setrKbChikuNmItem(List<RKbChikuNmDataModel> rKbChikuNmItem) {
		this.rKbChikuNmItem = rKbChikuNmItem;
	}

	public List<CameraDataModel> getCameraItem() {
		return cameraItem;
	}

	public void setCameraItem(List<CameraDataModel> cameraItem) {
		this.cameraItem = cameraItem;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
