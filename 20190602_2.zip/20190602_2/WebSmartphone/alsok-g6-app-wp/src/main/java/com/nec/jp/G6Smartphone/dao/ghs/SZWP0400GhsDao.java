package com.nec.jp.G6Smartphone.dao.ghs;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.RKbChikuDataModel;


@Repository
public class SZWP0400GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	public String getFlgKbSetDispByAcntId(String acntID) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(rAcntUserAuth.FLG_KB_SET_DISP, '') as flgKbSetDisp");
		strBuilder.append(" FROM	R_ACNT_USER_AUTH rAcntUserAuth");
		strBuilder.append(" WHERE	rAcntUserAuth.LN_ACNT_USER = :acntID");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("acntID", acntID);
		query.setMaxResults(1);

		return query.getSingleResult().toString();
	}

	public String selectGshsFlgInfo(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(rKeibi.FLG_GSHS, '') as flgGshs");
		strBuilder.append(" FROM	R_KEIBI rKeibi");
		strBuilder.append("			INNER JOIN R_DENKEI_MNG rDenkeiMng ON rKeibi.LN_KEIBI = rDenkeiMng.LN_KEIBI");
		strBuilder.append(" WHERE	rKeibi.LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND rDenkeiMng.FLG_LAST = '1'");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setMaxResults(1);
		
		return  query.getSingleResult().toString();
	}

	@SuppressWarnings("unchecked")
	public List<RKbChikuDataModel> searchGhsListInfo(String lnKeibi, List<String> subAddr) {
		StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT");
        strBuilder.append("    R1.LN_KB_CHIKU as lnKbChiku,");
        strBuilder.append("   	IFNULL(R1.SUB_ADDR, '') as subAddr,");
        strBuilder.append("   	IFNULL(R1.SD_KOBETU_NM, '') as sdKobetuNm,");
        strBuilder.append("  	IFNULL(R1.CHIKU, '') as chiku,");
        strBuilder.append("   	IFNULL(R2.KB_STS_N0, '') as n0f0Flg,");
        strBuilder.append("  	IFNULL(R2.EMPTY_STS, '') as empStsFlg");
        strBuilder.append(" FROM");
        strBuilder.append("    R_KB_CHIKU R1 INNER JOIN C_KB_CHIKU_STS R2 ON R1.LN_KB_CHIKU = R2.LN_KB_CHIKU");
        strBuilder.append(" WHERE");
        strBuilder.append(" R1.ENTRY_STS = '1'");
		strBuilder.append(" AND R1.LN_KEIBI = :lnKeibi");
		if(subAddr != null && !subAddr.isEmpty()) {
			strBuilder.append(" AND R1.SUB_ADDR IN :subAddr");
		}
		
        Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKbChikuDataGHS0400GhsModelResult");
        query.setParameter("lnKeibi", lnKeibi);
        if(subAddr != null && subAddr.size() > 0) {
			query.setParameter("subAddr", subAddr);
		}
        
        return (List<RKbChikuDataModel>) query.getResultList();
	}

}
