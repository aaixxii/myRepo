package com.nec.jp.G6Smartphone.service.ghs;

import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.jp.G6Smartphone.dao.ghs.CommonGhsDao;
import com.nec.jp.G6Smartphone.model.EQueCtrlModel;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;

@Service
public class CommonGhsService {

	@Autowired
	private CommonGhsDao commonDao;

//	public String getCmdSeq(String seqId) throws ApplicationException {
//		String result = G6Constant.INIT_CMD_SEQ_NUM;
//		try {
//			result = getCmdSeq(seqId, 12);
//		} catch (NoResultException noResultE) {
//			return G6Constant.INIT_CMD_SEQ_NUM;
//		} catch (Exception e) {
//			// DBアクセス例外
//			// 処理終了
//			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, 
//			        ErrorKey.EXCEPTION_DB_ACCESS.getValue(), 
//			        G6Common.printStackTraceToString(e));
//		}
//		return result;
//	}

	 /**
     * 指定SEQUENSE_IDの論理番号を取得する<br>
     *
     * @param sequenceId シーケンスID
     * @return 論理番号
     * @throws SQLException
     */
//    public String getLn(String sequenceId) throws ApplicationException {
//        try {
//            long sequenceNo = Long.parseLong(commonDao.getNextCmdSeqNum(sequenceId));
//            DecimalFormat df = new DecimalFormat();
//            SimpleDateFormat sdf = new SimpleDateFormat("");
//            java.util.Date dt = new java.util.Date();
//            sdf.setLenient(false);
//            sdf.applyPattern("yyyyMMddHHmmssSSS");
//            if (G6Constant.CD_SEQUENCE.LN_QUE_KB_SIG_SEQ_NAME.equals(sequenceId)) {
//                // 警備信号の場合のみシーケンスは二桁とし、末尾は0として返却
//                df.applyPattern("00");
//                return sdf.format(dt) + df.format(sequenceNo) + "0";
//            }
//            if (G6Constant.CD_SEQUENCE.LN_QUE_MST_SEND_SEQ_NAME.equals(sequenceId)
//                    || G6Constant.CD_SEQUENCE.LN_SYNC_SALE_SYS.equals(sequenceId)) {
//                // マスタ配信キューのみシーケンスは六桁とし、末尾は0として返却
//                // 通常はDBトリガにて設定するが、ミリ秒が取得できないためシーケンス番号で対応
//                sdf.applyPattern("yyyyMMddHHmmss");
//                df.applyPattern("000000");
//                return sdf.format(dt) + df.format(sequenceNo);
//            }
//            if (G6Constant.CD_SEQUENCE.LN_KB_CHIKU_SEQ_NAME.equals(sequenceId)
//                    || G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_SEQ_NAME.equals(sequenceId)
//                    || G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_DOKYO_SEQ_NAME.equals(sequenceId)
//                    || G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_KYUKYU_SEQ_NAME.equals(sequenceId)) {
//                // 論理番号4桁対象の場合
//                df.applyPattern("0000");
//                return sdf.format(dt).substring(0, 16) + df.format(sequenceNo);
//            }
//    
//            df.applyPattern("000");
//            return sdf.format(dt) + df.format(sequenceNo);
//        } catch (NoResultException noResultE) {
//            return G6Constant.INIT_CMD_SEQ_NUM;
//        } catch (Exception e) {
//            // DBアクセス例外
//            // 処理終了
//            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, 
//                    ErrorKey.EXCEPTION_DB_ACCESS.getValue(), 
//                    G6Common.printStackTraceToString(e));
//        }
//    }
    
//	private String getCmdSeq(String seqId, int len) {
//	    final String maxSeqNum = commonDao.getNextCmdSeqNum(seqId);
//	    final long sequenceNo = Long.parseLong(maxSeqNum);
//	    final DecimalFormat df = new DecimalFormat();
//	    final StringBuilder sb = new StringBuilder();
//        for (int i = 0; i < len; i++) {
//            sb.append("0");
//        }
//        df.applyPattern(sb.toString());
//        return df.format(sequenceNo);
//	}
	
	// @Transactional("transactionManagerGhs")
	public void saveEQueCtrlModel(Map<String, String> mapSoap, Date dateTime, String seqNo) throws ApplicationException {
		try {
			// 制御キューに情報を登録する
			// init data 警備状態設定要求
		    final EQueCtrlModel eQueCtrlModel = new EQueCtrlModel();
//			final String seqNo = getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
			eQueCtrlModel.setLnQueCtrl(seqNo);
			eQueCtrlModel.setHostNm(mapSoap.get(G6Constant.MYCD003.HOSTNM));
			eQueCtrlModel.setDenkei(mapSoap.get(G6Constant.MYCD003.DENKEINO));
			eQueCtrlModel.setGouki(mapSoap.get(G6Constant.MYCD003.GOUKINO));
			eQueCtrlModel.setSerialNum(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID));
			eQueCtrlModel.setConnDevNum(mapSoap.get(G6Constant.MYCD003.CONNDEVNUM));
			eQueCtrlModel.setDevNum(mapSoap.get(G6Constant.MYCD003.DEVNUM));
			eQueCtrlModel.setSubAddr(mapSoap.get(G6Constant.MYCD003.SUBADDRESS));
			eQueCtrlModel.setPriority(mapSoap.get(G6Constant.MYCD003.PRIORITY));
			eQueCtrlModel.setCmdSeqNum(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM));
			eQueCtrlModel.setProcessNum(mapSoap.get(G6Constant.MYCD003.PROCESSNUM));
			eQueCtrlModel.setCmdCd(mapSoap.get(G6Constant.MYCD003.CMDCD));
			eQueCtrlModel.setExecCmd(mapSoap.get(G6Constant.MYCD003.EXECCMD));
			eQueCtrlModel.setSoapMsg(mapSoap.get(G6Constant.MYCD003.SOAPMSG));
			eQueCtrlModel.setEnqTs(dateTime);
			eQueCtrlModel.setDeqAblTm(dateTime);
			eQueCtrlModel.setSts(mapSoap.get(G6Constant.MYCD003.STS));
			eQueCtrlModel.setIdInsert(mapSoap.get(RequestParam.acntID.getValue()));
			eQueCtrlModel.setInsertNm(mapSoap.get(RequestParam.acntNm.getValue()));
			eQueCtrlModel.setInsertTs(dateTime);
			eQueCtrlModel.setIdUpdate(mapSoap.get(RequestParam.acntID.getValue()));
			eQueCtrlModel.setUpdateNm(mapSoap.get(RequestParam.acntNm.getValue()));
			eQueCtrlModel.setUpdateTs(dateTime);

			commonDao.saveEQueCtrlModel(eQueCtrlModel);

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	/**
	 * コマンドシーケンス番号を返す
	 * @return
	 * @throws ApplicationException
	 */
    @Transactional("transactionManagerGhs")
	public String getCmdSeq() throws ApplicationException {
		return this.getSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM, 12);
	}
	
	/**
	 * 指定したIDのシーケンス番号を返す<br>
	 * （lenで指定した桁数で先頭０埋め編集を行う）
	 * @param sequenceId
	 * @param len
	 * @return
	 * @throws ApplicationException
	 */
	private String getSeq(String sequenceId, int len) throws ApplicationException {
		
		// DBよりシーケンスを採番
		long sequence = this.getSeqFromDb(sequenceId);
		
		// 0パディング編集
		DecimalFormat df = new DecimalFormat();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < len; i++) {
			sb.append("0");
		}
		df.applyPattern(sb.toString());
		
		// 結果を返す
		return df.format(sequence);
	}

    /**
     * 指定したIDの論理番号を返す
     *
     * @param sequenceId シーケンスID
     * @return 論理番号
     */
    @Transactional("transactionManagerGhs")
    public String getLn(String sequenceId) throws ApplicationException {
        long sequenceNo = this.getSeqFromDb(sequenceId);
        DecimalFormat df = new DecimalFormat();
        SimpleDateFormat sdf = new SimpleDateFormat("");
        java.util.Date dt = new java.util.Date();
        sdf.setLenient(false);
        sdf.applyPattern("yyyyMMddHHmmssSSS");
        if (sequenceId.equals(G6Constant.CD_SEQUENCE.LN_QUE_KB_SIG_SEQ_NAME)) {
            // 警備信号の場合のみシーケンスは二桁とし、末尾は0として返却
            df.applyPattern("00");
            return sdf.format(dt) + df.format(sequenceNo) + "0";
        }
        if (sequenceId.equals(G6Constant.CD_SEQUENCE.LN_QUE_MST_SEND_SEQ_NAME)
                || sequenceId.equals(G6Constant.CD_SEQUENCE.LN_SYNC_SALE_SYS)) {
            // マスタ配信キューのみシーケンスは六桁とし、末尾は0として返却
            // 通常はDBトリガにて設定するが、ミリ秒が取得できないためシーケンス番号で対応
            sdf.applyPattern("yyyyMMddHHmmss");
            df.applyPattern("000000");
            return sdf.format(dt) + df.format(sequenceNo);
        }
        if (sequenceId.equals(G6Constant.CD_SEQUENCE.LN_KB_CHIKU_SEQ_NAME)
                || sequenceId.equals(G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_SEQ_NAME)
                || sequenceId.equals(G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_DOKYO_SEQ_NAME)
                || sequenceId.equals(G6Constant.CD_SEQUENCE.LN_KNRN_MEIBO_KYUKYU_SEQ_NAME)) {
            // 論理番号4桁対象の場合
            df.applyPattern("0000");
            return sdf.format(dt).substring(0, 16) + df.format(sequenceNo);
        }

        df.applyPattern("000");
        return sdf.format(dt) + df.format(sequenceNo);
    }
    
	/**
	 * 指定したIDのシーケンスを採番する
	 * @param sequenceId
	 * @return
	 * @throws ApplicationException
	 */
	private long getSeqFromDb(String sequenceId) throws ApplicationException {
    
		// DBよりシーケンスを採番
		try {
			return commonDao.getSeq(sequenceId);
			
		}  catch(Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
        }
	}
	
	public String getAcntTypeFromAcntUser(String lnAcntUser)throws ApplicationException {
		try {
			return commonDao.getAcntTypeFromAcntUser(lnAcntUser);
		} catch (NoResultException noResultE) {
			return null;
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
