package com.nec.jp.G6Smartphone.SO;

public class KiyLoginInfoModel extends SZWP0000Info{
	
	private String lnAcntKeiyk; //LN_契約先アカウント論理番号
	private String lnKeiyk; //LN_契約先論理番号
	private String mlAddr; //メールアドレス
	private String passwd; //パスワード
	private String acntType; //アカウント区分
	private String userNm; //ユーザー氏名
	private String loginSts; //ログイン許可状態
	private String rgstSts; //登録状態
	private String mlSendSts; //メール通知許可状態
	private String updateTs; //更新日時
	private String acntSbt; //アカウント種別
	public KiyLoginInfoModel() {
		this.lnAcntKeiyk = "";
		this.lnKeiyk = "";
		this.mlAddr = "";
		this.passwd = "";
		this.acntType = "";
		this.userNm = "";
		this.loginSts = "";
		this.rgstSts = "";
		this.mlSendSts = "";
		this.updateTs = "";
		this.acntSbt = "";
	}
	public KiyLoginInfoModel(String lnAcntKeiyk, String lnKeiyk, String mlAddr, String passwd, String acntType,
			String userNm, String loginSts, String rgstSts, String mlSendSts, String updateTs, String acntSbt) {
		this.lnAcntKeiyk = lnAcntKeiyk;
		this.lnKeiyk = lnKeiyk;
		this.mlAddr = mlAddr;
		this.passwd = passwd;
		this.acntType = acntType;
		this.userNm = userNm;
		this.loginSts = loginSts;
		this.rgstSts = rgstSts;
		this.mlSendSts = mlSendSts;
		this.updateTs = updateTs;
		this.acntSbt = acntSbt;
	}
	public String getLnAcntKeiyk() {
		return lnAcntKeiyk;
	}
	public void setLnAcntKeiyk(String lnAcntKeiyk) {
		this.lnAcntKeiyk = lnAcntKeiyk;
	}
	public String getLnKeiyk() {
		return lnKeiyk;
	}
	public void setLnKeiyk(String lnKeiyk) {
		this.lnKeiyk = lnKeiyk;
	}
	public String getMlAddr() {
		return mlAddr;
	}
	public void setMlAddr(String mlAddr) {
		this.mlAddr = mlAddr;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getAcntType() {
		return acntType;
	}
	public void setAcntType(String acntType) {
		this.acntType = acntType;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getLoginSts() {
		return loginSts;
	}
	public void setLoginSts(String loginSts) {
		this.loginSts = loginSts;
	}
	public String getRgstSts() {
		return rgstSts;
	}
	public void setRgstSts(String rgstSts) {
		this.rgstSts = rgstSts;
	}
	public String getMlSendSts() {
		return mlSendSts;
	}
	public void setMlSendSts(String mlSendSts) {
		this.mlSendSts = mlSendSts;
	}
	public String getUpdateTs() {
		return updateTs;
	}
	public void setUpdateTs(String updateTs) {
		this.updateTs = updateTs;
	}
	public String getAcntSbt() {
		return acntSbt;
	}
	public void setAcntSbt(String acntSbt) {
		this.acntSbt = acntSbt;
	}

}
