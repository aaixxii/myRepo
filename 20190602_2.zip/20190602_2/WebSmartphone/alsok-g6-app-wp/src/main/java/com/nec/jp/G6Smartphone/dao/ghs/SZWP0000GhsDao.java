package com.nec.jp.G6Smartphone.dao.ghs;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nec.jp.G6Smartphone.SO.KiyLoginInfoModel;
import com.nec.jp.G6Smartphone.SO.LiyGSLoginInfoModel;
import com.nec.jp.G6Smartphone.SO.RKeibiDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.WQueAcMlTrigModel;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;

@Repository
public class SZWP0000GhsDao {

    @PersistenceContext(unitName = "ghsPersistence")
    private EntityManager entityManager;
    
    public KiyLoginInfoModel getKiyLoginInfo(String loginId, Date updateTs) {
        final StringBuilder strBuilder = new StringBuilder();
        final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

        strBuilder.append(" SELECT rak.LN_ACNT_KEIYK as lnAcntKeiyk,");
        strBuilder.append("    rak.LN_KEIYK as lnKeiyk,");
        strBuilder.append("    CAST(rak.ML_ADDR AS CHARACTER) as mlAddr,");
        strBuilder.append("    rak.PASSWD as passwd,");
        strBuilder.append("    CAST(rak.ACNT_TYPE AS CHARACTER) as acntType,");
        strBuilder.append("    rak.USER_NM as userNm,");
        strBuilder.append("    CAST(rak.LOGIN_STS AS CHARACTER) as loginSts,");
        strBuilder.append("    CAST(rak.RGST_STS AS CHARACTER) as rgstSts,");
        strBuilder.append("    CAST(rak.ML_SEND_STS AS CHARACTER) as mlSendSts,");
        strBuilder.append("    DATE_FORMAT(rak.UPDATE_TS, '%Y/%m/%d %H:%i:%s') as updateTs,");
        strBuilder.append("    :acntSbt as acntSbt");
        strBuilder.append(" FROM R_ACNT_KEIYK rak");
        strBuilder.append(" WHERE rak.ML_ADDR = :loginId");
        if (updateTs != null) {
            strBuilder.append(" AND rak.UPDATE_TS = :updateTs");
        }
        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "KiyLoginInfoModelResult");
        query.setParameter("loginId", loginId);
        if (updateTs != null) {
            query.setParameter("updateTs", sdf.format(updateTs));
        }
        query.setParameter("acntSbt", G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION);

        return (KiyLoginInfoModel) query.getSingleResult();
    }

    public String getKiyLoginFailureTimes(String lnAcntUser) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT	ckls.CNT_LOGIN_ERR as cntLoginErr");
        strBuilder.append(" FROM	C_KEIYK_LOGIN_STS ckls");
        strBuilder.append(" WHERE	ckls.LN_ACNT_KEIYK = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUser", lnAcntUser);

        return query.getSingleResult().toString();
    }

    @Transactional("transactionManagerGhs")
    public Boolean updateKiyLoginFailureTimes(String lnAcntUserCommon, String acntNm, String failureTimes,
            String loginSts, Date loginTs) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" UPDATE C_KEIYK_LOGIN_STS ckls");
        strBuilder.append(" SET ckls.ID_UPDATE = :lnAcntUserCommon,");
        strBuilder.append("    ckls.UPDATE_NM = :acntNm,");
        strBuilder.append("    ckls.UPDATE_TS = :updateDate,");

        if (null != loginSts) {
            strBuilder.append("    ckls.LAST_LOGIN_TS = :updateDate,");
            strBuilder.append("    ckls.FLG_LOGIN_STS = :loginSts,");
        }
        strBuilder.append("    ckls.CNT_LOGIN_ERR = :failureTimes");
        strBuilder.append(" WHERE ckls.LN_ACNT_KEIYK = :lnAcntUserCommon");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        if (null != loginSts) {
            query.setParameter("loginSts", loginSts);
        }
        query.setParameter("failureTimes", failureTimes);
        query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
        query.setParameter("acntNm", acntNm);
        query.setParameter("updateDate", loginTs);

        if (query.executeUpdate() > 0) {
            return true;
        }

        return false;
    }

    @Transactional("transactionManagerGhs")
    public Boolean updateKiyPasswordLock(String userCommon, String updateNm, String loginSts, String rgstSts,
            String mlSendSts) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" UPDATE R_ACNT_KEIYK rak");
        strBuilder.append(" SET rak.LOGIN_STS = :loginSts,");
        if (null != rgstSts) {
            strBuilder.append("    rak.RGST_STS = :rgstSts,");
        }
        if (null != mlSendSts) {
            strBuilder.append("    rak.ML_SEND_STS = :mlSendSts,");
        }
        strBuilder.append("    rak.STS_UPD_TS = SYSDATE(),");
        strBuilder.append("    rak.ID_UPDATE = :userCommon,");
        strBuilder.append("    rak.UPDATE_NM = :updateNm,");
        strBuilder.append("    rak.UPDATE_TS = :updateDate");
        strBuilder.append(" WHERE rak.LN_ACNT_KEIYK = :userCommon");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("loginSts", loginSts);
        if (null != rgstSts) {
            query.setParameter("rgstSts", rgstSts);
        }
        if (null != mlSendSts) {
            query.setParameter("mlSendSts", mlSendSts);
        }
        query.setParameter("userCommon", userCommon);
        query.setParameter("updateNm", updateNm);
        query.setParameter("updateDate", DateTimeCommon.getCurrentDateTime());

        if (query.executeUpdate() > 0) {
            return true;
        }
        return false;
    }
    
    @Transactional("transactionManagerGhs")
    public Boolean insertMailTrig(WQueAcMlTrigModel entity) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append("INSERT INTO W_QUE_AC_ML_TRIG");
        strBuilder.append("(	LN_QUE_AC_ML_TRIG, ACNT_TYPE, LN_ACNT, ML_KIND, LN_SEND_TGT, STS,");
        strBuilder.append("	ID_INSERT, INSERT_NM, INSERT_TS, ID_UPDATE, UPDATE_NM, UPDATE_TS)");
        strBuilder.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter(1, entity.getLnQueAcMlTrig());
        query.setParameter(2, entity.getAcntType());
        query.setParameter(3, entity.getLnAcnt());
        query.setParameter(4, entity.getMlKind());
        query.setParameter(5, entity.getLnSendTgt());
        query.setParameter(6, entity.getSts());
        query.setParameter(7, entity.getLnAcnt());
        query.setParameter(8, entity.getInsertNm());
        query.setParameter(9, entity.getInsertTs());
        query.setParameter(10, entity.getLnAcnt());
        query.setParameter(11, entity.getInsertNm());
        query.setParameter(12, entity.getInsertTs());
        if (query.executeUpdate() > 0) {
            return true;
        }
        return false;
    }
    
    @SuppressWarnings("unchecked")
    public List<RKeibiDataModel> getSecurityNameKeiyk(String lnAcntKeiyk, String keibiName) {
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append(" SELECT IFNULL(kaki.LN_KEIBI, '') as lnKeibi");
		strBuilder.append(" , IFNULL(kaki.KEIBI_NM, '') as keibiName1");
		strBuilder.append(" , IFNULL(kaki.KEIBI_ADDR, '') as keibiAddr1");
		strBuilder.append(" FROM V_WE_KEIYK_ACNT_KEIBI_INF kaki");
		strBuilder.append(" INNER JOIN R_TENANT_MNG rtm");
		strBuilder.append(" ON kaki.LN_KEIBI = rtm.LN_KEIBI");
		strBuilder.append(" WHERE kaki.LN_ACNT_KEIYK = :lnAcntKeiyk");
		strBuilder.append(" AND kaki.FLG_FIRST_KSIGINF_RCV = '1' ");
		if (keibiName != null && keibiName.length() > 0) {
			strBuilder.append(" AND KEIBI_NM LIKE :keibiName");
		}
		strBuilder.append(" AND kaki.FLG_GSHS IN (0, 2)");
		strBuilder.append(" AND rtm.FLG_WEB_USE = '1'");
		strBuilder.append("ORDER BY kaki.KEIBI_NM ASC, kaki.LN_KEIBI ASC");

        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKeibiDataModelResult");
        query.setParameter("lnAcntKeiyk", lnAcntKeiyk);
        if (keibiName != null && keibiName.length() > 0) {
			query.setParameter("keibiName", "%"+keibiName+"%");
		}
        
        return (List<RKeibiDataModel>) query.getResultList();
    }
    
    public RKeibiDataModel getSecurityNameLiy(String lnAcntUser, String keibiName) {
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append("SELECT IFNULL(rkb.LN_KEIBI, '') as lnKeibi");
		strBuilder.append("  , IFNULL(rkb.KEIBI_NM, '') as keibiName1");
		strBuilder.append("  , IFNULL(rkb.KEIBI_ADDR, '') as keibiAddr1");
		strBuilder.append(" FROM R_KEIBI rkb");
		strBuilder.append("  INNER JOIN R_TENANT_MNG rtm");
		strBuilder.append("    ON rkb.LN_KEIBI = rtm.LN_KEIBI");
		strBuilder.append("  INNER JOIN R_ACNT_USER rau");
		strBuilder.append("    ON rtm.LN_TENANT_MNG = rau.LN_TENANT_MNG");
		strBuilder.append(" WHERE rtm.TENANT_STS = '1'");
		strBuilder.append("  AND rau.LN_ACNT_USER = :lnAcntUser");
		strBuilder.append("  AND rau.GS_HS_TYPE IN ('0', '2')");
		strBuilder.append("  AND rtm.FLG_WEB_USE = '1'");
		if (keibiName != null && keibiName.length() > 0) {
			strBuilder.append(" AND rkb.KEIBI_NM LIKE :keibiName");
		}
		
        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKeibiDataModelResult");
        query.setParameter("lnAcntUser", lnAcntUser);
        if (keibiName != null && keibiName.length() > 0) {
			query.setParameter("keibiName", "%"+keibiName+"%");
		}
        return (RKeibiDataModel) query.getSingleResult();
    }
    
    /**
     * Get data from R_ACNT_USER table
     * 
     * @param loginId
     * @param updateTs
     * @param gshsType
     * @return
     */
    public LiyGSLoginInfoModel getLiyGSLoginInfo(String loginId, Date updateTs, String gshsType) {
        final StringBuilder strBuilder = new StringBuilder();
        final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

        strBuilder.append(" SELECT rau.LN_ACNT_USER as lnAcntUser,");
        strBuilder.append("    rau.LN_TENANT_MNG as lnTenantMng,");
        strBuilder.append("    CAST(rau.GS_HS_TYPE AS CHARACTER) as gsHsType,");
        strBuilder.append("    CAST(rau.ML_ADDR AS CHARACTER) as mlAddr,");
        strBuilder.append("    rau.PASSWD as passwd,");
        strBuilder.append("    CAST(rau.ACNT_TYPE AS CHARACTER) as acntType,");
        strBuilder.append("    rau.USER_NM as userNm,");
        strBuilder.append("    CAST(rau.LOGIN_STS AS CHARACTER) as loginSts,");
        strBuilder.append("    CAST(rau.RGST_STS AS CHARACTER) as rgstSts,");
        strBuilder.append("    CAST(rau.ML_SEND_STS AS CHARACTER) as mlSendSts,");
        strBuilder.append("    DATE_FORMAT(rau.UPDATE_TS, '%Y/%m/%d %H:%i:%s') as updateTs,");
        strBuilder.append("	  :acntSbt as acntSbt");
        strBuilder.append(" FROM R_ACNT_USER rau");
        strBuilder.append(" WHERE rau.ML_ADDR = :loginId");
        strBuilder.append(" AND rau.GS_HS_TYPE = :gshsType");
        if (updateTs != null) {
            strBuilder.append(" AND rau.UPDATE_TS = :updateTs");
        }

        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "LiyGSLoginInfoModelResult");
        query.setParameter("loginId", loginId);
        query.setParameter("gshsType", gshsType);
        if (updateTs != null) {
            query.setParameter("updateTs", sdf.format(updateTs));
        }
        query.setParameter("acntSbt", G6CodeConsts.CD027.GHS_THE_USER);
        return (LiyGSLoginInfoModel) query.getSingleResult();
    }

    /**
     * get login error from C_USER_LOGIN_STS table
     * 
     * @param lnAcntUser
     * @return
     */
    public String getLiyGSLoginFailureTimes(String lnAcntUser) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT T1.CNT_LOGIN_ERR as cntLoginErr");
        strBuilder.append(" FROM C_USER_LOGIN_STS T1");
        strBuilder.append(" WHERE T1.LN_ACNT_USER = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUser", lnAcntUser);

        return query.getSingleResult().toString();
    }

    /**
     * Update count time login failure in C_USER_LOGIN_STS table
     * 
     * @param lnAcntUser
     * @param acntNm
     * @param failureTimes
     * @param loginSts
     * @return
     */
    @Transactional("transactionManagerGhs")
    public Boolean updateLiyGSLoginFailureTimes(String lnAcntUser, String acntNm, String failureTimes,
            String loginSts, Date updateDate) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" UPDATE C_USER_LOGIN_STS");
        strBuilder.append(" SET ID_UPDATE = :lnAcntUser,");
        strBuilder.append("     UPDATE_NM = :acntNm,");
        strBuilder.append("     UPDATE_TS = :updateDate,");
        if (null != loginSts) {
            strBuilder.append("     LAST_LOGIN_TS = :updateDate,");
            strBuilder.append("     FLG_LOGIN_STS = :loginSts,");
        }
        strBuilder.append("     CNT_LOGIN_ERR = :failureTimes");
        strBuilder.append(" WHERE LN_ACNT_USER = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUser", lnAcntUser);
        query.setParameter("acntNm", acntNm);
        query.setParameter("updateDate", updateDate);
        if (null != loginSts) {
            query.setParameter("loginSts", loginSts);
        }
        query.setParameter("failureTimes", failureTimes);

        if (query.executeUpdate() > 0) {
            return true;
        }
        return false;
    }

    /**
     * Update lock password in R_ACNT_USER
     * 
     * @param userCommon
     * @param updateNm
     * @param loginSts
     * @param rgstSts
     * @param mlSendSts
     * @return
     */
    @Transactional("transactionManagerGhs")
    public Boolean updateLiyGSPasswordLock(String lnAcntUser, String updateNm, String loginSts, String rgstSts, String mlSendSts) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" UPDATE R_ACNT_USER ");
        strBuilder.append(" SET LOGIN_STS = :loginSts,");
        if (null != rgstSts) {
            strBuilder.append("    RGST_STS = :rgstSts,");
        }
        if (null != mlSendSts) {
            strBuilder.append("    ML_SEND_STS = :mlSendSts,");
        }
        strBuilder.append("    STS_UPD_TS = SYSDATE(),");
        strBuilder.append("    ID_UPDATE = :lnAcntUser,");
        strBuilder.append("    UPDATE_NM = :updateNm,");
        strBuilder.append("    UPDATE_TS = :updateDate");
        strBuilder.append(" WHERE LN_ACNT_USER = :lnAcntUser");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("loginSts", loginSts);
        if (null != rgstSts) {
            query.setParameter("rgstSts", rgstSts);
        }
        if (null != mlSendSts) {
            query.setParameter("mlSendSts", mlSendSts);
        }
        query.setParameter("lnAcntUser", lnAcntUser);
        query.setParameter("updateNm", updateNm);
        query.setParameter("updateDate", DateTimeCommon.getCurrentDateTime());

        if (query.executeUpdate() > 0) {
            return true;
        }
        return false;
    }
    
    /**
     * 警備先論理番号から契約先論理番号を取得
     * @param lnKeibi
     * @return 契約先論理番号
     */
	public String getLnKeiykFromLnKeibi(String lnKeibi) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT rb.LN_KEIYK");
        strBuilder.append(" FROM   R_BUKKEN rb INNER JOIN R_KEIBI rk ON rb.LN_BUKKEN = rk.LN_BUKKEN ");
        strBuilder.append(" WHERE  rk.LN_KEIBI = :lnKeibi");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnKeibi", lnKeibi);

        return query.getSingleResult().toString();
	}
}
