package com.nec.jp.G6Smartphone.SO;

public class GHSACntModel implements DataModelHandler {

	private String ghsAcntNo;
	private String mlAddr;
	
	public GHSACntModel(String ghsAcntNo, String mlAddr) {
		this.ghsAcntNo = ghsAcntNo;
		this.mlAddr = mlAddr;
	}

	public String getGhsAcntNo() {
		return ghsAcntNo;
	}

	public void setGhsAcntNo(String ghsAcntNo) {
		this.ghsAcntNo = ghsAcntNo;
	}

	public String getMlAddr() {
		return mlAddr;
	}

	public void setMlAddr(String mlAddr) {
		this.mlAddr = mlAddr;
	}
}
