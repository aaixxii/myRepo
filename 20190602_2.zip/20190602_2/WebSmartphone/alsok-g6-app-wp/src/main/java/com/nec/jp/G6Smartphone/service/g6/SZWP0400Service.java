package com.nec.jp.G6Smartphone.service.g6;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP0400Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP0400Service {

	@Autowired
	private SZWP0400Dao sZWP0400Dao;

	public List<RKbChikuDataModel> getOperableSecureAreaInfo(String acntID, String lnKeibi) throws ApplicationException {
		try {
			List<RKbChikuDataModel> resultList = sZWP0400Dao.getOperableSecureAreaInfo(acntID, lnKeibi);

			return resultList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public List<String> getKeibiAreaInfoList(String lnKbChiku) throws ApplicationException {
		try {
			List<String> keibiAreaInfoList = sZWP0400Dao.getKeibiAreaInfoList(lnKbChiku);

			return keibiAreaInfoList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public RCtlDevDataSubModel getSecureInfo(String lnKbChiku) throws ApplicationException {
		try {
			RCtlDevDataSubModel rCtlDevDataSubModel = sZWP0400Dao.getSecureInfo(lnKbChiku);

			return rCtlDevDataSubModel;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public List<String> getLnDevLpList(String lnKbChiku) throws ApplicationException {
		try {
			List<String> lnDevLpList = sZWP0400Dao.getLnDevLpList(lnKbChiku);

			return lnDevLpList;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public ControlQueueStatusModel getControlQueueStsInfo(String cmdSeqNum) throws ApplicationException {
		try {
			ControlQueueStatusModel controlQueueStatusModel = sZWP0400Dao.getControlQueueStsInfo(cmdSeqNum);

			return controlQueueStatusModel;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public ControlQueueStatusModel getLoopStsDtlInfo(String lnDev) throws ApplicationException {
		try {
			ControlQueueStatusModel controlQueueStatusModel = sZWP0400Dao.getLoopStsDtlInfo(lnDev);

			return controlQueueStatusModel;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
