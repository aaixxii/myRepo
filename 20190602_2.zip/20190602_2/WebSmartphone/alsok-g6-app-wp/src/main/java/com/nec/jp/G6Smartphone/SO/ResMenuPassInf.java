package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.model.SZWPUserForm;
import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResMenuPassInf implements ErrorHandler {

	private String errorCode;			// エラーコード
	private String errorMsg;			// エラーメッセージ
	private String acntID;				// アカウント論理番号
	private String lnAcntUserCommon;	// 利用者アカウント-ロール連関.LN_利用者アカウント共通論理番号
    private String userAcntAuthNm;		// 利用者権限マスター.利用者アカウント権限名称
	private String menuPassInf;			// 利用者権限マスター.メニューパス情報
	
	private String flgKbSetDisp;		//警備開始 / 解除表示フラグ
	private String flgKbHstDisp;		//警備履歴の確認表示フラグ
	private String flgRmtKbSetDisp;		//遠隔設備操作表示フラグ
	private String sdLineKind;			//SD_回線種別
	private SZWPUserForm szwpUser;		//表示権限の表示判定


	public ResMenuPassInf() {
		this.errorCode 			= G6Constant.FAIL_POPUP_CD;
		this.errorMsg 			= "";
		this.acntID 			= "";
		this.lnAcntUserCommon 	= "";
		this.userAcntAuthNm 	= "";
		this.menuPassInf 		= "";
	}

	public ResMenuPassInf(String lnAcntUserCommon, String userAcntAuthNm, String menuPassInf) {
		this.errorCode 			= G6Constant.SUCCESS_CD;
		this.errorMsg 			= "";
		this.acntID 			= "";
		this.lnAcntUserCommon 	= lnAcntUserCommon;
		this.userAcntAuthNm 	= userAcntAuthNm;
		this.menuPassInf 		= menuPassInf;
	}

	public ResMenuPassInf(String errorCode, String errorMsg, String lnAcntUserCommon, String userAcntAuthNm, String menuPassInf) {
		this.errorCode 			= errorCode;
		this.errorMsg 			= errorMsg;
		this.acntID 			= "";
		this.lnAcntUserCommon 	= lnAcntUserCommon;
		this.userAcntAuthNm 	= userAcntAuthNm;
		this.menuPassInf 		= menuPassInf;
	}

	public ResMenuPassInf(String errorCode, String errorMsg, String acntID, String lnAcntUserCommon,
			String userAcntAuthNm, String menuPassInf, String flgKbSetDisp, String flgKbHstDisp, String flgRmtKbSetDisp,
			String sdLineKind, SZWPUserForm szwpUser) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.acntID = acntID;
		this.lnAcntUserCommon = lnAcntUserCommon;
		this.userAcntAuthNm = userAcntAuthNm;
		this.menuPassInf = menuPassInf;
		this.flgKbSetDisp = flgKbSetDisp;
		this.flgKbHstDisp = flgKbHstDisp;
		this.flgRmtKbSetDisp = flgRmtKbSetDisp;
		this.sdLineKind = sdLineKind;
		this.szwpUser = szwpUser;
	}
	
	public String getFlgKbSetDisp() {
		return flgKbSetDisp;
	}

	public void setFlgKbSetDisp(String flgKbSetDisp) {
		this.flgKbSetDisp = flgKbSetDisp;
	}

	public String getFlgKbHstDisp() {
		return flgKbHstDisp;
	}

	public void setFlgKbHstDisp(String flgKbHstDisp) {
		this.flgKbHstDisp = flgKbHstDisp;
	}

	public String getFlgRmtKbSetDisp() {
		return flgRmtKbSetDisp;
	}

	public void setFlgRmtKbSetDisp(String flgRmtKbSetDisp) {
		this.flgRmtKbSetDisp = flgRmtKbSetDisp;
	}

	public String getSdLineKind() {
		return sdLineKind;
	}

	public void setSdLineKind(String sdLineKind) {
		this.sdLineKind = sdLineKind;
	}

	public SZWPUserForm getSzwpUser() {
		return szwpUser;
	}

	public void setSzwpUser(SZWPUserForm szwpUser) {
		this.szwpUser = szwpUser;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

   public String getLnAcntUserCommon() {
        return lnAcntUserCommon;
    }

    public void setLnAcntUserCommon(String lnAcntUserCommon) {
        this.lnAcntUserCommon = lnAcntUserCommon;
    }
	    
	public String getUserAcntAuthNm() {
		return userAcntAuthNm;
	}

	public void setUserAcntAuthNm(String userAcntAuthNm) {
		this.userAcntAuthNm = userAcntAuthNm;
	}

	public String getMenuPassInf() {
		return menuPassInf;
	}

	public void setMenuPassInf(String menuPassInf) {
		this.menuPassInf = menuPassInf;
	}
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
