package com.nec.jp.G6Smartphone.SO;

public class RKbChikuNmDataModel {

	private String lnKbChiku;			// 警備先地区.LN_警備先地区論理番号
	private String sdKobetuNm;			// 警備先地区.警備先地区名称

	public RKbChikuNmDataModel() {
		this.lnKbChiku = "";
		this.sdKobetuNm = "";
	}

	public RKbChikuNmDataModel(String lnKbChiku, String sdKobetuNm) {
		this.lnKbChiku = lnKbChiku;
		this.sdKobetuNm = sdKobetuNm;
	}

	public String getLnKbChiku() {
		return lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getSdKobetuNm() {
		return sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}
}
