package com.nec.jp.G6Smartphone.dao.ghs;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.KbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataModel;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP1000GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<KbChikuDataModel> getListSecurityDistrictGHS(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	rkc.LN_KB_CHIKU as lnKbChiku,");
		strBuilder.append("			rkc.SUB_ADDR as subAddr,");
		strBuilder.append("			rkc.SD_KOBETU_NM as sdKobetuNm");
		strBuilder.append(" FROM	R_KB_CHIKU rkc");
		strBuilder.append("			INNER JOIN R_KEIBI rk ON rkc.LN_KEIBI = rk.LN_KEIBI");
		strBuilder.append(" WHERE	rk.LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND rkc.ENTRY_STS = :entrySts");
		strBuilder.append(" ORDER BY rkc.LN_KB_CHIKU ASC,");
		strBuilder.append("			 rkc.SUB_ADDR ASC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "KbChikuDataModelResult");
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("entrySts", G6CodeConsts.CD031.REGISTERED);

		return (List<KbChikuDataModel>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<RDevDataModel> getListDeviceGHS(String lnKbChiku) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	rd.LN_DEV as lnDev,");
		strBuilder.append("			rd.SD_DEV_NM as sdDevNm,");
		strBuilder.append("			rd.SD_DEV_NUM as sdDevNum");
		strBuilder.append(" FROM	R_DEV rd");
		strBuilder.append("			INNER JOIN R_KB_CHIKU rk ON rd.LN_KB_CHIKU = rk.LN_KB_CHIKU");
		strBuilder.append(" WHERE	rk.LN_KB_CHIKU = :lnKbChiku");
		strBuilder.append("         AND rd.SD_RM_KIND = '11'");
		strBuilder.append(" ORDER BY rd.SD_DEV_NM ASC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RDevDataModelResult");
		query.setParameter("lnKbChiku", lnKbChiku);

		return (List<RDevDataModel>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<String> getListElectricNumGHS(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	rd.DENKEI");
		strBuilder.append(" FROM	R_DENKEI_MNG rd");
		strBuilder.append(" WHERE	rd.LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND rd.FLG_LAST = :lastFlg");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("lastFlg", G6CodeConsts.CD009.LATEST);

		return (List<String>) query.getResultList();
	}

	public RCtlDevDataModel getGoukiSerialGHS(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT GOUKI as gouKi,");
		strBuilder.append("    IFNULL(SERIAL_NUM, '') as serialNum,");
		strBuilder.append("    '' as sdLineKind");
		strBuilder.append(" FROM	R_KEIBI");
		strBuilder.append(" WHERE LN_KEIBI = :lnKeibi");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RCtlDevDataModelResult");
		query.setParameter("lnKeibi", lnKeibi);

		return (RCtlDevDataModel) query.getSingleResult();
	}

	public String getControlQueueStsGHS(String cmdSeqNum) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	CAST(STS as CHARACTER)");
		strBuilder.append(" FROM	E_QUE_CTRL");
		strBuilder.append(" WHERE	CMD_SEQ_NUM = :cmdSeqNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("cmdSeqNum", cmdSeqNum);
		query.setMaxResults(1);
		return (String) query.getSingleResult();
	}

	public String getDeviceStsGHS(String lnDev) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(DRCTSET_CNTR_ST, '') as drctsetCntrSt ");
		strBuilder.append(" FROM	C_DEV_STS");
		strBuilder.append(" WHERE	LN_DEV = :lnDev");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnDev", lnDev);

		return (String) query.getSingleResult().toString();
	}
}
