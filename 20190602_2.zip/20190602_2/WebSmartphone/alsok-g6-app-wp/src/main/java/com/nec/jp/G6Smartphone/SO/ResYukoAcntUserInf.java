package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResYukoAcntUserInf implements ErrorHandler {
    
    // エラーコード
    private String errorCode; 
    // エラーメッセージ
    private String errorMsg; 
    // アカウントID
    private String acntID;
    
    /**
     * メニューパス情報
     */
    protected String menupassInf;
    /**
     * 地区別権限有無
     */
    protected String chikuFlg;
    /**
     * 有効利用者アカウント区分
     */
    protected String yukoAcntUserKbn;
    
    
    public ResYukoAcntUserInf() {
        this.errorCode = G6Constant.FAIL_POPUP_CD;
        this.errorMsg = "";
        this.menupassInf = "";
        this.chikuFlg = "";
        this.yukoAcntUserKbn = "";
        this.acntID = "";
    }
    
    public ResYukoAcntUserInf(String menupassInf, String chikuFlg, String yukoAcntUserKbn) {
        this.errorCode = G6Constant.SUCCESS_CD;
        this.errorMsg = "";
        this.menupassInf = menupassInf;
        this.chikuFlg = chikuFlg;
        this.yukoAcntUserKbn = yukoAcntUserKbn;
        this.acntID = "";
    }

    public ResYukoAcntUserInf(String errorCode, String errorMsg, String menupassInf, String chikuFlg, String yukoAcntUserKbn) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
        this.menupassInf = menupassInf;
        this.chikuFlg = chikuFlg;
        this.yukoAcntUserKbn = yukoAcntUserKbn;
        this.acntID = "";
    }
    
    /**
     * @return the menupassInf
     */
    public String getMenupassInf() {
        return menupassInf;
    }
    /**
     * @return the chikuFlg
     */
    public String getChikuFlg() {
        return chikuFlg;
    }
    /**
     * @return the yukoAdntUserKbn
     */
    public String getYukoAcntUserKbn() {
        return yukoAcntUserKbn;
    }
    
    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public void setMenupassInf(String menupassInf) {
        this.menupassInf = menupassInf;
    }

    public void setChikuFlg(String chikuFlg) {
        this.chikuFlg = chikuFlg;
    }

    public void setYukoAcntUserKbn(String yukoAcntUserKbn) {
        this.yukoAcntUserKbn = yukoAcntUserKbn;
    }
    
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
