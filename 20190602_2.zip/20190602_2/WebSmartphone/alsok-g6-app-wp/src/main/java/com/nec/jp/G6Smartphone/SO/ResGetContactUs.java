package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetContactUs implements ErrorHandler {

	private String errorCode;
	private String errorMsg;
	private String gcTelNum;
	private String remoteTelNum;
	private String sonotaTelNum;
	private String jigyouNm;
	private String customerNum;
	private String acntID;
	
	public ResGetContactUs() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;;
		this.errorMsg = "";
		this.gcTelNum = "";
		this.remoteTelNum = "";
		this.sonotaTelNum = "";
		this.jigyouNm = "";
		this.customerNum = "";
		this.acntID = "";
	}
	public ResGetContactUs(String errorCode, String errorMsg, String gcTelNum, String remoteTelNum, String sonotaTelNum,
			String jigyouNm, String customerNum) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.gcTelNum = gcTelNum;
		this.remoteTelNum = remoteTelNum;
		this.sonotaTelNum = sonotaTelNum;
		this.jigyouNm = jigyouNm;
		this.customerNum = customerNum;
		this.acntID = "";
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getGcTelNum() {
		return gcTelNum;
	}
	public void setGcTelNum(String gcTelNum) {
		this.gcTelNum = gcTelNum;
	}
	public String getRemoteTelNum() {
		return remoteTelNum;
	}
	public void setRemoteTelNum(String remoteTelNum) {
		this.remoteTelNum = remoteTelNum;
	}
	public String getSonotaTelNum() {
		return sonotaTelNum;
	}
	public void setSonotaTelNum(String sonotaTelNum) {
		this.sonotaTelNum = sonotaTelNum;
	}
	public String getJigyouNm() {
		return jigyouNm;
	}
	public void setJigyouNm(String jigyouNm) {
		this.jigyouNm = jigyouNm;
	}
	public String getCustomerNum() {
		return customerNum;
	}
	public void setCustomerNum(String customerNum) {
		this.customerNum = customerNum;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
