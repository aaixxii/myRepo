package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;
import com.nec.jp.G6Smartphone.SO.ErrorDataModel;
import com.nec.jp.G6Smartphone.SO.LockedStatusDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.SO.RDevStsDataModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataSubModel;
import com.nec.jp.G6Smartphone.SO.ResGetKeibiSetteiStatus;
import com.nec.jp.G6Smartphone.SO.ResGetLockedStatus;
import com.nec.jp.G6Smartphone.SO.ResSetRemoteDev;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP0400Service;
import com.nec.jp.G6Smartphone.service.g6.SZWP0800Service;
import com.nec.jp.G6Smartphone.service.g6.SZWP1000Service;
import com.nec.jp.G6Smartphone.service.g6.SZWP1100Service;
import com.nec.jp.G6Smartphone.service.ghs.CommonGhsService;
import com.nec.jp.G6Smartphone.service.ghs.SZWP1000GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;

import jp.co.alsok.g6.common.log.ApplicationLog;
import jp.co.alsok.g6.zzw.util.G6AuthControl.Keiyk;

@Controller
@PropertySource("classpath:test.properties")
public class TestController {

	private static final ApplicationLog appLog = new ApplicationLog(TestController.class);

	@Autowired
	SZWP0400Service sZWP0400Service;
	@Autowired
	SZWP0800Service sZWP0800Service;
	@Autowired
	SZWP1000Service sZWP1000Service;
	@Autowired
	SZWP1000GhsService sZWP1000GhsService;
	@Autowired
	SZWP1100Service sZWP1100Service;
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;
	@Autowired
	CommonGhsService commonGhsService;

	@Value("${timeout}")
	Integer timeout;
	@Value("${cmdVer}")
	String cmdVer;
	@Value("${cmdVer2}")
	String cmdVer2;
	@Value("${timeSleep}")
	Integer timeSleep;
	@Value("${host_name}")
	String hostName;
	//test result for 2700
	@Value("${szwp2700_result}") String SZWP2700_Result;
	@Value("#{'${szwp2700_mem_data_list}'.split(',')}")  List<String> SZWP2700_mem_data_list;
	@Value("${szwp2700_url}") String SZWP2700_URL;
	//test result for 2900_009
	@Value("${szwp2900_009_result}") String szwp2900_009_Result;
	@Value("${szwp2900_009_ptz_enable_flg}") String szwp2900_009_Ptz_Enable_Flg;
	@Value("${szwp2900_009_preset_status}") String szwp2900_009_Preset_Status;
	@Value("${szwp2900_009_frame_rate}") String szwp2900_009_Frame_Rate;
	@Value("${szwp2900_009_img_quality}") String szwp2900_009_Img_Quality;
	@Value("${szwp2900_009_param_set_flg}") String szwp2900_009_Param_Set_Flg;
	@Value("${szwp2900_009_has_ope_auth}") String szwp2900_009_Has_Ope_Auth;
	@Value("${szwp2900_009_call_port}") String szwp2900_009_Call_Port;
	@Value("${szwp2900_009_call_ip}") String szwp2900_009_Call_Ip;
	@Value("${szwp2900_009_acnt_type_for_ope}") String szwp2900_009_Acnt_Type_For_Ope;
	@Value("${szwp2900_009_ln_acnt_user_common_for_ope}") String szwp2900_009_Ln_Acnt_User_Common_For_Ope;
	@Value("${szwp2900_009_strem_id}") String szwp2900_009_Strem_Id;
	@Value("${szwp2900_009_img_ip}") String szwp2900_009_Img_Ip;
	@Value("${szwp2900_009_acnt_name}") String szwp2900_009_Acnt_Name;
	@Value("${szwp2900_009_trans_flg}") String szwp2900_009_Trans_Flg;
	@Value("${szwp2900_009_url}") String szwp2900_009_URL;
	@Value("${szwp2900_009_url2}") String szwp2900_009_URL2;
	//test result for 2800
	@Value("${szwp2800_live_ip}") String SZWP2800_Live_Ip;
	@Value("${szwp2800_download_port}") String SZWP2800_Download_Port;
	@Value("${szwp2800_result}") String SZWP2800_Result;
	//test result for 2300_camctrl
	@Value("${szwp2300_camctrl_has_ope_auth}")  String SZWP2300_CAMCTRL_Has_Ope_Auth;
	@Value("${szwp2300_camctrl_acnt_type_for_ope}")  String SZWP2300_CAMCTRL_Acnt_Type_For_Ope;
	@Value("${szwp2300_camctrl_ln_dev_lst}")  String SZWP2300_CAMCTRL_Ln_Dev_Lst;
	@Value("#{'${szwp2300_camctrl_call_port_list}'.split(',')}")  List<String> SZWP2300_CAMCTRL_Call_Port_List;
	@Value("#{'${szwp2300_camctrl_call_ip_list}'.split(',')}")  List<String> SZWP2300_CAMCTRL_Call_Ip_List;
	@Value("#{'${szwp2300_camctrl_result_list}'.split(',')}") List<String> SZWP2300_CAMCTRL_Result_List;
	@Value("${szwp2300_camctrl_result}") String SZWP2300_CAMCTRL_Result;
	@Value("${szwp2300_camctrl_acnt_name}") String SZWP2300_CAMCTRL_Acnt_Name;
	
	@Value("${szwp2500_stopliveimg_result}") String SZWP2300_STOPLIVEIMG_Result;
	private static final String CMD_RSLT = "cmd_rslt";
	private static final String LGTM_ST = "lgtm_st";

	/*
	 * Get data from R_KB_CHIKU, R_KB_CHIKU_STS table
	 * @param: acntID, acntNm, lnKbChiku, lgtmSt
	 * return: object ResGetLockedStatus as JSON
	 */
	@RequestMapping(value = "/getLockedStatusForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getLockedStatusForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0400Controller.getLockedStatusForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetLockedStatus resGetLockedStatus = new ResGetLockedStatus();
		List<LockedStatusDataModel> lockedStatusDataModelList = new ArrayList<LockedStatusDataModel>();
		Map<String, Object> mapParam = new HashMap<String, Object>();

		try {
		    
		    List<Keiyk>  xxx = commonService.getUserOperationHani("29000101200000000002");
            String sdDevNum = "13435";
            if (sdDevNum == null || sdDevNum.length() < 11) {
                sdDevNum = sdDevNum + "            ";
                sdDevNum = sdDevNum.substring(0, 11);
            }
		 // 9-2.B)号機番号、シリアル番号の取得
            List<RCtlDevDataModel> rCtlDevDataModelList = sZWP1000Service.getListGoukiSerial("45435435", "123456789");
            RCtlDevDataModel rCtlDevDataModel = sZWP1000GhsService.getGoukiSerialGHS("");
            if(rCtlDevDataModelList.size() == 0) {
                rCtlDevDataModelList.add(new RCtlDevDataModel());
            }

            // 共通クラスから取得したコマンドシーケンス番号
            // String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
            final String cmdSeqNum1 = commonService.getCmdSeq();
            final String transNo = commonService.getTranSeq();

            
            
			List<String> lnKbChikuList = new ArrayList<String>();
			List<String> cmdSeqNumList = new ArrayList<String>();
			int remainCmdSq = 0;

			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 4) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatusForTest()");
				return jsonResult;
			}

			// Build require parameters
			Map<String, Boolean> mapRequireParam = new HashMap<String, Boolean>() {
				private static final long serialVersionUID = 1L;
				{
					put(RequestParam.acntID.getValue(), true);
					put(RequestParam.acntNm.getValue(), true);
					put(RequestParam.lnKbChiku.getValue(), true);
					put("lgtmSt", true);
				}
			};
			List<String> chkArrParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.lnKbChiku.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, mapRequireParam, chkArrParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatusForTest()");
				return jsonResult;
			}

			// unused: リクエスト情報取得

			// TODO SZWP0400：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 戸締り状態表示情報の取得
			lnKbChikuList = G6Common.readParamToArrayObject(mapParam, RequestParam.lnKbChiku.getValue());

			// リクエスト情報の警備先地区論理番号の件数分ループ
			for (String lnKbChiku : lnKbChikuList) {
				// 制御信号登録用情報を取得する。
				// 8-2.戸締り状態処理ＤＢ検索内容
				RCtlDevDataSubModel rCtlDevDataSubModel = sZWP0400Service.getSecureInfo(lnKbChiku);

				if (null != rCtlDevDataSubModel) {
					// コマンドシーケンス番号
					// String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
				    final String cmdSeqNum = commonService.getCmdSeq();
					Map<String, String> mapSoap = this.createParamForSoap400(rCtlDevDataSubModel, cmdSeqNum,
							mapParam.get("lgtmSt").toString());

					// 戸締り状態取得要求コマンドを発行する
					// 8-3.戸締り状態取得要求処理'
					String soapMsg = this.createSoapMsg400(mapSoap);
					final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
					
					mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
					mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
					mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());

					commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

					cmdSeqNumList.add(cmdSeqNum);
					remainCmdSq++;
				} else {
					cmdSeqNumList.add("");
				}

				lockedStatusDataModelList.add(new LockedStatusDataModel(lnKbChiku, ""));
			}

			long beginTime = System.currentTimeMillis();
			int countSleep = 0;

			// プロパティファイルから取得した「タイムアウト時間」までループ
			// start loop
			while (true) {
				long nowTime = System.currentTimeMillis();
				if ((nowTime - beginTime) > timeout) {
					break;
				}

				// リクエスト情報の警備先地区論理番号の件数分ループ
				for (int i = 0; i < cmdSeqNumList.size(); i++) {
					if (!"".equals(cmdSeqNumList.get(i))) {
						// 制御信号キューの状態を確認する
						// 8-4.戸締り状態取得処理'
						ControlQueueStatusModel controlQueueStatusModel = sZWP0400Service.getControlQueueStsInfo(cmdSeqNumList.get(i));

						if (null == controlQueueStatusModel) {
							jsonResult = G6Common.messageUpdateLogHandler(resGetLockedStatus, 
									G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

							// 処理終了
							appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatusForTest()");
							return jsonResult;
						}

						// 状態が「リクエスト送信中」もしくは「未送信」の場合
						if (G6CodeConsts.CD179.A_REQUEST_IS_BEING_SENT.equals(controlQueueStatusModel.getSts()) || 
								G6CodeConsts.CD179.UNSENT.equals(controlQueueStatusModel.getSts())) {
							// 次のリストへ移る
							continue;

						// 状態が（「リクエスト送信中」または「未送信」）以外の場合
						} else {
							// 8-4)で取得したSOAP電文より、
							// ループ状態通知（レスポンス）タグ <lpinfrd_rsp>の中の
							// 下記タグ（タグ名称<tag>）の内容を取得する。
							// ②センサー状態<lgtm_st>
							String execResult = "";
							execResult = G6Common.getElementByTagName(controlQueueStatusModel.getSoapMsg(), G6Constant.LGTM_ST);

							// 戸締り状態の項目設定
							// 戸締り状態情報が取得できた場合
							if (!"".equals(execResult)) {
								// LN_警備先地区論理番号／状態を戸締り状態情報を表示項目に設定する。
								lockedStatusDataModelList.get(i).setLockedSts(execResult);

							// 戸締り状態情報が取得できなかった場合
							} else {
								// 共通「エラーメッセージ取得処理」を呼び出し、エラーメッセージを取得する。
								jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.FAIL_POPUP_CD,
										ErrorKey.NO_LOCKIN_STS_INFO.getValue(), acntLanguage);

								// 処理終了
								appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatusForTest()");
								return jsonResult;
							}

							// 制御状態読出要求のコマンドシーケンス番号を削除する
							cmdSeqNumList.set(i, "");
							remainCmdSq--;
						}
					}
				}

				// 制御状態読出要求のコマンドシーケンス番号が残っていない場合
				if (0 == remainCmdSq) {
					resGetLockedStatus.setErrorCode(G6Constant.SUCCESS_CD);
					resGetLockedStatus.setLockedStatusItem(lockedStatusDataModelList);

					jsonResult = G6Common.parseJSON(resGetLockedStatus, acntLanguage);

					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatusForTest()");
					return jsonResult;
				}

				// プロパティファイルから取得「待機時間」の分、一定時間待機し、監視を継続
				G6Common.sleepOperation(timeout, timeSleep, countSleep);
				countSleep++;
			}
			// end loop

			// タイムアウト発生時
			// 共通「メッセージ取得処理」を呼び出し、エラーメッセージを取得する。
			jsonResult = G6Common.messageHandler(resGetLockedStatus, G6Constant.FAIL_POPUP_CD,
					ErrorKey.ERROR_SERVER_TIMEOUT.getValue(), acntLanguage);

		} catch (ApplicationException e) {
			if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_DB_ACCESS.getValue())) {
				jsonResult = G6Common.messageLogHandler(resGetLockedStatus, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_JSON.getValue())) {
				jsonResult = G6Common.messageLogHandler(resGetLockedStatus, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			}
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetLockedStatus, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetLockedStatus, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0400Controller.getLockedStatusForTest()");
		return jsonResult;
	}

	private Map<String, String> createParamForSoap400(RCtlDevDataSubModel rCtlDevDataSubModel, String cmdsqNo,
			String lgtmSt) {
		Map<String, String> mapSoap = new HashMap<String, String>();

		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer2);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataSubModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, rCtlDevDataSubModel.getCustomerNum1());
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataSubModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, rCtlDevDataSubModel.getSubAddr());
		mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.LPINFRD);
		mapSoap.put(LGTM_ST, lgtmSt);

		mapSoap.put(G6Constant.MYCD003.HOSTNM, hostName);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_9_LOW);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.LPINFRD);
		mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.SUCCESS);

		return mapSoap;
	}

	private String createSoapMsg400(Map<String, String> mapSoap) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
		// データ部作成
		// 共通項目タグ設定
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 共通クラスから取得したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<lgtm_st>");
		builder.append(mapSoap.get(LGTM_ST) + "</lgtm_st>");

		// フッター部作成
		builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

		return builder.toString();
	}

	/*
	 * Get data from R_CTL_DEV, R_KB_CHIKU, R_DENKEI_MNG table
	 * @param: acntID, acntNm, lnKeibi, lnKbChiku, (shoriKubun is 3, 4) lnKbArea, shoriKubun, cmdRslt
	 * return: object errorDataModel as JSON
	 */
	@RequestMapping(value = "/deleteKeibiStartForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String deleteKeibiStartForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0800Controller.deleteKeibiStartForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ErrorDataModel errorDataModel = new ErrorDataModel();
		Map<String, Object> mapParam = new HashMap<String, Object>();

		try {
			Map<String, Boolean> chkParamMap = null;

			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 7 || 
					null == mapParam.get(RequestParam.shoriKubun.getValue()) || 
					"".equals(mapParam.get(RequestParam.shoriKubun.getValue()))) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
				return jsonResult;
			}

			// リクエスト情報検証
			List<String> chkArrParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.lnKbArea.getValue());
				}
			};

			// リクエスト情報から処理区分を取得する
			String shoriKubun = mapParam.get(RequestParam.shoriKubun.getValue()).toString();

			if ((G6Constant.MYCD001.UNDER_SECURITY).equals(shoriKubun) || (G6Constant.MYCD001.UNPROTECTING).equals(shoriKubun)) {
				// Build require parameters
				chkParamMap = new HashMap<String, Boolean>() {
					private static final long serialVersionUID = 1L;
					{
						put(RequestParam.acntID.getValue(), true);
						put(RequestParam.acntNm.getValue(), true);
						put(RequestParam.lnKeibi.getValue(), true);
						put(RequestParam.lnKbChiku.getValue(), true);
						put(RequestParam.lnKbArea.getValue(), false);
						put(RequestParam.shoriKubun.getValue(), true);
						put("cmdRslt", true);
					}
				};

			} else if ((G6Constant.MYCD001.UNDER_SECURITY_IN_ROOM).equals(shoriKubun) || (G6Constant.MYCD001.UNPROTECTING_IN_ROOM).equals(shoriKubun)) {
				chkParamMap = new HashMap<String, Boolean>() {
					private static final long serialVersionUID = 1L;
					{
						put(RequestParam.acntID.getValue(), true);
						put(RequestParam.acntNm.getValue(), true);
						put(RequestParam.lnKeibi.getValue(), true);
						put(RequestParam.lnKbChiku.getValue(), true);
						put(RequestParam.lnKbArea.getValue(), true);
						put(RequestParam.shoriKubun.getValue(), true);
						put("cmdRslt", true);
					}
				};

			} else {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
				return jsonResult;
			}

			if (!G6Common.checkRequire(mapParam, chkParamMap, chkArrParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
				return jsonResult;
			}

			// unused: リクエスト情報取得

			// TODO SZWP0800：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// コマンドシーケンス番号
			// String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
			final String cmdSeqNum = commonService.getCmdSeq();
			
			// 警備先情報取得処理
			// 8-2.A)警備先情報の取得
			RCtlDevDataSubModel rCtlDevDataSubModel = sZWP0800Service.getSecureInfo(mapParam.get(RequestParam.lnKbChiku.getValue()).toString());

			// 警備先情報が取得出来なかった場合
			if (null == rCtlDevDataSubModel) {
				// エラーメッセージを取得する。 error.keibi.notFound
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.NO_SECURITY_DISTRICT_INFO_LIST.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
				return jsonResult;

				// 警備先情報が取得出来た場合
				// シリアル番号が設定されていなかった場合
			} else if ("".equals(rCtlDevDataSubModel.getSerialNum().trim())) {
				// エラーメッセージを取得する。 error.command.serialNumNotFound
				jsonResult = G6Common.messageHandler(errorDataModel, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_SERIALNUM_NOT_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
				return jsonResult;
			}

			// 警備開始／警備解除処理
			// リクエスト情報から処理区分を取得する
			// 処理区分が「警備開始」の場合
			// 警備開始処理を行う
			// 8-1.警備開始処理詳細
			if ((G6Constant.MYCD001.UNDER_SECURITY).equals(shoriKubun)) {
				Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.N0,
						mapParam.get("cmdRslt").toString());

				// 警備開始処理
				// 警備開始要求を制御信号キューに登録する
				// 8-3.警備開始処理ＤＢ更新内容
				String soapMsg = this.getSecurityStatusCmdOut(mapSoap);
				final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
				mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
				mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
				mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());

				commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

				long beginTime = System.currentTimeMillis();
				int countSleep = 0;

				// プロパティファイルから取得した「タイムアウト時間」までループ
				// start loop
				while (true) {
					long nowTime = System.currentTimeMillis();
					if ((nowTime - beginTime) > timeout) {
						break;
					}

					// 制御信号キューを検索する。
					// 8-2.B) 警備設定処理終了確認
					ControlQueueStatusModel controlQueueStatusModel = sZWP0800Service.getControlQueueStsInfo(cmdSeqNum);

					if (null == controlQueueStatusModel) {
						jsonResult = G6Common.messageUpdateLogHandler(errorDataModel, 
								G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

						// 処理終了
						appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
						return jsonResult;
					}

					// 状態が「0：未送信」以外の場合
					if (!G6CodeConsts.CD179.UNSENT.equals(controlQueueStatusModel.getSts())) {
						// 取得したSOAP電文からkbstset_rspタグ内の実行結果(<cmd_rslt>タグ)を取得する
						String execResult = "";
						execResult = G6Common.getElementByTagName(controlQueueStatusModel.getSoapMsg(), G6Constant.CMD_RESULT);

						// 「実行結果」により処理結果を判定する
						// 0：OK の場合
						if (G6CodeConsts.CD185.OK.equals(execResult)) {
							errorDataModel.setErrorCode(G6Constant.SUCCESS_CD);
							break;

						// 2：排他エラー の場合
						} else if (G6CodeConsts.CD185.EXCLUSION_ERROR.equals(execResult)) {
							errorDataModel.setErrorCode(G6Constant.FAIL_DUPLICATE_CD);
							break;

						// 上記以外の場合
						} else {
							break;
						}

					// 状態が「0：未送信」の場合
					} else {
						// 待機時間が経過するまで待機する
						G6Common.sleepOperation(timeout, timeSleep, countSleep);
						countSleep++;
					}
				}
				// end loop

			// 処理区分が「警備解除」の場合
			// 警備解除処理を行う
			// 9-1.警備削除処理詳細
			} else if ((G6Constant.MYCD001.UNPROTECTING).equals(shoriKubun)) {
				Map<String, String> mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.F0,
						mapParam.get("cmdRslt").toString());

				// 警備解除処理
				// 警備解除要求を制御信号キューに登録する
				// 9-2.警備解除処理ＤＢ更新内容
				String soapMsg = this.getSecurityStatusCmdOut(mapSoap);
				final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
				
				mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
				mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
				mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());

				commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

				long beginTime = System.currentTimeMillis();
				int countSleep = 0;

				// プロパティファイルから取得した「タイムアウト時間」までループ
				// start loop
				while (true) {
					long nowTime = System.currentTimeMillis();
					if ((nowTime - beginTime) > timeout) {
						break;
					}

					// 制御信号キューを検索する。
					// 8-2.B) 警備解除処理終了確認
					ControlQueueStatusModel controlQueueStatusModel = sZWP0800Service.getControlQueueStsInfo(cmdSeqNum);

					if (null == controlQueueStatusModel) {
						jsonResult = G6Common.messageUpdateLogHandler(errorDataModel, 
								G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

						// 処理終了
						appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
						return jsonResult;
					}

					// 状態が「0：未送信」以外の場合
					if (!G6CodeConsts.CD179.UNSENT.equals(controlQueueStatusModel.getSts())) {
						// 取得したSOAP電文からkbstset_rspタグ内の実行結果(<cmd_rslt>タグ)を取得する
						String execResult = "";
						execResult = G6Common.getElementByTagName(controlQueueStatusModel.getSoapMsg(), G6Constant.CMD_RESULT);

						// 「実行結果」により処理結果を判定する
						// 0：OK の場合
						if (G6CodeConsts.CD185.OK.equals(execResult)) {
							errorDataModel.setErrorCode(G6Constant.SUCCESS_CD);
							break;

						// 2：排他エラー の場合
						} else if (G6CodeConsts.CD185.EXCLUSION_ERROR.equals(execResult)) {
							errorDataModel.setErrorCode(G6Constant.FAIL_DUPLICATE_CD);
							break;

						// 上記以外の場合
						} else {
							break;
						}

					// 状態が「0：未送信」の場合
					} else {
						// 待機時間が経過するまで待機する
						G6Common.sleepOperation(timeout, timeSleep, countSleep);
						countSleep++;
					}
				}
				// end loop

			// 処理区分が「在室警備開始/在室警備解除」の場合
			// 在室警備処理を行う
			// 10-1.在室警備処理詳細
			} else if ((G6Constant.MYCD001.UNDER_SECURITY_IN_ROOM).equals(shoriKubun) || (G6Constant.MYCD001.UNPROTECTING_IN_ROOM).equals(shoriKubun)) {
				// リクエスト情報の警備エリア番号を取得する
				List<String> lnKbAreaList = G6Common.readParamToArrayObject(mapParam, RequestParam.lnKbArea.getValue());

				String soapMsg = "";
				Map<String, String> mapSoap = null;

				// 在室警備開始処理、
				if ((G6Constant.MYCD001.UNDER_SECURITY_IN_ROOM).equals(shoriKubun)) {
					mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.ZN0,
							mapParam.get("cmdRslt").toString());

					// リクエスト情報に処理区分が「在室警備開始｣の警備エリアが存在する場合
					// 在室警備開始要求を制御信号キューに登録する
					// 10-2.在室警備開始処理ＤＢ更新内容
					soapMsg = this.getSecurityStatusCmdIn(mapSoap, lnKbAreaList);

				// 在室警備解除処理
				} else if ((G6Constant.MYCD001.UNPROTECTING_IN_ROOM).equals(shoriKubun)) {
					mapSoap = this.createParamForSoap(rCtlDevDataSubModel, cmdSeqNum, G6CodeConsts.CD055.ZF0,
							mapParam.get("cmdRslt").toString());

					// リクエスト情報に処理区分が「在室警備解除｣の警備エリアが存在する場合
					// 在室警備解除要求を制御信号キューに登録する
					// 10-3.在室警備解除処理ＤＢ更新内容
					soapMsg = this.getSecurityStatusCmdIn(mapSoap, lnKbAreaList);
				}
				final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
				mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
				mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
				mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());

				commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

				long beginTime = System.currentTimeMillis();
				int countSleep = 0;

				// プロパティファイルから取得した「タイムアウト時間」までループ
				// start loop
				while (true) {
					long nowTime = System.currentTimeMillis();
					if ((nowTime - beginTime) > timeout) {
						break;
					}

					// 制御信号キューを検索する。
					// 8-2.B) 警備解除処理終了確認
					ControlQueueStatusModel controlQueueStatusModel = sZWP0800Service.getControlQueueStsInfo(cmdSeqNum);

					if (null == controlQueueStatusModel) {
						jsonResult = G6Common.messageUpdateLogHandler(errorDataModel, 
								G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

						// 処理終了
						appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
						return jsonResult;
					}

					// 開始処理、解除処理の状態が「0：未送信」以外の場合
					if (!G6CodeConsts.CD179.UNSENT.equals(controlQueueStatusModel.getSts())) {
						// 取得したSOAP電文からkbstset_rspタグ内の実行結果(<cmd_rslt>タグ)を取得する
						String execResult = "";
						execResult = G6Common.getElementByTagName(controlQueueStatusModel.getSoapMsg(), G6Constant.CMD_RESULT);

						// 「実行結果」により処理結果を判定する
						// 開始処理、解除処理両方が　0：OK の場合
						if (G6CodeConsts.CD185.OK.equals(execResult)) {
							errorDataModel.setErrorCode(G6Constant.SUCCESS_CD);
							break;

						// 開始処理、解除処理の片方でも　2：排他エラー の場合
						} else if (G6CodeConsts.CD185.EXCLUSION_ERROR.equals(execResult)) {
							errorDataModel.setErrorCode(G6Constant.FAIL_DUPLICATE_CD);
							break;

						// 上記以外の場合
						} else {
							break;
						}

					// 開始処理、解除処理の状態が片方でも「0：未送信」の場合
					} else {
						// 待機時間が経過するまで待機する
						G6Common.sleepOperation(timeout, timeSleep, countSleep);
						countSleep++;
					}
				}
				// end loop
			}

			jsonResult = G6Common.parseJSON(errorDataModel, acntLanguage);

		} catch (ApplicationException e) {
			if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_DB_ACCESS.getValue())) {
				jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_JSON.getValue())) {
				jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_DATETIME.getValue())) {
				jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			}
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(errorDataModel, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0800Controller.deleteKeibiStartForTest()");
		return jsonResult;
	}

	private Map<String, String> createParamForSoap(RCtlDevDataSubModel rCtlDevDataSubModel, String cmdsqNo, String noStat,
			String cmdRslt) {
		Map<String, String> mapSoap = new HashMap<String, String>();

		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataSubModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, rCtlDevDataSubModel.getCustomerNum1());
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataSubModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, rCtlDevDataSubModel.getSubAddr());
		mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.KBSTSET);
		mapSoap.put(G6Constant.MYCD003.NOSTAT, noStat);
		mapSoap.put(G6Constant.MYCD003.KNSTAT, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.DNSTAT, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);
		mapSoap.put(CMD_RSLT, cmdRslt);

		mapSoap.put(G6Constant.MYCD003.HOSTNM, hostName);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.KBSTSET);
		mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.SUCCESS);

		return mapSoap;
	}

	private String getSecurityStatusCmdOut(Map<String, String> mapSoap) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
		// データ部作成
		// 共通項目タグ設定
		// 電文バージョン
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 共通クラスから取得したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<sub_adr>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_adr>");
		builder.append("<kszinf>");
		builder.append("<kbzn_no>");
		builder.append("</kbzn_no>");
		builder.append("</kszinf>");
		builder.append("<n0_stat>");
		builder.append(mapSoap.get(G6Constant.MYCD003.NOSTAT) + "</n0_stat>");
		builder.append("<kn_stat>");
		builder.append(mapSoap.get(G6Constant.MYCD003.KNSTAT) + "</kn_stat>");
		builder.append("<dn_stat>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DNSTAT) + "</dn_stat>");
		builder.append("<result>");
		builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		builder.append("<cmd_rslt>");
		builder.append(mapSoap.get(CMD_RSLT) + "</cmd_rslt>");
		// フッター部作成
		builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

		return builder.toString();
	}

	private String getSecurityStatusCmdIn(Map<String, String> mapSoap, List<String> lnKbAreaList) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
		// データ部作成
		// 共通項目タグ設定
		// 電文バージョン
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 共通クラスから取得したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<sub_adr>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_adr>");
		for (String lnKbArea : lnKbAreaList) {
			builder.append("<kszinf>");
			builder.append("<kbzn_no>");
			builder.append(lnKbArea + "</kbzn_no>");
			builder.append("</kszinf>");
		}
		builder.append("<n0_stat>");
		builder.append(mapSoap.get(G6Constant.MYCD003.NOSTAT) + "</n0_stat>");
		builder.append("<kn_stat>");
		builder.append(mapSoap.get(G6Constant.MYCD003.KNSTAT) + "</kn_stat>");
		builder.append("<dn_stat>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DNSTAT) + "</dn_stat>");
		builder.append("<result>");
		builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		builder.append("<cmd_rslt>");
		builder.append(mapSoap.get(CMD_RSLT) + "</cmd_rslt>");
		// フッター部作成
		builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

		return builder.toString();
	}

	/*
	 * Get data from R_DEV_STS table
	 * @param: acntID, acntNm, lnKeibi, (ＧＨＳの場合) subAddr, rDevItem, sts
	 * return: object ResGetKeibiSetteiStatus as JSON
	 */
	@RequestMapping(value = "/getKeibiSetteiStatusForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getKeibiSetteiStatusForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1000Controller.getKeibiSetteiStatusForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetKeibiSetteiStatus resGetKeibiSetteiStatus = new ResGetKeibiSetteiStatus();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntType = null;

		try {
			Map<String, Boolean> chkParamMap = null;
			RDevDataModel[] rDevDataModelArr = null;
			List<String> denkeiList = null;
			List<String> cmdSqList = new ArrayList<String>();
			List<RDevStsDataModel> rDevStsDataModelList = new ArrayList<RDevStsDataModel>();
			int remainCmdSq = 0;

			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());

				// リクエスト情報取得
				acntType = commonComService.getAccountType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 6) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatusForTest()");
				return jsonResult;
			}

			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatusForTest()");
				return jsonResult;
			}

			// アカウント種別が次期警備の場合
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// Build require parameters
				chkParamMap = new HashMap<String, Boolean>() {
					private static final long serialVersionUID = 1L;
					{
						put(RequestParam.acntID.getValue(), true);
						put(RequestParam.acntNm.getValue(), true);
						put(RequestParam.lnKeibi.getValue(), true);
						put(RequestParam.subAddr.getValue(), false);
						put(RequestParam.rDevItem.getValue(), false);
						put(RequestParam.lnKbChiku.getValue(), false);
						put("sts", true);
					}
				};

			// アカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				// Build require parameters
				chkParamMap = new HashMap<String, Boolean>() {
					private static final long serialVersionUID = 1L;
					{
						put(RequestParam.acntID.getValue(), true);
						put(RequestParam.acntNm.getValue(), true);
						put(RequestParam.lnKeibi.getValue(), true);
						put(RequestParam.subAddr.getValue(), true);
						put(RequestParam.rDevItem.getValue(), false);
						put(RequestParam.lnKbChiku.getValue(), false);
						put("sts", true);
					}
				};
			}

			if (!G6Common.checkRequire(mapParam, chkParamMap)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatusForTest()");
				return jsonResult;
			}

			rDevDataModelArr = (RDevDataModel[]) G6Common.readParamToArrayObject(mapParam, RequestParam.rDevItem.getValue(), "RDevDataModel", acntLanguage);
			final String lnKbChiku = mapParam.get(RequestParam.lnKbChiku.getValue()).toString();
			
			if (null == rDevDataModelArr || 0 == rDevDataModelArr.length) {
				// 操作履歴の出力
				// 利用者の操作履歴を出力する。
				// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//				this.saveUserOperationLog(mapParam.get(RequestParam.acntID.getValue()).toString(), mapParam.get(RequestParam.acntNm.getValue()).toString());

				resGetKeibiSetteiStatus.setErrorCode(G6Constant.SUCCESS_CD);
				resGetKeibiSetteiStatus.setDatetime(DateTimeCommon.getCurrentDateTime());
				resGetKeibiSetteiStatus.setrDevStsItem(rDevStsDataModelList);

				jsonResult = G6Common.parseJSON(resGetKeibiSetteiStatus, acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatusForTest()");
				return jsonResult;
			}

			// TODO SZWP1000：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			rDevStsDataModelList = this.mappingData(rDevDataModelArr);

			// 更新処理（次期警備の場合）
			// アカウント種別が次期警備の場合
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				// 9-2.A)電計番号の取得
				denkeiList = sZWP1000Service.getListElectricNum(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				if (denkeiList.size() == 0) {
					denkeiList.add("");
				}

				// /ループ1　リクエスト情報のLN_設置機器論理番号の数だけ繰り返す
				for (int i = 0; i < rDevDataModelArr.length; i++) {
					// 9-2.B)号機番号、シリアル番号の取得
//					List<RCtlDevDataModel> rCtlDevDataModelList = sZWP1000Service.getListGoukiSerial(rDevDataModelArr[i].getLnDev());
				    List<RCtlDevDataModel> rCtlDevDataModelList = sZWP1000Service.getListGoukiSerial(rDevDataModelArr[i].getLnDev(), lnKbChiku);
					
					if(rCtlDevDataModelList.size() == 0) {
						rCtlDevDataModelList.add(new RCtlDevDataModel());
					}

					// 共通クラスから取得したコマンドシーケンス番号
					//String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
					final String cmdSeqNum = commonService.getCmdSeq();
					
					Map<String, String> mapSoap = this.createParamForSoap1000(rCtlDevDataModelList.get(0), denkeiList.get(0), cmdSeqNum,
							G6Constant.FOURSPACE, G6Constant.MYCD006.SU000, mapParam.get("sts").toString());

					// 制御状態読出要求用のSOAP電文を作成する
					// 9-3.B)制御状態読出要求コマンド
					String soapMsg = this.createSoapMsg1000(mapSoap);
					final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
					
					mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
					mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
					mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());

					// 制御状態読出要求コマンドを登録する
					// 9-3.A)制御状態読出要求登録
					// コミットを行う
					commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

					cmdSqList.add(cmdSeqNum);
					remainCmdSq++;
				}
				// /ループ1　終了

				long beginTime = System.currentTimeMillis();
				int countSleep = 0;

				// /ループ2　タイムアウトするまで繰り返す
				while (true) {
					long nowTime = System.currentTimeMillis();
					// タイムアウト時間を超過している場合
					if ((nowTime - beginTime) > timeout) {
						// ループ2を抜ける
						break;
					}

					// /ループ3　制御状態読出要求のコマンドシーケンス番号の数だけ繰り返す
					for(int i = 0; i < cmdSqList.size(); i++) {
						if(!"".equals(cmdSqList.get(i))) {
							// 制御状態読出要求コマンドの実行状態を取得する
							// 9-2.C)コマンド状態の取得
							String controlQueueSts = sZWP1000Service.getControlQueueSts(cmdSqList.get(i));

							if (null == controlQueueSts) {
								jsonResult = G6Common.messageUpdateLogHandler(resGetKeibiSetteiStatus, 
										G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

								// 処理終了
								appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatusForTest()");
								return jsonResult;
							}

							// コマンドが「0：未送信」「1：リクエスト送信中」以外の場合
							if(!G6CodeConsts.CD179.UNSENT.equals(controlQueueSts) && !G6CodeConsts.CD179.A_REQUEST_IS_BEING_SENT.equals(controlQueueSts)) {
								// 機器の状態を取得する
								// 9-2.D)設置機器状態の取得
								String drctsetCntrSts = sZWP1000Service.getDeviceSts(rDevDataModelArr[i].getLnDev());

								rDevStsDataModelList.get(i).setDrctsetCntrSts(drctsetCntrSts);

								// 制御状態読出要求のコマンドシーケンス番号を削除する
								cmdSqList.set(i, "");
								remainCmdSq--;
							}
						}
					}
					// /ループ3　終了

					// 制御状態読出要求のコマンドシーケンス番号が残っていない場合
					if(0 == remainCmdSq) {
						// ループ2を抜ける
						break;
					}

					// 一定時間sleep後、ループ2の先頭へ
					G6Common.sleepOperation(timeout, timeSleep, countSleep);
					countSleep++;
				}
				// /ループ2　終了

			// 更新処理（ＧＨＳの場合）
			// アカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				// 9-4.A)電計番号の取得
				denkeiList = sZWP1000GhsService.getListElectricNumGHS(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				if (denkeiList.size() == 0) {
					denkeiList.add("");
				}

				// 9-4.B)号機番号、シリアル番号の取得
				RCtlDevDataModel rCtlDevDataModel = sZWP1000GhsService.getGoukiSerialGHS(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				// /ループ1　リクエスト情報のLN_設置機器論理番号の数だけ繰り返す
				for (int i = 0; i < rDevDataModelArr.length; i++) {
					// 共通クラスから取得したコマンドシーケンス番号
					//String cmdSeqNum = commonService.getNextCmdSeqNum();
					// String cmdSeqNum = commonGhsService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
				    final String cmdSeqNum = commonGhsService.getCmdSeq();
					Map<String, String> mapSoap = this.createParamForSoap1000(rCtlDevDataModel, denkeiList.get(0), cmdSeqNum,
							mapParam.get(RequestParam.subAddr.getValue()).toString(), rDevDataModelArr[i].getSdDevNum(),
							mapParam.get("sts").toString());

					// 制御状態読出要求用のSOAP電文を作成する
					// 9-5.B)制御状態読出要求コマンド
					String soapMsg = this.createSoapMsg1000(mapSoap);

					mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
					mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
					mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());

					// 制御状態読出要求コマンドを登録する
					// 9-5.A)制御状態読出要求登録
					// コミットを行う
					final String seqNo = commonGhsService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
					commonGhsService.saveEQueCtrlModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

					cmdSqList.add(cmdSeqNum);
					remainCmdSq++;
				}
				// /ループ1　終了

				long beginTime = System.currentTimeMillis();
				int countSleep = 0;

				// /ループ2　タイムアウトするまで繰り返す
				while (true) {
					long nowTime = System.currentTimeMillis();
					// タイムアウト時間を超過している場合
					if ((nowTime - beginTime) > timeout) {
						// ループ2を抜ける
						break;
					}

					// /ループ3　制御状態読出要求のコマンドシーケンス番号の数だけ繰り返す
					for(int i = 0; i < cmdSqList.size(); i++) {
						if(!"".equals(cmdSqList.get(i))) {
							// 制御状態読出要求コマンドの実行状態を取得する
							// 9-4.C)コマンド状態の取得
							String controlQueueSts = sZWP1000GhsService.getControlQueueStsGHS(cmdSqList.get(i));

							if (null == controlQueueSts) {
								jsonResult = G6Common.messageUpdateLogHandler(resGetKeibiSetteiStatus, 
										G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

								// 処理終了
								appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatusForTest()");
								return jsonResult;
							}

							// コマンドが「0：未送信」「1：リクエスト送信中」以外の場合
							if(!G6CodeConsts.CD179.UNSENT.equals(controlQueueSts) && !G6CodeConsts.CD179.A_REQUEST_IS_BEING_SENT.equals(controlQueueSts)) {
								// 機器の状態を取得する
								// 9-4.D)設置機器状態の取得
								String drctsetCntrSts = sZWP1000GhsService.getDeviceStsGHS(rDevDataModelArr[i].getLnDev());

								rDevStsDataModelList.get(i).setDrctsetCntrSts(drctsetCntrSts);

								// 制御状態読出要求のコマンドシーケンス番号を削除する
								cmdSqList.set(i, "");
								remainCmdSq--;
							}
						}
					}
					// /ループ3　終了

					// 制御状態読出要求のコマンドシーケンス番号が残っていない場合
					if(0 == remainCmdSq) {
						// ループ2を抜ける
						break;
					}

					// 一定時間sleep後、ループ2の先頭へ
					G6Common.sleepOperation(timeout, timeSleep, countSleep);
					countSleep++;
				}
				// /ループ2　終了
			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			this.saveUserOperationLog(mapParam.get(RequestParam.acntID.getValue()).toString(), mapParam.get(RequestParam.acntNm.getValue()).toString());

			resGetKeibiSetteiStatus.setErrorCode(G6Constant.SUCCESS_CD);
			resGetKeibiSetteiStatus.setDatetime(DateTimeCommon.getCurrentDateTime());
			resGetKeibiSetteiStatus.setrDevStsItem(rDevStsDataModelList);

			jsonResult = G6Common.parseJSON(resGetKeibiSetteiStatus, acntLanguage);

		} catch (ApplicationException e) {
			if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_DB_ACCESS.getValue())) {
				jsonResult = G6Common.messageLogHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_DATETIME.getValue())) {
				jsonResult = G6Common.messageLogHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_JSON.getValue())) {
				jsonResult = G6Common.messageLogHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			}
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetKeibiSetteiStatus, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1000Controller.getKeibiSetteiStatusForTest()");
		return jsonResult;
	}

//	private void saveUserOperationLog(String acntId, String acntNm) throws ApplicationException {
//		HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//		// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//		final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//		hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//		hUserOperationLogModel.setDispId(ScreenID.SZWP1000.getSlashValue());
//		hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//		commonService.entryUserOperation(hUserOperationLogModel, acntId, acntNm, DateTimeCommon.getCurrentDate());
//	}

	private List<RDevStsDataModel> mappingData(RDevDataModel[] rDevDataModelArr) {
		List<RDevStsDataModel> rDevStsDataModelList = new ArrayList<RDevStsDataModel>();

		for (RDevDataModel obj : rDevDataModelArr) {
			RDevStsDataModel rDev = new RDevStsDataModel();
			rDev.setLnDev(obj.getLnDev());
			rDev.setSdDevNm(obj.getSdDevNm());
			rDev.setSdDevNum(obj.getSdDevNum());

			rDevStsDataModelList.add(rDev);
		}

		return rDevStsDataModelList;
	}

	private Map<String, String> createParamForSoap1000(RCtlDevDataModel rCtlDevDataModel, String denkei, String cmdsqNo,
			String subAddr, String termNo, String sts) {
		Map<String, String> mapSoap = new HashMap<String, String>();

		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, denkei);
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, subAddr);
		mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.DRCTRD);
		mapSoap.put(G6Constant.MYCD003.TERMNO, termNo);
		mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);

		mapSoap.put(G6Constant.MYCD003.HOSTNM, hostName);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, termNo);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.DRCT_RD);
		mapSoap.put(G6Constant.MYCD003.STS, sts);

		return mapSoap;
	}

	private String createSoapMsg1000(Map<String, String> mapSoap) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
		// データ部作成
		// 共通項目タグ設定
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 9-3.-A)に設定したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<term_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TERMNO) + "</term_no>");
		builder.append("<result>");
		builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		// フッター部作成
		builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

		return builder.toString();
	}

	/*
	 * Get data from R_DEV_STS table
	 * @param: acntID, acntNm, lnKeibi, lnKbChiku, lnDev, sdDevNum, cntrSt, drctsetCntrSts, sts
	 * return: object ResSetRemoteDev as JSON
	 */
	@RequestMapping(value = "/setRemoteDevForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String setRemoteDevForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1100Controller.setRemoteDevForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		String denkeiNum = "";
		RCtlDevDataSubModel rCtlDevDataModel = new RCtlDevDataSubModel();
		RKbChikuDataSubModel rKbChikuDataModel = new RKbChikuDataSubModel();
		Map<String, Object> mapParam = new HashMap<String, Object>();

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 9) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDevForTest()");
				return jsonResult;
			}

			// リクエスト情報検証
			List<String> chkParamList = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.lnKeibi.getValue());
					add(RequestParam.lnKbChiku.getValue());
					add(RequestParam.lnDev.getValue());
					add(RequestParam.sdDevNum.getValue());
					add(RequestParam.cntrSt.getValue());
					add("sts");
					add("drctsetCntrSts");
				}
			};

			if (!G6Common.checkRequire(mapParam, chkParamList)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDevForTest()");
				return jsonResult;
			}

			// unused: リクエスト情報取得

			// TODO SZWP1100：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 設定処理
			// 7-2.A)電計番号の取得
			denkeiNum = sZWP1100Service.getElectricNum(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

			// 7-2.B)号機番号、シリアル番号の取得
			rCtlDevDataModel = sZWP1100Service.getGoukiSerial(
					mapParam.get(RequestParam.lnKeibi.getValue()).toString());

			// 7-2.C)地区情報の取得
			rKbChikuDataModel = sZWP1100Service.getDistrictInfo(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

			// シリアル番号が設定されていない場合
			if ("".equals(rCtlDevDataModel.getSerialNum().trim())) {
				// エラーメッセージを画面に表示する
				jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_SERIALNUM_NOT_FOUND.getValue(), acntLanguage);
				
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDevForTest()");
				return jsonResult;
			}

			//String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
			final String cmdSeqNum = commonService.getCmdSeq();
			String soapMsg = "";
			Map<String, String> mapSoap = null;
			//String nextLnQueCtrlSig = commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
			final String nextLnQueCtrlSig = commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
			
			String cntrSt = mapParam.get(RequestParam.cntrSt.getValue()).toString();
			String sts = mapParam.get("sts").toString();

			mapSoap = this.createParamForSoap1100(rCtlDevDataModel, denkeiNum, cmdSeqNum, rKbChikuDataModel.getSubAddr(),
					mapParam.get(RequestParam.sdDevNum.getValue()).toString(), cntrSt, sts);

			// 「ON/OFF設定」ボタンが実行された場合
			if (G6CodeConsts.CD004.ON.equals(cntrSt)
					|| G6CodeConsts.CD004.OFF.equals(cntrSt)) {
				// 7-3.B)ダイレクト制御コマンド(ON設定)
				soapMsg = this.createSoapMsg1100(mapSoap);
			}

			mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
			mapSoap.put(RequestParam.acntID.getValue(), mapParam.get(RequestParam.acntID.getValue()).toString());
			mapSoap.put(RequestParam.acntNm.getValue(), mapParam.get(RequestParam.acntNm.getValue()).toString());

			final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);

			// 7-3.A)ダイレクト制御コマンド登録
			commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

			// 操作履歴情報にダイレクト制御操作を登録する
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//			hUserOperationLogModel.setLnLogUserOperation(nextLnQueCtrlSig);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP1100.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), mapParam.get(RequestParam.acntNm.getValue()).toString(), DateTimeCommon.getCurrentDate());

			// 操作状況取得
			long beginTime = System.currentTimeMillis();

			// プロパティファイルから取得した「タイムアウト時間」までループする
			while (true) {
				// 制御状態読出の結果を取得する
				// 7-2.D)コマンド状態の取得
				String cmdSts = sZWP1100Service.getCmdSts(cmdSeqNum);

				if (null == cmdSts) {
					jsonResult = G6Common.messageUpdateLogHandler(resSetRemoteDev, 
							G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDevForTest()");
					return jsonResult;
				}

				// 取得成功の場合(S：成功)
				if(G6CodeConsts.CD179.SUCCESS.equals(cmdSts)) {
					// 設置機器の状態を取得する
					// 7-2.E)設置機器状態の取得
					String deviceSts = mapParam.get("drctsetCntrSts").toString();

					resSetRemoteDev.setErrorCode(G6Constant.SUCCESS_CD);
					resSetRemoteDev.setLnDev(mapParam.get(RequestParam.lnDev.getValue()).toString());
					resSetRemoteDev.setDrctsetCntrSts(deviceSts);

					jsonResult = G6Common.parseJSON(resSetRemoteDev, acntLanguage);

					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDevForTest()");
					return jsonResult;

				// 取得失敗の場合(3:レスポンス受理(OK以外) E:エラー T：タイムアウト)
				} else if(G6CodeConsts.CD179.RESPONSE_ACCEPTANCE_BESIDES_OK.equals(cmdSts) || 
						G6CodeConsts.CD179.ERROR.equals(cmdSts) || 
						G6CodeConsts.CD179.TIME_OUT.equals(cmdSts)) {
					// エラーメッセージを設定する
					jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD,
							ErrorKey.ERROR_CONTROL_QUEUE_STATUS.getValue(), acntLanguage);

					// 処理終了
					appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDevForTest()");
					return jsonResult;
				}

				long nowTime = System.currentTimeMillis();

				if ((nowTime - beginTime) > timeout) {
					break;
				}
			}

			// 「タイムアウト時間」まで経過している場合
			// タイムアウトのエラーメッセージを設定する
			// リソースより以下のキーも文字列を取得する
			// error.deliverySetting.readTimeout
			jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD,
					ErrorKey.ERROR_DELIVERYSETTING_READTIMEOUT.getValue(), acntLanguage);

		} catch (ApplicationException e) {
			if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_DB_ACCESS.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_DATETIME.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_JSON.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			}
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDevForTest()");
		return jsonResult;
	}

	private Map<String, String> createParamForSoap1100(RCtlDevDataSubModel rCtlDevDataModel, String denkei, String cmdsqNo,
			String subAddr, String termNo, String cntrSt, String sts) {
		Map<String, String> mapSoap = new HashMap<String, String>();

		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, denkei);
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, subAddr);
		mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.DRCTSET);
		mapSoap.put(G6Constant.MYCD003.TERMNO, termNo);
		mapSoap.put(G6Constant.MYCD003.CNTRST, cntrSt);
		mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);

		mapSoap.put(G6Constant.MYCD003.HOSTNM, hostName);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, termNo);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.DWLDCOR);
		mapSoap.put(G6Constant.MYCD003.STS, sts);

		return mapSoap;
	}

	private String createSoapMsg1100(Map<String, String> mapSoap) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
		// データ部作成
		// 共通項目タグ設定
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 共通クラスから取得したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<term_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TERMNO) + "</term_no>");
		builder.append("<cntr_st>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CNTRST) + "</cntr_st>");
		builder.append("<result>");
		builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		// フッター部作成
		builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

		return builder.toString();
	}
	/*
	 * Get data from R_DEV_STS table
	 * @param: acntID, acntNm, lnKeibi, lnKbChiku, lnDev, sdDevNum, cntrSt, drctsetCntrSts, sts
	 * return: object ResSetRemoteDev as JSON
	 */
	@RequestMapping(value = "/mediaServer2700ForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String mediaServer2700ForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2700Controller.mediaServer2700ForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		String denkeiNum = "";
		RCtlDevDataSubModel rCtlDevDataModel = new RCtlDevDataSubModel();
		RKbChikuDataSubModel rKbChikuDataModel = new RKbChikuDataSubModel();
		Map<String, Object> mapParam = new HashMap<String, Object>();

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("url", SZWP2700_URL );
			params.put("mem_data_list", SZWP2700_mem_data_list);
			params.put("result", SZWP2700_Result);
			jsonResult = G6Common.parseJSON(params, acntLanguage);
		} catch (ApplicationException e) {
			if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_DB_ACCESS.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_DATETIME.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_JSON.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			}
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDevForTest()");
		return jsonResult;
	}
	/*
	 * Get data from R_DEV_STS table
	 * @param: acntID, acntNm, lnKeibi, lnKbChiku, lnDev, sdDevNum, cntrSt, drctsetCntrSts, sts
	 * return: object ResSetRemoteDev as JSON
	 */
	@RequestMapping(value = "/getDownloadIpPortForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getDownloadIpPortForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2800Controller.getDownloadIpPortForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		Map<String, Object> mapParam = new HashMap<String, Object>();

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("live_ip", SZWP2800_Live_Ip);
			params.put("download_port", SZWP2800_Download_Port);
			params.put("result", SZWP2800_Result);
			jsonResult = G6Common.parseJSON(params, acntLanguage);
		} catch (ApplicationException e) {
			if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_DB_ACCESS.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_DATETIME.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_JSON.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			}
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.getDownloadIpPortForTest()");
		return jsonResult;
	}
	/*
	 * Get data from R_DEV_STS table
	 * @param: acntID, acntNm, lnKeibi, lnKbChiku, lnDev, sdDevNum, cntrSt, drctsetCntrSts, sts
	 * return: object ResSetRemoteDev as JSON
	 */
	@RequestMapping(value = "/mediaServer2300_009ForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String mediaServer2300_009ForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "mediaServer2300_009ForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		String denkeiNum = "";
		RCtlDevDataSubModel rCtlDevDataModel = new RCtlDevDataSubModel();
		RKbChikuDataSubModel rKbChikuDataModel = new RKbChikuDataSubModel();
		Map<String, Object> mapParam = new HashMap<String, Object>();

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			Map<String, Object> params = new HashMap<String, Object>();
			Map<String, Object> resParams = new HashMap<String, Object>();
			params.put("result",szwp2900_009_Result);
			params.put("ptz_enable_flg", szwp2900_009_Ptz_Enable_Flg);
			params.put("preset_status", szwp2900_009_Preset_Status);
			params.put("frame_rate", szwp2900_009_Frame_Rate);
			params.put("img_quality", szwp2900_009_Img_Quality);
			params.put("param_set_flg", szwp2900_009_Param_Set_Flg);
			params.put("has_ope_auth", szwp2900_009_Has_Ope_Auth);
			//params.put("call_port", szwp2900_009_Call_Port);
			//params.put("call_ip", szwp2900_009_Call_Ip);
			params.put("acnt_type_for_ope", szwp2900_009_Acnt_Type_For_Ope);
			params.put("ln_acnt_user_common_for_ope", szwp2900_009_Ln_Acnt_User_Common_For_Ope);
			//params.put("strem_id", szwp2900_009_Strem_Id);
			//params.put("img_ip", szwp2900_009_Img_Ip);
			params.put("acnt_name", szwp2900_009_Acnt_Name);
			//params.put("trans_flg", szwp2900_009_Trans_Flg);
			if(mapParam.get("ln_dev").equals("20181030230000001006")
			|| mapParam.get("ln_dev").equals("20181030230000001100")){
				params.put("url", szwp2900_009_URL);
			} else if(mapParam.get("ln_dev").equals("20181030230000001101")
			|| mapParam.get("ln_dev").equals("20181030230000001102")){ 
				params.put("url", szwp2900_009_URL2);
			}
			resParams.put("alive_monitor", params);
			if(mapParam.get(G6Constant.RequestParam.ope_form_id.getValue()).equals("SZWP2300_000")){
				jsonResult = G6Common.parseJSON(resParams, acntLanguage);
				jsonResult = jsonResult.replace(":{", ":[{");
				jsonResult = jsonResult.replace("}}", "}]}");
			} else {
				jsonResult = G6Common.parseJSON(params, acntLanguage);
			}
		} catch (ApplicationException e) {
			if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_DB_ACCESS.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_DATETIME.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_JSON.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			}
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "mediaServer2300_009ForTest()");
		return jsonResult;
	}
	@RequestMapping(value = "/media_api_2300_camctrlForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String media_api_2300_camctrlForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "mediaServer2300_009ForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		String denkeiNum = "";
		RCtlDevDataSubModel rCtlDevDataModel = new RCtlDevDataSubModel();
		RKbChikuDataSubModel rKbChikuDataModel = new RKbChikuDataSubModel();
		Map<String, Object> mapParam = new HashMap<String, Object>();

		try {
			mapParam = G6Common.readParam(strParam);
			Map<String, Boolean> mapRequireParam = new HashMap<String, Boolean>();
			mapRequireParam.put("ope_form_id", true);
			// リクエスト情報からパラメータを取得する
			Map<String, Object> params = new HashMap<String, Object>();
			//String opeFormId = mapParam.get("ope_form_id").toString();
			params.put("has_ope_auth", SZWP2300_CAMCTRL_Has_Ope_Auth);
			params.put("acnt_type_for_ope", SZWP2300_CAMCTRL_Acnt_Type_For_Ope);
			params.put("ln_dev_lst", SZWP2300_CAMCTRL_Ln_Dev_Lst);
			params.put("acnt_name", SZWP2300_CAMCTRL_Acnt_Name);
			//if(G6Constant.OpeFromID.SZWU2900_016.getValue().equals(opeFormId) || G6Constant.OpeFromID.SZWU2900_017.getValue().equals(opeFormId)) {
			//	params.put("call_port_list", SZWP2300_CAMCTRL_Call_Port_List);
			//	params.put("call_ip_list", SZWP2300_CAMCTRL_Call_Ip_List);
			//	params.put("result_list", SZWP2300_CAMCTRL_Result_List);
			//} else {
				params.put("result", SZWP2300_CAMCTRL_Result);
			//}
			jsonResult = G6Common.parseJSON(params, acntLanguage);
		} catch (ApplicationException e) {
			if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_DB_ACCESS.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_DATETIME.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			} else if (e.getExceptionCode().equals(ErrorKey.EXCEPTION_PARSE_JSON.getValue())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
			}
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "mediaServer2300_009ForTest()");
		return jsonResult;
	}
	@RequestMapping(value = "/media_api_2500_stopLiveImageForTest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String media_api_2500_stopLiveImageForTest(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "media_api_2500_stopLiveImageForTest()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		try {
		    
			// リクエスト情報からパラメータを取得する
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("result",SZWP2300_STOPLIVEIMG_Result);
			jsonResult = G6Common.parseJSON(params, acntLanguage);
		} catch (Exception e) {
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "media_api_2500_stopLiveImageForTest()");
		return jsonResult;
	}
}
