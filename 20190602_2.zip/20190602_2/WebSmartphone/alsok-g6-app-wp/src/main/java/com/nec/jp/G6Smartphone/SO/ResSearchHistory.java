package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResSearchHistory implements ErrorHandler {

	private String errorCode;						// エラーコード
	private String errorMsg;						// エラーメッセージ
	private List<HistoryDataModel> historyItem;
	private String acntID;
	private String totalPage; 						//トタルページ


	public ResSearchHistory() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.historyItem = new ArrayList<HistoryDataModel>();
		this.acntID = "";
		this.totalPage = "0";
	}

	public ResSearchHistory(String errorCode, String errorMsg, List<HistoryDataModel> historyItem, String totalPage) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.historyItem = historyItem;
		this.acntID = "";
		this.totalPage = totalPage;
	}

	public String getTotalPage() {
		return totalPage;
	}
	
	public void setTotalPage(String totalPage) {
		this.totalPage = totalPage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<HistoryDataModel> getHistoryItem() {
		return historyItem;
	}

	public void setHistoryItem(List<HistoryDataModel> historyItem) {
		this.historyItem = historyItem;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
