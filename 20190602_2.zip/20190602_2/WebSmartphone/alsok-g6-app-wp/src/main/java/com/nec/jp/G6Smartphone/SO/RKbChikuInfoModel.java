package com.nec.jp.G6Smartphone.SO;

public class RKbChikuInfoModel implements DataModelHandler {

	private String lnKbChiku;
	private String lnKeibi;
	private String chiku;
	private String subAddr;
	private String sdKobetuNm;
	private String gyoumuCd;
	private String hosokuCd;
	

	public RKbChikuInfoModel() {
		this.lnKbChiku= "";
		this.lnKeibi= "";
		this.chiku= "";
		this.subAddr= "";
		this.sdKobetuNm= "";
		this.gyoumuCd= "";
		this.hosokuCd= "";
	}
	
	public RKbChikuInfoModel(String lnKbChiku, String lnKeibi, String chiku, String subAddr, String sdKobetuNm, String gyoumuCd, String hosokuCd) {
		this.lnKbChiku = lnKbChiku;
		this.lnKeibi = lnKeibi;
		this.chiku = chiku;
		this.subAddr = subAddr;
		this.sdKobetuNm = sdKobetuNm;
		this.gyoumuCd = gyoumuCd;
		this.hosokuCd = hosokuCd;
	}

	public String getLnKbChiku() {
		return lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getLnKeibi() {
		return lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getChiku() {
		return chiku;
	}

	public void setChiku(String chiku) {
		this.chiku = chiku;
	}

	public String getSubAddr() {
		return subAddr;
	}

	public void setSubbAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public String getSdKobetuNm() {
		return sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}

	public String getGyoumuCd() {
		return gyoumuCd;
	}

	public void setGyoumuCd(String gyoumuCd) {
		this.gyoumuCd = gyoumuCd;
	}

	public String getHosokuCd() {
		return hosokuCd;
	}

	public void setHosokuCd(String hosokuCd) {
		this.hosokuCd = hosokuCd;
	}
}
