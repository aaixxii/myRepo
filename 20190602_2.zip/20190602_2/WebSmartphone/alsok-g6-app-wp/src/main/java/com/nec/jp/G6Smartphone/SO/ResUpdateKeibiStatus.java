package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResUpdateKeibiStatus implements ErrorHandler {

	private String errorCode;
	private String errorMsg;
	private List<AreaSensorDataModel> areaSensorItem;
	private String acntID;	// アカウントID

	public ResUpdateKeibiStatus() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.areaSensorItem = new ArrayList<AreaSensorDataModel>();
		this.acntID = "";
	}

	public ResUpdateKeibiStatus(String errorCode, String errorMsg, List<AreaSensorDataModel> areaSensorItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.areaSensorItem = areaSensorItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public List<AreaSensorDataModel> getAreaSensorItem() {
		return areaSensorItem;
	}
	public void setAreaSensorItem(List<AreaSensorDataModel> areaSensorItem) {
		this.areaSensorItem = areaSensorItem;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
