package com.nec.jp.G6Smartphone.service.g6;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.dao.g6.SZWP1600Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1600Service {

	@Autowired
	SZWP1600Dao sZWP1600Dao;

	public String getScreenInfoList(String lnKbInf) throws ApplicationException {
		try {
			String videoFileName = sZWP1600Dao.getScreenInfoList(lnKbInf);

			return videoFileName;

		} catch (NoResultException noResultE) {
			return "";

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
