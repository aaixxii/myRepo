package com.nec.jp.G6Smartphone.dao.ghs;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.AcntUserAuthModel;


@Repository
public class SZWP0200GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	public AcntUserAuthModel getMenuDisplayAuthorityByAcntId(String acntID) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT ");
		strBuilder.append(" 	IFNULL(R_ACNT_USER_AUTH.FLG_KB_SET_DISP, '') as flgKbSetDisp,");
		strBuilder.append(" 	IFNULL(R_ACNT_USER_AUTH.FLG_KB_HST_DISP, '') as flgKbHstDisp,");
		strBuilder.append(" 	IFNULL(R_ACNT_USER_AUTH.FLG_RMT_KB_SET_DISP, '') as flgRmtKbSetDisp,");
		strBuilder.append(" 	IFNULL(R_ACNT_USER_AUTH.FLG_KNRN_DISP, '') as flgKnrnDisp,");
		strBuilder.append(" 	IFNULL(R_ACNT_USER_AUTH.FLG_WASURE_DISP, '') as flgWasureDisp,");
		strBuilder.append(" 	IFNULL(R_ACNT_USER_AUTH.FLG_KUSITU_DISP, '') as flgKusituDisp,");
		strBuilder.append(" 	IFNULL(R_ACNT_USER_AUTH.FLG_CARD_DISP, '') as flgCardDisp");
		strBuilder.append(" FROM R_ACNT_USER_AUTH");
		strBuilder.append(" INNER JOIN R_KB_CHIKU ON R_KB_CHIKU.LN_KB_CHIKU = R_ACNT_USER_AUTH.LN_KB_CHIKU");
		strBuilder.append(" WHERE R_KB_CHIKU.ENTRY_STS = '1'");
		strBuilder.append(" 	AND R_KB_CHIKU.SUB_ADDR != ''");
		strBuilder.append(" 	AND R_ACNT_USER_AUTH.LN_ACNT_USER = :acntID");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "AcntUserAuthModelResult");
		query.setParameter("acntID", acntID);
		query.setMaxResults(1);

		return (AcntUserAuthModel) query.getSingleResult();
	}
	
	public String getSdLineKind(String lnkeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	R_CTL_DEV.SD_LINE_KIND as lineKind");
		strBuilder.append(" FROM	R_CTL_DEV");
		strBuilder.append(" WHERE	R_CTL_DEV.LN_KEIBI = :lnkeibi");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnkeibi", lnkeibi);

		return query.getSingleResult().toString();
	}
	
	public String getKeiykServiceInfo(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT      RTM.FLG_WEB_USE");
		strBuilder.append(" FROM        R_TENANT_MNG RTM");
		strBuilder.append(" INNER JOIN R_KEIBI RK");
		strBuilder.append(" ON RTM.LN_KEIBI = RK.LN_KEIBI");
		strBuilder.append(" WHERE RTM.LN_KEIBI = :lnKeibi");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		
		return query.getSingleResult().toString();
	}
	
	public String getKeibiSetPrivilegeInfo(String lnAcntUser, String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT      RAUA.FLG_KB_SET_DISP");
		strBuilder.append(" FROM        R_ACNT_USER_AUTH RAUA");
		strBuilder.append(" WHERE       RAUA.LN_ACNT_USER = :lnAcntUser");
		strBuilder.append(" AND         RAUA.LN_KB_CHIKU IN (SELECT RKB.LN_KB_CHIKU FROM R_KB_CHIKU RKB WHERE RKB.LN_KEIBI = :lnKeibi)");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUser", lnAcntUser);
		query.setParameter("lnKeibi", lnKeibi);
		
		return query.getSingleResult().toString();
	}
	
	public String getKeibiHstPrivilegeInfo(String lnAcntUser, String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT      RAUA.FLG_KB_HST_DISP");
		strBuilder.append(" FROM        R_ACNT_USER_AUTH RAUA");
		strBuilder.append(" WHERE       RAUA.LN_ACNT_USER = :lnAcntUser");
		strBuilder.append(" AND         RAUA.LN_KB_CHIKU IN (SELECT RKB.LN_KB_CHIKU FROM R_KB_CHIKU RKB WHERE RKB.LN_KEIBI = :lnKeibi)");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUser", lnAcntUser);
		query.setParameter("lnKeibi", lnKeibi);
		
		return query.getSingleResult().toString();
	}
	
	public String getRmtSetPrivilegeInfo(String lnAcntUser, String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT      RAUA.FLG_RMT_KB_SET_DISP");
		strBuilder.append(" FROM        R_ACNT_USER_AUTH RAUA");
		strBuilder.append(" WHERE       RAUA.LN_ACNT_USER = :lnAcntUser");
		strBuilder.append(" AND         RAUA.LN_KB_CHIKU IN (SELECT RKB.LN_KB_CHIKU FROM R_KB_CHIKU RKB WHERE RKB.LN_KEIBI = :lnKeibi)");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUser", lnAcntUser);
		query.setParameter("lnKeibi", lnKeibi);
		
		return query.getSingleResult().toString();
	}
}
