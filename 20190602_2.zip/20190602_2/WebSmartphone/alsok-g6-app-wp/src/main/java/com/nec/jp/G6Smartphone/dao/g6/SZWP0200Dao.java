package com.nec.jp.G6Smartphone.dao.g6;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.ItmesAuthInfoModel;
import com.nec.jp.G6Smartphone.SO.ResMenuPassInf;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.utility.G6Constant;

@Repository
public class SZWP0200Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	/**
	 * メニューパス情報の取得。
     * SELECT
     *     利用者権限マスター.利用者アカウント権限名称
     *     利用者権限マスター.メニューパス情報
     * FROM
     *     利用者ロール.LN_利用者ロール論理番号 = 利用者ロール-権限連関.LN_利用者ロール論理番号
     *     利用者アカウント-ロール連関.LN_利用者ロール論理番号 = 利用者ロール.LN_利用者ロール論理番号
     *     利用者ロール-権限連関.利用者アカウント権限ID = 利用者権限マスター.利用者アカウント権限ID
     * WHERE
     *     利用者アカウント-ロール連関.LN_利用者アカウント共通論理番号 = セッション管理のLN_利用者アカウント共通論理番号
	 * @param lnAcntUserCommon
	 * @return a object include {利用者アカウント-ロール連関.LN_利用者アカウント共通論理番号, 利用者権限マスター.利用者アカウント権限名称, 利用者権限マスター.メニューパス情報}
	 */
	public ResMenuPassInf getMenuPassInfo(String lnAcntUserCommon) {
		final StringBuilder strBuilder = new StringBuilder();
//        strBuilder.append(" SELECT NEW com.nec.jp.G6Smartphone.SO.ResMenuPassInf(T1.id.lnAcntUserCommon, T4.userAcntAuthNm, T4.menupassInf)");
//        strBuilder.append(" FROM AAcntUserRoleModel T1");
//        strBuilder.append(" INNER JOIN AUserRoleModel T2 ON T2.lnUserRole = T1.id.lnUserRole");
//        strBuilder.append(" INNER JOIN AUserRoleAuthModel T3 ON T3.id.lnUserRole = T2.lnUserRole");
//        strBuilder.append(" INNER JOIN AUserAcntAuthMstModel T4 ON T4.lnUserAcntAuthId = T3.id.lnUserAcntAuthId");
//        strBuilder.append(" WHERE T1.id.lnAcntUserCommon = :lnAcntUserCommon");
//		  final Query query = entityManager.createQuery(strBuilder.toString(), ResMenuPassInf.class);
//		  query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
//		  // LIMIT 1
//		  query.setMaxResults(1);
		
		strBuilder.append(" SELECT");
        strBuilder.append(" T1.LN_ACNT_USER_COMMON as lnAcntUserCommon,");
        strBuilder.append(" IFNULL(T4.USER_ACNT_AUTH_NM, '') as userAcntAuthNm,");
        strBuilder.append(" IFNULL(T4.MENUPASS_INF, '') as menupassInf");
        strBuilder.append(" FROM");
        strBuilder.append(" A_ACNT_USER_ROLE T1");
        strBuilder.append(" INNER JOIN A_USER_ROLE T2 ON T2.LN_USER_ROLE = T1.LN_USER_ROLE");
        strBuilder.append(" INNER JOIN A_USER_ROLE_AUTH T3 ON T3.LN_USER_ROLE = T2.LN_USER_ROLE");
        strBuilder.append(" INNER JOIN A_USER_ACNT_AUTH_MST T4 ON T4.LN_USER_ACNT_AUTH_ID = T3.LN_USER_ACNT_AUTH_ID");
        strBuilder.append(" WHERE");
        strBuilder.append(" T1.LN_ACNT_USER_COMMON = :lnAcntUserCommon");
        strBuilder.append(" LIMIT 1");
        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "ResMenuPassInfResult");
        query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
        
		return (ResMenuPassInf) query.getSingleResult();
	}

	 /**
     * メニュー大項目表示権限の取得.
     *
     * @param acntUserKbn
     * @param lnUserRole
     * @return 利用者アカウント情報
     */
	@SuppressWarnings("unchecked")
	public List<ItmesAuthInfoModel> selectBigItmesAuth(String acntUserKbn, String lnUserRole) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT");
        strBuilder.append(" 	IFNULL(uaa1.MENUPASS_INF, '') as menupassInf,");
        strBuilder.append(" 	IFNULL(uaa1.USER_ACNT_AUTH_NM, '') as userAcntAuthNm,");
        strBuilder.append(" 	MAX(CASE WHEN d.YUKO_ACNT_USER_KBN >= :acntUserKbn");
        strBuilder.append(" 		THEN IFNULL(ura.AUTH, CASE WHEN :acntUserKbn = '0' THEN '2' ELSE '0' END) ELSE '0' END) AS menuAuth");
        strBuilder.append(" FROM M_DISP d");
        strBuilder.append(" INNER JOIN A_USER_ACNT_AUTH_MST uaa1 ON uaa1.MENUPASS_INF = LEFT(d.MENUPASS_INF, 2)");
        strBuilder.append(" INNER JOIN A_USER_ACNT_AUTH_MST uaa2 ON uaa2.MENUPASS_INF = LEFT(d.MENUPASS_INF, 4)");
        strBuilder.append(" LEFT JOIN A_USER_ROLE_AUTH ura ON uaa2.LN_USER_ACNT_AUTH_ID = ura.LN_USER_ACNT_AUTH_ID");
        strBuilder.append(" 	AND ura.LN_USER_ROLE = :lnUserRole");
        strBuilder.append(" LEFT JOIN A_USER_ROLE ur ON ura.LN_USER_ROLE = ur.LN_USER_ROLE AND ur.LN_USER_ROLE = :lnUserRole");
        strBuilder.append(" WHERE d.DISP_ID LIKE CONCAT('U','%')");
        strBuilder.append(" GROUP BY uaa1.MENUPASS_INF, uaa1.USER_ACNT_AUTH_NM");
        strBuilder.append(" ORDER BY uaa1.MENUPASS_INF");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "ItmesAuthInfoModelResult");
		query.setParameter("acntUserKbn", acntUserKbn);
		query.setParameter("lnUserRole", lnUserRole);
		
		return (List<ItmesAuthInfoModel>) query.getResultList();
	}

	/**
     * メニュー小項目表示権限の取得.
     *
     * @param acntUserKbn
     * @param lnUserRole
     * @return 利用者アカウント情報
     */
	@SuppressWarnings("unchecked")
	public List<ItmesAuthInfoModel> selectSmallItmesAuth(String acntUserKbn, String lnUserRole) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT");
        strBuilder.append(" 	IFNULL(uaa2.MENUPASS_INF, '') as menupassInf,");
        strBuilder.append(" 	IFNULL(uaa2.USER_ACNT_AUTH_NM, '') as userAcntAuthNm,");
        strBuilder.append(" 	MAX(CASE WHEN d.YUKO_ACNT_USER_KBN >= :acntUserKbn");
        strBuilder.append(" 		THEN IFNULL(ura.AUTH, CASE WHEN :acntUserKbn = '0' THEN '2' ELSE '0' END) ELSE '0' END) AS menuAuth");
        strBuilder.append(" FROM M_DISP d");
        strBuilder.append(" INNER JOIN A_USER_ACNT_AUTH_MST uaa2 ON uaa2.MENUPASS_INF = LEFT(d.MENUPASS_INF, 4)");
        strBuilder.append(" LEFT JOIN A_USER_ROLE_AUTH ura ON uaa2.LN_USER_ACNT_AUTH_ID = ura.LN_USER_ACNT_AUTH_ID ");
        strBuilder.append(" 	AND ura.LN_USER_ROLE = :lnUserRole");
        strBuilder.append(" LEFT JOIN A_USER_ROLE ur ON ura.LN_USER_ROLE = ur.LN_USER_ROLE");
        strBuilder.append(" 	AND ur.LN_USER_ROLE = :lnUserRole");
        strBuilder.append(" WHERE d.DISP_ID LIKE CONCAT('U', '%')");
        strBuilder.append(" GROUP BY uaa2.MENUPASS_INF, uaa2.USER_ACNT_AUTH_NM");
        strBuilder.append(" ORDER BY uaa2.MENUPASS_INF");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "ItmesAuthInfoModelResult");
		query.setParameter("acntUserKbn", acntUserKbn);
		query.setParameter("lnUserRole", lnUserRole);
		
		return (List<ItmesAuthInfoModel>) query.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<Character> getPrivilegeInfo(String lnAcntUserCommon, String lnUserAcntAuthId) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT      AURA.AUTH");
		strBuilder.append(" FROM        A_ACNT_USER AAU");
		strBuilder.append(" LEFT JOIN   A_ACNT_USER_ROLE AAUR");
		strBuilder.append(" ON          AAU.LN_ACNT_USER_COMMON = AAUR.LN_ACNT_USER_COMMON");
		strBuilder.append(" LEFT JOIN   A_USER_ROLE_AUTH AURA");
		strBuilder.append(" ON          AAUR.LN_USER_ROLE = AURA.LN_USER_ROLE");
		strBuilder.append(" LEFT JOIN   A_USER_ACNT_AUTH_MST AUAAM");
		strBuilder.append(" ON          AURA.LN_USER_ACNT_AUTH_ID = AUAAM.LN_USER_ACNT_AUTH_ID");
		strBuilder.append(" WHERE       AAU.LN_ACNT_USER_COMMON = :lnAcntUserCommon");
		strBuilder.append(" AND         AAU.CHECK_STS = :checkSts");
		strBuilder.append(" AND         AURA.LN_USER_ACNT_AUTH_ID = :lnUserAcntAuthId");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
		query.setParameter("checkSts", G6CodeConsts.CD077.COMPLETING_REGISTRATION);
		query.setParameter("lnUserAcntAuthId", lnUserAcntAuthId);

		return query.getResultList();
	}
	
	public String getCamCountInfo(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT		COUNT(*)");
		strBuilder.append(" FROM        R_DEV RD");
		strBuilder.append(" WHERE       RD.LN_KEIBI = :lnKeibi");
		strBuilder.append(" AND         RD.DEV_KIND IN ('01', '03' ,'04', '05')");
		strBuilder.append(" AND         RD.DEL_FLG = :delFlg");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		
		return query.getSingleResult().toString();
	}
	
}
