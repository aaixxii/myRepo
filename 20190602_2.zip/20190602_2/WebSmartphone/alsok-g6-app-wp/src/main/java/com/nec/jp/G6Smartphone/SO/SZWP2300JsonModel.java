package com.nec.jp.G6Smartphone.SO;

import java.io.Serializable;

public class SZWP2300JsonModel implements Serializable {

	private static final long serialVersionUID = 1L;
	/** 利用者アカウント共通論理番号 */
	private String ln_acnt_user_common;
	/** 画面ID */
	private String screen_id;
	/** 操作フォームID */
	private String ope_form_id;
	/** LN_警備先地区論理番号 */
	private String ln_kb_chiku;
	/** 解像度(画像サイズ） */
	private String img_quality;
	/** フレームレート(01-30,デフォルト05) */
	private String frame_rate;
	/** LN_設置機器論理番号 */
	private Object ln_dev;
//	/** アカウント種別 */
//	private String acnt_type_for_ope;
	/** ダイアログで選択した結果 */
	private String selected_for_dialog;
	/** PTZ情報（パン） */
	private String pan;
	/** PTZ情報（チルト） */
	private String tilt;
	/** PTZ情報（ズーム） */
	private String zoom;
	/** プリセット情報（プリセット番号） */
	private String preset_num;
	/** プリセット情報（制御区分） */
	private String control_kbn;
	/** アカウント論理番号 */
	private String ln_acnt_user_common_for_ope;
	/** カメラ番号 */
	private String camera_num;

	
	public String getLn_acnt_user_common_for_ope() {
		return ln_acnt_user_common_for_ope;
	}

	public void setLn_acnt_user_common_for_ope(String ln_acnt_user_common_for_ope) {
		this.ln_acnt_user_common_for_ope = ln_acnt_user_common_for_ope;
	}

	public String getCamera_num() {
		return camera_num;
	}

	public void setCamera_num(String camera_num) {
		this.camera_num = camera_num;
	}

	public SZWP2300JsonModel() {
	    /** 利用者アカウント共通論理番号 */
	    this.ln_acnt_user_common = "";
	    /** 画面ID */
	    this.screen_id = "";
	    /** 操作フォームID */
	    this.ope_form_id = "";
	    /** LN_警備先地区論理番号 */
	    this.ln_kb_chiku = "";
	    /** 解像度(画像サイズ） */
	    this.img_quality = "";
	    /** フレームレート(01-30,デフォルト05) */
	    this.frame_rate = "";
	    /** LN_設置機器論理番号 */
	    this.ln_dev = "";
//	    /** アカウント種別 */
//	    this.acnt_type_for_ope = "";
	    /** ダイアログで選択した結果 */
	    this.selected_for_dialog = "";
	    /** PTZ情報（パン） */
	    this.pan = "";
	    /** PTZ情報（チルト） */
	    this.tilt = "";
	    /** PTZ情報（ズーム） */
	    this.zoom = "";
	    /** プリセット情報（プリセット番号） */
	    this.preset_num = "";
	    /** プリセット情報（制御区分） */
	    this.control_kbn = "";
	    this.ln_acnt_user_common_for_ope = "";
	    this.camera_num = "";
	    
	}

	public String getLn_acnt_user_common() {
		return ln_acnt_user_common;
	}

	public void setLn_acnt_user_common(String ln_acnt_user_common) {
		this.ln_acnt_user_common = ln_acnt_user_common;
	}

	public String getScreen_id() {
		return screen_id;
	}

	public void setScreen_id(String screen_id) {
		this.screen_id = screen_id;
	}

	public String getOpe_form_id() {
		return ope_form_id;
	}

	public void setOpe_form_id(String ope_form_id) {
		this.ope_form_id = ope_form_id;
	}

	public String getLn_kb_chiku() {
		return ln_kb_chiku;
	}

	public void setLn_kb_chiku(String ln_kb_chiku) {
		this.ln_kb_chiku = ln_kb_chiku;
	}

	public String getImg_quality() {
		return img_quality;
	}

	public void setImg_quality(String img_quality) {
		this.img_quality = img_quality;
	}

	public String getFrame_rate() {
		return frame_rate;
	}

	public void setFrame_rate(String frame_rate) {
		this.frame_rate = frame_rate;
	}

	public Object getLn_dev() {
		return ln_dev;
	}

	public void setLn_dev(Object ln_dev) {
		this.ln_dev = ln_dev;
	}

	public String getSelected_for_dialog() {
		return selected_for_dialog;
	}

	public void setSelected_for_dialog(String selected_for_dialog) {
		this.selected_for_dialog = selected_for_dialog;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getTilt() {
		return tilt;
	}

	public void setTilt(String tilt) {
		this.tilt = tilt;
	}

	public String getZoom() {
		return zoom;
	}

	public void setZoom(String zoom) {
		this.zoom = zoom;
	}

	public String getPreset_num() {
		return preset_num;
	}

	public void setPreset_num(String preset_num) {
		this.preset_num = preset_num;
	}

	public String getControl_kbn() {
		return control_kbn;
	}

	public void setControl_kbn(String control_kbn) {
		this.control_kbn = control_kbn;
	}
}
