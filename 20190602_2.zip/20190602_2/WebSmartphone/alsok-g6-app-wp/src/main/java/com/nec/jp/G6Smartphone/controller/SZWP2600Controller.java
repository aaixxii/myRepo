package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.CameraDataModel;
import com.nec.jp.G6Smartphone.SO.CameraDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuNmDataModel;
import com.nec.jp.G6Smartphone.SO.ResGetCamera;
import com.nec.jp.G6Smartphone.SO.ResGetChikuList;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP2600Service;
import com.nec.jp.G6Smartphone.service.img.SZWP2600ImgService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;

@Controller
public class SZWP2600Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP2600Controller.class);

	//JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
	@Autowired
	SZWP2600Service sZWP2600Service;
	@Autowired
	SZWP2600ImgService sZWP2600ImgService;
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;

	/*
	 * Get data from R_KEIBI,R_DEV, I_MNG_Acum table
	 * @param: acntID, lnKeibi 
	 * return: object ResGetChikuList as JSON
	 */
	@RequestMapping(value = "/getAcumChikuList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getAcumChikuList(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2600Controller.getAcumChikuList()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		Map<String, Object> mapParam = new HashMap<String, Object>();
		List<RKbChikuNmDataModel> rKbChikuNmList = new ArrayList<RKbChikuNmDataModel>();
		List<CameraDataModel> cameraList = new ArrayList<CameraDataModel>();
		ResGetChikuList resGetChikuList = new ResGetChikuList();
		String acntNm = "";

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetChikuList, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumChikuList()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetChikuList, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumChikuList()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));


			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 3) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetChikuList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumChikuList()");
				return jsonResult;
			}

			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.lnKeibi.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetChikuList, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumChikuList()");
				return jsonResult;
			}

			// TODO SZWP2600：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);
			
			// リクエスト情報取得
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();

			// 初期表示情報の取得処理
			// 7-2.A)警備先地区一覧の取得
			rKbChikuNmList = sZWP2600Service.getSecurityDistrictList(mapParam.get(RequestParam.acntID.getValue()).toString(), mapParam.get(RequestParam.lnKeibi.getValue()).toString());

			if (rKbChikuNmList.size() > 0) {
				// 先頭の警備先地区の設置機器一覧情報を取得
				// 7-2.B)設置機器一覧の取得
				cameraList = sZWP2600Service.getDeviceList(rKbChikuNmList.get(0).getLnKbChiku());

				// 7-2.C)蓄積画像音声の取得
				for (CameraDataModel cameraDataModel : cameraList) {
					CameraDataSubModel cameraData = sZWP2600ImgService.getAccumulatedImageSound(cameraDataModel.getLnDev());

					if (null != cameraData) {
						cameraDataModel.setSavePath(cameraData.getSavePath());
						cameraDataModel.setFileNm(cameraData.getFileNm());
						cameraDataModel.setLnImgVoc(cameraData.getLnImgVoc());
					}
				}
			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//			// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//			final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//			hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP2600.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm, DateTimeCommon.getCurrentDate());
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());	// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);														// アカウント名
			hUserOperationLogModel.setLnKeibi(mapParam.get(RequestParam.lnKeibi.getValue()).toString());	// 警備先論理番号
			hUserOperationLogModel.setLnKbChiku(null);														// 警備先地区論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP2600.getValueForOperationLog());					// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);

			// 取得内容を応答する
			resGetChikuList.setErrorCode(G6Constant.SUCCESS_CD);
			resGetChikuList.setrKbChikuNmItem(rKbChikuNmList);
			resGetChikuList.setCameraItem(cameraList);
			
			//デコード済acntIDを設定したJWT認証トークンを付与
			resGetChikuList.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));

			jsonResult = G6Common.parseJSON(resGetChikuList, acntLanguage);

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetChikuList, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetChikuList, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetChikuList, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetChikuList, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetChikuList, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumChikuList()");
		return jsonResult;
	}

	/*
	 * Get data from R_DEV, I_MNG_Acum table
	 * @param: acntID, lnKbChiku
	 * return: object ResGetCamera as JSON
	 */
	@RequestMapping(value = "/getAcumDev", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getAcumDev(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2600Controller.getAcumDev()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetCamera resGetCamera = new ResGetCamera();
		List<CameraDataModel> cameraList = new ArrayList<CameraDataModel>();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntNm = "";
		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetCamera, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumDev()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetCamera, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumDev()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));

			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 3) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetCamera, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumDev()");
				return jsonResult;
			}

			// Build require parameters
			List<String> chkParamList = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.lnKbChiku.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, chkParamList)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetCamera, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumDev()");
				return jsonResult;
			}

			// リクエスト情報取得
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			
			// unused: リクエスト情報からアカウント種別を取得する

			// TODO SZWP2600：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// 設置機器情報取得
			// 設置機器情報を取得する
			// 7-2.B)設置機器一覧の取得
			cameraList = sZWP2600Service.getDeviceList(mapParam.get(RequestParam.lnKbChiku.getValue()).toString());

			// 7-2.C)蓄積画像音声の取得
			for (CameraDataModel cameraDataModel : cameraList) {
				CameraDataSubModel cameraData = sZWP2600ImgService.getAccumulatedImageSound(cameraDataModel.getLnDev());

				if (null != cameraData) {
					cameraDataModel.setSavePath(cameraData.getSavePath());
					cameraDataModel.setFileNm(cameraData.getFileNm());
					cameraDataModel.setLnImgVoc(cameraData.getLnImgVoc());
				}
			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//			// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//			final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//			hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP2600.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm, DateTimeCommon.getCurrentDate());

			String lnKeibi = commonService.getLnKeibiFromLnKbChiku(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM, mapParam.get(RequestParam.lnKbChiku.getValue()).toString());
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());	// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);														// アカウント名
			hUserOperationLogModel.setLnKeibi(lnKeibi);														// 警備先論理番号
			hUserOperationLogModel.setLnKbChiku(mapParam.get(RequestParam.lnKbChiku.getValue()).toString());// 警備先地区論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP2600.getValueForOperationLog());					// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);
			
			// 取得内容を応答する
			resGetCamera.setErrorCode(G6Constant.SUCCESS_CD);
			resGetCamera.setCameraItem(cameraList);

			//デコード済acntIDを設定したJWT認証トークンを付与
			resGetCamera.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));

			jsonResult = G6Common.parseJSON(resGetCamera, acntLanguage);

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetCamera, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetCamera, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetCamera, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetCamera, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetCamera, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2600Controller.getAcumDev()");
		return jsonResult;
	}
}
