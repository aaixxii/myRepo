package com.nec.jp.G6Smartphone.utility;

import java.util.HashMap;
import java.util.Map;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;

public class G6JWTVerifier extends AbstractJWTVerifier {
	
	private static final String PRIVATE_CLAIM_ACUNTID = "acntID";
	private static final String PRIVATE_CLAIM_LOGINTS = "loginTs";
	private static final String PRIVATE_CLAIM_LAST_MODIFY_ACNT_TS = "lastModifyAcntTs";
	private static final String PRIVATE_CLAIM_LN_ACNT_USER_COMMON = "ln_acnt_user_common";
	private static final String PRIVATE_CLAIM_LN_ACNT_KEIYK = "ln_acnt_keiyk";
	private static final String PRIVATE_CLAIM_LN_ACNT_USER = "ln_acnt_user";
	private static final String PRIVATE_CLAIM_ACNT_SBT = "acntSbt";
	
	
	private String secret;
	private String issuer;
	private int expireMinute;
	
	@Override
	public String getSecret() {
		return secret;
	}

	@Override
	public String getIssuer() {
		return issuer;
	}

	@Override
	public int getExpireMinute() {
		return expireMinute;
	}
	
	/**
	 * JWT認証トークンの設定値をメンバに格納する
	 * @param secret シークレット
	 * @param issuer 発行者
	 * @param expireMinute 有効期限(分)
	 * @return
	 */
	public void init(String secret, String issuer, String expireMinute) throws NumberFormatException{
		// 設定値キーをメンバに格納
		this.secret       = secret;							// シークレット
		this.issuer       = issuer;							// 発行者
		this.expireMinute = Integer.parseInt(expireMinute);	// 有効期限(分)
	}
	
	/**
	 * acntID, loginTs, lastModifyAcntTsを埋め込んだJWT認証トークンの生成(String値)<BR>
	 * <BR>
	 * 引数で受け取ったパラメータおよび、有効期限、発行者、固定鍵を<BR>
	 * 設定し、JWT認証トークンを生成する<BR>
	 * <BR>
	 *
	 * @param acntID アカウントID
	 * @param loginTs ログイン日時
	 * @param lastModifyAcntTs アカウント情報最終更新日時
	 * @return String JWT認証トークン
	 * @throws JWTCreationException　JWT認証トークンの生成エラー
	 */
	public String createToken(String acntID, String loginTs, String lastModifyAcntTs, String lnAcntUserCommon, String lnAcntKeiyk, String lnacntUser) throws JWTCreationException {
		Map<String, String> claims = new HashMap<String, String>();
		claims.put(PRIVATE_CLAIM_ACUNTID, acntID);
		claims.put(PRIVATE_CLAIM_LOGINTS, loginTs);
		claims.put(PRIVATE_CLAIM_LAST_MODIFY_ACNT_TS, lastModifyAcntTs);
		claims.put(PRIVATE_CLAIM_LN_ACNT_USER_COMMON, lnAcntUserCommon);
		claims.put(PRIVATE_CLAIM_LN_ACNT_KEIYK, lnAcntKeiyk);
		claims.put(PRIVATE_CLAIM_LN_ACNT_USER, lnacntUser);
		
		return createToken(claims);
	}
	
	/**
	 * 引数で受け取ったパラメータを埋め込んだJWT認証トークンの生成(String値)<BR>
	 * <BR>
	 * 引数で受け取ったパラメータおよび、有効期限、発行者、固定鍵を<BR>
	 * 設定し、JWT認証トークンを生成する<BR>
	 * <BR>
	 *
	 * @param acntID アカウントID
	 * @return String JWT認証トークン
	 * @throws JWTCreationException　JWT認証トークンの生成エラー
	 */
	public String createTokenWithMapParam(Map<String, String> mapParam) throws JWTCreationException {
		return createToken(mapParam);
	}
	
	
	/**
	 * JWT認証トークンを検証および設定されているacntIDの取得(String値)<BR>
	 * <BR>
	 * 引数で受け取ったJWT認証トークンの有効期限、発行者、固定鍵を<BR>
	 * 検証し、検証に成功した場合acntIDを取得する<BR>
	 * <BR>
	 *
	 * @param token JWT認証トークン
	 * @return String アカウントID
	 * @throws JWTVerificationException JWT認証トークンの検証エラー
	 */
	public String verifyAndGetAcuntID(String token) throws JWTVerificationException {
		return getClaim(verifyToken(token), PRIVATE_CLAIM_ACUNTID);
	}
	
	/**
	 * JWT認証トークンを検証および設定されているLoginTsの取得(String値)<BR>
	 * <BR>
	 * 引数で受け取ったJWT認証トークンの有効期限、発行者、固定鍵を<BR>
	 * 検証し、検証に成功した場合LoginTsを取得する<BR>
	 * <BR>
	 *
	 * @param token JWT認証トークン
	 * @return String ログイン時刻
	 * @throws JWTVerificationException JWT認証トークンの検証エラー
	 */
	public String verifyAndGetLoginTs(String token) throws JWTVerificationException {
		return getClaim(verifyToken(token), PRIVATE_CLAIM_LOGINTS);
	}
	
	/**
	 * JWT認証トークンを検証および設定されているLastModifyAcntTsの取得(String値)<BR>
	 * <BR>
	 * 引数で受け取ったJWT認証トークンの有効期限、発行者、固定鍵を<BR>
	 * 検証し、検証に成功した場合LastModifyAcntTsを取得する<BR>
	 * <BR>
	 *
	 * @param token JWT認証トークン
	 * @return String アカウント情報最終更新日時
	 * @throws JWTVerificationException JWT認証トークンの検証エラー
	 */
	public String verifyAndGetLastModifyAcntTs(String token) throws JWTVerificationException {
		return getClaim(verifyToken(token), PRIVATE_CLAIM_LAST_MODIFY_ACNT_TS);
	}
	
	/**
	 * JWT認証トークンを検証および設定されているLnAcntUserCommonの取得(String値)<BR>
	 * <BR>
	 * 引数で受け取ったJWT認証トークンの有効期限、発行者、固定鍵を<BR>
	 * 検証し、検証に成功した場合LnAcntUserCommonを取得する<BR>
	 * <BR>
	 * 
	 * @param token
	 * @return
	 * @throws JWTVerificationException
	 */
	public String verifyAndGetLnAcntUserCommon(String token) throws JWTVerificationException {
		return getClaim(verifyToken(token), PRIVATE_CLAIM_LN_ACNT_USER_COMMON);
	}
	
	/**
	 * JWT認証トークンを検証および設定されているLnAcntUserの取得(String値)<BR>
	 * <BR>
	 * 引数で受け取ったJWT認証トークンの有効期限、発行者、固定鍵を<BR>
	 * 検証し、検証に成功した場合LnAcntUserを取得する<BR>
	 * <BR>
	 * 
	 * @param token
	 * @return
	 * @throws JWTVerificationException
	 */
	public String verifyAndGetLnAcntUser(String token) throws JWTVerificationException {
		return getClaim(verifyToken(token), PRIVATE_CLAIM_LN_ACNT_USER);
	}
	
	/**
	 * JWT認証トークンを検証および設定されているLnAcntKeiykの取得(String値)<BR>
	 * <BR>
	 * 引数で受け取ったJWT認証トークンの有効期限、発行者、固定鍵を<BR>
	 * 検証し、検証に成功した場合LnAcntKeiykを取得する<BR>
	 * <BR>
	 * 
	 * @param token
	 * @return
	 * @throws JWTVerificationException
	 */
	public String verifyAndGetLnAcntKeiyk(String token) throws JWTVerificationException {
		return getClaim(verifyToken(token), PRIVATE_CLAIM_LN_ACNT_KEIYK);
	}
	
	/**
	 * JWT認証トークンを検証および設定されているAcntSbtの取得(String値)<BR>
	 * <BR>
	 * 引数で受け取ったJWT認証トークンの有効期限、発行者、固定鍵を<BR>
	 * 検証し、検証に成功した場合AcntSbtを取得する<BR>
	 * <BR>
	 * 
	 * @param token
	 * @return
	 * @throws JWTVerificationException
	 */
	public String verifyAndGetAcntSbt(String token) throws JWTVerificationException {
		return getClaim(verifyToken(token), PRIVATE_CLAIM_ACNT_SBT);
	}
}
