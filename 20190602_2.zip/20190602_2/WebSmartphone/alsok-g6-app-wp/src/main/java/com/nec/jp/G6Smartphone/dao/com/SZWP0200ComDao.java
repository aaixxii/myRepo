package com.nec.jp.G6Smartphone.dao.com;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.AcntUserInfoModel;

@Repository
public class SZWP0200ComDao {

	@PersistenceContext(unitName="comPersistence")
	private EntityManager entityManager;

	public Boolean updateSelectedLanguage(String acntID, String acntNm, String language, String updateTs) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" UPDATE	K_ACNT_USER_LOGIN_STS");
		strBuilder.append(" SET		SELECT_LANG = :language,");
		strBuilder.append("			UPDATE_ID = :acntID,");
		strBuilder.append("			UPDATE_NM = :acntNm,");
		strBuilder.append("			UPDATE_TS = :updateTs");
		strBuilder.append(" WHERE	LN_ACNT_USER_COMMON = :acntID");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("language", language);
		query.setParameter("acntID", acntID);
		query.setParameter("acntNm", acntNm);
		query.setParameter("updateTs", updateTs);

		if(query.executeUpdate() > 0) {
			return true;
		}

		return false;
	}

	public AcntUserInfoModel selectAcntUserInfo(String lnAcntUserCommon) {
		final StringBuilder strBuilder = new StringBuilder();
		
        strBuilder.append(" SELECT IFNULL(KAUC.ACNT_USER_KBN, '') as acntUserKbn,");
        strBuilder.append("        IFNULL(AAUR.LN_USER_ROLE, '') as lnUserRole");
        strBuilder.append(" FROM   K_ACNT_USER_COMMON  KAUC ");
        strBuilder.append(" 	   LEFT JOIN g6db.A_ACNT_USER_ROLE AAUR ON KAUC.LN_ACNT_USER_COMMON = AAUR.LN_ACNT_USER_COMMON");
		strBuilder.append(" WHERE  KAUC.LN_ACNT_USER_COMMON = :lnAcntUserCommon");
        
        Query query = entityManager.createNativeQuery(strBuilder.toString(), "AcntUserInfoModelResult");
        query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
        query.setMaxResults(1);
        
		return (AcntUserInfoModel) query.getSingleResult();
	}
}
