package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

public class SZWPUserForm implements Serializable {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 7281438140762854433L;

    /** 選択した警備先 */
    private String securityTargetSelection;

    /** アカウントID */
    private String accountId;

    /** アカウント名称 */
    private String AccountName;

    /** 前回ログイン日時 */
    private String lastLoginTs;

    /** 選択言語種別 */
    private Date selLangType;

    /** LN_利用者アカウント共通論理番号 */
    private String lnAcntUserCommon;

    /** 前回ログイン日. */
    private String sysDate;

    /** 前回ログイン曜日. */
    private String sysWeek;

    /** 前回ログイン時. */
    private String sysTime;

    /** メイン管理者設定. */
    private int mainItem;

    /** 大項目(警備開始/解除). */
    private int bigItem1;

    /** 大項目(履歴の確認). */
    private int bigItem2;

    /** 小項目(警備履歴一覧). */
    private int samllItem21;

    /** 小項目(登録人物検知履歴). */
    private int samllItem22;

    /** 小項目(重要犯罪者認証検知履歴). */
    private int samllItem23;

    /** 小項目(イベント画像情報). */
    private int samllItem24;

    /** 大項目(遠隔設備操作). */
    private int bigItem3;

    /** 大項目(画像メニュー). */
    private int bigItem4;

    /** 小項目(ライブ閲覧). */
    private int samllItem41;

    /** 小項目(蓄積画像閲覧). */
    private int samllItem42;

    /** 小項目(蓄積設定一覧). */
    private int samllItem43;

    /** 大項目(出退勤情報). */
    private int bigItem5;

    /** 大項目(出入管理情報). */
    private int bigItem6;

    /** 大項目(各種設定). */
    private int bigItem7;

    /** 小項目(アカウント一覧). */
    private int samllItem71;

    /** 小項目(権限ロール一覧). */
    private int samllItem72;

    /** 小項目(緊急連絡先一覧). */
    private int samllItem73;

    /** 小項目(警備セット忘れ通知設定). */
    private int samllItem74;

    /** 小項目(空室メール設定). */
    private int samllItem75;

    /** 小項目(カード情報一覧). */
    private int samllItem76;

    /** 小項目(簡易スケジュール設定). */
    private int samllItem77;

    /** 小項目(出退勤出力設定). */
    private int samllItem78;

    /** 小項目(登録済み画像一覧). */
    private int samllItem79;

    /** 小項目(登録済み重要犯罪者画像一覧). */
    private int samllItem70;


    /**
     * LN_利用者アカウント共通論理番号
     * 
     * @return lnAcntUserCommon
     */
    public String getLnAcntUserCommon() {
        return lnAcntUserCommon;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * 
     * @param lnAcntUserCommon
     *            設定 lnAcntUserCommon
     */
    public void setLnAcntUserCommon(String lnAcntUserCommon) {
        this.lnAcntUserCommon = lnAcntUserCommon;
    }

    /**
     * 選択言語種別 取得
     * 
     * @return selLangType
     */
    public Date getSelLangType() {
        return selLangType;
    }

    /**
     * 選択言語種別
     * 
     * @param selLangType
     *            設定 selLangType
     */
    public void setSelLangType(Date selLangType) {
        this.selLangType = selLangType;
    }

    /**
     * 選択した警備先を取得する
     * 
     * @return securityTargetSelection
     */
    public String getSecurityTargetSelection() {
        return securityTargetSelection;
    }

    /**
     * 選択した警備先を設定する
     * 
     * @param securityTargetSelection
     *            securityTargetSelection
     */
    public void setSecurityTargetSelection(String securityTargetSelection) {
        this.securityTargetSelection = securityTargetSelection;
    }

    /**
     * 前回ログイン日時を取得する lastLoginTs
     * 
     * @return lastLoginTs
     */
    public String getLastLoginTs() {
        return lastLoginTs;
    }

    /**
     * 前回ログイン日時を設定する
     * 
     * @param lastLoginTs
     *            lastLoginTs
     */
    public void setLastLoginTs(String lastLoginTs) {
        this.lastLoginTs = lastLoginTs;
    }

    /**
     * アカウントIDを取得する
     * 
     * @return アカウントID
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * アカウントIDを設定する
     * 
     * @param accountId
     *            アカウントID
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * アカウント名称を取得する
     * 
     * @return accountName
     */
    public String getAccountName() {
        return AccountName;
    }

    /**
     * アカウント名称を設定する
     * 
     * @param accountName
     *            accountName
     */
    public void setAccountName(String accountName) {
        AccountName = accountName;
    }

    /**
     * 前回ログイン日.
     * @return 前回ログイン日.
     */
    public String getSysDate() {
        return sysDate;
    }

    /**
     * 前回ログイン日.
     * @param sysDate 前回ログイン日.
     */
    public void setSysDate(String sysDate) {
        this.sysDate = sysDate;
    }

    /**
     * 前回ログイン曜日.
     * @return 前回ログイン曜日.
     */
    public String getSysWeek() {
        return sysWeek;
    }

    /**
     * 前回ログイン曜日.
     * @param sysWeek 前回ログイン曜日.
     */
    public void setSysWeek(String sysWeek) {
        this.sysWeek = sysWeek;
    }

    /**
     * 前回ログイン時.
     * @return 前回ログイン時.
     */
    public String getSysTime() {
        return sysTime;
    }

    /**
     * 前回ログイン時.
     * @param sysTime 前回ログイン時.
     */
    public void setSysTime(String sysTime) {
        this.sysTime = sysTime;
    }


    /**
     * メイン管理者設定.
     * @return メイン管理者設定.
     */
    public int getMainItem() {
        return mainItem;
    }

    /**
     * メイン管理者設定.
     * @param mainItem メイン管理者設定.
     */
    public void setMainItem(int mainItem) {
        this.mainItem = mainItem;
    }

    /**
     * 大項目(警備開始/解除).
     * @return 大項目(警備開始/解除).
     */
    public int getBigItem1() {
        return bigItem1;
    }

    /**
     * 大項目(警備開始/解除).
     * @param bigItem1 大項目(警備開始/解除).
     */
    public void setBigItem1(int bigItem1) {
        this.bigItem1 = bigItem1;
    }

    /**
     * 大項目(履歴の確認).
     * @return 大項目(履歴の確認).
     */
    public int getBigItem2() {
        return bigItem2;
    }

    /**
     * 大項目(履歴の確認).
     * @param bigItem2 大項目(履歴の確認).
     */
    public void setBigItem2(int bigItem2) {
        this.bigItem2 = bigItem2;
    }

    /**
     * 小項目(警備履歴一覧).
     * @return 小項目(警備履歴一覧).
     */
    public int getSamllItem21() {
        return samllItem21;
    }

    /**
     * 小項目(警備履歴一覧).
     * @param samllItem21 小項目(警備履歴一覧).
     */
    public void setSamllItem21(int samllItem21) {
        this.samllItem21 = samllItem21;
    }

    /**
     * 小項目(登録人物検知履歴).
     * @return 小項目(登録人物検知履歴).
     */
    public int getSamllItem22() {
        return samllItem22;
    }

    /**
     * 小項目(登録人物検知履歴).
     * @param samllItem22 小項目(登録人物検知履歴).
     */
    public void setSamllItem22(int samllItem22) {
        this.samllItem22 = samllItem22;
    }

    /**
     * 小項目(重要犯罪者認証検知履歴).
     * @return 小項目(重要犯罪者認証検知履歴).
     */
    public int getSamllItem23() {
        return samllItem23;
    }

    /**
     * 小項目(重要犯罪者認証検知履歴).
     * @param samllItem23 小項目(重要犯罪者認証検知履歴).
     */
    public void setSamllItem23(int samllItem23) {
        this.samllItem23 = samllItem23;
    }

    /**
     * 小項目(イベント画像情報).
     * @return 小項目(イベント画像情報).
     */
    public int getSamllItem24() {
        return samllItem24;
    }

    /**
     * 小項目(イベント画像情報).
     * @param samllItem24 小項目(イベント画像情報).
     */
    public void setSamllItem24(int samllItem24) {
        this.samllItem24 = samllItem24;
    }

    /**
     * 大項目(遠隔設備操作).
     * @return 大項目(遠隔設備操作).
     */
    public int getBigItem3() {
        return bigItem3;
    }

    /**
     * 大項目(遠隔設備操作).
     * @param bigItem3 大項目(遠隔設備操作).
     */
    public void setBigItem3(int bigItem3) {
        this.bigItem3 = bigItem3;
    }

    /**
     * 大項目(画像メニュー).
     * @return 大項目(画像メニュー).
     */
    public int getBigItem4() {
        return bigItem4;
    }

    /**
     * 大項目(画像メニュー).
     * @param bigItem4 大項目(画像メニュー).
     */
    public void setBigItem4(int bigItem4) {
        this.bigItem4 = bigItem4;
    }

    /**
     * 小項目(ライブ閲覧).
     * @return 小項目(ライブ閲覧).
     */
    public int getSamllItem41() {
        return samllItem41;
    }

    /**
     * 小項目(ライブ閲覧).
     * @param samllItem41 小項目(ライブ閲覧).
     */
    public void setSamllItem41(int samllItem41) {
        this.samllItem41 = samllItem41;
    }

    /**
     * 小項目(蓄積画像閲覧).
     * @return 小項目(蓄積画像閲覧).
     */
    public int getSamllItem42() {
        return samllItem42;
    }

    /**
     * 小項目(蓄積画像閲覧).
     * @param samllItem42 小項目(蓄積画像閲覧).
     */
    public void setSamllItem42(int samllItem42) {
        this.samllItem42 = samllItem42;
    }

    /**
     * 小項目(蓄積設定一覧).
     * @return 小項目(蓄積設定一覧).
     */
    public int getSamllItem43() {
        return samllItem43;
    }

    /**
     * 小項目(蓄積設定一覧).
     * @param samllItem43 小項目(蓄積設定一覧).
     */
    public void setSamllItem43(int samllItem43) {
        this.samllItem43 = samllItem43;
    }

    /**
     * 大項目(出退勤情報).
     * @return 大項目(出退勤情報).
     */
    public int getBigItem5() {
        return bigItem5;
    }

    /**
     * 大項目(出退勤情報).
     * @param bigItem5 大項目(出退勤情報).
     */
    public void setBigItem5(int bigItem5) {
        this.bigItem5 = bigItem5;
    }

    /**
     * 大項目(出入管理情報).
     * @return 大項目(出入管理情報).
     */
    public int getBigItem6() {
        return bigItem6;
    }

    /**
     * 大項目(出入管理情報).
     * @param bigItem6 大項目(出入管理情報).
     */
    public void setBigItem6(int bigItem6) {
        this.bigItem6 = bigItem6;
    }

    /**
     * 大項目(各種設定).
     * @return 大項目(各種設定).
     */
    public int getBigItem7() {
        return bigItem7;
    }

    /**
     * 大項目(各種設定).
     * @param bigItem7 大項目(各種設定).
     */
    public void setBigItem7(int bigItem7) {
        this.bigItem7 = bigItem7;
    }

    /**
     * 小項目(アカウント一覧).
     * @return 小項目(アカウント一覧).
     */
    public int getSamllItem71() {
        return samllItem71;
    }

    /**
     * 小項目(アカウント一覧).
     * @param samllItem71 小項目(アカウント一覧).
     */
    public void setSamllItem71(int samllItem71) {
        this.samllItem71 = samllItem71;
    }

    /**
     * 小項目(権限ロール一覧).
     * @return 小項目(権限ロール一覧).
     */
    public int getSamllItem72() {
        return samllItem72;
    }

    /**
     * 小項目(権限ロール一覧).
     * @param samllItem72 小項目(権限ロール一覧).
     */
    public void setSamllItem72(int samllItem72) {
        this.samllItem72 = samllItem72;
    }

    /**
     * 小項目(緊急連絡先一覧).
     * @return 小項目(緊急連絡先一覧).
     */
    public int getSamllItem73() {
        return samllItem73;
    }

    /**
     * 小項目(緊急連絡先一覧).
     * @param samllItem73 小項目(緊急連絡先一覧).
     */
    public void setSamllItem73(int samllItem73) {
        this.samllItem73 = samllItem73;
    }

    /**
     * 小項目(警備セット忘れ通知設定).
     * @return 小項目(警備セット忘れ通知設定).
     */
    public int getSamllItem74() {
        return samllItem74;
    }

    /**
     * 小項目(警備セット忘れ通知設定).
     * @param samllItem74 小項目(警備セット忘れ通知設定).
     */
    public void setSamllItem74(int samllItem74) {
        this.samllItem74 = samllItem74;
    }

    /**
     * 小項目(空室メール設定).
     * @return 小項目(空室メール設定).
     */
    public int getSamllItem75() {
        return samllItem75;
    }

    /**
     * 小項目(空室メール設定).
     * @param samllItem75 小項目(空室メール設定).
     */
    public void setSamllItem75(int samllItem75) {
        this.samllItem75 = samllItem75;
    }

    /**
     * 小項目(カード情報一覧).
     * @return 小項目(カード情報一覧).
     */
    public int getSamllItem76() {
        return samllItem76;
    }

    /**
     * 小項目(カード情報一覧).
     * @param samllItem76 小項目(カード情報一覧).
     */
    public void setSamllItem76(int samllItem76) {
        this.samllItem76 = samllItem76;
    }

    /**
     * 小項目(簡易スケジュール設定).
     * @return 小項目(簡易スケジュール設定).
     */
    public int getSamllItem77() {
        return samllItem77;
    }

    /**
     * 小項目(簡易スケジュール設定).
     * @param samllItem77 小項目(簡易スケジュール設定).
     */
    public void setSamllItem77(int samllItem77) {
        this.samllItem77 = samllItem77;
    }

    /**
     * 小項目(出退勤出力設定).
     * @return 小項目(出退勤出力設定).
     */
    public int getSamllItem78() {
        return samllItem78;
    }

    /**
     * 小項目(出退勤出力設定).
     * @param samllItem78 小項目(出退勤出力設定).
     */
    public void setSamllItem78(int samllItem78) {
        this.samllItem78 = samllItem78;
    }

    /**
     * 小項目(登録済み画像一覧).
     * @return 小項目(登録済み画像一覧).
     */
    public int getSamllItem79() {
        return samllItem79;
    }

    /**
     * 小項目(登録済み画像一覧).
     * @param samllItem79 小項目(登録済み画像一覧).
     */
    public void setSamllItem79(int samllItem79) {
        this.samllItem79 = samllItem79;
    }

    /**
     * 小項目(登録済み重要犯罪者画像一覧).
     * @return 小項目(登録済み重要犯罪者画像一覧).
     */
    public int getSamllItem70() {
        return samllItem70;
    }

    /**
     * 小項目(登録済み重要犯罪者画像一覧).
     * @param samllItem70 小項目(登録済み重要犯罪者画像一覧).
     */
    public void setSamllItem70(int samllItem70) {
        this.samllItem70 = samllItem70;
    }
}
