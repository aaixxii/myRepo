package com.nec.jp.G6Smartphone.dao.g6;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataSubModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP1100Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	public String getElectricNum(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	denkei");
		strBuilder.append(" FROM	RDenkeiMngModel");
		strBuilder.append(" WHERE	lnKeibi = :lnKeibi");
		strBuilder.append("			AND lastFlg = :lastFlg");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("lastFlg", G6CodeConsts.CD009.LATEST);
		query.setMaxResults(1);

		return (String) query.getSingleResult();
	}

	//public RCtlDevDataSubModel getGoukiSerial(String lnKeibi, String lnKbChiku) {
	public RCtlDevDataSubModel getGoukiSerial(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT a.LN_CTL_DEV as lnCtlDev,");
		strBuilder.append("     IFNULL(a.GOUKI, '') as gouKi,");
		strBuilder.append("     IFNULL(a.SERIAL_NUM, '') as serialNum,");
		strBuilder.append("     IFNULL(a.SD_LINE_KIND, '') as sdLineKind");
		strBuilder.append(" FROM	R_CTL_DEV a");
		strBuilder.append("     INNER JOIN R_DEV b ON a.LN_DEV = b.LN_DEV");
		strBuilder.append(" WHERE b.DEL_FLG = :delFlg");
		strBuilder.append(" AND b.LN_KEIBI = :lnKeibi");
		// strBuilder.append(" AND b.LN_KB_CHIKU = :lnKbChiku");
		strBuilder.append(" AND a.DEL_FLG = :delFlg");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RCtlDevDataSubModelResult");
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		query.setParameter("lnKeibi", lnKeibi);
		// query.setParameter("lnKbChiku", lnKbChiku);
		query.setMaxResults(1);

		return (RCtlDevDataSubModel) query.getSingleResult();
	}

	public RKbChikuDataSubModel getDistrictInfo(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	a.LN_KB_CHIKU as lnKbChiku,");
		strBuilder.append("			IFNULL(a.LN_KEIBI, '') as lnKeibi,");
		strBuilder.append("			a.CHIKU as chiku,");
		strBuilder.append("			IFNULL(a.SUB_ADDR, '') as subAddr,");
		strBuilder.append("			IFNULL(a.SD_KOBETU_NM, '') as sdKobetuNm,");
		strBuilder.append("			IFNULL(a.GYOUMU_CD, '') as gyoumuCd,");
		strBuilder.append("			IFNULL(a.HOSOKU_CD, '') as hosokuCd,");
		strBuilder.append("			IFNULL(b.GSHS_FLG, '') as gshsFlg");
		strBuilder.append(" FROM	R_KB_CHIKU a");
		strBuilder.append("			INNER JOIN R_KEIBI b ON a.LN_KEIBI = b.LN_KEIBI");
		strBuilder.append(" WHERE	a.LN_KEIBI = :lnKeibi");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKbChikuDataModelTempResult");
		query.setParameter("lnKeibi", lnKeibi);
		query.setMaxResults(1);

		return (RKbChikuDataSubModel) query.getSingleResult();
	}

	public String getCmdSts(String cmdSeqNum) throws Exception {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(c.STS, '')");
		strBuilder.append("	FROM	C_QUE_CTRL_SIG c");
		strBuilder.append("	WHERE	c.CMD_SEQ_NUM = :cmdSeqNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("cmdSeqNum", cmdSeqNum);
		query.setMaxResults(1);
		return (String) query.getSingleResult();
	}

	public String getDeviceSts(String lnDev) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	drctsetCntrSts");
		strBuilder.append(" FROM	RDevStModel");
		strBuilder.append(" WHERE	lnDev = :lnDev");

		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("lnDev", lnDev);

		return (String) query.getSingleResult();
	}
}
