package com.nec.jp.G6Smartphone.service.g6;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP0800Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP0800Service {

	@Autowired
	SZWP0800Dao sZWP0800Dao;

	public RCtlDevDataSubModel getSecureInfo(String lnKbChiku) throws ApplicationException {
		try {
			RCtlDevDataSubModel rCtlDevDataSubModel = sZWP0800Dao.getSecureInfo(lnKbChiku);

			return rCtlDevDataSubModel;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public ControlQueueStatusModel getControlQueueStsInfo(String cmdSeqNum) throws ApplicationException {
		try {
			ControlQueueStatusModel controlQueueStatusModel = sZWP0800Dao.getControlQueueStsInfo(cmdSeqNum);

			return controlQueueStatusModel;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
