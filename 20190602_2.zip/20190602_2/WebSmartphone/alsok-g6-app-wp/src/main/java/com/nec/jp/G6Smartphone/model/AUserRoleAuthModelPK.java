package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the A_USER_ROLE_AUTH database table.
 * 
 */
@Embeddable
public class AUserRoleAuthModelPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="LN_USER_ROLE")
	private String lnUserRole;

	@Column(name="LN_USER_ACNT_AUTH_ID")
	private String lnUserAcntAuthId;

	public AUserRoleAuthModelPK() {
	}
	public String getLnUserRole() {
		return this.lnUserRole;
	}
	public void setLnUserRole(String lnUserRole) {
		this.lnUserRole = lnUserRole;
	}
	public String getLnUserAcntAuthId() {
		return this.lnUserAcntAuthId;
	}
	public void setLnUserAcntAuthId(String lnUserAcntAuthId) {
		this.lnUserAcntAuthId = lnUserAcntAuthId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AUserRoleAuthModelPK)) {
			return false;
		}
		AUserRoleAuthModelPK castOther = (AUserRoleAuthModelPK)other;
		return 
			this.lnUserRole.equals(castOther.lnUserRole)
			&& this.lnUserAcntAuthId.equals(castOther.lnUserAcntAuthId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.lnUserRole.hashCode();
		hash = hash * prime + this.lnUserAcntAuthId.hashCode();
		
		return hash;
	}
}