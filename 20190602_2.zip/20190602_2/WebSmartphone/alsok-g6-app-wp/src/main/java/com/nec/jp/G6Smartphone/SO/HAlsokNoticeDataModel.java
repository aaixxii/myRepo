package com.nec.jp.G6Smartphone.SO;

public class HAlsokNoticeDataModel {

	private String lnHAlsokNotice;		// ALSOKお知らせ履歴.LN_ALSOKお知らせ履歴論理番号
	private String sendTs;				// ALSOKお知らせ履歴.送信予定日時
	private String title;				// ALSOKお知らせ履歴.タイトル

	public HAlsokNoticeDataModel() {
		
	}

	public HAlsokNoticeDataModel(String lnHAlsokNotice, String sendTs, String title) {
		this.lnHAlsokNotice = lnHAlsokNotice;
		this.sendTs = sendTs;
		this.title = title;
	}

	public String getLnHAlsokNotice() {
		return lnHAlsokNotice;
	}

	public void setLnHAlsokNotice(String lnHAlsokNotice) {
		this.lnHAlsokNotice = lnHAlsokNotice;
	}

	public String getSendTs() {
		return sendTs;
	}

	public void setSendTs(String sendTs) {
		this.sendTs = sendTs;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
}
