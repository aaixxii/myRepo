package com.nec.jp.G6Smartphone.service.g6;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.ResGetNoticeDetail;
import com.nec.jp.G6Smartphone.dao.g6.SZWP1900Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1900Service {

	@Autowired
	private SZWP1900Dao sZWP1900Dao;

	public ResGetNoticeDetail getNoticeDetail(String lnHAlsokNotice) throws ApplicationException {
		try {
			return  sZWP1900Dao.getNoticeDetail(lnHAlsokNotice);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
