package com.nec.jp.G6Smartphone.dao.g6;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.KbInfDataModel;

@Repository
public class SZWP3800Dao {

    @PersistenceContext(unitName = "g6Persistence")
    private EntityManager entityManager;
    
    private StringBuilder getCriminalDetectionListSql( String nickName, String keiykNm, String keibiName, String devNm) {
		StringBuilder strBuilder = new StringBuilder();
		
//	     SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//	     StringBuilder strBuilder = new StringBuilder();
//	     strBuilder.append(" SELECT	DATE_FORMAT(EKI.SIG_HASSEI_TS, '%Y/%m/%d %H:%i:%s') as sigHasseiTs");
//	     strBuilder.append(",		IFNULL(RAPI.NICK_NAME, '') as nickName");
//	     strBuilder.append(",		IFNULL(RKY.KEIYK_NM, '') as keiykNm");
//	     strBuilder.append(",		IFNULL(RK.KEIBI_NAME1,'') as keibiName");
//	     strBuilder.append(",		EKI.DEV_NM as devNm");
//	     strBuilder.append(",		IFNULL(EKN.LN_KB_INF, '') as cntLnKbInf");
//	     strBuilder.append(",		RAPI.LN_R_AUTH_PIC_INF as lnRAuthPicInf");
//	     strBuilder.append(",		EKI.LN_KB_INF as lnKbInf");
//	     strBuilder.append(" FROM	R_AUTH_PIC_INF RAPI");
//	     strBuilder
//	           .append(" 		LEFT JOIN R_PIC_INF_DEV_STS RPIDS ON RAPI.LN_R_AUTH_PIC_INF = RPIDS.LN_R_AUTH_PIC_INF");
//	     strBuilder.append(" 		LEFT JOIN R_DEV RD ON RPIDS.LN_DEV = RD.LN_DEV");
//	     strBuilder.append(" 		LEFT JOIN R_DEV_GROUP_MST RDGM ON RPIDS.LN_DEV = RDGM.LN_DEV");
//	     strBuilder.append(" 		LEFT JOIN R_KEIBI RK ON RD.LN_KEIBI = RK.LN_KEIBI");
//	     strBuilder.append(" 		LEFT JOIN E_KB_INF EKI ON RD.LN_KB_CHIKU = EKI.LN_KB_CHIKU");
//	     strBuilder.append(" 		LEFT JOIN E_KB_NOTICE EKN ON EKI.LN_KB_INF = EKN.LN_KB_INF");
//	     strBuilder.append(" 		LEFT JOIN R_KB_CHIKU RKC ON EKI.LN_KB_CHIKU = RKC.LN_KB_CHIKU");
//	     strBuilder.append(" 		LEFT JOIN R_KEIYK_BUKKEN RKB ON RK.LN_BUKKEN = RKB.LN_BUKKEN");
//	     strBuilder.append(" 		LEFT JOIN R_KEIYK RKY ON RKB.LN_KEIYK = RKY.LN_KEIYK");
//	     strBuilder.append(" WHERE	(DATE_FORMAT(EKI.SIG_HASSEI_TS, '%Y%m%d') BETWEEN :dateFrom AND :dateTo)");
//	     if (!nickName.isEmpty()) {
//	        strBuilder.append(" 	AND RAPI.NICK_NAME LIKE :nickName");
//	     }
//	     strBuilder.append(" 		AND RAPI.PIC_KIND = :picKind");
//	     if (!keiykNm.isEmpty()) {
//	        strBuilder.append(" 	AND RKY.KEIYK_NM LIKE :keiykNm");
//	     }
//	     if (!keibiName.isEmpty()) {
//	        strBuilder.append(" 	AND RK.KEIBI_NAME1 LIKE :keibiName");
//	     }
//	     if (!devNm.isEmpty()) {
//	        strBuilder.append(" 	AND EKI.DEV_NM LIKE :devNm");
//	     }
//	     if (!pathInf.isEmpty()) {
//	        strBuilder.append(" 	AND RK.PATH_INF = :pathInf");
//	     }
//	     strBuilder.append(" 		AND RAPI.DEL_FLG = :delFlg");
//	     strBuilder.append(" 		AND RPIDS.DEL_FLG = :delFlg");
//	     strBuilder.append(" 		AND RDGM.DEL_FLG = :delFlg");
//	     strBuilder.append(" 		AND RD.DEL_FLG = :delFlg");
//	     strBuilder.append(" ORDER BY	EKI.SIG_HASSEI_TS DESC");
//	     strBuilder.append(" ,			RAPI.NICK_NAME ASC");
//	     strBuilder.append(" ,			RKY.KEIYK_NM ASC");
//	     strBuilder.append(" ,			RK.KEIBI_NAME1 ASC");
//	     strBuilder.append(" ,			EKI.DEV_NM ASC");
//	
//	     Query query = entityManager.createNativeQuery(strBuilder.toString(), "KbInfDataModelResult");
//	     query.setParameter("picKind", G6CodeConsts.CD156.IMPORTANT_CRIMINAL_INFORMATION);
//	     query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
//	     query.setParameter("dateFrom", sdf.format(dateFrom));
//	     query.setParameter("dateTo", sdf.format(dateTo));
//	     if (!nickName.isEmpty()) {
//	        query.setParameter("nickName", "%" + nickName + "%");
//	     }
//	     if (!keiykNm.isEmpty()) {
//	        query.setParameter("keiykNm", "%" + keiykNm + "%");
//	     }
//	     if (!keibiName.isEmpty()) {
//	        query.setParameter("keibiName", "%" + keibiName + "%");
//	     }
//	     if (!devNm.isEmpty()) {
//	        query.setParameter("devNm", "%" + devNm + "%");
//	     }
//	     if (!pathInf.isEmpty()) {
//	        query.setParameter("pathInf", pathInf);
//	     }
     
	     strBuilder.append(" SELECT DATE_FORMAT(T6.SIG_HASSEI_TS, '%Y/%m/%d %H:%i:%s') as sigHasseiTs");
	     strBuilder.append(",    IFNULL(T1.NICK_NAME, '') as nickName");
	     strBuilder.append(",    IFNULL(T9.KEIYK_NM, '') as keiykNm");
	     strBuilder.append(",    IFNULL(T5.KEIBI_NAME1,'') as keibiName");
	     strBuilder.append(",    T6.DEV_NM as devNm");
	     strBuilder.append(",    IFNULL(T10.LN_KB_INF, '') as cntLnKbInf");
	     strBuilder.append(",    T1.LN_R_AUTH_PIC_INF as lnRAuthPicInf");
	     strBuilder.append(",    T6.LN_KB_INF as lnKbInf");
	     strBuilder.append(" FROM ");
	     strBuilder.append("     R_AUTH_PIC_INF T1");
	     strBuilder.append("     INNER JOIN R_PIC_INF_DEV_STS T2 ON T1.LN_R_AUTH_PIC_INF = T2.LN_R_AUTH_PIC_INF ");
	     strBuilder.append("       AND T2.DEL_FLG = '0'");
	     strBuilder.append("     INNER JOIN R_DEV_GROUP_MST T3 ON T2.LN_DEV = T3.LN_DEV ");
	     strBuilder.append("       AND T3.DEL_FLG = '0'");
	     strBuilder.append("     INNER JOIN R_DEV T4 ON T3.LN_DEV = T4.LN_DEV ");
	     strBuilder.append("       AND T4.DEL_FLG = '0'");
	     strBuilder.append("     INNER JOIN E_KB_INF T6 ON T6.IMG_NUM = T1.PIC_LGC_NO");
	     strBuilder.append("     INNER JOIN R_KB_CHIKU T7 ON T6.LN_KB_CHIKU = T7.LN_KB_CHIKU");
	     strBuilder.append("       AND T7.DEL_FLG = '0'");
	     strBuilder.append("     INNER JOIN E_KB_NOTICE T10 ON T10.LN_KB_INF = T6.LN_KB_INF");
	     strBuilder.append("     INNER JOIN R_KEIBI T5 ON T7.LN_KEIBI = T5.LN_KEIBI ");
	     strBuilder.append("       AND T5.DEL_FLG = '0'");
	     strBuilder.append("     INNER JOIN R_KEIYK_BUKKEN T8 ON T5.LN_BUKKEN = T8.LN_BUKKEN");
	     strBuilder.append("       AND T8.DEL_FLG = '0'");
	     strBuilder.append("     INNER JOIN R_KEIYK T9 ON T8.LN_KEIYK = T9.LN_KEIYK ");
	     strBuilder.append("       AND T9.DEL_FLG = '0'");
	     strBuilder.append("     INNER JOIN A_USER_OPERATION_HANI T12 ");
	     strBuilder.append("	    ON T12.LN_ACNT_USER_COMMON = :acntID");
	     strBuilder.append("	 AND ( T12.PATH_INF = T7.PATH_INF");
	     strBuilder.append("		OR T12.PATH_INF = LEFT(T7.PATH_INF, 41)");
	     strBuilder.append("		OR T12.PATH_INF = LEFT(T7.PATH_INF, 20) )");	     
	     strBuilder.append(" WHERE (DATE_FORMAT(T6.SIG_HASSEI_TS, '%Y%m%d') BETWEEN :dateFrom AND :dateTo)");
	     
	     // set value condition
	     if (!nickName.isEmpty()) {
	        strBuilder.append("    AND T1.NICK_NAME LIKE :nickName");
	     }
	     strBuilder.append("    AND T1.PIC_KIND = '1'");
	     if (!keiykNm.isEmpty()) {
	        strBuilder.append("    AND T9.KEIYK_NM LIKE :keiykNm");
	     }
	     if (!keibiName.isEmpty()) {
	        strBuilder.append("    AND T5.KEIBI_NAME1 LIKE :keibiName");
	     }
	     if (!devNm.isEmpty()) {
	        strBuilder.append("    AND T6.DEV_NM LIKE :devNm");
	     }
	     strBuilder.append("    AND RIGHT(T5.PATH_INF,20) = :lnKeibi");
	     strBuilder.append("    AND T1.DEL_FLG = '0'");
	     
	     // Order by
	     strBuilder.append(" ORDER BY T6.SIG_HASSEI_TS DESC");
	     strBuilder.append("    , T1.NICK_NAME ASC");
	     strBuilder.append("    , T9.KEIYK_NM ASC");
	     strBuilder.append("    , T5.KEIBI_NAME1 ASC");
	     strBuilder.append("    , T6.DEV_NM ASC");
		
     	return strBuilder;
    }
    
    public String getTotalRow(String acntID, String lnKeibi, Date dateFrom, Date dateTo, String nickName,String keiykNm, String keibiName, String devNm) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append("SELECT COUNT(*) FROM (");
		strBuilder.append(getCriminalDetectionListSql(nickName, keiykNm, keibiName, devNm).toString());
		strBuilder.append(") DistrictPulldownInfo");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("acntID", acntID);
		query.setParameter("dateFrom", sdf.format(dateFrom));
		query.setParameter("dateTo", sdf.format(dateTo));
		if (!nickName.isEmpty()) {
			query.setParameter("nickName", "%" + nickName + "%");
		}
		if (!keiykNm.isEmpty()) {
			query.setParameter("keiykNm", "%" + keiykNm + "%");
		}
		if (!keibiName.isEmpty()) {
			query.setParameter("keibiName", "%" + keibiName + "%");
		}
		if (!devNm.isEmpty()) {
			query.setParameter("devNm", "%" + devNm + "%");
		}
		query.setParameter("lnKeibi", lnKeibi);
		
		return query.getSingleResult().toString();
	}

    @SuppressWarnings("unchecked")
    public List<KbInfDataModel> getCriminalDetectionList(String acntID, String lnKeibi, Date dateFrom, Date dateTo, String nickName,String keiykNm, String keibiName, String devNm, int offset, int limitRowNum) {
       SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
       StringBuilder strBuilder = new StringBuilder();
       
       strBuilder.append(getCriminalDetectionListSql(nickName, keiykNm, keibiName, devNm).toString());
       strBuilder.append(" LIMIT :offset, :limitRowNum");

       // Perform query data from DB
       final Query query = entityManager.createNativeQuery(strBuilder.toString(), "KbInfDataModelResult");
       query.setParameter("acntID", acntID);
       query.setParameter("dateFrom", sdf.format(dateFrom));
       query.setParameter("dateTo", sdf.format(dateTo));
       if (!nickName.isEmpty()) {
          query.setParameter("nickName", "%" + nickName + "%");
       }
       if (!keiykNm.isEmpty()) {
          query.setParameter("keiykNm", "%" + keiykNm + "%");
       }
       if (!keibiName.isEmpty()) {
          query.setParameter("keibiName", "%" + keibiName + "%");
       }
       if (!devNm.isEmpty()) {
          query.setParameter("devNm", "%" + devNm + "%");
       }
       query.setParameter("lnKeibi", lnKeibi);
       query.setParameter("offset", offset);
       query.setParameter("limitRowNum", limitRowNum);
       
       return (List<KbInfDataModel>) query.getResultList();
    }
}
