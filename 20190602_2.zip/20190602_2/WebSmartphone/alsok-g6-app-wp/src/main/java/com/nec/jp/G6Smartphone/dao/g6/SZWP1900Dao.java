package com.nec.jp.G6Smartphone.dao.g6;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.ResGetNoticeDetail;

@Repository
public class SZWP1900Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	public ResGetNoticeDetail getNoticeDetail(String lnHAlsokNotice) {
		final StringBuilder strBuilder = new StringBuilder();
		// START: Change table H_ALSOK_NOTICE -> R_ALSOK_NOTICE
//		strBuilder.append(" SELECT	IFNULL(DATE_FORMAT(halsoknotice.SEND_TS, '%Y/%m/%d %H:%i:%s'),'') as send_ts,");
//		strBuilder.append(" 				IFNULL(cast(halsoknotice.TITLE as character),'') as title,");
//		strBuilder.append(" 				halsoknotice.INSERT_NM as insertNm,");
//		strBuilder.append(" 				IFNULL(halsoknotice.BODY,'') as body");
//		strBuilder.append(" FROM		H_ALSOK_NOTICE halsoknotice");
//		strBuilder.append(" WHERE	halsoknotice.LN_H_ALSOK_NOTICE = :lnHAlsokNotice");

        strBuilder.append(" SELECT IFNULL(DATE_FORMAT(halsoknotice.SEND_TS, '%Y/%m/%d %H:%i:%s'),'') as send_ts,");
        strBuilder.append("     IFNULL(cast(halsoknotice.TITLE as character),'') as title,");
        strBuilder.append("     halsoknotice.INSERT_NM as insertNm,");
        strBuilder.append("     IFNULL(halsoknotice.BODY,'') as body");
        strBuilder.append(" FROM  R_ALSOK_NOTICE halsoknotice");
        strBuilder.append(" WHERE halsoknotice.LN_ALSOK_NOTICE = :lnHAlsokNotice");
        // END: Change table H_ALSOK_NOTICE -> R_ALSOK_NOTICE 
        
        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "ResGetNoticeDetailResult");
		query.setParameter("lnHAlsokNotice", lnHAlsokNotice);

		return (ResGetNoticeDetail) query.getSingleResult();
	}
}
