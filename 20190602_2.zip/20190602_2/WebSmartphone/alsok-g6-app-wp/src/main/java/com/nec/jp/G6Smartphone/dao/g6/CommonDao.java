package com.nec.jp.G6Smartphone.dao.g6;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.UserOperationChikuInfoModel;
import com.nec.jp.G6Smartphone.SO.YukoAcntUserInf;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.CQueCtrlSigModel;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.utility.G6Constant;

import jp.co.alsok.g6.zzw.web.service.KeibisakiInfoConstant;

@Repository
public class CommonDao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	public void entryUserOperation(HUserOperationLogModel hUserOperationLogModel) {
		entityManager.persist(hUserOperationLogModel);
	}

	public void saveCQueCtrlSigModel(CQueCtrlSigModel entity) {
		entityManager.persist(entity);
	}
	
    /**
     * 指定PROP_KEYのプロパティ設定値を取得する<br>
     *
     * @param section
     * @param propKey
     * @return プロパティ設定値
     */
	public String getPropVal(String section, String propKey) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT  val");
		strBuilder.append(" FROM    RPropTblModel");
		strBuilder.append(" WHERE	SECTION  = :section");
		strBuilder.append(" AND     PROP_KEY = :propKey");
		
		Query query = entityManager.createQuery(strBuilder.toString());
		query.setParameter("section", section);
		query.setParameter("propKey", propKey);
		query.setMaxResults(1);

		return (String) query.getSingleResult();
	}

	public String getServiceType(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	c.KB_SERVICE_CD");
		strBuilder.append(" FROM	R_BUKKEN a");
		strBuilder.append(" 		INNER JOIN R_KEIYK_BUKKEN b on a.LN_BUKKEN = b.LN_BUKKEN");
		strBuilder.append(" 		INNER JOIN R_KEIYK c on b.LN_KEIYK = c.LN_KEIYK");
		strBuilder.append(" 		INNER JOIN R_KEIBI d on d.LN_BUKKEN = a.LN_BUKKEN");
		strBuilder.append(" WHERE	d.LN_KEIBI = :lnKeibi");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setMaxResults(1);

		return query.getSingleResult().toString();
	}
	
	public BigInteger findCmdSeqNum(String cmdSeqNum) {
		try {
			StringBuilder strBuilder = new StringBuilder();

			strBuilder.append(" SELECT COUNT(*)");
			strBuilder.append(" FROM	C_QUE_CTRL_SIG c");
			strBuilder.append(" WHERE c.CMD_SEQ_NUM = :cmdSeqNum");

			final Query query = entityManager.createNativeQuery(strBuilder.toString());
			query.setParameter("cmdSeqNum", cmdSeqNum);
			return (BigInteger) query.getSingleResult();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return BigInteger.ZERO;
	}
	
	/**
     * get sequence in table C_Sequence_Manager
     * @param cmdSeqNum
     * @return max number
     */
    public long getSeq(String sequenceId) {
        Long result;
        final StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("GET_SEQUENCE")
                .registerStoredProcedureParameter(1 , String.class , ParameterMode.IN)
                .registerStoredProcedureParameter(2 , Long.class, ParameterMode.OUT);
        storedProcedure.setParameter(1, sequenceId);
        storedProcedure.execute();
        result = (Long)storedProcedure.getOutputParameterValue(2);
        return result;
    }
    
    @SuppressWarnings("unchecked")
    public List<String> getUserOperationHani(String lnAcntUserCommon) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT CHIKU.PATH_INF AS PATH_INF");
        strBuilder.append(" FROM R_KB_CHIKU CHIKU");
        strBuilder.append(" INNER JOIN A_USER_OPERATION_HANI HANI ON HANI.LN_ACNT_USER_COMMON = :lnAcntUserCommon");
        strBuilder.append(" AND ( HANI.PATH_INF = CHIKU.PATH_INF");
        strBuilder.append("    OR HANI.PATH_INF = LEFT(CHIKU.PATH_INF, 41)");
        strBuilder.append("   OR HANI.PATH_INF = LEFT(CHIKU.PATH_INF, 20))");
        strBuilder.append(" AND CHIKU.DEL_FLG = '0'");
        strBuilder.append(" GROUP BY PATH_INF");
        strBuilder.append(" ORDER BY PATH_INF");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUserCommon", lnAcntUserCommon);

        return (List<String>) query.getResultList();
    }
    
    public String getAuth(String lnAcntUserCommon,
            String lnKeiyk, 
            String lnKeibi,
            String lnKbChiku, 
            String dispId) {
        final StringBuilder strBuilder = new StringBuilder();

        strBuilder.append(" SELECT ura.AUTH");
        strBuilder.append(" FROM A_USER_OPERATION_HANI auoh");
        strBuilder.append(" INNER JOIN A_ACNT_USER_ROLE aur ON auoh.LN_ACNT_USER_COMMON = :lnAcntUserCommon");
        strBuilder.append(" AND auoh.LN_ACNT_USER_COMMON = aur.LN_ACNT_USER_COMMON");
        strBuilder.append(" INNER JOIN A_USER_ROLE ur ON aur.LN_USER_ROLE = ur.LN_USER_ROLE");
        strBuilder.append(" INNER JOIN A_USER_ROLE_AUTH ura ON ur.LN_USER_ROLE = ura.LN_USER_ROLE");
        strBuilder.append(" INNER JOIN A_USER_ACNT_AUTH_MST uaa ON ura.LN_USER_ACNT_AUTH_ID = uaa.LN_USER_ACNT_AUTH_ID");
        strBuilder.append(" INNER JOIN M_DISP d ON d.DISP_ID = :dispId");
        strBuilder.append(" AND uaa.MENUPASS_INF = LEFT(d.MENUPASS_INF, 4)");
        strBuilder.append(" WHERE ( IFNULL(:lnKbChiku, '') <> '' ");
        strBuilder.append(" AND ( auoh.PATH_INF = :lnKeiyk");
        strBuilder.append(" OR auoh.PATH_INF = CONCAT(:lnKeiyk, '/', :lnKeibi) ");
        strBuilder.append(" OR (auoh.PATH_INF = CONCAT(:lnKeiyk, '/', :lnKeibi, '/', :lnKbChiku) AND ( IFNULL(ura.LN_KB_CHIKU, '') = '' OR ura.LN_KB_CHIKU = :lnKbChiku))))");
        strBuilder.append(" OR ( IFNULL(:lnKbChiku, '') = '' ");
        strBuilder.append(" AND ( auoh.PATH_INF = :lnKeiyk ");
        strBuilder.append(" OR auoh.PATH_INF LIKE CONCAT(:lnKeiyk, '/', :lnKeibi, '%')))");
        strBuilder.append(" ORDER BY ura.AUTH DESC LIMIT 1");

        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
        query.setParameter("lnKeiyk", lnKeiyk);
        query.setParameter("lnKeibi", lnKeibi);
        query.setParameter("lnKbChiku", lnKbChiku);
        query.setParameter("dispId", dispId);

        return query.getSingleResult().toString();
    }
    
    /**
     * <pre>
     *     
     * 利用者アカウント区分チェック       
     * ・アカウント区分により利用可能な画面かどうかを判断する。
     * </pre>
     * 
     * @param model
     * @param dispId
     * @return 利用不可(0),利用可（2),個別権限(3)
     */
    public YukoAcntUserInf getYukoAcntUserKbnInf(String dispId) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(MENUPASS_INF, '') as menupassInf, ");
        strBuilder.append("     IFNULL(CHIKU_FLG, '') as chikuFlg,");
        strBuilder.append("     IFNULL(YUKO_ACNT_USER_KBN, '') as yukoAcntUserKbn");
        strBuilder.append(" FROM M_DISP");
        strBuilder.append(" WHERE DISP_ID = :dispId");

        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "YukoAcntUserInf");
        query.setParameter("dispId", dispId);
        query.setMaxResults(1);
        return (YukoAcntUserInf) query.getSingleResult();
    }
    
    public UserOperationChikuInfoModel getChikuInfoForUserOperation(String lnKeibi, String lnKbChiku) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(LN_KEIYK, '') as lnKeiyk, ");
        strBuilder.append("     IFNULL(KEIBI_NAME1, '') as keibiNm,");
        strBuilder.append("     IFNULL(SD_KOBETU_NM, '') as sdKobetuNm");
        strBuilder.append(" FROM R_KEIYK_BUKKEN kyBkn"); 
        strBuilder.append("  INNER JOIN R_KEIBI kb"); 
        strBuilder.append("   on kyBkn.LN_BUKKEN = kb.LN_BUKKEN"); 
        strBuilder.append("  LEFT JOIN R_KB_CHIKU chk"); 
        strBuilder.append("    ON kb.LN_KEIBI = chk.LN_KEIBI"); 
        strBuilder.append("    AND chk.LN_KB_CHIKU = :lnKbChiku"); 
        strBuilder.append(" where kb.LN_KEIBI = :lnKeibi");
        
        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "UserOperationChikuInfoModelResult");
        query.setParameter("lnKeibi", lnKeibi);
        query.setParameter("lnKbChiku", lnKbChiku);
        
        query.setMaxResults(1);
        return (UserOperationChikuInfoModel) query.getSingleResult();
    }
    
    public String getLnKeibiFromLnKbChiku(String lnKbChiku) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(LN_KEIBI, '') as lnKeibi ");
        strBuilder.append(" FROM R_KB_CHIKU chk"); 
        strBuilder.append(" where chk.LN_KB_CHIKU = :lnKbChiku");
        
        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnKbChiku", lnKbChiku);
        
        query.setMaxResults(1);
        return (String) query.getSingleResult();
    }
    
    public UserOperationChikuInfoModel getChikuInfoFromKbinf(String lnKbInf) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(kbCh.LN_KEIBI, '') as lnKeibi, ");
        strBuilder.append("     IFNULL(kbCh.LN_KB_CHIKU , '') as lnKbChiku");
        strBuilder.append(" FROM E_KB_INF kbInf"); 
        strBuilder.append("  INNER JOIN R_KB_CHIKU kbCh"); 
        strBuilder.append("   ON kbInf.LN_KB_CHIKU = kbCh.LN_KB_CHIKU");  
        strBuilder.append(" WHERE kbInf.LN_KB_INF = :lnKbInf");

        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "UserOperationChikuInfoFromKeibInfModelResult");
        
        query.setParameter("lnKbInf", lnKbInf);
        
        query.setMaxResults(1);
        return (UserOperationChikuInfoModel) query.getSingleResult();
    }
    
    public UserOperationChikuInfoModel getChikuInfoFromLnDev(String lnDev) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     IFNULL(dev.LN_KEIBI, '') as lnKeibi, ");
        strBuilder.append("     IFNULL(dev.LN_KB_CHIKU, '') as lnKbChiku ");
        strBuilder.append(" FROM R_DEV dev "); 
        strBuilder.append(" WHERE dev.LN_DEV = :lnDev "); 
        
        final Query query = entityManager.createNativeQuery(strBuilder.toString(), "UserOperationChikuInfoFromKeibInfModelResult");
        
        query.setParameter("lnDev", lnDev);
        
        query.setMaxResults(1);
        return (UserOperationChikuInfoModel) query.getSingleResult();
    }
    
    public String getLnKbChikuFromChiku(String lnKeibi, String chiku) {
        final StringBuilder strBuilder = new StringBuilder();
        
        strBuilder.append(" SELECT ");
        strBuilder.append("     ck.LN_KB_CHIKU as lnKbChiku");
        strBuilder.append(" FROM R_KB_CHIKU ck"); 
        strBuilder.append(" WHERE ck.LN_KEIBI = :lnKeibi");
        strBuilder.append(" AND ck.CHIKU = :chiku");
        
        final Query query = entityManager.createNativeQuery(strBuilder.toString());
        
        query.setParameter("lnKeibi", lnKeibi);
        query.setParameter("chiku", chiku);
        
        query.setMaxResults(1);
        return (String) query.getSingleResult();
    }
        
	public String getKeiykServiceInfo(String lnKeibi, String lnKbServiceTeikyoMst) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT		COUNT(*)");
		strBuilder.append(" FROM		R_KEIBI_KB_SERVICE_TEIKYO RKKST");
		strBuilder.append(" LEFT JOIN	M_KB_SERVICE_TEIKYO_MST MKSTM");
		strBuilder.append(" ON			RKKST.LN_KB_SERVICE_TEIKYO_MST = MKSTM.LN_KB_SERVICE_TEIKYO_MST");
		strBuilder.append(" WHERE		MKSTM.LN_KB_SERVICE_TEIKYO_MST = :lnKbServiceTeikyoMst");
		strBuilder.append(" AND			RKKST.LN_KEIBI = :lnKeibi");
		strBuilder.append(" AND			MKSTM.DEL_FLG  = :delFlg");
		strBuilder.append(" AND			RKKST.DEL_FLG  = :delFlg");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKbServiceTeikyoMst", lnKbServiceTeikyoMst);
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		
		return query.getSingleResult().toString();
	}
	
	public Date getLastLoginTs(String lnAcntUser) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT");
		strBuilder.append("			aau.LAST_LOGIN_TS as lastLoginTs");
		strBuilder.append(" FROM	A_ACNT_USER aau");
		strBuilder.append(" WHERE	aau.LN_ACNT_USER_COMMON = :lnAcntUser");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUser", lnAcntUser);

		return (Date)query.getSingleResult();
	}
	
	public String getChikuCountExcMain(String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		
		strBuilder.append(" SELECT      COUNT(*)");
		strBuilder.append(" FROM        R_KB_CHIKU  RKC");
		strBuilder.append(" WHERE       RKC.LN_KEIBI =  :lnKeibi");
		strBuilder.append(" AND         RKC.CHIKU    <> ''");
		strBuilder.append(" AND         RKC.DEL_FLG  =  :delFlg");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		
		return query.getSingleResult().toString();
	}

	public int countLnKeibi(String acntId, String lnKeibi) {
    	StringBuilder strBuilder = new StringBuilder();

		strBuilder.append("SELECT COUNT(*)");
        strBuilder.append(" FROM");
        strBuilder.append("    A_USER_OPERATION_HANI AS HANI");
        strBuilder.append(" INNER JOIN R_KEIBI AS KEIBI");
        strBuilder.append("    ON ( KEIBI.PATH_INF = LEFT(HANI.PATH_INF, :keibiLength)");
        strBuilder.append("    OR HANI.PATH_INF = LEFT(KEIBI.PATH_INF, :numLength))");
        strBuilder.append("    AND KEIBI.DEL_FLG = '0'");
        strBuilder.append(" INNER JOIN R_KEIYK AS KEIYAKU");
        strBuilder.append("    ON KEIYAKU.LN_KEIYK = LEFT(KEIBI.PATH_INF, :numLength)");
        strBuilder.append("    AND KEIYAKU.DEL_FLG = '0'");
		strBuilder.append(" WHERE");
		strBuilder.append("    HANI.LN_ACNT_USER_COMMON = :lnAcntUserCommon");
		strBuilder.append("    AND KEIBI.LN_KEIBI = :lnKeibi");
		
		
		final Query query = entityManager.createNativeQuery(strBuilder.toString());
        query.setParameter("lnAcntUserCommon", acntId);
		query.setParameter("lnKeibi", lnKeibi);
        query.setParameter("keibiLength", KeibisakiInfoConstant.KEIBI_LENGTH);
        query.setParameter("numLength", KeibisakiInfoConstant.NUM_LENGTH);
		
		return  ((BigInteger)query.getSingleResult()).intValue();
	}
}
