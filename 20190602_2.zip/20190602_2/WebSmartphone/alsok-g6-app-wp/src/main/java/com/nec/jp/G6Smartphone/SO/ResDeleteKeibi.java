package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResDeleteKeibi implements ErrorHandler {

	private String errorCode;						// エラーコード
	private String errorMsg;						// エラーメッセージ
	private List<AreaDataModel> areaItem;
	private String acntID;							// アカウントID
	private String userAuth;		// アカウント区分による権限チェック

	public ResDeleteKeibi() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.areaItem = new ArrayList<AreaDataModel>();
		this.acntID = "";
	}

	public ResDeleteKeibi(String errorCode, String errorMsg, List<AreaDataModel> areaItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.areaItem = areaItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public List<AreaDataModel> getAreaItem() {
		return areaItem;
	}
	public void setAreaItem(List<AreaDataModel> areaItem) {
		this.areaItem = areaItem;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
	public String getUserAuth() {
		return userAuth;
	}
	public void setUserAuth(String userAuth) {
		this.userAuth = userAuth;
	}
}
