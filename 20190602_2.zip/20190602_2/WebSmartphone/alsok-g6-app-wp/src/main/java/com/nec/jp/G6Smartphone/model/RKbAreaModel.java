package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.AreaDataModel;
import com.nec.jp.G6Smartphone.SO.AreaSensorDataModel;


/**
 * The persistent class for the R_KB_AREA database table.
 * 
 */
@SqlResultSetMappings({
	@SqlResultSetMapping(name="AreaSensorDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = AreaSensorDataModel.class,
				columns = {
					@ColumnResult(name = "areaNm"),
					@ColumnResult(name = "devNm")
				}
			)
		}
	),
	@SqlResultSetMapping(name="AreaDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = AreaDataModel.class,
				columns = {
					@ColumnResult(name = "lnKbArea"),
					@ColumnResult(name = "kbAreaNum"),
					@ColumnResult(name = "kbAreaNm")
				}
			)
		}
	)
})
@Entity
@Table(name="R_KB_AREA")
@NamedQuery(name="RKbAreaModel.findAll", query="SELECT r FROM RKbAreaModel r")
public class RKbAreaModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_KB_AREA")
	private String lnKbArea;

	@Column(name="DEL_FLG")
	private String delFlg;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="KB_AREA_NM")
	private String kbAreaNm;

	@Column(name="KB_AREA_NUM")
	private String kbAreaNum;

	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	@Column(name="ZAITAKU_KB_FLG")
	private String zaitakuKbFlg;

	public RKbAreaModel() {
	}

	public String getLnKbArea() {
		return this.lnKbArea;
	}

	public void setLnKbArea(String lnKbArea) {
		this.lnKbArea = lnKbArea;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getKbAreaNm() {
		return this.kbAreaNm;
	}

	public void setKbAreaNm(String kbAreaNm) {
		this.kbAreaNm = kbAreaNm;
	}

	public String getKbAreaNum() {
		return this.kbAreaNum;
	}

	public void setKbAreaNum(String kbAreaNum) {
		this.kbAreaNum = kbAreaNum;
	}

	public String getLnKbChiku() {
		return this.lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public String getZaitakuKbFlg() {
		return this.zaitakuKbFlg;
	}

	public void setZaitakuKbFlg(String zaitakuKbFlg) {
		this.zaitakuKbFlg = zaitakuKbFlg;
	}

}