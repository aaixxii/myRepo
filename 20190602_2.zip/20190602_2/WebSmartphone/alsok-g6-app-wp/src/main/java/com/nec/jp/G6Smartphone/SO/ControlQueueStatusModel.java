package com.nec.jp.G6Smartphone.SO;

public class ControlQueueStatusModel {

	private String sts;
	private String soapMsg;

	public ControlQueueStatusModel() {
		this.sts = "";
		this.soapMsg = "";
	}

	public ControlQueueStatusModel(String sts, String soapMsg) {
		this.sts = sts;
		this.soapMsg = soapMsg;
	}
	
	public ControlQueueStatusModel(String sts) {
		this.sts = sts;
	}

	public String getSts() {
		return sts;
	}

	public void setSts(String sts) {
		this.sts = sts;
	}

	public String getSoapMsg() {
		return soapMsg;
	}

	public void setSoapMsg(String soapMsg) {
		this.soapMsg = soapMsg;
	}
}
