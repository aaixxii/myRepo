package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResDisplayLiveImage implements ErrorHandler {

	private String errorCode;		// エラーコード
	private String errorMsg;		// エラーメッセージ
	private String ptz_enable_flg;
	private String preset_status;
	private String frame_rate;
	private String img_quality;
	private String param_set_flg;
	private String has_ope_auth;
	private String acnt_type_for_ope;
	private String ln_acnt_user_common_for_ope;
	private String url;
	private String acnt_name;
	private String acntID;

	public ResDisplayLiveImage() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.ptz_enable_flg = "";
		this.preset_status = "";
		this.frame_rate = "";
		this.img_quality = "";
		this.param_set_flg = "";
		this.has_ope_auth = "";
		this.acnt_type_for_ope = "";
		this.ln_acnt_user_common_for_ope = "";
		this.url = "";
		this.acnt_name = "";
		this.acntID = "";
	}

	public ResDisplayLiveImage(
			String ptz_enable_flg,
			String preset_status,
			String frame_rate,
			String img_quality,
			String param_set_flg,
			String has_ope_auth,
			String call_port,
			String call_ip,
			String acnt_type_for_ope,
			String ln_acnt_user_common_for_ope,
			String strem_id,
			String img_ip,
			String acnt_name,
			String trans_flg) {
		this.errorCode = G6Constant.SUCCESS_CD;
		this.errorMsg = "";
		this.ptz_enable_flg =  ptz_enable_flg;
		this.preset_status =  preset_status;
		this.frame_rate =  frame_rate;
		this.img_quality =  img_quality;
		this.param_set_flg =  param_set_flg;
		this.has_ope_auth =  has_ope_auth;
		this.acnt_type_for_ope =  acnt_type_for_ope;
		this.ln_acnt_user_common_for_ope =  ln_acnt_user_common_for_ope;
		this.url =  strem_id;
		this.acntID = "";
	}

	public ResDisplayLiveImage(String errorCode, String errorMsg,
			String ptz_enable_flg,
			String preset_status,
			String frame_rate,
			String img_quality,
			String param_set_flg,
			String has_ope_auth,
			String call_port,
			String call_ip,
			String acnt_type_for_ope,
			String ln_acnt_user_common_for_ope,
			String strem_id,
			String img_ip,
			String acnt_name,
			String trans_flg) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.ptz_enable_flg =  ptz_enable_flg;
		this.preset_status =  preset_status;
		this.frame_rate =  frame_rate;
		this.img_quality =  img_quality;
		this.param_set_flg =  param_set_flg;
		this.has_ope_auth =  has_ope_auth;
		this.acnt_type_for_ope =  acnt_type_for_ope;
		this.ln_acnt_user_common_for_ope =  ln_acnt_user_common_for_ope;
		this.url =  strem_id;
		this.acnt_name =  acnt_name;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getPtz_enable_flg() {
		return ptz_enable_flg;
	}

	public void setPtz_enable_flg(String ptz_enable_flg) {
		this.ptz_enable_flg = ptz_enable_flg;
	}

	public String getPreset_status() {
		return preset_status;
	}

	public void setPreset_status(String preset_status) {
		this.preset_status = preset_status;
	}

	public String getFrame_rate() {
		return frame_rate;
	}

	public void setFrame_rate(String frame_rate) {
		this.frame_rate = frame_rate;
	}

	public String getImg_quality() {
		return img_quality;
	}

	public void setImg_quality(String img_quality) {
		this.img_quality = img_quality;
	}

	public String getParam_set_flg() {
		return param_set_flg;
	}

	public void setParam_set_flg(String param_set_flg) {
		this.param_set_flg = param_set_flg;
	}

	public String getHas_ope_auth() {
		return has_ope_auth;
	}

	public void setHas_ope_auth(String has_ope_auth) {
		this.has_ope_auth = has_ope_auth;
	}

	public String getAcnt_type_for_ope() {
		return acnt_type_for_ope;
	}

	public void setAcnt_type_for_ope(String acnt_type_for_ope) {
		this.acnt_type_for_ope = acnt_type_for_ope;
	}

	public String getLn_acnt_user_common_for_ope() {
		return ln_acnt_user_common_for_ope;
	}

	public void setLn_acnt_user_common_for_ope(String ln_acnt_user_common_for_ope) {
		this.ln_acnt_user_common_for_ope = ln_acnt_user_common_for_ope;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String strem_id) {
		this.url = strem_id;
	}

	public String getAcnt_name() {
		return acnt_name;
	}

	public void setAcnt_name(String acnt_name) {
		this.acnt_name = acnt_name;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}

}
