package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.AcntUserInfoModel;
import com.nec.jp.G6Smartphone.SO.AvailableMenuModel;
import com.nec.jp.G6Smartphone.SO.ResYukoAcntUserInf;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.com.SZWP0200ComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP0200Service;
import com.nec.jp.G6Smartphone.service.g6.SZWP0400Service;
import com.nec.jp.G6Smartphone.service.ghs.CommonGhsService;
import com.nec.jp.G6Smartphone.service.ghs.SZWP0200GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWP0200Controller {

    private static final ApplicationLog appLog = new ApplicationLog(SZWP0200Controller.class);

    //JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
    @Autowired
    CommonComService commonComService;
    @Autowired
    SZWP0200Service sZWP0200Service;
    @Autowired
    SZWP0200ComService sZWP0200ComService;
    @Autowired
    CommonService commonService;
    @Autowired
    SZWP0200GhsService sZWP0200GhsService;
    @Autowired
	SZWP0400Service sZWP0400Service;
    @Autowired
    CommonGhsService commonGhsService;
    
    //private YukoAcntUserInf mYukoInf;
    /*
     * Update K_ACNT_USER_LOGIN_STS table
     * 
     * @param: acntID, acntNm, language return: object ErrorDataModel as JSON
     */
    @RequestMapping(value = "/languageChange", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public @ResponseBody String languageChange(@RequestBody String strParam) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0200Controller.languageChange()");
        String jsonResult = "";
        String acntLanguage = G6CodeConsts.CD238.JAPANESE;
        String acntType = null;
        String acntID = null;
        String lnKeibi = null;
        AvailableMenuModel availableMenuModel = new AvailableMenuModel();
        Map<String, Object> mapParam = new HashMap<String, Object>();

        try {
            // リクエスト情報からパラメータを取得する
            mapParam = G6Common.readParam(strParam);

            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.languageChange()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.languageChange()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
            
            // リクエスト情報から選択言語種別を取得する
            if (null != mapParam.get(RequestParam.language.getValue())
                    && !"".equals(mapParam.get(RequestParam.language.getValue()))) {
                acntLanguage = mapParam.get(RequestParam.language.getValue()).toString();
            }

            // リクエスト情報を検証する
            if (mapParam.size() != 5) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.languageChange()");
                return jsonResult;
            }

            // Build require parameters
            List<String> lstRequiredParam = new ArrayList<String>() {
                private static final long serialVersionUID = 1L;
                {
                    add(RequestParam.acntID.getValue());
                    add(RequestParam.acntNm.getValue());
                    add(RequestParam.language.getValue());
                    add(RequestParam.lnKeibi.getValue());
                    add(RequestParam.acntSbt.getValue());
                }
            };

            if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.languageChange()");
                return jsonResult;
            }

            // 言語切替処理
            // 8-3.言語選択ＤＢ更新内容
            Boolean updateSts = sZWP0200ComService.updateSelectedLanguage(
                    mapParam.get(RequestParam.acntID.getValue()).toString(),
                    mapParam.get(RequestParam.acntNm.getValue()).toString(),
                    mapParam.get(RequestParam.language.getValue()).toString());

            if (!updateSts) {
                jsonResult = G6Common.messageUpdateLogHandler(availableMenuModel, G6Constant.FAIL_HTML_CD,
                        ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.UPDATE_SELECTED_LANG.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.languageChange()");
                return jsonResult;
            }
            
            acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
 			if (null == acntType) {
 				jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.FAIL_POPUP_CD, 
 						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

 				// 処理終了
 				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getMenuPassInf()");
 				return jsonResult;
 			}
 			
 			acntID = mapParam.get(RequestParam.acntID.getValue()).toString();

 			lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
            if (null == lnKeibi) {
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.FAIL_POPUP_CD, 
                        ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getMenuPassInf()");
                return jsonResult;
            }
             			
 			// 利用可能メニューの取得（開始） #########################
 			availableMenuModel = this.checkAvailableMenu(acntType, acntID, lnKeibi);
 			// 利用可能メニューの取得（終了） #########################
            
            availableMenuModel.setErrorCode(G6Constant.SUCCESS_CD);
            
            //デコード済acntIDを設定したJWT認証トークンを付与
            availableMenuModel.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
            
            jsonResult = G6Common.parseJSON(availableMenuModel, acntLanguage);

        } catch (ApplicationException e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            jsonResult = G6Common.messageLogHandler(availableMenuModel, G6Constant.FAIL_HTML_CD, e.getExceptionCode(),
                    e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            jsonResult = G6Common.messageLogHandler(availableMenuModel, G6Constant.FAIL_HTML_CD,
                    ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
        }

        // 処理終了
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.languageChange()");
        return jsonResult;
    }

    /*
     * Get data from A_USER_ACNT_AUTH_MST table
     * 
     * @param: acntID return: object ResgetMenuPassInf as JSON
     */
    @RequestMapping(value = "/getMenuPassInf", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public @ResponseBody String getMenuPassInf(@RequestBody String strParam) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0200Controller.getMenuPassInf()");
        String jsonResult = "";
        String acntLanguage = G6CodeConsts.CD238.JAPANESE;
        AvailableMenuModel availableMenuModel = new AvailableMenuModel();
        Map<String, Object> mapParam = new HashMap<String, Object>();
        String acntType = null;
        String acntID = null;
        String lnKeibi = null;

        try {
            // リクエスト情報からパラメータを取得する
            mapParam = G6Common.readParam(strParam);
            
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getMenuPassInf()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getMenuPassInf()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            // 選択されている警備先によりAcntIDをGHS契約者、GHS利用者に切り替える。
            commonService.convertAcntInfo(mapParam, tokenMapParam);
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(), tokenMapParam.get(RequestParam.acntID.getValue()));
            
            if (null != mapParam.get(RequestParam.acntID.getValue())
                    && !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
                // 選択言語種別の取得
                acntLanguage = commonComService
                        .getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
            }

            // リクエスト情報を検証する
            if (mapParam.size() != 3) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getMenuPassInf()");
                return jsonResult;
            }

            // Build require parameters
            final List<String> lstRequiredParam = new ArrayList<String>() {
                private static final long serialVersionUID = 1L;
                {
                    add(RequestParam.acntID.getValue());
                    add(RequestParam.acntSbt.getValue());
                    add(RequestParam.lnKeibi.getValue());
                }
            };
            if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getMenuPassInf()");
                return jsonResult;
            }
            
            acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
 			if (null == acntType) {
 				jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.FAIL_POPUP_CD, 
 						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

 				// 処理終了
 				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getMenuPassInf()");
 				return jsonResult;
 			}
 			
 			acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
 			lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
             			
 			// 利用可能メニューの取得（開始） #########################
 			availableMenuModel = this.checkAvailableMenu(acntType, acntID, lnKeibi);
 			// 利用可能メニューの取得（終了） #########################
 			
 			availableMenuModel.setErrorCode(G6Constant.SUCCESS_CD);
 			
            //デコード済acntIDを設定したJWT認証トークンを付与
 			availableMenuModel.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
 			
 			jsonResult = G6Common.parseJSON(availableMenuModel, acntLanguage);
            
        } catch (ApplicationException e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            jsonResult = G6Common.messageLogHandler(availableMenuModel, G6Constant.FAIL_HTML_CD, e.getExceptionCode(),
                    e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(availableMenuModel, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            jsonResult = G6Common.messageLogHandler(availableMenuModel, G6Constant.FAIL_HTML_CD,
                    ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
        }

        // 処理終了
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getMenuPassInf()");
        return jsonResult;
    }
    

    /**
     * <pre>
     *     
     * 利用者アカウント区分チェック       
     * ・アカウント区分により利用可能な画面かどうかを判断する。
     * </pre>
     * 
     * @param model
     * @param dispId
     * @return 利用不可(0),利用可（2),個別権限(3)
     */
    @RequestMapping(value = "/getInvalidateUserAcntKbn", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public @ResponseBody String getInvalidateUserAcntKbn(@RequestBody String strParam) {
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP0200Controller.getInvalidateUserAcntKbn()");
        String jsonResult = "";
        String acntLanguage = G6CodeConsts.CD238.JAPANESE;
        ResYukoAcntUserInf resYukoInf = new ResYukoAcntUserInf();
        Map<String, Object> mapParam = new HashMap<String, Object>();

        try {
            // リクエスト情報からパラメータを取得する
            mapParam = G6Common.readParam(strParam);
            
            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resYukoInf, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getInvalidateUserAcntKbn()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resYukoInf, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getInvalidateUserAcntKbn()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
            
            if (null != mapParam.get(RequestParam.acntID.getValue())
                    && !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
                // 選択言語種別の取得
                acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
            }
            // リクエスト情報を検証する
            if (mapParam.size() != 3) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(resYukoInf, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getInvalidateUserAcntKbn()");
                return jsonResult;
            }
            // Build require parameters
            final List<String> lstRequiredParam = new ArrayList<String>() {
                private static final long serialVersionUID = 1L;
                {
                    add(RequestParam.acntID.getValue());
                    add(RequestParam.acntSbt.getValue());
                    add(RequestParam.dispId.getValue());
                }
            };
            if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
                // リクエスト検証
                jsonResult = G6Common.messageHandler(resYukoInf, G6Constant.FAIL_POPUP_CD,
                        ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
                // 処理終了
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getInvalidateUserAcntKbn()");
                return jsonResult;
            }
            
            // リクエスト情報からアカウント種別を取得する
         	String acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
         	
            // 画面情報（有効利用者アカウント区分を取得
            //final int menupass = getYukoAcntUserKbnInf(mapParam.get(RequestParam.acntID.getValue()).toString(), 
            //        mapParam.get(RequestParam.dispId.getValue()).toString());
            int menupass = 2; //GHSユーザの場合は利用可「 2」
         	
         	// アカウント種別が、次期警備の場合
         	if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
         		menupass = G6Common.invalidateUserAcntKbn(commonComService, commonService,
         						mapParam.get(RequestParam.acntID.getValue()).toString(), 
         				 		mapParam.get(RequestParam.dispId.getValue()).toString());
         	}
         	
            if (menupass <= 0) {
                if (menupass == -1) {
                    // exception
                    jsonResult = G6Common.messageHandler(resYukoInf, G6Constant.FAIL_POPUP_CD, ErrorKey.COMMON_AUTH_EXCEPTION.getValue(), acntLanguage);
                } else {
                    // 画面情報が存在しない場合は利用不可
                    jsonResult = G6Common.messageHandler(resYukoInf, G6Constant.FAIL_POPUP_CD, ErrorKey.NO_PERMISSION.getValue(), acntLanguage);
                }
            } else {
                //有効利用者アカウントの場合、利用可
                resYukoInf.setErrorCode(G6Constant.SUCCESS_CD);
                //if (mYukoInf != null) {
                //    resYukoInf.setMenupassInf(mYukoInf.getMenupassInf());
                //    resYukoInf.setChikuFlg(mYukoInf.getChikuFlg());
                //    resYukoInf.setYukoAcntUserKbn(mYukoInf.getYukoAcntUserKbn());
                //}
                //デコード済acntIDを設定したJWT認証トークンを付与
                resYukoInf.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
                jsonResult = G6Common.parseJSON(resYukoInf, acntLanguage);
                
            }
        } catch (ApplicationException e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            jsonResult = G6Common.messageLogHandler(resYukoInf, G6Constant.FAIL_HTML_CD, e.getExceptionCode(),
                    e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resYukoInf, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resYukoInf, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
            jsonResult = G6Common.messageLogHandler(resYukoInf, G6Constant.FAIL_HTML_CD,
                    ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
        }
        appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP0200Controller.getInvalidateUserAcntKbn()");
        return jsonResult;
    }
    
    private AvailableMenuModel checkAvailableMenu(String acntType, String acntID, String lnKeibi) throws Exception {
    	AvailableMenuModel availableMenuModel = new AvailableMenuModel();
    	if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
 			
	            // 利用者アカウント情報(アカウント区分)の取得										
	        	AcntUserInfoModel acntUserInfo = sZWP0200ComService.selectAcntUserInfo(acntID);
	        	
	        	if (acntUserInfo == null) {
	        		// Do nothing
	        	} else if (acntUserInfo.getAcntUserKbn().equals("0") || acntUserInfo.getAcntUserKbn().equals("1")) {
	        		// 代表メイン管理者、またはメイン管理者
	        		availableMenuModel = this.getOwnerAvailableMenuModelG6(acntID, lnKeibi);
	        	} else if (acntUserInfo.getAcntUserKbn().equals("2") || acntUserInfo.getAcntUserKbn().equals("3")) {
	        		// サブ管理者、または利用者
	        		availableMenuModel = this.getUserAvailableMenuModelG6(acntID);
	        	}      
        } else if ( acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION) ) {
            // メイン管理者
            availableMenuModel = this.getOwnerAvailableMenuModelGHS(lnKeibi);
        } else if ( acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) ) {
            // メイン管理者以外
            availableMenuModel = this.getUserAvailableMenuModelGHS(acntID, lnKeibi);
        }
    	return availableMenuModel;
    }

    /**
     * メニュー項目表示権限の取得（G6利用者）
     * @param lnAcntUserCommon 
     */
    private AvailableMenuModel getUserAvailableMenuModelG6(String lnAcntUserCommon) throws Exception {
    	AvailableMenuModel availableMenuModel = new AvailableMenuModel();
    	
        // 警備開始/解除
        String kOpe = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.K_OPE);
        availableMenuModel.setKOpe(kOpe);
        
        // 履歴の確認
        String hChkKeibi = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.H_CHK_KEIBI);
        String hChkRpers = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.H_CHK_RPERS);
        String hChkMpers = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.H_CHK_MPERS);
        String hChkEvent = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.H_CHK_EVENT);
        
        if (hChkKeibi.equals("0") && 
        		hChkRpers.equals("0") && 
        			hChkMpers.equals("0") && 
        				hChkEvent.equals("0") ) {
        	// 履歴の確認に表示できるサブメニューが無い場合
        	availableMenuModel.setHChk("0");
        } else {
        	// 履歴の確認に表示できるサブメニューがある場合
        	availableMenuModel.setHChk("2");
        }
        
        availableMenuModel.setHChkKeibi(hChkKeibi);
        availableMenuModel.setHChkRpers(hChkRpers);
        availableMenuModel.setHChkMpers(hChkMpers);
        availableMenuModel.setHChkEvent(hChkEvent);   
        
        // 遠隔設備操作
        String rOpe = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.R_OPE);
        availableMenuModel.setROpe(rOpe);

        // 画像メニュー
        String gMenLivev = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.G_MEN_LIVEV);
        String gMenAccum = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.G_MEN_ACCUM);
        
        if (gMenLivev.equals("0") && 
        		gMenAccum.equals("0")  ) {
        	// 画像メニューに表示できるサブメニューが無い場合
        	availableMenuModel.setGMen("0");
        } else {
        	// 画像メニューに表示できるサブメニューがある場合
        	availableMenuModel.setGMen("2");
        }
        
        availableMenuModel.setGMenLivev(gMenLivev);
        availableMenuModel.setGMenAccum(gMenAccum);
        
        // ALSOKからのお知らせ
        availableMenuModel.setANot("2");
        
        // ALSOKへのお問い合わせ
        availableMenuModel.setAAsk("2");
        
        return availableMenuModel;
    }
 
    /**
     * メニュー項目表示権限の取得（G6管理者）
     * @param lnAcntUserCommon 
     * @param lnKeibi 
     */
    private AvailableMenuModel getOwnerAvailableMenuModelG6(String lnAcntUserCommon, String lnKeibi) throws Exception {
    	AvailableMenuModel availableMenuModel = new AvailableMenuModel();
    	
        // 警備開始/解除
		// 機械警備サービスの契約情報取得
    	String keibiServiceInfo = commonService.getKeiykServiceInfo(lnKeibi, G6Constant.CD_SERVICE_TEIKYO.KEIBI_SERVICE);

		if(keibiServiceInfo.equals("1")) {
			availableMenuModel.setKOpe("2");
		}else {
			availableMenuModel.setKOpe("0");
		}
        
        // 履歴の確認
        //String hChkKeibi = sZWP0200Service.getPrivilegeInfo(lnAcntUserCommon, G6Constant.CD_ACNT_AUTH_MST.H_CHK_KEIBI);
        String hChkRpers = commonService.getKeiykServiceInfo(lnKeibi, G6Constant.CD_SERVICE_TEIKYO.RPERS_SERVICE);
        String hChkMpers = commonService.getKeiykServiceInfo(lnKeibi, G6Constant.CD_SERVICE_TEIKYO.MPERS_SERVICE);
        String hChkEvent = commonService.getKeiykServiceInfo(lnKeibi, G6Constant.CD_SERVICE_TEIKYO.EVENT_PICTURE);
        
        if (keibiServiceInfo.equals("0") && 
        		hChkRpers.equals("0") && 
        			hChkMpers.equals("0") && 
        				hChkEvent.equals("0") ) {
        	// 履歴の確認に表示できるサブメニューが無い場合
        	availableMenuModel.setHChk("0");
        } else {
        	// 履歴の確認に表示できるサブメニューがある場合
        	availableMenuModel.setHChk("2");
        }
        
        // 機械警備サービスの契約が無い場合、サブメニュー（警備履歴一覧）を表示しない。
        if(keibiServiceInfo.equals("1")) {
			availableMenuModel.setHChkKeibi("2");
		}else {
			availableMenuModel.setHChkKeibi("0");
		}

        // 登録人物情報サービス
        if(hChkRpers.equals("1")) {
			availableMenuModel.setHChkRpers("2");
		}else {
			availableMenuModel.setHChkRpers("0");
		}
        
        // 重要犯罪者情報サービス
        if(hChkMpers.equals("1")) {
			availableMenuModel.setHChkMpers("2");
		}else {
			availableMenuModel.setHChkMpers("0");
		}
        
        // イベント画像サービス
        if(hChkEvent.equals("1")) {
			availableMenuModel.setHChkEvent("2");
		}else {
			availableMenuModel.setHChkEvent("0");
		}
        
        // 遠隔設備操作
        String rOpe = commonService.getKeiykServiceInfo(lnKeibi, G6Constant.CD_SERVICE_TEIKYO.REMOTE_OPERATION);

        if(rOpe.equals("1")) {
			availableMenuModel.setROpe("2");
		}else {
			availableMenuModel.setROpe("0");
		}

        // 画像メニュー
        String gMenLivev = sZWP0200Service.getCamCountInfo(lnKeibi);
        String gMenAccum = commonService.getKeiykServiceInfo(lnKeibi, G6Constant.CD_SERVICE_TEIKYO.ACCUM_PICTURE);
        
        if (gMenLivev.equals("0") && 
        		gMenAccum.equals("0")  ) {
        	// 画像メニューに表示できるサブメニューが無い場合
        	availableMenuModel.setGMen("0");
        } else {
        	// 画像メニューに表示できるサブメニューがある場合
        	availableMenuModel.setGMen("2");
        }
        
        // ライブ閲覧
        if(!gMenLivev.equals("0")) {
			availableMenuModel.setGMenLivev("2");
		}else {
			availableMenuModel.setGMenLivev("0");
		}
        
        // 蓄積画像閲覧
        if(gMenAccum.equals("1")) {
			availableMenuModel.setGMenAccum("2");
		}else {
			availableMenuModel.setGMenAccum("0");
		}
        
        // ALSOKからのお知らせ
        availableMenuModel.setANot("2");
        
        // ALSOKへのお問い合わせ
        availableMenuModel.setAAsk("2");
        
        return availableMenuModel;
    }

    /**
     * メニュー項目表示権限の取得（GHS利用者）
     * @param lnAcntUserCommon 
     */
    private AvailableMenuModel getUserAvailableMenuModelGHS(String lnAcntUser, String lnKeibi) throws Exception {
    	AvailableMenuModel availableMenuModel = new AvailableMenuModel();
    	
        // 警備開始/解除
        String kOpe = sZWP0200GhsService.getKeibiSetPrivilegeInfo(lnAcntUser, lnKeibi);
        if ( kOpe.equals("1") ) {
        	// 利用可能な場合
        	availableMenuModel.setKOpe("2");
        } else {
        	// 利用不可の場合
        	availableMenuModel.setHChk("0");
        }
        
        // 履歴の確認(警備履歴一覧)
        String hChkKeibi = sZWP0200GhsService.getKeibiHstPrivilegeInfo(lnAcntUser, lnKeibi);
        		
        if ( hChkKeibi.equals("1") ) {
        	// 履歴の確認に表示できるサブメニュー(警備履歴一覧)がある場合
        	availableMenuModel.setHChk("2");
        	availableMenuModel.setHChkKeibi("2");
        } else {
        	// 履歴の確認に表示できるサブメニュー(警備履歴一覧)が無い場合
        	availableMenuModel.setHChk("0");
        	availableMenuModel.setHChkKeibi("0");
        }

        // 登録人物情報サービス(次期警備サービスのため、GHSアカウントでは無効)
        availableMenuModel.setHChkRpers("0");
        
        // 重要犯罪者情報サービス(次期警備サービスのため、GHSアカウントでは無効)
        availableMenuModel.setHChkMpers("0");
        
        // イベント画像サービス(次期警備サービスのため、GHSアカウントでは無効)
		availableMenuModel.setHChkEvent("0");
        
        // 遠隔設備操作
        String rOpe = sZWP0200GhsService.getRmtSetPrivilegeInfo(lnAcntUser, lnKeibi);
        if ( rOpe.equals("1") ) {
        	// 利用可能な場合
        	availableMenuModel.setROpe("2");
        } else {
        	// 利用不可の場合
        	availableMenuModel.setROpe("0");
        }

        // 画像メニュー(次期警備サービスのため、GHSアカウントでは無効)
        availableMenuModel.setGMen("0");
        availableMenuModel.setGMenLivev("0");
        availableMenuModel.setGMenAccum("0");
        
        // ALSOKからのお知らせ
        availableMenuModel.setANot("2");
        
        // ALSOKへのお問い合わせ
        availableMenuModel.setAAsk("2");
        
        return availableMenuModel;
    }
 
    /**
     * メニュー項目表示権限の取得（GHS管理者）
     * @param lnAcntUserCommon 
     * @param lnKeibi 
     */
    private AvailableMenuModel getOwnerAvailableMenuModelGHS(String lnKeibi) throws Exception {
    	AvailableMenuModel availableMenuModel = new AvailableMenuModel();
    	
        // 警備開始/解除
		// ユーザWEBオプションの契約情報の取得＆確認
    	String keibiServiceInfo = sZWP0200GhsService.getKeiykServiceInfo(lnKeibi);

		if(keibiServiceInfo.equals("1")) {
			availableMenuModel.setKOpe("2");
		}else {
			availableMenuModel.setKOpe("0");
		}
        
        if (keibiServiceInfo.equals("0") ) {
        	// 機械警備サービスの契約が無い場合、メニュー（履歴の確認）＆サブメニュー（警備履歴一覧）を表示しない。
        	availableMenuModel.setHChk("0");
        	availableMenuModel.setHChkKeibi("0");
        } else {
        	// 機械警備サービスの契約がある場合、メニュー（履歴の確認）＆サブメニュー（警備履歴一覧）を表示する。
        	availableMenuModel.setHChk("2");
        	availableMenuModel.setHChkKeibi("2");
        }
        
        // 登録人物情報サービス(次期警備サービスのため、GHSアカウントでは無効)
        availableMenuModel.setHChkRpers("0");
        
        // 重要犯罪者情報サービス(次期警備サービスのため、GHSアカウントでは無効)
        availableMenuModel.setHChkMpers("0");
        
        // イベント画像サービス(次期警備サービスのため、GHSアカウントでは無効)
		availableMenuModel.setHChkEvent("0");
        
        // 遠隔設備操作
		// ユーザWEBオプションの契約情報の確認
        if(keibiServiceInfo.equals("1")) {
			availableMenuModel.setROpe("2");
		}else {
			availableMenuModel.setROpe("0");
		}

        // 画像メニュー(次期警備サービスのため、GHSアカウントでは無効)
        availableMenuModel.setGMen("0");
        availableMenuModel.setGMenLivev("0");
        availableMenuModel.setGMenAccum("0");
        
        // ALSOKからのお知らせ
        availableMenuModel.setANot("2");
        
        // ALSOKへのお問い合わせ
        availableMenuModel.setAAsk("2");
        
        return availableMenuModel;
    }

}
