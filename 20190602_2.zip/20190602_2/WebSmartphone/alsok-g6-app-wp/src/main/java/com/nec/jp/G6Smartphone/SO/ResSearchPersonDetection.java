package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResSearchPersonDetection implements ErrorHandler {

	private String errorCode;
	private String errorMsg;
	private String dtTo;
	private List<SdKobetuNmDataModel> sdKobetuNmItem;
	private String acntID;
	
	public ResSearchPersonDetection() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;;
		this.errorMsg = "";
		this.dtTo = "";
		this.sdKobetuNmItem = new ArrayList<SdKobetuNmDataModel>();
		this.acntID = "";
	}
	public ResSearchPersonDetection(String errorCode, String errorMsg, String dtTo,
			List<SdKobetuNmDataModel> sdKobetuNmItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.dtTo = dtTo;
		this.sdKobetuNmItem = sdKobetuNmItem;
		this.acntID = "";
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getDtTo() {
		return dtTo;
	}
	public void setDtTo(String dtTo) {
		this.dtTo = dtTo;
	}
	public List<SdKobetuNmDataModel> getSdKobetuNmItem() {
		return sdKobetuNmItem;
	}
	public void setSdKobetuNmItem(List<SdKobetuNmDataModel> sdKobetuNmItem) {
		this.sdKobetuNmItem = sdKobetuNmItem;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
