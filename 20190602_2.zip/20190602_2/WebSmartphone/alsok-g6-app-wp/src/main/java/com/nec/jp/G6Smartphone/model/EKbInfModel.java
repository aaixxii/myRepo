package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.KbInfDataModel;
import com.nec.jp.G6Smartphone.SO.SensorHistoryDataModel;


/**
 * The persistent class for the E_KB_INF database table.
 * 
 */
@SqlResultSetMappings({
	@SqlResultSetMapping(name="SensorHistoryDataModelResult",
			classes = {
				@ConstructorResult(
					targetClass = SensorHistoryDataModel.class,
					columns = {
						@ColumnResult(name = "hasseiDate"),
						@ColumnResult(name = "hasseiTime"),
						@ColumnResult(name = "kbAreaNm"),
						@ColumnResult(name = "devNm"),
						@ColumnResult(name = "videoFileName"),
						@ColumnResult(name = "lnKbInf")
					}
				)
			}
		),
	@SqlResultSetMapping(name="KbInfDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = KbInfDataModel.class,
				columns = {
					@ColumnResult(name = "sigHasseiTs"),
					@ColumnResult(name = "nickName"),
					@ColumnResult(name = "keiykNm"),
					@ColumnResult(name = "keibiName"),
					@ColumnResult(name = "devNm"),
					@ColumnResult(name = "cntLnKbInf"),
					@ColumnResult(name = "lnRAuthPicInf"),
					@ColumnResult(name = "lnKbInf")
				}
			)
		}
	)
})
@Entity
@Table(name="E_KB_INF")
@NamedQuery(name="EKbInfModel.findAll", query="SELECT e FROM EKbInfModel e")
public class EKbInfModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_KB_INF")
	private String lnKbInf;

	@Column(name="C0_MODE")
	private String c0Mode;

	@Column(name="CAMERA_NO")
	private String cameraNo;

	@Column(name="CARD_FRMT_ID")
	private String cardFrmtId;

	@Column(name="CARD_KAHEN_ID")
	private String cardKahenId;

	@Column(name="CARD_KOTEI_ID")
	private String cardKoteiId;

	@Column(name="CMD_SEQ_NUM_9")
	private String cmdSeqNum9;

	@Column(name="CMD_VER_9")
	private String cmdVer9;

	@Column(name="DENKEI_9")
	private String denkei9;

	@Column(name="DEV_NM")
	private String devNm;

	@Column(name="DEV_NUM")
	private String devNum;

	@Column(name="DN0_STS_MAIN_FLG")
	private String dn0StsMainFlg;

	@Column(name="DN0_STS_SUB_ADDR_FLG")
	private String dn0StsSubAddrFlg;

	@Column(name="EXCEPT_SIG_FLG")
	private String exceptSigFlg;

	@Column(name="FRAME_RATE")
	private String frameRate;

	@Column(name="GC_SEND_FLG")
	private String gcSendFlg;

	@Column(name="GENERATION_TS_9")
	private String generationTs9;

	@Column(name="GOUKI_9")
	private String gouki9;

	@Column(name="GW_HOST_NM")
	private String gwHostNm;

	@Column(name="GW_IP_KIND")
	private String gwIpKind;

	@Column(name="GW_RCV_IP_ADDR")
	private String gwRcvIpAddr;

	@Column(name="GW_RCV_TS")
	private String gwRcvTs;

	@Column(name="IMAGE_COUNT")
	private String imageCount;

	@Column(name="IMAGE_START_TIME")
	private String imageStartTime;

	@Column(name="IMG_NUM")
	private String imgNum;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="INTERPHONE_NO")
	private String interphoneNo;

	@Column(name="K_INDEX_NUM")
	private String kIndexNum;

	@Column(name="KN_STS_MAIN_FLG")
	private String knStsMainFlg;

	@Column(name="KN_STS_SUB_ADDR_FLG")
	private String knStsSubAddrFlg;

	@Column(name="LINE_KIND_9")
	private String lineKind9;

	@Column(name="LN_KB_CHIKU")
	private String lnKbChiku;

	@Column(name="LN_QUE_KB_SIG")
	private String lnQueKbSig;

	@Column(name="MIC_INTERPHONE_LINK_FLG")
	private String micInterphoneLinkFlg;

	@Column(name="MIC_NO")
	private String micNo;

	@Column(name="MODEL_TYPE")
	private String modelType;

	@Column(name="N0_STS_MAIN_FLG")
	private String n0StsMainFlg;

	@Column(name="N0_STS_SUB_ADDR_FLG")
	private String n0StsSubAddrFlg;

	@Column(name="OUT_REPORT_HYOJI_FLG")
	private String outReportHyojiFlg;

	@Column(name="RM_FLG")
	private String rmFlg;

	@Column(name="RM_KIND")
	private String rmKind;

	@Column(name="SIG_CODE")
	private String sigCode;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SIG_HASSEI_TS")
	private Date sigHasseiTs;

	@Column(name="SIG_KIND_1")
	private String sigKind1;

	@Column(name="SIG_KIND_2")
	private String sigKind2;

	@Column(name="SIG_NM")
	private String sigNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SIG_RCV_TS")
	private Date sigRcvTs;

	@Column(name="SINPO_FLG")
	private String sinpoFlg;

	@Column(name="SPEAKER_NO")
	private String speakerNo;

	@Column(name="SUB_ADDR_9")
	private String subAddr9;

	@Column(name="TR_NUM_9")
	private String trNum9;

	@Column(name="TRANSMITTER_9_ID")
	private String transmitter9Id;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	@Column(name="VER_FW")
	private String verFw;

	@Column(name="VIDEO_DEV_NUM")
	private String videoDevNum;

	@Column(name="VIDEO_FILE_NAME")
	private String videoFileName;

	@Column(name="VIDEO_LINK_FLG")
	private String videoLinkFlg;

	@Column(name="VIDEO_RECORD_COUNT")
	private String videoRecordCount;

	@Column(name="VIDEO_RECORD_TIME")
	private String videoRecordTime;

	@Column(name="VOICE_DEV_NUM")
	private String voiceDevNum;

	@Column(name="VOICE_FILE_NAME")
	private String voiceFileName;

	@Column(name="VOICE_RECORD_TIME")
	private String voiceRecordTime;

	public EKbInfModel() {
	}

	public String getLnKbInf() {
		return this.lnKbInf;
	}

	public void setLnKbInf(String lnKbInf) {
		this.lnKbInf = lnKbInf;
	}

	public String getC0Mode() {
		return this.c0Mode;
	}

	public void setC0Mode(String c0Mode) {
		this.c0Mode = c0Mode;
	}

	public String getCameraNo() {
		return this.cameraNo;
	}

	public void setCameraNo(String cameraNo) {
		this.cameraNo = cameraNo;
	}

	public String getCardFrmtId() {
		return this.cardFrmtId;
	}

	public void setCardFrmtId(String cardFrmtId) {
		this.cardFrmtId = cardFrmtId;
	}

	public String getCardKahenId() {
		return this.cardKahenId;
	}

	public void setCardKahenId(String cardKahenId) {
		this.cardKahenId = cardKahenId;
	}

	public String getCardKoteiId() {
		return this.cardKoteiId;
	}

	public void setCardKoteiId(String cardKoteiId) {
		this.cardKoteiId = cardKoteiId;
	}

	public String getCmdSeqNum9() {
		return this.cmdSeqNum9;
	}

	public void setCmdSeqNum9(String cmdSeqNum9) {
		this.cmdSeqNum9 = cmdSeqNum9;
	}

	public String getCmdVer9() {
		return this.cmdVer9;
	}

	public void setCmdVer9(String cmdVer9) {
		this.cmdVer9 = cmdVer9;
	}

	public String getDenkei9() {
		return this.denkei9;
	}

	public void setDenkei9(String denkei9) {
		this.denkei9 = denkei9;
	}

	public String getDevNm() {
		return this.devNm;
	}

	public void setDevNm(String devNm) {
		this.devNm = devNm;
	}

	public String getDevNum() {
		return this.devNum;
	}

	public void setDevNum(String devNum) {
		this.devNum = devNum;
	}

	public String getDn0StsMainFlg() {
		return this.dn0StsMainFlg;
	}

	public void setDn0StsMainFlg(String dn0StsMainFlg) {
		this.dn0StsMainFlg = dn0StsMainFlg;
	}

	public String getDn0StsSubAddrFlg() {
		return this.dn0StsSubAddrFlg;
	}

	public void setDn0StsSubAddrFlg(String dn0StsSubAddrFlg) {
		this.dn0StsSubAddrFlg = dn0StsSubAddrFlg;
	}

	public String getExceptSigFlg() {
		return this.exceptSigFlg;
	}

	public void setExceptSigFlg(String exceptSigFlg) {
		this.exceptSigFlg = exceptSigFlg;
	}

	public String getFrameRate() {
		return this.frameRate;
	}

	public void setFrameRate(String frameRate) {
		this.frameRate = frameRate;
	}

	public String getGcSendFlg() {
		return this.gcSendFlg;
	}

	public void setGcSendFlg(String gcSendFlg) {
		this.gcSendFlg = gcSendFlg;
	}

	public String getGenerationTs9() {
		return this.generationTs9;
	}

	public void setGenerationTs9(String generationTs9) {
		this.generationTs9 = generationTs9;
	}

	public String getGouki9() {
		return this.gouki9;
	}

	public void setGouki9(String gouki9) {
		this.gouki9 = gouki9;
	}

	public String getGwHostNm() {
		return this.gwHostNm;
	}

	public void setGwHostNm(String gwHostNm) {
		this.gwHostNm = gwHostNm;
	}

	public String getGwIpKind() {
		return this.gwIpKind;
	}

	public void setGwIpKind(String gwIpKind) {
		this.gwIpKind = gwIpKind;
	}

	public String getGwRcvIpAddr() {
		return this.gwRcvIpAddr;
	}

	public void setGwRcvIpAddr(String gwRcvIpAddr) {
		this.gwRcvIpAddr = gwRcvIpAddr;
	}

	public String getGwRcvTs() {
		return this.gwRcvTs;
	}

	public void setGwRcvTs(String gwRcvTs) {
		this.gwRcvTs = gwRcvTs;
	}

	public String getImageCount() {
		return this.imageCount;
	}

	public void setImageCount(String imageCount) {
		this.imageCount = imageCount;
	}

	public String getImageStartTime() {
		return this.imageStartTime;
	}

	public void setImageStartTime(String imageStartTime) {
		this.imageStartTime = imageStartTime;
	}

	public String getImgNum() {
		return this.imgNum;
	}

	public void setImgNum(String imgNum) {
		this.imgNum = imgNum;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getInterphoneNo() {
		return this.interphoneNo;
	}

	public void setInterphoneNo(String interphoneNo) {
		this.interphoneNo = interphoneNo;
	}

	public String getKIndexNum() {
		return this.kIndexNum;
	}

	public void setKIndexNum(String kIndexNum) {
		this.kIndexNum = kIndexNum;
	}

	public String getKnStsMainFlg() {
		return this.knStsMainFlg;
	}

	public void setKnStsMainFlg(String knStsMainFlg) {
		this.knStsMainFlg = knStsMainFlg;
	}

	public String getKnStsSubAddrFlg() {
		return this.knStsSubAddrFlg;
	}

	public void setKnStsSubAddrFlg(String knStsSubAddrFlg) {
		this.knStsSubAddrFlg = knStsSubAddrFlg;
	}

	public String getLineKind9() {
		return this.lineKind9;
	}

	public void setLineKind9(String lineKind9) {
		this.lineKind9 = lineKind9;
	}

	public String getLnKbChiku() {
		return this.lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getLnQueKbSig() {
		return this.lnQueKbSig;
	}

	public void setLnQueKbSig(String lnQueKbSig) {
		this.lnQueKbSig = lnQueKbSig;
	}

	public String getMicInterphoneLinkFlg() {
		return this.micInterphoneLinkFlg;
	}

	public void setMicInterphoneLinkFlg(String micInterphoneLinkFlg) {
		this.micInterphoneLinkFlg = micInterphoneLinkFlg;
	}

	public String getMicNo() {
		return this.micNo;
	}

	public void setMicNo(String micNo) {
		this.micNo = micNo;
	}

	public String getModelType() {
		return this.modelType;
	}

	public void setModelType(String modelType) {
		this.modelType = modelType;
	}

	public String getN0StsMainFlg() {
		return this.n0StsMainFlg;
	}

	public void setN0StsMainFlg(String n0StsMainFlg) {
		this.n0StsMainFlg = n0StsMainFlg;
	}

	public String getN0StsSubAddrFlg() {
		return this.n0StsSubAddrFlg;
	}

	public void setN0StsSubAddrFlg(String n0StsSubAddrFlg) {
		this.n0StsSubAddrFlg = n0StsSubAddrFlg;
	}

	public String getOutReportHyojiFlg() {
		return this.outReportHyojiFlg;
	}

	public void setOutReportHyojiFlg(String outReportHyojiFlg) {
		this.outReportHyojiFlg = outReportHyojiFlg;
	}

	public String getRmFlg() {
		return this.rmFlg;
	}

	public void setRmFlg(String rmFlg) {
		this.rmFlg = rmFlg;
	}

	public String getRmKind() {
		return this.rmKind;
	}

	public void setRmKind(String rmKind) {
		this.rmKind = rmKind;
	}

	public String getSigCode() {
		return this.sigCode;
	}

	public void setSigCode(String sigCode) {
		this.sigCode = sigCode;
	}

	public Date getSigHasseiTs() {
		return this.sigHasseiTs;
	}

	public void setSigHasseiTs(Date sigHasseiTs) {
		this.sigHasseiTs = sigHasseiTs;
	}

	public String getSigKind1() {
		return this.sigKind1;
	}

	public void setSigKind1(String sigKind1) {
		this.sigKind1 = sigKind1;
	}

	public String getSigKind2() {
		return this.sigKind2;
	}

	public void setSigKind2(String sigKind2) {
		this.sigKind2 = sigKind2;
	}

	public String getSigNm() {
		return this.sigNm;
	}

	public void setSigNm(String sigNm) {
		this.sigNm = sigNm;
	}

	public Date getSigRcvTs() {
		return this.sigRcvTs;
	}

	public void setSigRcvTs(Date sigRcvTs) {
		this.sigRcvTs = sigRcvTs;
	}

	public String getSinpoFlg() {
		return this.sinpoFlg;
	}

	public void setSinpoFlg(String sinpoFlg) {
		this.sinpoFlg = sinpoFlg;
	}

	public String getSpeakerNo() {
		return this.speakerNo;
	}

	public void setSpeakerNo(String speakerNo) {
		this.speakerNo = speakerNo;
	}

	public String getSubAddr9() {
		return this.subAddr9;
	}

	public void setSubAddr9(String subAddr9) {
		this.subAddr9 = subAddr9;
	}

	public String getTrNum9() {
		return this.trNum9;
	}

	public void setTrNum9(String trNum9) {
		this.trNum9 = trNum9;
	}

	public String getTransmitter9Id() {
		return this.transmitter9Id;
	}

	public void setTransmitter9Id(String transmitter9Id) {
		this.transmitter9Id = transmitter9Id;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public String getVerFw() {
		return this.verFw;
	}

	public void setVerFw(String verFw) {
		this.verFw = verFw;
	}

	public String getVideoDevNum() {
		return this.videoDevNum;
	}

	public void setVideoDevNum(String videoDevNum) {
		this.videoDevNum = videoDevNum;
	}

	public String getVideoFileName() {
		return this.videoFileName;
	}

	public void setVideoFileName(String videoFileName) {
		this.videoFileName = videoFileName;
	}

	public String getVideoLinkFlg() {
		return this.videoLinkFlg;
	}

	public void setVideoLinkFlg(String videoLinkFlg) {
		this.videoLinkFlg = videoLinkFlg;
	}

	public String getVideoRecordCount() {
		return this.videoRecordCount;
	}

	public void setVideoRecordCount(String videoRecordCount) {
		this.videoRecordCount = videoRecordCount;
	}

	public String getVideoRecordTime() {
		return this.videoRecordTime;
	}

	public void setVideoRecordTime(String videoRecordTime) {
		this.videoRecordTime = videoRecordTime;
	}

	public String getVoiceDevNum() {
		return this.voiceDevNum;
	}

	public void setVoiceDevNum(String voiceDevNum) {
		this.voiceDevNum = voiceDevNum;
	}

	public String getVoiceFileName() {
		return this.voiceFileName;
	}

	public void setVoiceFileName(String voiceFileName) {
		this.voiceFileName = voiceFileName;
	}

	public String getVoiceRecordTime() {
		return this.voiceRecordTime;
	}

	public void setVoiceRecordTime(String voiceRecordTime) {
		this.voiceRecordTime = voiceRecordTime;
	}

}