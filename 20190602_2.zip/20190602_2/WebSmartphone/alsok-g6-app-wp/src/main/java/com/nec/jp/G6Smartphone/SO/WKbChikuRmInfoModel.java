package com.nec.jp.G6Smartphone.SO;

public class WKbChikuRmInfoModel implements DataModelHandler {

	private String lnKbChiku;
	private String kbSetStsNo;
	private String rmSetTs;
	

	public WKbChikuRmInfoModel() {
		this.lnKbChiku= "";
		this.kbSetStsNo= "";
		this.rmSetTs= "";
	}
	
	public WKbChikuRmInfoModel(String lnKbChiku, String kbSetStsNo, String rmSetTs) {
		this.lnKbChiku = lnKbChiku;
		this.kbSetStsNo = kbSetStsNo;
		this.rmSetTs = rmSetTs;
	}

	public String getLnKbChiku() {
		return lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getKbSetStsNo() {
		return kbSetStsNo;
	}

	public void setKbSetStsNo(String kbSetStsNo) {
		this.kbSetStsNo = kbSetStsNo;
	}

	public String getRmSetTs() {
		return rmSetTs;
	}

	public void setRmSetTs(String rmSetTs) {
		this.rmSetTs = rmSetTs;
	}
}
