package com.nec.jp.G6Smartphone.constants;

/**
 * <B>コード定数保持クラス</B><br>
 * <br>
 * <B>概要</B><br>
 * コード一覧の定数を保持します。<br>
 * 
 * @author NEC
 */
public class G6CodeConsts {

	/**
     * 状態フラグ（CD001）
     */
    public static class CD001 {
        /**
         * 正常

         */
        public static final String NORMAL = "00";
        /**
         * 異常
         */
        public static final String ABNORMAL = "01";
    }

    /**
     * OK/NGフラグ（CD002）
     */
    public static class CD002 {
        /**
         * OK
         */
        public static final String OK = "0";
        /**
         * NG
         */
        public static final String NG = "1";
    }

    /**
     * YES/NOフラグ（CD003）
     */
    public static class CD003 {
        /**
         * YES
         */
        public static final String YES = "0";
        /**
         * NO
         */
        public static final String NO = "1";
    }

    /**
     * ON/OFFフラグ（CD004）
     */
    public static class CD004 {
        /**
         * OFF

         */
        public static final String OFF = "0";
        /**
         * ON
         */
        public static final String ON = "1";
    }

    /**
     * 有無フラグ（CD005）
     */
    public static class CD005 {
        /**
         * なし
         */
        public static final String NONE = "0";
        /**
         * あり
         */
        public static final String EXIST = "1";
    }

    /**
     * する/しないフラグ（CD006）
     */
    public static class CD006 {
        /**
         * しない
         */
        public static final String NOT_DO = "0";
        /**
         * する
         */
        public static final String DO = "1";
    }

    /**
     * 使用可否フラグ（CD007）
     */
    public static class CD007 {
        /**
         * 使用可

         */
        public static final String AVAILABLE = "0";
        /**
         * 使用不可
         */
        public static final String UNAVAILABLE = "1";
    }

    /**
     * 可/不可フラグ（CD008）
     */
    public static class CD008 {
        /**
         * 不可
         */
        public static final String DISABLED = "0";
        /**
         * 可能
         */
        public static final String ENABLED = "1";
    }

    /**
     * 最新フラグ（CD009）
     */
    public static class CD009 {
        /**
         * 最新でない

         */
        public static final String NOT_LATEST = "0";
        /**
         * 最新である
         */
        public static final String LATEST = "1";
    }

    /**
     * 使用有無フラグ（CD010）
     */
    public static class CD010 {
        /**
         * 使用しない
         */
        public static final String NOT_USE = "0";
        /**
         * 使用する
         */
        public static final String USE = "1";
    }

    /**
     * 要/不要フラグ（CD011）
     */
    public static class CD011 {
        /**
         * 不要
         */
        public static final String UNNEEDED = "0";
        /**
         * 必要
         */
        public static final String NEEDED = "1";
    }

    /**
     * 有効無効フラグ（CD012）
     */
    public static class CD012 {
        /**
         * 無効
         */
        public static final String UNABLE = "0";
        /**
         * 有効
         */
        public static final String VALID = "1";
    }

    /**
     * 検索済みフラグ（CD013）
     */
    public static class CD013 {
        /**
         * 未検索
         */
        public static final String NON_SEARCH = "0";
        /**
         * 検索済み
         */
        public static final String SEARCHED = "1";
    }

    /**
     * 対象非対象フラグ（CD014）
     */
    public static class CD014 {
        /**
         * 非対象
         */
        public static final String NON_TARGET = "0";
        /**
         * 対象
         */
        public static final String TARGET = "1";
    }

    /**
     * 送信済みフラグ（CD015）
     */
    public static class CD015 {
        /**
         * 送信未
         */
        public static final String UNSENT = "0";
        /**
         * 送信済
         */
        public static final String SENT = "1";
        /**
         * リトライ
         */
        public static final String RETRY = "2";
        /**
         * 送信先無し
         */
        public static final String NON_TARGET = "8";
        /**
         * エラー
         */
        public static final String ERROR = "E";
    }

    /**
     * 受信済みフラグ（CD016）
     */
    public static class CD016 {
        /**
         * 受信未
         */
        public static final String UNRECEIVED = "0";
        /**
         * 受信済
         */
        public static final String RECEIVED = "1";
    }

    /**
     * 完了状態（CD017）
     */
    public static class CD017 {
        /**
         * 未完了
         */
        public static final String NON_COMPLETION = "0";
        /**
         * 完了
         */
        public static final String COMPLETE = "1";
        /**
         * 処理中
         */
        public static final String PROCESSING = "2";
        /**
         * 失敗
         */
        public static final String FAILURE = "8";
        /**
         * 取り消し

         */
        public static final String CANCEL = "9";
    }

    /**
     * 送信結果（CD018）
     */
    public static class CD018 {
        /**
         * 成功
         */
        public static final String SUCCESS = "0";
        /**
         * 成功（メールサーバ－）
         */
        public static final String SUCCESS_BY_MAILSERVER = "1";
        /**
         * リトライ中
         */
        public static final String RETRY = "2";
        /**
         * リトライ期限切れ
         */
        public static final String EXPIRED = "3";
        /**
         * バウンス
         */
        public static final String BOUNCE = "4";
        /**
         * 失敗
         */
        public static final String FAILURE = "9";
    }

    /**
     * ブザー鳴動フラグ（CD019）
     */
    public static class CD019 {
        /**
         * 鳴動なし
         */
        public static final String NO_RUMBLING = "0";
        /**
         * 鳴動あり
         */
        public static final String RUMBLING = "1";
        /**
         * 以降鳴動なし
         */
        public static final String SINCE_NO_RUMBLING = "2";
    }

    /**
     * ログイン許可状態（CD020）
     */
    public static class CD020 {
        /**
         * ログイン不可
         */
        public static final String IMPOSSIBLE = "0";
        /**
         * ログイン可
         */
        public static final String POSSIBLE = "1";
        /**
         * ログイン不可(停止)
         */
        public static final String STOP = "9";
    }

    /**
     * ALSOKアカウント区分（CD021）
     */
    public static class CD021 {
        /**
         * 隊員
         */
        public static final String MEMBER = "0";
        /**
         * オペレータ
         */
        public static final String OPERATOR = "1";
        /**
         * 隊員兼オペレータ
         */
        public static final String MEMBER_AND_OPERATOR = "2";
    }

    /**
     * ALSOK隊員種別フラグ（CD022）
     */
    public static class CD022 {
        /**
         * 機動警備隊員
         */
        public static final String MOBILE_GARRISON_ONE = "0";
        /**
         * 技術員
         */
        public static final String CUSTOMER_SERVICE_ENGINEER = "1";
        /**
         * 協力会社
         */
        public static final String COOPERATION_COMPANY = "2";
        /**
         * その他
         */
        public static final String OTHERS = "3";
    }

    /**
     * GCTバージョン（CD023）
     */
    public static class CD023 {
        /**
         * 現行バージョン(v6.5)
         */
        public static final String GCT = "0650";
        /**
         * GCT7(v7)
         */
        public static final String GCT7 = "0700";
        /**
         * SCC社の処理にて使用
         */
        public static final String SCC = "GHS";
    }

    /**
     * システム区分（CD024）
     */
    public static class CD024 {
        /**
         * 次期警備
         */
        public static final String THE_NEXT_GUARD = "0";
        /**
         * GHS
         */
        public static final String GHS = "1";
        /**
         * ALSOK-GⅤ
         */
        public static final String ALSOK_GV = "2";
        /**
         * 現行GHS
         */
        public static final String PRESENT_GHS = "3";
        /**
         * 現行ALSOK-GⅤ
         */
        public static final String PRESENT_ALSOK_GV = "4";
        /**
         * 共通
         */
        public static final String COMMON = "5";
    }

    /**
     * 事業所種別（CD025）
     */
    public static class CD025 {
        /**
         * プロパー事業所
         */
        public static final String PROPER_OFFICE = "0";
        /**
         * グループ会社事業所
         */
        public static final String GROUP_COMPANY_OFFICE = "1";
    }

    /**
     * 自動遠隔点検検索選択タブ区分（CD026）
     */
    public static class CD026 {
        /**
         * 警備先検索
         */
        public static final String GUARD_PREVIOUS_SEARCH = "1";
        /**
         * 時刻検索
         */
        public static final String TIME_SEARCH = "2";
    }

    /**
     * アカウント種別（CD027）
     */
    public static class CD027 {
        /**
         * 次期警備システム
         */
        public static final String THE_NEXT_TERM_GUARD_SYSTEM = "0";
        /**
         * GⅤ
         */
        public static final String GV = "1";
        /**
         * GHS(利用者)
         */
        public static final String GHS_THE_USER = "2";
        /**
         * GHS(契約先)
         */
        public static final String GHS_CONTRACT_DESTINATION = "3";
    }

    /**
     * 送信フラグ（CD029）
     */
    public static class CD029 {
        /**
         * 送信しない
         */
        public static final String NOT_SEND = "0";
        /**
         * 送信する
         */
        public static final String SEND = "1";
    }

    /**
     * 表示フラグ（CD030）
     */
    public static class CD030 {
        /**
         * 表示しない
         */
        public static final String DO_NOT_SHOW = "0";
        /**
         * 表示する
         */
        public static final String INDICATED = "1";
    }

    /**
     * アカウント登録状態（CD031）
     */
    public static class CD031 {
        /**
         * 仮登録
         */
        public static final String TEMPORARY_REGISTRATION = "0";
        /**
         * 登録済み
         */
        public static final String REGISTERED = "1";
        /**
         * 変更中
         */
        public static final String NOW_CHANGING = "2";
        /**
         * タイムアウト(仮登録)
         */
        public static final String TIME_OUT = "9";
    }

    /**
     * メール通知許可状態（CD032）
     */
    public static class CD032 {
        /**
         * メール通知不可(確認待ち)
         */
        public static final String CONFIRMATION_WAITING = "0";
        /**
         * メール通知可
         */
        public static final String POSSIBLE = "1";
        /**
         * メール通知不可(エラー)
         */
        public static final String ERROR = "9";
    }

    /**
     * メール通知有無フラグ（CD033）
     */
    public static class CD033 {
        /**
         * メール通知しない
         */
        public static final String NOT_NOTIFY_MAILING = "0";
        /**
         * メール通知する
         */
        public static final String NOTIFY_MAILING = "1";
    }

    /**
     * DB処理区分（CD034）
     */
    public static class CD034 {
        /**
         * 登録
         */
        public static final String REGISTRATION = "1";
        /**
         * 更新
         */
        public static final String RENEWAL = "2";
        /**
         * 削除
         */
        public static final String ELIMINATION = "3";
    }

    /**
     * サービス種別（CD035）
     */
    public static class CD035 {
        /**
         * NHS-A
         */
        public static final String NHS_A = "01";
        /**
         * GS
         */
        public static final String GS = "02";
        /**
         * HS
         */
        public static final String HS = "03";
        /**
         * GSM
         */
        public static final String GSM = "04";
        /**
         * 次期警備
         */
        public static final String THE_NEXT_GUARD = "05";
    }

    /**
     * 時間設定種別（CD036）
     */
    public static class CD036 {
        /**
         * 定時
         */
        public static final String THE_FIXED_TIME = "1";
        /**
         * 常時
         */
        public static final String ALWAYS = "2";
    }

    /**
     * 機器種別コード（CD037）
     */
    public static class CD037 {
        /**
         * S-860(GS)

         */
        public static final String S_861_GS = "201";
        /**
         * S-728(HS)

         */
        public static final String S_729_HS
 = "301";
        /**
         * S-860M(GSM)
         */
        public static final String S_860M_GSM = "401";
    }

    /**
     * 制御コマンドコード（CD038）
     */
    public static class CD038 {
        /**
         * ver_req
         */
        public static final String VER_REQ = "R01";
        /**
         * flverreq
         */
        public static final String FLVERREQ = "R02";
        /**
         * dwldreq
         */
        public static final String DWLDREQ = "R03";
        /**
         * updtreq
         */
        public static final String UPDTREQ = "R04";
        /**
         * upfnreq
         */
        public static final String UPFNREQ = "R05";
        /**
         * updtcan
         */
        public static final String UPDTCAN = "R06";
        /**
         * dwldcor
         */
        public static final String DWLDCOR = "R07";
        /**
         * dwldcorde
         */
        public static final String DWLDCORDE = "R08";
        /**
         * upldbac
         */
        public static final String UPLDBAC = "R09";
        /**
         * upldreq
         */
        public static final String UPLDREQ = "R10";
        /**
         * upldcom
         */
        public static final String UPLDCOM = "R11";
        /**
         * drctset
         */
        public static final String DRCTSET = "R12";
        /**
         * drct_rd
         */
        public static final String DRCT_RD = "R13";
        /**
         * dhldreq
         */
        public static final String DHLDREQ = "R14";
        /**
         * dhld_rd
         */
        public static final String DHLD_RD = "R15";
        /**
         * shntset
         */
        public static final String SHNTSET = "R16";
        /**
         * shnt_rd
         */
        public static final String SHNT_RD = "R17";
        /**
         * elkyset
         */
        public static final String ELKYSET = "R18";
        /**
         * elky_rd
         */
        public static final String ELKY_RD = "R19";
        /**
         * zpsnset
         */
        public static final String ZPSNSET = "R20";
        /**
         * zpsn_rd
         */
        public static final String ZPSN_RD = "R21";
        /**
         * anpb_cl
         */
        public static final String ANPB_CL = "R22";
        /**
         * anpb_rd
         */
        public static final String ANPB_RD = "R23";
        /**
         * gchk_cl
         */
        public static final String GCHK_CL = "R24";
        /**
         * gchk_rd
         */
        public static final String GCHK_RD = "R25";
        /**
         * kylsset
         */
        public static final String KYLSSET = "R26";
        /**
         * kyls_rd
         */
        public static final String KYLS_RD = "R27";
        /**
         * alm_rst
         */
        public static final String ALM_RST = "R28";
        /**
         * almstop
         */
        public static final String ALMSTOP = "R29";
        /**
         * rstterm
         */
        public static final String RSTTERM = "R30";
        /**
         * ctstreq
         */
        public static final String CTSTREQ = "R31";
        /**
         * btckreq
         */
        public static final String BTCKREQ = "R32";
        /**
         * kbstset
         */
        public static final String KBSTSET = "R33";
        /**
         * kbst_rd
         */
        public static final String KBST_RD = "R34";
        /**
         * rmckreq
         */
        public static final String RMCKREQ = "R35";
        /**
         * lpinfrd
         */
        public static final String LPINFRD = "R36";
        /**
         * vdatsnd
         */
        public static final String VDATSND = "R37";
        /**
         * GsmFTPPutReq
         */
        public static final String GSM_FTP_PUT_REQ = "R38";
        /**
         * GsmFTPGetReq
         */
        public static final String GSM_FTP_GET_REQ = "R39";
        /**
         * GsmFileDelReq
         */
        public static final String GSM_FILE_DEL_REQ = "R40";
        /**
         * GsmFileGetReq
         */
        public static final String GSM_FILE_GET_REQ = "R41";
        /**
         * prlvgetreq
         */
        public static final String PRLVGETREQ = "M01";
        /**
         * ksigvgetreq
         */
        public static final String KSIGVGETREQ = "M02";
        /**
         * kaoregdelreq
         */
        public static final String KAOREGDELREQ = "M03";
        
        /**
         * drctset(GHS)
         */
        public static final String DRCTSET_GHS = "R07";
        
        /**
         * drct_rd(GHS)
         */
        public static final String DRCT_RD_GHS = "R08";
        
        /**
         * kbstset(GHS)
         */
        public static final String KBSTSET_GHS = "R14";
    }

    /**
     * セキュリティカード区分（CD039）
     */
    public static class CD039 {
        /**
         * ユーザー

         */
        public static final String THE_USER = "1";
        /**
         * ALSOK

         */
        public static final String ALSOK = "2";
        /**
         * パニック1(ユーザー)

         */
        public static final String PANIC_1_THE_USER = "8";
        /**
         * パニック2(ALSOK)
         */
        public static final String PANIC_2_ALSOK = "9";
    }

    /**
     * セキュリティカード有効フラグ（CD040）
     */
    public static class CD040 {
        /**
         * 無効
         */
        public static final String INVALID = "0";
        /**
         * 有効
         */
        public static final String EFFECTIVE = "1";
        /**
         * 紛失
         */
        public static final String LOSS = "2";
    }

    /**
     * ファイル種別（CD041）
     */
    public static class CD041 {
        /**
         * 制御装置F/W
         */
        public static final String CONTROL_SYSTEM_FW = "01";
        /**
         * 制御装置S/D
         */
        public static final String CONTROL_SYSTEM_SD = "02";
        /**
         * センサー動作履歴
         */
        public static final String SENSOR_HISTORY = "11";
        /**
         * 出入履歴
         */
        public static final String GOING_IN_AND_OUT_OF_HISTORY = "12";
        /**
         * 出退勤履歴
         */
        public static final String CLOCK_IN_AND_OUT_HISTORY = "13";
        /**
         * 作動試験結果

         */
        public static final String OPERATIONAL_TEST_RESULT = "40";
        /**
         * 自動点検結果
         */
        public static final String AUTOMATIC_CHECK_RESULT = "41";
        /**
         * 画像ユニット履歴
         */
        public static final String PICTURE_HISTORY = "51";
        /**
         * 履歴ファイル一括
         */
        public static final String HISTORY_FILE_LUMPING = "99";
    }

    /**
     * ファイル送信状態（CD042）
     */
    public static class CD042 {
        /**
         * 初期ロード解析待ち
         */
        public static final String FIRST_LOAD_ANALYSIS_WAITING = "1";
        /**
         * 初期ロード解析済み
         */
        public static final String FIRST_LOAD_ANALYSIS = "2";
        /**
         * 送信準備中
         */
        public static final String PREPARING_TO_SEND = "3";
        /**
         * 送信準備完了(送信待ち)
         */
        public static final String READY_SENT_WAITING = "4";
        /**
         * 送信中

         */
        public static final String SENDING = "5";
        /**
         * 送信済み(リブート待ち)

         */
        public static final String SENT_TRANSMISSION_WAITING = "6";
        /**
         * 送信済み(リブート中)

         */
        public static final String SENT_REBOOTING = "7";
        /**
         * 事後送信
         */
        public static final String SEND_AFTER = "8";
        /**
         * 完了(正常)

         */
        public static final String COMPLETION = "0";
        /**
         * エラー

         */
        public static final String ERROR = "E";
        /**
         * キャンセル中
         */
        public static final String CANCELING = "C";
    }

    /**
     * 機器種別種別コード（CD045）
     */
    public static class CD045 {
        /**
         * 制御装置

         */
        public static final String CONTROL_SYSTEM = "01";
        /**
         * その他周辺装置
         */
        public static final String OTHER_PERIPHERAL_DEVICES = "99";
    }

    /**
     * GSHSフラグ（CD046）
     */
    public static class CD046 {
        /**
         * GS
         */
        public static final String GS = "0";
        /**
         * HS
         */
        public static final String HS = "1";
        /**
         * GSM
         */
        public static final String GSM = "2";
        /**
         * 次期警備
         */
        public static final String THE_NEXT_GUARD = "3";
    }

    /**
     * 警備運用状態（CD047）
     */
    public static class CD047 {
        /**
         * 中断中
         */
        public static final String SUSPENDED = "0";
        /**
         * 警備中
         */
        public static final String UNDER_SECURITY = "1";
        /**
         * その他(エラー)
         */
        public static final String OTHER = "9";
    }

    /**
     * 警備契約形態（CD048）
     */
    public static class CD048 {
        /**
         * オンライン(外出ALSOKあり、在宅ALSOKあり)
         */
        public static final String ON_LINE = "0";
        /**
         * オフライン
         */
        public static final String OFF_LINE = "1";
    }

    /**
     * 警備ヘルスチェック間隔（CD049）
     */
    public static class CD049 {
        /**
         * 解除中なし、警備中なし
         */
        public static final String WITHOUT_DURING_GUARD = "0";
        /**
         * 解除中なし、警備中5分
         */
        public static final String WHOLE_GUARD_FOR_5MIN = "1";
        /**
         * 解除中なし、警備中30分
         */
        public static final String WHOLE_GUARD_FOR_30MIN = "2";
        /**
         * 解除中なし、警備中110分
         */
        public static final String WHOLE_GUARD_FOR_110MIN = "3";
        /**
         * 解除中なし、警備中24時間
         */
        public static final String WHOLE_GUARD_FOR_24H = "4";
        /**
         * 解除中24時間、警備中110分
         */
        public static final String DURING_GUARD_24H_FOR_110MIN = "5";
        /**
         * 解除中24時間、警備中4時間
         */
        public static final String DURING_GUARD_24H_FOR_4H = "6";
        /**
         * 解除中24時間、警備中8時間
         */
        public static final String DURING_GUARD_24H_FOR_8H = "7";
        /**
         * 解除中24時間、警備中24時間
         */
        public static final String DURING_GUARD_24H_FOR_24H = "8";
        /**
         * 解除中168時間、警備中24時間
         */
        public static final String DURING_GUARD_168H_FOR_24H = "9";
        /**
         * 2時間
         */
        public static final String HOURS_2 = "A";
        /**
         * 1時間
         */
        public static final String HOUR_1 = "B";
    }

    /**
     * 遠隔点検操作不可（CD050）
     */
    public static class CD050 {
        /**
         * SCIのみ
         */
        public static final String ONLY_SCI = "0";
        /**
         * 接点入力のみ
         */
        public static final String CONTACT_INPUT_ONLY = "1";
        /**
         * 接点入力とSCI混在
         */
        public static final String AND_SCI_INTERMINGLED = "2";
    }

    /**
     * 遠隔点検結果（CD051）
     */
    public static class CD051 {
        /**
         * 正常
         */
        public static final String NORMAL = "0";
        /**
         * 異常
         */
        public static final String ABNORMAL = "1";
        /**
         * 要求失敗
         */
        public static final String REQUEST_FAILURE = "2";
    }

    /**
     * 業務コード（CD052）
     */
    public static class CD052 {
        /**
         * 新画像連携用
         */
        public static final String FOR_NEW_PICTURE_COOPERATION = "GⅤ";
        /**
         * GC連携
         */
        public static final String GC_COOPERATION = "GHS";
    }

    /**
     * 登録状態（CD053）
     */
    public static class CD053 {
        /**
         * 未登録
         */
        public static final String UNREGISTERED = "0";
        /**
         * 登録
         */
        public static final String REGISTRATION = "1";
        /**
         * 一時削除
         */
        public static final String DELETE_TEMPORARILY = "2";
    }

    /**
     * 監視設定（CD054）
     */
    public static class CD054 {
        /**
         * 無し
         */
        public static final String NONE = "0";
        /**
         * 常時タイマ
         */
        public static final String ALWAYS_TIMER = "1";
        /**
         * 定時
         */
        public static final String REGULAR_TIME = "2";
    }

    /**
     * N0F0状態フラグ（CD055）
     */
    public static class CD055 {
        /**
         * N0
         */
        public static final String N0 = "N";
        /**
         * F0
         */
        public static final String F0 = "F";
        /**
         * ZN0
         */
        public static final String ZN0 = "M";
        /**
         * ZF0
         */
        public static final String ZF0 = "E";
    }

    /**
     * KNKF状態フラグ（CD056）
     */
    public static class CD056 {
        /**
         * KN
         */
        public static final String KN = "N";
        /**
         * KF
         */
        public static final String KF = "F";
    }

    /**
     * メールタイミングフラグ（CD057）
     */
    public static class CD057 {
        /**
         * 登録時(未送信状態)
         */
        public static final String UNSENT_STATE = "0";
        /**
         * 送信時(送信済み状態)
         */
        public static final String TRANSMITTED_STATE = "1";
    }

    /**
     * 払い出し状態（CD058）
     */
    public static class CD058 {
        /**
         * 未使用(未払い出し)
         */
        public static final String UNPAID = "0";
        /**
         * 使用中(払い出し済み)
         */
        public static final String ALREADY_PAID_OUT = "1";
        /**
         * 払い出し不可
         */
        public static final String NO_PAYOUT_ALLOWED = "N";
    }

    /**
     * 出退勤出力設定出力形式（CD059）
     */
    public static class CD059 {
        /**
         * 初期形式
         */
        public static final String THE_EARLY_STAGE_FORM = "01";
        /**
         * 就業奉行
         */
        public static final String SHUGYOHOKO = "02";
        /**
         * 就業奉行21
         */
        public static final String SHUGYOHOKO_21 = "03";
        /**
         * 弥生給与
         */
        public static final String YAYOIKYUYO = "04";
        /**
         * 給料王
         */
        public static final String KYURYOO = "05";
        /**
         * フリー
         */
        public static final String FREE = "06";
        /**
         * 日跨ぎ
         */
        public static final String DAY_SPANNING = "07";
    }

    /**
     * 出退勤出力設定タイトル行設定（CD060）
     */
    public static class CD060 {
        /**
         * 「出勤」「外出」先有効、「退勤」「戻り」後有効
         */
        public static final String EFFECTIVE_EFFECTIVE_AFTER = "01";
        /**
         * 「出勤」「外出」先有効、「退勤」「戻り」先有効
         */
        public static final String EFFECTIVE_EFFECTIVE = "02";
        /**
         * 「出勤」「外出」後有効、「退勤」「戻り」先有効
         */
        public static final String EFFECTIVE_AFTER_EFFECTIVE = "03";
        /**
         * 「出勤」「外出」後有効、「退勤」「戻り」後有効
         */
        public static final String EFFECTIVE_AFTER_EFFECTIVE_AFTER = "04";
        /**
         * 全て出力する
         */
        public static final String EVERYTHING_OUTPUTS = "05";
    }

    /**
     * 出退勤出力設定出力内容設定（CD061）
     */
    public static class CD061 {
        /**
         * 指定なし
         */
        public static final String WITHOUT_DESIGNATION = "01";
        /**
         * 日付（mm/dd(w)）
         */
        public static final String DATE_MM_DD_W = "02";
        /**
         * 日付（yyyy/mm/dd）
         */
        public static final String DATE_YYYY_MM_DD = "03";
        /**
         * 日付（yyyymmdd）
         */
        public static final String DATE_YYYYMMDD = "04";
        /**
         * 時刻
         */
        public static final String THE_TIME = "05";
        /**
         * 操作
         */
        public static final String OPERATION = "06";
        /**
         * 警備先名称
         */
        public static final String THE_GUARD_PREVIOUS_NAME = "07";
        /**
         * 部署
         */
        public static final String DEPARTMENT = "08";
        /**
         * カード番号
         */
        public static final String CARD_NUMBER = "09";
        /**
         * 氏名
         */
        public static final String THE_NAME = "10";
        /**
         * 社員コード
         */
        public static final String THE_EMPLOYEE_CODE = "11";
        /**
         * 出勤
         */
        public static final String ATTENDANCE = "12";
        /**
         * 退勤
         */
        public static final String CLOCK_OUT = "13";
        /**
         * 外出①
         */
        public static final String GOING_OUT_1 = "14";
        /**
         * 戻り①
         */
        public static final String RETURN_1 = "15";
        /**
         * 外出②
         */
        public static final String GOING_OUT_2 = "16";
        /**
         * 戻り②
         */
        public static final String RETURN_2 = "17";
        /**
         * 外出③
         */
        public static final String GOING_OUT_3 = "18";
        /**
         * 戻り③
         */
        public static final String RETURN_3 = "19";
        /**
         * 外出④
         */
        public static final String GOING_OUT_4 = "20";
        /**
         * 戻り④
         */
        public static final String RETURN_4 = "21";
        /**
         * 空白(指定なし)
         */
        public static final String BLANK = "22";
    }

    /**
     * 回線種別（CD062）
     */
    public static class CD062 {
        /**
         * なし

         */
        public static final String NONE = "0";
        /**
         * 無線公衆回線のみ

         */
        public static final String WIRELESS_PUBLIC_LINE_ONLY = "1";
        /**
         * IPインターネット回線+無線公衆回線

         */
        public static final String PUBLIC_CIRCUIT = "2";
        /**
         * IPインターネット回線

         */
        public static final String IP_INTERNET = "5";
    }

    /**
     * 設置機器入力種別（CD063）
     */
    public static class CD063 {
        /**
         * 未監視

         */
        public static final String UNMONITORED = "00";
        /**
         * 防犯警報

         */
        public static final String SECURITY_ALARM = "01";
        /**
         * 施錠警報

         */
        public static final String LOCK_ALARM = "02";
        /**
         * 防災警報
         */
        public static final String DISASTER_ALARM = "03";
        /**
         * ガス警報

         */
        public static final String GAS_ALARM = "04";
        /**
         * 非常警報

         */
        public static final String EMERGENCY_ALERT = "05";
        /**
         * 救急警報

         */
        public static final String FIRST_AID_WARNING = "06";
        /**
         * ライフリズム警報

         */
        public static final String LIFE_RHYTHM_WARNING = "07";
        /**
         * 保護警報

         */
        public static final String PROTECTION_WARNING = "08";
        /**
         * 停電警報

         */
        public static final String FAILURE_ALARM = "09";
        /**
         * 在／不在入力
         */
        public static final String PRESENCE_ABSENT_INPUT = "10";
        /**
         * 警備入力

         */
        public static final String GUARD_INPUT = "11";
        /**
         * 端末異常警報

         */
        public static final String TERMINAL_ABNORMAL_WARNING = "12";
        /**
         * 電池切れ警報

         */
        public static final String BATTERY_CLOTH_WARNING = "13";
        /**
         * 設備警報

         */
        public static final String EQUIPMENT_WARNING = "14";
        /**
         * ペーパーエンド

         */
        public static final String PAPER_END = "15";
        /**
         * 火災入力2

         */
        public static final String FIRE_INPUT_2 = "16";
        /**
         * 電気錠入力

         */
        public static final String ELECTRIC_TABLET_INPUT = "17";
        /**
         * 見守り専用

         */
        public static final String WATCHING_ONLY = "18";
        /**
         * 見守り開始
         */
        public static final String START_WATCHING = "19";
    }

    /**
     * 設置機器制御種別（CD064）
     */
    public static class CD064 {
        /**
         * 未使用

         */
        public static final String UNUSED = "00";
        /**
         * 警備地区
         */
        public static final String GUARD_AREA = "01";
        /**
         * 全警備連動

         */
        public static final String ALL_SECURITY_GUARD_INTERLOCK = "02";
        /**
         * 警備地区代表ループ状態連動

         */
        public static final String STATE_LINKAGE = "03";
        /**
         * 警備地区警報連動

         */
        public static final String SECURITY_DISTRICT_ALARM_LINKAGE = "04";
        /**
         * 全地区警報連動

         */
        public static final String ALL_DISTRICT_ALARM_LINKAGE = "05";
        /**
         * ALSOKライト

         */
        public static final String ALSOK_LIGHT = "06";
        /**
         * タイマー中出力

         */
        public static final String TIMER_MIDDLE_OUTPUT = "07";
        /**
         * センターリモート

         */
        public static final String CENTER_REMOTENESS = "11";
        /**
         * 警報ブザー出力

         */
        public static final String WARNING_BUZZER_OUTPUT = "12";
        /**
         * SFR状態出力
         */
        public static final String SFR_STATE_OUTPUT = "13";
    }

    /**
     * 立ち上がり区分（CD065）
     */
    public static class CD065 {
        /**
         * 通常

         */
        public static final String USUALLY = "0";
        /**
         * 起動
         */
        public static final String START = "1";
    }

    /**
     * センサー状態（CD066）
     */
    public static class CD066 {
        /**
         * 正常

         */
        public static final String NORMAL = "0";
        /**
         * 異常

         */
        public static final String ABNORMAL = "1";
        /**
         * 正常⇒異常

         */
        public static final String ABNORMAL_NORMAL = "2";
        /**
         * 異常⇒正常
         */
        public static final String NORMAL_ABNORMAL = "3";
    }

    /**
     * 回線フラグ（CD067）
     */
    public static class CD067 {
        /**
         * メイン回線

         */
        public static final String MAIN = "0";
        /**
         * バックアップ回線
         */
        public static final String BACKUP = "1";
    }

    /**
     * 設置機器状態動作種別（CD068）
     */
    public static class CD068 {
        /**
         * 通常

         */
        public static final String NORMAL = "0";
        /**
         * 擬似発報
         */
        public static final String PSEUDO_ALARM = "1";
    }

    /**
     * 特定日設定種別（CD069）
     */
    public static class CD069 {
        /**
         * 特定期間または特定日
         */
        public static final String SPECIFIC_PERIOD_OR_SPECIFIC_DAY = "0";
        /**
         * 曜日
         */
        public static final String DAY_OF_THE_WEEK = "1";
    }

    /**
     * 隔週実施可否（CD070）
     */
    public static class CD070 {
        /**
         * 該当週のみ
         */
        public static final String ONLY_THE_RELEVAN_WEEK = "0";
        /**
         * 隔週実施
         */
        public static final String BIWEEKLY_IMPLEMENTATION = "1";
    }

    /**
     * 曜日（CD071）
     */
    public static class CD071 {
        /**
         * 日曜
         */
        public static final String SUN = "0";
        /**
         * 月曜
         */
        public static final String MON = "1";
        /**
         * 火曜
         */
        public static final String TUES = "2";
        /**
         * 水曜
         */
        public static final String WED = "3";
        /**
         * 木曜
         */
        public static final String THU = "4";
        /**
         * 金曜
         */
        public static final String FRI = "5";
        /**
         * 土曜
         */
        public static final String SAT = "6";
        /**
         * 全日
         */
        public static final String ALL = "7";
    }

    /**
     * 入居状態（CD072）
     */
    public static class CD072 {
        /**
         * 未入居

         */
        public static final String NOT_YET_MOVED = "0";
        /**
         * 入居中
         */
        public static final String MOVING_IN = "1";
    }

    /**
     * WEB利用フラグ（CD073）
     */
    public static class CD073 {
        /**
         * WEB利用なし

         */
        public static final String WITHOUT_WEB_USE = "0";
        /**
         * WEB利用あり
         */
        public static final String WITH_WEB_USE = "1";
    }

    /**
     * 発行フラグ（CD074）
     */
    public static class CD074 {
        /**
         * 未発行

         */
        public static final String UNISSUED = "0";
        /**
         * 発行済

         */
        public static final String ISSUED = "1";
        /**
         * 対象外
         */
        public static final String NOT_COVERED = "9";
    }

    /**
     * 出勤退勤情報区分（CD075）
     */
    public static class CD075 {
        /**
         * 入館
         */
        public static final String ENTRY = "01";
        /**
         * 退館
         */
        public static final String LEAVE = "02";
        /**
         * 外出
         */
        public static final String GOING_OUT = "03";
    }

    /**
     * 履歴種別（CD076）
     */
    public static class CD076 {
        /**
         * 標準履歴
         */
        public static final String THE_STANDARD_HISTORY = "1";
        /**
         * エラー履歴
         */
        public static final String ERROR_HISTORY = "2";
        /**
         * 制御関連履歴
         */
        public static final String THE_CONTROL_RELATED_HISTORY = "3";
    }

    /**
     * アカウント確認状態（CD077）
     */
    public static class CD077 {
        /**
         * 確認待ち
         */
        public static final String CONFIRMATION_WAITING = "1";
        /**
         * 登録完了
         */
        public static final String COMPLETING_REGISTRATION = "2";
        /**
         * エラー
         */
        public static final String ERROR = "3";
        /**
         * タイムアウト
         */
        public static final String TIME_OUT = "4";
        /**
         * 停止
         */
        public static final String STOP = "5";
        /**
         * CSV取り込みエラー
         */
        public static final String CSV_ERROR = "6";
    }

    /**
     * メール表示フラグ（CD078）
     */
    public static class CD078 {
        /**
         * 受け取らない
         */
        public static final String CAN_NOT_ACCEPT = "0";
        /**
         * 受け取る
         */
        public static final String RECEIVE = "1";
        /**
         * すべて受け取る
         */
        public static final String RECEIVE_ALL = "2";
        /**
         * 不一致
         */
        public static final String DISAGREEMENT = "3";
    }

    /**
     * 利用者ロール変更可否フラグ（CD079）
     */
    public static class CD079 {
        /**
         * 可能
         */
        public static final String POSSIBLE = "0";
        /**
         * 不可能
         */
        public static final String IMPOSSIBLE = "1";
    }

    /**
     * 日付個別設定種別（CD080）
     */
    public static class CD080 {
        /**
         * 単独指定(YYYYMMDD)
         */
        public static final String INDEPENDENT_DESIGNATION_YYYYMMDD = "0";
        /**
         * 範囲指定(YYYYMMDD～yyyymmddd)
         */
        public static final String RANGE_PECIFICATION = "1";
        /**
         * 年指定(MMDD)
         */
        public static final String ANNUAL_ESIGNATION_MMDD = "2";
        /**
         * 月末指定(特殊)
         */
        public static final String MONTH_DESIGNATION_SPECIAL = "3";
    }

    /**
     * 状態信号種別（CD081）
     */
    public static class CD081 {
        /**
         * F0
         */
        public static final String F0 = "2";
        /**
         * N0
         */
        public static final String N0 = "3";
        /**
         * KF
         */
        public static final String KF = "4";
        /**
         * KN
         */
        public static final String KN = "5";
    }

    /**
     * 個別週指定フラグ（CD082）
     */
    public static class CD082 {
        /**
         * 全週(指定無し)
         */
        public static final String WITHOUT_DESIGNATION = "0";
        /**
         * 個別週指定有り
         */
        public static final String INDIVIDUAL_WEEK = "1";
    }

    /**
     * 週番号（CD083）
     */
    public static class CD083 {
        /**
         * 毎週
         */
        public static final String WEEKLY = "0";
        /**
         * 第1○曜日
         */
        public static final String DAY_OF_THE_WEEK_1 = "1";
        /**
         * 第2○曜日
         */
        public static final String DAY_OF_THE_WEEK_2 = "2";
        /**
         * 第3○曜日
         */
        public static final String DAY_OF_THE_WEEK_3 = "3";
        /**
         * 第4○曜日
         */
        public static final String DAY_OF_THE_WEEK_4 = "4";
        /**
         * 第5○曜日
         */
        public static final String DAY_OF_THE_WEEK_5 = "5";
    }

    /**
     * エラーコード（CD084）
     */
    public static class CD084 {
        /**
         * 共通
         */
        public static final String COMMON = "00";
        /**
         * 監視AP
         */
        public static final String MONITORING_AP = "01";
        /**
         * クライアント機器
         */
        public static final String CLIENT_EQUIPMENT = "02";
        /**
         * 信号受信SV
         */
        public static final String SIGNAL_RECEPTION_SV = "03";
        /**
         * 機器監視SV
         */
        public static final String EQUIPMENT_WATCH_SV = "04";
        /**
         * RMSV
         */
        public static final String RMSV = "05";
        /**
         * メディア受信SV
         */
        public static final String RECEPTION_SV_OF_MEDIA = "06";
        /**
         * 映像配信SV
         */
        public static final String PICTURE_DELIVERY_SV = "07";
        /**
         * SIP-SV
         */
        public static final String SIP_SV = "08";
        /**
         * 情報フロントSV

         */
        public static final String INFORMATION_FRON_SV = "09";
    }

    /**
     * エラーレベル（CD085）
     */
    public static class CD085 {
        /**
         * Trcae
         */
        public static final String TRCAE = "1";
        /**
         * SQL
         */
        public static final String SQL = "2";
        /**
         * INFO
         */
        public static final String INFO = "3";
        /**
         * WARN
         */
        public static final String WARN = "4";
        /**
         * ERROR
         */
        public static final String ERROR = "5";
        /**
         * CRITICAL
         */
        public static final String CRITICAL = "6";
    }

    /**
     * シャント種別（CD086）
     */
    public static class CD086 {
        /**
         * センサー
         */
        public static final String SENSOR = "1";
        /**
         * カメラ
         */
        public static final String CAMERA = "2";
        /**
         * 住戸
         */
        public static final String DWELLING_DOOR = "3";
    }

    /**
     * 受取フラグ（CD087）
     */
    public static class CD087 {
        /**
         * 受け取らない
         */
        public static final String CAN_NOT_ACCEPT = "0";
        /**
         * 受け取る
         */
        public static final String RECEIVE = "1";
        /**
         * すべて受け取る
         */
        public static final String RECEIVE_ALL = "2";
    }

    /**
     * 外部情報通知種別（CD088）
     */
    public static class CD088 {
        /**
         * お知らせ
         */
        public static final String NEWS = "1";
        /**
         * 問い合わせ先
         */
        public static final String INQUIRY = "2";
    }

    /**
     * 機器接続種別（CD089）
     */
    public static class CD089 {
        /**
         * 制御装置
         */
        public static final String CONTROL_SYSTEM = "0";
        /**
         * 新伝送
         */
        public static final String NEW_TRANSMISSION = "1";
        /**
         * 周辺機器
         */
        public static final String PERIPHERAL_DEVICE = "2";
    }

    /**
     * 機器種別ID（CD090）
     */
    public static class CD090 {
        /**
         * GⅤ
         */
        public static final String GV = "100";
        /**
         * Pegasus
         */
        public static final String PEGASUS = "500";
    }

    /**
     * 装置種別（CD091）
     */
    public static class CD091 {
        /**
         * 監視CL
         */
        public static final String WATCH_CL = "0";
        /**
         * RMCL
         */
        public static final String MONITOR_CL = "1";
        /**
         * 両方
         */
        public static final String BOTH_OF_THEM = "2";
    }

    /**
     * CL制御コマンドグループID（CD092）
     */
    public static class CD092 {
        /**
         * 警備状態
         */
        public static final String THE_GUARD_STATE = "01";
        /**
         * 電気錠
         */
        public static final String ELECTRIC_TABLET = "02";
        /**
         * 通信試験
         */
        public static final String COMMUNICATION_TEST = "03";
        /**
         * アラーム
         */
        public static final String ALARM = "04";
        /**
         * 装置
         */
        public static final String EQUIPMENT = "05";
        /**
         * シャント
         */
        public static final String SHUNT = "06";
        /**
         * 遠隔点検
         */
        public static final String REMOTE_CHECK = "07";
        /**
         * バッテリー
         */
        public static final String BATTERY = "08";
        /**
         * ファイル送信
         */
        public static final String SEND_FILE = "09";
        /**
         * ファイル取得
         */
        public static final String FILE_ACQUISITION = "10";
        /**
         * アンチパスバック
         */
        public static final String ANTI_PASS_BACK = "11";
        /**
         * ゲート関連
         */
        public static final String THE_GATE_RELATION = "12";
        /**
         * 制御保持
         */
        public static final String CONTROL_MAINTENANCE = "13";
        /**
         * ダイレクト
         */
        public static final String DIRECT = "14";
        /**
         * ライブ画像
         */
        public static final String LIVE_PICTURE = "15";
        /**
         * キーレス
         */
        public static final String KEY_LESS = "16";
        /**
         * 在室者制御
         */
        public static final String CONTROL_OF_OCCUPANTS = "17";
        /**
         * 警備キー設定
         */
        public static final String GUARD_KEY_SETTING = "18";
        /**
         * センサー確認
         */
        public static final String SENSOR_CONFIRMATION = "19";
        /**
         * 静止画像取得
         */
        public static final String STATIC_IMAGE_ACQUISITION = "20";
    }

    /**
     * 警備種別（CD093）
     */
    public static class CD093 {
        /**
         * A警備
         */
        public static final String A_GUARD = "A";
        /**
         * B警備
         */
        public static final String B_GUARD = "B";
        /**
         * C警備
         */
        public static final String C_GUARD = "C";
        /**
         * D警備
         */
        public static final String D_GUARD = "D";
        /**
         * E警備
         */
        public static final String E_GUARD = "E";
        /**
         * F警備
         */
        public static final String F_GUARD = "F";
    }

    /**
     * 契約種別（CD094）
     */
    public static class CD094 {
        /**
         * GⅤ
         */
        public static final String GV = "0";
        /**
         * VSS(欠番)
         */
        public static final String VSS_THE_MISSING_NUMBER = "1";
        /**
         * HS
         */
        public static final String HS = "2";
        /**
         * テナント
         */
        public static final String TENANT = "3";
        /**
         * アマンド
         */
        public static final String ALMONDS = "4";
    }

    /**
     * 店舗形態（CD095）
     */
    public static class CD095 {
        /**
         * 選択なし
         */
        public static final String WITHOUT_CHOICE = "空白";
        /**
         * 支店
         */
        public static final String BRANCH_OFFICE = "0";
        /**
         * 有人出張所
         */
        public static final String MANNED_BRANCH_OFFICE = "1";
        /**
         * 無人出張所
         */
        public static final String UNATTENDED_BRANCH_OFFICE = "2";
        /**
         * その他
         */
        public static final String OTHERS = "3";
    }

    /**
     * 警察消防種別（CD096）
     */
    public static class CD096 {
        /**
         * 警察
         */
        public static final String THE_POLICE = "0";
        /**
         * 消防
         */
        public static final String FIRE_FIGHTING = "1";
    }

    /**
     * 自動警備セット状態（CD097）
     */
    public static class CD097 {
        /**
         * 警備セット開始
         */
        public static final String GUARD_SET_STARTING = "0";
        /**
         * セットOK
         */
        public static final String SET_OK = "1";
        /**
         * セットNG
         */
        public static final String SET_NG = "2";
        /**
         * セット信号受信
         */
        public static final String SET_SIGNAL_RECEIVED = "3";
    }

    /**
     * 通報確認区分（CD098）
     */
    public static class CD098 {
        /**
         * 不要
         */
        public static final String UNNECESSARY = "0";
        /**
         * 通報
         */
        public static final String REPORT = "1";
        /**
         * 確認・通報
         */
        public static final String CONFIRMATION_AND_REPORT = "2";
    }

    /**
     * 任務時間（CD099）
     */
    public static class CD099 {
        /**
         * 空白
         */
        public static final String BLANK = "0";
        /**
         * ON-OFF
         */
        public static final String ON_OFF = "1";
        /**
         * 24H
         */
        public static final String H24 = "2";
    }

    /**
     * 設備区分（CD100）
     */
    public static class CD100 {
        /**
         * 空白
         */
        public static final String BLANK = "0";
        /**
         * 自社設備
         */
        public static final String IN_HOUSE_EQUIPMENT = "1";
        /**
         * 契約先設備
         */
        public static final String CONTRACT_PREVIOUS_EQUIPMENT = "2";
    }

    /**
     * 建物情報鉄筋コンクリート設定（CD101）
     */
    public static class CD101 {
        /**
         * 違う
         */
        public static final String DIFFERENT = "0";
        /**
         * 鉄筋コンクリート
         */
        public static final String REINFORCED_CONCRETE = "1";
    }

    /**
     * 建物情報鉄骨鉄筋コンクリート設定（CD102）
     */
    public static class CD102 {
        /**
         * 違う
         */
        public static final String DIFFERENT = "0";
        /**
         * 鉄骨鉄筋コンクリート
         */
        public static final String STEEL_REINFORCED_CONCRETE = "1";
    }

    /**
     * 建物情報鉄骨設定（CD103）
     */
    public static class CD103 {
        /**
         * 違う
         */
        public static final String DIFFERENT = "0";
        /**
         * 鉄骨
         */
        public static final String STEEL_FRAME = "1";
    }

    /**
     * 建物情報木造設定（CD104）
     */
    public static class CD104 {
        /**
         * 違う
         */
        public static final String DIFFERENT = "0";
        /**
         * 木造
         */
        public static final String WOODEN = "1";
    }

    /**
     * 建物情報その他設定（CD105）
     */
    public static class CD105 {
        /**
         * 違う
         */
        public static final String DIFFERENT = "0";
        /**
         * その他
         */
        public static final String OTHERS = "1";
    }

    /**
     * 自動退館空室確認サービス種別（CD106）
     */
    public static class CD106 {
        /**
         * 退館確認サービス
         */
        public static final String LEAVING_CONFIRMATION_SERVICE = "1";
        /**
         * 空室検索サービス
         */
        public static final String VACANT_ROOM_SEARCH_SERVICE = "2";
    }

    /**
     * 自動退館空室検索除外タイプ（CD107）
     */
    public static class CD107 {
        /**
         * 年月日指定(全地区)
         */
        public static final String DATE_DESIGNATION_ALL_AREAS = "1";
        /**
         * 月日指定(全地区)
         */
        public static final String TIME_DESIGNATION_ALL_AREAS = "2";
        /**
         * 範囲指定(全地区)
         */
        public static final String RANGE_SPECIFICATION_ALL_AREAS = "3";
        /**
         * 曜日指定(第x曜日)
         */
        public static final String DESIGNATION_XTH_DAY_OF_THE_WEEK = "4";
        /**
         * 定休日指定
         */
        public static final String REGULAR_DAY_OFF_DESIGNATION = "5";
        /**
         * 祝日指定
         */
        public static final String HOLIDAY_DESIGNATION = "6";
    }

    /**
     * 認証画像依頼元区分（CD108）
     */
    public static class CD108 {
        /**
         * お客様
         */
        public static final String CUSTOMER = "1";
        /**
         * 警察
         */
        public static final String THE_POLICE = "2";
        /**
         * テスト用
         */
        public static final String FOR_TESTS = "3";
    }

    /**
     * 認証画像登録状態（CD109）
     */
    public static class CD109 {
        /**
         * 登録待ち
         */
        public static final String PENDING_REGISTRATION = "1";
        /**
         * 登録完了
         */
        public static final String COMPLETING_REGISTRATION = "2";
        /**
         * 枚数エラー
         */
        public static final String THE_NUMBER_ERROR = "3";
        /**
         * 画像エラー
         */
        public static final String PICTURE_ERROR = "4";
        /**
         * 通信エラー
         */
        public static final String COMMUNICATION_ERROR = "5";
        /**
         * 拒否エラー
         */
        public static final String REFUSAL_ERROR = "6";
        /**
         * その他エラー
         */
        public static final String ADDITIONALLY_ERROR = "7";
        /**
         * 削除待ち
         */
        public static final String PENDING_DELETION = "8";
        /**
         * 削除エラー
         */
        public static final String ELIMINATION_ERROR = "9";
        /**
         * 未送信
         */
        public static final String UNSENT = "10";
    }

    /**
     * 真報判断最終フラグ（CD110）
     */
    public static class CD110 {
        /**
         * 継続
         */
        public static final String CONTINUATION = "0";
        /**
         * 真報
         */
        public static final String TRUE_REPORT = "1";
        /**
         * 誤報
         */
        public static final String FALSE_REPORT = "2";
    }

    /**
     * 制御プライオリティサービスID（CD111）
     */
    public static class CD111 {
        /**
         * 情報提供サービス
         */
        public static final String DATA_BASE_SERVICE = "01";
        /**
         * CL
         */
        public static final String CL = "02";
    }

    /**
     * 優先順位（CD112）
     */
    public static class CD112 {
        /**
         * 優先度0(高)
         */
        public static final String PRIORITY_0_HIGH = "0";
        /**
         * 優先度1
         */
        public static final String PRIORITY_1 = "1";
        /**
         * 優先度2
         */
        public static final String PRIORITY_2 = "2";
        /**
         * 優先度3
         */
        public static final String PRIORITY_3 = "3";
        /**
         * 優先度4
         */
        public static final String PRIORITY_4 = "4";
        /**
         * 優先度5
         */
        public static final String PRIORITY_5 = "5";
        /**
         * 優先度6
         */
        public static final String PRIORITY_6 = "6";
        /**
         * 優先度7
         */
        public static final String PRIORITY_7 = "7";
        /**
         * 優先度8
         */
        public static final String PRIORITY_8 = "8";
        /**
         * 優先度9(低)
         */
        public static final String PRIORITY_9_LOW = "9";
    }

    /**
     * 制御装置接続中回線（CD113）
     */
    public static class CD113 {
        /**
         * 回線1
         */
        public static final String CIRCUIT_1 = "1";
        /**
         * 回線2
         */
        public static final String CIRCUIT_2 = "2";
    }

    /**
     * 撮像トリガー（CD114）
     */
    public static class CD114 {
        /**
         * ON
         */
        public static final String ON = "0";
        /**
         * ON&OFF
         */
        public static final String ON_OFF = "1";
    }

    /**
     * 警備状態（CD115）
     */
    public static class CD115 {
        /**
         * 警備中
         */
        public static final String UNDER_SECURITY = "1";
        /**
         * 警備解除中
         */
        public static final String UNPROTECTING = "2";
        /**
         * 24時間
         */
        public static final String HOURS_24 = "3";
    }

    /**
     * 隊員セキュリティカード有効フラグ（CD116）
     */
    public static class CD116 {
        /**
         * 無効
         */
        public static final String INVALID = "0";
        /**
         * 有効
         */
        public static final String EFFECTIVE = "1";
        /**
         * 盗難紛失
         */
        public static final String THEFT_LOSS = "2";
    }

    /**
     * 隊員セキュリティカード操作区分（CD117）
     */
    public static class CD117 {
        /**
         * ユーザ
         */
        public static final String THE_USER = "0";
        /**
         * ALSOK
         */
        public static final String ALSOK = "1";
        /**
         * オプションa
         */
        public static final String OPTION_A = "2";
        /**
         * オプションb
         */
        public static final String OPTION_B = "3";
    }

    /**
     * アンチパスバック対象区分（CD118）
     */
    public static class CD118 {
        /**
         * なし
         */
        public static final String NONE = "0";
        /**
         * アンチパスバック対象
         */
        public static final String ANTI_PASS_BACK_TARGET = "1";
        /**
         * 準アンチパスバック対象
         */
        public static final String ASSOCIATE_ANTI_PASS_BACK_TARGET = "2";
    }

    /**
     * SD契約形態（CD119）
     */
    public static class CD119 {
        /**
         * オンライン①契約
         */
        public static final String ON_LINE_1_CONTRACT = "0";
        /**
         * オンライン②契約
         */
        public static final String ON_LINE_2_CONTRACT = "1";
        /**
         * オフライン
         */
        public static final String OFF_LINE = "2";
    }

    /**
     * 工事実施延長可否（CD120）
     */
    public static class CD120 {
        /**
         * 可能
         */
        public static final String POSSIBLE = "0";
        /**
         * 不可能
         */
        public static final String IMPOSSIBLE = "1";
    }

    /**
     * 保存画像.画像区分（CD121）
     */
    public static class CD121 {
        /**
         * 現在画像
         */
        public static final String CURRENT_IMAGE = "1";
        /**
         * セルフ警備警報画像
         */
        public static final String SELF_GUARD_WARNING_PICTURE = "2";
        /**
         * 警報画像
         */
        public static final String WARNING_PICTURE = "3";
    }

    /**
     * 拠点落着フラグ（CD122）
     */
    public static class CD122 {
        /**
         * 拠点で事案として存在する
         */
        public static final String FACT_PLAN_AT_A_BASE_BASE = "0";
        /**
         * 拠点で事案として存在しない(落着済最終情報未取得)
         */
        public static final String THE_LAST_INFORMATION_SHEEP_ACQUISITION_ACQUISITION = "1";
        /**
         * 拠点で事案として存在しない(落着済最終情報取得済)
         */
        public static final String THE_LAST_INFORMATION_IS_ALREADY_ACQUIRED_ACQUIRED = "2";
    }

    /**
     * 出動キャンセルマーク（CD123）
     */
    public static class CD123 {
        /**
         * 判定対象外、通知しない

         */
        public static final String JUDGMENT_INAPPLICABLY_INAPPLICABLY = "△(ｽﾍﾟｰｽ)";
        /**
         * 表示(警備先へ架電確認)

         */
        public static final String INDICATION_1 = "1";
        /**
         * 表示(特約等確認後、キャンセル可)

         */
        public static final String INDICATION_2 = "2";
        /**
         * 判定中

         */
        public static final String JUDGING = "*";
    }

    /**
     * キャンセル通知フラグ（CD124）
     */
    public static class CD124 {
        /**
         * 通知済み
         */
        public static final String NOTIFIED = "1";
        /**
         * 通知失敗
         */
        public static final String NOTIFICATION_FAILED = "2";
    }

    /**
     * 本人確認フラグ（CD125）
     */
    public static class CD125 {
        /**
         * 未実施
         */
        public static final String NOT_IMPLEMENTED = "△(ｽﾍﾟｰｽ)";
        /**
         * 確認済み
         */
        public static final String CONFIRMED = "1";
    }

    /**
     * 隊員状態フラグ（CD126）
     */
    public static class CD126 {
        /**
         * 指示
         */
        public static final String DIRECTIONS = "0";
        /**
         * 出勤
         */
        public static final String ATTENDANCE = "1";
        /**
         * 落着
         */
        public static final String SETTLEMENT = "2";
    }

    /**
     * 画面登録区分種別（CD127）
     */
    public static class CD127 {
        /**
         * 画面登録
         */
        public static final String SCREEN_REGISTRATION = "0";
        /**
         * 一括画面登録(警備先指定)
         */
        public static final String LUMPING_SCREEN_REGISTRATION = "1";
        /**
         * 装置指定(RMCLのみ)
         */
        public static final String ONLY_RMCL = "2";
    }

    /**
     * タイムアウト日時フラグ（CD128）
     */
    public static class CD128 {
        /**
         * 通常
         */
        public static final String USUALLY = "0";
        /**
         * 真報判断タイムオーバー
         */
        public static final String TRUE_REPORT_JUDGEMENT_TIME_OVER = "1";
    }

    /**
     * 真報判断実施フラグ（CD129）
     */
    public static class CD129 {
        /**
         * 真報判断しない
         */
        public static final String A_TRUE_REPORT_IS_NOT_JUDGED = "空白";
        /**
         * 未実施
         */
        public static final String UNACTED = "0";
        /**
         * 真報
         */
        public static final String TRUE_REPORT = "1";
    }

    /**
     * 真報理由フラグ（CD130）
     */
    public static class CD130 {
        /**
         * 未実施
         */
        public static final String UNACTED = "空白";
        /**
         * タイムアップ
         */
        public static final String TIME_UP = "0";
        /**
         * 即GC
         */
        public static final String IMMEDIATELY_GC = "1";
        /**
         * 真報判断_即出動
         */
        public static final String ITLL_BE_DISPATCHED_IMMEDIATELY = "2";
        /**
         * 真報判断_遅延出動
         */
        public static final String DELAYED_DISPATCHING = "3";
        /**
         * 真報判断_出動なし
         */
        public static final String WITHOUT_DISPATCHING = "9";
    }

    /**
     * 落着フラグ（CD131）
     */
    public static class CD131 {
        /**
         * 運用中
         */
        public static final String IN_OPERATION = "0";
        /**
         * 落着
         */
        public static final String SETTLEMENT = "1";
        /**
         * 取消
         */
        public static final String CANCELLATION = "2";
    }

    /**
     * インターホン状態（CD132）
     */
    public static class CD132 {
        /**
         * 無し
         */
        public static final String NONE = "0";
        /**
         * インタホン呼出中
         */
        public static final String CALLING_INTERPHONE = "1";
        /**
         * インタホン通話中
         */
        public static final String INTERPHONE_CALL_IN_PROGRESS = "2";
    }

    /**
     * RM表示レコード有フラグ（CD133）
     */
    public static class CD133 {
        /**
         * RM表示レコード有
         */
        public static final String WITH_RM_INDICATION_RECORD = "1";
    }

    /**
     * 電子メモ処置区分（CD134）
     */
    public static class CD134 {
        /**
         * 運用中
         */
        public static final String IN_OPERATION = "0";
        /**
         * 落着
         */
        public static final String SETTLEMENT = "1";
        /**
         * 取消
         */
        public static final String CANCELLATION = "2";
    }

    /**
     * 取得完了フラグ（CD135）
     */
    public static class CD135 {
        /**
         * 未取得
         */
        public static final String UNACQUIRED = "0";
        /**
         * 完了
         */
        public static final String COMPLETION = "1";
        /**
         * 失敗
         */
        public static final String FAILURE = "2";
        /**
         * 失敗(破棄)
         */
        public static final String FAILURE_DESTRUCTION = "3";
        /**
         * 取得予定なし
         */
        public static final String WITHOUT_ACQUISITION_SCHEDULES = "9";
    }

    /**
     * 警備情報発生元区分（CD136）
     */
    public static class CD136 {
        /**
         * 信号受信SV
         */
        public static final String SIGNAL_RECEPTION_SV = "0";
        /**
         * 機器管理サーバ
         */
        public static final String EQUIPMENT_ADMINISTRATIVE_SERVER = "1";
        /**
         * 監視AP内部
         */
        public static final String INSIDE_THE_WATCH_AP = "2";
        /**
         * 画面登録
         */
        public static final String SCREEN_REGISTRATION = "3";
        /**
         * 制御
         */
        public static final String CONTROL = "4";
        /**
         * 真報判断をキャンセルして送信
         */
        public static final String IS_CANCELED_AND_SENT = "2";
    }

    /**
     * GC送信フラグ（CD137）
     */
    public static class CD137 {
        /**
         * 無
         */
        public static final String NOTHING = "0";
        /**
         * 常時
         */
        public static final String ALWAYS = "1";
        /**
         * 誤報時
         */
        public static final String FALSE_REPORT = "3";
    }

    /**
     * 信号区分（CD138）
     */
    public static class CD138 {
        /**
         * 警報
         */
        public static final String WARNING = "01";
        /**
         * F0
         */
        public static final String F0 = "02";
        /**
         * N0
         */
        public static final String N0 = "03";
        /**
         * KF
         */
        public static final String KF = "04";
        /**
         * KN
         */
        public static final String KN = "05";
        /**
         * 状態
         */
        public static final String STATE = "06";
        /**
         * 復旧
         */
        public static final String RESTORATION = "07";
        /**
         * 停電
         */
        public static final String BLACKOUT = "08";
        /**
         * 故障
         */
        public static final String BREAKOUT = "09";
        /**
         * RM画面登録信号
         */
        public static final String RM_SCREEN_REGISTRATION_SIGNAL = "10";
    }

    /**
     * 信号種別マスター履歴表示フラグ（CD139）
     */
    public static class CD139 {
        /**
         * 表示しない
         */
        public static final String DOES_NOT_DISPLAY = "0";
        /**
         * 通常の履歴として表示
         */
        public static final String DISPLAY_AS_NORMAL_HISTORY = "1";
        /**
         * 内部統制信号として表示
         */
        public static final String DISPLAY_AS_CONTROL_SIGNAL = "2";
    }

    /**
     * RMT信号区分（CD140）
     */
    public static class CD140 {
        /**
         * 警報
         */
        public static final String WARNING = "01";
        /**
         * 停電、停電復旧
         */
        public static final String BLACKOUT_AND_POWER_RECOVERY = "02";
        /**
         * 全復旧
         */
        public static final String THE_WHOLE_RESTORATION = "03";
        /**
         * 入退館
         */
        public static final String ENTRANCE_AND_LEAVING = "04";
    }

    /**
     * 信号種別マスター信号絞込み区分（CD141）
     */
    public static class CD141 {
        /**
         * 監視事案設定対象
         */
        public static final String WATCH_FACT_PLAN_SETTING_TARGET = "1";
        /**
         * 事案絞込みプルダウン
         */
        public static final String FACT_PLAN_SQUEEZE_PULLDOWN = "2";
        /**
         * 両方
         */
        public static final String BOTH_OF_THEM = "3";
    }

    /**
     * 常時接続フラグ（CD142）
     */
    public static class CD142 {
        /**
         * 常時接続しない
         */
        public static final String NOT_ALWAYS_CONNECTED = "0";
        /**
         * 常時接続する
         */
        public static final String ALWAYS_CONNECTED = "1";
    }

    /**
     * ネットワーク機器フラグ（CD143）
     */
    public static class CD143 {
        /**
         * ルータorHUB
         */
        public static final String ROUTER_ORHUB = "0";
        /**
         * 終端装置
         */
        public static final String TERMINATING_DEVICE = "1";
        /**
         * モデム(不明)
         */
        public static final String MODEM_OBSCURITY = "2";
    }

    /**
     * モデム提供メーカ（CD144）
     */
    public static class CD144 {
        /**
         * YahooBB
         */
        public static final String YAHOOBB = "0";
        /**
         * NTT東西
         */
        public static final String NTT_EAST_AND_WEST = "1";
        /**
         * その他
         */
        public static final String OTHES = "2";
    }

    /**
     * 真報判断フラグ（CD145）
     */
    public static class CD145 {
        /**
         * 誤報
         */
        public static final String FALSE_REPORT = "0";
        /**
         * 真報
         */
        public static final String TRUE_REPORT = "1";
    }

    /**
     * アンチパスバック部屋番号（CD146）
     */
    public static class CD146 {
        /**
         * 部屋番号
         */
        public static final String THE_ROOM_NUMBER = "001-255";
        /**
         * 室外
         */
        public static final String OUTSIDE = "000";
        /**
         * フリー
         */
        public static final String FREE = "999";
    }

    /**
     * イベント管理情報履歴警備状態（CD147）
     */
    public static class CD147 {
        /**
         * 警備中
         */
        public static final String GUARDING = "1";
        /**
         * 警備解除中
         */
        public static final String GUARD_IS_RELEASED = "2";
        /**
         * その他
         */
        public static final String OTHERS = "3";
    }

    /**
     * シャント設定状態（CD148）
     */
    public static class CD148 {
        /**
         * 解除
         */
        public static final String RELEASE = "0";
        /**
         * 設定
         */
        public static final String SETTING = "1";
    }

    /**
     * 在宅警備区域状態（CD149）
     */
    public static class CD149 {
        /**
         * ZN0
         */
        public static final String ZN0 = "M";
        /**
         * ZF0
         */
        public static final String ZF0 = "E";
    }

    /**
     * 出動要請区分L6（CD150）
     */
    public static class CD150 {
        /**
         * 無し
         */
        public static final String NONE = "0";
        /**
         * 即時
         */
        public static final String IMMEDIATELY = "1";
        /**
         * 遅延
         */
        public static final String DELAY = "2";
    }

    /**
     * 保持設定情報（CD151）
     */
    public static class CD151 {
        /**
         * 保持解除
         */
        public static final String MAINTENANCE_RELEASE = "0";
        /**
         * 保持
         */
        public static final String MAINTENANCE = "1";
    }

    /**
     * 施解錠アンサ状態（CD152）
     */
    public static class CD152 {
        /**
         * 解錠
         */
        public static final String UNLOCKING = "0";
        /**
         * 施錠
         */
        public static final String LOCKING = "1";
    }

    /**
     * 続柄コード（CD153）
     */
    public static class CD153 {
        /**
         * 本人
         */
        public static final String THE_PERSON_HIMSELF = "0";
        /**
         * 夫
         */
        public static final String HUSBAND = "1";
        /**
         * 妻
         */
        public static final String WIFE = "2";
        /**
         * 子
         */
        public static final String CHILD = "3";
        /**
         * 孫
         */
        public static final String GRANDCHILD = "4";
        /**
         * 父
         */
        public static final String FATHER = "5";
        /**
         * 母
         */
        public static final String MOTHER = "6";
        /**
         * 兄
         */
        public static final String ELDER_BROTHER = "7";
        /**
         * 姉
         */
        public static final String ELDER_SISTER = "8";
        /**
         * 弟
         */
        public static final String YOUNGER_BROTHER = "9";
        /**
         * 妹
         */
        public static final String YOUNGER_SISTER = "10";
        /**
         * 祖父
         */
        public static final String GRANDFATHER = "11";
        /**
         * 祖母
         */
        public static final String GRANDMOTHER = "12";
        /**
         * その他
         */
        public static final String OTHERS = "99";
    }

    /**
     * スキーマ種別（CD154）
     */
    public static class CD154 {
        /**
         * 次期警備スキーマ
         */
        public static final String NEXT_SECURITY_GUARD_SCHEMA = "1";
        /**
         * 共通スキーマ
         */
        public static final String COMMON_SCHEMA = "2";
        /**
         * ＧⅤスキーマ
         */
        public static final String GV_SCHEMA = "3";
        /**
         * ＧＨＳスキーマ
         */
        public static final String GHS_SCHEMA = "4";
    }

    /**
     * 巡回状態（CD155）
     */
    public static class CD155 {
        /**
         * 巡回監視しない
         */
        public static final String PATROL_OFF = "0";
        /**
         * 巡回監視する
         */
        public static final String PATROL_ON = "1";
    }

    /**
     * 認証画像種類（CD156）
     */
    public static class CD156 {
        /**
         * 重要犯罪情報
         */
        public static final String IMPORTANT_CRIMINAL_INFORMATION = "1";
        /**
         * 特定顧客情報
         */
        public static final String SPECIFIC_CUSTOMER_INFORMATION = "2";
    }

    /**
     * 認証状態（CD157）
     */
    public static class CD157 {
        /**
         * 認証中
         */
        public static final String DURING_THE_AUTHENTICATION = "1";
        /**
         * 新規
         */
        public static final String NEW = "2";
        /**
         * 削除
         */
        public static final String ELIMINATION = "3";
    }

    /**
     * 更新状態（CD158）
     */
    public static class CD158 {
        /**
         * 未更新
         */
        public static final String NOT_UPDATED = "0";
        /**
         * 更新中
         */
        public static final String UPDATING = "1";
        /**
         * 更新済
         */
        public static final String ALREADY_RENEWED = "2";
    }

    /**
     * 閲覧設定状態（CD159）
     */
    public static class CD159 {
        /**
         * NO中
         */
        public static final String NO = "1";
        /**
         * FO中
         */
        public static final String FO = "2";
        /**
         * 24H
         */
        public static final String H24 = "3";
        /**
         * 閲覧無し
         */
        public static final String WITHOUT_READING = "4";
    }

    /**
     * 蓄積画像削除条件（CD160）
     */
    public static class CD160 {
        /**
         * 期間
         */
        public static final String PERIOD = "1";
        /**
         * 容量
         */
        public static final String THE_CAPACITY = "2";
        /**
         * 期間＋容量
         */
        public static final String THE_PERIOD_VOLUME = "3";
    }

    /**
     * 削除フラグ（CD161）
     */
    public static class CD161 {
        /**
         * 未削除
         */
        public static final String NOT_DELETED = "0";
        /**
         * 削除済
         */
        public static final String DELETED = "1";
    }

    /**
     * サイト区分（CD162）
     */
    public static class CD162 {
        /**
         * 利用者サイト
         */
        public static final String USER_SITE = "0";
        /**
         * 利用者サイト(AP/スマホ)
         */
        public static final String THE_USER_SITE_AP_SMART_PHONE = "1";
        /**
         * 隊員向けサイト
         */
        public static final String SITE_FOR_MEMBERS = "2";
        /**
         * 運用管理サイト
         */
        public static final String OPERATIONS_MANAGEMENT_SITE = "3";
        /**
         * 監視+巡回サイト
         */
        public static final String WATCH_PATROL_SITE = "4";
        /**
         * エラー表示サイト
         */
        public static final String ERROR_DISPLAY_SITE = "5";
        /**
         * RMT監視サイト
         */
        public static final String RMT_WATCH_SITE = "6";
    }

    /**
     * 名簿区分（CD163）
     */
    public static class CD163 {
        /**
         * 緊急連絡先
         */
        public static final String THE_URGENT_PHONE_NUMBER = "1";
        /**
         * 同居家族
         */
        public static final String THE_LIVING_FAMILY = "2";
        /**
         * 救急情報
         */
        public static final String FIRST_AID_INFORMATION = "3";
    }

    /**
     * IPアドレス払出フラグ（CD164）
     */
    public static class CD164 {
        /**
         * 自動
         */
        public static final String AUTOMATIC = "1";
        /**
         * 固定
         */
        public static final String FIXING = "2";
    }

    /**
     * 操作レベル区分（CD165）
     */
    public static class CD165 {
        /**
         * 警備
         */
        public static final String GUARD = "1";
        /**
         * 出入
         */
        public static final String GOING_IN_AND_OUT_OF = "2";
        /**
         * 出退勤
         */
        public static final String CLOCK_IN_AND_OUT = "3";
    }

    /**
     * キーレス権限設定フラグ（CD166）
     */
    public static class CD166 {
        /**
         * 設定
         */
        public static final String SETTING = "0";
        /**
         * 解除
         */
        public static final String RELEASE = "1";
    }

    /**
     * 論理削除フラグ（CD167）
     */
    public static class CD167 {
        /**
         * 有効
         */
        public static final String EFFECTIVE = "0";
        /**
         * 論理削除
         */
        public static final String LOGIC_ELIMINATION = "1";
    }

    /**
     * 映像音声区分（CD168）
     */
    public static class CD168 {
        /**
         * 画像
         */
        public static final String PICTURE = "0";
        /**
         * 音声
         */
        public static final String SOUND = "1";
    }

    /**
     * 画質（CD169）
     */
    public static class CD169 {
        /**
         * 低画質
         */
        public static final String LOW_IMAGE_QUALITY = "0";
        /**
         * 標準画質
         */
        public static final String STANDARD_IMAGE_QUALITY = "1";
        /**
         * 高画質
         */
        public static final String HIGH_DEFINITION = "2";
    }

    /**
     * 画像サイズ（CD170）
     */
    public static class CD170 {
        /**
         * 320×240（QVGA）
         */
        public static final String S_320_240_QVGA = "1";
        /**
         * 352×240
         */
        public static final String S_352_240 = "2";
        /**
         * 640×480（VGA）
         */
        public static final String S_640_480_VGA = "3";
        /**
         * 704×240
         */
        public static final String S_704_240 = "4";
        /**
         * 704×480
         */
        public static final String S_704_480 = "5";
        /**
         * 1280×720（HD）
         */
        public static final String S_1280_720_HD = "6";
        /**
         * 1920×1080（フルHD）
         */
        public static final String S_1920_1080_FULLHD = "7";
        /**
         * 1280×960（SXVGA）
         */
        public static final String S_1280_960_SXVGA = "8";
    }

    /**
     * 符号化方式（CD171）
     */
    public static class CD171 {
        /**
         * JPEG
         */
        public static final String JPEG = "1";
        /**
         * MotionJPEG
         */
        public static final String MOTIONJPEG = "2";
        /**
         * MPEG4
         */
        public static final String MPEG4 = "3";
        /**
         * H.264
         */
        public static final String H_264 = "4";
    }

    /**
     * ストリーミング方式（CD172）
     */
    public static class CD172 {
        /**
         * AS
         */
        public static final String AS = "1";
        /**
         * TS
         */
        public static final String TS = "2";
    }

    /**
     * 自動フラグ（CD173）
     */
    public static class CD173 {
        /**
         * 手動
         */
        public static final String MANUAL = "0";
        /**
         * 自動
         */
        public static final String AUTOMATIC = "1";
    }

    /**
     * 操作権限区分（CD174）
     */
    public static class CD174 {
        /**
         * 参照権限
         */
        public static final String REFERENCE_RIGHT = "0";
        /**
         * 操作権限
         */
        public static final String OPERATIONAL_RIGHT = "1";
    }

    /**
     * 検索条件機種（CD175）
     */
    public static class CD175 {
        /**
         * すべて
         */
        public static final String EVERYTHING = "00";
        /**
         * GS
         */
        public static final String GS = "01";
        /**
         * HS
         */
        public static final String HS = "02";
    }

    /**
     * 有線無線判別フラグ（CD176）
     */
    public static class CD176 {
        /**
         * アナログ
         */
        public static final String ANALOG = "A";
        /**
         * 有線(IP)/IPv4
         */
        public static final String A_CABLE_IP_IPV_4 = "0";
        /**
         * 有線(IP)/IPv6
         */
        public static final String A_CABLE_IP_IPV_6 = "1";
        /**
         * 無線(3G)/IPv4
         */
        public static final String WIRELESS_3G_IPV_4 = "2";
        /**
         * 無線(3G)/IPv6
         */
        public static final String WIRELESS_3G_IPV_6 = "3";
        /**
         * 無線(M2M)/IPv4
         */
        public static final String WIRELESS_M2M_IPV_4 = "4";
        /**
         * 無線(M2M)/IPv6
         */
        public static final String WIRELESS_M2M_IPV_6 = "5";
        /**
         * 無線(LTE)/IPv4
         */
        public static final String WIRELESS_LTE_IPV_4 = "6";
        /**
         * 無線(LTE)/IPv6
         */
        public static final String WIRELESS_LTE_IPV_6 = "7";
    }

    /**
     * リモート種別（CD177）
     */
    public static class CD177 {
        /**
         * 通常（本体操作）
         */
        public static final String USUAL_BODY_OPERATION = "0";
        /**
         * リモートコントロール
         */
        public static final String REMOTE_CONTROL = "1";
        /**
         * 接点入力
         */
        public static final String POINT_OF_FACT_INPUT = "2";
        /**
         * リーダー（カード操作）
         */
        public static final String READER_CARD_OPERATION = "3";
        /**
         * リーダー（テンキー操作）
         */
        public static final String READER_NUMERIC_KEY_OPERATION = "4";
        /**
         * 鍵式操作
         */
        public static final String THE_KEY_SYSTEM_OPERATION = "5";
        /**
         * タブレット操作
         */
        public static final String TABLET_OPERATION = "6";
        /**
         * スケジュール
         */
        public static final String SCHEDULE = "7";
    }

    /**
     * 処理状態フラグ（CD178）
     */
    public static class CD178 {
        /**
         * 未処理
         */
        public static final String UNPROCESSED = "0";
        /**
         * 警備信号処理終了
         */
        public static final String GUARD_SIGNAL_PROCESSING_END = "1";
        /**
         * GC送信処理済み
         */
        public static final String A_GC_TRANSMISSION_IS_ALREADY_PROCESSED = "2";
        /**
         * 処理中
         */
        public static final String BEING_PROCESSED = "3";
        /**
         * 重複警備信号受信
         */
        public static final String OVERLAP_GUARD_SIGNAL_RECEIVED = "D";
        /**
         * GC送信処理済み（再開）
         */
        public static final String GC_TRANSMISSION_IS_ALREADY_PROCESSED_RESUMPTION = "R";
        /**
         * エラー
         */
        public static final String ERROR = "9";
    }

    /**
     * キュー送信状態（CD179）
     */
    public static class CD179 {
        /**
         * 未送信
         */
        public static final String UNSENT = "0";
        /**
         * リクエスト送信中
         */
        public static final String A_REQUEST_IS_BEING_SENT = "1";
        /**
         * レスポンス受理（OK）
         */
        public static final String RESPONSE_ACCEPTANCE_OK = "2";
        /**
         * レスポンス受理（OK以外）
         */
        public static final String RESPONSE_ACCEPTANCE_BESIDES_OK = "3";
        /**
         * 成功
         */
        public static final String SUCCESS = "S";
        /**
         * エラー
         */
        public static final String ERROR = "E";
        /**
         * タイムアウト
         */
        public static final String TIME_OUT = "T";
    }

    /**
     * センターエラー詳細（CD180）
     */
    public static class CD180 {
        /**
         * 制御送信時リトライタイムアウト
         */
        public static final String TIME_OUT_1 = "T1";
        /**
         * 制御結果受信待ちタイムアウト
         */
        public static final String TIME_OUT_2 = "T2";
        /**
         * 先行処理エラー
         */
        public static final String ERROR = "PE";
        /**
         * 後続処理エラー
         */
        public static final String FOLLOWING_PROCESSING_ERROR = "SE";
        /**
         * その他エラー
         */
        public static final String ADDITIONALLY_ERROR = "OE";
    }

    /**
     * 制御装置コマンドエラーコード（CD181）
     */
    public static class CD181 {
        /**
         * 正常
         */
        public static final String NORMAL = "0";
        /**
         * ERROR
         */
        public static final String ERROR = "1";
        /**
         * パラメータ値不正
         */
        public static final String PARAMETER_VALUE_INJUSTICE = "2";
        /**
         * コマンドバージョン不正
         */
        public static final String COMMAND_VERSION_INJUSTICE = "3";
        /**
         * 拒絶
         */
        public static final String REFUSAL = "4";
        /**
         * 障害
         */
        public static final String OBSTACLE = "9";
    }

    /**
     * RMSVコマンド通知エラーコード（CD182）
     */
    public static class CD182 {
        /**
         * パラメータ値不正（業務APサーバから送信された電文が不正な場合）
         */
        public static final String PARAMETER_VALUE_INJUSTICE = "1";
        /**
         * サーバ間通信不正（RMサーバ、業務AP以外のサーバとの通信が不正な場合）
         */
        public static final String COMMUNICATION_INJUSTICE_BETWEEN = "2";
        /**
         * 送信機ID不正（アナログ回線経由）
         */
        public static final String CIRCUIT_PASS_PASS = "10";
    }

    /**
     * 制御装置コマンド実行結果(1)（CD183）
     */
    public static class CD183 {
        /**
         * OK
         */
        public static final String OK = "0";
        /**
         * CRCエラー
         */
        public static final String CRC_ERROR = "1";
        /**
         * データ不正
         */
        public static final String DATA_INJUSTICE = "2";
    }

    /**
     * 制御装置コマンド実行結果(2)（CD184）
     */
    public static class CD184 {
        /**
         * OK
         */
        public static final String OK = "0";
        /**
         * 装置番号エラー
         */
        public static final String EQUIPMENT_NUMBER_ERROR = "1";
        /**
         * ファイル名エラー
         */
        public static final String FILE_NAME_ERROR = "2";
    }

    /**
     * 制御装置コマンド実行結果(3)（CD185）
     */
    public static class CD185 {
        /**
         * OK
         */
        public static final String OK = "0";
        /**
         * NG
         */
        public static final String NG = "1";
        /**
         * 排他エラー
         */
        public static final String EXCLUSION_ERROR = "2";
        /**
         * SRFエラー
         */
        public static final String SRF_ERROR = "3";
        /**
         * 操作禁止（遷移不可操作）
         */
        public static final String TRANSFER_BAD_OPERATION_OPERATION = "4";
        /**
         * エリア不正
         */
        public static final String AREA_INJUSTICE = "5";
        /**
         * （欠番）
         */
        public static final String THE_MISSING_NUMBER = "6";
        /**
         * 地区、在室エリアなし
         */
        public static final String NO_AREA = "7";
        /**
         * 親子警備状態遷移エラー
         */
        public static final String TRANSITION_ERROR = "8";
        /**
         * 部分警備状態遷移エラー
         */
        public static final String PARTIAL_TRANSITION_ERROR = "9";
    }

    /**
     * 断線状態（CD186）
     */
    public static class CD186 {
        /**
         * 正常
         */
        public static final String NORMAL = "0";
        /**
         * 断線
         */
        public static final String BREAKING = "1";
    }

    /**
     * 営業システム連携区分（CD187）
     */
    public static class CD187 {
        /**
         * 新営業システム(連携元)→次期警備(連携先)
         */
        public static final String BIZSYSTEM_TO_NEXTGUARD = "1";
        /**
         * 次期警備(連携元)→新営業システム(連携先)
         */
        public static final String NEXTGUARD_TO_BIZSYSTEM = "2";
    }

    /**
     * 通知種別（CD188）
     */
    public static class CD188 {
        /**
         * 警備セット
         */
        public static final String GUARD_SET = "01";
        /**
         * 警備解除
         */
        public static final String GUARD_RELEASE = "02";
        /**
         * 警備セット忘れ通知
         */
        public static final String GUARD_SET_LEAVING_NOTICE = "03";
        /**
         * 空室メール通知
         */
        public static final String VACANT_ROOM_MAIL_NOTICE = "04";
        /**
         * 外出ALSOK警備開始
         */
        public static final String GOING_OUT_ALSOK_GUARD_STARTING = "05";
        /**
         * 外出ALSOK警備解除
         */
        public static final String GOING_OUT_ALSOK_GUARD_RELEASE = "06";
        /**
         * 在宅ALSOK警備開始
         */
        public static final String ALSOK_GUARD_STARTING_AT_HOME = "07";
        /**
         * 在宅ALSOK警備解除
         */
        public static final String ALSOK_GUARD_RELEASE_AT_HOME = "08";
        /**
         * 警報
         */
        public static final String WARNING = "09";
        /**
         * 定期連絡（正常）
         */
        public static final String NORMALITY = "21";
        /**
         * 定刻連絡（正常）
         */
        public static final String NORMALITY_NORMALITY = "22";
        /**
         * 定刻連絡（異常発生中）
         */
        public static final String IT_HAS_BROKEN_OUT_OUT = "23";
        /**
         * 定刻連絡（見守り停止中）
         */
        public static final String ITS_WATCHED_AND_SUSPENDED = "24";
        /**
         * 異常通知
         */
        public static final String ABNORMAL_NOTICE = "25";
        /**
         * 異常復旧
         */
        public static final String ABNORMAL_RESTORATION = "26";
        /**
         * 操作忘れ通知
         */
        public static final String OPERATIONAL_LEAVING_NOTICE = "27";
        /**
         * 見守り開始連絡
         */
        public static final String WATCH_STARTING_CONTACT = "28";
        /**
         * 見守り停止連絡
         */
        public static final String WATCH_STOP_CONTACT = "29";
        /**
         * 設定変更連絡
         */
        public static final String SETTING_CHANGE_CONTACT = "30";
        /**
         * 設定エラー
         */
        public static final String SETTING_ERROR = "31";
        /**
         * ALSOKお知らせ(GS)
         */
        public static final String ALSOK_NEWS_GS = "51";
        /**
         * ALSOKお知らせ(HS)
         */
        public static final String ALSOK_NEWS_HS = "52";
        /**
         * ユーザー仮登録(GS)
         */
        public static final String THE_USER_TEMPORARY_REGISTRATION_GS = "61";
        /**
         * ユーザー本登録(GS)
         */
        public static final String THE_USER_REGISTRATION_GS = "62";
        /**
         * パスワード再登録(GS)
         */
        public static final String PASSWORD_RE_REGISTRATION_GS = "63";
        /**
         * パスワード変更(GS)
         */
        public static final String PASSWORD_CHANGE_GS = "64";
        /**
         * ユーザー仮登録(HS)
         */
        public static final String THE_USER_TEMPORARY_REGISTRATION_HS = "65";
        /**
         * ユーザー本登録(HS)
         */
        public static final String THE_USER_REGISTRATION_HS = "66";
        /**
         * パスワード再登録(HS)
         */
        public static final String PASSWORD_RE_REGISTRATION_HS = "67";
        /**
         * パスワード変更完了(HS)
         */
        public static final String PASSWORD_CHANGE_COMPLETION_HS = "68";
        /**
         * メールアドレス変更(GS)
         */
        public static final String MAIL_ADDRESS_CHANGE_GS = "69";
        /**
         * メールアドレス変更(HS)
         */
        public static final String MAIL_ADDRESS_CHANGE_HS = "70";
    }

    /**
     * トリガーキュー状態（CD189）
     */
    public static class CD189 {
        /**
         * 未処理
         */
        public static final String UNPROCESSED = "0";
        /**
         * 処理済
         */
        public static final String ALREADY_PROCESSED = "1";
        /**
         * 取消
         */
        public static final String CANCELLATION = "2";
        /**
         * 送信先無し
         */
        public static final String WITHOUT_TRANSMISSION_DESTINATIONS = "8";
        /**
         * 送信エラー
         */
        public static final String SEND_ERROR = "E";
    }

    /**
     * 解析キュー状態（CD190）
     */
    public static class CD190 {
        /**
         * 未処理
         */
        public static final String UNPROCESSED = "0";
        /**
         * 処理済
         */
        public static final String ALREADY_PROCESSED = "1";
        /**
         * 処理済(バウンスメール)
         */
        public static final String ALREAD_PROCESSED_BOUNCE_MAIL = "2";
        /**
         * 解析対象外
         */
        public static final String ANALYSIS_APPLYING = "8";
        /**
         * 更新エラー
         */
        public static final String RENEWAL_ERROR = "9";
        /**
         * 解析エラー
         */
        public static final String ANALYSIS_ERROR = "E";
    }

    /**
     * ファイル受信状態（CD191）
     */
    public static class CD191 {
        /**
         * 受信待ち
         */
        public static final String RECEPTION_WAITING = "1";
        /**
         * 受信中
         */
        public static final String BEING_RECEIVED = "2";
        /**
         * 受信済み(解析待ち)
         */
        public static final String RECEIVED = "3";
        /**
         * 完了（正常）
         */
        public static final String COMPLETION_NORMALITY = "0";
        /**
         * エラー
         */
        public static final String ERROR = "E";
    }

    /**
     * 警備フラグ（CD192）
     */
    public static class CD192 {
        /**
         * F0
         */
        public static final String F0 = "0";
        /**
         * N0
         */
        public static final String N0 = "1";
        /**
         * ZN0
         */
        public static final String ZN0 = "2";
        /**
         * DF0
         */
        public static final String DF0 = "3";
    }

    /**
     * ALSOK警備フラグ（CD193）
     */
    public static class CD193 {
        /**
         * KF
         */
        public static final String KF = "0";
        /**
         * KN
         */
        public static final String KN = "1";
    }

    /**
     * 施解錠状態（CD196）
     */
    public static class CD196 {
        /**
         * 施錠
         */
        public static final String LOCKING = "0";
        /**
         * 解錠
         */
        public static final String UNLOCKING = "1";
        /**
         * 1回解錠
         */
        public static final String UNLOCKED_ONCE = "2";
        /**
         * 強制施錠
         */
        public static final String COMPULSION_LOCKING = "3";
    }

    /**
     * 処理中フラグ（CD197）
     */
    public static class CD197 {
        /**
         * 通常
         */
        public static final String USUALLY = "0";
        /**
         * 処理中
         */
        public static final String BEING_PROCESSED = "1";
    }

    /**
     * 開閉フラグ（CD198）
     */
    public static class CD198 {
        /**
         * 閉
         */
        public static final String CLOSED = "0";
        /**
         * 開
         */
        public static final String OPEN = "1";
    }

    /**
     * 施錠制御出力状態（CD199）
     */
    public static class CD199 {
        /**
         * 親機からの施錠
         */
        public static final String LOCKING_FROM_A_BASE_UNIT = "0";
        /**
         * 子機の制御入力端子、ボタン、サムターンによる施解錠
         */
        public static final String SLAVE_UNIT_BUTTON_LOCKING_UNLOCKING_BY_THUMB_TURN = "1";
    }

    /**
     * 定時監視状態（CD200）
     */
    public static class CD200 {
        /**
         * 正常（予約なし）
         */
        public static final String NORMAL_WITHOUT_RESERVATION = "0";
        /**
         * 定時異常判断中
         */
        public static final String DURING_THE_FIXED_TIME_ABNORMAL_JUDGEMENT = "1";
        /**
         * 定時異常
         */
        public static final String THE_FIXED_TIME_ABNORMALITY = "2";
    }

    /**
     * 長期断線判断区分（CD201）
     */
    public static class CD201 {
        /**
         * 正常
         */
        public static final String NORMAL = "0";
        /**
         * 長期断線判断中
         */
        public static final String LONG_BREAKING_IS_JUDGED = "1";
        /**
         * 長期断線異常
         */
        public static final String LONG_BREAKING_ABNORMALITY = "2";
    }

    /**
     * 断線区分（CD202）
     */
    public static class CD202 {
        /**
         * 正常
         */
        public static final String NORMAL = "0";
        /**
         * 断線(VN-）
         */
        public static final String BREAKING_VN = "1";
        /**
         * 断線(VF-）
         */
        public static final String BREAKING_VF = "2";
    }

    /**
     * 宛先取得区分（CD203）
     */
    public static class CD203 {
        /**
         * アカウントテーブル
         */
        public static final String ACCOUNT_TABLE = "0";
        /**
         * ファイル
         */
        public static final String FILE = "1";
        /**
         * アカウントテーブルとファイル
         */
        public static final String ACCOUNT_TABLE_AND_FILE = "2";
    }

    /**
     * 空室在室状態フラグ（CD204）
     */
    public static class CD204 {
        /**
         * 空室
         */
        public static final String VACANT_ROOM = "0";
        /**
         * 在室
         */
        public static final String STAY_IN_THE_ROOM = "1";
    }

    /**
     * 使用状態（CD205）
     */
    public static class CD205 {
        /**
         * 未使用
         */
        public static final String UNUSED = "0";
        /**
         * 使用中
         */
        public static final String IN_USE = "1";
        /**
         * 切断通知送信
         */
        public static final String CUTOFF_NOTICE_TRANSMISSION = "2";
        /**
         * 切断通知送信済
         */
        public static final String CUTOFF_NOTIFICATION_IS_ALREADY_SENT = "3";
        /**
         * 切断通知失敗
         */
        public static final String CUTOFF_NOTICE_FAILURE = "4";
    }

    /**
     * 性別（CD206）
     */
    public static class CD206 {
        /**
         * 男
         */
        public static final String MAN = "0";
        /**
         * 女
         */
        public static final String WOMAN = "1";
    }

    /**
     * 割当条件（CD207）
     */
    public static class CD207 {
        /**
         * 変更予定
         */
        public static final String PLANNED_CHANGE_IN = "0";
        /**
         * 割当予定
         */
        public static final String SCHEDULED_ALLOCATION = "1";
        /**
         * 固定
         */
        public static final String FIXED = "2";
        /**
         * 契約割当
         */
        public static final String CONTRACT_ASSIGNMENT = "3";
    }

    /**
     * 暗号化方式（CD208）
     */
    public static class CD208 {
        /**
         * 平文
         */
        public static final String PLAINTEXT = "0";
        /**
         * VPN
         */
        public static final String VPN = "1";
        /**
         * SSL
         */
        public static final String SSL = "2";
    }

    /**
     * 実施フラグ（CD209）
     */
    public static class CD209 {
        /**
         * 未実施
         */
        public static final String UNACTED = "0";
        /**
         * 実施
         */
        public static final String IMPLEMENTATION = "1";
    }

    /**
     * 建物構造種別（CD210）
     */
    public static class CD210 {
        /**
         * 鉄筋コンクリート
         */
        public static final String FERROCONCRETE = "0";
        /**
         * 鉄骨鉄筋コンクリート
         */
        public static final String STEEL_FRAMED_REINFORCED_CONCRETE = "1";
        /**
         * 鉄骨
         */
        public static final String STEEL_FRAME = "2";
        /**
         * 木造
         */
        public static final String WOODEN = "3";
        /**
         * その他
         */
        public static final String OTHERS = "4";
    }

    /**
     * 緊急連絡先対象（CD211）
     */
    public static class CD211 {
        /**
         * 緊急連絡先対象外
         */
        public static final String URGENT_PHONE_NUMBER_APPLYING = "0";
        /**
         * 緊急連絡先対象
         */
        public static final String URGENT_PHONE_NUMBER_TARGET = "1";
    }

    /**
     * メール選択（CD212）
     */
    public static class CD212 {
        /**
         * 全てのメールを選択
         */
        public static final String ALL_MAILS_CHOSEN = "1";
        /**
         * 緊連通知
         */
        public static final String EMERGENCY_NOTIFICATION = "2";
        /**
         * 警備開始通知
         */
        public static final String SECURITY_INTIATION_NOTICE = "3";
        /**
         * 警備解除通知
         */
        public static final String SECURITY_RELEASE_NOTIFICATION = "4";
        /**
         * 警備セット忘れ通知
         */
        public static final String SECURITY_SET_FORGET_NOTIFICATION = "5";
        /**
         * 空室状態通知
         */
        public static final String VACANT_ROOM_CONDITIONAL_SIGNALING = "6";
        /**
         * イベント情報通知
         */
        public static final String EVENT_INFORMATION_NOTICE = "7";
        /**
         * 設備異常
         */
        public static final String EQUIPMENT_ABNORMALITY = "8";
        /**
         * 自動警備セット
         */
        public static final String AUTOMATIC_GUARD_SET = "9";
    }

    /**
     * 受信設定（CD213）
     */
    public static class CD213 {
        /**
         * -
         */
        public static final String KARI_1 = "0";
        /**
         * ○
         */
        public static final String KARI_2 = "1";
        /**
         * ◎
         */
        public static final String KARI_3 = "2";
        /**
         * ●
         */
        public static final String KARI_4 = "3";
    }

    /**
     * Webサイト区分（CD214）
     */
    public static class CD214 {
        /**
         * 利用者サイト PC
         */
        public static final String USER_SITE_PC = "0";
        /**
         * 利用者サイト スマホ
         */
        public static final String USER_SITE_SMART_PHONE = "1";
    }

    /**
     * 画像要求区分（CD215）
     */
    public static class CD215 {
        /**
         * 検知時画像取得要求
         */
        public static final String AT_THE_TIME_OF_MEASURE = "0";
        /**
         * 巡回画像取得要求
         */
        public static final String PATROL_PICTURE = "1";
        /**
         * 撮像要求
         */
        public static final String IMAGING_REQUEST = "2";
        /**
         * 顔認証登録削除要求
         */
        public static final String FACIAL_AUTHENTICATION_REGISTATION_ELMINATION = "3";
    }

    /**
     * 利用者アカウント区分（CD216）
     */
    public static class CD216 {
        /**
         * 代表メイン管理者
         */
        public static final String REPRESENTATIVE_MAIN_ADMINISTRATOR = "0";
        /**
         * メイン管理者
         */
        public static final String MAIN_ADMINISTRATOR = "1";
        /**
         * サブ管理者
         */
        public static final String SUB_ADMINISTRATOR = "2";
        /**
         * 利用者
         */
        public static final String THE_USER = "3";
    }

    /**
     * 通話状態（CD217）
     */
    public static class CD217 {
        /**
         * 通話中
         */
        public static final String CALLING = "1";
        /**
         * 一斉鳴動中
         */
        public static final String RUMBLING = "2";
    }

    /**
     * ライブ状態（CD218）
     */
    public static class CD218 {
        /**
         * 準備中
         */
        public static final String IN_PREPARATION = "0";
        /**
         * 配信中
         */
        public static final String DURING_DELIVERY = "1";
        /**
         * 権限付与中
         */
        public static final String AUTHORIZATION_IN_PROGRESS = "2";
    }

    /**
     * 視聴間隔（CD219）
     */
    public static class CD219 {
        /**
         * 8時間
         */
        public static final String HOURS_8 = "0";
        /**
         * 2時間
         */
        public static final String HOURS_2 = "1";
        /**
         * 10分
         */
        public static final String MINUTES_10 = "2";
        /**
         * 1分
         */
        public static final String MINUTE_1 = "3";
    }

    /**
     * 画像取得完了フラグ（CD220）
     */
    public static class CD220 {
        /**
         * 未完了
         */
        public static final String UNCOMPLETETE = "0";
        /**
         * 完了
         */
        public static final String COMPLETION = "1";
    }

    /**
     * メール種別（CD221）
     */
    public static class CD221 {
        /**
         * 警備開始
         */
        public static final String GUARD_STARTING = "01";
        /**
         * 警備解除
         */
        public static final String GUARD_RELEASE = "02";
        /**
         * 在宅ALSOK警備開始
         */
        public static final String ALSOK_GUARD_STARTING_AT_HOME = "03";
        /**
         * 在宅ALSOK警備解除
         */
        public static final String ALSOK_GUARD_RELEASE_AT_HOME = "04";
        /**
         * 警備ｾｯﾄ忘れ
         */
        public static final String GUARD_SET_FORGETTING = "05";
        /**
         * 空室状態
         */
        public static final String THE_VACANT_ROOM_STATE = "06";
        /**
         * 警報発生
         */
        public static final String WARNING_OCCURRENCE = "07";
        /**
         * イベント発生
         */
        public static final String EVENT_OCCURRENCE = "08";
        /**
         * 画像蓄積情報（SD保存開始）
         */
        public static final String SD_PRESERVATION_STARTING = "11";
        /**
         * 画像蓄積情報（ニアフル）
         */
        public static final String NEAR_FULL = "12";
        /**
         * 画像蓄積情報（フル）
         */
        public static final String FULL = "13";
        /**
         * 画像蓄積情報（SD保存終了）
         */
        public static final String SD_PRESERVATION_END = "14";
        /**
         * 重要犯罪者情報（発生通知）
         */
        public static final String CRIMINAL_OCCURRENCE_NOTICE = "15";
        /**
         * 登録人物情報（発生通知）
         */
        public static final String CHARACTER_OCCURRENCE_NOTICE = "16";
        /**
         * 登録人物情報（設定変更連絡）
         */
        public static final String SETTING_CHANGE_CONTACT = "30";
        /**
         * 画像巡回結果（正常）
         */
        public static final String NORMALITY = "31";
        /**
         * 画像巡回結果（異常）
         */
        public static final String ABNORMALITY = "32";
        /**
         * ｱｶｳﾝﾄ仮登録（本登録依頼）通知
         */
        public static final String REGISTRATION_REQUEST_NOTICE = "50";
        /**
         * ｱｶｳﾝﾄ本登録完了通知
         */
        public static final String ACCOUNT_REGISTRATION_COMPLETION_NOTIFICATION = "51";
        /**
         * ｱｶｳﾝﾄ（ﾒｰﾙｱﾄﾞﾚｽ）変更通知
         */
        public static final String ACCOUNT_MAIL_ADDRESS_CHANGE_NOTICE = "52";
        /**
         * 設定変更内容通知
         */
        public static final String THE_SETTING_CHANGE_NOTICE_OF_CONTENTS = "53";
        /**
         * ﾊﾟｽﾜｰﾄﾞ変更通知
         */
        public static final String PASSWORD_CHANGE_NOTICE = "54";
        /**
         * ﾊﾟｽﾜｰﾄﾞ再登録通知
         */
        public static final String PASSWORD_RE_REGISTRATION_NOTICE = "55";
        /**
         * ALSOKからのお知らせ
         */
        public static final String NEWS_FROM_ALSOK = "70";
    }

    /**
     * バウンス状態（CD222）
     */
    public static class CD222 {
        /**
         * 受信なし
         */
        public static final String WITHOUT_RECEPTION = "0";
        /**
         * 受信あり
         */
        public static final String WITH_RECEPTION = "1";
        /**
         * バウンス
         */
        public static final String BOUNCE = "9";
    }

    /**
     * 変更理由（CD223）
     */
    public static class CD223 {
        /**
         * お客様登録操作
         */
        public static final String CUSTOMER_REGISTATION_OPERATION = "01";
        /**
         * お客様削除操作
         */
        public static final String CUSTMER_ELIMINATION_OPERATION = "02";
        /**
         * 認証期限超過
         */
        public static final String AUTHENTICATION_TIME_LIMIT_EXCESS = "03";
    }

    /**
     * 指定有無フラグ（CD226）
     */
    public static class CD226 {
        /**
         * 指定なし
         */
        public static final String NOT_SPECIFIED = "0";
        /**
         * 指定あり
         */
        public static final String SPECIFIED = "1";
    }

    /**
     * 装置種類（CD227）
     */
    public static class CD227 {
        /**
         * 警備ユニット
         */
        public static final String DEV_KU = "00";
        /**
         * 画像ユニット
         */
        public static final String DEV_CU = "01";
        /**
         * テナント装置
         */
        public static final String DEV_TU = "02";
        /**
         * 遠隔操作器
         */
        public static final String DEV_RC = "03";
        /**
         * 画像センサー
         */
        public static final String DEV_GS = "04";
        /**
         * カメラ
         */
        public static final String DEV_CM = "05";
    }

    /**
     * 画像取得状態（CD228）
     */
    public static class CD228 {
        /**
         * 未取得
         */
        public static final String UNACQUIRED = "0";
        /**
         * 取得成功
         */
        public static final String SUCCESS = "1";
        /**
         * 取得失敗
         */
        public static final String FAILURE = "2";
    }

    /**
     * 警報名称コード（CD229）
     */
    public static class CD229 {
        /**
         * 防犯・施錠
         */
        public static final String CRIME_LOCKING = "1";
        /**
         * 非常
         */
        public static final String EXTREME = "2";
        /**
         * 設備
         */
        public static final String EQUIPMENT = "3";
        /**
         * ホールドアップ警報
         */
        public static final String HOLDUP_WARNING = "4";
        /**
         * 火災
         */
        public static final String FIRE = "5";
        /**
         * ガス
         */
        public static final String GAS = "6";
    }

    /**
     * 操作方法コード（CD230）
     */
    public static class CD230 {
        /**
         * リモートコントロール
         */
        public static final String REMOTE_CONTROL = "1";
        /**
         * リーダー（カード操作）
         */
        public static final String READER_CARD = "2";
        /**
         * リーダー（テンキー操作）
         */
        public static final String READER_TENKEY = "3";
        /**
         * 鍵式操作
         */
        public static final String KEY_OPERATION = "4";
        /**
         * タブレット操作
         */
        public static final String TABLET_OPERATION = "5";
        /**
         * スケジュール
         */
        public static final String SCHEDULE = "6";
    }

    /**
     * 変更理由コード（CD231）
     */
    public static class CD231 {
        /**
         * 画像登録
         */
        public static final String PIC_REG = "1";
        /**
         * 画像削除（手動削除）
         */
        public static final String PIC_DEL_MANUAL = "2";
        /**
         * 画像削除（システムによる削除）
         */
        public static final String PIC_DEL_SYSTEM = "3";
    }

    /**
     * 登録人物顔画像送信結果コード（CD232）
     */
    public static class CD232 {
        /**
         * 成功
         */
        public static final String SUCCESS = "0";
        /**
         * 失敗
         */
        public static final String FAILURE = "9";
    }

    /**
     * メール送信状態（CD233）
     */
    public static class CD233 {
        /**
         * 送信待ち
         */
        public static final String SEND_WAIT = "0";
        /**
         * 送信予約
         */
        public static final String SEND_RESERVE = "1";
        /**
         * 送信中
         */
        public static final String SENDING = "2";
        /**
         * 送信済
         */
        public static final String SENT = "3";
    }

    /**
     * 実行状態（CD234）
     */
    public static class CD234 {
        /**
         * 未処理
         */
        public static final String NON_PROCESSING = "0";
        /**
         * 処理中
         */
        public static final String PROCESSING = "1";
    }

    /**
     * DN0DF0状態フラグ（CD235）
     */
    public static class CD235 {
        /**
         * DN0
         */
        public static final String DN0 = "N";
        /**
         * DF0
         */
        public static final String DF0 = "F";
    }

    /**
     * マイク・インターホン連動フラグ（CD236）
     */
    public static class CD236 {
        /**
         * 連携なし
         */
        public static final String NONE = "0";
        /**
         * 連携あり
         */
        public static final String EXITST = "1";
        /**
         * 連携あり（画像・音声一体）
         */
        public static final String COMBINED = "2";
    }

    /**
     * GC範囲フラグ（CD237）
     */
    public static class CD237 {
        /**
         * 全ＧＣ
         */
        public static final String ALL_GC = "1";
        /**
         * プロパーＧＣ
         */
        public static final String PROPER_GC = "2";
        /**
         * 自ＧＣ
         */
        public static final String OWN_GC = "3";
        /**
         * 事業所
         */
        public static final String OWN_OFFICE = "4";
        /**
         * 隊員
         */
        public static final String MEMBER = "5";
    }

    /**
     * 言語種別（CD238）
     */
    public static class CD238 {
        /**
         * 日本語
         */
        public static final String JAPANESE = "J";
        /**
         * 英語
         */
        public static final String ENGLISH = "E";
        /**
         * 中国語
         */
        public static final String CHINESE = "C";
    }

    /**
     * 事案表示先フラグ（CD239）
     */
    public static class CD239 {
        /**
         * 監視CL
         */
        public static final String WATCH_CL = "0";
        /**
         * RMCL
         */
        public static final String MONITOR_CL = "1";
        /**
         * 操作不可
         */
        public static final String NO_OPERATION = "9";
    }

    /**
     * 復旧信号区分（CD240）
     */
    public static class CD240 {
        /**
         * 通常信号
         */
        public static final String NORMAL = "1";
        /**
         * 全停電警報復旧信号
         */
        public static final String BLACKOUT_AND_POWER_RECOVERY = "2";
        /**
         * 全復旧信号
         */
        public static final String THE_WHOLE_RESTORATION = "3";
    }

    /**
     * 事態コード（CD241）
     */
    public static class CD241 {
        /**
         * 発生
         */
        public static final String OCCURRENCE = "00";
        /**
         * 要請
         */
        public static final String REQUEST = "01";
        /**
         * 終了
         */
        public static final String END = "03";
    }

    /**
     * 担当応援区分（CD242）
     */
    public static class CD242 {
        /**
         * 担当
         */
        public static final String RESPONSIBLE = "0";
        /**
         * 応援
         */
        public static final String CHEER = "1";
    }

    /**
     * 西暦和暦情報（CD243）
     */
    public static class CD243 {
        /**
         * 西暦
         */
        public static final String THE_CHRISTIAN_ERA = "0";
    }

    /**
     * 和暦略号情報（CD244）
     */
    public static class CD244 {
        /**
         * M
         */
        public static final String MEIJI = "1";
        /**
         * T
         */
        public static final String TAISHO = "2";
        /**
         * S
         */
        public static final String SHOWA = "3";
        /**
         * H
         */
        public static final String HEISEI = "4";
    }  
    
    /**
     * アカウント種別_メール送信用（CD248）
     */
    public static class CD248 {
        /**
         * 次期警備システム
         */
        public static final String THE_NEXT_TERM_GUARD_SYSTEM = "0";
        /**
         * GHS(利用者)
         */
        public static final String GHS_THE_USER = "1";
        /**
         * GHS(契約先)
         */
        public static final String GHS_CONTRACT_DESTINATION = "2";
        /**
         * GHS(見守り)
         */
        public static final String GHS_MIMAMORI = "3";
        /**
         * GⅤ(契約先)
         */
        public static final String GV_CONTRACT_DESTINATION = "4";
        /**
         * GⅤ(HS)
         */
        public static final String GV_HS_USER = "5";
    }
    
	/**
	 * サービス種別コード（CD259）
	 */
	public static class CD259 {
		/**
		 * S-860
		 */
		public static final String S_860_GS = "0";
		/**
		 * S-728
		 */
		public static final String S_728_HS = "1";
		/**
		 * S-860M
		 */
		public static final String S_860M_GSM = "2";
		/**
		 * S-861
		 */
		public static final String S_861_G6 = "3";
		/**
		 * CU-861
		 */
		public static final String CU_861_G6 = "4";
	}

	/**
	 * 監視条件設定回日程（CD260）
	 */
	public static class CD260 {
		/**
		 * 監視なし
		 */
		public static final String NO_MONITORING = "0";
		/**
		 * 監視あり
		 */
		public static final String WITH_MONITORING = "1";
	}

	/**
	 * VPN接続情報予約状況区分（CD261）
	 */
	public static class CD261 {
		/**
		 * 予約なし
		 */
		public static final String NO_RESERVATION = "0";
		/**
		 * 予約中
		 */
		public static final String IN_RESERVATION = "1";
	}

	/**
	 * VPN接続情報使用状況区分（CD262）
	 */
	public static class CD262 {
		/**
		 * 全て
		 */
		public static final String ALL_USE = "0";
		/**
		 * 未使用
		 */
		public static final String NO_USE = "1";
		/**
		 * 使用中
		 */
		public static final String IN_USE = "2";
	}

	/**
	 * 地区表示(GⅤ)（CD400）
	 */
	public static class CD400 {
		/**
		 * 技術入館のみ地区非表示
		 */
		public static final String TECH_AD_ONLY = "0";
		/**
		 * 地区表示すべて
		 */
		public static final String CHIKU_ALL = "1";
		/**
		 * 地区非表示
		 */
		public static final String CHIKU_HIDE = "2";
	}

	/**
	 * 電話番号種別(GⅤ)（CD401）
	 */
	public static class CD401 {
		/**
		 * 外線
		 */
		public static final String OUTSIDE_LINE = "0";
		/**
		 * 内線
		 */
		public static final String INSIDE_LINE = "1";
		/**
		 * 携帯
		 */
		public static final String MOBILE = "2";
		/**
		 * PHS
		 */
		public static final String PHS = "3";
	}

	/**
	 * 処置結果(GⅤ)（CD402）
	 */
	public static class CD402 {
		/**
		 * 未処置
		 */
		public static final String UNTREATED = "0";
		/**
		 * 完了
		 */
		public static final String COMPLETE = "1";
	}

	/**
	 * 電子メモ種類(GⅤ)（CD403）
	 */
	public static class CD403 {
		/**
		 * 全体
		 */
		public static final String OVER_ALL = "0";
		/**
		 * 残業連絡
		 */
		public static final String OVERTIME_CONTACT = "1";
		/**
		 * 宿泊連絡
		 */
		public static final String STAY_CONTACT = "2";
		/**
		 * 工事点検
		 */
		public static final String CONSTRACT_INSP = "3";
		/**
		 * 鍵立会い
		 */
		public static final String KEY_WITNESS = "4";
		/**
		 * 再入館
		 */
		public static final String RE_ENTRY = "5";
		/**
		 * 臨時緊連
		 */
		public static final String TEMP_EMER_CONTACT = "6";
		/**
		 * 短絡連絡
		 */
		public static final String SHORT_CONTACT = "7";
		/**
		 * 保守連絡
		 */
		public static final String MAINTENANCE_CONTACT = "8";
		/**
		 * その他
		 */
		public static final String OTHER = "9";
		/**
		 * 臨時警備
		 */
		public static final String EX_SEC = "A";
	}

	/**
	 * 表示切替(GⅤ)（CD404）
	 */
	public static class CD404 {
		/**
		 * 地区表示
		 */
		public static final String CHIKU_DISP = "0";
		/**
		 * 地区非表示
		 */
		public static final String CHIKU_HIDE = "1";
	}

	/**
	 * 運用状態(GⅤ)（CD405）
	 */
	public static class CD405 {
		/**
		 * 未開始
		 */
		public static final String NOT_STARTED = "0";
		/**
		 * 警備中
		 */
		public static final String UNDER_SECURITY = "1";
		/**
		 * 中断中
		 */
		public static final String SUSPENDED = "2";
		/**
		 * 解約
		 */
		public static final String CANCELLATION = "3";
	}

	/**
	 * 処理区分(GⅤ)（CD406）
	 */
	public static class CD406 {
		/**
		 * 全体
		 */
		public static final String OVER_ALL = "0";
		/**
		 * 落着
		 */
		public static final String CALM = "1";
		/**
		 * 取消
		 */
		public static final String CANCEL = "2";
	}

	/**
	 * 通報先1(GⅤ)（CD407）
	 */
	public static class CD407 {
		/**
		 * １１０
		 */
		public static final String POLICE_PHONE_NUM = "0";
		/**
		 * 所轄署
		 */
		public static final String AFFILIATED_DEPARTMENT = "1";
	}

	/**
	 * 通報先2(GⅤ)（CD408）
	 */
	public static class CD408 {
		/**
		 * １１９
		 */
		public static final String AMBULANCE_PHONE_NUM = "0";
		/**
		 * 所轄署
		 */
		public static final String AFFILIATED_DEPARTMENT = "1";
	}

	/**
	 * 通報区分1(GⅤ)（CD409）
	 */
	public static class CD409 {
		/**
		 * 警察
		 */
		public static final String POLICE = "0";
	}

	/**
	 * 通報区分2(GⅤ)（CD410）
	 */
	public static class CD410 {
		/**
		 * 火災
		 */
		public static final String FIRE = "0";
		/**
		 * 救急
		 */
		public static final String EMERGENCY = "1";
	}

	/**
	 * 真報判断フラグ(GⅤ)（CD411）
	 */
	public static class CD411 {
		/**
		 * 真報
		 */
		public static final String TRUE_REPORT = "0";
		/**
		 * 誤報
		 */
		public static final String FALSE_REPORT = "1";
	}

	/**
	 * 担当応援区分(GⅤ)（CD412）
	 */
	public static class CD412 {
		/**
		 * 担当
		 */
		public static final String IN_CHARGE = "0";
		/**
		 * 応援
		 */
		public static final String SUPPORT = "1";
	}

	/**
	 * 隊員種別(GⅤ)（CD413）
	 */
	public static class CD413 {
		/**
		 * 機動
		 */
		public static final String MOBILE = "0";
		/**
		 * 技術
		 */
		public static final String ENGINEER = "1";
	}

	/**
	 * キーレス許可隊員種別(GⅤ)（CD414）
	 */
	public static class CD414 {
		/**
		 * 機警
		 */
		public static final String MACHINE_WARNING = "0";
		/**
		 * 技術
		 */
		public static final String ENGINEER = "1";
	}

	/**
	 * 出動区分(GⅤ)（CD415）
	 */
	public static class CD415 {
		/**
		 * SGS
		 */
		public static final String SYUTSUDOU_SGS = "1";
	}

	/**
	 * 通報有無区分(GⅤ)（CD416）
	 */
	public static class CD416 {
		/**
		 * 無
		 */
		public static final String NONE = "0";
		/**
		 * 有
		 */
		public static final String EXIST = "1";
	}

	/**
	 * 警備状態(GⅤ)（CD417）
	 */
	public static class CD417 {
		/**
		 * F0
		 */
		public static final String F0 = "F";
		/**
		 * 帰宅待ち（在宅セルフ）
		 */
		public static final String HOME_SELF = "I";
		/**
		 * 帰宅待ち（在宅ALSOK）
		 */
		public static final String HOME_ALSOK = "J";
		/**
		 * N0L
		 */
		public static final String N0L = "K";
		/**
		 * N0S
		 */
		public static final String N0S = "L";
		/**
		 * ZN0
		 */
		public static final String ZN0 = "M";
		/**
		 * N0
		 */
		public static final String N0 = "N";
		/**
		 * 点検中
		 */
		public static final String INSPECTION = "P";
	}

	/**
	 * 警備操作(GⅤ)（CD418）
	 */
	public static class CD418 {
		/**
		 * N0L：帰宅待ち（在宅セルフ）終了
		 */
		public static final String N0L = "A";
		/**
		 * ZN0：帰宅待ち（在宅ALSOK）終了
		 */
		public static final String ZN0 = "B";
		/**
		 * F0L：在宅セルフ解除
		 */
		public static final String F0L = "C";
		/**
		 * F0S：外出セルフ解除
		 */
		public static final String F0S = "D";
		/**
		 * ZF0：在宅ALSOK解除
		 */
		public static final String ZF0 = "E";
		/**
		 * F0：外出ALSOK解除
		 */
		public static final String F0 = "F";
		/**
		 * N0L：帰宅待ち（在宅セルフ）開始
		 */
		public static final String N0L_2 = "I";
		/**
		 * N0L：エリア変更
		 */
		public static final String N0L_3 = "I2";
		/**
		 * ZN0：帰宅待ち（在宅ALSOK）開始
		 */
		public static final String ZN0_2 = "J";
		/**
		 * ZN0：エリア変更
		 */
		public static final String ZN0_3 = "J2";
		/**
		 * N0L：在宅セルフ開始
		 */
		public static final String N0L_4 = "K";
		/**
		 * N0L：エリア変更
		 */
		public static final String N0L_5 = "K2";
		/**
		 * N0S：外出セルフ開始
		 */
		public static final String N0S = "L";
		/**
		 * ZN0：在宅ALSOK開始
		 */
		public static final String ZN0_4 = "M";
		/**
		 * ZN0：エリア変更
		 */
		public static final String ZN0_5 = "M2";
		/**
		 * N0：外出ALSOK開始
		 */
		public static final String N0 = "N";
	}

	/**
	 * 警備エリア状態(GⅤ)（CD419）
	 */
	public static class CD419 {
		/**
		 * F0：解除
		 */
		public static final String F0 = "F";
		/**
		 * N0L：帰宅待ち（在宅セルフ）
		 */
		public static final String N0L = "I";
		/**
		 * ZN0：帰宅待ち（在宅ALSOK）
		 */
		public static final String ZN0 = "J";
		/**
		 * N0L：在宅セルフ
		 */
		public static final String N0L_2 = "K";
		/**
		 * N0S：外出セルフ
		 */
		public static final String N0S = "L";
		/**
		 * ZN0：在宅ALSOK
		 */
		public static final String ZN0_2 = "M";
	}

	/**
	 * 機器種別ID(GⅤ)（CD420）
	 */
	public static class CD420 {
		/**
		 * GⅤ
		 */
		public static final String GⅤ = "100";
		/**
		 * テナント
		 */
		public static final String TENNANT = "104";
		/**
		 * Pegasus
		 */
		public static final String PEGASUS = "500";
	}

	/**
	 * ファイル種別-GⅤ(GⅤ)（CD421）
	 */
	public static class CD421 {
		/**
		 * 機器情報
		 */
		public static final String EQUIPMENT_INFO = "00";
		/**
		 * 制御装置Ｆ/Ｗ
		 */
		public static final String CTRL_FW = "01";
		/**
		 * 制御装置ＳＤ
		 */
		public static final String CTRL_SD = "02";
		/**
		 * 制御装置カレンダー
		 */
		public static final String CTRL_DEV_CAL = "04";
		/**
		 * 制御装置サーバ証明書
		 */
		public static final String CTRL_SV_CERTIFICATE = "05";
		/**
		 * 周辺機器Ｆ/Ｗ
		 */
		public static final String PERIPHERAL_DEV_FW = "11";
		/**
		 * 周辺機器ＳＤ
		 */
		public static final String PERIPHERAL_DEV_SD = "12";
		/**
		 * 周辺機器カレンダー
		 */
		public static final String PERIPHERAL_CAL = "14";
		/**
		 * 周辺機器サーバ証明書
		 */
		public static final String PERIPHERAL_SV_CERTIFICATE = "15";
		/**
		 * 周辺機器基準画像
		 */
		public static final String PERIPHERAL_DEV_REF_IMG = "17";
		/**
		 * システム履歴
		 */
		public static final String SYS_HISTORY = "20";
		/**
		 * センサー動作履歴
		 */
		public static final String SENSOR_OPERATION_HISTORY = "21";
		/**
		 * 警備履歴
		 */
		public static final String SECURITY_HISTORY = "22";
		/**
		 * 出入管理履歴
		 */
		public static final String ACCESS_CTRL_HISTORY = "23";
		/**
		 * 出退勤履歴
		 */
		public static final String ATTENDANCE_RECORD = "24";
		/**
		 * 計測、モニタリング履歴
		 */
		public static final String MEASUREMENT_MONITORING_HISTORY = "25";
		/**
		 * タスクログ
		 */
		public static final String TASK_LOG = "26";
		/**
		 * 通信ログ
		 */
		public static final String COMMUNICATION_LOG = "27";
		/**
		 * Webアクセス履歴
		 */
		public static final String WEB_ACCESS_HISTORY = "28";
		/**
		 * メール送信履歴
		 */
		public static final String MAIL_TRANSMISSION_HISTORY = "29";
	}

	/**
	 * ファイル種別-テナント(GⅤ)（CD422）
	 */
	public static class CD422 {
		/**
		 * 制御装置ＳＤ
		 */
		public static final String CTRL_SD = "02";
		/**
		 * 周辺機器ＳＤ
		 */
		public static final String PERIPHERAL_DEV_SD = "12";
		/**
		 * 周辺機器基準画像
		 */
		public static final String PERIPHERAL_DEV_REF_IMG = "17";
		/**
		 * システム履歴
		 */
		public static final String SYS_HISTORY = "20";
	}

	/**
	 * ファイル種別-Pegasus(GⅤ)（CD423）
	 */
	public static class CD423 {
		/**
		 * 制御装置ＳＤ
		 */
		public static final String CTRL_SD = "02";
		/**
		 * 履歴
		 */
		public static final String HISTORY = "30";
	}

	/**
	 * センサー状態(GⅤ)（CD424）
	 */
	public static class CD424 {
		/**
		 * 正常
		 */
		public static final String NORMAL = "00";
		/**
		 * 異常
		 */
		public static final String FAULT = "01";
		/**
		 * センサー監視異常
		 */
		public static final String SENSOR_MONITORING_ERROR = "02";
		/**
		 * 機器故障
		 */
		public static final String EQUIPMENT_FAILURE = "03";
		/**
		 * 断線
		 */
		public static final String DISCONNECTION = "04";
		/**
		 * 電池劣化
		 */
		public static final String BATTERY_DETERIORATION = "05";
		/**
		 * 停電・復電
		 */
		public static final String POWER_OUTAGE_RECOVERY = "06";
		/**
		 * 過負荷
		 */
		public static final String OVERLOAD = "07";
		/**
		 * 電池電圧低下
		 */
		public static final String LOW_BATTERY_VOLTAGE = "08";
		/**
		 * ヒューズ切れ
		 */
		public static final String FUSE_BLOWN = "09";
		/**
		 * 外部電池接続
		 */
		public static final String EXTERNAL_BATTERY_CONNECTION = "10";
		/**
		 * 新伝送短絡異常
		 */
		public static final String NEW_TRANSMISSION_SHORT_CIRCUIT_FAULT = "11";
		/**
		 * 新伝送加電圧異常
		 */
		public static final String NEW_TRANSMISSION_APPLIED_VOLTAGE_ABNORMALITY = "12";
		/**
		 * 入力電圧低下
		 */
		public static final String INPUT_VOLTAGE_DROP = "13";
		/**
		 * 通信異常
		 */
		public static final String COMMUNICATION_ERROR = "14";
		/**
		 * 環境異常
		 */
		public static final String ENVIRONMENTAL_ABNORMALITY = "15";
		/**
		 * 位置異常
		 */
		public static final String POSITION_ERROR = "16";
		/**
		 * 施錠異常
		 */
		public static final String LOCKING_ABNORMALITY = "17";
		/**
		 * 解錠異常
		 */
		public static final String UNLOCKING_FAULT = "18";
		/**
		 * 開扉異常
		 */
		public static final String OPEN_DOOR_ABNORMALITY = "19";
		/**
		 * 脱落異常
		 */
		public static final String ABNORMAL_DROPOUT = "20";
		/**
		 * ダンパー異常（破壊）
		 */
		public static final String DAMPER_ABNORMALITY_DESTRUCTION = "21";
		/**
		 * アドレス重複
		 */
		public static final String ADDRESS_DUPLICATION = "22";
		/**
		 * ＬＥＤ寿命
		 */
		public static final String LED_LIFE = "23";
		/**
		 * 妨害
		 */
		public static final String DISTURBANCE = "24";
		/**
		 * こじ開け
		 */
		public static final String BREAKING_OPEN = "25";
		/**
		 * 停電入力
		 */
		public static final String POWER_OUTAGE_INPUT = "26";
		/**
		 * ライフ異常
		 */
		public static final String LIFE_ABNORMALITY = "27";
	}

	/**
	 * 契約別表示色（CD425）
	 */
	public static class CD425 {
		/**
		 * GS
		 */
		public static final String GS = "0";
		/**
		 * VSS(欠番)
		 */
		public static final String VSS_THE_MISSING_NUMBER = "1";
		/**
		 * HS
		 */
		public static final String HS = "2";
		/**
		 * テナント
		 */
		public static final String TENANT = "3";
		/**
		 * アマンド
		 */
		public static final String ALMONDS = "4";
	}

	/**
	 * メール正常通知原因（CD426）
	 */
	public static class CD426 {
		/**
		 * メール正常通知原因1
		 */
		public static final String MAIL_NORMAL_NOTIFY_CAUSE_1 = "000";
		/**
		 * メール正常通知原因2
		 */
		public static final String MAIL_NORMAL_NOTIFY_CAUSE_2 = "001";
	}

	/**
	 * メール異常通知原因（CD427）
	 */
	public static class CD427 {
		/**
		 * メール異常通知原因1
		 */
		public static final String MAIL_ABNORMAL_NOTIFY_CAUSE_1 = "500";
		/**
		 * メール異常通知原因2
		 */
		public static final String MAIL_ABNORMAL_NOTIFY_CAUSE_2 = "501";
	}

	/**
	 * 画像C事態（CD428）
	 */
	public static class CD428 {
		/**
		 * 発生
		 */
		public static final String OCCURRENCE = "00";
		/**
		 * 要請
		 */
		public static final String REQUEST = "01";
		/**
		 * 原因
		 */
		public static final String REASON = "02";
		/**
		 * 終了
		 */
		public static final String END = "03";
	}

	/**
	 * GC事態（CD429）
	 */
	public static class CD429 {
		/**
		 * 発生
		 */
		public static final String OCCURRENCE = "1";
		/**
		 * 指示
		 */
		public static final String DIRECTIONS = "2";
		/**
		 * 直行
		 */
		public static final String GO_STRAIGHT = "3";
		/**
		 * 現着
		 */
		public static final String LOCAL_ARRIVALS = "6";
		/**
		 * 入館
		 */
		public static final String ENTRY = "7";
		/**
		 * 退館
		 */
		public static final String LEAVE = "8";
		/**
		 * 原因
		 */
		public static final String REASON = "9";
		/**
		 * 終了
		 */
		public static final String END = "A";
		/**
		 * 取消
		 */
		public static final String CANCEL = "B";
		/**
		 * 一終
		 */
		public static final String ONCE_END = "C";
		/**
		 * 一消
		 */
		public static final String ONCE_CANCEL = "D";
	}

	/**
	 * 定時監視実施対象（CD430）
	 */
	public static class CD430 {
		/**
		 * 実施しない
		 */
		public static final String NOT_IMPLEMENTED = "0";
		/**
		 * N0のみ実施
		 */
		public static final String IMPLEMENTED_1 = "1";
		/**
		 * N0以外実施
		 */
		public static final String IMPLEMENTED_2 = "2";
		/**
		 * すべて実施
		 */
		public static final String IMPLEMENTED_ALL = "3";
	}

	/**
	 * 担当応援区分（CD431）
	 */
	public static class CD431 {
		/**
		 * 担当
		 */
		public static final String IN_CHARGE = "0";
		/**
		 * 応援
		 */
		public static final String SUPPORT = "1";
	}

	/**
	 * SDモード番号（CD432）
	 */
	public static class CD432 {
	}

	/**
	 * 開閉店状況（CD433）
	 */
	public static class CD433 {
	}

	/**
	 * 解像度（CD434）
	 */
	public static class CD434 {
		/**
		 * HD
		 */
		public static final String HD = "1";

		/**
		 * FullHD
		 */
		public static final String FullHD = "2";
		/**
		 * VGA
		 */
		public static final String VGA = "3";
	}

	/**
	 * 保持期間（日）（CD435）
	 */
	public static class CD435 {
		/**
		 * 7日間
		 */
		public static final String DAYS_7 = "7";
		/**
		 * 14日間
		 */
		public static final String DAYS_14 = "14";
		/**
		 * 30日間
		 */
		public static final String DAYS_30 = "30";
		/**
		 * 90日間
		 */
		public static final String DAYS_90 = "90";
	}

	/**
	 * 元号情報（CD436）
	 */
	public static class CD436 {
		/**
		 * 西暦
		 */
		public static final String THE_CHRISTIAN_ERA = "G";

		/**
		 * 明治
		 */
		public static final String MEIJI = "M";
		/**
		 * 大正
		 */
		public static final String TAISHO = "T";
		/**
		 * 昭和
		 */
		public static final String SHOWA = "S";
		/**
		 * 平成
		 */
		public static final String HEISEI = "H";
	}

	/**
	 * 多重配信サービス種別（CD437）
	 */
	public static class CD437 {
		/**
		 * 設備情報メール／おしらせネット
		 */
		public static final String MALE_INFONET = "01";
		/**
		 * ALSOK-MITS
		 */
		public static final String ALSOK_M = "02";
		/**
		 * Web入退館
		 */
		public static final String WEB = "03";
		/**
		 * 契約先(逆NET警備)①
		 */
		public static final String NET_1 = "04";
		/**
		 * 契約先(逆NET警備)②
		 */
		public static final String NET_2 = "05";
	}

	/**
	 * グループ操作権限（CD438）
	 */
	public static class CD438 {
		/**
		 * 事業所
		 */
		public static final String OFFICE = "01";
	}
}
