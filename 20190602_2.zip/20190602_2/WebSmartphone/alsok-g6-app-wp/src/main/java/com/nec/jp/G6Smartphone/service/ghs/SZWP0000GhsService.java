package com.nec.jp.G6Smartphone.service.ghs;

import java.util.Date;
import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.KiyLoginInfoModel;
import com.nec.jp.G6Smartphone.SO.LiyGSLoginInfoModel;
import com.nec.jp.G6Smartphone.SO.RKeibiDataModel;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP0000GhsDao;
import com.nec.jp.G6Smartphone.model.WQueAcMlTrigModel;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP0000GhsService {
    @Autowired
    private SZWP0000GhsDao sZWP0000GhsDao;
    public KiyLoginInfoModel getKiyLoginInfo(String loginId, Date updateTs) throws ApplicationException {
        try {
            KiyLoginInfoModel kiyLoginInfoModel = sZWP0000GhsDao.getKiyLoginInfo(loginId, updateTs);

            return kiyLoginInfoModel;

        } catch (NoResultException noResultE) {
            return null;

        } catch (Exception e) {
            // DBアクセス例外
            String exceptionMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    exceptionMsg);
        }
    }
    public LiyGSLoginInfoModel getLiyGSLoginInfo(String loginId, Date updateTs, String gshsType)
            throws ApplicationException {
        try {
            LiyGSLoginInfoModel liyGSLoginInfoModel = sZWP0000GhsDao.getLiyGSLoginInfo(loginId, updateTs, gshsType);

            return liyGSLoginInfoModel;

        } catch (NoResultException noResultE) {
            return null;

        } catch (Exception e) {
            // DBアクセス例外
            String exceptionMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    exceptionMsg);
        }
    }
    public Integer getKiyLoginFailureTimes(String lnAcntUser) throws ApplicationException {
        try {
            return Integer.valueOf(sZWP0000GhsDao.getKiyLoginFailureTimes(lnAcntUser));

        } catch (NoResultException noResultE) {
            return -1;

        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }

    public Boolean updateKiyLoginFailureTimes(String lnAcntUserCommon, String acntNm, String failureTimes,
            String loginSts, Date loginTs) throws ApplicationException {
        try {
            return sZWP0000GhsDao.updateKiyLoginFailureTimes(lnAcntUserCommon, acntNm, failureTimes, loginSts, loginTs);
        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }
    public Boolean updateKiyPasswordLock(String userCommon, String updateNm, String loginSts, String rgstSts,
            String mlSendSts) throws ApplicationException {
        try {
            return sZWP0000GhsDao.updateKiyPasswordLock(userCommon, updateNm, loginSts, rgstSts, mlSendSts);
        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }
    public void insertMailTrig(WQueAcMlTrigModel entity) throws ApplicationException {
        try {
            sZWP0000GhsDao.insertMailTrig(entity);
        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }
    
    public List<RKeibiDataModel> getSecurityNameKeiyk(String lnAcntKeiyk, String keibiName) throws ApplicationException {
        try {
            List<RKeibiDataModel> rKeibiDataModelList = sZWP0000GhsDao.getSecurityNameKeiyk(lnAcntKeiyk, keibiName);

            return rKeibiDataModelList;

        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }

    public RKeibiDataModel getSecurityNameLiy(String lnAcntKeiyk, String keibiName) throws ApplicationException {
        try {
            RKeibiDataModel rKeibiDataModel = sZWP0000GhsDao.getSecurityNameLiy(lnAcntKeiyk, keibiName);

            return rKeibiDataModel;

		} catch (NoResultException noResultException) {
			return null;
			
        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }
    
    /**
     * get status login error from C_USER_LOGIN_STS
     * 
     * @param lnAcntUser
     * @return
     * @throws ApplicationException
     */
    public Integer getLiyGSLoginFailureTimes(String lnAcntUser) throws ApplicationException {
        try {
            return Integer.valueOf(sZWP0000GhsDao.getLiyGSLoginFailureTimes(lnAcntUser));

        } catch (NoResultException noResultE) {
            return -1;

        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }

    /**
     * update times login failure in C_USER_LOGIN_STS
     * 
     * @param lnAcntUserCommon
     * @param acntNm
     * @param failureTimes
     * @param loginSts
     * @return
     * @throws ApplicationException
     */
    public Boolean updateLiyGSLoginFailureTimes(String lnAcntUserCommon, String acntNm, String failureTimes,
            String loginSts, Date updateTs) throws ApplicationException {
        try {
            return sZWP0000GhsDao.updateLiyGSLoginFailureTimes(lnAcntUserCommon, acntNm, failureTimes, loginSts, updateTs);
        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }

    /**
     * Update lock password in R_ACNT_USER
     * 
     * @param userCommon
     * @param updateNm
     * @param loginSts
     * @param rgstSts
     * @param mlSendSts
     * @return
     * @throws ApplicationException
     */
    public Boolean updateLiyGSPasswordLock(String userCommon, String updateNm, String loginSts, String rgstSts,
            String mlSendSts) throws ApplicationException {
        try {
            return sZWP0000GhsDao.updateLiyGSPasswordLock(userCommon, updateNm, loginSts, rgstSts, mlSendSts);
        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
    }
    
    /**
     * 警備先論理番号から契約先論理番号を取得
     * @param lnKeibi
     * @return 契約先論理番号
     * @throws ApplicationException
     */
	public String getLnKeiykFromLnKeibi(String lnKeibi) throws ApplicationException {
        try {
            return sZWP0000GhsDao.getLnKeiykFromLnKeibi(lnKeibi);

        } catch (NoResultException noResultE) {
            return null;

        } catch (Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
                    errorMsg);
        }
	}
}
