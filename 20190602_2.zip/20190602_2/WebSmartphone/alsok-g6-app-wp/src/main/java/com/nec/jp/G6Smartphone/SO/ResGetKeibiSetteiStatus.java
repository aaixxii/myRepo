package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetKeibiSetteiStatus implements ErrorHandler {

	private String errorCode;						// エラーコード
	private String errorMsg;						// エラーメッセージ
	private String datetime;						// YYYY/MM/DD hh:mm:ss
	private List<RDevStsDataModel> rDevStsItem;
	private String acntID;

	public ResGetKeibiSetteiStatus() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.datetime = "";
		this.rDevStsItem = new ArrayList<RDevStsDataModel>();
		this.acntID = "";
	}

	public ResGetKeibiSetteiStatus(String errorCode, String errorMsg, String datetime,
			List<RDevStsDataModel> rDevStsItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.datetime = datetime;
		this.rDevStsItem = rDevStsItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	public List<RDevStsDataModel> getrDevStsItem() {
		return rDevStsItem;
	}

	public void setrDevStsItem(List<RDevStsDataModel> rDevStsItem) {
		this.rDevStsItem = rDevStsItem;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
