package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the A_USER_OPERATION_HANI database table.
 * 
 */
@Embeddable
public class AUserOperationHaniModelPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="LN_ACNT_USER_COMMON")
	private String lnAcntUserCommon;

	@Column(name="PATH_INF")
	private String pathInf;

	public AUserOperationHaniModelPK() {
	}
	public String getLnAcntUserCommon() {
		return this.lnAcntUserCommon;
	}
	public void setLnAcntUserCommon(String lnAcntUserCommon) {
		this.lnAcntUserCommon = lnAcntUserCommon;
	}
	public String getPathInf() {
		return this.pathInf;
	}
	public void setPathInf(String pathInf) {
		this.pathInf = pathInf;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof AUserOperationHaniModelPK)) {
			return false;
		}
		AUserOperationHaniModelPK castOther = (AUserOperationHaniModelPK)other;
		return 
			this.lnAcntUserCommon.equals(castOther.lnAcntUserCommon)
			&& this.pathInf.equals(castOther.pathInf);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.lnAcntUserCommon.hashCode();
		hash = hash * prime + this.pathInf.hashCode();
		
		return hash;
	}
}