package com.nec.jp.G6Smartphone.dao.g6;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.JianDataModel;

@Repository
public class SZWP3500Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;
	
	private StringBuilder getPersonDetectiontSql(String lnKbChiku, String nickName) {
		StringBuilder strBuilder = new StringBuilder();
	
		strBuilder.append(" SELECT DATE_FORMAT(ejian.INSERT_TS, '%Y/%m/%d %H:%i:%s') as insertTs");
//		strBuilder.append(",	 cast(ekbinf.VIDEO_FILE_NAME as character) as videoFileName");
		strBuilder.append(", IFNULL(rauthpicinf.PIC_INF, '') as videoFileName");
		strBuilder.append(", IFNULL(rauthpicinf.NICK_NAME, '') as nickName");
		strBuilder.append(", IFNULL(rkbchiku.SD_KOBETU_NM, '') as sdKobetuNm");
		strBuilder.append(", ekbinf.DEV_NM as devNm");
		strBuilder.append(",	 rauthpicinf.LN_R_AUTH_PIC_INF as lnRAuthPicInf");
		strBuilder.append(", ekbinf.LN_KB_INF as lnKbInf");
		strBuilder.append(", ekbinf.LN_IMG_NUM_P as lnImgNump");
		
		strBuilder.append(" FROM	 E_JIAN ejian");
		strBuilder.append(" INNER JOIN E_KB_INF_JIAN ekbinfjian ON ejian.LN_JIAN = ekbinfjian.LN_JIAN");
		strBuilder.append(" INNER JOIN E_KB_INF ekbinf ON ekbinfjian.LN_KB_INF = ekbinf.LN_KB_INF");
		strBuilder.append(" INNER JOIN R_KB_CHIKU rkbchiku ON ejian.LN_KB_CHIKU = rkbchiku.LN_KB_CHIKU");
//		strBuilder.append(" INNER JOIN R_AUTH_PIC_INF rauthpicinf ON ekbinf.IMG_NUM  = rauthpicinf.LN_R_AUTH_PIC_INF");
		strBuilder.append(" INNER JOIN R_AUTH_PIC_INF rauthpicinf ON ekbinf.IMG_NUM  = rauthpicinf.PIC_LGC_NO");
		// strBuilder.append(" WHERE	(DATE_FORMAT(ejian.PRE_JIAN_HASSEI_TS, '%Y%m%d') BETWEEN :dateFrom AND :dateTo)");
		strBuilder.append(" WHERE (DATE_FORMAT(ejian.JIAN_HASSEI_TS, '%Y%m%d') BETWEEN :dateFrom AND :dateTo)");
		if (!nickName.isEmpty()) {
			strBuilder.append(" AND rauthpicinf.NICK_NAME LIKE :nickName");
		}
		if (!lnKbChiku.isEmpty()) {
			strBuilder.append(" AND ejian.LN_KB_CHIKU = :lnKbChiku");
		}
		strBuilder.append(" ORDER BY	ejian.INSERT_TS DESC");
		
		return strBuilder;
	}

	public String getTotalRow(String acntID, String lnKbChiku, Date dateFrom, Date dateTo, String nickName) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append("SELECT COUNT(*) FROM (");
		strBuilder.append(getPersonDetectiontSql(lnKbChiku, nickName).toString());
		strBuilder.append(") PersonDetectionList");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		if (!nickName.isEmpty()) {
			query.setParameter("nickName", "%" + nickName + "%");
		}
		if (!lnKbChiku.isEmpty()) {
			query.setParameter("lnKbChiku", lnKbChiku);
		}
		query.setParameter("dateFrom", sdf.format(dateFrom));
		query.setParameter("dateTo", sdf.format(dateTo));
		
		return query.getSingleResult().toString();
	}
	
	@SuppressWarnings("unchecked")
	public List<JianDataModel> getPersonDetectionList(String acntID, String lnKbChiku, Date dateFrom, Date dateTo, String nickName, int offset, int limitRowNum ) {
		StringBuilder strBuilder = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

		strBuilder.append(getPersonDetectiontSql(lnKbChiku, nickName).toString());
		strBuilder.append(" LIMIT :offset, :limitRowNum");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "JianDataModelResult");
		if (!nickName.isEmpty()) {
			query.setParameter("nickName", "%" + nickName + "%");
		}
		if (!lnKbChiku.isEmpty()) {
			query.setParameter("lnKbChiku", lnKbChiku);
		}
		query.setParameter("dateFrom", sdf.format(dateFrom));
		query.setParameter("dateTo", sdf.format(dateTo));
		query.setParameter("offset", offset);
		query.setParameter("limitRowNum", limitRowNum);

		return (List<JianDataModel>) query.getResultList();
	}
}
