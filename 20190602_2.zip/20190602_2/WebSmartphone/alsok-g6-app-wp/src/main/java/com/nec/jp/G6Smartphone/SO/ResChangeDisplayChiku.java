package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResChangeDisplayChiku implements ErrorHandler {
	private String errorCode;				// エラーコード
	private String errorMsg;				// エラーメッセージ
	private List<RDevDataModel> rDevItem;
	private String acntID;
	private String userAuth;				// アカウント区分による権限チェック

	public ResChangeDisplayChiku() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.rDevItem = new ArrayList<RDevDataModel>();
		this.acntID = "";
	}

	public ResChangeDisplayChiku(String errorCode, String errorMsg, List<RDevDataModel> rDevItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.rDevItem = rDevItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<RDevDataModel> getrDevItem() {
		return rDevItem;
	}

	public void setrDevItem(List<RDevDataModel> rDevItem) {
		this.rDevItem = rDevItem;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
	
	public String getUserAuth() {
		return userAuth;
	}

	public void setUserAuth(String userAuth) {
		this.userAuth = userAuth;
	}
}
