package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;

import com.nec.jp.G6Smartphone.SO.HEventInfoDataModel;

import java.util.Date;


/**
 * The persistent class for the H_EVENT_INFO database table.
 * 
 */
@SqlResultSetMapping(name="HEventInfoDataModelResult",
classes = {
	@ConstructorResult(
		targetClass = HEventInfoDataModel.class,
		columns = {
			@ColumnResult(name = "lnEventInfoHst"),
			@ColumnResult(name = "hasseiTs"),
			@ColumnResult(name = "chikuNm"),
			@ColumnResult(name = "kenchiNaiyou"),
			@ColumnResult(name = "videLkFlg"),
			@ColumnResult(name = "vfileInfo")
			}
		)
	}
)
@Entity
@Table(name="H_EVENT_INFO")
@NamedQuery(name="HEventInfoModel.findAll", query="SELECT h FROM HEventInfoModel h")
public class HEventInfoModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_EVENT_INFO_HST")
	private String lnEventInfoHst;

	@Column(name="CHIKU_NM")
	private String chikuNm;

	@Column(name="HASSEI_TS")
	private String hasseiTs;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="KB_STS")
	private String kbSts;

	@Column(name="KENCHI_NAIYOU")
	private String kenchiNaiyou;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	@Column(name="VFILE_INFO")
	private String vfileInfo;

	@Column(name="VIDE_LK_FLG")
	private String videLkFlg;

	public HEventInfoModel() {
	}

	public String getLnEventInfoHst() {
		return this.lnEventInfoHst;
	}

	public void setLnEventInfoHst(String lnEventInfoHst) {
		this.lnEventInfoHst = lnEventInfoHst;
	}

	public String getChikuNm() {
		return this.chikuNm;
	}

	public void setChikuNm(String chikuNm) {
		this.chikuNm = chikuNm;
	}

	public String getHasseiTs() {
		return this.hasseiTs;
	}

	public void setHasseiTs(String hasseiTs) {
		this.hasseiTs = hasseiTs;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getKbSts() {
		return this.kbSts;
	}

	public void setKbSts(String kbSts) {
		this.kbSts = kbSts;
	}

	public String getKenchiNaiyou() {
		return this.kenchiNaiyou;
	}

	public void setKenchiNaiyou(String kenchiNaiyou) {
		this.kenchiNaiyou = kenchiNaiyou;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public String getVfileInfo() {
		return this.vfileInfo;
	}

	public void setVfileInfo(String vfileInfo) {
		this.vfileInfo = vfileInfo;
	}

	public String getVideLkFlg() {
		return this.videLkFlg;
	}

	public void setVideLkFlg(String videLkFlg) {
		this.videLkFlg = videLkFlg;
	}

}