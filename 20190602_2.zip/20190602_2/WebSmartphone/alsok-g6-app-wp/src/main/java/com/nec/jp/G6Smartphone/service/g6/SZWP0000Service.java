package com.nec.jp.G6Smartphone.service.g6;

import java.util.Date;
import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.jp.G6Smartphone.SO.RKeibiDataModel;
import com.nec.jp.G6Smartphone.SO.UserLoginInfoModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP0000Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP0000Service {
	
	@Autowired
	private SZWP0000Dao sZWP0000Dao;	

	public UserLoginInfoModel getUserLoginInfo(String loginId) throws ApplicationException {
		try {
			UserLoginInfoModel userLoginInfoModel = sZWP0000Dao.getUserLoginInfo(loginId);

			return userLoginInfoModel;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String exceptionMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), exceptionMsg);
		}
	}
	
	public List<RKeibiDataModel> getSecurityName(String lnAcntUserCommon, String keibiName) throws ApplicationException {
		try {
			List<RKeibiDataModel> rKeibiDataModelList = sZWP0000Dao.getSecurityName(lnAcntUserCommon, keibiName);

			return rKeibiDataModelList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	@Transactional("transactionManagerG6")
	public Boolean updateConfirmStatus(String lnAcntUserCommon, String acntNm) throws ApplicationException {
		try {
			Date updateTs = DateTimeCommon.getCurrentDate();
			return sZWP0000Dao.updateConfirmStatus(lnAcntUserCommon, acntNm, updateTs);
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	@Transactional("transactionManagerG6")
	public Boolean updateRegisStatus(String lnAcntUserCommon) throws ApplicationException {
		try {
			return sZWP0000Dao.updateRegisStatus(lnAcntUserCommon);
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	@Transactional("transactionManagerG6")
	public Boolean updateLastLoginDate(String lnAcntUserCommon, String acntNm, Date updateTs) throws ApplicationException {
		try {
			return sZWP0000Dao.updateLastLoginDate(lnAcntUserCommon, acntNm, updateTs);
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getLnKeiykFromLnKeibi(String lnKeibi) throws ApplicationException {
		try {
			return sZWP0000Dao.getLnKeiykFromLnKeibi(lnKeibi);
			
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}