package com.nec.jp.G6Smartphone.utility;


public class ConfigKey {

    /**
     * ConfigKey "not.find.image.path" 。
     * 
     * <pre>
     *  説明      ：ルートディレクトリパス用
     * </pre>
     */
    public static final String NOT_FIND_IMAGE_PATH = "not.find.image.path";

}