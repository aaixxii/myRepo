package com.nec.jp.G6Smartphone.SO;

public class G6ACntModel implements DataModelHandler {

	private String g6AcntNo;
	private String mlAddr;
	private String g5AcntNo;

	public G6ACntModel(String g6AcntNo, String mlAddr, String g5AcntNo) {
		this.g6AcntNo = g6AcntNo;
		this.mlAddr = mlAddr;
		this.g5AcntNo = g5AcntNo;
	}

	public String getG6AcntNo() {
		return g6AcntNo;
	}

	public void setG6AcntNo(String g6AcntNo) {
		this.g6AcntNo = g6AcntNo;
	}

	public String getMlAddr() {
		return mlAddr;
	}

	public void setMlAddr(String mlAddr) {
		this.mlAddr = mlAddr;
	}

	public String getG5AcntNo() {
		return g5AcntNo;
	}

	public void setG5AcntNo(String g5AcntNo) {
		this.g5AcntNo = g5AcntNo;
	}
}
