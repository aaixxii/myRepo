package com.nec.jp.G6Smartphone.SO;

public class RDevNameDataModel {

	private String lnKbChiku;
	private String lnDev;
	private String sdDevNm;
	private String sdDevNum;
	public RDevNameDataModel() {
		this.lnKbChiku = "";
		this.lnDev = "";
		this.sdDevNm = "";
		this.sdDevNum = "";
	}
	public RDevNameDataModel(String lnKbChiku, String lnDev, String sdDevNm, String sdDevNum) {
		this.lnKbChiku = lnKbChiku;
		this.lnDev = lnDev;
		this.sdDevNm = sdDevNm;
		this.sdDevNum = sdDevNum;
	}
	public RDevNameDataModel(String lnKbChiku, String lnDev, String sdDevNm) {
		this.lnKbChiku = lnKbChiku;
		this.lnDev = lnDev;
		this.sdDevNm = sdDevNm;
		this.sdDevNum = "";
	}
	public String getLnKbChiku() {
		return lnKbChiku;
	}
	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}
	public String getLnDev() {
		return lnDev;
	}
	public void setLnDev(String lnDev) {
		this.lnDev = lnDev;
	}
	public String getSdDevNm() {
		return sdDevNm;
	}
	public void setSdDevNm(String sdDevNm) {
		this.sdDevNm = sdDevNm;
	}
	public String getSdDevNum() {
		return sdDevNum;
	}
	public void setSdDevNum(String sdDevNum) {
		this.sdDevNum = sdDevNum;
	}
}
