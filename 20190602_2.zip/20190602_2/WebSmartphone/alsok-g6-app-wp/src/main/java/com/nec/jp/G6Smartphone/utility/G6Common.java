package com.nec.jp.G6Smartphone.utility;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nec.jp.G6Smartphone.SO.DataModelHandler;
import com.nec.jp.G6Smartphone.SO.ErrorHandler;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.SO.YukoAcntUserInf;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

import jdk.nashorn.api.scripting.ScriptObjectMirror;
import jp.co.alsok.g6.common.log.ApplicationLog;
import jp.co.alsok.g6.zzw.util.StringUtil;

@SuppressWarnings("restriction")
public class G6Common {
	
	private static final ApplicationLog appLog = new ApplicationLog(G6Common.class);

	private static int jsonConnectTimeout = 0;

	private static int jsonReadTimeout = 0;

	/** JavaScriptのエンジンマネージャ */
	protected static ScriptEngineManager manager;

	/** JavaScriptのエンジンオブジェクト */
	protected static ScriptEngine engine;

	/** JavaScriptエンジン定数 javascript */
    private static final String SCRIPT_JAVASCRIPT = "javascript";

    /** JavaScriptメソッド文字列 Object() */
    private static final String SCRIPT_NEW_OBJECT = "new Object()";

    /** JavaScriptメソッド文字列 Array() */
    private static final String SCRIPT_NEW_ARRAY = "new Array()";
    
	/** JavaScriptクラス文字列 JSON */
    private static final String SCRIPT_JSON = "JSON";

    /** JavaScriptメソッド文字列 push() */
    private static final String SCRIPT_PUSH = "push";

    /** JavaScriptメソッド文字列 parse() */
    private static final String SCRIPT_PARSE = "parse";

    /** JavaScriptメソッド文字列 stringify() */
    private static final String SCRIPT_STRINGIFY = "stringify";

	private static final int DEFAULT_TIMEOUT = 25000;
	
	public static Boolean checkRequire(Map<String, Object> mapParam, List<String> lstRequireParam) {
		boolean isPass = true;

		for (String requireParam : lstRequireParam) {
			if (!mapParam.containsKey(requireParam)) {
				return false;
			}
		}

		for (Map.Entry<String, Object> entry : mapParam.entrySet()) {
			if (!lstRequireParam.contains(entry.getKey()) || null == entry.getValue() || "".equals(entry.getValue())) {
				isPass = false;
				break;
			}
		}

		return isPass;
	}

	public static Boolean checkRequire(Map<String, Object> mapParam, Map<String, Boolean> mapRequireParam) {
		boolean isPass = true;
		if (mapParam.keySet().equals(mapRequireParam.keySet())) {
			for (Map.Entry<String, Boolean> entry : mapRequireParam.entrySet()) {
				if (entry.getValue()) {
					if (mapParam.get(entry.getKey()) == null || mapParam.get(entry.getKey()).toString().isEmpty()) {
						isPass = false;
						break;
					}
				}
			}
		} else {
			isPass = false;
		}
		return isPass;
	}

	public static Boolean checkRequire(Map<String, Object> mapParam, Map<String, Boolean> mapOptionalParam,
			List<String> lstArrayParam) {
		boolean isPass = true;
		if (mapParam.keySet().equals(mapOptionalParam.keySet())) {
			for (Map.Entry<String, Boolean> entry : mapOptionalParam.entrySet()) {
				// Check required param
				if (entry.getValue()) {
					if (mapParam.get(entry.getKey()) == null || mapParam.get(entry.getKey()).toString().isEmpty()) {
						isPass = false;
						break;
					}

					// Check array param
					if (lstArrayParam.contains(entry.getKey())) {
						try {
							@SuppressWarnings("unchecked")
							List<Object> lstObject = (List<Object>) mapParam.get(entry.getKey());

							if (lstObject.size() == 0) {
								isPass = false;
								break;
							} else {
								for (Object object : lstObject) {
									if (null == object || "".equals(object)) {
										isPass = false;
										break;
									}
								}
							}
						} catch (Exception e) {
							appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 

							isPass = false;
							break;
						}
					}
				}
			}
		} else {
			isPass = false;
		}
		return isPass;
	}

	public static List<Set<String>> getSignalType(Map<String, Object> mapParam, List<String> lstRequireParam,
			String type) {
		List<Set<String>> listResult = new ArrayList<Set<String>>();

		for (Map.Entry<String, Object> entry : mapParam.entrySet()) {
			if (lstRequireParam.contains(entry.getKey()) && G6Constant.MYCD002.CHECKED.equals(entry.getValue())) {
				for (String item : G6Constant.signalTypeMap.get(entry.getKey()).get(type)) {
					Set<String> setResult = new HashSet<String>();
					setResult.addAll(stringToArray(item));
					listResult.add(setResult);
				}
			}
		}

		return listResult;
	}

	public static List<String> stringToArray(String str) {
		List<String> result = new ArrayList<String>(Arrays.asList(str.split(G6Constant.COMMA)));
		result.removeAll(Arrays.asList(""));

		return result;
	}

	public static Set<String> stringToHashSet(String str) {
		List<String> lst = new ArrayList<String>(Arrays.asList(str.split(G6Constant.COMMA)));
		Set<String> set = new HashSet<String>();

		for (String string : lst) {
			set.add(string);
		}

		return set;
	}

	@SuppressWarnings("unchecked")
	public static Map<String, Object> readParam(String strParam) throws ApplicationException {

		ObjectMapper objMapper = new ObjectMapper();

		Map<String, Object> mapParam = new HashMap<String, Object>();

		try {
			// parse JSON
			mapParam = objMapper.readValue(strParam, HashMap.class);

		} catch (Exception e) {
			// リクエスト検証例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.UTILITY_CONTEXT, ErrorKey.EXCEPTION_PARSE_JSON.getValue(),
					errorMsg);
		}

		return mapParam;
	}

	public static String parseJSON(Object errorHandler, String acntLanguage) {

		String jsonResult = "";
		String errorMsg = "";
		ObjectMapper objMapper = new ObjectMapper();

		try {
			// parse JSON
			jsonResult = objMapper.writeValueAsString(errorHandler);

		} catch (JsonProcessingException jsonProcessE) {
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, jsonProcessE); 

			try {
				errorMsg = MessageCommon.getMessage(ErrorKey.EXCEPTION_PROCESSING_JSON.getValue(), acntLanguage);

			} catch (ApplicationException e) {
				// デフォルトエラーメッセージを応答する。
				errorMsg = G6Constant.LocalMessage.get(ErrorKey.CANNOT_PROCESSING_JSON.getValue()).get(acntLanguage);
			}

			jsonResult = "{\"errorCode\":\"" + G6Constant.FAIL_HTML_CD + "\"," + "\"errorMsg\":\"" + errorMsg + "\"}";
		}

		return jsonResult;
	}

	public static String messageHandler(ErrorHandler errorHandler, String errorCode, String errorKey,
			String acntLanguage) {

		String errorMsg = "";
		String jsonResult = "";

		try {
			// Set errorCode
			errorHandler.setErrorCode(errorCode);

			// エラーメッセージをプロパティファイルから取得する。
			errorMsg = MessageCommon.getMessage(errorKey, acntLanguage);

			// エラーメッセージを応答する。
			errorHandler.setErrorMsg(errorMsg);
			jsonResult = parseJSON(errorHandler, acntLanguage);

		} catch (ApplicationException e) {
			// ファイルアクセス例外
			if (e.getExceptionCode().equals(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue())) {
				// Set errorCode
				errorHandler.setErrorCode(G6Constant.FAIL_HTML_CD);

				// ログを出力する（ログレベル：WARM)
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2003, null, e); 

				// エラーメッセージを応答する。
				errorHandler.setErrorMsg(
						G6Constant.LocalMessage.get(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue()).get(acntLanguage));
				jsonResult = parseJSON(errorHandler, acntLanguage);
			}
		}

		return jsonResult;
	}

	public static String messageSearchHandler(ErrorHandler errorHandler, String errorCode, String errorKey,
			String searchCondition, String acntLanguage) {

		String errorMsg = "";
		String jsonResult = "";

		try {
			// Set errorCode
			errorHandler.setErrorCode(errorCode);

			// エラーメッセージをプロパティファイルから取得する。
			errorMsg = MessageFormat.format(MessageCommon.getMessage(errorKey, acntLanguage),
					MessageCommon.getMessage(searchCondition, acntLanguage));

			// エラーメッセージを応答する。
			errorHandler.setErrorMsg(errorMsg);
			jsonResult = parseJSON(errorHandler, acntLanguage);

		} catch (ApplicationException e) {
			// ファイルアクセス例外
			if (e.getExceptionCode().equals(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue())) {
				// Set errorCode
				errorHandler.setErrorCode(G6Constant.FAIL_HTML_CD);

				// ログを出力する（ログレベル：WARM)
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2003, null, e); 

				// エラーメッセージを応答する。
				errorHandler.setErrorMsg(
						G6Constant.LocalMessage.get(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue()).get(acntLanguage));
				jsonResult = parseJSON(errorHandler, acntLanguage);
			}
		}

		return jsonResult;
	}

	public static String messageLogHandler(ErrorHandler errorHandler, String errorCode, String errorKey,
			String exceptionMsg, String acntLanguage) {

		String errorMsg = "";
		String jsonResult = "";

		try {
			// Set errorCode
			errorHandler.setErrorCode(errorCode);

			// エラーメッセージをプロパティファイルから取得する。
			errorMsg = MessageCommon.getMessage(errorKey, acntLanguage);

			// ログを出力する（ログレベル：WARM)
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2003, null, exceptionMsg); 

			// エラーメッセージを応答する。
			errorHandler.setErrorMsg(errorMsg);
			jsonResult = parseJSON(errorHandler, acntLanguage);

		} catch (ApplicationException e) {
			// ファイルアクセス例外
			if (e.getExceptionCode().equals(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue())) {
				// Set errorCode
				errorHandler.setErrorCode(G6Constant.FAIL_HTML_CD);

				// ログを出力する（ログレベル：WARM)
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2003, null, e); 

				// エラーメッセージを応答する。
				errorHandler.setErrorMsg(
						G6Constant.LocalMessage.get(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue()).get(acntLanguage));
				jsonResult = parseJSON(errorHandler, acntLanguage);
			}
		}

		return jsonResult;
	}

	public static String messageUpdateLogHandler(ErrorHandler errorHandler, String errorCode, String errorKey,
			String operationKey, String acntLanguage) {

		String errorMsg = "";
		String jsonResult = "";

		try {
			// Set errorCode
			errorHandler.setErrorCode(errorCode);

			// エラーメッセージをプロパティファイルから取得する。
			errorMsg = MessageFormat.format(MessageCommon.getMessage(errorKey, acntLanguage),
					MessageCommon.getMessage(operationKey, acntLanguage));

			// ログを出力する（ログレベル：WARM)
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2003, null, errorMsg); 

			// エラーメッセージを応答する。
			errorHandler.setErrorMsg(errorMsg);
			jsonResult = parseJSON(errorHandler, acntLanguage);

		} catch (ApplicationException e) {
			// ファイルアクセス例外
			if (e.getExceptionCode().equals(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue())) {
				// Set errorCode
				errorHandler.setErrorCode(G6Constant.FAIL_HTML_CD);

				// ログを出力する（ログレベル：WARM)
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2003, null, e); 

				// エラーメッセージを応答する。
				errorHandler.setErrorMsg(
						G6Constant.LocalMessage.get(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue()).get(acntLanguage));
				jsonResult = parseJSON(errorHandler, acntLanguage);
			}
		}

		return jsonResult;
	}

	public static String messageUpdateLogHandler(ErrorHandler errorHandler, String errorCode, String operationKey, String acntLanguage) {

        String errorMsg = "";
        String jsonResult = "";

        try {
            // Set errorCode
            errorHandler.setErrorCode(errorCode);

            // エラーメッセージをプロパティファイルから取得する。
            errorMsg = MessageCommon.getMessage(operationKey, acntLanguage);

            // ログを出力する（ログレベル：WARM)
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2003, null, errorMsg); 

            // エラーメッセージを応答する。
            errorHandler.setErrorMsg(errorMsg);
            jsonResult = parseJSON(errorHandler, acntLanguage);

        } catch (ApplicationException e) {
            // ファイルアクセス例外
            if (e.getExceptionCode().equals(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue())) {
                // Set errorCode
                errorHandler.setErrorCode(G6Constant.FAIL_HTML_CD);

                // ログを出力する（ログレベル：WARM)
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2003, null, e); 

                // エラーメッセージを応答する。
                errorHandler.setErrorMsg(
                        G6Constant.LocalMessage.get(ErrorKey.CANNOT_READ_MESSAGE_FILE.getValue()).get(acntLanguage));
                jsonResult = parseJSON(errorHandler, acntLanguage);
            }
        }

        return jsonResult;
    }
	
	public static DataModelHandler[] readParamToArrayObject(Map<String, Object> mapParam, String paramName,
			String modelName, String acntLanguage) throws ApplicationException {

		ObjectMapper objMapper = new ObjectMapper();

		DataModelHandler[] arrDataModelHandler = null;

		try {
			String strParam = G6Common.parseJSON(mapParam.get(paramName), acntLanguage);
			// parse JSON
			switch (modelName) {
			case "RDevDataModel":
				arrDataModelHandler = objMapper.readValue(strParam, RDevDataModel[].class);
				break;
			}

		} catch (Exception e) {
			// リクエスト検証例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.UTILITY_CONTEXT, ErrorKey.EXCEPTION_PARSE_JSON.getValue(),
					errorMsg);
		}

		return arrDataModelHandler;
	}

	@SuppressWarnings("unchecked")
	public static List<String> readParamToArrayObject(Map<String, Object> mapParam, String paramName)
			throws ApplicationException {
		List<String> listItem = new ArrayList<String>();

		try {
			listItem.addAll((List<String>) mapParam.get(paramName));

			for (Object item : listItem) {
				if (item != null && !(item instanceof String)) {
					throw new Exception();
				}
			}
		} catch (Exception e) {
			// リクエスト検証例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.UTILITY_CONTEXT, ErrorKey.EXCEPTION_PARSE_JSON.getValue(),
					errorMsg);
		}

		return listItem;
	}

	public static String getElementByTagName(String xmlRecord, String tagName) throws ApplicationException {
		String execResult = "";
		String[] resultArray = xmlRecord.split(tagName);

		if (resultArray.length != 2) {
			return execResult;
		}

		String result = resultArray[1];
		execResult = result.trim().substring(0, 1);

		if (G6Constant.OPEN_XML_TAG.equals(execResult)) {
			execResult = "";
		}

		return execResult;
	}

	// 待機時間が経過するまで待機する
	public static void sleepOperation(int timeout, int timeSleep, int countSleep) {
		try {
			if (countSleep < (timeout / timeSleep)) {
				Thread.sleep(timeSleep);
			} else {
				Thread.sleep(timeout % timeSleep);
			}
		} catch (Exception e) {
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e); 
		}
	}

	public static String createSoapHeader(String ns1) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
		builder.append("<ns1:");
		builder.append(ns1);
		builder.append(" xmlns:ns1=\"http://nec.com/alsok\">");

		return builder.toString();
	}

	public static String createSoapFooter(String ns1) {
		StringBuffer builder = new StringBuffer();

		// フッター部作成
		builder.append("</ns1:");
		builder.append(ns1);
		builder.append(">");

		return builder.toString();
	}

	/**
	 * GHS向けSoap電文のヘッダを返す
	 * @return Soap電文ヘッダ
	 */
	public static String createSoapHeaderForGhs() {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>");
		builder.append("<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
		builder.append("<SOAP-ENV:Body>");
		builder.append("<ns1:CommandNotice xmlns:ns1=\"http://nec.com/alsok\">");

		return builder.toString();
	}
	
	/**
	 * GHS向けSoap電文のフッタを返す
	 * @return Soap電文フッタ
	 */
	public static String createSoapFooterForGhs() {
		StringBuffer builder = new StringBuffer();

		// フッタ部作成
		builder.append("</ns1:CommandNotice>");
		builder.append("</SOAP-ENV:Body>");
		builder.append("</SOAP-ENV:Envelope>");
		return builder.toString();
	}
	
	/**
	 * TODO リクエスト情報を検証する
	 * 
	 * @return boolean
	 */
	public static boolean invalidateAcntRole(Map<String, Object> mapParam) {
		return true;
	}
	
	/**
     * <pre>
     *     
     * 利用者アカウント区分チェック       
     * ・アカウント区分により利用可能な画面かどうかを判断する。
     * </pre>
     * 
     * @param lnAcntUserCommon
     * @param dispId
     * @return 利用不可(0),利用可（2),個別権限(3)
     */
	public static int invalidateUserAcntKbn(CommonComService commonComService, CommonService commonService, String lnAcntUserCommon, String dispId) {
        try {
            String acntUserKbn = null;
            final String refixWord = "P";
            YukoAcntUserInf yukoInf = null;
            // 画面情報（有効利用者アカウント区分を取得
            final String firstword = dispId.substring(0, 1);
            if (refixWord.equals(firstword)) {
            	yukoInf = commonService.getYukoAcntUserKbnInf(dispId);
            } else {
            	yukoInf = commonService.getYukoAcntUserKbnInf(refixWord + dispId);
            }
            if (null == yukoInf) {
                // 画面情報が存在しない場合は利用不可
                return 0;
            }
            // 利用者アカウント区分を取得
            acntUserKbn = commonComService.getAcntUserKbn(lnAcntUserCommon);
            if (StringUtil.isNullOrEmpty(acntUserKbn)) {
                // 取得できなかった場合は利用不可
                return 0;
            } else if (G6CodeConsts.CD216.REPRESENTATIVE_MAIN_ADMINISTRATOR.equals(acntUserKbn)) {
                // 代表メイン管理者は無条件で利用可
                return 2;
            }
            // 有効判定
            if(!"9999999999".equals(yukoInf.getMenupassInf())) {
                 // メニューパス情報が9999999999以外の場合は、個別権限設定可
                 return 3;
             } else if (!StringUtil.isNullOrEmpty(yukoInf.getYukoAcntUserKbn()) 
                     && Integer.parseInt(yukoInf.getYukoAcntUserKbn()) >= Integer.parseInt(acntUserKbn)) {
                 // 利用者アカウント区分が、有効利用者アカウント区分以下の場合、利用可
                 return 2;
             } else {
                 // 利用者アカウント区分が、有効利用者アカウント区分よりも大きい場合、利用不可
                 return 0;
             }
        } catch (Exception ex) {
            // ログを出力する
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
            return -1;
        }
    }

	public static String printStackTraceToString(Exception e) {
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));

		return sw.toString();
	}

	public static String sendJsonMsg(String jsonMessage, String sendUrl) throws Exception {

		StringBuffer result = new StringBuffer();
		HttpURLConnection con = null;
		try {
			URL url = new URL(sendUrl);
			con = (HttpURLConnection) url.openConnection();

			// HTTPヘッダー
			con.setRequestMethod("POST");
			con.setRequestProperty("Accept", "application/json");
			con.setRequestProperty("Content-Length", String.valueOf(jsonMessage.getBytes().length));
			con.setRequestProperty("Content-Type", "application/JSON; charset=UTF-8");

			// リクエストとレスポンスのボディ受信を許可
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setUseCaches(false);

			con.setConnectTimeout(jsonConnectTimeout);
			con.setReadTimeout(jsonReadTimeout);

			// リクエストのbodyにJSON文字列を書き込む
			PrintStream ps = new PrintStream(con.getOutputStream());
			ps.print(jsonMessage);
			ps.close();

			// リクエスト送信
			try {
				con.connect();
				int status = con.getResponseCode();
				if (status == HttpURLConnection.HTTP_OK) {
					// 通信成功

					// レスポンスの書き出し
					InputStream in = con.getInputStream();
					InputStreamReader inReader = new InputStreamReader(in, "UTF-8");
					BufferedReader bufReader = new BufferedReader(inReader);

					String line = null;
					while ((line = bufReader.readLine()) != null) {
						result.append(line);
					}

				} else {
					// 通信が失敗した場合のレスポンスコードを表示
					StringBuilder errorLogMsg = new StringBuilder();
					errorLogMsg.append("jsonMessage: " + jsonMessage);
					errorLogMsg.append(System.getProperty(System.lineSeparator()));
					errorLogMsg.append("HTTPstatus = " + status);
					throw new ApplicationException(G6Constant.UTILITY_CONTEXT, ErrorKey.ERROR_MEDIA_RESPONSE.getValue(),
							errorLogMsg.toString());
				}

			} catch (Exception e) {
				String errorLogMsg = G6Common.printStackTraceToString(e);
				throw new ApplicationException(G6Constant.UTILITY_CONTEXT,
						ErrorKey.EXCEPTION_MEDIA_COMMUNICATION.getValue(), errorLogMsg);
			}
		} finally {
			if (con != null) {
				// コネクションを切断
				con.disconnect();
			}
		}

		return result.toString();
	}

	/**
	 * JSON設定値チェック処理
	 *
	 * @param jsonString チェック対象のJSON文字列
	 * @return String チェック後のJSON文字列
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
    public static Map<String, ?> jsonValueCheck(String jsonString) throws Exception {

		// JSON文字列をMAPに変換
		Map<String, ?> map = null;
		map = decodeJson(jsonString, map);
		if (map == null) {
			// JSON置換失敗
			return null;
		}
		// 設定値nullのパラメータをJSON文字列から除外する
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		Set<String> list = map.keySet();
		for (String key : list) {
			// key値がnullの場合は無視
			if (key == null) {
				continue;
			}
			// value値を取得
			Object tmpVal = (Object) map.get(key);
			String val = null;
			List<String> valList = null;
			if (tmpVal == null) {
				resultMap.put(key, "");
			} else if (key.equals("alive_monitor")) {
                // 配列オブジェクトの場合
                ScriptObjectMirror listRec = (ScriptObjectMirror)map.get(key);
                Map<String, ?>[] mapListObj = listRec.to(Map[].class);
                ArrayList<HashMap<String, Object>> resultArray = new ArrayList<HashMap<String, Object>>();
                for(Map<String, ?> childVal : mapListObj) {
                    Map<?, ?> childMap = (Map<?, ?>)childVal;
                    HashMap<String, Object> tmpMap = new HashMap<String, Object>();
                    for (Map.Entry<?, ?> entry : childMap.entrySet()) {
                        tmpMap.put((String)entry.getKey(), replaceNullString((String)entry.getValue()));
                    }
                    resultArray.add(tmpMap);
                }
                resultMap.put(key, resultArray);
			} else if (tmpVal instanceof String) {
				// 文字列型の場合
				val = (String) tmpVal;
				resultMap.put(key, replaceNullString(val));
			} else {
				// List型の場合
				valList = getMapValueList(map, key);
				List<String> resultList = new ArrayList<String>();
				for (String targetVal : valList) {
					resultList.add(replaceNullString(targetVal));
				}
				resultMap.put(key, resultList);
			}
		}
		return resultMap;
	}

	public static boolean isTimeOut(int timeoutSetting, long beginTime) {
	    boolean result = true;
	    try {
	        final long endTime = System.currentTimeMillis();
	        final int countTime = getCountTime(beginTime, endTime);
	        int timeout = timeoutSetting;
	        if (timeout <= 0) {
	            // setting default timeout is 30 seconds
	            timeout = DEFAULT_TIMEOUT;
	        }
            if (countTime > timeout) {
                result = true;
            } else {
                result = false;
            }
	    } catch (Exception ex) {
	        appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
	    }
	    return result;
	}
	
	private static int getCountTime(long beginTime, long endTime) {
	    int result = DEFAULT_TIMEOUT;
	    try {
	        result = Math.toIntExact(endTime - beginTime);
	    } catch (Exception ex) {
            appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, ex); 
        }
	    return result;
	}
    
	/**
	 * 文字列置換<BR>
	 * <BR>
	 *
	 * @param String 処理対象の文字列
	 * @return String 処理後の文字列
	 */
	private static String replaceNullString(String inputVal) {
		String outputVal = null;
		if (inputVal == null) {
			// value値がnullの場合は""として設定
			outputVal = "";
		} else if ("null".equals(inputVal)) {
			// nullを""に置換
			outputVal = inputVal.replaceAll("null", "");
		} else {
			// null設定がなかった場合は置換なし
			outputVal = inputVal;
		}
		return outputVal;
	}

	/**
     * JSONエンコード<BR>
     * <BR>
     * Mapオブジェクトをエンコードして<BR>
     * JSONオブジェクトを作成する<BR>
     * <BR>
     *
     * @param map エンコード対象のMapオブジェクト
     * @return Object JSONオブジェクト
     */
    @SuppressWarnings("unchecked")
    public static Object encodeJson(final Map<String, ?> map) {

        Object jsonString = null;
        try {
            // JSON文字列に変換する辞書オブジェクト
            ScriptObjectMirror mirror = (ScriptObjectMirror) engine.eval(SCRIPT_NEW_OBJECT);

            // Mapのキー数ループ
            for (String key : map.keySet()) {

                Object value = map.get(key);

                if (value == null) {
                    // valueがnullのものは変換しない
                } else if (value instanceof Map) {
                    // Map型
                    Map<String, List<Object>> innerMap = (HashMap<String, List<Object>>) value;
                    ScriptObjectMirror innerMirror = (ScriptObjectMirror) engine.eval(SCRIPT_NEW_OBJECT);
                    for (String mapkey : (innerMap.keySet())) {
                        Object mapvalue = innerMap.get(mapkey);
                        ScriptObjectMirror list = (ScriptObjectMirror) engine.eval(SCRIPT_NEW_ARRAY);
                        // リストの数ループ
                        for (Object listObject : (List<Object>) mapvalue) {
                            if (listObject instanceof Integer) {
                                list.callMember(SCRIPT_PUSH, ((Integer) listObject).intValue());
                            } else {
                                list.callMember(SCRIPT_PUSH, listObject);
                            }
                        }
                        innerMirror.put(mapkey, list);
                    }
                    mirror.put(key, innerMirror);
                } else if (value instanceof List) {
                    // List型
                    ScriptObjectMirror list = (ScriptObjectMirror) engine.eval(SCRIPT_NEW_ARRAY);
                    // リストの数ループ
                    for (Object listObject : (List<Object>) value) {
                        // List<Map<String,Object>>の場合
                        if (listObject instanceof Map) {
                            Map<String, Object> innerMap = (HashMap<String, Object>) listObject;
                            ScriptObjectMirror innerMirror = (ScriptObjectMirror) engine.eval(SCRIPT_NEW_OBJECT);
                            for (String innerKey : innerMap.keySet()) {
                                Object innerValue = innerMap.get(innerKey);
                                innerMirror.put(innerKey, innerValue);
                            }
                            list.callMember(SCRIPT_PUSH, innerMirror);
                        } else {
                            list.callMember(SCRIPT_PUSH, listObject);
                        }
                    }
                    mirror.put(key, list);
                } else {
                    mirror.put(key, value);
                }
            }

            ScriptObjectMirror json = (ScriptObjectMirror) engine.eval(SCRIPT_JSON);
            jsonString = json.callMember(SCRIPT_STRINGIFY, mirror);
        } catch (Exception e) {
        	// JSON置換で例外発生
        	return null;
        }

        return jsonString;
    }
    
	/**
	 * JSONデコード<BR>
	 * <BR>
	 * JSON文字列をデコードして<BR>
	 * WebパラメータのMapオブジェクトを作成する<BR>
	 * <BR>
	 *
	 * @param jsonString デコード対象のJSON文字列
	 * @return Map<String, ?> WebパラメータのMapオブジェクト
	 * @throws ApplicationException
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, ?> decodeJson(final String jsonString, final Map<String, ?> map)
			throws ApplicationException {

		Map<String, ?> resultMap = null;
		Object result = null;
		manager = new ScriptEngineManager();
		engine = manager.getEngineByName(SCRIPT_JAVASCRIPT);
		// JSON.parseの実行結果を取得する
		try {
			ScriptObjectMirror json = (ScriptObjectMirror) engine.eval(SCRIPT_JSON);
			result = json.callMember(SCRIPT_PARSE, jsonString);
		} catch (Exception e) {
			// MAP変換で例外発生
			String errorLogMsg = G6Common.printStackTraceToString(e);
			throw new ApplicationException(G6Constant.UTILITY_CONTEXT, ErrorKey.EXCEPTION_PARSE_JSON.getValue(),
					errorLogMsg);
		}

		if (!(result instanceof Map)) {
			// デコード失敗
			return null;
		}

		// デコード結果をMapに変換
		resultMap = (Map<String, ?>) result;

		return resultMap;
	}

	/**
	 * WebパラメータのMap値取得(List値)<BR>
	 * <BR>
	 * MapオブジェクトからWebパラメータのkeyで検索して<BR>
	 * List値を取得する<BR>
	 * <BR>
	 *
	 * @param map Mapオブジェクト
	 * @param key 検索キー
	 * @return List 取得値
	 * @throws ApplicationException 
	 */
	private static List<String> getMapValueList(final Map<String, ?> map, final String key) throws ApplicationException {

		List<String> valueList = null;
		try {
			if (map.containsKey(key)) {
				valueList = new LinkedList<String>();
				ScriptObjectMirror mirror = (ScriptObjectMirror) map.get(key);
				if (mirror == null) {
					valueList.add(null);
				} else {
					String[] array = mirror.to(String[].class);
					for (String value : array) {
						valueList.add(value);
					}
				}
			}
		} catch (Exception e) {
			String errorLogMsg = G6Common.printStackTraceToString(e);
			throw new ApplicationException(G6Constant.UTILITY_CONTEXT, ErrorKey.EXCEPTION_PARSE_JSON.getValue(),
					errorLogMsg);
		}
		return valueList;
	}
	
	/**
	 * Calculate the offset number of current page
	 * @param pageNo
	 * @param limitRowNum
	 * @return offset number
	 */
	public static int calculateOffSet(int pageNo, int limitRowNum) {
		int offset = 0;
		
		offset = (pageNo - 1) * limitRowNum;
		if(offset < 0) {
			offset = 0;
		}
		
		return offset;
	}
	
	/**
	 * Calculate the limit number of offset
	 * @param offset
	 * @param limitRowNum
	 * @param list
	 * @return offset number
	 */
	public static int calculateLimit(int offset, int limitRowNum, List list) {
		
		int limit = offset + limitRowNum;
		if (limit > list.size()) {
			limit = list.size();
		}
		
		return limit;
	}

	/**
	 * Calculate the total Page will has been displayed
	 * @param totalRow
	 * @param limitRowNum
	 * @return total pages number
	 * @throws ApplicationException
	 */
	public static int calculateTotalPages(int totalRow, int limitRowNum) throws ApplicationException {
		int totalPage = 0;

		try {
			int oddRows = totalRow % limitRowNum;
			totalPage = totalRow / limitRowNum;
			if(oddRows > 0) {
				totalPage += 1;
			}	
		} catch (Exception e) {
			String errorLogMsg = G6Common.printStackTraceToString(e);
			throw new ApplicationException(G6Constant.UTILITY_CONTEXT, ErrorKey.EXCEPTION_LIMIT_ROW.getValue(),
					errorLogMsg);
		}
		
		return totalPage;
	}
	
}
