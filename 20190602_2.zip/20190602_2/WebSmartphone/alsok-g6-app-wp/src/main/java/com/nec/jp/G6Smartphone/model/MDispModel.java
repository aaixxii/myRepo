package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;

import com.nec.jp.G6Smartphone.SO.YukoAcntUserInf;

/**
 * The persistent class for the M_DISP database table.
 * 
 */
@SqlResultSetMappings({
    @SqlResultSetMapping(name="YukoAcntUserInf",
        classes = {
            @ConstructorResult(
                targetClass = YukoAcntUserInf.class,
                columns = {
                    @ColumnResult(name = "menupassInf"),
                    @ColumnResult(name = "chikuFlg"),
                    @ColumnResult(name = "yukoAcntUserKbn")
                }
            )
        }
    )
})

@Entity
@Table(name="M_DISP")
@NamedQuery(name="MDispModel.findAll", query="SELECT r FROM MDispModel r")
public class MDispModel implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="DISP_ID")
    private String dispId;
    
    @Column(name="DISP_NM")
    private String dispNm;

    @Column(name="ORDER_NUM")
    private String orderNum;

    @Column(name="MENUPASS_INF")
    private Date menupassInf;

    @Column(name="CHIKU_FLG")
    private String chikuFlg;
    
    @Column(name="YUKO_ACNT_USER_KBN")
    private String yukoAcntUserKbn;

    public String getDispId() {
        return dispId;
    }

    public void setDispId(String dispId) {
        this.dispId = dispId;
    }

    public String getDispNm() {
        return dispNm;
    }

    public void setDispNm(String dispNm) {
        this.dispNm = dispNm;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public Date getMenupassInf() {
        return menupassInf;
    }

    public void setMenupassInf(Date menupassInf) {
        this.menupassInf = menupassInf;
    }

    public String getChikuFlg() {
        return chikuFlg;
    }

    public void setChikuFlg(String chikuFlg) {
        this.chikuFlg = chikuFlg;
    }
    
    public String getYukoAcntUserKbn() {
        return yukoAcntUserKbn;
    }

    public void setYukoAcntUserKbn(String yukoAcntUserKbn) {
        this.yukoAcntUserKbn = yukoAcntUserKbn;
    }
}