package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.AreaSensorDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP0600Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<AreaSensorDataModel> updateKeibiStatus(String acntID, String lnKbChiku) {
		StringBuilder strBuilder = new StringBuilder();

//		strBuilder.append(" SELECT	IFNULL(a.KB_AREA_NM, '') as areaNm,");
//		strBuilder.append("			b.SD_DEV_NM as devNm");
//		strBuilder.append(" FROM	R_KB_AREA a INNER JOIN R_DEV b ON");
//		strBuilder.append("			(b.LN_KB_AREA = a.LN_KB_AREA");
//		strBuilder.append("			AND b.LN_KB_CHIKU = :lnKbChiku");
//		strBuilder.append("			AND a.LN_KB_CHIKU = b.LN_KB_CHIKU)");
//		strBuilder.append("			INNER JOIN R_DEV_STS c ON c.LN_DEV = b.LN_DEV");
//		strBuilder.append(" WHERE	a.DEL_FLG = :delFlg");
//		strBuilder.append("			AND (c.SENS_STS = :sensSts1 OR c.SENS_STS = :sensSts2)");
//		strBuilder.append(" ORDER BY a.KB_AREA_NUM ASC,");
//		strBuilder.append("			 b.SD_DEV_NUM ASC");
		
		strBuilder.append(" SELECT IFNULL(c.KB_AREA_NM, '') as areaNm,");
		strBuilder.append("        a.SD_DEV_NM as devNm ");
		strBuilder.append(" FROM R_DEV a ");
		strBuilder.append(" LEFT JOIN H_LPINF_RD_DTL b");
		strBuilder.append(" ON a.LN_DEV = b.LN_DEV");
		strBuilder.append(" LEFT JOIN R_KB_AREA c");
		strBuilder.append(" ON a.LN_KB_AREA =  c.LN_KB_AREA");
		strBuilder.append(" WHERE a.LN_KB_CHIKU = :lnKbChiku");
		strBuilder.append(" AND a.DEL_FLG = :delFlg");
		strBuilder.append(" AND b.LN_LPINF_DTL = (SELECT LN_LPINF_DTL ");
		strBuilder.append("                       FROM H_LPINF_RD_DTL HLRD");
		strBuilder.append("                       LEFT JOIN R_DEV RD");
		strBuilder.append("                       ON RD.LN_DEV = HLRD.LN_DEV");
		strBuilder.append("                       WHERE RD.LN_KB_CHIKU = :lnKbChiku");
		strBuilder.append("                       ORDER BY HLRD.UPDATE_TS DESC LIMIT 1)");
		strBuilder.append(" AND b.SENS_STS = :sensSts");
		strBuilder.append(" ORDER BY c.KB_AREA_NUM ASC,");
		strBuilder.append("          a.SD_DEV_NUM ASC");
		
		Query query = entityManager.createNativeQuery(strBuilder.toString(), "AreaSensorDataModelResult");
		query.setParameter("lnKbChiku", lnKbChiku);
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		query.setParameter("sensSts", G6CodeConsts.CD001.ABNORMAL);
//		query.setParameter("sensSts2", G6CodeConsts.CD066.ABNORMAL_NORMAL);

		return (List<AreaSensorDataModel>) query.getResultList();
	}
}
