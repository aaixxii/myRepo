package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.AcumImageDataModel;
import com.nec.jp.G6Smartphone.SO.KiyLoginInfoModel;
import com.nec.jp.G6Smartphone.SO.LiyGSLoginInfoModel;
import com.nec.jp.G6Smartphone.SO.UserLoginInfoModel;


/**
 * The persistent class for the A_ACNT_USER database table.
 * 
 */
@SqlResultSetMappings({
	@SqlResultSetMapping(name="UserLoginInfoModelResult",
			classes = {
				@ConstructorResult(
					targetClass = UserLoginInfoModel.class,
					columns = {
						@ColumnResult(name = "lnAcntUserCommon"),
						@ColumnResult(name = "acntNm"),
						@ColumnResult(name = "passwd"),
						@ColumnResult(name = "mlSendSts"),
						@ColumnResult(name = "checkSts"),
						@ColumnResult(name = "lastLoginTs"),
						@ColumnResult(name = "acntUserKbn"),
						@ColumnResult(name = "acntSbt")
					}
				)
			}
		),
	@SqlResultSetMapping(name="UserLoginInfoModelResult2",
		classes = {
			@ConstructorResult(
				targetClass = UserLoginInfoModel.class,
				columns = {
					@ColumnResult(name = "lnAcntUserCommon"),
					@ColumnResult(name = "acntNm"),
					@ColumnResult(name = "mlAddr"),
					@ColumnResult(name = "passwd"),
					@ColumnResult(name = "mlSendSts"),
					@ColumnResult(name = "checkSts"),
					@ColumnResult(name = "lastLoginTs"),
					@ColumnResult(name = "acntUserKbn"),
					@ColumnResult(name = "acntSbt")
				}
			)
		}
	),
	@SqlResultSetMapping(name="KiyLoginInfoModelResult",
			classes = {
				@ConstructorResult(
					targetClass = KiyLoginInfoModel.class, 
					columns = {
							@ColumnResult(name = "lnAcntKeiyk"),
							@ColumnResult(name = "lnKeiyk"),
							@ColumnResult(name = "mlAddr"),
							@ColumnResult(name = "passwd"),
							@ColumnResult(name = "acntType"),
							@ColumnResult(name = "userNm"),
							@ColumnResult(name = "loginSts"),
							@ColumnResult(name = "rgstSts"),
							@ColumnResult(name = "mlSendSts"),
							@ColumnResult(name = "updateTs"),
							@ColumnResult(name = "acntSbt")
					}
				)
			}
		),
	@SqlResultSetMapping(name="LiyGSLoginInfoModelResult",
			classes = {
				@ConstructorResult(
					targetClass = LiyGSLoginInfoModel.class, 
					columns = {
							@ColumnResult(name = "lnAcntUser"),
							@ColumnResult(name = "lnTenantMng"),
							@ColumnResult(name = "gsHsType"),
							@ColumnResult(name = "mlAddr"),
							@ColumnResult(name = "passwd"),
							@ColumnResult(name = "acntType"),
							@ColumnResult(name = "userNm"),
							@ColumnResult(name = "loginSts"),
							@ColumnResult(name = "rgstSts"),
							@ColumnResult(name = "mlSendSts"),
							@ColumnResult(name = "updateTs"),
							@ColumnResult(name = "acntSbt")
					}
				)
			}
		),
	@SqlResultSetMapping(name="AcumImageDataModelResult",
			classes = {
				@ConstructorResult(
					targetClass = AcumImageDataModel.class,
					columns = {
						@ColumnResult(name = "lnLiveImgVoc"),
						@ColumnResult(name = "shotSttTstm"),
						@ColumnResult(name = "shotEndTstm"),
						@ColumnResult(name = "savePath"),
						@ColumnResult(name = "fileNm"),
						@ColumnResult(name = "fileSize"),
						@ColumnResult(name = "pxSize")
					}
				)
			}
		)
})

@Entity
@Table(name="A_ACNT_USER")
@NamedQuery(name="AAcntUserModel.findAll", query="SELECT a FROM AAcntUserModel a")
public class AAcntUserModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_ACNT_USER_COMMON")
	private String lnAcntUserCommon;

	@Column(name="ALSOK_BIKOU")
	private String alsokBikou;

	@Column(name="CARD_FLG")
	private String cardFlg;

	@Column(name="CHECK_STS")
	private String checkSts;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="KNRN_FLG")
	private String knrnFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_LOGIN_TS")
	private Date lastLoginTs;

	@Column(name="ML_ADDR_TOUROKU")
	private String mlAddrTouroku;

	@Column(name="ML_ERR_CD")
	private String mlErrCd;

	@Column(name="ML_SEND_FLG")
	private String mlSendFlg;

	@Column(name="ML_SEND_STS")
	private String mlSendSts;

	@Column(name="ML_STS")
	private String mlSts;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="STS_UPD_TS")
	private Date stsUpdTs;

	@Column(name="TOUROKU_BIKOU")
	private String tourokuBikou;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	@Column(name="WEB_ETURAN_FLG")
	private String webEturanFlg;

	public AAcntUserModel() {
	}

	public String getLnAcntUserCommon() {
		return this.lnAcntUserCommon;
	}

	public void setLnAcntUserCommon(String lnAcntUserCommon) {
		this.lnAcntUserCommon = lnAcntUserCommon;
	}

	public String getAlsokBikou() {
		return this.alsokBikou;
	}

	public void setAlsokBikou(String alsokBikou) {
		this.alsokBikou = alsokBikou;
	}

	public String getCardFlg() {
		return this.cardFlg;
	}

	public void setCardFlg(String cardFlg) {
		this.cardFlg = cardFlg;
	}

	public String getCheckSts() {
		return this.checkSts;
	}

	public void setCheckSts(String checkSts) {
		this.checkSts = checkSts;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getKnrnFlg() {
		return this.knrnFlg;
	}

	public void setKnrnFlg(String knrnFlg) {
		this.knrnFlg = knrnFlg;
	}

	public Date getLastLoginTs() {
		return this.lastLoginTs;
	}

	public void setLastLoginTs(Date lastLoginTs) {
		this.lastLoginTs = lastLoginTs;
	}

	public String getMlAddrTouroku() {
		return this.mlAddrTouroku;
	}

	public void setMlAddrTouroku(String mlAddrTouroku) {
		this.mlAddrTouroku = mlAddrTouroku;
	}

	public String getMlErrCd() {
		return this.mlErrCd;
	}

	public void setMlErrCd(String mlErrCd) {
		this.mlErrCd = mlErrCd;
	}

	public String getMlSendFlg() {
		return this.mlSendFlg;
	}

	public void setMlSendFlg(String mlSendFlg) {
		this.mlSendFlg = mlSendFlg;
	}

	public String getMlSendSts() {
		return this.mlSendSts;
	}

	public void setMlSendSts(String mlSendSts) {
		this.mlSendSts = mlSendSts;
	}

	public String getMlSts() {
		return this.mlSts;
	}

	public void setMlSts(String mlSts) {
		this.mlSts = mlSts;
	}

	public Date getStsUpdTs() {
		return this.stsUpdTs;
	}

	public void setStsUpdTs(Date stsUpdTs) {
		this.stsUpdTs = stsUpdTs;
	}

	public String getTourokuBikou() {
		return this.tourokuBikou;
	}

	public void setTourokuBikou(String tourokuBikou) {
		this.tourokuBikou = tourokuBikou;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

	public String getWebEturanFlg() {
		return this.webEturanFlg;
	}

	public void setWebEturanFlg(String webEturanFlg) {
		this.webEturanFlg = webEturanFlg;
	}

}