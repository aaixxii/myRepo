package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetLockedStatus implements ErrorHandler {

	private String errorCode;			// エラーコード
	private String errorMsg;			// エラーメッセージ
	private List<LockedStatusDataModel> lockedStatusItem;
	private String acntID;				// アカウントID

	public ResGetLockedStatus() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.lockedStatusItem = new ArrayList<LockedStatusDataModel>();
		this.acntID = "";
	}

	public ResGetLockedStatus(String errorCode, String errorMsg, List<LockedStatusDataModel> lockedStatusItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.lockedStatusItem = lockedStatusItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public List<LockedStatusDataModel> getLockedStatusItem() {
		return lockedStatusItem;
	}

	public void setLockedStatusItem(List<LockedStatusDataModel> lockedStatusItem) {
		this.lockedStatusItem = lockedStatusItem;
	}
	
	public String getAcntID() {
		return acntID;
	}

	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
