package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.CameraDataModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuNmDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP2600Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<RKbChikuNmDataModel> getSecurityDistrictList(String acntID, String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT			chiku.LN_KB_CHIKU as lnKbChiku");
		strBuilder.append(",						IFNULL(chiku.SD_KOBETU_NM, '') as sdKobetuNm");
		strBuilder.append(",						chiku.LN_KEIBI as lnKeibi");
		strBuilder.append(" FROM				R_KB_CHIKU chiku");
		strBuilder.append(" INNER JOIN 	R_KEIBI keibi ON chiku.LN_KEIBI = keibi.LN_KEIBI");
		strBuilder.append("			INNER JOIN A_USER_OPERATION_HANI A ON A.LN_ACNT_USER_COMMON = :acntID");
        strBuilder.append("			AND ( A.PATH_INF = chiku.PATH_INF");
        strBuilder.append("			   OR A.PATH_INF = LEFT(chiku.PATH_INF, 41)");
        strBuilder.append("			   OR A.PATH_INF = LEFT(chiku.PATH_INF, 20) )");
		strBuilder.append(" WHERE			keibi.LN_KEIBI = :lnKeibi");
		strBuilder.append("						AND chiku.ENTRY_STS = :entrySts");
		strBuilder.append(" ORDER BY		chiku.LN_KB_CHIKU ASC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "RKbChikuNmDataModelResult");
		query.setParameter("acntID", acntID);
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("entrySts", G6CodeConsts.CD031.REGISTERED);

		return (List<RKbChikuNmDataModel>) query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<CameraDataModel> getDeviceList(String lnKbChiku) {
		final StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT dev.LN_DEV as lnDev,");
		strBuilder.append("    dev.SD_DEV_NM as sdDevNm,");
		strBuilder.append("    dev.SD_DEV_NUM as sdDevNum");
		strBuilder.append(" FROM R_DEV dev");
		strBuilder.append(" INNER JOIN R_KB_CHIKU chiku ON dev.LN_KB_CHIKU = chiku.LN_KB_CHIKU");
		strBuilder.append(" WHERE chiku.LN_KB_CHIKU = :lnKbChiku");
		strBuilder.append(" AND dev.DEL_FLG = :delFlg");
        // START: Added conditions
        strBuilder.append(" AND (dev.SD_DEV_NUM LIKE 'GS%'");
        strBuilder.append("   OR dev.SD_DEV_NUM LIKE 'CM%'");
        strBuilder.append("   OR dev.SD_DEV_NUM LIKE 'RC%'");
        strBuilder.append("   OR dev.SD_DEV_NUM LIKE 'CU___-CM%')");
        // END: Added conditions
		strBuilder.append(" ORDER BY dev.SD_DEV_NUM ASC");

		final Query query = entityManager.createNativeQuery(strBuilder.toString(), "CameraDataModelResult");
		query.setParameter("lnKbChiku", lnKbChiku);
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);

		return (List<CameraDataModel>) query.getResultList();
	}
}
