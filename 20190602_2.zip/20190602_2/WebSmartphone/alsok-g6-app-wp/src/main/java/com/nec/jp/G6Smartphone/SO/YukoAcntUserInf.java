package com.nec.jp.G6Smartphone.SO;

public class YukoAcntUserInf {
    /**
     * メニューパス情報
     */
    protected String menupassInf;
    /**
     * 地区別権限有無
     */
    protected String chikuFlg;
    /**
     * 有効利用者アカウント区分
     */
    protected String yukoAcntUserKbn;
    
    
    public YukoAcntUserInf() {
        this.menupassInf = "";
        this.chikuFlg = "";
        this.yukoAcntUserKbn = "";
    }
    
    public YukoAcntUserInf(String menupassInf, String chikuFlg, String yukoAcntUserKbn) {
        this.menupassInf = menupassInf;
        this.chikuFlg = chikuFlg;
        this.yukoAcntUserKbn = yukoAcntUserKbn;
    }
    
    /**
     * @return the menupassInf
     */
    public String getMenupassInf() {
        return menupassInf;
    }
    /**
     * @return the chikuFlg
     */
    public String getChikuFlg() {
        return chikuFlg;
    }
    /**
     * @return the yukoAdntUserKbn
     */
    public String getYukoAcntUserKbn() {
        return yukoAcntUserKbn;
    }
}
