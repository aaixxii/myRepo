package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ResDownloadProcess;
import com.nec.jp.G6Smartphone.SO.ResGetDownloadIpPort;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;
import com.nec.jp.G6Smartphone.websocket.G6SocketClient;

import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWP2800Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP2800Controller.class);
	
	//JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;
	
	// getting value from config file
	@Value("${media_api_2800}")
	String MEDIA_API_2800;
	
	@RequestMapping(value = "/getDownloadIpPort", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getDownloadIpPort(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2800Controller.getDownloadIpPort()");
		String jsonResult = "";
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResGetDownloadIpPort resGetDownloadIpPort = new ResGetDownloadIpPort();
		Map<String, Object> mapResponse = new HashMap<String, Object>();
		String acntNm = "";
		
		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetDownloadIpPort, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.getDownloadIpPort()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetDownloadIpPort, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.getDownloadIpPort()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
			
			// 選択言語種別の取得
			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				acntLanguage = commonComService
						.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}
			// リクエスト情報を検証する
			if (mapParam.size() != 5) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetDownloadIpPort, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.getDownloadIpPort()");
				return jsonResult;
			}
			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.lnDev.getValue());
					add(RequestParam.downloadBgnPeriod.getValue());
					add(RequestParam.downloadEndPeriod.getValue());
				}
			};
			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetDownloadIpPort, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.getDownloadIpPort()");
				return jsonResult;
			}
			// TODO SZWP2800：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);
			Map<String, Object> params = new HashMap<String, Object>();
			String lnDev = mapParam.get(RequestParam.lnDev.getValue()).toString();
			Date dtFroms = DateTimeCommon
					.stringToDateTime(mapParam.get(RequestParam.downloadBgnPeriod.getValue()).toString());
			Date dtTos = DateTimeCommon
					.stringToDateTime(mapParam.get(RequestParam.downloadEndPeriod.getValue()).toString());
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();

			// LN_利用者アカウント共通論理番号
			params.put(RequestParam.ln_acnt_user_common.getValue(),
					mapParam.get(RequestParam.acntID.getValue()).toString());
			// 画面ID
			params.put(RequestParam.screen_id.getValue(), G6Constant.ScreenID.SZWU3200.getValue());
			// 操作フォームID
			params.put(RequestParam.ope_form_id.getValue(), G6Constant.OpeFromID.SZWU3200_002.getValue());
			// 設置機器論理番号
			// params.put(RequestParam.lnDev.getValue(), lnDev);
			params.put(RequestParam.ln_dev.getValue(), lnDev);
			// 基準の情報（yyyy-MM-dd HH:mm:ss）
			// 視聴間隔
			// ダウンロード開始期間(yyyy-MM-dd HH:mm:ss)
			params.put(RequestParam.download_bgn_period.getValue(), DateTimeCommon.toMediaServerFormat(dtFroms));
			// ダウンロード終了期間(yyyy-MM-dd HH:mm:ss)
			params.put(RequestParam.download_end_period.getValue(), DateTimeCommon.toMediaServerFormat(dtTos));
			// START: FIX BUG No.68
			// 削除
			// ln_dev_list ---> ""
			// params.put(RequestParam.ln_dev_list.getValue(), "");
			// accum_list_tm ---> ""
			// params.put(RequestParam.accum_list_tm.getValue(), "");
			// accum_list_intereval ---> ""
			// params.put(RequestParam.accum_list_intereval.getValue(), "");
			// END: FIX BUG No.68
			String postJsonData = G6Common.parseJSON(params, acntLanguage);
			// JSON電文を送信
			String strResponse = G6Common.sendJsonMsg(postJsonData, MEDIA_API_2800);
			// レスポンスを取得
			mapResponse = G6Common.readParam(strResponse);
			if (mapResponse.get(RequestParam.result.getValue()).toString().contentEquals("0")) {
				resGetDownloadIpPort.setErrorCode(G6Constant.SUCCESS_CD);
				// ライブ配信WEBサーバIP
				resGetDownloadIpPort.setLiveIP(mapResponse.get(RequestParam.live_ip.getValue()).toString());
				// ライブ配信WEBサーバPORT
				resGetDownloadIpPort.setDownloadPort(mapResponse.get(RequestParam.download_port.getValue()).toString());
			} else {
				jsonResult = G6Common.messageHandler(resGetDownloadIpPort, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_MEDIA_RESULT.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.getDownloadIpPort()");
				return jsonResult;
			}
			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//			// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//			final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//			hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP2800.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm, DateTimeCommon.getCurrentDate());
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());	// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);														// アカウント名
			hUserOperationLogModel.setLnKeibi(null);														// 警備先論理番号
			hUserOperationLogModel.setLnKbChiku(null);														// 警備先地区論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP2800.getValueForOperationLog());					// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);								// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);

			
			// デコード済acntIDを設定したJWT認証トークンを付与
			resGetDownloadIpPort.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
										
			jsonResult = G6Common.parseJSON(resGetDownloadIpPort, acntLanguage);
			
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetDownloadIpPort, G6Constant.FAIL_HTML_CD, e.getExceptionCode(),
					e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetDownloadIpPort, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetDownloadIpPort, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			jsonResult = G6Common.messageLogHandler(resGetDownloadIpPort, G6Constant.FAIL_HTML_CD,
					ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.getDownloadIpPort()");
		return jsonResult;
	}
	@RequestMapping(value = "/downloadProcess", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String downloadProcess(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2800Controller.downloadProcess()");
		String jsonResult = "";
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResDownloadProcess resDownloadProcess = new ResDownloadProcess();
		String command = "";
		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resDownloadProcess, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.downloadProcess()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resDownloadProcess, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.downloadProcess()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
            
			// 選択言語種別の取得
			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}
			// リクエスト情報を検証する
			if (mapParam.size() != 4) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resDownloadProcess, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.downloadProcess()");
				return jsonResult;
			}
			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.liveIP.getValue());
					add(RequestParam.downloadPort.getValue());
					add(RequestParam.command.getValue());
				}
			};
			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resDownloadProcess, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);
				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.downloadProcess()");
				return jsonResult;
			}
			// ライブ配信WEBサーバIPアドレス
			String liveIp = mapParam.get(RequestParam.liveIP.getValue()).toString();
			// ソケット通信用port
			String portServerSocket = mapParam.get(RequestParam.downloadPort.getValue()).toString();
			//コマンド
			command = mapParam.get(RequestParam.command.getValue()).toString();
			//ライブ配信WEBサーバの死活監視を行い
			G6SocketClient g6SocketClient = new G6SocketClient();
			//ダウンロード処理ステータスを返す
			String status = g6SocketClient.downloadProcess(liveIp, portServerSocket, command);
			
			// ステータス設定
			resDownloadProcess.setStatus(status);
			if (G6Constant.MYCD008.STATUS_FAILED.equals(status)) {
				//レスポンスのステータスが"F"の場合
				jsonResult = G6Common.messageHandler(resDownloadProcess, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_MEDIA_FAILURE.getValue(), acntLanguage);
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.downloadProcess()");
				return jsonResult;
			} else {
				resDownloadProcess.setErrorCode(G6Constant.SUCCESS_CD);
			}
			
			// デコード済acntIDを設定したJWT認証トークンを付与
			resDownloadProcess.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
	
			jsonResult = G6Common.parseJSON(resDownloadProcess, acntLanguage);
			
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resDownloadProcess, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resDownloadProcess, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resDownloadProcess, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			jsonResult = G6Common.messageLogHandler(resDownloadProcess, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
		}
		
		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2800Controller.downloadProcess()");
		return jsonResult;
	}
}
