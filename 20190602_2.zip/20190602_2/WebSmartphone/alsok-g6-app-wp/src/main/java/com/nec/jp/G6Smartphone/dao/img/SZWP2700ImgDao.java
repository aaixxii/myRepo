package com.nec.jp.G6Smartphone.dao.img;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.AcumImageDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP2700ImgDao {

	@PersistenceContext(unitName="imgPersistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<AcumImageDataModel> getAccumulatedImageSoundInf(String lnDev, Date dtStart) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT			T1.LN_ACUM_IMGVOC as lnLiveImgVoc");
		strBuilder.append(",						IFNULL(DATE_FORMAT(T1.SHOT_STT_TSTM, '%Y/%m/%d %H:%i'), '') as shotSttTstm");
		strBuilder.append(",						IFNULL(DATE_FORMAT(T1.SHOT_END_TSTM, '%Y/%m/%d %H:%i'), '') as shotEndTstm");
		strBuilder.append(",						IFNULL(T1.SAVE_PATH, '') as savePath");
		strBuilder.append(",						IFNULL(T1.FILE_NM, '') as fileNm");
		strBuilder.append(",						IFNULL(T1.FILE_SIZE, '') as fileSize");
		strBuilder.append(",						IFNULL(T1.PX_SIZE, '') as pxSize");
		strBuilder.append(" FROM				I_MNG_ACCUMULATE T1");
		strBuilder.append(" WHERE			T1.DEL_FLG = :delFlg");
		strBuilder.append(" 						AND T1.LN_DEV = :lnDev");
		strBuilder.append(" 						AND T1.SHOT_STT_TSTM >= :dtStart");
		strBuilder.append(" ORDER BY		T1.SHOT_STT_TSTM ASC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "AcumImageDataModelResult");

		query.setParameter("delFlg", G6CodeConsts.CD167.EFFECTIVE);
		query.setParameter("lnDev", lnDev);
		query.setParameter("dtStart", dtStart);

		return (List<AcumImageDataModel>) query.getResultList();
	}
}
