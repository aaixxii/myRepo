package com.nec.jp.G6Smartphone.service.com;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.ResGetOtherInfo;
import com.nec.jp.G6Smartphone.dao.com.SZWP2000ComDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP2000ComService {

	@Autowired
	private SZWP2000ComDao sZWP2000Dao;

	public String getALSOKGuardCenterInfo(String keibiGcCd) throws ApplicationException {
		try {
			return sZWP2000Dao.getALSOKGuardCenterInfo(keibiGcCd);
		} catch (NoResultException noResultE) {
			return "";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getBusinessInfo(String jisshiJigyouCd) throws ApplicationException {
		try {
			return sZWP2000Dao.getBusinessInfo(jisshiJigyouCd);
		} catch (NoResultException noResultE) {
			return "";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public ResGetOtherInfo getOtherInfo(String juchuJigyouCd) throws ApplicationException {
		try {
			return sZWP2000Dao.getOtherInfo(juchuJigyouCd);
		} catch (NoResultException noResultE) {
			return new ResGetOtherInfo();
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
