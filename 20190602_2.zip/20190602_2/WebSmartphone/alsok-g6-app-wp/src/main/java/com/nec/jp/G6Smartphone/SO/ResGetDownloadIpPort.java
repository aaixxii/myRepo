package com.nec.jp.G6Smartphone.SO;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetDownloadIpPort implements ErrorHandler {

	private String errorCode;	// エラーコード
	private String errorMsg;	// エラーメッセージ
	private String liveIP;
	private String downloadPort;
	private String acntID;
	
	public ResGetDownloadIpPort() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.liveIP = "";
		this.downloadPort = "";
		this.acntID = "";
	}
	public ResGetDownloadIpPort(String errorCode, String errorMsg, String liveIP, String downloadPort) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.liveIP = liveIP;
		this.downloadPort = downloadPort;
		this.acntID = "";
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getLiveIP() {
		return liveIP;
	}
	public void setLiveIP(String liveIp) {
		this.liveIP = liveIp;
	}
	public String getDownloadPort() {
		return downloadPort;
	}
	public void setDownloadPort(String downloadPort) {
		this.downloadPort = downloadPort;
	}
	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
}
