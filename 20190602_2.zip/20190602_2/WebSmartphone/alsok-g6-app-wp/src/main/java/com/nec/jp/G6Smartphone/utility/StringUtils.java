package com.nec.jp.G6Smartphone.utility;

/**
 * 文字関連のユーティリティメソッドを提供するクラスです。
 *
 * @author 2011/05/31 chenheng
 */
public final class StringUtils {

    /**
     * コンストラクタです。
     */
    private StringUtils() {
    }

    /**
     * 文字列の左側から文字列を充たす。
     *
     * @param str 入力文字列
     * @param fillChar 文字列
     * @param strLength 文字列桁数
     * @return 文字列
     */
    public static String addCharForStrL(String str, char fillChar, int strLength) {
        int strLen = str.length();
        StringBuilder sb = new StringBuilder();
        if (strLen < strLength) {
            while (strLen < strLength) {
                sb.append(fillChar);
                strLen = str.length() + sb.toString().length();
            }
        }
        sb.append(str);
        return sb.toString();
    }

    /**
     * 空文字列判定
     *
     * @param input 入力文字列
     * @return true/false
     */
    public static boolean isBlank(String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(str.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    /**
     * 指定された桁数の空白文字列を取得する。
     *
     * @param cnt 空白桁数
     * @return 指定された桁数の空白文字列
     */
    public static String space(int cnt) {
        StringBuilder strSpace = new StringBuilder("");
        for (int i = 0; i < cnt; i++) {
            strSpace.append(" ");
        }
        return strSpace.toString();
    }

    /**
     * 空文字列判定
     *
     * @param input 入力文字列
     * @return true/false
     */
    public static boolean isEmpty(String input) {
        if (input == null || "".equals(input)) {
            return true;
        } else {
            return false;
        }
    }
}
