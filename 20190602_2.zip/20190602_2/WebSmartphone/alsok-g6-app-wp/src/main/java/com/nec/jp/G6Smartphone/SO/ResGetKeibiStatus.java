package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResGetKeibiStatus implements ErrorHandler {

	private String errorCode;				// エラーコード
	private String errorMsg;				// エラーメッセージ
	private List<RKbChikuDataModel> rKbChikuItem;
	private String acntID;					// アカウントID
	private String userAuth;		// アカウント区分による権限チェック

	public ResGetKeibiStatus() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.rKbChikuItem = new ArrayList<RKbChikuDataModel>();
		this.acntID = "";
		this.userAuth = "";
	}

	public ResGetKeibiStatus(String errorCode, String errorMsg, List<RKbChikuDataModel> rKbChikuItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.rKbChikuItem = rKbChikuItem;
		this.acntID = "";
	}

	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public List<RKbChikuDataModel> getrKbChikuItem() {
		return rKbChikuItem;
	}
	public void setrKbChikuItem(List<RKbChikuDataModel> rKbChikuItem) {
		this.rKbChikuItem = rKbChikuItem;
	}

	public String getAcntID() {
		return acntID;
	}
	public void setAcntID(String acntID) {
		this.acntID = acntID;
	}
	public String getUserAuth() {
		return userAuth;
	}

	public void setUserAuth(String userAuth) {
		this.userAuth = userAuth;
	}
}
