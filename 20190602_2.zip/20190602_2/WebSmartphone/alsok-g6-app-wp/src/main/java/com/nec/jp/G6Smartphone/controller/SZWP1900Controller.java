package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ResGetNoticeDetail;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP1900Service;
import com.nec.jp.G6Smartphone.service.ghs.SZWP1900GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;

@Controller
public class SZWP1900Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP1900Controller.class);

	//JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;
	@Autowired
	SZWP1900Service sZWP1900Service;
	@Autowired
	SZWP1900GhsService sZWP1900GhsService;

	/*
	 * Get data from H_ALSOK_NOTICE table
	 * @param: acntID, lnHAlsokNotice
	 * return: object ResGetNoticeDetail as JSON
	 */
	@RequestMapping(value = "/getNoticeDetail", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getNoticeDetail(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1900Controller.getNoticeDetail()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		Map<String, Object> mapParam = new HashMap<String, Object>();
		ResGetNoticeDetail resGetNoticeDetail = new ResGetNoticeDetail();
		String acntType = "";
		String acntNm = "";

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);
			
			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetNoticeDetail, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1900Controller.getNoticeDetail()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetNoticeDetail, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1900Controller.getNoticeDetail()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));


			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 4) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetNoticeDetail, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1900Controller.getNoticeDetail()");
				return jsonResult;
			}
			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.acntSbt.getValue());
					add(RequestParam.lnHAlsokNotice.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetNoticeDetail, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1900Controller.getNoticeDetail()");
				return jsonResult;
			}

			// リクエスト情報取得
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();

			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resGetNoticeDetail, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1900Controller.getNoticeDetail()");
				return jsonResult;
			}

			// TODO SZWP1900：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// アカウント種別が、次期警備の場合
			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				resGetNoticeDetail = sZWP1900Service.getNoticeDetail(mapParam.get(RequestParam.lnHAlsokNotice.getValue()).toString());

			// アカウント種別が、ＧＨＳの場合
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) { 
				// 7-2.B)ALSOKお知らせ情報の取得
				// リクエスト情報のアカウント論理番号が契約先アカウントの場合
				if (acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
					// メール送信情報の取得する
					// 7-2.C)契約先アカウントのALSOKお知らせ送信情報の取得
					resGetNoticeDetail = sZWP1900GhsService.getNoticeDetailGHSKeiyk(mapParam.get(RequestParam.lnHAlsokNotice.getValue()).toString(),
							mapParam.get(RequestParam.acntID.getValue()).toString());

				// リクエスト情報のアカウント論理番号が利用者アカウントの場合
				} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER)) {
					// メール送信情報の取得する
					// 7-2.D)利用者アカウントのALSOKお知らせ送信情報の取得
					resGetNoticeDetail = sZWP1900GhsService.getNoticeDetailGHSUser(mapParam.get(RequestParam.lnHAlsokNotice.getValue()).toString(),
							mapParam.get(RequestParam.acntID.getValue()).toString());
				}
			}

			// お知らせ情報のチェックを行う
			// レコードが取得できない場合
			if (null == resGetNoticeDetail) {
				resGetNoticeDetail = new ResGetNoticeDetail();

				// エラーメッセージを設定して遷移元画面に遷移する
				jsonResult = G6Common.messageSearchHandler(resGetNoticeDetail, 
						G6Constant.FAIL_POPUP_CD, ErrorKey.NO_SEARCH_RESULT_FOUND.getValue(), ErrorKey.SCREEN_TITLE_SZWP1900.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1900Controller.getNoticeDetail()");
				return jsonResult;
			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//			// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//			final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//			hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP1900.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm, DateTimeCommon.getCurrentDate());
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());										// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);										// アカウント名
			hUserOperationLogModel.setLnKeibi(null);										// 警備先論理番号
			hUserOperationLogModel.setLnKbChiku(null);									// 警備先地区論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP1900.getValueForOperationLog());	// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, acntType);
			
			// 取得内容を応答する
			resGetNoticeDetail.setErrorCode(G6Constant.SUCCESS_CD);
			
			//デコード済acntIDを設定したJWT認証トークンを付与
			resGetNoticeDetail.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
			
			jsonResult = G6Common.parseJSON(resGetNoticeDetail, acntLanguage);

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			resGetNoticeDetail = new ResGetNoticeDetail();
			jsonResult = G6Common.messageLogHandler(resGetNoticeDetail, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetNoticeDetail, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetNoticeDetail, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetNoticeDetail, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetNoticeDetail, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1900Controller.getNoticeDetail()");
		return jsonResult;
	}
}
