package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the W_QUE_AC_ML_TRIG database table.
 * 
 */
@Entity
@Table(name="W_QUE_AC_ML_TRIG")
@NamedQuery(name="WQueAcMlTrigModel.findAll", query="SELECT w FROM WQueAcMlTrigModel w")
public class WQueAcMlTrigModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_QUE_AC_ML_TRIG")
	private String lnQueAcMlTrig;

	@Column(name="ACNT_TYPE")
	private String acntType;

	@Column(name="ID_INSERT")
	private String idInsert;

	@Column(name="ID_UPDATE")
	private String idUpdate;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="LN_ACNT")
	private String lnAcnt;

	@Column(name="LN_SEND_TGT")
	private String lnSendTgt;

	@Column(name="ML_KIND")
	private String mlKind;

	@Column(name="STS")
	private String sts;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public WQueAcMlTrigModel() {
	}

	public String getLnQueAcMlTrig() {
		return this.lnQueAcMlTrig;
	}

	public void setLnQueAcMlTrig(String lnQueAcMlTrig) {
		this.lnQueAcMlTrig = lnQueAcMlTrig;
	}

	public String getAcntType() {
		return this.acntType;
	}

	public void setAcntType(String acntType) {
		this.acntType = acntType;
	}

	public String getIdInsert() {
		return this.idInsert;
	}

	public void setIdInsert(String idInsert) {
		this.idInsert = idInsert;
	}

	public String getIdUpdate() {
		return this.idUpdate;
	}

	public void setIdUpdate(String idUpdate) {
		this.idUpdate = idUpdate;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getLnAcnt() {
		return this.lnAcnt;
	}

	public void setLnAcnt(String lnAcnt) {
		this.lnAcnt = lnAcnt;
	}

	public String getLnSendTgt() {
		return this.lnSendTgt;
	}

	public void setLnSendTgt(String lnSendTgt) {
		this.lnSendTgt = lnSendTgt;
	}

	public String getMlKind() {
		return this.mlKind;
	}

	public void setMlKind(String mlKind) {
		this.mlKind = mlKind;
	}

	public String getSts() {
		return this.sts;
	}

	public void setSts(String sts) {
		this.sts = sts;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}