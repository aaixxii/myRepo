package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.ResGetContactUs;
import com.nec.jp.G6Smartphone.SO.ResGetOtherInfo;
import com.nec.jp.G6Smartphone.SO.ResGetSecurityInfo;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.com.SZWP2000ComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP2000Service;
import com.nec.jp.G6Smartphone.service.ghs.SZWP2000GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;

@Controller
public class SZWP2000Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP2000Controller.class);

	//JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
	@Value("${ghsFuncOnly}")
	String ghsFuncOnly;
    
	@Autowired
	CommonService commonService;
	@Autowired
	CommonComService commonComService;
	@Autowired
	SZWP2000Service sZWP2000Service;
	@Autowired
	SZWP2000ComService sZWP2000ComService;
	@Autowired
	SZWP2000GhsService sZWP2000GhsService;

	/*
	 * Get data from R_KEIBI, K_GC, K_JIGYOU table
	 * @param: acntID, lnKeibi
	 * return: object ResGetContactUs as JSON
	 */
	@RequestMapping(value = "/getContactUs", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String getContactUs(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP2000Controller.getContactUs()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		Map<String, Object> mapParam = new HashMap<String, Object>();
		ResGetContactUs resGetContactUs = new ResGetContactUs();
		ResGetSecurityInfo resGetSecurityInfo = new ResGetSecurityInfo();
		String remoteEscortInfo = "";
		String acntType = "";
		String gcTelNum = "";
		String remoteTelNum = "";
		String denkeiNum = "";
		ResGetOtherInfo resGetOtherInfo = new ResGetOtherInfo();
		String acntNm = "";

		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

			//認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));
            
            // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resGetContactUs, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2000Controller.getContactUs()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resGetContactUs, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2000Controller.getContactUs()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
            
			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 4) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetContactUs, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2000Controller.getContactUs()");
				return jsonResult;
			}
			// Build require parameters
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.acntSbt.getValue());
					add(RequestParam.lnKeibi.getValue());
				}
			};
			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resGetContactUs, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2000Controller.getContactUs()");
				return jsonResult;
			}

			// リクエスト情報取得
			acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();

			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resGetContactUs, G6Constant.FAIL_POPUP_CD,
						ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2000Controller.getContactUs()");
				return jsonResult;
			}

			// TODO SZWP2000：利用者の権限検証
			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);

			// アカウント種別が、次期警備の場合
			if (G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM.equals(acntType)) {
				// 7-2.A)警備先情報取得
				resGetSecurityInfo = sZWP2000Service.getSecurityInfo(mapParam.get(RequestParam.lnKeibi.getValue()).toString());
				
				// リモートエスコートの契約情報取得
				remoteEscortInfo = commonService.getKeiykServiceInfo(mapParam.get(RequestParam.lnKeibi.getValue()).toString(), G6Constant.CD_SERVICE_TEIKYO.REMOTE_ESCORT);

				if (null != resGetSecurityInfo) {
					// 7-2.B)ALSOKガードセンター情報取得
					gcTelNum = sZWP2000ComService.getALSOKGuardCenterInfo(resGetSecurityInfo.getGcCd());
					// 7-2.C)事業所情報取得
					// リモートエスコートの契約有無を確認 + 機能制限（GHS FUNCTION ONLY FLG）の確認
					if ( remoteEscortInfo.equals("1") && !(ghsFuncOnly.equals(G6Constant.FLG_ENABLE)) ) {
						remoteTelNum = sZWP2000ComService.getBusinessInfo(resGetSecurityInfo.getJisshiJigyouCd());
					} else {
						// リモートエスコート（契約無）の場合、問い合わせ先を表示しない。
						remoteTelNum = "";
					}

					// 7-2.F)その他情報取得
					resGetOtherInfo = sZWP2000ComService.getOtherInfo(resGetSecurityInfo.getJuchuJigyouCd());
				}

			// アカウント種別が、ＧＨＳの場合
			} else if (G6CodeConsts.CD027.GHS_THE_USER.equals(acntType) || G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION.equals(acntType)) {
				// 7-2.D)ALSOKガードセンター情報取得
				resGetOtherInfo = sZWP2000GhsService.getALSOKGuardCenterInfoGHS(mapParam.get(RequestParam.lnKeibi.getValue()).toString());

				// お客様番号（電計番号）を取得する
				// 7-2.E)電計番号取得
				denkeiNum = sZWP2000GhsService.getDenkeiNumGHS(mapParam.get(RequestParam.lnKeibi.getValue()).toString());
			}

			// 操作履歴の出力
			// 利用者の操作履歴を出力する。
			// 共通関数「操作履歴出力関数」にて、操作履歴を出力する。
//			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
//			// hUserOperationLogModel.setLnLogUserOperation(commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION));
//			final String lnLogUserOperation = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//			hUserOperationLogModel.setLnLogUserOperation(lnLogUserOperation);
//			hUserOperationLogModel.setDispId(ScreenID.SZWP2000.getSlashValue());
//			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);
//			commonService.entryUserOperation(hUserOperationLogModel, mapParam.get(RequestParam.acntID.getValue()).toString(), acntNm, DateTimeCommon.getCurrentDate());
			HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
			hUserOperationLogModel.setInsertId(mapParam.get(RequestParam.acntID.getValue()).toString());										// アカウントID
			hUserOperationLogModel.setInsertNm(acntNm);										// アカウント名
			hUserOperationLogModel.setLnKeibi(mapParam.get(RequestParam.lnKeibi.getValue()).toString());										// 警備先論理番号
			hUserOperationLogModel.setLnKbChiku(null);									// 警備先地区論理番号
			hUserOperationLogModel.setDispId(ScreenID.SZWP2000.getValueForOperationLog());	// 操作画面ID
			hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
			commonService.entryUserOperation(hUserOperationLogModel, acntType);
			
			resGetContactUs.setErrorCode(G6Constant.SUCCESS_CD);

			// アカウント種別が、次期警備の場合
			if (G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM.equals(acntType)) {
				resGetContactUs.setGcTelNum(gcTelNum);
				resGetContactUs.setRemoteTelNum(remoteTelNum);
				resGetContactUs.setJigyouNm(resGetOtherInfo.getJigyouNm());
				resGetContactUs.setSonotaTelNum(resGetOtherInfo.getTelNum());
				resGetContactUs.setCustomerNum(resGetSecurityInfo.getCustomerNum());

			// アカウント種別が、ＧＨＳの場合
			} else if (G6CodeConsts.CD027.GHS_THE_USER.equals(acntType) || G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION.equals(acntType)) {
				resGetContactUs.setGcTelNum(resGetOtherInfo.getTelNum());
				resGetContactUs.setJigyouNm(resGetOtherInfo.getJigyouNm());
				resGetContactUs.setCustomerNum(denkeiNum);
			}

			// 取得内容を応答する
			// デコード済acntIDを設定したJWT認証トークンを付与
			resGetContactUs.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
			
			jsonResult = G6Common.parseJSON(resGetContactUs, acntLanguage);
			
		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resGetContactUs, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
		} catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resGetContactUs, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resGetContactUs, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
        } catch (Exception e) {
        	// 例外発生時にログ出力
        	appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
        	
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resGetContactUs, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resGetContactUs, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP2000Controller.getContactUs()");
		return jsonResult;
	}
}
