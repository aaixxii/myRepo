package com.nec.jp.G6Smartphone.dao.img;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.CameraDataSubModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP2200ImgDao {

	@PersistenceContext(unitName="imgPersistence")
	private EntityManager entityManager;

	public CameraDataSubModel getLiveImageSound(String lnDev) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(live.SAVE_PATH, '') as savePath,");
		strBuilder.append("			IFNULL(live.FILE_NM, '') as fileNm,");
		strBuilder.append("			live.LN_LIVE_IMGVOC as lnImgVoc");
		strBuilder.append(" FROM	I_MNG_LIVE live");
		strBuilder.append(" WHERE	live.DEL_FLG = :delFlg");
		strBuilder.append("			AND live.LN_DEV = :lnDev");
		strBuilder.append(" ORDER BY live.REC_STT_TSTM DESC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "CameraDataSubModelResult");
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);
		query.setParameter("lnDev", lnDev);
		query.setMaxResults(1);

		return (CameraDataSubModel) query.getSingleResult();
	}
}
