package com.nec.jp.G6Smartphone.dao.g6;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.ResGetSecurityInfo;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.utility.G6Constant;

@Repository
public class SZWP2000Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	public ResGetSecurityInfo getSecurityInfo (String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(" SELECT		IFNULL(rkeibi.JUCHU_JIGYOU_CD, '') 		as juchuJigyouCd");
		strBuilder.append(", 			IFNULL(rkeibi.JISSHI_JIGYOU_CD, '') 	as jisshiJigyouCd");
		strBuilder.append(", 			IFNULL(rkeibi.GC_CD, '') 				as gcCd");
		strBuilder.append(", 			rkeibi.CUSTOMER_NUM2 					as customerNum");
		strBuilder.append(", 			IFNULL(rkeibi.PIC_SURVEILLANCE_FLG, '') as picSurveillanceFlg");
		strBuilder.append(" FROM		R_KEIBI rkeibi");
		strBuilder.append(" WHERE		rkeibi.DEL_FLG  = :delFlg");
		strBuilder.append(" AND			rkeibi.LN_KEIBI = :lnKeibi");

		Query query = entityManager.createNativeQuery(strBuilder.toString(),"ResGetSecurityInfoResult");
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);

		return (ResGetSecurityInfo) query.getSingleResult();
	}
}
