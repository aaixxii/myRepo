package com.nec.jp.G6Smartphone.dao.ghs;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class SZWP1500GhsDao {

	@PersistenceContext(unitName="ghsPersistence")
	private EntityManager entityManager;

	public String getProcessResultGHS(String lnKbInf) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	IFNULL(BODY, '')");
		strBuilder.append(" FROM	E_KB_NOTICE");
		strBuilder.append(" WHERE	LN_KB_INF = :lnKbInf");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnKbInf", lnKbInf);
		query.setMaxResults(1);

		return (String) query.getSingleResult();
	}
}
