package com.nec.jp.G6Smartphone.service.g6;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataSubModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP1100Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1100Service {

	@Autowired
	SZWP1100Dao sZWP1100Dao;

	public String getElectricNum(String lnKeibi) throws ApplicationException {
		try {
			String denkeiNum = sZWP1100Dao.getElectricNum(lnKeibi);

			return denkeiNum;

		} catch (NoResultException noResultE) {
			return "";

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	//public RCtlDevDataSubModel getGoukiSerial(String lnKeibi, String lnKbChiku) throws ApplicationException {
	public RCtlDevDataSubModel getGoukiSerial(String lnKeibi) throws ApplicationException {
		try {
			// RCtlDevDataSubModel rCtlDevDataModel = sZWP1100Dao.getGoukiSerial(lnKeibi, lnKbChiku);
		    RCtlDevDataSubModel rCtlDevDataModel = sZWP1100Dao.getGoukiSerial(lnKeibi);
			return rCtlDevDataModel;

		} catch (NoResultException noResultE) {
			return new RCtlDevDataSubModel();

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public RKbChikuDataSubModel getDistrictInfo(String lnKeibi) throws ApplicationException {
		try {
			RKbChikuDataSubModel rCtlDevDataModel = sZWP1100Dao.getDistrictInfo(lnKeibi);

			return rCtlDevDataModel;

		} catch (NoResultException noResultE) {
			return new RKbChikuDataSubModel();

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getDeviceSts(String lnDev) throws ApplicationException {
		try {
			String deviceSts = sZWP1100Dao.getDeviceSts(lnDev);

			return (deviceSts == null) ? "" : deviceSts;

		} catch (NoResultException noResultE) {
			return "";

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getCmdSts(String cmdSeqNum) throws ApplicationException {
		try {
			String cmdSts = sZWP1100Dao.getCmdSts(cmdSeqNum);

			return cmdSts;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
