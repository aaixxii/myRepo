package com.nec.jp.G6Smartphone.service.g6;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.AcntUserInfoModel;
import com.nec.jp.G6Smartphone.SO.ItmesAuthInfoModel;
import com.nec.jp.G6Smartphone.SO.ResMenuPassInf;
import com.nec.jp.G6Smartphone.dao.g6.SZWP0200Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP0200Service {

	@Autowired
	private SZWP0200Dao sZWP0200Dao;

	public ResMenuPassInf getMenuPassInfo(String userId) throws ApplicationException {
		try {
			final ResMenuPassInf menuPassInf = sZWP0200Dao.getMenuPassInfo(userId);
			return menuPassInf;

		} catch (NoResultException noResultE) {
			return new ResMenuPassInf();

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(),
					errorMsg);
		}
	}

	/**
     * メニュー大項目表示権限の取得.
     *
     * @param sysIO
     *            フォーム
     * @return 利用者アカウント情報
     * @throws Exception
     *             ＤＢアクセス例外
     */
	public List<ItmesAuthInfoModel> selectBigItmesAuth(AcntUserInfoModel sysIO) throws ApplicationException {
		try {
			return sZWP0200Dao.selectBigItmesAuth(sysIO.getAcntUserKbn(), sysIO.getLnUserRole());
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	/**
     * メニュー小項目表示権限の取得.
     *
     * @param sysIO
     *            フォーム
     * @return 利用者アカウント情報
     * @throws Exception
     *             ＤＢアクセス例外
     */
	public List<ItmesAuthInfoModel> selectSmallItmesAuth(AcntUserInfoModel sysIO) throws ApplicationException {
		try {
			return sZWP0200Dao.selectSmallItmesAuth(sysIO.getAcntUserKbn(), sysIO.getLnUserRole());
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public String getPrivilegeInfo(String lnAcntUserCommon, String lnUserAcntAuthId)throws ApplicationException {
		try {
			// 権限の設定内容を取得（全地区分をリストで取得）
			List<Character> resultList = sZWP0200Dao.getPrivilegeInfo(lnAcntUserCommon, lnUserAcntAuthId);
			
			// 設定内容が全地区で0（×）の場合は0を返し、１つでも0以外があれば2を返す
			boolean isAllZero = resultList.stream().allMatch(x -> x == '0');
			if (isAllZero) {
				// 全地区で0の場合
				return "0";
				
			} else {
				// 1地区でも0以外がある場合
				return "2";
			}
			
		} catch (NoResultException noResultE) {
			return "0";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public String getCamCountInfo(String lnKeibi)throws ApplicationException {
		try {
			return sZWP0200Dao.getCamCountInfo(lnKeibi);
		} catch (NoResultException noResultE) {
			return "0";
		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);
			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
