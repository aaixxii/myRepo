package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.SdKobetuDataModel;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;

@Repository
public class SZWP1300Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<SdKobetuDataModel> getDistrictPulldownInfo(String acntID, String lnKeibi) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT  IFNULL(rkc.SD_KOBETU_NM, '') as sdKobetuNm,");
		strBuilder.append("			rkc.CHIKU as chiku,");
		strBuilder.append("			IFNULL(rkc.SUB_ADDR, '') as subAddr");
		strBuilder.append(" FROM	R_KB_CHIKU rkc");
        strBuilder.append("			INNER JOIN A_USER_OPERATION_HANI A ON A.LN_ACNT_USER_COMMON = :acntID");
        strBuilder.append("			AND ( A.PATH_INF = rkc.PATH_INF");
        strBuilder.append("			   OR A.PATH_INF = LEFT(rkc.PATH_INF, 41)");
        strBuilder.append("			   OR A.PATH_INF = LEFT(rkc.PATH_INF, 20) )");
		strBuilder.append(" WHERE	rkc.LN_KEIBI = :lnKeibi");
		strBuilder.append("			AND rkc.ENTRY_STS = :entrySts");
		strBuilder.append("			AND rkc.DEL_FLG = :delFlg");
		strBuilder.append(" ORDER BY rkc.SUB_ADDR ASC");

		Query query = entityManager.createNativeQuery(strBuilder.toString(), "SdKobetuDataModelResult");
		query.setParameter("acntID", acntID);
		query.setParameter("lnKeibi", lnKeibi);
		query.setParameter("entrySts", G6CodeConsts.CD031.REGISTERED);
		query.setParameter("delFlg", G6CodeConsts.CD161.NOT_DELETED);

		return (List<SdKobetuDataModel>) query.getResultList();
	}
}
