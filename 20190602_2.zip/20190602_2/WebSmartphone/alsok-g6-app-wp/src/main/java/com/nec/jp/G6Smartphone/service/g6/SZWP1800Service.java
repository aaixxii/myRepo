package com.nec.jp.G6Smartphone.service.g6;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.HAlsokNoticeDataModel;
import com.nec.jp.G6Smartphone.dao.g6.SZWP1800Dao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1800Service {

	@Autowired
	SZWP1800Dao sZWP1800Dao;

	public List<HAlsokNoticeDataModel> getNoticeList(Date dtFrom, Date dtTo, int offset, int limitRowNum) throws ApplicationException {
		try {
			List<HAlsokNoticeDataModel> hAlsokNoticeDataModelLst = sZWP1800Dao.getNoticeList(dtFrom, dtTo, offset, limitRowNum);

			return hAlsokNoticeDataModelLst;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public int getTotalRow(Date dateFrom, Date dateTo) throws ApplicationException {
		try {
			return Integer.parseInt(sZWP1800Dao.getTotalRow(dateFrom, dateTo));
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
