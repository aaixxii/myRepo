package com.nec.jp.G6Smartphone.SO;

public class HistoryDataModel {

	private String sendTs;			// 日時
	private String sdKobetuNm;		// 地区名称
	private String sigKind2;		// 種別
	private String sigKind1;		// 警備情報
	private String operationUser;	// 操作者
	private String rmKind;			// リモート種別
	private String body;			// メール
	private String sigNm;			// 信号名称
	private String lnKbInf;			// 警備情報論理番号
	private String kbAreaNm;		// 警備エリア名称
	private String cardKoteiID;		// カード番号
	private String lnJian;			// LN_事案論理番号

	public HistoryDataModel() {
		this.sendTs = "";
		this.sdKobetuNm = "";
		this.sigKind2 = "";
		this.sigKind1 = "";
		this.operationUser = "";
		this.rmKind = "";
		this.body = "";
		this.sigNm = "";
		this.lnKbInf = "";
		this.kbAreaNm = "";
		this.cardKoteiID = "";
		this.lnJian = "";
	}

	public HistoryDataModel(String sendTs, String sdKobetuNm, String sigKind2, String sigKind1, String operationUser,
			String rmKind, String body, String sigNm, String lnKbInf, String kbAreaNm, String cardKoteiID, String lnJian) {
		this.sendTs = sendTs;
		this.sdKobetuNm = sdKobetuNm;
		this.sigKind2 = sigKind2;
		this.sigKind1 = sigKind1;
		this.operationUser = operationUser;
		this.rmKind = rmKind;
		this.body = body;
		this.sigNm = sigNm;
		this.lnKbInf = lnKbInf;
		this.kbAreaNm = kbAreaNm;
		this.cardKoteiID = cardKoteiID;
		this.lnJian = lnJian;
	}

	public String getSendTs() {
		return sendTs;
	}

	public void setSendTs(String sendTs) {
		this.sendTs = sendTs;
	}

	public String getSdKobetuNm() {
		return sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}

	public String getSigKind2() {
		return sigKind2;
	}

	public void setSigKind2(String sigKind2) {
		this.sigKind2 = sigKind2;
	}

	public String getSigKind1() {
		return sigKind1;
	}

	public void setSigKind1(String sigKind1) {
		this.sigKind1 = sigKind1;
	}

	public String getOperationUser() {
		return operationUser;
	}

	public void setOperationUser(String operationUser) {
		this.operationUser = operationUser;
	}

	public String getRmKind() {
		return rmKind;
	}

	public void setRmKind(String rmKind) {
		this.rmKind = rmKind;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getLnKbInf() {
		return lnKbInf;
	}

	public void setLnKbInf(String lnKbInf) {
		this.lnKbInf = lnKbInf;
	}

	public String getKbAreaNm() {
		return kbAreaNm;
	}

	public void setKbAreaNm(String kbAreaNm) {
		this.kbAreaNm = kbAreaNm;
	}

	public String getCardKoteiID() {
		return cardKoteiID;
	}

	public void setCardKoteiID(String cardKoteiID) {
		this.cardKoteiID = cardKoteiID;
	}

	public String getSigNm() {
		return sigNm;
	}

	public void setSigNm(String sigNm) {
		this.sigNm = sigNm;
	}

	public String getLnJian() {
		return lnJian;
	}

	public void setLnJian(String lnJian) {
		this.lnJian = lnJian;
	}
}
