package com.nec.jp.G6Smartphone.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.nec.jp.G6Smartphone.SO.G6ACntModel;
import com.nec.jp.G6Smartphone.SO.GHSACntModel;
import com.nec.jp.G6Smartphone.SO.KeibisakiInfo;
import com.nec.jp.G6Smartphone.SO.RKeibiDataModel;
import com.nec.jp.G6Smartphone.SO.ResGetOtherInfo;
import com.nec.jp.G6Smartphone.SO.ResGetSecurityInfo;


/**
 * The persistent class for the R_KEIBI database table.
 * 
 */
@SqlResultSetMappings({
	@SqlResultSetMapping(name="RKeibiDataModelResult",
		classes = {
			@ConstructorResult(
				targetClass = RKeibiDataModel.class,
				columns = {
					@ColumnResult(name = "lnKeibi"),
					@ColumnResult(name = "keibiName1"),
					@ColumnResult(name = "keibiAddr1")
				}
			)
		}
	),
	
   @SqlResultSetMapping(name="KeibisakiInfoResult",
       classes = {
       @ConstructorResult(
           targetClass = KeibisakiInfo.class,
           columns = {
               @ColumnResult(name = "lnKeibi"),
               @ColumnResult(name = "keibiNm"),
               @ColumnResult(name = "keibiAddr"),
               @ColumnResult(name = "lnKeiyk"),
               @ColumnResult(name = "keiykNm")
               }
           )
       }
   ),
	   
	   
	@SqlResultSetMapping(name="ResGetSecurityInfoResult",
		classes = {
			@ConstructorResult(
				targetClass = ResGetSecurityInfo.class,
				columns = {
					@ColumnResult(name = "juchuJigyouCd"),
					@ColumnResult(name = "jisshiJigyouCd"),
					@ColumnResult(name = "gcCd"),
					@ColumnResult(name = "customerNum"),
					@ColumnResult(name = "picSurveillanceFlg")
				}
			)
		}
	),
	@SqlResultSetMapping(name="ResGetOtherInfoResult",
		classes = {
			@ConstructorResult(
				targetClass = ResGetOtherInfo.class,
				columns = {
					@ColumnResult(name = "telNum"),
					@ColumnResult(name = "jigyouNm")
				}
			)
		}
	),
	@SqlResultSetMapping(name="G6ACntInfoResult",
		classes = {
			@ConstructorResult(
				targetClass = G6ACntModel.class,
				columns = {
					@ColumnResult(name = "g6AcntNo"),
					@ColumnResult(name = "mlAddr"),
					@ColumnResult(name = "g5AcntNo")
				}
			)
		}
	),
	@SqlResultSetMapping(name="GHSACntInfoResult",
		classes = {
			@ConstructorResult(
				targetClass = GHSACntModel.class,
				columns = {
					@ColumnResult(name = "ghsAcntNo"),
					@ColumnResult(name = "mlAddr"),
				}
			)
		}
	),
	@SqlResultSetMapping(name="G6KeibisakiInfoResult",
       classes = {
       @ConstructorResult(
           targetClass = KeibisakiInfo.class,
           columns = {
                       @ColumnResult(name = "lnKeibi"),
                       @ColumnResult(name = "keibiNm1"),
                       @ColumnResult(name = "keibiAddr"),
                       @ColumnResult(name = "lnKeiyk"),
                       @ColumnResult(name = "keiykNm"),
                       @ColumnResult(name = "lnAcntUserCommon"),
                       @ColumnResult(name = "pathSlash"),
                       @ColumnResult(name = "systemId"),
                       @ColumnResult(name = "keibiLength"),
                       @ColumnResult(name = "numLength")
               }
           )
       }
   ),
   @SqlResultSetMapping(name="GhsKeibisakiInfoResult",
   classes = {
   @ConstructorResult(
       targetClass = KeibisakiInfo.class,
       columns = {
           @ColumnResult(name = "lnKeibi"),
           @ColumnResult(name = "keibiNm"),
           @ColumnResult(name = "keibiAddr"),
           @ColumnResult(name = "lnKeiyk"),
           @ColumnResult(name = "keiykNm"),
           @ColumnResult(name = "lnAcntUserCommon"),
           @ColumnResult(name = "systemId")
         }
       )
   }
   ),
})
@Entity
@Table(name="R_KEIBI")
@NamedQuery(name="RKeibiModel.findAll", query="SELECT r FROM RKeibiModel r")
public class RKeibiModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LN_KEIBI")
	private String lnKeibi;

	@Column(name="ADDR_CD")
	private String addrCd;

	@Column(name="AREA_CD")
	private String areaCd;

	@Column(name="BLD_KOZO_KIND")
	private String bldKozoKind;

	@Column(name="BLD_STAT")
	private String bldStat;

	@Column(name="CUSTOMER_NUM1")
	private String customerNum1;

	@Column(name="CUSTOMER_NUM2")
	private String customerNum2;

	@Column(name="CUSTOMER_NUM3")
	private String customerNum3;

	@Column(name="DEL_FLG")
	private String delFlg;

	@Column(name="EIFYOU_TM_2")
	private String eifyouTm2;

	@Column(name="EIGYOU_TM_1")
	private String eigyouTm1;

	@Column(name="EIGYOU_TM_3")
	private String eigyouTm3;

	@Column(name="FIRE_CALL_FLG")
	private String fireCallFlg;

	@Column(name="FIRE_NUM")
	private String fireNum;

	@Column(name="FIRST_KEIBI_SIG_RECV_FLG")
	private String firstKeibiSigRecvFlg;

	@Column(name="FW_SET_FLG")
	private String fwSetFlg;

	@Column(name="GC_CD")
	private String gcCd;

	@Column(name="GSHS_FLG")
	private String gshsFlg;

	@Column(name="GYOUSYU_ID")
	private String gyousyuId;

	@Column(name="INSERT_ID")
	private String insertId;

	@Column(name="INSERT_NM")
	private String insertNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="INSERT_TS")
	private Date insertTs;

	@Column(name="JIGYO_JISSEKI_CD")
	private String jigyoJissekiCd;

	@Column(name="JIGYO_SEIKYU_CD")
	private String jigyoSeikyuCd;

	@Column(name="JIGYO_TOIAWASE_CD")
	private String jigyoToiawaseCd;

	@Column(name="JISSHI_JIGYOU_CD")
	private String jisshiJigyouCd;

	@Column(name="JUCHU_JIGYOU_CD")
	private String juchuJigyouCd;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="KAIYAKU_DATE")
	private Date kaiyakuDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="KAIYAKU_YOTEI_DATE")
	private Date kaiyakuYoteiDate;

	@Column(name="KEIBI_ADDR_1")
	private String keibiAddr1;

	@Column(name="KEIBI_ADDR_2")
	private String keibiAddr2;

	@Column(name="KEIBI_ADDR_KANA")
	private String keibiAddrKana;

	@Column(name="KEIBI_NAME1")
	private String keibiName1;

	@Column(name="KEIBI_NAME1_KANA")
	private String keibiName1Kana;

	@Column(name="KEIBI_NAME2")
	private String keibiName2;

	@Column(name="KEIBI_NAME2_KANA")
	private String keibiName2Kana;

	@Column(name="KEIBI_PNAME1_KANA")
	private String keibiPname1Kana;

	@Column(name="KEIBI_PNAME2_KANA")
	private String keibiPname2Kana;

	@Column(name="KEIBI_PNAME3_KANA")
	private String keibiPname3Kana;

	@Column(name="KEIBI_TEL_NUM")
	private String keibiTelNum;

	@Column(name="KEIBISAKI_ABBR_NM")
	private String keibisakiAbbrNm;

	@Column(name="KEIYAKU_KIND1")
	private String keiyakuKind1;

	@Column(name="KEIYAKU_KIND2")
	private String keiyakuKind2;

	@Column(name="KYORI")
	private String kyori;

	@Column(name="LN_BUKKEN")
	private String lnBukken;

	@Column(name="PATH_INF")
	private String pathInf;

	@Column(name="PIC_SURVEILLANCE_FLG")
	private String picSurveillanceFlg;

	@Column(name="POLI_CALL_FLG")
	private String poliCallFlg;

	@Column(name="POST_NUM")
	private String postNum;

	@Column(name="ROTEI")
	private String rotei;

	@Column(name="SAME_AREA_FLG")
	private String sameAreaFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="SERVICE_DATE")
	private Date serviceDate;

	@Column(name="SIG_2_VIDEO_GET_FLG")
	private String sig2VideoGetFlg;

	@Column(name="SINPO_FLG")
	private String sinpoFlg;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="START_DATE")
	private Date startDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="START_KEIBI_DATE")
	private Date startKeibiDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="START_YOTEI_TS")
	private Date startYoteiTs;

	@Column(name="STORE_TYPE")
	private String storeType;

	@Column(name="SYOYOU")
	private String syoyou;

	@Column(name="UNYO_STS")
	private String unyoSts;

	@Column(name="UPDATE_ID")
	private String updateId;

	@Column(name="UPDATE_NM")
	private String updateNm;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TS")
	private Date updateTs;

	public RKeibiModel() {
	}

	public String getLnKeibi() {
		return this.lnKeibi;
	}

	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	public String getAddrCd() {
		return this.addrCd;
	}

	public void setAddrCd(String addrCd) {
		this.addrCd = addrCd;
	}

	public String getAreaCd() {
		return this.areaCd;
	}

	public void setAreaCd(String areaCd) {
		this.areaCd = areaCd;
	}

	public String getBldKozoKind() {
		return this.bldKozoKind;
	}

	public void setBldKozoKind(String bldKozoKind) {
		this.bldKozoKind = bldKozoKind;
	}

	public String getBldStat() {
		return this.bldStat;
	}

	public void setBldStat(String bldStat) {
		this.bldStat = bldStat;
	}

	public String getCustomerNum1() {
		return this.customerNum1;
	}

	public void setCustomerNum1(String customerNum1) {
		this.customerNum1 = customerNum1;
	}

	public String getCustomerNum2() {
		return this.customerNum2;
	}

	public void setCustomerNum2(String customerNum2) {
		this.customerNum2 = customerNum2;
	}

	public String getCustomerNum3() {
		return this.customerNum3;
	}

	public void setCustomerNum3(String customerNum3) {
		this.customerNum3 = customerNum3;
	}

	public String getDelFlg() {
		return this.delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getEifyouTm2() {
		return this.eifyouTm2;
	}

	public void setEifyouTm2(String eifyouTm2) {
		this.eifyouTm2 = eifyouTm2;
	}

	public String getEigyouTm1() {
		return this.eigyouTm1;
	}

	public void setEigyouTm1(String eigyouTm1) {
		this.eigyouTm1 = eigyouTm1;
	}

	public String getEigyouTm3() {
		return this.eigyouTm3;
	}

	public void setEigyouTm3(String eigyouTm3) {
		this.eigyouTm3 = eigyouTm3;
	}

	public String getFireCallFlg() {
		return this.fireCallFlg;
	}

	public void setFireCallFlg(String fireCallFlg) {
		this.fireCallFlg = fireCallFlg;
	}

	public String getFireNum() {
		return this.fireNum;
	}

	public void setFireNum(String fireNum) {
		this.fireNum = fireNum;
	}

	public String getFirstKeibiSigRecvFlg() {
		return this.firstKeibiSigRecvFlg;
	}

	public void setFirstKeibiSigRecvFlg(String firstKeibiSigRecvFlg) {
		this.firstKeibiSigRecvFlg = firstKeibiSigRecvFlg;
	}

	public String getFwSetFlg() {
		return this.fwSetFlg;
	}

	public void setFwSetFlg(String fwSetFlg) {
		this.fwSetFlg = fwSetFlg;
	}

	public String getGcCd() {
		return this.gcCd;
	}

	public void setGcCd(String gcCd) {
		this.gcCd = gcCd;
	}

	public String getGshsFlg() {
		return this.gshsFlg;
	}

	public void setGshsFlg(String gshsFlg) {
		this.gshsFlg = gshsFlg;
	}

	public String getGyousyuId() {
		return this.gyousyuId;
	}

	public void setGyousyuId(String gyousyuId) {
		this.gyousyuId = gyousyuId;
	}

	public String getInsertId() {
		return this.insertId;
	}

	public void setInsertId(String insertId) {
		this.insertId = insertId;
	}

	public String getInsertNm() {
		return this.insertNm;
	}

	public void setInsertNm(String insertNm) {
		this.insertNm = insertNm;
	}

	public Date getInsertTs() {
		return this.insertTs;
	}

	public void setInsertTs(Date insertTs) {
		this.insertTs = insertTs;
	}

	public String getJigyoJissekiCd() {
		return this.jigyoJissekiCd;
	}

	public void setJigyoJissekiCd(String jigyoJissekiCd) {
		this.jigyoJissekiCd = jigyoJissekiCd;
	}

	public String getJigyoSeikyuCd() {
		return this.jigyoSeikyuCd;
	}

	public void setJigyoSeikyuCd(String jigyoSeikyuCd) {
		this.jigyoSeikyuCd = jigyoSeikyuCd;
	}

	public String getJigyoToiawaseCd() {
		return this.jigyoToiawaseCd;
	}

	public void setJigyoToiawaseCd(String jigyoToiawaseCd) {
		this.jigyoToiawaseCd = jigyoToiawaseCd;
	}

	public String getJisshiJigyouCd() {
		return this.jisshiJigyouCd;
	}

	public void setJisshiJigyouCd(String jisshiJigyouCd) {
		this.jisshiJigyouCd = jisshiJigyouCd;
	}

	public String getJuchuJigyouCd() {
		return this.juchuJigyouCd;
	}

	public void setJuchuJigyouCd(String juchuJigyouCd) {
		this.juchuJigyouCd = juchuJigyouCd;
	}

	public Date getKaiyakuDate() {
		return this.kaiyakuDate;
	}

	public void setKaiyakuDate(Date kaiyakuDate) {
		this.kaiyakuDate = kaiyakuDate;
	}

	public Date getKaiyakuYoteiDate() {
		return this.kaiyakuYoteiDate;
	}

	public void setKaiyakuYoteiDate(Date kaiyakuYoteiDate) {
		this.kaiyakuYoteiDate = kaiyakuYoteiDate;
	}

	public String getKeibiAddr1() {
		return this.keibiAddr1;
	}

	public void setKeibiAddr1(String keibiAddr1) {
		this.keibiAddr1 = keibiAddr1;
	}

	public String getKeibiAddr2() {
		return this.keibiAddr2;
	}

	public void setKeibiAddr2(String keibiAddr2) {
		this.keibiAddr2 = keibiAddr2;
	}

	public String getKeibiAddrKana() {
		return this.keibiAddrKana;
	}

	public void setKeibiAddrKana(String keibiAddrKana) {
		this.keibiAddrKana = keibiAddrKana;
	}

	public String getKeibiName1() {
		return this.keibiName1;
	}

	public void setKeibiName1(String keibiName1) {
		this.keibiName1 = keibiName1;
	}

	public String getKeibiName1Kana() {
		return this.keibiName1Kana;
	}

	public void setKeibiName1Kana(String keibiName1Kana) {
		this.keibiName1Kana = keibiName1Kana;
	}

	public String getKeibiName2() {
		return this.keibiName2;
	}

	public void setKeibiName2(String keibiName2) {
		this.keibiName2 = keibiName2;
	}

	public String getKeibiName2Kana() {
		return this.keibiName2Kana;
	}

	public void setKeibiName2Kana(String keibiName2Kana) {
		this.keibiName2Kana = keibiName2Kana;
	}

	public String getKeibiPname1Kana() {
		return this.keibiPname1Kana;
	}

	public void setKeibiPname1Kana(String keibiPname1Kana) {
		this.keibiPname1Kana = keibiPname1Kana;
	}

	public String getKeibiPname2Kana() {
		return this.keibiPname2Kana;
	}

	public void setKeibiPname2Kana(String keibiPname2Kana) {
		this.keibiPname2Kana = keibiPname2Kana;
	}

	public String getKeibiPname3Kana() {
		return this.keibiPname3Kana;
	}

	public void setKeibiPname3Kana(String keibiPname3Kana) {
		this.keibiPname3Kana = keibiPname3Kana;
	}

	public String getKeibiTelNum() {
		return this.keibiTelNum;
	}

	public void setKeibiTelNum(String keibiTelNum) {
		this.keibiTelNum = keibiTelNum;
	}

	public String getKeibisakiAbbrNm() {
		return this.keibisakiAbbrNm;
	}

	public void setKeibisakiAbbrNm(String keibisakiAbbrNm) {
		this.keibisakiAbbrNm = keibisakiAbbrNm;
	}

	public String getKeiyakuKind1() {
		return this.keiyakuKind1;
	}

	public void setKeiyakuKind1(String keiyakuKind1) {
		this.keiyakuKind1 = keiyakuKind1;
	}

	public String getKeiyakuKind2() {
		return this.keiyakuKind2;
	}

	public void setKeiyakuKind2(String keiyakuKind2) {
		this.keiyakuKind2 = keiyakuKind2;
	}

	public String getKyori() {
		return this.kyori;
	}

	public void setKyori(String kyori) {
		this.kyori = kyori;
	}

	public String getLnBukken() {
		return this.lnBukken;
	}

	public void setLnBukken(String lnBukken) {
		this.lnBukken = lnBukken;
	}

	public String getPathInf() {
		return this.pathInf;
	}

	public void setPathInf(String pathInf) {
		this.pathInf = pathInf;
	}

	public String getPicSurveillanceFlg() {
		return this.picSurveillanceFlg;
	}

	public void setPicSurveillanceFlg(String picSurveillanceFlg) {
		this.picSurveillanceFlg = picSurveillanceFlg;
	}

	public String getPoliCallFlg() {
		return this.poliCallFlg;
	}

	public void setPoliCallFlg(String poliCallFlg) {
		this.poliCallFlg = poliCallFlg;
	}

	public String getPostNum() {
		return this.postNum;
	}

	public void setPostNum(String postNum) {
		this.postNum = postNum;
	}

	public String getRotei() {
		return this.rotei;
	}

	public void setRotei(String rotei) {
		this.rotei = rotei;
	}

	public String getSameAreaFlg() {
		return this.sameAreaFlg;
	}

	public void setSameAreaFlg(String sameAreaFlg) {
		this.sameAreaFlg = sameAreaFlg;
	}

	public Date getServiceDate() {
		return this.serviceDate;
	}

	public void setServiceDate(Date serviceDate) {
		this.serviceDate = serviceDate;
	}

	public String getSig2VideoGetFlg() {
		return this.sig2VideoGetFlg;
	}

	public void setSig2VideoGetFlg(String sig2VideoGetFlg) {
		this.sig2VideoGetFlg = sig2VideoGetFlg;
	}

	public String getSinpoFlg() {
		return this.sinpoFlg;
	}

	public void setSinpoFlg(String sinpoFlg) {
		this.sinpoFlg = sinpoFlg;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getStartKeibiDate() {
		return this.startKeibiDate;
	}

	public void setStartKeibiDate(Date startKeibiDate) {
		this.startKeibiDate = startKeibiDate;
	}

	public Date getStartYoteiTs() {
		return this.startYoteiTs;
	}

	public void setStartYoteiTs(Date startYoteiTs) {
		this.startYoteiTs = startYoteiTs;
	}

	public String getStoreType() {
		return this.storeType;
	}

	public void setStoreType(String storeType) {
		this.storeType = storeType;
	}

	public String getSyoyou() {
		return this.syoyou;
	}

	public void setSyoyou(String syoyou) {
		this.syoyou = syoyou;
	}

	public String getUnyoSts() {
		return this.unyoSts;
	}

	public void setUnyoSts(String unyoSts) {
		this.unyoSts = unyoSts;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public String getUpdateNm() {
		return this.updateNm;
	}

	public void setUpdateNm(String updateNm) {
		this.updateNm = updateNm;
	}

	public Date getUpdateTs() {
		return this.updateTs;
	}

	public void setUpdateTs(Date updateTs) {
		this.updateTs = updateTs;
	}

}