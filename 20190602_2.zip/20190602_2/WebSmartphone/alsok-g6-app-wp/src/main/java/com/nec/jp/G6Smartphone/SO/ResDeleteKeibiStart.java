package com.nec.jp.G6Smartphone.SO;

import java.util.ArrayList;
import java.util.List;

import com.nec.jp.G6Smartphone.utility.G6Constant;

public class ResDeleteKeibiStart implements ErrorHandler {

	private String errorCode;						// エラーコード
	private String errorMsg;						// エラーメッセージ
	private String denkei;							// 電計番号
	private String subAddr;							// サブアドレス
	private String gshsFlg;							// GSHSフラグ
	private List<RCtlDevDataModel> rCtlDevItem;

	public ResDeleteKeibiStart() {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.denkei = "";
		this.subAddr = "";
		this.gshsFlg = "";
		this.rCtlDevItem = new ArrayList<RCtlDevDataModel>();
	}

	public ResDeleteKeibiStart(String denkei) {
		this.errorCode = G6Constant.FAIL_POPUP_CD;
		this.errorMsg = "";
		this.denkei = denkei;
		this.subAddr = "";
		this.gshsFlg = "";
		this.rCtlDevItem = new ArrayList<RCtlDevDataModel>();
	}

	public ResDeleteKeibiStart(String errorCode, String errorMsg, String denkei, String subAddr, String gshsFlg,
			List<RCtlDevDataModel> rCtlDevItem) {
		this.errorCode = errorCode;
		this.errorMsg = errorMsg;
		this.denkei = denkei;
		this.subAddr = subAddr;
		this.gshsFlg = gshsFlg;
		this.rCtlDevItem = rCtlDevItem;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getDenkei() {
		return denkei;
	}

	public void setDenkei(String denkei) {
		this.denkei = denkei;
	}

	public String getSubAddr() {
		return subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public List<RCtlDevDataModel> getrCtlDevItem() {
		return rCtlDevItem;
	}

	public void setrCtlDevItem(List<RCtlDevDataModel> rCtlDevItem) {
		this.rCtlDevItem = rCtlDevItem;
	}

	public String getGshsFlg() {
		return gshsFlg;
	}

	public void setGshsFlg(String gshsFlg) {
		this.gshsFlg = gshsFlg;
	}
}
