package com.nec.jp.G6Smartphone.SO;

public class CameraDataModel {

	private String lnDev;			// LN_設置機器論理番号
	private String sdDevNm;			// カメラ名称
	private String sdDevNum;		// 装置番号
	private String lnImgVoc;	// LN_蓄積画像音声論理番号
	private String savePath;		// 保存先
	private String fileNm;			// ファイル名

	public CameraDataModel(String lnDev, String sdDevNm, String sdDevNum) {
		this.lnDev = lnDev;
		this.sdDevNm = sdDevNm;
		this.sdDevNum = sdDevNum;
		this.lnImgVoc = "";
		this.savePath = "";
		this.fileNm = "";
	}

	public String getLnDev() {
		return lnDev;
	}

	public void setLnDev(String lnDev) {
		this.lnDev = lnDev;
	}

	public String getSdDevNm() {
		return sdDevNm;
	}

	public void setSdDevNm(String sdDevNm) {
		this.sdDevNm = sdDevNm;
	}

	public String getSdDevNum() {
		return sdDevNum;
	}

	public void setSdDevNum(String sdDevNum) {
		this.sdDevNum = sdDevNum;
	}

	public String getLnImgVoc() {
		return lnImgVoc;
	}

	public void setLnImgVoc(String lnImgVoc) {
		this.lnImgVoc = lnImgVoc;
	}

	public String getSavePath() {
		return savePath;
	}

	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}

	public String getFileNm() {
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
}
