package com.nec.jp.G6Smartphone.utility;


import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Map;

import net.sf.json.JSONObject;

import org.springframework.beans.BeanUtils;

/**
 * @author 
 */
public class ConvUtil {

    public static boolean convToBool(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof byte[]) {
            return convBitToBool((byte[]) obj);
        }
        if ("1".equals(obj.toString())) {
            return true;
        } else if ("0".equals(obj.toString())) {
            return false;
        } else if ("true".equalsIgnoreCase(obj.toString())) {
            return true;
        } else if ("false".equalsIgnoreCase(obj.toString())) {
            return false;
        }
        return false;
    }
    
    public static boolean convBitToBool(byte[] bytes) {
        if (bytes == null) {
            return false;
        }
        return bytes[0] == 0x01 ? true : false;
    }

    /**
     * 値をDouble型に変換します<BR>
     *
     * @param pValue 判定値
     * @param pintNotFlg 「IS NULL」 か 「IS NOT NULL」 の判定フラグ
     * @return Doubleに変換（変換できない場合は「0」を返します）
     * @author  GaoHang 2011/10/28
     */
    public static double convToDouble(Object pValue) {
        double dblValue = 0;
        if (pValue == null) {
            return dblValue;
        }

        try {
            dblValue = Double.parseDouble(String.valueOf(pValue).trim());
        } catch (Exception e) {
            return dblValue;
        }
        return dblValue;
    }

    /**
     * 値をBigDecimal型に変換します<BR>
     *
     * @param value 判定値
     * @return Decimalに変換（変換できない場合は「0」を返します）
     * @author  GaoHang 2011/10/28
     */
    public static BigDecimal convToDec(Object value) {
        BigDecimal dec = new BigDecimal("0");

        if (value == null) {
            return dec;
        } else {
            try {
                if (value.getClass().isInstance(new Double(0))) {
                    dec = new BigDecimal(((Double) value).toString());
                } else {
                    dec = new BigDecimal(String.valueOf(value).trim());
                }
            } catch (Exception ex) {
                return dec;
            }
        }
        return dec;
    }

    /**
     * 値をLong型に変換します<BR>
     *
     * @param value 判定値
     * @return Longに変換（変換できない場合は「0」を返します）
     * @author  GaoHang 2011/10/28
     */
    public static long convToLong(Object value) {
        long lngValue = 0;

        if (value == null) {
            return lngValue;
        } else {
            try {
                lngValue = Long.parseLong(value.toString().trim());
            } catch (NumberFormatException ex) {
                return lngValue;
            }
        }
        return lngValue;
    }

    /**
     * 値をint型に変換します<BR>
     *
     * @param value 判定値
     * @return intに変換（変換できない場合は「0」を返します）
     * @author  GaoHang 2011/11/21
     */
    public static int convToInt(Object value) {
        int intValue = 0;
        //空データの場合
        if (value == null) {
            return intValue;
        } else {
            try {
                intValue = Integer.parseInt(value.toString().trim());
            } catch (NumberFormatException ex) {
                return intValue;
            } 
            return intValue;
        }
    }

    /**
     * 値をint型に変換します<BR>
     *
     * @param value 判定値
     * @return intに変換（変換できない場合は「0」を返します）
     * @author jinhui 2011/11/21
     */
    public static BigInteger convToBigInteger(Object value) {
        BigInteger intValue = BigInteger.ZERO;
        //空データの場合
        if (value == null) {
            return intValue;
        } else {
            try {
                intValue = BigInteger.valueOf(convToLong(value));
            } catch (NumberFormatException ex) {
                return intValue;
            }
        }
        return intValue;
    }

    public static short convToShort(Object value) {
        short retVal = new Short("0");
        if (value == null) {
            return retVal;
        } else {
            try {
                retVal = Short.parseShort(convToString(value));
            } catch (NumberFormatException ex) {
                return retVal;
            } 
        }
        return retVal;
    }
    
    public static void convMapToBean(Map<String, Object> map, Object obj) {  
          
        try {  
            BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());  
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();  
  
            for (PropertyDescriptor property : propertyDescriptors) {  
                String key = property.getName();  
  
                if (map.containsKey(key)) {  
                    Object value = map.get(key);  
                    // 得到property??的setter方法  
                    Method setter = property.getWriteMethod();  
                    setter.invoke(obj, value);  
                }  
  
            }  
  
        } catch (Exception e) {  
            System.out.println("transMap2Bean Error " + e);  
        }  
  
        return;  
  
    } 
    
    /**
     * Bean copy（org.springframework.beans.BeanUtils）。
     *
     * @param frombean
     * @param toBean 
     */
    public static void copyToBean(Object frombean, Object toBean) {
        BeanUtils.copyProperties(frombean,toBean);
    }

    

    /**
     * 値をString型に変換します。
     *
     * @param obj 入力文字列
     * @return String型の値
     */
    public static String convToString(Object obj) {
        if (obj == null) {
            return "";
        }
        if (StringUtils.isEmpty(obj.toString())) {
            return "";
        }
        return obj.toString();
    }

    /**
     * 空文字列判定
     *
     * @param input 入力文字列
     * @return true/false
     */
    public static boolean isEmpty(String input) {
        if (input == null || "".equals(input)) {
            return true;
        } else {
            return false;
        }
    }

    public static String convClobToString(Clob clob) {
        if (clob == null) {
            return null;
        }
        try{
            Reader reader = clob.getCharacterStream();
            char[] tempChar = new char[(int)clob.length()];
            int i = reader.read(tempChar);
            reader.close();
            if (i > 0) {
                return new String(tempChar);
            }
            
        }catch(IOException e){


        }catch(SQLException es){

        }
        return null;
    }
    
    public static JSONObject convObjectToJSON(Object obj) {
        return JSONObject.fromObject(obj);
    }
}