package com.nec.jp.G6Smartphone.SO;

public class KbChikuDataModel {

	private String lnKbChiku;		// 警備先地区.LN_警備先地区論理番号
	private String subAddr;			// 警備先地区.サブアドレス
	private String sdKobetuNm;		// 警備先地区.警備先地区名称

	public KbChikuDataModel() {
		this.lnKbChiku = "";
		this.subAddr = "";
		this.sdKobetuNm = "";
	}

	public KbChikuDataModel(String lnKbChiku, String subAddr, String sdKobetuNm) {
		this.lnKbChiku = lnKbChiku;
		this.subAddr = subAddr;
		this.sdKobetuNm = sdKobetuNm;
	}

	public String getLnKbChiku() {
		return lnKbChiku;
	}

	public void setLnKbChiku(String lnKbChiku) {
		this.lnKbChiku = lnKbChiku;
	}

	public String getSubAddr() {
		return subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}

	public String getSdKobetuNm() {
		return sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}
}
