package com.nec.jp.G6Smartphone.dao.g6;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.SO.SdKobetuNmDataModel;

@Repository
public class SZWP3400Dao {

	@PersistenceContext(unitName="g6Persistence")
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	public List<SdKobetuNmDataModel> securityDistrictList(String acntID, String lnKeibi, String lnKbChiku) {
		final StringBuilder strBuilder = new StringBuilder();

//		strBuilder.append(" SELECT			rkbchiku.LN_KB_CHIKU as lnKbChiku");
//		strBuilder.append(",						IFNULL(rkbchiku.SD_KOBETU_NM,'') as sdKobetuNm");
//		strBuilder.append(",						IFNULL(rkbchiku.LN_KEIBI,'')");
//		strBuilder.append(" FROM				R_KB_CHIKU rkbchiku");
//		strBuilder.append(" INNER JOIN	R_KEIBI rkeibi ON rkbchiku.LN_KEIBI = rkeibi.LN_KEIBI");
//		strBuilder.append(" WHERE			rkeibi.LN_KEIBI = :lnKeibi");
//		strBuilder.append(" 						AND rkbchiku.ENTRY_STS = :entrySts");
//		strBuilder.append(" ORDER BY		rkbchiku.LN_KB_CHIKU ASC");

        strBuilder.append(" SELECT ");
        strBuilder.append("      rkbchiku.LN_KB_CHIKU as lnKbChiku");
        strBuilder.append(",     IFNULL(rkbchiku.SD_KOBETU_NM,'') as sdKobetuNm");
        strBuilder.append(",     IFNULL(rkbchiku.LN_KEIBI,'')");
        strBuilder.append(" FROM ");
        strBuilder.append("      R_KB_CHIKU rkbchiku");
        strBuilder.append("			INNER JOIN A_USER_OPERATION_HANI A ON A.LN_ACNT_USER_COMMON = :acntID");
        strBuilder.append("			AND ( A.PATH_INF = rkbchiku.PATH_INF");
        strBuilder.append("			   OR A.PATH_INF = LEFT(rkbchiku.PATH_INF, 41)");
        strBuilder.append("			   OR A.PATH_INF = LEFT(rkbchiku.PATH_INF, 20) )");
        strBuilder.append(" WHERE ");
        strBuilder.append("      rkbchiku.DEL_FLG = '0' ");
        strBuilder.append(" AND rkbchiku.LN_KEIBI = :lnKeibi");
        if (lnKbChiku != null && !"".equals(lnKbChiku)) {
            strBuilder.append(" AND rkbchiku.LN_KB_CHIKU = :lnKbChiku");
        }
        strBuilder.append(" ORDER BY rkbchiku.SD_KOBETU_NM ASC");
     
		final Query query = entityManager.createNativeQuery(strBuilder.toString(), "SdKobetuNmDataModelResult");
		query.setParameter("acntID", acntID);
		query.setParameter("lnKeibi", lnKeibi);
		 if (lnKbChiku != null && !"".equals(lnKbChiku)) {
		     query.setParameter("lnKbChiku", lnKbChiku);
        }
		return (List<SdKobetuNmDataModel>) query.getResultList();
	}
}
