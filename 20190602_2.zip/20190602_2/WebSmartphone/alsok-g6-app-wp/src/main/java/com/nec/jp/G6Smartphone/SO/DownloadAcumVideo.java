package com.nec.jp.G6Smartphone.SO;

public class DownloadAcumVideo {

	private String liveIp;		// ライブ配信WEBサーバIPアドレス
	private String downloadPort;	// ソケット通信用port
	private String result;		// 処理結果 -> 0: OK, 1: NG
	
	public DownloadAcumVideo() {
		// do nothing
	}

	public DownloadAcumVideo(String liveIp, String downloadPort, String result) {
		this.liveIp = liveIp;
		this.downloadPort = downloadPort;
		this.result = result;
	}

	public String getLiveIp() {
		return liveIp;
	}

	public void setLiveIp(String liveIp) {
		this.liveIp = liveIp;
	}

	public String getDownloadPort() {
		return downloadPort;
	}

	public void setDownloadPort(String downloadPort) {
		this.downloadPort = downloadPort;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
}
