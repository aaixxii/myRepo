package com.nec.jp.G6Smartphone.SO;

public class ResGetOtherInfo {
	private String telNum;
	private String jigyouNm;
	public ResGetOtherInfo() {
		this.telNum = "";
		this.jigyouNm = "";
	}
	public ResGetOtherInfo(String telNum, String jigyouNm) {
		this.telNum = telNum;
		this.jigyouNm = jigyouNm;
	}
	public String getTelNum() {
		return telNum;
	}
	public void setTelNum(String telNum) {
		this.telNum = telNum;
	}
	public String getJigyouNm() {
		return jigyouNm;
	}
	public void setJigyouNm(String jigyouNm) {
		this.jigyouNm = jigyouNm;
	}
}
