package com.nec.jp.G6Smartphone.service.ghs;

import java.util.List;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.KbChikuDataModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataModel;
import com.nec.jp.G6Smartphone.SO.RDevDataModel;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP1000GhsDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP1000GhsService {

	@Autowired
	SZWP1000GhsDao sZWP1000Dao;

	public List<KbChikuDataModel> getListSecurityDistrictGHS(String lnKeibi) throws ApplicationException {
		try {
			List<KbChikuDataModel> kbChikuDataModelList = sZWP1000Dao.getListSecurityDistrictGHS(lnKeibi);

			return kbChikuDataModelList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public List<RDevDataModel> getListDeviceGHS(String lnKbChiku) throws ApplicationException {
		try {
			List<RDevDataModel> rDevDataModelList =  sZWP1000Dao.getListDeviceGHS(lnKbChiku);

			return rDevDataModelList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public List<String> getListElectricNumGHS(String lnKeibi) throws ApplicationException {
		try {
			List<String> resultList = sZWP1000Dao.getListElectricNumGHS(lnKeibi);

			return resultList;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public RCtlDevDataModel getGoukiSerialGHS(String lnKeibi) throws ApplicationException {
		try {
			RCtlDevDataModel rCtlDevDataModel = sZWP1000Dao.getGoukiSerialGHS(lnKeibi);
	
			return rCtlDevDataModel;

		} catch (NoResultException noResultE) {
			return new RCtlDevDataModel();

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getControlQueueStsGHS(String cmdSeqNum) throws ApplicationException {
		try {
			String result = sZWP1000Dao.getControlQueueStsGHS(cmdSeqNum);

			return result;

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getDeviceStsGHS(String lnDev) throws ApplicationException {
		try {
			String result = sZWP1000Dao.getDeviceStsGHS(lnDev);

			return (result == null) ? "" : result;

		} catch (NoResultException ex) {
			return "";

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
