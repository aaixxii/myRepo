package com.nec.jp.G6Smartphone.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.nec.jp.G6Smartphone.SO.DistrictGHSInfoModel;
import com.nec.jp.G6Smartphone.SO.RCtlDevDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuDataSubModel;
import com.nec.jp.G6Smartphone.SO.RKeibiGHSModel;
import com.nec.jp.G6Smartphone.SO.ResSetRemoteDev;
import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.model.HUserOperationLogModel;
import com.nec.jp.G6Smartphone.service.com.CommonComService;
import com.nec.jp.G6Smartphone.service.g6.CommonService;
import com.nec.jp.G6Smartphone.service.g6.SZWP1100Service;
import com.nec.jp.G6Smartphone.service.ghs.CommonGhsService;
import com.nec.jp.G6Smartphone.service.ghs.SZWP1100GhsService;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;
import com.nec.jp.G6Smartphone.utility.G6Constant.RequestParam;
import com.nec.jp.G6Smartphone.utility.G6Constant.ScreenID;
import com.nec.jp.G6Smartphone.utility.G6JWTVerifier;

import jp.co.alsok.g6.common.log.ApplicationLog;

@Controller
public class SZWP1100Controller {

	private static final ApplicationLog appLog = new ApplicationLog(SZWP1100Controller.class);
    //JWT認証トークンの検証
    private G6JWTVerifier jwtverifier;
    
	@Autowired
	SZWP1100Service sZWP1100Service;
	@Autowired
	SZWP1100GhsService sZWP1100GhsService;
	@Autowired
	CommonService commonService;
	@Autowired
	CommonGhsService commonGhsService;
	@Autowired
	CommonComService commonComService;

	@Value("${timeout}")
	Integer timeout;
	@Value("${cmdVer}")
	String cmdVer;
    @Value("${cmdVer2}")
    String cmdVer2;
	@Value("${host_name}")
	String hostName;

	/*
	 * Get data from R_DEV_STS table
	 * @param: acntID, acntNm, lnKeibi, lnKbChiku, lnDev, sdDevNum, cntrSt 
	 * return: object ResSetRemoteDev as JSON
	 */
	@RequestMapping(value = "/setRemoteDev", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public @ResponseBody String setRemoteDev(@RequestBody String strParam) {
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2000, null, "SZWP1100Controller.setRemoteDev()");
		String jsonResult = "";
		String acntLanguage = G6CodeConsts.CD238.JAPANESE;
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		Map<String, Object> mapParam = new HashMap<String, Object>();
		String acntType = "";
        
		try {
			// リクエスト情報からパラメータを取得する
			mapParam = G6Common.readParam(strParam);

            //認証用JWTの検証クラスのインスタンス化
            jwtverifier = new G6JWTVerifier();
            jwtverifier.init(commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_SECRET),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_ISSUER),
            		commonService.getPropVal(G6Constant.SECITON, G6Constant.P_KEY_EXPIRE_MINUTES));

         // ==後勝ちログイン、アカウント情報変更チェック 開始 ======================================================
            Map<String, String> tokenMapParam = new HashMap<>();
            // チェックを実行
            String validLoginSts = commonService.checkValidLoginSts(mapParam, tokenMapParam, jwtverifier);
            
            // チェックエラーの場合、メッセージを返し処理を終了
            if (G6Constant.LOGIN_STS_USER_INF_MODIFIED.equals(validLoginSts)) {
            	// ユーザ情報が変更された場合
                jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_USER_INF_MODIFIED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDev()");
                return jsonResult;
                
            } else if (G6Constant.LOGIN_STS_ANOTHER_SESSION_LOGINED.equals(validLoginSts)) {
            	// 同一ユーザでログインされた場合
                jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.VALID_LOGIN,
                        ErrorKey.ERROR_ANOTHER_SESSION_LOGINED.getValue(), acntLanguage);
                appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDev()");
                return jsonResult;
            }
            // ==後勝ちログイン、アカウント情報変更チェック 終了 ======================================================
            
            //JWTトークンを検証し、成功した場合acntIDをデコード済に置き換える
            mapParam.put(RequestParam.acntID.getValue(),jwtverifier.verifyAndGetAcuntID((mapParam.get(RequestParam.acntID.getValue())).toString()));
			
			if (null != mapParam.get(RequestParam.acntID.getValue())
					&& !"".equals(mapParam.get(RequestParam.acntID.getValue()))) {
				// 選択言語種別の取得
				acntLanguage = commonComService.getLanguageType(mapParam.get(RequestParam.acntID.getValue()).toString());
			}

			// リクエスト情報を検証する
			if (mapParam.size() != 8) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDev()");
				return jsonResult;
			}

			// リクエスト情報検証
			List<String> lstRequiredParam = new ArrayList<String>() {
				private static final long serialVersionUID = 1L;
				{
					add(RequestParam.acntID.getValue());
					add(RequestParam.acntSbt.getValue());
					add(RequestParam.acntNm.getValue());
					add(RequestParam.lnKeibi.getValue());
					add(RequestParam.lnKbChiku.getValue());
					add(RequestParam.lnDev.getValue());
					add(RequestParam.sdDevNum.getValue());
					add(RequestParam.cntrSt.getValue());
				}
			};

			if (!G6Common.checkRequire(mapParam, lstRequiredParam)) {
				// リクエスト検証
				jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_REQUEST_VALIDATION.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDev()");
				return jsonResult;
			}
			
			// リクエスト情報取得
			acntType = mapParam.get(RequestParam.acntSbt.getValue()).toString();
			if (null == acntType) {
				jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD, ErrorKey.NO_ACNT_TYPE_FOUND.getValue(), acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDev()");
				return jsonResult;
			}

			// unused: リクエスト情報取得

			// ◇リクエスト情報から取得したアカウントIDより、利用可能なメニューかチェックする
			// 共通関数「利用者権限チェック関数」にて、チェックを行う
			G6Common.invalidateAcntRole(mapParam);
			
			String acntID = mapParam.get(RequestParam.acntID.getValue()).toString();
			String acntNm = mapParam.get(RequestParam.acntNm.getValue()).toString();
			String lnKeibi = mapParam.get(RequestParam.lnKeibi.getValue()).toString();
			String lnDev = mapParam.get(RequestParam.lnDev.getValue()).toString();
			String sdDevNum = mapParam.get(RequestParam.sdDevNum.getValue()).toString();
			String cntrSt = mapParam.get(RequestParam.cntrSt.getValue()).toString();
			String lnkbChiku = mapParam.get(RequestParam.lnKbChiku.getValue()).toString();

			if (acntType.equals(G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM)) {
				jsonResult = doNextStatusSet(acntID, acntNm, lnKeibi, lnkbChiku, lnDev, sdDevNum, cntrSt, acntLanguage, tokenMapParam);
			
			//  アカウント種別が、ＧＨＳの場合 
			} else if (acntType.equals(G6CodeConsts.CD027.GHS_THE_USER) || acntType.equals(G6CodeConsts.CD027.GHS_CONTRACT_DESTINATION)) {
				jsonResult = doGHSStatusSet(acntID, acntNm, lnKeibi, lnkbChiku, lnDev, sdDevNum, cntrSt, acntLanguage, acntType, tokenMapParam);
			}

		} catch (ApplicationException e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, e.getExceptionCode(), e.getExceptionMsg(), acntLanguage);
        } catch (JWTVerificationException e) {
            jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_VERIFY_JSON.getValue(), acntLanguage);
        } catch (JWTCreationException e) {
            jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.TOKEN_ERROR,
                    ErrorKey.EXCEPTION_CREATE_JSON.getValue(), acntLanguage);
		} catch (Exception e) {
			// 例外発生時にログ出力
			appLog.log(G6Constant.LOG_MESSAGE_LZWP2002, null, e);
			
			if (G6Constant.MYCD007.DataIntegrityViolationException.equals(e.getClass().getSimpleName())) {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.ERROR_DUPLICATE_PRIMARY_KEY.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			} else {
				jsonResult = G6Common.messageLogHandler(resSetRemoteDev, G6Constant.FAIL_HTML_CD, ErrorKey.EXCEPTION_ROOT.getValue(), G6Common.printStackTraceToString(e), acntLanguage);
			}
		}

		// 処理終了
		appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDev()");
		return jsonResult;
	}

	private String doNextStatusSet(String acntID, String acntNm, String lnKeibi, String lnKbChiku, String lnDev, String sdDevNum, String cntrSt, String acntLanguage, Map<String, String> tokenMapParam) 
			throws ApplicationException, JWTCreationException {
		String jsonResult = "";
		String denkeiNum = "";
		RCtlDevDataSubModel rCtlDevDataModel = new RCtlDevDataSubModel();
		RKbChikuDataSubModel rKbChikuDataModel = new RKbChikuDataSubModel();
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		
		// 設定処理
		// 7-2.A)電計番号の取得
		denkeiNum = sZWP1100Service.getElectricNum(lnKeibi);

		// 7-2.B)号機番号、シリアル番号の取得
		// rCtlDevDataModel = sZWP1100Service.getGoukiSerial(lnKeibi, mapParam.get(RequestParam.lnKbChiku.getValue()).toString());
		rCtlDevDataModel = sZWP1100Service.getGoukiSerial(lnKeibi);
		// 7-2.C)地区情報の取得
		rKbChikuDataModel = sZWP1100Service.getDistrictInfo(lnKeibi);

		// シリアル番号が設定されていない場合
		if ("".equals(rCtlDevDataModel.getSerialNum().trim())) {
			// エラーメッセージを画面に表示する
			jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_SERIALNUM_NOT_FOUND.getValue(), acntLanguage);
			
			// 処理終了
			return jsonResult;
		}

		// String cmdSeqNum = commonService.getCmdSeq(G6Constant.CD_SEQUENCE.CMD_SEQ_NUM);
		final String cmdSeqNum = commonService.getCmdSeq();
		String soapMsg = "";
		Map<String, String> mapSoap = null;
		// String nextLnQueCtrlSig = commonService.getLn(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
//		final String nextLnQueCtrlSig = ProxyUtil.getSeqNoG6(G6Constant.CD_SEQUENCE.LN_LOG_USER_OPERATION);
		final String transNo = commonService.getTranSeq();
		String subAddr = rKbChikuDataModel.getSubAddr();
		if (subAddr == null || "".equals(subAddr.trim())) {
		    subAddr = "    ";
		}
		mapSoap = this.createParamForSoap(rCtlDevDataModel, 
		        denkeiNum, 
		        cmdSeqNum, 
		        subAddr,
		        sdDevNum, 
				cntrSt,
				transNo);

		// 「ON/OFF設定」ボタンが実行された場合
		if (G6CodeConsts.CD004.ON.equals(cntrSt)
				|| G6CodeConsts.CD004.OFF.equals(cntrSt)) {
			// 7-3.B)ダイレクト制御コマンド(ON設定)
			soapMsg = this.createSoapMsg(mapSoap);
		}

		mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
		mapSoap.put(RequestParam.acntID.getValue(), acntID);
		mapSoap.put(RequestParam.acntNm.getValue(), acntNm);

		// 7-3.A)ダイレクト制御コマンド登録
		final String seqNo = commonService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL_SIG);
		commonService.saveCQueCtrlSigModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

		// 操作履歴情報にダイレクト制御操作を登録する
		HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
		hUserOperationLogModel.setInsertId(acntID);										// アカウントID
		hUserOperationLogModel.setInsertNm(acntNm);										// アカウント名
		hUserOperationLogModel.setLnKeibi(lnKeibi);										// 警備先論理番号
		hUserOperationLogModel.setLnKbChiku(lnKbChiku);									// 警備先地区論理番号
		hUserOperationLogModel.setDispId(ScreenID.SZWP1100.getValueForOperationLog());	// 操作画面ID
		hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
		commonService.entryUserOperation(hUserOperationLogModel, G6CodeConsts.CD027.THE_NEXT_TERM_GUARD_SYSTEM);

		// 操作状況取得
		long beginTime = System.currentTimeMillis();

		// プロパティファイルから取得した「タイムアウト時間」までループする
		while (true) {
			// 制御状態読出の結果を取得する
			// 7-2.D)コマンド状態の取得
			String cmdSts = sZWP1100Service.getCmdSts(cmdSeqNum);

			if (null == cmdSts) {
				jsonResult = G6Common.messageUpdateLogHandler(resSetRemoteDev, 
						G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

				// 処理終了
				return jsonResult;
			}

			// 取得成功の場合(S：成功)
			if(G6CodeConsts.CD179.SUCCESS.equals(cmdSts)) {
				// 設置機器の状態を取得する
				// 7-2.E)設置機器状態の取得
				String deviceSts = sZWP1100Service.getDeviceSts(lnDev);

				resSetRemoteDev.setErrorCode(G6Constant.SUCCESS_CD);
				resSetRemoteDev.setLnDev(lnDev);
				resSetRemoteDev.setDrctsetCntrSts(deviceSts);

				//デコード済acntIDを設定したJWT認証トークンを付与
				resSetRemoteDev.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
				
				jsonResult = G6Common.parseJSON(resSetRemoteDev, acntLanguage);

				// 処理終了
				appLog.log(G6Constant.LOG_MESSAGE_LZWP2001, null, "SZWP1100Controller.setRemoteDev()");
				return jsonResult;

			// 取得失敗の場合(3:レスポンス受理(OK以外) E:エラー T：タイムアウト)
			} else if(G6CodeConsts.CD179.RESPONSE_ACCEPTANCE_BESIDES_OK.equals(cmdSts) || 
					G6CodeConsts.CD179.ERROR.equals(cmdSts) || 
					G6CodeConsts.CD179.TIME_OUT.equals(cmdSts)) {
				// エラーメッセージを設定する
				jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_CONTROL_QUEUE_STATUS.getValue(), acntLanguage);

				// 処理終了
				return jsonResult;
			}

            // タイムアウト時間を超過している場合
            if (G6Common.isTimeOut(timeout.intValue(), beginTime)) {
                break;
            }
		}
		// 「タイムアウト時間」まで経過している場合
		// タイムアウトのエラーメッセージを設定する
		// リソースより以下のキーも文字列を取得する
		// error.deliverySetting.readTimeout
		jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD,
				ErrorKey.ERROR_DELIVERYSETTING_READTIMEOUT.getValue(), acntLanguage);
		
		return jsonResult;
	}
	
	private String  doGHSStatusSet(String acntID, String acntNm, String lnKeibi, String lnKbChiku, String lnDev, String sdDevNum, String cntrSt, String acntLanguage, String acntType, Map<String, String> tokenMapParam) 
			throws ApplicationException, JWTCreationException {
		String jsonResult = "";
		String denkeiNum = "";
		RKeibiGHSModel rKeibiGHSModel = new RKeibiGHSModel();
		DistrictGHSInfoModel districtGHSInfoModel = new DistrictGHSInfoModel();
		ResSetRemoteDev resSetRemoteDev = new ResSetRemoteDev();
		
		// 設定処理
		// 8-2.A)電計番号の取得
		denkeiNum = sZWP1100GhsService.getElectricNum(lnKeibi);

		// 8-2.B)号機番号、シリアル番号の取得
		rKeibiGHSModel = sZWP1100GhsService.getGoukiSerial(lnKeibi);
		
		// 8-2.C)警備先地区一覧の取得
		districtGHSInfoModel = sZWP1100GhsService.getDistrictInfo(lnKeibi);

		// シリアル番号が設定されていない場合
		if ("".equals(rKeibiGHSModel.getSerialNum().trim())) {
			// エラーメッセージを画面に表示する
			jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD, ErrorKey.ERROR_SERIALNUM_NOT_FOUND.getValue(), acntLanguage);
			
			// 処理終了
			return jsonResult;
		}

		final String cmdSeqNum = commonGhsService.getCmdSeq();
		String soapMsg = "";
		Map<String, String> mapSoap = null;
		final String transNo = commonService.getTranSeq();
		String subAddr = districtGHSInfoModel.getSubAddr();
		if (subAddr == null || "".equals(subAddr.trim())) {
		    subAddr = "    ";
		}
		mapSoap = this.createGHSParamForSoap(rKeibiGHSModel, 
		        denkeiNum, 
		        cmdSeqNum, 
		        subAddr,
		        sdDevNum, 
				cntrSt,
				transNo);
		
		// ◇「ON設定」ボタンが実行された場合
		if (G6CodeConsts.CD004.ON.equals(cntrSt) || G6CodeConsts.CD004.OFF.equals(cntrSt)) {
			// 8-3.B)ダイレクト制御コマンド(ON設定)  -  cntrSt = 1
			// 8-3.C)ダイレクト制御コマンド(OFF設定) -  cntrSt = 0
			soapMsg = this.createGHSSoapMsg(mapSoap);
		}

		mapSoap.put(G6Constant.MYCD003.SOAPMSG, soapMsg);
		mapSoap.put(RequestParam.acntID.getValue(), acntID);
		mapSoap.put(RequestParam.acntNm.getValue(), acntNm);

		// 8-3.A)ダイレクト制御コマンド登録
		final String seqNo = commonGhsService.getLn(G6Constant.CD_SEQUENCE.LN_QUE_CTRL);
		commonGhsService.saveEQueCtrlModel(mapSoap, DateTimeCommon.getCurrentDate(), seqNo);

		// 操作履歴情報にダイレクト制御操作を登録する
		HUserOperationLogModel hUserOperationLogModel = new HUserOperationLogModel();
		hUserOperationLogModel.setInsertId(acntID);										// アカウントID
		hUserOperationLogModel.setInsertNm(acntNm);										// アカウント名
		hUserOperationLogModel.setLnKeibi(lnKeibi);										// 警備先論理番号
		hUserOperationLogModel.setLnKbChiku(lnKbChiku);									// 警備先地区論理番号
		hUserOperationLogModel.setDispId(ScreenID.SZWP1100.getValueForOperationLog());	// 操作画面ID
		hUserOperationLogModel.setUserOperationNaiyouCd(G6Constant.KIND);				// 操作内容コード
		commonService.entryUserOperation(hUserOperationLogModel, acntType);
		
		// 操作状況取得
		long beginTime = System.currentTimeMillis();

		// プロパティファイルから取得した「タイムアウト時間」までループする
		while (true) {
			// 制御状態読出の結果を取得する
			// 8-2.D)コマンド状態の取得
			String cmdSts = sZWP1100GhsService.getCmdSts(cmdSeqNum);

			if (null == cmdSts) {
				jsonResult = G6Common.messageUpdateLogHandler(resSetRemoteDev, 
						G6Constant.FAIL_HTML_CD, ErrorKey.OPERATION_FAIL.getValue(), ErrorKey.GET_QUEUE_STATUS.getValue(), acntLanguage);

				// 処理終了
				return jsonResult;
			}

			// 取得成功の場合(S：成功)
			if(G6CodeConsts.CD179.SUCCESS.equals(cmdSts)) {
				// 設置機器の状態を取得する
				// 8-2.E)設置機器状態の取得
				String deviceSts = sZWP1100GhsService.getDeviceSts(lnDev);

				resSetRemoteDev.setErrorCode(G6Constant.SUCCESS_CD);
				resSetRemoteDev.setLnDev(lnDev);
				resSetRemoteDev.setDrctsetCntrSts(deviceSts);

				//デコード済acntIDを設定したJWT認証トークンを付与
				resSetRemoteDev.setAcntID(jwtverifier.createTokenWithMapParam(tokenMapParam));
	   	
				jsonResult = G6Common.parseJSON(resSetRemoteDev, acntLanguage);

				// 処理終了
				return jsonResult;

			// 取得失敗の場合(3:レスポンス受理(OK以外) E:エラー T：タイムアウト)
			} else if(G6CodeConsts.CD179.RESPONSE_ACCEPTANCE_BESIDES_OK.equals(cmdSts) || 
					G6CodeConsts.CD179.ERROR.equals(cmdSts) || 
					G6CodeConsts.CD179.TIME_OUT.equals(cmdSts)) {
				// エラーメッセージを設定する
				jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD,
						ErrorKey.ERROR_CONTROL_QUEUE_STATUS.getValue(), acntLanguage);

				// 処理終了
				return jsonResult;
			}

            // タイムアウト時間を超過している場合
            if (G6Common.isTimeOut(timeout.intValue(), beginTime)) {
                break;
            }
		}
		// 「タイムアウト時間」まで経過している場合
		// タイムアウトのエラーメッセージを設定する
		// リソースより以下のキーも文字列を取得する
		// error.deliverySetting.readTimeout
		jsonResult = G6Common.messageHandler(resSetRemoteDev, G6Constant.FAIL_POPUP_CD,
				ErrorKey.ERROR_DELIVERYSETTING_READTIMEOUT.getValue(), acntLanguage);
		
		return jsonResult;
	}
	
	
	private Map<String, String> createParamForSoap(RCtlDevDataSubModel rCtlDevDataModel, String denkei, String cmdsqNo,
			String subAddr, String termNo, String cntrSt, String transNo) {
		Map<String, String> mapSoap = new HashMap<String, String>();

//		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer);
		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer2);
//		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
	    mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, transNo);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rCtlDevDataModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, denkei);
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rCtlDevDataModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, subAddr);
		
//		mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.LINETYPE, rCtlDevDataModel.getSdLineKind());
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.DRCTSET);
		mapSoap.put(G6Constant.MYCD003.TERMNO, termNo);
		mapSoap.put(G6Constant.MYCD003.CNTRST, cntrSt);
		mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);

		mapSoap.put(G6Constant.MYCD003.HOSTNM, hostName);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, termNo);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
//		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.DWLDCOR);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.DRCTSET);
		mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.UNSENT);

		return mapSoap;
	}

	private String createSoapMsg(Map<String, String> mapSoap) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeader(mapSoap.get(G6Constant.MYCD003.EXECCMD)));
		// データ部作成
		// 共通項目タグ設定
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		// 共通クラスから取得したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<term_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TERMNO) + "</term_no>");
		builder.append("<cntr_st>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CNTRST) + "</cntr_st>");
//		builder.append("<result>");
//		builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		// フッター部作成
		builder.append(G6Common.createSoapFooter(mapSoap.get(G6Constant.MYCD003.EXECCMD)));

		return builder.toString();
	}

	private Map<String, String> createGHSParamForSoap(RKeibiGHSModel rKeibiGHSModel, String denkei, String cmdsqNo, String subAddr, String termNo, String cntrSt, String transNo) {
		Map<String, String> mapSoap = new HashMap<String, String>();

		mapSoap.put(G6Constant.MYCD003.COMMANDVERSION, cmdVer);
		mapSoap.put(G6Constant.MYCD003.TRANSACTIONNO, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.GENERATIONTIME, DateTimeCommon.getShortCurrentDateTime());
		mapSoap.put(G6Constant.MYCD003.TRANSMITTERID, rKeibiGHSModel.getSerialNum());
		mapSoap.put(G6Constant.MYCD003.DENKEINO, denkei);
		mapSoap.put(G6Constant.MYCD003.GOUKINO, rKeibiGHSModel.getGouKi());
		mapSoap.put(G6Constant.MYCD003.SUBADDRESS, subAddr);
		mapSoap.put(G6Constant.MYCD003.LINETYPE, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.CMDSEQNUM, cmdsqNo);
		mapSoap.put(G6Constant.MYCD003.EXECCMD, G6Constant.MYCD004.DRCTSET);
		mapSoap.put(G6Constant.MYCD003.TERMNO, termNo);
		mapSoap.put(G6Constant.MYCD003.CNTRST, cntrSt);
		mapSoap.put(G6Constant.MYCD003.RESULT, G6CodeConsts.CD002.OK);
		
		mapSoap.put(G6Constant.MYCD003.HOSTNM, G6Constant.EMPTY);
		mapSoap.put(G6Constant.MYCD003.CONNDEVNUM, G6Constant.MYCD006.SU000);
		mapSoap.put(G6Constant.MYCD003.DEVNUM, termNo);
		mapSoap.put(G6Constant.MYCD003.PRIORITY, G6CodeConsts.CD112.PRIORITY_2);
		mapSoap.put(G6Constant.MYCD003.PROCESSNUM, G6Constant.MYCD005.START);
		mapSoap.put(G6Constant.MYCD003.CMDCD, G6CodeConsts.CD038.DRCTSET_GHS);
		mapSoap.put(G6Constant.MYCD003.STS, G6CodeConsts.CD179.UNSENT);

		return mapSoap;
	}

	private String createGHSSoapMsg(Map<String, String> mapSoap) {
		StringBuffer builder = new StringBuffer();

		// ヘッダ部作成
		builder.append(G6Common.createSoapHeaderForGhs());
		
		// データ部作成
		// 共通項目タグ設定
		builder.append("<HostName>");
		builder.append(mapSoap.get(G6Constant.MYCD003.HOSTNM) + "</HostName>");
		builder.append("<command_version>");
		builder.append(mapSoap.get(G6Constant.MYCD003.COMMANDVERSION) + "</command_version>");
		builder.append("<transaction_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSACTIONNO) + "</transaction_no>");
		builder.append("<generation_time>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GENERATIONTIME) + "</generation_time>");
		builder.append("<transmitter_id>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TRANSMITTERID) + "</transmitter_id>");
		builder.append("<denkei_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.DENKEINO) + "</denkei_no>");
		builder.append("<gouki_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.GOUKINO) + "</gouki_no>");
		builder.append("<sub_address>");
		builder.append(mapSoap.get(G6Constant.MYCD003.SUBADDRESS) + "</sub_address>");
		builder.append("<line_type>");
		builder.append(mapSoap.get(G6Constant.MYCD003.LINETYPE) + "</line_type>");
		
		// 共通クラスから取得したコマンドシーケンス番号
		builder.append("<cmdsq_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CMDSEQNUM) + "</cmdsq_no>");
		builder.append("<priority_level>");
		builder.append(G6Constant.EMPTY + "</priority_level>");
		builder.append("<timeout_sec>");
		builder.append(G6Constant.EMPTY + "</timeout_sec>");
		builder.append("<execmd>");
		builder.append(mapSoap.get(G6Constant.MYCD003.EXECCMD) + "</execmd>");
		builder.append("<term_no>");
		builder.append(mapSoap.get(G6Constant.MYCD003.TERMNO) + "</term_no>");
		builder.append("<cntr_st>");
		builder.append(mapSoap.get(G6Constant.MYCD003.CNTRST) + "</cntr_st>");
		builder.append("<result>");
		builder.append(mapSoap.get(G6Constant.MYCD003.RESULT) + "</result>");
		
		// フッター部作成
		builder.append(G6Common.createSoapFooterForGhs());

		return builder.toString();
	}
}
