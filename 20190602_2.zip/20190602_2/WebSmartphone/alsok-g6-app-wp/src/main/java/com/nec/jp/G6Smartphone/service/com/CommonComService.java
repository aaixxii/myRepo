package com.nec.jp.G6Smartphone.service.com;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.constants.G6CodeConsts;
import com.nec.jp.G6Smartphone.dao.com.CommonComDao;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class CommonComService {

	@Autowired
	private CommonComDao commonDao;

	public String getLanguageType(String lnAcntUserCommon) throws ApplicationException {
		String lang = G6CodeConsts.CD238.JAPANESE;
		try {
			lang = commonDao.getLanguageType(lnAcntUserCommon);
			if (lang == null || "".equals(lang)) {
				lang = G6CodeConsts.CD238.JAPANESE;
			}
		} catch (NoResultException noResultE) {
			lang = G6CodeConsts.CD238.JAPANESE;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
		return lang;
	}

	public String getAccountType(String userId) throws ApplicationException {
		try {
			return commonDao.getAccountType(userId);

		} catch (NoResultException noResultE) {
			return null;

		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String getUserName(String lnAcntUserCommon) throws ApplicationException {
		try {
			String acntNm = commonDao.getUserName(lnAcntUserCommon);
	
			return acntNm;

		} catch (NoResultException noResultE) {
			return "";

		} catch(Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public String getAcntUserKbn(String lnAcntUserCommon) throws ApplicationException {
        try {
            String acntNm = commonDao.getAcntUserKbn(lnAcntUserCommon);
    
            return acntNm;

        } catch (NoResultException noResultE) {
            return "";

        } catch(Exception e) {
            // DBアクセス例外
            String errorMsg = G6Common.printStackTraceToString(e);

            // 処理終了
            throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
        }
    }
	
}
