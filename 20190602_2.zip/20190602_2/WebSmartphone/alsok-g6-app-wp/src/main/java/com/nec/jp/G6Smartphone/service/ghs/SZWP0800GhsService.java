package com.nec.jp.G6Smartphone.service.ghs;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.NoResultException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.jp.G6Smartphone.SO.ControlQueueStatusModel;
import com.nec.jp.G6Smartphone.SO.RDenkeiMngInfoModel;
import com.nec.jp.G6Smartphone.SO.RKbChikuInfoModel;
import com.nec.jp.G6Smartphone.SO.RKbInfoModel;
import com.nec.jp.G6Smartphone.SO.WKbChikuRmInfoModel;
import com.nec.jp.G6Smartphone.dao.ghs.SZWP0800GhsDao;
import com.nec.jp.G6Smartphone.model.EQueCtrlModel;
import com.nec.jp.G6Smartphone.utility.ApplicationException;
import com.nec.jp.G6Smartphone.utility.G6Common;
import com.nec.jp.G6Smartphone.utility.G6Constant;
import com.nec.jp.G6Smartphone.utility.G6Constant.ErrorKey;

@Service
public class SZWP0800GhsService {

	@Autowired
	SZWP0800GhsDao sZWP0800GhsDao;

	public RKbInfoModel selectRKeibiInfoGhs(String lnKeibi) throws ApplicationException {
		try {
			return sZWP0800GhsDao.selectRKeibiInfoGhs(lnKeibi);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public RKbChikuInfoModel searchRKbChikuGhs(String lnKbChiku) throws ApplicationException {
		try {
			return sZWP0800GhsDao.searchRKbChikuGhs(lnKbChiku);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public RDenkeiMngInfoModel searchRDenkeiMngGhs(String lnKeibi) throws ApplicationException {
		try {
			return sZWP0800GhsDao.searchRDenkeiMngGhs(lnKeibi);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public WKbChikuRmInfoModel searchWKbChikuRmSetGhs(String lnKbChiku) throws ApplicationException {
		try {
			return sZWP0800GhsDao.searchWKbChikuRmSetGhs(lnKbChiku);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public boolean deleteWKbChikuRmSet(String lnKbChiku) throws ApplicationException {
		try {
			return sZWP0800GhsDao.deleteWKbChikuRmSet(lnKbChiku);
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public boolean insertWKbChikuRmSet(String cmdSeqNum, String lnKbChiku, String acntID, String acntNm, String LnQueCtrl,String KbSetStsn0, String userKindNo, Date dateTime) throws ApplicationException {
		try {
			return sZWP0800GhsDao.insertWKbChikuRmSet(cmdSeqNum, lnKbChiku, acntID, acntNm, LnQueCtrl, KbSetStsn0, userKindNo, dateTime);
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
	
	public EQueCtrlModel searchEQueCtrlGhs(String comSeqNo)  throws ApplicationException {
		try {
			return sZWP0800GhsDao.searchEQueCtrlGhs(comSeqNo);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}

	public String searchSysKbChikuGhs(String lnKbChiku, String cmdSeqNum) throws ApplicationException {
		try {
			return sZWP0800GhsDao.searchSysKbChikuGhs(lnKbChiku, cmdSeqNum);
		} catch (NoResultException noResultE) {
			return null;
		} catch (Exception e) {
			// DBアクセス例外
			String errorMsg = G6Common.printStackTraceToString(e);

			// 処理終了
			throw new ApplicationException(G6Constant.SERVICE_CONTEXT, ErrorKey.EXCEPTION_DB_ACCESS.getValue(), errorMsg);
		}
	}
}
