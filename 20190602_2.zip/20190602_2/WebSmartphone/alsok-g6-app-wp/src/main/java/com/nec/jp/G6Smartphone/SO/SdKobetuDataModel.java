package com.nec.jp.G6Smartphone.SO;

public class SdKobetuDataModel {

	private String sdKobetuNm;		// 区名称
	private String chiku;			// 地区（GHS/GVでは設定しない）
	private String subAddr;			// サブアドレス（GHS/GVでは設定しない）

	public SdKobetuDataModel(String sdKobetuNm, String chiku, String subAddr) {
		this.sdKobetuNm = sdKobetuNm;
		this.chiku = chiku;
		this.subAddr = subAddr;
	}

	public String getSdKobetuNm() {
		return sdKobetuNm;
	}

	public void setSdKobetuNm(String sdKobetuNm) {
		this.sdKobetuNm = sdKobetuNm;
	}

	public String getChiku() {
		return chiku;
	}

	public void setChiku(String chiku) {
		this.chiku = chiku;
	}

	public String getSubAddr() {
		return subAddr;
	}

	public void setSubAddr(String subAddr) {
		this.subAddr = subAddr;
	}
}
