package com.nec.jp.G6Smartphone.dao.com;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.nec.jp.G6Smartphone.utility.DateTimeCommon;
import com.nec.jp.G6Smartphone.utility.G6Constant;

@Repository
public class SZWP0000ComDao {

	@PersistenceContext(unitName="comPersistence")
	private EntityManager entityManager;

	public String getLoginFailureTimes(String lnAcntUserCommon) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" SELECT	kauls.CNT_LOGIN_ERR as cntLoginErr");
		strBuilder.append(" FROM	K_ACNT_USER_LOGIN_STS kauls");
		strBuilder.append(" WHERE	kauls.LN_ACNT_USER_COMMON = :lnAcntUserCommon");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);

		return query.getSingleResult().toString();
	}

	public Boolean updateLoginFailureTimes(String lnAcntUserCommon, String acntNm, String failureTimes) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" UPDATE	K_ACNT_USER_LOGIN_STS kauls");
		strBuilder.append(" SET		kauls.CNT_LOGIN_ERR = :failureTimes,");
		strBuilder.append("			kauls.UPDATE_ID = :lnAcntUserCommon,");
		strBuilder.append("			kauls.UPDATE_NM = :acntNm,");
		strBuilder.append("			kauls.UPDATE_TS = :updateDate");
		strBuilder.append(" WHERE	kauls.LN_ACNT_USER_COMMON = :lnAcntUserCommon");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("failureTimes", failureTimes);
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
		query.setParameter("acntNm", acntNm);
		query.setParameter("updateDate", DateTimeCommon.getCurrentDateTime());

		if(query.executeUpdate() > 0) {
			return true;
		}

		return false;
	}

	public Boolean updateLoginStatus(String lnAcntUserCommon, String acntNm) {
		StringBuilder strBuilder = new StringBuilder();

		strBuilder.append(" UPDATE	K_ACNT_USER_LOGIN_STS kauls");
		strBuilder.append(" SET		kauls.FLG_LOGIN_STS = :loginStsFlg,");
		strBuilder.append("			kauls.CNT_LOGIN_ERR = :loginErrCnt,");
		strBuilder.append("			kauls.UPDATE_ID = :lnAcntUserCommon,");
		strBuilder.append("			kauls.UPDATE_NM = :acntNm,");
		strBuilder.append("			kauls.UPDATE_TS = :updateDate");
		strBuilder.append(" WHERE	kauls.LN_ACNT_USER_COMMON = :lnAcntUserCommon");

		Query query = entityManager.createNativeQuery(strBuilder.toString());
		query.setParameter("loginStsFlg", G6Constant.LOGIN_STATUS_FLG);
		query.setParameter("loginErrCnt", G6Constant.LOGIN_ERROR_COUNT);
		query.setParameter("lnAcntUserCommon", lnAcntUserCommon);
		query.setParameter("acntNm", acntNm);
		query.setParameter("updateDate", DateTimeCommon.getCurrentDateTime());

		if(query.executeUpdate() > 0) {
			return true;
		}

		return false;
	}
}
