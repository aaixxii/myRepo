package com.yi.go.fastdfs;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringBootGoFastdfsApplicationTests {

    @Test
    public void contextLoads() {
    }

}

