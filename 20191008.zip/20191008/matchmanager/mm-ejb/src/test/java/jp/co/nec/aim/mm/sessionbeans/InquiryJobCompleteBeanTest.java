package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.*;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UnitDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class InquiryJobCompleteBeanTest {
	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private InquiryJobCompleteBean inquiryBean;

	private UnitDao unitdao;

	private InquiryJobDao inquiryJobDao;

	private SystemConfigDao systemConfigDao;	

	@Before
	public void setUp() throws Exception {
		unitdao = new UnitDao(entityManager);
		inquiryJobDao = new InquiryJobDao(entityManager);		
		systemConfigDao = new SystemConfigDao(entityManager);		
		systemConfigDao.writeAllMissingProperties(ds);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCompleteJob() {
		
	}
	
	

}
