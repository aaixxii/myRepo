package jp.co.nec.aim.mm.sessionbeans;
//package jp.co.nec.aim.mm.sessionbeans;
//
//import static org.junit.Assert.assertArrayEquals;
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertNull;
//import static org.junit.Assert.assertTrue;
//import static org.junit.Assert.fail;
//
//import java.io.IOException;
//import java.math.BigDecimal;
//import java.sql.SQLException;
//import java.util.List;
//import java.util.Map;
//
//import javax.annotation.Resource;
//import javax.ejb.EJB;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.persistence.Query;
//import javax.sql.DataSource;
//import javax.transaction.Transactional;
//
//
//import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;
//import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
//import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
//import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisOutput;
//import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
//import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintOutput;
//
//import jp.co.nec.aim.mm.dao.DateDao;
//import jp.co.nec.aim.mm.dao.SystemConfigDao;
//import jp.co.nec.aim.mm.entities.SystemConfigEntity;
//import jp.co.nec.aim.mm.exception.AimRuntimeException;
//
//import jp.co.nec.aim.mm.jms.JmsSender;
//import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
//import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
//import jp.co.nec.aim.mm.sessionbeans.pojo.ExtractJobHandler;
//import jp.co.nec.aim.mm.util.Deflater;
//import jp.co.nec.aim.mm.util.ProtobufCreater;
//import mockit.Mock;
//import mockit.MockUp;
//
//import org.apache.commons.codec.binary.Base64;
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import com.google.protobuf.ByteString;
//import com.google.protobuf.InvalidProtocolBufferException;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration
//@Transactional
//public class ExtractJobCompleteBeanTest {
//	@Resource
//	private DataSource dataSource;
//	@PersistenceContext(unitName = "aim-db")
//	private EntityManager entityManager;
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//
//	@EJB
//	private ExtractJobCompleteBean extractJobBean;
//
//	private DateDao dateDao;
//	private SystemConfigDao systemconfigdao;
//	private long curTime;
//	private static long logJobId;
//	private static long cbJobId;
//	private static String message;
//	private ProtobufCreater  protobufCreater;
//
//	@Before
//	public void setUp() throws Exception {
//		clearDB();
//		dateDao = new DateDao(dataSource);
//		systemconfigdao = new SystemConfigDao(entityManager);
//		systemconfigdao.writeAllMissingProperties(dataSource);
//		curTime = dateDao.getCurrentTimeMS();
//		protobufCreater = new ProtobufCreater ();	
//		intsertUnit();
//		insertFeJob();
//		List<Map<String, Object>> listecc = jdbcTemplate
//				.queryForList("select * from EXTRACT_COMPLETE_COUNT");
//		if (listecc.size() == 0) {
//			jdbcTemplate
//					.update("insert into EXTRACT_COMPLETE_COUNT values(0,0)");
//		}
//		jdbcTemplate.execute("commit");
//
//		Query q = entityManager.createNamedQuery("NQ::getConfigEntity");
//		q.setParameter("name", "BEHAVIOR.MAX_EXTRACT_JOB_FAILURES");
//		SystemConfigEntity e = (SystemConfigEntity) q.getResultList().get(0);
//		e.setValue("2");
//		entityManager.merge(e);
//		setMockMethod();
//	}
//
//	@After
//	public void tearDown() throws Exception {
//		clearDB();		
//	}
//
//	/**
//	 * setMockMethod
//	 */
//	private void setMockMethod() {
//		logJobId = 0;
//		cbJobId = 0;
//		message = "";
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				logJobId = jobId;
//				return;
//			}
//		};
//
//
//		new MockUp<ExceptionSender>() {
//			@Mock
//			private void send(String reasonCode, String msg, long jobId,
//					long topLevelId, long unitId, Exception e) {
//				message = msg;
//				return;
//			}
//		};
//		new MockUp<JmsSender>() {
//			@Mock
//			private void convertAndSend(String queueName, Object message) {
//				return;
//			}
//		};
//	}
//
//	private void clearDB() {
//		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
//		jdbcTemplate.execute("delete from FE_RESULTS");
//		jdbcTemplate.execute("delete from FE_LOT_JOBS");
//		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
//		jdbcTemplate.execute("delete from FE_JOB_FAILURE_REASONS");
//		jdbcTemplate.execute("delete from MATCH_UNITS");
//		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
//		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
//		jdbcTemplate.execute("commit");
//	}
//
//	private void intsertUnit() {
//		int id = 1;
//		jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID, UNIQUE_ID,"
//				+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
//		jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"
//				+ " values(" + id + ", " + curTime + ")");
//		jdbcTemplate.execute("insert into MU_EXTRACT_LOAD(MU_ID, PRESSURE,"
//				+ " UPDATE_TS) values(" + id + ", 1, " + curTime + ")");
//
//	}
//
//	private void insertFeJob() {
//		String fljSQL = "insert into FE_LOT_JOBS(LOT_JOB_ID, MU_ID,"
//				+ " ASSIGNED_TS, TIMEOUTS) values(?, ?, ?, ?)";
//
//		String fejSQL = "insert into FE_JOB_QUEUE(JOB_ID, LOT_JOB_ID, PRIORITY,"
//				+ " FUNCTION_ID, JOB_STATE, SUBMISSION_TS, ASSIGNED_TS, MU_ID,"
//				+ " CALLBACK_STYLE, CALLBACK_URL, FAILURE_COUNT) values(?, ?,"
//				+ "  5,17, ?, 1421206612748, ?, ?, 1, 'test Url', ?)";
//
//		int fljId = 1;
//		jdbcTemplate.update(fljSQL, new Object[] { fljId, fljId, curTime,
//				30 * 1000 });
//		int fejId = 1;
//		jdbcTemplate.update(fejSQL, new Object[] { (fljId - 1) * 3 + fejId,
//				fljId, 1, curTime, fljId, 0 });
//
//	}
//
//	
//
//
//
//	@Test
//	public void testunPressPayloadAndBuildPBExtractJobResult()
//			throws IOException {
//		PBExtractJobResultInternal testItem = createPBMuExtractJobResultInternal();
//		PBExtractJobResult testResultPayload = extractJobBean
//				.unPressPayloadAndBuildPBExtractJobResult(testItem);
//		Assert.assertNotNull(testResultPayload);
//		Assert.assertEquals(3, testResultPayload.getJobId());
//		Assert.assertTrue(testResultPayload.getServiceState().toString()
//				.contains("SERVICE_STATE_SUCCESS"));
//		Assert.assertEquals(3, testResultPayload.getKeyedTemplateCount());
//		Assert.assertNotNull(testResultPayload.getOutputPayload());
//	}
//
//	@Test
//	public void testInflateAndDeflater() throws IOException {
//		String payload = "I am extract job payload.";
//		byte[] compressed = Deflater.compress(payload.getBytes());
//		byte[] base64Maked = Base64.encodeBase64(compressed);
//
//		byte[] unMarkedBase64 = Base64.decodeBase64(base64Maked);
//		byte[] unCompressed = Deflater.uncompress(unMarkedBase64);
//
//		String reslutPayload = new String(unCompressed);
//		Assert.assertTrue(reslutPayload.equals(payload));
//	}
//
//	@Test
//	public void test_SUCCESS() throws Exception {
//		PBMuExtractJobResult jobResult = createExtractJobResult(ServiceStateType.SERVICE_STATE_SUCCESS);
//
//		extractJobBean.completeExtractJobs(jobResult);
//
//		List<Map<String, Object>> listFeJ = jdbcTemplate
//				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, ASSIGNED_TS,"
//						+ " RESULT_TS, RESULT, MU_ID, FAILED_FLAG, FAILURE_COUNT"
//						+ " from FE_JOB_QUEUE order by JOB_ID");
//		assertEquals(1, listFeJ.size());
//		assertEquals("1", listFeJ.get(0).get("JOB_ID").toString());
//		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
//		assertEquals("2", listFeJ.get(0).get("JOB_STATE").toString());
//		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
//		assertTrue(curTime < ((BigDecimal) listFeJ.get(0).get("RESULT_TS"))
//				.longValue());
//		assertNotNull(listFeJ.get(0).get("RESULT"));
//		assertEquals("1", listFeJ.get(0).get("MU_ID").toString());
//		assertEquals("0", listFeJ.get(0).get("FAILED_FLAG").toString());
//		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());
//
//		int fljCount = jdbcTemplate.queryForObject(
//				"select count(*) from FE_LOT_JOBS", Integer.class);
//		assertEquals(0, fljCount);
//
//		int load = jdbcTemplate.queryForObject(
//				"select PRESSURE from MU_EXTRACT_LOAD where MU_ID=1",
//				Integer.class);
//		assertEquals(0, load);
//
//		List<Map<String, Object>> listReason = jdbcTemplate
//				.queryForList("select JOB_ID, MU_ID, CODE, REASON, FAILURE_TIME"
//						+ " from FE_JOB_FAILURE_REASONS order by FAILURE_ID");
//		assertEquals(0, listReason.size());
//
//		List<Map<String, Object>> listResult = jdbcTemplate
//				.queryForList("select JOB_ID, RESULT_DATA, TEMPLATE_KEY,"
//						+ " TEMPLATE_INDEX from FE_RESULTS order by TEMPLATE_INDEX");
//		assertEquals(2, listResult.size());
//		String[] key = new String[] { TemplateFormatType.TEMPLATE_RDBTM.name(),
//				TemplateFormatType.TEMPLATE_RDBT.name() };
//		byte[][] data = new byte[][] { { 1, 2, 3, 4 }, { 5, 6, 7, 8 } };
//		for (int i = 0; i < listResult.size(); i++) {
//			assertEquals("1", listResult.get(i).get("JOB_ID").toString());
//			assertArrayEquals(data[i],
//					(byte[]) listResult.get(i).get("RESULT_DATA"));
//			assertEquals(key[i], listResult.get(i).get("TEMPLATE_KEY")
//					.toString());
//			assertEquals("" + (i + 1), listResult.get(i).get("TEMPLATE_INDEX")
//					.toString());
//		}
//
//		assertEquals(1, logJobId);
//		assertEquals(1, cbJobId);
//		assertEquals("Extraction job 1 contained DUPLICATE key "
//				+ "(TemplateFormatType: TEMPLATE_RDBT Indexer: 2),"
//				+ " ignoring...", message);
//
//	}
//
//	@Test
//	public void test_ERROR() throws Exception {
//
//		Query q = entityManager.createNamedQuery("NQ::getConfigEntity");
//		q.setParameter("name", "BEHAVIOR.SEND_HTTP_CALLBACKS");
//		SystemConfigEntity e = (SystemConfigEntity) q.getResultList().get(0);
//		e.setValue("false");
//		entityManager.merge(e);
//
//		PBMuExtractJobResult jobResult = createExtractJobResult(ServiceStateType.SERVICE_STATE_ERROR);
//
//		extractJobBean.completeExtractJobs(jobResult);
//
//		List<Map<String, Object>> listFeJ = jdbcTemplate
//				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, ASSIGNED_TS,"
//						+ " RESULT_TS, RESULT, MU_ID, FAILED_FLAG, FAILURE_COUNT"
//						+ " from FE_JOB_QUEUE order by JOB_ID");
//		assertEquals(1, listFeJ.size());
//		assertEquals("1", listFeJ.get(0).get("JOB_ID").toString());
//		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
//		assertEquals("2", listFeJ.get(0).get("JOB_STATE").toString());
//		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
//		assertTrue(curTime < ((BigDecimal) listFeJ.get(0).get("RESULT_TS"))
//				.longValue());
//		assertNotNull(listFeJ.get(0).get("RESULT"));
//		assertEquals("1", listFeJ.get(0).get("MU_ID").toString());
//		assertEquals("1", listFeJ.get(0).get("FAILED_FLAG").toString());
//		assertEquals("1", listFeJ.get(0).get("FAILURE_COUNT").toString());
//
//		int fljCount = jdbcTemplate.queryForObject(
//				"select count(*) from FE_LOT_JOBS", Integer.class);
//		assertEquals(0, fljCount);
//
//		int load = jdbcTemplate.queryForObject(
//				"select PRESSURE from MU_EXTRACT_LOAD where MU_ID=1",
//				Integer.class);
//		assertEquals(0, load);
//
//		List<Map<String, Object>> listReason = jdbcTemplate
//				.queryForList("select JOB_ID, MU_ID, CODE, REASON, FAILURE_TIME"
//						+ " from FE_JOB_FAILURE_REASONS order by FAILURE_ID");
//		assertEquals(1, listReason.size());
//		assertEquals("1", listReason.get(0).get("JOB_ID").toString());
//		assertEquals("1", listReason.get(0).get("MU_ID").toString());
//		assertEquals("TestCode", listReason.get(0).get("CODE").toString());
//		assertEquals("TestMessage", listReason.get(0).get("REASON").toString());
//		assertEquals("TestTime", listReason.get(0).get("FAILURE_TIME")
//				.toString());
//
//		List<Map<String, Object>> listResult = jdbcTemplate
//				.queryForList("select JOB_ID, RESULT_DATA, TEMPLATE_KEY,"
//						+ " TEMPLATE_INDEX from FE_RESULTS order by TEMPLATE_INDEX");
//		assertEquals(0, listResult.size());
//
//		assertEquals(1, logJobId);
//		assertEquals(0, cbJobId);
//		assertEquals("TestMessage", message);
//	}
//
//	@Test
//	public void test_ROLLBACK_Retry() throws InvalidProtocolBufferException {
//		PBMuExtractJobResult jobResult = createExtractJobResult(ServiceStateType.SERVICE_STATE_ROLLBACK);
//
//		extractJobBean.completeExtractJobs(jobResult);
//
//		List<Map<String, Object>> listFeJ = jdbcTemplate
//				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, ASSIGNED_TS,"
//						+ " RESULT_TS, RESULT, MU_ID, FAILED_FLAG, FAILURE_COUNT"
//						+ " from FE_JOB_QUEUE order by JOB_ID");
//		assertEquals(1, listFeJ.size());
//		assertEquals("1", listFeJ.get(0).get("JOB_ID").toString());
//		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
//		assertEquals("0", listFeJ.get(0).get("JOB_STATE").toString());
//		assertNull(listFeJ.get(0).get("ASSIGNED_TS"));
//		assertNull(listFeJ.get(0).get("RESULT_TS"));
//		assertNull(listFeJ.get(0).get("RESULT"));
//		assertNull(listFeJ.get(0).get("MU_ID"));
//		assertNull(listFeJ.get(0).get("FAILED_FLAG"));
//		assertEquals("1", listFeJ.get(0).get("FAILURE_COUNT").toString());
//
//		int fljCount = jdbcTemplate.queryForObject(
//				"select count(*) from FE_LOT_JOBS", Integer.class);
//		assertEquals(0, fljCount);
//
//		int load = jdbcTemplate.queryForObject(
//				"select PRESSURE from MU_EXTRACT_LOAD where MU_ID=1",
//				Integer.class);
//		assertEquals(0, load);
//
//		List<Map<String, Object>> listReason = jdbcTemplate
//				.queryForList("select JOB_ID, MU_ID, CODE, REASON, FAILURE_TIME"
//						+ " from FE_JOB_FAILURE_REASONS order by FAILURE_ID");
//		assertEquals(1, listReason.size());
//		assertEquals("1", listReason.get(0).get("JOB_ID").toString());
//		assertEquals("1", listReason.get(0).get("MU_ID").toString());
//		assertEquals("TestCode", listReason.get(0).get("CODE").toString());
//		assertEquals("TestMessage", listReason.get(0).get("REASON").toString());
//		assertEquals("TestTime", listReason.get(0).get("FAILURE_TIME")
//				.toString());
//
//		List<Map<String, Object>> listResult = jdbcTemplate
//				.queryForList("select JOB_ID, RESULT_DATA, TEMPLATE_KEY,"
//						+ " TEMPLATE_INDEX from FE_RESULTS order by TEMPLATE_INDEX");
//		assertEquals(0, listResult.size());
//
//		assertEquals(0, logJobId);
//		assertEquals(0, cbJobId);
//		assertEquals("TestMessage", message);
//	}
//
//	@Test
//	public void test_ROLLBACK_Done() throws Exception {
//		jdbcTemplate.execute("update FE_JOB_QUEUE set FAILURE_COUNT = 1");
//		jdbcTemplate.execute("commit");
//
//		Query q = entityManager.createNamedQuery("NQ::getConfigEntity");
//		q.setParameter("name", "BEHAVIOR.SEND_HTTP_CALLBACKS");
//		SystemConfigEntity e = (SystemConfigEntity) q.getResultList().get(0);
//		e.setValue("false");
//		entityManager.merge(e);
//
//		PBMuExtractJobResult jobResult = createExtractJobResult(ServiceStateType.SERVICE_STATE_ROLLBACK);
//
//		extractJobBean.completeExtractJobs(jobResult);
//
//		List<Map<String, Object>> listFeJ = jdbcTemplate
//				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, ASSIGNED_TS,"
//						+ " RESULT_TS, RESULT, MU_ID, FAILED_FLAG, FAILURE_COUNT"
//						+ " from FE_JOB_QUEUE order by JOB_ID");
//		assertEquals(1, listFeJ.size());
//		assertEquals("1", listFeJ.get(0).get("JOB_ID").toString());
//		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
//		assertEquals("2", listFeJ.get(0).get("JOB_STATE").toString());
//		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
//		assertTrue(curTime < ((BigDecimal) listFeJ.get(0).get("RESULT_TS"))
//				.longValue());
//		assertNotNull(listFeJ.get(0).get("RESULT"));
//		assertEquals("1", listFeJ.get(0).get("MU_ID").toString());
//		assertEquals("1", listFeJ.get(0).get("FAILED_FLAG").toString());
//		assertEquals("2", listFeJ.get(0).get("FAILURE_COUNT").toString());
//
//		int fljCount = jdbcTemplate.queryForObject(
//				"select count(*) from FE_LOT_JOBS", Integer.class);
//		assertEquals(0, fljCount);
//
//		int load = jdbcTemplate.queryForObject(
//				"select PRESSURE from MU_EXTRACT_LOAD where MU_ID=1",
//				Integer.class);
//		assertEquals(0, load);
//
//		List<Map<String, Object>> listReason = jdbcTemplate
//				.queryForList("select JOB_ID, MU_ID, CODE, REASON, FAILURE_TIME"
//						+ " from FE_JOB_FAILURE_REASONS order by FAILURE_ID");
//		assertEquals(1, listReason.size());
//		assertEquals("1", listReason.get(0).get("JOB_ID").toString());
//		assertEquals("1", listReason.get(0).get("MU_ID").toString());
//		assertEquals("TestCode", listReason.get(0).get("CODE").toString());
//		assertEquals("TestMessage", listReason.get(0).get("REASON").toString());
//		assertEquals("TestTime", listReason.get(0).get("FAILURE_TIME")
//				.toString());
//
//		List<Map<String, Object>> listResult = jdbcTemplate
//				.queryForList("select JOB_ID, RESULT_DATA, TEMPLATE_KEY,"
//						+ " TEMPLATE_INDEX from FE_RESULTS order by TEMPLATE_INDEX");
//		assertEquals(0, listResult.size());
//
//		assertEquals(1, logJobId);
//		assertEquals(0, cbJobId);
//		assertEquals("TestMessage", message);
//	}
//
//	@Test
//	public void test_ROLLBACK_NULL_MUID_Undo()
//			throws InvalidProtocolBufferException {
//		jdbcTemplate.execute("update FE_JOB_QUEUE set MU_ID = null");
//		jdbcTemplate.execute("commit");
//
//		PBMuExtractJobResult jobResult = createExtractJobResult(ServiceStateType.SERVICE_STATE_ROLLBACK);
//
//		extractJobBean.completeExtractJobs(jobResult);
//
//		List<Map<String, Object>> listFeJ = jdbcTemplate
//				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, ASSIGNED_TS,"
//						+ " RESULT_TS, RESULT, MU_ID, FAILED_FLAG, FAILURE_COUNT"
//						+ " from FE_JOB_QUEUE order by JOB_ID");
//		assertEquals(1, listFeJ.size());
//		assertEquals("1", listFeJ.get(0).get("JOB_ID").toString());
//		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
//		assertEquals("1", listFeJ.get(0).get("JOB_STATE").toString());
//		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
//		assertNull(listFeJ.get(0).get("RESULT_TS"));
//		assertNull(listFeJ.get(0).get("RESULT"));
//		assertNull(listFeJ.get(0).get("MU_ID"));
//		assertNull(listFeJ.get(0).get("FAILED_FLAG"));
//		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());
//
//		int fljCount = jdbcTemplate.queryForObject(
//				"select count(*) from FE_LOT_JOBS", Integer.class);
//		assertEquals(0, fljCount);
//
//		int load = jdbcTemplate.queryForObject(
//				"select PRESSURE from MU_EXTRACT_LOAD where MU_ID=1",
//				Integer.class);
//		assertEquals(1, load);
//
//		List<Map<String, Object>> listReason = jdbcTemplate
//				.queryForList("select JOB_ID, MU_ID, CODE, REASON, FAILURE_TIME"
//						+ " from FE_JOB_FAILURE_REASONS order by FAILURE_ID");
//		assertEquals(0, listReason.size());
//
//		List<Map<String, Object>> listResult = jdbcTemplate
//				.queryForList("select JOB_ID, RESULT_DATA, TEMPLATE_KEY,"
//						+ " TEMPLATE_INDEX from FE_RESULTS order by TEMPLATE_INDEX");
//		assertEquals(0, listResult.size());
//
//		assertEquals(0, logJobId);
//		assertEquals(0, cbJobId);
//		assertEquals("TestMessage", message);
//	}
//
//	@Test
//	public void test_ROLLBACK_Queued_Job_Undo()
//			throws InvalidProtocolBufferException {
//		jdbcTemplate.execute("update FE_JOB_QUEUE set JOB_STATE = 0");
//		jdbcTemplate.execute("commit");
//
//		PBMuExtractJobResult jobResult = createExtractJobResult(ServiceStateType.SERVICE_STATE_ROLLBACK);
//
//		extractJobBean.completeExtractJobs(jobResult);
//
//		List<Map<String, Object>> listFeJ = jdbcTemplate
//				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, ASSIGNED_TS,"
//						+ " RESULT_TS, RESULT, MU_ID, FAILED_FLAG, FAILURE_COUNT"
//						+ " from FE_JOB_QUEUE order by JOB_ID");
//		assertEquals(1, listFeJ.size());
//		assertEquals("1", listFeJ.get(0).get("JOB_ID").toString());
//		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
//		assertEquals("0", listFeJ.get(0).get("JOB_STATE").toString());
//		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
//		assertNull(listFeJ.get(0).get("RESULT_TS"));
//		assertNull(listFeJ.get(0).get("RESULT"));
//		assertEquals("1", listFeJ.get(0).get("MU_ID").toString());
//		assertNull(listFeJ.get(0).get("FAILED_FLAG"));
//		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());
//
//		int fljCount = jdbcTemplate.queryForObject(
//				"select count(*) from FE_LOT_JOBS", Integer.class);
//		assertEquals(0, fljCount);
//
//		int load = jdbcTemplate.queryForObject(
//				"select PRESSURE from MU_EXTRACT_LOAD where MU_ID=1",
//				Integer.class);
//		assertEquals(1, load);
//
//		List<Map<String, Object>> listReason = jdbcTemplate
//				.queryForList("select JOB_ID, MU_ID, CODE, REASON, FAILURE_TIME"
//						+ " from FE_JOB_FAILURE_REASONS order by FAILURE_ID");
//		assertEquals(0, listReason.size());
//
//		List<Map<String, Object>> listResult = jdbcTemplate
//				.queryForList("select JOB_ID, RESULT_DATA, TEMPLATE_KEY,"
//						+ " TEMPLATE_INDEX from FE_RESULTS order by TEMPLATE_INDEX");
//		assertEquals(0, listResult.size());
//
//		assertEquals(0, logJobId);
//		assertEquals(0, cbJobId);
//		assertEquals("TestMessage", message);
//	}
//
//	@Test
//	public void test_SUCCESS_NULL_MUID_Undo()
//			throws InvalidProtocolBufferException {
//		jdbcTemplate.execute("update FE_JOB_QUEUE set MU_ID = null");
//		jdbcTemplate.execute("commit");
//
//		PBMuExtractJobResult jobResult = createExtractJobResult(ServiceStateType.SERVICE_STATE_SUCCESS);
//
//		extractJobBean.completeExtractJobs(jobResult);
//
//		List<Map<String, Object>> listFeJ = jdbcTemplate
//				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, ASSIGNED_TS,"
//						+ " RESULT_TS, RESULT, MU_ID, FAILED_FLAG, FAILURE_COUNT"
//						+ " from FE_JOB_QUEUE order by JOB_ID");
//		assertEquals(1, listFeJ.size());
//		assertEquals("1", listFeJ.get(0).get("JOB_ID").toString());
//		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
//		assertEquals("1", listFeJ.get(0).get("JOB_STATE").toString());
//		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
//		assertNull(listFeJ.get(0).get("RESULT_TS"));
//		assertNull(listFeJ.get(0).get("RESULT"));
//		assertNull(listFeJ.get(0).get("MU_ID"));
//		assertNull(listFeJ.get(0).get("FAILED_FLAG"));
//		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());
//
//		int fljCount = jdbcTemplate.queryForObject(
//				"select count(*) from FE_LOT_JOBS", Integer.class);
//		assertEquals(0, fljCount);
//
//		int load = jdbcTemplate.queryForObject(
//				"select PRESSURE from MU_EXTRACT_LOAD where MU_ID=1",
//				Integer.class);
//		assertEquals(1, load);
//
//		List<Map<String, Object>> listReason = jdbcTemplate
//				.queryForList("select JOB_ID, MU_ID, CODE, REASON, FAILURE_TIME"
//						+ " from FE_JOB_FAILURE_REASONS order by FAILURE_ID");
//		assertEquals(0, listReason.size());
//
//		List<Map<String, Object>> listResult = jdbcTemplate
//				.queryForList("select JOB_ID, RESULT_DATA, TEMPLATE_KEY,"
//						+ " TEMPLATE_INDEX from FE_RESULTS order by TEMPLATE_INDEX");
//		assertEquals(0, listResult.size());
//
//		assertEquals(0, logJobId);
//		assertEquals(0, cbJobId);
//		assertEquals("", message);
//	}
//
//	@Test
//	public void testIncreaseExtractJobCompleteCount() {
//		String initSql = "UPDATE extract_complete_count SET complete_count =0,complete_ts =0";
//		jdbcTemplate.update(initSql);
//		jdbcTemplate.execute("commit");
//		int complitedCount = 5;
//		extractJobBean.increaseExtractJobCompleteCount(complitedCount);
//		String selSql = "select complete_count from extract_complete_count where ROWNUM = 1";
//		Long results = jdbcTemplate.queryForObject(selSql, Long.class);
//		assertEquals(5, results.intValue());
//	}
//
//	@Test
//	public void test_SQLException() throws InvalidProtocolBufferException {	
//		new MockUp<ExtractJobHandler>() {
//			@Mock
//			public int completeExtractJob(long jobId, long muId,
//					PBMuExtractJobResultItem result, boolean failed)
//					throws SQLException, IOException {
//				  throw new SQLException("SQLException in mock");				
//			}
//			
//		};
//		
//			PBMuExtractJobResult jobResult = createPBMuExtractJobResult();
//
//			extractJobBean.completeExtractJobs(jobResult);
//	
//	}
//	
//	private PBMuExtractJobResult createPBMuExtractJobResult() {
//		PBMuExtractJobResult.Builder extJobresult  = PBMuExtractJobResult.newBuilder();
//		extJobresult.setLotJobId(100);
//		extJobresult.setMuId(200);
//		PBMuExtractJobResultItem item = createPBMuExtractJobResultItem();
//		extJobresult.addResult(item);
//		return extJobresult.build();
//		
//	}
//	
//	private PBMuExtractJobResultItem createPBMuExtractJobResultItem() {
//		PBBusinessMessage pbMes = protobufCreater.createPBBusinessMessage();
//		PBMuExtractJobResultItem.Builder item = PBMuExtractJobResultItem.newBuilder();
//		item.setJobId(100);		
//		item.setResult(pbMes.toByteString());
//		return item.build();
//	}
//}
