//package jp.co.nec.aim.mm.aggregator;
//
//import static org.junit.Assert.*;
//
//import java.io.ByteArrayOutputStream;
//import java.io.PrintStream;
//import java.util.List;
//
//import javax.annotation.Resource;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.transaction.Transactional;
//
//
//import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidate;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateTemplate;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatistics;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatisticsAMR;
//
//import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
//import jp.co.nec.aim.mm.constants.JobState;
//import jp.co.nec.aim.mm.dao.InquiryJobDao;
//import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
//import jp.co.nec.aim.mm.entities.JobQueueEntity;
//import jp.co.nec.aim.mm.exception.AimRuntimeException;
//import jp.co.nec.aim.mm.jms.JmsSender;
//import mockit.Mock;
//import mockit.MockUp;
//
//import org.apache.commons.lang3.StringUtils;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import com.google.common.collect.Lists;
//import com.google.protobuf.InvalidProtocolBufferException;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration
//@Transactional
//public class Aggregator2Test {
//
//	private final static Logger log = LoggerFactory
//			.getLogger(Aggregator2Test.class);
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//
//	private JdbcTemplateHelper helper;
//
//	@PersistenceContext(unitName = "aim-db")
//	private EntityManager entityManager;
//	@Resource
//	private Aggregator aggregator;
//
//	private InquiryJobDao inquiryJobDao;
//
//	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
//	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
//	private static PrintStream bk_out = System.out;
//	private static PrintStream bk_err = System.err;
//
//	@Before
//	public void setUp() throws Exception {
//		if (null == helper) {
//			inquiryJobDao = new InquiryJobDao(entityManager);
//			helper = new JdbcTemplateHelper();
//		}
//		// jdbcTemplate.update("delete from job_queue");
//		helper.deleteInquiryJob(jdbcTemplate);
//		helper.scene01(jdbcTemplate);
//		setMockMethod();
//		System.setOut(new PrintStream(outContent));
//		System.setErr(new PrintStream(errContent));
//	}
//
//	@After
//	public void tearDown() throws Exception {
//		helper.deleteInquiryJob(jdbcTemplate);
//		jdbcTemplate.update("delete  from CONTAINER_JOB_FAILURE_REASONS");
//		jdbcTemplate.update("commit");
//		System.setOut(bk_out);
//		System.setErr(bk_err);
//	}
//
//	private void setMockMethod() {
//		new MockUp<JmsSender>() {
//			@Mock
//			private void convertAndSend(String queueName, Object object) {
//				return;
//			}
//		};
//	}
//
//	@Test
//	public void test_oneRecordFailure() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode1(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("insert into CONTAINER_JOB_FAILURE_REASONS(FAILURE_ID,CODE,REASON,FAILURE_TIME,MR_ID,CONTAINER_JOB_ID) values(2,1002,'error message',12345,1,10070)");
//			PBInquiryJobResultInternal.Builder internal = PBInquiryJobResultInternal
//					.newBuilder();
//			internal.setServiceState(PBServiceState
//					.newBuilder()
//					.setState(ServiceStateType.SERVICE_STATE_ERROR)
//					.setReason(
//							PBServiceStateReason.newBuilder().setCode("1002")
//									.setDescription("error message")
//									.setTime("12345")));
//			jdbcTemplate
//					.update("update CONTAINER_JOBS set CONTAINER_JOB_RESULT=? where CONTAINER_JOB_ID=?",
//							new Object[] { internal.build().toByteArray(),
//									10070 });
//			jdbcTemplate.update("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(true, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_ERROR, inquiryResult
//					.getServiceState().getState());
//			assertEquals("error message", inquiryResult.getServiceState()
//					.getReason().getDescription());
//			assertEquals("1002", inquiryResult.getServiceState().getReason()
//					.getCode());
//			assertEquals("12345", inquiryResult.getServiceState().getReason()
//					.getTime());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertFalse(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(0, candidateCount);
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			assertTrue(contains("No CandidateList found in search job results, skip aggregation and callback to client. jobId=1007 "));
//
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_oneRecordRollback() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode1(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("insert into CONTAINER_JOB_FAILURE_REASONS(FAILURE_ID,CODE,REASON,FAILURE_TIME,MR_ID,CONTAINER_JOB_ID) values(2,1002,'error message',12345,1,10070)");
//			PBInquiryJobResultInternal.Builder internal = PBInquiryJobResultInternal
//					.newBuilder();
//			internal.setServiceState(PBServiceState
//					.newBuilder()
//					.setState(ServiceStateType.SERVICE_STATE_ROLLBACK)
//					.setReason(
//							PBServiceStateReason.newBuilder().setCode("1002")
//									.setDescription("error message")
//									.setTime("12345")));
//			jdbcTemplate
//					.update("update CONTAINER_JOBS set CONTAINER_JOB_RESULT=? where CONTAINER_JOB_ID=?",
//							new Object[] { internal.build().toByteArray(),
//									10070 });
//			jdbcTemplate.update("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(true, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, inquiryResult
//					.getServiceState().getState());
//			assertEquals("error message", inquiryResult.getServiceState()
//					.getReason().getDescription());
//			assertEquals("1002", inquiryResult.getServiceState().getReason()
//					.getCode());
//			assertEquals("12345", inquiryResult.getServiceState().getReason()
//					.getTime());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertFalse(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(0, candidateCount);
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			assertTrue(contains("No CandidateList found in search job results, skip aggregation and callback to client. jobId=1007 "));
//
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_TI() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_TI(0);
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 1);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(16, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(16, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(2, candidateCount);
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			PBInquiryCandidate inquiryCandidate = candidateList.get(0);
//			assertEquals(9999, inquiryCandidate.getFusionScore());
//			assertEquals(7800, candidateList.get(1).getFusionScore());
//			assertEquals(true, inquiryCandidate.getHitFlag());
//			assertEquals(4, inquiryCandidate.getCandidateTemplateCount());
//			List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//					.getCandidateTemplateList();
//			List<Integer> requestIndexs = Lists.newArrayList();
//			for (int idx = 0; idx < tamplateList.size(); idx++) {
//				requestIndexs.add(tamplateList.get(idx)
//						.getInquiryRequestIndex());
//			}
//			assertTrue(requestIndexs.contains(0));
//			assertTrue(requestIndexs.contains(1));
//
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_TI_COM() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_TI_COM(0);
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 1);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(16, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(16, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(2, candidateCount);
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			PBInquiryCandidate inquiryCandidate = candidateList.get(0);
//			assertEquals(7619, inquiryCandidate.getFusionScore());
//			assertEquals(4800, candidateList.get(1).getFusionScore());
//			assertEquals(true, inquiryCandidate.getHitFlag());
//			assertEquals(4, inquiryCandidate.getCandidateTemplateCount());
//			List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//					.getCandidateTemplateList();
//			for (int idx = 0; idx < tamplateList.size(); idx++) {
//				assertEquals(0, tamplateList.get(idx).getInquiryRequestIndex());
//			}
//
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_LI() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_LI(0);
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 2);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(16, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(16, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(1, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				assertEquals(1420, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(8, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {
//			
//		}
//	}
//
//	@Test
//	public void test_LI_MultiAxis() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_LI_MultiAxis(0);
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 2);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(20, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(20, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(4, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(892, candidateList.get(0).getFusionScore());
//			assertEquals(380, candidateList.get(1).getFusionScore());
//			assertEquals(360, candidateList.get(2).getFusionScore());
//			assertEquals(30, candidateList.get(3).getFusionScore());
//
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_LI_MultiAxis_other() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_LI_MultiAxis_other(0);
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 2);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(8, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(8, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(2, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(876, candidateList.get(0).getFusionScore());
//			assertEquals(400, candidateList.get(1).getFusionScore());
//
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_LIX() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_LIX(0);
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 23);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(6, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(6, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(2, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(1420, candidateList.get(0).getFusionScore());
//			assertEquals(810, candidateList.get(1).getFusionScore());
//
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {
//			
//		}
//	}
//
//	@Test
//	public void test_IndexNull() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//
//		byte[] bytes1 = PBInquiryJobResultInternal
//				.newBuilder()
//				.setJobId(1)
//				.setServiceState(
//						PBServiceState.newBuilder().setState(
//								ServiceStateType.SERVICE_STATE_SUCCESS))
//				.setStatistics(
//						PBInquiryResultStatistics.newBuilder().setAmr(
//								PBInquiryResultStatisticsAMR.newBuilder()
//										.setMatchCount(30).setReadCount(100)))
//				.setCandidateList(
//						PBInquiryCandidateListInternal.newBuilder()
//								.addCandidate(
//										PBInquiryCandidateInternal.newBuilder()
//												.setConsolidateKey("A-1-1")
//												.setExternalId("A")
//												.setFusionScore(99))).build()
//				.toByteArray();
//
//		byte[] bytes2 = PBInquiryJobResultInternal
//				.newBuilder()
//				.setJobId(1)
//				.setServiceState(
//						PBServiceState.newBuilder().setState(
//								ServiceStateType.SERVICE_STATE_SUCCESS))
//				.setStatistics(
//						PBInquiryResultStatistics.newBuilder().setAmr(
//								PBInquiryResultStatisticsAMR.newBuilder()
//										.setMatchCount(30).setReadCount(100)))
//				.setCandidateList(
//						PBInquiryCandidateListInternal
//								.newBuilder()
//								.addCandidate(
//										PBInquiryCandidateInternal
//												.newBuilder()
//												.setConsolidateKey("A-1-1")
//												.setExternalId("A")
//												.setFusionScore(199)
//												.addCandidateTemplate(
//														PBInquiryCandidateTemplate
//																.newBuilder()
//																.setCompositScore(
//																		50)
//																.setContainerId(
//																		20)
//																.setEventId(1)
//																.setInquiryRequestIndex(
//																		1))))
//				.build().toByteArray();
//
//		jdbcTemplate.update("delete from container_jobs");
//		jdbcTemplate.update("delete from fusion_jobs");
//		jdbcTemplate.update("delete from job_queue");
//		jdbcTemplate
//				.update("insert into JOB_QUEUE(JOB_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID,DYNTHRESH_PERCENTAGE_POINT,DYNTHRESH_HIT_THRESHOLD)values(1,1,1,111,1,10,0,0,1,5.2,2000)");
//		jdbcTemplate
//				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,SEARCH_REQUEST_INDEX)values(1,1,1,1)");
//		jdbcTemplate
//				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,SEARCH_REQUEST_INDEX)values(2,1,1,2)");
//		jdbcTemplate
//				.update("insert into CONTAINER_JOBS(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,JOB_STATE)values(1,1,1,2)");
//		jdbcTemplate
//				.update("insert into CONTAINER_JOBS(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,JOB_STATE)values(2,1,1,2)");
//		jdbcTemplate
//				.update("update CONTAINER_JOBS cj set cj.CONTAINER_JOB_RESULT=?,JOB_STATE=2 where cj.CONTAINER_JOB_ID=1",
//						bytes1);
//		jdbcTemplate
//				.update("update CONTAINER_JOBS cj set cj.CONTAINER_JOB_RESULT=?,JOB_STATE=2 where cj.CONTAINER_JOB_ID=2",
//						bytes2);
//		try {
//			aggregator.doAggregation(1);
//			assertTrue(false);
//		} catch (Exception e) {			
//			assertTrue(e instanceof AimRuntimeException);
//			log.error("@@@@ ", e);
//			assertEquals(
//					"CandidateTemplate list is null or count is zero. jobId=1 threadId=1",
//					e.getCause().getMessage());
//		} finally {
//			
//		}
//	}
//
//	@Test
//	public void test_TLI() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_TLI(0);
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 3);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(16, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(16, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(1, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(2082, candidateList.get(0).getFusionScore());
//			assertEquals(8, candidateList.get(0).getCandidateTemplateList()
//					.size());
//			List<PBInquiryCandidateTemplate> templateList = candidateList
//					.get(0).getCandidateTemplateList();
//			for (int i = 0; i < 8; i++) {
//				Integer index = templateList.get(i).getInquiryRequestIndex();
//				switch (index) {
//				case 0:
//					assertEquals(700, candidateList.get(0)
//							.getCandidateTemplate(0).getCompositScore());
//					assertEquals(400, candidateList.get(0)
//							.getCandidateTemplate(1).getCompositScore());
//					break;
//				case 1:
//					assertEquals(350, candidateList.get(0)
//							.getCandidateTemplate(2).getCompositScore());
//					assertEquals(350, candidateList.get(0)
//							.getCandidateTemplate(3).getCompositScore());
//					break;
//				case 2:
//					assertEquals(720, candidateList.get(0)
//							.getCandidateTemplate(4).getCompositScore());
//					assertEquals(408, candidateList.get(0)
//							.getCandidateTemplate(5).getCompositScore());
//					break;
//				case 3:
//					assertEquals(312, candidateList.get(0)
//							.getCandidateTemplate(6).getCompositScore());
//					assertEquals(312, candidateList.get(0)
//							.getCandidateTemplate(7).getCompositScore());
//					break;
//				default:
//					fail();
//					break;
//				}
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_LLI() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_LLI(0);
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 4);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(8, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(8, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(1, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(1420, candidateList.get(0).getFusionScore());
//			assertEquals(4, candidateList.get(0).getCandidateTemplateList()
//					.size());
//			List<PBInquiryCandidateTemplate> templateList = candidateList
//					.get(0).getCandidateTemplateList();
//			for (int i = 0; i < 2; i++) {
//				Integer index = templateList.get(i).getInquiryRequestIndex();
//				switch (index) {
//				case 0:
//					assertEquals(700, candidateList.get(0)
//							.getCandidateTemplate(0).getCompositScore());
//					assertEquals(400, candidateList.get(0)
//							.getCandidateTemplate(1).getCompositScore());
//					break;
//				case 1:
//					assertEquals(720, candidateList.get(0)
//							.getCandidateTemplate(3).getCompositScore());
//					assertEquals(408, candidateList.get(0)
//							.getCandidateTemplate(4).getCompositScore());
//					break;
//				default:
//					fail();
//					break;
//				}
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {
//			
//		}
//	}
//
//	@Test
//	public void test_LIP() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_LIP();
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 5);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(14, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(14, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(5, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(700, candidateList.get(1).getFusionScore());
//			assertEquals(400, candidateList.get(2).getFusionScore());
//			assertEquals(240, candidateList.get(3).getFusionScore());
//			assertEquals(20, candidateList.get(4).getFusionScore());
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_TLIP() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_TLIP();
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 6);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(10, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(10, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(4, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(400, candidateList.get(1).getFusionScore());
//			assertEquals(240, candidateList.get(2).getFusionScore());
//			assertEquals(20, candidateList.get(3).getFusionScore());
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_LLIP() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_LLIP();
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 6);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(6, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(6, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(2, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(400, candidateList.get(1).getFusionScore());
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_FI() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//			List<String> containerJobResullt = helper.prepareResultXml_FI();
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 20);
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(10, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(10, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(3, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(700, candidateList.get(1).getFusionScore());
//			assertEquals(400, candidateList.get(2).getFusionScore());
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	private boolean contains(String msg) {
//		return StringUtils.contains(outContent.toString(), msg);
//	}
//
//}
