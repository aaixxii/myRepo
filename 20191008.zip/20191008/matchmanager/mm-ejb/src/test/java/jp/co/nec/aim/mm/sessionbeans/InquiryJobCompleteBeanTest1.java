package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.common.ProtobufHelper;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.AggregatorDao;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.procedure.CompleteJobProcedure;
import jp.co.nec.aim.mm.procedure.CorrectInquiryJobProcedure;
import jp.co.nec.aim.mm.procedure.FailureInquiryJobProcedure;
import jp.co.nec.aim.mm.procedure.GetAllContainerJobsProcedure;
import jp.co.nec.aim.mm.procedure.RetryInquiryJobProcedure;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class InquiryJobCompleteBeanTest1 {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private JdbcTemplateHelper helper = new JdbcTemplateHelper();

	@Resource
	private InquiryJobCompleteBean inquiryBean;

	private PBMapInquiryJobResult mapInquiryJobResult;

	private UnitDao unitdao;

	private InquiryJobDao inquiryJobDao;

	private SystemConfigDao systemConfigDao;	

	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private static PrintStream bk_out = System.out;
	private static PrintStream bk_err = System.err;

	@Before
	public void setUp() throws Exception {
		unitdao = new UnitDao(entityManager);
		inquiryJobDao = new InquiryJobDao(entityManager);
		helper = new JdbcTemplateHelper();
		systemConfigDao = new SystemConfigDao(entityManager);		

		helper.deleteInquiryJob(jdbcTemplate);
		helper.deleteFEJobs(jdbcTemplate);
		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteSystemConfig(jdbcTemplate);
		helper.scene01(jdbcTemplate);
		helper.insertMM_SameMMId(jdbcTemplate);
		systemConfigDao.writeAllMissingProperties(ds);
		helper.UpdateSystemConfig(jdbcTemplate,
				MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "true");
		setMockMethod();
		System.setOut(new PrintStream(outContent));
		System.setErr(new PrintStream(errContent));	
	}

	@After
	public void tearDown() throws Exception {		
		helper.deleteInquiryJob(jdbcTemplate);
		helper.deleteFEJobs(jdbcTemplate);
		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteSystemConfig(jdbcTemplate);
		System.setOut(bk_out);
		System.setErr(bk_err);
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object message) {
				System.out.printf("convertAndSend\r\n");
				return;
			}
		};
	}

	/**
	 * mm == null
	 */
	@Test
	public void testCompleteJob_01() {
		String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1001, 10720,
				0, value, 1, 100);
		inquiryBean.completeJob(mapInquiryJobResult);
		MapReducerEntity mu = unitdao.findMR(mapInquiryJobResult.getMrId());
		assertNull(mu);
		assertTrue(contains("findAndWarnState: (complete) Map Reducer id: "
				+ mapInquiryJobResult.getMrId() + " not found in database."));
	}

	/**
	 * remain_jobs > 0
	 */
	@Test
	public void testCompleteJob_02() {
		String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1001, 10720,
				0, value, 1, 100);
		PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
		 List<Long> planIdList = jdbcTemplate
				.queryForList(
						"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
								+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
								+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
						new Object[] { info.getTopLevelJobId(),
								info.getRequestIndex(), info.getContainerId() },
						Long.class);
		 Collections.shuffle(planIdList);
		 long planId = planIdList.get(0);
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		inquiryBean.completeJob(mapInquiryJobResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		//assertNotNull(cj.getContainerJobResult());
		//assertNotNull(cj.getResultTs());
		byte[] older = mapInquiryJobResult.getResult().toByteArray();
		byte[] newer = cj.getContainerJobResult();
		assertEquals(older.length, newer.length);
		for (int index = 0; index < older.length; index++) {
			assertEquals(older[index], newer[index]);
		}
		// assertTrue(contains("RemainJobs for JOB_ID: "
		// + mapInquiryJobResult.getJobInfo().getTopLevelJobId()
		// + " (MR_ID: " + mapInquiryJobResult.getMrId() + ") is 9"));
	}

	/**
	 * remain_jobs < 0 ; remain_jobs=-1;
	 */
	@Test
	public void testCompleteJob_03() {
		String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1000, 10710,
				0, value, 1, 100);
		PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
		long planId = jdbcTemplate
				.queryForObject(
						"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
								+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
								+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
						new Object[] { info.getTopLevelJobId(),
								info.getRequestIndex(), info.getContainerId() },
						Long.class);
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		inquiryBean.completeJob(mapInquiryJobResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);
		assertNull(cj.getResultTs());
		assertNull(cj.getContainerJobResult());
		assertTrue(contains("JOB_ID: "
				+ mapInquiryJobResult.getJobInfo().getTopLevelJobId()
				+ " (MR_ID: " + mapInquiryJobResult.getMrId()
				+ ") JOB_STATE != WORKING or REMAIN_JOBS <= 0"));
	}

	/**
	 * remain_jobs < 0 ; remain_jobs=-2;
	 */
	@Test
	public void testCompleteJob_04() {
		String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1001, 10720,
				1, value, 1, 100);
		PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
		long planId = jdbcTemplate
				.queryForObject(
						"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
								+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
								+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
						new Object[] { info.getTopLevelJobId(),
								info.getRequestIndex(), info.getContainerId() },
						Long.class);
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		inquiryBean.completeJob(mapInquiryJobResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);
		assertNull(cj.getResultTs());
		assertNull(cj.getContainerJobResult());
		assertTrue(contains("JOB_ID: "
				+ mapInquiryJobResult.getJobInfo().getTopLevelJobId()
				+ " (MR_ID: " + mapInquiryJobResult.getMrId()
				+ ") Sequence != FAILURE_COUNT, do nothing"));
	}

	/**
	 * remain_jobs < 0 ; remain_jobs=-3;
	 */
	@Test
	public void testCompleteJob_05() {
		new MockUp<AggregatorDao>() {
			@Mock
			public long updateJobResult(long jobId, int messageSequence,
					long containerJobId, byte[] result) {
				return -3;
			}
		};

		String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1001, 10720,
				1, value, 1, 100);
		PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
		long planId = jdbcTemplate
				.queryForObject(
						"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
								+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
								+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
						new Object[] { info.getTopLevelJobId(),
								info.getRequestIndex(), info.getContainerId() },
						Long.class);
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		inquiryBean.completeJob(mapInquiryJobResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);
		assertNull(cj.getResultTs());
		assertNull(cj.getContainerJobResult());
		assertTrue(contains("JOB_ID: "
				+ mapInquiryJobResult.getJobInfo().getTopLevelJobId()
				+ " (MR_ID: " + mapInquiryJobResult.getMrId()
				+ ") is not WORKING"));

	}

	/**
	 * remain_jobs < 0 ; remain_jobs=-4;
	 */
	@Test
	public void testCompleteJob_06() {
		new MockUp<AggregatorDao>() {
			@Mock
			public long updateJobResult(long jobId, int messageSequence,
					long containerJobId, byte[] result) {
				return -4;
			}
		};

		String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1001, 10720,
				1, value, 1, 100);
		PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
		long planId = jdbcTemplate
				.queryForObject(
						"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
								+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
								+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
						new Object[] { info.getTopLevelJobId(),
								info.getRequestIndex(), info.getContainerId() },
						Long.class);
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		inquiryBean.completeJob(mapInquiryJobResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);
		assertNull(cj.getResultTs());
		assertNull(cj.getContainerJobResult());
		assertTrue(contains("JOB_ID: "
				+ mapInquiryJobResult.getJobInfo().getTopLevelJobId()
				+ " (MR_ID: " + mapInquiryJobResult.getMrId()
				+ ") Could't get lock"));

	}

	/**
	 * remain_jobs < 0 ; remain_jobs=-5;
	 */
	@Test
	public void testCompleteJob_07() {
		new MockUp<AggregatorDao>() {
			@Mock
			public long updateJobResult(long jobId, int messageSequence,
					long containerJobId, byte[] result) {
				return -5;
			}
		};

		String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1001, 10720,
				1, value, 1, 100);
		PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
		long planId = jdbcTemplate
				.queryForObject(
						"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
								+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
								+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
						new Object[] { info.getTopLevelJobId(),
								info.getRequestIndex(), info.getContainerId() },
						Long.class);
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		inquiryBean.completeJob(mapInquiryJobResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);
		assertNull(cj.getResultTs());
		assertNull(cj.getContainerJobResult());
		assertTrue(contains("Returned remainJobs: -5 for MR_ID: "
				+ mapInquiryJobResult.getMrId() + ", it's not supported"));

	}

	/**
	 * remain_jobs == 0 doAggration
	 */
	@Test
	public void testCompleteJob_08() {
		try {
			String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1007,
					10780, 0, value, 2, 100);
			PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
			long planId = jdbcTemplate
					.queryForObject(
							"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
									+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
									+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
							new Object[] { info.getTopLevelJobId(),
									info.getRequestIndex(),
									info.getContainerId() }, Long.class);
			long containerJobId = inquiryJobDao.getContainerJobId(planId);
			DateDao dateDao = new DateDao(ds);
			long lastTs = dateDao.getCurrentTimeMS();
			helper.insertMR(jdbcTemplate, lastTs);
			long jobId = mapInquiryJobResult.getJobInfo().getTopLevelJobId();
			helper.updateJobQueue(jdbcTemplate, jobId);
			List<String> containerJobResullt = helper
					.prepareResultXml_oneRecode(80);
			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);

			helper.updateContianerJob_01(jdbcTemplate, containerJobId);

			InquiryTrafficEntity traffic = inquiryJobDao
					.getInquiryTraffic(jobId);
			Long olderExceCount = traffic.getJobExecCount();
			inquiryBean.completeJob(mapInquiryJobResult);
			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
			assertNotNull(jobQueue.getResults());
			assertNotNull(jobQueue.getResultsTS());
			assertEquals(JobState.DONE, jobQueue.getJobState());
			assertNotNull(jobQueue.getFailedFlag());
			assertEquals(false, jobQueue.getFailedFlag());
			assertEquals(0, jobQueue.getRemainJobs());
			List<ContainerJobEntity> list = inquiryJobDao
					.getAllContainerJob(jobId);
			for (ContainerJobEntity containerJob : list) {
				assertEquals(JobState.DONE, containerJob.getJobState());
				assertNotNull(containerJob.getContainerJobResult());
				assertNotNull(containerJob.getResultTs());
			}

			traffic = inquiryJobDao.getInquiryTraffic(jobId);
			entityManager.refresh(traffic);
			assertEquals(Long.valueOf(olderExceCount - 1),
					traffic.getJobExecCount());	

		IdentifyResponse inquiryResult = IdentifyResponse
					.parseFrom(jobQueue.getResults());
		PBBusinessMessage pbMsg = PBBusinessMessage.parseFrom(inquiryResult.getBusinessMessage(0).toByteArray());
		if (pbMsg.hasDataBlock() && pbMsg.getDataBlock().getDataGroupCount() > 0) {
			pbMsg.getDataBlock().getDataGroupList().forEach( one -> {
				one.getDataElementList().forEach(el -> {
					assertNotNull(el.getElementName());	
				 assertNotNull(el.getElementValue());
				});
			});
		}
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * rollback containerjobId
	 */
	@Test
	public void testCompleteJob_26() {
		new MockUp<InquiryJobDao>() {
			@Mock
			public ContainerJobEntity getContainerJob(long containerJobId) {
				return null;
			}
		};

		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);

		long jobId = 1007;
		long planId = 10780;
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ROLLBACK,
				"Description Not NULL");
		JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		long failuerCount = jobQueue.getFailureCount();
		inquiryBean.completeJob(mapInquiryJobResult);
		jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobQueue);
		assertEquals(failuerCount, jobQueue.getFailureCount());
		assertTrue(contains("Container_Job_ID:10770 is already removed"));
	}

	/**
	 * rollback
	 */
	@Test
	public void testCompleteJob_09() {
		long jobId = 1007;
		long planId = 10780;
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		helper.updateAllContainerJobs(jdbcTemplate, jobId);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ROLLBACK,
				"Description Not NULL");
		JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		long failuerCount = jobQueue.getFailureCount();
		inquiryBean.completeJob(mapInquiryJobResult);
		jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobQueue);
		assertEquals(failuerCount, jobQueue.getFailureCount());
		assertTrue(contains("Container job id could not be found with plan id: 10780"));
	}

	/**
	 * rollback
	 */
	@Test
	public void testCompleteJob_25() {
		long jobId = 1007;
		long planId = 10780;
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		helper.updateAllContainerJobs(jdbcTemplate, jobId);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure02(
				jobId, planId, ServiceStateType.SERVICE_STATE_ROLLBACK,
				"CC&&DD");
		JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		long failuerCount = jobQueue.getFailureCount();
		inquiryBean.completeJob(mapInquiryJobResult);
		jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobQueue);
		assertEquals(failuerCount, jobQueue.getFailureCount());
		assertTrue(contains("Container job id could not be found with plan id: 10780"));
	}

	/**
	 * rollback reason null
	 */
	@Test
	public void testCompleteJob_10() {
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ROLLBACK,
				"Description Not NULL");
		JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		long failuerCount = jobQueue.getFailureCount();
		inquiryBean.completeJob(mapInquiryJobResult);
		jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobQueue);
		assertEquals(failuerCount + 1, jobQueue.getFailureCount());
		assertEquals(JobState.QUEUED, jobQueue.getJobState());
		assertNull(jobQueue.getAssignedTs());// TODO AssignedTs==null
		List<ContainerJobEntity> containerjoblist = inquiryJobDao
				.getAllContainerJob(jobId);
		for (ContainerJobEntity containerjob : containerjoblist) {
			entityManager.refresh(containerjob);
			assertNull(containerjob.getMrId());
			assertNull(containerjob.getAssignedTs());
			assertNull(containerjob.getPlanId());
			assertNull(containerjob.getResultTs());
			assertNull(containerjob.getContainerJobResult());
			assertEquals(JobState.QUEUED, containerjob.getJobState());
		}

		assertEquals(containerjoblist.size(), jobQueue.getRemainJobs());

		InquiryTrafficEntity inquiryTraffic = inquiryJobDao
				.getInquiryTraffic(jobId);
		assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
	}

	/**
	 * rollback reason null error is existed
	 */
	@Test
	public void testCompleteJob_22() {
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure02(
				jobId, planId, ServiceStateType.SERVICE_STATE_ROLLBACK,
				"Description Not NULL");

		JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		long failuerCount = jobQueue.getFailureCount();
		inquiryBean.completeJob(mapInquiryJobResult);
		jobQueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobQueue);
		assertEquals(failuerCount + 1, jobQueue.getFailureCount());
		assertEquals(JobState.QUEUED, jobQueue.getJobState());
		assertNull(jobQueue.getAssignedTs());// TODO AssignedTs==null
		List<ContainerJobEntity> containerjoblist = inquiryJobDao
				.getAllContainerJob(jobId);
		for (ContainerJobEntity containerjob : containerjoblist) {
			entityManager.refresh(containerjob);
			assertNull(containerjob.getMrId());
			assertNull(containerjob.getAssignedTs());
			assertNull(containerjob.getPlanId());
			assertNull(containerjob.getResultTs());
			assertNull(containerjob.getContainerJobResult());
			assertEquals(JobState.QUEUED, containerjob.getJobState());
		}

		assertEquals(containerjoblist.size(), jobQueue.getRemainJobs());

		InquiryTrafficEntity inquiryTraffic = inquiryJobDao
				.getInquiryTraffic(jobId);
		assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
	}

	/**
	 * Error reason is null
	 */
	@Test
	public void testCompleteJob_11() {
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ERROR,
				"Description Not NULL");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());

		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}			
		
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is null
	 */
	@Test
	public void testCompleteJob_24() {
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure02(
				jobId, planId, ServiceStateType.SERVICE_STATE_ERROR,
				"Description Not NULL");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}

		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is not null
	 */
	@Test
	public void testCompleteJob_12() {
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ERROR, "CC&&DD");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}	
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is not null
	 */
	@Test
	public void testCompleteJob_23() {
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure02(
				jobId, planId, ServiceStateType.SERVICE_STATE_ERROR, "CC&&DD");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}	
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is not null systemConfigDao HTTP_CALLBACKS_ENABLED false
	 */
	@Test
	public void testCompleteJob_13() {
		helper.UpdateSystemConfig(jdbcTemplate,
				MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "false");
		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ERROR, "CC&&DD");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is not null url is null and style is xml
	 */
	@Test
	public void testCompleteJob_14() {

		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, null, 0);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ERROR, "CC&&DD");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is not null url is 127.0.0.1 and style is xml
	 */
	@Test
	public void testCompleteJob_15() {

		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, "127.0.0.1", 0);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ERROR, "CC&&DD");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is not null url is 127.0.0.1 and style is protobuf
	 */
	@Test
	public void testCompleteJob_16() {

		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, "127.0.0.1", 1);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ERROR, "CC&&DD");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is not null url is blank and style is xml
	 */
	@Test
	public void testCompleteJob_17() {

		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, "   ", 0);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ERROR, "CC&&DD");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * Error reason is not null url is blank and style is xml
	 */
	@Test
	public void testCompleteJob_18() {

		DateDao dateDao = new DateDao(ds);
		long lastTs = dateDao.getCurrentTimeMS();
		helper.insertMU(jdbcTemplate, lastTs);
		helper.insertMR(jdbcTemplate, lastTs);
		long jobId = 1007;
		long planId = 10780;
		long containerJobId = inquiryJobDao.getContainerJobId(planId);
		helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, " 127.0.0.1 ", 0);
		mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(jobId,
				planId, ServiceStateType.SERVICE_STATE_ERROR, "CC&&DD");
		inquiryBean.completeJob(mapInquiryJobResult);
		JobQueueEntity jobqueue = inquiryJobDao.getTopLevelJob(jobId);
		entityManager.refresh(jobqueue);
		assertEquals(1, jobqueue.getFailureCount());
		ContainerJobEntity containerjob = inquiryJobDao
				.getContainerJob(containerJobId);
		entityManager.refresh(containerjob);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		assertEquals(true, jobqueue.getFailedFlag());
		assertEquals(JobState.DONE, jobqueue.getJobState());
		assertNotNull(jobqueue.getResultsTS());
		assertNotNull(jobqueue.getResults());
		try {
			IdentifyResponse inquiryJobResult = IdentifyResponse
					.parseFrom(jobqueue.getResults());
			PBBusinessMessage pmMsg = PBBusinessMessage.parseFrom(inquiryJobResult.getBusinessMessage(0).toByteArray());
			if (pmMsg.hasResponse() && pmMsg.getResponse().hasStatus()) {
				pmMsg.getResponse().getStatus().toLowerCase().contains("sucess");
			}
		} catch (InvalidProtocolBufferException e) {
			assertFalse(true);
		}
	}

	/**
	 * exception.throwArgException
	 */
	@Test
	public void testCompleteJob_19() {
		try {
			long jobId = 1007;
			long planId = 10780;
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure01(
					jobId, planId, ServiceStateType.SERVICE_STATE_ERROR);
			inquiryBean.completeJob(mapInquiryJobResult);
			assertFalse(true);
		} catch (ArgumentException ex) {
			assertFalse(false);
		}
	}

	/**
	 * exception.throwArgException
	 */
	@Test
	public void testCompleteJob_20() {
		try {
			long jobId = 1007;
			long planId = 10780;
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure01(
					jobId, planId, ServiceStateType.SERVICE_STATE_ROLLBACK);
			inquiryBean.completeJob(mapInquiryJobResult);
			assertFalse(true);
		} catch (ArgumentException ex) {
			assertFalse(false);
		}
	}

	/**
	 * remain_jobs < 0 ; remain_jobs=-2;
	 */
	@Test
	public void testCompleteJob_21() {
		new MockUp<AggregatorDao>() {
			@Mock
			public long updateJobResult(long jobId, int messageSequence,
					long containerJobId, byte[] result) {
				throw new AimRuntimeException("Message Info!!");
			}
		};
		try {
			String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1001,
					10720, 1, value, 1, 100);
			DateDao dateDao = new DateDao(ds);
			long lastTs = dateDao.getCurrentTimeMS();
			helper.insertMU(jdbcTemplate, lastTs);
			helper.insertMR(jdbcTemplate, lastTs);
			inquiryBean.completeJob(mapInquiryJobResult);
			assertFalse(true);
		} catch (AimRuntimeException ex) {
			assertFalse(false);
		}
	}

	@Test
	public void test_oneRecordException01() {
		new MockUp<GetAllContainerJobsProcedure>() {
			@Mock
			public Map<String, Object> action(long topleveljob)
					throws DataAccessException {
				throw new EmptyResultDataAccessException("DataAccessException",
						0);
			}
		};
		try {
			String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
			long planId = 10780;
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1007,
					planId, 0, value, 2, 100);
			long containerJobId = inquiryJobDao.getContainerJobId(planId);
			DateDao dateDao = new DateDao(ds);
			long lastTs = dateDao.getCurrentTimeMS();
			helper.insertMU(jdbcTemplate, lastTs);
			helper.insertMR(jdbcTemplate, lastTs);
			long jobId = mapInquiryJobResult.getJobInfo().getTopLevelJobId();
			helper.updateJobQueue(jdbcTemplate, jobId);
			List<String> containerJobResullt = helper
					.prepareResultXml_oneRecode(80);
			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
			PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
			planId = jdbcTemplate
					.queryForObject(
							"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
									+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
									+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
							new Object[] { info.getTopLevelJobId(),
									info.getRequestIndex(),
									info.getContainerId() }, Long.class);
			helper.updateContianerJob_01(jdbcTemplate, containerJobId);
			inquiryBean.completeJob(mapInquiryJobResult);
			assertFalse(true);
		} catch (AimRuntimeException e) {
			assertTrue(e.getMessage(), true);
		}
	}

	@Test
	public void test_oneRecordException02() {
		new MockUp<CompleteJobProcedure>() {
			@Mock
			public void action(long jobId, byte[] result, boolean failed) {
				throw new EmptyResultDataAccessException("DataAccessException",
						0);
			}
		};
		try {
			String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1007,
					10780, 0, value, 2, 100);
			PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
			long planId = jdbcTemplate
					.queryForObject(
							"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
									+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
									+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
							new Object[] { info.getTopLevelJobId(),
									info.getRequestIndex(),
									info.getContainerId() }, Long.class);
			long containerJobId = inquiryJobDao.getContainerJobId(planId);
			DateDao dateDao = new DateDao(ds);
			long lastTs = dateDao.getCurrentTimeMS();
			helper.insertMU(jdbcTemplate, lastTs);
			helper.insertMR(jdbcTemplate, lastTs);
			long jobId = mapInquiryJobResult.getJobInfo().getTopLevelJobId();
			helper.updateJobQueue(jdbcTemplate, jobId);
			List<String> containerJobResullt = helper
					.prepareResultXml_oneRecode(80);
			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
			helper.updateContianerJob_01(jdbcTemplate, containerJobId);
			inquiryBean.completeJob(mapInquiryJobResult);
			assertFalse(true);
		} catch (AimRuntimeException e) {
			assertTrue(e.getMessage(), true);
		}
	}

	@Test
	public void test_oneRecordException03() {
		new MockUp<CorrectInquiryJobProcedure>() {
			@Mock
			public long action(long jobId, int messageSequence,
					long containerJobId, byte[] result) {
				throw new EmptyResultDataAccessException("DataAccessException",
						0);
			}
		};
		try {
			String value = "ExternalId01,50,ExternalId01-10-1||1,4,0,50@25,10,1@75,10,1@95,10,1";
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResult(1007,
					10780, 0, value, 2, 100);
			PBInquiryJobInfoInternal info = mapInquiryJobResult.getJobInfo();
			long planId = jdbcTemplate
					.queryForObject(
							"select cj.PLAN_ID from JOB_QUEUE jq,FUSION_JOBS fj,CONTAINER_JOBS cj "
									+ "where jq.JOB_ID=fj.JOB_ID and fj.FUSION_JOB_ID=cj.FUSION_JOB_ID "
									+ "and jq.JOB_ID=? and fj.SEARCH_REQUEST_INDEX=? and cj.CONTAINER_ID=?",
							new Object[] { info.getTopLevelJobId(),
									info.getRequestIndex(),
									info.getContainerId() }, Long.class);
			long containerJobId = inquiryJobDao.getContainerJobId(planId);
			DateDao dateDao = new DateDao(ds);
			long lastTs = dateDao.getCurrentTimeMS();
			helper.insertMU(jdbcTemplate, lastTs);
			helper.insertMR(jdbcTemplate, lastTs);
			long jobId = mapInquiryJobResult.getJobInfo().getTopLevelJobId();
			helper.updateJobQueue(jdbcTemplate, jobId);
			List<String> containerJobResullt = helper
					.prepareResultXml_oneRecode(80);
			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
			helper.updateContianerJob_01(jdbcTemplate, containerJobId);

			inquiryBean.completeJob(mapInquiryJobResult);
			assertFalse(true);
		} catch (AimRuntimeException e) {
			assertTrue(e.getMessage(), true);
		}
	}

	@Test
	public void test_oneRecordException04() {

		new MockUp<RetryInquiryJobProcedure>() {
			@Mock
			public long execute(long toplevelJobId) {
				throw new EmptyResultDataAccessException("DataAccessException",
						0);
			}
		};
		try {
			DateDao dateDao = new DateDao(ds);
			long lastTs = dateDao.getCurrentTimeMS();
			helper.insertMU(jdbcTemplate, lastTs);
			helper.insertMR(jdbcTemplate, lastTs);
			long jobId = 1007;
			long planId = 10780;
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(
					jobId, planId, ServiceStateType.SERVICE_STATE_ROLLBACK,
					"Description Not NULL");
			inquiryBean.completeJob(mapInquiryJobResult);
			assertFalse(true);
		} catch (AimRuntimeException e) {
			assertTrue(e.getMessage(), true);
		}
	}

	@Test
	public void test_oneRecordException05() {
		new MockUp<FailureInquiryJobProcedure>() {
			@Mock
			public long action(PBServiceState serviceState, byte[] bJobResult,
					long containerJobId, Long segmentId) {
				throw new EmptyResultDataAccessException("DataAccessException",
						0);
			}
		};

		try {
			DateDao dateDao = new DateDao(ds);
			long lastTs = dateDao.getCurrentTimeMS();
			helper.insertMU(jdbcTemplate, lastTs);
			helper.insertMR(jdbcTemplate, lastTs);
			long jobId = 1007;
			long planId = 10780;
			mapInquiryJobResult = ProtobufHelper.MapInquiryJobResultFailure(
					jobId, planId, ServiceStateType.SERVICE_STATE_ERROR,
					"CC&&DD");
			inquiryBean.completeJob(mapInquiryJobResult);
			assertFalse(true);
		} catch (AimRuntimeException e) {
			assertTrue(e.getMessage(), true);
		}
	}

	private boolean contains(String msg) {
		return StringUtils.contains(outContent.toString(), msg);
	}

}
