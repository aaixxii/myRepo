package jp.co.nec.aim.mm.dao;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.PersonBiometricEntity;

/**
 * SegmentDao
 * 
 * @author liuyq
 * 
 */
public class PersonBiometricDao {

	private EntityManager manager;

	public PersonBiometricDao(EntityManager manager) {
		this.manager = manager;
	}

	/**
	 * findPersonBiometric
	 * 
	 * @param bioId
	 * @return PersonBiometric instance
	 */
	public PersonBiometricEntity findPersonBiometric(long bioId) {
		return manager.find(PersonBiometricEntity.class, bioId);
	}
	
	public int delBioByExternalId (String id) {
		Query q = manager.createNamedQuery("NQ::delBioUsingEnrollId");
		q.setParameter("enrollId", id);
		return q.executeUpdate();
	}

}
