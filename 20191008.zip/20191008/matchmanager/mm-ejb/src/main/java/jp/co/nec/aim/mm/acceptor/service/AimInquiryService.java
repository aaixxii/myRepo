package jp.co.nec.aim.mm.acceptor.service;

import static jp.co.nec.aim.mm.constants.MMConfigProperty.DEFAULT_MAX_CANDIDATES;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.mm.acceptor.AimInquiryRequest;
import jp.co.nec.aim.mm.acceptor.CommonOptions;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

/**
 * The main work flow of inquiry <br>
 * 
 * Include following public method:
 * <p>
 * inquiry, getJobStatus, listJobIds, deleteJob clearJobs, getJobResult,
 * getJobResult
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimInquiryService {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AimInquiryService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	@EJB
	private Inquiry inquiry;	
	private AcceptorValidator validator;
	private InquiryJobDao inquiryJobDao;
	private SystemConfigDao sysConfigDao;
	private DateDao dateDao;
	private ExceptionHelper exception;

	/**
	 * AimInquiryService default constructor
	 */
	public AimInquiryService() {
	}

	@PostConstruct
	private void init() {
		this.inquiryJobDao = new InquiryJobDao(manager, dataSource);
		this.sysConfigDao = new SystemConfigDao(manager);
		this.validator = new AcceptorValidator(manager, dataSource);		
		this.dateDao = new DateDao(dataSource);
		this.exception = new ExceptionHelper(dateDao);
	}

	/**
	 * The main work flow of inquiry
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @param isFromServlet
	 *            IS called by SERVLET
	 * @return PBInquiryJobResponse instance
	 */
	public long inquiry(final IdentifyRequest request,
			boolean isFromServlet) {
		// first check the parameter PBInquiryJobRequest
		// if any error occurred, throw IllegalArgumentException
		// servLet will response 400 (bad request)
		// at the meanwhile convert to new Request		
		PBBusinessMessage pbMes = validator.checkInquiryJobRequest(request);
		log.debug("received identify request batchJobId:{}", request.getBatchJobId());
		final CommonOptions options = new CommonOptions();
		options.setFromServlet(isFromServlet);
		options.setFunctioName("MI");
		if (pbMes.getRequest().hasMaxResults()) {
			options.setMaxCandidates(pbMes.getRequest().getMaxResults());
		} else {
			int sysMaxCandidate = sysConfigDao
					.getMMPropertyInt(DEFAULT_MAX_CANDIDATES);
			// set default MaxCandidates
			options.setMaxCandidates(sysMaxCandidate);
		}
		final List<AimInquiryRequest> aimRequestList = Lists.newArrayList();
		AimInquiryRequest aimInquiryRequest = new AimInquiryRequest("MI",Arrays.asList(1),request.toBuilder());
		aimRequestList.add(aimInquiryRequest);	
		long jobId = inquiry.inquiry(aimRequestList, options);	
		return Long.valueOf(jobId);
	}	


	/**
	 * delete the inquiry Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(PBDeleteJobRequest request) {
		long jobId = request.getJobId();
		try {
			inquiryJobDao.deleteJob(jobId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex, String.format(
					"Exception occurred when when delete "
							+ "inquiry job by job id %s", jobId));
		}
	}

	/**
	 * clear all inquiry Jobs
	 */
	public void clearJobs() {
		try {
			inquiryJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex,
					"Exception occurred when clear inquiry job.");
		}
	}
}
