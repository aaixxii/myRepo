package jp.co.nec.aim.mm.logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;

public class ProtobufDumpLogger {
    private static Logger logger = LoggerFactory.getLogger("protobufdump");
    public ProtobufDumpLogger() {}
    
    public static final void trace(String protobuferTypeName, long batchJobId, String batchType,  PBBusinessMessage psMsg) {
        if (logger.isDebugEnabled()) {           
            StringBuilder sb = new StringBuilder(); 
            sb.append(System.lineSeparator());
            sb.append(protobuferTypeName + ":");
            sb.append(System.lineSeparator());
            sb.append("batchJobId:" + batchJobId);
            sb.append(System.lineSeparator());
            sb.append("batchType:" + batchType);
            sb.append(System.lineSeparator());
            sb.append(psMsg.toString());
            sb.append(System.lineSeparator());       
            sb.append("");
            logger.debug(sb.toString());        
        } 
    } 
    
    public static final void traceAimJobResult(String protobuferTypeName, long jobId, long unitId,  PBBusinessMessage psMsg) {
        if (logger.isDebugEnabled()) {
            StringBuilder sb = new StringBuilder();
            sb.append(System.lineSeparator());
            sb.append(protobuferTypeName + ":");
            sb.append(System.lineSeparator());
            sb.append("jobId:" + jobId);            
            sb.append(System.lineSeparator());
            if (protobuferTypeName.equals("PBMuExtractJobResultItem")) {
                sb.append("muId:" + unitId);
            } else if (protobuferTypeName.equals("PBInquiryJobInfoInternal")) {
                sb.append("mrId:" + unitId);
            }       
            sb.append(System.lineSeparator());
            sb.append(psMsg.toString());
            sb.append(System.lineSeparator());       
            sb.append("");
            logger.debug(sb.toString());             
        } 
    }
}
