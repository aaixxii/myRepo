package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.entities.PersonBiometricEntity;

public class UniqueKeyCheckDao {
	
	private EntityManager em;

	public UniqueKeyCheckDao(EntityManager em) {
		this.em = em;
	}
	
	@SuppressWarnings("unchecked")
	public  List<BatchJobInfoEntity> checkBatchJobId(long batchJobId, String batchType) {
		try {
			Query q = em.createNamedQuery("NQ::checkBatchJobId");
			q.setParameter("batchJobId", batchJobId);
			q.setParameter("batchType", batchType);
			return (List<BatchJobInfoEntity>) q.getResultList();
		} catch (Exception e) {
			return null;
		}

	}
	
	@SuppressWarnings("unchecked")
	public  List<BatchJobInfoEntity> checkRequestId(String reqeustId, String batchType) {
		try {
			Query q = em.createNamedQuery("NQ::checkRequestId");
			q.setParameter("reqId", reqeustId);
			q.setParameter("batchType", batchType);
			return (List<BatchJobInfoEntity>) q.getResultList();
		} catch (Exception e) {
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public  List<PersonBiometricEntity> checkEnrollmentID(String enrollId) {
		try {
			Query q = em.createNamedQuery("NQ::checkEnrollmentID");
			q.setParameter("enrollId", enrollId);
			List<PersonBiometricEntity> results = q.getResultList();
			return results;			
		} catch (Exception e) {
			return null;
		}
	}
	
	
	
	

	
}
