package jp.co.nec.aim.mm.dao;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

public class PartitionDao {
    private static Logger logger = LoggerFactory.getLogger(PartitionDao.class);  
    
    private DataSource ds;
    
    private JdbcTemplate jdbcTemplate; 
    
    private static String getCountSql = "select count(p_no) from segment_change_log";
    private static String initSql = "";
    
    
    public PartitionDao(DataSource ds) {
        this.ds = ds;  
        jdbcTemplate = new JdbcTemplate(ds);
    }
    
    public int getPatitionPnoCount() {        
        return jdbcTemplate.queryForObject(getCountSql, Integer.class);  
    }
    
    public void createPartition(long intPNo) {
        String addPatitionSql = "ALTER TABLE change_log ADD PARTITION ( PARTITION p" + String.valueOf(intPNo)
                + " VALUES IN (" + String.valueOf(intPNo) + "))";        
        jdbcTemplate.execute(addPatitionSql);
    }
    
    public void deletePartition(long intPNo) {
        String clearPartitionSql = "ALTER TABLE change_log TRUNCATE PARTITION p" + String.valueOf(intPNo);
        jdbcTemplate.execute(clearPartitionSql);
        
    }   

    
    public int getDataCountByPNo(Integer intPNo) {
       String getCountInOnePartionSQL = "SELECT * FROM change_log PARTITION (p" + intPNo.toString() + ")";
       return jdbcTemplate.queryForObject(getCountInOnePartionSQL, Integer.class);  
    }    
    
    
}
