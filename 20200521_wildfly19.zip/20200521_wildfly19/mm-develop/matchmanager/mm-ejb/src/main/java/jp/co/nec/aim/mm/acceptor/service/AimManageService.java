package jp.co.nec.aim.mm.acceptor.service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.sessionbeans.SystemInitializationBean;

/**
 * The main work flow of manage <br>
 * 
 * Include following public method:
 * <p>
 * callbackTest, checkExternalId, initialize
 * <p>
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimManageService {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimManageService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@EJB
	private SystemInitializationBean initBean;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	/**
	 * AimManageService constructor
	 */
	public AimManageService() {
	}

	@PostConstruct
	private void init() {
		
	}

	/**
	 * check callback URL is alive or not
	 * 
	 * @param rquest
	 *            PBCallbackRequest instance
	 * @return HTTP response code (500 return when can not be reachable)
	 */


	/**
	 * checkExternalId
	 * 
	 * @param request
	 *            PBCheckExternalIdRequest instance
	 * @return PBCheckExternalIdResponse instance
	 */


	/**
	 * initialize the AIM system
	 */
	public void initialize() {
		if (log.isDebugEnabled()) {
			log.debug("call initialize Aim");
		}
		initBean.initializeAIM();
		if (log.isDebugEnabled()) {
			log.debug("call initialize Aim successfully..");
		}
	}
}
