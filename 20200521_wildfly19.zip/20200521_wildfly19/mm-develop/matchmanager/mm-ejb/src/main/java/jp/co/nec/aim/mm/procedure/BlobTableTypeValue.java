package jp.co.nec.aim.mm.procedure;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import oracle.jdbc.OracleConnection;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;

import com.google.common.collect.Lists;

/**
 * Class represents BLOB_TABLE_TYPE
 * 
 * @author kurosu
 * 
 */
public class BlobTableTypeValue extends AbstractSqlTypeValue {
	private static final String ALTER_SESSION_SQL = "alter session set events '60025 trace name context forever'";
	private byte[][] matrix;
	private List<Blob> blobs;
	private static final String BLOB_TABLE_TYPE = "BLOB_TABLE_TYPE";

	public BlobTableTypeValue(byte[][] matrix) {
		this.matrix = matrix;
	}

	@Override
	protected Object createTypeValue(Connection conn, int sqlType,
			String typeName) throws SQLException {
		OracleConnection oraConn = conn.unwrap(OracleConnection.class);
		try {
			return oraConn.createARRAY(BLOB_TABLE_TYPE,
					createBLOBArray(oraConn));
		} catch (IOException e) {
			throw new AimRuntimeException(e);
		}
	}

	private Blob[] createBLOBArray(OracleConnection oraConn)
			throws SQLException, IOException {
		blobs = Lists.newArrayListWithCapacity(matrix.length);
		for (int i = 0; i < matrix.length; i++) {
			Blob blob = oraConn.createBlob();
			OutputStream stream = blob.setBinaryStream(1L);
			stream.write(matrix[i]);
			stream.flush();
			stream.close();
			blobs.add(blob);
		}
		return blobs.toArray(new Blob[] {});
	}

	/**
	 * Need to call freeTemporary() after craeteTemporary()
	 * 
	 * @param jdbcTemplate
	 * @throws SQLException
	 */
	public void freeTemporary(JdbcTemplate jdbcTemplate) throws SQLException {
		for (Blob blob : blobs) {
			blob.free();
		}
		jdbcTemplate.execute(ALTER_SESSION_SQL);
	}

}
