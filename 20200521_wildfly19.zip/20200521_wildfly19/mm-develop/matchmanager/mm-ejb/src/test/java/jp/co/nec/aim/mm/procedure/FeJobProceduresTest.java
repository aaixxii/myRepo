package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.*;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FeJobProceduresTest {
	
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	
	private FeJobProcedures feJobProcedures;
	

	@Before
	public void setUp() throws Exception {
		jdbcTemplate.update("delete from BATCH_JOB_INFO");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.execute("commit");
		feJobProcedures = new FeJobProcedures(dataSource);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateNewFeJob() throws SQLException {
		String externalId = "1234666666666666";
		byte[] payload = "templatedata".getBytes();
		Long result = feJobProcedures.createNewFeJob(externalId, payload);
		System.out.print(result);	
		
	}

}
