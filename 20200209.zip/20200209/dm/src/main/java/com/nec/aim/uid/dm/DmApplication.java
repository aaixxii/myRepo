package com.nec.aim.uid.dm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

import lombok.extern.slf4j.Slf4j;

/**
 * @author xiazp
 *
 */
@ComponentScan("com.nec.aim.uid.dm")
@EnableAutoConfiguration
@SpringBootApplication
@PropertySource("classpath:application.yml")
@Slf4j
public class DmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DmApplication.class, args);
		log.info("DM Server is running!");
	}

}
