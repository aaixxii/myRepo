package com.nec.aim.uid.dm.segmenter;

import java.io.IOException;

import org.apache.hadoop.fs.ContentSummary;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.nec.aim.uid.dm.HdfsConfig;

import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Slf4j
public class SegmentDownloader {
	
	 private static String HDFS_PATH;
		
	 @Autowired
	 HdfsConfig hdfsConfig; 
	 
	 @Autowired
	 FileSystem fileSystem;
	
	public byte[] getSegmentData(long segmentId) throws IOException {	
		String strPath = HDFS_PATH + "/" + String.valueOf(segmentId);
		 Path newPath = new Path(strPath);
		if (!fileSystem.exists(newPath)) {
			log.warn("file not found");
			return new byte[] {};
		}       
        ContentSummary cSummary = fileSystem.getContentSummary(newPath);
        long length = cSummary.getLength();		
		byte[] byteArr = new byte[(int) length];
		 FSDataOutputStream outputStream = fileSystem.create(newPath, false);
		 outputStream.write(byteArr);
		return byteArr;		
	}	

}
