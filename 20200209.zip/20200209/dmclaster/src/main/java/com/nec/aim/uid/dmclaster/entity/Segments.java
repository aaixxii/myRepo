package com.nec.aim.uid.dmclaster.entity;

import java.io.Serializable;
import java.sql.Blob;


import lombok.Data;

@Data
public class Segments implements Serializable {
    /**
	 * 
	 */
	public Segments() {}
	private static final long serialVersionUID = -5552299464283137498L;

	 
    long segId;    
   
    Blob data;
    
    public Segments(Long id, Blob data) {
    	this.segId = id; 
        this.data = data;	
    }

}
