package com.nec.aim.uid.dmclaster.entity;

import java.io.Serializable;



import lombok.Data;



public class Dm implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -780998884959197663L;

	
    int dmId;
    
   
    String url;
    
   
    String status;
    
    public Dm(Short id) {
    	this.dmId = id;  	
    }
}
