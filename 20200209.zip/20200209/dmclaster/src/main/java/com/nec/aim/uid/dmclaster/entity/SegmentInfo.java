package com.nec.aim.uid.dmclaster.entity;


import java.io.Serializable;
import java.sql.Timestamp;


public class SegmentInfo implements Serializable {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = -3686490055450742690L;

	  
    long segId;
    
   
    long lastVer;
    
   
    long lastOffset;
    
    
    Timestamp lastModified;
    
    
    boolean corruptedFlag;
    
    
    String status;   
    
    public SegmentInfo(Long id) {
    	this.segId = id;
    }
    
    @Override
    public boolean equals(Object obj) {
        return false;
    }
    @Override
    public int hashCode() {
        return 0;        
    }    
}
