package com.nec.aim.uid.dmclaster.entity;

import com.spring4all.spring.boot.starter.hbase.api.RowMapper;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;


public class SegmentsRowMapper implements RowMapper<Segments> {   
    private static byte[] SEG_ID = "segId".getBytes();
    private static byte[] DATA= "data".getBytes();

    @Override
    public Segments mapRow(Result result, int rowNum) throws Exception {
        long segId = Bytes.toLong(result.get(SEG_ID));
        int age = Bytes.toInt(result.getValue(DATA);
    
        Segments dto = new Segments();
        dto.setSegId(segId);
        dto.setData(data);(age);
        return dto;
    }
}
