package com.nec.aim.uid.dmclaster;

import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "spring.data.hbase")
public class HBaseConfig {

    /**
     * zk claster ip
     */
    private static String quorum;
    /**
     * hbase root
     */
    private static String rootDir;
    /**
     * zk node 
     */
    private static String nodeParent;

    /**
     * conncetion to hbase
     *
     * @return
     * @throws IOException
     */
    public static Connection initHbase() throws IOException {

        org.apache.hadoop.conf.Configuration configuration = HBaseConfiguration.create();
        configuration.set("hbase.zookeeper.quorum", quorum);
        Connection connection = ConnectionFactory.createConnection(configuration);
        return connection;
    }

    public void setQuorum(String quorum) {
        HBaseConfig.quorum = quorum;
    }

    public void setRootDir(String rootDir) {
        HBaseConfig.rootDir = rootDir;
    }

    public void setNodeParent(String nodeParent) {
        HBaseConfig.nodeParent = nodeParent;
    }
}
