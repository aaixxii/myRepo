package com.nec.aim.uid.dmclaster.entity;

import java.io.Serializable;


public class SegmengChangeLog implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -1468372533905085999L;

	 	
    long segChangeId;
    
   
    long bioId;
    
    
    long segId;
    
   
    long segVer;
    
   
    short changeType; 
    
    @Override
    public boolean equals(Object obj) {
        return false;
    }
    @Override
    public int hashCode() {
        return 0;        
    }   
}
