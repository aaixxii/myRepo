package com.nec.aim.uid.dmclaster.segmenter;


import org.apache.hadoop.hbase.client.ResultScanner;

import com.nec.aim.uid.dmclaster.entity.Segments;

import java.io.IOException;
import java.util.List;


public interface HBaseService { 
    void createTable(String tableNmae, String[] cols) throws IOException;
   
    void insertData(String tableName,  Segments segs) throws IOException;

    /**
     * 获取原始数据
     *
     * @param tableName 表名
     * @return
     */
    ResultScanner getNoDealData(String tableName);

  
    Segments getDataByRowKey(String tableName, String rowKey) throws IOException;
  
    String getCellData(String tableName, String rowKey, String family, String col);

 
    List<Segments> getAllData(String tableName) throws IOException;

    /**
     * 删除指定cell数据
     *
     * @param tableName 表名
     * @param rowKey    行key
     * @throws IOException
     */
    void deleteByRowKey(String tableName, String rowKey) throws IOException;

    /**
     * 删除表
     *
     * @param tableName 表名
     */
    void deleteTable(String tableName);
}
