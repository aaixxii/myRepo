package com.nec.aim.uid.dmclaster;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmclasterApplicationTests {

	@Test
	void contextLoads() {
	}

}

//https://juejin.im/post/5ce79437518825332d13c572
//https://blog.csdn.net/guolindonggld/article/details/82767620
//create 'emp', 'personal data', ’professional data’
//create 't1', {NAME => 'f1', VERSIONS => 1, TTL => 2592000, BLOCKCACHE => true}