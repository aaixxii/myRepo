//package jp.co.nec.aim.mm.aggregator;
//
//import static org.junit.Assert.*;
//
//import java.io.ByteArrayOutputStream;
//import java.io.PrintStream;
//import java.sql.SQLException;
//import java.util.Collections;
//import java.util.List;
//import java.util.Map;
//
//import javax.annotation.Resource;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.sql.DataSource;
//import javax.transaction.Transactional;
//
//import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryCandidateInternal;
//import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobResultInternal;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidate;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateTemplate;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
//import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
//import jp.co.nec.aim.mm.common.ProtobufHelper;
//import jp.co.nec.aim.mm.constants.ConfigProperties;
//import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
//import jp.co.nec.aim.mm.constants.JobState;
//import jp.co.nec.aim.mm.constants.MMConfigProperty;
//import jp.co.nec.aim.mm.dao.AggregatorDao;
//import jp.co.nec.aim.mm.dao.InquiryJobDao;
//import jp.co.nec.aim.mm.dao.SystemConfigDao;
//import jp.co.nec.aim.mm.entities.ContainerJobEntity;
//import jp.co.nec.aim.mm.entities.ContainerJobFailureReasonEntity;
//import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
//import jp.co.nec.aim.mm.entities.JobQueueEntity;
//import jp.co.nec.aim.mm.exception.AimRuntimeException;
//import jp.co.nec.aim.mm.jms.JmsSender;
//import jp.co.nec.aim.mm.procedure.ContainerJobResult;
//import mockit.Mock;
//import mockit.MockUp;
//
//import org.apache.commons.lang3.StringUtils;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import com.google.common.collect.Lists;
//import com.google.common.collect.Maps;
//import com.google.protobuf.InvalidProtocolBufferException;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration
//@Transactional
//public class AggregatorTest {
//
//	@Resource
//	private DataSource ds;
//
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//
//	private JdbcTemplateHelper helper;
//
//	@PersistenceContext(unitName = "aim-db")
//	private EntityManager entityManager;
//	@Resource
//	private Aggregator aggregator;
//
//	private SystemConfigDao systemConfigDao;
//
//	private InquiryJobDao inquiryJobDao;
//
//	private ByteArrayOutputStream outContent;
//	private ByteArrayOutputStream errContent;
//
//	private static PrintStream bk_out = System.out;
//	private static PrintStream bk_err = System.err;
//
//	@Before
//	public void setUp() throws Exception {
//		if (null == helper) {
//			inquiryJobDao = new InquiryJobDao(entityManager);
//			helper = new JdbcTemplateHelper();
//			systemConfigDao = new SystemConfigDao(entityManager);
//		}
//
//		helper.deleteSystemConfig(jdbcTemplate);
//		// jdbcTemplate.update("delete from job_queue");
//		helper.deleteInquiryJob(jdbcTemplate);
//		helper.scene01(jdbcTemplate);
//		systemConfigDao.writeAllMissingProperties(ds);
//		setMockMethod();
//		outContent = new ByteArrayOutputStream();
//		errContent = new ByteArrayOutputStream();
//		System.setOut(new PrintStream(outContent));
//		System.setErr(new PrintStream(errContent));
//	}
//
//	@After
//	public void tearDown() throws Exception {		
//		System.setOut(bk_out);
//		System.setErr(bk_err);
//	}
//
//	private void setMockMethod() {
//		new MockUp<JmsSender>() {
//			@Mock
//			private void convertAndSend(String queueName, Object object) {
//				System.out.printf("convertAndSend\r\n");
//				return;
//			}
//		};
//	}
//
//	@Test
//	public void testDoAggregation() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecordCompare();
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(8, candidateCount);
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(true, candidateList.get(0).getHitFlag());
//			assertEquals(99, candidateList.get(0).getCandidateTemplateCount());
//			List<PBInquiryCandidateTemplate> tamplateList = candidateList
//					.get(0).getCandidateTemplateList();
//			List<Integer> requestIndexs = Lists.newArrayList();
//			for (int idx = 0; idx < tamplateList.size(); idx++) {
//				requestIndexs.add(tamplateList.get(idx)
//						.getInquiryRequestIndex());
//			}
//
//			assertTrue(requestIndexs.contains(0));
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testDoAggregation_maxCondidates() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecordCompare();
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("update job_queue set max_candidates = 7 where job_id=1007");
//			jdbcTemplate.execute("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(7, candidateCount);
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(9999, candidateList.get(1).getFusionScore());
//			assertEquals(9999, candidateList.get(2).getFusionScore());
//			assertEquals(9999, candidateList.get(3).getFusionScore());
//			assertEquals(9999, candidateList.get(4).getFusionScore());
//			assertEquals(9999, candidateList.get(5).getFusionScore());
//			assertEquals(9999, candidateList.get(6).getFusionScore());
//
//			assertEquals(true, candidateList.get(0).getHitFlag());
//			assertEquals(99, candidateList.get(0).getCandidateTemplateCount());
//			List<PBInquiryCandidateTemplate> tamplateList = candidateList
//					.get(0).getCandidateTemplateList();
//			List<Integer> requestIndexs = Lists.newArrayList();
//			for (int idx = 0; idx < tamplateList.size(); idx++) {
//				requestIndexs.add(tamplateList.get(idx)
//						.getInquiryRequestIndex());
//			}
//
//			assertTrue(requestIndexs.contains(0));
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testDoAggregation_maxCondidates_5() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecordCompare();
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("update job_queue set max_candidates = 5 where job_id=1007");
//			jdbcTemplate.execute("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(5, candidateCount);
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(9999, candidateList.get(1).getFusionScore());
//			assertEquals(9999, candidateList.get(2).getFusionScore());
//			assertEquals(9999, candidateList.get(3).getFusionScore());
//			assertEquals(9999, candidateList.get(4).getFusionScore());
//			assertEquals(true, candidateList.get(0).getHitFlag());
//			assertEquals(99, candidateList.get(0).getCandidateTemplateCount());
//			List<PBInquiryCandidateTemplate> tamplateList = candidateList
//					.get(0).getCandidateTemplateList();
//			List<Integer> requestIndexs = Lists.newArrayList();
//			for (int idx = 0; idx < tamplateList.size(); idx++) {
//				requestIndexs.add(tamplateList.get(idx)
//						.getInquiryRequestIndex());
//			}
//
//			assertTrue(requestIndexs.contains(0));
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testDoAggregation_maxCondidates_5_0() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecordCompare();
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("update job_queue set max_candidates = 5 where job_id=1007");
//			jdbcTemplate.execute("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(5, candidateCount);
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(9999, candidateList.get(1).getFusionScore());
//			assertEquals(9999, candidateList.get(2).getFusionScore());
//			assertEquals(9999, candidateList.get(3).getFusionScore());
//			assertEquals(9999, candidateList.get(4).getFusionScore());
//			assertEquals(true, candidateList.get(0).getHitFlag());
//			assertEquals(99, candidateList.get(0).getCandidateTemplateCount());
//			List<PBInquiryCandidateTemplate> tamplateList = candidateList
//					.get(0).getCandidateTemplateList();
//			List<Integer> requestIndexs = Lists.newArrayList();
//			for (int idx = 0; idx < tamplateList.size(); idx++) {
//				requestIndexs.add(tamplateList.get(idx)
//						.getInquiryRequestIndex());
//			}
//
//			assertTrue(requestIndexs.contains(0));
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testDoAggregation_maxCondidates_null() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecordCompare();
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("update job_queue set max_candidates = null where job_id=1007");
//			jdbcTemplate.execute("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(8, candidateCount);
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(true, candidateList.get(0).getHitFlag());
//			assertEquals(99, candidateList.get(0).getCandidateTemplateCount());
//			List<PBInquiryCandidateTemplate> tamplateList = candidateList
//					.get(0).getCandidateTemplateList();
//			List<Integer> requestIndexs = Lists.newArrayList();
//			for (int idx = 0; idx < tamplateList.size(); idx++) {
//				requestIndexs.add(tamplateList.get(idx)
//						.getInquiryRequestIndex());
//			}
//
//			assertTrue(requestIndexs.contains(0));
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_null() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper.prepareResultXml_null(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertFalse(inquiryResult.hasCandidateList());
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_oneRecord() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(260, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(8, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_twoRecord_onlyMatchCount() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_twoRecord(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 1, 100);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(80, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(8000, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(362, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(16, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				assertTrue(requestIndexs.contains(4));
//				assertTrue(requestIndexs.contains(5));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_twoRecord() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_twoRecord(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 1, 100);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(80, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(8000, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(362, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(16, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				assertTrue(requestIndexs.contains(4));
//				assertTrue(requestIndexs.contains(5));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_twoRecord_sortMerge() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_twoRecord_sortMerge(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 1, 100);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(80, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(8000, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals("ExternalId02", candidateList.get(0).getExternalId());
//			assertEquals(449, candidateList.get(0).getFusionScore());
//
//			assertEquals("ExternalId04", candidateList.get(1).getExternalId());
//			assertEquals(391, candidateList.get(1).getFusionScore());
//
//			assertEquals("ExternalId01", candidateList.get(2).getExternalId());
//			assertEquals(362, candidateList.get(2).getFusionScore());
//
//			assertEquals("ExternalId09", candidateList.get(3).getExternalId());
//			assertEquals(362, candidateList.get(3).getFusionScore());
//
//			assertEquals("ExternalId05", candidateList.get(4).getExternalId());
//			assertEquals(353, candidateList.get(4).getFusionScore());
//
//			assertEquals("ExternalId03", candidateList.get(5).getExternalId());
//			assertEquals(280, candidateList.get(5).getFusionScore());
//
//			assertEquals("ExternalId06", candidateList.get(6).getExternalId());
//			assertEquals(280, candidateList.get(6).getFusionScore());
//
//			assertEquals("ExternalId08", candidateList.get(7).getExternalId());
//			assertEquals(280, candidateList.get(7).getFusionScore());
//
//			assertEquals("ExternalId10", candidateList.get(8).getExternalId());
//			assertEquals(279, candidateList.get(8).getFusionScore());
//
//			assertEquals("ExternalId07", candidateList.get(9).getExternalId());
//			assertEquals(261, candidateList.get(9).getFusionScore());
//
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(16, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * job id is not exist
//	 */
//	@Test
//	public void test_jobIdNull() {
//		try {
//			long jobId = 10;
//			aggregator.doAggregation(jobId);
//			assertTrue(contains("Job 10 queued for aggregation not found, skip aggaregation!"));
//		} finally {			
//		}
//	}
//
//	/**
//	 * job is already been Done
//	 */
//	@Test
//	public void test_jobIdDone() {
//		try {
//			long jobId = 1006;
//			helper.updateJobQueueJobState(jdbcTemplate, jobId);
//			aggregator.doAggregation(jobId);
//			assertTrue(contains("Job 1006 already be DONE, skip to aggregation."));
//		} finally {			
//		}
//	}
//
//	/**
//	 * throw Exception
//	 */
//	@Test
//	public void test_jobIdException() {
//		new MockUp<InquiryJobDao>() {
//			@Mock
//			public JobQueueEntity getTopLevelJob(long jobId)
//					throws SQLException {
//				throw new SQLException("SQLException occoured");
//			}
//		};
//		try {
//			long jobId = 1006;
//			aggregator.doAggregation(jobId);
//			fail();
//		} catch (AimRuntimeException e) {
//			assertTrue(contains("An error occoured during find JOB_QUEUE record for aggregation. jobId=1006"));
//		} finally {			
//		}
//	}
//
//	/**
//	 * notify to jms,HTTP_CALLBACKS_ENABLED is true,url is 127.0.0.1,type is
//	 * protobuf
//	 */
//	@Test
//	public void test_oneRecordAndCallback() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			helper.UpdateSystemConfig(entityManager,
//					MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "true");
//			helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, "127.0.0.1",
//					1);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(260, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(8, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			// assertTrue(contains("JMS SEND to java:/jms/queue/AimAsynchHttpQueue"));
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * notify to jms,HTTP_CALLBACKS_ENABLED is false
//	 */
//	@Test
//	public void test_oneRecordAndCallbackfalse() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			helper.UpdateSystemConfig(entityManager,
//					MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "false");
//			helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, "127.0.0.1",
//					1);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(260, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(8, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			assertFalse(contains("JMS SEND to java:/jms/queue/AimAsynchHttpQueue"));
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * notify to jms,HTTP_CALLBACKS_ENABLED is true url is null
//	 */
//	@Test
//	public void test_oneRecordAndCallbackUrlNull() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			helper.UpdateSystemConfig(entityManager,
//					MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "false");
//			helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, null, 1);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(260, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(8, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			assertFalse(contains("JMS SEND to java:/jms/queue/AimAsynchHttpQueue"));
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * notify to jms,HTTP_CALLBACKS_ENABLED is true url is 127.0.0.1, type is
//	 * xml
//	 */
//	@Test
//	public void test_oneRecordAndCallbackTypeXml() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			helper.UpdateSystemConfig(entityManager,
//					MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "true");
//			helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, "127.0.0.1",
//					0);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(260, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(8, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			// TODO
//			// assertTrue(contains("JMS SEND to queue/AimAsynchHttpQueue"));
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * IsPurgeContainerJobs is false
//	 */
//	@Test
//	public void test_oneRecordIsPurgeContainerJobsfalse() {
//		new MockUp<ConfigProperties>() {
//			@Mock
//			public boolean isPropertyValue(ConfigPropertyNames name) {
//				if (name.equals(ConfigPropertyNames.IS_PURGE_CONTAINER_JOBS)) {
//					return false;
//				} else {
//					String value = ConfigProperties.getInstance()
//							.getPropertyValue(name);
//					return Boolean.valueOf(value);
//				}
//			}
//		};
//
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			helper.UpdateSystemConfig(entityManager,
//					MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "false");
//			helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, null, 1);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(260, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(8, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			List<ContainerJobEntity> containerJobs = inquiryJobDao
//					.getAllContainerJob(jobId);
//			assertEquals(80, containerJobs.size());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * IsPurgeContainerJobs is true
//	 */
//	@Test
//	public void test_oneRecordIsPurgeContainerJobs() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			helper.UpdateSystemConfig(entityManager,
//					MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "false");
//
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(160, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(10, candidateCount);
//			int index = 0;
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//			for (PBInquiryCandidate inquiryCandidate : candidateList) {
//				if (index < 9) {
//					assertEquals("ExternalId0" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				} else {
//					assertEquals("ExternalId" + String.valueOf(index + 1),
//							inquiryCandidate.getExternalId());
//				}
//
//				assertEquals(260, inquiryCandidate.getFusionScore());
//				assertEquals(true, inquiryCandidate.getHitFlag());
//				assertEquals(8, inquiryCandidate.getCandidateTemplateCount());
//				List<PBInquiryCandidateTemplate> tamplateList = inquiryCandidate
//						.getCandidateTemplateList();
//				List<Integer> requestIndexs = Lists.newArrayList();
//				for (int idx = 0; idx < tamplateList.size(); idx++) {
//					requestIndexs.add(tamplateList.get(idx)
//							.getInquiryRequestIndex());
//				}
//
//				assertTrue(requestIndexs.contains(0));
//				assertTrue(requestIndexs.contains(1));
//				assertTrue(requestIndexs.contains(2));
//				assertTrue(requestIndexs.contains(3));
//				index++;
//			}
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			List<ContainerJobEntity> containerJobs = inquiryJobDao
//					.getAllContainerJob(jobId);
//			assertEquals(0, containerJobs.size());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * IsPurgeContainerJobs is true, error
//	 */
//	@Test
//	public void test_oneRecordFailureIsPurgeContainerJobs() {
//		new MockUp<ConfigProperties>() {
//			@Mock
//			public boolean isPropertyValue(ConfigPropertyNames name) {
//				if (name.equals(ConfigPropertyNames.IS_PURGE_CONTAINER_JOBS)) {
//					return false;
//				} else {
//					String value = ConfigProperties.getInstance()
//							.getPropertyValue(name);
//					return Boolean.valueOf(value);
//				}
//			}
//		};
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode1(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("insert into CONTAINER_JOB_FAILURE_REASONS(FAILURE_ID,CODE,REASON,FAILURE_TIME,MR_ID,CONTAINER_JOB_ID) values(2,1002,'error message',12345,1,10070)");
//
//			PBInquiryJobResultInternal.Builder internal = PBInquiryJobResultInternal
//					.newBuilder();
//			internal.setServiceState(PBServiceState
//					.newBuilder()
//					.setState(ServiceStateType.SERVICE_STATE_ERROR)
//					.setReason(
//							PBServiceStateReason.newBuilder().setCode("1002")
//									.setDescription("error message")
//									.setTime("12345")));
//			jdbcTemplate
//					.update("update CONTAINER_JOBS set CONTAINER_JOB_RESULT=? where CONTAINER_JOB_ID=?",
//							new Object[] { internal.build().toByteArray(),
//									10070 });
//			jdbcTemplate.update("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(true, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_ERROR, inquiryResult
//					.getServiceState().getState());
//			assertEquals("error message", inquiryResult.getServiceState()
//					.getReason().getDescription());
//			assertEquals("1002", inquiryResult.getServiceState().getReason()
//					.getCode());
//			assertEquals("12345", inquiryResult.getServiceState().getReason()
//					.getTime());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertFalse(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(0, candidateCount);
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			assertTrue(contains("No CandidateList found in search job results, skip aggregation and callback to client. jobId=1007 "));
//			List<ContainerJobEntity> containerJobs = inquiryJobDao
//					.getAllContainerJob(jobId);
//			assertEquals(80, containerJobs.size());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * IsPurgeContainerJobs is true, rollback
//	 */
//	@Test
//	public void test_oneRecordFailureIsPurgeContainerJobs_RollBack() {
//		new MockUp<ConfigProperties>() {
//			@Mock
//			public boolean isPropertyValue(ConfigPropertyNames name) {
//				if (name.equals(ConfigPropertyNames.IS_PURGE_CONTAINER_JOBS)) {
//					return false;
//				} else {
//					String value = ConfigProperties.getInstance()
//							.getPropertyValue(name);
//					return Boolean.valueOf(value);
//				}
//			}
//		};
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode1(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("insert into CONTAINER_JOB_FAILURE_REASONS(FAILURE_ID,CODE,REASON,FAILURE_TIME,MR_ID,CONTAINER_JOB_ID) values(2,1002,'error message',12345,1,10070)");
//
//			PBInquiryJobResultInternal.Builder internal = PBInquiryJobResultInternal
//					.newBuilder();
//			internal.setServiceState(PBServiceState
//					.newBuilder()
//					.setState(ServiceStateType.SERVICE_STATE_ROLLBACK)
//					.setReason(
//							PBServiceStateReason.newBuilder().setCode("1002")
//									.setDescription("error message")
//									.setTime("12345")));
//			jdbcTemplate
//					.update("update CONTAINER_JOBS set CONTAINER_JOB_RESULT=? where CONTAINER_JOB_ID=?",
//							new Object[] { internal.build().toByteArray(),
//									10070 });
//			jdbcTemplate.update("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(true, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, inquiryResult
//					.getServiceState().getState());
//			assertEquals("error message", inquiryResult.getServiceState()
//					.getReason().getDescription());
//			assertEquals("1002", inquiryResult.getServiceState().getReason()
//					.getCode());
//			assertEquals("12345", inquiryResult.getServiceState().getReason()
//					.getTime());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertFalse(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(0, candidateCount);
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			assertTrue(contains("No CandidateList found in search job results, skip aggregation and callback to client. jobId=1007 "));
//			List<ContainerJobEntity> containerJobs = inquiryJobDao
//					.getAllContainerJob(jobId);
//			assertEquals(80, containerJobs.size());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * IsPurgeContainerJobs is false, error
//	 */
//	@Test
//	public void test_oneRecordFailureIsPurgeContainerJobsfalse() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode1(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			jdbcTemplate
//					.update("insert into CONTAINER_JOB_FAILURE_REASONS(FAILURE_ID,CODE,REASON,FAILURE_TIME,MR_ID,CONTAINER_JOB_ID) values(2,1002,'error message',12345,1,10070)");
//			PBInquiryJobResultInternal.Builder internal = PBInquiryJobResultInternal
//					.newBuilder();
//			internal.setServiceState(PBServiceState
//					.newBuilder()
//					.setState(ServiceStateType.SERVICE_STATE_ERROR)
//					.setReason(
//							PBServiceStateReason.newBuilder().setCode("1002")
//									.setDescription("error message")
//									.setTime("12345")));
//			jdbcTemplate
//					.update("update CONTAINER_JOBS set CONTAINER_JOB_RESULT=? where CONTAINER_JOB_ID=?",
//							new Object[] { internal.build().toByteArray(),
//									10070 });
//			jdbcTemplate.update("commit");
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(true, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_ERROR, inquiryResult
//					.getServiceState().getState());
//			assertEquals("error message", inquiryResult.getServiceState()
//					.getReason().getDescription());
//			assertEquals("1002", inquiryResult.getServiceState().getReason()
//					.getCode());
//			assertEquals("12345", inquiryResult.getServiceState().getReason()
//					.getTime());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertFalse(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(0, candidateCount);
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//			assertTrue(contains("No CandidateList found in search job results, skip aggregation and callback to client. jobId=1007 "));
//			List<ContainerJobEntity> containerJobs = inquiryJobDao
//					.getAllContainerJob(jobId);
//			assertEquals(80, containerJobs.size());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	/**
//	 * notify to jms,HTTP_CALLBACKS_ENABLED is true,url is 127.0.0.1,type is
//	 * otherelse
//	 */
//	@Test
//	public void test_oneRecordAndCallbackType3() {
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			helper.UpdateSystemConfig(entityManager,
//					MMConfigProperty.HTTP_CALLBACKS_ENABLED.getName(), "true");
//			helper.updateJobQueueURLandStyle(jdbcTemplate, jobId, "127.0.0.1",
//					3);
//			try {
//				aggregator.doAggregation(jobId);
//				fail();
//			} catch (AimRuntimeException e) {
//				assertTrue(contains("An error occoured during find JOB_QUEUE record for aggregation. jobId=1007"));
//			}
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_oneRecordMapnull() {
//		new MockUp<AggregatorDao>() {
//			@Mock
//			public Map<String, Object> getAllContainerJobs(long topleveljob) {
//				Map<String, Object> maps = Maps.newHashMap();
//				maps.put("p_failue_refcursor", null);
//				maps.put("p_success_refcursor", null);
//				return maps;
//			}
//		};
//
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(0, inquiryResult.getCandidateList()
//					.getCandidateCount());
//			assertTrue(contains("No CandidateList found in search job results, skip aggregation and callback to client. jobId=1007 "));
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_oneRecordMapEmptry() {
//		new MockUp<AggregatorDao>() {
//			@Mock
//			public Map<String, Object> getAllContainerJobs(long topleveljob) {
//				Map<String, Object> maps = Maps.newHashMap();
//				List<ContainerJobFailureReasonEntity> reasons = Lists
//						.newArrayList();
//				List<ContainerJobResult> jobResults = Lists.newArrayList();
//				maps.put("p_failue_refcursor", reasons);
//				maps.put("p_success_refcursor", jobResults);
//				return maps;
//			}
//		};
//
//		try {
//			long jobId = 1007;
//			List<String> containerJobResullt = helper
//					.prepareResultXml_oneRecode(80);
//			helper.updateDB_01(jdbcTemplate, jobId, containerJobResullt, 2, 2);
//			aggregator.doAggregation(jobId);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertEquals(0, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(0, inquiryResult.getCandidateList()
//					.getCandidateCount());
//			assertTrue(contains("No CandidateList found in search job results, skip aggregation and callback to client. jobId=1007 "));
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	private boolean contains(String msg) {
//		return StringUtils.contains(outContent.toString(), msg);
//	}
//
//	@Test
//	public void test_protobuf() {
//		String str = "LI-001,400,LI-001-1-A||1,3,0,400@400,1,1,{1:23}";
//		PBInquiryJobResultInternal result = ProtobufHelper
//				.InquiryJobResultInternal(Long.valueOf(1007), str, 2, 2);
//		System.out.printf(result.toString());
//	}
//
//	@Test
//	public void testCompare() {
//		List<PBInquiryCandidateInternal> list = Lists.newArrayList();
//		PBInquiryCandidateInternal.Builder builder = PBInquiryCandidateInternal
//				.newBuilder();
//		builder.setConsolidateKey("EventId01-10-01");
//		builder.setFusionScore(80);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId02-10-02");
//		builder.setFusionScore(70);
//		builder.setExternalId("EventId02");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId10-10-10");
//		builder.setFusionScore(50);
//		builder.setExternalId("EventId10");
//		list.add(builder.build());
//		builder.setConsolidateKey("EventId10-10-10");
//		builder.setFusionScore(100);
//		builder.setExternalId("EventId10");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId02-10-02");
//		builder.setFusionScore(90);
//		builder.setExternalId("EventId02");
//		list.add(builder.build());
//
//		Collections.sort(list, new CandidateComparator());
//
//		assertEquals(5, list.size());
//		assertEquals("EventId01-10-01", list.get(0).getConsolidateKey());
//		assertEquals(80, list.get(0).getFusionScore());
//		assertEquals("EventId01", list.get(0).getExternalId());
//		assertEquals("EventId02-10-02", list.get(1).getConsolidateKey());
//		assertEquals(90, list.get(1).getFusionScore());
//		assertEquals("EventId02", list.get(1).getExternalId());
//		assertEquals("EventId02-10-02", list.get(2).getConsolidateKey());
//		assertEquals(70, list.get(2).getFusionScore());
//		assertEquals("EventId02", list.get(2).getExternalId());
//		assertEquals("EventId10-10-10", list.get(3).getConsolidateKey());
//		assertEquals(100, list.get(3).getFusionScore());
//		assertEquals("EventId10", list.get(3).getExternalId());
//		assertEquals("EventId10-10-10", list.get(4).getConsolidateKey());
//		assertEquals(50, list.get(4).getFusionScore());
//		assertEquals("EventId10", list.get(4).getExternalId());
//	}
//
//	@Test
//	public void testCompare_t() {
//		List<PBInquiryCandidateInternal> list = Lists.newArrayList();
//		PBInquiryCandidateInternal.Builder builder = PBInquiryCandidateInternal
//				.newBuilder();
//		builder.setConsolidateKey("EventId01-10");
//		builder.setFusionScore(80);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId02-10-02");
//		builder.setFusionScore(70);
//		builder.setExternalId("EventId02");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId10-10-08");
//		builder.setFusionScore(50);
//		builder.setExternalId("EventId10");
//		list.add(builder.build());
//		builder.setConsolidateKey("EventId10-10-10");
//		builder.setFusionScore(100);
//		builder.setExternalId("EventId10");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId02--03");
//		builder.setFusionScore(90);
//		builder.setExternalId("EventId02");
//		list.add(builder.build());
//
//		Collections.sort(list, new CandidateComparator());
//
//		assertEquals(5, list.size());
//		assertEquals("EventId01-10", list.get(0).getConsolidateKey());
//		assertEquals(80, list.get(0).getFusionScore());
//		assertEquals("EventId01", list.get(0).getExternalId());
//		assertEquals("EventId02--03", list.get(1).getConsolidateKey());
//		assertEquals(90, list.get(1).getFusionScore());
//		assertEquals("EventId02", list.get(1).getExternalId());
//		assertEquals("EventId02-10-02", list.get(2).getConsolidateKey());
//		assertEquals(70, list.get(2).getFusionScore());
//		assertEquals("EventId02", list.get(2).getExternalId());
//		assertEquals("EventId10-10-08", list.get(3).getConsolidateKey());
//		assertEquals(50, list.get(3).getFusionScore());
//		assertEquals("EventId10", list.get(3).getExternalId());
//		assertEquals("EventId10-10-10", list.get(4).getConsolidateKey());
//		assertEquals(100, list.get(4).getFusionScore());
//		assertEquals("EventId10", list.get(4).getExternalId());
//	}
//
//	@Test
//	public void testCompare_A() {
//		List<PBInquiryCandidateInternal> list = Lists.newArrayList();
//		PBInquiryCandidateInternal.Builder builder = PBInquiryCandidateInternal
//				.newBuilder();
//		builder.setConsolidateKey("EventId01-10");
//		builder.setFusionScore(80);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId02-10-B");
//		builder.setFusionScore(70);
//		builder.setExternalId("EventId02");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId10-10-D");
//		builder.setFusionScore(50);
//		builder.setExternalId("EventId10");
//		list.add(builder.build());
//		builder.setConsolidateKey("EventId10-10-A");
//		builder.setFusionScore(100);
//		builder.setExternalId("EventId10");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId02--B");
//		builder.setFusionScore(90);
//		builder.setExternalId("EventId02");
//		list.add(builder.build());
//
//		Collections.sort(list, new CandidateComparator());
//
//		assertEquals(5, list.size());
//		assertEquals("EventId01-10", list.get(0).getConsolidateKey());
//		assertEquals(80, list.get(0).getFusionScore());
//		assertEquals("EventId01", list.get(0).getExternalId());
//		assertEquals("EventId02--B", list.get(1).getConsolidateKey());
//		assertEquals(90, list.get(1).getFusionScore());
//		assertEquals("EventId02", list.get(1).getExternalId());
//		assertEquals("EventId02-10-B", list.get(2).getConsolidateKey());
//		assertEquals(70, list.get(2).getFusionScore());
//		assertEquals("EventId02", list.get(2).getExternalId());
//		assertEquals("EventId10-10-A", list.get(3).getConsolidateKey());
//		assertEquals(100, list.get(3).getFusionScore());
//		assertEquals("EventId10", list.get(3).getExternalId());
//		assertEquals("EventId10-10-D", list.get(4).getConsolidateKey());
//		assertEquals(50, list.get(4).getFusionScore());
//		assertEquals("EventId10", list.get(4).getExternalId());
//	}
//
//	@Test
//	public void testCompare_B() {
//		List<PBInquiryCandidateInternal> list = Lists.newArrayList();
//		PBInquiryCandidateInternal.Builder builder = PBInquiryCandidateInternal
//				.newBuilder();
//		builder.setConsolidateKey("EventId01-10-A");
//		builder.setFusionScore(80);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId01-10-A");
//		builder.setFusionScore(70);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId01-10-A");
//		builder.setFusionScore(50);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.setConsolidateKey("EventId01-10-A");
//		builder.setFusionScore(100);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId01-10-A");
//		builder.setFusionScore(100);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId01-10-A");
//		builder.setFusionScore(60);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//		builder.setConsolidateKey("EventId01-10-A");
//		builder.setFusionScore(90);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//
//		Collections.sort(list, new CandidateComparator());
//
//		assertEquals(7, list.size());
//		assertEquals("EventId01-10-A", list.get(0).getConsolidateKey());
//		assertEquals(100, list.get(0).getFusionScore());
//		assertEquals("EventId01", list.get(0).getExternalId());
//		assertEquals("EventId01-10-A", list.get(1).getConsolidateKey());
//		assertEquals(100, list.get(1).getFusionScore());
//		assertEquals("EventId01", list.get(1).getExternalId());
//		assertEquals("EventId01-10-A", list.get(2).getConsolidateKey());
//		assertEquals(90, list.get(2).getFusionScore());
//		assertEquals("EventId01", list.get(2).getExternalId());
//		assertEquals("EventId01-10-A", list.get(3).getConsolidateKey());
//		assertEquals(80, list.get(3).getFusionScore());
//		assertEquals("EventId01", list.get(3).getExternalId());
//		assertEquals("EventId01-10-A", list.get(4).getConsolidateKey());
//		assertEquals(70, list.get(4).getFusionScore());
//		assertEquals("EventId01", list.get(4).getExternalId());
//		assertEquals("EventId01-10-A", list.get(5).getConsolidateKey());
//		assertEquals(60, list.get(5).getFusionScore());
//		assertEquals("EventId01", list.get(5).getExternalId());
//		assertEquals("EventId01-10-A", list.get(6).getConsolidateKey());
//		assertEquals(50, list.get(6).getFusionScore());
//		assertEquals("EventId01", list.get(6).getExternalId());
//	}
//
//	@Test
//	public void testCompare_C() {
//		List<PBInquiryCandidate> list = Lists.newArrayList();
//		PBInquiryCandidate.Builder builder = PBInquiryCandidate.newBuilder();
//		builder.setHitFlag(true);
//		builder.setFusionScore(80);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//
//		builder.setHitFlag(true);
//		builder.setFusionScore(70);
//		builder.setExternalId("EventId01");
//		list.add(builder.build());
//		builder.clear();
//
//		builder.setHitFlag(true);
//		builder.setFusionScore(50);
//		builder.setExternalId("EventId02");
//		list.add(builder.build());
//		builder.clear();
//
//		builder.setHitFlag(true);
//		builder.setFusionScore(100);
//		builder.setExternalId("EventId02");
//		list.add(builder.build());
//		builder.clear();
//
//		builder.setHitFlag(true);
//		builder.setFusionScore(100);
//		builder.setExternalId("EventId03");
//		list.add(builder.build());
//		builder.clear();
//
//		builder.setHitFlag(true);
//		builder.setFusionScore(60);
//		builder.setExternalId("EventId03");
//		list.add(builder.build());
//		builder.clear();
//
//		builder.setHitFlag(true);
//		builder.setFusionScore(60);
//		builder.setExternalId("EventId03");
//		list.add(builder.build());
//
//		Collections.sort(list, new CandidateMergeComparator());
//
//		assertEquals(7, list.size());
//		assertEquals(100, list.get(0).getFusionScore());
//		assertEquals("EventId02", list.get(0).getExternalId());
//		assertEquals(100, list.get(1).getFusionScore());
//		assertEquals("EventId03", list.get(1).getExternalId());
//		assertEquals(80, list.get(2).getFusionScore());
//		assertEquals("EventId01", list.get(2).getExternalId());
//		assertEquals(70, list.get(3).getFusionScore());
//		assertEquals("EventId01", list.get(3).getExternalId());
//		assertEquals(60, list.get(4).getFusionScore());
//		assertEquals("EventId03", list.get(4).getExternalId());
//		assertEquals(60, list.get(5).getFusionScore());
//		assertEquals("EventId03", list.get(5).getExternalId());
//		assertEquals(50, list.get(6).getFusionScore());
//		assertEquals("EventId02", list.get(6).getExternalId());
//	}
//
//	@Test
//	public void testCompare_D() {
//		List<PBInquiryCandidateInternal> list = Lists.newArrayList();
//		PBInquiryCandidateInternal.Builder builder = PBInquiryCandidateInternal
//				.newBuilder();
//		builder.setConsolidateKey("EventId01-10-A");
//		builder.setFusionScore(8000);
//		builder.setExternalId("EventId_01");
//		list.add(builder.build());
//		builder.clear();
//
//		builder.setConsolidateKey("EventId02-10-A");
//		builder.setFusionScore(9999);
//		builder.setExternalId("EventId_02");
//		list.add(builder.build());
//
//		Collections.sort(list, new CandidateComparatorMerge());
//
//		assertEquals(2, list.size());
//
//		assertEquals(9999, list.get(0).getFusionScore());
//		assertEquals("EventId_02", list.get(0).getExternalId());
//		assertEquals(8000, list.get(1).getFusionScore());
//		assertEquals("EventId_01", list.get(1).getExternalId());
//	}
//
//	@Test
//	public void test_LIP_maxCandiate_1() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//
//			List<String> containerJobResullt = helper.prepareResultXml_LIP();
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 5);
//			jdbcTemplate
//					.update("update job_queue set max_candidates = 1 where job_id=1");
//			jdbcTemplate.execute("commit");
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(14, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(14, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(1, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//
//	@Test
//	public void test_LIP_maxCandiate_3() throws InvalidProtocolBufferException {
//		helper.deleteInquiryJob(jdbcTemplate);
//		try {
//			long jobId = 1;
//
//			List<String> containerJobResullt = helper.prepareResultXml_LIP();
//			helper.updateDB_common(jdbcTemplate, jobId, containerJobResullt, 2,
//					2, 5);
//			jdbcTemplate
//					.update("update job_queue set max_candidates = 3 where job_id=1");
//			jdbcTemplate.execute("commit");
//			aggregator.doAggregation(1);
//			JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(jobId);
//			assertEquals(JobState.DONE, jobQueue.getJobState());
//			assertEquals(false, jobQueue.getFailedFlag());
//			assertNotNull(jobQueue.getResultsTS());
//			PBInquiryJobResult inquiryResult = PBInquiryJobResult
//					.parseFrom(jobQueue.getResults());
//			assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, inquiryResult
//					.getServiceState().getState());
//			assertEquals(14, inquiryResult.getStatistics().getAmr()
//					.getMatchCount());
//			assertEquals(14, inquiryResult.getStatistics().getAmr()
//					.getReadCount());
//			assertTrue(inquiryResult.hasCandidateList());
//			long candidateCount = inquiryResult.getCandidateList()
//					.getCandidateCount();
//			assertEquals(3, candidateCount);
//
//			List<PBInquiryCandidate> candidateList = inquiryResult
//					.getCandidateList().getCandidateList();
//
//			assertEquals(9999, candidateList.get(0).getFusionScore());
//			assertEquals(700, candidateList.get(1).getFusionScore());
//			assertEquals(400, candidateList.get(2).getFusionScore());
//			InquiryTrafficEntity inquiryTraffic = inquiryJobDao
//					.getInquiryTraffic(jobId);
//			assertEquals(Long.valueOf(1), inquiryTraffic.getJobExecCount());
//		} catch (InvalidProtocolBufferException e) {
//			assertFalse(e.getMessage(), true);
//		} finally {			
//		}
//	}
//}
