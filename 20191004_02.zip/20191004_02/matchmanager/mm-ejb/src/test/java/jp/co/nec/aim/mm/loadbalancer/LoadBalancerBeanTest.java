package jp.co.nec.aim.mm.loadbalancer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.common.TestLogger;
import jp.co.nec.aim.mm.dao.LoadBalancerDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.wakeup.ReportWakeUp;
import jp.co.nec.slb.exception.DeployExcrption;
import jp.co.nec.slb.loadbalance.Deployment;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class LoadBalancerBeanTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private LoadBalancerBean slbBean;

	@BeforeClass
	public static void setUpClass() {
		new MockUp<LoggerFactory>() {
			@Mock
			public Logger getLogger(String name) {
				return new TestLogger();
			}
		};
	}

	@AfterClass
	public static void tearDownClass() {		
	}

	@Before
	public void setUp() throws Exception {
		clearDB();

		jdbcTemplate.execute("insert into MATCH_MANAGERS(MM_ID, UNIQUE_ID,"
				+ " STATE, CONTACT_URL, HEARTBEAT_TS, VERSION) values(1,"
				+ " 'UNIQUE_ID', 'WORKING', 'CONTACT_URL', 1421206612748,"
				+ " '1')");
		jdbcTemplate.execute("insert into MM_EVENTS(NAME, LAST_TS, MM_ID)"
				+ " values('SEGMENT_LOAD_BALANCING', 1421206612748, 1)");

		TestLogger.isDebugEnabled = false;
		TestLogger.level = "";
		TestLogger.message = "";
	}

	@After
	public void tearDown() throws Exception {
		slbBean.clearCache();
		jdbcTemplate.execute("update CONTAINERS set MIN_REDUNDANCY = 1");
		clearDB();
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from DM_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_FUNCTIONS");
		jdbcTemplate.execute("delete from DM_SEG_REPORTS");
		jdbcTemplate.execute("delete from MU_SEG_REPORTS");
		jdbcTemplate.execute("delete from DM_SEGMENTS");
		jdbcTemplate.execute("delete from MU_SEGMENTS");
		jdbcTemplate.execute("delete from SEGMENTS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("delete from MM_EVENTS");
		jdbcTemplate.execute("delete from MATCH_MANAGERS");
		jdbcTemplate.execute("commit");
	}

	private void insertUnit(int startMUId, int muCount, int startDMId,
			int dmCount) {
		for (int id = startMUId; id < startMUId + muCount; id++) {
			jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID, UNIQUE_ID,"
					+ " STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR)"
					+ " values(" + id + ", '" + id + "', 'WORKING', 5, 1.0)");
			jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"
					+ " values(" + id + ", 1421206612748)");
		}

		for (int id = startDMId; id < startDMId + dmCount; id++) {
			jdbcTemplate.execute("insert into DATA_MANAGERS(DM_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into DM_CONTACTS(DM_ID, CONTACT_TS)"
					+ " values(" + id + ", 1421206612748)");
		}
	}

	private void insertEligible(int startMUId, int muCount, int startDMId,
			int dmCount) {
		for (int id = startMUId; id < startMUId + muCount; id++) {
			jdbcTemplate.execute("insert into MU_ELIGIBLE_CONTAINERS(MU_ID,"
					+ " CONTAINER_ID) select  " + id
					+ " as MU_ID, CONTAINER_ID from CONTAINERS");
		}

		for (int id = startDMId; id < startDMId + dmCount; id++) {
			jdbcTemplate.execute("insert into DM_ELIGIBLE_CONTAINERS(DM_ID,"
					+ " CONTAINER_ID) select  " + id
					+ " as DM_ID, CONTAINER_ID from CONTAINERS");
		}
	}

	private void insertSegments(int segCount, long containerId, int startId) {
		for (int id = startId; id <= segCount + startId - 1; id++) {
			jdbcTemplate.execute("insert into SEGMENTS(SEGMENT_ID,"
					+ " CONTAINER_ID, BIO_ID_START, BIO_ID_END, RECORD_COUNT,"
					+ " VERSION, REVISION, BINARY_LENGTH_COMPACTED,"
					+ " BINARY_LENGTH_UNCOMPACTED) values(" + id + ", "
					+ containerId + ", 1, 100, 100, 100, 100, 10000, 10000)");

		}
	}

	private void insertMuSeg(boolean[][] matrix, int startMUId, int muCount,
			int startDMId, int dmCount) {
		for (int unitId = 1; unitId <= muCount; unitId++) {
			for (int segId = 1; segId <= matrix[0].length; segId++) {
				if (matrix[unitId - 1][segId - 1] == true) {
					jdbcTemplate.execute("insert into MU_SEGMENTS(MU_ID, "
							+ " SEGMENT_ID, RANK) values("
							+ (unitId + startMUId - 1) + ", " + segId + ", 0)");
				}
			}
		}
		for (int unitId = 1; unitId <= dmCount; unitId++) {
			for (int segId = 1; segId <= matrix[0].length; segId++) {
				if (matrix[unitId - 1][segId - 1] == true) {
					jdbcTemplate.execute("insert into DM_SEGMENTS(DM_ID, "
							+ " SEGMENT_ID, RANK) values("
							+ (unitId + startDMId - 1) + ", " + segId + ", 0)");
				}
			}
		}
	}

	private void insertMuSegReport(boolean[][] matrix, int startMUId,
			int muCount, int startDMId, int dmCount) {
		for (int unitId = 1; unitId <= muCount; unitId++) {
			for (int segId = 1; segId <= matrix[0].length; segId++) {
				if (matrix[unitId - 1][segId - 1] == true) {
					jdbcTemplate.execute("insert into MU_SEG_REPORTS(MU_ID, "
							+ " SEGMENT_ID, STATUS, SEGMENT_VERSION, "
							+ "SEGMENT_QUEUED_VERSION) values("
							+ (unitId + startMUId - 1) + ", " + segId
							+ ", 0, 100, 100)");
				}
			}
		}
		for (int unitId = 1; unitId <= dmCount; unitId++) {
			for (int segId = 1; segId <= matrix[0].length; segId++) {
				if (matrix[unitId - 1][segId - 1] == true) {
					jdbcTemplate.execute("insert into DM_SEG_REPORTS(DM_ID, "
							+ " SEGMENT_ID, STATUS, SEGMENT_VERSION)"
							+ " values(" + (unitId + startDMId - 1) + ", "
							+ segId + ", 0, 100)");
				}
			}
		}
	}

	@Test
	public void test_SLB_Disable() {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'false')");

		slbBean.executeSLB();

		List<Map<String, Object>> listDmSegMap = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");
		assertEquals(0, listDmSegMap.size());

		List<Map<String, Object>> listMuSegMap = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");
		assertEquals(0, listMuSegMap.size());
	}

	@Test
	public void test_SLB_NoEligibleUnit() {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");

		insertSegments(10, 3, 1);
		insertUnit(1, 6, 7, 6);

		slbBean.executeSLB();

		List<Map<String, Object>> listDmSegMap = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");
		assertEquals(0, listDmSegMap.size());

		List<Map<String, Object>> listMuSegMap = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");
		assertEquals(0, listMuSegMap.size());
	}

	@Test
	public void test_SLB_NoSegment() {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");

		slbBean.executeSLB();

		List<Map<String, Object>> listDmSegMap = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");
		assertEquals(0, listDmSegMap.size());

		List<Map<String, Object>> listMuSegMap = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");
		assertEquals(0, listMuSegMap.size());
	}

	@Test
	public void test_SLB_Redundancy_0() {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(2,"
				+ " 'LOAD_BALANCER.DEFAULT_DM_MIN_REDUNDANCY', '0')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(3,"
				+ " 'LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY', '0')");
		jdbcTemplate.execute("update CONTAINERS set MIN_REDUNDANCY = null");

		insertSegments(10, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		slbBean.executeSLB();

		List<Map<String, Object>> listDmSegMap = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");
		assertEquals(0, listDmSegMap.size());

		List<Map<String, Object>> listMuSegMap = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");
		assertEquals(0, listMuSegMap.size());
	}

	@Test
	public void test_SLB_NoChange() {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(2,"
				+ " 'LOAD_BALANCER.DEFAULT_DM_MIN_REDUNDANCY', '2')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(3,"
				+ " 'LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY', '2')");
		jdbcTemplate.execute("update CONTAINERS set MIN_REDUNDANCY = 2");

		insertSegments(10, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSeg(matrix, 1, 6, 7, 6);
		insertMuSegReport(matrix, 1, 6, 7, 6);
		jdbcTemplate.execute("commit");

		final List<Long> unitList = new ArrayList<Long>();
		new MockUp<ReportWakeUp>() {
			@Mock
			public void notifyMessage(Set<Long> unitList) {
				unitList.addAll(unitList);
				return;
			}
		};

		slbBean.executeSLB();

		int unitIds[] = new int[] { 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 1, 2, 7, 8, 2, 3, 8, 9, 3, 4, 9, 4, 5, 10,
				1, 5, 6, 6, 7, 10 };

		List<Map<String, Object>> listDmSegMap = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");
		assertEquals(20, listDmSegMap.size());
		for (int i = 0; i < listDmSegMap.size(); i++) {
			assertEquals("" + (unitIds[i] + 6), listDmSegMap.get(i)
					.get("DM_ID").toString());
			assertEquals("" + segIds[i], listDmSegMap.get(i).get("SEGMENT_ID")
					.toString());
		}
		List<Map<String, Object>> listMuSegMap = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");
		assertEquals(20, listMuSegMap.size());
		for (int i = 0; i < listMuSegMap.size(); i++) {
			assertEquals("" + unitIds[i], listMuSegMap.get(i).get("MU_ID")
					.toString());
			assertEquals("" + segIds[i], listMuSegMap.get(i).get("SEGMENT_ID")
					.toString());
		}

		assertEquals(0, unitList.size());

	}

	@Test
	public void test_SLB_Less_Redundancy() {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(2,"
				+ " 'LOAD_BALANCER.DEFAULT_DM_MIN_REDUNDANCY', '2')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(3,"
				+ " 'LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY', '2')");
		jdbcTemplate.execute("update CONTAINERS set MIN_REDUNDANCY = 2");

		insertSegments(10, 3, 1);
		insertUnit(1, 1, 2, 1);
		insertEligible(1, 1, 2, 1);

		final List<Long> unitList = new ArrayList<Long>();
		new MockUp<ReportWakeUp>() {
			@Mock
			public void notifyMessage(Set<Long> unitIds) {
				unitList.addAll(unitIds);
				return;
			}
		};

		slbBean.executeSLB();

		List<Map<String, Object>> listDmSegMap = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");
		assertEquals(10, listDmSegMap.size());
		for (int i = 0; i < listDmSegMap.size(); i++) {
			assertEquals("2", listDmSegMap.get(i).get("DM_ID").toString());
			assertEquals("" + (i + 1), listDmSegMap.get(i).get("SEGMENT_ID")
					.toString());
		}
		List<Map<String, Object>> listMuSegMap = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");
		assertEquals(10, listMuSegMap.size());
		for (int i = 0; i < listMuSegMap.size(); i++) {
			assertEquals("1", listMuSegMap.get(i).get("MU_ID").toString());
			assertEquals("" + (i + 1), listMuSegMap.get(i).get("SEGMENT_ID")
					.toString());
		}

		assertEquals(2, unitList.size());

	}

	@Test
	public void test_SLB_TimeOut_Enter() {
		insertSegments(10, 3, 1);
		insertUnit(1, 7, 7, 7);
		insertEligible(1, 7, 7, 7);

		jdbcTemplate.execute("update MATCH_UNITS set STATE = 'TIMED_OUT'"
				+ " where MU_ID = 1");
		jdbcTemplate.execute("update DATA_MANAGERS set STATE = 'TIMED_OUT'"
				+ " where DM_ID = 7");

		testAndAssertSLB(2, 10, 2, 6, 8, 6);
	}

	@Test
	public void test_SLB_TimeOut() {
		insertSegments(10, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		jdbcTemplate.execute("update MATCH_UNITS set STATE = 'TIMED_OUT'"
				+ " where MU_ID = 1");
		jdbcTemplate.execute("update DATA_MANAGERS set STATE = 'TIMED_OUT'"
				+ " where DM_ID = 7");

		testAndAssertSLB(2, 10, 2, 5, 8, 5);
	}

	@Test
	public void test_SLB_Enter() {
		insertSegments(10, 3, 1);
		insertUnit(1, 7, 7, 7);
		insertEligible(1, 7, 7, 7);

		testAndAssertSLB(2, 10, 1, 7, 7, 7);
	}

	@Test
	public void test_SLB_SegmentAdd() {
		insertSegments(13, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		testAndAssertSLB(2, 13, 1, 6, 7, 6);
	}

	@Test
	public void test_SLB_SegmentAdd_Two() {
		insertSegments(13, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		testAndAssertSLB(2, 13, 1, 6, 7, 6);

		slbBean.executeSLB();

		assertUnitSegmentMap("DM", 2, 13, 7, 6);
		assertUnitSegmentMap("MU", 2, 13, 1, 6);
	}

	@Test
	public void test_SLB_SegmentAdd_Two_Add() {
		insertSegments(13, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		testAndAssertSLB(2, 13, 1, 6, 7, 6);

		insertUnit(7, 6, 13, 6);
		insertEligible(7, 6, 13, 6);

		slbBean.executeSLB();

		assertUnitSegmentMap("DM", 2, 13, 7, 12);
		assertUnitSegmentMap("MU", 2, 13, 1, 12);
	}

	@Test
	public void test_SLB_SegmentAdd_Two_AddSeg() {
		insertSegments(13, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		testAndAssertSLB(2, 13, 1, 6, 7, 6);

		insertSegments(20, 1, 14);
		insertSegments(20, 2, 34);
		insertSegments(20, 4, 54);
		insertSegments(20, 5, 74);
		jdbcTemplate.execute("commit");
		slbBean.executeSLB();

		assertUnitSegmentMap("DM", 2, 93, 7, 6);
		assertUnitSegmentMap("MU", 2, 93, 1, 6);
	}

	@Test
	public void test_SLB_RedundancyIncrease() {
		insertSegments(13, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		testAndAssertSLB(3, 13, 1, 6, 7, 6);
	}

	@Test
	public void test_SLB_RedundancyDecrease() {
		insertSegments(13, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		testAndAssertSLB(1, 13, 1, 6, 7, 6);
	}

	@Test
	public void test_SLB_First() {
		int Redundancy = 2;
		int segCount = 13;
		int startMUId = 1;
		int muCount = 6;
		int startDMId = 7;
		int dmCount = 6;

		insertSegments(segCount, 3, 1);
		insertUnit(startMUId, muCount, startDMId, dmCount);
		insertEligible(startMUId, muCount, startDMId, dmCount);

		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(2,"
				+ " 'LOAD_BALANCER.DEFAULT_DM_MIN_REDUNDANCY', '" + Redundancy
				+ "')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(3,"
				+ " 'LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY', '" + Redundancy
				+ "')");
		jdbcTemplate.execute("update CONTAINERS set MIN_REDUNDANCY = "
				+ Redundancy);

		final List<Long> unitList = new ArrayList<Long>();
		new MockUp<ReportWakeUp>() {
			@Mock
			public void notifyMessage(Set<Long> unitIds) {
				unitList.addAll(unitIds);
				return;
			}
		};

		slbBean.executeSLB();

		assertUnitSegmentMap("DM", Redundancy, segCount, startDMId, dmCount);
		assertUnitSegmentMap("MU", Redundancy, segCount, startMUId, muCount);

		assertTrue((muCount + dmCount) == unitList.size());

	}

	@Test
	public void test_SLB_DeployExcrption() {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(2,"
				+ " 'LOAD_BALANCER.DEFAULT_DM_MIN_REDUNDANCY', '7')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(3,"
				+ " 'LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY', '7')");
		jdbcTemplate.execute("update CONTAINERS set MIN_REDUNDANCY = 7");

		insertSegments(10, 3, 1);
		insertUnit(1, 6, 7, 6);
		insertEligible(1, 6, 7, 6);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSeg(matrix, 1, 6, 7, 6);
		insertMuSegReport(matrix, 1, 6, 7, 6);
		jdbcTemplate.execute("commit");

		new MockUp<Deployment>() {
			@Mock
			public boolean[][] deploy(boolean[][] preMatUnitSegment) {
				throw new DeployExcrption("");
			}
		};

		slbBean.executeSLB();

		int unitIds[] = new int[] { 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 1, 2, 7, 8, 2, 3, 8, 9, 3, 4, 9, 4, 5, 10,
				1, 5, 6, 6, 7, 10 };

		List<Map<String, Object>> listDmSegMap = jdbcTemplate
				.queryForList("select * from DM_SEGMENTS order by DM_ID, SEGMENT_ID");
		assertEquals(20, listDmSegMap.size());
		for (int i = 0; i < listDmSegMap.size(); i++) {
			assertEquals("" + (unitIds[i] + 6), listDmSegMap.get(i)
					.get("DM_ID").toString());
			assertEquals("" + segIds[i], listDmSegMap.get(i).get("SEGMENT_ID")
					.toString());
		}
		List<Map<String, Object>> listMuSegMap = jdbcTemplate
				.queryForList("select * from MU_SEGMENTS order by MU_ID, SEGMENT_ID");
		assertEquals(20, listMuSegMap.size());
		for (int i = 0; i < listMuSegMap.size(); i++) {
			assertEquals("" + unitIds[i], listMuSegMap.get(i).get("MU_ID")
					.toString());
			assertEquals("" + segIds[i], listMuSegMap.get(i).get("SEGMENT_ID")
					.toString());
		}

		assertTrue(TestLogger.message.contains("DeployExcrption when deploy"));
		assertTrue(TestLogger.message
				.contains("MU Count are less than Redundancy."));
		assertTrue(TestLogger.message
				.contains("DM Count are less than Redundancy."));
	}

	@Test
	public void test_SLB_Excrption() {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");

		new MockUp<LoadBalancerDao>() {
			@Mock
			public void lockForSLB() {
				throw new DeployExcrption("");
			}
		};

		try {
			slbBean.executeSLB();
		} catch (AimRuntimeException e) {
			assertTrue(TestLogger.message
					.contains("unknow Exception when doing Segment Load Balance."));
			assertEquals("unknow Exception when doing Segment Load Balance.",
					e.getMessage());
			return;
		}
		fail();
	}

	private void testAndAssertSLB(int Redundancy, int segCount, int startMUId,
			int muCount, int startDMId, int dmCount) {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(1,"
				+ " 'LOAD_BALANCER.ENABLED', 'true')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(2,"
				+ " 'LOAD_BALANCER.DEFAULT_DM_MIN_REDUNDANCY', '" + Redundancy
				+ "')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(3,"
				+ " 'LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY', '" + Redundancy
				+ "')");
		jdbcTemplate.execute("update CONTAINERS set MIN_REDUNDANCY = "
				+ Redundancy);

		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		insertMuSeg(matrix, 1, 6, 7, 6);
		insertMuSegReport(matrix, 1, 6, 7, 6);

		final List<Long> unitList = new ArrayList<Long>();
		new MockUp<ReportWakeUp>() {
			@Mock
			public void notifyMessage(Set<Long> unitIds) {
				unitList.addAll(unitIds);
				return;
			}
		};

		slbBean.executeSLB();

		assertUnitSegmentMap("DM", Redundancy, segCount, startDMId, dmCount);
		assertUnitSegmentMap("MU", Redundancy, segCount, startMUId, muCount);

		assertTrue(1 <= unitList.size());

	}

	private void assertUnitSegmentMap(String type, int Redundancy,
			int segCount, int startId, int count) {
		String table = type + "_SEGMENTS";
		String column = type + "_ID";
		List<Map<String, Object>> listUnitSegMap = jdbcTemplate
				.queryForList("select * from " + table + " order by " + column
						+ ", SEGMENT_ID");
		assertEquals(Redundancy * segCount, listUnitSegMap.size());

		listUnitSegMap = jdbcTemplate.queryForList("select count(" + column
				+ ") as Redundancy, SEGMENT_ID from " + table
				+ " group by SEGMENT_ID order by SEGMENT_ID");
		assertEquals(segCount, listUnitSegMap.size());
		for (int i = 0; i < listUnitSegMap.size(); i++) {
			assertEquals("" + Redundancy,
					listUnitSegMap.get(i).get("Redundancy").toString());
			assertEquals("" + (i + 1), listUnitSegMap.get(i).get("SEGMENT_ID")
					.toString());
		}
		listUnitSegMap = jdbcTemplate.queryForList("select count(SEGMENT_ID)"
				+ " as Load, " + column + " from " + table + " group by "
				+ column + " order by " + column);
		assertEquals(count, listUnitSegMap.size());

		double avg = 1.0 * (Redundancy * segCount) / count;
		int maxUnitLoad = (int) (avg + 2);
		int minUnitLoad = (int) (avg * 0.6);
		for (int i = 0; i < listUnitSegMap.size(); i++) {
			assertTrue(minUnitLoad <= ((BigDecimal) listUnitSegMap.get(i).get(
					"Load")).intValue());
			assertTrue(maxUnitLoad >= ((BigDecimal) listUnitSegMap.get(i).get(
					"Load")).intValue());
			assertEquals("" + (i + startId), listUnitSegMap.get(i).get(column)
					.toString());
		}
	}
}
