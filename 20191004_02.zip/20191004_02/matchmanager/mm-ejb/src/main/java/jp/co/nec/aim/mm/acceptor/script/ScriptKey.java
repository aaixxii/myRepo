package jp.co.nec.aim.mm.acceptor.script;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * The class of ScriptKey <br>
 * Script Composite Primary Key <br>
 * 
 * Include following key <br>
 * functionName, formatType, printType, position <br>
 * 
 * @author liuyq
 * 
 */
public final class ScriptKey implements Key {
	/** function name(not require) **/
	private String functionName;
	/** template format(TEMPLATE_RDBT)(required) **/
	private String formatType;
	/** finger print(FINGER_PRINT_ROLLED, FINGER_PRINT_SLAP) (not require) **/
	private String printType;
	/** position(finger PLAM or face position (not require)) **/
	private String position;

	/**
	 * ScriptKey constructor
	 * 
	 * @param functionName
	 *            function name(TI TIM..)
	 * @param formatType
	 *            template format(TEMPLATE_RDBT)
	 * @param printType
	 *            finger print(FINGER_PRINT_ROLLED)
	 * @param position
	 *            position(finger or face position)
	 */
	public ScriptKey(final String functionName, final String formatType,
			final String printType, final String position) {
		this.functionName = functionName;
		this.formatType = formatType;
		this.printType = printType;
		this.position = position;
	}

	/**
	 * ScriptKey constructor
	 * 
	 * @param formatType
	 *            template format(TEMPLATE_RDBT)
	 * @param printType
	 *            finger print(FINGER_PRINT_ROLLED)
	 * @param position
	 *            position(finger or face position)
	 */
	public ScriptKey(final String formatType, final String printType,
			final String position) {
		this.formatType = formatType;
		this.printType = printType;
		this.position = position;
	}

	/**
	 * ScriptKey constructor
	 * 
	 * @param formatType
	 * @param printType
	 */
	public ScriptKey(final String formatType, final String printType) {
		this.formatType = formatType;
		this.printType = printType;
	}

	/**
	 * ScriptKey constructor
	 * 
	 * @param scriptItem
	 *            SearchScriptItem instance
	 */
	public ScriptKey(SearchScriptItem scriptItem) {
		if (StringUtils.isNotEmpty(scriptItem.getFunctionName())) {
			this.functionName = scriptItem.getFunctionName();
		}

		if (StringUtils.isNotEmpty(scriptItem.getTemplateFormat())) {
			this.formatType = scriptItem.getTemplateFormat();
		}

		if (StringUtils.isNotEmpty(scriptItem.getFingerPrint())) {
			this.printType = scriptItem.getFingerPrint();
		}
	}

	/**
	 * ScriptKey
	 * 
	 * @param templateData
	 *            PBKeyedTemplateData instance
	 * @param scopes
	 *            PBInquiryScopeOptions instance
	 */
	public ScriptKey(PBKeyedTemplateData templateData,
			FingerPrintType printType, InquiryFunctionType function) {
		this.functionName = function.name();
		this.formatType = templateData.getKeyedTemplate().getKey().name();
		this.printType = printType.name();
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	public String getPrintType() {
		return printType;
	}

	public FingerPrintType getPrintTypeEnum() {
		return FingerPrintType.valueOf(printType);
	}

	public void setPrintType(String printType) {
		this.printType = printType;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
