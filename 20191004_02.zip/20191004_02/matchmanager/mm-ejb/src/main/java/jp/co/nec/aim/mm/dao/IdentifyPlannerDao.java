package jp.co.nec.aim.mm.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Set;

import javax.persistence.PersistenceException;

import jp.co.nec.aim.mm.identify.planner.JobInfoFromDB;
import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;
import jp.co.nec.aim.mm.identify.planner.MuSegmentMap;
import jp.co.nec.aim.mm.identify.planner.SegmentIdAndVeison;
import jp.co.nec.aim.mm.identify.planner.TopJobInfo;

import org.springframework.dao.DataAccessException;

public interface IdentifyPlannerDao {

	public long getRUCFromDB() throws PersistenceException, SQLException;

	public void setRUC(Long newRUC) throws DataAccessException, SQLException;

	public List<Long> getLimitedJobsByFamiliy();

	public List<MuSegmentMap> getNewMuSegMaps(Integer containerId,
			Integer functionId);

	public List<SegmentIdAndVeison> getSegmentVersionByContainerId(
			long containerId) throws PersistenceException, SQLException;

	public Integer getSegmentCount(Integer containerId)
			throws PersistenceException, SQLException;

	public Integer getWorkingMR() throws PersistenceException, SQLException;

	List<TopJobInfo> getJobInfoForCreatePlans(Long[] jobIds);

	public Long updateAfterPlanned(Long topJobId, Integer contaierId,
			Long containerJobId, Integer fucntonId, String plans);

	public List<TopJobInfo> convert(List<JobInfoFromDB> fromDBJobInfos);

	public boolean updateInquiryTraffic(long topJobId)
			throws PersistenceException, SQLException;

	public List<MuCpuAndPressure> getMuCpuAndPressure(Set<Integer> muIds)
			throws PersistenceException, SQLException;

	public void lockJobQueueRowForProcess(Long topJobId)
			throws DataAccessException, SQLException;

	public void lockForIdentifyPlaner() throws DataAccessException;
}
