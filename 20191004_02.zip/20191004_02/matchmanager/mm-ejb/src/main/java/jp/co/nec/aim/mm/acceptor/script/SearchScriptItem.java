package jp.co.nec.aim.mm.acceptor.script;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "search-script-item", propOrder = { "functionName",
		"templateFormat", "fingerPrint", "fusionWeight", "containerSpec" })
public class SearchScriptItem {
	@XmlElement(required = true)
	protected String functionName;
	@XmlElement(required = true)
	protected String templateFormat;
	@XmlElement
	protected String fingerPrint;
	@XmlElement(nillable = true)
	protected List<FusionWeight> fusionWeight;
	@XmlElement(required = true)
	protected ContainerSpec containerSpec;

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getTemplateFormat() {
		return templateFormat;
	}

	public void setTemplateFormat(String templateFormat) {
		this.templateFormat = templateFormat;
	}

	public String getFingerPrint() {
		return fingerPrint;
	}

	public void setFingerPrint(String fingerPrint) {
		this.fingerPrint = fingerPrint;
	}

	public List<FusionWeight> getFusionWeight() {
		if (fusionWeight == null) {
			fusionWeight = new ArrayList<FusionWeight>();
		}
		return this.fusionWeight;
	}

	/**
	 * Gets the value of the containerSpec property.
	 * 
	 * @return possible object is {@link ContainerSpec }
	 * 
	 */
	public ContainerSpec getContainerSpec() {
		return containerSpec;
	}

	/**
	 * Sets the value of the containerSpec property.
	 * 
	 * @param value
	 *            allowed object is {@link ContainerSpec }
	 * 
	 */
	public void setContainerSpec(ContainerSpec value) {
		this.containerSpec = value;
	}

}
