package jp.co.nec.aim.mm.async.servlet;

import static jp.co.nec.aim.mm.constants.ErrorMessage.NOT_SUPPORT_METHOD;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.mm.acceptor.service.AimInquiryService;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.servlet.AimAbstractServlet;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * InquiryServiceServlet
 * 
 * @author liuyq
 * 
 */
public class AsyncInquiryServiceServlet extends AimAbstractServlet {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3792084762155878017L;
	private static Logger log = LoggerFactory
			.getLogger(AsyncInquiryServiceServlet.class);

	private static final String INQUIRY_URL = "inquiry";	
	private static final String INQ_DELETEJOB_URL = "deletejob";
	private static final String INQ_CLEARJOBS_URL = "clearjobs";

	@EJB
	private AimInquiryService inquiryService;

	/**
	 * doPost
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException {
		final StopWatch t = new StopWatch();
		t.start();

		final String url = req.getRequestURI().toLowerCase();
		if (url.endsWith(INQUIRY_URL)) {
			doInquiry(req, res);	
		} else if (url.endsWith(INQ_DELETEJOB_URL)) {
			doDeleteJob(req, res);
		} else if (url.endsWith(INQ_CLEARJOBS_URL)) {
			doNoSuport(req, res, "clearJobs with post");
		} else {
			final String unknownMsg = String.format(NOT_SUPPORT_METHOD, "unknown");
			log.error(unknownMsg);
			writeErrorToResponse(req, res, HttpStatus.SC_METHOD_NOT_ALLOWED,
					unknownMsg, null);
			return;
		}

		t.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doPost",
				t.elapsedTime());
	}

	/**
	 * doGet
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		final StopWatch t = new StopWatch();
		t.start();

		final String url = req.getRequestURI().toLowerCase();
		if (url.endsWith(INQUIRY_URL)) {
			doNoSuport(req, res, "inquiry with get");		
		} else if (url.endsWith(INQ_DELETEJOB_URL)) {
			doNoSuport(req, res, "deleteJob with get");
		} else if (url.endsWith(INQ_CLEARJOBS_URL)) {
			doClearJobs(req, res);
		} else {
			final String unknownMsg = String.format(NOT_SUPPORT_METHOD, "unknown");
			log.error(unknownMsg);
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					unknownMsg, null);
			return;
		}

		t.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doPost",
				t.elapsedTime());
			
		
	}

	/**
	 * do inquiry process
	 * 
	 * @param req
	 *            HttpServletRequest
	 * @param res
	 *            HttpServletResponse
	 * @throws IOException
	 */
	private void doInquiry(final HttpServletRequest req,
			final HttpServletResponse res) throws IOException {
		if (isContextSizeEmpty(req)) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					EMPTY_REQUEST_MSG, null);			
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to deSerial from inputStream..");
		}
		IdentifyRequest request = null;
		try {
			request = IdentifyRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					ex.getMessage(), ex);			
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to call inquiry with parameter PBInquiryJobRequest..");
		}	
		long identifyJobWaitTime = 10000;				
		IdentifyResponse identifyResponse = null;
		try {
			String topJobId = inquiryService.inquiry(request, true);
			Object idyLocker = new Object();
			AimManager.saveInquryClientJobLocker(topJobId, idyLocker);
			synchronized (idyLocker) {
				long startGetExtResultTime = System.currentTimeMillis();
				log.info("Go to waiting identifyjob results! jobId={}", topJobId);
				try {
					idyLocker.wait(identifyJobWaitTime);
				} catch (InterruptedException e) {
					log.error(e.getMessage(), e);
					Thread.currentThread().interrupt();
				}			
				identifyResponse = AimManager.getIdentifyClientResponse(topJobId);			
				if (identifyResponse != null) {
					identifyResponse.writeTo(res.getOutputStream());					
					log.info("Get job({}) result success", topJobId);
					long endGetResultTime = System.currentTimeMillis();
					log.info("*****MM get job results used time = {}****",
							endGetResultTime - startGetExtResultTime);				
				} else {
					long currentTime = System.currentTimeMillis();			
					if (currentTime -  startGetExtResultTime >= identifyJobWaitTime) {
						log.warn(
								"Timeout is happend! the waiting time = ({}), jobId({})",
								currentTime - startGetExtResultTime, topJobId);						
					} 
				}
			}
			AimManager.finishInquryClientJob(topJobId);
		} catch (Exception ex) {
			IdentifyResponse ersRes = buildIdentifyResponse(request, ex);
			ersRes.writeTo(res.getOutputStream());						
			return;
		}	
	}


	/**
	 * doDeleteJob
	 * 
	 * @param req
	 * @param res
	 * @throws IOException
	 */
	private void doDeleteJob(final HttpServletRequest req,
			final HttpServletResponse res) throws IOException {
		if (isContextSizeEmpty(req)) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					EMPTY_REQUEST_MSG, null);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to deSerial from inputStream..");
		}
		PBDeleteJobRequest request = null;
		try {
			request = PBDeleteJobRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					ex.getMessage(), ex);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to call deleteJob with parameter PBDeleteJobRequest..");
		}
		try {
			inquiryService.deleteJob(request); //ToDo
		} catch (Exception ex) {
			handleException(ex, req, res, null);
			return;
		}

		res.setStatus(HttpStatus.SC_OK);
	}

	/**
	 * doClearJobs
	 * 
	 * @param req
	 * @param res
	 */
	private void doClearJobs(final HttpServletRequest req,
			final HttpServletResponse res) {
		if (log.isDebugEnabled()) {
			log.debug("ready to call clearJobs..");
		}
		try {
			inquiryService.clearJobs();
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_INTERNAL_SERVER_ERROR,
					ex.getMessage(), ex);
			return;
		}
	}
	
	private IdentifyResponse buildIdentifyResponse(IdentifyRequest request, Exception ex) throws InvalidProtocolBufferException {
		IdentifyResponse.Builder iqyRes = IdentifyResponse.newBuilder();
		iqyRes.setBatchJobId(request.getBatchJobId());
		iqyRes.setType(request.getType());
		PBBusinessMessage oldPbMeg = PBBusinessMessage.parseFrom(request.getBusinessMessage(0));
		PBBusinessMessage.Builder lastPbMsg = PBBusinessMessage.newBuilder();
		PBRequest.Builder lastPBRequest = PBRequest.newBuilder();
		lastPBRequest.setRequestId(oldPbMeg.getRequest().getRequestId());
		lastPBRequest.setRequestType(oldPbMeg.getRequest().getRequestType());
		lastPbMsg.setRequest(lastPBRequest);
		PBResponse.Builder lastRes = PBResponse.newBuilder();
		lastRes.setStatus("1");
		lastRes.setErrorMessage(String.format("%s", ex.getMessage()));
		lastRes.setResendable("N");
		lastPbMsg.setResponse(lastRes.build());
		iqyRes.addBusinessMessage(lastPbMsg.build().toByteString());
		return iqyRes.build();		
	}
}
