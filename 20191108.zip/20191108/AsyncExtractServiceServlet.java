package jp.co.nec.aim.mm.async.servlet;

import static jp.co.nec.aim.mm.constants.ErrorMessage.NOT_SUPPORT_METHOD;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.mm.acceptor.service.AimExtractService;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.servlet.AimAbstractServlet;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * ExtractServiceServlet
 * 
 * @author liuyq
 * 
 */
public class AsyncExtractServiceServlet extends AimAbstractServlet {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -3362589922113319124L;
	private static Logger log = LoggerFactory
			.getLogger(AsyncExtractServiceServlet.class);

	private static final String EXTRACT_URL = "extract";	
	private static final String FE_DELETEJOB_URL = "deletejob";
	private static final String FE_CLEARJOBS_URL = "clearjobs";

	@EJB
	private AimExtractService extractService;

	/**
	 * doPost
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException {
		final StopWatch t = new StopWatch();
		t.start();	
		final String url = req.getRequestURI().toLowerCase();
		if (url.endsWith(EXTRACT_URL)) {
			doExtract(req, res);			
		} else if (url.endsWith(FE_DELETEJOB_URL)) {
			doDeleteJob(req, res);	
		} else if (url.endsWith(FE_CLEARJOBS_URL)) {
			doNoSuport(req, res, "clearJobs with post");
		} else {
			final String unknown = String.format(NOT_SUPPORT_METHOD, "unknown");
			log.error(unknown);
			writeErrorToResponse(req, res, HttpStatus.SC_METHOD_NOT_ALLOWED,
					unknown, null);
			return;
		}

		t.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doPost",
				t.elapsedTime());
	}

	/**
	 * doGet
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		final StopWatch t = new StopWatch();
		t.start();	
		final String url = req.getRequestURI().toLowerCase();
		if (url.endsWith(EXTRACT_URL)) {
			doNoSuport(req, res, "extract with get");	
		} else if (url.endsWith(FE_DELETEJOB_URL)) {
			doNoSuport(req, res, "deleteFeJobId with get");
		} else if (url.endsWith(FE_CLEARJOBS_URL)) {
			doClearJobs(req, res);
		} else {
			final String unknown = String.format(NOT_SUPPORT_METHOD, "unknown");			
			log.error(unknown);
			writeErrorToResponse(req, res, HttpStatus.SC_METHOD_NOT_ALLOWED,
					unknown, null);
			return;
		}

		t.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "doPost",
				t.elapsedTime());
			
		
	}

	/**
	 * do extract process
	 * 
	 * @param req
	 *            HttpServletRequest
	 * @param res
	 *            HttpServletResponse
	 * @throws IOException
	 */
	private void doExtract(final HttpServletRequest req,
			final HttpServletResponse res) throws IOException {	
		if (isContextSizeEmpty(req)) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					EMPTY_REQUEST_MSG, null);			
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to deSerial from inputStream..");
		}
		ExtractRequest request = null;
		try {
			request = ExtractRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					ex.getMessage(), ex);			
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to call extract with parameter PBExtractJobRequest..");
		}	
		long extractJobWaitTime = 10000;
		ExtractResponse extractResponse = null;
		try {
			String efJobId = extractService.extract(request, true);
			log.info("aim fejobId={}", efJobId);
			Object extLocker = new Object();
			AimManager.saveExtractClientJobLocker(efJobId, extLocker);
			synchronized (extLocker) {
				long startGetExtResultTime = System.currentTimeMillis();
				log.info("Go to waiting extractjob results! jobId={}", efJobId);
				try {
					extLocker.wait(extractJobWaitTime);
				} catch (InterruptedException e) {
					log.error(e.getMessage(), e);
					Thread.currentThread().interrupt();
				}			
				extractResponse = AimManager.getExtractClientResponse(efJobId);			
				if (extractResponse != null) {					
					extractResponse.writeTo(res.getOutputStream());					
					log.info("Get job({}) result success", efJobId);
					long endGetResultTime = System.currentTimeMillis();
					log.info("*****MM get job results used time = {}****",
							endGetResultTime - startGetExtResultTime);				
				} else {
					long currentTime = System.currentTimeMillis();			
					if (currentTime -  startGetExtResultTime >= extractJobWaitTime) {
						log.warn(
								"Timeout is happend! the waiting time = ({}), jobId({})",
								currentTime - startGetExtResultTime, efJobId );
						
					} 
				}					
			}
			AimManager.finishExtractClientJob(efJobId);
		} catch (Exception ex) {
			ExtractResponse errRes = buildExtractResponse(request, ex);
			errRes.writeTo(res.getOutputStream());			
			return;
		}
	}


	/**
	 * doDeleteJob
	 * 
	 * @param req
	 * @param res
	 * @throws IOException
	 */	
	private void doDeleteJob(final HttpServletRequest req,
			final HttpServletResponse res) throws IOException {
		if (isContextSizeEmpty(req)) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					EMPTY_REQUEST_MSG, null);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to deSerial from inputStream..");
		}
		PBDeleteJobRequest request = null;
		try {
			request = PBDeleteJobRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST,
					ex.getMessage(), ex);
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("ready to call deleteJob with parameter PBDeleteJobRequest..");
		}
		try {
			extractService.deleteJob(request);
		} catch (Exception ex) {			
			handleException(ex, req, res, null);
			return;
		}

		res.setStatus(HttpStatus.SC_OK);
	}

	/**
	 * doClearJobs
	 * 
	 * @param req
	 * @param res
	 */
	private void doClearJobs(final HttpServletRequest req,
			final HttpServletResponse res) {
		if (log.isDebugEnabled()) {
			log.debug("ready to call clearJobs..");
		}
		try {
			extractService.clearJobs();
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_INTERNAL_SERVER_ERROR,
					ex.getMessage(), ex);
			return;
		}
	}
	
	private ExtractResponse buildExtractResponse(ExtractRequest request, Exception ex) throws InvalidProtocolBufferException {
		ExtractResponse.Builder extRes = ExtractResponse.newBuilder();
		extRes.setBatchJobId(request.getBatchJobId());
		extRes.setType(request.getType());
		PBBusinessMessage oldPbMeg = PBBusinessMessage.parseFrom(request.getBusinessMessage(0));
		PBBusinessMessage.Builder lastPbMsg = PBBusinessMessage.newBuilder();
		PBRequest.Builder lastPBRequest = PBRequest.newBuilder();
		lastPBRequest.setRequestId(oldPbMeg.getRequest().getRequestId());
		lastPBRequest.setRequestType(oldPbMeg.getRequest().getRequestType());
		lastPbMsg.setRequest(lastPBRequest);
		PBResponse.Builder lastRes = PBResponse.newBuilder();
		lastRes.setStatus("1");
		lastRes.setErrorMessage(String.format("%s",ex.getMessage()));
		lastRes.setResendable("N");
		lastPbMsg.setResponse(lastRes.build());
		extRes.addBusinessMessage(lastPbMsg.build().toByteString());
		return extRes.build();		
	}
}
