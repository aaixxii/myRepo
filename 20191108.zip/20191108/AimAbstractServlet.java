package jp.co.nec.aim.mm.servlet;

import static jp.co.nec.aim.mm.constants.ErrorMessage.NOT_SUPPORT_METHOD;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJBException;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.Constants;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.DistributorExcception;
import jp.co.nec.aim.mm.exception.EventException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.exception.TemplateValidatorException;
import jp.co.nec.aim.mm.exception.UDPNotifyException;

/**
 * the abstract class of HttpServlet
 * 
 * @author liuyq
 * 
 */
public abstract class AimAbstractServlet extends HttpServlet {

	/** empty request message **/
	protected static final String EMPTY_REQUEST_MSG = "Received an empty POST request";

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -4016671086602252401L;
	private static Logger log = LoggerFactory
			.getLogger(AimAbstractServlet.class);

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	private DateDao dateDao;
	private ExceptionHelper exception;	

	@PostConstruct
	public void initDateDao() {
		this.dateDao = new DateDao(dataSource);
		this.exception = new ExceptionHelper();
	}

	/**
	 * check the request context size is empty.
	 * 
	 * @param req
	 * @return isContextSizeEmpty
	 */
	protected boolean isContextSizeEmpty(ServletRequest req) {
		if (req == null || req.getContentLength() <= 0) {
			return true;
		}
		return false;
	}

	/**
	 * writeToResponse
	 * 
	 * @param request
	 * @param response
	 * @param statusCode
	 * @param object
	 * @param e
	 */
	protected void writeToResponse(HttpServletResponse response,
			int statusCode, byte[] array, Exception e) {
		if (array == null || array.length == 0) {
			log.error("Argument byte[] is null when writeToResponse..");
			return;
		}

		log.error(e.getMessage(), e);
		response.setContentLength(array.length);
		response.setStatus(statusCode);
		response.setCharacterEncoding(Constants.ENCODING_UTF8);
		writeResultToResponse(array, response);
	}

	/**
	 * writeErrorToResponse
	 * 
	 * @param request
	 * @param response
	 * @param statusCode
	 * @param message
	 * @param t
	 */
	protected void writeErrorToResponse(HttpServletRequest request,
			HttpServletResponse response, int statusCode, String message,
			Exception t) {
		if (t == null) {
			log.error(message);
		} else {
			log.error(message, t);
		}

		String clientInfo = buildClientInfo(request, message);
		int contentLength = clientInfo.length();
		response.setContentLength(contentLength);
		response.setStatus(statusCode);
		response.setCharacterEncoding(Constants.ENCODING_UTF8);
		writeResultToResponse(clientInfo, response);
	}

	/**
	 * writeResultToResponse
	 * 
	 * @param output
	 * @param res
	 */
	protected void writeResultToResponse(byte[] output, HttpServletResponse res) {
		try (BufferedOutputStream bos = new BufferedOutputStream(
				res.getOutputStream())) {
			bos.write(output);
			bos.flush();
		} catch (IOException e) {
			String errorMessage = "error write to response " + e.getMessage();
			log.error(errorMessage, e);
		}
	}

	/**
	 * writeResultToResponse
	 * 
	 * @param output
	 * @param res
	 */
	protected void writeResultToResponse(String output, HttpServletResponse res) {
		try (PrintWriter pw = res.getWriter()) {
			pw.write(output);
			pw.flush();
		} catch (IOException e) {
			String errorMessage = "error write to response " + e.getMessage();
			log.error(errorMessage, e);
		}
	}

	/**
	 * buildClientInfo
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param errorMessage
	 *            error message
	 * @return ClientInfo
	 */
	private String buildClientInfo(HttpServletRequest request,
			String errorMessage) {
		StringBuilder clientInfo = new StringBuilder();
		if (errorMessage != null) {
			clientInfo.append(errorMessage);
		}
		clientInfo.append(" information:");
		clientInfo.append(" RemoteHost:");
		clientInfo.append(request.getRemoteHost());
		clientInfo.append(" RemoteAddress:");
		clientInfo.append(request.getRemoteAddr());
		clientInfo.append(" RemotePort:");
		clientInfo.append(request.getRemotePort());
		clientInfo.append(" RemoteUser:");
		clientInfo.append(request.getRemoteUser());
		return clientInfo.toString();
	}

	/**
	 * handlerException
	 * 
	 * The following exception will be treated as RollBack state
	 * <ol>
	 * <li>SQLException</li>
	 * <li>DataBaseException</li>
	 * <li>DataAccessException</li>
	 * </ol>
	 * 
	 * @param ex
	 *            exception
	 * @param req
	 *            HttpServletRequest
	 * @param res
	 *            HttpServletResponse
	 * @param b
	 *            Builder
	 */
	protected void handleException(final Exception ex,
			final HttpServletRequest req, final HttpServletResponse res,
			com.google.protobuf.GeneratedMessage.Builder<?> b) {
		if (ex == null) {
			throw new IllegalArgumentException(
					"Parameter ex is null when handlerException..");
		}

		final Throwable e = (ex.getCause() == null) ? ex : ex.getCause();
		// Response protoBuffer object is not necessary
		int status = -999;
		if (b == null) {			
			if (e instanceof DataBaseException 
				|| e instanceof DistributorExcception
				|| e instanceof EventException	
				|| e instanceof UDPNotifyException
				|| e instanceof HttpPostException
				|| e instanceof NullPointerException
				|| ex instanceof EJBException				
				|| e instanceof AimRuntimeException) {	
				status = HttpStatus.SC_INTERNAL_SERVER_ERROR;				
			} else if(e instanceof IllegalArgumentException 
				|| e instanceof TemplateValidatorException				
				|| e instanceof ArgumentException){
				status = HttpStatus.SC_BAD_REQUEST;				
			} else {
				status = HttpStatus.SC_METHOD_NOT_ALLOWED;
			}		
			writeErrorToResponse(req, res, status,
					exception.getDescription(ex), ex);
			return;
		}
		if (ex instanceof DataBaseException
				|| ex instanceof DistributorExcception
				|| ex instanceof EventException	
				|| ex instanceof UDPNotifyException
				|| ex instanceof HttpPostException
				|| ex instanceof EJBException
				|| ex instanceof AimRuntimeException) {	
			writeToResponse(res, HttpStatus.SC_INTERNAL_SERVER_ERROR, b.build().toByteArray(), ex);
		} else if(ex instanceof IllegalArgumentException
				|| ex instanceof TemplateValidatorException
				|| ex instanceof ArgumentException) {
			writeToResponse(res, HttpStatus.SC_BAD_REQUEST, b.build().toByteArray(), ex);	
		} else {
			writeToResponse(res, HttpStatus.SC_METHOD_NOT_ALLOWED, b.build().toByteArray(), ex);	
		}		
		return;
	}
	
	@Override
	public void doHead(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		doNoSuport(req, resp, "HEAD");
		return;
	}

	@Override
	public void doPut(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		doNoSuport(req, resp, "PUT");
		return;	
	}

	@Override
	public void doDelete(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {		
			log.error(NOT_SUPPORT_METHOD);
			doNoSuport(req, resp, "DELETE");
			return;	
	}

	@Override
	public void doTrace(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {	
		doNoSuport(req, resp, "TRACE");
			return;				
		}		
	
	public void doNoSuport(HttpServletRequest req, HttpServletResponse resp, String method) {		
		final String notSupportMsg = String.format(NOT_SUPPORT_METHOD, method);
		resp.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
		writeErrorToResponse(req, resp, HttpStatus.SC_METHOD_NOT_ALLOWED,notSupportMsg, null);
	}
	
}
