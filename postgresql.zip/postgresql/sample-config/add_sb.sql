/* Server Settings- Modify SERVER_ID, SERVER_HOSTNAME accordingly  */

Insert into BIO_SERVER_INFO
   (SERVER_ID, SERVER_HOSTNAME, SERVER_TYPE, SERVER_STATE, COMPONENT_TYPE, 
    SERVER_GROUP_ID, SUB_SYSTEM_GROUP_ID, MAX_JOB_COUNT, CREATE_DATETIME)
 Values
   ('SB001', '10.10.10.10', 'MANAGER', 'ACTIVE', 'SB', 
    'SBG01', 'SNG01', 0, CURRENT_TIMESTAMP);


/* Connection Settings- Modify SERVER_ID, ipaddress in CONNECTION_URL accordingly  */

Insert into BIO_SERVER_CONNECTION_INFO
   (SERVER_ID, COMPONENT_TYPE, CONNECTION_TYPE, PROTOCOL_TYPE, CONNECTION_URL)
 Values
   ('SB001', 'SB', 'COMPONENT', 'HESSIAN', 'http://10.10.10.10:8080/bio-matcher-webservices/remoting/http/bioSearchBrokerService/httpBioSearchBrokerService');

