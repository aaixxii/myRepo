package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Call MATCH_MANAGER_API.delete_job() and delete record in JOB_QUEUE which has
 * specifed job_id.
 * 
 * @author kurosu
 * 
 */
public class DeleteJobProcedure extends StoredProcedure {

	private static final String SQL = "MATCH_MANAGER_API.delete_job";
	private Long jobId;

	public DeleteJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		compile();
	}

	public void execute() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", getJobId());
		execute(map);

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Long getJobId() {
		return jobId;
	}
}
