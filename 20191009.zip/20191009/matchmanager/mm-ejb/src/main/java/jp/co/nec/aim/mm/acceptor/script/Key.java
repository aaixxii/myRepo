package jp.co.nec.aim.mm.acceptor.script;

public interface Key {
	String getFormatType();
}
