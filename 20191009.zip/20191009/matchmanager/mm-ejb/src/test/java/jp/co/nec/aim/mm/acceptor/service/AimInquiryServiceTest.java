//package jp.co.nec.aim.mm.acceptor.service;
//
//import static org.junit.Assert.fail;
//
//import java.net.URL;
//import java.util.Date;
//import java.util.List;
//import java.util.Map;
//
//import javax.annotation.Resource;
//import javax.sql.DataSource;
//
//import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
//import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateReference;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
//import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryCandidateList;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryOptions;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatistics;
//import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatisticsAMR;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
//import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
//import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;
//import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusRequest;
//import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
//import jp.co.nec.aim.message.proto.JobCommonService.PBListJobIdsResponse;
//import jp.co.nec.aim.mm.constants.AimError;
//import jp.co.nec.aim.mm.dao.InquiryJobDao;
//import jp.co.nec.aim.mm.exception.AimRuntimeException;
//import jp.co.nec.aim.mm.exception.ArgumentException;
//import jp.co.nec.aim.mm.exception.DataBaseException;
//import jp.co.nec.aim.mm.jms.JmsSender;
//import jp.co.nec.aim.mm.license.LicenseManager;
//import mockit.Mock;
//import mockit.MockUp;
//
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.google.protobuf.ByteString;
//import com.google.protobuf.InvalidProtocolBufferException;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration()
//@Transactional
//public class AimInquiryServiceTest extends
//		AbstractTransactionalJUnit4SpringContextTests {
//	@Resource
//	private DataSource dataSource;
//	@Resource
//	private AimInquiryService aimInquiryService;
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//
//	@Before
//	public void setUp() {
//		jdbcTemplate.update("delete from FE_JOB_QUEUE");
//		jdbcTemplate.update("delete from FUSION_JOBS");
//		jdbcTemplate.update("delete from CONTAINER_JOBS");
//		jdbcTemplate.update("delete from JOB_QUEUE");
//		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
//		jdbcTemplate.update("delete from FE_RESULTS");
//		jdbcTemplate.update("delete from SEGMENTS");
//		jdbcTemplate.execute("commit");
//		setMockMethod();
//	}
//
//	@After
//	public void tearDown() {
//
//		jdbcTemplate.update("delete from FE_JOB_QUEUE");
//		jdbcTemplate.update("delete from FUSION_JOBS");
//		jdbcTemplate.update("delete from CONTAINER_JOBS");
//		jdbcTemplate.update("delete from JOB_QUEUE");
//		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
//		jdbcTemplate.update("delete from FE_RESULTS");
//		jdbcTemplate.update("delete from SEGMENTS");
//		jdbcTemplate.execute("commit");
//
//	}
//
//	private void setMockMethod() {
//		new MockUp<JmsSender>() {
//			@Mock
//			private void convertAndSend(String queueName, Object object) {
//				return;
//			}
//		};
//	}
//
//	@Test
//	public void testInquiryPriorityIncorrect() {
//		PBInquiryJobRequest inquiryJobReq = PBInquiryJobRequest
//				.newBuilder()
//				.setJobInfo(
//						PBInquiryJobInfo.newBuilder().setPriority(11)
//								.setFunction(InquiryFunctionType.FI)).build();
//		try {
//			aimInquiryService.inquiry(inquiryJobReq, true);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof ArgumentException);
//			ArgumentException exception = (ArgumentException) e;
//			Assert.assertEquals(AimError.PRIORITY_OUT_RANGE.getErrorCode(),
//					exception.getErrorCode());
//			Assert.assertEquals("Inquiry Job (Priority is out of range)",
//					exception.getDescription());
//			Assert.assertEquals("Inquiry Job (Priority is out of range)",
//					e.getMessage());
//
//			return;
//		}
//		fail();
//
//	}
//
//	@Test
//	public void testInquirykeyedFusionJobInputNull() {
//		PBInquiryJobRequest inquiryJobReq = PBInquiryJobRequest
//				.newBuilder()
//				.setJobInfo(
//						PBInquiryJobInfo.newBuilder().setFunction(
//								InquiryFunctionType.FI)).build();
//		try {
//			aimInquiryService.inquiry(inquiryJobReq, true);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof ArgumentException);
//			ArgumentException exception = (ArgumentException) e;// INQ_TEMPLATE_LIST
//			Assert.assertEquals(AimError.INQ_FUSION_LIST.getErrorCode(),
//					exception.getErrorCode());
//			Assert.assertEquals(
//					"Inquiry Job(fusionJobInput list is null or empty)",
//					exception.getDescription());
//			Assert.assertEquals(
//					"Inquiry Job(fusionJobInput list is null or empty)",
//					e.getMessage());
//			return;
//		}
//		fail();
//
//	}
//
//	@Test
//	public void testInquirykeyedInquiryOptionsFusionweightsIsNotNull() {
//		new MockUp<LicenseManager>() {
//			@Mock
//			public void check(String function, Date now) {
//				return;
//			}
//		};		
//		URL url = this.getClass().getResource("Inquiry_fe_resluts.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		PBInquiryFusionWeight.Builder fusionWeightBuilder = PBInquiryFusionWeight
//				.newBuilder().setInquirySet(FingerSetType.PC2_ROLLED)
//				.setWeight(20);
//		PBKeyedTemplateIndexer.Builder indexerBuilder = PBKeyedTemplateIndexer
//				.newBuilder().setFingerPrintType(
//						FingerPrintType.FINGER_PRINT_ROLLED);
//		PBKeyedTemplateReference.Builder templateRefBuilder = PBKeyedTemplateReference
//				.newBuilder().setJobId(20)
//				.setKey(TemplateFormatType.TEMPLATE_TI)
//				.setIndexer(indexerBuilder);
//
//		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
//				.newBuilder().setKeyedReferenece(templateRefBuilder);
//		PBInquiryOptions.Builder optionsBuilder = PBInquiryOptions.newBuilder()
//				.addFusionWeight(fusionWeightBuilder);
//		PBInquiryJobRequest inquiryJobReq = PBInquiryJobRequest
//				.newBuilder()
//				.setJobInfo(
//						PBInquiryJobInfo.newBuilder().setFunction(
//								InquiryFunctionType.TI))
//				.addFusionJobInput(
//						PBFusionJobInput
//								.newBuilder()
//								.setScopes(
//										PBInquiryScopeOptions
//												.newBuilder()
//												.addScope(1)
//												.addTargetFingerPrint(
//														FingerPrintType.FINGER_PRINT_ROLLED)
//												.addTargetFingerPrint(
//														FingerPrintType.FINGER_PRINT_SLAP))
//								.setKeyedTemplateData(templateBuilder)
//								.setInquiryOptions(optionsBuilder)).build();
//
//		PBInquiryJobResponse inquiryJobRes = aimInquiryService.inquiry(
//				inquiryJobReq, true);
//		jdbcTemplate.update("commit");
//		// Assert.assertEquals(600, inquiryJobRes.getJobId());
//		List<Map<String, Object>> listJQ = jdbcTemplate
//				.queryForList("select * from job_queue");
//		Assert.assertEquals(1, listJQ.size());
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from fusion_jobs");
//		Map<String, Object> mapFJ = list.get(0);
//		Assert.assertEquals(listJQ.get(0).get("JOB_ID"), mapFJ.get("JOB_ID"));
//		byte[] bytes = (byte[]) list.get(0).get("INQUIRY_JOB_DATA");
//		try {
//			PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(bytes);
//			Assert.assertEquals(20, request.getFusionJobInput(0)
//					.getInquiryOptions().getFusionWeight(0).getWeight());
//			/*
//			 * Assert.assertEquals(100, request.getFusionJobInput(0)
//			 * .getInquiryOptions().getFusionWeight(1).getWeight());
//			 */
//			Assert.assertEquals(1, request.getFusionJobInput(0)
//					.getInquiryOptions().getFusionWeightCount());
//		} catch (InvalidProtocolBufferException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			fail();
//		}
//		Assert.assertTrue(inquiryJobRes.getJobId() > 0);
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				inquiryJobRes.getServiceState().getState());
//	}
//
//	@Test
//	public void testInquirykeyedInquiryOptionsFusionweightsIsNotNullTLIX() {
//		new MockUp<LicenseManager>() {
//			@Mock
//			public void check(String function, Date now) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("Inquiry_fe_resluts.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		PBInquiryFusionWeight.Builder fusionWeightBuilder = PBInquiryFusionWeight
//				.newBuilder().setInquirySet(FingerSetType.PC2_ROLLED)
//				.setWeight(120);
//		/*
//		 * PBKeyedTemplateIndexer.Builder indexerBuilder =
//		 * PBKeyedTemplateIndexer .newBuilder().setFingerPrintType(
//		 * FingerPrintType.FINGER_PRINT_ROLLED);
//		 */
//		PBKeyedTemplateReference.Builder templateRefBuilder = PBKeyedTemplateReference
//				.newBuilder().setJobId(21)
//				.setKey(TemplateFormatType.TEMPLATE_TLIX);
//		// .setIndexer(indexerBuilder);
//
//		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
//				.newBuilder().setKeyedReferenece(templateRefBuilder);
//		PBInquiryOptions.Builder optionsBuilder = PBInquiryOptions.newBuilder()
//				.addFusionWeight(fusionWeightBuilder);
//		PBInquiryJobRequest inquiryJobReq = PBInquiryJobRequest
//				.newBuilder()
//				.setJobInfo(
//						PBInquiryJobInfo.newBuilder().setFunction(
//								InquiryFunctionType.TLIX))
//				.addFusionJobInput(
//						PBFusionJobInput
//								.newBuilder()
//								.setScopes(
//										PBInquiryScopeOptions.newBuilder()
//												.addScope(1))
//								.setKeyedTemplateData(templateBuilder)
//								.setInquiryOptions(optionsBuilder)).build();
//		PBInquiryJobResponse inquiryJobRes = aimInquiryService.inquiry(
//				inquiryJobReq, true);
//		jdbcTemplate.update("commit");
//		Assert.assertNotNull(inquiryJobRes.getJobId());
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from fusion_jobs");
//		byte[] bytes = (byte[]) list.get(0).get("INQUIRY_JOB_DATA");
//		try {
//			PBInquiryJobRequest request = PBInquiryJobRequest.parseFrom(bytes);
//			Assert.assertEquals(4, request.getFusionJobInput(0)
//					.getInquiryOptions().getFusionWeightCount());
//			for (int i = 0; i < 4; i++) {
//				if (request.getFusionJobInput(0).getInquiryOptions()
//						.getFusionWeight(i).getInquirySet()
//						.equals(FingerSetType.PC2_ROLLED)) {
//					Assert.assertEquals(120, request.getFusionJobInput(0)
//							.getInquiryOptions().getFusionWeight(i).getWeight());
//				}
//
//				if (request.getFusionJobInput(0).getInquiryOptions()
//						.getFusionWeight(i).getInquirySet()
//						.equals(FingerSetType.PC2_SLAP)) {
//					Assert.assertEquals(200, request.getFusionJobInput(0)
//							.getInquiryOptions().getFusionWeight(i).getWeight());
//				}
//				if (request.getFusionJobInput(0).getInquiryOptions()
//						.getFusionWeight(i).getInquirySet()
//						.equals(FingerSetType.FMP5_ROLLED)) {
//					Assert.assertEquals(100, request.getFusionJobInput(0)
//							.getInquiryOptions().getFusionWeight(i).getWeight());
//				}
//				if (request.getFusionJobInput(0).getInquiryOptions()
//						.getFusionWeight(i).getInquirySet()
//						.equals(FingerSetType.FMP5_SLAP)) {
//					Assert.assertEquals(100, request.getFusionJobInput(0)
//							.getInquiryOptions().getFusionWeight(i).getWeight());
//				}
//			}
//		} catch (InvalidProtocolBufferException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			fail();
//		}
//		Assert.assertTrue(inquiryJobRes.getJobId() > 0);
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				inquiryJobRes.getServiceState().getState());
//
//	}
//
//	@Test
//	public void testInquirykeyedInquiryOptionsFusionweightsIsNull() {
//		new MockUp<LicenseManager>() {
//			@Mock
//			public void check(String function, Date now) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("Inquiry_fe_resluts.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		PBKeyedTemplateIndexer.Builder indexerBuilder = PBKeyedTemplateIndexer
//				.newBuilder().setFingerPrintType(
//						FingerPrintType.FINGER_PRINT_ROLLED);
//		PBKeyedTemplateReference.Builder templateRefBuilder = PBKeyedTemplateReference
//				.newBuilder().setJobId(20)
//				.setKey(TemplateFormatType.TEMPLATE_TI)
//				.setIndexer(indexerBuilder);
//
//		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
//				.newBuilder().setKeyedReferenece(templateRefBuilder);
//		PBInquiryOptions.Builder optionsBuilder = PBInquiryOptions.newBuilder();
//		PBInquiryJobRequest inquiryJobReq = PBInquiryJobRequest
//				.newBuilder()
//				.setJobInfo(
//						PBInquiryJobInfo.newBuilder().setFunction(
//								InquiryFunctionType.TI))
//				.addFusionJobInput(
//						PBFusionJobInput
//								.newBuilder()
//								.setScopes(
//										PBInquiryScopeOptions
//												.newBuilder()
//												.addScope(1)
//												.addTargetFingerPrint(
//														FingerPrintType.FINGER_PRINT_ROLLED))
//								.setKeyedTemplateData(templateBuilder)
//								.setInquiryOptions(optionsBuilder)).build();
//		PBInquiryJobResponse inquiryJobRes = aimInquiryService.inquiry(
//				inquiryJobReq, true);
//		Assert.assertTrue(inquiryJobRes.getJobId() > 0);
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				inquiryJobRes.getServiceState().getState());
//
//	}
//
//	@Test
//	public void testInquirykeyedInquiryOptionsIsNull() {
//		new MockUp<LicenseManager>() {
//			@Mock
//			public void check(String function, Date now) {
//				return;
//			}
//		};		
//		URL url = this.getClass().getResource("Inquiry_fe_resluts.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		PBKeyedTemplateIndexer.Builder indexerBuilder = PBKeyedTemplateIndexer
//				.newBuilder().setFingerPrintType(
//						FingerPrintType.FINGER_PRINT_ROLLED);
//
//		PBKeyedTemplateReference.Builder templateRefBuilder = PBKeyedTemplateReference
//				.newBuilder().setJobId(20)
//				.setKey(TemplateFormatType.TEMPLATE_TI)
//				.setIndexer(indexerBuilder);
//
//		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
//				.newBuilder().setKeyedReferenece(templateRefBuilder);
//		PBInquiryJobRequest inquiryJobReq = PBInquiryJobRequest
//				.newBuilder()
//				.setJobInfo(
//						PBInquiryJobInfo.newBuilder().setFunction(
//								InquiryFunctionType.TI))
//				.addFusionJobInput(
//						PBFusionJobInput
//								.newBuilder()
//								.setScopes(
//										PBInquiryScopeOptions
//												.newBuilder()
//												.addScope(1)
//												.addTargetFingerPrint(
//														FingerPrintType.FINGER_PRINT_ROLLED))
//								.setKeyedTemplateData(templateBuilder)).build();
//		PBInquiryJobResponse inquiryJobRes = aimInquiryService.inquiry(
//				inquiryJobReq, true);
//		Assert.assertTrue(inquiryJobRes.getJobId() > 0);
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				inquiryJobRes.getServiceState().getState());
//
//	}
//
//	@Test
//	public void testInquirykeyedTemplateData() {
//		jdbcTemplate.update("delete from fusion_jobs");
//		jdbcTemplate.update("commit");
//		new MockUp<JmsSender>() {
//			@Mock
//			private void convertAndSend(String queueName, Object object) {
//				return;
//			}
//		};
//		
//		new MockUp<LicenseManager>() {
//			@Mock
//			public void check(String function, Date now) {
//				return;
//			}
//		};		
//		byte[] bytes = { 1, 2, 3 };
//
//		PBInquiryJobRequest inquiryJobReq = PBInquiryJobRequest
//				.newBuilder()
//				.setJobInfo(
//						PBInquiryJobInfo.newBuilder().setFunction(
//								InquiryFunctionType.TI))
//				.addFusionJobInput(
//						PBFusionJobInput
//								.newBuilder()
//								.setScopes(
//										PBInquiryScopeOptions
//												.newBuilder()
//												.addScope(1)
//												.addTargetFingerPrint(
//														FingerPrintType.FINGER_PRINT_SLAP)
//												.addTargetFingerPrint(
//														FingerPrintType.FINGER_PRINT_ROLLED))
//								.setKeyedTemplateData(
//										PBKeyedTemplateData
//												.newBuilder()
//												.setKeyedTemplate(
//														PBKeyedTemplate
//																.newBuilder()
//																.setKey(TemplateFormatType.TEMPLATE_TI)
//																.setTemplateBinary(
//																		ByteString
//																				.copyFrom(bytes))
//																.setIndexer(
//																		PBKeyedTemplateIndexer
//																				.newBuilder()
//																				.setFingerPrintType(
//																						FingerPrintType.FINGER_PRINT_ROLLED)))))
//				.build();
//		try {
//			PBInquiryJobResponse inquiryJobRes = aimInquiryService.inquiry(
//					inquiryJobReq, true);
//			Assert.assertTrue(inquiryJobRes.getJobId() > 0);
//			Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//					inquiryJobRes.getServiceState().getState());
//			List<Map<String, Object>> listJQ = jdbcTemplate
//					.queryForList("select * from job_queue");
//			Assert.assertEquals(1, listJQ.size());
//			Map<String, Object> mapJQ = listJQ.get(0);
//
//			List<Map<String, Object>> list = jdbcTemplate
//					.queryForList("select * from fusion_jobs");
//			Assert.assertEquals(1, list.size());
//			Map<String, Object> map = list.get(0);
//			Assert.assertEquals(1,
//					Integer.parseInt(map.get("FUNCTION_ID").toString()));
//			Assert.assertEquals(mapJQ.get("JOB_ID"), map.get("JOB_ID"));
//			List<Map<String, Object>> listCJ = jdbcTemplate
//					.queryForList("select * from container_jobs");
//			Assert.assertEquals(0, listCJ.size());
//			byte[] bytes1 = (byte[]) list.get(0).get("INQUIRY_JOB_DATA");
//			try {
//				PBInquiryJobRequest request = PBInquiryJobRequest
//						.parseFrom(bytes1);
//				Assert.assertEquals(1, request.getFusionJobInput(0)
//						.getInquiryOptions().getFusionWeightCount());
//				Assert.assertEquals(100, request.getFusionJobInput(0)
//						.getInquiryOptions().getFusionWeight(0).getWeight());
//				Assert.assertEquals(FingerSetType.PC2_ROLLED, request
//						.getFusionJobInput(0).getInquiryOptions()
//						.getFusionWeight(0).getInquirySet());
//
//			} catch (InvalidProtocolBufferException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//				fail();
//			}
//		} finally {			
//		}
//
//	}
//
//	@Test
//	public void testGetJobStatusFAILED_FLAGIsNull() {
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,5,0,123,0,123,0,0,1)");
//		jdbcTemplate.execute("commit");
//		PBJobStatusRequest jobStatusReq = PBJobStatusRequest.newBuilder()
//				.setJobId(20).build();
//		PBJobStatusResponse jobStatusRes = aimInquiryService
//				.getJobStatus(jobStatusReq);
//		Assert.assertEquals(20, jobStatusRes.getJobId());
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				jobStatusRes.getServiceState().getState());
//		Assert.assertEquals(false, jobStatusRes.getJobFailed());
//		Assert.assertEquals(JobStateType.JOB_STATE_QUEUED,
//				jobStatusRes.getJobState());
//	}
//
//	@Test
//	public void testGetJobStatusFAILED_FLAGNotNull() {
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,5,0,123,1,0,123,0,0,1)");
//		jdbcTemplate.execute("commit");
//		PBJobStatusRequest jobStatusReq = PBJobStatusRequest.newBuilder()
//				.setJobId(20).build();
//		PBJobStatusResponse jobStatusRes = aimInquiryService
//				.getJobStatus(jobStatusReq);
//		Assert.assertEquals(20, jobStatusRes.getJobId());
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				jobStatusRes.getServiceState().getState());
//		Assert.assertEquals(true, jobStatusRes.getJobFailed());
//		Assert.assertEquals(JobStateType.JOB_STATE_QUEUED,
//				jobStatusRes.getJobState());
//	}
//
//	@Test
//	public void testGetJobStatusFAILED_FLAGNotNull_WORKING() {
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,5,1,123,1,0,123,0,0,1)");
//		jdbcTemplate.execute("commit");
//		PBJobStatusRequest jobStatusReq = PBJobStatusRequest.newBuilder()
//				.setJobId(20).build();
//		PBJobStatusResponse jobStatusRes = aimInquiryService
//				.getJobStatus(jobStatusReq);
//		Assert.assertEquals(20, jobStatusRes.getJobId());
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				jobStatusRes.getServiceState().getState());
//		Assert.assertEquals(true, jobStatusRes.getJobFailed());
//		Assert.assertEquals(JobStateType.JOB_STATE_WORKING,
//				jobStatusRes.getJobState());
//	}
//
//	@Test
//	public void testGetJobStatusFAILED_FLAGNotNull_DONE() {
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,5,2,123,1,0,123,0,0,1)");
//		jdbcTemplate.execute("commit");
//		PBJobStatusRequest jobStatusReq = PBJobStatusRequest.newBuilder()
//				.setJobId(20).build();
//		PBJobStatusResponse jobStatusRes = aimInquiryService
//				.getJobStatus(jobStatusReq);
//		Assert.assertEquals(20, jobStatusRes.getJobId());
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				jobStatusRes.getServiceState().getState());
//		Assert.assertEquals(true, jobStatusRes.getJobFailed());
//		Assert.assertEquals(JobStateType.JOB_STATE_DONE,
//				jobStatusRes.getJobState());
//	}
//
//	@Test
//	public void testGetJobStatusJQNull() {
//		/*
//		 * jdbcTemplate .update(
//		 * "INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,5,0,123,1,0,123,0,0,1)"
//		 * );
//		 */
//		jdbcTemplate.execute("commit");
//		PBJobStatusRequest jobStatusReq = PBJobStatusRequest.newBuilder()
//				.setJobId(20).build();
//		try {
//			aimInquiryService.getJobStatus(jobStatusReq);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof ArgumentException);			
//		}
//
//	}
//
//	@Test
//	public void testListJobIdsNull() {
//
//		try {
//			aimInquiryService.listJobIds();
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof AimRuntimeException);
//			Assert.assertEquals("List inquiry job id empty..", e.getMessage());
//		}
//
//	}
//
//	@Test
//	public void testListJobIds() {
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,5,0,123,1,0,123,0,0,1)");
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(25,5,0,123,1,0,123,0,0,1)");
//		jdbcTemplate.execute("commit");
//		PBListJobIdsResponse listJobIdRes = aimInquiryService.listJobIds();
//		Assert.assertEquals(2, listJobIdRes.getJobIdList().size());
//		// listJobIdRes.getJobIdList().remove(0);
//		Assert.assertEquals(20, listJobIdRes.getJobId(0));
//		Assert.assertEquals(25, listJobIdRes.getJobId(1));
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				listJobIdRes.getServiceState().getState());
//	}
//
//	@Test
//	public void testDeleteJob() {
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,5,0,123,1,0,123,0,0,1)");
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(25,5,0,123,1,0,123,0,0,1)");
//		jdbcTemplate.execute("commit");
//		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
//				"select count(*) from job_queue", Integer.class));
//		PBDeleteJobRequest deleteJobReq = PBDeleteJobRequest.newBuilder()
//				.setJobId(20).build();
//		aimInquiryService.deleteJob(deleteJobReq);
//		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
//				"select count(*) from job_queue", Integer.class));
//
//	}
//
//	@Test
//	public void testDeleteJobNull() {
//		PBDeleteJobRequest deleteJobReq = PBDeleteJobRequest.newBuilder()
//				.setJobId(20).build();
//		aimInquiryService.deleteJob(deleteJobReq);
//		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
//				"select count(*) from job_queue", Integer.class));
//	}
//
//	@Test
//	public void testClearJobs() {
//		aimInquiryService.clearJobs();
//		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
//				"select count(*) from job_queue", Integer.class));
//	}
//
//	@Test
//	public void testClearJobsDataBaseException() {
//		new MockUp<InquiryJobDao>() {
//			@Mock
//			public void clearJobs() {
//				throw new DataBaseException("1",
//						"Exception occurred when clear inquiry job.", "111111");
//			}
//		};
//		try {
//			aimInquiryService.clearJobs();
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof DataBaseException);
//			DataBaseException exception = (DataBaseException) e;
//			Assert.assertEquals(
//					"Inquiry Service (DataBase error occurred, error:Exception occurred when clear inquiry job.)",
//					exception.getDescription());
//			Assert.assertEquals(AimError.INQ_DB.getErrorCode(),
//					exception.getErrorCode());
//			Assert.assertEquals(
//					"Inquiry Service (DataBase error occurred, error:Exception occurred when clear inquiry job.)",
//					e.getMessage());
//			return;
//		} finally {
//			
//		}
//		fail();
//
//	}
//
//	@Test
//	public void testGetJobResultJobIdNotExistInDB() {
//		PBJobResultRequest inquiryJobRequest = PBJobResultRequest.newBuilder()
//				.setJobId(20).build();
//		try {
//			aimInquiryService.getJobResult(inquiryJobRequest);
//		} catch (Exception e) {			
//			Assert.assertTrue(e instanceof ArgumentException);		
//			return;
//		}
//		fail();
//	}
//
//	@Test
//	public void testGetJobResultResult_JobStateNotDone() {
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(25,5,0,123,1,0,123,0,0,1)");
//		jdbcTemplate.execute("commit");
//		PBJobResultRequest inquiryJobRequest = PBJobResultRequest.newBuilder()
//				.setJobId(25).build();
//		try {
//			aimInquiryService.getJobResult(inquiryJobRequest);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof AimRuntimeException);
//			Assert.assertEquals(
//					e.getMessage(),
//					"Job 25 is in QUEUED state. Job must be in DONE state before calling getJobResult()");
//			return;
//		}
//		fail();
//
//	}
//
//	@Test
//	public void testGetJobResultResultNull() {
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(25,5,2,123,1,0,123,0,0,1)");
//		jdbcTemplate.execute("commit");
//		PBJobResultRequest inquiryJobRequest = PBJobResultRequest.newBuilder()
//				.setJobId(25).build();
//		try {
//			aimInquiryService.getJobResult(inquiryJobRequest);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof AimRuntimeException);
//			Assert.assertEquals(e.getMessage(),
//					"Inquiry Job 25 result is null..)");
//			return;
//		}
//		fail();
//
//	}
//
//	@Test
//	public void testGetJobResultResultNotNull() {
//		byte[] bytes = PBInquiryJobResult
//				.newBuilder()
//				.setJobId(25)
//				.setServiceState(
//						PBServiceState.newBuilder().setState(
//								ServiceStateType.SERVICE_STATE_SUCCESS))
//				.build().toByteArray();
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,RESULT,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(25,5,2,?,123,1,0,123,0,0,1)",
//						bytes);
//		jdbcTemplate.execute("commit");
//		PBJobResultRequest inquiryJobRequest = PBJobResultRequest.newBuilder()
//				.setJobId(25).build();
//		PBInquiryJobResult inqJobResult = aimInquiryService
//				.getJobResult(inquiryJobRequest);
//		Assert.assertEquals(0, inqJobResult.getCandidateList()
//				.getCandidateList().size());
//		Assert.assertEquals(25, inqJobResult.getJobId());
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				inqJobResult.getServiceState().getState());
//	}
//
//	@Test
//	public void testGetJobResultResultNotNull_StatisticsNotNull_candidateListNotNull() {
//		byte[] bytes = PBInquiryJobResult
//				.newBuilder()
//				.setJobId(25)
//				.setCandidateList(PBInquiryCandidateList.newBuilder())
//				.setStatistics(
//						PBInquiryResultStatistics.newBuilder().setAmr(
//								PBInquiryResultStatisticsAMR.newBuilder()
//										.setMatchCount(100l).setReadCount(10l)))
//				.setServiceState(
//						PBServiceState.newBuilder().setState(
//								ServiceStateType.SERVICE_STATE_SUCCESS))
//				.build().toByteArray();
//		jdbcTemplate
//				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,RESULT,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(25,5,2,?,123,1,0,123,0,0,1)",
//						bytes);
//		jdbcTemplate.execute("commit");
//		PBJobResultRequest inquiryJobRequest = PBJobResultRequest.newBuilder()
//				.setJobId(25).build();
//		PBInquiryJobResult inqJobResult = aimInquiryService
//				.getJobResult(inquiryJobRequest);
//		Assert.assertEquals(0, inqJobResult.getCandidateList()
//				.getCandidateList().size());
//		Assert.assertEquals(25, inqJobResult.getJobId());
//		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
//				inqJobResult.getServiceState().getState());
//	}
//
//	@Test
//	public void testInquiry_1top_2fusion_2containerjob_scopeisnull_aggregation() {
//
//		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
//				.newBuilder()
//				.setKeyedTemplate(
//						PBKeyedTemplate
//								.newBuilder()
//								.setKey(TemplateFormatType.TEMPLATE_TI)
//								.setIndexer(
//										PBKeyedTemplateIndexer
//												.newBuilder()
//												.setFingerPrintType(
//														FingerPrintType.FINGER_PRINT_ROLLED))
//								.setTemplateBinary(
//										ByteString
//												.copyFrom(new byte[] { 0, 1 })));
//
//		PBInquiryJobRequest inquiryJobReq = PBInquiryJobRequest
//				.newBuilder()
//				.setJobInfo(
//						PBInquiryJobInfo.newBuilder().setFunction(
//								InquiryFunctionType.TI))
//				.addFusionJobInput(
//						PBFusionJobInput.newBuilder().setKeyedTemplateData(
//								templateBuilder)).build();
//		try {
//			aimInquiryService.inquiry(inquiryJobReq, true);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof ArgumentException);
//			ArgumentException exception = (ArgumentException) e;
//			Assert.assertEquals(AimError.INQ_COMBINE_OF_KEY.getErrorCode(),
//					exception.getErrorCode());
//			Assert.assertEquals(
//					"Inquiry Job (The combination of functionName, TemplateFormatType, Search Side FingerPrintType and File side FingerPrintType is not correct, Search Key: SearchKey[function=TI,templateFmt=TEMPLATE_TI,sFinPrint=FINGER_PRINT_ROLLED,fFinPrint=<null>])",
//					exception.getDescription());
//			Assert.assertEquals(
//					"Inquiry Job (The combination of functionName, TemplateFormatType, Search Side FingerPrintType and File side FingerPrintType is not correct, Search Key: SearchKey[function=TI,templateFmt=TEMPLATE_TI,sFinPrint=FINGER_PRINT_ROLLED,fFinPrint=<null>])",
//					e.getMessage());
//
//			return;
//		}
//		fail();
//		jdbcTemplate.execute("commit");
//	}
//
//}
