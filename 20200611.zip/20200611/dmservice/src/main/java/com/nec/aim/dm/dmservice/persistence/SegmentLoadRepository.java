package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import com.nec.aim.dm.dmservice.entity.SegmentLoading;

/**
 * @author xia
 * @file SegmentLoadRepository.java
 * @create at 2020/06/11 15:18:18 
 */
public interface SegmentLoadRepository {	
	/**
	 * @param segLoad
	 * @throws SQLException
	 */
	public void insertSegmentLoad(SegmentLoading segLoad)  throws SQLException;
	/**
	 * @param segLoad
	 * @throws SQLException
	 */
	public void updateSegmentLoadWithMailFlag(SegmentLoading segLoad)  throws SQLException;	
	/**
	 * @param segLoad
	 * @throws SQLException
	 */
	public void updateSegmentLoadNoMailFlag(SegmentLoading segLoad)  throws SQLException;
	/**
	 * @param segLoad
	 * @throws SQLException
	 */
	public void updateAfterDelWithNoMailFlag(SegmentLoading segLoad)  throws SQLException;
	/**
	 * @param version
	 * @param nsmid
	 * @param segmentId
	 * @throws SQLException
	 */
	public void updateAfterNew(long version, int nsmid, long segmentId) throws SQLException;
	/**
	 * @param storageId
	 * @param segmentId
	 * @return
	 * @throws SQLException
	 */
	public long getLastVersion(int storageId, long segmentId) throws SQLException;
	/**
	 * @param segmentId
	 * @return
	 * @throws SQLException
	 */
	public List<String> getActiveStorageUrl(long segmentId) throws SQLException;	
}
