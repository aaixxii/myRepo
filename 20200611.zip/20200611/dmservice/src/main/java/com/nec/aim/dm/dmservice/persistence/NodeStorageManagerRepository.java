package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import com.nec.aim.dm.dmservice.entity.NodeStorageManager;

/**
 * @author xia
 * @file NodeStorageManagerRepository.java
 * @create at 2020/06/11 15:17:12 
 */
public interface NodeStorageManagerRepository {
	/**
	 * @return
	 * @throws SQLException
	 */
	public List<NodeStorageManager> findAll()  throws SQLException;
	/**
	 * @param id
	 * @param dmStorageId
	 * @return
	 * @throws SQLException
	 */
	public NodeStorageManager findById(Long id, String dmStorageId)  throws SQLException;	
	/**
	 * @param redundancy
	 * @return
	 * @throws SQLException
	 */
	public List<NodeStorageManager>  findNeedNodeByRedundancy(int redundancy)  throws SQLException;
	/**
	 * @param storageId
	 */
	public void setSignalMailFlag(int storageId);	
	/**
	 * @param segmentId
	 * @param redundancy
	 * @return
	 * @throws SQLException
	 */
	public List<NodeStorageManager> getNodeStorgeBySegmentId(Long segmentId, Integer redundancy) throws SQLException;
	public void commit() throws SQLException;
	public void rollback() throws SQLException;
	/**
	 * @throws SQLException
	 */
	public void getNodeStorageUrlAndId() throws SQLException;
}
