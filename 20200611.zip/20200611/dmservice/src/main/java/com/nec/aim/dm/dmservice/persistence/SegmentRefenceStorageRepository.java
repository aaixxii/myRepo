package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import com.nec.aim.dm.dmservice.entity.SegBioNsmUrl;

/**
 * @author xia
 * @file SegmentRefenceStorageRepository.java
 * @create at 2020/06/11 15:18:52 
 */
public interface SegmentRefenceStorageRepository {
	/**
	 * @param storageId
	 * @param segId
	 * @param bioId
	 * @throws SQLException
	 */
	public void insertSegRefStorageWitoutRefId(Integer storageId, Long segId, Long bioId) throws SQLException;
	/**
	 * @param storageId
	 * @param segId
	 * @param bioId
	 * @param externalId
	 * @throws SQLException
	 */
	public void inserSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId, String externalId)  throws SQLException;
	/**
	 * @param storageId
	 * @param segId
	 * @param bioId
	 * @return
	 * @throws SQLException
	 */
	public int deleteSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId)  throws SQLException;
	/**
	 * @param externalId
	 * @param storageId
	 * @param segId
	 * @param bioId
	 * @return
	 * @throws SQLException
	 */
	public int updateSegmentRefenceStorageInfo( String externalId, Integer storageId, Long segId, Long bioId)  throws SQLException;
	/**
	 * @param externalId
	 * @return
	 * @throws SQLException
	 */
	public List<SegBioNsmUrl> getInfoForGetTemplate(String externalId)  throws SQLException;
}
