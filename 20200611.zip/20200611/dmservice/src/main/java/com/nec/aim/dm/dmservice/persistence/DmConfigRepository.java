package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

/**
 * @author xia
 * @file DmConfigRepository.java
 * @create at 2020/06/11 15:16:50 
 */
public interface DmConfigRepository {
	
	/**
	 * @return
	 * @throws SQLException
	 */
	public int getRedundancy() throws SQLException;
	/**
	 * @return
	 * @throws SQLException
	 */
	public int getMaxSegmentRecord() throws SQLException;

}
