package jp.co.nec.aim.mm.exception;

/**
 * ArgumentException
 * 
 * @author liuyq
 * 
 */
public class XmlRequstException extends AimErrorInfoException {
	
	private static final long serialVersionUID = 4250493026997517624L;

	/**
	 * ArgumentException
	 * 
	 * @param errorCode
	 *            error code
	 * @param description
	 *            error description
	 * @param epochTime
	 *            error epoch time
	 */
	public XmlRequstException(String errorCode, String description,
			String epochTime, String uidCode) {
		super(errorCode, description, epochTime, uidCode);
	}
}
