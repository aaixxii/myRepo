package jp.co.nec.aim.mm.sessionbeans.pojo;

import static jp.co.nec.aim.mm.constants.Constants.IN_USING_ADJUST;
import static jp.co.nec.aim.mm.constants.Constants.SEGMENT_CHANGE_LOG_PRIFFIX;
import static jp.co.nec.aim.mm.constants.Constants.SEGMENT_CHANGE_LOG_SAVE_DAYS;

import java.time.LocalDate;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.mm.partition.PartitionUtil;

public class AimManager {
	private static Logger logger = LoggerFactory.getLogger(AimManager.class);
	private static final ConcurrentHashMap<String, Object> inquiryCilientJobLockerQueue = new ConcurrentHashMap<>(); //key is jobId used get job result
	private static final ConcurrentHashMap<String, Object> extractCilientJobLockerQueue = new ConcurrentHashMap<>();
	
	private static final ConcurrentHashMap<String, UidAimAmqResponse> inquiryClientJobResultsQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, String> extractClientJobResultsQueue = new ConcurrentHashMap<>();
	
	private static final ConcurrentHashMap<String, Object> inquiryLockQueue = new ConcurrentHashMap<>(); 
	private static final ConcurrentHashMap<String, IdentifyResponse> inquiryJobResutQueue = new ConcurrentHashMap<>(); //key is top_job_id 	
	private static final ConcurrentHashMap<String, Object> extractLockQueue = new ConcurrentHashMap<>(); //key is fe_job_id
	private static final ConcurrentHashMap<String, PBMuExtractJobResultItem> extractJobResutQueue = new ConcurrentHashMap<>(); //key is fe_job_id 
	
	private static final ConcurrentHashMap<String, String> uidMMSettingMap = new ConcurrentHashMap<>();
	
	public static void saveToUidMMSettingMap(String key, String value) {
		uidMMSettingMap.putIfAbsent(key, value);
	}
	
	public static String getValueFromUidMMSettingMap(String key) {
		return uidMMSettingMap.get(key);
	}	
	
private static final ConcurrentHashMap<String, Long> segChangeRotationMap = new ConcurrentHashMap<>(); 
	
	public static void saveSegChangeSaveDays(Long segChangeLogSaveDays) {
		segChangeRotationMap.remove(SEGMENT_CHANGE_LOG_SAVE_DAYS);
		segChangeRotationMap.put(SEGMENT_CHANGE_LOG_SAVE_DAYS, segChangeLogSaveDays);		
	}
	
	public static Long getSegChangeSaveDays() {
		return segChangeRotationMap.get(SEGMENT_CHANGE_LOG_SAVE_DAYS);
	}
	
	public static void saveInUsingAdjust(Long inUsingAdjust) {
		segChangeRotationMap.remove(IN_USING_ADJUST);
		segChangeRotationMap.put(IN_USING_ADJUST, inUsingAdjust);		
	}
	
	public static Long getInUsingAdjust() {
		return segChangeRotationMap.get(IN_USING_ADJUST);
	}
	
	public static String getSaveToWhichTable() {
		LocalDate today = LocalDate.now();
		long hashValue = PartitionUtil.getInstance().caculateHashAtThisToday(today);
		return SEGMENT_CHANGE_LOG_PRIFFIX + String.valueOf(hashValue);
	}
	
	public static String getTargetTableNameByDay(LocalDate thisDay) {		
		long hashValue = PartitionUtil.getInstance().caculateHashAtThisToday(thisDay);
		return SEGMENT_CHANGE_LOG_PRIFFIX + String.valueOf(hashValue);
	}

	public static void finishInquryClientJob(String topJobId) {
		try {
			inquiryCilientJobLockerQueue.remove(topJobId);
			inquiryClientJobResultsQueue.remove(topJobId);
			logger.info("Indetify Job is completed, jobid:{}", topJobId);			
		} catch (Exception e) {
			logger.warn("Object associated with key:{} may be removed!", topJobId);
		}		
	}
	
	public static void finishExtractClientJob(String feJobId) {
		try {
			extractCilientJobLockerQueue.remove(feJobId);
			extractClientJobResultsQueue.remove(feJobId);
			logger.info("Extract Job is completed, jobid:{}", feJobId);			
		} catch (Exception e) {
			logger.warn("Object associated with key:{} may be removed!", feJobId);
		}	
	}	
	
	public static void saveInquryClientJobLocker(String key , Object locker) {
		inquiryCilientJobLockerQueue.put(key, locker);		
	}

	public static void saveExtractClientJobLocker(String key , Object locker) {
		logger.info("save key={}", key);
		extractCilientJobLockerQueue.put(key, locker);		
	}
	
	public static void saveInquryClientJobResult(String key , UidAimAmqResponse idyRes) {
		inquiryClientJobResultsQueue.putIfAbsent(key, idyRes);
		Object iqyLocker = inquiryCilientJobLockerQueue.get(key);
		synchronized (iqyLocker) {			
			iqyLocker.notify();
			logger.info("identify job:{} is completed. notified to AimIdentifyServlet.", key);
		}			
	}
	
	public static void saveExtractClientJobResult(String key , String extRes) {
		extractClientJobResultsQueue.putIfAbsent(key, extRes);
		Object extLocker = extractCilientJobLockerQueue.get(key);
		synchronized (extLocker) {			
			extLocker.notify();
			logger.info("extract job:{} is completed. notified to AimExtractServlet.", key);
		}			
	}
	
	public static UidAimAmqResponse getIdentifyClientResponse(String key) {		
		return Optional.of(inquiryClientJobResultsQueue.get(key)).orElse(null);
	}
	
	public static String getExtractClientResponse(String key) {		
		return Optional.of(extractClientJobResultsQueue.get(key)).orElse(null);
	}	
	
	public static void finishInquiryJob(String topJobId) {
		try {
			inquiryLockQueue.remove(topJobId);
			inquiryJobResutQueue.remove(topJobId);
		} catch (Exception e) {
			logger.warn("Object associated with key:{} may be removed!", topJobId);
		}		
	}
	
	public static PBMuExtractJobResultItem getExtractJobResult(String feJobId) {
		return Optional.of(extractJobResutQueue.get(feJobId)).orElse(null);
	}
	
	public static void saveToExtractJobResutQueue(String key, PBMuExtractJobResultItem oneFejobResut) {
		extractJobResutQueue.put(key, oneFejobResut);		
		Object locker = extractLockQueue.get(key);
		synchronized (locker) {			
			locker.notify();
			logger.info("extract job:{} is completed. notified to AimSyncService.", key);
		}		
	}
	
	public static void saveToInquiryJobResutQueue(String key, IdentifyResponse iqyRes) {
		inquiryJobResutQueue.putIfAbsent(key, iqyRes);
	}
	
	public static IdentifyResponse getIdentifyResponse(String key) {		
		return Optional.of(inquiryJobResutQueue.get(key)).orElse(null);
	}	
	
	public static void saveToExtractLockQueue(String key, Object obj) {
		extractLockQueue.putIfAbsent(key, obj);		
	}
	
	public static void saveToInquiryLockQueue(String key, Object obj) {
		inquiryLockQueue.put(key, obj);
	}
	
	public static void finishExtractJob(String extJobId) {
		try {
			extractLockQueue.remove(extJobId);
			extractJobResutQueue.remove(extJobId);
		} catch (Exception e) {
			logger.warn("Object associated with key:{} may be removed!", extJobId);
		}	
	}

	public static ConcurrentHashMap<String, Object> getInquirylockqueue() {
		return inquiryLockQueue;
	}

	public static ConcurrentHashMap<String, Object> getExtractlockqueue() {
		return extractLockQueue;
	}
}
