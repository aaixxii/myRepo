package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.commons.lang3.time.StopWatch;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.log.Log;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class AddBiometricsProcedureThreadTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void before() {
		cleanRecord();
	}

	@After
	public void after() {
		cleanRecord();
	}

	private void cleanRecord() {
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testCallProcecure() {
		AddBiometricsProcedure procedure = new AddBiometricsProcedure(
				dataSource);
		procedure.setExternalId("test-001");
		procedure.setpNo(11);
		procedure.setContainerId(1);
		procedure.setBiometricsData(new byte[] { 1, 2, 3, 4 });
		procedure.execute();

		String sql = "SELECT CONTAINER_ID,EXTERNAL_ID FROM PERSON_BIOMETRICS";
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
		assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		assertEquals(1, ((Integer) map.get("CONTAINER_ID")).intValue());		
		assertEquals("test-001", (String) map.get("EXTERNAL_ID"));
	}

	@Test
	public void testCallProcecure_ExtractNull() {
		AddBiometricsProcedure procedure = new AddBiometricsProcedure(
				dataSource);
		procedure.setExternalId("test-111");
		procedure.setpNo(73);
		procedure.setContainerId(1);
		procedure.setBiometricsData(new byte[] { 1, 2, 3, 4 });
		procedure.execute();

		String sql = "SELECT CONTAINER_ID,EXTERNAL_ID FROM PERSON_BIOMETRICS";
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
		assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		assertEquals(1, ((Integer) map.get("CONTAINER_ID")).intValue());		
		assertEquals("test-111", (String) map.get("EXTERNAL_ID"));
	}

	@Test
	public void testCallProcedureWithThreads_BinId2()
			throws InterruptedException, ExecutionException {		
		int threads = 1;
		ScheduledExecutorService service = Executors
				.newScheduledThreadPool(threads);
		List<ScheduledFuture<Integer>> futures = new ArrayList<ScheduledFuture<Integer>>();
		int[] binIds = { 1 };
		for (int id = 0; id < threads; id++) {
			futures.add(service.schedule(new AddBioTask(dataSource, 2, binIds[id]), 2L,
					TimeUnit.SECONDS));
		}

		for (ScheduledFuture<Integer> future : futures) {
			Integer time = future.get();
			Log.info("It took {} msec to call add_biometrics()", time);
		}

		assertEquals(
				2,
				jdbcTemplate.queryForObject(
						"SELECT count(BIOMETRICS_ID) FROM PERSON_BIOMETRICS",
						Integer.class).intValue());
		assertEquals(
				2,
				jdbcTemplate
						.queryForObject(
								"select count(SEGMENT_ID) from SEGMENTS",
								Integer.class).intValue());
	}

	@Test
	public void testCallProcedureWithThreads() throws InterruptedException,
			ExecutionException {
		int threads = 10;
		ScheduledExecutorService service = Executors
				.newScheduledThreadPool(threads);
		List<ScheduledFuture<Integer>> futures = new ArrayList<ScheduledFuture<Integer>>();
		int[] binIds = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
		for (int id = 0; id < threads; id++) {
			futures.add(service.schedule(new AddBioTask(dataSource, binIds[id],
					id), 2L, TimeUnit.SECONDS));
		}

		for (ScheduledFuture<Integer> future : futures) {
			Integer time = future.get();
			Log.info("It took {} msec to call add_biometrics()", time);
		}

		assertEquals(
				10,
				jdbcTemplate.queryForObject(
						"SELECT count(BIOMETRICS_ID) FROM PERSON_BIOMETRICS",
						Integer.class).intValue());
		assertEquals(
				10,
				jdbcTemplate
						.queryForObject(
								"select count(SEGMENT_ID) from SEGMENTS",
								Integer.class).intValue());
	}

	private class AddBioTask implements Callable<Integer> {
		private DataSource dataSource;
		private int id;
		private int binId;

		public AddBioTask(DataSource dataSource, int binId, int id) {
			this.dataSource = dataSource;
			this.binId = binId;
			this.id = id;
		}

		@Override
		public Integer call() throws Exception {
			StopWatch watch = new StopWatch();
			watch.start();
			AddBiometricsProcedure procedure = new AddBiometricsProcedure(
					dataSource);
			procedure.setContainerId(new Integer(binId));
			procedure.setBiometricsData(new byte[] { 1, 2, 3, 4,5 });
			procedure.setpNo(new Integer(1));
			procedure.setExternalId("ExtId-0000" + id);
			procedure.execute();
			watch.stop();
			return new Integer((int) watch.getTime());
		}
	}

}
