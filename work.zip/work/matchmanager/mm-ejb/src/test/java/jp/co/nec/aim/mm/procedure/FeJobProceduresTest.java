package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FeJobProceduresTest {
	
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	
	private FeJobProcedures feJobProcedures;
	

	@Before
	public void setUp() throws Exception {		
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("commit");
		feJobProcedures = new FeJobProcedures(dataSource);
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testCreateNewFeJob() throws SQLException {
		String externalId = "1234666666666666";
		String requstId = "22222222222222222";
		String requstType = "insert";
		String payload = "I am payload";
		Long result = feJobProcedures.createNewFeJob(externalId,requstId,requstType, payload);
		Assert.assertNotNull(result);
		Assert.assertTrue(result >= 0L);		
	}
}
