package com.nec.lmx.agent.lmx;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class JdkSchedulerTest {
	static ScheduledExecutorService heatBeatExecutor = Executors.newSingleThreadScheduledExecutor();
	public static void main(String args[]) {
		heatBeatExecutor.scheduleAtFixedRate(new Thread(CheckExpiredTask), 0, 500,TimeUnit.MILLISECONDS);
	}	
	private static Runnable CheckExpiredTask = () -> {
		 System.out.println("Run lmx heatbeat!");
	};
}
