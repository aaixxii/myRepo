package com.nec.aim.uid.mumock.constants;

public class Configer {
	public static long muId = 1l;
	public static String muIpPort = "127.0.0.1:8084";	
	
	public static long getMuId() {
		return muId;
	}
	public static void setMuId(long muId) {
		Configer.muId = muId;
	}
	public static String getMuIpPort() {
		return muIpPort;
	}
	public static void setMuIpPort(String muIpPort) {
		Configer.muIpPort = muIpPort;
	}	
	
}
