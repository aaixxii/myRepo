package com.nec.aim.uid.mumock.extract;

import java.io.IOException;

import com.nec.aim.uid.mumock.post.HttpPoster;
import com.nec.aim.uid.mumock.util.ProtobufCreater;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;

public class ExtractResultSender implements Runnable {	
	private PBMuExtractJobRequest pbExtReq;
	private static final String mmUrl = "http://192.168.22.107:8080/matchmanager/ExtractJobComplete";
	
	public ExtractResultSender(PBMuExtractJobRequest pbExtReq) {
		this.pbExtReq = pbExtReq;		
	}

	@Override
	public void run() {
		
		PBMuExtractJobResult estRes = null;
		try {
			estRes = ProtobufCreater.buildPBMuExtractJobResult(pbExtReq);
		} catch (IOException e) {			
			e.printStackTrace();
		}
		HttpPoster.doExtractComplete(estRes, mmUrl);
		
	}

}
