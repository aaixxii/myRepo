package jp.co.nec.aim.mm.util;

import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;

import com.google.protobuf.ByteString;

public class KeyedIndexer {
	private String key;
	private int index;
	private byte[] template;

	public KeyedIndexer(TemplateFormatType keyType,
			PBKeyedTemplateIndexer indexer) {
		key = keyType.name();
		if (indexer == null) {
			index = 0;
		} else if (indexer.hasIndex()) {
			index = indexer.getIndex();
		} else if (indexer.hasFingerPrintType()) {
			index = indexer.getFingerPrintType().getNumber();
		} else if (indexer.hasPosition()) {
			index = indexer.getPosition().getNumber();
		} else {
			index = 0;
		}
	}

	public KeyedIndexer(TemplateFormatType keyType,
			PBKeyedTemplateIndexer indexer, ByteString template) {
		this(keyType, indexer);
		if (template != null) {
			this.template = template.toByteArray();
		}
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public byte[] getTemplate() {
		return template;
	}

	public void setTemplate(byte[] template) {
		this.template = template;
	}

	@Override
	public int hashCode() {
		return key.hashCode() * 10 + index;
	}

	@Override
	public boolean equals(Object anObject) {
		if (this == anObject) {
			return true;
		}
		if (anObject instanceof KeyedIndexer) {
			KeyedIndexer other = (KeyedIndexer) anObject;
			return other.key.equals(key) && other.index == index;
		}
		return false;
	}

	@Override
	public String toString() {
		return "TemplateFormatType: " + key + " Indexer: " + index;
	}
}
