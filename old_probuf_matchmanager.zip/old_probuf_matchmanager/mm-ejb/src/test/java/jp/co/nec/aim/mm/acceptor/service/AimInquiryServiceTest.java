package jp.co.nec.aim.mm.acceptor.service;

import static org.junit.Assert.fail;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.mm.aggregator.Aggregator;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.util.ProtobufCreater;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimInquiryServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private AimInquiryService aimInquiryService;
	@Resource
	private JdbcTemplate jdbcTemplate;
	private ProtobufCreater protobufCreater;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FUSION_JOBS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.execute("commit");
		setMockMethod();
		protobufCreater = new ProtobufCreater();
	}

	@After
	public void tearDown() {

		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FUSION_JOBS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.execute("commit");

	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
		
		new MockUp<Aggregator>() {
			@Mock
			public void doAggregation(long jobId) {
				return;
			}
			
		};
	}
	
	@Test
	public void inquiryByTemplateTest() {
		IdentifyRequest identifyRequest  = protobufCreater.createIdentifyRequest(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		String jobId = aimInquiryService.inquiry(identifyRequest, true);		
		Assert.assertNotNull(jobId);
	}
	
	@Test
	public void inquiryByReferIdTest() {
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);		
		pq.setEnrollmentId("enrollId1");
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		PBResponse.Builder pbRes = PBResponse.newBuilder();
		pbRes.setStatus("0");
		PBDataBlock.Builder dataBlock = PBDataBlock.newBuilder();
		PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
		template.setData(ByteString.copyFrom("template data".getBytes()));
		template.setReferenceId("enrollId1");
		dataBlock.setTemplateInfo(template.build());
		pbMsg.setDataBlock(dataBlock.build());		
		
		byte[] result = pbMsg.build().toByteArray();
		String sql = "insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,REFERENCE_ID,JOB_STATE,SUBMISSION_TS, RESULT) "
				+ "values(2000,17,'enrollId1',1, 333, ?)";
		jdbcTemplate.update(sql, new Object[] {result});
		IdentifyRequest identifyRequest  = protobufCreater.createIdentifyRequest(E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT);
		String jobId = aimInquiryService.inquiry(identifyRequest, true);		
		Assert.assertNotNull(jobId);
	}

	
	@Test(expected = Exception.class)
	public void inquiryByTemplateTestHaveProtobufErr() {
		IdentifyRequest identifyRequest  = protobufCreater.createIdentifyRequestWithErr(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		aimInquiryService.inquiry(identifyRequest, true);
		
	}
	
	@Test
	public void testDeleteJob() {
		jdbcTemplate
				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(20,5,0,123,1,0,123,0,0,1)");
		jdbcTemplate
				.update("INSERT INTO JOB_QUEUE(JOB_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) VALUES(25,5,0,123,1,0,123,0,0,1)");
		jdbcTemplate.execute("commit");
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from job_queue", Integer.class));
		PBDeleteJobRequest deleteJobReq = PBDeleteJobRequest.newBuilder()
				.setJobId(20).build();
		aimInquiryService.deleteJob(deleteJobReq);
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from job_queue", Integer.class));

	}

	@Test
	public void testDeleteJobNull() {
		PBDeleteJobRequest deleteJobReq = PBDeleteJobRequest.newBuilder()
				.setJobId(20).build();
		aimInquiryService.deleteJob(deleteJobReq);
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from job_queue", Integer.class));
	}

	@Test
	public void testClearJobs() {
		aimInquiryService.clearJobs();
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from job_queue", Integer.class));
	}

	@Test
	public void testClearJobsDataBaseException() {
		new MockUp<InquiryJobDao>() {
			@Mock
			public void clearJobs() {
				throw new DataBaseException("1",
						"Exception occurred when clear inquiry job.", "111111");
			}
		};
		try {
			aimInquiryService.clearJobs();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof DataBaseException);
			DataBaseException exception = (DataBaseException) e;
			Assert.assertEquals(
					"Inquiry Service (DataBase error occurred, error:Exception occurred when clear inquiry job.)",
					exception.getDescription());
			Assert.assertEquals(AimError.INQ_DB.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Service (DataBase error occurred, error:Exception occurred when clear inquiry job.)",
					e.getMessage());
			return;
		} finally {
			
		}
		fail();

	}


}
