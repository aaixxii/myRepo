package jp.co.nec.aim.mm.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBCorruptTempalte;
import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBResourceInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentInfo;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;

public class ProtobufHelper {		

	public static PBMapInquiryJobResult MapInquiryJobResult(long topLevelJobId,
			long planId, int msgSequence, String value, long matchCount,long readCount) {
			
		int requestIndex = 7;
		int containerId = 1;
		int messageSequence = msgSequence;
		long jobTimeout = 10;
		int internalMaxCandidates = 10;
		int mrId = 10;

		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
				.newBuilder();
		builder.setMrId(mrId);
		builder.setPlanId(planId);
		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
		jobInfo.setTopLevelJobId(topLevelJobId);
		jobInfo.setRequestIndex(requestIndex);
		jobInfo.setContainerId(containerId);
		jobInfo.setMessageSequence(messageSequence);
		jobInfo.setJobTimeout(jobTimeout);
		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
		jobInfo.setMuJobPopTime(7);		
		PBBusinessMessage result =  createPBBusinessMessage();
		builder.setResult(result);		
		return builder.build();
	}			

	public static PBMapInquiryJobResult MapInquiryJobResultFailure(
			long topLevelJobId, long planId, ServiceStateType stateType,
			String description) {
		int requestIndex = 7;
		int containerId = 1;
		long jobTimeout = 10;
		int internalMaxCandidates = 10;
		int mrId = 10;

		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
				.newBuilder();
		builder.setMrId(mrId);
		builder.setPlanId(planId);
		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
		jobInfo.setTopLevelJobId(topLevelJobId);
		jobInfo.setRequestIndex(requestIndex);
		jobInfo.setContainerId(containerId);
		jobInfo.setMessageSequence(0);
		jobInfo.setJobTimeout(jobTimeout);
		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
		jobInfo.setMuJobPopTime(7);

		
		//builder.setResult(result);
		return builder.build();
	}



	public static PBComponentInfo PBComponentInfo(ComponentType type,
			String version, String uniqueId, String contactUrl,
			String resouceInfo) {
		PBComponentInfo.Builder componentInfoBuilder = PBComponentInfo
				.newBuilder();

		componentInfoBuilder.setComponent(type);
		componentInfoBuilder.setVersion(version);
		componentInfoBuilder.setUniqueId(uniqueId);
		componentInfoBuilder.setContactUrl(contactUrl);

		if (StringUtils.isBlank(resouceInfo)) {
			return componentInfoBuilder.build();
		}

		String[] resourceInfo = StringUtils.split(resouceInfo, "-");
		PBResourceInfo.Builder resourceInfoBuilder = componentInfoBuilder
				.getResourceInfoBuilder();
		String abilityInfo = resourceInfo[0];
		if (!StringUtils.isBlank(abilityInfo)) {
			String[] infos = StringUtils.split(abilityInfo, ",");
			resourceInfoBuilder.getAbilityInfoBuilder()
					.setPrimarySize(Integer.parseInt(infos[0]))
					.setSecondarySize(Integer.parseInt(infos[1]));

			if (!StringUtils.isBlank(infos[2])) {
				resourceInfoBuilder.getAbilityInfoBuilder().setNumOfMatchers(
						Integer.parseInt(infos[2]));
			}
			if (!StringUtils.isBlank(infos[3])) {
				resourceInfoBuilder.getAbilityInfoBuilder().setNumOfExtractors(
						Integer.parseInt(infos[3]));
			}
			if (infos.length >= 4 && !StringUtils.isBlank(infos[4])) {
				resourceInfoBuilder.getAbilityInfoBuilder()
						.setPerformanceFactor(Integer.parseInt(infos[4]));
			}
		}
		if (resourceInfo.length > 1) {

			String[] infos = StringUtils.split(resourceInfo[1], "/");

			if (infos.length > 1 && !StringUtils.isBlank(infos[1])) {
				resourceInfoBuilder.setSegmentMapChanged(false);
				if (infos[1].equals("0")) {
					resourceInfoBuilder.setSegmentMapChanged(true);
				}

			}
			String[] segmentInfos = StringUtils.split(infos[0], "@");
			if (!StringUtils.isBlank(segmentInfos[0])) {
				StringUtils.split(resourceInfo[1], "/");
				List<PBSegmentInfo> pbSegInfos = Lists.newArrayList();
				for (String segmentInfo : segmentInfos) {
					String[] segInfos = StringUtils.split(segmentInfo, "||");
					PBSegmentInfo.Builder segBuilder = PBSegmentInfo
							.newBuilder();
					if (!StringUtils.isBlank(segInfos[0])) {
						String[] segInfo = StringUtils.split(segInfos[0], ",");

						segBuilder.setId(Integer.parseInt(segInfo[0]));
						if (segInfo[1].equals("0")) {
							segBuilder
									.setState(SegmentStateType.SEGMENT_STATE_MEMORY);
						}
						if (segInfo[1].equals("1")) {
							segBuilder
									.setState(SegmentStateType.SEGMENT_STATE_DISK);
						}
						if (segInfo[1].equals("2")) {
							segBuilder
									.setState(SegmentStateType.SEGMENT_STATE_ERROR);
						}
						segBuilder.setVersion(Long.parseLong(segInfo[2]));
						segBuilder.setQueuedVersion(Long.parseLong(segInfo[3]));
					}
					if (!StringUtils.isBlank(segInfos[1])) {
						String[] ids = StringUtils.split(segInfos[1], ",");
						PBCorruptTempalte.Builder builder = PBCorruptTempalte
								.newBuilder();
						for (int i = 0; i < ids.length; i++) {
							builder.addId(Long.parseLong(ids[i]));
						}
						segBuilder.setCorruptTemplates(builder);
					}
					pbSegInfos.add(segBuilder.build());
				}
				resourceInfoBuilder.addAllSegmentInfo(pbSegInfos);
			}
		}

		return componentInfoBuilder.build();
	}

	public static PBMapInquiryJobResult MapInquiryJobResultFailure01(
			long topLevelJobId, long planId, ServiceStateType stateType) {
		int requestIndex = 7;
		int containerId = 1;
		long jobTimeout = 10;
		int internalMaxCandidates = 10;
		int mrId = 10;

		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
				.newBuilder();
		builder.setMrId(mrId);
		builder.setPlanId(planId);
		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
		jobInfo.setTopLevelJobId(topLevelJobId);
		jobInfo.setRequestIndex(requestIndex);
		jobInfo.setContainerId(containerId);
		jobInfo.setMessageSequence(0);
		jobInfo.setJobTimeout(jobTimeout);
		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
		jobInfo.setMuJobPopTime(7);		
		PBBusinessMessage result = createPBBusinessMessage();
		builder.setResult(result);
		return builder.build();
	}

	public static PBMapInquiryJobResult MapInquiryJobResultFailure02(
			long topLevelJobId, long planId, ServiceStateType stateType,
			String description) {
		int requestIndex = 7;
		int containerId = 1;
		long jobTimeout = 10;
		int internalMaxCandidates = 10;
		int mrId = 10;

		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult
				.newBuilder();
		builder.setMrId(mrId);
		builder.setPlanId(planId);
		PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder();
		jobInfo.setTopLevelJobId(topLevelJobId);
		jobInfo.setRequestIndex(requestIndex);
		jobInfo.setContainerId(containerId);
		jobInfo.setMessageSequence(0);
		jobInfo.setJobTimeout(jobTimeout);
		jobInfo.setInternalMaxCandidates(internalMaxCandidates);
		jobInfo.setMuJobPopTime(7);
		PBBusinessMessage result = createPBBusinessMessage();			
		builder.setResult(result);
		builder.getErrorBuilder().setMuId(10).setSegmentId(1);
		return builder.build();
	}
	
	public static PBBusinessMessage createPBBusinessMessage() {
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
		PBResponse.Builder ps = PBResponse.newBuilder();
		ps.setStatus("0:success");
		pbMsg.setResponse(ps);
		PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());
		}
		
		Collections.shuffle(pbList); 		
		
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(false);
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}		
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		return pbMsg.build();
	}

}
