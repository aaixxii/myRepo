package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class InitExecutingJobCountProcedureTest {
	
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	

	@Before
	public void setUp() throws Exception {
		jdbcTemplate.execute("delete from JOB_QUEUE");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from JOB_QUEUE");
	}

	@Test
	public void testExecute() {
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(1000,1,1,3000,0,0,0,1)";
		jdbcTemplate.execute(jobQueueSql);
		InitExecutingJobCountProcedure procedure = new InitExecutingJobCountProcedure(
				dataSource);
		procedure.execute();
		List<Map<String, Object>> listIT = jdbcTemplate.queryForList("select"
				+ " JOB_EXEC_COUNT from INQUIRY_TRAFFIC order by FAMILY_ID");
		assertEquals(1, listIT.size());
		assertEquals("1", listIT.get(0).get("JOB_EXEC_COUNT")
				.toString());
		
	}

}
