﻿run.sh 
# mysql
docker run --name mysql \
  -d \
  -p 3306:3306 \
  --volumes-from data-mysql \
  -e 'MYSQL_ROOT_PASSWORD=password' \
  mysql
# redmine
docker run --name redmine \
  -d \
  --link mysql:mysql \
  --volumes-from data-redmine \
  --volumes-from data-gitbucket  \
  -e 'REDMINE_RELATIVE_URL_ROOT=/redmine' \
  -e 'DB_USER=redmine' \
  -e 'DB_NAME=redmine' \
  -e 'DB_PASS=password' \
  -e 'SMTP_USER=address@hoge.com' \
  -e 'SMTP_PASS=password' \
  sameersbn/redmine:2.6.3
# gitbucket
docker run --name gitbucket \
  -d \
  -p 29418:29418 \
  --volumes-from data-gitbucket \
  f99aq8ove/gitbucket \
  java -jar /opt/gitbucket.war --prefix=/gitbucket
# reverse-proxy
# あらかじめ myname/proxy でイメージをビルドしておく
docker run --name proxy
  -d \
  --link redmine:redmine
  --link gitbucket:gitbucket
  -p 80:80 \
  myname/proxy


docker stop gitbucket
docker stop redmine
docker stop mysql
docker stop proxy
# まとめて削除
docker rm gitbucket
docker rm redmine
docker rm mysql
docker rm proxy