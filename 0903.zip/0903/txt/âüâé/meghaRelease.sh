#!/bin/sh -x

RELEASE_VER=1.2.0
DVP_VER=1.2.0

COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-XM-GLOBAL-$RELEASE_VER/AIM-XM-GLOBAL-$RELEASE_VER-PKG

MEGHA_PKG_NAME=aim-xm-global-megha-$DVP_VER.zip   
KALITH_PJ_NAME=Megha-fork-1.2.0_8
                       
count=0
SVN_USER=xia
SVN_PWD=xia

if [ -d ./release ]; then
sudo rm -rf ./release
fi

mkdir release
cd release

svn ls --username $SVN_USER --password $SVN_PWD $COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $COPY_TO_DIR
else
	svn co --username $SVN_USER --password $SVN_PWD --depth=empty $COPY_TO_DIR
	svn ls --username $SVN_USER --password $SVN_PWD $COPY_TO_DIR/$MEGHA_PKG_NAME	
	if test $? = 0 ; then
		svn up --username $SVN_USER --password $SVN_PWD --depth=files AIM-XM-GLOBAL-$RELEASE_VER/$MEGHA_PKG_NAME
	fi
fi
cp -p -f ../$KALITH_PJ_NAME/src/bio-matcher-module/target/wildfly-9.0.2.Final-$DVP_VER.zip AIM-XM-GLOBAL-$RELEASE_VER-PKG
cd  AIM-XM-GLOBAL-$RELEASE_VER-PKG
svn add *
svn commit --username $SVN_USER --password $SVN_PWD --message "Update By $SVN_USER"
COMMIT_RESULT=$?
if test $COMMIT_RESULT -eq 0 ; then	
	count=`expr $count + 1`	 
fi

#Copy mehga rpm to shipment
cd ..

MEGHA_RPM_NAME=aim-xm-$DVP_VER-0.x86_64.rpm

RPM_COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-XM-GLOBAL-$RELEASE_VER/AIM-XM-GLOBAL-$RELEASE_VER-PKG/AIMInstaller/pkgs

svn ls --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $RPM_COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR
else
	svn co --username $SVN_USER --password $SVN_PWD --depth=empty $RPM_COPY_TO_DIR
	svn ls --username $SVN_USER --password $SVN_PWD $RPM_COPY_TO_DIR/$MEGHA_RPM_NAME	
	if test $? = 0 ; then
		svn up --username $SVN_USER --password $SVN_PWD --depth=files AIM-XM-GLOBAL-$RELEASE_VER/$MEGHA_RPM_NAME
	fi
fi
cp -p -f ../$KALITH_PJ_NAME/src/bio-matcher-module/target/rpm/aim-xm/RPMS/x86_64/$MEGHA_RPM_NAME pkgs
cd  pkgs
svn add *
svn commit --username $SVN_USER --password $SVN_PWD --message "Update By $SVN_USER"

cd ../
sudo rm -rf release
echo "Completed ......Done!"