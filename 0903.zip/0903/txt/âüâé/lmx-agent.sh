#!/bin/sh

#***********************************************************
#                readme:
#    su - root        
#    cd to path of lmx-agent tool
#    unzip lmx-agent.zip
#    chown -R usrid:groupid path to lmx-agent tool
#    chmod 775 lmx-agent.sh 
#    sh lmx-agent.sh port
****************************************************************

# sample for start LmxAgent: sh ./lmx_agent.sh port

#export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH

export LMX_LIB_PATH="/license/lmx/linux_x64"
java -jar -Djava.library.path=/license/lmx/linux_x64  -Djava.lmx.license.path=@192.168.21.119 lmx-agent.jar 8888


echo ""
echo " lmx agent..."
echo ""

PARAMA=$1

pwd

if [ ! -e log ]; then
        mkdir log
fi

if [ $# -lt 1 ]; then
echo "Usage:  lmx_agent.sh port"
exit 1
fi

java -jar ./lmx-agent.jar $PARAMA


