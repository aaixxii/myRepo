### 環境変数
export NDK_ROOT=/opt/Android/NDK-r14b
export PATH=$PATH:${NDK_ROOT}:${NDK_ROOT}/arm/32/bin

### FPINC C Wrapper library
pushd SDK/c_wrapper/src/wrapper
make
popd

### JNI
cp SDK/c_wrapper/src/wrapper/NecCmlArmWrapper.h SDK/JNI/src/NecCmlAndroidWrapper/jni/include
cp SDK/c_wrapper/src/core/include/FPINC.h SDK/JNI/src/NecCmlAndroidWrapper/jni/include
cp SDK/c_wrapper/src/wrapper/32/libNecArmWrapper.a SDK/JNI/src/NecCmlAndroidWrapper/jni/lib/32
cp SDK/c_wrapper/src/core/lib/32/libFPINC.a SDK/JNI/src/NecCmlAndroidWrapper/jni/lib/32
pushd SDK/JNI/src/NecCmlAndroidWrapper
javac -d ./bin ./src/com/nec/wrapper/NecCmlAndroidWrapper.java
jar cvf neccmlandroidwrapper.jar ./bin/com/nec/wrapper/
ndk-build NDK_TOOLCHAIN_VERSION=4.9
popd

### AimAndroidTest
export JDK8=/usr/java/jdk1.8.0_91
export PATH=$JDK8/bin:$PATH
export GRADLE_HOME=/opt/gradle-3.4.1
export PATH=$GRADLE_HOME/bin:$PATH

export ANDROID_SDK=/usr/Android/Sdk
export PATH=$ANDROID_SDK/platforms:$ANDROID_SDK/tools:$PATH
export PATH
sudo chmod -R 777 ./Application/AndroidStudioTest/app/libs/
sudo cp ./SDK/JNI/src/NecCmlAndroidWrapper/neccmlandroidwrapper.jar ./Application/AndroidStudioTest/app/libs/
cd ./Application/AndroidStudioTest/
bash ./gradlew
