# What is this?

This repository contains some scripts to help you to play with [Docker Swarm](https://docs.docker.com/engine/swarm/) and [Docker Machine](https://docs.docker.com/machine/) in your computer. You will be able to manage your own swarm for test Docker capabilities without needs any other infrastructure.