package com.xia.entity;
// Generated 2018/06/23 21:44:17 by Hibernate Tools 5.2.10.Final

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class BioLockInfo.
 * @see com.xia.entity.BioLockInfo
 * @author Hibernate Tools
 */
public class BioLockInfoHome {

	private static final Log log = LogFactory.getLog(BioLockInfoHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext().lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException("Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(BioLockInfo transientInstance) {
		log.debug("persisting BioLockInfo instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(BioLockInfo instance) {
		log.debug("attaching dirty BioLockInfo instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(BioLockInfo instance) {
		log.debug("attaching clean BioLockInfo instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(BioLockInfo persistentInstance) {
		log.debug("deleting BioLockInfo instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public BioLockInfo merge(BioLockInfo detachedInstance) {
		log.debug("merging BioLockInfo instance");
		try {
			BioLockInfo result = (BioLockInfo) sessionFactory.getCurrentSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public BioLockInfo findById(java.lang.String id) {
		log.debug("getting BioLockInfo instance with id: " + id);
		try {
			BioLockInfo instance = (BioLockInfo) sessionFactory.getCurrentSession().get("com.xia.entity.BioLockInfo",
					id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<BioLockInfo> findByExample(BioLockInfo instance) {
		log.debug("finding BioLockInfo instance by example");
		try {
			List<BioLockInfo> results = (List<BioLockInfo>) sessionFactory.getCurrentSession()
					.createCriteria("com.xia.entity.BioLockInfo").add(create(instance)).list();
			log.debug("find by example successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
