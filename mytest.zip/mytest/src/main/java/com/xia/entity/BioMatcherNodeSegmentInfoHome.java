package com.xia.entity;
// Generated 2018/06/23 21:44:17 by Hibernate Tools 5.2.10.Final

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class BioMatcherNodeSegmentInfo.
 * @see com.xia.entity.BioMatcherNodeSegmentInfo
 * @author Hibernate Tools
 */
public class BioMatcherNodeSegmentInfoHome {

	private static final Log log = LogFactory.getLog(BioMatcherNodeSegmentInfoHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext().lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException("Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(BioMatcherNodeSegmentInfo transientInstance) {
		log.debug("persisting BioMatcherNodeSegmentInfo instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(BioMatcherNodeSegmentInfo instance) {
		log.debug("attaching dirty BioMatcherNodeSegmentInfo instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(BioMatcherNodeSegmentInfo instance) {
		log.debug("attaching clean BioMatcherNodeSegmentInfo instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(BioMatcherNodeSegmentInfo persistentInstance) {
		log.debug("deleting BioMatcherNodeSegmentInfo instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public BioMatcherNodeSegmentInfo merge(BioMatcherNodeSegmentInfo detachedInstance) {
		log.debug("merging BioMatcherNodeSegmentInfo instance");
		try {
			BioMatcherNodeSegmentInfo result = (BioMatcherNodeSegmentInfo) sessionFactory.getCurrentSession()
					.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public BioMatcherNodeSegmentInfo findById(com.xia.entity.BioMatcherNodeSegmentInfoId id) {
		log.debug("getting BioMatcherNodeSegmentInfo instance with id: " + id);
		try {
			BioMatcherNodeSegmentInfo instance = (BioMatcherNodeSegmentInfo) sessionFactory.getCurrentSession()
					.get("com.xia.entity.BioMatcherNodeSegmentInfo", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<BioMatcherNodeSegmentInfo> findByExample(BioMatcherNodeSegmentInfo instance) {
		log.debug("finding BioMatcherNodeSegmentInfo instance by example");
		try {
			List<BioMatcherNodeSegmentInfo> results = (List<BioMatcherNodeSegmentInfo>) sessionFactory
					.getCurrentSession().createCriteria("com.xia.entity.BioMatcherNodeSegmentInfo")
					.add(create(instance)).list();
			log.debug("find by example successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
