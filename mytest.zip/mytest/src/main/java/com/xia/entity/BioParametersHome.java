package com.xia.entity;
// Generated 2018/06/23 21:44:17 by Hibernate Tools 5.2.10.Final

import java.util.List;
import javax.naming.InitialContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.SessionFactory;
import static org.hibernate.criterion.Example.create;

/**
 * Home object for domain model class BioParameters.
 * @see com.xia.entity.BioParameters
 * @author Hibernate Tools
 */
public class BioParametersHome {

	private static final Log log = LogFactory.getLog(BioParametersHome.class);

	private final SessionFactory sessionFactory = getSessionFactory();

	protected SessionFactory getSessionFactory() {
		try {
			return (SessionFactory) new InitialContext().lookup("SessionFactory");
		} catch (Exception e) {
			log.error("Could not locate SessionFactory in JNDI", e);
			throw new IllegalStateException("Could not locate SessionFactory in JNDI");
		}
	}

	public void persist(BioParameters transientInstance) {
		log.debug("persisting BioParameters instance");
		try {
			sessionFactory.getCurrentSession().persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void attachDirty(BioParameters instance) {
		log.debug("attaching dirty BioParameters instance");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(BioParameters instance) {
		log.debug("attaching clean BioParameters instance");
		try {
			sessionFactory.getCurrentSession().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void delete(BioParameters persistentInstance) {
		log.debug("deleting BioParameters instance");
		try {
			sessionFactory.getCurrentSession().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public BioParameters merge(BioParameters detachedInstance) {
		log.debug("merging BioParameters instance");
		try {
			BioParameters result = (BioParameters) sessionFactory.getCurrentSession().merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public BioParameters findById(com.xia.entity.BioParametersId id) {
		log.debug("getting BioParameters instance with id: " + id);
		try {
			BioParameters instance = (BioParameters) sessionFactory.getCurrentSession()
					.get("com.xia.entity.BioParameters", id);
			if (instance == null) {
				log.debug("get successful, no instance found");
			} else {
				log.debug("get successful, instance found");
			}
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List<BioParameters> findByExample(BioParameters instance) {
		log.debug("finding BioParameters instance by example");
		try {
			List<BioParameters> results = (List<BioParameters>) sessionFactory.getCurrentSession()
					.createCriteria("com.xia.entity.BioParameters").add(create(instance)).list();
			log.debug("find by example successful, result size: " + results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}
}
