#!/bin/bash

echo "build docker megha"
cd centos72
docker build -t centos72 .
cd ..
cd jdk
docker build -t centosjdk .
cd ..
cd megha
docker build -t megha .