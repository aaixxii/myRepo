const hostname = '127.0.0.1';
const port = 3000;
const http = require('http');
const fs = require('fs');
var express = require('express');
var app = express();
var path = require('path');
url = require('url');

app.use(express.static('public'));
app.use(express.static('views'));

app.get('/', function (req, res) {
    fs.readFile(__dirname + '/views/home.html', 'utf-8', function (err, data) {
        if (err) {
            res.setHeader('Content-Type', 'text/plain');
            res.statusCode = 404;
            res.end('Not Founded.');
        } else {
            res.setHeader('Content-Type', 'text/html');
            res.statusCode = 200;
            res.end(data);
        }
    });
});

app.get('/job_results', function (req, res) {
    var name = "";
    if (req.query.name) {
        name = req.query.name;
    }
    res.set('Content-Type', 'text/plain');
    var xml2js = require('xml2js');
    var parser = new xml2js.Parser();
    var xmlFile = path.join(__dirname, 'job_results', name);
    fs.readFile(xmlFile, function (err, data) {
        if (err) {
            res.statusCode = 404;
            res.end('Not Founded.');
        } else {
            parser.parseString(data, function (err, result) {
                if (err) {
                    res.statusCode = 500;
                    res.end('Parse xml error.');
                } else {
                    res.statusCode = 200;
                    res.end(result);
                }
            });
        }
    });
});

app.get('/images', function (req, res) {
    var name = "";
    if (req.query.name) {
        name = req.query.name;
    }
    var imageFile = path.join(__dirname, 'images', name); 
    var imagePath = path.resolve(path.resolve(__dirname,images + name)); 
    res.sendfile(imagePath);
    // var request = url.parse(req.url, true);
    // var action = request.pathname;
    // var img = fs.readFileSync(imageFile);
    // res.writeHead(200, {'Content-Type': 'image/bmp' });
    // res.end(img, 'binary');
    
   
    
    //res.sendfile(imageFile);
    // res.sendfile(imageFile);
    //var buf = fs.readFileSync(imageFile);
    //res.write('<html><body><img src="data:image/jpeg;base64,')
    //res.write(Buffer.from(data).toString('base64'));
    //res.end('"/></body></html>');
    //res.end(buf);
    //fs.createReadStream("C://Users/as/Desktop/App _Ideas/hh.jpg"),
   //var data = fs.createReadStream("C://Users/as/Desktop/App _Ideas/hh.jpg"), 
    //var bmp = require("bmp-js");
    //var bmpBuffer = fs.readFileSync(imageFile);
   // var bmpData = bmp.decode(bmpBuffer);
   // res.end(bmpData);

   


  


});



app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});