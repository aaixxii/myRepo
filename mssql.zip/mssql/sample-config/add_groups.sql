
USE [XMDB]
GO

Insert into BIO_SERVER_GROUP_INFO
   (GROUP_ID, COMPONENT_TYPE, DESCRIPTION)
 Values
   ('VCG01', 'VC', 'Verification Controller Group');
   
Insert into BIO_SERVER_GROUP_INFO
   (GROUP_ID, COMPONENT_TYPE, DESCRIPTION)
 Values
   ('VNG01', 'VN', 'Verification Node Group');
   
 

Insert into BIO_SERVER_GROUP_INFO
   (GROUP_ID, COMPONENT_TYPE, DESCRIPTION)
 Values
   ('ECG01', 'EC', 'Extraction Controller Group');

Insert into BIO_SERVER_GROUP_INFO
   (GROUP_ID, COMPONENT_TYPE, DESCRIPTION)
 Values
   ('ENG01', 'EN', 'Extraction Node Group');
   



Insert into BIO_SERVER_GROUP_INFO
   (GROUP_ID, COMPONENT_TYPE, DESCRIPTION)
 Values
   ('SBG01', 'SB', 'Search Broker Group');
   
Insert into BIO_SERVER_GROUP_INFO
   (GROUP_ID, COMPONENT_TYPE, DESCRIPTION)
 Values
   ('SCG01', 'SC', 'Search Controller Group');
   
Insert into BIO_SERVER_GROUP_INFO
   (GROUP_ID, COMPONENT_TYPE, DESCRIPTION)
 Values
   ('SNG01', 'SN', 'Search Node Group');

GO
