:r sample-config/add_bin_segments.sql
:r sample-config/add_ec.sql
:r sample-config/add_ec_parameters.sql
:r sample-config/add_en.sql

:r sample-config/add_sb.sql
:r sample-config/add_sc.sql
:r sample-config/add_sc_parameters.sql
:r sample-config/add_sn.sql

:r sample-config/add_tvc.sql
:r sample-config/add_tvn.sql
:r sample-config/add_vc.sql
:r sample-config/add_vc_parameters.sql
:r sample-config/add_vn.sql


:r sample-config/add_groups.sql
:r sample-config/add_template_definitions.sql
:r sample-config/add_template_storage.sql


