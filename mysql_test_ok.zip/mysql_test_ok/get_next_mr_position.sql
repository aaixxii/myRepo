CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_next_mr_position`()
my_label:BEGIN
         DECLARE  l_last_location  int DEFAULT 0;  
         DECLARE l_last_ts         int DEFAULT 0;
         DECLARE l_next_position   int DEFAULT 0;
         DECLARE l_next_mr_id      int DEFAULT 0;
         DECLARE l_seed            int DEFAULT 0;
         DECLARE l_count_last_mr   int DEFAULT 0;
         DECLARE l_count_reducer   int DEFAULT 0;  
         
         SET AUTOCOMMIT=0;
         
		SELECT COUNT(mr_id) into l_count_reducer FROM MAP_REDUCERS
        WHERE  STATE = 'WORKING'
		AND RING_LOCATION IS NOT NULL;
        IF (l_count_reducer = 0) THEN
           SELECT NULL AS mr_id, NULL AS CONTACT_URL FROM DUAL;
            LEAVE my_label; 
        END IF;      
        LOCK TABLE LAST_ASSIGNED_MR WRITE; 
         SELECT COUNT(ASSIGNED_LOCATION) into l_count_last_mr FROM LAST_ASSIGNED_MR;
         IF(l_count_last_mr = 0) THEN
            SELECT mr_id, ring_location INTO l_next_mr_id, l_next_position
                   FROM MAP_REDUCERS 
                   WHERE STATE = 'WORKING'
                   AND RING_LOCATION IS NOT NULL ORDER BY ring_location LIMIT 1;                  
            INSERT INTO LAST_ASSIGNED_MR (assigned_location, assigned_ts) VALUES(l_next_position, get_epoch_time_num());
            COMMIT;
            -- at last, return the MR id and it's contact url           
              SELECT mr.mr_id, mr.CONTACT_URL FROM MAP_REDUCERS mr WHERE mr.mr_id = l_next_mr_id;            
             LEAVE my_label; 
         END IF;
           -- if last checkPoint is exist, then fetch the latest latest MR location
         SELECT assigned_location, assigned_ts INTO l_last_location, l_last_ts
         FROM LAST_ASSIGNED_MR  ORDER BY assigned_ts LIMIT 1;  
        
        -- fetch next MR location with specified latest MR location
        -- MR state must in working and RING_LOCATION is not null
        SELECT mr_id  AS mr_id,  ring_location AS location,         
          (-floor((ring_location - (l_last_location + 1)) / c_ring_size) * 360) + (ring_location - (l_last_location + 1)) AS seed
        INTO l_next_mr_id, l_next_position, l_seed         
        FROM MAP_REDUCERS
        WHERE STATE = 'WORKING'  AND RING_LOCATION IS NOT NULL ORDER BY SEED LIMIT 1;          
        -- save the last MR checkpoint
        UPDATE LAST_ASSIGNED_MR 
        SET assigned_location = l_next_position,
           assigned_ts = get_epoch_time_num()
        WHERE assigned_location = l_last_location
        AND assigned_ts = l_last_ts;
        -- let the other transaction find the last MR position
        COMMIT;     
           SELECT mr.mr_id, mr.CONTACT_URL FROM MAP_REDUCERS mr WHERE mr.mr_id = l_next_mr_id; 
      unlock table;
END