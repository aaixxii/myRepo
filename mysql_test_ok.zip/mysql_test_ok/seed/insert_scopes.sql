use AIMDB;
Insert into SCOPES (SCOPE_ID) values (1);
COMMIT;
