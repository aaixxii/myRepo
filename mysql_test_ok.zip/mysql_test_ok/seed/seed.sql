

source ./insert_format_types.sql

source ./insert_inquiry_traffic.sql

source ./insert_function_types.sql

source ./insert_scopes.sql

source ./insert_containers.sql

source ./insert_high_level_service_layouts.sql

source ./insert_system_init.sql

source ./insert_extract_complete_count.sql




