package jp.co.nec.aim.mm.scheduler;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.constants.SchedulerEnum;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.procedure.GarbageSegChangeLogProcedure;
import jp.co.nec.aim.mm.sessionbeans.GarbageSegChangeLogBean;
import jp.co.nec.aim.mm.sessionbeans.PollBean;
import mockit.Mock;
import mockit.MockUp;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ListCommon {

	private List<Long> executeTime_01;
	private List<Long> executeTime_02;
	private List<Long> executeTime_03;
	private List<Long> executeTime_04;
	private List<Long> executeTime_05;
	private List<Long> executeTime_06;
	private List<Long> executeTime_07;
	private List<Long> executeTime_08;
	private List<Long> executeTime_09;
	private Map<SchedulerEnum, Long> map;

	/**
	 * @return the executeTime_01
	 */
	public List<Long> getExecuteTime_01() {
		return executeTime_01;
	}

	/**
	 * @param executeTime_01
	 *            the executeTime_01 to set
	 */
	public void setExecuteTime_01(List<Long> executeTime_01) {
		this.executeTime_01 = executeTime_01;
	}

	/**
	 * @return the executeTime_02
	 */
	public List<Long> getExecuteTime_02() {
		return executeTime_02;
	}

	/**
	 * @param executeTime_02
	 *            the executeTime_02 to set
	 */
	public void setExecuteTime_02(List<Long> executeTime_02) {
		this.executeTime_02 = executeTime_02;
	}

	/**
	 * @return the executeTime_03
	 */
	public List<Long> getExecuteTime_03() {
		return executeTime_03;
	}

	/**
	 * @param executeTime_03
	 *            the executeTime_03 to set
	 */
	public void setExecuteTime_03(List<Long> executeTime_03) {
		this.executeTime_03 = executeTime_03;
	}

	/**
	 * @return the executeTime_04
	 */
	public List<Long> getExecuteTime_04() {
		return executeTime_04;
	}

	/**
	 * @param executeTime_04
	 *            the executeTime_04 to set
	 */
	public void setExecuteTime_04(List<Long> executeTime_04) {
		this.executeTime_04 = executeTime_04;
	}

	/**
	 * @return the executeTime_05
	 */
	public List<Long> getExecuteTime_05() {
		return executeTime_05;
	}

	/**
	 * @param executeTime_05
	 *            the executeTime_05 to set
	 */
	public void setExecuteTime_05(List<Long> executeTime_05) {
		this.executeTime_05 = executeTime_05;
	}

	/**
	 * @return the executeTime_06
	 */
	public List<Long> getExecuteTime_06() {
		return executeTime_06;
	}

	/**
	 * @param executeTime_06
	 *            the executeTime_06 to set
	 */
	public void setExecuteTime_06(List<Long> executeTime_06) {
		this.executeTime_06 = executeTime_06;
	}

	/**
	 * @return the executeTime_07
	 */
	public List<Long> getExecuteTime_07() {
		return executeTime_07;
	}

	/**
	 * @param executeTime_07
	 *            the executeTime_07 to set
	 */
	public void setExecuteTime_07(List<Long> executeTime_07) {
		this.executeTime_07 = executeTime_07;
	}

	/**
	 * @return the executeTime_08
	 */
	public List<Long> getExecuteTime_08() {
		return executeTime_08;
	}

	/**
	 * @param executeTime_08
	 *            the executeTime_08 to set
	 */
	public void setExecuteTime_08(List<Long> executeTime_08) {
		this.executeTime_08 = executeTime_08;
	}

	/**
	 * @return the executeTime_09
	 */
	public List<Long> getExecuteTime_09() {
		return executeTime_09;
	}

	/**
	 * @param executeTime_09
	 *            the executeTime_09 to set
	 */
	public void setExecuteTime_09(List<Long> executeTime_09) {
		this.executeTime_09 = executeTime_09;
	}

	public void init() {
		executeTime_01 = Lists.newArrayList();
		executeTime_02 = Lists.newArrayList();
		executeTime_03 = Lists.newArrayList();
		executeTime_04 = Lists.newArrayList();
		executeTime_05 = Lists.newArrayList();
		executeTime_06 = Lists.newArrayList();
		executeTime_07 = Lists.newArrayList();
		executeTime_08 = Lists.newArrayList();
		executeTime_09 = Lists.newArrayList();

		map = Maps.newHashMap();
		map.put(SchedulerEnum.AggregationSchedulable, Long.valueOf(1000));
		map.put(SchedulerEnum.DefragSchedulable, Long.valueOf(-1));
		map.put(SchedulerEnum.FePlannerSchedulable, Long.valueOf(1000));
		map.put(SchedulerEnum.GarbageSegmentChangeLogSchedulable,
				Long.valueOf(86400000));
		map.put(SchedulerEnum.IdentifyPlannerSchedulable, Long.valueOf(1000));
		map.put(SchedulerEnum.LoadBalanceSchedulable, Long.valueOf(60000));
		map.put(SchedulerEnum.MMHeartBeatSchedulable, Long.valueOf(1000));
		map.put(SchedulerEnum.PollSchedulable, Long.valueOf(1000));
		map.put(SchedulerEnum.PurgeJobQueueSchedulable, Long.valueOf(3600000));
	}

	public void clear() {
		executeTime_01.clear();
		executeTime_02.clear();
		executeTime_03.clear();
		executeTime_04.clear();
		executeTime_05.clear();
		executeTime_06.clear();
		executeTime_07.clear();
		executeTime_08.clear();
		executeTime_09.clear();
	}

	public void printf(String className, String methodName) {
		System.out.printf("**************************" + className + ":"
				+ methodName + "************************************\r\n");

		int pos_01 = executeTime_01.indexOf(null);
		int pos_02 = executeTime_02.indexOf(null);
		int pos_03 = executeTime_03.indexOf(null);
		int pos_04 = executeTime_04.indexOf(null);
		int pos_05 = executeTime_05.indexOf(null);
		int pos_06 = executeTime_06.indexOf(null);
		int pos_07 = executeTime_07.indexOf(null);
		int pos_08 = executeTime_08.indexOf(null);
		int pos_09 = executeTime_09.indexOf(null);

		printAllItem(SchedulerEnum.AggregationSchedulable, executeTime_01,
				pos_01);
		printAllItem(SchedulerEnum.DefragSchedulable, executeTime_02, pos_02);
		printAllItem(SchedulerEnum.FePlannerSchedulable, executeTime_03, pos_03);
		printAllItem(SchedulerEnum.GarbageSegmentChangeLogSchedulable,
				executeTime_04, pos_04);
		printAllItem(SchedulerEnum.IdentifyPlannerSchedulable, executeTime_05,
				pos_05);
		printAllItem(SchedulerEnum.LoadBalanceSchedulable, executeTime_06,
				pos_06);
		printAllItem(SchedulerEnum.MMHeartBeatSchedulable, executeTime_07,
				pos_07);
		printAllItem(SchedulerEnum.PollSchedulable, executeTime_08, pos_08);
		printAllItem(SchedulerEnum.PurgeJobQueueSchedulable, executeTime_09,
				pos_09);
	}

	private void printAllItem(SchedulerEnum schedulerenum,
			List<Long> executeTime, int pos) {
		long totalSize = executeTime.size();
		if (pos < 0 && totalSize > 0) {
			System.out.printf("%s size: %d org_IntervalInMillis: %d\r\n",
					schedulerenum.getClazz().getSimpleName(), totalSize,
					map.get(schedulerenum));
		} else {
			totalSize = schedulerenum
					.equals(SchedulerEnum.MMHeartBeatSchedulable) ? totalSize
					: totalSize - 1;
			System.out
					.printf("%s size: %d org_IntervalInMillis: %d, re_IntervalInMillis=%d\r\n",
							schedulerenum.getClazz().getSimpleName(),
							totalSize, map.get(schedulerenum),
							schedulerenum.getIntervalInMillis());
		}

		System.out.printf("index:IntervalInMillis\r\n");
		for (int index = executeTime.size() - 1; index >= 1; index--) {
			int preIndex = index - 1;

			if (pos >= 0) {
				if (index == pos) {
					continue;
				} else if (preIndex == pos) {
					preIndex -= 1;
				}

				if (index == pos + 1) {
					System.out.printf("reScheduler Mark\r\n");
					if (pos == 0) {
						continue;
					}
				}
			}

			Long diffTime = executeTime.get(index) - executeTime.get(preIndex);
			System.out.printf("%5d:%16d\r\n", index, diffTime);
		}
	}

	public void setMockMethods() {
		new MockUp<AggregationSchedulable>() {
			@Mock
			public void executeJob(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_01.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<DefragSchedulable>() {
			@Mock
			public void executeJob(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_02.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<FePlannerSchedulable>() {
			@Mock
			public void executeJob(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_03.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<GarbageSegmentChangeLogSchedulable>() {
			@Mock
			public void executeJob(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_04.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<IdentifyPlannerSchedulable>() {
			@Mock
			public void executeJob(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_05.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<LoadBalanceSchedulable>() {
			@Mock
			public void executeJob(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_06.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<MMHeartBeatSchedulable>() {
			@Mock
			public void execute(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_07.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<PollSchedulable>() {
			@Mock
			public void executeJob(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_08.add(System.currentTimeMillis());
				return;
			}
		};
		new MockUp<PurgeJobQueueSchedulable>() {
			@Mock
			public void executeJob(JobExecutionContext context)
					throws JobExecutionException {
				executeTime_09.add(System.currentTimeMillis());
				return;
			}
		};
	}

	public void setMockMethods01() {
		new MockUp<PollBean>() {
			@Mock
			public void aggregateJob() {
				executeTime_01.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void defrag() {
				executeTime_02.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void notifyFEJobPlanner() {
				executeTime_03.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<GarbageSegChangeLogProcedure>() {
			@Mock
			public long execute() {
				executeTime_04.add(System.currentTimeMillis());
				return 1;
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void notifyInqueryJobPlanner() {
				executeTime_05.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void loadBalance() {
				executeTime_06.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void updateHeartBeatTS() {
				executeTime_07.add(System.currentTimeMillis());
				return;
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void poll() {
				executeTime_08.add(System.currentTimeMillis());
				return;
			}
		};
		new MockUp<PollBean>() {
			@Mock
			public void purgeJobQueueByResultTs() {
				executeTime_09.add(System.currentTimeMillis());
				return;
			}
		};
	}

	public void setMockMethods02() {
		new MockUp<PollBean>() {
			@Mock
			public void aggregateJob() {
				executeTime_01.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void defrag() {
				executeTime_02.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void notifyFEJobPlanner() {
				executeTime_03.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};

		new MockUp<GarbageSegChangeLogBean>() {
			@Mock
			public void execute() {
				executeTime_04.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void notifyInqueryJobPlanner() {
				executeTime_05.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void loadBalance() {
				executeTime_06.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void updateHeartBeatTS() {
				executeTime_07.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};

		new MockUp<PollBean>() {
			@Mock
			public void poll() {
				executeTime_08.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};
		new MockUp<PollBean>() {
			@Mock
			public void purgeJobQueueByResultTs() {
				executeTime_09.add(System.currentTimeMillis());
				throw new RuntimeException();
			}
		};
	}

	public void initSysConf(JdbcTemplateHelper helper,
			JdbcTemplate jdbcTemplate, EntityManager entityManager,
			SystemConfigDao sysConfigDao, DataSource ds) {
		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteSystemConfig(jdbcTemplate);
		sysConfigDao.writeAllMissingProperties(ds);
		updateUpdateSystemConfig(helper, entityManager);
		SchedulerEnum.AggregationSchedulable.setCurrentTime(0);
		SchedulerEnum.DefragSchedulable.setCurrentTime(0);
		SchedulerEnum.FePlannerSchedulable.setCurrentTime(0);
		SchedulerEnum.IdentifyPlannerSchedulable.setCurrentTime(0);
		SchedulerEnum.GarbageSegmentChangeLogSchedulable.setCurrentTime(0);
		SchedulerEnum.LoadBalanceSchedulable.setCurrentTime(0);
		SchedulerEnum.MMHeartBeatSchedulable.setCurrentTime(0);
		SchedulerEnum.PollSchedulable.setCurrentTime(0);
		SchedulerEnum.PurgeJobQueueSchedulable.setCurrentTime(0);
		SchedulerEnum.AggregationSchedulable.setDelayMillis(0);
		SchedulerEnum.DefragSchedulable.setDelayMillis(0);
		SchedulerEnum.FePlannerSchedulable.setDelayMillis(0);
		SchedulerEnum.IdentifyPlannerSchedulable.setDelayMillis(0);
		SchedulerEnum.GarbageSegmentChangeLogSchedulable.setDelayMillis(0);
		SchedulerEnum.LoadBalanceSchedulable.setDelayMillis(0);
		SchedulerEnum.MMHeartBeatSchedulable.setDelayMillis(0);
		SchedulerEnum.PollSchedulable.setDelayMillis(0);
		SchedulerEnum.PurgeJobQueueSchedulable.setDelayMillis(0);
	}

	private void updateUpdateSystemConfig(JdbcTemplateHelper helper,
			EntityManager entityManager) {

		helper.UpdateSystemConfig(entityManager,
				SchedulerEnum.AggregationSchedulable.getIntervalProperty()
						.getName(), String.valueOf(1000));

		SchedulerEnum.AggregationSchedulable.setIntervalInMillis(1000);

		SchedulerEnum.DefragSchedulable.setIntervalInMillis(-1);

		helper.UpdateSystemConfig(entityManager,
				SchedulerEnum.FePlannerSchedulable.getIntervalProperty()
						.getName(), String.valueOf(1000));

		SchedulerEnum.FePlannerSchedulable.setIntervalInMillis(1000);

		helper.UpdateSystemConfig(entityManager,
				SchedulerEnum.IdentifyPlannerSchedulable.getIntervalProperty()
						.getName(), String.valueOf(1000));

		SchedulerEnum.IdentifyPlannerSchedulable.setIntervalInMillis(1000);
		SchedulerEnum.GarbageSegmentChangeLogSchedulable
				.setIntervalInMillis(86400000);

		SchedulerEnum.LoadBalanceSchedulable.setIntervalInMillis(60000);

		SchedulerEnum.MMHeartBeatSchedulable.setIntervalInMillis(1000);

		helper.UpdateSystemConfig(entityManager, SchedulerEnum.PollSchedulable
				.getIntervalProperty().getName(), String.valueOf(1000));

		SchedulerEnum.PollSchedulable.setIntervalInMillis(1000);
		SchedulerEnum.PurgeJobQueueSchedulable.setIntervalInMillis(3600000);

		entityManager.flush();
	}

	public void rescheduler() {
		executeTime_01.add(null);
		executeTime_02.add(null);
		executeTime_03.add(null);
		executeTime_04.add(null);
		executeTime_05.add(null);
		executeTime_06.add(null);
		executeTime_08.add(null);
		executeTime_09.add(null);
	}
}
