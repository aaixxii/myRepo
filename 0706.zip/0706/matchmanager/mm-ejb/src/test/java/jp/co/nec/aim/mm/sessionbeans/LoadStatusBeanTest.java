package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.fail;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBLoadState;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.exception.ArgumentException;

import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class LoadStatusBeanTest {
	@Resource
	private LoadStatusBean loadStatusBean;

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private static PrintStream bk_out = System.out;
	private static PrintStream bk_err = System.err;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);
		jdbcTemplate.update("delete from MU_INQUIRY_LOAD");
		jdbcTemplate.update("delete from MATCH_UNITS");
		jdbcTemplate.update("commit");
		System.setOut(new PrintStream(outContent));
		System.setErr(new PrintStream(errContent));

	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from MU_INQUIRY_LOAD");
		jdbcTemplate.update("delete from MATCH_UNITS");
		jdbcTemplate.update("commit");		
		System.setOut(bk_out);
		System.setErr(bk_err);

	}

	@Test
	public void test_updateMuLoad_WrongComponentType() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'1','WORKING')");
		jdbcTemplate
				.update("insert into MU_INQUIRY_LOAD(MU_ID,PRESSURE,REPORT_TS)values(1,1,1111)");
		PBLoadState request = PBLoadState.newBuilder()
				.setComponent(ComponentType.MAP_REDUCER).setId(1)
				.setMatchingLoad(5).build();
		try {
			loadStatusBean.updateMuLoad(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.COMPONENT_TYPE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"PBComponentInfo.ComponentType(MAP_REDUCER) is not support..",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void test_updateMuLoad() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE)values(1,'1','WORKING')");
		jdbcTemplate
				.update("insert into MU_INQUIRY_LOAD(MU_ID,PRESSURE,REPORT_TS)values(1,1,1111)");
		jdbcTemplate.update("commit");
		PBLoadState request = PBLoadState.newBuilder()
				.setComponent(ComponentType.MATCH_UNIT).setId(1)
				.setMatchingLoad(5).build();
		loadStatusBean.updateMuLoad(request);
		jdbcTemplate.update("commit");
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_INQUIRY_LOAD");
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(1, Integer.parseInt(map.get("MU_ID").toString()));
		Assert.assertEquals(5, Integer.parseInt(map.get("PRESSURE").toString()));
	}

	@Test
	public void test_updateMuLoad_NoDataInDB() {
		PBLoadState request = PBLoadState.newBuilder()
				.setComponent(ComponentType.MATCH_UNIT).setId(1)
				.setMatchingLoad(5).build();
		loadStatusBean.updateMuLoad(request);
		
		Assert.assertTrue(contains("Could not find MU with id: 1 when update MuLoad."));
	}

	private boolean contains(String msg) {		
		return StringUtils.contains(outContent.toString(), msg);
	}

}
