/**this is file UiaiResposeCreater.java
 * @author xia
   @date 2020/06/07
 */
package jp.co.nec.aim.mm.util;

import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.uid.jaxb.Candidate;
import jp.co.nec.aim.uid.jaxb.CandidateList;
import jp.co.nec.aim.uid.jaxb.Diagnostics;
import jp.co.nec.aim.uid.jaxb.Response;
import jp.co.nec.aim.uid.jaxb.Return;

/**
 * @author xia
 *
 */
public class UiaiResposeCreater {
	
	public static Response createRespose(String requestId, boolean isFaild, UidRequestType type) {
	    Response uidRes = new Response();
	    uidRes.setRequestId(requestId);
	    uidRes.setTimeStamp(System.currentTimeMillis());
	    Return rt = new Return();
    	if (!isFaild) {
    		rt.setValue(1);	    		
    	} else {
    		rt.setValue(0);
    	}
    	uidRes.setReturn(rt);
	    switch(type.name()) {
	    case "Quality":	
	    case "Insert":	
	    	Diagnostics dg = new Diagnostics();
	    	uidRes.setDiagnostics(dg);	    
	    break;	    	
	    case "Identify":
	    	Candidate cd = new Candidate();
	    	CandidateList caList = new CandidateList();
	    	caList.getCandidate().add(cd);
	    	uidRes.setCandidateList(caList);
	    	uidRes.setCandidateList(caList);
	    	 break;	
	    case "Delete":
	    	 break;
		default:
			break;			
	    }
		return uidRes;
	}
}
