//package jp.co.nec.aim.mm.extract.dispatch;
//
//import java.util.concurrent.ExecutionException;
//
//import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
//import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
//import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResponse;
//import mockit.Mock;
//import mockit.MockUp;
//
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//
//import com.google.protobuf.ByteString;
//
//public class ExtractJobResultCallBackerTest {
//	private ExtractJobResultCallBacker callbacker;
//	private int muPostRetryCount = 3;
//
//	@Before
//	public void setUp() throws Exception {
//		callbacker = new ExtractJobResultCallBacker();
//	}
//
//	@After
//	public void tearDown() throws Exception {
//		callbacker = null;
//	}
//
//	@Test
//	public void testSendExtractJobResult() throws InterruptedException, ExecutionException {
//		new MockUp<ExtractRequestPoster>() {
//			@Mock
//			public boolean postRequest(String url, int trycount, byte[] response) {
//				return true;
//			}
//		};
//		String url = "http://localhost:7878";
//		ComponentProcessStautsInfo failedInfo = new ComponentProcessStautsInfo();
//		failedInfo.setFailureReason("some error reason");
//		failedInfo.setMsgCode("8888");
//		failedInfo.setMsgType(MessageType.ERROR);
//		failedInfo.setProcessType(ProcessType.EXTRACT);
//		failedInfo.setReasonTime(String.valueOf(System.currentTimeMillis()));
//		long feJobId = 1000l;
//		PBExtractJobResponse.Builder feResponse = PBExtractJobResponse.newBuilder();
//		feResponse.setJobId(feJobId);
//		PBServiceState.Builder errorState = PBServiceState.newBuilder();
//		PBServiceStateReason.Builder reason = PBServiceStateReason.newBuilder();
//		String errorMsg = failedInfo.getFailureReason();
//		reason.setCode(failedInfo.getMsgCode());
//		reason.setDescriptionBytes(ByteString.copyFrom(errorMsg.getBytes()));
//		reason.setTime(failedInfo.getReasonTime());
//		errorState.setState(ServiceStateType.SERVICE_STATE_ERROR);
//		errorState.setReason(reason);
//		feResponse.setServiceState(errorState);
//		byte[] responseData = feResponse.build().toByteArray();
//		boolean result = callbacker.asynchCallback(url, muPostRetryCount, responseData).get();
//		Assert.assertTrue(result);
//	}
//
//	@Test
//	public void testAsynchStringCallback() throws InterruptedException, ExecutionException {
//		new MockUp<ExtractRequestPoster>() {
//			@Mock
//			public boolean postRequest(String Url, int muPostRetryCount, String message) {
//				return true;
//			}
//		};
//		String msg = "ABCDEFJHIJKLMNOPQRSTUVWXYZ";
//		String url = "http://localhost:7878";
//		boolean result = callbacker.asynchCallback(url, muPostRetryCount, msg).get();
//		Assert.assertTrue(result);
//	}
//
//	@Test
//	public void testSendExtractJobResult_post_failded() throws InterruptedException, ExecutionException {
//		new MockUp<ExtractRequestPoster>() {
//			@Mock
//			public boolean postRequest(String url, int muPostRetyCount, byte[] results) {
//				return false;
//			}
//		};
//		String url = "http://localhost:7878";
//		ComponentProcessStautsInfo failedInfo = new ComponentProcessStautsInfo();
//		failedInfo.setFailureReason("some error reason");
//		failedInfo.setMsgCode("8888");
//		failedInfo.setMsgType(MessageType.ERROR);
//		failedInfo.setProcessType(ProcessType.EXTRACT);
//		failedInfo.setReasonTime(String.valueOf(System.currentTimeMillis()));
//		long feJobId = 1000l;
//		PBExtractJobResponse.Builder feResponse = PBExtractJobResponse.newBuilder();
//		feResponse.setJobId(feJobId);
//		PBServiceState.Builder errorState = PBServiceState.newBuilder();
//		PBServiceStateReason.Builder reason = PBServiceStateReason.newBuilder();
//		String errorMsg = failedInfo.getFailureReason();
//		reason.setCode(failedInfo.getMsgCode());
//		reason.setDescriptionBytes(ByteString.copyFrom(errorMsg.getBytes()));
//		reason.setTime(failedInfo.getReasonTime());
//		errorState.setState(ServiceStateType.SERVICE_STATE_ERROR);
//		errorState.setReason(reason);
//		feResponse.setServiceState(errorState);
//		byte[] responseData = feResponse.build().toByteArray();
//		boolean result = callbacker.asynchCallback(url, muPostRetryCount, responseData).get();
//		Assert.assertTrue(!result);
//	}
//
//	@Test
//	public void testAsynchStringCallback_post_failed() throws InterruptedException, ExecutionException {
//		new MockUp<ExtractRequestPoster>() {
//			@Mock
//			public boolean postRequest(String Url, int muPostRetryCount, String message) {
//				return false;
//			}
//		};
//		String msg = "ABCDEFJHIJKLMNOPQRSTUVWXYZ";
//		String url = "http://localhost:7878";
//		boolean result = callbacker.asynchCallback(url, muPostRetryCount, msg).get();
//		Assert.assertTrue(!result);
//
//	}
//
//}
