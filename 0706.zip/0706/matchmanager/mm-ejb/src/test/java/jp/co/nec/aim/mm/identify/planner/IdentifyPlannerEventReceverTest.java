package jp.co.nec.aim.mm.identify.planner;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.receiver.IdentifyPlannerEventRecever;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class IdentifyPlannerEventReceverTest {
	private BrokerService broker = null;
	private String jmsURL = "tcp://localhost:61796";
	private String plannerQueue = JNDIConstants.INQUIRY_JOB_PLANNER_QUEUE;
	private String mesgToIdentifyPlanner = "Please create excuting plan for mus";
	@Resource
	private IdentifyPlannerEventRecever receiver;

	@Before
	public void setUp() throws Exception {
		broker = new BrokerService();
		broker.setBrokerName("AIM_JMS_SERVER");
		broker.addConnector(jmsURL);
		broker.setPersistent(false);
		broker.start();
		send(mesgToIdentifyPlanner);
	}

	public void send(String msg) throws JMSException {
		ConnectionFactory factory = new ActiveMQConnectionFactory(jmsURL);
		Connection connection = factory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		Destination queue = session.createQueue(plannerQueue);
		MessageProducer producer = session.createProducer(queue);
		TextMessage message = session.createTextMessage(msg);
		producer.send(message);
		connection.close();
	}

	@After
	public void tearDown() throws Exception {
		broker.stop();
	}

	@Test
	public void testOnMessage() throws JMSException {
		ConnectionFactory factory = new ActiveMQConnectionFactory(jmsURL);
		Connection connection = factory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		Destination queue = session.createQueue(plannerQueue);
		MessageConsumer consumer = session.createConsumer(queue);
		consumer.setMessageListener(receiver);
		Message rcvMessage = consumer.receive();
		TextMessage txtMsg = (TextMessage) rcvMessage;
		Assert.assertEquals(mesgToIdentifyPlanner, txtMsg.getText());
	}

}
