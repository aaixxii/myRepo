package jp.co.nec.aim.mm.loadbalancer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.mm.common.TestLogger;
import jp.co.nec.aim.mm.entities.UnitSegMap;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadBalancerUtilTest {
	private LoadBalancerUtil util;

	@Before
	public void setUp() {
		TestLogger.isDebugEnabled = false;
		TestLogger.level = "";
		TestLogger.message = "";
		new MockUp<LoggerFactory>() {
			@Mock
			public Logger getLogger(String name) {
				return new TestLogger();
			}
		};

		util = new LoadBalancerUtil();
	}

	@After
	public void tearDown() {		
	}

	@Test
	public void test_createMatrix() {
		int unitIds[] = new int[] { 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 4, 5, 10, 1, 5, 6, 1, 2, 7, 8, 2, 3, 8, 9,
				3, 4, 9, 6, 7, 10 };
		List<UnitSegMap> unitSegMaps = new ArrayList<UnitSegMap>();
		for (int i = 0; i < 20; i++) {
			UnitSegMap unitSegMap = new UnitSegMap();
			unitSegMap.setUnitId(unitIds[i]);
			unitSegMap.setSegmentId(segIds[i]);

			unitSegMaps.add(unitSegMap);
		}

		List<Long> unitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			unitsList.add(new Long(i + 1));
		}
		List<Long> segIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			segIdsList.add(new Long(i + 1));
		}

		boolean[][] matrix = util.createMatrix(unitSegMaps, segIdsList,
				unitsList);

		boolean[][] resultMatrix = new boolean[][] {//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};

		for (int unitIndex = 0; unitIndex < matrix.length; unitIndex++) {
			for (int segIndex = 0; segIndex < matrix[0].length; segIndex++) {
				assertEquals(resultMatrix[unitIndex][segIndex],
						matrix[unitIndex][segIndex]);
			}
		}
	}

	@Test
	public void test_createMatrix_2() {
		int unitIds[] = new int[] { 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 4, 5, 10, 1, 5, 6, 1, 2, 7, 8, 2, 3, 8, 9,
				3, 4, 9, 6, 7, 10 };
		List<UnitSegMap> unitSegMaps = new ArrayList<UnitSegMap>();
		for (int i = 0; i < 20; i++) {
			UnitSegMap unitSegMap = new UnitSegMap();
			unitSegMap.setUnitId(unitIds[i]);
			unitSegMap.setSegmentId(segIds[i]);

			unitSegMaps.add(unitSegMap);
		}

		List<Long> unitsList = new ArrayList<Long>();
		List<Long> segIdsList = new ArrayList<Long>();

		boolean[][] matrix = util.createMatrix(unitSegMaps, segIdsList,
				unitsList);

		for (int unitIndex = 0; unitIndex < matrix.length; unitIndex++) {
			for (int segIndex = 0; segIndex < matrix[0].length; segIndex++) {
				assertEquals(false, matrix[unitIndex][segIndex]);
			}
		}
	}

	@Test
	public void test_createUnitSegMaps() {

		List<Long> unitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			unitsList.add(new Long(i + 1));
		}
		List<Long> segIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			segIdsList.add(new Long(i + 1));
		}

		boolean[][] matrix = new boolean[][] {//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};

		List<UnitSegMap> unitSegMaps = util.createUnitSegMaps(matrix,
				segIdsList, unitsList);
		assertEquals(20, unitSegMaps.size());

		int unitIds[] = new int[] { 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4,
				5, 5, 5, 6, 6, 6 };
		int segIds[] = new int[] { 4, 5, 10, 1, 5, 6, 1, 2, 7, 8, 2, 3, 8, 9,
				3, 4, 9, 6, 7, 10 };
		for (int i = 0; i < unitSegMaps.size(); i++) {
			assertEquals(unitIds[i], unitSegMaps.get(i).getUnitId());
			assertEquals(segIds[i], unitSegMaps.get(i).getSegmentId());
		}
	}

	@Test
	public void test_exportSLBLog() {
		List<Long> unitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			unitsList.add(new Long(i + 1));
		}
		List<Long> segIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			segIdsList.add(new Long(i + 1));
		}
		boolean[][] matrix = new boolean[][] {//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		List<UnitSegMap> unitSegMaps = util.createUnitSegMaps(matrix,
				segIdsList, unitsList);

		List<Long> newUnitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			newUnitsList.add(new Long(i + 2));
		}
		List<Long> newSegIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			newSegIdsList.add(new Long(i + 2));
		}
		boolean[][] newMatrix = new boolean[][] {//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		List<UnitSegMap> newUnitSegMaps = util.createUnitSegMaps(newMatrix,
				newSegIdsList, newUnitsList);

		util.exportSLBLog(unitSegMaps, newUnitSegMaps);

		assertEquals("info", TestLogger.level);
		assertEquals("Added MU_IDs = 7Removed MU_IDs = 1"
				+ "Added SEGMETN_IDs = 11Removed SEGMETN_IDs = 1"
				+ "Removed {SEMENT_ID, MU_ID} = {1, 1}, {1, 5}"
				+ "Removed {SEMENT_ID, MU_ID} = {2, 1}, {2, 2}"
				+ "Added {SEMENT_ID, MU_ID} = {2, 3}, {2, 4}"
				+ "Removed {SEMENT_ID, MU_ID} = {3, 2}, {3, 3}"
				+ "Added {SEMENT_ID, MU_ID} = {3, 4}, {3, 5}"
				+ "Removed {SEMENT_ID, MU_ID} = {4, 3}, {4, 4}"
				+ "Added {SEMENT_ID, MU_ID} = {4, 5}, {4, 6}"
				+ "Removed {SEMENT_ID, MU_ID} = {5, 4}, {5, 5}"
				+ "Added {SEMENT_ID, MU_ID} = {5, 2}, {5, 6}"
				+ "Removed {SEMENT_ID, MU_ID} = {6, 5}, {6, 6}"
				+ "Added {SEMENT_ID, MU_ID} = {6, 2}, {6, 3}"
				+ "Removed {SEMENT_ID, MU_ID} = {7, 1}, {7, 6}"
				+ "Added {SEMENT_ID, MU_ID} = {7, 3}, {7, 7}"
				+ "Removed {SEMENT_ID, MU_ID} = {8, 1}, {8, 2}"
				+ "Added {SEMENT_ID, MU_ID} = {8, 4}, {8, 7}"
				+ "Removed {SEMENT_ID, MU_ID} = {9, 2}, {9, 3}"
				+ "Added {SEMENT_ID, MU_ID} = {9, 4}, {9, 5}"
				+ "Removed {SEMENT_ID, MU_ID} = {10, 4}"
				+ "Added {SEMENT_ID, MU_ID} = {10, 5}"
				+ "Added {SEMENT_ID, MU_ID} = {11, 2}, {11, 7}",
				TestLogger.message);
	}

	@Test
	public void test_exportSLBLog_First() {
		TestLogger.isDebugEnabled = true;

		List<UnitSegMap> unitSegMaps = new ArrayList<UnitSegMap>();

		List<Long> newUnitsList = new ArrayList<Long>();
		for (int i = 0; i < 6; i++) {
			newUnitsList.add(new Long(i + 2));
		}
		List<Long> newSegIdsList = new ArrayList<Long>();
		for (int i = 0; i < 10; i++) {
			newSegIdsList.add(new Long(i + 2));
		}
		boolean[][] newMatrix = new boolean[][] {//
				{ false, false, false, true, true, false, false, false, false,
						true },//
				{ true, false, false, false, true, true, false, false, false,
						false },//
				{ true, true, false, false, false, false, true, true, false,
						false },//
				{ false, true, true, false, false, false, false, true, true,
						false },//
				{ false, false, true, true, false, false, false, false, true,
						false },//
				{ false, false, false, false, false, true, true, false, false,
						true } //
		};
		List<UnitSegMap> newUnitSegMaps = util.createUnitSegMaps(newMatrix,
				newSegIdsList, newUnitsList);

		util.exportSLBLog(unitSegMaps, newUnitSegMaps);

		assertEquals("debug", TestLogger.level);
		assertEquals("Added MU_IDs = 2, 3, 4, 5, 6, 7"
				+ "Added SEGMETN_IDs = 5, 6, 11, 2, 7, 3, 8, 9, 4, 10"
				+ "Added {SEMENT_ID, MU_ID} = {2, 3}, {2, 4}"
				+ "Added {SEMENT_ID, MU_ID} = {3, 4}, {3, 5}"
				+ "Added {SEMENT_ID, MU_ID} = {4, 5}, {4, 6}"
				+ "Added {SEMENT_ID, MU_ID} = {5, 2}, {5, 6}"
				+ "Added {SEMENT_ID, MU_ID} = {6, 2}, {6, 3}"
				+ "Added {SEMENT_ID, MU_ID} = {7, 3}, {7, 7}"
				+ "Added {SEMENT_ID, MU_ID} = {8, 4}, {8, 7}"
				+ "Added {SEMENT_ID, MU_ID} = {9, 4}, {9, 5}"
				+ "Added {SEMENT_ID, MU_ID} = {10, 5}, {10, 6}"
				+ "Added {SEMENT_ID, MU_ID} = {11, 2}, {11, 7}",
				TestLogger.message);
	}

	@Test
	public void test_createMatrix_unitSegMaps() {
		try {
			util.createMatrix(null, new ArrayList<Long>(),
					new ArrayList<Long>());
		} catch (IllegalArgumentException e) {
			assertEquals("unitSegMaps == null", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_createMatrix_segIds() {
		try {
			util.createMatrix(new ArrayList<UnitSegMap>(), null,
					new ArrayList<Long>());
		} catch (IllegalArgumentException e) {
			assertEquals("segIds == null", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_createMatrix_unitIdList() {
		try {
			util.createMatrix(new ArrayList<UnitSegMap>(),
					new ArrayList<Long>(), null);
		} catch (IllegalArgumentException e) {
			assertEquals("unitIdList == null", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_createUnitSegMaps_matrix() {
		try {
			util.createUnitSegMaps(null, new ArrayList<Long>(),
					new ArrayList<Long>());
		} catch (IllegalArgumentException e) {
			assertEquals("matrix == null", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_createUnitSegMaps_segIds() {
		try {
			util.createUnitSegMaps(new boolean[1][1], null,
					new ArrayList<Long>());
		} catch (IllegalArgumentException e) {
			assertEquals("segIds == null", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_createUnitSegMaps_unitIds() {
		try {
			util.createUnitSegMaps(new boolean[1][1], new ArrayList<Long>(),
					null);
		} catch (IllegalArgumentException e) {
			assertEquals("unitIds == null", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_createUnitSegMaps_unitIds_size() {
		try {
			util.createUnitSegMaps(new boolean[1][1], new ArrayList<Long>(),
					new ArrayList<Long>());
		} catch (IllegalArgumentException e) {
			assertEquals("matrix.length != units.size()", e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void test_createUnitSegMaps_matrix_length() {
		TestLogger.level = "";
		TestLogger.message = "";

		util.createUnitSegMaps(new boolean[0][0], new ArrayList<Long>(),
				new ArrayList<Long>());

		assertEquals("info", TestLogger.level);
		assertEquals("matrix.length == 0", TestLogger.message);
	}

	@Test
	public void test_createUnitSegMaps_segIds_size() {
		TestLogger.level = "";
		TestLogger.message = "";

		List<Long> unitIds = new ArrayList<Long>();
		unitIds.add(1l);

		util.createUnitSegMaps(new boolean[1][1], new ArrayList<Long>(),
				unitIds);

		assertEquals("info", TestLogger.level);
		assertEquals("segIds.size() == 0", TestLogger.message);
	}
}
