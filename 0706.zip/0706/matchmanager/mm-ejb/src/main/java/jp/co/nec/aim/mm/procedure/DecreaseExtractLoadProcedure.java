package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

public class DecreaseExtractLoadProcedure extends StoredProcedure {
	/** SQL **/
	private static final String SQL = "decrease_extract_load";

	private Long muId; // MU id
	private Integer lotJobCount; // MU related Lot job count

	/**
	 * DecreaseExtractLoadProcedure
	 * 
	 * @param dataSource
	 */
	public DecreaseExtractLoadProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_mu_id", Types.INTEGER));
		declareParameter(new SqlParameter("p_lot_count", Types.INTEGER));
		declareParameter(new SqlOutParameter("o_pressure", Types.INTEGER));
		compile();
	}

	/**
	 * execute DecreaseExtractLoadProcedure
	 */
	public Integer execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_id", getMuId());
		map.put("p_lot_count", getLotJobCount());
		Map<String, Object> resultMap = execute(map);
		int count = ((Integer) resultMap.get("o_pressure")).intValue();
		return count;
	}

	public Long getMuId() {
		return muId;
	}

	public void setMuId(Long muId) {
		this.muId = muId;
	}

	public Integer getLotJobCount() {
		return lotJobCount;
	}

	public void setLotJobCount(Integer lotJobCount) {
		this.lotJobCount = lotJobCount;
	}

}
