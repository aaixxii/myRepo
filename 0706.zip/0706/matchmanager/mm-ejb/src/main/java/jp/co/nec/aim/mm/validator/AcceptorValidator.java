package jp.co.nec.aim.mm.validator;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.exception.UiDaiValidatorException;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;
import jp.co.nec.aim.mm.util.XmlUtil;


/**
 * Validate the Accept protoBuffer Object from client
 * 
 * @author liuyq
 */
public final class AcceptorValidator { 
    
    public static void checkInquiryRequest (String request, String requestId , String cmd, String refId , String refUrl, String maxResults)  {    	
		if (StringUtils.isBlank(requestId)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() + " requestId is empty.");
			aimError.setMessage(errMsg);
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
			
		}
		if (requestId.length() != 36) {
			AimError aimError = AimError.INQ_REQUESET_REQUEST_ID_SIZE_MISS;
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}		
		if (StringUtils.isBlank(cmd)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() + " payload is empty in indentify request.");
			aimError.setMessage(errMsg);
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());

		}
		if (!cmd.equals("Identify")) {
			AimError aimError = AimError.INQ_E_REQUESET_TYPE_MISS;
			String errMsg = String.format(aimError.getMessage() + " it must be 'Identify'in  indentify request.");
			aimError.setMessage(errMsg);
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}
		
		if (StringUtils.isBlank(refId) && StringUtils.isBlank(refId)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() +  " request must have  one of refId  or one of refurl");
			aimError.setMessage(errMsg);
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}		
		
		if (!StringUtils.isBlank(refId) && refId.length() != 36) {
			AimError aimError = AimError.INQ_REQUESET_ENROLLMENTID_SIZE_MISS;
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}
		
		if (StringUtils.isBlank(maxResults) || Integer.valueOf(maxResults) < 1) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() + " invaid maxResults.");
			aimError.setMessage(errMsg);
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}	
    } 
    
    public static void checkExtractRequest (String request, String requestId , String cmd, String refId , String refUrl) {
    		
		if (StringUtils.isBlank(requestId)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errStr = String.format(aimError.getMessage() +  " requestId is empty.");
			aimError.setMessage(errStr);
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
			
		}
		if (requestId.length() != 36) {
			AimError aimError = AimError.EXTRACT_REQUESET_REQUEST_ID_SIZE_MISS;			
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}		
		if (StringUtils.isBlank(cmd)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() +  " payload is empty in extract request.");
			aimError.setMessage(errMsg);			
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());

		}
		if (!cmd.equals("Quality")) {
			AimError aimError = AimError.ENROLL_BATCH_TYPE_MISS_MATCH;				
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}
		
		if (StringUtils.isBlank(refUrl) && StringUtils.isBlank(refId)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() +  " request must have  refId  or refurl");
			aimError.setMessage(errMsg);			
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}		
		
		if (!StringUtils.isBlank(refId) && refId.length() != 36) {
			AimError aimError = AimError.EXTRACT_REQUESET_ENROLLMENTID_SIZE_MISS;			
			throw new UiDaiValidatorException(aimError.getErrorCode(), aimError.getMessage(), String.valueOf(System.currentTimeMillis()), aimError.getUidCode());
		}
    } 
    
    public static UidAimAmqResponse checkSyncDeleteRequest (String request, String requestId , String cmd,  String refId) throws IOException  {
    	UidAimAmqResponse uidAmqRes = null;	
		if (StringUtils.isBlank(requestId)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() +  " requestId is empty.");
			uidAmqRes = new UidAimAmqResponse();
			uidAmqRes.setXmlResult(errMsg);
			return uidAmqRes;
		}
		if (requestId.length() != 36) {
			AimError aimError = AimError.ENROLL_REQUESET_REQUEST_ID_SIZE_MISS;
			uidAmqRes = new UidAimAmqResponse();
			String xml = XmlUtil.dom4jCreateResponseXml(requestId, "2", aimError.getUidCode());
			uidAmqRes.setXmlResult(xml);
			return uidAmqRes;
		}
		
		if (StringUtils.isBlank(cmd)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() +  " payload is empty in sync request.");
			aimError.setMessage(errMsg);
			uidAmqRes = new UidAimAmqResponse();
			String xml = XmlUtil.dom4jCreateResponseXml(requestId, "2", aimError.getUidCode());
			uidAmqRes.setXmlResult(xml);
			return uidAmqRes;

		}
		if (!cmd.equals("Delete")) {
			AimError aimError = AimError.ENROLL_E_REQUESET_TYPE_MISS;			
			uidAmqRes = new UidAimAmqResponse();
			String xml = XmlUtil.dom4jCreateResponseXml(requestId, "2", aimError.getUidCode());
			uidAmqRes.setXmlResult(xml);
			return uidAmqRes;
		}
		return uidAmqRes;
    }
    
    public static UidAimAmqResponse checkSyncInsertRequest(String request, String requestId , String cmd, String refId , String refUrl) throws IOException {
    	UidAimAmqResponse uidAmqRes = null;	
		if (StringUtils.isBlank(requestId)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() + " requestId is empty.");
			uidAmqRes = new UidAimAmqResponse();
			uidAmqRes.setXmlResult(errMsg);
			return uidAmqRes;
		}
		if (requestId.length() != 36) {
			AimError aimError = AimError.ENROLL_REQUESET_REQUEST_ID_SIZE_MISS;
			uidAmqRes = new UidAimAmqResponse();
			String xml = XmlUtil.dom4jCreateResponseXml(requestId, "2", aimError.getUidCode());
			uidAmqRes.setXmlResult(xml);
			return uidAmqRes;

		}		
		if (StringUtils.isBlank(cmd)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() + " payload is empty in sync request.");
			aimError.setMessage(errMsg);
			uidAmqRes = new UidAimAmqResponse();
			String xml = XmlUtil.dom4jCreateResponseXml(requestId, "2", aimError.getUidCode());
			uidAmqRes.setXmlResult(xml);
			return uidAmqRes;

		}
		if (!cmd.equals("Insert")) {
			AimError aimError = AimError.ENROLL_E_REQUESET_TYPE_MISS;			
			uidAmqRes = new UidAimAmqResponse();
			String xml = XmlUtil.dom4jCreateResponseXml(requestId, "2", aimError.getUidCode());
			uidAmqRes.setXmlResult(xml);
			return uidAmqRes;
		}
		
		if (StringUtils.isBlank(refUrl) && StringUtils.isBlank(refId)) {
			AimError aimError = AimError.REQUST_ERROR;
			String errMsg = String.format(aimError.getMessage() +  " request must have  one of refId  or one of refurl");
			aimError.setMessage(errMsg);
			uidAmqRes = new UidAimAmqResponse();
			String xml = XmlUtil.dom4jCreateResponseXml(requestId, "2", aimError.getUidCode());
			uidAmqRes.setXmlResult(xml);
			return uidAmqRes;
		}		
		
		if (!StringUtils.isBlank(refId) && refId.length() != 36) {
			AimError aimError = AimError.ENROLL_REQUESET_ENROLLMENTID_SIZE_MISS;
			uidAmqRes = new UidAimAmqResponse();
			String xml = XmlUtil.dom4jCreateResponseXml(requestId, "2", aimError.getUidCode());
			uidAmqRes.setXmlResult(xml);
			return uidAmqRes;
		}		
		return uidAmqRes;    	
    } 
}
