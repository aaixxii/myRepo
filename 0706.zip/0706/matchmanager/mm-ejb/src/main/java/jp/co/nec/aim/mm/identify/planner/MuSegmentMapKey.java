package jp.co.nec.aim.mm.identify.planner;

public class MuSegmentMapKey {
	private Integer functionId;
	private Integer containerId;

	@Override
	public int hashCode() {
		return this.functionId.intValue() + this.containerId.intValue();
	}

	@Override
	public boolean equals(Object other) {
		if (other != null
				&& other instanceof MuSegmentMapKey
				&& this.functionId.intValue() == ((MuSegmentMapKey) other).functionId
						.intValue()
				&& this.containerId.intValue() == ((MuSegmentMapKey) other).containerId
						.intValue()) {
			return true;
		} else {
			return false;
		}
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public MuSegmentMapKey(Integer functionId, Integer containerId) {
		this.functionId = functionId;
		this.containerId = containerId;
	}

	public String toString() {
		return String.format("%d-%d", functionId, containerId);
	}
}
