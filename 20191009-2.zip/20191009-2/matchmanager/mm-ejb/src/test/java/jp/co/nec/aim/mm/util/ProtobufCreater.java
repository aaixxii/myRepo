package jp.co.nec.aim.mm.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;

public class ProtobufCreater {
	
	public ProtobufCreater() {
		
	}
	
	public PBMuExtractJobResult createPBMuExtractJobResult(long muId, long lotJobId, long feJobid) {
		PBBusinessMessage pbMsg = createPBBusinessMessage();
		PBMuExtractJobResultItem.Builder muItem = PBMuExtractJobResultItem.newBuilder();
		muItem.setJobId(feJobid);
		muItem.setResult(pbMsg.toByteString());
		PBMuExtractJobResult.Builder pBMuExtractJobResult = PBMuExtractJobResult.newBuilder();
		pBMuExtractJobResult.setMuId(muId);
		pBMuExtractJobResult.setLotJobId(lotJobId);
		pBMuExtractJobResult.addResult(0, muItem.build());
		return pBMuExtractJobResult.build();		
		
	}
	
	public PBBusinessMessage createPBBusinessMessage() {
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
		PBResponse.Builder ps = PBResponse.newBuilder();
		ps.setStatus("0:success");
		pbMsg.setResponse(ps);
		PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 10; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("xia" + i);
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}	
		
		Collections.shuffle(pbList); 		
		
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(false);
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		System.out.print(pbDeList.toString());
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		return pbMsg.build();
		
	}

}
