package jp.co.nec.aim.mm.procedure;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class DecreaseExtractLoadProcedureTest {
	@Resource
	private DataSource ds;
	private DecreaseExtractLoadProcedure procedure;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		procedure = new DecreaseExtractLoadProcedure(ds);
		clearDB();

	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}
	
	private void clearDB() {
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from MM_EVENTS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testExcute() {

		jdbcTemplate.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(1000,'1000','http://127.0.0.1:65521/1','WORKING')");	
		jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"+ " values(" + 1000 + ", " + 333 + ")");				
		jdbcTemplate.update("insert into mu_extract_load(mu_id,pressure,update_ts) values(1000,2,333)");
		jdbcTemplate.update("INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(1,1000,333,0)");
		jdbcTemplate.update("insert into FE_JOB_QUEUE (JOB_ID,LOT_JOB_ID,FUNCTION_ID,REFERENCE_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)"
				    + "values(1000,1,1,'8888',4,1,1000,333,0)");
		
		procedure.setMuId(1000L);
		procedure.setLotJobCount(0);
		int pressure = procedure.execute();
		Assert.assertEquals(2, pressure);

	}
}
