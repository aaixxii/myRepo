package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MATCH_MANAGERS database table.
 * 
 */
@Entity
@Table(name = "MATCH_MANAGERS")
@NamedQuery(name = "MatchManagerEntity.findAll", query = "SELECT m FROM MatchManagerEntity m")
public class MatchManagerEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MATCH_MANAGERS_MMID_GENERATOR", sequenceName = "SERVER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MATCH_MANAGERS_MMID_GENERATOR")
	@Column(name = "MM_ID")
	private long mmId;

	@Column(name = "CONTACT_URL")
	private String contactUrl;

	@Column(name = "HEARTBEAT_TS")
	private Long heartbeatTs;

	@Column(name = "\"STATE\"")
	@Enumerated(EnumType.STRING)
	private UnitState state;

	@Column(name = "UNIQUE_ID")
	private String uniqueId;

	@Column(name = "\"VERSION\"")
	private String version;

	public MatchManagerEntity() {
	}

	public long getMmId() {
		return this.mmId;
	}

	public void setMmId(long mmId) {
		this.mmId = mmId;
	}

	public String getContactUrl() {
		return this.contactUrl;
	}

	public void setContactUrl(String contactUrl) {
		this.contactUrl = contactUrl;
	}

	public Long getHeartbeatTs() {
		return this.heartbeatTs;
	}

	public void setHeartbeatTs(Long heartbeatTs) {
		this.heartbeatTs = heartbeatTs;
	}

	public UnitState getState() {
		return this.state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public String getUniqueId() {
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}