package com.nec.aim.uid.client.main;

import static com.nec.aim.uid.client.common.UidClientConstants.DM_NOBLOCKING;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_SERVICES_URLS;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_WEB_CONTENT;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_REQUEST_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_POST_TIMEOUT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_HEATBEAT_INTERVAL;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_SOCKET_PORT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_HEATBEAT_TYPE;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.manager.UidDmJobRunManager;
import com.nec.aim.uid.client.monitor.DirectoryMonitor;
import com.nec.aim.uid.client.post.DmJobPoster;
import com.nec.aim.uid.client.post.DmRequestPoster;
import com.nec.aim.uid.client.post.HeatbeatPoster;
import com.nec.aim.uid.client.socket.SocketHeatBeatSender;

public class UidClientMain {
	private static Logger logger = LoggerFactory.getLogger(UidClientMain.class);
	private static final String RUN = "dm";
	private static final String STOP = "stop";
	private DirectoryMonitor monitor;

	public static void main(String[] args) {
		UidClientMain uidMain = new UidClientMain();
		uidMain.handleParameter(args);
	}

	private static void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append(lineSeparater);

		sb.append(lineSeparater);
		sb.append("Pring usage for dm:");
		sb.append(lineSeparater);
		sb.append(" Usage for starting dm with files or direcotry:");
		sb.append(lineSeparater);
		sb.append("  java -jar dmclient.jar dm 'parameter file path ...'");
		sb.append(lineSeparater);
		sb.append(" Usage for starting dm no parameter files:");
		sb.append(lineSeparater);
		sb.append("  java -jar dmclient.jar　dm");
		sb.append(lineSeparater);
		sb.append("  *no parameter file path means using files in directory of jobrequests.*");
		sb.append(lineSeparater);

		sb.append(" Usage for stop dm client:");
		sb.append(lineSeparater);
		sb.append("  java -jar dmclient.jar stop");
		logger.info(sb.toString());
	}

	private void handleParameter(String[] args) {
//		Runnable runnable = () -> {
//			stop();
//		};
//		Runtime.getRuntime().addShutdownHook(new Thread(runnable));

		if (RUN.equals(args[0].toLowerCase()) && args.length == 1) {
			startDM(null, RUN);
		} else if (RUN.equals(args[0].toLowerCase()) && args.length > 1) {
			startDM(args, RUN);
		} else if (STOP.equals(args[0].toLowerCase())) {
			stop();
		} else {
			pringUsage();
			System.exit(0);
		}
	}

	public void startDM(String[] filePaths, String paramater) {
		System.setProperty("file.encoding", "UTF-8");
		UidCommonManager clietnManager = UidCommonManager.getInstance();
		if (clietnManager.getMapSize() == 0) {
			if (!clietnManager.getAllProperties()) {
				String errMsg = "There are some wrong in uid.dm.client.properties. or isn't exist!. stop process!";
				logger.error(errMsg);
				System.exit(0);
			}
		}
		String dmWebContent = UidCommonManager.getValue(DM_WEB_CONTENT);
		String dmIpAndports = UidCommonManager.getValue(DM_SERVICES_URLS);
		String postTimeOut = UidCommonManager.getValue(DM_POST_TIMEOUT);		
		String sendInterval = UidCommonManager.getValue(DM_HEATBEAT_INTERVAL);
		String heatBeatType = UidCommonManager.getValue(DM_HEATBEAT_TYPE).toLowerCase();
		Long interval = null;
		try {
			interval = Long.parseLong(sendInterval);
		} catch (NumberFormatException e) {
			interval = 5000L;
		}
		if (heatBeatType.startsWith("http")) {			
		    HeatbeatPoster heatbeatPoster = new HeatbeatPoster(dmWebContent, dmIpAndports, Integer.valueOf(postTimeOut));
			int dms = heatbeatPoster.judgeDmServiceIsActive();
			logger.info("Active DM service count is {}", dms);			
			UidDmJobRunManager.httpHeatbeatSheduleTask(heatbeatPoster, interval.longValue());			
		} else if (heatBeatType.startsWith("socket")) {
			String dmSocketPorts = UidCommonManager.getValue(DM_SOCKET_PORT);
			String[] ipAndPorts = dmIpAndports.split(",");
			for (String one : ipAndPorts) {
				 String baseUrl =  "http://" + one +"/" + dmWebContent;
				 UidDmJobRunManager.addActiveDmServiceTome(baseUrl);
			}
			String[] socketPorts = dmSocketPorts.split(",");
			if (ipAndPorts.length != socketPorts.length) {
				throw new UidClientException("DM Service ip count is not equal socket count.");
			}
			UidDmJobRunManager.setSocketHeatbeatExector(ipAndPorts.length);			
			for (int i = 0; i < ipAndPorts.length; i++) {
				SocketHeatBeatSender sender = new SocketHeatBeatSender(dmWebContent, ipAndPorts[i], socketPorts[i], interval.longValue());
				UidDmJobRunManager.sumitSocketHeatbeatJobToMe(sender);
			}
		}	
		List<String> paramterFiles = new ArrayList<>();
		if (Objects.isNull(filePaths) || filePaths.length < 1) {
			// URL url =
			// this.getClass().getClassLoader().getResource("jobrequests");
			// String paramPath = url.getPath();
			String paramPath = UidCommonManager.getValue(JOB_REQUEST_PATH);
			File parmFile = new File(paramPath);
			if (parmFile.isDirectory()) {
				File[] fileArr = parmFile.listFiles();
				for (File afile : fileArr) {
					paramterFiles.add(afile.getAbsolutePath());
				}
			} else {
				paramterFiles.add(parmFile.getAbsolutePath());
			}

		} else {
			for (int i = 0; i < filePaths.length; i++) {
				File file = new File(filePaths[i]);
				if (file.isFile()) {
					paramterFiles.add(file.getAbsolutePath());
				} else if (file.isDirectory()) {
					File[] fileList = file.listFiles();
					for (File one : fileList) {
						paramterFiles.add(one.getAbsolutePath());
					}
				}
			}
		}
		String isBlocking = UidCommonManager.getValue(DM_NOBLOCKING);
		if (String.format(isBlocking).toLowerCase().startsWith("true")) {
			DmJobPoster.addJobToDm(paramterFiles);
		} else {
			DmRequestPoster dmRunable = new DmRequestPoster(paramterFiles);
			Thread task = new Thread(dmRunable);
			task.start();
		}
		monitor = new DirectoryMonitor();			
		UidDmJobRunManager.commitMonitorTask(monitor);
		logger.info("uid dm client is started!");
	}

	public void stop() {
		UidCommonManager.getInstance().shutdown();
		UidDmJobRunManager.shutdown();
		monitor.setStop(true);	
		SocketHeatBeatSender.stop();
		logger.info("dm client sucess shutdown.");		
		System.exit(0);
	}
}
