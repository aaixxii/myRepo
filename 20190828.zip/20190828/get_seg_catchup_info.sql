CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_seg_catchup_info`(
  IN p_component_type int,
  IN p_seg_diffs json
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
    -- p_seg_diffs= '{segmentId:1000,reportVersion:1,lastVersion:5},{segmentId:1000,reportVersion:1, lastVersion:5},{segmentId:1000,reportVersion:1, lastVersion:5}';
    DECLARE i INT DEFAULT 0;
    declare one_json varchar(32);
    declare seg_diff varchar(32);
	declare v_segmentId int(38);
    declare v_reportVersion int(38);
	declare v_latestVersion int(38);
    DECLARE t_error INTEGER DEFAULT 0;   
    declare cur cursor for  select * from segment_diffs;     
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
     DROP TEMPORARY TABLE IF EXISTS list_tmp;
     create temporary table history_ids(id int(38)) engine=memory;     
	 DROP TEMPORARY TABLE IF EXISTS list_tmp;
     create temporary table segment_diffs(
	     segmentId int(38),
         reportVersion int(38),
         latestVersion int(38)     
     ) engine=memory;     
     WHILE i < JSON_LENGTH(p_seg_diffs) DO
      set one_json =concat("’$[",i,"]’");
        SELECT JSON_EXTRACT( p_seg_diffs,CONCAT('$[',i,']')) INTO seg_diff;  
        insert into segment_diffs (segmentId, reportVersion,latestVersion) values (seg_diff->>"$.segmentId", seg_diff->>"$.reportVersion",seg_diff->>"$.latestVersion");
        set i = i +1; 
     END WHILE;
     open cur;
	lable_loop: loop
      FETCH cur INTO v_segmentId, v_reportVersion,  v_latestVersion;
      insert into history_ids(id) values (
        (select segment_change_id from segment_change_log c
		 WHERE segment_id = v_segmentId
		AND segment_version <= v_latestVersion 
		 AND segment_version > v_reportVersion
		ORDER BY c.segment_change_id, c.segment_version)  
      );  
       IF (p_component_type = 3) THEN
         select null;
       ELSEIF (p_component_type = 1) then
        select null;
       end if;
      
    end loop;  
      
      
     
     insert into history_ids(id) values (
	 
     );
     
     
     
     
     
     
     
     
    

END