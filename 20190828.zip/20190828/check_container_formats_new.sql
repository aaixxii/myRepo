CREATE DEFINER=`aimuser`@`%` PROCEDURE `check_container_formats_new`(
     in p_function_id int,
     in  p_candidate_containers VARCHAR(1024)
)
    READS SQL DATA
my_label:BEGIN
    -- p_candidate_containers="1,2,3,321,322,323"；     
      DECLARE l_actual_format_name VARCHAR(255);
      DECLARE l_target_format_name VARCHAR(255);
      DECLARE l_target_format_id int;
      DECLARE l_function_name VARCHAR(20);
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
      declare v_contaier_id int;
      declare v_format_id int;
      declare f_contaier_id int;
       declare f_format_id int;
	  DECLARE t_error INTEGER DEFAULT 0;  
      declare t_err_msg varchar(2048);
	 --  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
	  -- DROP TEMPORARY TABLE IF EXISTS arr_container_ids;
      -- create temporary table arr_container_ids(id int  NOT NULL PRIMARY KEY UNIQUE) engine=memory; 
		while v_idx > 0 do
         SET v_idx = INSTR(p_candidate_containers,',');
         SET v_tmp_str = substr(p_slb_matrix,0,t_idx-1); 
         SET v_contaier_id = CAST(v_tmp_str AS UNSIGNED);
          set p_candidate_containers=substr(p_candidate_containers,v_idx +1 ,LENGTH(p_candidate_containers)); 
         select c.container_id into f_contaier_id from containers c
         where c.container_id = v_contaier_id;
         if f_contaier_id is null then
          set  t_error =1;         
          select $t_err_msg;          
         end if;
		leave my_label;
        SELECT  f.target_format_id, f.function_name
		   INTO l_target_format_id, l_function_name
         FROM function_types f
         WHERE f.function_id = p_function_id; 
         select c.format_id into f_format_id from containers c where c.container_id = v_contaier_id;
         if STRCMP(f_format_id,l_target_format_id) <> 0 then
          set t_err_msg=""; 
           select $t_err_msg;  
		end if; 
      end while; 
END