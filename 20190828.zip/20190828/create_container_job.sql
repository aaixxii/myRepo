CREATE DEFINER=`aimuser`@`%` PROCEDURE `create_container_job`(
   IN   p_job_id int,
   IN   p_search_request_index int,
   IN   p_function_id int,
   IN   p_inquiry_job_data BLOB,
   IN   p_container_list varchar(2048),
   OUT  p_empty_job int,
   OUT  p_remain_job int,
   OUT  p_fusion_job_id int
)
BEGIN
   declare decl_fusion_job_id int;
   declare  l_count int;   
    DECLARE t_error INTEGER DEFAULT 0;  
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;


END