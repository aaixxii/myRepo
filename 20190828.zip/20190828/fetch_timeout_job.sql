CREATE DEFINER=`aimuser`@`%` PROCEDURE `fetch_timeout_job`(
)
BEGIN
declare l_epoch_time long;
 DECLARE t_error INTEGER DEFAULT 0; 
 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1; 
set l_epoch_time := get_epoch_time_num();
      SELECT job_id  FROM job_queue 
          WHERE job_state = 'WORKING'
          AND 0 <= timeouts 
          AND assigned_ts < (select l_epoch_time - timeouts FROM dual)
        order by job_id; 
        if t_error=1 then 
          select 1 from dual where false;
        end if; 
END