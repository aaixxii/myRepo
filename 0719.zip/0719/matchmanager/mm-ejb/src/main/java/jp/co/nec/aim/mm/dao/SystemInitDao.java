package jp.co.nec.aim.mm.dao;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.SystemInitEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Dao Class for SystemInitEntity
 * 
 * @author jinxl
 * 
 */
public class SystemInitDao {
	private static final String UNIT_NETWORK_SEGMENT = "UNIT_NETWORK_SEGMENT";
	private static final String UNIT_WAKEUP_PORT = "UNIT_WAKEUP_PORT";
	private static final String NUM_OF_MAX_FE_LOT = "NUM_OF_MAX_FE_LOT";
	private static final String SEGMENT_CHANGE_LOG_SAVE_DAYS = "SEGMENT_CHANGE_LOG_SAVE_DAYS";
	private static final String IN_USING_PARTITIONS = "IN_USING_PARTITIONS";
	private static final String IN_USING_ADJUST = "IN_USING_ADJUST";
	private static final String ONE_TEMPLATET_BYTE_SIZE = "ONE_TEMPLATET_BYTE_SIZE";
	
	private static final Logger log = LoggerFactory.getLogger(SystemInitDao.class);

	private EntityManager entityManager;

	public SystemInitDao(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	private SystemInitEntity getSystemInitEntity(String key) {
		Query q = entityManager.createNamedQuery("NQ:getSystemInitEntity");
		q.setParameter("key", key);
		try {
			return (SystemInitEntity) q.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}

	public int updateInUsingPartitions(String pnoStr) {
		Query q = entityManager.createNamedQuery("NQ::updateInUsingPartitions");
		q.setParameter("keyValue", pnoStr);
		return q.executeUpdate();
	}

	public String getInUsingPartitions() {
		SystemInitEntity entity = getSystemInitEntity(IN_USING_PARTITIONS);
		if (entity == null) {
			log.warn("IN_USING_PARTITIONS is not yet set in SYSTEM_INIT");
			return null;
		} else {
			String value = entity.getKeyValue();
			return value;
		}
	}

	public Long getSegChangeLogSaveDays() {
		SystemInitEntity entity = getSystemInitEntity(SEGMENT_CHANGE_LOG_SAVE_DAYS);
		if (entity == null) {
			log.warn("SEGMENT_CHANGE_LOG_SAVE_DAYS is not yet set in SYSTEM_INIT");
			return null;
		} else {
			String value = entity.getKeyValue();
			Long segChangeLogSaveDays = null;
			try {
				segChangeLogSaveDays = Long.valueOf(value);
			} catch (Exception e) {
				log.error("parse SEGMENT_CHANGE_LOG_SAVE_DAYS to Long error..", e);
			}
			return segChangeLogSaveDays;
		}
	}
	
	//partitio save days
	public int updateSegChangeLogSaveDays(String pNo) {
		Query q = entityManager.createNamedQuery("NQ::updatePartitionSaveDays");
		q.setParameter("keyValue", pNo);
		return q.executeUpdate();
	}
	
	public Long getInUsingAdjust() {
		SystemInitEntity entity = getSystemInitEntity(IN_USING_ADJUST);
		if (entity == null) {
			log.warn("IN_USING_ADJUST is not yet set in SYSTEM_INIT");
			return null;
		} else {
			String value = entity.getKeyValue();
			Long inUsingAdjust = null;
			try {
				inUsingAdjust = Long.valueOf(value);
			} catch (Exception e) {
				log.error("parse IN_USING_ADJUST to Long error..", e);
			}
			return inUsingAdjust;
		}
	}
	
	public int updateInUsingAdjuist(Long adjust) {
		Query q = entityManager.createNamedQuery("NQ::updateInUsingAdjuist");
		q.setParameter("keyValue", adjust.toString());
		return q.executeUpdate();
	}
	
	public Integer getOneTemplateSize() {
		SystemInitEntity entity = getSystemInitEntity(ONE_TEMPLATET_BYTE_SIZE);
		if (entity == null) {
			log.warn("ONE_TEMPLATET_BYTE_SIZE is not yet set in SYSTEM_INIT");
			return null;
		} else {
			String value = entity.getKeyValue();
			Integer oneTemplateSize = null;
			try {
				oneTemplateSize = Integer.valueOf(value);
			} catch (Exception e) {
				log.error("parse MU Max lot to Integer error..", e);
			}
			return oneTemplateSize;
		}
	}
	
	public Integer getMuMaxLot() {
		SystemInitEntity entity = getSystemInitEntity(NUM_OF_MAX_FE_LOT);
		if (entity == null) {
			log.warn("NUM_OF_MAX_FE_LOT is not yet set in SYSTEM_INIT");
			return null;
		} else {
			String value = entity.getKeyValue();
			Integer maxLot = null;
			try {
				maxLot = Integer.valueOf(value);
			} catch (Exception e) {
				log.error("parse MU Max lot to Integer error..", e);
			}
			return maxLot;
		}
	}

	public String getUnitNetWorkSegment() {
		SystemInitEntity entity = getSystemInitEntity(UNIT_NETWORK_SEGMENT);
		if (entity == null) {
			log.warn("UNIT_NETWORK_SEGMENT is not yet set in SYSTEM_INIT");
			return null;
		} else {
			return entity.getKeyValue();
		}
	}

	public Integer getUnitWakeupPort() {
		SystemInitEntity entity = getSystemInitEntity(UNIT_WAKEUP_PORT);
		if (entity == null) {
			log.warn("UNIT_WAKEUP_PORT is not yet set in SYSTEM_INIT");
			return null;
		} else {
			String value = entity.getKeyValue();
			Integer port = null;
			try {
				port = Integer.valueOf(value);
			} catch (Exception e) {
				log.error("parse MU notify port to Integer error..", e);
			}
			return port;
		}

	}
}
