package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;

import jp.co.nec.aim.mm.entities.DmServiceEntity;

public class DmServiceDao {
	
	private EntityManager em;

	public DmServiceDao(EntityManager em) {
		this.em = em;
	}	

	
	public DmServiceEntity findDM(String id) {
		return em.find(DmServiceEntity.class, id);
	}	
	
	public List<DmServiceEntity> findAllDmService() {
		String allSql = "select e from DmServiceEntity e";		 
		List<DmServiceEntity> result = em.createQuery(allSql, DmServiceEntity.class).getResultList();
		return result;
	}
}
