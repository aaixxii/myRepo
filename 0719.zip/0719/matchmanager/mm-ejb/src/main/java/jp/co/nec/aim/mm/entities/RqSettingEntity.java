package jp.co.nec.aim.mm.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the RqSettingEntity database table.
 * 
 */
@Entity
@Table(name = "RQ_SETTING")
public class RqSettingEntity implements Serializable {	
	
	private static final long serialVersionUID = 3403067566239230898L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Integer id;
	
	@Column(name = "EXCHANGE_NAME")
	private String exchangeName;		
	
	@Column(name = "QUEUE_NAME")
	private String queueName;
	
	@Column(name = "HOST")
	private String host;
	
	@Column(name = "PORT")
	private Integer port;
	
	@Column(name = "USER_NAME")
	private String userName;
	
	@Column(name = "PASSWD")
	private String passwd;
	
	@Column(name = "V_HOST")
	private String vHost;
	
	@Column(name = "TH_NUM")
	private Integer thNum;
	
	@Column(name = "TIMESTAMP")
	private Timestamp planedTs;
	
	@Column(name = "TIMEOUT_TH")
	private Integer timeoutTH;
	
	@Column(name = "POOLING_TIME")
	private Integer poolingTime;
	
	@Column(name = "MASTER_NODE")
	private String masterNode;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getExchangeName() {
		return exchangeName;
	}

	public void setExchangeName(String exchangeName) {
		this.exchangeName = exchangeName;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getvHost() {
		return vHost;
	}

	public void setvHost(String vHost) {
		this.vHost = vHost;
	}

	public Integer getThNum() {
		return thNum;
	}

	public void setThNum(Integer thNum) {
		this.thNum = thNum;
	}

	public Timestamp getPlanedTs() {
		return planedTs;
	}

	public void setPlanedTs(Timestamp planedTs) {
		this.planedTs = planedTs;
	}

	public Integer getTimeoutTH() {
		return timeoutTH;
	}

	public void setTimeoutTH(Integer timeoutTH) {
		this.timeoutTH = timeoutTH;
	}

	public Integer getPoolingTime() {
		return poolingTime;
	}

	public void setPoolingTime(Integer poolingTime) {
		this.poolingTime = poolingTime;
	}

	public String getMasterNode() {
		return masterNode;
	}

	public void setMasterNode(String masterNode) {
		this.masterNode = masterNode;
	}	
	
}