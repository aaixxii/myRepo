package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeLotJobEntity;
import jp.co.nec.aim.mm.entities.MuExtractLoadEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * get all data from database for dispatching extract plans to mu
 * 
 * @author xiazp
 *
 */
public class FEPlanDispatchDaoImpl implements FEPlanDispatchDao {
	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;
	private static final String GET_FE_LOT_JOB = "FROM FeLotJobEntity fj WHERE fj.lotJobId = :feLotJobId";
	private static final String GET_FE_JOB = "FROM FeJobQueueEntity fq WHERE fq.lotJobId = :feLotJobId order by fq.id,fq.muId";
	private static final String GET_FE_JOB_PAYLOAD = "FROM FeJobPayloadEntity fjp WHERE fjp.jobId in :feJobIds order by fjp.jobId";
	private static final String GET_MU_URL = "SELECT mu.contactUrl FROM MatchUnitEntity mu WHERE mu.muId =:muId";
	private static final String GET_EXTRACT_JOB_TIMEOUT = "SELECT fy.topLevelJobTimeouts FROM  FunctionTypeEntity fy WHERE fy.id =:functionId";
	private static final String GET_EXTRACT_JOB_RETRY_TIME = "SELECT PROPERTY_VALUE FROM SYSTEM_CONFIG WHERE PROPERTY_NAME =:maxExtractJobFaildCount";
	private static final String SYSTEM_CONFIG_SQL = "SELECT PROPERTY_VALUE FROM SYSTEM_CONFIG WHERE PROPERTY_NAME = :properyName";
	private static final String GET_MU_EXTRACT_LOAD_ENTITY = "FROM MuExtractLoadEntity ml WHERE ml.muId = :muId";
	private static final String URL_SQL = "SELECT fj.callbackUrl FROM FeJobQueueEntity fj WHERE fj.id =:feJobId";
	private static final String UPDATE_MU_EXTRACT_LOAD_SQL = 
	"update MU_EXTRACT_LOAD ml set ml.PRESSURE =CASE SIGN(ml.PRESSURE -1) WHEN -1 THEN 0 WHEN 0 THEN 0 WHEN 1 THEN ml.PRESSURE -1 END,ml.UPDATE_TS = get_epoch_time_num() where ml.MU_ID = ?";
	

	// private static final String SELECT_MU_PRESSURE =
	// "select ml.pressure from mu_extract_load ml where ml.mu_id = ? for update";

	private static Logger logger = LoggerFactory
			.getLogger(FEPlanDispatchDaoImpl.class);

	public FEPlanDispatchDaoImpl(EntityManager manager,
			JdbcTemplate jdbcTemplate) {
		this.manager = manager;
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
	 * @param feLotJobId
	 */
	@Override
	public FeLotJobEntity getFeLotJob(long feLotJobId) {
		FeLotJobEntity result = null;
		try {
			Query q = manager.createQuery(GET_FE_LOT_JOB);
			q.setParameter("feLotJobId", new Long(feLotJobId));
			result = (FeLotJobEntity) q.getSingleResult();
			if (result.getLotJobId() < 0 || result == null) {
				return null;
			}
		} catch (Exception e) {
			logger.warn(e.getMessage());
			return null;
		}
		return result;
	}

	/**
	 * @param feLotJobId
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FeJobQueueEntity> getFeJobs(long feLotJobId) {
		List<FeJobQueueEntity> results = null;
		try {
			Query q = manager.createQuery(GET_FE_JOB);
			q.setParameter("feLotJobId", new Long(feLotJobId));
			results = q.getResultList();
			if (results == null || results.size() <= 0) {
				return null;
			}
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
		return results;
	}

	/**
	 * @param feJobIds
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<FeJobPayloadEntity> getFeJobPayLoads(List<Long> feJobIds) {
		List<FeJobPayloadEntity> results = null;
		try {
			Query q = manager.createQuery(GET_FE_JOB_PAYLOAD);
			q.setParameter("feJobIds", feJobIds);
			results = q.getResultList();
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
		return results;
	}

	/**
	 * @param muId
	 */
	@Override
	public String getMuUrl(long muId) {

		try {
			Query q = manager.createQuery(GET_MU_URL);
			q.setParameter("muId", new Long(muId));
			String result =  (String) q.getSingleResult();
			if (result != null && result.length() > 1 && !result.equals("[]")) {
				return result;				
			} else  {
				return null;
			}			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public long getFeJobTimeOut() {
		try {
			Query q = manager.createQuery(GET_EXTRACT_JOB_TIMEOUT);
			q.setParameter("functionId", new Integer(17));
			return (long) q.getSingleResult();
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return -1;
		}
	}

	@Override
	public Integer getMaxExtractJobRetryCount() {
		try {
			Query q = manager.createNativeQuery(GET_EXTRACT_JOB_RETRY_TIME);
			q.setParameter("maxExtractJobFaildCount",
					"BEHAVIOR.MAX_EXTRACT_JOB_FAILURES");
			String times = (String) q.getSingleResult();
			return Integer.valueOf(times);
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public MuExtractLoadEntity findMuExtractLoadEntity(long muId) {
		try {
			Query q = manager.createQuery(GET_MU_EXTRACT_LOAD_ENTITY);
			q.setParameter("muId", new Long(muId));
			return (MuExtractLoadEntity) q.getSingleResult();
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public String getCallBackURL(long feJobId) {
		try {
			Query q = manager.createQuery(URL_SQL);
			q.setParameter("feJobId", new Long(feJobId));
			return (String) q.getSingleResult();
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public String getSystemConfigValue(String propertyName) {
		try {
			Query q = manager.createNativeQuery(SYSTEM_CONFIG_SQL);
			q.setParameter("properyName", propertyName);
			return (String) q.getSingleResult();
		} catch (PersistenceException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public void updateMuExtractLoad(Integer muId) {
		jdbcTemplate.update(UPDATE_MU_EXTRACT_LOAD_SQL, new Object[] { muId });
	}
}
