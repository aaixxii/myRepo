/**this is file PreferredMapper.java
 * @author xia
   @date 2020/06/06
 */
package jp.co.nec.aim.mm.util;

import com.sun.xml.bind.marshaller.NamespacePrefixMapper;

/**
 * @author xia
 *
 */
public class PreferredMapper extends NamespacePrefixMapper {

	/* (non-Javadoc)
	 * @see com.sun.xml.bind.marshaller.NamespacePrefixMapper#getPreferredPrefix(java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public String getPreferredPrefix(String arg0, String arg1, boolean arg2) {		
		return "";
	}

}
