package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;

import jp.co.nec.aim.mm.entities.RqSettingEntity;

public class AmqSettingDao {
	
	private EntityManager em;

	public AmqSettingDao(EntityManager em) {
		this.em = em;
	}	

	
	public RqSettingEntity findAmqSetting(Integer id) {
		return em.find(RqSettingEntity.class, id);
	}	
	
	public List<RqSettingEntity> findAllAmqSetting() {
		String allSql = "select e from RqSettingEntity e";		 
		List<RqSettingEntity> result = em.createQuery(allSql, RqSettingEntity.class).getResultList();
		return result;
	}
}
