package jp.co.nec.aim.mm.acceptor.service;


import java.io.IOException;
import java.io.StringWriter;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimSyncServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private AimSyncService aimSyncService;
	@Resource
	private JdbcTemplate jdbcTemplate;
	
	

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from SYSTEM_CONFIG");
		jdbcTemplate
				.update("INSERT INTO SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME, PROPERTY_VALUE) VALUES (1000, 'TEMPLATE_VALIDATION.ENABLED', 'false')");

//		jdbcTemplate.update("delete from segments");
//		jdbcTemplate.update("delete from person_biometrics");
//		jdbcTemplate.update("delete from segment_change_log");
//		jdbcTemplate.execute("commit");
		setMockMethod();
		//protobufCreater = new ProtobufCreater();
	}

	@After
	public void tearDown() {

		jdbcTemplate
				.update("update CONTAINERS set MAX_SEGMENT_SIZE = 20000000 ");
		//jdbcTemplate.update("delete from segments");
//		jdbcTemplate.update("delete from FE_JOB_QUEUE");		
//		jdbcTemplate.update("delete from person_biometrics");
//		jdbcTemplate.update("delete from segment_change_log");
		jdbcTemplate.execute("commit");		
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}

		};
	}
	
	@Test	
	public void syncDataTest_insert_by_url() throws IOException {	
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Request")
				 .addAttribute("requestId", "12345")
				 .addAttribute("version", "1.0f")
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Insert").addAttribute("referenceId", "test").addAttribute("referenceUrl", "http://test.com");
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();	
        System.out.println(resuslt);
       UidAimAmqResponse uidAmqRes = aimSyncService.syncData(resuslt);
       System.out.print(uidAmqRes.toString());
	
	}
	
	@Test
	public void syncDeleteTest() throws InvalidProtocolBufferException {
		
	
	}
}
