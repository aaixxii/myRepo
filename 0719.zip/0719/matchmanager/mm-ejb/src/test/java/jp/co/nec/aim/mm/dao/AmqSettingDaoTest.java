/**this is file AmqSettingDaoTest.java
 * @author xia
   @date 2020/07/18
 */
package jp.co.nec.aim.mm.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.mm.entities.RqSettingEntity;

/**
 * @author xia
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class AmqSettingDaoTest {
	
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	
	private AmqSettingDao amqDao;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		amqDao = new AmqSettingDao(entityManager);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	
	@Test
	public void testFindAmqSetting() {
		RqSettingEntity setting = amqDao.findAmqSetting(1);
		Assert.assertNotNull(setting);
		Assert.assertEquals("xia", setting.getUserName());		
	}
	
	@Test
	public void testFindAllAmqSetting() {
		List<RqSettingEntity> result = amqDao.findAllAmqSetting();	
		Assert.assertNotNull(result);
		Assert.assertEquals(1, result.size());
	}

}
