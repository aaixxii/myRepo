package jp.co.nec.aim.mm.partition;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PartitionUtilTestReduceToAdd {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}	
	
	private  long caculateHashAtThisToday(LocalDate thisDay) {
		Long saveDays = 5L;
		Long adjust = 0L;
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + adjust.longValue()) % (saveDays.longValue());
	}
	
	@Test
	public void testcaculate7HashAtThisToday() {
		String date = "2020-04-22";
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate thisDay = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));
		long todayHashValue = caculateHashAtThisToday(thisDay);
		System.out.print(todayHashValue);
	}	
	
	public long caculate5NewAdjustAtThisDay(long newN, LocalDate firstAddDay) {
		Long oldSaveDays = 5L;		
		long firstAddDayHashValue = caculateHashAtThisToday(firstAddDay);
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstAddDay);
		long quotient = epochDays/oldSaveDays.longValue();
		long deltaX = oldSaveDays * quotient + firstAddDayHashValue - epochDays;
		long X = (epochDays + deltaX) % oldSaveDays;
		long Y = epochDays % newN;		
		long adjustNew = (X - Y + newN) % newN;		
		return adjustNew;
		//long hashNew = (epochDays + adjustNew) % newN;
	}
	
	@Test
	public void testcaculate5NewAdjustAtThisDay() {
		String date = "2020-04-22";
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate thisDay = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));		
		long adjust = caculate5NewAdjustAtThisDay(7l, thisDay);
		System.out.print(adjust);
	}
	
	@Test
	public void testcaculateNewAdjustAtThisDay() {
		String firstDayStr = "2020-04-22";		
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate firstDay = LocalDate.parse(firstDayStr, DateTimeFormatter.ofPattern(DATE_FORMAT));
		 long adjust = caculate5NewAdjustAtThisDay(7l, firstDay);
		 LocalDate epoch = LocalDate.ofEpochDay(0);
		 String date = "2020-04-30";
		 LocalDate at21Day = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));
		 long epochDays = ChronoUnit.DAYS.between(epoch, at21Day);
		 long hashNew = (epochDays + adjust) % 7;
		System.out.print(hashNew);
	}
}
