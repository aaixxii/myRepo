package jp.co.nec.aim.df.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.RangeSegment;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.util.ConnectionUtil;

import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class MergerSegmentDaoTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Rule
	public TestName name = new TestName();

	private MergerSegmentDao dao;
	private Connection con;

	private void clearData() {
		jdbcTemplate.execute("delete from person_biometrics");
		jdbcTemplate.execute("delete from segment_change_log");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.update("commit");
	}

	private static DataCreatorUtil creator;

	@Before
	public void setup() throws SQLException {
		con = DataSourceCreator.getInstance().getDataSource().getConnection();
		dao = DaoFactory.createDao(MergerSegmentDao.class, con);

		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}

		clearData();
		final String methodName = name.getMethodName();
		if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond2SegsResultIs1")) {
			creator.createGetPersonRangeInfoMergerBeyond2SegsResultIs1();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond3SegsResultIs1")) {
			creator.createGetPersonRangeInfoMergerBeyond3SegsResultIs1();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond4SegsResultIs1")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs1();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond5SegsResultIs1")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs1();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond3SegsResultIs2")) {
			creator.createGetPersonRangeInfoMergerBeyond3SegsResultIs2();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond4SegsResultIs2")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs2();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond4SegsResultIs3")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs3();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoStartidIsOverExistId")) {
			creator.createGetPersonRangeInfoMergerBeyond2SegsResultIs1();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond5SegsResultIs2")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs2();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond5SegsResultIs3")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs3();
		} else if (methodName
				.equalsIgnoreCase("testGetPersonRangeInfoMergerBeyond5SegsResultIs4")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs4();
		} else if (methodName.equalsIgnoreCase("testGetNextIdTheIdIsSeparated")) {
			creator.CreateGetNextIdTheIdIsSeparated();
		} else if (methodName.equalsIgnoreCase("testGetNextIdTheIdIsNotExist")) {
			creator.CreateGetNextIdTheIdIsSeparated();
		} else if (methodName
				.equalsIgnoreCase("testGetNextIdTheIdIsNotWithinSpecSegmentRange")) {
			creator.CreateGetNextIdTheIdIsSeparated();
		} else if (methodName.equalsIgnoreCase("testGetNextIdCannotGetNextId")) {
			creator.CreateGetNextIdTheIdIsSeparated();
		} else if (methodName
				.equalsIgnoreCase("testGetNextIdTheIdIsContinuous")) {
			creator.CreateGetNextIdTheIdIsSeparated();
		}
		jdbcTemplate.update("commit");
	}

	@After
	public void after() {
		ConnectionUtil.close(con);
		clearData();
	}

	@AfterClass
	public static void afterClass() {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
	}

	// ////////////////////////////////////////////////////////////////////
	// ///////////////////////// test section /////////////////////////////
	// ////////////////////////////////////////////////////////////////////
	@Test
	public void testGetPersonRangeInfoNoDataReturnNull() {
		RangeSegment range = dao.getPersonRangeInfo(1, "2,3,4", 200000, 1);
		assertNull(range);
	}

	@Test
	public void testGetPersonRangeInfoStartidIsOverExistId() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2", 200000, 50);
		assertNull(range);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond2SegsResultIs1() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 30);
		assertEquals(range.getRecordCount().intValue(), 18);
		assertEquals(range.getSegmentId().intValue(), 2);
		assertEquals(range.getTotalLength().intValue(), 159210);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond3SegsResultIs1() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 50);
		assertEquals(range.getRecordCount().intValue(), 20);
		assertEquals(range.getSegmentId().intValue(), 3);
		assertEquals(range.getTotalLength().intValue(), 176938);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond4SegsResultIs1() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3,4", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 69);
		assertEquals(range.getRecordCount().intValue(), 19);
		assertEquals(range.getSegmentId().intValue(), 4);
		assertEquals(range.getTotalLength().intValue(), 168112);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond5SegsResultIs1() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 89);
		assertEquals(range.getRecordCount().intValue(), 20);
		assertEquals(range.getSegmentId().intValue(), 5);
		assertEquals(range.getTotalLength().intValue(), 176976);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond3SegsResultIs2() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 52);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 3);
		assertEquals(range.getTotalLength().intValue(), 194628);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond4SegsResultIs2() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3,4", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 72);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 4);
		assertEquals(range.getTotalLength().intValue(), 194628);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond4SegsResultIs3() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3,4", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 32);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 2);
		assertEquals(range.getTotalLength().intValue(), 194590);

		Long nextId = dao.getNextId(1, 32, "1,2,3,4");
		assertEquals(nextId.intValue(), 33);

		range = dao.getPersonRangeInfo(1, "1,2,3,4", 200000, 33);
		assertEquals(range.getRangeId().intValue(), 74);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 4);
		assertEquals(range.getTotalLength().intValue(), 194590);

		nextId = dao.getNextId(1, 74, "1,2,3,4");
		assertEquals(nextId.intValue(), 75);

		range = dao.getPersonRangeInfo(1, "1,2,3,4", 200000, 75);
		assertEquals(range.getRangeId().intValue(), 78);
		assertEquals(range.getRecordCount().intValue(), 4);
		assertEquals(range.getSegmentId().intValue(), 4);
		assertEquals(range.getTotalLength().intValue(), 35380);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond5SegsResultIs2() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 91);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 5);
		assertEquals(range.getTotalLength().intValue(), 194666);

		Long nextId = dao.getNextId(1, 91, "1,2,3,4,5");
		assertEquals(nextId.intValue(), 92);

		range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 92);
		assertEquals(range.getRangeId().intValue(), 93);
		assertEquals(range.getRecordCount().intValue(), 2);
		assertEquals(range.getSegmentId().intValue(), 5);
		assertEquals(range.getTotalLength().intValue(), 17690);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond5SegsResultIs3() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 46);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 3);
		assertEquals(range.getTotalLength().intValue(), 194590);

		Long nextId = dao.getNextId(1, 46, "1,2,3,4,5");
		assertEquals(nextId.intValue(), 47);

		range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 47);
		assertEquals(range.getRangeId().intValue(), 92);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 5);
		assertEquals(range.getTotalLength().intValue(), 194590);

		nextId = dao.getNextId(1, 92, "1,2,3,4,5");
		assertEquals(nextId.intValue(), 93);

		range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 93);
		assertEquals(range.getRangeId().intValue(), 98);
		assertEquals(range.getRecordCount().intValue(), 6);
		assertEquals(range.getSegmentId().intValue(), 5);
		assertEquals(range.getTotalLength().intValue(), 53070);
	}

	@Test
	public void testGetPersonRangeInfoMergerBeyond5SegsResultIs4() {
		RangeSegment range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 1);
		assertEquals(range.getRangeId().intValue(), 28);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 2);
		assertEquals(range.getTotalLength().intValue(), 194590);

		Long nextId = dao.getNextId(1, 28, "1,2,3,4,5");
		assertEquals(nextId.intValue(), 29);

		range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 29);
		assertEquals(range.getRangeId().intValue(), 56);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 3);
		assertEquals(range.getTotalLength().intValue(), 194590);

		nextId = dao.getNextId(1, 56, "1,2,3,4,5");
		assertEquals(nextId.intValue(), 57);

		range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 57);
		assertEquals(range.getRangeId().intValue(), 90);
		assertEquals(range.getRecordCount().intValue(), 22);
		assertEquals(range.getSegmentId().intValue(), 5);
		assertEquals(range.getTotalLength().intValue(), 194590);

		nextId = dao.getNextId(1, 90, "1,2,3,4,5");
		assertEquals(nextId.intValue(), 91);

		range = dao.getPersonRangeInfo(1, "1,2,3,4,5", 200000, 91);
		assertEquals(range.getRangeId().intValue(), 104);
		assertEquals(range.getRecordCount().intValue(), 14);
		assertEquals(range.getSegmentId().intValue(), 5);
		assertEquals(range.getTotalLength().intValue(), 123830);
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetPersonRangeInfo_withException() {
		try {
			new MockUp<BaseDao>() {
				@Mock
				public void prepareStatement(String sql)
						throws DefragmentDaoException {
					throw new NullPointerException();
				}
			};
			dao.getPersonRangeInfo(1, "", 1, 1L);
		} finally {			
		}
	}

	@Test
	public void testGetNextIdWithNoData() {
		Long nextId = dao.getNextId(1, 90, "1,2,3,4,5");
		assertNull(nextId);
	}

	@Test
	public void testGetNextIdTheIdIsContinuous() {
		Long nextId = dao.getNextId(1, 3, "1,2");
		assertEquals(nextId.intValue(), 4);
	}

	@Test
	public void testGetNextIdTheIdIsSeparated() {
		Long nextId = dao.getNextId(1, 10, "1,2");
		assertEquals(nextId.intValue(), 23);
	}

	@Test
	public void testGetNextIdTheIdIsNotExist() {
		Long nextId = dao.getNextId(1, 12, "1,2");
		assertEquals(nextId.intValue(), 23);
	}

	@Test
	public void testGetNextIdTheIdIsNotWithinSpecSegmentRange() {
		Long nextId = dao.getNextId(1, 12, "1");
		assertNull(nextId);
	}

	@Test
	public void testGetNextIdCannotGetNextId() {
		Long nextId = dao.getNextId(1, 45, "1,2");
		assertNull(nextId);
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetNextId_withException() {
		try {
			new MockUp<BaseDao>() {
				@Mock
				public void prepareStatement(String sql)
						throws DefragmentDaoException {
					throw new NullPointerException();
				}
			};
			dao.getNextId(1, 1L, "");
		} finally {			
		}
	}

}
