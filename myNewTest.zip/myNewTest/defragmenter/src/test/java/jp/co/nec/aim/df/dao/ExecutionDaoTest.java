package jp.co.nec.aim.df.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.SegmentVersion;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.util.ConnectionUtil;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class ExecutionDaoTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Rule
	public TestName name = new TestName();

	private static ExecutionDao dao;
	private static Connection con;
	private static SegmentDefragDao segDefragdao;

	@BeforeClass
	public static void setDaoAndConnection() throws SQLException {
		con = DataSourceCreator.getInstance().getDataSource().getConnection();
		dao = DaoFactory.createDao(ExecutionDao.class, con);
		segDefragdao = DaoFactory.createDao(SegmentDefragDao.class);
	}

	@AfterClass
	public static void closeConnection() {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
		ConnectionUtil.close(con);
	}

	private void clearSegmentData() {
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	private static DataCreatorUtil creator;

	@Before
	public void setup() {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}

		clearSegmentData();

		creator.initDefragContainerId();
		final String methodName = name.getMethodName();
		if (methodName.equalsIgnoreCase("testDeleteExistSegment")) {
			creator.createSegmentWithId(1111L);
		} else if (methodName
				.equalsIgnoreCase("testDeleteExistSegmentVersionIsNotmatch")) {
			creator.createSegmentWithId(1111L);
		} else if (methodName.equalsIgnoreCase("testUpdateSegmentAll")) {
			creator.createSegmentWithId(2222L);
		} else if (methodName
				.equalsIgnoreCase("testUpdateSegmentAllIsNotMatchVersion")) {
			creator.createSegmentWithId(2222L);
		} else if (methodName.equalsIgnoreCase("testUpdateSegmentFromTo")) {
			creator.createSegmentWithId(2222L);
		} else if (methodName
				.equalsIgnoreCase("testLockRowAndGetVersion_with3Segments")
				|| methodName
						.equalsIgnoreCase("testLockRowAndGetVersion_checkSegmentsLocked_commit")
				|| methodName
						.equalsIgnoreCase("testLockRowAndGetVersion_checkSegmentsLocked_rollback")) {
			creator.createSegmentWithId(1111L);
			creator.createSegmentWithId(2222L);
			creator.createSegmentWithId(3333L);
		} else if (methodName
				.equalsIgnoreCase("testLockAndGetContainerId_WithRecord")
				|| methodName
						.equalsIgnoreCase("testLockAndGetContainerId_WithRecord_checkLocked_commit")
				|| methodName
						.equalsIgnoreCase("testLockAndGetContainerId_WithRecord_checkLocked_rollback")) {
			creator.setDefragContainerId(111L);
		} else if (methodName.equalsIgnoreCase("testDeleteMuJobs_normally")
				|| methodName
						.equalsIgnoreCase("testDeleteMuJobs_withVersionNotMatch")) {
			creator.createSegmentWithId(1111L);
			creator.createSegmentWithId(2222L);
			creator.createSegmentWithId(3333L);
			creator.insertJob();
		}
		jdbcTemplate.execute("commit");
	}

	@After
	public void after() {
		ConnectionUtil.commit(con);
		clearSegmentData();
	}

	@Test
	public void testLockRowAndGetVersion_with3Segments() {
		final String segmentIds = "1111,2222,3333";

		List<SegmentVersion> segmentVersions = dao
				.lockRowAndGetVersion(segmentIds);

		assertEquals(segmentVersions.size(), 3);

		SegmentVersion version1 = segmentVersions.get(0);
		assertEquals(version1.getSegmentId(), 1111L);
		assertEquals(version1.getVersion(), 34);
		assertEquals(version1.getReVersion(), 34);

		SegmentVersion version2 = segmentVersions.get(1);
		assertEquals(version2.getSegmentId(), 2222L);
		assertEquals(version2.getVersion(), 34);
		assertEquals(version2.getReVersion(), 34);

		SegmentVersion version3 = segmentVersions.get(2);
		assertEquals(version3.getSegmentId(), 3333L);
		assertEquals(version3.getVersion(), 34);
		assertEquals(version3.getReVersion(), 34);
	}

	@Test
	public void testLockRowAndGetVersion_withNothing() {
		final String segmentIds = "1111,2222,3333";
		List<SegmentVersion> segmentVersions = dao
				.lockRowAndGetVersion(segmentIds);
		assertEquals(segmentVersions.size(), 0);
	}

	@Test(expected = DefragmentDaoException.class)
	public void testLockRowAndGetVersion_withDaoException() {
		final String errorSegmentIds = "1111,2222,3333sdsd";
		dao.lockRowAndGetVersion(errorSegmentIds);
	}

	@Test
	public void testLockRowAndGetVersion_checkSegmentsLocked_commit() {
		final String segmentIds = "1111,2222,3333";
		dao.lockRowAndGetVersion(segmentIds);
		String sql = "select SEGMENT_ID from segments where SEGMENT_ID in ("
				+ segmentIds + ") FOR UPDATE SKIP LOCKED";
		List<SegmentVersion> versions = jdbcTemplate
				.query(sql,
						new Object[] {},//
						new BeanPropertyRowMapper<SegmentVersion>(
								SegmentVersion.class));

		assertEquals(versions.size(), 0);
		ConnectionUtil.commit(con);
		versions = jdbcTemplate
				.query(sql,
						new Object[] {},//
						new BeanPropertyRowMapper<SegmentVersion>(
								SegmentVersion.class));

		assertEquals(versions.size(), 3);
	}

	@Test
	public void testLockRowAndGetVersion_checkSegmentsLocked_rollback() {
		final String segmentIds = "1111,2222,3333";
		dao.lockRowAndGetVersion(segmentIds);
		String sql = "select SEGMENT_ID from segments where SEGMENT_ID in ("
				+ segmentIds + ") FOR UPDATE SKIP LOCKED";
		List<SegmentVersion> versions = jdbcTemplate
				.query(sql,
						new Object[] {},//
						new BeanPropertyRowMapper<SegmentVersion>(
								SegmentVersion.class));

		assertEquals(versions.size(), 0);
		ConnectionUtil.rollBack(con);
		versions = jdbcTemplate
				.query(sql,
						new Object[] {},//
						new BeanPropertyRowMapper<SegmentVersion>(
								SegmentVersion.class));

		assertEquals(versions.size(), 3);
	}

	@Test
	public void testLockAndGetContainerId_noRecord() {
		clearSegmentData();
		Long containerId = segDefragdao.getTrifficContainerId();
		assertNull(containerId);
	}

	@Test
	public void testLockAndGetContainerId_WithRecord() {
		Long containerId = segDefragdao.getTrifficContainerId();
		assertEquals(containerId.longValue(), 111L);
	}

	@Test(expected = DefragmentDaoException.class)
	public void testLockAndGetContainerId_WithRecord_Excption() {
		new MockUp<BaseDao>() {
			@Mock
			protected void prepareStatement(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException("");
			}
		};
		try {
			Long containerId = segDefragdao.getTrifficContainerId();
			assertEquals(containerId.longValue(), 111L);
		} finally {			
		}
	}

	public static class ContainerId {
		private long containerId;

		public long getContainerId() {
			return containerId;
		}

		public void setContainerId(long containerId) {
			this.containerId = containerId;
		}
	}

}
