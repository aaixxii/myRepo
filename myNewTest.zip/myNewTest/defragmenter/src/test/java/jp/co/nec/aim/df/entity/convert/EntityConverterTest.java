package jp.co.nec.aim.df.entity.convert;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.df.entity.Segment;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.entity.convert.EntityConverter;

import org.junit.Assert;
import org.junit.Test;

/**
 * 
 * @author liuyq
 * 
 */
public class EntityConverterTest {

    /**
     * testConvertSegments
     */
    @Test
    public void testConvertSegments() {
        List<SegmentSummary> segSummarys = new ArrayList<SegmentSummary>();
        SegmentSummary seg1 = new SegmentSummary(1, 1L, 1000L, 2000L, 1000L, 1000, 1000, 123456L,
                123456L, false, 1.0d);
        segSummarys.add(seg1);

        SegmentSummary seg2 = new SegmentSummary(1, 2L, 1000L, 2000L, 500L, 1000, 1000,
                10000L + 26L, 20000L + 26L, false, 0.5d);
        segSummarys.add(seg2);

        List<Segment> segments = EntityConverter.convertSegments(segSummarys, "SDBL");
        Assert.assertEquals(5, segments.size());

        Segment segment1 = segments.get(0);
        Assert.assertEquals(segment1.getContainerId(), "1");
        Assert.assertEquals(segment1.getFormatName(), "SDBL");
        Assert.assertEquals(segment1.getRecord(), "1000");
        Assert.assertEquals(segment1.getRegistRatio(), "[#####################] 100.00%");
        Assert.assertEquals(segment1.getRegistSegSize(), "0.12/0.12(MB)");
        Assert.assertEquals(segment1.getSegmentId(), "1");

        Segment segment2 = segments.get(1);
        Assert.assertEquals(segment2.getContainerId(), "1");
        Assert.assertEquals(segment2.getFormatName(), "SDBL");
        Assert.assertEquals(segment2.getRecord(), "500");
        Assert.assertEquals(segment2.getRegistRatio(), "[##########           ] 50.00%");
        Assert.assertEquals(segment2.getRegistSegSize(), "0.01/0.02(MB)");
        Assert.assertEquals(segment2.getSegmentId(), "2");

        Segment segment3 = segments.get(2);
        Assert.assertEquals(segment3.getContainerId(), "");
        Assert.assertEquals(segment3.getFormatName(), "");
        Assert.assertEquals(segment3.getRecord(), "");
        Assert.assertEquals(segment3.getRegistRatio(), " _____________________");
        Assert.assertEquals(segment3.getRegistSegSize(), "");
        Assert.assertEquals(segment3.getSegmentId(), "");

        Segment segment4 = segments.get(3);
        Assert.assertEquals(segment4.getContainerId(), "");
        Assert.assertEquals(segment4.getFormatName(), "");
        Assert.assertEquals(segment4.getRecord(), "");
        Assert.assertEquals(segment4.getRegistRatio(), " |         |         |");
        Assert.assertEquals(segment4.getRegistSegSize(), "");
        Assert.assertEquals(segment4.getSegmentId(), "");

        Segment segment5 = segments.get(4);
        Assert.assertEquals(segment5.getContainerId(), "");
        Assert.assertEquals(segment5.getFormatName(), "");
        Assert.assertEquals(segment5.getRecord(), "");
        Assert.assertEquals(segment5.getRegistRatio(), " 0%       50%       100%    ");
        Assert.assertEquals(segment5.getRegistSegSize(), "");
        Assert.assertEquals(segment5.getSegmentId(), "");
    }
}
