package jp.co.nec.aim.df.util;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.util.ToolConsoleUtil;
import junit.framework.Assert;

import org.junit.Test;

public class ToolConsoleUtilTest {

    private static final String BR = System.getProperty("line.separator");

    @Test(expected = IllegalArgumentException.class)
    public void testDisplaySegmentsParaIsNull() {
        ToolConsoleUtil.displaySegments(null);
    }

    @Test
    public void testDisplaySegmentsIsEmpty() {
        final ContainerSummary para = new ContainerSummary();
        String ret = ToolConsoleUtil.displaySegments(para);
        Assert.assertEquals(null, ret);
    }

    @Test
    public void testDisplaySegmentsNormal() {
        final ContainerSummary para = new ContainerSummary();

        List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
        segments.add(new SegmentSummary(1, 1L, 1L, 10L, 10L, 100, 100, 1234L, 1234L, false, 1d));
        segments.add(new SegmentSummary(1, 2L, 1L, 11L, 20L, 100, 100, 1234L, 1234L, false, 1d));
        segments.add(new SegmentSummary(1, 3L, 1L, 21L, 30L, 100, 100, 1234L, 1234L, false, 1d));
        segments.add(new SegmentSummary(1, 4L, 1L, 31L, 40L, 100, 100, 1234L, 1234L, false, 1d));

        para.addSegmentList(segments);

        String ret = ToolConsoleUtil.displaySegments(para);
        Assert.assertEquals(expectRet1, ret.replaceAll(BR, ""));
    }

    private static final String expectRet1 = "=================================================================================================================================="
            + "CONTAINER_ID    CONTAINER_NAME        SEG_ID    REGIST_RATIO                                      REGIST_SIZE/SEG_SIZE          RECORD    "
            + "=================================================================================================================================="
            + "1               null                  1         [#####################] 100.00%                   0.00/0.00(MB)                 10        "
            + "1               null                  2         [#####################] 100.00%                   0.00/0.00(MB)                 20        "
            + "1               null                  3         [#####################] 100.00%                   0.00/0.00(MB)                 30        "
            + "1               null                  4         [#####################] 100.00%                   0.00/0.00(MB)                 40        "
            + "                                                 _____________________                                                                    "
            + "                                                 |         |         |                                                                    "
            + "                                                 0%       50%       100%                                                                  ";

}
