package jp.co.nec.aim.df.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;

import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.TotalInformation;
import jp.co.nec.aim.df.exception.ConsoleException;
import jp.co.nec.aim.df.util.ConsoleUtil.FieldAndFormat;
import mockit.Mock;
import mockit.MockUp;

public class ConsoleUtilTest {
	private static final String BR = System.getProperty("line.separator");

	@Rule
	public TestName name = new TestName();

	private DataCreatorUtil creator;

	@Before
	public void setUp() {
		if (creator == null) {
			creator = new DataCreatorUtil();
		}
	}

	@Test
	public void testDisplayContainerInfo_normally() {
		final String expectResult = "Container Total Information"
				+ BR
				+ "totalContainerCount 21         totalSegmentCount 1212       totalBinarySize 12121212  "
				+ BR;
		TotalInformation information = new TotalInformation(21, 1212, 12121212L);
		String ret = ConsoleUtil.displayContainerInfo(information);
		assertEquals(ret, expectResult);
	}

	@Test
	public void testDisplayContainerInfo_fieldIsNull() {
		final String expectResult = "Container Total Information"
				+ BR
				+ "totalContainerCount null       totalSegmentCount null       totalBinarySize null      "
				+ BR;
		TotalInformation information = new TotalInformation();
		String ret = ConsoleUtil.displayContainerInfo(information);
		assertEquals(ret, expectResult);
	}

	@Test
	public void testDisplayContainerList_ParaIsnull() {
		assertEquals(ConsoleUtil.displayContainerList(null), "");
	}

	@Test(expected = IllegalArgumentException.class)
	public void testDisplayContainerInfo_ParaIsnull() {
		assertEquals(ConsoleUtil.displayContainerInfo(null), "");
	}

	@Test
	public void testDisplayContainerList_ParaIsEmpty() {
		assertEquals(
				ConsoleUtil
						.displayContainerList(new ArrayList<ContainerSummary>()),
				"");
	}

	@Test(expected = ConsoleException.class)
	public void testDisplayContainerList_Exception() {

		List<ContainerSummary> containers = creator.createContainerList();
		try {
			new MockUp<FieldAndFormat>() {
				@Mock
				public String getFormatType() {
					throw new ConsoleException("");
				}

			};
			ConsoleUtil.displayContainerList(containers).replaceAll(BR, "");
		} finally {			
		}
	}

	@Test
	public void testDisplayContainerList_WorstSegmentIsNull() {
		final String expectResult = "Container Summary"
				+ "=================================================================================================================================="
				+ "Container Id    scope     Format Name     Segment Number    Fragment Radio      Worst Three Segment           "
				+ "=================================================================================================================================="
				+ "1               1         formatName1     1                 1%                  null                          "
				+ "2               1         formatName2     2                 2%                  null                          "
				+ "3               1         formatName3     3                 3%                  null                          "
				+ "4               1         formatName4     4                 4%                  null                          "
				+ "5               1         formatName5     5                 5%                  null                          "
				+ "6               1         formatName6     6                 6%                  null                          "
				+ "7               1         formatName7     7                 7%                  null                          "
				+ "8               1         formatName8     8                 8%                  null                          "
				+ "9               1         formatName9     9                 9%                  null                          "
				+ "10              1         formatName10    10                10%                 null                          ";

		List<ContainerSummary> containers = creator
				.createContainerList_worstSegmentIsNull();
		String result = ConsoleUtil.displayContainerList(containers)
				.replaceAll(BR, "");
		assertEquals(result, expectResult);
	}

	@Test
	public void testDisplayContainerListForSeg_paraIsNull() {
		try {
			ConsoleUtil.displayContainerSegments(null);
		} catch (IllegalArgumentException ex) {
			assertEquals(ex.getMessage(),
					"the container list can not be displayed "
							+ "due to the container list is null or empty..");
		}
	}

	@Test
	public void testDisplayContainerListForSeg_DetailListIsEmpty() {
		try {
			List<ContainerSummary> containers = new ArrayList<ContainerSummary>();
			ConsoleUtil.displayContainerSegments(containers);
		} catch (IllegalArgumentException ex) {
			assertEquals(ex.getMessage(),
					"the container list can not be displayed "
							+ "due to the container list is null or empty..");
		}
	}

	@Test
	public void testDisplayContainerListForSeg_normally() {
		final String expectResult = "Segment Summary"
				+ "=================================================================================================================================="
				+ "Container Id    Seg Id  Data Radio  Frag Radio  Start Id  End Id  Records  version   reVersion   blCompacted  blunCompacted  willbeDeleted"
				+ "=================================================================================================================================="
				+ "1               1       0.52        0.48        1         22      10       34        34          88476        194616         false     "
				+ "1               2       0.45        0.55        23        44      10       34        34          88476        194616         false     "
				+ "1               3       0.25        0.75        45        66      10       34        34          88476        194616         false     "
				+ "1               4       0.25        0.75        47        88      10       34        34          88476        194616         false     "
				+ "1               5       0.25        0.75        89        110     10       34        34          88476        194616         false     ";

		List<ContainerSummary> containers = creator.create1Container5Segment();
		String ret = ConsoleUtil.displayContainerSegments(containers)
				.replaceAll(BR, "");
		assertEquals(expectResult, ret);
	}

	@Test(expected = ConsoleException.class)
	public void testDisplayContainerListForSeg_Exception() {

		List<ContainerSummary> containers = creator.create1Container5Segment();
		try {
			new MockUp<FieldAndFormat>() {
				@Mock
				public String getFormatType() {
					throw new ConsoleException("");
				}

			};
			ConsoleUtil.displayContainerSegments(containers).replaceAll(BR, "");
		} finally {			
		}
	}

	@Test
	public void testDisplayPlan_paraIsNull() {
		try {
			ConsoleUtil.displayPlan(null);
		} catch (IllegalArgumentException ex) {
			assertEquals(ex.getMessage(), "the PLAN list can not be displayed "
					+ "due to the PLAN list is null or empty..");
		}
	}

	@Test
	public void testDisplayPlan_PlanIsEmpty() {
		try {
			ConsoleUtil.displayPlan(new ArrayList<Plan>());
		} catch (IllegalArgumentException ex) {
			assertEquals(ex.getMessage(), "the PLAN list can not be displayed "
					+ "due to the PLAN list is null or empty..");
		}
	}

	@Test
	public void testDisplayPlan_Normally() {
		final String expectResult = "PLAN Summary"
				+ "=================================================================================================================================="
				+ "joint     container Id    first SegId    max Segment Size    max Segment Diff    "
				+ "=================================================================================================================================="
				+ "2         1               1              200000              1000                "
				+ "3         1               1              200000              1000                "
				+ "Segment Summary"
				+ "=================================================================================================================================="
				+ "Container Id    Seg Id  Data Radio  Frag Radio  Start Id  End Id  Records  version   reVersion   blCompacted  blunCompacted  willbeDeleted"
				+ "=================================================================================================================================="
				+ "1               1       0.44238     0.55762     1         22      10       34        34          88476        194616         false     "
				+ "1               1       0.44238     0.55762     23        44      8        36        36          70786        194616         false     "
				+ "Segment Summary"
				+ "=================================================================================================================================="
				+ "Container Id    Seg Id  Data Radio  Frag Radio  Start Id  End Id  Records  version   reVersion   blCompacted  blunCompacted  willbeDeleted"
				+ "=================================================================================================================================="
				+ "1               1       0.3098      0.6902      1         22      7        37        37          61960        194616         false     "
				+ "1               2       0.3098      0.6902      23        44      7        37        37          61960        194616         false     "
				+ "1               3       0.3098      0.6902      45        66      7        37        37          61960        194616         false     ";

		List<Plan> plans = creator.createDisplayPlan();
		String ret = ConsoleUtil.displayPlan(plans).replaceAll(BR, "");

		assertEquals(ret, expectResult);
	}

	@Test(expected = ConsoleException.class)
	public void testDisplayPlan_Exception() {

		List<Plan> plans = creator.createDisplayPlan();
		try {
			new MockUp<FieldAndFormat>() {
				@Mock
				public String getFormatType() {
					throw new ConsoleException("");
				}

			};
			ConsoleUtil.displayPlan(plans).replaceAll(BR, "");
		} finally {			
		}

	}

	@Test
	public void testDisplayPlan_AllFieldNull() {
		final String expectResult = "PLAN Summary"
				+ "=================================================================================================================================="
				+ "joint     container Id    first SegId    max Segment Size    max Segment Diff    "
				+ "=================================================================================================================================="
				+ "0         0               0              0                   0                   "
				+ "0         0               0              0                   0                   "
				+ "Segment Summary"
				+ "=================================================================================================================================="
				+ "Container Id    Seg Id  Data Radio  Frag Radio  Start Id  End Id  Records  version   reVersion   blCompacted  blunCompacted  willbeDeleted"
				+ "=================================================================================================================================="
				+ "null            null    null        null        null      null    null     null      null        null         null           false     "
				+ "Segment Summary"
				+ "=================================================================================================================================="
				+ "Container Id    Seg Id  Data Radio  Frag Radio  Start Id  End Id  Records  version   reVersion   blCompacted  blunCompacted  willbeDeleted"
				+ "=================================================================================================================================="
				+ "null            null    null        null        null      null    null     null      null        null         null           false     ";

		List<Plan> plans = creator.createDisplayPlanFiledIsNull();
		String ret = ConsoleUtil.displayPlan(plans).replaceAll(BR, "");
		assertEquals(ret, expectResult);
	}

	@Test
	public void testDisplayHeader() {
		final String expectResult = "**********************************************************************************************************************************"
				+ "                                                    AIM Defragmentation System                                                    "
				+ "**********************************************************************************************************************************";

		String header = ConsoleUtil.displayHeader().replaceAll(BR, "");
		assertTrue(header.contains(expectResult));

	}
}
