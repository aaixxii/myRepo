package jp.co.nec.aim.df.dao;

import static org.junit.Assert.assertNull;

import javax.annotation.Resource;

import jp.co.nec.aim.df.exception.DefragmentDaoException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class SystemInitDaoTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	private static SystemInitDao dao = DaoFactory
			.createDao(SystemInitDao.class);

	@Before
	public void setUp() {
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() {
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("commit");
	}

	@Test(expected=DefragmentDaoException.class)
	public void testGetMultiBootFlag_withNoRecord() {
		assertNull(dao.lockAndGetMultiBootFlag());
	}
}
