package jp.co.nec.aim.df.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.data.DataGeneration;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.service.ContainerInitService;
import jp.co.nec.aim.df.service.MakePlanService;
import jp.co.nec.aim.df.service.PollFindJobService;
import jp.co.nec.aim.df.util.ConnectionUtil;
import jp.co.nec.aim.df.util.ConsoleUtil;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class PollFindJobDaoTest {

	@Resource
	private JdbcTemplate jdbcTemplate;
	private static PollFindJobDao dao;

	static ContainerInitService initService = new ContainerInitService();
	MakePlanService makePlanService = new MakePlanService();
	List<ContainerSummary> containerList;
	List<Plan> planArray;
	static int times = 5;
	static boolean bJobNotWorking = false;
	PollFindJobService pollfindjobservice;
	Plan plan;
	private static Connection con;
	DataSource ds = DataSourceCreator.getInstance().getDataSource();

	@BeforeClass
	public static void init() {
		dao = DaoFactory.createDao(PollFindJobDao.class);
	}

	@Before
	public void setUp() throws Exception {

		try {
			if (con == null) {
				con = ds.getConnection();
			}
		} catch (SQLException e) {
			String message = "can not get connection from datasource..";
			throw new DefragmentServiceException(message);
		}

		DataGeneration.deleteInformation(jdbcTemplate);
		DataGeneration.insertTotalInformation(jdbcTemplate);
		DataGeneration.deleteItem(jdbcTemplate, times);

		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			planArray = makePlanService.makePlan(container);
			ConsoleUtil.displayPlan(planArray);
		}

	}

	@After
	public void tearDown() throws Exception {
		DataGeneration.deleteInformation(jdbcTemplate);
		planArray.clear();		
	}
	
	@AfterClass
	public static void afterClass() {
		ConnectionUtil.close(con);
		DataSourceCreator.getInstance().shutdownDataSource();
	}

	@Test(expected = DefragmentDaoException.class)
	public void test_findJobStatus_Exception() {
		plan = planArray.get(0);
		DataGeneration.insert_JOB(jdbcTemplate, 1);

		new MockUp<BaseDao>() {
			
			@Mock
			protected void prepareStatementCon(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException("");
			}

		};
		try {
			dao.findJobStatus(1, 3, 1);
		} finally {			
		}
	}
}
