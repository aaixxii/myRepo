package jp.co.nec.aim.df.dao;

import static junit.framework.Assert.fail;
import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.util.ConnectionUtil;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class PersistSegmentDaoTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Rule
	public TestName name = new TestName();

	private static PersistSegmentDao dao;
	private static ContainerAnalysisDao analysisDao;
	private static Connection con;

	@BeforeClass
	public static void setDaoAndConnection() throws SQLException {
		con = DataSourceCreator.getInstance().getDataSource().getConnection();
		dao = DaoFactory.createDao(PersistSegmentDao.class, con);
		analysisDao = DaoFactory.createDao(ContainerAnalysisDao.class);
	}

	@AfterClass
	public static void closeConnection() {
		ConnectionUtil.close(con);
	}

	private void clearSegmentData() {
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	private static DataCreatorUtil creator;

	@Before
	public void setup() {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}

		clearSegmentData();
		final String methodName = name.getMethodName();
		if (methodName.equalsIgnoreCase("testDeleteExistSegment")) {
			creator.createSegmentWithId(1111L);
		} else if (methodName
				.equalsIgnoreCase("testDeleteExistSegmentVersionIsNotmatch")) {
			creator.createSegmentWithId(1111L);
		} else if (methodName.equalsIgnoreCase("testUpdateSegmentAll")) {
			creator.createSegmentWithId(2222L);
		} else if (methodName
				.equalsIgnoreCase("testUpdateSegmentAllIsNotMatchVersion")) {
			creator.createSegmentWithId(2222L);
		} else if (methodName.equalsIgnoreCase("testUpdateSegmentFromTo")) {
			creator.createSegmentWithId(2222L);
		} else if (methodName
				.equalsIgnoreCase("testLockRowAndGetVersion_with3Segments")
				|| methodName
						.equalsIgnoreCase("testLockRowAndGetVersion_checkSegmentsLocked_commit")
				|| methodName
						.equalsIgnoreCase("testLockRowAndGetVersion_checkSegmentsLocked_rollback")) {
			creator.createSegmentWithId(1111L);
			creator.createSegmentWithId(2222L);
			creator.createSegmentWithId(3333L);
		} else if (methodName
				.equalsIgnoreCase("testLockAndGetContainerId_WithRecord")
				|| methodName
						.equalsIgnoreCase("testLockAndGetContainerId_WithRecord_checkLocked_commit")
				|| methodName
						.equalsIgnoreCase("testLockAndGetContainerId_WithRecord_checkLocked_rollback")) {
			creator.setDefragContainerId(111L);
		} 
		jdbcTemplate.execute("commit");
	}

	@After
	public void after() {
		ConnectionUtil.commit(con);
		clearSegmentData();
	}

	@AfterClass
	public static void afterClass() {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
	}

	@Test
	public void testDeleteUnExistSegment() {
		SegmentSummary segment = creator.createSegmentSummaryEmpty();
		int count = dao.deleteSegment(segment);
		assertEquals(count, 0);
	}

	@Test
	public void testDeleteExistSegment() {
		SegmentSummary segment = new SegmentSummary();
		segment.setSegId(1111L);
		segment.setVersion(3400);
		segment.setReVersion(3400);
		segment.setVersionBackUp(34);
		segment.setReVersionBackUp(34);

		int count = dao.deleteSegment(segment);
		assertEquals(count, 1);
	}

	@Test(expected = DefragmentDaoException.class)
	public void testDeleteExistSegment_Exception() {
		SegmentSummary segment = new SegmentSummary();
		segment.setSegId(1111L);
		segment.setVersion(3400);
		segment.setReVersion(3400);
		segment.setVersionBackUp(34);
		segment.setReVersionBackUp(34);

		MockUp<BaseDao> mocked = new MockUp<BaseDao>() {
			@Mock
			protected void prepareStatementCon(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException("");
			}
		};

		try {
			int count = dao.deleteSegment(segment);
			assertEquals(count, 1);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testUpdateSegmentSegmentIdIsMissing() {
		try {
			dao.updateSegment(new SegmentSummary());
		} catch (DefragmentDaoException ex) {
			assertEquals(ex.getMessage(),
					"the segment id is null while update the segment");
			return;
		}
		fail();
	}

	@Test
	public void testUpdateSegmentNoColumToUpdate() {
		SegmentSummary segment = creator.createSegmentSummaryOnlyId();
		try {
			dao.updateSegment(segment);
		} catch (DefragmentDaoException ex) {
			assertEquals(
					ex.getMessage(),
					"jp.co.nec.aim.df.exception.DefragmentDaoException: "
							+ "at least one colum is required while update segment..");
			return;
		}
		fail();
	}

	@Test
	public void testUpdateSegmentFromTo() {
		final long segmentId = 2222L;

		SegmentSummary segment = creator
				.createSegmentSummaryStartEndId(segmentId);
		int count = dao.updateSegment(segment);
		assertEquals(count, 1);
		ConnectionUtil.commit(con);

		List<SegmentSummary> segments = analysisDao.getSegmentSummary(1);
		assertEquals(segments.size(), 1);

		SegmentSummary segmentFormDataBase = segments.get(0);
		assertEquals(segment.getSegId().intValue(), segmentFormDataBase
				.getSegId().intValue());
		assertEquals(segment.getStartId().intValue(), segmentFormDataBase
				.getStartId().intValue());
		assertEquals(segment.getEndId().intValue(), segmentFormDataBase
				.getEndId().intValue());
	}

	@Test
	public void testUpdateSegmentAll() {
		final long segmentId = 2222L;

		SegmentSummary segment = creator.createSegmentSummaryAll(segmentId);
		int count = dao.updateSegment(segment);
		assertEquals(count, 1);
		ConnectionUtil.commit(con);

		List<SegmentSummary> segments = analysisDao.getSegmentSummary(1);
		assertEquals(segments.size(), 1);

		SegmentSummary segmentFormDataBase = segments.get(0);
		assertEquals(segment.getContainerId().intValue(), segmentFormDataBase
				.getContainerId().intValue());
		assertEquals(segment.getSegId().intValue(), segmentFormDataBase
				.getSegId().intValue());
		assertEquals(segment.getStartId().intValue(), segmentFormDataBase
				.getStartId().intValue());
		assertEquals(segment.getEndId().intValue(), segmentFormDataBase
				.getEndId().intValue());
		assertEquals(segment.getRecordCount().intValue(), segmentFormDataBase
				.getRecordCount().intValue());
		assertEquals(segment.getVersion().intValue(), segmentFormDataBase
				.getVersion().intValue());
		assertEquals(segment.getReVersion().intValue(), segmentFormDataBase
				.getReVersion().intValue());
		assertEquals(segment.getBlCompacted().intValue(), segmentFormDataBase
				.getBlCompacted().intValue());
		assertEquals(segment.getBlunCompacted().intValue(), segmentFormDataBase
				.getBlunCompacted().intValue());
	}

	@Test
	public void testUpdateSegmentAllIsNotMatchVersion() {
		final long segmentId = 2222L;
		SegmentSummary segment = creator
				.createSegmentSummaryAllIsNotMatchVersion(segmentId);
		int count = dao.updateSegment(segment);
		assertEquals(count, 0);
	}
}
