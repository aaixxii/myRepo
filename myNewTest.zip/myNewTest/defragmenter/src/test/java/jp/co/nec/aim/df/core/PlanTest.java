package jp.co.nec.aim.df.core;

import java.util.ArrayList;
import java.util.Collection;

import jp.co.nec.aim.df.entity.SegmentSummary;
import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

public class PlanTest {

	private static Plan plan = null;

	@BeforeClass
	public static void beforeClass() {
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		plan = new Plan(1, 1, 20000, 1000, segments);
	}

	@Test
	public void testWillMergerSegsIsEmpty() {
		Assert.assertEquals(plan.getFirstSegId(), 0L);
	}

	@Test
	public void testgetFirstSegmentStartIdIsUnderZero() {
		Assert.assertEquals(plan.getFirstSegmentStartId(), -1L);
	}

	@Test
	public void testgetLastSegmentEndIdIsUnderZero() {
		Assert.assertEquals(plan.getLastSegmentEndId(), -1L);
	}
}
