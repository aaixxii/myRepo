package jp.co.nec.aim.df.service;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.df.common.HttpTestServer;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.util.PropertiesUtil;
import junit.framework.Assert;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class StatusCheckerServiceTest {

	private static HttpTestServer _server;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private DataCreatorUtil creator;

	@BeforeClass
	public static void init() throws Exception {
		_server = new HttpTestServer(55513);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void after() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	@Before
	public void setUp() {
		creator = new DataCreatorUtil(jdbcTemplate);
		clearData();
	}

	@After
	public void tearDown() {
		clearData();
	}

	private void clearData() {
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	private static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {

				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				response.setStatus(200);
				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}

	@Test
	public void testIsMMFlowControlStatusOk_FlowControlIsTrueAndMMCareIsTrueAndMMisAlive() {
//		creator.insertSystemInitflowcontrol("true");
//		jdbcTemplate.execute("commit");

		try {
			new MockUp<PropertiesUtil>() {
				@Mock
				public boolean getMmCare() {
					return true;
				}
			};
			StatusCheckerService flowservice = new StatusCheckerService();
			Assert.assertTrue(flowservice.isMMStatusOk());
		} finally {			
		}
	}
	
	@Test
	public void testIsMMFlowControlStatusOk_FlowControlIsTrueAndMMCareIsTrueAndMMisNotAlive() {
		try {
			new MockUp<PropertiesUtil>() {
				@Mock
				public String getMmPort() {
					return "1234";
				}
				
				@Mock
				public boolean getMmCare() {
					return true;
				}
			};
			
			
//			creator.insertSystemInitflowcontrol("true");
//			jdbcTemplate.execute("commit");

			StatusCheckerService flowservice = new StatusCheckerService();
			
			Assert.assertFalse(flowservice.isMMStatusOk());
		} finally {			
		}
	}
	
	
	@Test
	public void testIsMMFlowControlStatusOk_FlowControlIsTrueAndMMCareIsfalseAndMMisAlive() {
//		creator.insertSystemInitflowcontrol("true");
//		jdbcTemplate.execute("commit");

		try {
			new MockUp<PropertiesUtil>() {
				@Mock
				public boolean getMmCare() {
					return false;
				}
			};
			StatusCheckerService flowservice = new StatusCheckerService();
			Assert.assertTrue(flowservice.isMMStatusOk());
		} finally {			
		}
	}
	

	@Test
	public void testIsMMFlowControlStatusOk_FlowControlIsTrueAndMMCareIsfalseAndMMisNotAlive() {
		try {
			new MockUp<PropertiesUtil>() {
				@Mock
				private String getMmPort() {
					return "1234";
				}
				
				@Mock
				public boolean getMmCare() {
					return false;
				}
			};

//			creator.insertSystemInitflowcontrol("true");
//			jdbcTemplate.execute("commit");

			StatusCheckerService flowservice = new StatusCheckerService();
			Assert.assertTrue(flowservice.isMMStatusOk());
		} finally {			
		}
	}
	
	@Test
	public void testIsMMFlowControlStatusOk_MMCareIsTrueAndMMisAlive() {
		try {
			new MockUp<PropertiesUtil>() {				
				@Mock
				private boolean getMmCare() {
					return true;
				}
			};

			StatusCheckerService flowservice = new StatusCheckerService();

			Assert.assertTrue(flowservice.isMMStatusOk());
		} finally {			
		}
	}
	
	
	@Test
	public void testIsMMFlowControlStatusOk_FlowControlIsFalseAndMMCareIsTrueAndMMisnotAlive() {
//		creator.insertSystemInitflowcontrol("false");
//		jdbcTemplate.execute("commit");

		try {
			new MockUp<PropertiesUtil>() {
				@Mock
				private String getMmPort() {
					return "1234";
				}
				
				@Mock
				private boolean getMmCare() {
					return true;
				}
			};

			StatusCheckerService flowservice = new StatusCheckerService();

			Assert.assertFalse(flowservice.isMMStatusOk());
		} finally {			
		}
	}
	
	
	@Test
	public void testIsMMFlowControlStatusOk_FlowControlIsFalseAndMMCareIsfalseAndMMisAlive() {
		try {
			new MockUp<PropertiesUtil>() {
				@Mock
				private boolean getMmCare() {
					return false;
				}
			};

			StatusCheckerService flowservice = new StatusCheckerService();

			Assert.assertTrue(flowservice.isMMStatusOk());
		} finally {			
		}
	}
	
	
	@Test
	public void testIsMMFlowControlStatusOk_FlowControlIsFalseAndMMCareIsfalseAndMMisnotAlive() {
		try {
			new MockUp<PropertiesUtil>() {
				@Mock
				private String getMmPort() {
					return "1234";
				}
				
				@Mock
				private boolean getMmCare() {
					return false;
				}
			};

			StatusCheckerService flowservice = new StatusCheckerService();

			Assert.assertTrue(flowservice.isMMStatusOk());
		} finally {			
		}
	}
}
