package jp.co.nec.aim.df.dao;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.exception.DefragmentServiceException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class RUCDaoTest {

	private RUCDao dao;
	private static DataCreatorUtil creator;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private static Connection con;
	DataSource ds = DataSourceCreator.getInstance().getDataSource();

	@Before
	public void setUp() throws Exception {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}

		try {
			if (con == null) {
				con = ds.getConnection();
			}
		} catch (SQLException e) {
			String message = "can not get connection from datasource..";
			throw new DefragmentServiceException(message);
		}

		dao = DaoFactory.createDao(RUCDao.class, this.con);
		jdbcTemplate.execute("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.update("commit");
	}

	@Test
	public void test() {
		creator.cleanAndSetRUC();
		jdbcTemplate.update("commit");

		dao.increaseRUC();
		assertEquals(2, creator.getRUC().intValue());
		dao.increaseRUC();
		assertEquals(3, creator.getRUC().intValue());
		
		dao.increaseRUC();
		assertEquals(4, creator.getRUC().intValue());
	}

}
