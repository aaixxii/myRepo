package jp.co.nec.aim.df.dao;

import java.sql.Connection;

import javax.sql.DataSource;

public class DaoFactoryTestClass {

	// ///////////////////////////////////////////////////
	// /////////////////create dAO with not connection////
	// ///////////////////////////////////////////////////
	public static abstract class AbstractClassInstantiationException {
	}

	public static class ClassNoSuchMethodException {
	}

	public static class ClassMethodWithInvocationTargetException {
		public void setInitParams(DataSource dataSource) {
			throw new NullPointerException();
		}
	}

	public static class ClassMethodWithIllegalAccessException {

		public ClassMethodWithIllegalAccessException() {

		}

		public void setInitParams(DataSource dataSource) {

		}
	}

	// ///////////////////////////////////////////////////
	// /////////////////create dAO with connection///////
	// ///////////////////////////////////////////////////
	public static abstract class AbstractClassConInstantiationException {
	}

	public static class ClassConNoSuchMethodException {
	}

	public static class ClassConMethodWithInvocationTargetException {
		public void setInitParams(Connection connection) {
			throw new NullPointerException();
		}
	}

	public static class ClassConMethodWithIllegalAccessException {
		private ClassConMethodWithIllegalAccessException() {
		}

		public void setInitParams(Connection connection) {
		}
	}

}
