package jp.co.nec.aim.df.util;

import static junit.framework.Assert.assertEquals;

import org.junit.Test;

public class PropertiesUtilTest {

	@Test
	public void testPropertiesUtilAllFiled() {
		assertEquals("oracle.jdbc.driver.OracleDriver",
				PropertiesUtil.getJdbcDriverclassname());
		assertEquals(false, PropertiesUtil.getJdbcDefaultautocommit());
		assertEquals(10, PropertiesUtil.getJdbcMaxactive());
		assertEquals(20, PropertiesUtil.getJdbcMaxidle());
		assertEquals(1000, PropertiesUtil.getJdbcMaxwait());
		assertEquals(20, PropertiesUtil.getJdbcMinidle());

		assertEquals("http://127.0.0.1:55513/test", PropertiesUtil.getMMUrl());
		assertEquals(false, PropertiesUtil.getMmCare());

		assertEquals(5, PropertiesUtil.getMaxJoint());
		assertEquals(2000, PropertiesUtil.getConnectionTimeout());
		assertEquals(2000, PropertiesUtil.getSocketTimeout());
		assertEquals(26, PropertiesUtil.getSegmentHeaderLength());
		assertEquals(14, PropertiesUtil.getTemplateHeaderLength());
		assertEquals(3, PropertiesUtil.getRetryExecutionCount());
		assertEquals(100, PropertiesUtil.getMaxPlanSize());
		assertEquals(20000, PropertiesUtil.getPollContainerJobsTimeout());
	}
}
