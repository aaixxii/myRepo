package jp.co.nec.aim.df.service;

import javax.annotation.Resource;

import jp.co.nec.aim.df.data.DataCreatorUtilSimilor;
import jp.co.nec.aim.df.service.DisplaySegmentService;
import jp.co.nec.aim.df.service.ServiceFactory;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class DisplaySegmentServiceTest {

    private static final String BR = System.getProperty("line.separator");

    @Resource
    private JdbcTemplate jdbcTemplate;

    @Rule
    public TestName name = new TestName();

    private static DataCreatorUtilSimilor creator;

    @Before
    public void setup() {
        if (creator == null) {
            creator = new DataCreatorUtilSimilor(jdbcTemplate);
        }

        clearData();

        final String methodName = name.getMethodName();
        if (methodName.equalsIgnoreCase("testDisplayIsNormalAndBinIsNull")) {
            creator.createGetPersonRangeInfoMergerBeyond2SegsResultIs1();
        } else if (methodName.equalsIgnoreCase("testDisplayIsNormalAndBinIsSpecified")) {
            creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs4();
        } else if (methodName.equalsIgnoreCase("testDisplayBinIsNotFound")) {
            creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs4();
        }

        jdbcTemplate.execute("commit");
    }

    @After
    public void after() {
        clearData();
    }

    /** instance **/
    private static final DisplaySegmentService service = ServiceFactory
            .createService(DisplaySegmentService.class);

    /**
     * clear the data
     */
    private void clearData() {
        jdbcTemplate.execute("delete from segments");
        jdbcTemplate.execute("delete from person_biometrics");
        jdbcTemplate.execute("delete from segment_change_log");
        jdbcTemplate.update("commit");
    }

    @Test
    public void testTheDataIsEmptyAndContainerIdIsNull() {
        final String ret = service.display(null);
        Assert.assertEquals("", ret);
    }

    @Test
    public void testTheDataIsEmptyAndContainerIdIsSpecified() {
        final String ret = service.display(1);
        Assert.assertEquals("", ret);
    }

    @Test
    public void testDisplayIsNormalAndBinIsNull() {
        final String ret = service.display(null);
        Assert.assertEquals(expectRet1, ret.replaceAll(BR, ""));
    }

    @Test
    public void testDisplayIsNormalAndBinIsSpecified() {
        final String ret = service.display(1);
        Assert.assertEquals(expectRet2, ret.replaceAll(BR, ""));
    }

    @Test
    public void testDisplayBinIsNotFound() {
        final String ret = service.display(1212);
        Assert.assertEquals("", ret);
    }

    private final String expectRet1 = "=================================================================================================================================="
            + "CONTAINER_ID    CONTAINER_NAME        SEG_ID    REGIST_RATIO                                      REGIST_SIZE/SEG_SIZE          RECORD    "
            + "=================================================================================================================================="
            + "1               RDBT                  1         [#########            ] 45.45%                    0.08/0.19(MB)                 10        "
            + "1               RDBT                  2         [#######              ] 36.36%                    0.07/0.19(MB)                 8         "
            + "                                                 _____________________                                                                    "
            + "                                                 |         |         |                                                                    "
            + "                                                 0%       50%       100%                                                                  ";

    private final String expectRet2 = "=================================================================================================================================="
            + "CONTAINER_ID    CONTAINER_NAME        SEG_ID    REGIST_RATIO                                      REGIST_SIZE/SEG_SIZE          RECORD    "
            + "=================================================================================================================================="
            + "1               RDBT                  1         [#################    ] 81.82%                    0.15/0.19(MB)                 16        "
            + "1               RDBT                  2         [#################    ] 81.82%                    0.15/0.19(MB)                 16        "
            + "1               RDBT                  3         [#################    ] 81.82%                    0.15/0.19(MB)                 16        "
            + "1               RDBT                  4         [#################    ] 81.82%                    0.15/0.19(MB)                 16        "
            + "1               RDBT                  5         [#################    ] 81.82%                    0.15/0.19(MB)                 16        "
            + "                                                 _____________________                                                                    "
            + "                                                 |         |         |                                                                    "
            + "                                                 0%       50%       100%                                                                  ";
}
