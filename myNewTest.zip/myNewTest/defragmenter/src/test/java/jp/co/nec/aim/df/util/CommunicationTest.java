package jp.co.nec.aim.df.util;

import static org.apache.commons.io.IOUtils.write;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.AbstractHttpClient;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;

import jp.co.nec.aim.df.common.HttpTestServer;
import jp.co.nec.aim.df.exception.CommunicationException;
import junit.framework.Assert;
import mockit.Mock;
import mockit.MockUp;

public class CommunicationTest {

	private static HttpTestServer _server = null;

	private static volatile String DefragContainerId = "";
	private static volatile String status = "";
	static long time = 4000;
	static int statusCode = 200;
	Map<String, String> contain = new HashMap<String, String>();

	@BeforeClass
	public static void init() throws Exception {
		_server = new HttpTestServer(55513);
		_server.start(getMockHandler());
	}

	private static final boolean RETRY = true;

	@AfterClass
	public static void after() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {
		contain.clear();
		time = 0;
		statusCode = 200;
	}

	public static Handler getMockHandler() {

		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {

				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				try {
					System.out.println(time);
					time -= 2000;
					if (time < 0) {
						time = 0;
					}
					Thread.sleep(time);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				DefragContainerId = request.getHeader("DefragContainerId");
				status = request.getHeader("status");
				response.setStatus(statusCode);
				write("1", response.getOutputStream());
				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);

			}

		};
		return handler;
	}

	@Test
	public void testPostCommunication_NormalStop() throws Exception {
		time = 0;
		contain.put("DefragContainerId", "2");
		contain.put("status", "stop");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);
		Assert.assertEquals(DefragContainerId, "2");
		Assert.assertEquals(status, "stop");

	}

	@Test
	public void testPostCommunication_NormalStart() throws Exception {
		time = 0;
		contain.put("DefragContainerId", "1");
		contain.put("status", "start");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);
		Assert.assertEquals(DefragContainerId, "1");
		Assert.assertEquals(status, "start");

	}

	@Test
	public void testPostCommunication_Timeout1000() throws Exception {
		time = 1000;
		contain.put("DefragContainerId", "1");
		contain.put("status", "start");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);

		Assert.assertEquals(DefragContainerId, "1");
		Assert.assertEquals(status, "start");

	}

	@Test
	public void testPostCommunication_Timeout2000() throws Exception {
		time = 2000;
		contain.put("DefragContainerId", "1");
		contain.put("status", "start");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);

		Assert.assertEquals(DefragContainerId, "1");
		Assert.assertEquals(status, "start");

	}

	@Test
	public void testPostCommunication_Timeout4000() throws Exception {
		time = 4000;
		contain.put("DefragContainerId", "1");
		contain.put("status", "start");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);

		Assert.assertEquals(DefragContainerId, "1");
		Assert.assertEquals(status, "start");

	}

	@Test
	public void testPostCommunication_Timeout7000() throws Exception {
		time = 7000;
		contain.put("DefragContainerId", "1");
		contain.put("status", "start");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);

		Assert.assertEquals(DefragContainerId, "1");
		Assert.assertEquals(status, "start");

	}

	@Ignore
	@Test(expected = CommunicationException.class)
	public void testPostCommunication_Timeout10000() throws Exception {
		time = 10000;
		contain.put("DefragContainerId", "1");
		contain.put("status", "start");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);

	}

	@Test
	public void testPostCommunication_statusCode400() throws Exception {
		time = 0;
		statusCode = 400;
		contain.put("DefragContainerId", "1");
		contain.put("status", "start");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);

	}

	@Test
	public void testPostCommunication_statusCode500() throws Exception {
		time = 0;
		statusCode = 500;
		contain.put("DefragContainerId", "1");
		contain.put("status", "start");
		CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
				contain, RETRY);

	}

	@Test(expected = CommunicationException.class)
	public void testGetCommunication() throws Exception {
		contain.put("DefragContainerId", "1");
		contain.put("status", "stop");
		CommunicationUtil.postCommunication("http://127.0.0.1:2352/test",
				contain, RETRY);
	}

	@Test(expected = CommunicationException.class)
	public void testGetCommunication_IOException() throws Exception {
		MockUp<AbstractHttpClient> mocked = new MockUp<AbstractHttpClient>() {

			@Mock
			public final HttpResponse execute(HttpUriRequest request)
					throws IOException, ClientProtocolException {
				throw new IOException("");
			}
		};

		try {
			time = 0;
			contain.put("DefragContainerId", "2");
			contain.put("status", "stop");
			CommunicationUtil.postCommunication("http://127.0.0.1:55513/test",
					contain, RETRY);
			Assert.assertEquals(DefragContainerId, "2");
			Assert.assertEquals(status, "stop");
		} finally {	
			mocked.tearDown();
		}
	}

}
