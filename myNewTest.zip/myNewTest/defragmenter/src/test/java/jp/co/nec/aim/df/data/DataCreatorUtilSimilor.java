package jp.co.nec.aim.df.data;

import static jp.co.nec.aim.df.constant.SystemConstant.DEFAULT_MAX_SEGMENT_DIFFS;
import static jp.co.nec.aim.df.constant.SystemConstant.SEGMENT_HEADER_LENGTH;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * this is the common class for create the test data
 */
public final class DataCreatorUtilSimilor {
	/** insert person_biometrics sql **/
	private final static String INSERT_PERSON = "insert into person_biometrics"
			+ "(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)"
			+ " values(?,?,?,?,?,?,?,?)";

	/** insert segment sql **/
	private final static String INSERT_SEGMENTS = "insert into segments"
			+ "(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED) "
			+ "values(?,?,?,?,?,?,?,?,?)";

	/** insert max segment size sql **/
	private final static String UPDATE_MAX_SEGMENT_SIZE = "update CONTAINERS set MAX_SEGMENT_SIZE = ? where CONTAINER_ID = ?";
	
	/** the jdbcTemplate instance **/
	private JdbcTemplate jdbcTemplate;

	public static final int correctMaxSize = 20000000;

	public DataCreatorUtilSimilor() {
	}

	/**
	 * constructor
	 * 
	 * @param jdbcTemplate
	 *            jdbcTemplate
	 */
	public DataCreatorUtilSimilor(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	// ////////////////////////////////////////////////////////////////////
	// ///////////////////// create data section //////////////////////////
	// ////////////////////////////////////////////////////////////////////
	public void createGetPersonRangeInfoMergerBeyond4SegsResultIs3() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 88; i++) {
			if ((i >= 13 && i <= 22) || (i >= 35 && i <= 44)
					|| (i >= 57 && i <= 66) || (i >= 79 && i <= 88))
				continue;
			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();;
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 2, 1, 22,
				106140 + SEGMENT_HEADER_LENGTH, 12, 32, 32,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 2, 23, 44,
				106140 + SEGMENT_HEADER_LENGTH, 12, 32, 32,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 2, 45, 66,
				106140 + SEGMENT_HEADER_LENGTH, 12, 32, 32,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 2, 67, 88,
				106140 + SEGMENT_HEADER_LENGTH, 12, 32, 32,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond2SegsResultIs1
	 */
	public Plan createPlanMergerBeyond4SegsResultIs3() {
		final int joint = 2;
		final int containerid = 1;
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadio1 = (106140d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 12L, 32, 32,
				106140L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio1));

		final double dataRadio2 = (106140d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 23L, 44L, 12L, 32, 32,
				106140L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio2));

		final double dataRadio3 = (106140d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 25L, 66L, 12L, 32, 32,
				106140L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio3));

		final double dataRadio4 = (106140d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 4L, 67L, 88L, 12L, 32, 32,
				106140L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio4));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond4SegsResultIs2
	 */
	public void createGetPersonRangeInfoMergerBeyond4SegsResultIs2() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 88; i++) {
			if ((i >= 6 && i <= 22) || (i >= 28 && i <= 44)
					|| (i >= 51 && i <= 66) || (i >= 76 && i <= 88))
				continue;
			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();;
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 2, 1, 22,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 2, 23, 44,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 2, 45, 66,
				53070 + SEGMENT_HEADER_LENGTH, 6, 38, 38,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 2, 67, 88,
				79624 + SEGMENT_HEADER_LENGTH, 9, 35, 35,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond2SegsResultIs1
	 */
	public Plan createPlanMergerBeyond4SegsResultIs2() {
		final int joint = 2;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadio1 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio1));

		final double dataRadio2 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 23L, 44L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio2));

		final double dataRadio3 = (106140d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 25L, 66L, 6L, 38, 38,
				106140L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio3));

		final double dataRadio4 = (79624d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 4L, 67L, 88L, 9L, 35, 35,
				79624L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio4));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond3SegsResultIs1
	 */
	public void createGetPersonRangeInfoMergerBeyond3SegsResultIs2() {
		final int maxSegmentSize = 20000000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 66; i++) {
			if ((i >= 8 && i <= 22) || (i >= 30 && i <= 44)
					|| (i >= 54 && i <= 66))
				continue;
			if (i % 2 == 0)
				length = 881200;
			else
				length = 885000;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 2, 1, 22,
				6193400 + SEGMENT_HEADER_LENGTH, 7, 37, 37,
				19459000 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 2, 23, 44,
				6193400 + SEGMENT_HEADER_LENGTH, 7, 37, 37,
				19459000 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 2, 45, 66,
				7962400 + SEGMENT_HEADER_LENGTH, 9, 41, 41,
				19459000 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 2, 45, 66,
				7962400 + SEGMENT_HEADER_LENGTH, 9, 41, 41,
				19459000 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 5, 2, 45, 66,
				7962400 + SEGMENT_HEADER_LENGTH, 9, 41, 41,
				19459000 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond3SegsResultIs2
	 */
	public Plan createPlanMergerBeyond3SegsResultIs2() {
		final int joint = 3;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadioSeg1 = (61934d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 7L, 37, 37,
				61934L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg1));

		final double dataRadioSeg2 = (61934d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 23L, 44L, 7L, 37, 37,
				61934L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg2));

		final double dataRadioSeg3 = (79624d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 45L, 66L, 9L, 41, 41,
				79624L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg3));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond2SegsResultIs1
	 */
	public void createGetPersonRangeInfoMergerBeyond2SegsResultIs1() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 44; i++) {
			if ((i >= 11 && i <= 22) || (i >= 31 && i <= 44))
				continue;
			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 1, 1, 22,
				88450 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 1, 23, 44,
				70760 + SEGMENT_HEADER_LENGTH, 8, 36, 36,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond2SegsResultIs1
	 */
	public Plan createPlanMergerBeyond2SegsResultIs1() {
		final int joint = 2;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadio = (88450d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;

		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio));

		segments.add(new SegmentSummary(containerid, 1L, 23L, 44L, 8L, 36, 36,
				70760L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadio));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond3SegsResultIs1
	 */
	public void createGetPersonRangeInfoMergerBeyond3SegsResultIs1() {
		final int maxSegmentSize = 20000000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 66; i++) {
			if ((i >= 8 && i <= 22) || (i >= 30 && i <= 44)
					|| (i >= 51 && i <= 66))
				continue;
			if (i % 2 == 0)
				length = 881200;
			else
				length = 885000;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 1, 1, 22,
				6193400 + SEGMENT_HEADER_LENGTH, 7, 37, 37,
				19459000 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 1, 23, 44,
				6193400 + SEGMENT_HEADER_LENGTH, 7, 37, 37,
				19459000 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 1, 45, 66,
				5307000 + SEGMENT_HEADER_LENGTH, 6, 38, 38,
				19459000 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond3SegsResultIs1
	 */
	public Plan createPlanMergerBeyond3SegsResultIs1() {
		final int joint = 3;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadioSeg1 = (61934d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 7L, 37, 37,
				61934L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg1));

		final double dataRadioSeg2 = (61934d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 23L, 44L, 7L, 37, 37,
				61934L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg2));

		final double dataRadioSeg3 = (61934d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 45L, 66L, 7L, 37, 37,
				61934L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg3));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond4SegsResultIs1
	 */
	public void createGetPersonRangeInfoMergerBeyond4SegsResultIs1() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 88; i++) {
			if ((i >= 6 && i <= 22) || (i >= 28 && i <= 44)
					|| (i >= 51 && i <= 66) || (i >= 70 && i <= 88))
				continue;
			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 1, 1, 22,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 1, 23, 44,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 1, 45, 66,
				53070 + SEGMENT_HEADER_LENGTH, 6, 38, 38,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 1, 67, 88,
				26554 + SEGMENT_HEADER_LENGTH, 3, 41, 41,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond4SegsResultIs1
	 */
	public Plan createPlanMergerBeyond4SegsResultIs1() {
		final int joint = 4;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadioSeg1 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 44L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg1));

		final double dataRadioSeg2 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 45, 60L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg2));

		final double dataRadioSeg3 = (53070d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 61L, 88L, 6L, 38, 38,
				53070L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg3));

		final double dataRadioSeg4 = (26554d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 4L, 67L, 88L, 3L, 41, 41,
				26554L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, true, dataRadioSeg4));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond5SegsResultIs1
	 */
	public void createGetPersonRangeInfoMergerBeyond5SegsResultIs1() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 110; i++) {
			if ((i >= 6 && i <= 22) || (i >= 28 && i <= 44)
					|| (i >= 51 && i <= 66) || (i >= 70 && i <= 88)
					|| (i >= 90 && i <= 110))
				continue;

			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 2, 1, 22,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 2, 23, 44,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 2, 45, 66,
				53070 + SEGMENT_HEADER_LENGTH, 6, 38, 38,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 2, 67, 88,
				26554 + SEGMENT_HEADER_LENGTH, 3, 41, 41,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 5, 2, 89, 110,
				8864 + SEGMENT_HEADER_LENGTH, 1, 43, 43,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond4SegsResultIs1
	 */
	public Plan createPlanMergerBeyond5SegsResultIs1() {
		final int joint = 5;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadioSeg1 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg1));

		final double dataRadioSeg2 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 23L, 44L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg2));

		final double dataRadioSeg3 = (53070d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 45L, 66L, 6L, 38, 38,
				53070L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg3));

		final double dataRadioSeg4 = (26554d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 4L, 67L, 88L, 3L, 41, 41,
				26554L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg4));

		final double dataRadioSeg5 = (8864d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 5L, 89L, 110L, 1L, 41, 41,
				8864L + SEGMENT_HEADER_LENGTH, 194590L + SEGMENT_HEADER_LENGTH,
				false, dataRadioSeg5));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond5SegsResultIs2
	 */
	public void createGetPersonRangeInfoMergerBeyond5SegsResultIs2() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 110; i++) {
			if ((i >= 6 && i <= 22) || (i >= 28 && i <= 44)
					|| (i >= 51 && i <= 66) || (i >= 70 && i <= 88)
					|| (i >= 94 && i <= 110))
				continue;

			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 2, 1, 22,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 2, 23, 44,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 2, 45, 66,
				53070 + SEGMENT_HEADER_LENGTH, 6, 38, 38,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 2, 67, 88,
				26554 + SEGMENT_HEADER_LENGTH, 3, 41, 41,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 5, 2, 89, 110,
				44244 + SEGMENT_HEADER_LENGTH, 5, 39, 39,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond5SegsResultIs3
	 */
	public Plan createPlanMergerBeyond5SegsResultIs2() {
		final int joint = 5;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadioSeg1 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg1));

		final double dataRadioSeg2 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 23L, 44L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg2));

		final double dataRadioSeg3 = (53070d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 45L, 66L, 6L, 38, 38,
				53070L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg3));

		final double dataRadioSeg4 = (26554d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 4L, 67L, 88L, 3L, 41, 41,
				26554L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg4));

		final double dataRadioSeg5 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 5L, 89L, 110L, 5L, 39, 39,
				44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg5));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond5SegsResultIs3
	 */
	public void createGetPersonRangeInfoMergerBeyond5SegsResultIs5() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 110; i++) {

			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 1, 1, 22,
				194590 + SEGMENT_HEADER_LENGTH, 22, 22, 22,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 1, 1, 22,
				194590 + SEGMENT_HEADER_LENGTH, 22, 22, 22,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 1, 1, 22,
				194590 + SEGMENT_HEADER_LENGTH, 22, 22, 22,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 1, 1, 22,
				194590 + SEGMENT_HEADER_LENGTH, 22, 22, 22,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 5, 1, 1, 22,
				194590 + SEGMENT_HEADER_LENGTH, 22, 22, 22,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond5SegsResultIs3
	 */
	public void createGetPersonRangeInfoMergerBeyond5SegsResultIs3() {
		final int maxSegmentSize = 20000000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 110; i++) {
			if ((i >= 11 && i <= 22) || (i >= 33 && i <= 44)
					|| (i >= 55 && i <= 66) || (i >= 77 && i <= 88)
					|| (i >= 99 && i <= 110))
				continue;

			if (i % 2 == 0)
				length = 881200;
			else
				length = 885000;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 1, 1, 22,
				8845000 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 1, 23, 44,
				8845000 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 1, 45, 66,
				8845000 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 1, 67, 88,
				8845000 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 5, 1, 89, 110,
				8845000 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 6, 1, 89, 110,
				19459000 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 7, 1, 89, 110,
				19459000 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond5SegsResultIs3
	 */
	public Plan createPlanMergerBeyond5SegsResultIs3() {
		final int joint = 5;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadioSeg1 = (88450d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg1));

		final double dataRadioSeg2 = (88450d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 23L, 44L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg2));

		final double dataRadioSeg3 = (88450d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 45L, 66L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg3));

		final double dataRadioSeg4 = (88450d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 4L, 67L, 88L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg4));

		final double dataRadioSeg5 = (88450d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 5L, 89L, 110L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg5));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * createGetPersonRangeInfoMergerBeyond5SegsResultIs4
	 */
	public void createGetPersonRangeInfoMergerBeyond5SegsResultIs4() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 110; i++) {
			if ((i >= 17 && i <= 22) || (i >= 39 && i <= 44)
					|| (i >= 61 && i <= 66) || (i >= 83 && i <= 88)
					|| (i >= 105 && i <= 110))
				continue;

			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 1, 1, 22,
				159210 + SEGMENT_HEADER_LENGTH, 16, 28, 28,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 1, 23, 44,
				159210 + SEGMENT_HEADER_LENGTH, 16, 28, 28,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 3, 1, 45, 66,
				159210 + SEGMENT_HEADER_LENGTH, 16, 28, 28,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 4, 1, 67, 88,
				159210 + SEGMENT_HEADER_LENGTH, 16, 28, 28,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 5, 1, 89, 110,
				159210 + SEGMENT_HEADER_LENGTH, 16, 28, 28,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createPlanMergerBeyond5SegsResultIs4
	 */
	public Plan createPlanMergerBeyond5SegsResultIs4() {
		final int joint = 5;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadioSeg1 = (159210d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 1L, 1L, 22L, 16L, 28, 28,
				159210L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg1));

		final double dataRadioSeg2 = (159210d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 2L, 23L, 44L, 16L, 28, 28,
				159210L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg2));

		final double dataRadioSeg3 = (159210d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 3L, 45L, 66L, 16L, 28, 28,
				159210L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg3));

		final double dataRadioSeg4 = (159210d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 4L, 67L, 88L, 16L, 28, 28,
				159210L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg4));

		final double dataRadioSeg5 = (159210d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		segments.add(new SegmentSummary(containerid, 5L, 89L, 110L, 16L, 28, 28,
				159210L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg5));

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	/**
	 * CreateGetNextIdTheIdIsSeparated
	 */
	public void CreateGetNextIdTheIdIsSeparated() {
		final int maxSegmentSize = 200000;
		final int containerId = 1;
		updateMaxSegmentSize(maxSegmentSize, containerId);

		int length = 0;
		for (int i = 1; i <= 44; i++) {
			if ((i >= 11 && i <= 22) || (i >= 31 && i <= 44))
				continue;
			if (i % 2 == 0)
				length = 8812;
			else
				length = 8850;

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(INSERT_PERSON, new Object[] { i,
					"EXTERNAL_ID_" + i, "AAAAA".getBytes(), length, epochTimeNum, 0, 1,
					1 });
		}

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 1, 2, 1, 22,
				88450 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });

		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { 2, 2, 23, 44,
				70760 + SEGMENT_HEADER_LENGTH, 8, 36, 36,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createSegmentWithId
	 * 
	 * @param segmentId
	 *            segmentId
	 */
	public void createSegmentWithId(long segmentId) {
		jdbcTemplate.update(INSERT_SEGMENTS, new Object[] { segmentId, 1, 1,
				22, 88450 + SEGMENT_HEADER_LENGTH, 10, 34, 34,
				194590 + SEGMENT_HEADER_LENGTH });
	}

	/**
	 * createSegmentSummaryEmpty
	 * 
	 * @return SegmentSummary
	 */
	public SegmentSummary createSegmentSummaryEmpty() {
		SegmentSummary segment = new SegmentSummary();
		segment.setSegId(121212L);
		segment.setVersionBackUp(12);
		segment.setReVersionBackUp(12);
		return segment;
	}

	/**
	 * createSegmentSummaryOnlyId
	 */
	public SegmentSummary createSegmentSummaryOnlyId() {
		SegmentSummary segment = new SegmentSummary();
		segment.setSegId(123L);
		return segment;
	}

	/**
	 * createSegmentSummaryAll
	 */
	public SegmentSummary createSegmentSummaryAll(long segmentId) {
		return new SegmentSummary(1, segmentId, 1L, 100L, 80L, 34, 34,
				12345678L, 12345678L, false, 0.78);
	}

	/**
	 * createSegmentSummaryAll
	 */
	public SegmentSummary createSegmentSummaryAllIsNotMatchVersion(
			long segmentId) {
		return new SegmentSummary(1, segmentId, 1L, 100L, 80L, 1, 1, 12345678L,
				12345678L, false, 0.78);
	}

	/**
	 * createSegmentSummaryStartEndId
	 */
	public SegmentSummary createSegmentSummaryStartEndId(long segmentId) {
		SegmentSummary segment = new SegmentSummary();
		segment.setSegId(segmentId);
		segment.setVersionBackUp(34);
		segment.setReVersionBackUp(34);
		segment.setStartId(500L);
		segment.setEndId(1000L);
		return segment;
	}

	/**
	 * updateMaxSegmentSize
	 * 
	 * @param maxSegmentSize
	 * @param containerId
	 */
	public void updateMaxSegmentSize(final int maxSegmentSize, final int containerId) {
		// update max segment size = 200000
		jdbcTemplate.update(UPDATE_MAX_SEGMENT_SIZE, new Object[] {
				maxSegmentSize, containerId });
		jdbcTemplate.execute("commit");
	}

	/**
	 * createContainerList
	 */
	public List<ContainerSummary> createContainerList() {
		final List<ContainerSummary> containers = new ArrayList<ContainerSummary>();

		final List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		segments.add(new SegmentSummary(1, 1L, 1L, 22L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.52));
		segments.add(new SegmentSummary(1, 2L, 23L, 44L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.45));
		segments.add(new SegmentSummary(1, 3L, 45L, 66L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.25));

		for (int i = 1; i <= 10; i++) {
			final ContainerSummary container = new ContainerSummary(i, 1,
					"formatName" + i, i, i / 100d);
			container.addSegmentList(segments);
			container.setSegmentParameter();
			containers.add(container);
		}
		return containers;
	}

	/**
	 * createContainerList_worstSegmentIsNull
	 */
	public List<ContainerSummary> createContainerList_worstSegmentIsNull() {
		final List<ContainerSummary> containers = new ArrayList<ContainerSummary>();

		for (int i = 1; i <= 10; i++) {
			final ContainerSummary container = new ContainerSummary(i, 1,
					"formatName" + i, i, i / 100d);
			containers.add(container);
		}
		return containers;
	}

	/**
	 * createContainerList_fieldIsNull
	 */
	public List<ContainerSummary> createContainerList_fieldIsNull() {
		final List<ContainerSummary> containers = new ArrayList<ContainerSummary>();

		for (int i = 1; i <= 10; i++) {
			final ContainerSummary container = new ContainerSummary();
			containers.add(container);
		}
		return containers;
	}

	/**
	 * create1Container5Segment
	 */
	public List<ContainerSummary> create1Container5Segment() {
		final List<ContainerSummary> containers = new ArrayList<ContainerSummary>();

		final List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		segments.add(new SegmentSummary(1, 1L, 1L, 22L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.52));
		segments.add(new SegmentSummary(1, 2L, 23L, 44L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.45));
		segments.add(new SegmentSummary(1, 3L, 45L, 66L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.25));
		segments.add(new SegmentSummary(1, 4L, 47L, 88L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.25));
		segments.add(new SegmentSummary(1, 5L, 89L, 110L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.25));

		final ContainerSummary container = new ContainerSummary(1, 1,
				"formatName" + 1, 1, 1 / 100d);
		container.addSegmentList(segments);
		container.setSegmentParameter();
		containers.add(container);
		return containers;
	}

	/**
	 * create1Container5SegmentWithNotContinuousId
	 */
	public ContainerSummary create1Container5SegmentWithNotContinuousId() {
		final List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		segments.add(new SegmentSummary(1, 1L, 1L, 22L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.36));
		segments.add(new SegmentSummary(1, 3L, 23L, 44L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.45));
		segments.add(new SegmentSummary(1, 5L, 45L, 66L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.25));
		segments.add(new SegmentSummary(1, 7L, 47L, 88L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.25));
		segments.add(new SegmentSummary(1, 9L, 89L, 110L, 10L, 34, 34,
				88450L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, 0.25));

		final ContainerSummary container = new ContainerSummary(1, 1,
				"formatName" + 1, 1, 1 / 100d);
		container.addSegmentList(segments);
		container.setSegmentParameter();
		container.setMaxSegmentDiffs(1000);
		container.setContainerId(2);
		container.setMaxSegmetSize(2000000);

		return container;
	}

	/**
	 * createSegmentFieldNull
	 */
	public List<ContainerSummary> createSegmentFieldNull() {
		final List<ContainerSummary> containers = new ArrayList<ContainerSummary>();

		final List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		segments.add(new SegmentSummary());
		segments.add(new SegmentSummary());
		segments.add(new SegmentSummary());
		segments.add(new SegmentSummary());
		segments.add(new SegmentSummary());

		final ContainerSummary container = new ContainerSummary(1, 1,
				"formatName" + 1, 1, 1 / 100d);
		container.addSegmentList(segments);
		container.setSegmentParameter();
		containers.add(container);
		return containers;
	}

	/**
	 * createDisplayPlan
	 * 
	 * @return plan information
	 */
	public List<Plan> createDisplayPlan() {
		final List<Plan> plans = new ArrayList<Plan>();
		plans.add(createPlanMergerBeyond2SegsResultIs1());
		plans.add(createPlanMergerBeyond3SegsResultIs1());
		return plans;
	}

	/**
	 * createDisplayPlanFiledIsNull
	 * 
	 * @return List<Plan>
	 */
	public List<Plan> createDisplayPlanFiledIsNull() {
		final List<Plan> plans = new ArrayList<Plan>();
		Plan plan1 = new Plan();
		plan1.addwillMergerSegs(new SegmentSummary());
		plans.add(plan1);

		Plan plan2 = new Plan();
		plan2.addwillMergerSegs(new SegmentSummary());
		plans.add(plan2);

		return plans;
	}

	/**
	 * insertSystemInitContainerId
	 */
	public void insertSystemInitContainerId(long containerid) {
		final String sql = "insert into SYSTEM_INIT(INIT_ID, KEY_NAME, KEY_VALUE) values (?,?,?)";
		jdbcTemplate.update(sql, new Object[] { 100, "DEFRAG_CONTAINER_ID", containerid });
	}

	/**
	 * insertSystemInitMultiBootFlag
	 */
	public void insertSystemInitMultiBootFlag(String trueOrfalse) {
		final String sql = "insert into SYSTEM_INIT(INIT_ID, KEY_NAME, KEY_VALUE) values (?,?,?)";
		jdbcTemplate.update(sql, new Object[] { 500, "DEFRAG_MULTI_BOOT",
				trueOrfalse });
	}

//	/**
//	 * insertSystemInitContainerId
//	 */
//	public void insertSystemInitflowcontrol(String trueOrfalse) {
//		final String sql = "insert into SYSTEM_INIT(INIT_ID, KEY_NAME, KEY_VALUE) values (?,?,?)";
//		jdbcTemplate.update(sql, new Object[] { 101, "FLOW_CONTROL_ENABLED",
//				trueOrfalse });
//	}

	/**
	 * createOneContainer_With20segments
	 */
	public ContainerSummary createOneContainer_With20segments() {
		final List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		for (int i = 1; i <= 20; i++) {
			segments.add(new SegmentSummary(1, i, (i - 1) * 22 + 1, i * 22,
					10L, 34, 34, 88450L + SEGMENT_HEADER_LENGTH,
					194590L + SEGMENT_HEADER_LENGTH, false, 0.52));
		}
		final ContainerSummary container = new ContainerSummary(1, 1,
				"formatName" + 1, 20, 20 / 100d);
		container.addSegmentList(segments);
		container.setSegmentParameter();
		return container;
	}

	/**
	 * insertSystemInitContainerId
	 */
	public void insertSystemMaxSegmentDiff() {
		final String sql = "insert into SYSTEM_CONFIG(CONFIG_ID, PROPERTY_NAME, PROPERTY_VALUE) values (?,?,?)";
		jdbcTemplate.update(sql, new Object[] { 100,
				"BEHAVIOR.MAX_SEGMENT_DIFFS", 1500 });
	}

	/**
	 * createPlanMergerBeyond4SegsResultIs1
	 */
	public Plan createPlanMergerBeyond4SegsResultIs1_VersionIsNotMatch() {
		final int joint = 4;
		final int containerid = 1;
		
		final int maxSegmentSize = 200000;
		Collection<SegmentSummary> segments = new ArrayList<SegmentSummary>(
				joint);

		final double dataRadioSeg1 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		final SegmentSummary segment1 = new SegmentSummary(containerid, 1L, 1L, 22L,
				5L, 39, 39, 44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg1);
		segment1.setVersionBackUp(50);
		segment1.setReVersionBackUp(50);
		segments.add(segment1);

		final double dataRadioSeg2 = (44244d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		final SegmentSummary segment2 = new SegmentSummary(containerid, 2L, 23L, 44L,
				5L, 39, 39, 44244L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg2);
		segment2.setVersionBackUp(50);
		segment2.setReVersionBackUp(50);
		segments.add(segment2);

		final double dataRadioSeg3 = (53070d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		final SegmentSummary segment3 = new SegmentSummary(containerid, 3L, 45L, 66L,
				6L, 38, 38, 53070L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg3);
		segment3.setVersionBackUp(50);
		segment3.setReVersionBackUp(50);
		segments.add(segment3);

		final double dataRadioSeg4 = (26554d + SEGMENT_HEADER_LENGTH)
				/ maxSegmentSize;
		final SegmentSummary segment4 = new SegmentSummary(containerid, 4L, 67L, 88L,
				3L, 41, 41, 26554L + SEGMENT_HEADER_LENGTH,
				194590L + SEGMENT_HEADER_LENGTH, false, dataRadioSeg4);
		segment4.setVersionBackUp(50);
		segment4.setReVersionBackUp(50);
		segments.add(segment4);

		return new Plan(joint, containerid,  maxSegmentSize,
				DEFAULT_MAX_SEGMENT_DIFFS, segments);
	}

	public void insertJob() {
		final String insertContainerJobs = "insert into CONTAINER_JOBS (CONTAINER_JOB_ID,CONTAINER_ID, fusion_job_id)"
				+ " values(?, ?, ?)";
		
		final String insertFusionJobs = "insert into fusion_jobs (FUSION_JOB_ID, FUNCTION_ID, INQUIRY_JOB_DATA,"
				+ "JOB_ID, SEARCH_REQUEST_INDEX) values(?,?,?,?,?)";

		final String insertJobQueue = "insert into job_queue(JOB_ID, priority, job_state,SUBMISSION_TS,CALLBACK_STYLE,FAMILY_ID) values(?,?,?,?,?,?)";

		long epochTimeNum=System.currentTimeMillis();
		jdbcTemplate.update(insertJobQueue, new Object[] { 1, 1, 0, epochTimeNum, 0, 1 });

		jdbcTemplate.update(insertFusionJobs, new Object[] { 1, 1, "AAAAAA", 1,
				1 });

		jdbcTemplate.update(insertContainerJobs, new Object[] { 1, 2, 1 });

//		jdbcTemplate.update(insertSegmentJobs,
//				new Object[] { 1, 1, 1111, 0, 0 });
//		jdbcTemplate.update(insertSegmentJobs,
//				new Object[] { 2, 1, 2222, 0, 0 });
//		jdbcTemplate.update(insertSegmentJobs,
//				new Object[] { 3, 1, 3333, 0, 0 });

	}
}
