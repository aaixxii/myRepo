package jp.co.nec.aim.df.core;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.data.DataGeneration;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.service.ContainerInitService;
import jp.co.nec.aim.df.service.MakePlanService;
import jp.co.nec.aim.df.util.ConsoleUtil;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class DefragmentTest {

	@Resource
	JdbcTemplate jdbcTemplate;
	static ContainerInitService initService = new ContainerInitService();
	MakePlanService makePlanService = new MakePlanService();
	List<ContainerSummary> containerList;
	List<Plan> planArray = new ArrayList<Plan>();;
	static int times = 5;
	private DataCreatorUtil dataCreatorUtil = null;
	int containId = 1;
	private static DataCreatorUtil creator;

	@AfterClass
	public static void afterClass() {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
	}

	@Before
	public void setUp() throws Exception {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}
		creator.updateMaxSegmentSize(200000, 1);
		DataGeneration.deleteInformation(jdbcTemplate);
		planArray.clear();
		dataCreatorUtil = new DataCreatorUtil(jdbcTemplate);
		DataGeneration.deleteInformation(jdbcTemplate);
		DataGeneration.insertTotalInformation(jdbcTemplate);
		System.out.println("+++++++++++++++++++++++++++++++++++");
	}

	@After
	public void tearDown() throws Exception {
		DataGeneration.deleteInformation(jdbcTemplate);
		planArray.clear();
	}

	@Test
	public void testFragmentationAnalysis_5() throws SQLException {
		times = 5;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			Defragment.analysisFragmentation(container, planArray);
			ConsoleUtil.displayPlan(planArray);
		}

		Defragment.choosePlans(planArray);
		ConsoleUtil.displayPlan(planArray);

		assertEquals(3, planArray.size());
		assertEquals(4, planArray.get(0).getJoint());
		assertEquals(1, planArray.get(0).getFirstSegId());
		assertEquals(containId, planArray.get(0).getContainerId());
		assertEquals(4, planArray.get(0).getLastSegId());
		for (int i = 0; i < planArray.get(0).getJoint(); i++) {
			assertEquals(1 + i, planArray.get(0).getWillMergerSegs().get(i)
					.getSegId().intValue());

			assertEquals(0 + i * 16, planArray.get(0).getWillMergerSegs()
					.get(i).getStartId().intValue());
		}
	}

	@Test
	public void testFragmentationAnalysis_4() throws SQLException {
		times = 4;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			Defragment.analysisFragmentation(container, planArray);
			ConsoleUtil.displayPlan(planArray);
		}

		Defragment.choosePlans(planArray);
		ConsoleUtil.displayPlan(planArray);
		int joint = planArray.get(0).getJoint();
		assertEquals(3, planArray.size());
		assertEquals(4, planArray.get(0).getJoint());
		assertEquals(1, planArray.get(0).getFirstSegId());
		assertEquals(containId, planArray.get(0).getContainerId());
		assertEquals((1 + joint - 1), planArray.get(0).getLastSegId());
		assertEquals(4, planArray.get(1).getJoint());
		assertEquals(5, planArray.get(1).getFirstSegId());
		assertEquals(containId, planArray.get(1).getContainerId());
		assertEquals((5 + joint - 1), planArray.get(1).getLastSegId());
		assertEquals(4, planArray.get(2).getJoint());
		assertEquals(9, planArray.get(2).getFirstSegId());
		assertEquals(containId, planArray.get(2).getContainerId());
		assertEquals((9 + joint - 1), planArray.get(2).getLastSegId());
	}

	@Test
	public void testFragmentationAnalysis_3() throws SQLException {
		times = 3;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			Defragment.analysisFragmentation(container, planArray);
		}

		assertEquals(8, planArray.size());

	}

	/**
	 * 
	 * @throws SQLException
	 */
	@Test
	public void testExecutationPlanning() throws SQLException {
		times = 2;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			Defragment.analysisFragmentation(container, planArray);
		}

		Defragment.choosePlans(planArray);
		assertEquals(0, planArray.size());
		// int joint = planArray.get(0).getJoint();
		// assertEquals(1, planArray.size());
		// assertEquals(5, planArray.get(0).getJoint());
		// assertEquals(9, planArray.get(0).getFirstSegId());
		// assertEquals(2, planArray.get(0).getSegmentSetId());
		// assertEquals((9 + joint - 1), planArray.get(0).getLastSegId());
	}

	@Test(expected = IllegalArgumentException.class)
	public void testExecutationPlanning_Times1() throws SQLException {
		times = 1;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			Defragment.analysisFragmentation(container, planArray);
			ConsoleUtil.displayPlan(planArray);
		}

		Defragment.choosePlans(planArray);
		ConsoleUtil.displayPlan(planArray);
	}

	@Test
	public void testBestPlanCombiBySameJoint() throws SQLException {
		times = 10;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();

		for (ContainerSummary container : containerList) {
			Defragment.analysisFragmentation(container, planArray);
			ConsoleUtil.displayPlan(planArray);
		}

		Defragment.choosePlans(planArray);
		ConsoleUtil.displayPlan(planArray);
		int joint = planArray.get(0).getJoint();
		assertEquals(6, planArray.size());
		assertEquals(2, planArray.get(0).getJoint());
		assertEquals(1, planArray.get(0).getFirstSegId());
		assertEquals(containId, planArray.get(0).getContainerId());
		assertEquals((1 + joint - 1), planArray.get(0).getLastSegId());
		assertEquals(2, planArray.get(1).getJoint());
		assertEquals(3, planArray.get(1).getFirstSegId());
		assertEquals(containId, planArray.get(1).getContainerId());
		assertEquals((3 + joint - 1), planArray.get(1).getLastSegId());
		assertEquals(2, planArray.get(2).getJoint());
		assertEquals(5, planArray.get(2).getFirstSegId());
		assertEquals(containId, planArray.get(2).getContainerId());
		assertEquals((5 + joint - 1), planArray.get(2).getLastSegId());
		assertEquals(2, planArray.get(3).getJoint());
		assertEquals(7, planArray.get(3).getFirstSegId());
		assertEquals(containId, planArray.get(3).getContainerId());
		assertEquals((7 + joint - 1), planArray.get(3).getLastSegId());
		assertEquals(2, planArray.get(4).getJoint());
		assertEquals(9, planArray.get(4).getFirstSegId());
		assertEquals(containId, planArray.get(4).getContainerId());
		assertEquals((9 + joint - 1), planArray.get(4).getLastSegId());
		assertEquals(2, planArray.get(5).getJoint());
		assertEquals(11, planArray.get(5).getFirstSegId());
		assertEquals(containId, planArray.get(5).getContainerId());
		assertEquals((11 + joint - 1), planArray.get(5).getLastSegId());
	}

	/**
	 * LogUtil.error
	 * 
	 * @throws SQLException
	 * @throws ParseException
	 */
	@Test(expected = IllegalArgumentException.class)
	public void testBestPlan_tatalRadio() throws SQLException, ParseException {
		times = 10;
		DataGeneration.insertItem(jdbcTemplate);
		containerList = initService.initContainerSummary();

		for (ContainerSummary container : containerList) {
			Defragment.analysisFragmentation(container, planArray);
			ConsoleUtil.displayPlan(planArray);
		}

		Defragment.choosePlans(planArray);
		ConsoleUtil.displayPlan(planArray);
	}

	@Test
	public void testBestPlanCombiBySameJointWithSegmentInterval() {
		ContainerSummary container = dataCreatorUtil
				.create1Container5SegmentWithNotContinuousId();

		List<Plan> plans = new ArrayList<Plan>();
		Defragment.analysisFragmentation(container, plans);
		Defragment.choosePlans(plans);

		ConsoleUtil.displayPlan(plans);

		Plan plan1 = plans.get(0);

		assertEquals(plan1.getJoint(), 2);
		assertEquals(plan1.getContainerId(), 2);
		assertEquals(plan1.getFirstSegId(), 1);
		assertEquals(plan1.getLastSegId(), 3);

		assertEquals(plan1.getContainerId(), 2);
		assertEquals(plan1.getMaxSegmentSize(), 2000000);
		assertEquals(plan1.getMaxSegmentDiffs(), 1000);

		List<SegmentSummary> segments1 = plan1.getWillMergerSegs();
		assertEquals(segments1.size(), 2);

		SegmentSummary segment1 = segments1.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getDataRadio().toString(), "0.36");
		assertEquals(segment1.getFragmentRadio().toString(), "0.64");
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 22);

		SegmentSummary segment2 = segments1.get(1);
		assertEquals(segment2.getContainerId().intValue(), 1);
		assertEquals(segment2.getSegId().intValue(), 3);
		assertEquals(segment2.getDataRadio().toString(), "0.45");
		assertEquals(segment2.getFragmentRadio().toString(), "0.55");
		assertEquals(segment2.getStartId().intValue(), 23);
		assertEquals(segment2.getEndId().intValue(), 44);

		Plan plan2 = plans.get(1);

		assertEquals(plan2.getJoint(), 2);
		assertEquals(plan2.getContainerId(), 2);
		assertEquals(plan2.getFirstSegId(), 5);
		assertEquals(plan2.getLastSegId(), 7);

		assertEquals(plan2.getContainerId(), 2);
		assertEquals(plan2.getMaxSegmentSize(), 2000000);
		assertEquals(plan2.getMaxSegmentDiffs(), 1000);

		List<SegmentSummary> segments2 = plan2.getWillMergerSegs();
		assertEquals(segments2.size(), 2);

		SegmentSummary segment2_1 = segments2.get(0);
		assertEquals(segment2_1.getContainerId().intValue(), 1);
		assertEquals(segment2_1.getSegId().intValue(), 5);
		assertEquals(segment2_1.getDataRadio().toString(), "0.25");
		assertEquals(segment2_1.getFragmentRadio().toString(), "0.75");
		assertEquals(segment2_1.getStartId().intValue(), 45);
		assertEquals(segment2_1.getEndId().intValue(), 66);

		SegmentSummary segment2_2 = segments2.get(1);
		assertEquals(segment2_2.getContainerId().intValue(), 1);
		assertEquals(segment2_2.getSegId().intValue(), 7);
		assertEquals(segment2_2.getDataRadio().toString(), "0.25");
		assertEquals(segment2_2.getFragmentRadio().toString(), "0.75");
		assertEquals(segment2_2.getStartId().intValue(), 47);
		assertEquals(segment2_2.getEndId().intValue(), 88);
	}

	@Test
	public void testFragmentationAnalysis_10() throws Exception {
		times = 10;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			Defragment.analysisFragmentation(container, planArray);
			ConsoleUtil.displayPlan(planArray);
		}

		Defragment.choosePlans(planArray);
		ConsoleUtil.displayPlan(planArray);

		assertEquals(6, planArray.size());
	}
}
