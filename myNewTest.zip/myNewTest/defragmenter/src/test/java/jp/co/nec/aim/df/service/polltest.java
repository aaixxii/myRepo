package jp.co.nec.aim.df.service;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jp.co.nec.aim.df.common.UpdateJobStatusThread;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class polltest {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void DoUpdate() throws InterruptedException {
		ApplicationContext actx = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		JdbcTemplate jdbcTemplate = (JdbcTemplate) actx.getBean("jdbcTemplate");

		ExecutorService pool = Executors.newFixedThreadPool(2);

		Thread t10 = new UpdateJobStatusThread(jdbcTemplate, 2);

		pool.execute(t10);

		pool.shutdown();
	}

}