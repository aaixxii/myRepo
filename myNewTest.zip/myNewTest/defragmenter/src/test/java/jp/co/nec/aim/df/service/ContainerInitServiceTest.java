package jp.co.nec.aim.df.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.data.DataGeneration;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.entity.TotalInformation;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class ContainerInitServiceTest {

	private ContainerInitService initService = new ContainerInitService();

	@Resource
	JdbcTemplate jdbcTemplate;
	MakePlanService makePlanService = new MakePlanService();
	List<ContainerSummary> containerList;
	List<Plan> planArray = new ArrayList<Plan>();;
	static int times = 5;
	private static DataCreatorUtil creator;

	@Before
	public void setUp() throws Exception {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}
		creator.updateMaxSegmentSize(20000000, 1);
		DataGeneration.deleteInformation(jdbcTemplate);
		DataGeneration.insertTotalInformation(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		DataGeneration.deleteInformation(jdbcTemplate);
		planArray.clear();
	}

	@Test
	public void testInitContainerSummary() {
		List<ContainerSummary> ContainerSummarylist = initService
				.initContainerSummary();

		int i = 1;
		for (ContainerSummary container : ContainerSummarylist) {
			List<SegmentSummary> SegmentSummarylist = container
					.getSegmentSummary();
			for (SegmentSummary seg : SegmentSummarylist) {
				assertEquals(i++, seg.getSegId().intValue());
			}
			assertEquals(1, container.getContainerId().intValue());
			assertEquals(20000000, container.getMaxSegmentSize().intValue());
			assertEquals(13, container.getMaxSegmentId());
		}
	}

	@Test(expected = DefragmentServiceException.class)
	public void testInitContainerSummary_Exception() {
		MockUp<BaseDao> mocked = new MockUp<BaseDao>() {

			@Mock
			protected void prepareStatement(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException("");
			}
		};
		try {
			initService.initContainerSummary();
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testInitContainerSummary_init() {
		ContainerSummary containerSummary = new ContainerSummary(1, 1, "RDTB",
				12, 0.5d);
		assertEquals(1, containerSummary.getContainerId().intValue());
		assertEquals("RDTB", containerSummary.getFormatName());
		assertTrue(containerSummary.getFragmentRadio().equals(0.5d));
		assertEquals(12, containerSummary.getSegmentNumber().intValue());
	}

	@Test
	public void testInitContainerSummary_Set() {
		ContainerSummary containerSummary = new ContainerSummary();
		containerSummary.setContainerId(1);
		containerSummary.setFormatName("RDBT");
		containerSummary.setSegmentNumber(12);
		containerSummary.setFragmentRadio(0.4d);
		assertEquals(1, containerSummary.getContainerId().intValue());
		assertEquals("RDBT", containerSummary.getFormatName());
		assertTrue(containerSummary.getFragmentRadio().equals(0.4d));
		assertEquals(12, containerSummary.getSegmentNumber().intValue());
	}

	@Test
	public void testinitTotalContainer() {
		TotalInformation totalinformation = initService.initTotalContainer();

		assertEquals(1, totalinformation.getTotalContainerCount().intValue());
		assertEquals(13, totalinformation.getTotalSegmentCount().intValue());
		assertEquals(2456421, totalinformation.getTotalBinarySize().intValue());

	}

	@Test(expected = DefragmentServiceException.class)
	public void testinitTotalContainer_Exception() {
		MockUp<BaseDao> mocked = new MockUp<BaseDao>() {
			@Mock
			protected void prepareStatement(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException("");
			}
		};
		try {
			initService.initTotalContainer();
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testinitTotalContainer_Init() {
		TotalInformation totalinformation = new TotalInformation(1, 2, 123);

		assertEquals(1, totalinformation.getTotalContainerCount().intValue());
		assertEquals(2, totalinformation.getTotalSegmentCount().intValue());
		assertEquals(123, totalinformation.getTotalBinarySize().intValue());
	}

	@Test
	public void testinitTotalContainer_Set() {
		TotalInformation totalinformation = new TotalInformation();
		totalinformation.setTotalContainerCount(1);
		totalinformation.setTotalBinarySize(123L);
		totalinformation.setTotalSegmentCount(12);

		assertEquals(1, totalinformation.getTotalContainerCount().intValue());
		assertEquals(12, totalinformation.getTotalSegmentCount().intValue());
		assertEquals(123, totalinformation.getTotalBinarySize().intValue());
	}

}
