package jp.co.nec.aim.df.service;

import static org.apache.commons.io.IOUtils.write;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.df.common.HttpTestServer;
import jp.co.nec.aim.df.exception.CommunicationException;
import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;

public class CommunicationServiceTest {

	private static HttpTestServer _server;
	private CommunicationService service = new CommunicationService();

	static int comId = 0;
	static int eventcase = 0;

	@BeforeClass
	public static void init() throws Exception {
		_server = new HttpTestServer(55513);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void after() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {

		comId = 0;
		eventcase = 0;
	}

	public static Handler getMockHandler() {

		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {

				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				System.out.println(comId);

				switch (eventcase) {
				case 0:
					response.setStatus(200);
					write("-1", response.getOutputStream());
					break;
				case 1:
					response.setStatus(200);
					if (comId == 0) {
						write("-1", response.getOutputStream());
						System.out.println("-1");
					} else {
						write("1", response.getOutputStream());
						System.out.println("1");
					}
					comId--;

					break;
				case 2:
					response.setStatus(200);
					write("1", response.getOutputStream());
					break;

				case 3:
					response.setStatus(200);
					write("1", response.getOutputStream());
					break;
				case 4:
					response.setStatus(400);
					write("1", response.getOutputStream());
					break;
				case 5:
					response.setStatus(500);
					write("1", response.getOutputStream());
					break;
				case 6:
					response.setStatus(402);
					write("1", response.getOutputStream());
					break;
				}

				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}

		};
		return handler;
	}

	@Test
	public void testStopPOSTResult_ReqIdeqResId() {
		comId = 0;
		boolean b = service.sendStopSignal(1);
		Assert.assertEquals(b, true);
	}

	@Test
	public void testStartPOSTResult_reqIdeqresId() {
		eventcase = 2;
		comId = 2;
		boolean b = service.sendStartSignal(1);
		Assert.assertEquals(b, true);
	}

	@Test(expected = CommunicationException.class)
	public void testStopPOSTResult_statusCode400() {
		eventcase = 4;
		service.sendStopSignal(1);
	}

	@Test(expected = CommunicationException.class)
	public void testStopPOSTResult_statusCode500() {
		eventcase = 5;
		service.sendStopSignal(1);
	}
	
	@Test(expected = CommunicationException.class)
	public void testStopPOSTResult_statusCode402() {
		eventcase = 6;
		service.sendStopSignal(1);
	}

}
