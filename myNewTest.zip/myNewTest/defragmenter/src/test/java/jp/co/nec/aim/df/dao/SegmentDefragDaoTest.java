package jp.co.nec.aim.df.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import javax.annotation.Resource;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class SegmentDefragDaoTest {

	private SegmentDefragDao dao = DaoFactory.createDao(SegmentDefragDao.class);
	private static DataCreatorUtil creator;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testGetSegDefragCount() {

		assertEquals(0, dao.getSegDefragCount());
		assertEquals(null, dao.getTrifficContainerId());

		creator.initDefragContainerId();
		creator.cleanAndSetRUC();
		jdbcTemplate.update("commit");

		assertEquals(1, dao.getSegDefragCount());
		assertEquals(new Long(-1), dao.getTrifficContainerId());
	}

	@Test
	public void testGetTrifficContainerId() {

		creator.initDefragContainerId();
		creator.cleanAndSetRUC();
		jdbcTemplate.update("commit");

		assertEquals(1, dao.getSegDefragCount());
		assertEquals(new Long(-1), dao.getTrifficContainerId());

		creator.setDefragContainerId(20);
		jdbcTemplate.update("commit");

		assertEquals(1, dao.getSegDefragCount());
		assertEquals(new Long(20), dao.getTrifficContainerId());
	}

	@Test
	public void testGetSegDefragCount_Exception() {

		creator.initDefragContainerId();
		creator.cleanAndSetRUC();
		jdbcTemplate.update("commit");

		new MockUp<BaseDao>() {

			@Mock
			protected void prepareStatement(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException("DefragmentDaoException occured in prepareStatement");
			}

		};
		try {
			dao.getTrifficContainerId();
			assertFalse("DefragmentDaoException donot occoured.", true);
		} catch (DefragmentDaoException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(ex.getMessage(), true);
		} finally {			
		}
	}

	@Test
	public void testGetTrifficContainerId_Exception() {

		creator.initDefragContainerId();
		creator.cleanAndSetRUC();
		jdbcTemplate.update("commit");

		new MockUp<BaseDao>() {

			@Mock
			protected void prepareStatement(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException("DefragmentDaoException occured in  prepareStatement");
			}

		};
		try {
			dao.getTrifficContainerId();
			assertFalse("DefragmentDaoException donot occoured.", true);
		} catch (DefragmentDaoException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(ex.getMessage(), true);
		} finally {			
		}
	}

}
