package jp.co.nec.aim.df.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.util.ConnectionUtil;
import mockit.Mock;
import mockit.MockUp;

import org.apache.commons.dbcp.DelegatingConnection;
import org.apache.commons.dbcp.DelegatingResultSet;
import org.apache.commons.dbcp.DelegatingStatement;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import org.apache.commons.dbcp.SQLNestedException;

public class BaseDaoTest extends BaseDao {

	private static DataSource ds = null;

	@BeforeClass
	public static void beforeClass() {
		if (ds == null) {
			ds = DataSourceCreator.getInstance().getDataSource();
		}

	}

	@AfterClass
	public static void afterClass() {
		if (ds != null) {
			DataSourceCreator.getInstance().shutdownDataSource();
		}
	}

	@Before
	public void setUp() {
		this.setInitParams(ds);
	}

	@After
	public void tearDown() {

	}

	@Test(expected = DefragmentDaoException.class)
	public void testReleaseResultSet_SqlException() throws SQLException {
		try {
			new MockUp<DelegatingResultSet>() {
				@Mock
				public void close() throws SQLException {
					throw new SQLException();
				}
			};

			prepareStatement("select * from dual");
			executeQuery();
			releaseResultSet();
		} finally {		

			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testPrepareStatement_SqlException() {
		try {
			new MockUp<DelegatingConnection>() {
				@Mock
				public PreparedStatement prepareStatement(String sql)
						throws SQLException {
					throw new SQLException();
				}
			};
			prepareStatement("select * from dual");
		} finally {	
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = SQLNestedException.class)
	public void testPrepareStatementCon_SqlException() throws SQLException {
		Connection con = null;
		try {
			con = ds.getConnection();
			this.setInitParams(con);
			con.close();
			prepareStatementCon("select * from dual");
		} finally {
			ConnectionUtil.close(con);
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testReleasePreparedStatement_SqlException() {
		try {
			new MockUp<DelegatingStatement>() {
				@Mock
				public void close() throws SQLException {
					throw new SQLException();
				}
			};

			prepareStatement("select * from dual");
			executeQuery();
			releasePreparedStatement();
		} finally {			
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testReleaseConnectionToPoll() throws SQLException {
		try {
			prepareStatement("select * from dual");
			executeQuery();

			conThreadLocal.get().close();
			releaseConnectionToPoll();
		} finally {
			releasePreparedStatement();
			releaseResultSet();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testSetParamString_SQLException() {
		try {
			prepareStatement("select * from dual");
			releasePreparedStatement();
			setParam(1, "");
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testSetParamInt_SQLException() {
		try {
			prepareStatement("select * from dual");
			releasePreparedStatement();
			setParam(1, 1);
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testSetParamLong_SQLException() {
		try {
			prepareStatement("select * from dual");
			releasePreparedStatement();
			setParam(1, 1L);
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetString_SQLException() {
		try {
			prepareStatement("select * from dual");
			executeQuery();
			releaseResultSet();
			getString("");
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetInt_SQLException() {
		try {
			prepareStatement("select * from dual");
			executeQuery();
			releaseResultSet();
			getInt("");
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetLong_SQLException() {
		try {
			prepareStatement("select * from dual");
			executeQuery();
			releaseResultSet();
			getLong("");
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetDouble_SQLException() {
		try {
			prepareStatement("select * from dual");
			executeQuery();
			releaseResultSet();
			getDouble("");
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testNext_SQLException() {
		try {
			prepareStatement("select * from dual");
			executeQuery();
			releaseResultSet();
			next();
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetResultCount_SQLException() {
		try {
			prepareStatement("select * from dual");
			executeQuery();
			releaseResultSet();

			getResultCount();
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test
	public void testExecuteQuery_PsIsNull() {
		executeQuery();
	}

	@Test(expected = DefragmentDaoException.class)
	public void testExecuteUpdate_SQLException() {
		try {
			prepareStatement("select * from dual");
			releasePreparedStatement();
			executeUpdate();
		} finally {
			releasePreparedStatement();
			releaseResultSet();
			releaseConnectionToPoll();
		}
	}

	@Test
	public void testExecuteUpdate_psIsnull() {
		executeUpdate();
	}

}
