package jp.co.nec.aim.df.service;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import javax.annotation.Resource;

import jp.co.nec.aim.df.constant.SystemConstant;
import jp.co.nec.aim.df.data.DataCreatorUtilSimilor;
import jp.co.nec.aim.df.service.ServiceFactory;
import jp.co.nec.aim.df.service.SimulationService;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class SimulationServiceTest {

    private static final String BR = System.getProperty("line.separator");

    @Resource
    private JdbcTemplate jdbcTemplate;

    @Rule
    public TestName name = new TestName();

    private static DataCreatorUtilSimilor creator;

    @Before
    public void setup() throws SecurityException, NoSuchFieldException, Exception {
        if (creator == null) {
            creator = new DataCreatorUtilSimilor(jdbcTemplate);
        }

        clearData();

        final String methodName = name.getMethodName();
        if (methodName.equalsIgnoreCase("testDisplayIsNormal")) {
            creator.createGetPersonRangeInfoMergerBeyond3SegsResultIs1();
        } else if (methodName.equalsIgnoreCase("testDisplayIsNormalMergerResultIs2")) {
            creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs3();
        }

        jdbcTemplate.execute("commit");
    }

    @After
    public void after() {
        clearData();
    }

    /** instance **/
    private static final SimulationService service = ServiceFactory
            .createService(SimulationService.class);

    /**
     * clear the data
     */
    private void clearData() {
        jdbcTemplate.execute("delete from segments");
        jdbcTemplate.execute("delete from person_biometrics");
        jdbcTemplate.execute("delete from segment_change_log");
        jdbcTemplate.update("commit");
    }

    @Test
    public void testTheDataIsEmpty() {
        final String ret = service.display(1);
        Assert.assertEquals("", ret);
    }

    @Test
    public void testDisplayIsNormal() {
        final String ret = service.display(1);
        Assert.assertEquals(expectRet1, ret.replaceAll(BR, ""));
    }

    @Test
    public void testDisplayIsNormalMergerResultIs2() throws Exception {
        try {
            setFinalStatic(SystemConstant.class.getField("START_JOINT"), 5);
            final String ret = service.display(1);
            Assert.assertEquals(expectRet2, ret.replaceAll(BR, ""));
        } finally {
            setFinalStatic(SystemConstant.class.getField("START_JOINT"), 2);
        }
    }

    private final String expectRet1 = "MaxJoint=5   ||   MaxPlanSize=100"
            + "CONTAINER=1   || Shrink Size 56 MB -->  30 MB (-26 MB)" + "Joint Information:"
            + "[1, 2]->[1]   ";

    private final String expectRet2 = "MaxJoint=5   ||   MaxPlanSize=100"
            + "CONTAINER=1   || Shrink Size 1 MB -->  42 MB (--41 MB)" + "Joint Information:"
            + "[1, 2, 3, 4, 5]->[1, 2, 3]   ";

    static void setFinalStatic(Field field, Object newValue) throws Exception {
        field.setAccessible(true);
        Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
        field.set(null, newValue);
    }
}
