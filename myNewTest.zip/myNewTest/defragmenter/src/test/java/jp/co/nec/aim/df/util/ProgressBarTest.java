package jp.co.nec.aim.df.util;

import java.util.List;

import jp.co.nec.aim.df.util.ProgressBar;
import junit.framework.Assert;

import org.junit.Test;

/**
 * ProgressBarTest
 * 
 * @author liuyq
 * 
 */
public class ProgressBarTest {

    @Test
    public void testGetMarkPercentLength41() {
        List<String> array = ProgressBar.getMarkPercent(41);

        Assert.assertEquals(3, array.size());
        String first = array.get(0);
        Assert.assertEquals(" _________________________________________", first);

        String second = array.get(1);
        Assert.assertEquals(" |                   |                   |", second);

        String third = array.get(2);
        Assert.assertEquals(" 0%                 50%                 100%    ", third);
    }

    @Test
    public void testGetMarkPercentLength21() {
        List<String> array = ProgressBar.getMarkPercent(21);

        Assert.assertEquals(3, array.size());
        String first = array.get(0);
        Assert.assertEquals(" _____________________", first);

        String second = array.get(1);
        Assert.assertEquals(" |         |         |", second);

        String third = array.get(2);
        Assert.assertEquals(" 0%       50%       100%    ", third);
    }

    @Test
    public void testShowBarByPointRadio65() {
        double rate = 0.65d;
        int barLength = 20;

        String ret = ProgressBar.showBarByPoint(rate, barLength);
        Assert.assertEquals("[#############       ] 65.00%", ret);
    }

    @Test
    public void testShowBarByPointRadio23() {
        double rate = 0.23d;
        int barLength = 40;

        String ret = ProgressBar.showBarByPoint(rate, barLength);
        Assert.assertEquals("[#########                               ] 23.00%", ret);
    }
}
