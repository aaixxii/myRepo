package jp.co.nec.aim.df.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.entity.TotalInformation;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class ContainerAnalysisDaoTest {
	private ContainerAnalysisDao dao = DaoFactory
			.createDao(ContainerAnalysisDao.class);;
	@Resource
	private JdbcTemplate jdbcTemplate;

	List<Integer> startsegId = new ArrayList<Integer>();

	@Rule
	public TestName name = new TestName();

	/**
	 * clearData
	 */
	private void clearData() {
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from person_biometrics");
		jdbcTemplate.execute("delete from system_config");
		jdbcTemplate.update("commit");
	}

	private static DataCreatorUtil creator;

	@Before
	public void setUp() throws Exception {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}

		clearData();
		final String methodName = name.getMethodName();
		if (methodName
				.equalsIgnoreCase("testGetTotalInformationWith14ContainerId")) {
			creator.createTestGetTotalInformationWithContainerId(new int[] { 1,
					2, 3, 4, 5, 321, 322, 323, 324, 326, 331, 332, 333, 334,
					335 });
		} else if (methodName
				.equalsIgnoreCase("testGetContainerSummaryWith10ContainerId")) {
			creator.createTestGetTotalInformationWithContainerId(new int[] { 1,
					2, 3, 4, 5, 321, 322, 323, 324, 326 });
		} else if (methodName
				.equalsIgnoreCase("testGetSegmentSummaryWithContainerId")) {
			creator.createTestGetTotalInformationWithContainerId(new int[] { 1,
					2, 3, 4, 5, 321, 322, 323, 324, 326, 331 });
		} else if (methodName
				.equalsIgnoreCase("testGetMaxSegmentDiffs_fromDatabase")) {
			creator.insertSystemMaxSegmentDiff();
		}
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		clearData();
	}

	@AfterClass
	public static void closeConnection() {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
	}

	@Test
	public void testGetTotalInformationNothing() {
		TotalInformation information = dao.getTotalInformation();
		assertEquals(information.getTotalBinarySize().intValue(), 0);
		assertEquals(information.getTotalContainerCount().intValue(), 0);
		assertEquals(information.getTotalSegmentCount().intValue(), 0);
	}

	@Test
	public void testGetTotalInformationWith14ContainerId() {
		TotalInformation information = dao.getTotalInformation();

		assertEquals(information.getTotalBinarySize().intValue(), 199990 * 150);
		assertEquals(information.getTotalContainerCount().intValue(), 15);
		assertEquals(information.getTotalSegmentCount().intValue(), 150);
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetTotalInformation_withException() {
		MockUp<BaseDao> mocked = null;
		try {
		  mocked = new MockUp<BaseDao>() {
				@Mock
				public void prepareStatement(String sql)
						throws DefragmentDaoException {
					throw new NullPointerException();
				}
			};
			dao.getTotalInformation();
		} finally {	
			mocked.tearDown();
		}

	}

	@Test
	public void testGetContainerSummaryNothing() {
		List<ContainerSummary> summary = dao.getContainerSummary();
		assertNotNull(summary);
		assertTrue(summary.isEmpty());
	}

	@Test
	public void testGetContainerSummaryWith10ContainerId() {
		final Object[][] expectResult = new Object[][] { { 1, 1, 10, "RDBT" },
				{ 2, 2, 10, "RDBT" }, { 3, 3, 10, "RDBL" },
				{ 4, 4, 10, "RDBL" }, { 5, 5, 10, "PDB" },
				{ 321, 321, 10, "LDB" }, { 322, 322, 10, "PLDB" },
				{ 323, 323, 10, "RDBLS" }, { 324, 324, 10, "RDBLS" },
				{ 326, 326, 10, "LDBS" } };
		List<ContainerSummary> summary = dao.getContainerSummary();
		assertNotNull(summary);
		assertEquals(summary.size(), 10);

		int index = 0;
		for (final ContainerSummary container : summary) {
			final Object[] arrays = expectResult[index++];
			assertEquals(container.getContainerId().intValue(),
					Integer.parseInt(arrays[0].toString()));
			assertEquals(container.getContainerId().intValue(),
					Integer.parseInt(arrays[1].toString()));
			assertEquals(container.getSegmentNumber().intValue(),
					Integer.parseInt(arrays[2].toString()));
			assertEquals(container.getFormatName(), arrays[3].toString());
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetContainerSummary_withException() {
		MockUp<BaseDao> mocked = null;
		try {
			 mocked = new MockUp<BaseDao>() {
				@Mock
				public void prepareStatement(String sql)
						throws DefragmentDaoException {
					throw new NullPointerException();
				}
			};
			dao.getContainerSummary();
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testGetSegmentSummaryNothing() {
		List<SegmentSummary> segments = dao.getSegmentSummary(1);
		assertNotNull(segments);
		assertTrue(segments.isEmpty());
	}

	@Test
	public void testGetSegmentSummaryWithContainerId() {

		List<SegmentSummary> segments = dao.getSegmentSummary(1);
		assertEquals(segments.size(), 10);

		final int eachBinSegment = 10;
		final int recordCount = 20;
		final int size = 199990;
		int segmentIndex = 1;

		for (int i = 0; i < eachBinSegment; i++) {
			int startid = 1 + (segmentIndex - 1) * recordCount;
			int endid = startid + recordCount - 1;

			final SegmentSummary segment = segments.get(i);
			assertEquals(segment.getContainerId().intValue(), 1);
			assertEquals(segment.getSegId().intValue(), segmentIndex++);
			assertEquals(segment.getStartId().intValue(), startid);
			assertEquals(segment.getEndId().intValue(), endid);
			assertEquals(segment.getVersion().intValue(), 20);
			assertEquals(segment.getReVersion().intValue(), 20);

			assertEquals(segment.getVersionBackUp().intValue(), 20);
			assertEquals(segment.getReVersionBackUp().intValue(), 20);

			assertEquals(segment.getBlCompacted().intValue(), size);
			assertEquals(segment.getBlunCompacted().intValue(), size);
		}
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetSegmentSummary_withException() {
		MockUp<BaseDao> mocked = null;
		try {
			mocked = new MockUp<BaseDao>() {
				@Mock
				public void prepareStatement(String sql)
						throws DefragmentDaoException {
					throw new NullPointerException();
				}
			};
			dao.getSegmentSummary(1);
		} finally {	
			mocked.tearDown();
		}
	}

	@Test
	public void testGetMaxSegmentDiffs_defaultValue() {
		int maxDiff = dao.getMaxSegmentDiffs();
		assertEquals(maxDiff, 1000);
	}

	@Test
	public void testGetMaxSegmentDiffs_fromDatabase() {
		int maxDiff = dao.getMaxSegmentDiffs();
		assertEquals(maxDiff, 1500);
	}

	@Test(expected = DefragmentDaoException.class)
	public void testGetMaxSegmentDiffs_withException() {
		MockUp<BaseDao> mocked = null;
		try {
			mocked = new MockUp<BaseDao>() {
				@Mock
				public void prepareStatement(String sql)
						throws DefragmentDaoException {
					throw new NullPointerException();
				}
			};
			dao.getMaxSegmentDiffs();
		} finally {	
			mocked.tearDown();
		}
	}
}
