package jp.co.nec.aim.df.dbcp;

import java.sql.SQLException;

import jp.co.nec.aim.df.exception.DefragmentDaoException;
import mockit.Mock;
import mockit.MockUp;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DataSourceCreatorTest {

	DataSourceCreator datasourcecreator;

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {
		datasourcecreator = null;
	}

	@Test
	public void testSetupDateSource() {
		datasourcecreator = DataSourceCreator.getInstance();
		datasourcecreator.getDataSource();
		datasourcecreator.shutdownDataSource();
	}

	@Test
	public void testGetInstance() {
		datasourcecreator = DataSourceCreator.getInstance();
		datasourcecreator.getDataSource();
		datasourcecreator.shutdownDataSource();
	}

	@Test(expected = DefragmentDaoException.class)
	public void testdbsnull_Exception() {
		new MockUp<BasicDataSource>() {

			@Mock
			public synchronized void close() throws SQLException {
				throw new SQLException();
			}

		};
		try {
			datasourcecreator = DataSourceCreator.getInstance();
			datasourcecreator.getDataSource();
			datasourcecreator.shutdownDataSource();
		} finally {			
		}
	}

	@Test
	public void testdbsnull() {
		datasourcecreator = new DataSourceCreator();
		datasourcecreator.shutdownDataSource();
	}

}
