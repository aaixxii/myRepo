package jp.co.nec.aim.df.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dao.ContainerAnalysisDao;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.util.ConnectionUtil;
import jp.co.nec.aim.df.util.PropertiesUtil;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class PersistSegmentServiceTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Rule
	public TestName name = new TestName();

	private static PersistSegmentService service;


	@BeforeClass
	public static void beforeClass() {
		DataSource ds = DataSourceCreator.getInstance().getDataSource();
		Connection connection = null;
		try {
			connection = ds.getConnection();
		} catch (SQLException e) {
		}
		service = new PersistSegmentService(connection);
		analysisDao = DaoFactory.createDao(ContainerAnalysisDao.class);
	}

	@AfterClass
	public static void endClass() {
		try {
			service.getConnection().close();
		} catch (SQLException e) {
		}
	}

	private static DataCreatorUtil creator;
	private static ContainerAnalysisDao analysisDao;

	private void clearData() {
		jdbcTemplate.execute("delete from person_biometrics");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from system_init");
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.update("commit");
	}

	@Before
	public void setup() {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}

		clearData();
		creator.setDefragContainerId(-1);
		final String methodName = name.getMethodName();
		if (methodName
				.equalsIgnoreCase("testPersistSegmentTheVersionIsNotMatch_MMCare_true")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs1();
		} else if (methodName.equalsIgnoreCase("testPersistSegment_normally")
				|| methodName
						.equalsIgnoreCase("testPersistSegment_mockMMcareisFalse")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs1();
			creator.setDefragContainerId(1L);
		}
		jdbcTemplate.execute("commit");
	}

	@After
	public void after() {
		clearData();
	}

	// ////////////////////////////////////////////////////////////////////
	// ///////////////////// test parameter exception /////////////////////
	// ////////////////////////////////////////////////////////////////////
	@Test
	public void testParaPlanIsNull() {
		try {
			service.persistSegment(null);
		} catch (NullPointerException ex) {
			assertEquals("the parameter plan is null while persistSegment..",
					ex.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testWillMergerSegmentsIsEmpty() {
		try {
			service.persistSegment(new Plan());
		} catch (DefragmentServiceException ex) {
			assertEquals("the plans is empty "
					+ "while persistSegment to database..", ex.getMessage());
			return;
		}
		fail();
	}


	@Test
	public void testPersistSegment_normally() {
		Plan plan = creator.createPlanMergerBeyond4SegsResultIs1();
		service.persistSegment(plan);
		ConnectionUtil.commit(service.getConnection());

		List<SegmentSummary> segments = analysisDao.getSegmentSummary(1);
		assertEquals(segments.size(), 3);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(1, segment1.getSegId().intValue());
		assertEquals(1, segment1.getStartId().intValue());
		assertEquals(44, segment1.getEndId().intValue());

		SegmentSummary segment2 = segments.get(1);
		assertEquals(2, segment2.getSegId().intValue());
		assertEquals(45, segment2.getStartId().intValue());
		assertEquals(60, segment2.getEndId().intValue());

		SegmentSummary segment3 = segments.get(2);
		assertEquals(3, segment3.getSegId().intValue());
		assertEquals(61, segment3.getStartId().intValue());
		assertEquals(88, segment3.getEndId().intValue());
	}

	@Test
	public void testPersistSegment_mockMMcareisFalse() {
		new MockUp<PropertiesUtil>() {
			@Mock
			public boolean getMmCare() {
				return false;
			}
		};

		try {
			Plan plan = creator.createPlanMergerBeyond4SegsResultIs1();
			service.persistSegment(plan);
			ConnectionUtil.commit(service.getConnection());

			List<SegmentSummary> segments = analysisDao.getSegmentSummary(1);
			assertEquals(segments.size(), 3);

			SegmentSummary segment1 = segments.get(0);
			assertEquals(1, segment1.getSegId().intValue());
			assertEquals(1, segment1.getStartId().intValue());
			assertEquals(44, segment1.getEndId().intValue());

			SegmentSummary segment2 = segments.get(1);
			assertEquals(2, segment2.getSegId().intValue());
			assertEquals(45, segment2.getStartId().intValue());
			assertEquals(60, segment2.getEndId().intValue());

			SegmentSummary segment3 = segments.get(2);
			assertEquals(3, segment3.getSegId().intValue());
			assertEquals(61, segment3.getStartId().intValue());
			assertEquals(88, segment3.getEndId().intValue());
		} finally {			
		}
	}
}
