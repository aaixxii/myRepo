package jp.co.nec.aim.df.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.util.ConnectionUtil;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class SegmentDefragUpdateDaoTest {

	private SegmentDefragUpdateDao segDefragUpdDao;
	private SegmentDefragDao dao = DaoFactory.createDao(SegmentDefragDao.class);
	private static DataCreatorUtil creator;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private static Connection con;
	DataSource ds = DataSourceCreator.getInstance().getDataSource();

	@Before
	public void setUp() throws Exception {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}
		try {
			if (con == null) {
				con = ds.getConnection();
			}
		} catch (SQLException e) {
			String message = "can not get connection from datasource..";
			throw new DefragmentServiceException(message);
		}

		segDefragUpdDao = DaoFactory.createDao(SegmentDefragUpdateDao.class, this.con);

		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testinsertSegDefrag() {
		segDefragUpdDao.insertSegDefrag(-1);
		
		ConnectionUtil.commit(con);
		
		assertEquals(1, dao.getSegDefragCount());
		assertEquals(new Long(-1), dao.getTrifficContainerId());
		
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.update("commit");
		
		segDefragUpdDao.insertSegDefrag(50);
		
		ConnectionUtil.commit(con);
		
		assertEquals(1, dao.getSegDefragCount());
		assertEquals(new Long(50), dao.getTrifficContainerId());	
		
		segDefragUpdDao.updateSegDefrag(80);
		
		ConnectionUtil.commit(con);
		
		assertEquals(1, dao.getSegDefragCount());
		assertEquals(new Long(80), dao.getTrifficContainerId());	
		
		
		segDefragUpdDao.updateSegDefrag(-1);
		
		ConnectionUtil.commit(con);
		
		assertEquals(1, dao.getSegDefragCount());
		assertEquals(new Long(-1), dao.getTrifficContainerId());
		
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.update("commit");
		
		segDefragUpdDao.updateSegDefrag(90);
		
		ConnectionUtil.commit(con);
		
		assertEquals(0, dao.getSegDefragCount());
		assertEquals(null, dao.getTrifficContainerId());
		
	}
	
	@Test
	public void testinsertSegDefrag_Exception() {
		new MockUp<BaseDao>() {

			@Mock
			protected void prepareStatementCon(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException(
						"DefragmentDaoException occured in prepareStatementCon");
			}

		};
		try {
			segDefragUpdDao.insertSegDefrag(20);
			assertFalse("DefragmentDaoException donot occoured.", true);
		} catch (DefragmentDaoException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(ex.getMessage(), true);
		} finally {			
		}
	}

	@Test
	public void testupdateSegDefrag_Exception() {

		creator.initDefragContainerId();
		creator.cleanAndSetRUC();
		jdbcTemplate.update("commit");

		new MockUp<BaseDao>() {

			@Mock
			protected void prepareStatementCon(String sql)
					throws DefragmentDaoException {
				throw new DefragmentDaoException(
						"DefragmentDaoException occured in  prepareStatementCon");
			}

		};
		try {
			segDefragUpdDao.updateSegDefrag(20);
			assertFalse("DefragmentDaoException donot occoured.", true);
		} catch (DefragmentDaoException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(ex.getMessage(), true);
		} finally {			
		}
	}

}
