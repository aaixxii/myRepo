package jp.co.nec.aim.df.service;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.df.common.StaticChange;
import jp.co.nec.aim.df.constant.SystemConstant;
import jp.co.nec.aim.df.core.Defragment;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.data.DataGeneration;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.util.ConsoleUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class MakePlanServiceTest {

	@Resource
	JdbcTemplate jdbcTemplate;
	static ContainerInitService initService = new ContainerInitService();
	MakePlanService makePlanService = new MakePlanService();
	List<ContainerSummary> containerList;
	List<Plan> planArray;
	static int times = 5;
	int containerId = 1;
	private static DataCreatorUtil creator;

	@AfterClass
	public static void afterClass() {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
		DataSourceCreator.getInstance().shutdownDataSource();
	}

	@Before
	public void setUp() throws Exception {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}
		creator.updateMaxSegmentSize(200000, 1);
		DataGeneration.deleteInformation(jdbcTemplate);
		DataGeneration.insertTotalInformation(jdbcTemplate);
		System.out.println("+++++++++++++++++++++++++++++++++++");
	}

	@After
	public void tearDown() throws Exception {
		DataGeneration.deleteInformation(jdbcTemplate);
		if (planArray != null && !planArray.isEmpty()) {
			planArray.clear();
		}
	}

	@Test
	public void testFragmentationAnalysis_5_MaxPlanSize()
			throws SecurityException, NoSuchFieldException, Exception {

		StaticChange.setFinalStatic(
				SystemConstant.class.getField("MAXPLANSIZE"), 1);
		try {
			times = 5;
			DataGeneration.deleteItem(jdbcTemplate, times);
			ContainerInitService initService01 = new ContainerInitService();
			containerList = initService01.initContainerSummary();
			MakePlanService makePlanService01 = new MakePlanService();
			for (ContainerSummary container : containerList) {
				planArray = makePlanService01.makePlan(container);
				ConsoleUtil.displayPlan(planArray);
			}
			assertEquals(1, planArray.size());
			assertEquals(4, planArray.get(0).getJoint());
			assertEquals(1, planArray.get(0).getFirstSegId());
			assertEquals(containerId, planArray.get(0).getContainerId());
			assertEquals(4, planArray.get(0).getLastSegId());
			for (int i = 0; i < planArray.get(0).getJoint(); i++) {
				assertEquals(1 + i, planArray.get(0).getWillMergerSegs().get(i)
						.getSegId().intValue());

				assertEquals(0 + i * 16, planArray.get(0).getWillMergerSegs()
						.get(i).getStartId().intValue());
			}
		} finally {
			StaticChange.setFinalStatic(
					SystemConstant.class.getField("MAXPLANSIZE"), 100);
		}
	}

	@Test
	public void testFragmentationAnalysis_5() throws SQLException {
		times = 5;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			planArray = makePlanService.makePlan(container);
			ConsoleUtil.displayPlan(planArray);
		}
		assertEquals(3, planArray.size());
		assertEquals(4, planArray.get(0).getJoint());
		assertEquals(1, planArray.get(0).getFirstSegId());
		assertEquals(containerId, planArray.get(0).getContainerId());
		assertEquals(4, planArray.get(0).getLastSegId());
		for (int i = 0; i < planArray.get(0).getJoint(); i++) {
			assertEquals(1 + i, planArray.get(0).getWillMergerSegs().get(i)
					.getSegId().intValue());

			assertEquals(0 + i * 16, planArray.get(0).getWillMergerSegs()
					.get(i).getStartId().intValue());
		}
	}

	@Test
	public void testFragmentationAnalysis_4() throws SQLException {
		times = 4;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			planArray = makePlanService.makePlan(container);
			ConsoleUtil.displayPlan(planArray);
		}
		assertEquals(3, planArray.size());
		int joint = planArray.get(0).getJoint();
		assertEquals(3, planArray.size());
		assertEquals(4, planArray.get(0).getJoint());
		assertEquals(1, planArray.get(0).getFirstSegId());
		assertEquals(containerId, planArray.get(0).getContainerId());
		assertEquals((1 + joint - 1), planArray.get(0).getLastSegId());
		assertEquals(4, planArray.get(1).getJoint());
		assertEquals(5, planArray.get(1).getFirstSegId());
		assertEquals(containerId, planArray.get(1).getContainerId());
		assertEquals((5 + joint - 1), planArray.get(1).getLastSegId());
		assertEquals(4, planArray.get(2).getJoint());
		assertEquals(9, planArray.get(2).getFirstSegId());
		assertEquals(containerId, planArray.get(2).getContainerId());
		assertEquals((9 + joint - 1), planArray.get(2).getLastSegId());
	}

	@Test
	public void testFragmentationAnalysis_3() throws SQLException {
		times = 3;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			planArray = makePlanService.makePlan(container);

		}
		assertEquals(2, planArray.size());
	}

	/**
	 * 
	 * @throws SQLException
	 */
	@Test
	public void testExecutationPlanning() throws SQLException {
		times = 2;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			planArray = makePlanService.makePlan(container);
			// ConsoleUtil.displayPlan(planArray);
		}

		assertEquals(0, planArray.size());
		// int joint = planArray.get(0).getJoint();
		// assertEquals(1, planArray.size());
		// assertEquals(1, planArray.size());
		// assertEquals(5, planArray.get(0).getJoint());
		// assertEquals(9, planArray.get(0).getFirstSegId());
		// assertEquals(2, planArray.get(0).getSegmentSetId());
		// assertEquals((9 + joint - 1), planArray.get(0).getLastSegId());
	}

	@Test(expected = DefragmentServiceException.class)
	public void testFragmentationAnalysis_4_Exception() throws SQLException {
		times = 4;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();

		new MockUp<Defragment>() {
			@Mock
			public void analysisFragmentation(final ContainerSummary container,
					final List<Plan> planlist) {
				throw new DefragmentDaoException("");
			}

		};

		try {

			for (ContainerSummary container : containerList) {
				planArray = makePlanService.makePlan(container);
				ConsoleUtil.displayPlan(planArray);
			}
			assertEquals(3, planArray.size());
		} finally {			
		}
	}

	@Test
	public void testBestPlanCombiBySameJoint() throws SQLException {
		times = 10;
		DataGeneration.deleteItem(jdbcTemplate, times);
		containerList = initService.initContainerSummary();

		for (ContainerSummary container : containerList) {
			planArray = makePlanService.makePlan(container);
			ConsoleUtil.displayPlan(planArray);
		}
		int joint = planArray.get(0).getJoint();
		assertEquals(6, planArray.size());
		assertEquals(2, planArray.get(0).getJoint());
		assertEquals(1, planArray.get(0).getFirstSegId());
		assertEquals(containerId, planArray.get(0).getContainerId());
		assertEquals((1 + joint - 1), planArray.get(0).getLastSegId());
		assertEquals(2, planArray.get(1).getJoint());
		assertEquals(3, planArray.get(1).getFirstSegId());
		assertEquals(containerId, planArray.get(1).getContainerId());
		assertEquals((3 + joint - 1), planArray.get(1).getLastSegId());
		assertEquals(2, planArray.get(2).getJoint());
		assertEquals(5, planArray.get(2).getFirstSegId());
		assertEquals(containerId, planArray.get(2).getContainerId());
		assertEquals((5 + joint - 1), planArray.get(2).getLastSegId());
		assertEquals(2, planArray.get(3).getJoint());
		assertEquals(7, planArray.get(3).getFirstSegId());
		assertEquals(containerId, planArray.get(3).getContainerId());
		assertEquals((7 + joint - 1), planArray.get(3).getLastSegId());
		assertEquals(2, planArray.get(4).getJoint());
		assertEquals(9, planArray.get(4).getFirstSegId());
		assertEquals(containerId, planArray.get(4).getContainerId());
		assertEquals((9 + joint - 1), planArray.get(4).getLastSegId());
		assertEquals(2, planArray.get(5).getJoint());
		assertEquals(11, planArray.get(5).getFirstSegId());
		assertEquals(containerId, planArray.get(5).getContainerId());
		assertEquals((11 + joint - 1), planArray.get(5).getLastSegId());
	}

}
