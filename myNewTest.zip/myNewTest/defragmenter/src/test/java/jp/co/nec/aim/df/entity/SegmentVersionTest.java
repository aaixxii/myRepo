package jp.co.nec.aim.df.entity;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class SegmentVersionTest {

	private final SegmentVersion instance = new SegmentVersion();
	private final SegmentVersion instanceWithField = new SegmentVersion(1L,
			100, 100);

	@Test
	public void testIsMatchVersion_segmentsIsEmpty() {
		assertFalse(instance.isMatchVersion(new ArrayList<SegmentSummary>()));
	}

	@Test
	public void testIsMatchVersion_theVersionIsnotmatch() {
		List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		for (int i = 1; i <= 10; i++) {
			SegmentSummary segment = new SegmentSummary();
			segment.setSegId((long) i);
			segment.setVersionBackUp(i);
			segment.setReVersionBackUp(i);
			segments.add(segment);
		}
		assertFalse(instanceWithField.isMatchVersion(segments));
	}

	@Test
	public void testIsMatchVersion_theVersionIsMatch() {
		List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		for (int i = 1; i <= 10; i++) {
			SegmentSummary segment = new SegmentSummary();
			segment.setSegId((long) i);
			segment.setVersionBackUp(99 + i);
			segment.setReVersionBackUp(99 + i);
			segments.add(segment);
		}
		assertTrue(instanceWithField.isMatchVersion(segments));
	}

	@Test
	public void testIsMatchReVersion_theVersionIsnotmatch() {
		List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		for (int i = 1; i <= 10; i++) {
			SegmentSummary segment = new SegmentSummary();
			segment.setSegId((long) i);
			segment.setVersionBackUp(i);
			segment.setReVersionBackUp(i);
			segments.add(segment);
		}
		assertFalse(instanceWithField.isMatchVersion(segments));
	}

	@Test
	public void testIsMatchReVersion_theVersionIsMatch() {
		List<SegmentSummary> segments = new ArrayList<SegmentSummary>();
		for (int i = 1; i <= 10; i++) {
			SegmentSummary segment = new SegmentSummary();
			segment.setSegId((long) i);
			segment.setVersionBackUp(99 + i);
			segment.setReVersionBackUp(99 + i);
			segments.add(segment);
		}
		assertTrue(instanceWithField.isMatchVersion(segments));
	}
}
