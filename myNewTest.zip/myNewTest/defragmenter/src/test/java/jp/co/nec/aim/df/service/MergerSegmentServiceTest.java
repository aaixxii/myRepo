package jp.co.nec.aim.df.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dao.MergerSegmentDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.RangeSegment;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class MergerSegmentServiceTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Rule
	public TestName name = new TestName();

	private static MergerSegmentService service;

	@BeforeClass
	public static void beforeClass() {
		DataSource ds = DataSourceCreator.getInstance().getDataSource();
		Connection connection = null;
		try {
			connection = ds.getConnection();
		} catch (SQLException e) {
		}
		service = new MergerSegmentService(connection);
	}

	@AfterClass
	public static void endClass() {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
	}

	private static DataCreatorUtil creator;

	private void clearData() {
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from person_biometrics");
		jdbcTemplate.execute("delete from segment_change_log");
		jdbcTemplate.update("commit");
	}

	@Before
	public void setup() {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}

		clearData();

		final String methodName = name.getMethodName();
		if (methodName.equalsIgnoreCase("testTwoSegmentMergerToOne")) {
			creator.createGetPersonRangeInfoMergerBeyond2SegsResultIs1();
		} else if (methodName.equalsIgnoreCase("testThreeSegmentMergerToOne")) {
			creator.createGetPersonRangeInfoMergerBeyond3SegsResultIs1();
		} else if (methodName.equalsIgnoreCase("testFourSegmentMergerToOne")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs1();
		} else if (methodName.equalsIgnoreCase("testFiveSegmentMergerToOne")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs1();
		} else if (methodName.equalsIgnoreCase("testThreeSegmentMergerToTwo")) {
			creator.createGetPersonRangeInfoMergerBeyond3SegsResultIs2();
		} else if (methodName.equalsIgnoreCase("testFourSegmentMergerToThree")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs3();
		} else if (methodName.equalsIgnoreCase("testFourSegmentMergerToTwo")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs2();
		} else if (methodName.equalsIgnoreCase("testFiveSegmentMergerToFour")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs4();
		} else if (methodName.equalsIgnoreCase("testFiveSegmentMergerToThree")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs3();
		} else if (methodName.equalsIgnoreCase("testFiveSegmentMergerToTwo")) {
			creator.createGetPersonRangeInfoMergerBeyond5SegsResultIs2();
		}
		jdbcTemplate.execute("commit");
	}

	@After
	public void after() {
		clearData();
	}

	// ////////////////////////////////////////////////////////////////////
	// ///////////////////// test parameter exception /////////////////////
	// ////////////////////////////////////////////////////////////////////
	@Test
	public void testParaPlanIsNull() {
		try {
			service.mergerSegmentPlan(null);
		} catch (IllegalArgumentException ex) {
			assertEquals(
					"the parameter plan is null while mergerSegmentPlan..",
					ex.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testWillMergerSegmentsIsEmpty() {
		try {
			service.mergerSegmentPlan(new Plan());
		} catch (DefragmentServiceException ex) {
			assertEquals("the number of segment will be merger is empty..",
					ex.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testTwoSegmentMergerToOne() {
		Plan plan = creator.createPlanMergerBeyond2SegsResultIs1();

		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 2);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 44);
		assertEquals(segment1.getRecordCount().intValue(), 18);
		assertEquals(segment1.getVersion().intValue(), 2034);
		assertEquals(segment1.getReVersion().intValue(), 2034);
		assertEquals(segment1.getBlCompacted().intValue(), 159236);
		assertEquals(segment1.getBlunCompacted().intValue(), 159236);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertTrue(segment2.willbeDeleted());
	}

	@Test
	public void testThreeSegmentMergerToOne() {
		Plan plan = creator.createPlanMergerBeyond3SegsResultIs1();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 3);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 66);
		assertEquals(segment1.getRecordCount().intValue(), 21);
		assertEquals(segment1.getVersion().intValue(), 2037);
		assertEquals(segment1.getReVersion().intValue(), 2037);
		assertEquals(segment1.getBlCompacted().intValue(), 185828);
		assertEquals(segment1.getBlunCompacted().intValue(), 185828);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertTrue(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertTrue(segment3.willbeDeleted());
	}

	@Test
	public void testFourSegmentMergerToOne() {
		Plan plan = creator.createPlanMergerBeyond4SegsResultIs1();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 4);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 88);
		assertEquals(segment1.getRecordCount().intValue(), 19);
		assertEquals(segment1.getVersion().intValue(), 2039);
		assertEquals(segment1.getReVersion().intValue(), 2039);
		assertEquals(segment1.getBlCompacted().intValue(), 168138);
		assertEquals(segment1.getBlunCompacted().intValue(), 168138);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertTrue(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertTrue(segment3.willbeDeleted());

		SegmentSummary segment4 = segments.get(2);
		assertTrue(segment4.willbeDeleted());
	}

	@Test
	public void testFiveSegmentMergerToOne() {
		Plan plan = creator.createPlanMergerBeyond5SegsResultIs1();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 5);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 110);
		assertEquals(segment1.getRecordCount().intValue(), 20);
		assertEquals(segment1.getVersion().intValue(), 2039);
		assertEquals(segment1.getReVersion().intValue(), 2039);
		assertEquals(segment1.getBlCompacted().intValue(), 177002);
		assertEquals(segment1.getBlunCompacted().intValue(), 177002);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertTrue(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertTrue(segment3.willbeDeleted());

		SegmentSummary segment4 = segments.get(3);
		assertTrue(segment4.willbeDeleted());

		SegmentSummary segment5 = segments.get(4);
		assertTrue(segment5.willbeDeleted());
	}

	@Test
	public void testThreeSegmentMergerToTwo() {
		Plan plan = creator.createPlanMergerBeyond3SegsResultIs2();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 3);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 52);
		assertEquals(segment1.getRecordCount().intValue(), 22);
		assertEquals(segment1.getVersion().intValue(), 2037);
		assertEquals(segment1.getReVersion().intValue(), 2037);
		assertEquals(segment1.getBlCompacted().intValue(), 194654);
		assertEquals(segment1.getBlunCompacted().intValue(), 194654);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertEquals(segment2.getContainerId().intValue(), 1);
		assertEquals(segment2.getSegId().intValue(), 2);
		assertEquals(segment2.getStartId().intValue(), 53);
		assertEquals(segment2.getEndId().intValue(), 53);
		assertEquals(segment2.getRecordCount().intValue(), 1);
		assertEquals(segment2.getVersion().intValue(), 2037);
		assertEquals(segment2.getReVersion().intValue(), 2037);
		assertEquals(segment2.getBlCompacted().intValue(), 8890);
		assertEquals(segment2.getBlunCompacted().intValue(), 8890);
		assertFalse(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertTrue(segment3.willbeDeleted());
	}

	@Test
	public void testFourSegmentMergerToThree() {
		Plan plan = creator.createPlanMergerBeyond4SegsResultIs3();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 4);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 32);
		assertEquals(segment1.getRecordCount().intValue(), 22);
		assertEquals(segment1.getVersion().intValue(), 2032);
		assertEquals(segment1.getReVersion().intValue(), 2032);
		assertEquals(segment1.getBlCompacted().intValue(), 194616);
		assertEquals(segment1.getBlunCompacted().intValue(), 194616);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertEquals(segment2.getContainerId().intValue(), 1);
		assertEquals(segment2.getSegId().intValue(), 2);
		assertEquals(segment2.getStartId().intValue(), 33);
		assertEquals(segment2.getEndId().intValue(), 74);
		assertEquals(segment2.getRecordCount().intValue(), 22);
		assertEquals(segment2.getVersion().intValue(), 2032);
		assertEquals(segment2.getReVersion().intValue(), 2032);
		assertEquals(segment2.getBlCompacted().intValue(), 194616);
		assertEquals(segment2.getBlunCompacted().intValue(), 194616);
		assertFalse(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertEquals(segment3.getContainerId().intValue(), 1);
		assertEquals(segment3.getSegId().intValue(), 3);
		assertEquals(segment3.getStartId().intValue(), 75);
		assertEquals(segment3.getEndId().intValue(), 78);
		assertEquals(segment3.getRecordCount().intValue(), 4);
		assertEquals(segment3.getVersion().intValue(), 2032);
		assertEquals(segment3.getReVersion().intValue(), 2032);
		assertEquals(segment3.getBlCompacted().intValue(), 35406);
		assertEquals(segment3.getBlunCompacted().intValue(), 35406);
		assertFalse(segment3.willbeDeleted());

		SegmentSummary segment4 = segments.get(3);
		assertTrue(segment4.willbeDeleted());
	}

	@Test
	public void testFourSegmentMergerToTwo() {
		Plan plan = creator.createPlanMergerBeyond4SegsResultIs2();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 4);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 72);
		assertEquals(segment1.getRecordCount().intValue(), 22);
		assertEquals(segment1.getVersion().intValue(), 2039);
		assertEquals(segment1.getReVersion().intValue(), 2039);
		assertEquals(segment1.getBlCompacted().intValue(), 194654);
		assertEquals(segment1.getBlunCompacted().intValue(), 194654);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertEquals(segment2.getContainerId().intValue(), 1);
		assertEquals(segment2.getSegId().intValue(), 2);
		assertEquals(segment2.getStartId().intValue(), 73);
		assertEquals(segment2.getEndId().intValue(), 75);
		assertEquals(segment2.getRecordCount().intValue(), 3);
		assertEquals(segment2.getVersion().intValue(), 2039);
		assertEquals(segment2.getReVersion().intValue(), 2039);
		assertEquals(segment2.getBlCompacted().intValue(), 26580);
		assertEquals(segment2.getBlunCompacted().intValue(), 26580);
		assertFalse(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertTrue(segment3.willbeDeleted());

		SegmentSummary segment4 = segments.get(3);
		assertTrue(segment4.willbeDeleted());
	}

	@Test
	public void testFiveSegmentMergerToFour() {
		Plan plan = creator.createPlanMergerBeyond5SegsResultIs4();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 5);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 28);
		assertEquals(segment1.getRecordCount().intValue(), 22);
		assertEquals(segment1.getVersion().intValue(), 2028);
		assertEquals(segment1.getReVersion().intValue(), 2028);
		assertEquals(segment1.getBlCompacted().intValue(), 194616);
		assertEquals(segment1.getBlunCompacted().intValue(), 194616);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertEquals(segment2.getContainerId().intValue(), 1);
		assertEquals(segment2.getSegId().intValue(), 2);
		assertEquals(segment2.getStartId().intValue(), 29);
		assertEquals(segment2.getEndId().intValue(), 56);
		assertEquals(segment2.getRecordCount().intValue(), 22);
		assertEquals(segment2.getVersion().intValue(), 2028);
		assertEquals(segment2.getReVersion().intValue(), 2028);
		assertEquals(segment2.getBlCompacted().intValue(), 194616);
		assertEquals(segment2.getBlunCompacted().intValue(), 194616);
		assertFalse(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertEquals(segment3.getContainerId().intValue(), 1);
		assertEquals(segment3.getSegId().intValue(), 3);
		assertEquals(segment3.getStartId().intValue(), 57);
		assertEquals(segment3.getEndId().intValue(), 90);
		assertEquals(segment3.getRecordCount().intValue(), 22);
		assertEquals(segment3.getVersion().intValue(), 2028);
		assertEquals(segment3.getReVersion().intValue(), 2028);
		assertEquals(segment3.getBlCompacted().intValue(), 194616);
		assertEquals(segment3.getBlunCompacted().intValue(), 194616);
		assertFalse(segment3.willbeDeleted());

		SegmentSummary segment4 = segments.get(3);
		assertEquals(segment4.getContainerId().intValue(), 1);
		assertEquals(segment4.getSegId().intValue(), 4);
		assertEquals(segment4.getStartId().intValue(), 91);
		assertEquals(segment4.getEndId().intValue(), 104);
		assertEquals(segment4.getRecordCount().intValue(), 14);
		assertEquals(segment4.getVersion().intValue(), 2028);
		assertEquals(segment4.getReVersion().intValue(), 2028);
		assertEquals(segment4.getBlCompacted().intValue(), 123856);
		assertEquals(segment4.getBlunCompacted().intValue(), 123856);

		SegmentSummary segment5 = segments.get(4);
		assertTrue(segment5.willbeDeleted());
	}

	@Test
	public void testFiveSegmentMergerToThree() {
		Plan plan = creator.createPlanMergerBeyond5SegsResultIs3();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 5);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 46);
		assertEquals(segment1.getRecordCount().intValue(), 22);
		assertEquals(segment1.getVersion().intValue(), 2034);
		assertEquals(segment1.getReVersion().intValue(), 2034);
		assertEquals(segment1.getBlCompacted().intValue(), 194616);
		assertEquals(segment1.getBlunCompacted().intValue(), 194616);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertEquals(segment2.getContainerId().intValue(), 1);
		assertEquals(segment2.getSegId().intValue(), 2);
		assertEquals(segment2.getStartId().intValue(), 47);
		assertEquals(segment2.getEndId().intValue(), 92);
		assertEquals(segment2.getRecordCount().intValue(), 22);
		assertEquals(segment2.getVersion().intValue(), 2034);
		assertEquals(segment2.getReVersion().intValue(), 2034);
		assertEquals(segment2.getBlCompacted().intValue(), 194616);
		assertEquals(segment2.getBlunCompacted().intValue(), 194616);
		assertFalse(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertEquals(segment3.getContainerId().intValue(), 1);
		assertEquals(segment3.getSegId().intValue(), 3);
		assertEquals(segment3.getStartId().intValue(), 93);
		assertEquals(segment3.getEndId().intValue(), 98);
		assertEquals(segment3.getRecordCount().intValue(), 6);
		assertEquals(segment3.getVersion().intValue(), 2034);
		assertEquals(segment3.getReVersion().intValue(), 2034);
		assertEquals(segment3.getBlCompacted().intValue(), 53096);
		assertEquals(segment3.getBlunCompacted().intValue(), 53096);
		assertFalse(segment3.willbeDeleted());

		SegmentSummary segment4 = segments.get(3);
		assertTrue(segment4.willbeDeleted());

		SegmentSummary segment5 = segments.get(4);
		assertTrue(segment5.willbeDeleted());
	}

	@Test
	public void testFiveSegmentMergerToTwo() {
		Plan plan = creator.createPlanMergerBeyond5SegsResultIs2();
		service.mergerSegmentPlan(plan);
		List<SegmentSummary> segments = plan.getWillMergerSegs();

		assertEquals(segments.size(), 5);

		SegmentSummary segment1 = segments.get(0);
		assertEquals(segment1.getContainerId().intValue(), 1);
		assertEquals(segment1.getSegId().intValue(), 1);
		assertEquals(segment1.getStartId().intValue(), 1);
		assertEquals(segment1.getEndId().intValue(), 91);
		assertEquals(segment1.getRecordCount().intValue(), 22);
		assertEquals(segment1.getVersion().intValue(), 2039);
		assertEquals(segment1.getReVersion().intValue(), 2039);
		assertEquals(segment1.getBlCompacted().intValue(), 194692);
		assertEquals(segment1.getBlunCompacted().intValue(), 194692);
		assertFalse(segment1.willbeDeleted());

		SegmentSummary segment2 = segments.get(1);
		assertEquals(segment2.getContainerId().intValue(), 1);
		assertEquals(segment2.getSegId().intValue(), 2);
		assertEquals(segment2.getStartId().intValue(), 92);
		assertEquals(segment2.getEndId().intValue(), 93);
		assertEquals(segment2.getRecordCount().intValue(), 2);
		assertEquals(segment2.getVersion().intValue(), 2039);
		assertEquals(segment2.getReVersion().intValue(), 2039);
		assertEquals(segment2.getBlCompacted().intValue(), 17716);
		assertEquals(segment2.getBlunCompacted().intValue(), 17716);
		assertFalse(segment2.willbeDeleted());

		SegmentSummary segment3 = segments.get(2);
		assertTrue(segment3.willbeDeleted());

		SegmentSummary segment4 = segments.get(3);
		assertTrue(segment4.willbeDeleted());

		SegmentSummary segment5 = segments.get(4);
		assertTrue(segment5.willbeDeleted());
	}

	@Test
	public void testFourSegmentMergerToThree_Null() {
		new MockUp<MergerSegmentDao>() {
			@Mock
			public RangeSegment getPersonRangeInfo(final int containerId,
					final String segmentIds, final int vacancySize,
					final long startPerId) {
				return null;
			}
		};
		try {
			Plan plan = creator.createPlanMergerBeyond5SegsResultIs3();
			service.mergerSegmentPlan(plan);
			List<SegmentSummary> segments = plan.getWillMergerSegs();

			assertEquals(segments.size(), 5);
		} finally {			
		}
	}

}
