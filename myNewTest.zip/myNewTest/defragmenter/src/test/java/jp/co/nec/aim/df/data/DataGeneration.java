package jp.co.nec.aim.df.data;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import org.springframework.jdbc.core.JdbcTemplate;

public class DataGeneration {
	Timestamp timestamp, timestamp01, timestamp02;

	static List<Integer> startsegId = new ArrayList<Integer>();
	
	
	/**
	 * insertTotalInformation
	 * 
	 * @throws ParseException
	 * @throws SQLException
	 */
	public static void insertTotalInformation(JdbcTemplate jdbcTemplate)
			throws ParseException, SQLException {
		long sumsize = 0;
		DateFormat dateFormat;

		dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

		dateFormat.setLenient(false);

		final String insertPerson = "insert into person_biometrics"
				+ "(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)"
				+ " values(?,?,?,?,?,?,?,?)";
		// final String insertSegmentChange = "insert into segment_change_log"
		// +
		// "(SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) "
		// + "values(?,?,?,?,?)";
		final String insertSegments = "insert into segments"
				+ "(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED) "
				+ "values(?,?,?,?,?,?,?,?,?)";

		final String insertSegmentInit = "insert into SYSTEM_INIT"
				+ "(INIT_ID,KEY_NAME,KEY_VALUE)" + "values(?,?,?)";

//		jdbcTemplate.update(insertSegmentInit, new Object[] { 0,
//				"DEFRAG_CONTAINER_ID", -1 });
//		jdbcTemplate.update(insertSegmentInit, new Object[] { 1,
//				"FLOW_CONTROL_ENABLED", "true" });

		int segmentid = 0;
		int containerId=1;
		int startsegmentid = 0;
		int icount = 201;
		for (int index = 0; index < icount; index++) {

			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(insertPerson, new Object[] { index,
					"EXTERNAL_ID_" + index, "AAAAA".getBytes(), 12121 + index,
					epochTimeNum, 0, 1, 1 });

			sumsize += 12121 + index;

			if (sumsize > (200000 - (12121 + index + 1))) {
				segmentid++;
				jdbcTemplate.update(insertSegments, new Object[] { segmentid,
						containerId, startsegmentid, index, sumsize,
						index - startsegmentid, 1, 1, sumsize });
				startsegmentid = index + 1;
				startsegId.add(startsegmentid);
				startsegId.add(segmentid);
				sumsize = 0;
			}
			if (index >= (icount - 1)) {
				if (sumsize != 0) {
					segmentid++;
					jdbcTemplate.update(insertSegments, new Object[] {
							segmentid, containerId, startsegmentid, index,
							sumsize, index - startsegmentid, 1, 1, sumsize });
					startsegmentid = index;
					startsegId.add(startsegmentid);
					startsegId.add(segmentid);
					sumsize = 0;
				}
			}

		}

		// int index = 0;
		// for (int j = 0; j < startsegId.size(); j += 2) {
		// for (; index < 2000; index++) {
		// if (index <= startsegId.get(j)) {
		// jdbcTemplate.update(insertSegmentChange, new Object[] {
		// index, index, startsegId.get(j + 1), index, 0 });
		// } else {
		// break;
		// }
		// }
		// }

		jdbcTemplate.execute("commit");
	}

	public static void insert_JOB(JdbcTemplate jdbcTemplate, int jobstatus) {
		int fusionjobid = 0;
		int jobid = 0;
		int containerjobId = 0;
//		int segmentjobid = 0;
		final String segmentCount = "select count(*) FROM segments";
//		final String insertMuJobs = "insert into mu_jobs (mu_job_id, segment_set_job_id, mu_id, "
//				+ "job_state) values(?, ?, 10, ?)";

		final String insertContainerJobs = "insert into CONTAINER_JOBS (CONTAINER_JOB_ID,CONTAINER_ID, fusion_job_id)"
				+ " values(?, ?, ?)";

		final String insertFusionJobs = "insert into fusion_jobs (FUSION_JOB_ID, FUNCTION_ID, INQUIRY_JOB_DATA,"
				+ "JOB_ID, SEARCH_REQUEST_INDEX) values(?,?,?,?,?)";

		final String insertJobQueue = "insert into job_queue(JOB_ID, priority, job_state,SUBMISSION_TS,CALLBACK_STYLE,FAMILY_ID) values(?,?,?,?,?,?)";

		int containerId = 1;
		
		jdbcTemplate.update("insert into MATCH_UNITS(MU_ID, UNIQUE_ID, STATE)"
				+ " values(10, '10', 'WORKING')");
		
		int icount = jdbcTemplate.queryForInt(segmentCount);
		for (int x = 1; x <= icount; x++) {
			if (x == 1) {
				jobid++;
				long epochTimeNum=System.currentTimeMillis();
				jdbcTemplate.update(insertJobQueue, new Object[] { jobid, 1,
						jobstatus, epochTimeNum, 0, 1 });
				jdbcTemplate.execute("commit");

				fusionjobid++;
				jdbcTemplate.update(insertFusionJobs, new Object[] {
						fusionjobid, 1, "AAAAAA", jobid, 1 });
				jdbcTemplate.execute("commit");
				containerjobId++;
				jdbcTemplate.update(insertContainerJobs, new Object[] {
						containerjobId, containerId, fusionjobid });
				jdbcTemplate.execute("commit");
//				segmentjobid++;
//				jdbcTemplate.update(insertMuJobs, new Object[] {
//						segmentjobid, containerjobId, 0 });
				jdbcTemplate.execute("commit");
			} else if (x % 25 == 0) {
				fusionjobid++;
				jdbcTemplate.update(insertFusionJobs, new Object[] {
						fusionjobid, 1, "AAAAAA", jobid, 1 });

				jdbcTemplate.execute("commit");
			} else if (x % 15 == 0) {
				containerjobId++;
				jdbcTemplate.update(insertContainerJobs, new Object[] {
						containerjobId, containerjobId, fusionjobid });
				jdbcTemplate.execute("commit");

			}
//			segmentjobid++;
//			jdbcTemplate.update(insertMuJobs, new Object[] { segmentjobid,
//					containerjobId, 0 });
			jdbcTemplate.execute("commit");

		}
	}

	public static int RandomParam01(int idx, int[] intRet, long[] longSegid) {
		Random random = new Random();
		boolean bl = false;
		int count = 0;
		int x = idx;
		for (int i = 0; i < startsegId.size() - 2; i += 2) {
			int result = 0;
			do {
				bl = false;
				if (i == 0) {
					result = Math.abs(random.nextInt(startsegId.get(i) + 1));
				} else {
					result = Math
							.abs(random.nextInt((startsegId.get(i) - startsegId
									.get(i - 2)))
									+ startsegId.get(i - 2));
				}
				for (int j = 0; j < count; j++) {
					if (result == intRet[j]) {
						bl = true;
						break;
					}
				}
				if (bl == false) {
					intRet[count] = result;
					longSegid[count] = startsegId.get(i + 1);
					count++;
					x--;
					if (x <= 0) {
						x = idx;
						break;
					}
				}
			} while (true);
		}
		return count;
	}

	public static int RandomParam(int idx, int[] intRet, long[] longSegid) {
		int count = 0;
		int x = idx;
		for (int i = 0; i < startsegId.size() - 2; i += 2) {
			int result = startsegId.get(i);
			do {
				result--;

				intRet[count] = result;
				longSegid[count] = startsegId.get(i + 1);
				count++;
				x--;
				if (x <= 0) {
					x = idx;
					break;
				}

			} while (true);
		}
		return count;
	}

	public static void update_JOB(JdbcTemplate jdbcTemplate, int jobstatus) {

		final String update_JobState = "update CONTAINER_JOBS SET job_state=? ";
		final String update_JobQueue = "update JOB_QUEUE SET job_state=? ";
		jdbcTemplate.update(update_JobState, new Object[] { jobstatus });
		jdbcTemplate.update(update_JobQueue, new Object[] { jobstatus });
		jdbcTemplate.execute("commit");
	}

	public static int deleteItem(JdbcTemplate jdbcTemplate, int deleteCount)
			throws SQLException {
		final String deletePerson = "delete from person_biometrics where BIOMETRICS_ID=?";
		// final String insertSegmentChange = "insert into segment_change_log"
		// +
		// "(SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) "
		// + "values(?,?,?,?,?)";
		final String selectperson = "select BIOMETRIC_DATA_LEN from person_biometrics where BIOMETRICS_ID=?";
		final String selectsegments = "select BINARY_LENGTH_COMPACTED from segments where SEGMENT_ID=?";
		final String updateSegments = "Update segments SET BINARY_LENGTH_COMPACTED=? WHERE SEGMENT_ID=?";
		int[] intRet = new int[2048];
		long[] longSegid = new long[2048];
		int total = 0;
		int count = RandomParam(deleteCount, intRet, longSegid);
		for (int idx = 0; idx < count; idx++) {
			long biometricdatalen = jdbcTemplate.queryForLong(selectperson,
					new Object[] { intRet[idx] });
			long binarylengthcompacted = jdbcTemplate.queryForLong(
					selectsegments, new Object[] { longSegid[idx] });
			jdbcTemplate.update(updateSegments, new Object[] {
					binarylengthcompacted - biometricdatalen, longSegid[idx] });

			jdbcTemplate.update(deletePerson, new Object[] { intRet[idx] });
			// jdbcTemplate.update(insertSegmentChange, new Object[] { 2000 +
			// idx,
			// intRet[idx], longSegid[idx], 2000 + idx, 1 });
			jdbcTemplate.execute("commit");

			total++;
		}
		System.out.println("total: " + total);
		System.out.println("count: " + count);
		return count;
	}

	public static void insertItem(JdbcTemplate jdbcTemplate)
			throws ParseException {

		DateFormat dateFormat;

		dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

		dateFormat.setLenient(false);

		final String insertPerson = "insert into person_biometrics"
				+ "(BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)"
				+ " values(?,?,?,?,?,?,?,?)";
		final String insertSegmentChange = "insert into segment_change_log"
				+ "(SEGMENT_CHANGE_ID,BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE) "
				+ "values(?,?,?,?,?)";
		final String insertSegments = "update segments set bio_id_end=? , binary_length_compacted=? where segment_id=?";
		final String selectSegment = "select bio_id_start, bio_id_end, binary_length_compacted "
				+ "from segments where segment_id=?";

		final String selectLastSegId = "select Max(segment_id) FROM segments";
		int lastsegmentId = jdbcTemplate.queryForInt(selectLastSegId);
		Map<String, Object> map = jdbcTemplate.queryForMap(selectSegment,
				new Object[] { lastsegmentId });

		Integer startId = Integer.valueOf(map.get("bio_id_start").toString());
		Integer endId = Integer.valueOf(map.get("bio_id_end").toString());
		Integer binarylength = Integer.valueOf(map.get(
				"binary_length_compacted").toString());

		int sumSize = binarylength;
		if ((sumSize + 12121 + endId) > 200000) {
			return;
		}
		while (true) {
			endId++;
			sumSize += 12121 + endId;
			if (sumSize > (200000 - (12121 + endId + 1))) {
				jdbcTemplate.update(insertSegments, new Object[] { endId,
						sumSize, lastsegmentId });
				startId = endId;
				startsegId.add(startId);
				startsegId.add(lastsegmentId);
				break;
			}
			long epochTimeNum=System.currentTimeMillis();
			jdbcTemplate.update(insertPerson, new Object[] { endId,
					"EXTERNAL_ID_" + endId, "AAAAA".getBytes(), 12121 + endId,
					epochTimeNum, 0, 1, 1 });
			jdbcTemplate.update(insertSegmentChange, new Object[] { endId,
					endId, lastsegmentId, endId, 0 });
		}
	}

	public static void deleteInformation(JdbcTemplate jdbcTemplate)
			throws SQLException {
//		final String deleteSYSINIT = "delete from SYSTEM_INIT";
		final String deletePerson = "delete from person_biometrics";
		final String deleteSegmentChange = "delete from segment_change_log ";
		final String deleteJobqueue = "delete from job_queue";
		final String deleteFusionjobs = "delete from fusion_jobs";
		final String deletecontainerjobs = "delete from container_jobs ";
		final String deleteSegments = "delete from segments";
		final String deleteMUs = "delete from match_units";
		final String deleteSegDefrag = "delete from segment_defragmentation";
//		jdbcTemplate.update(deleteSYSINIT);
		jdbcTemplate.update(deletePerson);
		jdbcTemplate.update(deleteSegmentChange);
		jdbcTemplate.update(deleteJobqueue);
		jdbcTemplate.update(deleteFusionjobs);
		jdbcTemplate.update(deletecontainerjobs);
		jdbcTemplate.update(deleteSegments);
		jdbcTemplate.update(deleteMUs);
		jdbcTemplate.update(deleteSegDefrag);
		jdbcTemplate.execute("commit");
		startsegId.clear();
	}

	public static double getDataRadio(JdbcTemplate jdbcTemplate, Long segmentId) {
		final String selectSegment = "select bio_id_start, bio_id_end, binary_length_compacted "
				+ "from segments where segment_id=?";
		final String selectperson = "select sum(biometric_data_len )from person_biometrics where biometrics_id>=? and biometrics_id<=?";
		Map<String, Object> map = jdbcTemplate.queryForMap(selectSegment,
				new Object[] { segmentId });

		Integer startId = Integer.valueOf(map.get("bio_id_start").toString());
		Integer endId = Integer.valueOf(map.get("bio_id_end").toString());
		Integer binaryMaxlength = 200000;
		Integer binarylength02 = jdbcTemplate.queryForInt(selectperson,
				new Object[] { startId, endId });

		double x = (double) binarylength02 / (double) binaryMaxlength;
		return x;
	}

	public static double getFragRadio(JdbcTemplate jdbcTemplate, Long segmentId) {
		double x = getDataRadio(jdbcTemplate, segmentId);
		double y = 1 - x;
		return y;
	}

	public static List<Map<String, Object>> getSegmentInfo(
			JdbcTemplate jdbcTemplate) {
		final String selectSegment = "select * from segments";
		List<Map<String, Object>> jdbcresult = jdbcTemplate
				.queryForList(selectSegment);
		return jdbcresult;
	}

	public static List<Map<String, Object>> getPersonInfo(
			JdbcTemplate jdbcTemplate) {
		final String selectSegment = "select * from person_biometrics";
		List<Map<String, Object>> jdbcresult = jdbcTemplate
				.queryForList(selectSegment);
		return jdbcresult;
	}

	public void insertContainer(JdbcTemplate jdbcTemplate) {
		String sql = "insert into \"CONTAINERS\"(CONTAINER_ID,CONTAINER_NAME,"
				+ "SCOPE_ID,FORMAT_ID,MAX_SEGMENT_SIZE)values(?,?,?,?,?)";
		jdbcTemplate.update(sql, new Object[] { 1, "RDBT", 1, 1, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 2, "SDBT", 1, 1, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 3, "RDBL", 1, 2, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 4, "SDBL", 1, 2, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 5, "PDB", 1, 14, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 321, "LDB", 1, 3, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 322, "PLDB", 1, 15, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 323, "RDBLS", 1, 7, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 324, "SDBLS", 1, 7, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 326, "LDBS", 1, 9, 20000000 });
		jdbcTemplate
				.update(sql, new Object[] { 331, "RDBTM", 1, 16, 20000000 });
		jdbcTemplate
				.update(sql, new Object[] { 332, "SDBTM", 1, 16, 20000000 });
		jdbcTemplate
				.update(sql, new Object[] { 333, "RDBLM", 1, 17, 20000000 });
		jdbcTemplate
				.update(sql, new Object[] { 334, "SDBLM", 1, 17, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 335, "FDB", 1, 18, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 336, "LDBM", 1, 19, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 341, "XDBL", 1, 20, 20000000 });
		jdbcTemplate.update(sql, new Object[] { 342, "LDBX", 1, 21, 20000000 });
	}
}
