package jp.co.nec.aim.df.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.util.ConnectionUtil;
import jp.co.nec.aim.df.util.ProxyUtil;
import mockit.Mock;
import mockit.MockUp;

public class DaoFactroyTest {

	private static Connection con;

	@BeforeClass
	public static void beforeClass() {
		if (con == null) {
			try {
				con = DataSourceCreator.getInstance().getDataSource()
						.getConnection();
			} catch (SQLException e) {
			}
		}
	}

	@AfterClass
	public static void afterClass() {
		ConnectionUtil.close(con);
		DataSourceCreator.getInstance().shutdownDataSource();
	}

	@Test
	public void testCreateDao_normally() throws SecurityException,
			NoSuchFieldException, IllegalArgumentException,
			IllegalAccessException, SQLException {
		MergerSegmentDao dao = DaoFactory.createDao(MergerSegmentDao.class);
		assertNotNull(dao);

		Field field = BaseDao.class.getDeclaredField("dataSource");
		field.setAccessible(true);
		BasicDataSource ds = (BasicDataSource) field.get(dao);
		Connection con = ds.getConnection();
		assertFalse(con.isClosed());
	}

	@Test
	public void testCreateDao_IllegalAccessException() {
		try {
			new MockUp<ProxyUtil>() {
				@Mock
				public <T> T getProxyInstance(Class<T> clazz) {
					throw new DefragmentDaoException(
							"IllegalAccessException occurred"
									+ " while create Dao instance");
				}
			};

			DaoFactory
					.createDao(DaoFactoryTestClass.ClassMethodWithIllegalAccessException.class);
		} catch (DefragmentDaoException ex) {
			assertEquals(ex.getMessage(), "IllegalAccessException occurred"
					+ " while create Dao instance");
			return;
		} finally {			
		}
		fail();
	}

	@Test
	public void testCreateDao_InstantiationException() {
		new MockUp<ProxyUtil>() {
			@Mock
			public <T> T getProxyInstance(Class<T> clazz)
					throws RuntimeException {
				throw new RuntimeException("InstantiationException occurred"
						+ " while create Dao instance");
			}
		};

		try {

			DaoFactory
					.createDao(DaoFactoryTestClass.AbstractClassInstantiationException.class);
		} catch (RuntimeException ex) {
			assertEquals(ex.getMessage(), "InstantiationException occurred"
					+ " while create Dao instance");
			return;
		} finally {			
		}
		fail();
	}

	@Test
	public void testCreateDao_NoSuchMethodException() {
		try {
			DaoFactory
					.createDao(DaoFactoryTestClass.ClassNoSuchMethodException.class);
		} catch (DefragmentDaoException ex) {
			assertEquals(ex.getMessage(), "NoSuchMethodException occurred"
					+ " while create Dao instance");
			return;
		}
		fail();
	}

	@Test
	public void testCreateDao_InvocationTargetException() {
		try {
			new MockUp<ProxyUtil>() {
				@Mock
				public <T> T getProxyInstance(Class<T> clazz) {
					throw new DefragmentDaoException(
							"InvocationTargetException occurred"
									+ " while create Dao instance");
				}
			};

			DaoFactory
					.createDao(DaoFactoryTestClass.ClassMethodWithInvocationTargetException.class);
		} catch (DefragmentDaoException ex) {
			assertEquals(ex.getMessage(), "InvocationTargetException occurred"
					+ " while create Dao instance");
			return;
		} finally {			
		}
		fail();
	}

	@Test
	public void testCreateDaoWithConnection_normally()
			throws SecurityException, NoSuchFieldException,
			IllegalArgumentException, IllegalAccessException, SQLException {

		MergerSegmentDao dao = DaoFactory
				.createDao(MergerSegmentDao.class, con);
		assertNotNull(dao);

		Field field = BaseDao.class.getDeclaredField("con");
		field.setAccessible(true);

		Connection connection = (Connection) field.get(dao);
		assertFalse(connection.isClosed());
	}

	@Test
	public void testCreateDaoWithConnection_InstantiationException() {
		try {
			new MockUp<ProxyUtil>() {
				@Mock
				public <T> T getProxyInstance(Class<T> clazz) {
					throw new DefragmentDaoException(
							"InstantiationException occurred"
									+ " while create Dao instance");
				}
			};

			DaoFactory
					.createDao(
							DaoFactoryTestClass.AbstractClassConInstantiationException.class,
							con);
		} catch (DefragmentDaoException ex) {
			assertEquals(ex.getMessage(), "InstantiationException occurred"
					+ " while create Dao instance");
			return;
		} finally {			
		}
		fail();
	}

	@Test
	public void testCreateDaoWithConnection_NoSuchMethodException() {
		try {
			DaoFactory.createDao(
					DaoFactoryTestClass.ClassConNoSuchMethodException.class,
					con);
		} catch (DefragmentDaoException ex) {			
			return;
		}
		fail();
	}

	@Test
	public void testCreateDaoWithConnection_InvocationTargetException() {
		try {
			DaoFactory
					.createDao(
							DaoFactoryTestClass.ClassConMethodWithInvocationTargetException.class,
							con);
		} catch (DefragmentDaoException ex) {
			assertEquals(ex.getMessage(), "InvocationTargetException occurred"
					+ " while create Dao instance");
			return;
		}

		fail();
	}

	@Test
	public void testCreateDaoWithConnection_IllegalAccessException() {
		try {
			new MockUp<ProxyUtil>() {
				@Mock
				public <T> T getProxyInstance(Class<T> clazz) {
					throw new DefragmentDaoException(
							"IllegalAccessException occurred"
									+ " while create Dao instance");
				}
			};

			DaoFactory
					.createDao(
							DaoFactoryTestClass.ClassConMethodWithIllegalAccessException.class,
							con);
		} catch (DefragmentDaoException ex) {
			assertEquals(ex.getMessage(), "IllegalAccessException occurred"
					+ " while create Dao instance");
			return;
		} finally {			
		}
		fail();
	}

}
