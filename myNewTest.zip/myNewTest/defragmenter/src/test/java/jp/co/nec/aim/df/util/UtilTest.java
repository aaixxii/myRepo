package jp.co.nec.aim.df.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;

import org.junit.Test;

import mockit.Mock;
import mockit.MockUp;

public class UtilTest {

	@Test
	public void testObjectIsNull() {
		assertTrue(Util.isObjectNull(null));
	}

	@Test
	public void testObjectIsNotNull() {
		assertFalse(Util.isObjectNull(new Object()));
	}

	@Test
	public void testIsMapNull() {
		assertTrue(Util.isMapNullOrEmpty(null));
	}

	@Test
	public void testIsMapEmpty() {
		assertTrue(Util.isMapNullOrEmpty(new HashMap<String, String>()));
	}

	@Test
	public void testIsMapNotEmpty() {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("key", "value");
		assertFalse(Util.isMapNullOrEmpty(map));
	}

	@Test
	public void testRemoveLastCommaNotContainComma() {
		final String notContainComma = "test";

		StringBuilder sb = new StringBuilder();
		sb.append(notContainComma);

		Util.removeLastComma(sb);
		assertEquals(sb.toString(), notContainComma);
	}

	@Test
	public void testRemoveLastCommaContainComma() {
		final String notContainComma = "test,";
		final String expectResult = "test";

		StringBuilder sb = new StringBuilder();
		sb.append(notContainComma);

		Util.removeLastComma(sb);
		assertEquals(sb.toString(), expectResult);
	}

	@Test
	public void testUtilTest_sleep() {
		try {
			new MockUp<Thread>() {
				@Mock
				public void sleep(long millis) throws InterruptedException {
					throw new InterruptedException("");
				}
			};

			Util.sleep(1000);
		}
		catch(Exception ex)
		{
			assertEquals(ex.getMessage(),"");		
		} finally {			
		}

	}
}
