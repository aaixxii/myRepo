package jp.co.nec.aim.df.service;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;

import jp.co.nec.aim.df.util.ProxyUtil;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ServiceFactoryTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public <T> void testCreateServiceClassOfTConnection() {
		try {
			new MockUp<ProxyUtil>() {
				@Mock
				public T getProxyInstance(Class<T> clazz) {
					return null;
				}
			};
			ServiceFactory t = ServiceFactory
					.createService(ServiceFactory.class);

			assertEquals(null, t);
		} finally {			
		}
	}

	@Test
	public void testCreateServiceClassOfT() {
		try {
			new MockUp<ProxyUtil>() {
				@Mock
				public <T> T getProxyInstance(Class<T> clazz, Connection conn) {
					return null;
				}
			};

			Connection conn = null;
			ServiceFactory t = ServiceFactory.createService(
					ServiceFactory.class, conn);
			assertEquals(null, t);
		} finally {			
		}

	}
}
