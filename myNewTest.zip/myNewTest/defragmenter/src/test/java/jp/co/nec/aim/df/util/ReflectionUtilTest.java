package jp.co.nec.aim.df.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import jp.co.nec.aim.df.util.ReflectionUtil;
import junit.framework.Assert;

import org.junit.Test;

public class ReflectionUtilTest {
    static final Object instance = new ReflectionTest();

    @Test
    public void testInvokeMethod() {
        Object ret = ReflectionUtil.invokeMethod(instance, "testRetString", null, null);
        String retStr = ((ReflectionTest) instance).testRetString();
        Assert.assertEquals((String) ret, retStr);
    }

    @Test
    public void testInvokeMethodWithParameter() {
        final String parameter = "hello world";
        Object ret = ReflectionUtil.invokeMethod(instance, "testRetStringWithPara",
                new Class[] { String.class }, new Object[] { parameter });
        String retStr = ((ReflectionTest) instance).testRetStringWithPara(parameter);
        Assert.assertEquals((String) ret, retStr);
    }

    @Test
    public void testInvokeMethodByName() {
        Object ret = ReflectionUtil.invokeMethodByName(instance, "testRetString", null);
        String retStr = ((ReflectionTest) instance).testRetString();
        Assert.assertEquals((String) ret, retStr);
    }

    @Test
    public void testGetAccessibleMethod() throws IllegalArgumentException, IllegalAccessException,
            InvocationTargetException {
        final String parameter = "hello world";
        Method m = ReflectionUtil.getAccessibleMethod(instance, "testRetStringWithPara",
                new Class[] { String.class });
        Assert.assertEquals(parameter, m.invoke(instance, parameter));
    }

    @Test
    public void testGetAccessibleMethodByName() throws IllegalArgumentException,
            IllegalAccessException, InvocationTargetException {
        final String parameter = "hello world";
        Method m = ReflectionUtil.getAccessibleMethodByName(instance, "testRetString");
        Assert.assertEquals(parameter, m.invoke(instance, new Object[] {}));
    }

    @Test
    public void testMakeAccessible() throws SecurityException, NoSuchMethodException {
        Method m = ReflectionTest.class.getDeclaredMethod("testPrivate", new Class[] {});
        Assert.assertFalse(m.isAccessible());
        ReflectionUtil.makeAccessible(m);
        Assert.assertTrue(m.isAccessible());
    }

    static class ReflectionTest {
        public String testRetString() {
            return "hello world";
        }

        public String testRetStringWithPara(String str) {
            return str;
        }

        @SuppressWarnings("unused")
        private void testPrivate() {
        }

    }

}
