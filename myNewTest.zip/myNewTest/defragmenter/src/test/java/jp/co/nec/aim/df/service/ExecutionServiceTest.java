package jp.co.nec.aim.df.service;

import static org.apache.commons.io.IOUtils.write;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.df.common.HttpTestServer;
import jp.co.nec.aim.df.common.StaticChange;
import jp.co.nec.aim.df.constant.SystemConstant;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.data.DataGeneration;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentVersion;
import jp.co.nec.aim.df.exception.CommunicationException;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.exception.PollContainerJobsTimeOutException;
import jp.co.nec.aim.df.exception.ReturnValueNotSuccessException;
import jp.co.nec.aim.df.exception.VersionNotMatchException;
import jp.co.nec.aim.df.util.ConsoleUtil;
import mockit.Mock;
import mockit.MockUp;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.dbcp.DelegatingConnection;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class ExecutionServiceTest {
	@Resource
	private JdbcTemplate jdbcTemplate;

	private static final ContainerInitService initService = new ContainerInitService();
	private final MakePlanService makePlanService = new MakePlanService();
	private List<ContainerSummary> containerList;
	private List<Plan> planArray;
	private static int times = 5;
	private static ExecutionService executionservice;
	private static HttpTestServer _server;
	private static int eventcase = 0;
	private static volatile int time = 2000;
	private static int idx = 0;
	private static DataCreatorUtil creator;
	@Rule
	public TestName name = new TestName();

	@BeforeClass
	public static void initClass() throws Exception {
		_server = new HttpTestServer(55513);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void endClass() throws Exception {
		creator.updateMaxSegmentSize(DataCreatorUtil.correctMaxSize, 1);
		if (_server != null) {
			_server.stop();
			_server = null;
		}
		DataSourceCreator.getInstance().shutdownDataSource();
	}

	@Before
	public void setUp() throws Exception {

		eventcase = 0;
		idx = 0;
		time = 0;

		if (planArray != null) {
			if (!planArray.isEmpty()) {
				planArray.clear();
			}
		}
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}

		creator.updateMaxSegmentSize(200000, 1);

		if (executionservice == null) {
			executionservice = ServiceFactory
					.createService(ExecutionService.class);
		}

		DataGeneration.deleteInformation(jdbcTemplate);

		final String methodName = name.getMethodName();
		if (methodName
				.equalsIgnoreCase("testPersistSegmentTheVersionIsNotMatch_MMCare_true")) {
			creator.createGetPersonRangeInfoMergerBeyond4SegsResultIs1();
		} else {
			DataGeneration.insertTotalInformation(jdbcTemplate);
			DataGeneration.deleteItem(jdbcTemplate, times);
		}

		StaticChange.setFinalStatic(
				SystemConstant.class.getField("LEVEL_ERRORS"), 0.005);
		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			planArray = makePlanService.makePlan(container);
			ConsoleUtil.displayPlan(planArray);
		}
		StaticChange.setFinalStatic(
				SystemConstant.class.getField("LEVEL_ERRORS"), 0.05);
		creator.cleanAndSetRUC();
		creator.initDefragContainerId();
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {

		DataGeneration.deleteInformation(jdbcTemplate);
		if (planArray != null) {
			if (!planArray.isEmpty()) {
				planArray.clear();
			}
		}
		executionservice = null;
		eventcase = 0;
		idx = 0;
		time = 0;
	}

	public static Handler getMockHandler() {

		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {

				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();

				switch (eventcase) {
				case 0:
					idx++;
					if (idx >= 2) {
						response.setStatus(200);
						write("-1", response.getOutputStream());
						break;
					}
					response.setStatus(200);
					write("1", response.getOutputStream());
					break;

				case 1:
					try {
						System.out.println(time);
						time -= 2000;
						if (time < 0) {
							time = 0;
						}
						Thread.sleep(time);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					response.setStatus(200);
					write("2", response.getOutputStream());
					break;
				case 2:
					idx++;
					if (idx >= 2) {
						try {
							System.out.println(time);
							time -= 2000;
							if (time < 0) {
								time = 0;
							}
							Thread.sleep(time);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						response.setStatus(200);
						write("-1", response.getOutputStream());
						break;
					}
					response.setStatus(200);
					write("1", response.getOutputStream());
					break;

				case 3:
					idx++;
					if (idx == 2) {
						try {
							System.out.println(time);
							time -= 2000;
							if (time < 0) {
								time = 0;
							}
							Thread.sleep(time);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						response.setStatus(200);
						write("1", response.getOutputStream());
						break;
					}
					response.setStatus(200);
					write("1", response.getOutputStream());
					break;
				case 4:
					if (time <= 2000) {
						response.setStatus(200);
						write("-1", response.getOutputStream());
						break;
					}
					try {
						System.out.println(time);
						time -= 2000;
						if (time < 0) {
							time = 0;
						}
						Thread.sleep(time);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					response.setStatus(200);
					write("1", response.getOutputStream());
					break;
				}

				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}

		};
		return handler;
	}

	// TODO
	@Test
	public void testPlanExecution() throws Exception {
		eventcase = 2;
		time = 2000;

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		executionservice.planExecution(planArray);

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(13, result01.size());
		assertEquals(10, result02.size());
	}

	@Test
	public void testPlanExecution_checkParamterPlansIsNull() throws Exception {
		planArray.clear();
		planArray = null;
		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);
		try {
			executionservice.planExecution(planArray);
			assertFalse(
					"IllegalArgumentException is not occoured in planExecution method",
					true);
		} catch (IllegalArgumentException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(
					"IllegalArgumentException is not occoured in planExecution method",
					true);
		}

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(13, result01.size());
		assertEquals(13, result02.size());
	}

	@Test
	public void testPlanExecution_checkParamterPlansIsEmpty() throws Exception {
		planArray.clear();

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);
		try {
			executionservice.planExecution(planArray);
			assertFalse(
					"DefragmentServiceException is not occoured in planExecution method",
					true);
		} catch (DefragmentServiceException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(
					"DefragmentServiceException is not occoured in planExecution method",
					true);
		}
		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(13, result01.size());
		assertEquals(13, result02.size());
	}

	/**
	 * 
	 * @param mmCare
	 * @throws NoSuchFieldException
	 * @throws SecurityException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 */
	private void setMMCare(boolean mmCare) throws SecurityException,
			NoSuchFieldException, IllegalArgumentException,
			IllegalAccessException {
		Field field = ExecutionService.class.getDeclaredField("isMMCare");
		field.setAccessible(true);
		field.set(executionservice, mmCare);
		field.setAccessible(false);
	}

	/**
	 * send Signal to MM to stop the defragment control, CommunicationException
	 * occurred..
	 */
	@Test
	public void testPlanExecution_sendSignalToStopControl_CommunicationException()
			throws Exception {
		setMMCare(true);

		eventcase = 2;
		time = 20000;
		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);
		try {
			executionservice.planExecution(planArray);
			assertFalse(
					"CommunicationException is not occoured in planExecution method",
					true);
		} catch (CommunicationException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(
					"CommunicationException is not occoured in planExecution method",
					true);
		}
		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(13, result01.size());
		assertEquals(10, result02.size());
	}

	// TODO
	@Test
	public void testPlanExecution_waitUntilJobDone() throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		setMMCare(false);

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		executionservice.planExecution(planArray);
		ConsoleUtil.displayPlan(planArray);
		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(result01.size(), 13);
		assertEquals(result02.size(), 10);
		int version = 0;
		int reversion = 0;
		for (int i = 0; i < result02.size(); i++) {
			if (i <= 8) {
				version = Integer.valueOf(result02.get(i).get("VERSION")
						.toString());
				assertEquals(2001, version);

				reversion = Integer.valueOf(result02.get(i).get("REVISION")
						.toString());
				assertEquals(2001, reversion);
			} else {
				version = Integer.valueOf(result02.get(i).get("VERSION")
						.toString());
				assertEquals(1, version);

				reversion = Integer.valueOf(result02.get(i).get("REVISION")
						.toString());
				assertEquals(1, reversion);
			}

		}
	}

	/** ContainerIdIsNotCurrentException **/
	// TODO
	@Test
	@Ignore
	public void testPlanExecution_waitUntilJobDone_MMCaretrue()
			throws Exception {
		eventcase = 2;
		time = 2000;

		setMMCare(true);

		DataGeneration.insert_JOB(jdbcTemplate, 1);
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		new MockUp<BinDefragService>() {
			@Mock
			public Long getTrifficContainerId() {
				return new Long(2);
			}

		};

		try {
			executionservice.planExecution(planArray);

			List<Map<String, Object>> result02 = DataGeneration
					.getSegmentInfo(jdbcTemplate);
			assertEquals(result02.size(), 13);
			assertEquals(result01.size(), 13);
		} finally {			
		}
	}

	@Test
	public void testPlanExecution_waitUntilJobDone_MMCaretrue_PollContainerJobsTimeOutException()
			throws Exception {
		eventcase = 2;
		time = 2000;

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);
		DataGeneration.insert_JOB(jdbcTemplate, 1);
		setMMCare(true);

		try {
			executionservice.planExecution(planArray);
			assertFalse(
					"can not catch PollContainerJobsTimeOutException in planExecution",
					true);
		} catch (PollContainerJobsTimeOutException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(
					"can not catch PollContainerJobsTimeOutException in planExecution",
					true);
		}

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);
		assertEquals(result02.size(), 13);
		assertEquals(result01.size(), 13);
	}

	/**
	 * 
	 * @throws SQLException
	 */
	@Test
	public void testPlanExecution_init_SQLException() {

		MockUp<BasicDataSource> mocked = new MockUp<BasicDataSource>() {
			@Mock
			public Connection getConnection() throws SQLException {
				throw new SQLException();
			}

		};
		try {
			new ExecutionService();
			assertFalse(
					"can not catch PollContainerJobsTimeOutException in ExecutionService",
					true);
		} catch (DefragmentServiceException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(
					"can not catch DefragmentServiceException in ExecutionService",
					true);
		} finally {	
			mocked.tearDown();
		}
	}

	/**
	 * sql Exception occurred while plan Execution, roll back the connection
	 * 
	 * @throws SQLException
	 */
	// TODO
	@Test
	public void testPlanExecution_doPlanTransaction_SQLException()
			throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		MockUp<DelegatingConnection> mocked = new MockUp<DelegatingConnection>() {
			@Mock
			public void setAutoCommit(boolean autoCommit) throws SQLException {
				throw new SQLException();
			}

		};
		try {
			executionservice.planExecution(planArray);
		} finally {	
			mocked.tearDown();
		}

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(result02, result01);
	}

	@Test
	public void testPlanExecution_doPlanTransaction_ContainerIdIsNotCurrentException()
			throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		final String deleteSYSINIT = "delete from SYSTEM_INIT";
		final String deleteSYSDEFRAG = "delete from SEGMENT_DEFRAGMENTATION";
		jdbcTemplate.update(deleteSYSINIT);
		jdbcTemplate.update(deleteSYSDEFRAG);
		jdbcTemplate.execute("commit");

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		setMMCare(true);
		executionservice.planExecution(planArray);

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertNotSame(result02, result01);
		assertEquals(13, result01.size());
		assertEquals(10, result02.size());
	}

	@Test
	public void testPlanExecution_doPlanTransaction_VersionNotMatchException()
			throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		MockUp<PersistSegmentService> mocked = new MockUp<PersistSegmentService>() {
			@Mock
			public final void persistSegment(final Plan plan) {
				throw new VersionNotMatchException("");
			}

		};

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		try {
			executionservice.planExecution(planArray);
		} finally {	
			mocked.tearDown();
		}

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(result02, result01);

	}

	@Test
	public void testPlanExecution_doPlanTransaction_DefragmentDaoException()
			throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		MockUp<PersistSegmentService> mocked = new MockUp<PersistSegmentService>() {
			@Mock
			public final void persistSegment(final Plan plan) {
				throw new DefragmentDaoException("");
			}

		};

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		try {
			executionservice.planExecution(planArray);
		} finally {	
			mocked.tearDown();
		}

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(result02, result01);

	}

	@Test
	public void testPlanExecution_doPlanTransaction_IllegalArgumentException()
			throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		MockUp<PersistSegmentService> mocked = new MockUp<PersistSegmentService>() {
			@Mock
			public final void persistSegment(final Plan plan) {
				throw new IllegalArgumentException();
			}

		};

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		try {
			executionservice.planExecution(planArray);
		} finally {	
			mocked.tearDown();
		}

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(result02, result01);

	}

	// TODO
	@Test
	public void testPlanExecution_doPlanTransaction_DefragmentServiceException()
			throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		MockUp<PersistSegmentService> mocked = new MockUp<PersistSegmentService>() {
			@Mock
			public final void persistSegment(final Plan plan) {
				throw new DefragmentServiceException("");
			}

		};

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);
		try {
			executionservice.planExecution(planArray);
		} finally {	
			mocked.tearDown();
		}
		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		assertEquals(result02, result01);
		assertEquals(13, result01.size());
		assertEquals(13, result02.size());

	}

	// TODO
	@Test
	@Ignore
	public void testPlanExecution_waitUntilJobDone_ReDo() throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		executionservice.planExecution(planArray);

		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);
		assertEquals(result02.size(), 10);
		assertEquals(result01.size(), 13);
		int version = 0;
		int reversion = 0;
		for (int i = 0; i < result02.size(); i++) {
			if (i <= 8) {
				version = Integer.valueOf(result02.get(i).get("VERSION")
						.toString());
				assertEquals(2001, version);

				reversion = Integer.valueOf(result02.get(i).get("REVISION")
						.toString());
				assertEquals(2001, reversion);
			} else {
				version = Integer.valueOf(result02.get(i).get("VERSION")
						.toString());
				assertEquals(1, version);

				reversion = Integer.valueOf(result02.get(i).get("REVISION")
						.toString());
				assertEquals(1, reversion);
			}

		}
	}

	// TODO
	@Test
	@Ignore
	public void testPlanExecution_waitUntilJobDone_isMMCare() throws Exception {
		eventcase = 2;
		time = 2000;
		try {
			polltest.DoUpdate();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		List<Map<String, Object>> result01 = DataGeneration
				.getSegmentInfo(jdbcTemplate);

		setMMCare(false);

		executionservice.planExecution(planArray);
		List<Map<String, Object>> result02 = DataGeneration
				.getSegmentInfo(jdbcTemplate);
		assertEquals(result02.size(), 10);
		assertEquals(result01.size(), 13);
		int version = 0;
		int reversion = 0;
		for (int i = 0; i < result02.size(); i++) {
			if (i <= 8) {
				version = Integer.valueOf(result02.get(i).get("VERSION")
						.toString());
				assertEquals(2001, version);

				reversion = Integer.valueOf(result02.get(i).get("REVISION")
						.toString());
				assertEquals(2001, reversion);
			} else {
				version = Integer.valueOf(result02.get(i).get("VERSION")
						.toString());
				assertEquals(1, version);

				reversion = Integer.valueOf(result02.get(i).get("REVISION")
						.toString());
				assertEquals(1, reversion);
			}
		}
	}

	/**
	 * send Signal to MM to start the defragment control,
	 * ReturnValueNotSuccessException occurred..
	 */
	@Test
	public void testPlanExecution_sendSignalToStartControl_ReturnValueNotSuccessException()
			throws Exception {
		setMMCare(true);
		eventcase = 1;
		creator.setDefragContainerId(2);
		jdbcTemplate.execute("commit");
		try {
			executionservice.planExecution(planArray);
			assertFalse(
					"ReturnValueNotSuccessException is not occoured in planExecution",
					true);
		} catch (ReturnValueNotSuccessException ex) {
			assertTrue(ex.getMessage(), true);
		} catch (Exception ex) {
			assertFalse(
					"ReturnValueNotSuccessException is not occoured in planExecution",
					true);
		}

	}

	// TODO
	@Test
	@Ignore
	public void testPersistSegmentTheVersionIsLockedSegmentRow_MMCare_true()
			throws Exception {
		try {
			setMMCare(true);

			Plan plan = creator.createPlanMergerBeyond4SegsResultIs1();
			List<Plan> plans = new ArrayList<Plan>();
			plans.add(plan);
			executionservice.planExecution(plans);

			String sql = "select SEGMENT_ID from segments where SEGMENT_ID in ("
					+ "1,2,3,4" + ") for update skip locked";
			List<SegmentVersion> versions = jdbcTemplate.query(sql,
					new Object[] {},//
					new BeanPropertyRowMapper<SegmentVersion>(
							SegmentVersion.class));

			assertEquals(versions.size(), 4);
		} finally {
		}
	}

	// TODO
	@Test
	@Ignore
	public void testPersistSegmentTheVersionIsNotMatch_MMCare_true()
			throws Exception {
		try {
			setMMCare(true);
			Plan plan = creator
					.createPlanMergerBeyond4SegsResultIs1_VersionIsNotMatch();
			List<Plan> plans = new ArrayList<Plan>();
			plans.add(plan);
			executionservice.planExecution(plans);

			String sql = "select SEGMENT_ID from segments where SEGMENT_ID in ("
					+ "1,2,3,4" + ")";
			List<SegmentVersion> versions = jdbcTemplate.query(sql,
					new Object[] {},//
					new BeanPropertyRowMapper<SegmentVersion>(
							SegmentVersion.class));
			assertEquals(versions.size(), 4);
		} finally {
		}
	}

	@Test
	public void testPlanExecution_waitUntilJobDone_isMMCarefalse_isAlivefalse_isJobRemain()
			throws Exception {
		eventcase = 2;
		time = 2000;

		DataGeneration.insert_JOB(jdbcTemplate, 1);

		if (_server != null) {
			_server.stop();
		}

		setMMCare(false);

		try {
			executionservice.planExecution(planArray);
			ConsoleUtil.displayPlan(planArray);
		} finally {
			if (_server != null)
				_server.start(getMockHandler());
		}
	}

}
