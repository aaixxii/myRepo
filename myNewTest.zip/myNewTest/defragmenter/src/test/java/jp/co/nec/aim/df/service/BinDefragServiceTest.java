package jp.co.nec.aim.df.service;

import static junit.framework.Assert.assertEquals;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.df.dao.RUCDao;
import jp.co.nec.aim.df.dao.SegmentDefragDao;
import jp.co.nec.aim.df.data.DataCreatorUtil;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.ReturnValueNotSuccessException;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class BinDefragServiceTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Rule
	public TestName name = new TestName();

	private static BinDefragService service;

	private static DataCreatorUtil creator;

	private static SegmentDefragDao segDefragDao;

	@BeforeClass
	public static void beforeClass() {
		DataSource ds = DataSourceCreator.getInstance().getDataSource();
		Connection connection = null;
		try {
			connection = ds.getConnection();
		} catch (SQLException e) {
		}
		service = new BinDefragService(connection);
	}

	@Before
	public void setUp() throws Exception {
		if (creator == null) {
			creator = new DataCreatorUtil(jdbcTemplate);
		}
		creator.initDefragContainerId();
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from resource_update_count");
		jdbcTemplate.execute("delete from segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testGetTrifficContainerId() {
		creator.setDefragContainerId(1);
		jdbcTemplate.execute("commit");
		assertEquals(1, service.getTrifficContainerId().intValue());
	}

	@Test(expected = ReturnValueNotSuccessException.class)
	public void testStartContainerDefrag() throws Exception {
		creator.setDefragContainerId(1);
		jdbcTemplate.execute("commit");
		service.startContainerDefrag(1);
	}

	/**
	 * @throws Exception 
	 * 
	 */
	@Test
	public void testStartContainerDefrag_01() throws Exception {
		creator.cleanAndSetRUC();
		creator.setDefragContainerId(-1);
		jdbcTemplate.execute("commit");
		service.startContainerDefrag(1);

		assertEquals(1, service.getTrifficContainerId().intValue());
		assertEquals(2, creator.getRUC().intValue());
	}

	/**
	 * @throws Exception 
	 * 
	 */
	@Ignore
	@Test(expected = DefragmentDaoException.class)
	public void testStartContainerDefrag_02() throws Exception {

		new MockUp<RUCDao>() {
			@Mock
			public void increaseRUC() {
				throw new DefragmentDaoException("DefragmentDaoException occoured in increaseRUC method.");
			}
		};
		try {
			creator.cleanAndSetRUC();
			creator.setDefragContainerId(-1);
			jdbcTemplate.execute("commit");
			service.startContainerDefrag(1);

			assertEquals(-1, service.getTrifficContainerId().intValue());
			assertEquals(1, creator.getRUC().intValue());
		} finally {			
		}
	}
	
	
	@Test(expected = ReturnValueNotSuccessException.class)
	public void testStopContainerDefrag() throws Exception {
		creator.setDefragContainerId(-1);
		jdbcTemplate.execute("commit");
		service.stopContainerDefrag(1);
	}

	/**
	 * @throws Exception 
	 * 
	 */
	@Test
	public void testStopContainerDefrag_01() throws Exception {
		creator.cleanAndSetRUC();
		creator.setDefragContainerId(1);
		jdbcTemplate.execute("commit");
		service.stopContainerDefrag(1);

		assertEquals(-1, service.getTrifficContainerId().intValue());
		assertEquals(2, creator.getRUC().intValue());
	}


}
