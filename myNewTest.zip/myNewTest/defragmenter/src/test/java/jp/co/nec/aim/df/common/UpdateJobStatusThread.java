package jp.co.nec.aim.df.common;

import jp.co.nec.aim.df.data.DataGeneration;

import org.springframework.jdbc.core.JdbcTemplate;

public class UpdateJobStatusThread extends Thread {

	private JdbcTemplate jdbcTemplate;

	private int jobstatus;

	public UpdateJobStatusThread(JdbcTemplate jdbcTemplate, int jobstatus) {
		this.jobstatus = jobstatus;
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void run() {
		DataGeneration.update_JOB(jdbcTemplate, jobstatus);
	}
}
