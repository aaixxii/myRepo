package jp.co.nec.aim.df.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.data.DataGeneration;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.exception.PollContainerJobsTimeOutException;
import jp.co.nec.aim.df.util.ConnectionUtil;
import jp.co.nec.aim.df.util.ConsoleUtil;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
@Transactional
public class PollFindJobServiceTest {

	@Resource
	private JdbcTemplate jdbcTemplate;

	static ContainerInitService initService = new ContainerInitService();
	MakePlanService makePlanService = new MakePlanService();
	List<ContainerSummary> containerList;
	List<Plan> planArray;
	static int times = 5;
	static boolean bJobNotWorking = false;
	PollFindJobService pollfindjobservice;
	Plan plan;
	private static Connection con;
	DataSource ds = DataSourceCreator.getInstance().getDataSource();

	@Before
	public void setUp() throws Exception {

		try {
			if (con == null) {
				con = ds.getConnection();
			}
		} catch (SQLException e) {
			String message = "can not get connection from datasource..";
			throw new DefragmentServiceException(message);
		}

		pollfindjobservice = new PollFindJobService(con);
		DataGeneration.deleteInformation(jdbcTemplate);
		DataGeneration.insertTotalInformation(jdbcTemplate);
		DataGeneration.deleteItem(jdbcTemplate, times);

		containerList = initService.initContainerSummary();
		for (ContainerSummary container : containerList) {
			planArray = makePlanService.makePlan(container);
			ConsoleUtil.displayPlan(planArray);
		}
	}

	@After
	public void tearDown() throws Exception {
		DataGeneration.deleteInformation(jdbcTemplate);
		planArray.clear();
	}

	@AfterClass
	public static void afterClass() {
		ConnectionUtil.close(con);
		DataSourceCreator.getInstance().shutdownDataSource();
	}

	@Test
	public void TimerServiceTest() throws InterruptedException {
		plan = planArray.get(0);
		DataGeneration.insert_JOB(jdbcTemplate, 1);
		DataGeneration.update_JOB(jdbcTemplate, 2);
		pollfindjobservice.waitUntilJobDone(plan);

	}

	@Test(expected = PollContainerJobsTimeOutException.class)
	public void TimeOutServiceTest() {
		plan = planArray.get(0);
		DataGeneration.insert_JOB(jdbcTemplate, 1);
		pollfindjobservice.waitUntilJobDone(plan);
	}

}