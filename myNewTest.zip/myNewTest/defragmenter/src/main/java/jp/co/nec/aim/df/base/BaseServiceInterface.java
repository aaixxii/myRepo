package jp.co.nec.aim.df.base;

import java.io.Serializable;

public interface BaseServiceInterface extends Serializable {
	void initialize();
}
