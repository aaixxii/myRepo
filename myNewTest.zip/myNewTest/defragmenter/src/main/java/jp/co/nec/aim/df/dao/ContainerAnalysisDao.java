package jp.co.nec.aim.df.dao;

import static jp.co.nec.aim.df.constant.SystemConstant.DEFAULT_MAX_SEGMENT_DIFFS;
import static jp.co.nec.aim.df.constant.SystemConstant.SEGMENT_HEADER_LENGTH;
import java.util.List;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.entity.TotalInformation;
import jp.co.nec.aim.df.exception.DefragmentDaoException;

/**
 * ContainerAnalysisDao <br>
 * initialize the each container information, <br>
 * segment information from database
 */
public class ContainerAnalysisDao extends BaseDao {

	/** list system container count, segment count and total binary size **/
	private static final String LIST_TOTAL_INFO = "select tmp1.container_count as totalContainerCount"
			+ "      ,tmp2.segment_count as totalsegmentcount"
			+ "      ,tmp2.binary_size as totalbinarysize"
			+ "  from ("
			+ "select count(container_count.container_id) as container_count"
			+ "  from ("
			+ "select b.container_id as container_id"
			+ "  from segments s"
			+ "      ,containers b"
			+ " where s.container_id = b.container_id"
			+ " group by b.container_id ) container_count ) tmp1"
			+ "         ,("
			+ "select sum(binary_length_compacted) as binary_size"
			+ "      ,count(segment_id) as segment_count"
			+ "  from segments ) tmp2";

	/** list the container summary **/
	private static final String LIST_CONTALNER_SUMMARY = "select b.container_id as containerid"
			+ "      ,b.scope as scope"
			+ "      ,b.container_name as containerName"
			+ "      ,ft.format_name as formatname"
			+ "      ,b.seg_number as segmentnumber"
			+ "      ,b.maxsegmentsize as maxsegmentsize"
			+ "  from ("
			+ "select cs.container_id as container_id"
			+ "      ,cs.scope_id as scope"
			+ "      ,cs.container_name as container_name"
			+ "      ,cs.format_id"
			+ "      ,cs.max_segment_size as maxsegmentsize"
			+ "      ,count(s.segment_id) as seg_number"
			+ "  from segments s"
			+ "      ,containers cs"
			+ " where s.container_id = cs.container_id"
			+ " group by cs.container_id"
			+ "         ,cs.scope_id"
			+ "         ,cs.container_name"
			+ "         ,cs.format_id"
			+ "         ,cs.max_segment_size) b"
			+ "         ,format_types ft"
			+ " where b.format_id = ft.format_id" + " order by b.container_id";

	/** list the segment summary **/
	private static final String LIST_SEGMENT_SUMMARY = "SELECT cs.container_id AS containerId, "
			+ "       s.segment_id AS segId, "
			+ "       (s.binary_length_compacted-"
			+ SEGMENT_HEADER_LENGTH
			+ ") / (cs.max_segment_size-"
			+ SEGMENT_HEADER_LENGTH
			+ ") AS dataRadio, "
			+ "       ( cs.max_segment_size - s.binary_length_compacted ) / (cs.max_segment_size-"
			+ SEGMENT_HEADER_LENGTH
			+ ") AS fragmentRadio, "
			+ "       s.bio_id_start AS startId, "
			+ "       s.bio_id_end AS endId, "
			+ "       s.record_count recordCount, "
			+ "       s.version AS version, "
			+ "       s.revision AS reversion, "
			+ "       s.version AS versionBackUp, "
			+ "       s.revision AS reversionBackUp, "
			+ "       s.binary_length_compacted AS blCompacted, "
			+ "       s.binary_length_uncompacted AS blunCompacted "
			+ "FROM   segments s, "
			+ "       containers cs "
			+ "WHERE  s.container_id = cs.container_id "
			+ "       and cs.container_id = ?" + "ORDER  BY s.segment_id ASC";

	/** get the BEHAVIOR.MAX_SEGMENT_DIFFS value from SYSTEM_CONFIG **/
	private static final String GET_MAX_SEGMENT_DIFFS = "SELECT property_value AS segmentDiffs FROM system_config "
			+ "where PROPERTY_NAME = 'BEHAVIOR.MAX_SEGMENT_DIFFS'";

	/** the alias of segmentDiffs **/
	private static final String COL_SEGMENT_DIFF = "segmentDiffs";

	/**
	 * getTotalInformation <br>
	 * get system container count, segment count and total binary size
	 * 
	 * @return TotalInformation instance
	 */
	public TotalInformation getTotalInformation() {
		TotalInformation totalinformation = null;
		try {
			prepareStatement(LIST_TOTAL_INFO);
			executeQuery();
			if (next()) {
				totalinformation = mapping(TotalInformation.class);
			}
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
			releaseConnectionToPoll();
		}
		return totalinformation;
	}

	/**
	 * getContainerSummary
	 * 
	 * @return List<ContainerSummary> the ContainerSummary list
	 */
	public List<ContainerSummary> getContainerSummary() {
		List<ContainerSummary> containerSummarylist = null;
		try {
			prepareStatement(LIST_CONTALNER_SUMMARY);
			executeQuery();
			containerSummarylist = mappingList(ContainerSummary.class);
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
			releaseConnectionToPoll();
		}
		return containerSummarylist;
	}

	/**
	 * get all Segment information belong to specified container id
	 * 
	 * @param containerId
	 *            the specified container id
	 * @return all Segment information belong to specified container id
	 */
	public List<SegmentSummary> getSegmentSummary(int containerId) {
		List<SegmentSummary> segmentSummarylist;
		try {
			prepareStatement(LIST_SEGMENT_SUMMARY);
			setParam(index, containerId);
			executeQuery();
			segmentSummarylist = mappingList(SegmentSummary.class);
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
			releaseConnectionToPoll();
		}
		return segmentSummarylist;
	}

	/**
	 * get the behavior.max_segment_diffs value from system_config
	 * 
	 * @return behavior.max_segment_diffs value
	 */
	public int getMaxSegmentDiffs() {
		int imaxSegmentDiffs;
		try {
			prepareStatement(GET_MAX_SEGMENT_DIFFS);
			executeQuery();
			if (next()) {
				imaxSegmentDiffs = getInt(COL_SEGMENT_DIFF);
			} else {
				imaxSegmentDiffs = DEFAULT_MAX_SEGMENT_DIFFS;
			}
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
			releaseConnectionToPoll();
		}
		return imaxSegmentDiffs;
	}
}
