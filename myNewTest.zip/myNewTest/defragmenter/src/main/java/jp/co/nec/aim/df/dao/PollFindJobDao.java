package jp.co.nec.aim.df.dao;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.constant.ContainerJobState;
import jp.co.nec.aim.df.exception.DefragmentDaoException;

/**
 * PollFindJobDao <br>
 * get the top job count which status is in (queue or working) with segment <br>
 * id, if return count > 0, that mean there is working or queue job in system <br>
 * the current thread sleep a short time, continue otherwise all the job is
 * done.. do persist the segment to database operation <br>
 */
public class PollFindJobDao extends BaseDao {

	/**
	 * find the top level job status is necessary due to if persist the segment
	 * into database with deletion operation, the container job related to deleted
	 * segment will be removed, at this time, if aggregation poll is not
	 * reached, the removed container jobs result will be lost. as above reason,
	 * we will wait until the top level jobs related to specified segment is
	 * done successfully.
	 */
    private final static String SELECT_JOB_STATUS_COUNT = "SELECT Count(job_id) "
            + "FROM   (SELECT jq.job_id "
            + "        FROM   job_queue jq, "
            + "               fusion_jobs fj, "
            + "               container_jobs cj, "
            + "               segments s "
            + "        WHERE  jq.job_id = fj.job_id "
            + "               AND fj.fusion_job_id = cj.fusion_job_id "
            + "               AND cj.container_id = s.container_id "
            + "               AND s.container_id = ? "
            + "               AND s.segment_id >= ? "
            + "               AND s.segment_id <= ? "
            + "               AND jq.job_state = ? "
            + "        GROUP  BY jq.job_id)";

	/**
	 * get the top job count which status is <br>
	 * in (queue or working) with segment id. <br>
	 * if return count > 0, that mean there is <br>
	 * working or queue job in system <br>
	 * otherwise all the job is done..
	 * 
	 * @param startSegId
	 *            start segment id
	 * @param endSegId
	 *            end segment id
	 * @return the job count that the status is in queue or working
	 */
	public int findJobStatus(final long startSegId, final long endSegId,
			int containerId) {
		int result = 0;
		try {
			prepareStatementCon(SELECT_JOB_STATUS_COUNT);
			setParam(index++, containerId);
			setParam(index++, startSegId);
			setParam(index++, endSegId);
			setParam(index++, ContainerJobState.WORKING.ordinal());
			executeQuery();
			result = getResultCount();
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
		}
		return result;
	}
}
