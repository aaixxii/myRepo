package jp.co.nec.aim.df.dbcp;

import java.sql.SQLException;

import javax.sql.DataSource;

import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.util.PropertiesUtil;

import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * dataSource creator <br>
 * create the single dataSource instance <br>
 */
public final class DataSourceCreator {
	/** the single instance **/
	private static DataSourceCreator INSTANCE;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(DataSourceCreator.class);

	DataSourceCreator() {
	}

	/**
	 * get single Instance
	 * 
	 * @return DataSorceCreator instance
	 */
	public static final synchronized DataSourceCreator getInstance() {
		if (log.isDebugEnabled()) {
			log.debug("start DataSourceCreator getInstance..");
		}

		if (INSTANCE == null) {
			INSTANCE = new DataSourceCreator();
		}
		if (log.isDebugEnabled()) {
			log.debug("end DataSourceCreator getInstance..");
		}
		return INSTANCE;
	}

	/** the dataSource instance **/
	private DataSource dataSource;

	/**
	 * getDataSource
	 * 
	 * @return the dataSource instance
	 */
	public synchronized final DataSource getDataSource() {
		if (log.isDebugEnabled()) {
			log.debug("start DataSourceCreator getDataSource..");
		}
		if (dataSource == null) {
			setupDateSource();
		}
		if (log.isDebugEnabled()) {
			log.debug("end DataSourceCreator getDataSource..");
		}
		return this.dataSource;
	}

	/**
	 * create dataSource instance <br>
	 * 1. set driver class name <br>
	 * 2. set user name <br>
	 * 3. set user password <br>
	 * 4. set connection uRL <br>
	 * 5. set AutoCommit flag <br>
	 * 6. set Initial Size <br>
	 * 7. set MaxActive <br>
	 * 8. set MaxIdle <br>
	 * 9. set MinIdle <br>
	 * 10. set MaxWait <br>
	 * 
	 * @throws DefragmentDaoException
	 */
	private final void setupDateSource() {
		if (log.isDebugEnabled()) {
			log.debug("start DataSourceCreator setupDateSource..");
		}

		BasicDataSource ds = new BasicDataSource();
		ds.setDriverClassName(PropertiesUtil.getJdbcDriverclassname());
		ds.setUsername(PropertiesUtil.getJdbcUsername());
		ds.setPassword(PropertiesUtil.getJdbcPassword());
		ds.setUrl(PropertiesUtil.getJdbcUrl());

		ds.setDefaultAutoCommit(PropertiesUtil.getJdbcDefaultautocommit());
		ds.setInitialSize(PropertiesUtil.getJdbcInitialsize());
		ds.setMaxActive(PropertiesUtil.getJdbcMaxactive());
		ds.setMaxIdle(PropertiesUtil.getJdbcMaxidle());
		ds.setMinIdle(PropertiesUtil.getJdbcMinidle());
		ds.setMaxWait(PropertiesUtil.getJdbcMaxwait());
		ds.setTestOnBorrow(PropertiesUtil.getJbdctestOnBorrow());
		ds.setTestOnReturn(PropertiesUtil.getJbdctestOnReturn());
		ds.setTestWhileIdle(PropertiesUtil.getJbdctestWhileIdle());
		ds.setValidationQuery(PropertiesUtil.getJdbcValidationQuery());
		this.dataSource = ds;
		if (log.isDebugEnabled()) {
			log.debug("end DataSourceCreator setupDateSource..");
		}
	}

	/**
	 * shutdown and close DataSource
	 * 
	 * @throws DefragmentDaoException
	 */
	public synchronized final void shutdownDataSource()
			throws DefragmentDaoException {
		if (log.isDebugEnabled()) {
			log.debug("start DataSourceCreator shutdownDataSource..");
		}
		BasicDataSource dbs = (BasicDataSource) dataSource;
		try {
			if (dbs != null)
				dbs.close();
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
		if (log.isDebugEnabled()) {
			log.debug("end DataSourceCreator shutdownDataSource..");
		}
	}
}
