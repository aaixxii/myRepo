package jp.co.nec.aim.df.service;

import static jp.co.nec.aim.df.constant.SystemConstant.POLLCONTAINERJOBS_TIMEOUT;
import static jp.co.nec.aim.df.constant.SystemConstant.POLLING_JOB_DURATION;

import java.sql.Connection;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.dao.PollFindJobDao;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.PollContainerJobsTimeOutException;
import jp.co.nec.aim.df.util.Util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PollFindJobService extends BaseService {
    /** log instance **/
    private static final Logger log = LoggerFactory
            .getLogger(PollFindJobService.class);

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -1396680472242212370L;

    /** PollFindJobDao instance **/
    private PollFindJobDao dao;

    /**
     * default constructor
     */
    public PollFindJobService() {
    }

    /**
     * constructor with connection
     */
    public PollFindJobService(Connection con) {
        this.con = con;
        dao = DaoFactory.createDao(PollFindJobDao.class, this.con);
    }

    @Override
    public void initialize() {
    }

    /**
     * start poll to find the job count, break until <br>
     * the job is all done
     * 
     * @param plan
     *            the plan instance
     */
    public void waitUntilJobDone(final Plan plan)
            throws PollContainerJobsTimeOutException {
        // get plan first and last segment id
        final long startSegId = plan.getFirstSegId();
        final long endSegId = plan.getLastSegId();
        int loopTime = 0;

        if (log.isDebugEnabled()) {
            log.debug("start poll to find the job count, break until "
                    + "the job is all done, segment between from {} to {}",
                    startSegId, endSegId);
        }

        try {
            long startTime = System.currentTimeMillis();
            while (true) {
                if (Thread.currentThread().isInterrupted()) {
                    log.error("find job status poll has been interrupted, exiting.");
                    return;
                }

                final int jobCount = getRemainJobCount(plan);
                log.info("find job poll already loop {} "
                        + "times.. but still {} top level job(s) in status"
                        + " working.. ", ++loopTime, jobCount);

                if (isTheJobAllDone(jobCount)) {
                    log.info("all top level job is done, "
                            + "the segments is between from {} to {}..",
                            startSegId, endSegId);
                    break;
                }

                // timeout checker
                long endTime = System.currentTimeMillis();
                long timediff = endTime - startTime;
                if (timediff >= POLLCONTAINERJOBS_TIMEOUT) {
                    throw new PollContainerJobsTimeOutException(
                            "timeout event occurred while waiting top level jobs, "
                                    + "timeout value: " + POLLCONTAINERJOBS_TIMEOUT
                                    + "ms");
                }
                Util.sleep(POLLING_JOB_DURATION);
            }
        } catch (DefragmentDaoException e) {
            log.error("DefragmentDaoException while poll find job..", e);
            Util.sleep(POLLING_JOB_DURATION);
        } catch (PollContainerJobsTimeOutException e) {
            throw e;
        } catch (Exception e) {
            log.error("Exception while poll find job..", e);
            Util.sleep(POLLING_JOB_DURATION);
        }
    }

    /**
     * isTheJobAllDone
     * 
     * @param jobCount
     *            the job count is in status (queue and working)
     * @return is the job all done
     * 
     */
    private boolean isTheJobAllDone(final int remain) {
        return (remain <= 0);
    }

    /**
     * get Remain top level Job Count
     * 
     * @return remain job count
     */
    public int getRemainJobCount(final Plan plan) {
        final int jobCount = dao.findJobStatus(plan.getFirstSegId(),
                plan.getLastSegId(), plan.getContainerId());
        return jobCount;
    }
}
