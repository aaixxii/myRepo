package jp.co.nec.aim.df.service;

import java.sql.Connection;

import jp.co.nec.aim.df.util.ProxyUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ServiceFactory is used for create service instance
 */
public class ServiceFactory {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(ServiceFactory.class);

	/**
	 * create Service instance using parameter connection
	 * 
	 * @param clazz
	 *            the class type
	 * @param con
	 *            the parameter connection
	 * @return the proxy service instance
	 */
	public static <T> T createService(Class<T> clazz, Connection con) {
		if (log.isDebugEnabled()) {
			log.debug("start ServiceFactory createService..");
		}
		T t = ProxyUtil.getProxyInstance(clazz, con);
		if (log.isDebugEnabled()) {
			log.debug("end ServiceFactory createService..");
		}
		return t;
	}

	/**
	 * create Service instance
	 * 
	 * @param clazz
	 *            the class type
	 * @return the proxy service instance
	 */
	public static <T> T createService(Class<T> clazz) {
		if (log.isDebugEnabled()) {
			log.debug("start ServiceFactory createService..");
		}
		T t = ProxyUtil.getProxyInstance(clazz);
		if (log.isDebugEnabled()) {
			log.debug("end ServiceFactory createService..");
		}
		return t;
	}

}
