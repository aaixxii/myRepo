package jp.co.nec.aim.df.util;

import static jp.co.nec.aim.df.constant.SystemConstant.EMPTY;
import static jp.co.nec.aim.df.constant.SystemConstant.BR;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.nec.aim.df.constant.Header;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.entity.TotalInformation;
import jp.co.nec.aim.df.exception.ConsoleException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ConsoleUtil {@link ConsoleUtil} <br>
 * this class is for output the message
 */
public final class ConsoleUtil {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(ConsoleUtil.class);

	private static final String MARK = "*";
	private static final String MARK_EQUAL = "=";
	private static final String SPACE = " ";
	private static final String HEADER_DETAIL = "AIM Defragmentation System";
	private static final int COL_LENGTH = 130;
	private static final String CONTAINER_INFORMATION = "Container Total Information";
	private static final String CONTAINER_LIST = "Container Summary";
	private static final String SEGMENT_SUMMARY_LIST = "Segment Summary";
	private static final String PLAN_LIST = "PLAN Summary";
	private static final String FORMAT_CONTAINER = "%-15s %-10s";

	/**
	 * display Container Summary in the containerId
	 * 
	 * @param information
	 *            the container Total information
	 */
	public final static String displayContainerInfo(
			final TotalInformation information) {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil displayContainerInfo..");
		}

		if (information == null) {
			throw new IllegalArgumentException(
					"the total information can not be displayed "
							+ "due to total information is null..");
		}

		final StringBuilder sb = new StringBuilder();
		sb.append(CONTAINER_INFORMATION);
		sb.append(BR);
		sb.append(String.format(FORMAT_CONTAINER, "totalContainerCount",
				information.getTotalContainerCount()));
		sb.append(SPACE);
		sb.append(String.format(FORMAT_CONTAINER, "totalSegmentCount",
				information.getTotalSegmentCount()));
		sb.append(SPACE);
		sb.append(String.format(FORMAT_CONTAINER, "totalBinarySize",
				information.getTotalBinarySize()));
		sb.append(BR);
		String result = sb.toString();
		log.info(result);

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil displayContainerInfo..");
		}
		return result;
	}

	/**
	 * display Container List in the containerId
	 * 
	 * @param detailList
	 *            container detail list
	 */
	public final static String displayContainerList(
			final List<ContainerSummary> detailList) {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil displayContainerList..");
		}

		if (detailList == null || detailList.isEmpty()) {
			log.warn("the container list can not be displayed "
					+ "due to the container list is null or empty..");
			return EMPTY;
		}

		final StringBuilder sb = new StringBuilder();
		try {
			sb.append(CONTAINER_LIST);
			sb.append(BR);
			FieldAndFormat[] fieldAndFormats = getListHeader(sb,
					ContainerSummary.class);
			sb.append(BR);
			getListBody(detailList, sb, fieldAndFormats);
			sb.append(BR);
		} catch (Exception ex) {
			throw new ConsoleException(ex);
		}

		String result = sb.toString();
		log.info(result);

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil displayContainerList..");
		}
		return result;
	}

	/**
	 * display Container children segments List in the containerId
	 * 
	 * @param detailList
	 *            container detail list
	 */
	public final static String displayContainerSegments(
			final List<ContainerSummary> detailList) {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil displayContainerListForSeg..");
		}

		if (detailList == null || detailList.isEmpty()) {
			throw new IllegalArgumentException(
					"the container list can not be displayed "
							+ "due to the container list is null or empty..");
		}

		final StringBuilder sb = new StringBuilder();
		try {
			for (ContainerSummary containersummary : detailList) {
				sb.append(SEGMENT_SUMMARY_LIST);
				sb.append(BR);
				FieldAndFormat[] fieldAndFormatsForSum = getListHeader(sb,
						SegmentSummary.class);
				sb.append(BR);
				getListBody(containersummary.getSegmentSummary(), sb,
						fieldAndFormatsForSum);
				sb.append(BR);
			}
			sb.append(BR);
		} catch (Exception ex) {
			throw new ConsoleException(ex);
		}

		String result = sb.toString();
		if (log.isDebugEnabled()) {
			log.debug(result);
		}

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil displayContainerListForSeg..");
		}
		return result;
	}

	public final static void newLine(int lineNumber) {
		for (int i = 0; i < lineNumber; i++)
			log.info(BR);
	}

	/**
	 * display the plan information in containerId
	 * 
	 * @param planlist
	 *            the plan detail list
	 */
	public final static String displayPlan(final List<Plan> planlist) {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil displayPlan..");
		}

		if (planlist == null || planlist.isEmpty()) {
			throw new IllegalArgumentException(
					"the PLAN list can not be displayed "
							+ "due to the PLAN list is null or empty..");
		}

		final StringBuilder sb = new StringBuilder();
		try {
			sb.append(PLAN_LIST);
			sb.append(BR);
			FieldAndFormat[] fieldAndFormats = getListHeader(sb, Plan.class);
			sb.append(BR);
			getListBody(planlist, sb, fieldAndFormats);
			sb.append(BR);
			for (Plan plan : planlist) {
				sb.append(SEGMENT_SUMMARY_LIST);
				sb.append(BR);
				FieldAndFormat[] fieldAndFormatsForSum = getListHeader(sb,
						SegmentSummary.class);
				sb.append(BR);
				getListBody(plan.getWillMergerSegs(), sb, fieldAndFormatsForSum);
				sb.append(BR);
			}
			sb.append(BR);

		} catch (Exception ex) {
			throw new ConsoleException(ex);
		}

		String result = sb.toString();
		log.info(result);

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil displayPlan..");
		}

		return result;
	}

	/**
	 * this is the common function of display the list body <br>
	 * 
	 * @param detailList
	 *            the detail list
	 * @param sb
	 *            the string will be appended
	 * @param formatArray
	 *            the header format type
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private final static <T> void getListBody(final List<T> detailList,
			final StringBuilder sb, final FieldAndFormat[] formatArray)
			throws IllegalArgumentException, IllegalAccessException {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil getListBody..");
		}

		for (final T item : detailList) {
			for (final FieldAndFormat fieldAndFormat : formatArray) {
				sb.append(String.format(fieldAndFormat.getFormatType(),
						fieldAndFormat.getField().get(item)));
			}
			sb.append(BR);
		}

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil getListBody..");
		}
	}

	/**
	 * display the header information and return the header size and name
	 * 
	 * @param sb
	 *            the string will be appended
	 * @param clazz
	 *            the type of display class
	 * @return the field and format
	 */
	private final static FieldAndFormat[] getListHeader(final StringBuilder sb,
			final Class<?> clazz) {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil getListHeader..");
		}

		final Field[] fields = clazz.getDeclaredFields();
		final List<FieldAndFormat> formatArray = new ArrayList<FieldAndFormat>();
		addMark(sb, COL_LENGTH, MARK_EQUAL);
		sb.append(BR);
		for (final Field field : fields) {
			Header header = field.getAnnotation(Header.class);
			if (header == null)
				continue;

			final int length = header.length();
			String headerName = header.headerName();
			String formatType = "%-" + length + "s";
			formatArray.add(new FieldAndFormat(field, formatType));
			sb.append(String.format(formatType, headerName));
		}
		sb.append(BR);
		addMark(sb, COL_LENGTH, MARK_EQUAL);

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil getListHeader..");
		}
		return formatArray.toArray(new FieldAndFormat[0]);
	}

	/**
	 * display AIM defragment system header
	 */
	public final static String displayHeader() {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil displayHeader..");
		}

		final StringBuilder sb = new StringBuilder();

		appendCurrentTime(sb);
		addMark(sb, COL_LENGTH, MARK);
		sb.append(BR);
		centerHeaderDetail(sb);
		sb.append(BR);
		addMark(sb, COL_LENGTH, MARK);
		log.info(sb.toString());

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil displayHeader..");
		}
		return sb.toString();
	}

	/**
	 * startDisplayBinRange
	 * 
	 * @param containerid
	 *            the container id user specified
	 */
	public final static void startDisplayBinRange(int containerid) {
		log.info(
				"-----------------------> begin defragment container id {}.<-----------------------",
				containerid);
	}

	/**
	 * endDisplayBinRange
	 * 
	 * @param containerid
	 *            the container id user specified
	 */
	public final static void endDisplayBinRange(int containerid) {
		log.info(
				"----------------------->  end defragment container id {}. <-----------------------"
						+ BR, containerid);
	}

	/**
	 * set the header to center
	 * 
	 * @param sb
	 *            the string will be appended
	 */
	private static void centerHeaderDetail(final StringBuilder sb) {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil centerHeaderDetail..");
		}

		final int start = sb.length();
		final int wLength = Math.min(HEADER_DETAIL.length(), COL_LENGTH);
		addMark(sb, (COL_LENGTH - wLength) / 2, SPACE);
		sb.append(HEADER_DETAIL);
		addMark(sb, (COL_LENGTH - wLength) / 2, SPACE);
		addMark(sb, COL_LENGTH - (sb.length() - start), SPACE);

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil centerHeaderDetail..");
		}
	}

	/**
	 * add the mark symbol
	 * 
	 * @param to
	 *            the string will be appended
	 * @param howMany
	 *            the length
	 * @param detail
	 *            symbol
	 */
	private final static void addMark(final StringBuilder to,
			final int howMany, final String detail) {
		if (log.isDebugEnabled()) {
			log.debug("start ConsoleUtil addMark..");
		}

		for (int i = 0; i < howMany; i++) {
			to.append(detail);
		}

		if (log.isDebugEnabled()) {
			log.debug("end ConsoleUtil addMark..");
		}
	}

	/**
	 * append the CurrentTime
	 * 
	 * @param sb
	 *            the StringBuilder instance
	 */
	private final static void appendCurrentTime(final StringBuilder sb) {
		final Date now = new Date();
		final SimpleDateFormat format = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		sb.append("Current Time:");
		sb.append(format.format(now));
		sb.append(BR);
	}

	/**
	 * the class is save the field and format
	 */
	static class FieldAndFormat {
		private Field field;
		private String formatType;

		public Field getField() {
			field.setAccessible(true);
			return field;
		}

		public String getFormatType() {
			return formatType;
		}

		public FieldAndFormat(Field field, String formatType) {
			this.field = field;
			this.formatType = formatType;
		}
	}
}
