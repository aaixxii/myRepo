package jp.co.nec.aim.df.service;

import java.sql.Connection;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.dao.RUCDao;
import jp.co.nec.aim.df.dao.SegmentDefragDao;
import jp.co.nec.aim.df.dao.SegmentDefragUpdateDao;
import jp.co.nec.aim.df.exception.ReturnValueNotSuccessException;
import jp.co.nec.aim.df.util.ConnectionUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * BinDefragService
 * 
 * @author jinxl
 * 
 */
public class BinDefragService extends BaseService {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 8166694015535682717L;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(BinDefragService.class);

	private SegmentDefragDao segDefragDao;
	private SegmentDefragUpdateDao segDefragUpdateDao;

	private RUCDao rucDao; // RUC DAO

	public BinDefragService(Connection con) {
		this.con = con;
		segDefragDao = DaoFactory.createDao(SegmentDefragDao.class);
		segDefragUpdateDao = DaoFactory.createDao(SegmentDefragUpdateDao.class,
				this.con);
		rucDao = DaoFactory.createDao(RUCDao.class, this.con);
	}

	@Override
	public void initialize() {

	}

	public Long getTrifficContainerId() {
		return segDefragDao.getTrifficContainerId();
	}

	private void setDefragContainerId(long containerId) {

		int count = 0;
		try {
			count = segDefragDao.getSegDefragCount();
			if (count == 0) {
				segDefragUpdateDao.insertSegDefrag(containerId);
			} else {
				segDefragUpdateDao.updateSegDefrag(containerId);
			}
		} finally {

		}
	}

	/**
	 * 
	 * @param containerId
	 *            Container_ID to start defrag.
	 */
	public void startContainerDefrag(final long containerId) throws Exception {
		Long maitainContainerId = segDefragDao.getTrifficContainerId();

		if (maitainContainerId == null || maitainContainerId == -1) {

			setDefragContainerId(containerId);

			// Insert RUC count
			rucDao.increaseRUC();

			ConnectionUtil.commit(con);

		} else {
			log.error("Container Id in segment_defragmentation is not successful");
			throw new ReturnValueNotSuccessException(
					"Container Id in segment_defragmentation is not successful");
		}
	}

	/**
	 * 
	 * @param containerId
	 *            Container_ID to stop defrag.
	 */
	public void stopContainerDefrag(final long containerId) throws Exception {

		long maitainContainerId = segDefragDao.getTrifficContainerId();
		if (maitainContainerId == containerId) {

			setDefragContainerId(new Long(-1));

			// Insert RUC count before call SLB
			rucDao.increaseRUC();

			ConnectionUtil.commit(con);

		} else {
			log.error("Container Id in segment_defragmentation is not successful");
			throw new ReturnValueNotSuccessException(
					"Container Id in segment_defragmentation is not successful");
		}
	}
}
