package jp.co.nec.aim.df.service;

import static jp.co.nec.aim.df.constant.SystemConstant.MM_COMMAND;
import static jp.co.nec.aim.df.constant.SystemConstant.MM_STATUS_START;
import static jp.co.nec.aim.df.constant.SystemConstant.MM_STATUS_STOP;

import java.util.HashMap;
import java.util.Map;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.entity.HttpResponseInfo;
import jp.co.nec.aim.df.exception.CommunicationException;
import jp.co.nec.aim.df.util.CommunicationUtil;
import jp.co.nec.aim.df.util.PropertiesUtil;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this class is for Communication with MM <br>
 */
public class CommunicationService extends BaseService {

	/** serialVersionUID **/
	private static final long serialVersionUID = 4289373780678443695L;
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(CommunicationService.class);
	/** need to retry while communication **/
	private static final boolean RETRY = true;

	/**
	 * post start signal to MM
	 * 
	 * @param containerId
	 *            the container id will send to MM
	 * @return is execute successfully
	 */
	public boolean sendStartSignal(int containerId) {
		// the transmission header
		Map<String, String> header = new HashMap<String, String>();
		header.put(MM_COMMAND, MM_STATUS_START);

		// get response information from MM
		final HttpResponseInfo response = CommunicationUtil.postCommunication(
				PropertiesUtil.getMMUrl(), header, RETRY);

		// handle the response
		handleResponse(containerId, response, MM_STATUS_START);
		return true;
	}

	/**
	 * post stop signal to MM
	 * 
	 * @param containerId
	 *            the container id will send to MM
	 * @return is execute successfully
	 */
	public boolean sendStopSignal(int containerId) {
		// the transmission header
		Map<String, String> header = new HashMap<String, String>();
		header.put(MM_COMMAND, MM_STATUS_STOP);

		// get response information from MM
		final HttpResponseInfo response = CommunicationUtil.postCommunication(
				PropertiesUtil.getMMUrl(), header, RETRY);

		// handle the response
		handleResponse(containerId, response, MM_STATUS_STOP);
		return true;
	}

	/**
	 * handleResponse <br>
	 * 1 check response stausCode is SC_OK <br>
	 * 2 throw CommunicationException while SC_BAD_REQUEST <br>
	 * 3 throw CommunicationException while SC_INTERNAL_SERVER_ERROR <br>
	 * 4 throw CommunicationException while other error <br>
	 * 
	 * 
	 * @param containerId
	 *            the container id send to MM
	 * @param response
	 *            the response information include status code<br>
	 *            and the body message
	 * @param mmStatus
	 *            the start or stop signal
	 */
	private void handleResponse(int containerId, HttpResponseInfo response,
			String mmStatus) {
		final int statusCode = response.getStatusCode();
		final String body = response.getBodyMessage();

		switch (statusCode) {
		case HttpStatus.SC_OK:
			log.info("send the " + mmStatus + " flow control with "
					+ "container id {} to MM successfully..", containerId);
			break;
		case HttpStatus.SC_BAD_REQUEST:
			final String badRequestmessage = "send the " + mmStatus
					+ " flow control with " + "container id " + containerId
					+ " to MM abnormal bad request, "
					+ "return status code is " + statusCode
					+ "..";
			log.error(badRequestmessage);
			throw new CommunicationException(badRequestmessage);
		default:
			String unknowMessage = "send the " + mmStatus
					+ " flow control with " + "container id " + containerId
					+ " to MM abnormal, " + "return status code is "
					+ statusCode + ", MM error Message is :"
					+ ((body == null) ? "unknown" : body);
			log.error(unknowMessage);
			throw new CommunicationException(unknowMessage);
		}
	}

	@Override
	public void initialize() {
	}
}
