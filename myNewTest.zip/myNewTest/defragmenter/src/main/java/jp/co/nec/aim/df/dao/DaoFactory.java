package jp.co.nec.aim.df.dao;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;

import javax.sql.DataSource;

import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.util.ProxyUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * DaoFactory is used for create dao instance
 */
public class DaoFactory {
	/** the name of set connection into dao instance **/
	private static final String SET_CONNECTION_METHOD_NAME = "setInitParams";
	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(DaoFactory.class);

	/**
	 * create Dao instance and set the connection instance <br>
	 * that from apache dbcp datasource into Dao instance <br>
	 * 
	 * @param clazz
	 * @return Dao instance
	 */
	public static <T> T createDao(Class<T> clazz) {
		try {
			if (log.isDebugEnabled()) {
				log.debug("start DaoFactory createDao..");
			}

			T t = ProxyUtil.getProxyInstance(clazz);
			Method method = clazz.getMethod(SET_CONNECTION_METHOD_NAME,
					DataSource.class);
			method.setAccessible(true);
			DataSource ds = DataSourceCreator.getInstance().getDataSource();
			method.invoke(t, ds);
			if (log.isDebugEnabled()) {
				log.debug("end DaoFactory createDao..");
			}
			return t;
		} catch (IllegalAccessException e) {
			throw new DefragmentDaoException("IllegalAccessException occurred"
					+ " while create Dao instance", e);
		} catch (NoSuchMethodException e) {
			throw new DefragmentDaoException("NoSuchMethodException occurred"
					+ " while create Dao instance", e);
		} catch (InvocationTargetException e) {
			throw new DefragmentDaoException(
					"InvocationTargetException occurred"
							+ " while create Dao instance", e);
		}
	}

	/**
	 * createDao with connection
	 * 
	 * @param clazz
	 *            dAO class
	 * @return dAO instance
	 */
	public static <T> T createDao(Class<T> clazz, Connection con) {
		try {
			if (log.isDebugEnabled()) {
				log.debug("start DaoFactory createDao..");
			}

			T t = ProxyUtil.getProxyInstance(clazz);
			Method method = clazz.getMethod(SET_CONNECTION_METHOD_NAME,
					Connection.class);
			method.setAccessible(true);
			method.invoke(t, con);
			if (log.isDebugEnabled()) {
				log.debug("end DaoFactory createDao..");
			}
			return t;
		} catch (IllegalAccessException e) {
			throw new DefragmentDaoException("IllegalAccessException occurred"
					+ " while create Dao instance", e);
		} catch (NoSuchMethodException e) {
			throw new DefragmentDaoException("NoSuchMethodException occurred"
					+ " while create Dao instance", e);
		} catch (InvocationTargetException e) {
			throw new DefragmentDaoException(
					"InvocationTargetException occurred"
							+ " while create Dao instance", e);
		}
	}

}
