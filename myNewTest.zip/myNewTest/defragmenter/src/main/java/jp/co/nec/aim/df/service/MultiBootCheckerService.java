package jp.co.nec.aim.df.service;

import java.sql.SQLException;

import javax.sql.DataSource;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.dao.SystemInitDao;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.exception.MultiBootException;
import jp.co.nec.aim.df.util.ConnectionUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this service is used to check the defragment Multi-Boot operation <br>
 * if Multi-Boot is detected while do defragment, this service will <br>
 * throw an MultiBootException exception and the main program will exit <br>
 * immediately...
 */
public class MultiBootCheckerService extends BaseService {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(MultiBootCheckerService.class);

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8951757614441175217L;
	private SystemInitDao dao;

	/**
	 * default constructor
	 */
	public MultiBootCheckerService() {
	}

	@Override
	public void initialize() {
		DataSource ds = DataSourceCreator.getInstance().getDataSource();
		try {
			this.con = ds.getConnection();
		} catch (SQLException e) {
			String message = "can not get connection from datasource..";
			throw new DefragmentServiceException(message, e);
		}
		this.dao = DaoFactory.createDao(SystemInitDao.class, this.con);
	}

	/**
	 * begin lock the MultiBootFlag <br>
	 * the first operation of defragment will get Object (is not null)<br>
	 * and the other operation of defragment will get the null value <br>
	 * due to the defragment can be execute only single operation..
	 */
	public void begin() throws MultiBootException {
		if (log.isDebugEnabled()) {
			log.debug("begin to check Defragment Multi-Boot operation..");
		}
		final Object objectValue = dao.lockAndGetMultiBootFlag();
		if (objectValue == null) {
			throw new MultiBootException(
					"Defragment Multi-Boot operation is detected. "
							+ "only single operation is allowed..");
		}

		if (log.isDebugEnabled()) {
			log.debug("end to check Defragment Multi-Boot operation..");
		}
	}

	/**
	 * commit and release the connection
	 */
	public void end() {
		if (log.isDebugEnabled()) {
			log.debug("commit and release the connection when "
					+ "check Defragment Multi-Boot operation..");
		}
		ConnectionUtil.commit(this.con);
		ConnectionUtil.close(this.con);
	}
}
