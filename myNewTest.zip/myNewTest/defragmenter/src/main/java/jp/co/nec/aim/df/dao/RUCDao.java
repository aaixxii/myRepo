package jp.co.nec.aim.df.dao;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.exception.DefragmentDaoException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
public class RUCDao extends BaseDao{

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(RUCDao.class);
	
	private static final String INCREASE_RUC="{ call MATCH_MANAGER_API.INCREASE_RUC() }";
	
	/**
	 * increaseRUC
	 */
	public void increaseRUC() {
		log.info("Ready to increase RUC.");
		try {
			prepareStatementCon(INCREASE_RUC);
			executeUpdate();
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
		}
	}

}
