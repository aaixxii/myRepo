package jp.co.nec.aim.df.entity;

import static jp.co.nec.aim.df.constant.SystemConstant.BR;
import static jp.co.nec.aim.df.constant.SystemConstant.MAX_JOINT;
import static jp.co.nec.aim.df.constant.SystemConstant.MAXPLANSIZE;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.df.core.Plan;

/**
 * 
 * @author liuyq
 * 
 */
public final class SimulationInfo implements Serializable {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 5893222453514777880L;
    private static final String FORMAT_PARA = "MaxJoint=%d   ||   MaxPlanSize=%d";
    private static final String FORMAT_MB = "CONTAINER=%d   || Shrink Size %d MB -->  %d MB (-%d MB)";
    private static final String BLANK = " ";

    /**
     * default constructor
     */
    public SimulationInfo() {
    }

    /**
     * the constructor with specified parameter
     * 
     * @param containerId
     * @param originalSize
     * @param afterSize
     * @param plans
     */
    public SimulationInfo(final int containerId, final long originalSize, final long afterSize,
            final List<Plan> plans) {
        this.containerId = containerId;
        this.originalSize = originalSize;
        this.afterSize = afterSize;
        this.plans.addAll(plans);
    }

    /** the container id */
    private int containerId;
    /** the original total container binary size (byte) */
    private long originalSize;

    /** after Simulation total container binary size (byte) */
    private long afterSize;

    /** after Simulation the plan summary */
    private List<Plan> plans = new ArrayList<Plan>();

    public int getContainerId() {
        return containerId;
    }

    public void setContainerId(int containerId) {
        this.containerId = containerId;
    }

    public long getOriginalSize() {
        return originalSize;
    }

    public void setOriginalSize(long originalSize) {
        this.originalSize = originalSize;
    }

    public long getAfterSize() {
        return afterSize;
    }

    public void setAfterSize(long afterSize) {
        this.afterSize = afterSize;
    }

    public List<Plan> getPlans() {
        return plans;
    }

    public void setPlans(List<Plan> plans) {
        this.plans = plans;
    }

    @Override
    public String toString() {
        final StringBuffer eachBinInfo = new StringBuffer();
        final StringBuffer eachPlan = new StringBuffer();

        long delSize = 0L;
        int index = 0;
        for (final Plan plan : this.plans) {
            List<SegmentSummary> segments = plan.getWillMergerSegs();

            final int size = segments.size();
            List<Long> beforeSegIds = new ArrayList<Long>(size);
            List<Long> afterSegIds = new ArrayList<Long>(size);
            for (final SegmentSummary segment : segments) {
                beforeSegIds.add(segment.getSegId());
                if (!segment.willbeDeleted()) {
                    afterSegIds.add(segment.getSegId());
                } else {
                    delSize += segment.getBlunCompacted();
                }
            }

            if (index++ % 5 == 0) {
                eachPlan.append(BR);
            }
            eachPlan.append(beforeSegIds.toString());
            eachPlan.append("->");
            eachPlan.append(afterSegIds.toString());
            eachPlan.append(BLANK);
            eachPlan.append(BLANK);
            eachPlan.append(BLANK);
        }

        eachBinInfo.append(BR);

        final int orgSize = cast(originalSize);
        final int aftSize = cast(afterSize - delSize);
        final int diffSize = orgSize - aftSize;

        eachBinInfo.append(String.format(FORMAT_PARA, MAX_JOINT, MAXPLANSIZE));
        eachBinInfo.append(BR);
        eachBinInfo.append(String.format(FORMAT_MB, containerId, orgSize, aftSize, diffSize));
        eachBinInfo.append(BR);
        eachBinInfo.append("Joint Information:");
        eachBinInfo.append(eachPlan.toString());
        return eachBinInfo.toString();
    }

    /** the unit from byte to MB */
    private static long CONVERT_UNIT_SIZE = 1024 * 1024;

    private static int cast(long var) {
        return (int) ((double) var / CONVERT_UNIT_SIZE + 0.5d);
    }

}
