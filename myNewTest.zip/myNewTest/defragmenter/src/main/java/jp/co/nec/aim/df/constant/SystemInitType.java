package jp.co.nec.aim.df.constant;

public enum SystemInitType {
	 DEFRAG_MULTI_BOOT
}
