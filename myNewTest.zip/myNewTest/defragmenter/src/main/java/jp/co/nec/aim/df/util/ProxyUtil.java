package jp.co.nec.aim.df.util;

import java.sql.Connection;

import net.sf.cglib.proxy.Enhancer;

/**
 * ProxyUtil is used for create the proxy instance using cgLib
 */
public class ProxyUtil {

	/** interceptor instance **/
	private static final LogPerformInterceptor interceptor = new LogPerformInterceptor();

	/**
	 * get proxy instance using cgLib
	 * 
	 * @param clazz
	 *            class type
	 * @return the proxy instance
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getProxyInstance(Class<T> clazz) {
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(clazz);
		enhancer.setCallback(interceptor);
		return (T) enhancer.create();
	}

	/**
	 * get proxy instance with parameter connection using cgLib
	 * 
	 * @param clazz
	 *            class type
	 * @param connection
	 *            parameter connection
	 * @return the proxy instance
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getProxyInstance(Class<T> clazz, Connection connection) {
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(clazz);
		enhancer.setCallback(interceptor);
		return (T) enhancer.create(new Class[] { Connection.class },
				new Object[] { connection });
	}
}
