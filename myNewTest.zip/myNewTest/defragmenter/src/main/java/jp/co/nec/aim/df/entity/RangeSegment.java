package jp.co.nec.aim.df.entity;

import java.io.Serializable;

import jp.co.nec.aim.df.constant.FieldMapped;

/**
 * To keep the segment range information
 */
public final class RangeSegment implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = 6469011577417903955L;

	@FieldMapped
	private Long rangeId;

	@FieldMapped
	private Long totalLength;

	@FieldMapped
	private Long recordCount;

	@FieldMapped
	private Long segmentId;

	public Long getRangeId() {
		return rangeId;
	}

	public Long getTotalLength() {
		return totalLength;
	}

	public Long getRecordCount() {
		return recordCount;
	}

	public Long getSegmentId() {
		return segmentId;
	}
}
