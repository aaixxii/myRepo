package jp.co.nec.aim.df.exception;

public class VersionNotMatchException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4771615915865272665L;

	/**
	 * @param message
	 */
	public VersionNotMatchException(String message) {
		super(message);
	}
}
