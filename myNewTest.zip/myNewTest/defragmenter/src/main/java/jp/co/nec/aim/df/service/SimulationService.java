package jp.co.nec.aim.df.service;

import static jp.co.nec.aim.df.constant.SystemConstant.BR;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SimulationInfo;
import jp.co.nec.aim.df.exception.DefragmentServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this service is the defragMent Simulation. <br>
 * before do real defragMent, it is necessary to <br>
 * find out what the different between beginning to <br>
 * end. this service supply the above function. <br>
 * 1. the joint information within the bin range <br>
 * 2. the different Shrink binary size between from the beginning to end <br>
 * <br>
 * the following show the example: <br>
 * <code>
 * 
 * BIN=4   || Shrink Size 146 MB -->  113 MB (-33 MB)<br>
   Joint Information:<br>
   [242, 243]->[242]   [244, 245]->[244]   [246, 247]->[246]   [250, 251]->[250]   [252, 253]->[252]<br>
   [254, 255]->[254]   [256, 257]->[256]   [258, 259]->[258]   [260, 261]->[260]   [264, 265]->[264]<br>
   [268, 269]->[268]<br>
 * 
 * </code>
 * 
 * @author liuyq
 * 
 */
public class SimulationService extends BaseService {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 2148657218749850984L;
    /** log instance **/
    private static final Logger log = LoggerFactory.getLogger(SimulationService.class);

    /** Container initialize Service */
    private ContainerInitService initService;
    /** make Plan Service */
    private MakePlanService makePlanService;
    /** Merger Segment Service **/
    private MergerSegmentService mergerService;

    /**
     * initialize the necessary service
     */
    public void initialize() {
        this.initService = ServiceFactory.createService(ContainerInitService.class);
        this.makePlanService = ServiceFactory.createService(MakePlanService.class);

        DataSource ds = DataSourceCreator.getInstance().getDataSource();
        try {
            this.con = ds.getConnection();
        } catch (SQLException e) {
            String message = "can not get connection from datasource..";
            throw new DefragmentServiceException(message, e);
        }
        this.mergerService = ServiceFactory.createService(MergerSegmentService.class, this.con);
    }

    /**
     * display the expect result in the containerId
     */
    public String display(Integer containerIdPara) {
        // log out the current time..
        log.info("Current time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())
                + BR);
        final StringBuffer ret = new StringBuffer();

        // initialize the container information
        final List<ContainerSummary> containerList = initService.initContainerSummary();

        // AIM system without any bin information
        if (containerList == null || containerList.isEmpty()) {
            log.warn("AIM system without any Container information..");
            return ret.toString();
        }

        boolean isFoundBin = false;
        // loop the each container and get the defragMent Simulation
        for (final ContainerSummary container : containerList) {
            final int containerId = container.getContainerId();

            // if the parameter container id is specified, skip this operation,
            // do defragMent. otherwise until the loop container id is match
            // the container id specified, do operation.
            if (containerIdPara != null && containerIdPara != containerId) {
                if (log.isDebugEnabled()) {
                    log.debug("the specified container id is {} "
                            + "and not match the loop container id {}, skip..", containerIdPara, containerId);
                }
                continue;
            }

            try {
                // make the plan for current container
                // if the plan is empty, skip this and go next
                List<Plan> plans = makePlanService.makePlan(container);
                if (plans.isEmpty()) {
                    log.info("after analysis,  this Container without any "
                            + "defragment plan in containerid {}..", containerId);
                    continue;
                }

                // get the bin binary size before defragMent Simulation
                final long beforeSize = container.getTotalBinarySize();

                // loop the plan and do defragMent Simulation
                for (final Plan plan : plans) {
                    mergerService.mergerSegmentPlan(plan);
                }

                final long afterSize = container.getTotalBinarySize();

                // calculate the different binary size and output
                final String simuInfo = new SimulationInfo(containerId, beforeSize, afterSize, plans)
                        .toString();
                ret.append(simuInfo);
                log.info(simuInfo);

            } catch (Exception ex) {
                // if exception occurred while do Execute plan
                // operation, skip this container
                // do the next container
                log.error("Exception occurred while Execute container.. " + "container id: {}",
                        container.getContainerId(), ex);
                continue;
            } finally {
                //
                if (log.isDebugEnabled()) {
                    log.debug("finish do Simulation operation..");
                }
                isFoundBin = true;
            }
        }

        // if the specified bin is not found, warning only..
        if (!isFoundBin) {
            log.warn("Specified CONTAINER_ID:{} does not contain Segments."
                    + " To Simulate all, just specify blank.", containerIdPara);
        }

        return ret.toString();
    }
}
