package jp.co.nec.aim.df.entity;

import java.io.Serializable;

import jp.co.nec.aim.df.constant.FieldMapped;

/**
 * The container total information
 */
public final class TotalInformation implements Serializable {
	/** serialVersionUID */
	private static final long serialVersionUID = 7193345967846409733L;

	/**
	 * Constructor
	 */
	public TotalInformation() {
	}

	/**
	 * Constructor
	 * 
	 * @param totalContainerCount
	 * @param totalSegmentCount
	 * @param totalBinarySize
	 */
	public TotalInformation(int totalContainerCount, int totalSegmentCount,
			long totalBinarySize) {
		this.totalContainerCount = totalContainerCount;
		this.totalSegmentCount = totalSegmentCount;
		this.totalBinarySize = totalBinarySize;
	}

	public Integer getTotalContainerCount() {
		return totalContainerCount;
	}

	public void setTotalContainerCount(Integer totalContainerCount) {
		this.totalContainerCount = totalContainerCount;
	}

	public Integer getTotalSegmentCount() {
		return totalSegmentCount;
	}

	public void setTotalSegmentCount(Integer totalSegmentCount) {
		this.totalSegmentCount = totalSegmentCount;
	}

	public Long getTotalBinarySize() {
		return totalBinarySize;
	}

	public void setTotalBinarySize(Long totalBinarySize) {
		this.totalBinarySize = totalBinarySize;
	}

	@FieldMapped
	private Integer totalContainerCount;
	@FieldMapped
	private Integer totalSegmentCount;
	@FieldMapped
	private Long totalBinarySize;
}
