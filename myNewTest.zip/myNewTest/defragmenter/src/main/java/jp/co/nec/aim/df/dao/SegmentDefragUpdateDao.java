package jp.co.nec.aim.df.dao;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.exception.DefragmentDaoException;

/**
 * SEGMENT_DEFRAGMENTATION Dao Class
 * 
 * @author jinxl
 * 
 */
public class SegmentDefragUpdateDao extends BaseDao {

	private String INSERT_SEG_DEFRAG = "insert into SEGMENT_DEFRAGMENTATION("
			+ "CONTAINER_ID, START_TS, END_TS) values(?, match_manager_api.get_epoch_time_num(), 0)";
	private String UPDATE_SEG_DEFRAG_CONTAINERID = "update SEGMENT_DEFRAGMENTATION set"
			+ " CONTAINER_ID = ?, START_TS = match_manager_api.get_epoch_time_num() ";

	public void insertSegDefrag(long containerId) {
		try {
			prepareStatementCon(INSERT_SEG_DEFRAG);
			setParam(index++, containerId);
			executeUpdate();
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
		}
	}

	public void updateSegDefrag(long containerId) {
		try {
			prepareStatementCon(UPDATE_SEG_DEFRAG_CONTAINERID);
			setParam(index++, containerId);
			executeUpdate();
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
		}
	}
}
