package jp.co.nec.aim.df.exception;

public class DefragmentDaoException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1287506188023072691L;

	/**
	 * @param message
	 */
	public DefragmentDaoException(String message) {
		super(message);

	}

	/**
	 * @param cause
	 */
	public DefragmentDaoException(Throwable cause) {
		super(cause);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public DefragmentDaoException(String message, Throwable cause) {
		super(message, cause);

	}
}
