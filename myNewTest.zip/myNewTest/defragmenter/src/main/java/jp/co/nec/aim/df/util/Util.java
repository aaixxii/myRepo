package jp.co.nec.aim.df.util;

import java.util.Map;

import jp.co.nec.aim.df.constant.SystemConstant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this is the common utility
 * 
 */
public final class Util {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(Util.class);

	/**
	 * the object null judgment
	 * 
	 * @param object
	 * @return true or false
	 */
	public static final boolean isObjectNull(Object object) {
		return (object == null);
	}

	/**
	 * the Map null or empty
	 * 
	 * @param object
	 * @return true or false
	 */
	public static final boolean isMapNullOrEmpty(Map<?, ?> map) {
		return (map == null || map.isEmpty());
	}

	/**
	 * removeLastComma
	 * 
	 * @param sb
	 */
	public static final void removeLastComma(StringBuilder sb) {
		if (log.isDebugEnabled()) {
			log.debug("start Util removeLastComma..");
		}
		final int length = sb.length();

		char c = sb.charAt(length - 1);
		if (c == SystemConstant.COMMA_CHAR) {
			sb.deleteCharAt(length - 1);
		}
		if (log.isDebugEnabled()) {
			log.debug("end Util removeLastComma..");
		}
	}

	/**
	 * thread sleep time
	 * 
	 * @param sleepTime
	 *            sleep time
	 */
	public static final void sleep(final int sleepTime) {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			log.error("InterruptedException occurred..", e);
		}
	}
}
