package jp.co.nec.aim.df.dao;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.util.Util;

/**
 * this dao include the delete and update the segment function
 */
public class PersistSegmentDao extends BaseDao {

    /** the SQL of delete the segment **/
    private final static String DELETE_SEGMENT = "delete from segments "
            + "where segment_id = ? ";

//    /** the SQL of delete the mu job **/
//    private final static String DELETE_MU_JOBS = "DELETE FROM mu_jobs "
//            + "WHERE  mu_job_id IN (SELECT mjfr.mu_job_id "
//            + "                      FROM   segments s, MU_JOB_FAILURE_REASONS mjfr "
//            + "                      WHERE  mjfr.segment_id = s.segment_id "
//            + "                             AND s.version = ? "
//            + "                             AND s.revision = ? "
//            + "                             AND s.segment_id = ?) ";

    /**
     * delete the segment with segment id
     * 
     * @param segmentId
     *            the segment id
     * @return deleted count
     */
    public int deleteSegment(final SegmentSummary segment) {
        try {
            prepareStatementCon(DELETE_SEGMENT);
            setParam(index++, segment.getSegId());

            // comment the following code due to segment that will delete
            // has locked , version and reVersion can not be changed.
            // so, only segment id is enough.

            // setParam(index++, segment.getVersionBackUp());
            // setParam(index++, segment.getReVersionBackUp());
            executeUpdate();
        } catch (Exception ex) {
            throw new DefragmentDaoException(ex);
        } finally {
            releaseResultSet();
            releasePreparedStatement();
        }
        return cnt;
    }

//    /**
//     * we will remove the MU jobs before remove the segment
//     * 
//     * @param segment
//     *            the segment instance
//     * @return deleted count
//     */
//    public int deleteMuJobs(final SegmentSummary segment) {
//        try {
//            prepareStatementCon(DELETE_MU_JOBS);
//            setParam(index++, segment.getVersionBackUp());
//            setParam(index++, segment.getReVersionBackUp());
//            setParam(index++, segment.getSegId());
//            executeUpdate();
//        } catch (Exception ex) {
//            throw new DefragmentDaoException(ex);
//        } finally {
//            releaseResultSet();
//            releasePreparedStatement();
//        }
//        return cnt;
//
//    }

    /**
     * update the segment
     * 
     * @param segment
     *            segment instance
     * @return update count
     */
    public int updateSegment(final SegmentSummary segment) {
        // segmentId is required
        Long segmentId = segment.getSegId();
        if (segmentId == null) {
            throw new DefragmentDaoException("the segment id is null"
                    + " while update the segment");
        }

        try {
            prepareStatementCon(createDynamicSql(segment));

            Long startId = segment.getStartId();
            if (!Util.isObjectNull(startId)) {
                setParam(index++, startId);
            }

            Long endId = segment.getEndId();
            if (!Util.isObjectNull(endId)) {
                setParam(index++, endId);
            }

            Long blCompact = segment.getBlCompacted();
            if (!Util.isObjectNull(blCompact)) {
                setParam(index++, blCompact);
            }

            Long recordCount = segment.getRecordCount();
            if (!Util.isObjectNull(recordCount)) {
                setParam(index++, recordCount);
            }

            Integer version = segment.getVersion();
            if (!Util.isObjectNull(version)) {
                setParam(index++, version);
            }

            Integer reVersion = segment.getReVersion();
            if (!Util.isObjectNull(reVersion)) {
                setParam(index++, reVersion);
            }

            Long blunCompact = segment.getBlunCompacted();
            if (!Util.isObjectNull(blunCompact)) {
                setParam(index++, blunCompact);
            }

            setParam(index++, segment.getSegId());
            setParam(index++, segment.getVersionBackUp());
            setParam(index++, segment.getReVersionBackUp());
            executeUpdate();

        } catch (Exception ex) {
            throw new DefragmentDaoException(ex);
        } finally {
            releaseResultSet();
            releasePreparedStatement();
        }
        return cnt;
    }

    /**
     * createDynamicSql
     * 
     * @return
     */
    private String createDynamicSql(SegmentSummary segment) {
        boolean isAtLeastOneColum = false;
        StringBuilder sb = new StringBuilder();
        sb.append("update Segments ");
        sb.append("set ");
        if (!Util.isObjectNull(segment.getStartId())) {
            isAtLeastOneColum = true;
            sb.append("BIO_ID_START = ?,");
        }

        if (!Util.isObjectNull(segment.getEndId())) {
            isAtLeastOneColum = true;
            sb.append("BIO_ID_END = ?,");
        }

        if (!Util.isObjectNull(segment.getBlCompacted())) {
            isAtLeastOneColum = true;
            sb.append("BINARY_LENGTH_COMPACTED = ?,");
        }

        if (!Util.isObjectNull(segment.getRecordCount())) {
            isAtLeastOneColum = true;
            sb.append("RECORD_COUNT = ?,");
        }

        if (!Util.isObjectNull(segment.getVersion())) {
            isAtLeastOneColum = true;
            sb.append("VERSION = ?,");
        }

        if (!Util.isObjectNull(segment.getReVersion())) {
            isAtLeastOneColum = true;
            sb.append("REVISION = ?,");
        }

        if (!Util.isObjectNull(segment.getBlunCompacted())) {
            isAtLeastOneColum = true;
            sb.append("BINARY_LENGTH_UNCOMPACTED = ?,");
        }

        Util.removeLastComma(sb);

        sb.append("where SEGMENT_ID = ? ");
        sb.append("and VERSION = ? ");
        sb.append("and REVISION = ? ");

        // if the updated field is nothing
        if (!isAtLeastOneColum) {
            throw new DefragmentDaoException(
                    "at least one colum is required while update segment..");
        }
        return sb.toString();
    }
}