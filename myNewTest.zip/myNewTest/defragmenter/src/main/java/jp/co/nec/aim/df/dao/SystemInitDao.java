package jp.co.nec.aim.df.dao;

import static jp.co.nec.aim.df.constant.SystemInitType.DEFRAG_MULTI_BOOT;
import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.constant.SystemInitType;
import jp.co.nec.aim.df.exception.DefragmentDaoException;

/**
 * find key_value in table SYSTEM_INIT <br>
 * with the key_name  <br>
 */
public class SystemInitDao extends BaseDao {

	/** the alias of KEY_VALUE **/
	private static final String ALIAS = "value";

	/** get the flow control flag **/
	private static final String GET_VALUE = "select KEY_VALUE as " + ALIAS
			+ " from SYSTEM_INIT" + " where KEY_NAME = ? ";

	/** the sql of lock row **/
	private static final String SKIP_LOCKED = "for update skip locked";


	/**
	 * lock And GetMultiBootFlag
	 */
	public Object lockAndGetMultiBootFlag() {
		return getSystemInitValue(DEFRAG_MULTI_BOOT, true, false);
	}

	/**
	 * get the system object value from SystemInit
	 * 
	 * @param type
	 *            the type of system init
	 * @param isLocked
	 *            is necessary for lock the row
	 * @param isAutoConnection
	 *            is the connection create automic
	 * @return the object value
	 */
	private Object getSystemInitValue(final SystemInitType type,
			final boolean isLocked, final boolean isAutoConnection) {
		Object value = null;
		try {
			final String sql = getSql(isLocked);
			if (isAutoConnection) {
				prepareStatement(sql);
			} else {
				prepareStatementCon(sql);
			}

			setParam(index++, type.name());
			executeQuery();
			if (next()) {
				value = getObject(ALIAS);
			}
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
			if (isAutoConnection) {
				releaseConnectionToPoll();
			}
		}
		return value;
	}

	/**
	 * get detail Sql wether locked
	 * 
	 * @param isLocked
	 * @return the detail sql
	 */
	private String getSql(final boolean isLocked) {
		return (isLocked ? (GET_VALUE + SKIP_LOCKED) : GET_VALUE);
	}

}
