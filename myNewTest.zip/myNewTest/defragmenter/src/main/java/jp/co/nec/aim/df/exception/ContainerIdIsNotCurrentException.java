package jp.co.nec.aim.df.exception;

public class ContainerIdIsNotCurrentException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7434822287757989782L;

	/**
	 * @param message
	 */
	public ContainerIdIsNotCurrentException(String message) {
		super(message);
	}
}
