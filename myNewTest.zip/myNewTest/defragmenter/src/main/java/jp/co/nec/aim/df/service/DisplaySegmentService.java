package jp.co.nec.aim.df.service;

import static jp.co.nec.aim.df.constant.SystemConstant.BR;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entrance.EntranceBean;
import jp.co.nec.aim.df.util.ToolConsoleUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this service used to display the segment detail in containerId <br>
 * environment just like following: <br>
 * <code> 
•	Sample <br>
•	
•	BIN    SEG_ID   REGIST_RATIO                     REGIST_SIZE/SEG_SIZE RECORD<br>
•	------ ------   -------------------------------- -------------------- --------<br>
•	  SDBL    242   [#########################] 100%       7.20/7.20 (MB)     9843<br>
•	  SDBL    244   [#########################] 100%       7.20/7.20 (MB)     9843<br>
•	  SDBL    246   [#########################] 100%       7.20/7.20 (MB)     9843<br>
•	  SDBL    248   [############             ]  50%       4.00/8.00 (MB)     5468<br>
•	  SDBL    249   [#########################] 100%       8.00/8.00 (MB)    10936<br>
•	                 _________________________<br>
•	                 |           |           |<br>
•	                 0%         50%         100%<br>
 * </code>
 * 
 * @author liuyq
 * 
 */
public class DisplaySegmentService extends BaseService {
    /** log instance **/
    private static final Logger log = LoggerFactory.getLogger(EntranceBean.class);

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -6296144355444002964L;

    /** Container initialize Service */
    private ContainerInitService initService;

    /**
     * initialize
     */
    public void initialize() {
        this.initService = ServiceFactory.createService(ContainerInitService.class);
    }

    /**
     * display the segment information in the containerId
     * 
     * @param containerId
     *            the container id
     */
    public String display(Integer containerId) {
        // log out the current time..
        log.info("Current time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())
                + BR);
        final StringBuffer ret = new StringBuffer();

        // initialize the all container
        List<ContainerSummary> bins = initService.initContainerSummary();

        // AIM system without any bin information
        if (bins == null || bins.isEmpty()) {
            log.warn("AIM system without any Container information..");
            return ret.toString();
        }

        // if the containerId is null, display all segments
        // information group by the bin
        if (containerId == null) {
            if (log.isDebugEnabled()) {
                log.debug("the specified container id is null, display all "
                        + "segment infomation group by the Container..");
            }

            // loop the all container and display the segment detail.
            for (final ContainerSummary bin : bins) {
                try {
                    ret.append(ToolConsoleUtil.displaySegments(bin));
                } catch (Exception ex) {
                    log.error("exception occurred while do display segment operation..", ex);
                    continue;
                }
            }
        } else {
            boolean isBinFound = false;
            // using the specified container id
            for (final ContainerSummary bin : bins) {
                final int id = bin.getContainerId();
                if (containerId == id) {
                    ret.append(ToolConsoleUtil.displaySegments(bin));
                    isBinFound = true;
                    break;
                }
            }

            if (!isBinFound) {
                log.warn("Specified CONTAINER_ID:{} does not contain Segments."
                        + " To display all Segments, just specify blank.", containerId);
            }
        }
        return ret.toString();
    }
}
