package jp.co.nec.aim.df.util;

import static jp.co.nec.aim.df.constant.SystemConstant.CONNECTION_TIMEOUT;
import static jp.co.nec.aim.df.constant.SystemConstant.REDIRECTING;
import static jp.co.nec.aim.df.constant.SystemConstant.RETRY_EXECUTIONCOUNT;
import static jp.co.nec.aim.df.constant.SystemConstant.SOCKET_BUFFERSIZE;
import static jp.co.nec.aim.df.constant.SystemConstant.SOCKET_TIMEOUT;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import jp.co.nec.aim.df.entity.HttpResponseInfo;
import jp.co.nec.aim.df.exception.CommunicationException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this is the Communication common class <br>
 * using post method to MM to send the signal <br>
 * and return the status code and result <br>
 */
public final class CommunicationUtil {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(CommunicationUtil.class);

	/**
	 * post communication method <br>
	 * default timeout -> 10s <br>
	 * default post retry count -> 3 <br>
	 * 
	 * @param url
	 *            post url
	 * @param containerId
	 *            the bind id will be send to MM
	 * @param status
	 *            the signal(start or stop) will be send to MM
	 * @return HttpResponse instance
	 * @throws CommunicationException
	 */
	public static final HttpResponseInfo postCommunication(final String url,
			final Map<String, String> header, boolean isRetryAble)
			throws CommunicationException {
		if (log.isDebugEnabled()) {
			log.debug("start CommunicationUtil postCommunication..");
		}

		DefaultHttpClient httpClient = null;
		HttpPost httpPost = null;
		String bodyMessage = null;
		int statusCode;
		try {
			// create instance httpClient with hTTP parameter
			// set the retry handler
			httpClient = new DefaultHttpClient(setParam());
			if (isRetryAble) {
				httpClient.setHttpRequestRetryHandler(retryHandler);
			} else {
				httpClient.setHttpRequestRetryHandler(noRetryHander);
			}

			// create post instance
			httpPost = new HttpPost(url);

			// set header the container id and status that will transform to MM
			if (!Util.isMapNullOrEmpty(header)) {
				final Set<Entry<String, String>> entrys = header.entrySet();
				for (final Entry<String, String> entry : entrys) {
					httpPost.setHeader(entry.getKey(), entry.getValue());
				}
			}

			// get the status code and body message.
			HttpResponse response = httpClient.execute(httpPost);
			statusCode = response.getStatusLine().getStatusCode();
			HttpEntity reEntity = response.getEntity();
			if (reEntity != null) {
				bodyMessage = EntityUtils.toString(reEntity);
			}
		} catch (IOException e) {
			throw new CommunicationException(
					"IOException occurred while execute post method to MM..", e);
		} catch (Exception e) {
			throw new CommunicationException(
					"unknown Exception occurred while execute post method to MM..",
					e);
		} finally {
			ConnectionUtil.close(httpPost);
			ConnectionUtil.close(httpClient);
		}

		if (log.isDebugEnabled()) {
			log.debug("end CommunicationUtil postCommunication..");
		}
		return new HttpResponseInfo(statusCode, bodyMessage);
	}

	/**
	 * the retry handler,default max retry count is 3.
	 */
	private static HttpRequestRetryHandler retryHandler = new HttpRequestRetryHandler() {
		public boolean retryRequest(IOException exception, int executionCount,
				HttpContext context) {
			if (log.isDebugEnabled()) {
				log.debug("start CommunicationUtil retryRequest..");
			}

			if (executionCount <= RETRY_EXECUTIONCOUNT) {
				log.warn("Send signal to MM,  Retried connection {}"
						+ " times, which exceeds the maximum"
						+ " retry count of {}.", executionCount,
						RETRY_EXECUTIONCOUNT);
			} else {
				// Do not retry if over max retry count
				throw new CommunicationException("retry the request "
						+ executionCount + " times");
			}
			if (log.isDebugEnabled()) {
				log.debug("end CommunicationUtil retryRequest..");
			}
			return true;
		}
	};

	private static HttpRequestRetryHandler noRetryHander = new DefaultHttpRequestRetryHandler(
			0, false);

	/**
	 * set the parameter include <br>
	 * connection_timeout is set to 2 second<br>
	 * socket_timeout is set to 2 second<br>
	 * socket_buffersize is set to 1024 <br>
	 * redirecting is set true<br>
	 * 
	 * @return HttpParams instance
	 */
	private static final HttpParams setParam() {
		if (log.isDebugEnabled()) {
			log.debug("start CommunicationUtil SetParam..");
		}

		final HttpParams httpParams = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParams,
				CONNECTION_TIMEOUT);
		HttpConnectionParams.setSoTimeout(httpParams, SOCKET_TIMEOUT);
		HttpConnectionParams.setSocketBufferSize(httpParams, SOCKET_BUFFERSIZE);
		HttpClientParams.setRedirecting(httpParams, REDIRECTING);

		if (log.isDebugEnabled()) {
			log.debug("set the http parameter, ConnectionTimeout: {}, "
					+ "SocketTimeout: {}, " + "SocketBufferSize: {}, "
					+ "isRedirecting: {}", new Object[] { CONNECTION_TIMEOUT,
					SOCKET_TIMEOUT, SOCKET_BUFFERSIZE, REDIRECTING });
		}

		if (log.isDebugEnabled()) {
			log.debug("end CommunicationUtil SetParam..");
		}
		return httpParams;
	}
}
