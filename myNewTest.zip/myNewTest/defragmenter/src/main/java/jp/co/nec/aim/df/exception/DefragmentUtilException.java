package jp.co.nec.aim.df.exception;

public class DefragmentUtilException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3043993852433416329L;

	/**
	 * @param message
	 */
	public DefragmentUtilException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public DefragmentUtilException(String message, Throwable cause) {
		super(message, cause);
	}
}
