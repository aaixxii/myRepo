package jp.co.nec.aim.df.core;

import static jp.co.nec.aim.df.constant.SystemConstant.COMMA;
import static jp.co.nec.aim.df.constant.SystemConstant.SEGMENT_HEADER_LENGTH;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import jp.co.nec.aim.df.constant.Header;
import jp.co.nec.aim.df.entity.SegmentSummary;

/**
 * the defragmentation plan
 */
public final class Plan {

	/** the number of joint **/
	@Header(length = 10, headerName = "joint")
	private int joint;

	/** the container id **/
	@Header(length = 16, headerName = "container Id")
	private int containerId;

	/** first segment id that will be merger **/
	@Header(length = 15, headerName = "first SegId")
	private long firstSegId;

	private long lastSegId;

	/** maxSegmentSize **/
	@Header(length = 20, headerName = "max Segment Size")
	private int maxSegmentSize;


	public int getMaxSegmentSize() {
		return maxSegmentSize;
	}

	// ////////////////////////////////////////////////////////////
	// /////////////////// DM download related/////////////////////
	// ///////////////////////////////////////////////////////////
	@Header(length = 20, headerName = "max Segment Diff")
	private int maxSegmentDiffs;

	public int getMaxSegmentDiffs() {
		return maxSegmentDiffs;
	}

	/** the segment information that will be merger **/
	private List<SegmentSummary> willMergerSegs = new ArrayList<SegmentSummary>();

	/**
	 * constructor
	 */
	public Plan() {
	}

	/**
	 * another constructor
	 * 
	 * @param joint
	 * @param containerId
	 * @param maxSegmentSize
	 * @param maxSegmentDiffs
	 * @param segMergerList
	 */
	public Plan(int joint, int containerId, int maxSegmentSize,
			int maxSegmentDiffs, Collection<SegmentSummary> segMergerList) {
		this.joint = joint;
		this.containerId = containerId;
		this.maxSegmentSize = maxSegmentSize;
		this.maxSegmentDiffs = maxSegmentDiffs;
		this.willMergerSegs.addAll(segMergerList);
		if (!segMergerList.isEmpty()) {
			this.firstSegId = willMergerSegs.get(0).getSegId();
			final int size = willMergerSegs.size();
			this.lastSegId = willMergerSegs.get(size - 1).getSegId();
		}
	}

	private static final int FIRST_INDEX = 0;

	public int getJoint() {
		return joint;
	}

	public long getFirstSegId() {
		return firstSegId;
	}

	public long getLastSegId() {
		return lastSegId;
	}

	public List<SegmentSummary> getWillMergerSegs() {
		return willMergerSegs;
	}

	public int getContainerId() {
		return containerId;
	}

	public SegmentSummary getFirstSegment() {
		return willMergerSegs.get(FIRST_INDEX);
	}

	public void setOtherSegmentToDelete() {
		int index = 0;
		for (SegmentSummary segment : willMergerSegs) {
			if (index++ == FIRST_INDEX) {
				continue;
			}
			segment.setWillbeDeleted(true);
		}
	}

	/**
	 * getSegIdsSpliteByComma
	 * 
	 * @return the segment id arrays split by comma
	 */
	public String getSegIdsSplitByComma() {
		StringBuilder sb = new StringBuilder();
		final int size = willMergerSegs.size();
		for (int index = 0; index < size; index++) {
			final SegmentSummary segment = willMergerSegs.get(index);
			sb.append(segment.getSegId());
			if (index != size - 1) {
				sb.append(COMMA);
			}
		}
		return sb.toString();
	}

	public long getFirstSegmentStartId() {
		if (willMergerSegs.isEmpty()) {
			return -1;
		}
		return willMergerSegs.get(FIRST_INDEX).getStartId();
	}

	public long getLastSegmentEndId() {
		if (willMergerSegs.isEmpty()) {
			return -1;
		}
		final int size = willMergerSegs.size();
		return willMergerSegs.get(size - 1).getEndId();
	}

	public long getRecordCount() {
		long totalCount = 0;
		for (SegmentSummary segment : willMergerSegs) {
			totalCount += segment.getRecordCount();
		}
		return totalCount;
	}

	/**
	 * get Total segment that will be merger binary length
	 * 
	 * @return size
	 */
	public long getTotalBlCompacted() {
		long length = 0;
		for (final SegmentSummary segment : willMergerSegs) {
			length += segment.getBlCompacted();
		}
		return length;
	}

	/**
	 * get Actual segment binary_length_compacted <br>
	 * remove the segment_header_length is necessary
	 * 
	 * @return actual segment binary_length_compacted
	 */
	public long getOneResultActualSegmentL() {
		final long sumLength = getTotalBlCompacted();
		final int removeHeaderSize = SEGMENT_HEADER_LENGTH * (this.joint - 1);
		return (sumLength - removeHeaderSize);
	}

	/**
	 * isRemainDataNotHigherOne
	 * 
	 * @return is RemainData Not Higher One segment
	 */
	public boolean isRemainDataNotHigherOne() {
		final long length = this.getOneResultActualSegmentL();
		if (length <= maxSegmentSize) {
			return true;
		}
		return false;
	}

	/**
	 * add segment to willMergerSegs
	 * 
	 * @param segment
	 *            segment
	 */
	public void addwillMergerSegs(SegmentSummary segment) {
		this.willMergerSegs.add(segment);
	}
}
