package jp.co.nec.aim.df.service;

import static jp.co.nec.aim.df.constant.SystemConstant.MM_COMMAND;
import static jp.co.nec.aim.df.constant.SystemConstant.MM_STATUS;

import java.util.HashMap;
import java.util.Map;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.entity.HttpResponseInfo;
import jp.co.nec.aim.df.util.CommunicationUtil;
import jp.co.nec.aim.df.util.PropertiesUtil;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//TODO 
/**
 * Status Checker Service is used to check the MM is not alive and <br>
 * the flag of MMCare is true. skip do defragment operation.
 */
public class StatusCheckerService extends BaseService {

	/** serialVersionUID */
	private static final long serialVersionUID = 3557351407252939601L;
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(StatusCheckerService.class);
	private boolean isMMCare;

	@Override
	public void initialize() {
		this.isMMCare = PropertiesUtil.getMmCare();
	}

	/**
	 * MMCare and MMAlive 's relation
	 * |MMCare |MMAlive |status
	 * |    Y  |     Y  | OK
	 * |    Y  |     N  | Cancel
	 * |    N  |     Y  | OK
	 * |    N  |     N  | OK
	 * @return is MM FlowControl Status oK
	 */
	public boolean isMMStatusOk() {
		if (isMMCare) {
			if (!isMMAlive(true)) {
				log.info("MM care flag is true, MM is not alive, "
						+ "skip do defragment operation..");
				return false;
			}
		}
		return true;
	}

	/**
	 * check the MM is alive
	 * 
	 * @return is MM alive or not
	 */
	public boolean isMMAlive(boolean retryAble) {
		final String mmUrl = PropertiesUtil.getMMUrl();
		try {
			// the transmission header
			Map<String, String> header = new HashMap<String, String>();
			header.put(MM_COMMAND, MM_STATUS);
			
			HttpResponseInfo response = CommunicationUtil.postCommunication(
					mmUrl, header, retryAble);
			if (response.getStatusCode() == HttpStatus.SC_OK) {
				if (log.isDebugEnabled()) {
					log.debug("Post to MM webservice successfully, "
							+ "MM is alive, MM url:{}.", mmUrl);
				}
				return true;
			}
		} catch (Exception ex) {
			if (log.isDebugEnabled()) {
				log.debug("Post to MM webservice error, MM url:{}.",
						mmUrl);
			}
		}
		return false;
	}
}
