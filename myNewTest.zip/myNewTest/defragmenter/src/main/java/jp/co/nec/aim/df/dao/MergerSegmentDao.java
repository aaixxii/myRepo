package jp.co.nec.aim.df.dao;

import static jp.co.nec.aim.df.constant.SystemConstant.REPLACE;
import static jp.co.nec.aim.df.constant.SystemConstant.TEMPLATE_HEADER_LENGTH;
import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.entity.RangeSegment;
import jp.co.nec.aim.df.exception.DefragmentDaoException;

/**
 * MergerSegmentDao is used for merger segment operation
 */
public class MergerSegmentDao extends BaseDao {

	/** find the range id that total length is low than parameter **/
	private static final String FIND_RANGE_INFOS = " SELECT rangeId, "
			+ "       totalLength, " + "       recordCount, "
			+ "       segmentId "
			+ "FROM   (SELECT /*+ index(pb PERSON_BIOMETRICS_IDX3) */ pb.biometrics_id AS rangeId, "
			+ "               s.segment_id                    AS segmentId, "
			+ "               Sum(1) " + "                 OVER ( "
			+ "                   partition BY cs.container_id "
			+ "                   ORDER BY pb.biometrics_id)  AS recordCount, "
			+ "               Sum(pb.biometric_data_len + ?) "
			+ "                 OVER( "
			+ "                   partition BY cs.container_id "
			+ "                   ORDER BY pb.biometrics_id ) AS totalLength "
			+ "        FROM   person_biometrics pb, "
			+ "               segments s,"
			+ "               containers  cs "
			+ "        WHERE  s.bio_id_start <= pb.biometrics_id "
			+ "               AND s.bio_id_end >= pb.biometrics_id "
			+ "               AND pb. container_id = cs.container_id "
			+ "               AND s.segment_id IN ( " + REPLACE + " ) "
			+ "               AND cs.container_id = ? "
			+ "               AND pb.biometrics_id >= ? "
			+ "        ORDER  BY pb.biometrics_id DESC) "
			+ "WHERE  totalLength <= ? " + "       AND rownum = 1 ";

	/** get the next biometrics_id belongs to the bin **/
	private static final String GET_NEXT_ID = "SELECT tmp.biometricsId "
			+ "FROM " + "(SELECT /*+ index(pb PERSON_BIOMETRICS_IDX3) */ pb.biometrics_id AS biometricsId "
			+ "FROM   person_biometrics pb,"
			+ "       segments s,"
			+ "       containers cs "
			+ "WHERE  pb.container_id = cs.container_id "
			+ "       AND s.bio_id_start <= pb.biometrics_id "
			+ "       AND s.bio_id_end >= pb.biometrics_id "
			+ "       AND cs.container_id = ?" + "       AND pb.biometrics_id > ? "
			+ "       AND s.segment_id IN ( " + REPLACE + " ) "
			+ "ORDER  BY pb.biometrics_id ) tmp" + " WHERE rownum = 1";

	/**
	 * find the range information in person_biometrics while merger the segment
	 * 
	 * @param containerId
	 *            container id
	 * @param segmentIds
	 *            segment id
	 * @param vacancySize
	 *            vacancy Size
	 * @param startPerId
	 *            start person id
	 * @return the range segment information
	 */
	public RangeSegment getPersonRangeInfo(final int containerId,
			final String segmentIds, final int vacancySize,
			final long startPerId) {
		RangeSegment rangesegment = null;
		try {
			final String sql = FIND_RANGE_INFOS.replace(REPLACE, segmentIds);
			prepareStatementCon(sql);
			setParam(index++, TEMPLATE_HEADER_LENGTH);
			setParam(index++, containerId);
			setParam(index++, startPerId);
			setParam(index++, vacancySize);
			executeQuery();
			if (next()) {
				rangesegment = mapping(RangeSegment.class);
			}
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
		}
		return rangesegment;
	}

	/**
	 * get the Next biometricsId
	 * 
	 * @param containerId
	 *            the biometricsId belong to this bin
	 * @param biometricsId
	 * @return the Next biometricsId belongs to this bin
	 */
	public Long getNextId(final int containerId, final long biometricsId,
			final String segmentIds) {
		Long nextId = null;
		try {
			final String sql = GET_NEXT_ID.replace(REPLACE, segmentIds);
			prepareStatementCon(sql);
			setParam(index++, containerId);
			setParam(index++, biometricsId);
			executeQuery();
			if (next()) {
				nextId = getLong("biometricsId");
			}
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
		}
		return nextId;
	}
}
