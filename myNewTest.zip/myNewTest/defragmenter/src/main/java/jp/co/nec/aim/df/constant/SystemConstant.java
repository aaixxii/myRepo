package jp.co.nec.aim.df.constant;

import java.text.DecimalFormat;

import jp.co.nec.aim.df.util.PropertiesUtil;

/**
 * the SystemConstant class define common field used in system..
 */
public final class SystemConstant {

	/** the start number of segment joint **/
	public static final Integer START_JOINT = 2;

	/** the Max number of segment joint **/
	public static final int MAX_JOINT = PropertiesUtil.getMaxJoint();

	/** the default number of segment joint **/
	public static final int DEFAULT_MAX_JOINT = 5;

	/** the length of segment header **/
	public static final int SEGMENT_HEADER_LENGTH = PropertiesUtil
			.getSegmentHeaderLength();

	/** the length of template header **/
	public static final int TEMPLATE_HEADER_LENGTH = PropertiesUtil
			.getTemplateHeaderLength();

	/** the comma **/
	public static final String COMMA = ",";

	/** the duration of poll job **/
	public static final int POLLING_JOB_DURATION = 2000;

	/** http protocol **/
	public static final String HTTP_PROTOCOL = "http://";

	/** colon **/
	public static final String COLON = ":";

	/** the signal of stop **/
	public static final String MM_STATUS_STOP = "stop";

	/** the signal of start **/
	public static final String MM_STATUS_START = "start";

	/** the signal of status **/
	public static final String MM_STATUS = "status";
	
	/** the key of container id **/
	public static final String MM_DEFRAGCONTAINERID = "DefragContainerId";

	/** the key of status **/
	public static final String MM_COMMAND = "status";

	/** the connection time out **/
	public static final int CONNECTION_TIMEOUT = PropertiesUtil
			.getConnectionTimeout();

	/** the socket time out **/
	public static final int SOCKET_TIMEOUT = PropertiesUtil.getSocketTimeout();

	/** the socket buffer size **/
	public static final int SOCKET_BUFFERSIZE = 1024;

	/** the flag of redirecting **/
	public static final boolean REDIRECTING = true;

	/** the default retry count **/
	public static final int RETRY_EXECUTIONCOUNT = PropertiesUtil
			.getRetryExecutionCount();

	/** the char of comma **/
	public static final char COMMA_CHAR = ',';

	/** default max segment different range **/
	public static final int DEFAULT_MAX_SEGMENT_DIFFS = 1000;

	/** array first index **/
	public static final int FIRST_INDEX = 0;

	/** MM properties name **/
	public static final String MM_PROPERTIES_NAME = "MM.properties";

	/** JDBC properties name **/
	public static final String JDBC_PROPERTIES_NAME = "jdbc.properties";

	/** defragment properties name **/
	public static final String DEFRAGMENT_PROPERTIES_NAME = "defragment.properties";

	/** the format type of double **/
	private static final String FORMAT_TYPE = "0.00000000";

	/** the format instance **/
	public static final DecimalFormat FORMAT = new DecimalFormat(FORMAT_TYPE);

	/** segment replace **/
	public static final String REPLACE = "$SegmentIds";

	/** empty string **/
	public static final String EMPTY = "";

	/** the line number **/
	public static final int LINE_NUMBER = 1;

	public static final double STANDARD_LEVEL = 1.00;

	public static final double LEVEL_ERRORS = 0.05;

	public static final int MAXPLANSIZE = PropertiesUtil.getMaxPlanSize();

	/** the default number of max plan **/
	public static final int DEFAULT_MAX_PLAN_SIZE = 1;

	public static final long POLLCONTAINERJOBS_TIMEOUT = PropertiesUtil
			.getPollContainerJobsTimeout();

	public static final String BR = System.getProperty("line.separator");

	/** skip do defragment warn message **/
	public static final String SKIP_MESSAGE = "skip do defragment opearation directly in the following situation:"
			+ BR
			+ "1. MM_Care is true And MM is not alive. ";
}
