package jp.co.nec.aim.df.service;

import java.util.List;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.dao.ContainerAnalysisDao;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.entity.TotalInformation;
import jp.co.nec.aim.df.exception.DefragmentServiceException;

/**
 * inquiry the container information <br>
 * and the segment information that belongs to container <br>
 */
public class ContainerInitService extends BaseService {

	private static final long serialVersionUID = 5112400498100073438L;
	/** dAo instance **/
	private ContainerAnalysisDao dao;

	/**
	 * constructor
	 */
	public ContainerInitService() {
	}

	@Override
	public void initialize() {
		this.dao = DaoFactory.createDao(ContainerAnalysisDao.class);
	}

	/**
	 * initTotalContainer
	 */
	public TotalInformation initTotalContainer() {
		try {
			TotalInformation totalinformation = dao.getTotalInformation();
			return totalinformation;
		} catch (Exception ex) {
			throw new DefragmentServiceException(ex);
		}
	}

	/**
	 * initContainerSummary
	 */
	public List<ContainerSummary> initContainerSummary() {
		try {
			final int maxSegmentDiff = dao.getMaxSegmentDiffs();
			final List<ContainerSummary> summary = dao.getContainerSummary();

			for (final ContainerSummary container : summary) {
				final int containerid = container.getContainerId();
				final List<SegmentSummary> segmentSummary = dao
						.getSegmentSummary(containerid);
				container.addSegmentList(segmentSummary);
				container.setSegmentParameter();
				container.setMaxSegmentDiffs(maxSegmentDiff);
			}
			return summary;
		} catch (Exception ex) {
			throw new DefragmentServiceException(ex);
		}
	}
}
