package jp.co.nec.aim.df.entity;

import java.util.List;

import jp.co.nec.aim.df.constant.FieldMapped;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * the Segment version detail inquiry from database
 */
public final class SegmentVersion {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(SegmentVersion.class);

	/**
	 * the default constructor
	 */
	public SegmentVersion() {
	}

	/**
	 * the constructor with field
	 * 
	 * @param segmentId
	 * @param version
	 * @param reVersion
	 */
	public SegmentVersion(Long segmentId, Integer version, Integer reVersion) {
		this.segmentId = segmentId;
		this.version = version;
		this.reVersion = reVersion;
	}

	@FieldMapped
	private Long segmentId;
	@FieldMapped
	private Integer version;
	@FieldMapped
	private Integer reVersion;

	public long getSegmentId() {
		return segmentId;
	}

	public int getVersion() {
		return version;
	}

	public int getReVersion() {
		return reVersion;
	}

	/**
	 * check the latest segment version is Match segment Version <br>
	 * before Analysis
	 * 
	 * @param segments
	 * @return is match the version
	 */
	public boolean isMatchVersion(List<SegmentSummary> segments) {
		for (final SegmentSummary segment : segments) {
			if (this.segmentId == segment.getSegId().longValue()) {
				if (log.isDebugEnabled()) {
					log.debug("check the segment version is matchable..");
				}
				boolean isMatch = (segment.getVersionBackUp().intValue() == version
						.intValue())
						&& (segment.getReVersionBackUp().intValue() == reVersion
								.intValue());
				if (!isMatch) {
					log.info("the segment version has changed, segment id:"
							+ this.segmentId + ", the version in the database:"
							+ this.version + " and version before analysis:"
							+ segment.getVersionBackUp());
				}
				return isMatch;
			}
		}
		return false;
	}
}
