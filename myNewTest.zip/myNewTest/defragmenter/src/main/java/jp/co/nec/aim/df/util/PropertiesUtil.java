package jp.co.nec.aim.df.util;

import static jp.co.nec.aim.df.constant.SystemConstant.COLON;
import static jp.co.nec.aim.df.constant.SystemConstant.HTTP_PROTOCOL;
import static jp.co.nec.aim.df.constant.SystemConstant.JDBC_PROPERTIES_NAME;
import static jp.co.nec.aim.df.constant.SystemConstant.MM_PROPERTIES_NAME;
import static jp.co.nec.aim.df.constant.SystemConstant.DEFRAGMENT_PROPERTIES_NAME;
import static jp.co.nec.aim.df.constant.SystemConstant.DEFAULT_MAX_PLAN_SIZE;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import jp.co.nec.aim.df.constant.DefragmentProperties;
import jp.co.nec.aim.df.constant.JdbcProperties;
import jp.co.nec.aim.df.constant.MMProperties;
import jp.co.nec.aim.df.exception.DefragmentUtilException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static jp.co.nec.aim.df.constant.SystemConstant.DEFAULT_MAX_JOINT;

/**
 * this is the Properties common class <br>
 * read the Properties file and return <br>
 */
public final class PropertiesUtil {

	/** jdbcProperties instance **/
	private static Properties jdbcProperties;
	/** mmProperties instance **/
	private static Properties mmProperties;
	/** defragmentProperties instance **/
	private static Properties defragmentProperties;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(PropertiesUtil.class);

	static {
		InputStream jdbcIn = null;
		InputStream mmIn = null;
		InputStream defragmentIn = null;

		try {
			if (log.isDebugEnabled()) {
				log.debug("load the jdbc Properties..");
			}
			// load MM.properties
			jdbcProperties = new Properties();
			jdbcIn = PropertiesUtil.class.getClassLoader().getResourceAsStream(
					JDBC_PROPERTIES_NAME);
			jdbcProperties.load(jdbcIn);
			if (log.isDebugEnabled()) {
				log.debug("end load the jdbc Properties..");
			}

			if (log.isDebugEnabled()) {
				log.debug("load the mm Properties..");
			}
			// load jdbc.properties
			mmProperties = new Properties();
			mmIn = PropertiesUtil.class.getClassLoader().getResourceAsStream(
					MM_PROPERTIES_NAME);
			mmProperties.load(mmIn);
			if (log.isDebugEnabled()) {
				log.debug("end load the mm Properties..");
			}

			if (log.isDebugEnabled()) {
				log.debug("load the defragment Properties..");
			}
			defragmentProperties = new Properties();
			defragmentIn = PropertiesUtil.class.getClassLoader()
					.getResourceAsStream(DEFRAGMENT_PROPERTIES_NAME);
			defragmentProperties.load(defragmentIn);
			if (log.isDebugEnabled()) {
				log.debug("end load the defragment Properties..");
			}
		} catch (IOException ex) {
			throw new DefragmentUtilException(
					"IOException occurred while load Properties file.", ex);
		} finally {
			ConnectionUtil.close(jdbcIn);
			ConnectionUtil.close(mmIn);
			ConnectionUtil.close(defragmentIn);
		}
	}

	// ////////////////////////////////////////////////////////////////////////
	// /////////////////////////////MM.properties//////////////////////////////
	// ////////////////////////////////////////////////////////////////////////
	/**
	 * get MM Properties value from Properties
	 * 
	 * @return the key of properties
	 */
	private static Object getMMValue(final String key) {
		final Object value = mmProperties.getProperty(key);
		if (value == null) {
			throw new DefragmentUtilException(
					"the Properties value is null while "
							+ "read from mmProperties and key is " + key);
		}
		return value;
	}

	private static String getMmIp() {
		return String.valueOf(getMMValue(MMProperties.MM_IP.getProperty()));
	}

	private static String getMmPort() {
		return String.valueOf(getMMValue(MMProperties.MM_PORT.getProperty()));
	}

	private static String getMmAdds() {
		return String.valueOf(getMMValue(MMProperties.MM_ADDS.getProperty()));
	}

	public static boolean getMmCare() {
		return Boolean.valueOf(getMMValue(MMProperties.MM_CARE.getProperty())
				.toString());
	}

	public static String getMMUrl() {
		return HTTP_PROTOCOL + getMmIp() + COLON + getMmPort() + getMmAdds();
	}

	// ////////////////////////////////////////////////////////////////////////
	// /////////////////////////////jdbc.properties////////////////////////////
	// ////////////////////////////////////////////////////////////////////////
	/**
	 * get jdbc Properties value from Properties
	 * 
	 * @return the key of properties
	 */
	private static Object getJdbcValue(final String key) {
		final Object value = jdbcProperties.getProperty(key);
		if (value == null) {
			throw new DefragmentUtilException(
					"the Properties value is null while "
							+ "read from jdbcProperties and key is " + key);
		}
		return value;
	}

	public static String getJdbcDriverclassname() {
		return String.valueOf(getJdbcValue(JdbcProperties.JDBC_DRIVERCLASSNAME
				.getProperty()));
	}

	public static String getJdbcUrl() {
		return String.valueOf(getJdbcValue(JdbcProperties.JDBC_URL
				.getProperty()));
	}

	public static String getJdbcUsername() {
		return String.valueOf(getJdbcValue(JdbcProperties.JDBC_USERNAME
				.getProperty()));
	}

	public static String getJdbcPassword() {
		return String.valueOf(getJdbcValue(JdbcProperties.JDBC_PASSWORD
				.getProperty()));
	}

	public static int getJdbcMaxactive() {
		return Integer.parseInt(getJdbcValue(
				JdbcProperties.JDBC_MAXACTIVE.getProperty()).toString());
	}

	public static int getJdbcInitialsize() {
		return Integer.parseInt(getJdbcValue(
				JdbcProperties.JDBC_INITIALSIZE.getProperty()).toString());
	}

	public static int getJdbcMaxidle() {
		return Integer.parseInt(getJdbcValue(
				JdbcProperties.JDBC_MAXIDLE.getProperty()).toString());
	}

	public static int getJdbcMinidle() {
		return Integer.parseInt(getJdbcValue(
				JdbcProperties.JDBC_MINIDLE.getProperty()).toString());
	}

	public static long getJdbcMaxwait() {
		return Long.parseLong(getJdbcValue(
				JdbcProperties.JDBC_MAXWAIT.getProperty()).toString());
	}

	public static boolean getJdbcDefaultautocommit() {
		return Boolean
				.parseBoolean(getJdbcValue(
						JdbcProperties.JDBC_DEFAULTAUTOCOMMIT.getProperty())
						.toString());
	}

	public static boolean getJbdctestOnBorrow() {
		return Boolean.parseBoolean(getJdbcValue(
				JdbcProperties.JDBC_TESTONBORROW.getProperty()).toString());
	}

	public static boolean getJbdctestOnReturn() {
		return Boolean.parseBoolean(getJdbcValue(
				JdbcProperties.JDBC_TESTONRETURN.getProperty()).toString());
	}

	public static boolean getJbdctestWhileIdle() {
		return Boolean.parseBoolean(getJdbcValue(
				JdbcProperties.JDBC_TESTWHILEIDLE.getProperty()).toString());
	}

	public static String getJdbcValidationQuery() {
		return getJdbcValue(JdbcProperties.JDBC_VALIDATIONQUERY.getProperty())
				.toString();
	}

	// ////////////////////////////////////////////////////////////////////////
	// //////////////////////////defragment.properties/////////////////////////
	// ////////////////////////////////////////////////////////////////////////
	/**
	 * get defragment Properties value from Properties
	 * 
	 * @return the key of properties
	 */
	private static Object getDefragmentValue(final String key) {
		final Object value = defragmentProperties.getProperty(key);
		if (value == null) {
			throw new DefragmentUtilException(
					"the Properties value is null while "
							+ "read from defragmentProperties and key is "
							+ key);
		}
		return value;
	}

	public static int getMaxJoint() {
		Object o = getDefragmentValue(DefragmentProperties.DEFRAGMENT_MAX_JOINT
				.getProperty());

		return (o == null || o.equals("")) ? DEFAULT_MAX_JOINT : Integer
				.parseInt(o.toString());
	}

	public static int getSegmentHeaderLength() {
		return Integer.parseInt(getDefragmentValue(
				DefragmentProperties.DEFRAGMENT_SEGMENT_HEADER_LENGTH
						.getProperty()).toString());
	}

	public static int getTemplateHeaderLength() {
		return Integer.parseInt(getDefragmentValue(
				DefragmentProperties.DEFRAGMENT_TEMPLATE_HEADER_LENGTH
						.getProperty()).toString());
	}

	public static int getConnectionTimeout() {
		return Integer.parseInt(getDefragmentValue(
				DefragmentProperties.DEFRAGMENT_CONNECTION_TIMEOUT
						.getProperty()).toString());
	}

	public static int getSocketTimeout() {
		return Integer.parseInt(getDefragmentValue(
				DefragmentProperties.DEFRAGMENT_SOCKET_TIMEOUT.getProperty())
				.toString());
	}

	public static int getRetryExecutionCount() {
		return Integer.parseInt(getDefragmentValue(
				DefragmentProperties.DEFRAGMENT_RETRY_EXECUTIONCOUNT
						.getProperty()).toString());
	}

	public static int getMaxPlanSize() {
		Object o = getDefragmentValue(DefragmentProperties.DEFRAGMENT_MAX_PLAN_SIZE
				.getProperty());

		return (o == null || o.equals("")) ? DEFAULT_MAX_PLAN_SIZE : Integer
				.parseInt(o.toString());
	}

	public static long getPollContainerJobsTimeout() {
		return Long.parseLong(getDefragmentValue(
				DefragmentProperties.DEFRAGMENT_POLLCONTAINERJOBS_TIMEOUT
						.getProperty()).toString());
	}

}
