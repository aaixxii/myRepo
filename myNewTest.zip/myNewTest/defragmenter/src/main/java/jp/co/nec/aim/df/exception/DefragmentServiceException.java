package jp.co.nec.aim.df.exception;

public class DefragmentServiceException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1287506188023072691L;

	/**
	 * @param message
	 */
	public DefragmentServiceException(String message) {
		super(message);

	}

	/**
	 * @param cause
	 */
	public DefragmentServiceException(Throwable cause) {
		super(cause);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public DefragmentServiceException(String message, Throwable cause) {
		super(message, cause);

	}
}
