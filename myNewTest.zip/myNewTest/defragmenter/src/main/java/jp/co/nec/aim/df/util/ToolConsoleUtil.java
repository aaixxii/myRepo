package jp.co.nec.aim.df.util;

import static jp.co.nec.aim.df.constant.SystemConstant.BR;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.Segment;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.entity.convert.EntityConverter;
import jp.co.nec.aim.df.exception.ConsoleException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this Util used to display the detail in containerId <br>
 * 
 * @author liuyq
 * 
 */
public final class ToolConsoleUtil {

    /** log instance **/
    private static final Logger log = LoggerFactory.getLogger(ToolConsoleUtil.class);

    /** the method name will be invoked **/
    private static final String GET_LIST_HEADER = "getListHeader";
    private static final String GET_LIST_BODY = "getListBody";

    /**
     * display the the segment radio detail in containerId this Util used to display
     * the segment detail in containerId <br>
     * environment just like following: <br>
     * <code> 
     •   Sample <br>
     •   ============================================================================<br>
     •   BIN    SEG_ID   REGIST_RATIO                     REGIST_SIZE/SEG_SIZE RECORD<br>
     •   ============================================================================<br>
     •     SDBL    242   [#########################] 100%       7.20/7.20 (MB)     9843<br>
     •     SDBL    244   [#########################] 100%       7.20/7.20 (MB)     9843<br>
     •     SDBL    246   [#########################] 100%       7.20/7.20 (MB)     9843<br>
     •     SDBL    248   [############             ]  50%       4.00/8.00 (MB)     5468<br>
     •     SDBL    249   [#########################] 100%       8.00/8.00 (MB)    10936<br>
     •                    _________________________<br>
     •                    |           |           |<br>
     •                    0%         50%         100%<br>
     * </code>
     * 
     * @param bin
     *            the summary of container
     */
    public static String displaySegments(final ContainerSummary bin) {
        if (log.isDebugEnabled()) {
            log.debug("start ConsoleUtil displaySegment.. ");
        }

        // if the parameter incorrect, throw the exception
        if (bin == null) {
            throw new IllegalArgumentException("the parameter Container is null..");
        }

        final StringBuilder sb = new StringBuilder();
        try {
            final Integer containerid = bin.getContainerId();
            final String containerName = bin.getContainerName();

            // if the current bin has no segment, skip directly
            final List<SegmentSummary> segSummarys = bin.getSegmentSummary();
            if (segSummarys == null || segSummarys.isEmpty()) {
                log.warn("there are no any segments in Container id {} ", containerid);
                return null;
            }

            // invoke the method getListHeader and getListBody to
            // fetch the segment detail information
            final ConsoleUtil obj = new ConsoleUtil();
            final Object retObject = ReflectionUtil.invokeMethodByName(obj, GET_LIST_HEADER,
                    new Object[] { sb, Segment.class });
            final List<Segment> segments = EntityConverter.convertSegments(segSummarys, containerName);
            sb.append(BR);
            ReflectionUtil.invokeMethodByName(obj, GET_LIST_BODY, new Object[] { segments, sb,
                    retObject });

            // output the information to containerId
            log.info(sb.toString());
        } catch (Exception ex) {
            log.error("error occurred while displaySegments..", ex);
            throw new ConsoleException(ex);
        }

        if (log.isDebugEnabled()) {
            log.debug("end ConsoleUtil displaySegment.. ");
        }

        return sb.toString();
    }

    /**
     * the method only for test
     * 
     * @param args
     */
    public static void main(String[] args) {
        final ConsoleUtil obj = new ConsoleUtil();
        final StringBuilder sb = new StringBuilder();

        final Object objRet = ReflectionUtil.invokeMethodByName(obj, "getListHeader", new Object[] {
                sb, Segment.class });

        final List<Segment> segments = new ArrayList<Segment>();
        for (int index = 0; index < 10; index++) {
            segments.add(new Segment("1", "RDBL", String.valueOf(index + 1), "", "", "1000"));
        }
        sb.append(BR);
        ReflectionUtil
                .invokeMethodByName(obj, "getListBody", new Object[] { segments, sb, objRet });
        System.out.println(sb.toString());
    }
}
