package jp.co.nec.aim.df.entrance;

import jp.co.nec.aim.df.constant.ExecuteMode;

import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import org.kohsuke.args4j.Option;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <h1>The AIM deFragmentation System</h1> <br>
 * <h4>1. display the each container information</h4> <br>
 * <h4>2. loop the each container(bin) id, do deFragment operation.</h4> <br>
 * <h4>3. make a deFragmentation plan and display in containerId or file</h4> <br>
 * <h4>4. send a signal to MM, MM stop to check MM is alive and MM care,assign
 * containerId in Segment_Defragment,</h4> <br>
 * <h4>wait for until all the job is done , begin plan execution</h4> <br>
 * <h4>5. according to plan, merger the segment.</h4><br>
 * <h4>6. after merger successfully, persist the segment to database, send to
 * signal to tell MM continue..</h4><br>
 * <h4>7. continue next containerId <br>
 */
public class Entrance {
	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(Entrance.class);

	@Option(required = true, name = "-m", aliases = "--mode", usage = "defragment mode")
	private String mode;

	@Option(name = "-b", aliases = "--container", usage = "defragment container id")
	private Integer containerId;

	/**
	 * the entrance of AIM DeFragmentation System
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		if (log.isDebugEnabled()) {
			log.debug("start Entrance main..");
		}

		if (args == null || args.length == 0) {
			throw new RuntimeException(
					"the defragmentation parameter is null..");
		}

		Entrance entrance = new Entrance();
		CmdLineParser parser = new CmdLineParser(entrance);
		try {
			parser.parseArgument(args);
		} catch (CmdLineException e) {
			throw new RuntimeException(
					"the defragmentation parameters is invalid.", e);
		}

		final EntranceBean bean = new EntranceBean();
		final ExecuteMode mode = bean.getExecuteMode(entrance.mode);

		switch (mode) {
		case DEFRAGMENT:
			bean.doDefragmentation(entrance.containerId);
			break;
		case SEG_DISPLAY:
			bean.displaySegment(entrance.containerId);
			break;
		case SIMULATION:
			bean.simulation(entrance.containerId);
			break;
		default:
			throw new RuntimeException("the mode " + mode + " is not support..");
		}

		if (log.isDebugEnabled()) {
			log.debug("end Entrance main..");
		}
	}

}
