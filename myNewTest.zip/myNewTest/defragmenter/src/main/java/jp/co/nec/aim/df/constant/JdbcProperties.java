package jp.co.nec.aim.df.constant;

/**
 * @type Enum
 * @function jdbc.properties
 * 
 */
public enum JdbcProperties {
	JDBC_DRIVERCLASSNAME("jdbc.driverClassName"), JDBC_URL("jdbc.url"), JDBC_USERNAME(
			"jdbc.username"), JDBC_PASSWORD("jdbc.password"), JDBC_MAXACTIVE(
			"jdbc.maxActive"), JDBC_INITIALSIZE("jdbc.initialSize"), JDBC_MAXIDLE(
			"jdbc.maxIdle"), JDBC_MINIDLE("jdbc.minIdle"), JDBC_MAXWAIT(
			"jdbc.maxWait"), JDBC_DEFAULTAUTOCOMMIT("jdbc.defaultautocommit"), JDBC_TESTONBORROW(
			"jdbc.testOnBorrow"), JDBC_TESTONRETURN("jdbc.testOnReturn"), JDBC_TESTWHILEIDLE(
			"jdbc.testWhileIdle"), JDBC_VALIDATIONQUERY("jdbc.validationQuery");

	private String property;

	private JdbcProperties(String property) {

		this.property = property;
	}

	/**
	 * @function getProperty get the Property
	 * @return
	 */
	public String getProperty() {

		return property;

	}
}
