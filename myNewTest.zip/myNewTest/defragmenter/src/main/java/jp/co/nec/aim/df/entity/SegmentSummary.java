package jp.co.nec.aim.df.entity;

import static jp.co.nec.aim.df.constant.SystemConstant.FORMAT;

import java.io.Serializable;

import jp.co.nec.aim.df.constant.FieldMapped;
import jp.co.nec.aim.df.constant.Header;

/**
 * The information of segment
 */
public final class SegmentSummary implements Serializable {

	/** serialVersionUID */
	private static final long serialVersionUID = -8980569411496621366L;

	public SegmentSummary() {
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public Long getSegId() {
		return segId;
	}

	public void setSegId(Long segId) {
		this.segId = segId;
	}

	public Double getDataRadio() {
		return dataRadio;
	}

	public void setDataRadio(Double dataRadio) {
		this.dataRadio = dataRadio;
	}

	public Double getFragmentRadio() {
		return fragmentRadio;
	}

	public void setFragmentRadio(Double fragmentRadio) {
		this.fragmentRadio = fragmentRadio;
	}

	public Long getStartId() {
		return startId;
	}

	public void setStartId(Long startId) {
		this.startId = startId;
	}

	public Long getEndId() {
		return endId;
	}

	public void setEndId(Long endId) {
		this.endId = endId;
	}

	public Long getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Long recordCount) {
		this.recordCount = recordCount;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public void increaseVersion(int versionPara) {
		this.version += versionPara;
	}

	public Integer getReVersion() {
		return reVersion;
	}

	public void setReVersion(int reVersion) {
		this.reVersion = reVersion;
	}

	public void increaseReVersion(int reVersionPara) {
		this.reVersion += reVersionPara;
	}

	public Long getBlCompacted() {
		return blCompacted;
	}

	public void setBlCompacted(Long blCompacted) {
		this.blCompacted = blCompacted;
	}

	public Long getBlunCompacted() {
		return blunCompacted;
	}

	public void setBlunCompacted(Long blunCompacted) {
		this.blunCompacted = blunCompacted;
	}

	public boolean willbeDeleted() {
		return willbeDeleted;
	}

	public void setWillbeDeleted(boolean willbeDeleted) {
		this.willbeDeleted = willbeDeleted;
	}

	public Integer getVersionBackUp() {
		return versionBackUp;
	}

	public void setVersionBackUp(Integer versionBackUp) {
		this.versionBackUp = versionBackUp;
	}

	public Integer getReVersionBackUp() {
		return reVersionBackUp;
	}

	public void setReVersionBackUp(Integer reVersionBackUp) {
		this.reVersionBackUp = reVersionBackUp;
	}

	/**
	 * the another constructor
	 * 
	 * @param containerId
	 * @param segmentId
	 * @param startId
	 * @param endId
	 * @param recordCount
	 * @param version
	 * @param reVersion
	 * @param blCompacted
	 * @param blunCompacted
	 * @param willbeDeleted
	 * @param dataRadio
	 */
	public SegmentSummary(int containerId, long segmentId, long startId, long endId,
			Long recordCount, int version, int reVersion, Long blCompacted,
			Long blunCompacted, boolean willbeDeleted, Double dataRadio) {
		this.containerId = containerId;
		this.segId = segmentId;
		this.startId = startId;
		this.endId = endId;
		this.recordCount = recordCount;
		this.version = version;
		this.reVersion = reVersion;
		this.versionBackUp = version;
		this.reVersionBackUp = reVersion;
		this.blCompacted = blCompacted;
		this.blunCompacted = blunCompacted;
		this.willbeDeleted = willbeDeleted;
		this.dataRadio = Double.valueOf(FORMAT.format(dataRadio));
		this.fragmentRadio = Double.valueOf(FORMAT.format(1 - dataRadio));
	}

	@FieldMapped
	@Header(length = 16, headerName = "Container Id")
	private Integer containerId;
	@FieldMapped
	@Header(length = 8, headerName = "Seg Id")
	private Long segId;
	@FieldMapped
	@Header(length = 12, headerName = "Data Radio")
	private Double dataRadio;
	@FieldMapped
	@Header(length = 12, headerName = "Frag Radio")
	private Double fragmentRadio;
	@FieldMapped
	@Header(length = 10, headerName = "Start Id")
	private Long startId;
	@FieldMapped
	@Header(length = 8, headerName = "End Id")
	private Long endId;
	@FieldMapped
	@Header(length = 9, headerName = "Records")
	private Long recordCount;
	@FieldMapped
	@Header(length = 10, headerName = "version")
	private Integer version;
	@FieldMapped
	@Header(length = 12, headerName = "reVersion")
	private Integer reVersion;
	@FieldMapped
	@Header(length = 13, headerName = "blCompacted")
	private Long blCompacted;
	@FieldMapped
	@Header(length = 15, headerName = "blunCompacted")
	private Long blunCompacted;
	@Header(length = 10, headerName = "willbeDeleted")
	private boolean willbeDeleted;
	@FieldMapped
	private Integer versionBackUp;
	@FieldMapped
	private Integer reVersionBackUp;
}
