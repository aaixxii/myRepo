package jp.co.nec.aim.df.exception;

public class ConsoleException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1287506188023072691L;

	/**
	 * @param cause
	 */
	public ConsoleException(Throwable cause) {
		super(cause);
	}

	/**
	 * ConsoleException
	 * 
	 * @param message
	 * @param cause
	 */
	public ConsoleException(String message) {
		super(message);
	}
}
