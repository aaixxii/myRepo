package jp.co.nec.aim.df.constant;

public enum DefragmentProperties {
	DEFRAGMENT_MAX_JOINT("defragment.MAX_JOINT"), DEFRAGMENT_SEGMENT_HEADER_LENGTH(
			"defragment.SEGMENT_HEADER_LENGTH"), DEFRAGMENT_TEMPLATE_HEADER_LENGTH(
			"defragment.TEMPLATE_HEADER_LENGTH"), DEFRAGMENT_CONNECTION_TIMEOUT(
			"defragment.CONNECTION_TIMEOUT"), DEFRAGMENT_SOCKET_TIMEOUT(
			"defragment.SOCKET_TIMEOUT"), DEFRAGMENT_RETRY_EXECUTIONCOUNT(
			"defragment.RETRY_EXECUTIONCOUNT"), DEFRAGMENT_MAX_PLAN_SIZE(
			"defragment.MAX_PLAN_SIZE"), DEFRAGMENT_POLLCONTAINERJOBS_TIMEOUT(
			"defragment.POLLCONTAINERJOBS_TIMEOUT");

	private String property;

	private DefragmentProperties(String property) {
		this.property = property;
	}

	/**
	 * @function getProperty get the Property
	 * @return
	 */
	public String getProperty() {

		return property;

	}
}
