package jp.co.nec.aim.df.entrance;

import static jp.co.nec.aim.df.constant.SystemConstant.BR;
import static jp.co.nec.aim.df.constant.SystemConstant.LINE_NUMBER;
import static jp.co.nec.aim.df.constant.SystemConstant.MAX_JOINT;
import static jp.co.nec.aim.df.constant.SystemConstant.SKIP_MESSAGE;
import static jp.co.nec.aim.df.constant.SystemConstant.START_JOINT;

import java.util.List;

import jp.co.nec.aim.df.constant.ExecuteMode;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.exception.CommunicationException;
import jp.co.nec.aim.df.exception.ConsoleException;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.exception.DefragmentUtilException;
import jp.co.nec.aim.df.exception.MultiBootException;
import jp.co.nec.aim.df.exception.PollContainerJobsTimeOutException;
import jp.co.nec.aim.df.exception.ReturnValueNotSuccessException;
import jp.co.nec.aim.df.service.ContainerInitService;
import jp.co.nec.aim.df.service.DisplaySegmentService;
import jp.co.nec.aim.df.service.ExecutionService;
import jp.co.nec.aim.df.service.MakePlanService;
import jp.co.nec.aim.df.service.MultiBootCheckerService;
import jp.co.nec.aim.df.service.ServiceFactory;
import jp.co.nec.aim.df.service.SimulationService;
import jp.co.nec.aim.df.service.StatusCheckerService;
import jp.co.nec.aim.df.util.ConsoleUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * the main flow of defragmentation
 */
public final class EntranceBean {
    /** log instance **/
    private static final Logger log = LoggerFactory.getLogger(EntranceBean.class);

    /** Container initialize Service */
    private ContainerInitService initService;
    /** make Plan Service */
    private MakePlanService makePlanService;
    /** StatusCheckerService **/
    private StatusCheckerService checker;
    /** MultiBootCheckerService **/
    private MultiBootCheckerService mBootChecker;
    /** Container initialize Service */
    private DisplaySegmentService displaySegService;
    /** Simulation Service */
    private SimulationService simulationService;

    /**
     * the main of doDefragmentation
     * 
     * @param containerIdPara
     *            the container id specified from containerId
     */
    public void doDefragmentation(Integer containerIdPara) {
        if (log.isDebugEnabled()) {
            log.debug("start Entrance doDefragmentation..");
        }

        long startTime = System.currentTimeMillis();
        try {
            // first initialize service instance
            initializeService();

            // set new line
            ConsoleUtil.newLine(LINE_NUMBER);

            // display system header in containerId
            ConsoleUtil.displayHeader();

            // check the operation of defragment is Multi-boot
            mBootChecker.begin();

            // check the status is ready for defragment
            if (!checker.isMMStatusOk()) {
                log.warn(SKIP_MESSAGE);
                return;
            }

            // display the Total Container information in containerId
            ConsoleUtil.displayContainerInfo(initService.initTotalContainer());

            // get ContainerSummary information and display in containerId
            List<ContainerSummary> containerList = initService.initContainerSummary();
            ConsoleUtil.displayContainerList(containerList);

            // check START_JOINT is less than MAX_JOINT
            if (MAX_JOINT < START_JOINT) {
                log.warn("MAX_JOINT must be bigger than START_JOINT!!");
                return;
            }

            boolean isFoundBin = false;
            // loop the containerList, and do deFragmentation
            for (final ContainerSummary container : containerList) {
                final int containerId = container.getContainerId();

                // if the parameter container id is specified, skip this operation,
                // do defragMent. otherwise until the loop container id is match
                // the container id specified, do operation.
                if (containerIdPara != null && containerIdPara != containerId) {
                    if (log.isDebugEnabled()) {
                        log.debug("the specified container id is {} "
                                + "and not match the loop container id {}, skip..", containerIdPara, containerId);
                    }
                    continue;
                }

                try {
                    ConsoleUtil.startDisplayBinRange(containerId);

                    // make the plan for current container
                    // if the plan is empty, skip this and go next
                    List<Plan> planArray = makePlanService.makePlan(container);
                    if (planArray.isEmpty()) {
                        log.info("after analysis, the joint number "
                                + "from {} to {} without any defragment" + " plan in containerid {}..",
                                START_JOINT, MAX_JOINT, containerId);
                        continue;
                    }

                    log.info("display the Plan summary " + "before merger and Execute the Plan.");
                    ConsoleUtil.displayPlan(planArray);

                    // create new ExecutionService represent
                    // each container owns different connection
                    ExecutionService execute = ServiceFactory.createService(ExecutionService.class);
                    execute.planExecution(planArray);

                    // display the plan after meger and execute the plan
                    log.info(BR + "display the Plan summary "
                            + "after merger and Execute the Plan.");
                    ConsoleUtil.displayPlan(planArray);
                } catch (CommunicationException ex) {
                    // send signal to MM with communication error,
                    // break from loop, return directly..
                    log.error("communication with MM error while "
                            + "MMCare is ture, stop AIM defragmentation.", ex);
                    break;
                } catch (ReturnValueNotSuccessException ex) {
                    // if the return value after send signal to MM is
                    // incorrect, break from loop, return directly..
                    log.error("receive failed value from MM, " + "stop AIM defragmentation.", ex);
                    break;
                } catch (PollContainerJobsTimeOutException ex) {
                    // if timeout event occurred while wait top level job done
                    // cancel do defragment
                    log.error("PollMuJobTimeOutException occurred..", ex);
                    break;
                } catch (Exception ex) {
                    // if exception occurred while do Execute plan
                    // operation, skip this container
                    // do the next container
                    log.error("Exception occurred while Execute plan.. " + "container id: {}",
                            container.getContainerId(), ex);
                    continue;
                } finally {
                    isFoundBin = true;
                    ConsoleUtil.endDisplayBinRange(containerId);
                }
            }
            // if the specified bin is not found, warning only..
            if (!isFoundBin) {
                log.warn("Specified CONTAINER_ID:{} does not contain Segments. "
                        + "To execute all Containers, just specify blank.", containerIdPara);
            }
        } catch (DefragmentServiceException ex) {
            log.error("DefragmentServiceException occurred..", ex);
        } catch (DefragmentDaoException ex) {
            log.error("DefragmentDaoException occurred..", ex);
        } catch (ConsoleException ex) {
            log.error("ConsoleException occurred..", ex);
        } catch (CommunicationException ex) {
            log.error("CommunicationException occurred..", ex);
        } catch (DefragmentUtilException ex) {
            log.error("DefragmentUtilException occurred..", ex);
        } catch (IllegalArgumentException ex) {
            log.error("IllegalArgumentException occurred..", ex);
        } catch (MultiBootException ex) {
            // MultiBoot operation is detected..
            log.error("MultiBoot operation is detected..", ex);
        } catch (Exception ex) {
            log.error("Unknown exception occurred..", ex);
        } finally {
            // commit and release the multiBoot connection
            if (mBootChecker != null) {
                mBootChecker.end();
            }
            // shutdown dataSource instance
            DataSourceCreator.getInstance().shutdownDataSource();
            if (log.isDebugEnabled()) {
                log.debug("end Entrance doDefragmentation..");
            }
            long endTime = System.currentTimeMillis();
            log.info("execute time {} ms..", (endTime - startTime));
            ConsoleUtil.newLine(LINE_NUMBER);
        }
    }

    /**
     * getExecuteMode
     * 
     * @param mode
     *            the mode of defragment
     */
    public ExecuteMode getExecuteMode(String mode) {
        ExecuteMode executeMode;

        if (mode.equalsIgnoreCase("defragment")) {
            executeMode = ExecuteMode.DEFRAGMENT;
        } else if (mode.equalsIgnoreCase("updateContainerId")) {
            executeMode = ExecuteMode.UPDATE_CONTAINERID;
        } else if (mode.equalsIgnoreCase("simulation")) {
            executeMode = ExecuteMode.SIMULATION;
        } else if (mode.equalsIgnoreCase("segDisplay")) {
            executeMode = ExecuteMode.SEG_DISPLAY;
        } else {
            throw new IllegalArgumentException("the Execute mode " + mode + " is not support..");
        }
        return executeMode;
    }

    /**
     * display the defragMent simulation result in the containerId
     * 
     * @param containerId
     *            the container id specified from containerId
     */
    public void simulation(Integer containerId) {
        if (log.isDebugEnabled()) {
            log.debug("start Entrance doDefragmentation..");
        }

        long startTime = System.currentTimeMillis();
        try {
            // first initialize service instance
            initializeSimuService();

            // display the simulation result
            simulationService.display(containerId);
        } catch (ConsoleException ex) {
            log.error("ConsoleException occurred..", ex);
        } catch (Exception ex) {
            log.error("Unknown exception occurred..", ex);
        } finally {
            log.info(BR);
            long endTime = System.currentTimeMillis();
            log.info("execute time {} ms..", (endTime - startTime));
        }
    }

    /**
     * display the segment detail in the containerId with the specified container id <br>
     * if the container id is not specified(is null), display all the segments
     * 
     * @param containerId
     */
    public void displaySegment(Integer containerId) {
        if (log.isDebugEnabled()) {
            log.debug("start defragment tool -> displaySegment..");
        }

        long startTime = System.currentTimeMillis();
        try {
            // first initialize service instance
            initializeSegService();

            // display the segment information in the containerId
            // include CONTAINER_ID FORMAT_NAME SEG_ID REGIST_RATIO
            // REGIST_SIZE/SEG_SIZE RECORD
            displaySegService.display(containerId);
        } catch (ConsoleException ex) {
            log.error("ConsoleException occurred..", ex);
        } catch (Exception ex) {
            log.error("Unknown exception occurred..", ex);
        } finally {
            log.info(BR);
            long endTime = System.currentTimeMillis();
            log.info("execute time {} ms..", (endTime - startTime));
        }
    }

    /**
     * initialize the segment display Service
     */
    private void initializeSegService() {
        if (log.isDebugEnabled()) {
            log.debug("start Entrance initializeService..");
        }
        this.displaySegService = ServiceFactory.createService(DisplaySegmentService.class);
        if (log.isDebugEnabled()) {
            log.debug("end Entrance initializeService.. ");
        }
    }

    /**
     * initialize Simulation Service
     */
    private void initializeSimuService() {
        if (log.isDebugEnabled()) {
            log.debug("start Entrance initializeService..");
        }
        this.simulationService = ServiceFactory.createService(SimulationService.class);
        if (log.isDebugEnabled()) {
            log.debug("end Entrance initializeService.. ");
        }
    }

    /**
     * initialize each Service
     */
    private void initializeService() {
        if (log.isDebugEnabled()) {
            log.debug("start Entrance initializeService..");
        }
        long startTime = System.currentTimeMillis();
        this.initService = ServiceFactory.createService(ContainerInitService.class);
        this.makePlanService = ServiceFactory.createService(MakePlanService.class);
        this.checker = ServiceFactory.createService(StatusCheckerService.class);
        this.mBootChecker = ServiceFactory.createService(MultiBootCheckerService.class);
        long endTime = System.currentTimeMillis();
        if (log.isDebugEnabled()) {
            log.debug("end Entrance initializeService.. execute time {} ms..",
                    (endTime - startTime));
        }
    }

}
