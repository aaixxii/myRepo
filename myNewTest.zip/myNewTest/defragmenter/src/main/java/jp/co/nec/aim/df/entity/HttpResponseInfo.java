package jp.co.nec.aim.df.entity;

/**
 * this class is the response information from MM
 */
public final class HttpResponseInfo {

	/**
	 * the constructor of HttpResponse
	 * 
	 * @param statusCode
	 * @param bodyMessage
	 */
	public HttpResponseInfo(int statusCode, String bodyMessage) {
		this.statusCode = statusCode;
		this.bodyMessage = bodyMessage;
	}

	/** status code (200, 400, 500) **/
	private int statusCode;
	/** response message include bindid or error message **/
	private String bodyMessage;

	public int getStatusCode() {
		return statusCode;
	}

	public String getBodyMessage() {
		return bodyMessage;
	}
}
