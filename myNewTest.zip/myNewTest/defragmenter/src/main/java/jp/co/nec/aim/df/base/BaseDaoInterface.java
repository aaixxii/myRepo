package jp.co.nec.aim.df.base;

import java.sql.Connection;
import java.util.List;

import javax.sql.DataSource;

/**
 * BaseDaoInterface
 * 
 */
public interface BaseDaoInterface {

	/**
	 * set the {@link DataSource} to dao instance
	 * 
	 * @param DataSource
	 *            database connection poll
	 */
	void setInitParams(DataSource dataSource);

	/**
	 * set the {@link Connection} to dao instance
	 * 
	 * @param connection
	 */
	void setInitParams(Connection connection);

	/**
	 * mapping object from resultSet to entity Class
	 * 
	 * @param clazz
	 *            entity Class
	 * @return entity Class
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	<T> T mapping(Class<T> clazz) throws InstantiationException,
			IllegalAccessException;

	/**
	 * mapping list from resultSet to entity Class
	 * 
	 * @param clazz
	 *            entity Class
	 * @return entity Class
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	<T> List<T> mappingList(Class<T> clazz) throws InstantiationException,
			IllegalAccessException;
}
