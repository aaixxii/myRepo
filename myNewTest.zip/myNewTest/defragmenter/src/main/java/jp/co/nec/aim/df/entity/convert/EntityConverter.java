package jp.co.nec.aim.df.entity.convert;

import static jp.co.nec.aim.df.constant.SystemConstant.SEGMENT_HEADER_LENGTH;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.df.entity.Segment;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.util.ProgressBar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this class is convert from the SegmentSummary entity to Segment <br>
 * 
 * 
 * @author liuyq
 * 
 */
public final class EntityConverter {

    /** log instance **/
    private static final Logger log = LoggerFactory.getLogger(EntityConverter.class);

    // ////////////////////////////////////////////////////////////////
    // ///////////////////////constant variable////////////////////////
    // ////////////////////////////////////////////////////////////////
    private static long CONVERT_UNIT_SIZE = 1024 * 1024;
    private static final String RADIO_FORMAT_TYPE = "%.2f/%.2f(MB)";
    private static final int BAR_LENGTH = 21;

    // ////////////////////////////////////////////////////////////////

    /**
     * convert form SegmentSummary list to Segment list
     * 
     * @param segSummarys
     * @param formatName
     * @return
     */
    public static List<Segment> convertSegments(final List<SegmentSummary> segSummarys,
            final String containerName) {
        List<Segment> segments = new ArrayList<Segment>();
        for (final SegmentSummary segSummary : segSummarys) {
            try {
                final String containerId = String.valueOf(segSummary.getContainerId());
                final String segmentId = String.valueOf(segSummary.getSegId());

                if (log.isDebugEnabled()) {
                    log.debug("ready to convert SegmentSummary to Segment with containerid: {}, segmentId:{}..");
                }

                double compactSize = (double) (segSummary.getBlCompacted() - SEGMENT_HEADER_LENGTH)
                        / CONVERT_UNIT_SIZE;
                double unCompactSize = (double) (segSummary.getBlunCompacted() - SEGMENT_HEADER_LENGTH)
                        / CONVERT_UNIT_SIZE;
                final String registSegSize = String.format(RADIO_FORMAT_TYPE, compactSize,
                        unCompactSize);

                final double rate = compactSize / unCompactSize;
                final String registRatio = ProgressBar.showBarByPoint(rate, BAR_LENGTH);

                final String recordCnt = String.valueOf(segSummary.getRecordCount());
                segments.add(new Segment(containerId, containerName, segmentId, registRatio, registSegSize,
                        recordCnt));

                if (log.isDebugEnabled()) {
                    log.debug("convert completed..");
                }
            } catch (Exception ex) {
                log.error("error occurred while convert the SegmentSummary to segment..", ex);
            }
        }
        return appendTail(segments);
    }

    /**
     * append following to the tail<br>
     * <code>
     * •  _________________________
       •  |           |           |
       •  0%         50%         100%
     * 
     * </code>
     * 
     * @param sb
     */
    private static List<Segment> appendTail(final List<Segment> segments) {
        final List<String> percents = ProgressBar.getMarkPercent(BAR_LENGTH);
        for (final String tail : percents) {
            segments.add(new Segment(tail));
        }
        return segments;
    }
}
