package jp.co.nec.aim.df.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.co.nec.aim.df.constant.FieldMapped;
import jp.co.nec.aim.df.constant.Header;
import jp.co.nec.aim.df.util.Util;

/**
 * ContainerSummary include the Container information and the segment <br>
 * that belong to this container.
 */
public final class ContainerSummary implements Serializable {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -8893634749675041314L;
    private static final String RADIO_FORMAT_TYPE = "%.0f%%";
    private static final String COMMA = ",";
    private static final int THREE = 3;
    private static final String NOTHING = "-";
    private static final String EMPTY = "";

    public ContainerSummary() {
    }

    public ContainerSummary(int containerId, int scope, String formatName, int SegmentNumber,
            double fragmentRadio) {
        this.containerId = containerId;
        this.scope = scope;
        this.formatName = formatName;
        this.SegmentNumber = SegmentNumber;
        this.fragmentRadioDouble = fragmentRadio;
        this.fragmentRadio = String.format(RADIO_FORMAT_TYPE, fragmentRadio * 100);
        this.segmentList = new ArrayList<SegmentSummary>();
    }

    @Header(length = 16, headerName = "Container Id")
    @FieldMapped
    private Integer containerId;

    @FieldMapped
    private String containerName;

    @Header(length = 10, headerName = "scope")
    @FieldMapped
    private Integer scope;

    @Header(length = 16, headerName = "Format Name")
    @FieldMapped
    private String formatName;

    @Header(length = 18, headerName = "Segment Number")
    @FieldMapped
    private Integer SegmentNumber;

    private Double fragmentRadioDouble;

    @Header(length = 20, headerName = "Fragment Radio")
    private String fragmentRadio;

    @Header(length = 30, headerName = "Worst Three Segment")
    private String worstThreeSegment;

    private ArrayList<SegmentSummary> segmentList;


    @FieldMapped
    private Integer maxSegmentSize;

    public Integer getMaxSegmentSize() {
        return maxSegmentSize;
    }

    public void setMaxSegmetSize(Integer maxSegmentSize) {
        this.maxSegmentSize = maxSegmentSize;
    }

    // ////////////////////////////////////////////////////////////
    // /////////////////// DM download related/////////////////////
    // ///////////////////////////////////////////////////////////
    private int maxSegmentDiffs;

    public int getMaxSegmentDiffs() {
        return maxSegmentDiffs;
    }

    public void setMaxSegmentDiffs(int maxSegmentDiffs) {
        this.maxSegmentDiffs = maxSegmentDiffs;
    }

    /**
     * set worst three segment information
     */
    @SuppressWarnings("unchecked")
    public final void setSegmentParameter() {
        List<SegmentSummary> segments = (ArrayList<SegmentSummary>) (this.segmentList).clone();
        segments.remove(segments.size() - 1);
        Collections.sort(segments, new Comparator<SegmentSummary>() {
            public int compare(SegmentSummary o1, SegmentSummary o2) {
                if (Util.isObjectNull(o1.getFragmentRadio())
                        || Util.isObjectNull(o2.getFragmentRadio())) {
                    return 0;
                }

                final double compare = o1.getFragmentRadio() - o2.getFragmentRadio();
                if (compare > 0) {
                    return -1;
                } else if (compare == 0) {
                    return 0;
                } else {
                    return 1;
                }
            }
        });

        final StringBuilder sb = new StringBuilder();
        final int tsize = segments.size();
        final int size = tsize > THREE ? THREE : tsize;
        double total = 0.0;
        int totalCount = 0;

        for (int index = 0; index < size; index++) {
            final SegmentSummary segment = segments.get(index);
            final Long segmentId = segment.getSegId();
            final Double radio = segment.getFragmentRadio();

            // set Segment Average Radio
            total += segment.getFragmentRadio();
            totalCount++;

            sb.append(String.format("[%s](%2$.0f%%)", segmentId, (radio == null ? 0 : radio * 100)));
            if (index != size - 1) {
                sb.append(COMMA);
            }
        }

        // set fragmentRadioDouble and fragmentRadio attribute
        final boolean isSegmentEmpty = segments.isEmpty();
        this.fragmentRadioDouble = isSegmentEmpty ? 0.0d : (total / totalCount);
        this.fragmentRadio = isSegmentEmpty ? NOTHING : String.format("%.0f%%",
                (total / totalCount) * 100);
        this.worstThreeSegment = (sb.toString().equals(EMPTY) ? NOTHING : sb.toString());
    }

    /**
     * getTotalFragRadio
     * 
     * @return add each segment defragment radio in container
     */
    public double getTotalFragRadio() {
        double totalRadio = 0d;
        for (SegmentSummary segment : segmentList) {
            totalRadio += segment.getFragmentRadio();
        }
        return totalRadio;
    }

    public long getMaxSegmentId() {
        long maxSegmentId = 0l;
        for (SegmentSummary segment : segmentList) {
            maxSegmentId = segment.getSegId() > maxSegmentId ? segment.getSegId() : maxSegmentId;
        }
        return maxSegmentId;
    }

    public Integer getContainerId() {
        return containerId;
    }

    public void setContainerId(Integer containerId) {
        this.containerId = containerId;
    }

    public String getFormatName() {
        return formatName;
    }

    public void setFormatName(String formatName) {
        this.formatName = formatName;
    }

    public Integer getSegmentNumber() {
        return SegmentNumber;
    }

    public void setSegmentNumber(Integer segmentNumber) {
        SegmentNumber = segmentNumber;
    }

    public Double getFragmentRadio() {
        return fragmentRadioDouble;
    }

    public void setFragmentRadio(Double fragmentRadio) {
        this.fragmentRadioDouble = fragmentRadio;
        this.fragmentRadio = String.format("%.0f%%", fragmentRadio * 100);
    }

    public List<SegmentSummary> getSegmentSummary() {
        return segmentList;
    }

    /**
     * addSegmentList
     * 
     * @param segmentList
     */
    public void addSegmentList(List<SegmentSummary> segmentList) {
        if (this.segmentList == null) {
            this.segmentList = new ArrayList<SegmentSummary>();
        }
        this.segmentList.clear();
        this.segmentList.addAll(segmentList);
    }

    public void setScope(Integer scope) {
        this.scope = scope;
    }

    public Integer getScope() {
        return scope;
    }

    // /////////////////////////////////////////////////////////////////////
    // //////the following is for defragMent display tool //////////////////
    // /////////////////////////////////////////////////////////////////////
    public String getContainerName() {
        return this.containerName;
    }

    public long getTotalBinarySize() {
        long binarySize = 0L;
        if (this.segmentList != null) {
            for (final SegmentSummary segment : segmentList) {
                binarySize += segment.getBlunCompacted();
            }
        }
        return binarySize;
    }

}
