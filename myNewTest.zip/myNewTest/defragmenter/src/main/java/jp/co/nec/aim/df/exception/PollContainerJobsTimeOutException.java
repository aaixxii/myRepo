package jp.co.nec.aim.df.exception;

public class PollContainerJobsTimeOutException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1287506188023072691L;

	/**
	 * ConsoleException
	 * 
	 * @param message
	 * @param cause
	 */
	public PollContainerJobsTimeOutException(String message) {
		super(message);
	}
}
