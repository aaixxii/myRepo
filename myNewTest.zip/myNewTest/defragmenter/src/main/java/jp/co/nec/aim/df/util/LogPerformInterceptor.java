package jp.co.nec.aim.df.util;

import java.lang.reflect.Method;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this Method interceptor class is used for output the log and execute time for
 * service and dao method
 */
public class LogPerformInterceptor implements MethodInterceptor {

	/**
	 * intercept the service and dAO class method
	 */
	@Override
	public Object intercept(Object obj, Method method, Object[] args,
			MethodProxy proxy) throws Throwable {
		Logger log = LoggerFactory.getLogger(obj.getClass().getSuperclass());
		long startTime = System.currentTimeMillis();
		if (log.isDebugEnabled()) {
			log.debug(" [ start ] " + method);
		}
		Object result = proxy.invokeSuper(obj, args);
		long endTime = System.currentTimeMillis();
		String strtimediff = String.format(". execute time {%d} ms..",
				(endTime - startTime));
		if (log.isDebugEnabled()) {
			log.debug(" [  end  ] " + method + strtimediff);
		}
		return result;
	}
}
