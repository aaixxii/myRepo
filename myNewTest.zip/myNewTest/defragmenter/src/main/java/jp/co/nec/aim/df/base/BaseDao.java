package jp.co.nec.aim.df.base;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.df.constant.FieldMapped;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import static jp.co.nec.aim.df.constant.SystemConstant.FORMAT;

/**
 * This class supply the basic function of dAo <br>
 * get Statement, execute sql and database operation related.<br>
 */
public abstract class BaseDao implements BaseDaoInterface {

	/** DB Connection **/
	protected ThreadLocal<Connection> conThreadLocal;

	/** connection poll **/
	protected DataSource dataSource;

	private Connection con;

	/** PreparedStatement **/
	protected PreparedStatement ps;

	/** ResultSet **/
	protected ResultSet rs;

	/** update count **/
	protected int cnt;

	/** parameter index **/
	protected int index = 1;

	/** constructor **/
	protected BaseDao() {
	}

	@Override
	public void setInitParams(DataSource dataSource) {
		this.dataSource = dataSource;
		this.conThreadLocal = new ThreadLocal<Connection>();
	}

	@Override
	public void setInitParams(Connection connection) {
		this.con = connection;
	}

	/**
	 * mapping the result from the database <br>
	 * and set to entity class
	 * 
	 * @param clazz
	 *            mapped class
	 * @return T the data
	 */
	public <T> T mapping(Class<T> clazz) throws DefragmentDaoException {
		T t = null;
		try {
			t = clazz.newInstance();
			final Field[] fields = clazz.getDeclaredFields();

			for (final Field field : fields) {
				field.setAccessible(true);
				FieldMapped fieldMapped = field
						.getAnnotation(FieldMapped.class);
				if (fieldMapped == null) {
					continue;
				}

				final Class<?> typeClazz = field.getType();
				Object object = null;

				if (typeClazz == String.class) {
					object = getString(field.getName());
				} else if (typeClazz == Long.class) {
					object = getLong(field.getName());
				} else if (typeClazz == Integer.class) {
					object = getInt(field.getName());
				} else if (typeClazz == Double.class) {
					object = Double.valueOf(FORMAT.format(getDouble(field
							.getName())));
				} else {
					throw new DefragmentServiceException("the type "
							+ typeClazz.getSimpleName()
							+ " is not support for mapping..");
				}

				field.set(t, object);
			}
		} catch (InstantiationException e) {
			throw new DefragmentDaoException(e);
		} catch (IllegalAccessException e) {
			throw new DefragmentDaoException(e);
		}
		return t;
	}

	/**
	 * mappingList
	 */
	public <T> List<T> mappingList(Class<T> clazz) {
		List<T> objlist = new ArrayList<T>();
		while (next()) {
			objlist.add(mapping(clazz));
		}
		return objlist;
	}

	/**
	 * release ResultSet <br>
	 * 
	 * @throws DefragmentDaoException
	 */
	protected void releaseResultSet() throws DefragmentDaoException {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * get PreparedStatement <br>
	 * 
	 * @param sql
	 *            sql
	 * @throws DefragmentDaoException
	 */
	protected void prepareStatement(String sql) throws DefragmentDaoException {
		try {
			cnt = 0;
			index = 1;
			Connection con = dataSource.getConnection();
			conThreadLocal.set(con);
			ps = con.prepareStatement(sql);
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * get PreparedStatement <br>
	 * 
	 * @param sql
	 *            sql
	 * @throws DefragmentDaoException
	 */
	protected void prepareStatementCon(String sql)
			throws DefragmentDaoException {
		try {
			cnt = 0;
			index = 1;
			ps = con.prepareStatement(sql);
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * release PreparedStatement<br>
	 * 
	 * @throws DefragmentDaoException
	 */
	protected void releasePreparedStatement() throws DefragmentDaoException {
		try {
			if (ps != null) {
				ps.close();
			}
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * releaseConnectionToPoll
	 * 
	 * @throws DefragmentDaoException
	 */
	protected void releaseConnectionToPoll() throws DefragmentDaoException {
		try {
			Connection connection = conThreadLocal.get();
			if (connection != null) {
				connection.close();
			}
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * set String parameter (String)<br>
	 * 
	 * @param index
	 *            the index order
	 * @param param
	 *            parameter
	 * @param ps
	 *            Prepared Statement instance
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected void setParam(int index, String param)
			throws DefragmentDaoException {
		try {
			ps.setString(index, param);
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * set integer parameter (integer)<br>
	 * 
	 * @param index
	 *            the index order
	 * @param param
	 *            parameter
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected void setParam(int index, int param) throws DefragmentDaoException {
		try {
			if (ps != null) {
				ps.setInt(index, param);
			}
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * set long parameter (long)<br>
	 * 
	 * @param index
	 *            the index order
	 * @param param
	 *            parameter
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected void setParam(int index, long param)
			throws DefragmentDaoException {
		try {
			if (ps != null) {
				ps.setLong(index, param);
			}
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * get the String value from the specified column label name
	 * 
	 * @param columnLabel
	 *            column label name
	 * @return the String value
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected String getString(String columnLabel)
			throws DefragmentDaoException {
		try {
			return rs.getString(columnLabel);
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * get the integer value from the specified column label name
	 * 
	 * @param columnLabel
	 *            column label name
	 * @return the integer value
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected int getInt(String columnLabel) throws DefragmentDaoException {
		try {
			return rs.getInt(columnLabel);
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * get the Object value from the specified column label name
	 * 
	 * @param columnLabel
	 *            column label name
	 * @return the Object value
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected Object getObject(String columnLabel)
			throws DefragmentDaoException {
		try {
			return rs.getObject(columnLabel);
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * get the long value from the specified column label name
	 * 
	 * @param columnLabel
	 *            column label name
	 * @return the long value
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected long getLong(String columnLabel) throws DefragmentDaoException {
		try {
			return rs.getLong(columnLabel);
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * get the double value from the specified column label name
	 * 
	 * @param columnLabel
	 *            column label name
	 * @return the double value
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected double getDouble(String columnLabel)
			throws DefragmentDaoException {
		try {

			return rs.getDouble(columnLabel);
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * ResultSet move to next result
	 * 
	 * @return if has record return true otherwise return false
	 * @throws DefragmentDaoException
	 *             if sqlException occurred
	 */
	protected boolean next() throws DefragmentDaoException {
		try {
			return rs.next();
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * get result from result set
	 * 
	 * @return the count result
	 */
	protected int getResultCount() {
		try {
			int count = 0;
			if (next()) {
				count = rs.getInt(1);
			}
			return count;
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * execute Query sQL
	 * 
	 * @throws DefragmentDaoException
	 */
	protected void executeQuery() throws DefragmentDaoException {
		try {
			if (ps != null) {
				rs = ps.executeQuery();
			}
		} catch (SQLException e) {
			throw new DefragmentDaoException(e);
		}
	}

	/**
	 * execute Update sQL
	 * 
	 * @throws DefragmentDaoException
	 */
	protected void executeUpdate() throws DefragmentDaoException {
		if (ps != null) {
			try {
				cnt = ps.executeUpdate();
			} catch (SQLException e) {
				throw new DefragmentDaoException(e);
			}
		}
	}
}
