package jp.co.nec.aim.df.entity;

import java.io.Serializable;

import jp.co.nec.aim.df.constant.Header;

/**
 * 
 * @author liuyq
 * 
 */
public final class Segment implements Serializable {

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 186588165272208021L;
    private static final String EMPTY = "";

    @Header(length = 16, headerName = "CONTAINER_ID")
    private String containerId;

    @Header(length = 22, headerName = "CONTAINER_NAME")
    private String formatName;

    @Header(length = 10, headerName = "SEG_ID")
    private String segmentId;

    @Header(length = 50, headerName = "REGIST_RATIO")
    private String registRatio;

    @Header(length = 30, headerName = "REGIST_SIZE/SEG_SIZE")
    private String registSegSize;

    @Header(length = 10, headerName = "RECORD")
    private String record;

    public Segment() {
    }

    public Segment(final String containerId, final String formatName, final String segmentId,
            final String registRatio, final String registSegSize, final String record) {
        this.containerId = containerId;
        this.formatName = formatName;
        this.segmentId = segmentId;
        this.registRatio = registRatio;
        this.registSegSize = registSegSize;
        this.record = record;
    }

    public Segment(final String registRatio) {
        this.containerId = EMPTY;
        this.formatName = EMPTY;
        this.segmentId = EMPTY;
        this.registRatio = registRatio;
        this.registSegSize = EMPTY;
        this.record = EMPTY;
    }

    public String getContainerId() {
        return containerId;
    }

    public void setContainerId(String containerId) {
        this.containerId = containerId;
    }

    public String getFormatName() {
        return formatName;
    }

    public void setFormatName(String formatName) {
        this.formatName = formatName;
    }

    public String getSegmentId() {
        return segmentId;
    }

    public void setSegmentId(String segmentId) {
        this.segmentId = segmentId;
    }

    public String getRegistRatio() {
        return registRatio;
    }

    public void setRegistRatio(String registRatio) {
        this.registRatio = registRatio;
    }

    public String getRegistSegSize() {
        return registSegSize;
    }

    public void setRegistSegSize(String registSegSize) {
        this.registSegSize = registSegSize;
    }

    public String getRecord() {
        return record;
    }

    public void setRecord(String record) {
        this.record = record;
    }
}
