package jp.co.nec.aim.df.base;

import java.sql.Connection;

public abstract class BaseService implements BaseServiceInterface {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -66095794247586612L;

	/** the service connection **/
	protected Connection con;

	/**
	 * get the service Connection
	 * 
	 * @return the service connection
	 */
	public Connection getConnection() {
		return this.con;
	}

	/**
	 * the abstract class constructor
	 */
	public BaseService() {
		initialize();
	}
}
