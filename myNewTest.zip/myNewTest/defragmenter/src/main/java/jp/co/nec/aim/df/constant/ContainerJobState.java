package jp.co.nec.aim.df.constant;

/**
 * JobState is the enum that represents the different states that entries in
 * both the 'JobQueue' and 'GridQueue' tables can be in.
 */
public enum ContainerJobState {
	QUEUED, WORKING, DONE, ERROR;
}
