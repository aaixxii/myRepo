package jp.co.nec.aim.df.util;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * the connection utility <br>
 * include function of commit, rollBack, close and so on
 */
public final class ConnectionUtil {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(ConnectionUtil.class);

	/**
	 * commit the connection
	 * 
	 * @param con
	 *            connection
	 */
	public static final void commit(Connection con) {
		if (log.isDebugEnabled()) {
			log.debug("start ConnectionUtil commit..");
		}
		try {
			if (con != null)
				con.commit();
		} catch (SQLException e) {
			log.error("commit the connection error..", e);
		}
		if (log.isDebugEnabled()) {
			log.debug("end ConnectionUtil commit..");
		}
	}

	/**
	 * rollBack the connection
	 * 
	 * @param con
	 *            connection
	 */
	public static final void rollBack(Connection con) {
		if (log.isDebugEnabled()) {
			log.debug("start ConnectionUtil rollBack..");
		}
		try {
			if (con != null)
				con.rollback();
		} catch (SQLException e) {
			log.error("rollback the connection error..", e);
		}
		if (log.isDebugEnabled()) {
			log.debug("end ConnectionUtil rollBack..");
		}
	}

	/**
	 * close the connection
	 * 
	 * @param con
	 *            connection
	 */
	public static final void close(Connection con) {
		if (log.isDebugEnabled()) {
			log.debug("start ConnectionUtil close..");
		}
		try {
			if (con != null && !con.isClosed())
				con.close();
		} catch (SQLException e) {
			log.error("close the connection error..", e);
		}
		if (log.isDebugEnabled()) {
			log.debug("end ConnectionUtil close..");
		}
	}

	/**
	 * close the InputStream connection
	 * 
	 * @param InputStream
	 *            InputStream instance
	 */
	public static final void close(InputStream is) {
		if (log.isDebugEnabled()) {
			log.debug("start ConnectionUtil close InputStream..");
		}

		try {
			if (is != null) {
				is.close();
			}
		} catch (Exception e) {
			log.error("close the InputStream error..", e);
		}

		if (log.isDebugEnabled()) {
			log.debug("end ConnectionUtil close InputStream..");
		}
	}

	/**
	 * close the httpClient connection
	 * 
	 * @param HttpClient
	 *            httpClient instance
	 */
	public static final void close(HttpClient httpClient) {
		if (log.isDebugEnabled()) {
			log.debug("start ConnectionUtil close httpClient..");
		}
		try {
			if (httpClient != null)
				httpClient.getConnectionManager().shutdown();
		} catch (Exception e) {
			log.error("release client connection error..", e);
		}
		if (log.isDebugEnabled()) {
			log.debug("end ConnectionUtil close httpClient..");
		}
	}

	/**
	 * close the HttpPost connection
	 * 
	 * @param HttpPost
	 *            httpPost instance
	 */
	public static final void close(HttpPost httpPost) {
		if (log.isDebugEnabled()) {
			log.debug("start ConnectionUtil close httpClient..");
		}

		try {
			if (httpPost != null)
				httpPost.abort();
		} catch (Exception e) {
			log.error("release post connection error..", e);
		}

		if (log.isDebugEnabled()) {
			log.debug("end ConnectionUtil close httpClient..");
		}
	}

}
