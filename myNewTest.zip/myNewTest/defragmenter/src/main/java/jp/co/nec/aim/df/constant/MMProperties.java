package jp.co.nec.aim.df.constant;

/**
 * @type Enum
 * @function MM.properties
 * 
 */
public enum MMProperties {
	MM_IP("MM.IP"), MM_PORT("MM.PORT"), MM_ADDS("MM.ADDS"), MM_CARE("MM.CARE");

	/**
	 * MM.properties property
	 */
	private String property;

	private MMProperties(String property) {
		this.property = property;
	}

	public String getProperty() {
		return property;
	}
}
