package jp.co.nec.aim.df.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Generate the Progress Bar string <br>
 * only tow parameter is necessary <br>
 * 1. the main rate <br>
 * 2. the Progress bar will be displayed in containerId <br>
 * 
 * @author liuyq
 * 
 */
public final class ProgressBar {

    // ////////////////////////////////////////////////////////////////
    // ///////////////////////constant variable////////////////////////
    // ////////////////////////////////////////////////////////////////
    private static final String FORMAT = " %.2f%%";
    private static final String LEFT_BRACKET = "[";
    private static final String RIGHT_BRACKET = "]";
    private static final String MARK = "#";
    private static final String BLANK = " ";
    private static final String UNDER_LINE = "_";
    private static final String SPLIT = "|";
    private static final String RADIO_FORMAT_TYPE = "%.0f%%";

    // ////////////////////////////////////////////////////////////////

    /**
     * Generate the Progress Bar string
     * 
     * @param rate
     *            the rate will be applied in the bar
     * @param barLength
     *            the length of the bar
     * @return Progress Bar string
     */
    public static String showBarByPoint(double rate, int barLength) {
        int barSign = (int) (rate * barLength);
        return makeBarBySignAndLength(barSign, barLength) + String.format(FORMAT, rate * 100);
    }

    /**
     * append the bar string with specified parameter
     * 
     * @param barSign
     *            fixed bar length
     * @param barLength
     *            the length of the bar
     * @return
     */
    private static String makeBarBySignAndLength(int barSign, int barLength) {
        StringBuilder bar = new StringBuilder();
        bar.append(LEFT_BRACKET);
        for (int i = 1; i <= barLength; i++) {
            if (i <= barSign) {
                bar.append(MARK);
            } else {
                bar.append(BLANK);
            }
        }
        bar.append(RIGHT_BRACKET);
        return bar.toString();
    }

    /**
     * Mark Percent like following <br>
     * <code>
     •                     _________________________
     •                     |           |           |
     •                     0%         50%         100%
     * </code>
     * 
     * @param barLength
     * @return
     */
    public static List<String> getMarkPercent(final int barLength) {
        final List<String> markers = new ArrayList<String>();
        final StringBuffer tail1 = new StringBuffer();
        final StringBuffer tail2 = new StringBuffer();
        final StringBuffer tail3 = new StringBuffer();

        tail1.append(BLANK);
        tail2.append(BLANK);
        tail3.append(BLANK);

        int barSign = (barLength >> 1) + 1;
        double percent = 0.0d;

        for (int i = 1; i <= barLength; i++) {
            tail1.append(UNDER_LINE);
            if (i == 1 || i == barSign || i == barLength) {
                tail2.append(SPLIT);
            } else {
                tail2.append(BLANK);
            }

            if (i == 1 || i == barSign - 2 || i == barLength - 4) {
                tail3.append(String.format(RADIO_FORMAT_TYPE, percent));
                percent += 50d;
            } else {
                tail3.append(BLANK);
            }

        }
        markers.add(tail1.toString());
        markers.add(tail2.toString());
        markers.add(tail3.toString());
        return markers;
    }

    /**
     * only for test
     * 
     * @param args
     */
    public static void main(String[] args) {
        final String bar = showBarByPoint(0.751d, 40);
        System.out.println(bar);

        final List<String> markers = getMarkPercent(40);

        for (String marker : markers) {
            System.out.println(marker);
        }
    }

}
