package jp.co.nec.aim.df.service;

import static jp.co.nec.aim.df.constant.SystemConstant.FORMAT;
import static jp.co.nec.aim.df.constant.SystemConstant.SEGMENT_HEADER_LENGTH;

import java.sql.Connection;
import java.util.List;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.dao.MergerSegmentDao;
import jp.co.nec.aim.df.entity.RangeSegment;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.exception.DefragmentServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * according to plans, we will merger the segments with <br>
 * the number of joint, the key is find the the range of <br>
 * segment after the merger
 */
public class MergerSegmentService extends BaseService {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6826670863138259166L;

	/** the MergerSegmentDao dAO instance **/
	private MergerSegmentDao dao;

	/** the multiplier of version **/
	private static final int MULTIPLIER = 2;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(MergerSegmentService.class);

	@Override
	public void initialize() {
	}

	public MergerSegmentService() {
	}

	/**
	 * the MergerSegmentService with parameter connection
	 * 
	 * @param con
	 *            connection
	 */
	public MergerSegmentService(Connection con) {
		this.con = con;
		this.dao = DaoFactory.createDao(MergerSegmentDao.class, this.con);
	}

	/**
	 * this function will merger the segment according to plans
	 * 
	 * @param plans
	 * @return the merged Segment information that <br>
	 *         will update into database
	 */
	public Boolean mergerSegmentPlan(final Plan plan) {
		if (plan == null) {
			throw new IllegalArgumentException("the parameter plan is null"
					+ " while mergerSegmentPlan..");
		}

		final List<SegmentSummary> segments = plan.getWillMergerSegs();
		if (segments.isEmpty()) {
			throw new DefragmentServiceException("the number of segment "
					+ "will be merger is empty..");
		}

		// the flag means is necessary to persist the segment
		// into database..
		boolean isNecessaryPersist = true;

		// get maxSegmentSize, containerId, segmentIds, firstSegment
		// ignorHeaderSize, versionAdded from the instance Plan
		final int maxSegmentSize = plan.getMaxSegmentSize();
		final int containerId = plan.getContainerId();
		final String segmentIds = plan.getSegIdsSplitByComma();
		final SegmentSummary firstSegment = plan.getFirstSegment();
		final int ignorHeaderSize = maxSegmentSize - SEGMENT_HEADER_LENGTH;
		final int versionAdded = plan.getMaxSegmentDiffs() * MULTIPLIER;

		// if the plan merger result is 1
		// do one result operation and return
		if (plan.isRemainDataNotHigherOne()) {
			return doOneSegResultOperation(plan, versionAdded, maxSegmentSize);
		}

		// otherwise will loop the each segment to fill the length blank
		final int segmentSize = segments.size();
		Long startPerId = firstSegment.getStartId();

		// loop the segment in plans
		for (int i = 0; i < segmentSize; i++) {
			final SegmentSummary segment = segments.get(i);

			// this dAO function will apply for new space for next segment
			// until satisfy the space
			// apply for next segment
			// 1. the range id
			// 2. the binary length of apply space
			// 3. the number of the apply record count
			final RangeSegment rangeInfo = dao.getPersonRangeInfo(containerId,
					segmentIds, ignorHeaderSize, startPerId);
			if (rangeInfo == null) {
				if (log.isDebugEnabled()) {
					log.debug("can not find the range information,"
							+ " ignorHeaderSize: {}, containerid: {},"
							+ " segmentIds: {}", ignorHeaderSize, containerId,
							segmentIds);
				}
				isNecessaryPersist = setNextSegmentsToDelete(segments, i);
				break;
			}

			// append the segments and find the next person id
			startPerId = appendSegment(rangeInfo, segment, maxSegmentSize,
					versionAdded, segmentIds, startPerId);

			// can not find next person id in specified segment id
			if (startPerId == null) {
				isNecessaryPersist = setNextSegmentsToDelete(segments, i + 1);
				break;
			}
		}

		return isNecessaryPersist;
	}

	/**
	 * set the Next Segments began from beginIndex To Delete
	 * 
	 * @param segments
	 *            the SegmentSummary
	 * @param beginIndex
	 *            delete from
	 * 
	 * @return boolean is necessary to persist, the system is output the
	 *         plan,but in actual there is nothing to merger the segment due to
	 *         the plan has deviation.
	 */
	private boolean setNextSegmentsToDelete(
			final List<SegmentSummary> segments, final int beginIndex) {
		final int size = segments.size();
		if (beginIndex >= size) {
			log.warn("the beginIndex is bigger than the segment size while set the Next"
					+ " Segments To Delete..");
			return false;
		}

		for (int i = beginIndex; i < size; i++) {
			final SegmentSummary segment = segments.get(i);
			if (log.isDebugEnabled()) {
				log.debug("mark the delete flag to segment id: {}.. ",
						segment.getSegId());
			}
			segment.setWillbeDeleted(true);
		}
		return true;
	}

	/**
	 * append the multip-Segment to one segment
	 * 
	 * @param rangeInfo
	 * @param segment
	 * @param maxSegmentSize
	 * @return the start id
	 */
	private final Long appendSegment(final RangeSegment rangeInfo,
			final SegmentSummary segment, final int maxSegmentSize,
			final int versionAdded, final String segmentIds, final Long startId) {
		// the rangeId is the range that divide into the segment
		final long rangeId = rangeInfo.getRangeId();
		// the total length of binary within the range id
		final long totalLength = rangeInfo.getTotalLength();
		// the record count within the range id
		final long recordCount = rangeInfo.getRecordCount();

		// get the next person id within the range of segment
		Long nextStartId = dao.getNextId(segment.getContainerId(), rangeId,
				segmentIds);

		// set the start person id
		segment.setStartId(startId);
		// set the range id to end person id
		segment.setEndId(rangeId);
		// add the segment header size is necessary
		segment.setBlCompacted(totalLength + SEGMENT_HEADER_LENGTH);
		// the uncompact length is the same as compact length
		segment.setBlunCompacted(totalLength + SEGMENT_HEADER_LENGTH);

		// set record count
		segment.setRecordCount(recordCount);

		// version and reVersion plus versionAdded
		// versionAdded = 2 * max_segment_diff
		segment.increaseVersion(versionAdded);
		segment.increaseReVersion(versionAdded);

		// this segment will persist to database
		segment.setWillbeDeleted(false);

		// set the DataRadio and FragmentRadio
		final double binaryLength = segment.getBlCompacted();

		// set data radio and defragment radio
		setRadio(segment, binaryLength, maxSegmentSize);

		// return the next id
		return nextStartId;
	}

	/**
	 * if all segments will merger to one <br>
	 * whatever the number of joint <br>
	 * set first segment<br>
	 * start id -> no change <br>
	 * end if -> the last segment end id <br>
	 * version +1 <br>
	 * reVersion + 1 <br>
	 * binary_length_compacted and binary_length_uncompacted -> <br>
	 * sum(each segment BINARY_LENGTH_COMPACTED) - sum(each segment header) <br>
	 * remove the segment header length is necessary.. <br>
	 * 
	 * @param plan
	 * @return boolean is necessary for persist the segment base on plan
	 */
	private final boolean doOneSegResultOperation(final Plan plan,
			final int versionAdded, final int maxSegmentSize) {
		// first check the mergered segments total binary size
		// is great than max segment size
		// if false -> the plan has deviation
		final long length = plan.getOneResultActualSegmentL();
		if (length > maxSegmentSize) {
			log.warn("the mergered segments({}) total binary size: {} is "
					+ "over max segment size: {} due to the plan has deviation"
					+ " while do one result segment merger operation..",
					plan.getSegIdsSplitByComma(), length, maxSegmentSize);
			return false;
		}

		// get first segment and set each field
		final SegmentSummary first = plan.getFirstSegment();
		first.setContainerId(plan.getContainerId());
		first.setSegId(plan.getFirstSegId());
		first.setStartId(plan.getFirstSegmentStartId());
		first.setEndId(plan.getLastSegmentEndId());
		first.setRecordCount(plan.getRecordCount());

		// set the version and reVersion, default is (2 * 1000)
		first.increaseVersion(versionAdded);
		first.increaseReVersion(versionAdded);

		first.setBlCompacted(length);
		first.setBlunCompacted(length);
		first.setWillbeDeleted(false);

		// set data radio and defragment radio
		setRadio(first, length, maxSegmentSize);

		// the other segment will be deleted
		plan.setOtherSegmentToDelete();

		// return the merged segments
		return true;
	}

	/**
	 * set the Data Radio and Fragment Radio
	 * 
	 * @param segment
	 *            the segment instance
	 * @param binaryLength
	 *            the merger segment actual compact size
	 * @param maxSegmentSize
	 *            max segment size
	 */
	private final void setRadio(final SegmentSummary segment,
			final double binaryLength, final int maxSegmentSize) {
		segment.setDataRadio(Double.valueOf(FORMAT.format(binaryLength
				/ maxSegmentSize)));
		segment.setFragmentRadio(Double.valueOf(FORMAT.format(1 - segment
				.getDataRadio())));
	}
}
