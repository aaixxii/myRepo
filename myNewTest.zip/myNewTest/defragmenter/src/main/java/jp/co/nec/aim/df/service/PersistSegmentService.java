package jp.co.nec.aim.df.service;

import java.sql.Connection;
import java.util.List;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.dao.PersistSegmentDao;
import jp.co.nec.aim.df.entity.SegmentSummary;
import jp.co.nec.aim.df.exception.DefragmentServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * after communicate with the MM successfully, <br>
 * Persist the merged segment to database
 */
public class PersistSegmentService extends BaseService {

    /** log instance **/
    private static final Logger log = LoggerFactory
            .getLogger(PersistSegmentService.class);

    /** serialVersionUID */
    private static final long serialVersionUID = -1309867554695917610L;

    /** PersistSegmentDao instance **/
    private PersistSegmentDao dao;

    @Override
    public void initialize() {
    }

    public PersistSegmentService() {
    }

    /**
     * PersistSegmentService constructor with Connection
     * 
     * @param con
     *            the connection
     */
    public PersistSegmentService(Connection con) {
        this.con = con;
        this.dao = DaoFactory.createDao(PersistSegmentDao.class, this.con);
    }

    /**
     * persistSegment
     * 
     * @param segments
     *            segments that was merged
     */
    public void persistSegment(final Plan plan) {
        if (plan == null) {
            throw new NullPointerException(
                    "the parameter plan is null while persistSegment..");
        }

        // get segments from the plan
        final List<SegmentSummary> segments = plan.getWillMergerSegs();
        if (segments.isEmpty()) {
            throw new DefragmentServiceException("the plans is empty "
                    + "while persistSegment to database..");
        }

        if (log.isDebugEnabled()) {
            log.debug("all the condition is done, "
                    + "begin to persist segment to database..");
        }

        try {
            // loop the segments
            // do update or delete operation base on condition
            for (final SegmentSummary segment : segments) {
                if (segment.willbeDeleted()) {
                    if (log.isDebugEnabled()) {
                        log.debug("ready to delete the segment "
                                + "with segment id: {}", segment.getSegId());
                    }
//                    // first delete the MU_JOB_FAILURE_REASONS related to specified segment
//                    // otherwise, if delete the segment record directly, we will
//                    // got an exception as following..
//                    // ORA-02292: integrity constraint
//                    // (AIMUSER.MU_JOBS_FK2)
//                    // violated - child record found
//                    dao.deleteMuJobs(segment);

                    // second delete the segment record
                    dao.deleteSegment(segment);
                } else {
                    if (log.isDebugEnabled()) {
                        log.debug("ready to update the segment "
                                + "with segment id: {}", segment.getSegId());
                    }
                    dao.updateSegment(segment);
                }
            }
        } catch (Exception ex) {
            String message = "persist Segment to database exception occurred..";
            log.error(message, ex);
            throw new DefragmentServiceException(message, ex);
        }
    }
}
