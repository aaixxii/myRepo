package jp.co.nec.aim.df.service;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.core.Defragment;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.exception.DefragmentServiceException;

/**
 * MakePlanService <br>
 * draw up the segment defragment plan within the container. <br>
 * and return the plan of segment defragment
 */
public class MakePlanService extends BaseService {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 8903184319597579865L;

	public MakePlanService() {
	}

	@Override
	public void initialize() {
	}

	/**
	 * draw up the segment defragment plan within the container. <br>
	 * 1. fragmentation Analysis, get all plan begin from 2 to 5 (default) <br>
	 * 2. get the best joint number and remove the other joint number plan <br>
	 * then return the best joint number plan
	 * 
	 * @param container
	 *            container information
	 * @return return the best plan
	 */
	public List<Plan> makePlan(final ContainerSummary container) {
		List<Plan> plans = new ArrayList<Plan>();
		try {
			Defragment.analysisFragmentation(container, plans);
			Defragment.choosePlans(plans);
		} catch (Exception ex) {
			throw new DefragmentServiceException(ex);
		}
		return plans;
	}
}
