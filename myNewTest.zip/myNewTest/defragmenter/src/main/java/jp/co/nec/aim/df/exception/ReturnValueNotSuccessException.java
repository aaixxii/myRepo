package jp.co.nec.aim.df.exception;

public class ReturnValueNotSuccessException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2879211354967775729L;

	/**
	 * @param message
	 */
	public ReturnValueNotSuccessException(String message) {
		super(message);

	}
}
