package jp.co.nec.aim.df.service;

import static jp.co.nec.aim.df.constant.SystemConstant.FIRST_INDEX;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import jp.co.nec.aim.df.base.BaseService;
import jp.co.nec.aim.df.core.Plan;
import jp.co.nec.aim.df.dao.DaoFactory;
import jp.co.nec.aim.df.dao.ExecutionDao;
import jp.co.nec.aim.df.dbcp.DataSourceCreator;
import jp.co.nec.aim.df.entity.SegmentVersion;
import jp.co.nec.aim.df.exception.CommunicationException;
import jp.co.nec.aim.df.exception.ContainerIdIsNotCurrentException;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import jp.co.nec.aim.df.exception.DefragmentServiceException;
import jp.co.nec.aim.df.exception.PollContainerJobsTimeOutException;
import jp.co.nec.aim.df.exception.ReturnValueNotSuccessException;
import jp.co.nec.aim.df.exception.VersionNotMatchException;
import jp.co.nec.aim.df.util.ConnectionUtil;
import jp.co.nec.aim.df.util.PropertiesUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ExecutionService
 */
public class ExecutionService extends BaseService {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(ExecutionService.class);

	/**
	 * default constructor
	 */
	public ExecutionService() {
	}

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1232897382233515692L;
	private CommunicationService communication;
	private MergerSegmentService mergerService;
	private PersistSegmentService persistService;
	private PollFindJobService pollFindJob;
	private StatusCheckerService checkService;
	private BinDefragService binDefragService;
	private boolean isMMCare;
	private ExecutionDao dao;

	@Override
	public void initialize() {
		DataSource ds = DataSourceCreator.getInstance().getDataSource();
		try {
			this.con = ds.getConnection();
		} catch (SQLException e) {
			String message = "can not get connection from datasource..";
			throw new DefragmentServiceException(message, e);
		}
		this.communication = ServiceFactory
				.createService(CommunicationService.class);
		this.mergerService = ServiceFactory.createService(
				MergerSegmentService.class, this.con);
		this.persistService = ServiceFactory.createService(
				PersistSegmentService.class, this.con);
		this.pollFindJob = ServiceFactory.createService(
				PollFindJobService.class, this.con);
		this.checkService = ServiceFactory
				.createService(StatusCheckerService.class);
		this.binDefragService = ServiceFactory.createService(
				BinDefragService.class, this.con);
		this.isMMCare = PropertiesUtil.getMmCare();
		this.dao = DaoFactory.createDao(ExecutionDao.class, this.con);
	}

	/**
	 * The main flow of plan Execution
	 * 
	 * @param plans
	 *            the container plan
	 * @throws Exception
	 */
	public void planExecution(final List<Plan> plans) throws Exception {
		// check the parameter
		checkParamter(plans);

		// get the containerId
		final int containerId = plans.get(FIRST_INDEX).getContainerId();

		// the flag represent the send start
		// signal operation has error or not
		boolean isStartCorrect = true;

		try {
			isStartCorrect = trafficFlowControlStart(containerId);
			// do plan Execution
			// 1. merger the segments with the plan
			// 2. listen all the job that related to the
			// plan segment is all done
			// 3. Persist the merged segment to database
			// 4. do commit operation if successfully, rollBack when failed
			doPlanTransaction(plans);
		} catch (CommunicationException ex) {
			// if send start signal with CommunicationException
			// set the flag isStartCorrect to false
			// and skip do send stop signal operation..
			isStartCorrect = false;
			throw ex;
		} finally {
			// at last if start opereration without any error
			// send signal to MM to
			// stop defragment control with containerId
			if (isStartCorrect) {
				trafficFlowControlStop(containerId);
			} else {
				log.info("skip send stop traffic signal operation"
						+ " due to start opearation with communication error..");
			}

			ConnectionUtil.close(this.con);
		}
	}

	/**
	 * do each Plan Transaction
	 * 
	 * @param plans
	 *            the plans List
	 */
	private void doPlanTransaction(final List<Plan> plans) {
		// the each plan is a transaction
		for (final Plan plan : plans) {
			try {
				final int containerId = plan.getContainerId();
				final int joint = plan.getJoint();
				final long startSeg = plan.getFirstSegId();
				final long lastSeg = plan.getLastSegId();
				final boolean isNeedRetry = false;
				final boolean isMMAlive = checkService.isMMAlive(isNeedRetry);

				if (log.isDebugEnabled()) {
					log.debug("begin plan Execution transaction,"
							+ "container id: {}, joint number: {}, "
							+ "start segment id: {}, " + "end segment id: {}",
							new Object[] { containerId, joint, startSeg,
									lastSeg });
				}

				// set autoCommit to false
				con.setAutoCommit(false);

				// MM care flag is true
				if (isMMCare && isMMAlive) {
					// first lock the segment rows with segment id array
					// at the same time, get the version and reVersion
					// check the current version is match the version before
					// Analysis, if the version has no change, go continue
					// otherwise throw VersionNotMatchException,
					// skip persist segment to database and rollBack
					// the connection
					lockAndCheckVersion(plan);

					// check the current container id is same as the container
					// id
					// in system_init table key_name named
					checkIsTheCurrentContainerId(containerId);
				}

				if (log.isDebugEnabled()) {
					log.debug("start wait Until job is done..");
				}

				// skip this plan due to following reason:
				// 1 MM_Care=False, MM is not alive
				// 2 MM_Care=False, MM is not alive
				final boolean isJobRemain = isJobRemain(plan);
				if (!isMMCare && !isMMAlive && isJobRemain) {
					log.warn("Skip this plan due to MM_Care is false and"
							+ " MM is not alive whatever the FlowControl "
							+ "is on or off..");
					continue;
				} else {
					if (isJobRemain) {
						// otherwise start timer to listen all the job
						// that related to the plan segment is all done
						pollFindJob.waitUntilJobDone(plan);
					}
				}

				// MM care flag is true
				if (isMMCare && isMMAlive) {
					// check the current container id is same as the container
					// id
					// in system_init table key_name named
					checkIsTheCurrentContainerId(containerId);
				}

				if (log.isDebugEnabled()) {
					log.debug("all the job is done, begin to persist segment "
							+ "into database..");
				}

				if (log.isDebugEnabled()) {
					log.debug("start merger the segment plan.. ");
				}

				// the second is merger the segments with the plan
				boolean isNecessaryPersist = mergerService
						.mergerSegmentPlan(plan);

				if (!isNecessaryPersist) {
					log.info("the system is output the plan, but in actual"
							+ " there is nothing to merger the segment due to"
							+ " the plan has deviation.");
					ConnectionUtil.rollBack(con);
					return;
				}

				if (log.isDebugEnabled()) {
					log.debug("merger the segment plan successfully.. ");
				}
				
				// the last is the Persist the merged segment to database
				persistService.persistSegment(plan);

				// if this transaction complete successfully, do commit
				// operation
				// if failed, do rollBack operation.
				ConnectionUtil.commit(con);
				log.info("end plan Execution transaction, "
						+ "plan commit successfully, include segment ids {}.",
						plan.getSegIdsSplitByComma());
			} catch (SQLException ex) {
				ConnectionUtil.rollBack(con);
				log.error("sql Exception occurred while plan Execution, "
						+ "roll back the connection", ex);
			} catch (VersionNotMatchException ex) {
				ConnectionUtil.rollBack(con);
				log.error("VersionNotMatchException occurred while "
						+ "plan Execution, roll back the connection", ex);
			} catch (ContainerIdIsNotCurrentException ex) {
				ConnectionUtil.rollBack(con);
				log.error("ContainerIdIsNotCurrentException occurred while "
						+ "plan Execution, roll back the connection", ex);
			} catch (DefragmentDaoException ex) {
				ConnectionUtil.rollBack(con);
				log.error("DefragmentDaoException occurred while "
						+ "plan Execution, roll back the connection", ex);
			} catch (DefragmentServiceException ex) {
				ConnectionUtil.rollBack(con);
				log.error("DefragmentServiceException occurred while "
						+ "plan Execution, roll back the connection", ex);
			} catch (PollContainerJobsTimeOutException ex) {
				ConnectionUtil.rollBack(con);
				throw ex;
			} catch (Exception ex) {
				ConnectionUtil.rollBack(con);
				log.error("Exception occurred while plan Execution, "
						+ "roll back the connection", ex);
			}
		}
	}

	private boolean trafficFlowControlStart(final int containerId)
			throws Exception {
		// send signal to MM to
		// start the defragment control with containerId
		boolean isStartCorrect = sendSignalToStartControl(containerId);

		if (isMMCare) {
			binDefragService.startContainerDefrag(containerId);
		}
		return isStartCorrect;
	}

	private boolean trafficFlowControlStop(final int containerId)
			throws Exception {
		boolean isStartCorrect = sendSignalToStopControl(containerId);
		if (isMMCare) {
			binDefragService.stopContainerDefrag(containerId);
		}
		return isStartCorrect;
	}

	/**
	 * send Signal To MM, Start defragment Control <br>
	 * MM stop the MU job distribution
	 * 
	 * @param containerId
	 *            the containerId that will be control for defragment
	 * @return is send signal Successful
	 * @throws Exception
	 */
	private boolean sendSignalToStartControl(final int containerId)
			throws Exception {
		try {
			return communication.sendStartSignal(containerId);
		} catch (CommunicationException ex) {
			log.error("send Signal to MM to start the defragment control,"
					+ " CommunicationException occurred,"
					+ " maybe 400, 500 error ..", ex);
			mmCareJudgeMent(ex);
		} catch (ReturnValueNotSuccessException ex) {
			log.error("send Signal to MM to start the defragment control,"
					+ " ReturnValueNotSuccessException occurred..", ex);
			mmCareJudgeMent(ex);
		}
		return false;
	}

	/**
	 * send Signal To MM, stop defragment Control <br>
	 * MM continue the MU job distribution
	 * 
	 * @param containerId
	 *            the containerId that will be control for defragment
	 * @return
	 * @throws Exception
	 */
	private boolean sendSignalToStopControl(final int containerId)
			throws Exception {
		try {
			communication.sendStopSignal(containerId);
		} catch (CommunicationException ex) {
			log.error("send Signal to MM to start the defragment control,"
					+ " CommunicationException occurred,"
					+ " maybe 400, 500 error ..", ex);
			mmCareJudgeMent(ex);
		} catch (ReturnValueNotSuccessException ex) {
			log.error("send Signal to MM to stop the defragment control,"
					+ " ReturnValueNotSuccessException occurred..", ex);
			mmCareJudgeMent(ex);
		}
		return false;
	}

	/**
	 * checkParamter is null or empty
	 */
	private void checkParamter(final List<Plan> plans) {
		// check parameter
		if (plans == null) {
			throw new IllegalArgumentException("the plans is null "
					+ "while planExecution..");
		}

		if (plans.isEmpty()) {
			throw new DefragmentServiceException("the plans is empty "
					+ "while planExecution..");
		}
	}

	/**
	 * mmCareJudgeMent
	 * 
	 * @param ex
	 *            the exception
	 * @throws Exception
	 */
	private void mmCareJudgeMent(Exception ex) throws Exception {
		if (isMMCare) {
			throw ex;
		} else {
			log.info("ignore the above exception "
					+ "due to MM care flag is {}", isMMCare);
		}
	}

	/**
	 * lock segment rows and check the version, if the version is not match,
	 * throw the VersionNotMatchException
	 * 
	 * @param plan
	 */
	private void lockAndCheckVersion(final Plan plan) {
		final List<SegmentVersion> versions = dao.lockRowAndGetVersion(plan
				.getSegIdsSplitByComma());

		for (final SegmentVersion version : versions) {
			if (version.isMatchVersion(plan.getWillMergerSegs())) {
				if (log.isDebugEnabled()) {
					log.debug("the segment version has no change,"
							+ " segment id: {}, segment version: {}",
							version.getSegmentId(), version.getVersion());
				}
			} else {
				throw new VersionNotMatchException(
						"the segment version has changed, segment id: "
								+ version.getSegmentId());
			}
		}
	}

	/**
	 * check the container id current in use is different from the container id
	 * in database<br>
	 * if yes, continue, otherwise throw the ContainerIdIsNotCurrentException
	 */
	private void checkIsTheCurrentContainerId(final long containerId) {
		final Long containerIdInDb = binDefragService.getTrifficContainerId();
		if (containerIdInDb == null
				|| (containerIdInDb.longValue() != containerId)) {
			throw new ContainerIdIsNotCurrentException(
					"the container id current in use is different from the container id in database.."
							+ "the current container id: "
							+ containerId
							+ " the database container id: " + containerIdInDb);
		}
	}

	/**
	 * check is remain the top level jobs
	 * 
	 * @return is job remain
	 */
	private boolean isJobRemain(final Plan plan) {
		return (pollFindJob.getRemainJobCount(plan) > 0);
	}
}
