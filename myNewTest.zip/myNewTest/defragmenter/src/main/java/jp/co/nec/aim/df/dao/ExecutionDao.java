package jp.co.nec.aim.df.dao;

import java.util.List;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.entity.SegmentVersion;
import jp.co.nec.aim.df.exception.DefragmentDaoException;
import static jp.co.nec.aim.df.constant.SystemConstant.REPLACE;

/**
 * ExecutionDao lock the table segments row and get the version <br>
 * lock the SYSTEM_INIT and get the container id
 * 
 */
public class ExecutionDao extends BaseDao {
	/** lock the segments table rows and get the version **/
	private static final String LOCK_SEGMENTS_GET_VERSION = "select SEGMENT_ID as segmentId"
			+ ", VERSION as version, REVISION as reVersion"
			+ " from segments where SEGMENT_ID in ("
			+ REPLACE
			+ ") order by SEGMENT_ID for update";

	/**
	 * lock the segment row and get the version
	 * 
	 * @param segments
	 *            segment
	 */
	public List<SegmentVersion> lockRowAndGetVersion(final String segmentIds) {
		List<SegmentVersion> segmentVersions = null;
		try {
			String sql = LOCK_SEGMENTS_GET_VERSION.replace(REPLACE, segmentIds);
			prepareStatementCon(sql);
			executeQuery();
			segmentVersions = mappingList(SegmentVersion.class);
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
		}
		return segmentVersions;
	}
}
