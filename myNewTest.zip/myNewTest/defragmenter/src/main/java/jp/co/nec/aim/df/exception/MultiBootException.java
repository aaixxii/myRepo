package jp.co.nec.aim.df.exception;

/**
 * the exception of MultiBoot
 */
public class MultiBootException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -335026656751093927L;

	/**
	 * @param message
	 */
	public MultiBootException(String message) {
		super(message);

	}
}
