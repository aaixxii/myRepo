package jp.co.nec.aim.df.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import jp.co.nec.aim.df.entity.ContainerSummary;
import jp.co.nec.aim.df.entity.SegmentSummary;
import static jp.co.nec.aim.df.constant.SystemConstant.STANDARD_LEVEL;
import static jp.co.nec.aim.df.constant.SystemConstant.LEVEL_ERRORS;
import static jp.co.nec.aim.df.constant.SystemConstant.START_JOINT;
import static jp.co.nec.aim.df.constant.SystemConstant.MAX_JOINT;
import static jp.co.nec.aim.df.constant.SystemConstant.MAXPLANSIZE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * this class draw up the plan of segment defragment <br>
 * the joint number default is begin from 2 and end is 5 <br>
 */
public final class Defragment {
    /** log instance **/
    private static final Logger log = LoggerFactory.getLogger(Defragment.class);

    /**
     * fragmentationAnalysis <br>
     * after the Analysis, return all joint plan
     * 
     * @param container
     *            ContainerSummary instance
     * @param planlist
     *            the plan summary
     */
    public final static void analysisFragmentation(final ContainerSummary container,
            final List<Plan> planlist) {
        if (log.isDebugEnabled()) {
            log.debug("start Defragment fragmentationAnalysis..");
        }

        final int containerId = container.getContainerId();
        final double totalRadio = container.getTotalFragRadio();
        if (totalRadio < STANDARD_LEVEL - LEVEL_ERRORS) {
            log.info("the total defragment radio is {} in containerid:{}, " + "skip this container..",
                    totalRadio, containerId);
            return;
        }

        final List<SegmentSummary> segments = container.getSegmentSummary();
        final int size = segments.size();

        if (log.isDebugEnabled()) {
            log.debug("begin to Analysis, joint number from {} to {}," + " container id:{}..",
                    START_JOINT, MAX_JOINT, containerId);
        }

        for (int joint = START_JOINT; joint <= MAX_JOINT; joint++) {
            final List<SegmentSummary> willbeMerger = new ArrayList<SegmentSummary>(joint);
            /* the last segment do not defragment */
            for (int i = 0; i < size - joint; i++) {
                double fragRadioSum = 0;
                for (int j = i; j <= (i + joint - 1); j++) {
                    final SegmentSummary segment = segments.get(j);
                    fragRadioSum += segment.getFragmentRadio();
                    willbeMerger.add(segment);
                }

                if (fragRadioSum >= STANDARD_LEVEL) {
                    final Plan newPlan = InsertNewPlan(joint, container, willbeMerger);
                    planlist.add(newPlan);
                    if (log.isDebugEnabled()) {
                        log.debug("sum of the frag Radio is {}," + " merged segment ids is {}",
                                fragRadioSum, newPlan.getSegIdsSplitByComma());
                    }
                }
                willbeMerger.clear();
            }
        }

        if (planlist.isEmpty()) {
            return;
        }

        if (log.isDebugEnabled()) {
            log.debug("end to Analysis, joint number from {} to {}..", START_JOINT, MAX_JOINT);
        }

        if (log.isDebugEnabled()) {
            log.debug("end Defragment fragmentationAnalysis..");
        }
    }

    /**
     * ExecutationPlanning <br>
     * list the plan and find the best one to Execute
     * 
     * @param planlist
     *            the plan list
     */
    public final static void choosePlans(final List<Plan> planlist) {
        if (log.isDebugEnabled()) {
            log.debug("start Defragment executationPlanning..");
        }

        final int boxSize = MAX_JOINT + 1;
        final int planbox[] = new int[boxSize];
        int min = MAX_JOINT;

        if (planlist.isEmpty()) {
            return;
        }

        for (final Plan plan : planlist) {
            final int joint = plan.getJoint();
            if (min > joint) {
                min = joint;
            }
            planbox[joint]++;
        }

        for (int joint = START_JOINT; joint <= MAX_JOINT; joint++) {
            if (planbox[joint] > 0) {
                if (log.isDebugEnabled()) {
                    log.debug("There is {} plan when Joint number is {}.", planbox[joint], joint);
                }
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("The best joint number is {}..", min);
        }

        bestPlanCombiBySameJoint(min, planlist);
        if (log.isDebugEnabled()) {
            log.debug("end Defragment executationPlanning..");
        }
    }

    /**
     * bestPlanCombiBySameJoint <br>
     * get the best plan for Merger
     * 
     * @param joint
     *            joint
     * @param planlist
     *            plan list
     */
    private final static void bestPlanCombiBySameJoint(final int joint, final List<Plan> planlist) {
        if (log.isDebugEnabled()) {
            log.debug("start Defragment bestPlanCombiBySameJoint..");
        }

        for (int k = planlist.size() - 1; k > 0; k--) {
            if (planlist.get(k).getJoint() != joint) {
                planlist.remove(k);
            }
        }

        for (int i = 0; i < planlist.size(); i++) {
            final Plan plan = planlist.get(i);

            long firstSegId = plan.getFirstSegId();
            long lastSegId = plan.getLastSegId();

            for (int j = planlist.size() - 1; j > i; j--) {
                long tmp = planlist.get(j).getFirstSegId();
                if ((tmp >= firstSegId) && (tmp <= lastSegId)) {
                    if (log.isDebugEnabled()) {
                        log.debug("remove same joint plan, index: {}, "
                                + "cover from: {}, cover to: {}", j, firstSegId, lastSegId);
                    }
                    planlist.remove(j);
                }
            }
        }

        /* planlist size <= MAXPLANSIZE */
        final int planSize = planlist.size();
        if (planSize > MAXPLANSIZE) {
            log.info("remove the plan that was exceed the allowed plan size"
                    + " due to analyzed plan size {} is" + " bigger than max plan size {}",
                    planSize, MAXPLANSIZE);

            for (int i = planlist.size() - 1; i >= MAXPLANSIZE; i--) {
                planlist.remove(i);
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("end Defragment bestPlanCombiBySameJoint..");
        }
    }

    /**
     * InsertNewPlan<br>
     * if fragment radio sum is match the condition, InsertNewPlan
     * 
     * @param joint
     * @param firstSegmentId
     * @param segments
     * @return plan instance
     */
    private final static Plan InsertNewPlan(final int joint, final ContainerSummary container,
            final Collection<SegmentSummary> segments) {
        if (log.isDebugEnabled()) {
            log.debug("start Defragment InsertNewPlan..");
        }
        final Plan plan = new Plan(joint, container.getContainerId(), /*container.getContainerId(),*/
                container.getMaxSegmentSize(), container.getMaxSegmentDiffs(), segments);
        if (log.isDebugEnabled()) {
            log.debug("end Defragment InsertNewPlan..");
        }
        return plan;
    }
}
