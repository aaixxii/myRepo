package jp.co.nec.aim.df.dao;

import jp.co.nec.aim.df.base.BaseDao;
import jp.co.nec.aim.df.exception.DefragmentDaoException;

/**
 * SEGMENT_DEFRAGMENTATION Dao Class
 * 
 * @author jinxl
 * 
 */
public class SegmentDefragDao extends BaseDao {

	private String GET_SEG_DEFRAG_COUNT = "select count(CONTAINER_ID) from SEGMENT_DEFRAGMENTATION";

	private String GET_SEG_DEFRAG_CONTAINERID = "select CONTAINER_ID from SEGMENT_DEFRAGMENTATION";

	public int getSegDefragCount() {
		int count = 0;
		try {
			prepareStatement(GET_SEG_DEFRAG_COUNT);

			executeQuery();
			count = getResultCount();
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
			releaseConnectionToPoll();
		}
		return count;
	}

	public Long getTrifficContainerId() {
		Long containerId = null;
		try {
			prepareStatement(GET_SEG_DEFRAG_CONTAINERID);
			executeQuery();
			if (next()) {
				containerId = getLong("CONTAINER_ID");
			}
			return containerId;
		} catch (Exception ex) {
			throw new DefragmentDaoException(ex);
		} finally {
			releaseResultSet();
			releasePreparedStatement();
			releaseConnectionToPoll();
		}
	}
}
