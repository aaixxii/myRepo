package jp.co.nec.aim.df.constant;

public enum ExecuteMode {
	DEFRAGMENT, UPDATE_CONTAINERID, SEG_DISPLAY, SIMULATION;
}
