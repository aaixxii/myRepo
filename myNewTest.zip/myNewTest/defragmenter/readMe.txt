This is a defragmentation project for AIM5.0.0

How to deploy this project.

 $ checkout this project
 $ mvn clean package
   skip tests
 $ mvn -DskipTests clean package

  ---- How to exeute the defragment ----
  1. After execute the maven package command, find the zip package named [defragmentation-bin.zip] in target path.

  2. Unzip the zip file [defragmentation-bin.zip]
 
  3. Gave the execute permission.
     $ chmod +x -R ./

  4. Properties file configution
     config folder
       |-------------- defragment.properties (defragment related properties)
       |-------------- jdbc.properties       (modify the jdbc url is necessary base on your environment)
       |-------------- MM.properties         (modify the MM ip is necessary base on your environment)
       |-------------- logback.xml           (log related config file)
 
  5. Go to Path bin, and execute the script. 
     if you want execute the defragment. 
      $ ./execDefragment.sh      (linux)
      $   execDefragment.bat     (windows)
     if you want to update the MM traffic container id directly when the defragment tool exit abnormal.
     you can update the traffic container id to -1(normal).
      $ ./updateTrafficContainerId.sh  (linux)
      $   updateTrafficContainerId.bat (windows)

      the output message: 
      ***********************************************************************
      *******************defragmentation container id update tool******************
      ***********************************************************************
      Please input the container id:-1
      ready to update the traffic container id -1..
      update the traffic containerid -1 successfully.
      
  6. Output log inforamtion
     after execution, you will find the detail inforamtion in log folder. include 
     debug.log (the log level is debug)
     info.log    (the log level is info)  