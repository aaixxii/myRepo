package com.nec.aim.uid.dmwebapp.model;

public class AIMLModel {

	private Category category;

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		AIMLModel other = (AIMLModel) obj;
		if (this.category == null) {
			if (other.category != null) {
				return false;
			}
		} else if (!this.category.equals(other.category)) {
			return false;
		}
		return true;
	}

	public Category getCategory() {
		return this.category;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((this.category == null) ? 0 : this.category.hashCode());
		return result;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "AIML [category=" + this.category + "]";
	}

}
