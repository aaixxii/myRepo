package com.nec.aim.uid.dmwebapp.persistence;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "segment_change_log")
public class SegmengChangeLog {
    @PrimaryKeyColumn(name="seg_change_id", ordinal = 0, type = PrimaryKeyType.PARTITIONED, ordering = Ordering.DESCENDING) 
    long segChangeId;
    
    @Column(value = "bio_id")
    long bioId;
    
    @Column(value = "seg_id")
    long segId;
    
    @Column(value = "seg_ver")
    long segVer;
    
    @Column(value = "change_type")
    short changeType;

    public long getSegChangeId() {
        return segChangeId;
    }

    public void setSegChangeId(long segChangeId) {
        this.segChangeId = segChangeId;
    }

    public long getBioId() {
        return bioId;
    }

    public void setBioId(long bioId) {
        this.bioId = bioId;
    }

    public long getSegId() {
        return segId;
    }

    public void setSegId(long segId) {
        this.segId = segId;
    }

    public long getSegVer() {
        return segVer;
    }

    public void setSegVer(long segVer) {
        this.segVer = segVer;
    }

    public short getChangeType() {
        return changeType;
    }

    public void setChangeType(short changeType) {
        this.changeType = changeType;
    }
    
    @Override
    public boolean equals(Object obj) {
        return false;
    }
    @Override
    public int hashCode() {
        return 0;        
    }   
}
