package com.nec.aim.uid.dmwebapp.persistence;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface SegmentRepository extends CassandraRepository<Segment, Segment> {
	
	   @Query("select * from book where title = ?0 and publisher=?1")
	    Iterable<Segment> findByTitleAndPublisher(String title, String publisher);

}
