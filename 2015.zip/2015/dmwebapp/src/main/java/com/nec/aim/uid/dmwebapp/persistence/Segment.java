package com.nec.aim.uid.dmwebapp.persistence;

import java.sql.Timestamp;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;


@Table(value = "segment")
public class Segment {
    
    @PrimaryKeyColumn(name="seg_id", ordinal = 1, type = PrimaryKeyType.PARTITIONED, ordering = Ordering.DESCENDING)    
    long segId;
    
    @Column(value = "last_ver")
    long lastVer;
    
    @Column(value = "last_offset")
    long lastOffset;
    
    @Column(value = "last_modified")
    Timestamp lastModified;
    
    @Column(value = "corrupted_flag")
    boolean corruptedFlag;
    
    @Column(value = "status")
    String status;

    public long getSegId() {
        return segId;
    }

    public void setSegId(long segId) {
        this.segId = segId;
    }

    public long getLastVer() {
        return lastVer;
    }

    public void setLastVer(long lastVer) {
        this.lastVer = lastVer;
    }  
   
    public long getLastOffset() {
        return lastOffset;
    }

    public void setLastOffset(long lastOffset) {
        this.lastOffset = lastOffset;
    }

    public Timestamp getLastModified() {
        return lastModified;
    }

    public void setLastModified(Timestamp lastModified) {
        this.lastModified = lastModified;
    }

    public boolean isCorruptedFlag() {
        return corruptedFlag;
    }

    public void setCorruptedFlag(boolean corruptedFlag) {
        this.corruptedFlag = corruptedFlag;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    @Override
    public boolean equals(Object obj) {
        return false;
    }
    @Override
    public int hashCode() {
        return 0;        
    }    
}
