package com.nec.aim.uid.dmwebapp.model;

public class Template {
	private Set set;
	private String value;

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		Template other = (Template) obj;
		if (this.set == null) {
			if (other.set != null) {
				return false;
			}
		} else if (!this.set.equals(other.set)) {
			return false;
		}
		if (this.value == null) {
			if (other.value != null) {
				return false;
			}
		} else if (!this.value.equals(other.value)) {
			return false;
		}
		return true;
	}

	public Set getSet() {
		return this.set;
	}

	public String getValue() {
		return this.value;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((this.set == null) ? 0 : this.set.hashCode());
		result = prime * result
				+ ((this.value == null) ? 0 : this.value.hashCode());
		return result;
	}

	public void setSet(Set set) {
		this.set = set;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "Template [set=" + this.set + ", value=" + this.value + "]";
	}

}
