package com.nec.aim.uid.client.runner;


import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.manager.UidClientManager;


public class UidJobRunner {
	private static final UidJobRunner INSTANCE = new UidJobRunner();
	private boolean mustRun = true;
	private static Logger logger = LoggerFactory.getLogger(UidJobRunner.class);

	public UidJobRunner() {
	}

	public static UidJobRunner getInstance() {
		return INSTANCE;
	}

	public void run() {
		UidClientManager manager = UidClientManager.getInstance();		
		
		while (mustRun) {	
			
		}
	
	}	

	private Runnable generateReqeust(int oneCircleJobCount, File file) {
		Runnable circleJob = null;

		return null;
	}	

	public boolean isMustRun() {
		return mustRun;
	}

	public void setMustRun(boolean mustRun) {
		this.mustRun = mustRun;
	}

	FilenameFilter fileNameFilter = new FilenameFilter() {
		@Override
		public boolean accept(File dir, String name) {
			if (name.lastIndexOf('.') > 0) {
				int lastIndex = name.lastIndexOf('.');
				String str = name.substring(lastIndex);				
				if (str.equals(".xml") || str.equals(".dat")) {
					return true;
				}
			}
			return false;
		}
	};

	FilenameFilter xmlNameFilter = new FilenameFilter() {
		@Override
		public boolean accept(File dir, String name) {
			if (name.lastIndexOf('.') > 0) {
				int lastIndex = name.lastIndexOf('.');
				String str = name.substring(lastIndex);				
				if (str.equals(".xml")) {
					return true;
				}
			}
			return false;
		}
	};

	FilenameFilter datNameFilter = new FilenameFilter() {
		@Override
		public boolean accept(File dir, String name) {
			if (name.lastIndexOf('.') > 0) {
				int lastIndex = name.lastIndexOf('.');
				String str = name.substring(lastIndex);				
				if (str.equals(".dat")) {
					return true;
				}
			}
			return false;
		}
	};
	
	@SuppressWarnings("unused")
	private File foundXml(File[] fileList, String prefix) {
		for (int i = 0; i < fileList.length; i++) {
			File file = fileList[i];
			String tmp = file.getName();
			if (tmp.startsWith(prefix)) {
				return file;
			}
		}
		return null;
	}	

}
