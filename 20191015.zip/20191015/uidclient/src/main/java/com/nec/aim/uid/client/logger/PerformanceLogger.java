package com.nec.aim.uid.client.logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PerformanceLogger {
	private static Logger log = LoggerFactory.getLogger("PerformanceLogger");

	// Basic Items
	private static final String KEY_VALUE_SEPARATOR = "===";
	private static final String LOG_ITEM_SEPARATOR = "<>";

	// Key-Values
	private static final String KEY_FORMAT = "FORMAT";
	private static final String KEY_CATEGORY = "CATEGORY";
	private static final String KEY_COMPONENT = "COMPONENT";
	private static final String KEY_FUNCTION = "FUNC";
	private static final String JOB_ID = "JOBID";
	private static final String ONE_CIRCLE_JOB_COUNT = "oneCircleJobCount";
	private static final String PRIORITY = "priority";
	private static final String KEY_CLASS = "CLASS";
	private static final String KEY_ELAPSED_TIME = "ELAPSED_TIME";	

	private static final String VALUE_FORMAT = "NSV";
	private static final String VALUE_CATEGORY = "PERF";

	private PerformanceLogger() {
	}

	public static final void trace(String className, String functionName, String jobId, String oneCircleJobCount, Integer priority, long elapsedTime) {
		// Don't throw exception because logger must not affect application
		// behavior
		if (className == null) {
			return;
		}

		if (functionName == null) {
			return;
		}

		String performanceLogMessage = buildPerformanceLog("XMClient", className, functionName, jobId, oneCircleJobCount, priority, elapsedTime);

		if (log.isTraceEnabled()) {
			log.trace(performanceLogMessage);
		}
	}

	private static final String buildPerformanceLog(String componentName, String className, String functionName, 
			String jobId, String oneCircleJobCount,  Integer priority, long elapsedTime) {
		StringBuilder logMessage = new StringBuilder();

		appendKeyAndValue(logMessage, KEY_FORMAT, VALUE_FORMAT);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_CATEGORY, VALUE_CATEGORY);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_COMPONENT, componentName);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_CLASS, className);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_FUNCTION, functionName);
		appendLogItemSeparator(logMessage);
		
		if (jobId != null) {
			appendKeyAndValue(logMessage, JOB_ID, jobId);
			appendLogItemSeparator(logMessage);	
		}
		
		if (oneCircleJobCount != null) {
			appendKeyAndValue(logMessage, ONE_CIRCLE_JOB_COUNT, oneCircleJobCount);
			appendLogItemSeparator(logMessage);	
		}	
		
		if (priority != null) {
			appendKeyAndValue(logMessage, PRIORITY, String.valueOf(priority));
			appendLogItemSeparator(logMessage);	
		}	
		
		appendKeyAndValue(logMessage, KEY_ELAPSED_TIME, new Long(elapsedTime).toString());
		String performanceLogMessage = logMessage.toString();
		return performanceLogMessage;
	}

	private static final void appendKeyAndValue(StringBuilder logMessage, String key, String value) {
		logMessage.append(key);
		logMessage.append(KEY_VALUE_SEPARATOR);
		logMessage.append(value);
	}

	private static final void appendLogItemSeparator(StringBuilder logMessage) {
		logMessage.append(LOG_ITEM_SEPARATOR);
	}
}
