package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.dispatch.DmServiceManager;
import com.nec.aim.dm.dmservice.entity.NodeStorageManager;
import com.nec.aim.dm.dmservice.entity.NsmIdUrl;

@Repository
public class NodeStorageManagerRepositoryImpl implements NodeStorageManagerRepository{
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	private static final String sqlAll = "select * from node_storage_manager";
	private static final String sqlById = "select * from node_storage_manager where nsm_id=?";
	//private static final String sqlByRedundancy = "select nsm_id,url from node_storage_manager where status=0 or status=1 and space>=? order by space DESC limit ?";
	private static final String sqlByRedundancy = "select * from node_storage_manager where (status=1 or status=0) and space>0 order by space DESC limit ?";
	private static final String setMailFlagSql = "update node_storage_manager  set mail_flag ='signal' where  nsm_id =?";
	private static final String getNodeStorageBySegIdSql = "select n.* from node_storage_manager n, segment_loading s where (n.status =1 or n.status =0) and n.nsm_id = s.nsm_id and s.segment_id=? limit ?";	
	private static final String getNsmIplAndId = "select nsm_id, url from node_storage_manager where status=1";


	@Override
	public List<NodeStorageManager> findAll()  throws SQLException {		
		return jdbcTemplate.query(sqlAll,  nodeRowMapper);
	}

	@Override
	public NodeStorageManager findById(Long id, String dmStrorageId)  throws SQLException{		
		return jdbcTemplate.queryForObject(sqlById, new Object[] {id, dmStrorageId}, nodeRowMapper);
	}
	
	RowMapper<NodeStorageManager> nodeRowMapper = (rs, rowNum) -> {
	    NodeStorageManager node = new NodeStorageManager();
	    node.setNsmId(rs.getInt("nsm_id"));	   
	    node.setUrl(rs.getString("url"));
	    node.setDiskSize(rs.getInt("disk_size"));
	    node.setSpace(rs.getInt("space"));
	    node.setStatus(rs.getInt("status"));
	    node.setUpdateTs(rs.getTimestamp("update_ts"));
	    return node;
	};

	@Override
	public List<NodeStorageManager>  findNeedNodeByRedundancy(int redundancy)  throws SQLException {		
		return jdbcTemplate.query(sqlByRedundancy,  new Object[] {redundancy}, nodeRowMapper)	;
	}

	@Override
	public void setSignalMailFlag(int storageId) {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(setMailFlagSql, new Object[] {storageId});
	}
	
	@Override
	public List<NodeStorageManager> getNodeStorgeBySegmentId(Long segmentId, Integer redundancy) throws SQLException {		
		List<NodeStorageManager> results = jdbcTemplate.query(getNodeStorageBySegIdSql, new Object[] {segmentId, redundancy}, nodeRowMapper);
		return results;
	}
	
	RowMapper<NsmIdUrl> nsmIdUrlMapper = (rs, rowNum) -> {
		NsmIdUrl nu = new NsmIdUrl();
		nu.setStorageId(rs.getInt("nsm_id"));
		nu.setBasUrl(rs.getString("url"));
		return nu;		
	};
	
	@Override
	public void getNodeStorageUrlAndId() throws SQLException {
		List<NsmIdUrl> result =  jdbcTemplate.query(getNsmIplAndId,nsmIdUrlMapper);	
		result.forEach(one -> {
			DmServiceManager.putToNodeStorageUrlMap(one.getStorageId(), one.getBasUrl());
		});		
		
	}	

	@Override
	public void commit() throws SQLException {
		jdbcTemplate.execute("commit");
		
	}

	@Override
	public void rollback() throws SQLException {
		jdbcTemplate.execute("rollback");		
	}	
}
