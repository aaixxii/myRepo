package jp.co.nec.aim.mm.constants;

/**
 * @author Erik Vandekieft
 */
public enum SystemConfigNamespace {
	MM("default.mm.properties"), DM("default.dm.properties"), MU(
			"default.mu.properties"), SMS("default.sms.properties");

	private String defaultPropertiesFilename;

	private SystemConfigNamespace(String defaultPropertiesFilename) {
		this.defaultPropertiesFilename = defaultPropertiesFilename;
	}

	public String getDefaultPropertiesFilename() {
		return defaultPropertiesFilename;
	}
}
