package jp.co.nec.aim.mm.exception;

public class UnreachableCodeException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5670653981311541162L;

	public UnreachableCodeException() {
	}
	
	public UnreachableCodeException(Throwable ex) {
		super(ex);
	}

	public UnreachableCodeException(String detail, Throwable ex) {
		super(detail, ex);
	}

}
