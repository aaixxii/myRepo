package jp.co.nec.aim.mm.constants;

/**
 * JobState is the enum that represents the different states that entries in
 * both the 'JobQueue' and 'GridQueue' tables can be in.
 * 
 * @author Erik Vandekieft
 * 
 */
public enum JobState {
	QUEUED(0), //
	WORKING(1), //
	DONE(2);
	private int val;

	private JobState(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}
}
