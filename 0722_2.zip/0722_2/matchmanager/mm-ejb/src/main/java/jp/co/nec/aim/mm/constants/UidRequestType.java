/**this is file UidRequestType.java
 * @author xia
   @date 2020/05/30
 */
package jp.co.nec.aim.mm.constants;

/**
 * @author xia
 *
 */
public enum UidRequestType {
	Quality, Insert, Identify, Delete;
}
