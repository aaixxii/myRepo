package com.nec.aim.dm.dmservice.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nec.aim.dm.dmservice.dispatch.Dispatcher;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class DownloadController extends HttpServlet {	
	
	private static final long serialVersionUID = -5673372086651421607L;
	
	@Autowired
	Dispatcher dispatcher;
	
	@GetMapping("/seg/{Id}")
	public void downloadSegment(HttpServletRequest req, HttpServletResponse res, @PathVariable("Id") Long segId) throws IOException, InterruptedException, ExecutionException, SQLException {
		log.info("Received downloadSegment from {}", req.getRemoteHost());		
	    String url = dispatcher.getNsmUrl(segId);
	    log.info("redirct download to {}", url);	    
	    res.setStatus(HttpServletResponse.SC_MOVED_TEMPORARILY);	    
	    res.setHeader("Location", url);
	    res.sendRedirect(url);	
	    return;
	}	

	/**
	 * @param req
	 * @param res
	 * @param segId
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @throws SQLException
	 */
//	@GetMapping("/seg/{Id}")
//	public void downloadSegment(HttpServletRequest req, HttpServletResponse res, @PathVariable("Id") Long segId) throws IOException, InterruptedException, ExecutionException, SQLException {
//		log.info("Received downloadSegment from {}", req.getRemoteHost());
//		Long segmentId = new Long(segId);
//		byte[] segmentData = dispatcher.dispatchDownloadReqeust(segmentId);		
//		if (segmentData != null && segmentData.length > 0) {
//			long length = segmentData.length;
//			res.setContentType("application/binary");
//			res.addHeader("Content-Length", Long.toString(length));
//			//res.setHeader("Content-Disposition", "attachment; filename=" + segmentId + ".seg");
//			res.getOutputStream().write(segmentData);
//			res.setStatus(200);
//			log.info("Success send segment data to mu, segmentId={}", segmentId);
//		} else {
//			throw new DmServiceException("Faild to get segment data");
//		}
//	}	
}
