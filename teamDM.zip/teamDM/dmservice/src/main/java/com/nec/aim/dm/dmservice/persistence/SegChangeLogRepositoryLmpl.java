package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.SegChangeLog;

@Repository
public class SegChangeLogRepositoryLmpl implements SegChangeLogRepository {

	private static final String insertForNewSql = "insert into SEGMENT_CHANGE_LOG(BIOMETRICS_ID,SEGMENT_ID,SEGMENT_VERSION, CHANGE_TYPE, UPDATE_TS) values(?,?,?,?,CURRENT_TIMESTAMP())";
	private static final String insertSql = "insert into SEGMENT_CHANGE_LOG(BIOMETRICS_ID,EXTERNAL_ID,TEMPLATE_DATA,SEGMENT_ID,SEGMENT_VERSION, CHANGE_TYPE, UPDATE_TS) values(?,?,?,?,?,?,CURRENT_TIMESTAMP())";
	private static final String deleteSql = "insert into SEGMENT_CHANGE_LOG(BIOMETRICS_ID,EXTERNAL_ID,SEGMENT_ID,SEGMENT_VERSION, CHANGE_TYPE,UPDATE_TS) values(?,?,?,?,?,CURRENT_TIMESTAMP())";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void insertForNewSegment(Long biometricsId, Long segmentId, Long segmentVer, Integer catchUp)
			throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertForNewSql, new Object[] { biometricsId, segmentId, segmentVer, catchUp });

	}

	@Override
	public void insert(SegChangeLog catchUp) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql,
				new Object[] { catchUp.getBiometricsId(), catchUp.getExternalId(), catchUp.getTemplateData(),
						catchUp.getSegmentId(), catchUp.getSegmentVersion(), catchUp.getChangeType() });
	}

	@Override
	public void delete(SegChangeLog catchUp) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(deleteSql, new Object[] { catchUp.getBiometricsId(), catchUp.getExternalId(),
				catchUp.getSegmentId(), catchUp.getSegmentVersion(), catchUp.getChangeType() });
	}
}
