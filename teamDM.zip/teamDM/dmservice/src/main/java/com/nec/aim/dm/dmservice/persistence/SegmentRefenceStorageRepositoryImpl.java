package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.SegBioNsmUrl;

@Repository
public class SegmentRefenceStorageRepositoryImpl implements SegmentRefenceStorageRepository {

	private static final String insertSql = "insert into SEGMENT_REF_STORAGE_INFO(SB_ID, SEGMENT_ID, BIO_ID, EXTERNAL_ID) values(?,?,?,?)";
	private static final String insertWitoutRefIdSql = "insert into SEGMENT_REF_STORAGE_INFO(SB_ID, SEGMENT_ID, BIO_ID) values(?,?,?)";
	private static final String updateSql = "update SEGMENT_REF_STORAGE_INFO set EXTERNAL_ID =? where SB_ID=? and SEGMENT_ID=? and BIO_ID=?";
	private static final String deleteRefIdSql = "delete from SEGMENT_REF_STORAGE_INFO where SB_ID=? and SEGMENT_ID=? and BIO_ID=?";
	private static final String getSql = "select NG.URL,SRS.SEGMENT_ID, SRS.BIO_ID from SEGMENT_REF_STORAGE_INFO SRS, STORAGE_BOX NG where  SRS.SB_ID = NG.SB_ID and NG.STATUS=1 and SRS.EXTERNAL_ID=?";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	RowMapper<SegBioNsmUrl> segBioNsmUrlMapper = (rs, rowNum) -> {
		SegBioNsmUrl segBioNsmUrl = new SegBioNsmUrl();
		segBioNsmUrl.setUrl(rs.getString("URL"));
		segBioNsmUrl.setSegmentId(rs.getLong("SEGMENT_ID"));
		segBioNsmUrl.setBioId(rs.getLong("BIO_ID"));
		return segBioNsmUrl;
	};

	@Override
	public void inserSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId, String externalId)
			throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql, new Object[] { storageId, segId, bioId, externalId });
	}

	@Override
	public void insertSegRefStorageWitoutRefId(Integer storageId, Long segId, Long bioId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertWitoutRefIdSql, new Object[] { storageId, segId, bioId });
	}

	@Override
	public int deleteSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		return jdbcTemplate.update(deleteRefIdSql, new Object[] { storageId, segId, bioId });
	}

	@Override
	public int updateSegmentRefenceStorageInfo(String externalId, Integer storageId, Long segId, Long bioId)
			throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		return jdbcTemplate.update(updateSql, new Object[] { externalId, storageId, segId, bioId });
	}

	@Override
	public List<SegBioNsmUrl> getInfoForGetTemplate(String externalId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		List<SegBioNsmUrl> result = jdbcTemplate.query(getSql, new Object[] { externalId }, segBioNsmUrlMapper);
		return result;
	}

}
