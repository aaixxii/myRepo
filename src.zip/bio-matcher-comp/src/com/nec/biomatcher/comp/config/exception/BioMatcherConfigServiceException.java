package com.nec.biomatcher.comp.config.exception;

import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioMatcherConfigServiceException.
 */
public class BioMatcherConfigServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio matcher config service exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioMatcherConfigServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio matcher config service exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioMatcherConfigServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio matcher config service exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioMatcherConfigServiceException(Throwable cause) {
		super(cause);
	}

	@Override
	protected Logger getErrorLogger() {
		return CommonLogger.CONFIG_LOG;
	}
}