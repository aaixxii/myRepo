package com.nec.biomatcher.comp.zmq;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class ZmqClientException extends CoreException {

	private static final long serialVersionUID = 1L;

	public ZmqClientException(String message, Throwable cause) {
		super(message, cause);
	}

	public ZmqClientException(String message) {
		super(message);
	}

	public ZmqClientException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

}
