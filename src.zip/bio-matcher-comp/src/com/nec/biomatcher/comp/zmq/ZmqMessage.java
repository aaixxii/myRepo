package com.nec.biomatcher.comp.zmq;

import java.io.Serializable;

public class ZmqMessage implements Serializable {
	private static final long serialVersionUID = 1L;

	private String messageKey;
	private byte[] messageBuf;
	private String connectionUrl;

	public ZmqMessage(String messageKey, byte[] messageBuf, String connectionUrl) {
		this.messageKey = messageKey;
		this.messageBuf = messageBuf;
		this.connectionUrl = connectionUrl;
	}

	public ZmqMessage(String messageKey, byte[] messageBuf) {
		this.messageKey = messageKey;
		this.messageBuf = messageBuf;
	}

	public String getMessageKey() {
		return messageKey;
	}

	public void setMessageKey(String messageKey) {
		this.messageKey = messageKey;
	}

	public byte[] getMessageBuf() {
		return messageBuf;
	}

	public void setMessageBuf(byte[] messageBuf) {
		this.messageBuf = messageBuf;
	}

	@Override
	public String toString() {
		return "[messageKey: " + messageKey + ", messageBufSize: " + (messageBuf == null ? 0 : messageBuf.length) + "]";
	}

	public String getConnectionUrl() {
		return connectionUrl;
	}

	public void setConnectionUrl(String connectionUrl) {
		this.connectionUrl = connectionUrl;
	}
}
