package com.nec.biomatcher.comp.zmq;

import org.apache.log4j.Logger;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;
import org.zeromq.ZMQ.Socket;

public class ZmqSendReceiveConnection {
	private static final Logger logger = Logger.getLogger(ZmqSendReceiveConnection.class);

	public static final byte[] sendReceiveMessage(final String serverId, final String connectionUrl,
			byte[] requestPayload, long timeoutMilli)
			throws ZmqClientException, ZmqConnectionException, ZmqSendException, ZmqReceiveException {
		final boolean noBlockFlag = true;
		Context context = null;
		Socket requester = null;
		long connectionTimeTakenMilli = 0;
		long beforeCallStartTimeMilli = System.currentTimeMillis();
		try {
			context = ZMQ.context(1);

			requester = context.socket(ZMQ.REQ);

			requester.setLinger(0);

			// default timeouts
			requester.setSendTimeOut(Math.max(100, (int) timeoutMilli));

			try {
				requester.connect(connectionUrl);
			} finally {
				connectionTimeTakenMilli = System.currentTimeMillis() - beforeCallStartTimeMilli;
			}

			int sendTimeoutMilli = Math.max(100, (int) (timeoutMilli - connectionTimeTakenMilli));
			long sendTimeTakenMilli = 0;
			long sendStartTimestampMilli = System.currentTimeMillis();
			boolean sendFlag = false;
			try {
				requester.setSendTimeOut(sendTimeoutMilli);
				if (noBlockFlag) {
					sendFlag = requester.send(requestPayload, ZMQ.NOBLOCK);
				} else {
					sendFlag = requester.send(requestPayload);
				}

				sendTimeTakenMilli = System.currentTimeMillis() - sendStartTimestampMilli;

				if (!sendFlag) {
					throw new ZmqSendException("Error sending message to serverId: " + serverId + ",  connectionUrl: "
							+ connectionUrl + ", sendTimeout: " + sendTimeoutMilli + ", sendTimeTaken: "
							+ sendTimeTakenMilli + ", sendFlag: " + sendFlag + ", connectionTimeTakenMilli: "
							+ connectionTimeTakenMilli);
				}
			} catch (ZmqSendException ex) {
				throw ex;
			} catch (Throwable th) {
				sendTimeTakenMilli = System.currentTimeMillis() - sendStartTimestampMilli - sendTimeTakenMilli;
				throw new ZmqSendException("Error sending message to serverId: " + serverId + ",  connectionUrl: "
						+ connectionUrl + ", sendTimeoutMilli: " + sendTimeoutMilli + ", sendTimeTakenMilli: "
						+ sendTimeTakenMilli + ", connectionTimeTakenMilli: " + connectionTimeTakenMilli + " : "
						+ th.getMessage(), th);
			}

			long receiveTimeTakenMilli = 0;
			long receiveStartTimestampMilli = System.currentTimeMillis();
			int receiveTimeoutMill = Math.max(100,
					(int) (timeoutMilli - connectionTimeTakenMilli - sendTimeTakenMilli));
			try {
				requester.setReceiveTimeOut(receiveTimeoutMill);

				byte[] responsePayload = requester.recv();

				receiveTimeTakenMilli = System.currentTimeMillis() - receiveStartTimestampMilli;

				if (responsePayload == null) {
					throw new ZmqReceiveException("Error in receiveMessage : Received bytearray is null from serverId: "
							+ serverId + ",  connectionUrl: " + connectionUrl + ", receiveTimeoutMill: "
							+ receiveTimeoutMill + ", receiveTimeTakenMilli: " + receiveTimeTakenMilli
							+ ", sendTimeTakenMilli: " + sendTimeTakenMilli + ", connectionTimeTakenMilli: "
							+ connectionTimeTakenMilli);
				}

				return responsePayload;
			} catch (ZmqReceiveException ex) {
				throw ex;
			} catch (Throwable th) {
				receiveTimeTakenMilli = System.currentTimeMillis() - receiveStartTimestampMilli;
				throw new ZmqReceiveException(
						"Error in receiveMessage from serverId: " + serverId + ",  connectionUrl: " + connectionUrl
								+ ", receiveTimeoutMill: " + receiveTimeoutMill + ", receiveTimeTakenMilli: "
								+ receiveTimeTakenMilli + ", sendTimeTakenMilli: " + sendTimeTakenMilli
								+ ", connectionTimeTakenMilli: " + connectionTimeTakenMilli + " : " + th.getMessage(),
						th);
			}
		} catch (ZmqSendException | ZmqReceiveException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new ZmqConnectionException(
					"Error in openConnection to serverId: " + serverId + ",  connectionUrl: " + connectionUrl
							+ ", connectionTimeTakenMilli: " + connectionTimeTakenMilli + " : " + th.getMessage(),
					th);
		} finally {
			if (requester != null) {
				try {
					requester.close();
				} catch (Throwable th) {
					logger.error("Error in closeConnection while closing requester for serverId: " + serverId
							+ ", connectionUrl: " + connectionUrl + " : " + th.getMessage(), th);
				}
			}

			if (context != null) {
				try {
					context.close();
				} catch (Throwable th) {
					logger.error("Error in closeConnection wile closing context for serverId: " + serverId
							+ ", connectionUrl: " + connectionUrl + " : " + th.getMessage(), th);
				}
			}
		}
	}

}
