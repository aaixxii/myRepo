package com.nec.biomatcher.comp.zmq;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class ZmqSendException extends CoreException {

	private static final long serialVersionUID = 1L;

	public ZmqSendException(String message, Throwable cause) {
		super(message, cause);
	}

	public ZmqSendException(String message) {
		super(message);
	}

	public ZmqSendException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

}
