package com.nec.biomatcher.comp.zmq;

import com.nec.biomatcher.comp.zmq.ZmqPushConnection.ZmqPushSocket;

public class ZmqPushSocketRef {
	public ZmqPushSocket zmqPushSocket;
}
