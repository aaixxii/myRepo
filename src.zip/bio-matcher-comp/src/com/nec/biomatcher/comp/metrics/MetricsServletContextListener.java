package com.nec.biomatcher.comp.metrics;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.apache.log4j.Logger;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.servlets.MetricsServlet;
import com.google.common.base.MoreObjects;

/**
 * The listener interface for receiving metricsServletContext events. The class
 * that is interested in processing a metricsServletContext event implements
 * this interface, and the object created with that class is registered with a
 * component using the component's <code>addMetricsServletContextListener<code>
 * method. When the metricsServletContext event occurs, that object's
 * appropriate method is invoked.
 *
 * @see MetricsServletContextEvent
 */
public class MetricsServletContextListener extends MetricsServlet.ContextListener {
	private static final Logger logger = Logger.getLogger(MetricsServletContextListener.class);

	@Override
	protected MetricRegistry getMetricRegistry() {
		return MetricsUtil.METRICS_REGISTRY;
	}

	@Override
	protected String getJsonpCallbackParameter() {
		logger.info("In MetricsServletContextListener.getJsonpCallbackParameter called");
		return "jsonpCallback";
	}

	@Override
	public void contextInitialized(ServletContextEvent event) {
		logger.info("In MetricsServletContextListener.contextInitialized called");
		final ServletContext context = event.getServletContext();
		context.setAttribute(MetricsServlet.CALLBACK_PARAM,
				MoreObjects.firstNonNull(getJsonpCallbackParameter(), "jsonpCallback"));

		super.contextInitialized(event);

	}
}
