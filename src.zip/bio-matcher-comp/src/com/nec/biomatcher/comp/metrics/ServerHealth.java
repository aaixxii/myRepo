package com.nec.biomatcher.comp.metrics;

import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;

/**
 * The Class ServerHealth.
 */
public class ServerHealth {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(ServerHealth.class);

	/**
	 * Register free memory gauge.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 */
	public static void registerFreeMemoryGauge(BioComponentType componentType, String serverId) {
		MetricsUtil.registerGauge(componentType, serverId, "FREE_MEMORY", () -> {
			double freeMemory = Long.valueOf(Runtime.getRuntime().freeMemory()).doubleValue() / 1024 / 1024 / 1024;
			return Math.round(freeMemory * 100.0) / 100.0;
		});
	}

	/**
	 * Register free space gauge.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 * @param path
	 *            the path
	 */
	public static void registerFreeSpaceGauge(BioComponentType componentType, String serverId, String measurement,
			Path path) {

		MetricsUtil.registerCachedGauge(componentType, serverId, measurement, 3, TimeUnit.MINUTES,
				(Supplier<Double>) () -> {
					try {
						double usableSpace = Long.valueOf(Files.getFileStore(path).getUsableSpace()).doubleValue();
						if (usableSpace > 0) {
							usableSpace = Math.round((usableSpace / 1024 / 1024 / 1024) * 100.0) / 100.0;
						}
						return usableSpace;
					} catch (Throwable th) {
						logger.error("Error in registerFreeSpaceGauge.getUsableSpace for path: " + path + " : "
								+ th.getMessage(), th);
						return -1D;
					}
				});
	}

	/**
	 * Register system load gauge.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 */
	public static void registerSystemLoadGauge(BioComponentType componentType, String serverId) {

		MetricsUtil.registerGauge(componentType, serverId, "SYSTEM_LOAD", (Supplier<Double>) () -> {
			try {
				double systemLoad = ManagementFactory.getOperatingSystemMXBean().getSystemLoadAverage();
				if (systemLoad > 0) {
					systemLoad = Math.round(systemLoad * 100.0) / 100.0;
				}
				return systemLoad;
			} catch (Throwable th) {
				logger.error("Error in registerSystemLoadGauge.getSystemLoadAverage: " + th.getMessage());
				return -1D;
			}
		});
	}

}
