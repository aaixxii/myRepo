package com.nec.biomatcher.comp.metrics;

import static com.codahale.metrics.MetricRegistry.name;

import java.io.Closeable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.function.Supplier;

import com.codahale.metrics.CachedGauge;
import com.codahale.metrics.Counter;
import com.codahale.metrics.ExponentiallyDecayingReservoir;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Reservoir;
import com.codahale.metrics.health.HealthCheckRegistry;
import com.google.common.util.concurrent.Striped;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;

/**
 * The Class MetricsUtil.
 */
public class MetricsUtil {

	/** The Constant METRICS_REGISTRY. */
	public static final MetricRegistry METRICS_REGISTRY = new MetricRegistry();
	// public static final MetricRegistry METRICS_REGISTRY = new
	// CustomMetricRegistry();

	/** The Constant HEALTH_CHECK_REGISTRY. */
	public static final HealthCheckRegistry HEALTH_CHECK_REGISTRY = new HealthCheckRegistry();

	/** The Constant stripedLock. */
	private static final Striped<Lock> stripedLock = Striped.lazyWeakLock(512);

	/** The Constant DOT. */
	private static final String DOT = ".";

	/**
	 * Register gauge.
	 *
	 * @param <T>
	 *            the generic type
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 * @param supplier
	 *            the supplier
	 */
	public static final <T> void registerGauge(BioComponentType componentType, String serverId, String measurement,
			Supplier<T> supplier) {
		String key = buildKey(componentType, serverId, measurement);
		registerGauge(key, supplier);
	}

	public static final <T> void registerGauge(String key, Supplier<T> supplier) {
		Lock lock = stripedLock.get(key);
		lock.lock();
		try {
			if (!METRICS_REGISTRY.getGauges().containsKey(key)) {
				METRICS_REGISTRY.register(key, new Gauge<T>() {
					@Override
					public T getValue() {
						return supplier.get();
					}
				});
			}
		} finally {
			lock.unlock();
		}
	}

	public static final void registerMetric(Metric metric, String name, String... names) {
		String key = name(name, names);
		METRICS_REGISTRY.register(key, metric);
	}

	/**
	 * Register cached gauge.
	 *
	 * @param <T>
	 *            the generic type
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 * @param timeout
	 *            the timeout
	 * @param timeoutUnit
	 *            the timeout unit
	 * @param supplier
	 *            the supplier
	 */
	public static final <T> void registerCachedGauge(BioComponentType componentType, String serverId,
			String measurement, long timeout, TimeUnit timeoutUnit, Supplier<T> supplier) {
		String key = buildKey(componentType, serverId, measurement);
		stripedLock.get(key).lock();
		try {
			if (!METRICS_REGISTRY.getGauges().containsKey(key)) {
				METRICS_REGISTRY.register(key, new CachedGauge<T>(timeout, timeoutUnit) {
					protected T loadValue() {
						return supplier.get();
					}
				});
			}
		} finally {
			stripedLock.get(key).unlock();
		}
	}

	/**
	 * Meter.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 */
	public static void meter(BioComponentType componentType, String serverId, String measurement) {
		METRICS_REGISTRY.meter(buildKey(componentType, serverId, measurement)).mark();
	}

	/**
	 * Inc counter.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 */
	public static void incCounter(BioComponentType componentType, String serverId, String measurement) {
		METRICS_REGISTRY.counter(buildKey(componentType, serverId, measurement)).inc();
	}

	/**
	 * Dec counter.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 */
	public static void decCounter(BioComponentType componentType, String serverId, String measurement) {
		METRICS_REGISTRY.counter(buildKey(componentType, serverId, measurement)).dec();
	}

	public static void setCounterValue(BioComponentType componentType, String serverId, String measurement,
			long value) {
		Counter counter = METRICS_REGISTRY.counter(buildKey(componentType, serverId, measurement));

		long count = counter.getCount();
		if (count == value) {
			return;
		} else if (count > value) {
			counter.dec(count - value);
		} else if (count < value) {
			counter.inc(value - count);
		}
	}

	/**
	 * Try to reset the counter to 0, Might not result is proper resetting if
	 * some other thread changes the counter
	 * 
	 * @param componentType
	 * @param serverId
	 * @param measurement
	 */
	public static void restCounter(BioComponentType componentType, String serverId, String measurement) {
		Counter counter = METRICS_REGISTRY.counter(buildKey(componentType, serverId, measurement));
		long count = counter.getCount();
		if (count > 0) {
			counter.dec(count);
		} else if (count < 0) {
			counter.inc(-1 * count);
		}
	}

	/**
	 * Time.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 * @return the closeable
	 */
	public static Closeable time(BioComponentType componentType, String serverId, String measurement) {
		return METRICS_REGISTRY.timer(buildKey(componentType, serverId, measurement)).time();
	}

	public static void time(BioComponentType componentType, String serverId, String measurement, long duration,
			TimeUnit unit) {
		METRICS_REGISTRY.timer(buildKey(componentType, serverId, measurement)).update(duration, unit);
	}

	public static void time(String key, long duration, TimeUnit unit) {
		METRICS_REGISTRY.timer(key).update(duration, unit);
	}

	public static void checkAndTime(BioComponentType componentType, String serverId, String measurement, long duration,
			TimeUnit unit) {
		if (duration > 0) {
			METRICS_REGISTRY.timer(buildKey(componentType, serverId, measurement)).update(duration, unit);
		}
	}

	public static void checkAndTime(String key, long duration, TimeUnit unit) {
		if (duration > 0) {
			METRICS_REGISTRY.timer(key).update(duration, unit);
		}
	}

	/**
	 * Histogram.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 * @param value
	 *            the value
	 */
	public static void histogram(BioComponentType componentType, String serverId, String measurement, long value) {
		String key = buildKey(componentType, serverId, measurement);

		Histogram histogram = METRICS_REGISTRY.getHistograms().get(key);
		if (histogram == null) {
			stripedLock.get(key).lock();
			try {
				histogram = METRICS_REGISTRY.getHistograms().get(key);
				if (histogram == null) {
					Reservoir reservoir = new ExponentiallyDecayingReservoir();
					histogram = new Histogram(reservoir);
					METRICS_REGISTRY.register(key, histogram);
				}
			} finally {
				stripedLock.get(key).unlock();
			}
		}
		histogram.update(value);
	}

	/**
	 * Builds the key.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverId
	 *            the server id
	 * @param measurement
	 *            the measurement
	 * @return the string
	 */
	private static final String buildKey(final BioComponentType componentType, final String serverId,
			final String measurement) {
		if (measurement == null) {
			throw new IllegalArgumentException("Metric measurement is not supplied while buildKey, componentType: "
					+ componentType + ", serverId: " + serverId);
		}

		StringBuilder sb = new StringBuilder();

		String appendDot = "";
		if (componentType != null) {
			sb.append("componentType").append(DOT).append(componentType.name());
			appendDot = DOT;
		}

		if (serverId != null) {
			sb.append(appendDot).append("serverId").append(DOT).append(serverId);
			appendDot = DOT;
		}

		sb.append(appendDot).append(measurement);

		return sb.toString();
	}
}
