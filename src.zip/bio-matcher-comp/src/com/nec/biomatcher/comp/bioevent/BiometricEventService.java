package com.nec.biomatcher.comp.bioevent;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import com.google.common.collect.RangeSet;
import com.nec.biomatcher.comp.bioevent.dataAccess.BiometricEventCriteria;
import com.nec.biomatcher.comp.bioevent.exception.BiometricEventServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;
import com.nec.biomatcher.spec.transfer.biometrics.DeleteBiometricEventDto;
import com.nec.biomatcher.spec.transfer.biometrics.InsertBiometricEventDto;
import com.nec.biomatcher.spec.transfer.biometrics.UpdateBiometricEventUserFlagDto;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;

/**
 * The Interface BiometricEventService.
 */
public interface BiometricEventService {

	public List<BiometricEventInfo> insertEvent(InsertBiometricEventDto insertBiometricEventDto, String sourceSiteId)
			throws BiometricEventServiceException;

	public List<BiometricEventInfo> deleteEvent(DeleteBiometricEventDto deleteBiometricEventDto, String sourceSiteId)
			throws BiometricEventServiceException;

	public List<BiometricEventInfo> updateUserFlag(UpdateBiometricEventUserFlagDto updateBiometricEventUserFlagDto,
			String sourceSiteId) throws BiometricEventServiceException;

	public List<BiometricEventInfo> assignDataVersionToBiometricEvents(Integer segmentId, boolean isConversionMode)
			throws BiometricEventServiceException;

	public int checkAndResetPendingSyncEventDataVersion(Integer segmentId, long latestMatcherNodeSegmentVersionId,
			AtomicBoolean notifySyncCompletedFlag, long previousSyncCompMatcherNodeSegmentVersionId)
			throws BiometricEventServiceException;

	public void notifySyncCompleted(Integer segmentId, long lastSyncVersion) throws BiometricEventServiceException;

	public int notifySyncCompleted(Long biometricId, Long dataVersion, BiometricEventPhase currentPhase,
			BiometricEventPhase newPhase) throws BiometricEventServiceException;

	public void notifySyncCompleted(Integer segmentId, RangeSet<Long> segmentVersionRangeSet,
			Set<Long> corruptedSegmentVersionIdList) throws BiometricEventServiceException;

	public void notifyCorruptedBiometricIdList(List<Long> corruptedBiometricIdList)
			throws BiometricEventServiceException;

	public void notifyCorruptedEventsByDataVersion(Integer segmentId, List<Long> corruptedDataVersionIdList)
			throws BiometricEventServiceException;

	public BiometricEventInfo getBiometricEventInfo(Long biometricId) throws BiometricEventServiceException;

	public BiometricEventInfo getBiometricEventInfoByExternalId(String externalId, String eventId, Integer binId)
			throws BiometricEventServiceException;

	public BiometricEventInfo getLatestBiometricEventInfoByExternalId(String externalId, Integer binId)
			throws BiometricEventServiceException;

	public List<BiometricEventInfo> getBiometricEventInfoListByExternalId(String externalId, String eventId,
			Integer binId) throws BiometricEventServiceException;

	public List<BiometricEventInfo> getBiometricEventInfoListForVersioning(Integer segmentId, int maxRecords)
			throws BiometricEventServiceException;

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentId(Integer segmentId, int maxRecords)
			throws BiometricEventServiceException;

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentId(Integer segmentId, Long afterBiometricId,
			Long afterDataVersion, int maxRecords) throws BiometricEventServiceException;

	/**
	 * Gets the biometric event info list by bin id.
	 *
	 * @param binId
	 *            the bin id
	 * @param dataVersion
	 *            the data version
	 * @param maxRecords
	 *            the max records
	 * @return the biometric event info list by bin id
	 * @throws BiometricEventServiceException
	 *             the biometric event service exception
	 */
	public List<BiometricEventInfo> getBiometricEventInfoListByBinId(Integer binId, Long dataVersion, int maxRecords)
			throws BiometricEventServiceException;

	/**
	 * Gets the biometric event info list by segment id.
	 *
	 * @param segmentId
	 *            the segment id
	 * @param dataVersion
	 *            the data version
	 * @param maxRecords
	 *            the max records
	 * @return the biometric event info list by segment id
	 * @throws BiometricEventServiceException
	 *             the biometric event service exception
	 */
	public List<BiometricEventInfo> getBiometricEventInfoListBySegmentIdForSync(Integer segmentId, Long dataVersion,
			int maxRecords) throws BiometricEventServiceException;

	public List<BiometricEventInfo> getBiometricEventInfoListBySegmentIdForRemoteSync(Integer segmentId,
			Long dataVersion, String siteId, BiometricEventStatus biometricEventStatus, int maxRecords)
			throws BiometricEventServiceException;

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentId(Integer segmentId, Long afterBiometricId,
			int maxRecords) throws BiometricEventServiceException;

	public List<BiometricEventInfo> getBiometricEventInfoListBySegmentIdVersionRange(Integer segmentId,
			Long fromDataVersion, Long toDataVersion) throws BiometricEventServiceException;

	public List<BiometricEventInfo> getBiometricEventInfoListBySegmentIdVersionRange(Integer segmentId,
			Long fromDataVersion, Long toDataVersion, BiometricEventPhase phase, int maxRecords)
			throws BiometricEventServiceException;

	public List<BiometricEventInfo> getBiometricEventInfoListBySegmentIdVersionList(Integer segmentId,
			List<Long> dataVersionList, BiometricEventPhase phase) throws BiometricEventServiceException;

	/**
	 * Gets the biometric event info list for segmentation.
	 *
	 * @param binId
	 *            the bin id
	 * @param maxRecords
	 *            the max records
	 * @return the biometric event info list for segmentation
	 * @throws BiometricEventServiceException
	 *             the biometric event service exception
	 */
	public List<BiometricEventInfo> getBiometricEventInfoListForSegmentation(Integer binId, int maxRecords)
			throws BiometricEventServiceException;

	public Map<Integer, Long> getCurrentEventSegmentVersionMap() throws BiometricEventServiceException;

	public Long getMaxEventSegmentVersionBySegmentId(Integer segmentId) throws BiometricEventServiceException;

	public PageResult<BiometricEventInfo> getBiometricEventInfoList(BiometricEventCriteria biometricEventCriteria,
			PageRequest pageRequest) throws BiometricEventServiceException;

}
