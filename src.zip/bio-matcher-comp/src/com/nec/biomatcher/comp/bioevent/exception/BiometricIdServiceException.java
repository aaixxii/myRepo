package com.nec.biomatcher.comp.bioevent.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BiometricIdServiceException.
 */
public class BiometricIdServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new biometric id service exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BiometricIdServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new biometric id service exception.
	 *
	 * @param message
	 *            the message
	 */
	public BiometricIdServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new biometric id service exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BiometricIdServiceException(Throwable cause) {
		super(cause);
	}

}
