package com.nec.biomatcher.comp.lobstream.util;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Stream;

import org.apache.log4j.Logger;

import com.google.common.hash.HashFunction;
import com.google.common.hash.Hashing;
import com.google.common.primitives.Longs;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.comp.util.JobIdGenerator;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.DateUtil;
import com.nec.biomatcher.core.framework.common.FileUtils;
import com.nec.biomatcher.core.framework.common.HostnameUtil;

/**
 * Util class for file system related operations like read, write, etc.
 * 
 */
public class LobFileSystemUtil {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(LobFileSystemUtil.class);

	private static final AtomicInteger writeConcurrencyCounter = new AtomicInteger();
	private static final AtomicInteger readConcurrencyCounter = new AtomicInteger();

	private static long lobFileRecheckDelayMilli = 100;

	/**
	 * Private constructor to prevent instantiating this class.
	 */
	private LobFileSystemUtil() {

	}

	public static void setLobFileRecheckDelayMilli(long lobFileRecheckDelayMilli) {
		LobFileSystemUtil.lobFileRecheckDelayMilli = lobFileRecheckDelayMilli;
	}

	/**
	 * Builds the lob stream file.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobType
	 *            the lob type
	 * @param lobStreamStoragePath
	 *            the lob stream storage path
	 * @return the file
	 */
	public static final File buildLobStreamFile(String lobId, String lobType, File lobStreamStoragePath) {
		Calendar cal = Calendar.getInstance();
		return Paths.get(lobStreamStoragePath.getAbsolutePath(), buildLobStreamFolderPath(lobId, cal),
				lobType == null ? lobId : (lobId + "." + lobType)).toFile();
	}

	/**
	 * Write to file.
	 *
	 * @param lobData
	 *            the lob data
	 * @param lobFile
	 *            the lob file
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static final void writeToFile(byte[] lobData, File lobFile) throws IOException {
		writeConcurrencyCounter.incrementAndGet();
		long startTimestampMilli = System.currentTimeMillis();
		int lobDataLength = 0;
		try {
			lobDataLength = lobData.length;
			lobFile.getParentFile().mkdirs();
			Files.write(lobFile.toPath(), lobData);
		} catch (Throwable th) {
			logger.error("Error in writeToFile: lobFile: " + lobFile.getAbsolutePath() + " : " + th.getMessage(), th);
			throw th;
		} finally {
			writeConcurrencyCounter.decrementAndGet();
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 100 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info("In writeToFile: TimeTakenMilli: " + timeTakenMilli + ", lobFile: " + lobFile
						+ ", lobDataLength: " + lobDataLength + ", readConcurrency: " + readConcurrencyCounter.get()
						+ ", writeConcurrency: " + writeConcurrencyCounter.get());
			}
		}
	}

	/**
	 * Gets the lob data.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobType
	 *            the lob type
	 * @param lobStreamStoragePath
	 *            the lob stream storage path
	 * @param retentionHours
	 *            the retention hours
	 * @return the lob data
	 * @throws LobImageNotFoundException
	 *             the lob image not found exception
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public static final byte[] getLobData(String lobId, String lobType, File lobStreamStoragePath, int retentionHours)
			throws LobImageNotFoundException, LobImageServiceException {
		if (logger.isTraceEnabled())
			logger.trace("[getLobData] name: " + lobId + ", lobType: " + lobType);
		readConcurrencyCounter.incrementAndGet();
		long startTimestampMilli = System.currentTimeMillis();
		int lobDataLength = 0;
		Path lobFilePath = null;
		Path firstCheckLobFilePath = null;
		try {
			final String baseAbsolutePath = lobStreamStoragePath.getAbsolutePath();
			final String lobFolderPart = buildLobStreamFolderLobPart(lobId);
			final String fileName = lobType == null ? lobId : (lobId + "." + lobType);
			final Calendar cal = Calendar.getInstance();

			for (int i = 0; i <= retentionHours; i++) {
				if (i > 0) {
					cal.add(Calendar.HOUR_OF_DAY, -1);
				}

				lobFilePath = Paths.get(baseAbsolutePath, "lobs", buildLobStreamFolderDatePart(cal), lobFolderPart,
						fileName);

				if (firstCheckLobFilePath == null) {
					firstCheckLobFilePath = lobFilePath;
				}

				if (Files.exists(lobFilePath)) {
					byte[] lobData = Files.readAllBytes(lobFilePath);
					lobDataLength = lobData.length;
					return lobData;
				} else {
					if (logger.isTraceEnabled())
						logger.trace("In getLobData: Cannot find lobFile: " + lobFilePath + ", loopCount: " + i);
				}
			}

			/**
			 * This re check is for overcoming issue, where lob is not
			 * immediately visible on other mounts
			 */
			if (firstCheckLobFilePath != null) {
				Uninterruptibles.sleepUninterruptibly(lobFileRecheckDelayMilli, TimeUnit.MILLISECONDS);
				if (Files.exists(firstCheckLobFilePath)) {
					logger.info("In getLobData: Found the lob file after sleeping for " + lobFileRecheckDelayMilli
							+ " milliseconds, firstCheckLobFilePath: " + firstCheckLobFilePath);
					byte[] lobData = Files.readAllBytes(firstCheckLobFilePath);
					lobDataLength = lobData.length;
					return lobData;
				} else {
					logger.warn("In getLobData: Cannot find firstCheckLobFilePath: " + firstCheckLobFilePath
							+ " after waiting for 100 milliseconds");
				}
			}

			throw new LobImageNotFoundException("Lob image is not found for lobId: " + lobId
					+ ", firstCheckLobFilePath: " + firstCheckLobFilePath + ", lobFilePath: " + lobFilePath);
		} catch (LobImageNotFoundException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new LobImageServiceException("Error in getLobData: lobId: " + lobId + ", firstCheckLobFilePath: "
					+ firstCheckLobFilePath + ", lobFilePath: " + lobFilePath + " : " + th.getMessage(), th);
		} finally {
			readConcurrencyCounter.decrementAndGet();
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 200 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info("In getLobData: TimeTakenMilli: " + timeTakenMilli + ", lobFile: "
						+ lobFilePath + ", lobDataLength: " + lobDataLength + ", readConcurrency: "
						+ readConcurrencyCounter.get() + ", writeConcurrency: " + writeConcurrencyCounter.get());
			}
		}
	}

	/**
	 * Delete lob.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobType
	 *            the lob type
	 * @param lobStreamStoragePath
	 *            the lob stream storage path
	 * @param retentionHours
	 *            the retention hours
	 * @return true, if successful
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public static final boolean deleteLob(String lobId, String lobType, File lobStreamStoragePath, int retentionHours)
			throws LobImageServiceException {
		logger.trace("[deleteLob] name: " + lobId + ", lobType: " + lobType);
		Path lobFilePath = null;
		try {
			final String baseAbsolutePath = lobStreamStoragePath.getAbsolutePath();
			final String lobFolderPart = buildLobStreamFolderLobPart(lobId);
			final String fileName = lobType == null ? lobId : (lobId + "." + lobType);

			final Calendar cal = Calendar.getInstance();
			for (int i = 0; i <= retentionHours; i++) {
				if (i > 0) {
					cal.add(Calendar.HOUR_OF_DAY, -1);
				}

				lobFilePath = Paths.get(baseAbsolutePath, "lobs", buildLobStreamFolderDatePart(cal), lobFolderPart,
						fileName);
				boolean deletedFlag = Files.deleteIfExists(lobFilePath);
				if (deletedFlag) {
					return true;
				}
			}

			return false;
		} catch (Throwable th) {
			throw new LobImageServiceException("Error in deleteLob: lobId: " + lobId + ", lobType: " + lobType
					+ ", lobFilePath: " + lobFilePath + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Delete lobs by lob id.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobStreamStoragePath
	 *            the lob stream storage path
	 * @param retentionHours
	 *            the retention hours
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public static final void deleteLobsByLobId(String lobId, File lobStreamStoragePath, int retentionHours)
			throws LobImageServiceException {
		logger.trace("[deleteLobsByLobId] lobId: " + lobId);
		try {
			final Predicate<Path> predicate = (path) -> path.getFileName().toString().startsWith(lobId);

			final String baseAbsolutePath = lobStreamStoragePath.getAbsolutePath();
			final String lobFolderPart = buildLobStreamFolderLobPart(lobId);

			final Calendar cal = Calendar.getInstance();
			for (int i = 0; i <= retentionHours; i++) {
				if (i > 0) {
					cal.add(Calendar.HOUR_OF_DAY, -1);
				}
				AtomicBoolean foundFlag = new AtomicBoolean(false);
				Path baseLobFilePath = Paths.get(baseAbsolutePath, "lobs", buildLobStreamFolderDatePart(cal),
						lobFolderPart);
				if (Files.isDirectory(baseLobFilePath)) {
					try (Stream<Path> dirStream = Files.list(baseLobFilePath)) {
						try (Stream<Path> filteredStream = dirStream.filter(predicate)) {
							filteredStream.forEach((path) -> {
								try {
									foundFlag.set(true);
									Files.deleteIfExists(path);
								} catch (Throwable th) {
									logger.error(
											"Error deleting lobFile : " + path.toString() + " : " + th.getMessage(),
											th);
								}
							});
						}
					}
				}

				if (foundFlag.get()) {
					break;
				}
			}
		} catch (Throwable th) {
			throw new LobImageServiceException("Error in deleteLobsByLobId: lobId: " + lobId + " : " + th.getMessage(),
					th);
		}
	}

	/**
	 * Perform housekeeping.
	 *
	 * @param lobStreamStoragePath
	 *            the lob stream storage path
	 * @param retentionHours
	 *            the retention hours
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public static final void performHousekeeping(File lobStreamStoragePath, int retentionHours)
			throws LobImageServiceException {
		logger.info("[performHousekeeping] lobStreamStoragePath: " + lobStreamStoragePath + ", retentionHours: "
				+ retentionHours);
		long startTimestamp = System.currentTimeMillis();
		OutputStream hkLockStream = tryLockForHouseKeeping(lobStreamStoragePath);
		if (hkLockStream == null) {
			CommonLogger.STATUS_LOG.info("[performHousekeeping] lobStreamStoragePath: " + lobStreamStoragePath
					+ ": Unable to acquire housekeeping lock");
			return;
		}
		try {
			String baseAbsolutePath = lobStreamStoragePath.getAbsolutePath();

			Calendar retentionCal = Calendar.getInstance();
			retentionCal.add(Calendar.HOUR_OF_DAY, -retentionHours);

			int maxLoopCount = Math.max(5, retentionHours);
			// Delete Hourly lob data older than retention period
			for (int i = 0; i < maxLoopCount; i++) {
				retentionCal.add(Calendar.HOUR_OF_DAY, -1);

				Path deleteFolderPath = Paths.get(baseAbsolutePath, "lobs", buildLobStreamFolderDatePart(retentionCal));
				if (Files.isDirectory(deleteFolderPath)) {
					FileUtils.deleteFolderQuietly(deleteFolderPath);
				}
			}

			// Delete daily lob data older than retention period, just in case
			// if some stale lob folders are not deleted earlier run
			for (int i = 0; i < 3; i++) {
				retentionCal.add(Calendar.DAY_OF_YEAR, -1);

				Path deleteFolderPath = Paths.get(baseAbsolutePath, "lobs",
						buildLobStreamFolderWithDayPart(retentionCal));
				if (Files.isDirectory(deleteFolderPath)) {
					FileUtils.deleteFolderQuietly(deleteFolderPath);
				}
			}

		} catch (Throwable th) {
			throw new LobImageServiceException("Error in performHousekeeping: lobStreamStoragePath: "
					+ lobStreamStoragePath + ", retentionHours: " + retentionHours + " : " + th.getMessage(), th);
		} finally {
			releaseHouseKeepingLock(hkLockStream);
			logger.info("Timetaken for performHousekeeping: " + (System.currentTimeMillis() - startTimestamp)
					+ ", lobStreamStoragePath: " + lobStreamStoragePath);
		}
	}

	private static OutputStream tryLockForHouseKeeping(File lobStreamStoragePath) {
		Path lockFilePath = Paths.get(lobStreamStoragePath.getAbsolutePath(), "lobs", "lob_housekeeping.lock");
		try {
			lockFilePath.getParent().toFile().mkdirs();
			OutputStream hkLockStream = Files.newOutputStream(lockFilePath);
			hkLockStream.write(("Lock acquired by " + HostnameUtil.getHostname() + " at "
					+ DateUtil.parseDate(new Date(), DateUtil.FORMAT_YYYY_MM_DD_HH_MM_SS) + System.lineSeparator())
							.getBytes());
			return hkLockStream;
		} catch (Throwable th) {
			logger.error("Error in tryLockForHouseKeeping: lockFilePath: " + lockFilePath + " : " + th.getMessage(),
					th);
		}
		return null;
	}

	private static void releaseHouseKeepingLock(OutputStream hkLockStream) {
		if (hkLockStream != null) {
			try {
				try {
					hkLockStream.write(("Lock released by " + HostnameUtil.getHostname() + " at "
							+ DateUtil.parseDate(new Date(), DateUtil.FORMAT_YYYY_MM_DD_HH_MM_SS)
							+ System.lineSeparator()).getBytes());
				} finally {
					hkLockStream.close();
				}
			} catch (Throwable th) {
			}
		}
	}

	/**
	 * Check lob file exists.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobType
	 *            the lob type
	 * @param lobStreamStoragePath
	 *            the lob stream storage path
	 * @param retentionHours
	 *            the retention hours
	 * @return true, if successful
	 */
	public static final boolean checkLobFileExists(String lobId, String lobType, File lobStreamStoragePath,
			int retentionHours) {
		final Calendar cal = Calendar.getInstance();
		final String baseAbsolutePath = lobStreamStoragePath.getAbsolutePath();
		final String lobFolderPart = buildLobStreamFolderLobPart(lobId);
		final String fileName = lobType == null ? lobId : (lobId + "." + lobType);

		for (int i = 0; i <= retentionHours; i++) {
			if (i > 0) {
				cal.add(Calendar.HOUR_OF_DAY, -1);
			}

			Path lobFilePath = Paths.get(baseAbsolutePath, "lobs", buildLobStreamFolderDatePart(cal), lobFolderPart,
					fileName);
			if (Files.exists(lobFilePath)) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Generated the image file path based on <code>storagePath</code> &
	 * <code>lobId</code>
	 * <p/>
	 * Based on <code>lobId</code> a hierarchical folder structure will be
	 * created with every two digits as a new folder leaving the last three
	 * digits.
	 * 
	 * <pre>
	 * For example: Lets say storagePath is '/home/itf'
	 * If lobId = 999, lob image path will be '/home/itf/'
	 * If lobId = 1000,
	 *      Leaving the last 3 digits we are left with '1'. Folder name is always 2 digits,
	 *      so prepend '0'. So image file path will be '/home/itf/01/'
	 * </pre>
	 *
	 * @param lobId
	 *            record identifier
	 * @param cal
	 *            the cal
	 * @return the lob image directory
	 * @throws IllegalArgumentException
	 *             if the base directory doesn't exist
	 */
	public static final String buildLobStreamFolderPathOldDepricated(String lobId, Calendar cal) {
		// Keeping this method just for reference

		StringBuilder pathBuilder = new StringBuilder();

		pathBuilder.append(cal.get(Calendar.YEAR)).append(File.separator).append(cal.get(Calendar.DAY_OF_YEAR))
				.append(File.separator);

		String lobIdStr = getUUIDHashCode(lobId);
		// Say for example lobId is 1000 and we remove the last 3 digits i.e
		// '000' from the lobId,
		// we will be left with '1'. We need to left pad '1' with '0' so that
		// the directory name becomes 2 digits - '01'.
		// So, when length of lobIdStr is an even number, we will have to
		// prepend 0 so that we will able
		// to split the entire string into set of 2 digit characters
		if (lobIdStr.length() % 2 != 0) {
			lobIdStr = "0" + lobIdStr;
		}

		char[] pathArr = lobIdStr.toCharArray();
		for (int i = 0; i < pathArr.length; i += 2) {
			pathBuilder.append(pathArr[i]).append(pathArr[i + 1]).append(File.separator);
		}

		return pathBuilder.toString();
	}

	public static final String buildLobStreamFolderPath(String lobId, Calendar cal) {
		return Paths.get("lobs", buildLobStreamFolderDatePart(cal), buildLobStreamFolderLobPart(lobId)).toString();
	}

	public static final String buildLobStreamFolderLobPart(String lobId) {
		String lobHash = getUUIDHashCode(lobId);

		StringBuilder pathBuilder = new StringBuilder();
		if (lobHash.length() > 2) {
			char[] pathArr = null;

			int padLength = (lobHash.length() - 2) % 3;
			switch (padLength) {
			case 1:
				pathArr = ("00" + lobHash).toCharArray();
				break;
			case 2:
				pathArr = ("0" + lobHash).toCharArray();
				break;
			default:
				pathArr = lobHash.toCharArray();
			}

			for (int i = 0; i < pathArr.length - 2; i += 3) {
				pathBuilder.append(pathArr[i]).append(pathArr[i + 1])
						// .append(pathArr[i + 2]) //Commented to create more
						// collision so less number of folders are created
						.append(File.separator);
			}
		}
		return pathBuilder.toString();
	}

	public static final String buildLobStreamFolderDatePart(Calendar cal) {
		StringBuilder pathBuilder = new StringBuilder().append(cal.get(Calendar.DAY_OF_YEAR)).append(File.separator)
				.append(String.valueOf(cal.get(Calendar.HOUR_OF_DAY))).append(File.separator);

		return pathBuilder.toString();
	}

	public static final String buildLobStreamFolderWithDayPart(Calendar cal) {
		StringBuilder pathBuilder = new StringBuilder().append(cal.get(Calendar.DAY_OF_YEAR)).append(File.separator);

		return pathBuilder.toString();
	}

	/**
	 * Gets the UUID hash code. Objective of using hash is to increase the id
	 * collision, so less number of folders are created
	 * 
	 * @param lobId
	 *            the lob id
	 * @return the UUID hash code
	 */
	private static String getUUIDHashCode(String lobId) {
		if (lobId.startsWith(JobIdGenerator.DEFAULT_PREFIX)) {
			HashFunction hashFunction = Hashing.murmur3_32();
			long hash = hashFunction.newHasher().putString(lobId, Charset.defaultCharset()).hash().asInt();
			return Long.toHexString(Math.abs(hash)).toUpperCase();
		}

		if (lobId.length() < 36) {
			Long numberVal = Longs.tryParse(lobId);
			if (numberVal != null && numberVal > 0) {
				return Long.toHexString(numberVal).toUpperCase();
			} else {
				return lobId;
			}
		}

		UUID uuid = UUID.fromString(lobId);

		/**
		 * This murmur3_128 hash is too unique and very big value, this is not
		 * causing the collision, thereby too many folders are created
		 */
		/*
		 * HashFunction hashFunction = Hashing.murmur3_128(); long hash =
		 * hashFunction. newHasher() .putLong(uuid.getLeastSignificantBits())
		 * .putLong(uuid.getMostSignificantBits()) .hash().asLong(); return
		 * Long.toHexString(hash).toUpperCase();
		 */

		HashFunction hashFunction = Hashing.murmur3_32();
		long hash = hashFunction.newHasher().putLong(uuid.getLeastSignificantBits())
				.putLong(uuid.getMostSignificantBits()).hash().asInt();

		return Long.toHexString(Math.abs(hash)).toUpperCase();
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 */
	public static void main(String args[]) {
		System.out.println(Long.toHexString(Long.MAX_VALUE));
	}
}
