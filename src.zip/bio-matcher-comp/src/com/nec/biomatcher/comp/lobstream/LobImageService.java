package com.nec.biomatcher.comp.lobstream;

import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;

/**
 * The Interface LobImageService.
 */
public interface LobImageService {

	/**
	 * Creates the lob.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobData
	 *            the lob data
	 * @param lobType
	 *            the lob type
	 * @return the string
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public String createLob(String lobId, byte[] lobData, String lobType) throws LobImageServiceException;

	/**
	 * Creates the lob.
	 *
	 * @param lobData
	 *            the lob data
	 * @param lobType
	 *            the lob type
	 * @return the string
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public String createLob(byte[] lobData, String lobType) throws LobImageServiceException;

	/**
	 * Gets the lob data.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobType
	 *            the lob type
	 * @return the lob data
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 * @throws LobImageNotFoundException
	 *             the lob image not found exception
	 */
	public byte[] getLobData(String lobId, String lobType) throws LobImageServiceException, LobImageNotFoundException;

	/**
	 * Check lob exists.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobType
	 *            the lob type
	 * @return true, if successful
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public boolean checkLobExists(String lobId, String lobType) throws LobImageServiceException;

	/**
	 * Delete lob.
	 *
	 * @param lobId
	 *            the lob id
	 * @param lobType
	 *            the lob type
	 * @return true, if successful
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public boolean deleteLob(String lobId, String lobType) throws LobImageServiceException;

	/**
	 * Delete lobs by lob id.
	 *
	 * @param lobId
	 *            the lob id
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public void deleteLobsByLobId(String lobId) throws LobImageServiceException;

	public void performLobHousekeeping();
}
