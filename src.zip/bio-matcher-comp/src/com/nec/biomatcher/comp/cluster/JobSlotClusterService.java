package com.nec.biomatcher.comp.cluster;

import java.io.Closeable;
import java.net.InetSocketAddress;
import java.net.URI;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.IntStream;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.common.base.Function;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.Uninterruptibles;
import com.hazelcast.config.Config;
import com.hazelcast.config.JoinConfig;
import com.hazelcast.config.NetworkConfig;
import com.hazelcast.config.TcpIpConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.ILock;
import com.hazelcast.core.IMap;
import com.hazelcast.core.IQueue;
import com.hazelcast.core.ISet;
import com.hazelcast.core.MemberAttributeEvent;
import com.hazelcast.core.MembershipEvent;
import com.hazelcast.core.MembershipListener;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.util.ServerStatusMonitor;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class JobSlotClusterService {
	private static final Logger logger = Logger.getLogger(JobSlotClusterService.class);
	private static final Logger STATUS_LOG = CommonLogger.STATUS_LOG;

	private ConcurrentValuedHashMap<String, ReadWriteLock> workerNodeLockMap = new ConcurrentValuedHashMap<>(
			workerNodeId -> new ReentrantReadWriteLock());

	private final String controllerId;
	private final BioComponentType controllerComponentType;
	private final BioComponentType workerComponentType;
	private final Function<String, Boolean> statusCheckFunction;
	private final BioMatcherConfigService bioMatcherConfigService;
	private final BioParameterService bioParameterService;

	private final HazelcastInstance hazelcastInstance;
	private final ISet<String> controllerIdSet;
	private final IQueue<String> jobSlotQueue;
	private final IMap<String, Integer> maxJobCountMap;
	private final Map<String, IAtomicLong> submitCounterMap = new HashMap<String, IAtomicLong>();

	private final CopyOnWriteArraySet<String> registeredWorkerNodeIdList = new CopyOnWriteArraySet<String>();
	private final Set<String> onlineWorkerNodeIdSet = new CopyOnWriteArraySet<String>();
	private final Set<String> offlineWorkerNodeIdSet = new CopyOnWriteArraySet<String>();

	private final MatcherFunctionControlUtil matcherFunctionControlUtil;

	public JobSlotClusterService(BioComponentType controllerComponentType, BioComponentType workerComponentType,
			Function<String, Boolean> statusCheckFunction, BioMatcherConfigService bioMatcherConfigService,
			BioParameterService bioParameterService) throws Exception {
		this.controllerComponentType = controllerComponentType;
		this.workerComponentType = workerComponentType;
		this.statusCheckFunction = statusCheckFunction;
		this.bioMatcherConfigService = bioMatcherConfigService;
		this.bioParameterService = bioParameterService;
		this.controllerId = findControllerId();

		if (controllerId != null) {
			this.hazelcastInstance = buildClusterInstance();
			this.controllerIdSet = hazelcastInstance.getSet("CONTROLLER_ID_SET_" + controllerComponentType.name());
			this.jobSlotQueue = getJobSlotQueue();
			this.maxJobCountMap = getMaxJobCountMap();
			this.matcherFunctionControlUtil = new MatcherFunctionControlUtil(controllerComponentType, controllerId,
					bioMatcherConfigService, hazelcastInstance);
			controllerIdSet.add(controllerId);
			CommonTaskScheduler.scheduleWithFixedDelay(new ClusterManagementTask(), 100, 100, TimeUnit.MILLISECONDS);
		} else {
			this.hazelcastInstance = null;
			this.controllerIdSet = null;
			this.jobSlotQueue = null;
			this.maxJobCountMap = null;
			this.matcherFunctionControlUtil = null;
		}
	}

	public HazelcastInstance getHazelcastInstance() {
		return this.hazelcastInstance;
	}

	private String findControllerId() throws Exception {
		BioServerInfo currentController = bioMatcherConfigService.getServerInfoByServerHost(HostnameUtil.getHostname(),
				HostnameUtil.getIpAddress(), controllerComponentType);

		if (currentController == null) {
			currentController = bioMatcherConfigService.getServerInfoByServerHost(HostnameUtil.LOCAL_HOSTNAME,
					HostnameUtil.LOCAL_IPADDRESS, controllerComponentType);
			if (currentController == null) {
				CommonLogger.STATUS_LOG.info("Controller of controllerComponentType: " + controllerComponentType
						+ " is not configured for ipAddress : " + HostnameUtil.getIpAddress() + " or hostname: "
						+ HostnameUtil.getHostname());
				return null;
			}
		}

		if (!BioServerState.ACTIVE.equals(currentController.getServerState())) {
			CommonLogger.STATUS_LOG.warn(controllerComponentType + " Controller state is not ACTIVE for serverId: "
					+ currentController.getServerId() + ", serverHost: " + currentController.getServerHost());
			return null;
		}

		return currentController.getServerId();
	}

	public final String getControllerId() {
		return controllerId;
	}

	private final void notifyOnline(String workerNodeId, int maxJobSlots) {
		STATUS_LOG.info("In notifyOnline: workerNodeId: " + workerNodeId + ", maxJobSlots: " + maxJobSlots);

		ServerStatusMonitor.notifyOnline(workerComponentType, workerNodeId);

		Lock lock = workerNodeLockMap.getValue(workerNodeId).writeLock();
		lock.lock();
		try {
			offlineWorkerNodeIdSet.remove(workerNodeId);
			if (!onlineWorkerNodeIdSet.contains(workerNodeId)) {
				STATUS_LOG.info("In notifyOnline: controllerId: " + controllerId + ", workerComponentType: "
						+ workerComponentType + ", workerNodeId: " + workerNodeId);
				onlineWorkerNodeIdSet.add(workerNodeId);

				ILock clusterLock = hazelcastInstance.getLock(controllerComponentType.name() + "_CLUSTER_LOCK");
				clusterLock.lock();
				try {
					// Check if already marked as online
					if (isWorkerNodeOnline(workerNodeId)) {
						STATUS_LOG
								.info("In notifyOnline: Worker node already marked as online for workerComponentType: "
										+ workerComponentType + ", workerNodeId: " + workerNodeId);
						return;
					}

					// Drain any existing slots
					while (jobSlotQueue.remove(workerNodeId))
						;

					// Reset submit counter on each controller
					for (String controllerId : controllerIdSet) {
						try {
							IAtomicLong submitCounter = getControllerWorkerNodeSubmitCounter(controllerId,
									workerNodeId);
							submitCounter.set(0);
						} catch (Throwable th) {
							logger.error("Error in notifyOnline during submitCounter.set(0): " + th.getMessage(), th);
						}
					}

					// Drain any existing slots
					while (jobSlotQueue.remove(workerNodeId))
						;

					// Mark worker node as online
					setWorkerNodeOnlineFlag(workerNodeId, true);

					// Add jobslots for worker node
					IntStream stream = IntStream.range(0, maxJobSlots);
					stream.forEach(n -> {
						boolean offerFlag = jobSlotQueue.offer(workerNodeId);
						STATUS_LOG.info("In notifyOnline: After adding jobSlotQueue for workerNodeId: " + workerNodeId
								+ ", offerFlag: " + offerFlag);
					});
					stream.close();
				} finally {
					clusterLock.unlock();
				}
			}
		} finally {
			lock.unlock();
		}

	}

	public final void notifyOffline(String workerNodeId) {
		ServerStatusMonitor.notifyOffline(workerComponentType, workerNodeId);

		Lock lock = workerNodeLockMap.getValue(workerNodeId).writeLock();
		lock.lock();
		try {
			onlineWorkerNodeIdSet.remove(workerNodeId);
			if (!offlineWorkerNodeIdSet.contains(workerNodeId)) {
				STATUS_LOG.info("In notifyOffline: controllerId: " + controllerId + ", workerComponentType: "
						+ workerComponentType + ", workerNodeId: " + workerNodeId);
				offlineWorkerNodeIdSet.add(workerNodeId);

				ILock clusterLock = hazelcastInstance.getLock(controllerComponentType.name() + "_CLUSTER_LOCK");
				clusterLock.lock();
				try {
					// Mark worker node as offline
					setWorkerNodeOnlineFlag(workerNodeId, false);

					// Reset submit counter on each controller
					for (String controllerId : controllerIdSet) {
						try {
							IAtomicLong submitCounter = getControllerWorkerNodeSubmitCounter(controllerId,
									workerNodeId);
							submitCounter.set(0);
						} catch (Throwable th) {
							logger.error("Error in notifyOffline during submitCounter.set(0): " + th.getMessage(), th);
						}
					}

					// Drain any existing slots
					while (jobSlotQueue.remove(workerNodeId)) {
						STATUS_LOG.info("In notifyOffline: After removing jobSlot for workerNodeId: " + workerNodeId);
					}
				} finally {
					clusterLock.unlock();
				}
			}
		} finally {
			lock.unlock();
		}
	}

	public final String acquireJobSlot(long acquireTimeoutMilli) throws Exception {
		try (Closeable timer = MetricsUtil.time(workerComponentType, controllerId,
				"ACQUIRE_WORKER_JOB_SLOT_TIME_TAKEN")) {
			long startTime = System.currentTimeMillis();
			do {
				long pollStartTime = System.currentTimeMillis();

				String workerNodeId = jobSlotQueue.poll(acquireTimeoutMilli, TimeUnit.MILLISECONDS);

				if (workerNodeId != null) {
					if (onlineWorkerNodeIdSet.contains(workerNodeId)) {
						long currentSubmitCounter = submitCounterMap.get(workerNodeId).incrementAndGet();

						if (logger.isDebugEnabled()) {
							logger.debug("In pollJobSlot: controllerId: " + controllerId + ", workerComponentType: "
									+ workerComponentType + ", workerNodeId: " + workerNodeId
									+ ", currentSubmitCounter: " + currentSubmitCounter);
						}

						return workerNodeId;
					} else {
						logger.warn("WorkerNode : " + workerNodeId
								+ " is not online, removing the slot for workerNodeId: " + workerNodeId);
					}
				} else {
					logger.warn("In pollJobSlot: Unable to acquire jobSlot by controllerId: " + controllerId
							+ ", controllerComponentType: " + controllerComponentType.name()
							+ " after polling, pollTimeTaken: " + (System.currentTimeMillis() - pollStartTime));
				}

				acquireTimeoutMilli = acquireTimeoutMilli - (System.currentTimeMillis() - startTime);
			} while (acquireTimeoutMilli > 0);
		}

		return null;
	}

	public final void releaseJobSlot(String workerNodeId) {
		logger.trace("In releaseJobSlot: before jobSlotQueue.offer: workerNodeId: " + workerNodeId);

		if (workerNodeId == null) {
			return;
		}

		IAtomicLong submitCounter = submitCounterMap.get(workerNodeId);
		if (submitCounter == null) {
			return;
		}

		int currentSubmitCounter = (int) submitCounter.get();
		if (currentSubmitCounter <= 0) {
			if (!isWorkerNodeOnline(workerNodeId)) {
				STATUS_LOG.info("In releaseJobSlot: Detected workerNode is already marked as offline for workerNodeId: "
						+ workerNodeId + ", currentSubmitCounter: " + currentSubmitCounter);
			}
			return;
		}

		if (onlineWorkerNodeIdSet.contains(workerNodeId)) {
			boolean offerFlag = jobSlotQueue.offer(workerNodeId);
			if (offerFlag) {
				logger.info("Before releaseSlot, currentLoad=" + currentSubmitCounter + " NodeId=" + workerNodeId + " controllerId=" + controllerId);
				currentSubmitCounter = (int) submitCounter.decrementAndGet();
				logger.info("After releaseSlot, currentLoad=" + (int) submitCounter.get() + " NodeId=" + workerNodeId  + " controllerId=" + controllerId);
			} else {
				STATUS_LOG.warn("In releaseJobSlot: JobSlotQueue offer returned false for : " + workerNodeId);
			}
		} else {
			logger.warn("Worker node is offline, ignored releaseJobSlot for workerNodeId: " + workerNodeId);
		}

		if (logger.isDebugEnabled()) {
			logger.debug(
					"In offerJobSlot: controllerId: " + controllerId + ", workerComponentType: " + workerComponentType
							+ ", workerNodeId: " + workerNodeId + ", currentSubmitCounter: " + currentSubmitCounter);
		}
	}

	public final IAtomicLong getControllerWorkerNodeSubmitCounter(String controllerId, String workerNodeId) {
		IAtomicLong submitCounter = hazelcastInstance.getAtomicLong(
				controllerComponentType.name() + "_CONTROLLER_SUBMIT_COUNTER_" + controllerId + "_" + workerNodeId);
		return submitCounter;
	}

	private final void setWorkerNodeOnlineFlag(String workerNodeId, boolean flag) {
		IAtomicLong onlineFlag = hazelcastInstance
				.getAtomicLong(controllerComponentType.name() + "_WORKER_ONLINE_FLAG_" + workerNodeId);
		onlineFlag.set(flag ? 1 : 0);
	}

	private final boolean isWorkerNodeOnline(String workerNodeId) {
		IAtomicLong onlineFlag = hazelcastInstance
				.getAtomicLong(controllerComponentType.name() + "_WORKER_ONLINE_FLAG_" + workerNodeId);
		return onlineFlag.get() == 1;
	}

	public final IQueue<String> getJobSlotQueue() {
		IQueue<String> jobSlotQueue = hazelcastInstance.getQueue(controllerComponentType.name() + "_JOB_SLOT_QUEUE");
		return jobSlotQueue;
	}

	public final IMap<String, Integer> getMaxJobCountMap() {
		IMap<String, Integer> maxJobCountMap = hazelcastInstance
				.getMap(controllerComponentType.name() + "_MAX_JOB_COUNT_MAP");
		return maxJobCountMap;
	}

	public final boolean checkWorkerNodeConnection(String workerNodeId, boolean firstRunFlag) {
		boolean connectFlag = false;
		boolean isOfflinePreviously = offlineWorkerNodeIdSet.contains(workerNodeId);
		Lock lock = workerNodeLockMap.getValue(workerNodeId).writeLock();
		lock.lock();
		try {

			connectFlag = statusCheckFunction.apply(workerNodeId);
			if (connectFlag) {
				Integer currentMaxWorkerJobCount = maxJobCountMap.get(workerNodeId);
				if (currentMaxWorkerJobCount == null) {
					BioServerInfo workerNodeInfo = bioMatcherConfigService.getServerInfo(workerNodeId);
					currentMaxWorkerJobCount = workerNodeInfo.getMaxJobCount();
				}

				notifyOnline(workerNodeId, currentMaxWorkerJobCount);
			} else if (firstRunFlag || !isOfflinePreviously) {
				notifyOffline(workerNodeId);
			}
		} catch (Throwable th) {
			logger.error("Error in checkWorkerNodeConnection: offline workerNodeId: " + workerNodeId + " : "
					+ th.getMessage(), th);
		} finally {
			lock.unlock();
			if (firstRunFlag || ((connectFlag && isOfflinePreviously) || (!connectFlag && !isOfflinePreviously))) {
				logger.info("In checkWorkerNodeConnection finally : workerNodeId: " + workerNodeId + ", connectFlag: "
						+ connectFlag + ", isOfflinePreviously: " + isOfflinePreviously + ", firstRunFlag: "
						+ firstRunFlag);
			} else {
				logger.debug("In checkWorkerNodeConnection finally : workerNodeId: " + workerNodeId + ", connectFlag: "
						+ connectFlag + ", isOfflinePreviously: " + isOfflinePreviously);
			}

		}
		return connectFlag;
	}

	public final void adjustJobSlots() throws CoreException {
		try {
			List<BioServerInfo> workerNodeInfoList = bioMatcherConfigService
					.getServerInfoListByComponentType(workerComponentType, BioServerState.ACTIVE);

			Set<String> currentActiveStateServerIdSet = new HashSet<>();

			for (BioServerInfo workerNodeInfo : workerNodeInfoList) {
				currentActiveStateServerIdSet.add(workerNodeInfo.getServerId());

				if (!registeredWorkerNodeIdList.contains(workerNodeInfo.getServerId())) {
					if (workerNodeInfo.getMaxJobCount() == 0) {
						continue;
					}

					IAtomicLong submitCounter = getControllerWorkerNodeSubmitCounter(controllerId,
							workerNodeInfo.getServerId());
					submitCounter.set(0);

					submitCounterMap.put(workerNodeInfo.getServerId(), submitCounter);

					bioMatcherConfigService.createServerConnnections(workerNodeInfo.getServerId(),
							workerNodeInfo.getServerHost(), workerNodeInfo.getComponentType());

					boolean onlineFlag = statusCheckFunction.apply(workerNodeInfo.getServerId());

					configureClusterdWorkerNode(workerNodeInfo, onlineFlag);

					MetricsUtil.registerGauge(workerComponentType, workerNodeInfo.getServerId(),
							controllerComponentType.name() + "_" + workerComponentType.name() + "_"
									+ "ACTIVE_JOB_COUNT",
							() -> {
								return submitCounter.get();
							});

					registeredWorkerNodeIdList.add(workerNodeInfo.getServerId());
				} else if (onlineWorkerNodeIdSet.contains(workerNodeInfo.getServerId())) {

					Integer currentMaxWorkerJobCount = maxJobCountMap.get(workerNodeInfo.getServerId());
					if (currentMaxWorkerJobCount != null
							&& currentMaxWorkerJobCount.intValue() != workerNodeInfo.getMaxJobCount().intValue()) {
						ILock lock = hazelcastInstance.getLock(controllerComponentType.name() + "_CLUSTER_LOCK");
						lock.lock();
						try {
							if (onlineWorkerNodeIdSet.contains(workerNodeInfo.getServerId())) {
								currentMaxWorkerJobCount = maxJobCountMap.get(workerNodeInfo.getServerId());

								if (currentMaxWorkerJobCount < workerNodeInfo.getMaxJobCount()) {
									logger.info("In adjustJobSlots before increasing slots for : "
											+ workerNodeInfo.getServerId() + ", jobSlotQueueSize: "
											+ jobSlotQueue.size());
									for (int i = currentMaxWorkerJobCount; i < workerNodeInfo.getMaxJobCount(); i++) {
										boolean offerFlag = jobSlotQueue.offer(workerNodeInfo.getServerId());
										logger.info("In adjustJobSlots after adding jobSlotQueue for : "
												+ workerNodeInfo.getServerId() + ", offerFlag: " + offerFlag);
									}
									maxJobCountMap.put(workerNodeInfo.getServerId(), workerNodeInfo.getMaxJobCount());
									logger.info("In adjustJobSlots after increasing slots for : "
											+ workerNodeInfo.getServerId() + ", jobSlotQueueSize: "
											+ jobSlotQueue.size());
								} else if (currentMaxWorkerJobCount > workerNodeInfo.getMaxJobCount()) {
									int diff = currentMaxWorkerJobCount - workerNodeInfo.getMaxJobCount();
									logger.info("In adjustJobSlots before reducing slots for : "
											+ workerNodeInfo.getServerId() + ", jobSlotQueueSize: "
											+ jobSlotQueue.size());
									int counter = 0;
									for (int i = 0; i < diff; i++) {
										boolean removeFlag = jobSlotQueue.remove(workerNodeInfo.getServerId());
										logger.info("In adjustJobSlots after removing jobSlotQueue for : "
												+ workerNodeInfo.getServerId() + ", removeFlag: " + removeFlag);
										if (removeFlag) {
											counter++;
										}
									}
									maxJobCountMap.put(workerNodeInfo.getServerId(),
											currentMaxWorkerJobCount - counter);
									logger.info("In adjustJobSlots after reducing slots for : "
											+ workerNodeInfo.getServerId() + ", jobSlotQueueSize: "
											+ jobSlotQueue.size());
								}
							}
						} finally {
							lock.unlock();
						}
					}
				}

			}

			Set<String> disabledServerIdSet = new HashSet<>(
					Sets.difference(registeredWorkerNodeIdList, currentActiveStateServerIdSet));
			for (String disabledServerId : disabledServerIdSet) {
				notifyOffline(disabledServerId);
				offlineWorkerNodeIdSet.remove(disabledServerId);

				IAtomicLong submitCounter = getControllerWorkerNodeSubmitCounter(controllerId, disabledServerId);
				submitCounter.set(0);

				registeredWorkerNodeIdList.remove(disabledServerId);
			}
		} catch (Throwable th) {
			logger.warn("Error in adjustJobSlots: " + th.getMessage());
			throw new CoreException("Error in adjustJobSlots: " + th.getMessage(), th);
		}
	}

	private void configureClusterdWorkerNode(BioServerInfo workerNodeInfo, boolean onlineFlag) throws Exception {
		logger.info("In configureClusterdWorkerNode workerNodeInfo: " + workerNodeInfo.getServerId() + ", nodeState: "
				+ workerNodeInfo.getServerState() + ", onlineFlag: " + onlineFlag);

		if (!BioServerState.ACTIVE.equals(workerNodeInfo.getServerState())) {
			logger.debug("In configureClusterdWorkerNode: Worker node is not active for " + workerNodeInfo.getServerId()
					+ ", NodeState: " + workerNodeInfo.getServerState());
			return;
		}

		ILock lock = hazelcastInstance.getLock(controllerComponentType.name() + "_CLUSTER_LOCK");
		lock.lock();
		try {
			IAtomicLong registeredWorkerNodeIdCounter = hazelcastInstance.getAtomicLong(
					controllerComponentType.name() + "_REGISTERED_WORKER_NODE_COUNTER_" + workerNodeInfo.getServerId());
			if (registeredWorkerNodeIdCounter.get() > 0) {
				if (onlineFlag) {
					onlineWorkerNodeIdSet.add(workerNodeInfo.getServerId());
				} else {
					offlineWorkerNodeIdSet.add(workerNodeInfo.getServerId());
				}
				return;
			}

			maxJobCountMap.put(workerNodeInfo.getServerId(), workerNodeInfo.getMaxJobCount());

			// Drain any existing slots
			while (jobSlotQueue.remove(workerNodeInfo.getServerId()))
				;

			// Reset submit counter on each controller
			for (String controllerId : controllerIdSet) {
				try {
					IAtomicLong submitCounter = getControllerWorkerNodeSubmitCounter(controllerId,
							workerNodeInfo.getServerId());
					submitCounter.set(0);
				} catch (Throwable th) {
					logger.error("Error in notifyOnline during submitCounter.set(0): " + th.getMessage(), th);
				}
			}

			// Mark worker node as online
			setWorkerNodeOnlineFlag(workerNodeInfo.getServerId(), onlineFlag);

			// Add jobslots for worker node
			if (onlineFlag) {
				onlineWorkerNodeIdSet.add(workerNodeInfo.getServerId());
				IntStream stream = IntStream.range(0, workerNodeInfo.getMaxJobCount());
				stream.forEach(n -> {
					boolean offerFlag = jobSlotQueue.offer(workerNodeInfo.getServerId());
					logger.info(
							"In configureClusterdWorkerNode: After adding jobSlotQueue for : controllerComponentType: "
									+ controllerComponentType.name() + ", workerNodeId: " + workerNodeInfo.getServerId()
									+ ", offerFlag: " + offerFlag);
				});
				stream.close();
			} else {
				offlineWorkerNodeIdSet.add(workerNodeInfo.getServerId());
			}

			registeredWorkerNodeIdCounter.incrementAndGet();
		} finally {
			lock.unlock();

			CommonLogger.STATUS_LOG
					.info("In configureClusterdWorkerNode : workerNodeId: " + workerNodeInfo.getServerId()
							+ ", onlineFlag: " + onlineFlag + ", jobSlotQueueSize: " + jobSlotQueue.size());
		}
	}

	private HazelcastInstance buildClusterInstance() throws Exception {
		logger.info("In buildClusterInstance for  controllerId: " + controllerId + ", controllerComponentType: "
				+ controllerComponentType + ", hostname: " + HostnameUtil.getHostname() + ", ipAddress: "
				+ HostnameUtil.getIpAddress());
		try {

			BioServerInfo controllerServerInfo = bioMatcherConfigService.getServerInfo(controllerId);
			bioMatcherConfigService.createServerConnnections(controllerServerInfo.getServerId(),
					controllerServerInfo.getServerHost(), controllerServerInfo.getComponentType());

			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(controllerId, controllerComponentType,
					BioConnectionType.CLUSTER, BioProtocolType.HAZELCAST);
			if (StringUtils.isBlank(connectionUrl)) {
				throw new IllegalArgumentException("Controller connection url is not configured for serverId: "
						+ controllerId + ", controllerComponentType: " + controllerComponentType + ", connectionType: "
						+ BioConnectionType.CLUSTER + ", protocolType: " + BioProtocolType.HAZELCAST);
			}

			URI uri = new URI(connectionUrl);

			if (uri.getHost() == null || uri.getPort() == 0) {
				throw new IllegalArgumentException("Host and port for controller is not properly configured serverId: "
						+ controllerId + ", controllerComponentType: " + controllerComponentType + ", connectionType: "
						+ BioConnectionType.CLUSTER + ", protocolType: " + BioProtocolType.HAZELCAST
						+ ", connectionUrl: " + connectionUrl);
			}

			String clusterInstanceId = controllerComponentType.name() + "_ControllerCluster";
			HazelcastInstance currentHazelcastInstance = Hazelcast.getHazelcastInstanceByName(clusterInstanceId);
			if (currentHazelcastInstance != null) {
				currentHazelcastInstance.shutdown();
			}

			Config config = new Config(clusterInstanceId);
			config.getGroupConfig().setName(clusterInstanceId).setPassword("nec");

			config.setProperty("hazelcast.shutdownhook.enabled", "true");

			NetworkConfig network = config.getNetworkConfig();

			network.setPort(uri.getPort());
			network.setPortAutoIncrement(false);
			network.setReuseAddress(true);

			network.setPublicAddress(uri.getHost());

			JoinConfig join = network.getJoin();
			join.getMulticastConfig().setEnabled(false);
			TcpIpConfig tcpIpConfig = join.getTcpIpConfig();

			List<BioServerInfo> controllerList = bioMatcherConfigService
					.getServerInfoListByComponentType(controllerComponentType);
			Set<String> addedServerHostSet = new HashSet<>();
			for (BioServerInfo controller : controllerList) {
				if (!BioServerState.ACTIVE.equals(controller.getServerState())) {
					logger.warn("Controller state is not active for serverId : " + controller.getServerId());
					continue;
				}

				bioMatcherConfigService.createServerConnnections(controller.getServerId(), controller.getServerHost(),
						controller.getComponentType());

				connectionUrl = bioMatcherConfigService.getServerConnectionUrl(controller.getServerId(),
						controllerComponentType, BioConnectionType.CLUSTER, BioProtocolType.HAZELCAST);
				if (StringUtils.isBlank(connectionUrl)) {
					logger.error("Controller connection url is not configured for serverId: " + controller.getServerId()
							+ ", controllerComponentType: " + controllerComponentType + ", connectionType: "
							+ BioConnectionType.CLUSTER + ", protocolType: " + BioProtocolType.HAZELCAST);
					continue;
				}

				URI clusterMemberUri = new URI(connectionUrl);

				if (clusterMemberUri.getHost() == null || clusterMemberUri.getPort() == 0) {
					logger.error("Host and port for controller is not properly configured serverId: " + controllerId
							+ ", controllerComponentType: " + controllerComponentType + ", connectionType: "
							+ BioConnectionType.CLUSTER + ", protocolType: " + BioProtocolType.HAZELCAST
							+ ", connectionUrl: " + connectionUrl);
					continue;
				}

				logger.info("After parsing connectionUrl: " + connectionUrl + ", host: " + clusterMemberUri.getHost()
						+ ", port: " + clusterMemberUri.getPort());

				if (addedServerHostSet.contains(clusterMemberUri.getHost())) {
					logger.warn("Cluster member host is already added for hostname: " + clusterMemberUri.getHost()
							+ ", serverId: " + controller.getServerId() + ", controllerComponentType: "
							+ controllerComponentType + ", connectionType: " + BioConnectionType.CLUSTER
							+ ", protocolType: " + BioProtocolType.HAZELCAST);
					continue;
				}

				tcpIpConfig.addMember(clusterMemberUri.getHost());

				addedServerHostSet.add(clusterMemberUri.getHost());
			}

			tcpIpConfig.setEnabled(true);

			network.getInterfaces().setEnabled(true).addInterface("*.*.*.*");
			// network.getInterfaces().setEnabled(true).addInterface(uri.getHost());

			HazelcastInstance hazelcastInstance = Hazelcast.getOrCreateHazelcastInstance(config);

			ClusterInstanceRegistry.register(controllerComponentType, hazelcastInstance);

			logger.info("Current cluster members: " + hazelcastInstance.getCluster().getMembers().size());

			hazelcastInstance.getCluster().addMembershipListener(new ClusterMembershipListener());

			logger.info("In buildClusterInstance: controllerComponentType: " + controllerComponentType
					+ ", controllerId: " + controllerId + " : hazelcastInstance created successfully");

			return hazelcastInstance;
		} catch (Throwable th) {
			logger.error("Error in buildClusterInstance: controllerComponentType: " + controllerComponentType
					+ ", controllerId: " + controllerId + " : " + th.getMessage());
			throw new CoreException("Error in buildClusterInstance: controllerComponentType: " + controllerComponentType
					+ ", controllerId: " + controllerId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Handler member down.
	 *
	 * @param memberHostname
	 *            the member hostname
	 * @param memberIpAddress
	 *            the member ip address
	 */
	private void handlerMemberDown(String memberHostname, String memberIpAddress) {
		logger.info("In handlerMemberDown : controllerComponentType: " + controllerComponentType + ", memberHostname: "
				+ memberHostname + ", memberIpAddress: " + memberIpAddress);

		try {
			BioServerInfo memberDownController = bioMatcherConfigService.getServerInfoByServerHost(memberHostname,
					memberIpAddress, controllerComponentType);
			if (memberDownController == null) {
				logger.warn(
						"In handlerMemberDown: Controller cannot find the BioServerInfo for controllerComponentType: "
								+ controllerComponentType + ", memberHostname : " + memberHostname
								+ ", memberIpAddress: " + memberIpAddress);
				return;
			}

			if (BioServerState.STANDBY.equals(memberDownController.getServerState())) {
				return;
			}

			List<BioServerInfo> workerNodeInfoList = bioMatcherConfigService
					.getServerInfoListByComponentType(workerComponentType, BioServerState.ACTIVE);

			ILock lock = hazelcastInstance.getLock(controllerComponentType.name() + "_CLUSTER_LOCK");
			lock.lock();
			try {
				final String memberDownControllerId = memberDownController.getServerId();

				if (matcherFunctionControlUtil != null) {
					matcherFunctionControlUtil.releaseControllerFunctionLoad(memberDownControllerId);
				}

				workerNodeInfoList.forEach(workerNodeInfo -> {
					IAtomicLong submitCounter = getControllerWorkerNodeSubmitCounter(memberDownControllerId,
							workerNodeInfo.getServerId());
					int count = (int) submitCounter.get();
					submitCounter.set(0);

					if (count > 0) {
						if (onlineWorkerNodeIdSet.contains(workerNodeInfo.getServerId())) {
							// release slots acquired by other controller back
							// to queue
							IntStream stream = IntStream.range(0, count);
							stream.forEach(n -> {
								boolean offerFlag = jobSlotQueue.offer(workerNodeInfo.getServerId());
								STATUS_LOG.info("In handlerMemberDown: memberDownControllerId: "
										+ memberDownControllerId + ", controllerComponentType: "
										+ controllerComponentType + ", After adding jobSlotQueue for workerNodeId: "
										+ workerNodeInfo.getServerId() + ", offerFlag: " + offerFlag);
							});
							stream.close();
						}
					}
				});

				logger.info("In handlerMemberDown : memberDownControllerId: " + memberDownControllerId
						+ ", controllerComponentType: " + controllerComponentType + ", clusterMemberSize: "
						+ hazelcastInstance.getCluster().getMembers().size() + ", localMember: "
						+ hazelcastInstance.getCluster().getLocalMember().getSocketAddress().getHostName()
						+ ", jobSlotQueueSize: " + jobSlotQueue.size());
			} finally {
				lock.unlock();
			}
		} catch (Throwable th) {
			logger.error("Error in handlerMemberDown : controllerComponentType: " + controllerComponentType
					+ ", memberHostname: " + memberHostname + ", memberIpAddress: " + memberIpAddress + " : "
					+ th.getMessage(), th);
		}
	}

	class ClusterMembershipListener implements MembershipListener {
		@Override
		public void memberAdded(MembershipEvent membershipEvent) {
			InetSocketAddress socketAddress = membershipEvent.getMember().getSocketAddress();
			logger.info("Received memberRemoved notification on controllerId: " + controllerId
					+ ", controllerComponentType: " + controllerComponentType + ", eventType: "
					+ membershipEvent.getEventType() + ", SocketAddress: " + socketAddress);
		}

		@Override
		public void memberRemoved(MembershipEvent membershipEvent) {
			InetSocketAddress socketAddress = membershipEvent.getMember().getSocketAddress();
			logger.info("Received memberRemoved notification on controllerId: " + controllerId
					+ ", controllerComponentType: " + controllerComponentType + ", eventType: "
					+ membershipEvent.getEventType() + ", SocketAddress: " + socketAddress);
			handlerMemberDown(socketAddress.getHostName(), socketAddress.getAddress().getHostAddress());
		}

		@Override
		public void memberAttributeChanged(MemberAttributeEvent memberAttributeEvent) {
			logger.info("Received memberAttributeChanged notification on controllerId: " + controllerId
					+ ", controllerComponentType: " + controllerComponentType + ", eventType: "
					+ memberAttributeEvent.getEventType() + ", SocketAddress: "
					+ memberAttributeEvent.getMember().getSocketAddress() + ", key: " + memberAttributeEvent.getKey()
					+ ", value: " + memberAttributeEvent.getValue());
		}
	}

	class ClusterManagementTask implements Runnable {
		@Override
		public void run() {
			Thread.currentThread().setName("JOB_SLOT_CLUSTER_MGMT_TASK_" + Thread.currentThread().getId());
			logger.info("In ClusterManagementTask.run: controllerId: " + controllerId + ", controllerComponentType: "
					+ controllerComponentType.name());

			boolean firstRunFlag = true;
			int statusCheckDelaySeconds = 30;
			long lastAdjustJobSlotsTimestampMilli = 0;

			try {
				while (!ShutdownHook.isShutdownFlag) {
					try {
						statusCheckDelaySeconds = bioParameterService.getParameterValue(
								workerComponentType + "_STATUS_CHECK_DELAY_SECONDS", "DEFAULT",
								statusCheckDelaySeconds);

						if (firstRunFlag
								|| (System.currentTimeMillis() - lastAdjustJobSlotsTimestampMilli) > TimeUnit.MINUTES
										.toMillis(1)) {
							adjustJobSlots();
							lastAdjustJobSlotsTimestampMilli = System.currentTimeMillis();
						}

						for (String workerNodeId : offlineWorkerNodeIdSet) {
							BioServerInfo workerNodeServerInfo = bioMatcherConfigService.getServerInfo(workerNodeId);
							if (workerNodeServerInfo == null
									|| !BioServerState.ACTIVE.equals(workerNodeServerInfo.getServerState())
									|| workerNodeServerInfo.getMaxJobCount() == 0) {
								continue;
							}
							checkWorkerNodeConnection(workerNodeId, firstRunFlag);
						}

						firstRunFlag = false;
					} catch (Throwable th) {
						logger.error("Error in ClusterManagementTask.run: " + th.getMessage(), th);
					} finally {
						if (!ShutdownHook.isShutdownFlag) {
							Uninterruptibles.sleepUninterruptibly(statusCheckDelaySeconds, TimeUnit.SECONDS);
						}
					}
				}
			} finally {
				CommonLogger.STATUS_LOG.warn("Exiting ClusterManagementTask.run: controllerId: " + controllerId
						+ ", controllerComponentType: " + controllerComponentType.name() + ", isShutdownFlag: "
						+ ShutdownHook.isShutdownFlag);
			}
		}
	}

	public MatcherFunctionControlUtil getMatcherFunctionControlUtil() {
		return matcherFunctionControlUtil;
	}
}
