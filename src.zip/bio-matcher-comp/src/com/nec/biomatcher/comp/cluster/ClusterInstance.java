package com.nec.biomatcher.comp.cluster;

import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.IExecutorService;
import com.hazelcast.core.ILock;
import com.hazelcast.core.IMap;
import com.hazelcast.core.IQueue;
import com.hazelcast.core.ISet;
import com.hazelcast.core.ITopic;

public class ClusterInstance {
	private String clusterInstanceId;
    private HazelcastInstance hazelcastInstance;
    
    public ClusterInstance(String clusterInstanceId) {
        this.hazelcastInstance = Hazelcast.getHazelcastInstanceByName(clusterInstanceId);
    }  

    public ClusterInstance(HazelcastInstance hazelcastInstance) {
        this.hazelcastInstance = hazelcastInstance;
    }
    
  
    

    public <E> IQueue<E> getQueue(String key) {
        return hazelcastInstance.getQueue(key);
    }

    public <E> ITopic<E> getTopic(String key) {
        return hazelcastInstance.getTopic(key);
    }

    public ILock getLock(String key) {
        return hazelcastInstance.getLock(key);
    }

    public <K, V> IMap<K, V> getMap(String key) {
        return hazelcastInstance.getMap(key);
    }

    public <E> ISet<E> getSet(String key) {
        return hazelcastInstance.getSet(key);
    }

    public IAtomicLong getAtomicLong(String key) {
        return hazelcastInstance.getAtomicLong(key);
    }

    public void executeOnAllMemebers(Runnable runnable) {
        IExecutorService executorService = hazelcastInstance.getExecutorService("admin-executor");
        executorService.executeOnAllMembers(runnable);
    }
    
    public HazelcastInstance getHazelcastInstance() {
        return hazelcastInstance;
    }

    public synchronized void setHazelcastInstance(HazelcastInstance hazelcastInstance) {
        this.hazelcastInstance = hazelcastInstance;
    }

	public String getClusterInstanceId() {
		return clusterInstanceId;
	}

	public void setClusterInstanceId(String clusterInstanceId) {
		this.clusterInstanceId = clusterInstanceId;
	}

}
