package com.nec.biomatcher.comp.cluster;

import java.util.Map;
import java.util.concurrent.ConcurrentSkipListSet;

import org.apache.log4j.Logger;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.ILock;
import com.hazelcast.core.ISet;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;

public class MatcherFunctionControlUtil {
    private static final Logger logger = Logger.getLogger(MatcherFunctionControlUtil.class);

    private final BioComponentType controllerComponentType;
    private final String controllerId;
    private final BioMatcherConfigService bioMatcherConfigService;
    private final HazelcastInstance hazelcastInstance;
    private final ConcurrentValuedHashMap<String, IAtomicLong> functionLoadCounterMap;
    private final ConcurrentSkipListSet<String> functionIdSet = new ConcurrentSkipListSet<>();

    public MatcherFunctionControlUtil(BioComponentType controllerComponentType, String controllerId, BioMatcherConfigService bioMatcherConfigService, HazelcastInstance hazelcastInstance) {
        this.controllerComponentType = controllerComponentType;
        this.controllerId = controllerId.toUpperCase();
        this.bioMatcherConfigService = bioMatcherConfigService;
        this.hazelcastInstance = hazelcastInstance;
        this.functionLoadCounterMap = new ConcurrentValuedHashMap<>(key -> hazelcastInstance.getAtomicLong(key));
    }

    public boolean tryAcquireFunctionSlot(String functionId) {
        try {
            functionId = functionId.toUpperCase();

            Map<String, Integer> functionCapacityMap = bioMatcherConfigService.getFunctionCapacityMap();

            Integer maxFunctionCapacity = functionCapacityMap.get(functionId);

            if (maxFunctionCapacity == null || maxFunctionCapacity <= 0) {
                return false;
            }

            ILock acquireLock = hazelcastInstance.getLock("FUNC_LOAD_" + functionId);
            acquireLock.lock();
            try {
                IAtomicLong functionLoadCounter = functionLoadCounterMap.getValue("FUNC_LOAD_" + functionId);
                if (functionLoadCounter.get() < maxFunctionCapacity) {
                    if (addCounter(functionId, controllerId, 1)) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } finally {
                acquireLock.unlock();
            }
        } catch (Throwable th) {
            logger.error("Error during tryAcquireFunctionSlot for functionId: " + functionId + " : " + th.getMessage(), th);
            throw new RuntimeException("Error during tryAcquireFunctionSlot for functionId: " + functionId + " : " + th.getMessage(), th);
        }
    }

    public void releaseFunctionSlot(String functionId) {
        try {
            functionId = functionId.toUpperCase();

            addCounter(functionId, controllerId, -1);
        } catch (Throwable th) {
            logger.error("Error during releaseFunctionSlot for functionId: " + functionId + " : " + th.getMessage(), th);
            throw new RuntimeException("Error during tryAcquireFunctionSlot for functionId: " + functionId + " : " + th.getMessage(), th);
        }
    }

    public boolean acquireFunctionSlot(String functionId) {
        // Used for enrollment functions, so no need to check against max capacity
        try {
            functionId = functionId.toUpperCase();

            return addCounter(functionId, controllerId, 1);
        } catch (Throwable th) {
            logger.error("Error during acquireFunctionSlot for functionId: " + functionId + " : " + th.getMessage(), th);
            throw new RuntimeException("Error during acquireFunctionSlot for functionId: " + functionId + " : " + th.getMessage(), th);
        }
    }

    public void releaseControllerFunctionLoad(String controllerId) {
        CommonLogger.STATUS_LOG.info("In releaseControllerFunctionLoad for controllerId: " + controllerId);
        try {
            ISet<String> functionIdSet = hazelcastInstance.getSet("FUNCTION_ID_SET");
            functionIdSet.forEach(functionId -> {
                ILock acquireLock = hazelcastInstance.getLock("FUNC_LOAD_" + functionId);
                acquireLock.lock();
                try {
                    IAtomicLong controllerFunctionLoadCounter = functionLoadCounterMap.getValue("FUNC_LOAD_" + controllerId + "_" + functionId);
                    long delta = controllerFunctionLoadCounter.get();
                    if (delta > 0) {
                        boolean releasedFlag = addCounter(functionId, controllerId, -1 * delta);
                        CommonLogger.STATUS_LOG.info("In releaseControllerFunctionLoad for controllerId: " + controllerId + ", functionId: " + functionId + ", delta: " + delta + ", releasedFlag: " + releasedFlag);
                    }
                } catch (Throwable th) {
                    logger.error("Error in releaseControllerFunctionLoad for controllerId: " + controllerId + ", functionId: " + functionId + " : " + th.getMessage(), th);
                } finally {
                    acquireLock.unlock();
                }
            });

        } catch (Throwable th) {
            logger.error("Error during releaseControllerFunctionLoad for controllerId: " + controllerId + " : " + th.getMessage(), th);
        }
    }

    private final void addToFunctionIdSet(String functionId, IAtomicLong functionLoadCounter) {
        try {
            if (functionIdSet.add(functionId)) {
                ISet<String> functionIdSet = hazelcastInstance.getSet("FUNCTION_ID_SET");
                functionIdSet.add(functionId);

                if (functionLoadCounter != null) {
                    MetricsUtil.registerGauge("FUNCTION." + functionId + ".LOAD", () -> {
                        return functionLoadCounter.get();
                    });
                }
            }
        } catch (Throwable th) {
            logger.error("Error during addToFunctionIdSet for functionId: " + functionId + " : " + th.getMessage(), th);
        }
    }

    private final boolean addCounter(String functionId, String controllerId, long delta) {
        boolean controllerFuncLoadUpdatedFlag = false;
        boolean funcLoadUpdatedFlag = false;
        IAtomicLong controllerFunctionLoadCounter = null;
        IAtomicLong functionLoadCounter = null;
        try {
            controllerFunctionLoadCounter = functionLoadCounterMap.getValue("FUNC_LOAD_" + controllerId + "_" + functionId);
            controllerFunctionLoadCounter.addAndGet(delta);
            controllerFuncLoadUpdatedFlag = true;

            functionLoadCounter = functionLoadCounterMap.getValue("FUNC_LOAD_" + functionId);
            functionLoadCounter.addAndGet(delta);
            funcLoadUpdatedFlag = true;

            return true;
        } catch (Throwable th) {
            logger.error("Error in MatcherFunctionControlUtil.addCounter for functionId: " + functionId + ", delta: " + delta + ", funcLoadUpdatedFlag: " + funcLoadUpdatedFlag + ", controllerFuncLoadUpdatedFlag: " + controllerFuncLoadUpdatedFlag + " : " + th.getMessage(), th);

            if (controllerFuncLoadUpdatedFlag) {
                try {
                    controllerFunctionLoadCounter.addAndGet(-1 * delta);
                } catch (Throwable th1) {
                }
            }

            if (funcLoadUpdatedFlag) {
                try {
                    functionLoadCounter.addAndGet(-1 * delta);
                } catch (Throwable th1) {
                }
            }
        } finally {
            if (delta > 0) {
                addToFunctionIdSet(functionId, functionLoadCounter);
            }
        }
        return false;
    }

}
