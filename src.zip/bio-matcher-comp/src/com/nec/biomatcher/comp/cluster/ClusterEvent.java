package com.nec.biomatcher.comp.cluster;

import java.io.Serializable;

public class ClusterEvent implements Serializable {
    private static final long serialVersionUID = 1L;
    private String eventSource;
    private String eventType;
    private byte[] eventData;

    private String targetServerHostname;

    public ClusterEvent() {
    }

    public ClusterEvent(String eventSource, String eventType, byte[] eventData) {
        this.eventSource = eventSource;
        this.eventType = eventType;
        this.eventData = eventData;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public byte[] getEventData() {
        return eventData;
    }

    public void setEventData(byte[] eventData) {
        this.eventData = eventData;
    }

    public String getEventSource() {
        return eventSource;
    }

    public void setEventSource(String eventSource) {
        this.eventSource = eventSource;
    }

    public String getTargetServerHostname() {
        return targetServerHostname;
    }

    public void setTargetServerHostname(String targetServerHostname) {
        this.targetServerHostname = targetServerHostname;
    }
}
