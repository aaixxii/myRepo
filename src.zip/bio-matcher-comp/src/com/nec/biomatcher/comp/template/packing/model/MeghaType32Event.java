package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Sets;
import com.google.common.primitives.UnsignedBytes;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType32Event extends MeghaEvent {
	public static final int COUNT_MAX_FINGERS = 10;

	private byte featureHoldFlag = 0;

	private byte[] rolledQuality;
	private byte[] slapQuality;
	private byte pad[] = new byte[1];
	private byte rolledCmlafFeatureData[];
	private byte slapCmlafFeatureData[];

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "featureHoldFlag",
				StringUtils.leftPad(UnsignedBytes.toString(featureHoldFlag, 2), Byte.SIZE, "0"));
		printStream.printf("%-20s - %s\n", "rolledQuality", Arrays.toString(rolledQuality));
		printStream.printf("%-20s - %s\n", "slapQuality", Arrays.toString(rolledQuality));
		printStream.printf("%-20s - %s\n", "rolledCmlafFeatureData", rolledCmlafFeatureData != null);
		printStream.printf("%-20s - %s\n", "slapCmlafFeatureData", slapCmlafFeatureData != null);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).featureHoldFlag(1).quality(COUNT_MAX_FINGERS)
				.quality(COUNT_MAX_FINGERS).pad(1).featureDataLength(4).featureData(1, "FINGER_CMLAF_FEATURE_DATA_SIZE")
				.featureDataLength(4).featureData(1, "FINGER_CMLAF_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FINGER_CMLAF);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (rolledCmlafFeatureData == null && slapCmlafFeatureData == null) {
			throw new MeghaTemplateException("Both rolledCmlafFeatureData and slapCmlafFeatureData are not set");
		}

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.FINGER_CMLAF.getValue().byteValue());

		if (rolledQuality == null) {
			rolledQuality = new byte[COUNT_MAX_FINGERS];
		}
		if (slapQuality == null) {
			slapQuality = new byte[COUNT_MAX_FINGERS];
		}

		featureHoldFlag = 0;
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 0, rolledCmlafFeatureData != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 1, slapCmlafFeatureData != null);

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());
		eventDataBuf.put(featureHoldFlag);
		eventDataBuf.put(rolledQuality);
		eventDataBuf.put(slapQuality);
		eventDataBuf.put(pad);

		if (rolledCmlafFeatureData != null) {
			if (rolledCmlafFeatureData.length == 0 || rolledCmlafFeatureData.length > meghaTemplateConfig
					.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException("Invalid rolledCmlafFeatureData length, actual: "
						+ rolledCmlafFeatureData.length + ", expected: "
						+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
			}
			eventDataBuf.putInt(rolledCmlafFeatureData.length);

			eventDataBuf.put(rolledCmlafFeatureData);

			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE")
							- rolledCmlafFeatureData.length);

		} else {
			eventDataBuf.putInt(0);
			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
		}

		if (slapCmlafFeatureData != null) {
			if (slapCmlafFeatureData.length == 0 || slapCmlafFeatureData.length > meghaTemplateConfig
					.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException(
						"Invalid slapCmlafFeatureData length, actual: " + slapCmlafFeatureData.length + ", expected: "
								+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
			}
			eventDataBuf.putInt(slapCmlafFeatureData.length);

			eventDataBuf.put(slapCmlafFeatureData);

			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE")
							- slapCmlafFeatureData.length);

		} else {
			eventDataBuf.putInt(0);
			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
		}

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		featureHoldFlag = eventDataBuf.get();

		rolledQuality = new byte[COUNT_MAX_FINGERS];
		eventDataBuf.get(rolledQuality);

		slapQuality = new byte[COUNT_MAX_FINGERS];
		eventDataBuf.get(slapQuality);

		eventDataBuf.position(eventDataBuf.position() + pad.length);

		List<Integer> featureIndexFlagList = HoldFlagUtil.getHoldFlagIndexList(featureHoldFlag, 2);

		if (featureIndexFlagList.contains(0)) {
			int dataSize = eventDataBuf.getInt();

			if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
						+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
			}

			rolledCmlafFeatureData = new byte[dataSize];

			eventDataBuf.get(rolledCmlafFeatureData);

			eventDataBuf.position(eventDataBuf.position()
					+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE") - dataSize);

		} else {
			eventDataBuf.getInt();

			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
		}

		if (featureIndexFlagList.contains(1)) {
			int dataSize = eventDataBuf.getInt();

			if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
						+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
			}

			slapCmlafFeatureData = new byte[dataSize];

			eventDataBuf.get(slapCmlafFeatureData);

			eventDataBuf.position(eventDataBuf.position()
					+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE") - dataSize);

		} else {
			eventDataBuf.getInt();

			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
		}
	}

	public byte[] getRolledQuality() {
		return rolledQuality;
	}

	public void setRolledQuality(byte[] rolledQuality) {
		this.rolledQuality = rolledQuality;
	}

	public byte[] getSlapQuality() {
		return slapQuality;
	}

	public void setSlapQuality(byte[] slapQuality) {
		this.slapQuality = slapQuality;
	}

	public byte[] getRolledCmlafFeatureData() {
		return rolledCmlafFeatureData;
	}

	public void setRolledCmlafFeatureData(byte[] rolledCmlafFeatureData) {
		this.rolledCmlafFeatureData = rolledCmlafFeatureData;
	}

	public byte[] getSlapCmlafFeatureData() {
		return slapCmlafFeatureData;
	}

	public void setSlapCmlafFeatureData(byte[] slapCmlafFeatureData) {
		this.slapCmlafFeatureData = slapCmlafFeatureData;
	}

}
