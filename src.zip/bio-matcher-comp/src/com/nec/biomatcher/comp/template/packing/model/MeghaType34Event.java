package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Set;

import com.google.common.collect.Sets;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType34Event extends MeghaEvent {
	public static final int MAX_LATENT_PATTERNS_COUNT = 7;
	public static final int MAX_FINGER_COUNT = 10;

	byte fingerNumbers[];
	byte latentPatterns[];
	byte ldbFeatureData[];

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "fingerNumbers", Arrays.toString(fingerNumbers));
		printStream.printf("%-20s - %s\n", "latentPatterns",
				Arrays.toString(new String(latentPatterns, StandardCharsets.UTF_8).toCharArray()));
		printStream.printf("%-20s - %s\n", "ldbFeatureData", ldbFeatureData != null);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).bytes(MAX_FINGER_COUNT)
				.bytes(MAX_LATENT_PATTERNS_COUNT).featureDataLength(4)
				.featureData(1, "LATENT_FINGER_LDB_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FINGER_PC2, AlgorithmType.FINGER_FMP5);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (ldbFeatureData == null) {
			throw new MeghaTemplateException("Invalid ldbFeatureData is not set");
		}

		if (ldbFeatureData.length == 0
				|| ldbFeatureData.length > meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LDB_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid ldbFeatureData length, actual: " + ldbFeatureData.length
					+ ", expected: " + meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LDB_FEATURE_DATA_SIZE"));
		}

		if (fingerNumbers != null && fingerNumbers.length != MAX_FINGER_COUNT) {
			throw new MeghaTemplateException("Invalid fingerNumbers length, actual: " + fingerNumbers.length
					+ ", expected: " + MAX_FINGER_COUNT);
		}

		if (latentPatterns != null && latentPatterns.length != MAX_LATENT_PATTERNS_COUNT) {
			throw new MeghaTemplateException("Invalid latentPatterns length, actual: " + latentPatterns.length
					+ ", expected: " + MAX_LATENT_PATTERNS_COUNT);
		}

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());

		if (fingerNumbers == null) {
			fingerNumbers = new byte[MAX_FINGER_COUNT];
		}

		eventDataBuf.put(fingerNumbers);

		if (latentPatterns == null) {
			latentPatterns = new byte[MAX_LATENT_PATTERNS_COUNT];
		}

		eventDataBuf.put(latentPatterns);

		eventDataBuf.putInt(ldbFeatureData.length);

		eventDataBuf.put(ldbFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LDB_FEATURE_DATA_SIZE") - ldbFeatureData.length);

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		fingerNumbers = new byte[MAX_FINGER_COUNT];
		eventDataBuf.get(fingerNumbers);

		latentPatterns = new byte[MAX_LATENT_PATTERNS_COUNT];
		eventDataBuf.get(latentPatterns);

		int dataSize = eventDataBuf.getInt();
		if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LDB_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
					+ meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LDB_FEATURE_DATA_SIZE"));
		}

		ldbFeatureData = new byte[dataSize];
		eventDataBuf.get(ldbFeatureData);
		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LDB_FEATURE_DATA_SIZE") - dataSize);
	}

	public byte[] getLdbFeatureData() {
		return ldbFeatureData;
	}

	public void setLdbFeatureData(byte[] ldbFeatureData) {
		this.ldbFeatureData = ldbFeatureData;
	}

	public byte[] getFingerNumbers() {
		return fingerNumbers;
	}

	public void setFingerNumbers(byte[] fingerNumbers) {
		this.fingerNumbers = fingerNumbers;
	}

	public byte[] getLatentPatterns() {
		return latentPatterns;
	}

	public void setLatentPatterns(byte[] latentPatterns) {
		this.latentPatterns = latentPatterns;
	}

}
