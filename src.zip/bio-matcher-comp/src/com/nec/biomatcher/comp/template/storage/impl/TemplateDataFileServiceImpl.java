package com.nec.biomatcher.comp.template.storage.impl;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.comp.template.storage.TemplateStorageService;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateStorageInfo;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataServiceException;
import com.nec.biomatcher.comp.template.storage.exception.TemplateStorageServiceException;
import com.nec.biomatcher.comp.template.storage.util.TemplateFileUtil;
import com.nec.biomatcher.core.framework.common.PFLogger;

public class TemplateDataFileServiceImpl implements TemplateDataService {
	private static final Logger logger = Logger.getLogger(TemplateDataFileServiceImpl.class);

	/** The free space size threshold. */
	private Long freeSpaceSizeThreshold = 10L * 1024L * 1024L;

	private TemplateStorageService templateStorageService;

	private static final AtomicLong saveTemplateCounter = new AtomicLong();

	public String saveTemplateData(Integer binId, Long biometricId, byte[] templateData)
			throws TemplateDataServiceException {
		PFLogger.start();
		int storageId = -1;
		try {
			if (biometricId == null) {
				throw new TemplateDataServiceException("biometricId is null");
			}

			if (binId == null) {
				throw new TemplateDataServiceException("binId is null");
			}

			if (templateData == null || templateData.length == 0) {
				throw new TemplateDataServiceException(
						"Template data bytes is empty or null for biometricId: " + biometricId + ", binId: " + binId);
			}

			List<BioTemplateStorageInfo> templateStorageInfoList = templateStorageService
					.getActiveTemplateStorageInfoList();

			if (templateStorageInfoList.size() == 0) {
				throw new TemplateDataServiceException("BioTemplateStorageInfo list is empty");
			}

			long counter = saveTemplateCounter.accumulateAndGet(1, (currrValue, newValue) -> (currrValue + newValue));
			BioTemplateStorageInfo templateStorageInfo = templateStorageInfoList
					.get((int) (counter % templateStorageInfoList.size()));
			storageId = templateStorageInfo.getStorageId();
			Path templateFilePath = TemplateFileUtil.buildTemplateFilePath(templateStorageInfo.getRootPath(), binId,
					biometricId);

			TemplateFileUtil.createTemplateFileDirectories(templateFilePath);

			try {
				TemplateFileUtil.createTemplateFile(templateFilePath, templateData);
			} catch (Throwable th) {
				logger.error(
						"Error saving templateFile for biometricId: " + biometricId + ", binId: " + binId
								+ ", templateFilePath: " + templateFilePath.toAbsolutePath() + " : " + th.getMessage(),
						th);
				if (checkFreeSpaceAndDeActivate(templateStorageInfo)) {
					return saveTemplateData(binId, biometricId, templateData);
				}
				throw new TemplateDataServiceException(
						"Error saving templateFile for biometricId: " + biometricId + ", binId: " + binId
								+ ", templateFilePath: " + templateFilePath.toAbsolutePath() + " : " + th.getMessage(),
						th);
			}

			return TemplateFileUtil.buildTemplateDataKey(templateStorageInfo.getStorageId(), binId, biometricId);
		} catch (TemplateDataServiceException ex) {
			throw ex;
		} catch (TemplateStorageServiceException ex) {
			throw new TemplateDataServiceException(ex);
		} catch (Throwable th) {
			throw new TemplateDataServiceException("Error saving template data: " + th.getMessage(), th);
		} finally {
			PFLogger.end(200, "binId: " + binId + ", biometricId: " + biometricId + ", storageId: " + storageId);
		}
	}

	public void updateTemplateData(String templateDataKey, byte[] templateData) throws TemplateDataServiceException {
		PFLogger.start();
		try {
			List<Long> templateDataKeyParts = TemplateFileUtil.parseTemplateDataKey(templateDataKey);

			Integer storageId = templateDataKeyParts.get(0).intValue();
			Integer binId = templateDataKeyParts.get(1).intValue();
			Long biometricId = templateDataKeyParts.get(2);

			BioTemplateStorageInfo bioTemplateStorageInfo = templateStorageService.getTemplateStorageInfo(storageId);

			Path templateFilePath = TemplateFileUtil.buildTemplateFilePath(bioTemplateStorageInfo.getRootPath(), binId,
					biometricId);

			TemplateFileUtil.createTemplateFile(templateFilePath, templateData);
		} catch (TemplateStorageServiceException ex) {
			throw new TemplateDataServiceException(ex);
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in updateTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end(200, "templateDataKey: " + templateDataKey);
		}
	}

	public void deleteTemplateData(String templateDataKey) throws TemplateDataServiceException {
		try {
			if (templateDataKey == null) {
				return;
			}
			List<Long> templateDataKeyParts = TemplateFileUtil.parseTemplateDataKey(templateDataKey);

			Integer storageId = templateDataKeyParts.get(0).intValue();
			Integer binId = templateDataKeyParts.get(1).intValue();
			Long biometricId = templateDataKeyParts.get(2);

			BioTemplateStorageInfo bioTemplateStorageInfo = templateStorageService.getTemplateStorageInfo(storageId);

			Path templateFilePath = TemplateFileUtil.buildTemplateFilePath(bioTemplateStorageInfo.getRootPath(), binId,
					biometricId);

			TemplateFileUtil.deleteTemplateFile(templateFilePath);
		} catch (TemplateStorageServiceException ex) {
			throw new TemplateDataServiceException(ex);
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in deleteTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		}
	}

	public byte[] getTemplateData(String templateDataKey) throws TemplateDataServiceException {
		PFLogger.start();
		try {
			List<Long> templateDataKeyParts = TemplateFileUtil.parseTemplateDataKey(templateDataKey);

			return getTemplateData(templateDataKeyParts.get(0).intValue(), templateDataKeyParts.get(1).intValue(),
					templateDataKeyParts.get(2));
		} catch (TemplateDataServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in getTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end(100, "templateDataKey: " + templateDataKey);
		}
	}

	private byte[] getTemplateData(Integer storageId, Integer binId, Long biometricId)
			throws TemplateDataServiceException {
		try {
			BioTemplateStorageInfo bioTemplateStorageInfo = templateStorageService.getTemplateStorageInfo(storageId);

			Path templateFilePath = TemplateFileUtil.buildTemplateFilePath(bioTemplateStorageInfo.getRootPath(), binId,
					biometricId);

			return TemplateFileUtil.readTemplateFileData(templateFilePath);
		} catch (TemplateStorageServiceException ex) {
			throw new TemplateDataServiceException(ex);
		} catch (Throwable th) {
			throw new TemplateDataServiceException("Error in getTemplateData : storageId: " + storageId + ", binId: "
					+ binId + ", biometricId: " + biometricId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Check free space and de activate.
	 *
	 * @param templateStorageInfo
	 *            the template storage info
	 * @return true, if successful
	 * @throws TemplateStorageServiceException
	 *             the template storage service exception
	 */
	private boolean checkFreeSpaceAndDeActivate(BioTemplateStorageInfo templateStorageInfo)
			throws TemplateStorageServiceException {
		try {
			if (TemplateFileUtil.getFreeSpace(templateStorageInfo.getRootPath()) < freeSpaceSizeThreshold) {
				templateStorageService.deactivateTemplateStorageInfo(templateStorageInfo.getStorageId());
				return true;
			}
			return false;
		} catch (Throwable th) {
			throw new TemplateStorageServiceException("Error in checkFreeSpaceAndDeActivate: " + th.getMessage(), th);
		}
	}

	public void setFreeSpaceSizeThreshold(Long freeSpaceSizeThreshold) {
		this.freeSpaceSizeThreshold = freeSpaceSizeThreshold;
	}

	public void setTemplateStorageService(TemplateStorageService templateStorageService) {
		this.templateStorageService = templateStorageService;
	}

}
