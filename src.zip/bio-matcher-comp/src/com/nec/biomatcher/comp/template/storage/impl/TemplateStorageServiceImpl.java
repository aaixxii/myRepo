package com.nec.biomatcher.comp.template.storage.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.template.storage.TemplateStorageService;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateStorageInfo;
import com.nec.biomatcher.comp.template.storage.dataAccess.TemplateStorageDao;
import com.nec.biomatcher.comp.template.storage.exception.TemplateStorageServiceException;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

/**
 * The Class TemplateStorageServiceImpl.
 */
public class TemplateStorageServiceImpl implements TemplateStorageService {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(TemplateStorageServiceImpl.class);

	/** The template storage dao. */
	private TemplateStorageDao templateStorageDao;

	public BioTemplateStorageInfo getTemplateStorageInfo(Integer storageId) throws TemplateStorageServiceException {
		try {
			return templateStorageDao.getEntity(BioTemplateStorageInfo.class, storageId);
		} catch (Throwable th) {
			throw new TemplateStorageServiceException("Error in getTemplateStorageInfo: " + th.getMessage(), th);
		}
	}

	public List<BioTemplateStorageInfo> getActiveTemplateStorageInfoList() throws TemplateStorageServiceException {
		try {
			return templateStorageDao.getEntityListByField(BioTemplateStorageInfo.class, "activeFalg", Boolean.TRUE);
		} catch (Throwable th) {
			throw new TemplateStorageServiceException("Error in getActiveTemplateStorageInfoList: " + th.getMessage(),
					th);
		}
	}

	public List<BioTemplateStorageInfo> getTemplateStorageInfoList() throws TemplateStorageServiceException {
		try {
			return templateStorageDao.getAllEntity(BioTemplateStorageInfo.class);
		} catch (Throwable th) {
			throw new TemplateStorageServiceException("Error in getTemplateStorageInfoList: " + th.getMessage(), th);
		}
	}

	public Map<Integer, String> getTemplateStorageInfoMap() throws TemplateStorageServiceException {
		try {
			return templateStorageDao.getAllEntity(BioTemplateStorageInfo.class).stream().collect(
					Collectors.toMap(BioTemplateStorageInfo::getStorageId, BioTemplateStorageInfo::getRootPath));
		} catch (Throwable th) {
			throw new TemplateStorageServiceException("Error in getTemplateStorageInfoList: " + th.getMessage(), th);
		}
	}

	public void activateTemplateStorageInfo(Integer storageId) throws TemplateStorageServiceException {
		logger.info("In activateTemplateStorageInfo: storageId: " + storageId);
		try {
			BioTemplateStorageInfo bioTemplateStorageInfo = templateStorageDao
					.getEntityForUpdate(BioTemplateStorageInfo.class, storageId);
			if (bioTemplateStorageInfo.getActiveFalg() == Boolean.FALSE) {
				bioTemplateStorageInfo.setActiveFalg(Boolean.TRUE);
				bioTemplateStorageInfo.setUpdateDateTime(new Date());
				templateStorageDao.updateEntity(bioTemplateStorageInfo);
			}
		} catch (Throwable th) {
			throw new TemplateStorageServiceException("Error in activateTemplateStorageInfo: " + th.getMessage(), th);
		}
	}

	public void deactivateTemplateStorageInfo(Integer storageId) throws TemplateStorageServiceException {
		logger.info("In deactivateTemplateStorageInfo: storageId: " + storageId);
		try {
			BioTemplateStorageInfo bioTemplateStorageInfo = templateStorageDao
					.getEntityForUpdate(BioTemplateStorageInfo.class, storageId);
			if (bioTemplateStorageInfo.getActiveFalg()) {
				bioTemplateStorageInfo.setActiveFalg(Boolean.FALSE);
				bioTemplateStorageInfo.setUpdateDateTime(new Date());
				templateStorageDao.updateEntity(bioTemplateStorageInfo);
			}
		} catch (Throwable th) {
			throw new TemplateStorageServiceException("Error in deactivateTemplateStorageInfo: " + th.getMessage(), th);
		}
	}

	public void setTemplateStorageDao(TemplateStorageDao templateStorageDao) {
		this.templateStorageDao = templateStorageDao;
	}

	@Override
	public void saveTemplateStorageInfo(BioTemplateStorageInfo templateStorageInfo)
			throws TemplateStorageServiceException {

		try {

			List<BioTemplateStorageInfo> templateStorageInfoList = this.getTemplateStorageInfoList();
			Integer lastStorageId = 0;
			if (CollectionUtils.isNotEmpty(templateStorageInfoList)) {
				lastStorageId = templateStorageInfoList.get(0).getStorageId();
				for (BioTemplateStorageInfo bioTemplateStorageInfo : templateStorageInfoList) {
					if (bioTemplateStorageInfo.getStorageId() > lastStorageId) {
						lastStorageId = bioTemplateStorageInfo.getStorageId();
					}
				}
			}

			templateStorageInfo.setStorageId(lastStorageId + 1); // need to
																	// modify
																	// this as
																	// it can
																	// generate
																	// duplicate
																	// storage
																	// id
			templateStorageInfo.setCreateDateTime(new Date());
			templateStorageDao.saveOrUpdateEntity(templateStorageInfo);
		} catch (DaoException e) {
			throw new TemplateStorageServiceException("Error in saveTemplateStorageInfo: " + e.getMessage(), e);
		}
	}

	@Override
	public void updateTemplateStorageInfo(BioTemplateStorageInfo templateStorageInfo)
			throws TemplateStorageServiceException {
		try {

			BioTemplateStorageInfo bioTemplateStorageInfo = templateStorageDao
					.getEntityForUpdate(BioTemplateStorageInfo.class, templateStorageInfo.getStorageId());
			templateStorageInfo.setUpdateDateTime(new Date());
			templateStorageDao.mergeEntity(templateStorageInfo);

		} catch (DaoException e) {
			throw new TemplateStorageServiceException("Error in saveTemplateStorageInfo: " + e.getMessage(), e);
		}

	}

	@Override
	public void deleteTemplateStorageInfo(Integer storageId) throws TemplateStorageServiceException {
		try {
			if (storageId != null) {
				BioTemplateStorageInfo bioTemplateStorageInfo = this.getTemplateStorageInfo(storageId);
				if (bioTemplateStorageInfo != null) {
					templateStorageDao.deleteEntity(bioTemplateStorageInfo);
				}
			}
		} catch (DaoException e) {
			throw new TemplateStorageServiceException("Error in saveTemplateStorageInfo: " + e.getMessage(), e);
		}

	}

}
