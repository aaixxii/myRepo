package com.nec.biomatcher.comp.template.storage.impl;

import java.nio.ByteBuffer;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.Bytes;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataNotFoundException;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataServiceException;
import com.nec.biomatcher.comp.util.CassandraConnector;
import com.nec.biomatcher.core.framework.common.PFLogger;

public class TemplateDataCassandraServiceImpl implements TemplateDataService, InitializingBean {
	private static final Logger logger = Logger.getLogger(TemplateDataCassandraServiceImpl.class);

	private BioMatcherConfigService bioMatcherConfigService;

	private CassandraConnector cassandraConnector;

	private String insertSql = "insert into BIO_TEMPLATE_DATA_INFO (TEMPLATE_DATA_ID, CREATE_DATETIME, UPDATE_DATETIME, TEMPLATE_DATA) values (?, ?, ?, ?)";
	private String selectQuery = "select TEMPLATE_DATA from BIO_TEMPLATE_DATA_INFO where TEMPLATE_DATA_ID=?";
	private String deleteSql = "delete from BIO_TEMPLATE_DATA_INFO where TEMPLATE_DATA_ID=?";

	public String saveTemplateData(Integer binId, Long biometricId, byte[] templateData)
			throws TemplateDataServiceException {
		if (biometricId == null) {
			throw new TemplateDataServiceException("biometricId is null");
		}

		String templateDataKey = biometricId.toString();

		saveTemplateData(templateDataKey, templateData);

		return templateDataKey;
	}

	public void updateTemplateData(String templateDataKey, byte[] templateData) throws TemplateDataServiceException {
		saveTemplateData(templateDataKey, templateData);
	}

	private final void saveTemplateData(String templateDataKey, byte[] templateData)
			throws TemplateDataServiceException {
		PFLogger.start();
		try {
			if (StringUtils.isBlank(templateDataKey)) {
				throw new TemplateDataServiceException("templateDataKey is null or empty");
			}

			if (templateData == null || templateData.length == 0) {
				throw new TemplateDataServiceException(
						"Template data bytes is empty or null for templateDataKey: " + templateDataKey);
			}

			Date now = new Date();
			Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
			PreparedStatement preparedStatement = session.prepare(insertSql);
			BoundStatement boundStatement = preparedStatement.bind(templateDataKey, now, now,
					ByteBuffer.wrap(templateData));
			session.execute(boundStatement);

		} catch (TemplateDataServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in saveTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end(200, "templateDataKey: " + templateDataKey);
		}
	}

	public void deleteTemplateData(String templateDataKey) throws TemplateDataServiceException {
		try {
			if (StringUtils.isBlank(templateDataKey)) {
				return;
			}

			Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
			PreparedStatement preparedStatement = session.prepare(deleteSql);
			BoundStatement boundStatement = preparedStatement.bind(templateDataKey);
			session.execute(boundStatement);
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in deleteTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		}
	}

	public byte[] getTemplateData(String templateDataKey)
			throws TemplateDataServiceException, TemplateDataNotFoundException {
		PFLogger.start();
		try {
			if (StringUtils.isBlank(templateDataKey)) {
				throw new TemplateDataServiceException("templateDataKey is null or empty");
			}

			Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
			PreparedStatement preparedStatement = session.prepare(selectQuery);
			BoundStatement boundStatement = preparedStatement.bind(templateDataKey);
			Row row = session.execute(boundStatement).one();
			if (row == null) {
				throw new TemplateDataNotFoundException(
						"Template data not found with templateDataKey: " + templateDataKey);
			}
			ByteBuffer lobDataBuffer = row.getBytes("TEMPLATE_DATA");
			return Bytes.getArray(lobDataBuffer);
		} catch (TemplateDataNotFoundException ex) {
			throw ex;
		} catch (TemplateDataServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in getTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end(100, "templateDataKey: " + templateDataKey);
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In afterPropertiesSet");
		cassandraConnector = CassandraConnector.getInstance();
		cassandraConnector.initializeConfig(bioMatcherConfigService);
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}
}
