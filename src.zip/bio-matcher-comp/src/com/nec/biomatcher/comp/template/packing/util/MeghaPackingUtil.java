package com.nec.biomatcher.comp.template.packing.util;

import java.io.File;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.model.MeghaEventHeader;
import com.nec.biomatcher.comp.template.packing.model.MeghaTemplateHeader;
import com.nec.biomatcher.comp.template.packing.model.MeghaType11Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType11Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType12Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType12Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType1Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType1Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType22Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType22Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType2Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType2Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType31Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType31Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType32Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType32Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType33Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType33Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType34Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType34Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType35Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType35Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType36Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType36Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType37Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType37Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType38Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType38Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType39Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType39Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType3Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType3Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType40Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType40Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType41Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType41Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType42Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType42Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType43Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType43Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType44Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType44Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType45Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType45Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType46Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType46Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType47Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType47Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType48Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType48Template;
import com.nec.biomatcher.comp.template.packing.model.MeghaType4Event;
import com.nec.biomatcher.comp.template.packing.model.MeghaType4Template;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.BioFeType;
import com.nec.biomatcher.spec.transfer.model.GenderEnum;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;
import com.nec.biomatcher.spec.transfer.model.PatternType;
import com.nec.biomatcher.spec.transfer.model.TemplateType;
import com.nec.biomatcher.spec.transfer.template.BioFingerFeatureInfo;
import com.nec.biomatcher.spec.transfer.template.BioTemplateEvent;
import com.nec.biomatcher.spec.transfer.template.BioTemplateHeader;
import com.nec.biomatcher.spec.transfer.template.BioTemplatePayload;
import com.nec.biomatcher.spec.transfer.template.BioType11Event;
import com.nec.biomatcher.spec.transfer.template.BioType12Event;
import com.nec.biomatcher.spec.transfer.template.BioType1Event;
import com.nec.biomatcher.spec.transfer.template.BioType2Event;
import com.nec.biomatcher.spec.transfer.template.BioType31Event;
import com.nec.biomatcher.spec.transfer.template.BioType32Event;
import com.nec.biomatcher.spec.transfer.template.BioType33Event;
import com.nec.biomatcher.spec.transfer.template.BioType34Event;
import com.nec.biomatcher.spec.transfer.template.BioType35Event;
import com.nec.biomatcher.spec.transfer.template.BioType36Event;
import com.nec.biomatcher.spec.transfer.template.BioType37Event;
import com.nec.biomatcher.spec.transfer.template.BioType38Event;
import com.nec.biomatcher.spec.transfer.template.BioType39Event;
import com.nec.biomatcher.spec.transfer.template.BioType3Event;
import com.nec.biomatcher.spec.transfer.template.BioType40Event;
import com.nec.biomatcher.spec.transfer.template.BioType41Event;
import com.nec.biomatcher.spec.transfer.template.BioType42Event;
import com.nec.biomatcher.spec.transfer.template.BioType43Event;
import com.nec.biomatcher.spec.transfer.template.BioType44Event;
import com.nec.biomatcher.spec.transfer.template.BioType45Event;
import com.nec.biomatcher.spec.transfer.template.BioType46Event;
import com.nec.biomatcher.spec.transfer.template.BioType47Event;
import com.nec.biomatcher.spec.transfer.template.BioType48Event;
import com.nec.biomatcher.spec.transfer.template.BioType4Event;

public class MeghaPackingUtil {
	private static final Logger logger = Logger.getLogger(MeghaPackingUtil.class);
	private static final Logger TEMPLATE_LOGGER = Logger.getLogger("TEMPLATE_LOGGER");

	public static byte[] packTemplate(BioTemplatePayload bioTemplatePayload, MeghaTemplateConfig meghaTemplateConfig,
			TemplateType templateType) throws MeghaTemplateException {
		try {
			byte[] templateData = packTemplateInternal(bioTemplatePayload, meghaTemplateConfig,
					templateType.getTemplateTypeCode());

			if (TEMPLATE_LOGGER.isTraceEnabled()) {
				dumpTemplateFile(templateType, templateData);
			}

			return templateData;
		} catch (MeghaTemplateException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new MeghaTemplateException(
					"Error in template packing for templateType: " + templateType + " : " + th.getMessage(), th);
		}
	}

	private static final byte[] packTemplateInternal(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {
		TemplateType templateType = TemplateType.enumOf(templateTypeCode);
		if (templateType == null) {
			throw new MeghaTemplateException("TemplateTypeCode: " + templateTypeCode + " is not supported");
		}

		switch (templateTypeCode) {
		case 1:
			return packType1Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 2:
			return packType2Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 3:
			return packType3Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 4:
			return packType4Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 11:
			return packType11Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 12:
			return packType12Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 22:
			return packType22Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 31:
			return packType31Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 32:
			return packType32Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 33:
			return packType33Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 34:
			return packType34Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 35:
			return packType35Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 36:
			return packType36Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 37:
			return packType37Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 38:
			return packType38Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 39:
			return packType39Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 40:
			return packType40Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 41:
			return packType41Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 42:
			return packType42Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 43:
			return packType43Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 44:
			return packType44Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 45:
			return packType45Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 46:
			return packType46Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);
		case 47:
			return packType47Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);

		case 48:
			return packType48Template(bioTemplatePayload, meghaTemplateConfig, templateTypeCode);

		default:
			throw new MeghaTemplateException("Template type: " + templateTypeCode + " packing is not supported");
		}
	}

	public static byte[] packType1Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType1Template meghaTemplate = new MeghaType1Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;

		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType1Event)) {
				continue;
			}
			BioType1Event bioEvent = (BioType1Event) event;

			if (bioEvent.getFaceS17FeatureData() == null || bioEvent.getFaceS17FeatureData().length == 0) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.FACE_NEC_S17,
					null);

			MeghaType1Event meghaEvent = new MeghaType1Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setFaceFeatureData(bioEvent.getFaceS17FeatureData());

			if (bioEvent.getQuality() != null) {
				meghaEvent.setQuality(bioEvent.getQuality().byteValue());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType2Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType2Template meghaTemplate = new MeghaType2Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;

		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType2Event)) {
				continue;
			}
			BioType2Event bioEvent = (BioType2Event) event;

			if (bioEvent.getFaceS18FeatureData() == null || bioEvent.getFaceS18FeatureData().length == 0) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.FACE_NEC_S18,
					null);

			MeghaType2Event meghaEvent = new MeghaType2Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setFaceFeatureData(bioEvent.getFaceS18FeatureData());

			if (bioEvent.getQuality() != null) {
				meghaEvent.setQuality(bioEvent.getQuality().byteValue());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType3Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType3Template meghaTemplate = new MeghaType3Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;

		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType3Event)) {
				continue;
			}
			BioType3Event bioEvent = (BioType3Event) event;

			if (bioEvent.getFaceNFV2FeatureData() == null || bioEvent.getFaceNFV2FeatureData().length == 0) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					AlgorithmType.FACE_NEC_NFV2, null);

			MeghaType3Event meghaEvent = new MeghaType3Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setFaceFeatureData(bioEvent.getFaceNFV2FeatureData());

			if (bioEvent.getQuality() != null) {
				meghaEvent.setQuality(bioEvent.getQuality().byteValue());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType4Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType4Template meghaTemplate = new MeghaType4Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;

		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType4Event)) {
				continue;
			}
			BioType4Event bioEvent = (BioType4Event) event;

			if (bioEvent.getFaceNFG2FeatureData() == null || bioEvent.getFaceNFG2FeatureData().length == 0) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					AlgorithmType.FACE_NEC_NFG2, null);

			MeghaType4Event meghaEvent = new MeghaType4Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setFaceFeatureData(bioEvent.getFaceNFG2FeatureData());

			if (bioEvent.getQuality() != null) {
				meghaEvent.setQuality(bioEvent.getQuality().byteValue());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType11Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType11Template meghaTemplate = new MeghaType11Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;

		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType11Event)) {
				continue;
			}
			BioType11Event bioEvent = (BioType11Event) event;

			if (ArrayUtils.isEmpty(bioEvent.getIrisRightNecFeatureData())
					&& ArrayUtils.isEmpty(bioEvent.getIrisLeftNecFeatureData())) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.IRIS_NEC,
					null);

			MeghaType11Event meghaEvent = new MeghaType11Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setIrisLeftFeatureData(bioEvent.getIrisLeftNecFeatureData());
			meghaEvent.setIrisRightFeatureData(bioEvent.getIrisRightNecFeatureData());

			meghaEvent.setIrisLeftQuality(
					bioEvent.getIrisLeftQuality() == null ? 0 : bioEvent.getIrisLeftQuality().byteValue());
			meghaEvent.setIrisRightQuality(
					bioEvent.getIrisRightQuality() == null ? 0 : bioEvent.getIrisRightQuality().byteValue());

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType12Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType12Template meghaTemplate = new MeghaType12Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;

		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType12Event)) {
				continue;
			}
			BioType12Event bioEvent = (BioType12Event) event;

			if (ArrayUtils.isEmpty(bioEvent.getIrisRightDeltaIdFeatureData())
					&& ArrayUtils.isEmpty(bioEvent.getIrisLeftDeltaIdFeatureData())) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					AlgorithmType.IRIS_DELTA_ID, null);

			MeghaType12Event meghaEvent = new MeghaType12Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setIrisLeftFeatureData(bioEvent.getIrisLeftDeltaIdFeatureData());
			meghaEvent.setIrisRightFeatureData(bioEvent.getIrisRightDeltaIdFeatureData());

			meghaEvent.setIrisLeftQuality(
					bioEvent.getIrisLeftQuality() == null ? 0 : bioEvent.getIrisLeftQuality().byteValue());
			meghaEvent.setIrisRightQuality(
					bioEvent.getIrisRightQuality() == null ? 0 : bioEvent.getIrisRightQuality().byteValue());

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType22Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType22Template meghaTemplate = new MeghaType22Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;

		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType12Event)) {
				continue;
			}
			BioType12Event bioEvent = (BioType12Event) event;

			if (ArrayUtils.isEmpty(bioEvent.getIrisRightDeltaIdFeatureData())
					&& ArrayUtils.isEmpty(bioEvent.getIrisLeftDeltaIdFeatureData())) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					AlgorithmType.IRIS_DELTA_ID, null);

			MeghaType22Event meghaEvent = new MeghaType22Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setIrisLeftFeatureData(bioEvent.getIrisLeftDeltaIdFeatureData());
			meghaEvent.setIrisRightFeatureData(bioEvent.getIrisRightDeltaIdFeatureData());

			meghaEvent.setIrisLeftQuality(
					bioEvent.getIrisLeftQuality() == null ? 0 : bioEvent.getIrisLeftQuality().byteValue());
			meghaEvent.setIrisRightQuality(
					bioEvent.getIrisRightQuality() == null ? 0 : bioEvent.getIrisRightQuality().byteValue());

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType31Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType31Template meghaTemplate = new MeghaType31Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType31Event)) {
				continue;
			}
			BioType31Event bioEvent = (BioType31Event) event;

			if (bioEvent.getCmlafFeatureData() == null || bioEvent.getCmlafFeatureData().length == 0) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.FINGER_CMLAF,
					null);

			MeghaType31Event meghaEvent = new MeghaType31Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setCmlafFeatureData(bioEvent.getCmlafFeatureData());
			meghaEvent.setQuality(buildFingerQualityBytes(bioEvent.getFingerQualities()));

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType32Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType32Template meghaTemplate = new MeghaType32Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType32Event)) {
				continue;
			}
			BioType32Event bioEvent = (BioType32Event) event;

			if (bioEvent.getRolledCmlafFeatureData() == null && bioEvent.getSlapCmlafFeatureData() == null) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.FINGER_CMLAF,
					null);

			MeghaType32Event meghaEvent = new MeghaType32Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setRolledCmlafFeatureData(bioEvent.getRolledCmlafFeatureData());
			meghaEvent.setSlapCmlafFeatureData(bioEvent.getSlapCmlafFeatureData());
			meghaEvent.setRolledQuality(buildFingerQualityBytes(bioEvent.getRolledFingerQualities()));
			meghaEvent.setSlapQuality(buildFingerQualityBytes(bioEvent.getSlapFingerQualities()));

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType33Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType33Template meghaTemplate = new MeghaType33Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType33Event)) {
				continue;
			}
			BioType33Event bioEvent = (BioType33Event) event;

			if (CollectionUtils.isEmpty(bioEvent.getFingerInfoList())) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					bioEvent.getAlgorithmType(), bioEvent.getFeType());

			MeghaType33Event meghaEvent = new MeghaType33Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			for (BioFingerFeatureInfo fingerInfo : bioEvent.getFingerInfoList()) {
				if (fingerInfo.getFingerPosition() < 1 || fingerInfo.getFingerPosition() > 20) {
					continue;
				}
				meghaEvent.addFingerInfo(fingerInfo.getFingerPosition(), fingerInfo.getPrimaryPatternType(),
						fingerInfo.getSecondaryPatternType(), fingerInfo.getQuality(), fingerInfo.getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType34Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType34Template meghaTemplate = new MeghaType34Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType34Event)) {
				continue;
			}
			BioType34Event bioEvent = (BioType34Event) event;

			if (bioEvent.getLatentFeatureData() == null || bioEvent.getLatentFeatureData().length == 0) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					bioEvent.getAlgorithmType(), bioEvent.getFeType());

			MeghaType34Event meghaEvent = new MeghaType34Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setFingerNumbers(buildLatentSelectFingers(bioEvent.getFingerNumbers()));
			meghaEvent.setLatentPatterns(buildLatentPatternBytes(bioEvent.getLatentPatterns()));
			meghaEvent.setLdbFeatureData(bioEvent.getLatentFeatureData());

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType35Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType35Template meghaTemplate = new MeghaType35Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType35Event)) {
				continue;
			}
			BioType35Event bioEvent = (BioType35Event) event;

			if (bioEvent.getCmlFeatureData() == null || bioEvent.getCmlFeatureData().length == 0) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.FINGER_CML,
					null);

			MeghaType35Event meghaEvent = new MeghaType35Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setCmlFeatureData(bioEvent.getCmlFeatureData());
			meghaEvent.setQuality(buildFingerQualityBytes(bioEvent.getFingerQualities()));
			meghaEvent.setMatchConfig(bioEvent.getMatchConfig());
			meghaEvent.setRollOrSlap(
					(byte) ((bioEvent.getIsRolledFlag() == null || bioEvent.getIsRolledFlag()) ? 'R' : 'S'));

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType36Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType36Template meghaTemplate = new MeghaType36Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType36Event)) {
				continue;
			}
			BioType36Event bioEvent = (BioType36Event) event;

			if (ArrayUtils.isEmpty(bioEvent.getRolledCmlFeatureData())
					&& ArrayUtils.isEmpty(bioEvent.getSlapCmlFeatureData())) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.FINGER_CML,
					null);

			MeghaType36Event meghaEvent = new MeghaType36Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setRolledCmlFeatureData(bioEvent.getRolledCmlFeatureData());
			meghaEvent.setSlapCmlFeatureData(bioEvent.getSlapCmlFeatureData());
			meghaEvent.setRolledQuality(buildFingerQualityBytes(bioEvent.getRolledFingerQualities()));
			meghaEvent.setSlapQuality(buildFingerQualityBytes(bioEvent.getSlapFingerQualities()));
			meghaEvent.setMatchConfig(bioEvent.getMatchConfig());

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType37Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType37Template meghaTemplate = new MeghaType37Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType37Event)) {
				continue;
			}
			BioType37Event bioEvent = (BioType37Event) event;

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.PALM_PC3R,
					BioFeType.P);

			MeghaType37Event meghaEvent = new MeghaType37Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			if (bioEvent.getFullLeft() != null) {
				meghaEvent.setFullLeft(bioEvent.getFullLeft().getQuality(), bioEvent.getFullLeft().getFeatureData());
			}
			if (bioEvent.getFullRight() != null) {
				meghaEvent.setFullRight(bioEvent.getFullRight().getQuality(), bioEvent.getFullRight().getFeatureData());
			}

			if (bioEvent.getWriterLeft() != null) {
				meghaEvent.setWriterLeft(bioEvent.getWriterLeft().getQuality(),
						bioEvent.getWriterLeft().getFeatureData());
			}
			if (bioEvent.getWriterRight() != null) {
				meghaEvent.setWriterRight(bioEvent.getWriterRight().getQuality(),
						bioEvent.getWriterRight().getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType38Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType38Template meghaTemplate = new MeghaType38Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType38Event)) {
				continue;
			}
			BioType38Event bioEvent = (BioType38Event) event;

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.PALM_PC3R,
					BioFeType.P);

			MeghaType38Event meghaEvent = new MeghaType38Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			if (bioEvent.getLowerRight() != null) {
				meghaEvent.setLowerRight(bioEvent.getLowerRight().getQuality(),
						bioEvent.getLowerRight().getFeatureData());
			}
			if (bioEvent.getUpperRight() != null) {
				meghaEvent.setUpperRight(bioEvent.getUpperRight().getQuality(),
						bioEvent.getUpperRight().getFeatureData());
			}
			if (bioEvent.getLowerLeft() != null) {
				meghaEvent.setLowerLeft(bioEvent.getLowerLeft().getQuality(), bioEvent.getLowerLeft().getFeatureData());
			}
			if (bioEvent.getUpperLeft() != null) {
				meghaEvent.setUpperLeft(bioEvent.getUpperLeft().getQuality(), bioEvent.getUpperLeft().getFeatureData());
			}

			if (bioEvent.getWriterLeft() != null) {
				meghaEvent.setWriterLeft(bioEvent.getWriterLeft().getQuality(),
						bioEvent.getWriterLeft().getFeatureData());
			}
			if (bioEvent.getWriterRight() != null) {
				meghaEvent.setWriterRight(bioEvent.getWriterRight().getQuality(),
						bioEvent.getWriterRight().getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType39Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType39Template meghaTemplate = new MeghaType39Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType39Event)) {
				continue;
			}
			BioType39Event bioEvent = (BioType39Event) event;

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.PALM_PC3R,
					BioFeType.P);

			MeghaType39Event meghaEvent = new MeghaType39Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			if (bioEvent.getInterDigitalRight() != null) {
				meghaEvent.setInterDigitalRight(bioEvent.getInterDigitalRight().getQuality(),
						bioEvent.getInterDigitalRight().getFeatureData());
			}
			if (bioEvent.getThenarRight() != null) {
				meghaEvent.setThenarRight(bioEvent.getThenarRight().getQuality(),
						bioEvent.getThenarRight().getFeatureData());
			}
			if (bioEvent.getHypothenarRight() != null) {
				meghaEvent.setHypothenarRight(bioEvent.getHypothenarRight().getQuality(),
						bioEvent.getHypothenarRight().getFeatureData());
			}

			if (bioEvent.getInterDigitalLeft() != null) {
				meghaEvent.setInterDigitalLeft(bioEvent.getInterDigitalLeft().getQuality(),
						bioEvent.getInterDigitalLeft().getFeatureData());
			}
			if (bioEvent.getThenarLeft() != null) {
				meghaEvent.setThenarLeft(bioEvent.getThenarLeft().getQuality(),
						bioEvent.getThenarLeft().getFeatureData());
			}
			if (bioEvent.getHypothenarLeft() != null) {
				meghaEvent.setHypothenarLeft(bioEvent.getHypothenarLeft().getQuality(),
						bioEvent.getHypothenarLeft().getFeatureData());
			}

			if (bioEvent.getWriterLeft() != null) {
				meghaEvent.setWriterLeft(bioEvent.getWriterLeft().getQuality(),
						bioEvent.getWriterLeft().getFeatureData());
			}
			if (bioEvent.getWriterRight() != null) {
				meghaEvent.setWriterRight(bioEvent.getWriterRight().getQuality(),
						bioEvent.getWriterRight().getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType40Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType40Template meghaTemplate = new MeghaType40Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType40Event)) {
				continue;
			}
			BioType40Event bioEvent = (BioType40Event) event;

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.PALM_PC3R,
					BioFeType.P);

			MeghaType40Event meghaEvent = new MeghaType40Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setPartNumbers(buildLatentSelectPartNumbers(bioEvent.getPartNumbers()));
			meghaEvent.setPc3PldbFeatureData(bioEvent.getLatentPc3FeatureData());

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType41Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType41Template meghaTemplate = new MeghaType41Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType41Event)) {
				continue;
			}
			BioType41Event bioEvent = (BioType41Event) event;

			if (CollectionUtils.isEmpty(bioEvent.getFingerInfoList())) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					bioEvent.getAlgorithmType(), bioEvent.getFeType());

			MeghaType41Event meghaEvent = new MeghaType41Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			for (BioFingerFeatureInfo fingerInfo : bioEvent.getFingerInfoList()) {
				if (fingerInfo.getFingerPosition() < 1 || fingerInfo.getFingerPosition() > 20) {
					continue;
				}
				meghaEvent.addFingerInfo(fingerInfo.getFingerPosition(), fingerInfo.getPrimaryPatternType(),
						fingerInfo.getSecondaryPatternType(), fingerInfo.getQuality(), fingerInfo.getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType42Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType42Template meghaTemplate = new MeghaType42Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType42Event)) {
				continue;
			}
			BioType42Event bioEvent = (BioType42Event) event;

			if (CollectionUtils.isEmpty(bioEvent.getFingerInfoList())) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					bioEvent.getAlgorithmType(), bioEvent.getFeType());

			MeghaType42Event meghaEvent = new MeghaType42Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			for (BioFingerFeatureInfo fingerInfo : bioEvent.getFingerInfoList()) {
				if (fingerInfo.getFingerPosition() < 1 || fingerInfo.getFingerPosition() > 20) {
					continue;
				}
				meghaEvent.addFingerInfo(fingerInfo.getFingerPosition(), fingerInfo.getPrimaryPatternType(),
						fingerInfo.getSecondaryPatternType(), fingerInfo.getQuality(), fingerInfo.getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType43Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType43Template meghaTemplate = new MeghaType43Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType43Event)) {
				continue;
			}
			BioType43Event bioEvent = (BioType43Event) event;

			if (CollectionUtils.isEmpty(bioEvent.getFingerInfoList())) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					bioEvent.getAlgorithmType(), bioEvent.getFeType());

			MeghaType43Event meghaEvent = new MeghaType43Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			for (BioFingerFeatureInfo fingerInfo : bioEvent.getFingerInfoList()) {
				if (fingerInfo.getFingerPosition() < 1 || fingerInfo.getFingerPosition() > 20) {
					continue;
				}
				meghaEvent.addFingerInfo(fingerInfo.getFingerPosition(), fingerInfo.getPrimaryPatternType(),
						fingerInfo.getSecondaryPatternType(), fingerInfo.getQuality(), fingerInfo.getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType44Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType44Template meghaTemplate = new MeghaType44Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType44Event)) {
				continue;
			}
			BioType44Event bioEvent = (BioType44Event) event;

			if (bioEvent.getLatentFeatureData() == null || bioEvent.getLatentFeatureData().length == 0) {
				throw new MeghaTemplateException("Feature data is not set for the event payload");
			}

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(),
					bioEvent.getAlgorithmType(), bioEvent.getFeType());

			MeghaType44Event meghaEvent = new MeghaType44Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setFingerNumbers(buildLatentSelectFingers(bioEvent.getFingerNumbers()));
			meghaEvent.setLatentPatterns(buildLatentPatternBytes(bioEvent.getLatentPatterns()));
			meghaEvent.setManualEdit((byte) (Boolean.TRUE.equals(bioEvent.getManualEditFlag()) ? 1 : 0));
			meghaEvent.setLfmlFeatureData(bioEvent.getLatentFeatureData());

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType45Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType45Template meghaTemplate = new MeghaType45Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType45Event)) {
				continue;
			}
			BioType45Event bioEvent = (BioType45Event) event;

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.PALM_LFML,
					BioFeType.P);

			MeghaType45Event meghaEvent = new MeghaType45Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			if (bioEvent.getFullLeft() != null) {
				meghaEvent.setFullLeft(bioEvent.getFullLeft().getQuality(), bioEvent.getFullLeft().getFeatureData());
			}
			if (bioEvent.getFullRight() != null) {
				meghaEvent.setFullRight(bioEvent.getFullRight().getQuality(), bioEvent.getFullRight().getFeatureData());
			}

			if (bioEvent.getWriterLeft() != null) {
				meghaEvent.setWriterLeft(bioEvent.getWriterLeft().getQuality(),
						bioEvent.getWriterLeft().getFeatureData());
			}
			if (bioEvent.getWriterRight() != null) {
				meghaEvent.setWriterRight(bioEvent.getWriterRight().getQuality(),
						bioEvent.getWriterRight().getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType46Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType46Template meghaTemplate = new MeghaType46Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType46Event)) {
				continue;
			}
			BioType46Event bioEvent = (BioType46Event) event;

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.PALM_LFML,
					BioFeType.P);

			MeghaType46Event meghaEvent = new MeghaType46Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			
			if (bioEvent.getLowerRight() != null) {
				meghaEvent.setLowerRight(bioEvent.getLowerRight().getQuality(),
						bioEvent.getLowerRight().getFeatureData());
			}
			if (bioEvent.getLowerLeft() != null) {
				meghaEvent.setLowerLeft(bioEvent.getLowerLeft().getQuality(),
						bioEvent.getLowerLeft().getFeatureData());
			}
			
			if (bioEvent.getUpperRight() != null) {
				meghaEvent.setUpperRight(bioEvent.getUpperRight().getQuality(),
						bioEvent.getUpperRight().getFeatureData());
			}
			if (bioEvent.getUpperLeft() != null) {
				meghaEvent.setUpperLeft(bioEvent.getUpperLeft().getQuality(),
						bioEvent.getUpperLeft().getFeatureData());
			}

			if (bioEvent.getWriterLeft() != null) {
				meghaEvent.setWriterLeft(bioEvent.getWriterLeft().getQuality(),
						bioEvent.getWriterLeft().getFeatureData());
			}
			if (bioEvent.getWriterRight() != null) {
				meghaEvent.setWriterRight(bioEvent.getWriterRight().getQuality(),
						bioEvent.getWriterRight().getFeatureData());
			}
			
			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType48Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType48Template meghaTemplate = new MeghaType48Template((meghaTemplateConfig.getUserFlagByteCount()));

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType40Event)) {
				continue;
			}
			BioType48Event bioEvent = (BioType48Event) event;

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.PALM_LFML,
					BioFeType.P);

			MeghaType48Event meghaEvent = new MeghaType48Event();
			meghaEvent.setEventHeader(meghaEventHeader);
			meghaEvent.setPartNumbers(buildLatentSelectPartNumbers(bioEvent.getPartNumbers()));
			meghaEvent.setLfmlPldbFeatureData(bioEvent.getLatentLfmlPalmFeatureData());

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	public static byte[] packType47Template(BioTemplatePayload bioTemplatePayload,
			MeghaTemplateConfig meghaTemplateConfig, int templateTypeCode) throws MeghaTemplateException {

		if (CollectionUtils.isEmpty(bioTemplatePayload.getEvents())) {
			throw new MeghaTemplateException("Event information is not set in template payload");
		}

		MeghaType47Template meghaTemplate = new MeghaType47Template(meghaTemplateConfig.getUserFlagByteCount());

		MeghaTemplateHeader meghaTemplateHeader = buildMeghaTemplateHeader(bioTemplatePayload.getTemplateHeader(),
				meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.setTemplateHeader(meghaTemplateHeader);

		int eventIndex = 0;
		for (BioTemplateEvent event : bioTemplatePayload.getEvents()) {
			if (!(event instanceof BioType47Event)) {
				continue;
			}
			BioType47Event bioEvent = (BioType47Event) event;

			MeghaEventHeader meghaEventHeader = buildMeghaEventHeader(bioEvent.getEventId(), AlgorithmType.PALM_LFML,
					BioFeType.P);

			MeghaType47Event meghaEvent = new MeghaType47Event();
			meghaEvent.setEventHeader(meghaEventHeader);

			if (bioEvent.getInterDigitalRight() != null) {
				meghaEvent.setInterDigitalRight(bioEvent.getInterDigitalRight().getQuality(), bioEvent.getInterDigitalRight().getFeatureData());
			}
			if (bioEvent.getThenarRight() != null) {
				meghaEvent.setThenarRight(bioEvent.getThenarRight().getQuality(), bioEvent.getThenarRight().getFeatureData());
			}
			if (bioEvent.getHypothenarRight() != null) {
				meghaEvent.setHypothenarRight(bioEvent.getHypothenarRight().getQuality(), bioEvent.getHypothenarRight().getFeatureData());
			}

			if (bioEvent.getInterDigitalLeft() != null) {
				meghaEvent.setInterDigitalLeft(bioEvent.getInterDigitalLeft().getQuality(), bioEvent.getInterDigitalLeft().getFeatureData());
			}
			if (bioEvent.getThenarLeft() != null) {
				meghaEvent.setThenarLeft(bioEvent.getThenarLeft().getQuality(), bioEvent.getThenarLeft().getFeatureData());
			}
			if (bioEvent.getHypothenarLeft() != null) {
				meghaEvent.setHypothenarLeft(bioEvent.getHypothenarLeft().getQuality(), bioEvent.getHypothenarLeft().getFeatureData());
			}

			if (bioEvent.getWriterLeft() != null) {
				meghaEvent.setWriterLeft(bioEvent.getWriterLeft().getQuality(), bioEvent.getWriterLeft().getFeatureData());
			}
			if (bioEvent.getWriterRight() != null) {
				meghaEvent.setWriterRight(bioEvent.getWriterRight().getQuality(), bioEvent.getWriterRight().getFeatureData());
			}

			meghaTemplate.getEventMap().put(eventIndex, meghaEvent);
			eventIndex++;
		}

		if (eventIndex == 0) {
			throw new MeghaTemplateException("Required event information is not set in template payload");
		}

		byte templateBuf[] = meghaTemplate.pack(meghaTemplateConfig);

		return templateBuf;
	}

	private static byte[] buildLatentSelectFingers(Set<ImagePosition> fingerNumbers) {
		byte[] fingerNumberBytes = new byte[10];

		if (fingerNumbers != null && fingerNumbers.size() > 0) {
			// Sort
			TreeSet<Byte> fingerNumbersSet = new TreeSet<>();
			for (ImagePosition fingerNumber : fingerNumbers) {
				fingerNumbersSet.add((byte) fingerNumber.getPosition());
			}

			Iterator<Byte> iterator = fingerNumbersSet.iterator();
			for (int i = 0; i < fingerNumberBytes.length && iterator.hasNext(); i++) {
				fingerNumberBytes[i] = iterator.next();
			}
		}

		return fingerNumberBytes;
	}

	private static byte[] buildLatentSelectPartNumbers(Set<ImagePosition> palmParts) {
		byte[] palmPartsBytes = new byte[17];

		if (palmParts != null && palmParts.size() > 0) {
			// Sort
			TreeSet<Byte> palmPartsSet = new TreeSet<>();
			for (ImagePosition palmPart : palmParts) {
				palmPartsSet.add((byte) palmPart.getPosition());
			}

			Iterator<Byte> iterator = palmPartsSet.iterator();
			for (int i = 0; i < palmPartsBytes.length && iterator.hasNext(); i++) {
				palmPartsBytes[i] = iterator.next();
			}
		}

		return palmPartsBytes;
	}

	private static byte[] buildLatentPatternBytes(PatternType[] patternTypes) {
		byte[] patternBytes = new byte[7];

		if (patternTypes != null) {
			for (int i = 0; i < 7 && i < patternTypes.length; i++) {
				patternBytes[i] = (byte) patternTypes[i].getValue();
			}
		}
		return patternBytes;
	}

	private static byte[] buildFingerQualityBytes(Integer[] fingerQualities) {
		byte[] qualityBytes = new byte[10];

		if (fingerQualities != null) {
			for (int i = 0; i < 10 && i < fingerQualities.length; i++) {
				qualityBytes[i] = fingerQualities[i].byteValue();
			}
		}
		return qualityBytes;
	}

	private static MeghaEventHeader buildMeghaEventHeader(String eventId, AlgorithmType algorithmType,
			BioFeType feType) {
		MeghaEventHeader meghaEventHeader = new MeghaEventHeader();

		if (eventId != null) {
			meghaEventHeader.setEventId(eventId);
		}

		if (algorithmType != null) {
			meghaEventHeader.setAlgType(algorithmType.getValue().byteValue());
		}

		if (feType != null && feType.name().length() == 1) {
			meghaEventHeader.setFeType((byte) feType.name().charAt(0));
		}

		return meghaEventHeader;
	}

	private static MeghaTemplateHeader buildMeghaTemplateHeader(BioTemplateHeader bioTemplateHeader,
			int userFlagByteCount) {
		MeghaTemplateHeader meghaTemplateHeader = new MeghaTemplateHeader(userFlagByteCount);
		meghaTemplateHeader.setExternalId(bioTemplateHeader.getExternalId());
		meghaTemplateHeader.setYob(bioTemplateHeader.getYob());
		meghaTemplateHeader.setRace(bioTemplateHeader.getRace());

		if (bioTemplateHeader.getGender() != null) {
			meghaTemplateHeader.setGender(getMeghaGender(bioTemplateHeader.getGender()));
		}

		byte[] userFlags = new byte[userFlagByteCount];
		if (bioTemplateHeader.getUserFlags() != null) {
			System.arraycopy(bioTemplateHeader.getUserFlags(), 0, userFlags, 0,
					Math.min(bioTemplateHeader.getUserFlags().length, userFlags.length));
		}
		meghaTemplateHeader.setUserFlags(userFlags);

		byte[] regionFlags = new byte[8];
		if (bioTemplateHeader.getRegionFlags() != null) {
			System.arraycopy(bioTemplateHeader.getRegionFlags(), 0, regionFlags, 0,
					Math.min(bioTemplateHeader.getRegionFlags().length, regionFlags.length));
		}
		meghaTemplateHeader.setRegionFlags(regionFlags);

		return meghaTemplateHeader;
	}

	private static byte getMeghaGender(GenderEnum gender) {
		if (gender == null) {
			return 'U';
		}

		switch (gender) {
		case F:
			return 'F';
		case M:
			return 'M';
		case U:
			return 'U';
		default:
			return 'U';
		}
	}

	private static void dumpTemplateFile(TemplateType templateType, byte[] templateData) {
		try {
			File templateFile = File.createTempFile(templateType.name() + "_", ".dat");
			FileUtils.writeByteArrayToFile(templateFile, templateData);
			logger.info("In dumpTemplate: templateFile: " + templateFile.getAbsolutePath());
		} catch (Throwable th) {

		}
	}

}
