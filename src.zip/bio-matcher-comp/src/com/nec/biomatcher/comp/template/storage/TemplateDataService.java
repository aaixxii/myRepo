package com.nec.biomatcher.comp.template.storage;

import com.nec.biomatcher.comp.template.storage.exception.TemplateDataNotFoundException;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataServiceException;

/**
 * The Interface TemplateDataService.
 */
public interface TemplateDataService {

	/**
	 * Save template data.
	 *
	 * @param binId
	 *            the bin id
	 * @param biometricId
	 *            the biometric id
	 * @param templateData
	 *            the template data
	 * @return the string
	 * @throws TemplateDataServiceException
	 *             the template data service exception
	 */
	public String saveTemplateData(Integer binId, Long biometricId, byte[] templateData)
			throws TemplateDataServiceException;

	/**
	 * Update template data.
	 *
	 * @param templateDataKey
	 *            the template data key
	 * @param templateData
	 *            the template data
	 * @throws TemplateDataServiceException
	 *             the template data service exception
	 */
	public void updateTemplateData(String templateDataKey, byte[] templateData) throws TemplateDataServiceException;

	/**
	 * Delete template data.
	 *
	 * @param templateDataKey
	 *            the template data key
	 * @throws TemplateDataServiceException
	 *             the template data service exception
	 */
	public void deleteTemplateData(String templateDataKey) throws TemplateDataServiceException;

	/**
	 * Gets the template data.
	 *
	 * @param templateDataKey
	 *            the template data key
	 * @return the template data
	 * @throws TemplateDataServiceException
	 *             the template data service exception
	 */
	public byte[] getTemplateData(String templateDataKey)
			throws TemplateDataServiceException, TemplateDataNotFoundException;
}
