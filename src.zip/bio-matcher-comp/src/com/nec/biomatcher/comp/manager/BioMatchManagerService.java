package com.nec.biomatcher.comp.manager;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioRemoteSiteSyncInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.manager.exception.BioMatchManagerException;
import com.nec.biomatcher.core.framework.cache.MethodCache;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;

/**
 * The Interface BioMatchManagerService.
 */
public interface BioMatchManagerService {

	public BioServerInfo getServerInfo(String serverId) throws BioMatchManagerException;

	public List<BioServerInfo> getServerInfoListByComponentType(BioComponentType componentType,
			BioServerState serverState) throws BioMatchManagerException;

	public BioRemoteSiteSyncInfo getRemoteSiteSyncInfo(String siteId, Integer segmentId)
			throws BioMatchManagerException;

	public void updateRemoteSiteSyncSegmentVersion(String siteId, Integer segmentId, Long segmentVersion,
			BiometricEventStatus biometricEventStatus) throws BioMatchManagerException;

	public void updateRemoteSiteSyncSegmentVersion(String siteId, Map<Integer, Long> segmentVersionMap,
			BiometricEventStatus biometricEventStatus) throws BioMatchManagerException;

	public BioMatcherSegmentInfo getMatcherSegmentInfo(Integer segmentId) throws BioMatchManagerException;

	public Long getMaxMatcherNodeSegmentVersion(Integer segmentId) throws BioMatchManagerException;

	public List<BioMatcherNodeSegmentInfo> getMatcherNodeSegmentInfoList() throws BioMatchManagerException;

	public int updateMatcherSegmentVersion(Integer segmentId, Long segmentVersion) throws BioMatchManagerException;

	public int updateMatcherNodeSegmentVersion(String matcherNodeId, Map<Integer, Long> segmentIdVersionMap)
			throws BioMatchManagerException;

	public BioMatcherNodeSegmentInfo getMatcherNodeSegmentInfo(String searchNodeId, Integer segmentId)
			throws BioMatchManagerException;

	public List<BioMatcherNodeSegmentInfo> getMatcherNodeSegmentInfoList(String searchNodeId)
			throws BioMatchManagerException;

	public List<BioMatcherSegmentInfo> getMatcherSegmentInfoList() throws BioMatchManagerException;

	public List<BioMatcherSegmentInfo> getMatcherSegmentInfoListByBinId(Integer binId) throws BioMatchManagerException;

	public Map<Integer, Long> getMatcherSegmentVersionMapBySearchBrokerId(String searchBrokerId)
			throws BioMatchManagerException;

	@MethodCache(timeToLiveSeconds = 5, timeToLiveSecondsParamName = "LIVE_MATCHER_SEGMENT_VERSION_TTL_SECONDS")
	public Map<Integer, Long> getLiveMatcherSegmentVersionMap(Integer binId) throws BioMatchManagerException;

	// @MethodCache(timeToLiveSeconds=1,
	// timeToLiveSecondsParamName="LIVE_MATCHER_NODE_SEGMENT_VERSION_TTL_SECONDS")
	@MethodCache
	public ConcurrentHashMap<Integer, Long> getLiveMatcherNodeSegmentVersionMap(String searchNodeId)
			throws BioMatchManagerException;

	@MethodCache(timeToLiveSeconds = 30, timeToLiveSecondsParamName = "EVENT_COUNT_BY_BINID_SEGMENTID_TTL_SECONDS")
	public Map<BiKey<Integer, Integer>, Long> getEventCountByBinIdSegmentId() throws BioMatchManagerException;
}
