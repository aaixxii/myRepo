package com.nec.biomatcher.comp.manager.dataAccess.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdDetailInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.manager.dataAccess.BioMatchManagerDao;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDaoException;

/**
 * The Class BioMatchManagerHibernateImpl.
 */
public class BioMatchManagerHibernateImpl extends AbstractHibernateDao implements BioMatchManagerDao {

	public int updateMatcherSegmentVersion(Integer segmentId, Long segmentVersion) throws DaoException {
		try {
			String hql = "update BioMatcherSegmentInfo set segmentVersion=:segmentVersion, updateDateTime = :updateDateTime where segmentId=:segmentId and segmentVersion<:segmentVersion";

			int updateCount = this.currentSession().createQuery(hql).setInteger("segmentId", segmentId)
					.setLong("segmentVersion", segmentVersion).setTimestamp("updateDateTime", new Date())
					.executeUpdate();

			return updateCount;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

	public int updateMatcherNodeSegmentVersion(String matcherNodeId, Map<Integer, Long> segmentIdVersionMap)
			throws DaoException {
		try {
			String hql = "update BioMatcherNodeSegmentInfo set segmentVersion=:segmentVersion, updateDateTime = :updateDateTime where matcherNodeId=:matcherNodeId and segmentId=:segmentId";
			int updateCount = 0;
			for (Entry<Integer, Long> entry : segmentIdVersionMap.entrySet()) {
				Integer segmentId = entry.getKey();
				Long segmentVersion = entry.getValue();

				if (segmentId != null && segmentVersion != null) {
					int count = this.currentSession().createQuery(hql).setString("matcherNodeId", matcherNodeId)
							.setInteger("segmentId", segmentId).setLong("segmentVersion", segmentVersion)
							.setTimestamp("updateDateTime", new Date()).executeUpdate();

					updateCount += count;
				}
			}
			return updateCount;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

	@SuppressWarnings("rawtypes")
	public Map<BiKey<Integer, Integer>, Long> getEventCountByBinIdSegmentId() throws DaoException {
		try {
			Map<BiKey<Integer, Integer>, Long> eventCountByBinSegmentMap = new HashMap<>();

			List<BiometricIdInfo> biometricIdInfoList = getAllEntity(BiometricIdInfo.class);

			biometricIdInfoList.forEach((biometricIdInfo) -> {
				long delta = (biometricIdInfo.getCurrentBiometricId() > 0L) ? (biometricIdInfo.getCurrentBiometricId()
						- Math.max(1L, biometricIdInfo.getStartBiometricId())) : 0L;
				BiKey<Integer, Integer> binIdSegmentIdKey = new BiKey<>(biometricIdInfo.getBinId(),
						biometricIdInfo.getSegmentId());

				eventCountByBinSegmentMap.compute(binIdSegmentIdKey, (oldBinIdSegmentIdKey, oldCount) -> {
					return oldCount == null ? delta : delta + oldCount;
				});

			});

			List deletedCountList = this.currentSession().createCriteria(BiometricIdDetailInfo.class)
					.add(Restrictions.eq("reuseFlag", Boolean.TRUE))
					.setProjection(Projections.projectionList().add(Projections.groupProperty("binId"))
							.add(Projections.groupProperty("segmentId")).add(Projections.rowCount()))
					.list();

			for (Object obj : deletedCountList) {
				Object[] objArr = (Object[]) obj;

				Integer binId = ((Number) objArr[0]).intValue();
				Integer segmentId = ((Number) objArr[1]).intValue();
				Long deletedCount = -1L * ((Number) objArr[2]).longValue();

				BiKey<Integer, Integer> binIdSegmentIdKey = new BiKey<>(binId, segmentId);

				eventCountByBinSegmentMap.compute(binIdSegmentIdKey, (oldBinIdSegmentIdKey, oldCount) -> {
					return oldCount == null ? deletedCount : oldCount + deletedCount;
				});
			}

			return eventCountByBinSegmentMap;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}

	public Long getMaxMatcherNodeSegmentVersion(Integer segmentId) throws DaoException {
		try {

			Number maxSegmentVersion = (Number) this.currentSession().createCriteria(BioMatcherNodeSegmentInfo.class)
					.add(Restrictions.eq("segmentId", segmentId)).setProjection(Projections.max("segmentVersion"))
					.uniqueResult();

			if (maxSegmentVersion != null) {
				return maxSegmentVersion.longValue();
			}

			return -1L;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}
}
