package com.nec.biomatcher.comp.entities.dataAccess.types;

import javax.xml.bind.annotation.XmlEnum;

/**
 * The Enum BioMatcherGroupType.
 */
@XmlEnum
public enum BioMatcherGroupType {

	/** The data. */
	DATA("Data"),

	/** The job. */
	JOB("Job");

	/** The description. */
	private String description;

	/**
	 * Instantiates a new bio matcher group type.
	 *
	 * @param description
	 *            the description
	 */
	private BioMatcherGroupType(String description) {
		this.description = description;
	}

	/**
	 * Gets the description.
	 * 
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

}
