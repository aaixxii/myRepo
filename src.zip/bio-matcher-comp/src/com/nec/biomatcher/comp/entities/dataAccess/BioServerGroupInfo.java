package com.nec.biomatcher.comp.entities.dataAccess;

import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioServerGroupInfo.
 */
public class BioServerGroupInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The group id. */
	private String groupId;

	/** The component type. */
	private BioComponentType componentType;

	/** The description. */
	private String description;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public BioComponentType getComponentType() {
		return componentType;
	}

	public void setComponentType(BioComponentType componentType) {
		this.componentType = componentType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
