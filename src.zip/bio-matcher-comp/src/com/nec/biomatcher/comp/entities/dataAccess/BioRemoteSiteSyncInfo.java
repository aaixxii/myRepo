package com.nec.biomatcher.comp.entities.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

public class BioRemoteSiteSyncInfo implements Dbo {
	private static final long serialVersionUID = 1L;

	private String siteId;
	private Integer segmentId;
	private Long insertSegmentVersion;
	private Long deleteSegmentVersion;
	private Date updateDateTime;

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public Long getInsertSegmentVersion() {
		return insertSegmentVersion;
	}

	public void setInsertSegmentVersion(Long insertSegmentVersion) {
		this.insertSegmentVersion = insertSegmentVersion;
	}

	public Long getDeleteSegmentVersion() {
		return deleteSegmentVersion;
	}

	public void setDeleteSegmentVersion(Long deleteSegmentVersion) {
		this.deleteSegmentVersion = deleteSegmentVersion;
	}
}
