package com.nec.biomatcher.comp.entities.dataAccess.types;

import javax.xml.bind.annotation.XmlEnum;

/**
 * The Enum BioLocationType.
 */
@XmlEnum
public enum BioLocationType {

	/** The local. */
	LOCAL,

	/** The remote. */
	REMOTE;
}
