package com.nec.biomatcher.comp.entities.dataAccess.types;

/**
 * The Enum BioProtocolType.
 */
public enum BioProtocolType {

	/** The soap. */
	SOAP,

	/** The hessian. */
	HESSIAN,

	/** The http. */
	HTTP,

	/** The tcp. */
	TCP,

	/** The zeromq. */
	ZEROMQ,

	/** The jms. */
	JMS,

	/** The ssh. */
	SSH,

	/** The hazelcast. */
	HAZELCAST;

	public String toString() {
		return name();
	}
}
