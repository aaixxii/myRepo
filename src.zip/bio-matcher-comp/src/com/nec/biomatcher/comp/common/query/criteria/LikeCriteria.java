package com.nec.biomatcher.comp.common.query.criteria;

/**
 * Criteria for specifying like condition.
 *
 * @author Mahesh
 */
public class LikeCriteria extends CriteriaDto implements ValueCriteriaDto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The value. */
	private String value;

	/**
	 * Instantiates a new like criteria.
	 */
	public LikeCriteria() {

	}

	/**
	 * Instantiates a new like criteria.
	 *
	 * @param value
	 *            the value
	 */
	public LikeCriteria(String value) {
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
