package com.nec.biomatcher.comp.common.sequence;

import java.util.Date;

import com.nec.biomatcher.comp.common.sequence.dataAccess.BioSequenceNumber;
import com.nec.biomatcher.comp.common.sequence.exception.BioSequenceGeneratorException;
import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;

/**
 * This interface provides the function to generate sequence number using the
 * BIO_SEQUENCES table.
 *
 * @author Alvin Chua
 * @version 1.0
 * @since 24 Oct 2014
 */
public interface BioSequenceGenerator {

	public static final String DEFAULT_SEQUENCE_GROUP = "DEFAULT";

	/**
	 * Creates the.
	 *
	 * @param sequenceName
	 *            the sequence name
	 * @param groupName
	 *            the group name
	 * @param max
	 *            the max
	 * @param min
	 *            the min
	 * @param value
	 *            the value
	 * @param resetPolicy
	 *            the reset policy
	 * @return the bio sequence number
	 * @throws Exception
	 *             the exception
	 */
	public BioSequenceNumber create(String sequenceName, String groupName, Long max, Long min, Long value,
			Integer resetPolicy) throws Exception;

	/**
	 * Update sequence.
	 *
	 * @param sequenceNumber
	 *            the sequence number
	 * @param userIdm
	 *            the user idm
	 * @param terminalId
	 *            the terminal id
	 * @throws Exception
	 *             the exception
	 */
	public void updateSequence(BioSequenceNumber sequenceNumber, String userIdm, String terminalId) throws Exception;

	/**
	 * Reset.
	 *
	 * @param sequenceName
	 *            the sequence name
	 * @param groupName
	 *            the group name
	 * @param resetTimeStamp
	 *            the reset time stamp
	 * @throws Exception
	 *             the exception
	 */
	public void reset(String sequenceName, String groupName, Date resetTimeStamp) throws Exception;

	/**
	 * Delete.
	 *
	 * @param sequenceName
	 *            the sequence name
	 * @param groupName
	 *            the group name
	 * @throws Exception
	 *             the exception
	 */
	public void delete(String sequenceName, String groupName) throws Exception;

	/**
	 * Next.
	 *
	 * @param name
	 *            the name
	 * @param group
	 *            the group
	 * @param maximum
	 *            the maximum
	 * @param minimum
	 *            the minimum
	 * @param resetPolicy
	 *            the reset policy
	 * @return the long
	 * @throws BioSequenceGeneratorException
	 *             the bio sequence generator exception
	 */
	public Long next(String name, String group, Long maximum, Long minimum, Integer resetPolicy)
			throws BioSequenceGeneratorException;

	/**
	 * Next.
	 *
	 * @param name
	 *            the name
	 * @param group
	 *            the group
	 * @param incrementBy
	 *            the increment by
	 * @return the long
	 * @throws BioSequenceGeneratorException
	 *             the bio sequence generator exception
	 */
	public Long next(String name, String group, int incrementBy) throws BioSequenceGeneratorException;

	/**
	 * Gets the.
	 *
	 * @param sequenceName
	 *            the sequence name
	 * @param groupName
	 *            the group name
	 * @return the bio sequence number
	 * @throws Exception
	 *             the exception
	 */
	public BioSequenceNumber get(String sequenceName, String groupName) throws Exception;

	/**
	 * Get all the sequences pagination.
	 *
	 * @param pageRequest
	 *            the page request
	 * @param userId
	 *            the user id
	 * @param terminalId
	 *            the terminal id
	 * @return the all sequences
	 * @throws Exception
	 *             the exception
	 */
	public PageResult<BioSequenceNumber> getAllSequences(PageRequest pageRequest, String userId, String terminalId)
			throws Exception;

}
