package com.nec.biomatcher.comp.common.errorlog.dataAccess.impl;

import com.nec.biomatcher.comp.common.errorlog.dataAccess.BioMatcherErrorLogDao;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;

public class BioMatcherErrorLogHibernateImpl extends AbstractHibernateDao implements BioMatcherErrorLogDao {

}
