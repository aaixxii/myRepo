package com.nec.biomatcher.comp.common.sequence.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioSequenceGeneratorException.
 */
public class BioSequenceGeneratorException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio sequence generator exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioSequenceGeneratorException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio sequence generator exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioSequenceGeneratorException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio sequence generator exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioSequenceGeneratorException(Throwable cause) {
		super(cause);
	}

}
