package com.nec.biomatcher.comp.common.query.criteria;

/**
 * Criteria for specifying null condition.
 *
 * @author Mahesh
 */
public class NullCriteria extends CriteriaDto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

}
