package com.nec.biomatcher.comp.common.errorlog.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioMatcherErrorLogInfo.
 */
public class BioMatcherErrorLogInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The error log id. */
	private String errorLogId;

	/** The error host. */
	private String errorHost;

	/** The error source. */
	private String errorSource;

	private String errorCode;

	/** The error message. */
	private String errorMessage;

	/** The exception detail. */
	private String exceptionDetail;

	/** The reference key1. */
	private String referenceKey1;

	/** The reference key2. */
	private String referenceKey2;

	/** The create date time. */
	private Date createDateTime;

	public String getErrorLogId() {
		return errorLogId;
	}

	public void setErrorLogId(String errorLogId) {
		this.errorLogId = errorLogId;
	}

	public String getErrorHost() {
		return errorHost;
	}

	public void setErrorHost(String errorHost) {
		this.errorHost = errorHost;
	}

	public String getErrorSource() {
		return errorSource;
	}

	public void setErrorSource(String errorSource) {
		this.errorSource = errorSource;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getExceptionDetail() {
		return exceptionDetail;
	}

	public void setExceptionDetail(String exceptionDetail) {
		this.exceptionDetail = exceptionDetail;
	}

	public String getReferenceKey1() {
		return referenceKey1;
	}

	public void setReferenceKey1(String referenceKey1) {
		this.referenceKey1 = referenceKey1;
	}

	public String getReferenceKey2() {
		return referenceKey2;
	}

	public void setReferenceKey2(String referenceKey2) {
		this.referenceKey2 = referenceKey2;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
