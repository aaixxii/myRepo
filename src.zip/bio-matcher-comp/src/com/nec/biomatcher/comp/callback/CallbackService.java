package com.nec.biomatcher.comp.callback;

public interface CallbackService {
	public static boolean isBatchCallbackUrl(String url) {
		return url.endsWith("#batchCallback");
	}

	public void postCallback(String url, String body) throws Exception;

	public void postBatchCallback(String url) throws Exception;
}
