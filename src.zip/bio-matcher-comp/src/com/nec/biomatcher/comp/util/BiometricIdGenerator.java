package com.nec.biomatcher.comp.util;

import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.bioevent.BiometricIdService;
import com.nec.biomatcher.comp.bioevent.exception.BiometricIdServiceException;
import com.nec.biomatcher.comp.bioevent.util.RoundRobinAcquireBiometricIdsFunction;
import com.nec.biomatcher.comp.bioevent.util.StickyAcquireBiometricIdsFunction;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdDetailInfo;
import com.nec.biomatcher.core.framework.common.concurrent.KeyedPreLoadProducer;

/**
 * The Class BiometricIdGenerator.
 */
public class BiometricIdGenerator implements InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BiometricIdGenerator.class);

	/** The biometric id service. */
	private BiometricIdService biometricIdService;

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	private KeyedPreLoadProducer<Integer, BiometricIdDetailInfo> biometricIdProducer;

	private RoundRobinAcquireBiometricIdsFunction roundRobinAcquireBiometricIdsFunction;
	private StickyAcquireBiometricIdsFunction stickyAcquireBiometricIdsFunction;

	/**
	 * Acquire biometric id.
	 *
	 * @param binId
	 *            the bin id
	 * @return the biometric id detail info
	 * @throws BiometricIdServiceException
	 *             the biometric id service exception
	 */
	public BiometricIdDetailInfo acquireBiometricId(Integer binId) throws BiometricIdServiceException {
		long startTimeMilli = System.currentTimeMillis();
		try {
			return biometricIdProducer.take(binId);
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error during acquireBiometricId: " + th.getMessage(), th);
		} finally {
			long acquireBiometricIdTimeTakenMilli = System.currentTimeMillis() - startTimeMilli;
			if (logger.isTraceEnabled() || acquireBiometricIdTimeTakenMilli > 100) {
				logger.info("In acquireBiometricId for binId: " + binId + ", TimeTakenMilli: "
						+ acquireBiometricIdTimeTakenMilli);
			}
		}
	}

	/**
	 * Release biometric ids.
	 *
	 * @param releasedBiometricIdList
	 *            the released biometric id list
	 * @throws BiometricIdServiceException
	 *             the biometric id service exception
	 */
	public void releaseBiometricIds(List<BiometricIdDetailInfo> releasedBiometricIdList)
			throws BiometricIdServiceException {
		biometricIdService.releaseBiometricIds(releasedBiometricIdList);
	}

	public void commitAcquiredBiometricIdList(List<Long> commitBiometricIdList) throws BiometricIdServiceException {
		biometricIdService.commitAcquiredBiometricIdList(commitBiometricIdList);
	}

	private final List<BiometricIdDetailInfo> preAcquireBiometricIds(Integer binId) throws BiometricIdServiceException {
		try {
			boolean useStickyBiometricIdGenerator = bioParameterService
					.getParameterValue("USE_STICKY_BIOMETRIC_ID_GENERATOR_FLAG", "DEFAULT", false);

			if (useStickyBiometricIdGenerator) {
				return stickyAcquireBiometricIdsFunction.apply(binId);
			} else {
				return roundRobinAcquireBiometricIdsFunction.apply(binId);
			}
		} catch (Throwable th) {
			if (th.getCause() instanceof BiometricIdServiceException) {
				throw (BiometricIdServiceException) th.getCause();
			}

			throw new BiometricIdServiceException(
					"Error in preAcquireBiometricIds for binId: " + binId + " : " + th.getMessage(), th);
		}
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBiometricIdService(BiometricIdService biometricIdService) {
		this.biometricIdService = biometricIdService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In BiometricIdGenerator.afterPropertiesSet");

		biometricIdService.releaseOldBiometricIdsByAcquireHost();

		roundRobinAcquireBiometricIdsFunction = new RoundRobinAcquireBiometricIdsFunction();
		roundRobinAcquireBiometricIdsFunction.setBioMatcherConfigService(bioMatcherConfigService);
		roundRobinAcquireBiometricIdsFunction.setBiometricIdService(biometricIdService);
		roundRobinAcquireBiometricIdsFunction.setBioParameterService(bioParameterService);

		stickyAcquireBiometricIdsFunction = new StickyAcquireBiometricIdsFunction();
		stickyAcquireBiometricIdsFunction.setBioMatcherConfigService(bioMatcherConfigService);
		stickyAcquireBiometricIdsFunction.setBiometricIdService(biometricIdService);
		stickyAcquireBiometricIdsFunction.setBioParameterService(bioParameterService);

		Supplier<Integer> preLoadMinSizeCheckThresholdSupplier = BioParameterService
				.getIntSupplier("BIOMETRIC_ID_PRELOAD_MIN_SIZE_THRESHOLD", "DEFAULT", 25);

		Supplier<Integer> concurrencyCountSupplier = BioParameterService
				.getIntSupplier("BIOMETRIC_ID_PRELOAD_CONCURRENCY_COUNT", "DEFAULT", 5);

		Function<Integer, List<BiometricIdDetailInfo>> biometicIdProducerFunction = (binId) -> {
			try {
				return preAcquireBiometricIds(binId);
			} catch (Throwable th) {
				throw new RuntimeException(th.getMessage(), th);
			}
		};

		biometricIdProducer = new KeyedPreLoadProducer<>("BiometricIdProducer", biometicIdProducerFunction,
				preLoadMinSizeCheckThresholdSupplier, concurrencyCountSupplier);
	}

}
