package com.nec.biomatcher.comp.util;

public class LocalServerComponents {
	private static String searchControllerId;
	private static String searchBrokerId;
	private static String searchBrokerSnGroupId;
	private static String verificationControllerId;
	private static String extractionControllerId;

	public static final String getSearchControllerId() {
		return searchControllerId;
	}

	public static final void setSearchControllerId(String searchControllerId) {
		LocalServerComponents.searchControllerId = searchControllerId;
	}

	public static final String getSearchBrokerId() {
		return searchBrokerId;
	}

	public static final void setSearchBrokerId(String searchBrokerId) {
		LocalServerComponents.searchBrokerId = searchBrokerId;
	}

	public static final String getVerificationControllerId() {
		return verificationControllerId;
	}

	public static final void setVerificationControllerId(String verificationControllerId) {
		LocalServerComponents.verificationControllerId = verificationControllerId;
	}

	public static final String getExtractionControllerId() {
		return extractionControllerId;
	}

	public static final void setExtractionControllerId(String extractionControllerId) {
		LocalServerComponents.extractionControllerId = extractionControllerId;
	}

	public static String getSearchBrokerSnGroupId() {
		return searchBrokerSnGroupId;
	}

	public static void setSearchBrokerSnGroupId(String searchBrokerSnGroupId) {
		LocalServerComponents.searchBrokerSnGroupId = searchBrokerSnGroupId;
	}

}
