package com.nec.biomatcher.comp.util;

import java.net.InetSocketAddress;
import java.net.URI;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.HostDistance;
import com.datastax.driver.core.PoolingOptions;
import com.datastax.driver.core.Session;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerConnectionInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerType;
import com.nec.biomatcher.comp.template.storage.impl.TemplateDataCassandraServiceImpl;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.StringUtil;

public class CassandraConnector implements AutoCloseable {
    private static final CassandraConnector CASSANDRA_CONNECTOR = new CassandraConnector();
    
    private Cluster cluster;
    private Session pooledSession;
    
    private CassandraConnector() {
        
    }
    
    public static CassandraConnector getInstance() {
        return CASSANDRA_CONNECTOR;
    }
    
    
    public Session getPooledSession(BioMatcherConfigService bioMatcherConfigService) throws BioMatcherConfigServiceException {
        if (pooledSession == null) {
            synchronized (TemplateDataCassandraServiceImpl.class) {
                if (pooledSession == null) {
                    closeCluster();

                    List<BioServerInfo> serverInfoList = bioMatcherConfigService.getServerInfoListByServerType(BioServerType.CASSANDRA_DB, BioComponentType.CDB);
                    if (CollectionUtils.isEmpty(serverInfoList)) {
                        throw new BioMatcherConfigServiceException("Cannot find BioServerInfo with serverType: "+BioServerType.CASSANDRA_DB.name()+", componentType: "+BioComponentType.CDB.name());
                    }

                    Set<String> inetSocketAddressList = new HashSet<>();
                    Map<String, String> connectionProperties = new HashMap<>();
                    int portNumber =0;
                    for(BioServerInfo serverInfo:serverInfoList) {
                        try {
                            bioMatcherConfigService.createServerConnnections(serverInfo.getServerId(), serverInfo.getServerHost(), serverInfo.getComponentType());

                            BioServerConnectionInfo bioServerConnectionInfo = bioMatcherConfigService.getServerConnectionInfo(serverInfo.getServerId(), serverInfo.getComponentType(), BioConnectionType.SERVICE);
                            if (bioServerConnectionInfo==null || StringUtils.isBlank(bioServerConnectionInfo.getConnectionUrl())) {
                                CommonLogger.CONFIG_LOG.error("Invalid connectionUrl, Host and port is not properly configured serverId: " + serverInfo.getServerId() + ", controllerComponentType: " + serverInfo.getComponentType() + ", connectionType: " + BioConnectionType.SERVICE + ", protocolType: " + BioProtocolType.TCP );
                                continue;
                            }
                            
                            String connectionUrl = bioServerConnectionInfo.getConnectionUrl();

                            URI uri = new URI(connectionUrl);

                            if (uri.getHost() == null || uri.getPort() == 0) {
                                CommonLogger.CONFIG_LOG.error("Invalid connectionUrl, Host and port is not properly configured serverId: " + serverInfo.getServerId() + ", controllerComponentType: " + serverInfo.getComponentType() + ", connectionType: " + BioConnectionType.SERVICE + ", protocolType: " + BioProtocolType.TCP + ", connectionUrl: " + connectionUrl);
                                continue;
                            }
                            CommonLogger.CONFIG_LOG.info("In getPooledSession: serverId: "+serverInfo.getServerId()+", host: "+uri.getHost()+", port: "+uri.getPort());
                            
                            portNumber = uri.getPort();
                            
                            inetSocketAddressList.add(uri.getHost());
                            if(bioServerConnectionInfo.getConnectionProperties()!=null) {
                                connectionProperties.putAll(bioServerConnectionInfo.getConnectionProperties());
                            }
                        }
                        catch(Throwable th) {
                            CommonLogger.CONFIG_LOG.error("Error getting InetSocketAddress for serverInfo with serverId: " + serverInfo.getServerId() + ", componentType: " + serverInfo.getComponentType() + ", connectionType: " + BioConnectionType.SERVICE + ", protocolType: " + BioProtocolType.TCP+" : "+th.getMessage(), th);
                        }
                    }
                    
                    if (CollectionUtils.isEmpty(inetSocketAddressList)) {
                        throw new BioMatcherConfigServiceException("InetSocketAddress list is empty for BioServerInfo list with serverType: "+BioServerType.CASSANDRA_DB.name()+", componentType: "+BioComponentType.CDB.name());
                    }
                   
                    String keyspace = "bio_matcher";
                    int coreConnectionsPerHost = 4;
                    int maxConnectionsPerHost = 10;
                    int maxRequestsPerLocalConnection = 32768;
                    int maxRequestsPerRemoteConnection = 2000;
                    int heartbeatIntervalSeconds = 120;

                    keyspace = connectionProperties.getOrDefault("keyspace", keyspace);
                    coreConnectionsPerHost = StringUtil.stringToInt(connectionProperties.get("coreConnectionsPerHost"), coreConnectionsPerHost);
                    maxConnectionsPerHost = StringUtil.stringToInt(connectionProperties.get("maxConnectionsPerHost"), maxConnectionsPerHost);
                    maxRequestsPerLocalConnection = StringUtil.stringToInt(connectionProperties.get("maxRequestsPerLocalConnection"), maxRequestsPerLocalConnection);
                    maxRequestsPerRemoteConnection = StringUtil.stringToInt(connectionProperties.get("maxRequestsPerRemoteConnection"), maxRequestsPerRemoteConnection);
                    heartbeatIntervalSeconds = StringUtil.stringToInt(connectionProperties.get("heartbeatIntervalSeconds"), heartbeatIntervalSeconds);

                    PoolingOptions poolingOptions = new PoolingOptions();
                    poolingOptions.setCoreConnectionsPerHost(HostDistance.LOCAL, coreConnectionsPerHost).setMaxConnectionsPerHost(HostDistance.LOCAL, maxConnectionsPerHost).setMaxRequestsPerConnection(HostDistance.LOCAL, maxRequestsPerLocalConnection).setMaxRequestsPerConnection(HostDistance.REMOTE, maxRequestsPerRemoteConnection)
                            .setHeartbeatIntervalSeconds(heartbeatIntervalSeconds);

                    CommonLogger.CONFIG_LOG.info("In getPooledSession: inetSocketAddressList: ["+inetSocketAddressList+"]");
                    
                    cluster = Cluster.builder()
                            .addContactPoints(inetSocketAddressList.toArray(new String[inetSocketAddressList.size()]))
                            .withPort(portNumber)
                            .withPoolingOptions(poolingOptions)
                            .build();

                    CommonLogger.CONFIG_LOG.info("In getPooledSession: keyspace: ["+keyspace+"]");
                    
                    pooledSession = cluster.connect(keyspace);
                }
            }
        }

        return pooledSession;
    }
    
    private void closeSession() {
        if (pooledSession != null) {
            try {
                pooledSession.close();
            } catch (Throwable th) {
            } finally {
                pooledSession = null;
            }
        }
    }

    private void closeCluster() {
        if (cluster != null) {
            try {
                cluster.close();
            } catch (Throwable th) {
            } finally {
                cluster = null;
            }
        }
    }

    
    public void initializeConfig(BioMatcherConfigService bioMatcherConfigService) throws Exception {
        List<BioServerInfo> serverInfoList = bioMatcherConfigService.getServerInfoListByServerType(BioServerType.CASSANDRA_DB, BioComponentType.CDB);
        for(BioServerInfo serverInfo:serverInfoList) {
            try {
                bioMatcherConfigService.createServerConnnections(serverInfo.getServerId(), serverInfo.getServerHost(), serverInfo.getComponentType());
            }
            catch(Throwable th) {
               CommonLogger.CONFIG_LOG.error("Error creating default connection config for serverInfo with serverId: " + serverInfo.getServerId() + ", componentType: " + serverInfo.getComponentType() + ", connectionType: " + BioConnectionType.SERVICE + ", protocolType: " + BioProtocolType.TCP+" : "+th.getMessage(), th); 
            }
        }
    }

    @Override
    public void close() throws Exception {
        closeSession();
        closeCluster();
    }
}
