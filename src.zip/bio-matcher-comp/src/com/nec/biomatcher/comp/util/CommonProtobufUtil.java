package com.nec.biomatcher.comp.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Sets;
import com.google.protobuf.ByteString;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.exception.BioParameterServiceException;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.BioCropInfo;
import com.nec.biomatcher.spec.transfer.model.BioParameterDto;
import com.nec.biomatcher.spec.transfer.model.BioParameterGroupDto;
import com.nec.biomatcher.spec.transfer.model.BioParameterKeyEnum;
import com.nec.biomatcher.spec.transfer.model.BioRectangle;
import com.nec.biomatcher.spec.transfer.model.ExtractInputParameter;
import com.nec.biomatcher.spec.transfer.model.FaceExtractInputParameter;
import com.nec.biomatcher.spec.transfer.model.FaceInputDetection;
import com.nec.biomatcher.spec.transfer.model.Image;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;
import com.nec.biomatcher.spec.transfer.model.IrisExtractInputParameter;
import com.nec.biomatcher.spec.transfer.model.IrisInputDetection;
import com.nec.biomatcher.spec.transfer.model.MatchInputParameter;
import com.nec.biomatcher.spec.transfer.model.Modality;
import com.nec.megha.proto.common.CommonProto;
import com.nec.megha.proto.common.CommonProto.Crop;
import com.nec.megha.proto.common.CommonProto.ImageData;
import com.nec.megha.proto.common.CommonProto.ImageData.ExtractManualData;
import com.nec.megha.proto.common.CommonProto.ImageData.ImageFormat;
import com.nec.megha.proto.common.CommonProto.KeyValue;
import com.nec.megha.proto.common.CommonProto.KeyValueGroup;
import com.nec.megha.proto.common.CommonProto.KeyValueGroupHolder;
import com.nec.megha.proto.common.CommonProto.Point;
import com.nec.megha.proto.common.CommonProto.Rectangle;
import com.nec.megha.proto.common.CommonProto.SubType;
import com.nec.megha.proto.mgmt.CapacityProto.Capacity;

/**
 * The Class CommonProtobufUtil.
 */
public class CommonProtobufUtil {

	/**
	 * Builds the capacity proto.
	 *
	 * @param maxJobCount
	 *            the max job count
	 * @param serverId
	 *            the server id
	 * @return the byte[]
	 */
	public static final Capacity buildCapacityProto(int maxJobCount, String serverId) {
		Capacity.Builder builder = Capacity.newBuilder();
		builder.setCapacity(maxJobCount);
		builder.setInstanceId(serverId);
		Capacity capacity = builder.build();
		return capacity;
	}

	/**
	 * Gets the client image format.
	 *
	 * @param imgFormat
	 *            the img format
	 * @return the client image format
	 */
	public static final ImageFormat getClientImageFormat(com.nec.biomatcher.spec.transfer.model.ImageFormat imgFormat) {
		if (imgFormat == null) {
			throw new IllegalArgumentException("ImageFormat in null");
		}

		if (com.nec.biomatcher.spec.transfer.model.ImageFormat.JPEG2000.equals(imgFormat)) {
			return ImageFormat.JP2;
		}

		try {
			return ImageFormat.valueOf(imgFormat.name());
		} catch (Throwable th) {
			throw new IllegalArgumentException("ImageFormat : " + imgFormat + " is not supported by client", th);
		}
	}

	public static final com.nec.biomatcher.spec.transfer.model.ImageFormat getImageFormat(ImageFormat imgFormat) {
		if (imgFormat == null) {
			throw new IllegalArgumentException("ImageFormat in null");
		}

		switch (imgFormat) {
		case BMP:
			return com.nec.biomatcher.spec.transfer.model.ImageFormat.BMP;
		case JP2:
			return com.nec.biomatcher.spec.transfer.model.ImageFormat.JPEG2000;
		case JPEG:
			return com.nec.biomatcher.spec.transfer.model.ImageFormat.JPEG;

		case PNG:
			return com.nec.biomatcher.spec.transfer.model.ImageFormat.PNG;
		case WSQ:
			return com.nec.biomatcher.spec.transfer.model.ImageFormat.WSQ;
		case RAW:
			return com.nec.biomatcher.spec.transfer.model.ImageFormat.RAW;
			
	    case NEC_BINARY:
            return com.nec.biomatcher.spec.transfer.model.ImageFormat.NEC_BINARY;			

		default:
			throw new IllegalArgumentException("Invalid ImageFormat: " + imgFormat.name());
		}
	}

	/**
	 * Gets the client modality.
	 *
	 * @param modality
	 *            the modality
	 * @return the client modality
	 */
	public static final com.nec.megha.proto.common.CommonProto.Modality getClientModality(Modality modality) {
		if (modality == null) {
			throw new IllegalArgumentException("Modality in null");
		}

		switch (modality) {
		case FACE:
			return CommonProto.Modality.MODAL_FACE;
		case IRIS:
			return CommonProto.Modality.MODAL_IRIS;
		case FINGER:
			return CommonProto.Modality.MODAL_FINGER;
		case PALM:
			return CommonProto.Modality.MODAL_PALM;
		default:
			break;
		}

		throw new IllegalArgumentException("Modality : " + modality + " is not supported by client");
	}

	/**
	 * Gets the image position.
	 *
	 * @param subType
	 *            the sub type
	 * @return the image position
	 */
	public static final ImagePosition getImagePosition(SubType subType) {
		if (subType == null) {
			// return ImagePosition.UNKNOWN;
			throw new IllegalArgumentException("SubType in null");
		}

		return ImagePosition.enumOf(subType.getNumber());
	}

	/**
	 * Gets the client sub type.
	 *
	 * @param imagePosition
	 *            the image position
	 * @return the client sub type
	 */
	public static final SubType getClientSubType(Integer imagePosition) {
		if (imagePosition == null) {
			throw new IllegalArgumentException("ImagePosition in null");
		}

		SubType subType = SubType.valueOf(imagePosition);
		if (subType == null) {
			throw new IllegalArgumentException("ImagePosition : " + imagePosition + " is not supported by client");
		}

		return subType;
	}

	/**
	 * Gets the client algorithm type.
	 *
	 * @param algorithmType
	 *            the algorithm type
	 * @return the client algorithm type
	 */
	public static final com.nec.megha.proto.common.CommonProto.AlgorithmType getClientAlgorithmType(
			AlgorithmType algorithmType) {
		if (algorithmType == null) {
			throw new IllegalArgumentException("algorithmType in null: " + algorithmType);
		}
		return com.nec.megha.proto.common.CommonProto.AlgorithmType.valueOf(algorithmType.getValue());
	}

	/**
	 * Gets the algorithm type.
	 *
	 * @param algorithmType
	 *            the algorithm type
	 * @return the algorithm type
	 */
	public static final AlgorithmType getAlgorithmType(
			com.nec.megha.proto.common.CommonProto.AlgorithmType algorithmType) {
		if (algorithmType == null) {
			throw new IllegalArgumentException("algorithmType in null");
		}

		return AlgorithmType.enumOf(algorithmType.getNumber());
	}

	/**
	 * Gets the modality.
	 *
	 * @param subType
	 *            the sub type
	 * @return the modality
	 */
	public static final Modality getModality(SubType subType,
			com.nec.megha.proto.common.CommonProto.AlgorithmType algorithmType) {
		if (subType != null) {
			if (subType.name().contains("FACE")) {
				return Modality.FACE;
			}
			if (subType.name().contains("IRIS")) {
				return Modality.IRIS;
			}
			if (subType.name().contains("ROLL") || subType.name().contains("SLAP")) {
				return Modality.FINGER;
			}
			if (subType.name().contains("PALM")) {
				return Modality.PALM;
			}
		}

		if (algorithmType != null) {
			switch (algorithmType) {
			case AlgFaceNecS17:
				return Modality.FACE;
			case AlgFaceNecS18:
				return Modality.FACE;
			case AlgFaceNFV2:
				return Modality.FACE;
			case AlgFaceNFG2:
				return Modality.FACE;
            case AlgFaceNFV3:
                return Modality.FACE;				
			case AlgFingerCML:
				return Modality.FINGER;
			case AlgFingerBT5:
				return Modality.FINGER;	
			case AlgFingerCMLaF:
				return Modality.FINGER;
			case AlgFingerELFT:
				return Modality.FINGER;
			case AlgFingerFMP5:
				return Modality.FINGER;
			case AlgFingerLFML:
				return Modality.FINGER;
			case AlgFingerPC2:
				return Modality.FINGER;
			case AlgFingerPC3R:
				return Modality.FINGER;
			case AlgFingerFIS:
                return Modality.FINGER;				
			case AlgIrisDeltaId:
				return Modality.IRIS;
			case AlgIrisNec:
				return Modality.IRIS;
			case AlgPalmPC3R:
				return Modality.PALM;
			case AlgPalmLFML:
				return Modality.PALM; 
			default:
				throw new IllegalArgumentException(
						"SubType : " + subType + ", algorithmType: " + algorithmType + " cannot be mapped to Modality");
			}
		}

		throw new IllegalArgumentException(
				"SubType : " + subType + ", algorithmType: " + algorithmType + " cannot be mapped to Modality");
	}

	public static final Modality getModality(com.nec.megha.proto.common.CommonProto.Modality modality) {
		if (modality == null) {
			throw new IllegalArgumentException("modality in null");
		}

		switch (modality) {
		case MODAL_FACE:
			return Modality.FACE;
		case MODAL_IRIS:
			return Modality.IRIS;
		case MODAL_FINGER:
			return Modality.FINGER;
		case MODAL_PALM:
			return Modality.PALM;
		default:
			throw new IllegalArgumentException("Invalid modality : " + modality.name());
		}
	}

	public static final com.nec.megha.proto.common.CommonProto.Modality getClientModality(SubType subType,
			com.nec.megha.proto.common.CommonProto.AlgorithmType algorithmType) {
		if (subType != null) {
			if (subType.name().contains("FACE")) {
				return CommonProto.Modality.MODAL_FACE;
			}
			if (subType.name().contains("IRIS")) {
				return CommonProto.Modality.MODAL_IRIS;
			}
			if (subType.name().contains("ROLL") || subType.name().contains("SLAP")) {
				return CommonProto.Modality.MODAL_FINGER;
			}
			if (subType.name().contains("PALM")) {
				return CommonProto.Modality.MODAL_PALM;  
			}
		}

		if (algorithmType != null) {
			switch (algorithmType) {
			case AlgFaceNecS17:
				return CommonProto.Modality.MODAL_FACE;
			case AlgFaceNecS18:
				return CommonProto.Modality.MODAL_FACE;
			case AlgFaceNFV2:
				return CommonProto.Modality.MODAL_FACE;
            case AlgFaceNFV3:
                return CommonProto.Modality.MODAL_FACE;				
			case AlgFaceNFG2:
				return CommonProto.Modality.MODAL_FACE;
			case AlgFingerCML:
				return CommonProto.Modality.MODAL_FINGER;
			case AlgFingerCMLaF:
				return CommonProto.Modality.MODAL_FINGER;
			case AlgFingerELFT:
				return CommonProto.Modality.MODAL_FINGER;
			case AlgFingerFMP5:
				return CommonProto.Modality.MODAL_FINGER;
			case AlgFingerLFML:
				return CommonProto.Modality.MODAL_FINGER;
			case AlgFingerPC2:
				return CommonProto.Modality.MODAL_FINGER;
			case AlgFingerPC3R:
				return CommonProto.Modality.MODAL_FINGER; 
			case AlgFingerBT5:
				return CommonProto.Modality.MODAL_FINGER;
	        case AlgFingerFIS:
                return CommonProto.Modality.MODAL_FINGER;				
			case AlgIrisDeltaId:
				return CommonProto.Modality.MODAL_IRIS;
			case AlgIrisNec:
				return CommonProto.Modality.MODAL_IRIS;
			case AlgPalmPC3R:
				return CommonProto.Modality.MODAL_PALM;
			case AlgPalmLFML:
				return CommonProto.Modality.MODAL_PALM; 
			default:
				throw new IllegalArgumentException(
						"SubType : " + subType + ", algorithmType: " + algorithmType + " cannot be mapped to Modality");
			}
		}

		throw new IllegalArgumentException(
				"SubType : " + subType + ", algorithmType: " + algorithmType + " cannot be mapped to Modality");
	}

	/**
	 * Builds the image data.
	 *
	 * @param image
	 *            the image
	 * @param modality
	 *            the modality
	 * @param subType
	 *            the sub type
	 * @return the image data
	 */
	public static ImageData buildImageData(Image image, Modality modality, SubType subType) {
		ImageData.Builder imageDataBuilder = ImageData.newBuilder();

		imageDataBuilder.setFormat(CommonProtobufUtil.getClientImageFormat(image.getType()));
		imageDataBuilder.setModality(CommonProtobufUtil.getClientModality(modality));
		imageDataBuilder.setSubType(subType);
		imageDataBuilder.setData(ByteString.copyFrom(image.getData()));
		if (image.getWidth() != null) {
			imageDataBuilder.setWidth(image.getWidth());
		}

		if (image.getHeight() != null) {
			imageDataBuilder.setHeight(image.getHeight());
		}

		if (image.getDpi() != null) {
			imageDataBuilder.setResolution(image.getDpi());
		}

		if (image.isBlackOnWhite() != null) {
			imageDataBuilder.setIsBlackOnWhite(image.isBlackOnWhite());
		}

		List<BioCropInfo> cropList = image.getCropInfo();
		if (cropList != null) {
			for (BioCropInfo info : cropList) {
				Crop.Builder crop = Crop.newBuilder();
				if (info.getAmputation() != null) {
					crop.setAmputation(info.getAmputation());
				}
				if (info.getAngle() != null) {
					crop.setAngle(info.getAngle());
				}

				if (info.getPosition() != null) {
					crop.setSubType(getClientSubType(info.getPosition().getPosition()));
				}

				if (info.getCenter() != null) {
					Point.Builder center = Point.newBuilder();
					center.setX(info.getCenter().getX());
					center.setY(info.getCenter().getY());
					crop.setCenter(center);
				}

				BioRectangle rectangle = info.getRectangle();
				if (rectangle != null) {
					Rectangle.Builder rt = Rectangle.newBuilder();
					if (rectangle.getLowerLeft() != null) {
						Point.Builder lowerLeft = Point.newBuilder();
						lowerLeft.setX(info.getRectangle().getLowerLeft().getX());
						lowerLeft.setY(info.getRectangle().getLowerLeft().getY());
						rt.setLowerLeft(lowerLeft);
					}

					if (rectangle.getLowerRight() != null) {
						Point.Builder lowerRight = Point.newBuilder();
						lowerRight.setX(info.getRectangle().getLowerRight().getX());
						lowerRight.setY(info.getRectangle().getLowerRight().getY());
						rt.setLowerRight(lowerRight);
					}

					if (rectangle.getUpperLeft() != null) {
						Point.Builder upperLeft = Point.newBuilder();
						upperLeft.setX(info.getRectangle().getUpperLeft().getX());
						upperLeft.setY(info.getRectangle().getUpperLeft().getY());
						rt.setUpperLeft(upperLeft);
					}

					if (rectangle.getUpperRight() != null) {
						Point.Builder upperRight = Point.newBuilder();
						upperRight.setX(info.getRectangle().getUpperRight().getX());
						upperRight.setY(info.getRectangle().getUpperRight().getY());
						rt.setUpperRight(upperRight);
					}
					crop.setRectangle(rt);
				}
				imageDataBuilder.addCrop(crop);
			}
		}

		if (image.hasKeyValueGroupList()) {
			imageDataBuilder.setKvGroupHolder(buildKvGroupHolder(image.getKeyValueGroupList()));
		}

		if (image.getManualData() != null
				&& (image.getManualData().getEditedMinutia() != null || image.getManualData().getMarkup() != null)) {
			ExtractManualData.Builder extractManualDataBuilder = ExtractManualData.newBuilder();

			if (image.getManualData().getEditedMinutia() != null) {
				extractManualDataBuilder
						.setEditedMinutia(ByteString.copyFrom(image.getManualData().getEditedMinutia()));
			}

			if (image.getManualData().getMarkup() != null) {
				extractManualDataBuilder.setMarkUp(ByteString.copyFrom(image.getManualData().getMarkup()));
			}

			imageDataBuilder.setManualData(extractManualDataBuilder.build());
		}

		return imageDataBuilder.build();
	}

	public static KeyValueGroupHolder buildKvGroupHolder(List<BioParameterGroupDto> keyValueGroupList) {
		KeyValueGroupHolder.Builder keyValueGroupHolderBuilder = KeyValueGroupHolder.newBuilder();
		for (BioParameterGroupDto bioParameterGroupDto : keyValueGroupList) {
			keyValueGroupHolderBuilder.addParamGroup(buildKeyValueGroup(bioParameterGroupDto));
		}
		return keyValueGroupHolderBuilder.build();
	}

	public static KeyValueGroup buildKeyValueGroup(BioParameterGroupDto bioParameterGroupDto) {
		KeyValueGroup.Builder keyValueGroupBuilder = KeyValueGroup.newBuilder();
		keyValueGroupBuilder.setGroupName(bioParameterGroupDto.getGroupName());

		if (bioParameterGroupDto.hasKeyValuePairList()) {
			for (BioParameterDto bioParameterDto : bioParameterGroupDto.getKeyValuePairList()) {
				KeyValue.Builder keyValueBuilder = KeyValue.newBuilder();
				keyValueBuilder.setKey(bioParameterDto.getKey());
				keyValueBuilder.setValue(bioParameterDto.getValue());
				keyValueGroupBuilder.addKv(keyValueBuilder.build());
			}
		}

		if (bioParameterGroupDto.hasKeyValueGroupList()) {
			for (BioParameterGroupDto subBioParameterGroupDto : bioParameterGroupDto.getKeyValueGroupList()) {
				keyValueGroupBuilder.addKvGroup(buildKeyValueGroup(subBioParameterGroupDto));
			}
		}
		
		if (bioParameterGroupDto.getAlgType() != null) {
		    keyValueGroupBuilder.setAlgType(CommonProtobufUtil.getClientAlgorithmType(bioParameterGroupDto.getAlgType()));		    
		}

		return keyValueGroupBuilder.build();
	}

	/**
	 * Builds the key value group.
	 *
	 * @param extractInputParameter
	 *            the extract input parameter
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the key value group
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public static KeyValueGroup buildKeyValueGroup(FaceExtractInputParameter extractInputParameter,
			BioParameterService bioParameterService) throws BioParameterServiceException {
		KeyValueGroup.Builder builder = KeyValueGroup.newBuilder();

		FaceInputDetection faceDetection = extractInputParameter.getFaceInputDetection();

		if (faceDetection.getAlgorithmType() != null) {
			String groupName = "DETECTION_PARAM_" + faceDetection.getAlgorithmType();

			builder.setGroupName(groupName);

			Map<String, String> defaultParameters = bioParameterService.getPropertyMap(groupName, "DEFAULT");
			Set<String> setParameters = Sets.newHashSet();

			if (faceDetection.getDetectionAlgorithm() != null) {
				KeyValue keyValue = buildKeyValue(BioParameterKeyEnum.Algorithm,
						faceDetection.getDetectionAlgorithm().getValue());
				if (keyValue != null) {
					builder.addKv(keyValue);
					setParameters.add(BioParameterKeyEnum.Algorithm.name());
				}
			}

			if (faceDetection.getEyeRoll() != null) {
				KeyValue keyValue = buildKeyValue(BioParameterKeyEnum.EyeRoll, faceDetection.getEyeRoll());
				if (keyValue != null) {
					builder.addKv(keyValue);
					setParameters.add(BioParameterKeyEnum.EyeRoll.name());
				}
			}

			if (faceDetection.getMaxEyeDistance() != null) {
				KeyValue keyValue = buildKeyValue(BioParameterKeyEnum.MaxEyeDistance,
						faceDetection.getMaxEyeDistance());
				if (keyValue != null) {
					builder.addKv(keyValue);
					setParameters.add(BioParameterKeyEnum.MaxEyeDistance.name());
				}
			}

			if (faceDetection.getMinEyeDistance() != null) {
				KeyValue keyValue = buildKeyValue(BioParameterKeyEnum.MinEyeDistance,
						faceDetection.getMinEyeDistance());
				if (keyValue != null) {
					builder.addKv(keyValue);
					setParameters.add(BioParameterKeyEnum.MinEyeDistance.name());
				}
			}

			if (faceDetection.getReliability() != null) {
				KeyValue keyValue = buildKeyValue(BioParameterKeyEnum.Reliability, faceDetection.getReliability());
				if (keyValue != null) {
					builder.addKv(keyValue);
					setParameters.add(BioParameterKeyEnum.Reliability.name());
				}
			}

			if (faceDetection.getShrinkFactor() != null) {
				KeyValue keyValue = buildKeyValue(BioParameterKeyEnum.ShrinkFactor, faceDetection.getShrinkFactor());
				if (keyValue != null) {
					builder.addKv(keyValue);
					setParameters.add(BioParameterKeyEnum.ShrinkFactor.name());
				}
			}

			if (faceDetection.hasParameters()) {
				for (BioParameterDto bioParameter : faceDetection.getParameters()) {
					if (bioParameter.getKey() != null && bioParameter.getValue() != null) {
						KeyValue keyValue = buildKeyValue(bioParameter.getKey(), bioParameter.getValue());
						if (keyValue != null) {
							builder.addKv(keyValue);
							setParameters.add(bioParameter.getKey());
						}
					}
				}
			}

			if (defaultParameters.size() > 0) {
				for (Entry<String, String> entry : defaultParameters.entrySet()) {
					if (!setParameters.contains(entry.getKey()) && entry.getValue() != null) {
						KeyValue keyValue = buildKeyValue(entry.getKey(), entry.getValue());
						if (keyValue != null) {
							builder.addKv(keyValue);
						}
					}
				}
			}
		}

		return builder.build();
	}

	/**
	 * Builds the key value group.
	 *
	 * @param extractInputParameter
	 *            the extract input parameter
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the key value group
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public static KeyValueGroup buildKeyValueGroup(IrisExtractInputParameter extractInputParameter,
			BioParameterService bioParameterService) throws BioParameterServiceException {
		KeyValueGroup.Builder builder = KeyValueGroup.newBuilder();

		IrisInputDetection irisDetection = extractInputParameter.getIrisInputDetection();

		if (irisDetection.getAlgorithmType() != null) {
			String groupName = "DETECTION_PARAM_" + irisDetection.getAlgorithmType();

			builder.setGroupName(groupName);

			Map<String, String> defaultParameters = bioParameterService.getPropertyMap(groupName, "DEFAULT");
			Set<String> setParameters = Sets.newHashSet();

			if (irisDetection.getSpeedLevel() != null) {
				KeyValue keyValue = buildKeyValue(BioParameterKeyEnum.Speed, irisDetection.getSpeedLevel());
				if (keyValue != null) {
					builder.addKv(keyValue);
					setParameters.add(BioParameterKeyEnum.Speed.name());
				}
			}

			if (irisDetection.hasParameters()) {
				for (BioParameterDto bioParameter : irisDetection.getParameters()) {
					if (bioParameter.getKey() != null && bioParameter.getValue() != null) {
						KeyValue keyValue = buildKeyValue(bioParameter.getKey(), bioParameter.getValue());
						if (keyValue != null) {
							builder.addKv(keyValue);
							setParameters.add(bioParameter.getKey());
						}
					}
				}
			}

			if (defaultParameters.size() > 0) {
				for (Entry<String, String> entry : defaultParameters.entrySet()) {
					if (!setParameters.contains(entry.getKey()) && entry.getValue() != null) {
						KeyValue keyValue = buildKeyValue(entry.getKey(), entry.getValue());
						if (keyValue != null) {
							builder.addKv(keyValue);
						}
					}
				}
			}
		}

		return builder.build();
	}

	/**
	 * Builds the match input parameter map.
	 *
	 * @param matchInputParameter
	 *            the match input parameter
	 * @param algorithmType
	 *            the algorithm type
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the map
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public static Map<String, String> buildMatchInputParameterMap(MatchInputParameter matchInputParameter,
			AlgorithmType algorithmType, BioParameterService bioParameterService) throws BioParameterServiceException {

		Map<String, String> matchInputParameterMap = new HashMap<>();

		if (matchInputParameter != null && matchInputParameter.hasParameters()) {
			for (BioParameterDto bioParameterDto : matchInputParameter.getParameters()) {
				if (!matchInputParameterMap.containsKey(bioParameterDto.getKey())
						&& StringUtils.isNotBlank(bioParameterDto.getValue())) {
					matchInputParameterMap.put(bioParameterDto.getKey(), bioParameterDto.getValue());
				}
			}
		}

		Map<String, String> defaultParameters = bioParameterService
				.getPropertyMap("PROPERTIES_DEFAULT_MATCH_PARAM_" + algorithmType.name(), "DEFAULT");
		if (defaultParameters != null) {
			for (Entry<String, String> entry : defaultParameters.entrySet()) {
				if (!matchInputParameterMap.containsKey(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())) {
					matchInputParameterMap.put(entry.getKey(), entry.getValue());
				}
			}
		}

		Map<String, String> overwriteParameters = bioParameterService
				.getPropertyMap("PROPERTIES_OVERWRITE_MATCH_PARAM_" + algorithmType.name(), "DEFAULT");
		if (overwriteParameters != null) {
			for (Entry<String, String> entry : overwriteParameters.entrySet()) {
				if (StringUtils.isBlank(entry.getValue())) {
					matchInputParameterMap.remove(entry.getKey());
				} else {
					matchInputParameterMap.put(entry.getKey(), entry.getValue());
				}
			}
		}

		return matchInputParameterMap;
	}

	/**
	 * Builds the extract input parameter map.
	 *
	 * @param extractInputParameter
	 *            the extract input parameter
	 * @param algorithmType
	 *            the algorithm type
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the map
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public static Map<String, String> buildExtractInputParameterMap(Collection<ExtractInputParameter> extractInputParameters,
			AlgorithmType algorithmType, BioParameterService bioParameterService) throws BioParameterServiceException {
		Map<String, String> extractInputParameterMap = new HashMap<>();
		Iterator<ExtractInputParameter> it = extractInputParameters.iterator();
		ExtractInputParameter extractInputParameter = null;
        while (it.hasNext()) {
            extractInputParameter = it.next();
		      if (extractInputParameter != null && extractInputParameter.hasParameters()) {
		            for (BioParameterDto bioParameterDto : extractInputParameter.getParameters()) {
		                if (!extractInputParameterMap.containsKey(bioParameterDto.getKey())
		                        && StringUtils.isNotBlank(bioParameterDto.getValue())) {
		                    extractInputParameterMap.put(bioParameterDto.getKey(), bioParameterDto.getValue());
		                }
		            }
		        }

		        Map<String, String> defaultParameters = bioParameterService
		                .getPropertyMap("PROPERTIES_DEFAULT_DETECTION_PARAM_" + algorithmType.name(), "DEFAULT");
		        if (defaultParameters != null) {
		            for (Entry<String, String> entry : defaultParameters.entrySet()) {
		                if (!extractInputParameterMap.containsKey(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())) {
		                    extractInputParameterMap.put(entry.getKey(), entry.getValue());
		                }
		            }
		        }

		        Map<String, String> overwriteParameters = bioParameterService
		                .getPropertyMap("PROPERTIES_OVERWRITE_DETECTION_PARAM_" + algorithmType.name(), "DEFAULT");
		        if (overwriteParameters != null) {
		            for (Entry<String, String> entry : overwriteParameters.entrySet()) {
		                if (StringUtils.isBlank(entry.getValue())) {
		                    extractInputParameterMap.remove(entry.getKey());
		                } else {
		                    extractInputParameterMap.put(entry.getKey(), entry.getValue());
		                }
		            }
		        }		    
		}

		return extractInputParameterMap;
	}

	public static BioParameterGroupDto buildKeyValueGroup(KeyValueGroup cleintKeyValueGroup) {
		BioParameterGroupDto kvGroup = new BioParameterGroupDto();
		kvGroup.setGroupName(cleintKeyValueGroup.getGroupName());
		if (cleintKeyValueGroup.getKvCount() > 0) {
			for (KeyValue keyValue : cleintKeyValueGroup.getKvList()) {
				kvGroup.getKeyValuePairList().add(new BioParameterDto(keyValue.getKey(), keyValue.getValue()));
			}
		}
		if (cleintKeyValueGroup.getKvGroupCount() > 0) {
			for (KeyValueGroup cleintSubKeyValueGroup : cleintKeyValueGroup.getKvGroupList()) {
				kvGroup.getKeyValueGroupList().add(buildKeyValueGroup(cleintSubKeyValueGroup));
			}
		}

		return kvGroup;
	}

	/**
	 * Builds the key value.
	 *
	 * @param key
	 *            the key
	 * @param value
	 *            the value
	 * @return the key value
	 */
	public static final KeyValue buildKeyValue(BioParameterKeyEnum key, Object value) {
		if (key == null || value == null) {
			return null;
		}

		return KeyValue.newBuilder().setKey(key.name()).setValue(String.valueOf(value)).build();
	}

	/**
	 * Builds the key value.
	 *
	 * @param key
	 *            the key
	 * @param value
	 *            the value
	 * @return the key value
	 */
	public static final KeyValue buildKeyValue(String key, Object value) {
		if (key == null || value == null) {
			return null;
		}

		return KeyValue.newBuilder().setKey(key).setValue(String.valueOf(value)).build();
	}

}
