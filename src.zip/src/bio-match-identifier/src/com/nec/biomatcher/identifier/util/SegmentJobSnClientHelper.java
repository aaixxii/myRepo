package com.nec.biomatcher.identifier.util;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.hazelcast.util.function.Consumer;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeClientHelper;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.util.LocalServerComponents;
import com.nec.biomatcher.comp.zmq.ZmqConnectionException;
import com.nec.biomatcher.comp.zmq.ZmqPullMessageListener;
import com.nec.biomatcher.comp.zmq.ZmqPushConnection;
import com.nec.biomatcher.comp.zmq.ZmqPushSocketRef;
import com.nec.biomatcher.comp.zmq.ZmqSendException;
import com.nec.biomatcher.core.framework.cache.SpringCacheManager;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ExceptionMessageFormatter;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.BooleanLatch;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentReader;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.DynamicSemaphore;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.searchcontroller.util.SearchResultCallbackUtil;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.MultiSnSegmentJobInfoList;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.SnSegmentJobInfo;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.SnSegmentJobInfoList;
import com.nec.megha.proto.search.SearchRequestProto.SearchRequest;
import com.nec.megha.proto.search.SearchResponseProto.SearchResponse;

public class SegmentJobSnClientHelper implements InitializingBean {
	private static final Logger logger = Logger.getLogger(SegmentJobSnClientHelper.class);

	private static final Logger SEARCH_JOB_NODE_REQUEST_LOGGER = Logger.getLogger("SEARCH_JOB_NODE_REQUEST");

	private BioMatcherConfigService bioMatcherConfigService;

	private BioSearchControllerManager bioSearchControllerManager;

	private BioSearchBrokerManager bioSearchBrokerManager;

	private BioParameterService bioParameterService;

	private Function<String, Boolean> searchNodeOnlineCheckFunction = null;

	private Consumer<String> notifySearchNodeOfflineFunction = null;

	private MatcherNodeClientHelper matcherNodeClientHelper = new MatcherNodeClientHelper();

	private Supplier<Integer> messagSubmitterBatchSizeSupplier;
	private Supplier<Boolean> scToSnDirectFlagSupplier;
	private Supplier<Integer> snSegmentJobSubmitterConcurrencySupplier;

	private ZmqPullMessageListener sbJobDistributionMessageListener;

	private static final ExecutorService segmentJobSnClientExecutorService = Executors.newCachedThreadPool();
	private static final ConcurrentHashMap<String, SnSegJobRequestBuilderTask> snSegJobRequestBuilderTaskMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, SnSegJobSenderTask> snSegJobSenderTaskMap = new ConcurrentHashMap<>();

	private LoadingCache<String, String> snWorkerConnectionUrlCache;

	private LoadingCache<String, AtomicBoolean> errorJobStatusCache = CacheBuilder.newBuilder().concurrencyLevel(100)
			.maximumSize(1024).expireAfterAccess(3, TimeUnit.MINUTES).build(new CacheLoader<String, AtomicBoolean>() {
				public AtomicBoolean load(String key) throws Exception {
					return new AtomicBoolean(false);
				}
			});

	public final void addToSearchRequestBuilderQueue(SnSegmentJobInfoList snSegmentJobInfoList) {
		getSnSegJobRequestBuilderTask(snSegmentJobInfoList.getSearchNodeId()).addToQueue(snSegmentJobInfoList);
	}

	private final SnSegJobRequestBuilderTask getSnSegJobRequestBuilderTask(String searchNodeId) {
		SnSegJobRequestBuilderTask snSegJobRequestBuilderTask = snSegJobRequestBuilderTaskMap.get(searchNodeId);
		if (snSegJobRequestBuilderTask == null) {
			snSegJobRequestBuilderTask = snSegJobRequestBuilderTaskMap.computeIfAbsent(searchNodeId,
					(searchNodeIdParam) -> new SnSegJobRequestBuilderTask(searchNodeIdParam));
		}
		return snSegJobRequestBuilderTask;
	}

	private final SnSegJobSenderTask getSnSegJobSenderTask(String searchNodeId) {
		SnSegJobSenderTask snSegJobSenderTask = snSegJobSenderTaskMap.get(searchNodeId);
		if (snSegJobSenderTask == null) {
			snSegJobSenderTask = snSegJobSenderTaskMap.computeIfAbsent(searchNodeId,
					(searchNodeIdParam) -> new SnSegJobSenderTask(searchNodeIdParam));
		}
		return snSegJobSenderTask;
	}

	public class SnSegJobRequestBuilderTask implements Runnable {
		private final LinkedBlockingQueue<SnSegmentJobInfoList> snSegmentJobInfoListQueue = new LinkedBlockingQueue<>();
		private final String searchNodeId;
		private final DynamicSemaphore keyConcurrencySemaphore;
		private final SnSegJobSenderTask snSegJobSenderTask;

		public SnSegJobRequestBuilderTask(String searchNodeId) {
			this.searchNodeId = searchNodeId;
			this.keyConcurrencySemaphore = DynamicSemaphore.getInstance("SEG_JOB_SENDER_" + searchNodeId,
					snSegmentJobSubmitterConcurrencySupplier);
			this.snSegJobSenderTask = getSnSegJobSenderTask(searchNodeId);
		}

		public void addToQueue(SnSegmentJobInfoList snSegmentJobInfoList) {
			snSegmentJobInfoListQueue.add(snSegmentJobInfoList);
			trySubmitTask();
		}

		private final void trySubmitTask() {
			if (keyConcurrencySemaphore.tryAcquire()) {
				try {
					segmentJobSnClientExecutorService.submit(SnSegJobRequestBuilderTask.this);
				} catch (Throwable th) {
					logger.error("Error in SnSegJobRequestBuilderTask.trySubmitTask for searchNodeId: " + searchNodeId
							+ " : " + th.getMessage(), th);
					keyConcurrencySemaphore.release();
				}
			}
		}

		public void run() {
			try {
				Thread.currentThread()
						.setName("SN_SEG_JOB_BUILDER_" + searchNodeId + "_" + Thread.currentThread().getId());
				CommonLogger.STATUS_LOG.info("In SnSegJobRequestBuilderTask for searchNodeId: " + searchNodeId);

				while (!ShutdownHook.isShutdownFlag) {
					try {
						SnSegmentJobInfoList snSegmentJobInfoList = snSegmentJobInfoListQueue.take();
						buildAndSendSearchRequests(snSegmentJobInfoList, snSegJobSenderTask);
					} catch (Throwable th) {
						logger.error("Error in SnSegJobRequestBuilderTask for searchNodeId: " + searchNodeId + " : "
								+ th.getMessage(), th);
					}
				}
			} finally {
				CommonLogger.STATUS_LOG.warn("Exiting the SnSegJobRequestBuilderTask for searchNodeId: " + searchNodeId
						+ ", isShutdownFlag: " + ShutdownHook.isShutdownFlag);
				keyConcurrencySemaphore.release();
			}
		}
	}

	public class SnSegJobSenderTask implements Runnable {
		private final LinkedBlockingQueue<SegmentJobMessage> segmentJobMessageQueue = new LinkedBlockingQueue<>();
		private final String searchNodeId;
		private final Semaphore keyConcurrencySemaphore = new Semaphore(1);

		public SnSegJobSenderTask(String searchNodeId) {
			this.searchNodeId = searchNodeId;
		}

		public void addToQueue(SegmentJobMessage segmentJobMessage) {
			segmentJobMessageQueue.add(segmentJobMessage);
			trySubmitTask();
		}

		private final void trySubmitTask() {
			if (keyConcurrencySemaphore.tryAcquire()) {
				try {
					segmentJobSnClientExecutorService.submit(SnSegJobSenderTask.this);
				} catch (Throwable th) {
					logger.error("Error in SnSegJobSenderTask.trySubmitTask for searchNodeId: " + searchNodeId + " : "
							+ th.getMessage(), th);
					keyConcurrencySemaphore.release();
				}
			}
		}

		public void run() {
			ZmqPushSocketRef zmqPushSocketRef = new ZmqPushSocketRef();
			try {
				Thread.currentThread()
						.setName("SN_SEG_JOB_SENDER_" + searchNodeId + "_" + Thread.currentThread().getId());
				CommonLogger.STATUS_LOG.info("In SnSegJobSenderTask for searchNodeId: " + searchNodeId);

				while (!ShutdownHook.isShutdownFlag) {
					boolean connectionClosedFlag = true;
					try {
						initializeZmqPushSocket(searchNodeId, zmqPushSocketRef);
						connectionClosedFlag = false;

						while (!ShutdownHook.isShutdownFlag) {
							SegmentJobMessage segmentJobMessage = segmentJobMessageQueue.poll(10, TimeUnit.SECONDS);
							if (segmentJobMessage == null) {
								if (!connectionClosedFlag) {
									boolean closeInactiveConnectionFlag = bioParameterService.getParameterValue(
											"ZMQ_PUSH_CLOSE_INACTIVE_CONNECTION_FLAG", "DEFAULT", false);
									if (closeInactiveConnectionFlag) {
										closeZmqPushSocket(zmqPushSocketRef);
										connectionClosedFlag = true;
									}
								}
								continue;
							}

							if (isSearchJobMarkedAsError(segmentJobMessage.searchJobId)) {
								logger.warn("Search job is already marked as error, ignoring the searchJobId: "
										+ segmentJobMessage.searchJobId);
								continue;
							}

							long startTimeMilli = System.currentTimeMillis();
							try {
								if (connectionClosedFlag) {
									initializeZmqPushSocket(searchNodeId, zmqPushSocketRef);
									connectionClosedFlag = false;
								}

								ZmqPushConnection.sendMessage(zmqPushSocketRef.zmqPushSocket,
										segmentJobMessage.segmentJobId, segmentJobMessage.payload);
							} catch (ZmqConnectionException | ZmqSendException ex) {
								logger.error(ex.getClass().getSimpleName()
										+ " in SnSegJobSenderTask during sendMessage to searchNodeId: " + searchNodeId
										+ ", searchJobId: " + segmentJobMessage.searchJobId + " : " + ex.getMessage(),
										ex);
								notifySearchNodeOfflineFunction.accept(searchNodeId);
								matcherNodeClientHelper.handleSendReceiveError(searchNodeId, BioComponentType.SN, ex);
								handleSearchRequestBuilderError(segmentJobMessage.searchJobId,
										segmentJobMessage.searchControllerId,
										SearchConstants.ERROR_CODE_SEARCH_JOB_TIMEOUT, "SEND_TIMEOUT_ERROR",
										ex.getMessage(), ex, new AtomicReference<>());
								break;
							}
						}
					} catch (Throwable th) {
						logger.error("Error in SnSegJobSenderTask for searchNodeId: " + searchNodeId + " : "
								+ th.getMessage(), th);
					}
				}
			} finally {
				CommonLogger.STATUS_LOG.warn("Exiting the SnSegJobSenderTask for searchNodeId: " + searchNodeId
						+ ", isShutdownFlag: " + ShutdownHook.isShutdownFlag);
				keyConcurrencySemaphore.release();

				closeZmqPushSocket(zmqPushSocketRef);
			}
		}

		private final void initializeZmqPushSocket(String searchNodeId, ZmqPushSocketRef zmqPushSocketRef)
				throws Exception {
			String snWorkerConnectionUrl = snWorkerConnectionUrlCache.get(searchNodeId);
			if (zmqPushSocketRef.zmqPushSocket == null) {
				zmqPushSocketRef.zmqPushSocket = ZmqPushConnection.createSocket(snWorkerConnectionUrl);
			} else if (zmqPushSocketRef.zmqPushSocket.isErrorSendFlag()) {
				ZmqPushConnection.closeSocketQuitely(zmqPushSocketRef.zmqPushSocket);
				zmqPushSocketRef.zmqPushSocket = ZmqPushConnection.createSocket(snWorkerConnectionUrl);
			}
		}

		private final void closeZmqPushSocket(ZmqPushSocketRef zmqPushSocketRef) {
			if (zmqPushSocketRef != null && zmqPushSocketRef.zmqPushSocket != null) {
				ZmqPushConnection.closeSocketQuitely(zmqPushSocketRef.zmqPushSocket);
				zmqPushSocketRef.zmqPushSocket = null;
			}
		}
	}

	private final class SegmentJobMessage {
		private final String searchJobId;
		private final String segmentJobId;
		private final String searchControllerId;
		private final byte[] payload;

		public SegmentJobMessage(String searchJobId, String segmentJobId, String searchControllerId, byte[] payload) {
			this.searchJobId = searchJobId;
			this.segmentJobId = segmentJobId;
			this.searchControllerId = searchControllerId;
			this.payload = payload;
		}
	}

	private final void markSearchJobAsError(String searchJobId) {
		errorJobStatusCache.getUnchecked(searchJobId).set(true);
	}

	private final boolean isSearchJobMarkedAsError(String searchJobId) {
		AtomicBoolean errorFlag = errorJobStatusCache.getIfPresent(searchJobId);
		return errorFlag != null && errorFlag.get();
	}

	public final void buildAndSendSearchRequests(SnSegmentJobInfoList snSegmentJobInfoList,
			SnSegJobSenderTask snSegJobSenderTask) {
		String searchJobId = snSegmentJobInfoList.getSearchJobId();
		String searchNodeId = snSegmentJobInfoList.getSearchNodeId();
		String assignmentServerId = snSegmentJobInfoList.getAssignmentServerId();
		String searchControllerId = snSegmentJobInfoList.getSearchControllerId();

		NDC.clear();
		NDC.push(searchJobId);
		NDC.push(searchNodeId);

		if (logger.isDebugEnabled())
			logger.debug("In buildAndSendSearchRequests");

		long startTimeMilli = System.currentTimeMillis();
		long approxAssignmentToSendDelayMilli = (startTimeMilli - snSegmentJobInfoList.getJobCreateTimestampMilli())
				- snSegmentJobInfoList.getAssignmentDelayMilli();
		long loadTimeTakenMilli = -1;

		AtomicLong totalSearchRequestCount = new AtomicLong();
		AtomicReference<SearchResponse> errorSearchResponseRef = new AtomicReference<>();
		AtomicBoolean errorFlag = errorJobStatusCache.getUnchecked(searchJobId);
		try {
			if (errorFlag.get()) {
				logger.info("In buildAndSendSearchRequests: Search job is already marked as error");
				return;
			}

			BiKey<SearchJobRequestDto, Throwable> laodedPayload = loadSearchJobRequestDto(searchJobId,
					searchControllerId);

			loadTimeTakenMilli = System.currentTimeMillis() - startTimeMilli;

			if (laodedPayload.getB() != null) {
				Throwable th = laodedPayload.getB();
				handleSearchRequestBuilderError(searchJobId, assignmentServerId,
						SearchConstants.ERROR_CODE_SERIALIZATION, "SEARCH_OTHER_ERROR", th.getMessage(), th,
						errorSearchResponseRef);
				return;
			}

			final SearchJobRequestDto searchJobRequestDto = laodedPayload.getA();
			final String responseCallbackUrl = getSearchResultCallbackUrl(assignmentServerId);
			final long minSegmentSearchJobTimeoutMilli = bioParameterService
					.getParameterValue("MIN_SEGMENT_SEARCH_JOB_TIMEOUT_MILLI", "DEFAULT", 200);
			final long jobTimeoutMilli = snSegmentJobInfoList.getJobTimeoutMilli() - loadTimeTakenMilli
					- snSegmentJobInfoList.getAssignmentDelayMilli();

			if (jobTimeoutMilli < minSegmentSearchJobTimeoutMilli) {
				String errorMessage = "Not enough time left to execute, calculatedJobTimeoutMilli: " + jobTimeoutMilli
						+ ", minSegmentSearchJobTimeoutMilli: " + minSegmentSearchJobTimeoutMilli
						+ ", jobTimeoutMilli: " + snSegmentJobInfoList.getJobTimeoutMilli() + ", assignmentDelayMilli: "
						+ snSegmentJobInfoList.getAssignmentDelayMilli() + ",  loadTimeTakenMilli: "
						+ loadTimeTakenMilli + ", approxAssignmentToSendDelayMilli: " + approxAssignmentToSendDelayMilli
						+ " for searchJobId: " + searchJobId;
				handleSearchRequestBuilderError(searchJobId, searchControllerId,
						SearchConstants.ERROR_CODE_SEARCH_JOB_TIMEOUT, "SEARCH_TIMEOUT_ERROR", errorMessage, null,
						errorSearchResponseRef);
				return;
			}

			boolean isSnOnline = searchNodeOnlineCheckFunction.apply(searchNodeId);

			if (!isSnOnline) {
				String errorMessage = "Detected offline Search node " + searchNodeId + " while submitting searchJobId: "
						+ searchJobId;
				handleSearchRequestBuilderError(searchJobId, searchControllerId,
						SearchConstants.ERROR_CODE_SEARCH_NODE_ERROR, "SEARCH_CONNECTION_ERROR", errorMessage, null,
						errorSearchResponseRef);
				return;
			}

			for (SnSegmentJobInfo snSegmentJobInfo : snSegmentJobInfoList.getSnSegmentJobInfoList()) {
				String segmentJobId = snSegmentJobInfo.getSegmentJobId();

				if (errorSearchResponseRef.get() != null || errorFlag.get()) {
					logger.info("In buildAndSendSearchRequests: Search job is already marked as error : segmentJobId: "
							+ segmentJobId);
					break;
				}

				if (logger.isDebugEnabled())
					logger.debug("In buildSearchRequests for segmentJobId: " + segmentJobId);

				SearchRequest searchRequestPayload = SearchProtobufUtil.toProtobuf(searchJobId, snSegmentJobInfo,
						responseCallbackUrl, searchJobRequestDto, jobTimeoutMilli, bioParameterService);

				if (SEARCH_JOB_NODE_REQUEST_LOGGER.isTraceEnabled()) {
					SEARCH_JOB_NODE_REQUEST_LOGGER.trace("searchRequestPayload: " + searchRequestPayload.toString());
				}

				totalSearchRequestCount.incrementAndGet();

				snSegJobSenderTask.addToQueue(new SegmentJobMessage(searchJobId, segmentJobId, searchControllerId,
						searchRequestPayload.toByteArray()));
			}
		} catch (Throwable th) {
			logger.error(th.getClass().getSimpleName() + " Error in buildAndSendSearchRequests: " + th.getMessage(),
					th);
			handleSearchRequestBuilderError(searchJobId, searchControllerId,
					SearchConstants.ERROR_CODE_SEARCH_JOB_EXECUTION, "SEARCH_OTHER_ERROR", th.getMessage(), th,
					errorSearchResponseRef);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimeMilli;

			if (timeTakenMilli > 200 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info(
						"In buildAndSendSearchRequests: TimeTakenMilli: " + timeTakenMilli + ", loadTimeTakenMilli: "
								+ loadTimeTakenMilli + ", totalSearchRequestCount: " + totalSearchRequestCount.get()
								+ ", approxAssignmentToSendDelayMilli: " + approxAssignmentToSendDelayMilli
								+ (errorSearchResponseRef.get() != null ? ", errorFlag: true" : ""));
			}
		}
	}

	private void handleSearchRequestBuilderError(String searchJobId, String assignmentServerId, String errorCode,
			String errorType, String logMessage, Throwable th, AtomicReference<SearchResponse> errorSearchResponseRef) {
		if (errorSearchResponseRef.get() == null) {
			logger.error("In handleSearchRequestBuilderError: " + logMessage);

			SearchResponse errorSearchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId,
					assignmentServerId, errorCode, logMessage,
					th == null ? logMessage : ExceptionMessageFormatter.format(th));
			errorSearchResponseRef.set(errorSearchResponse);

			sendErrorSearchResponse(searchJobId, errorSearchResponse, assignmentServerId);

			logger.debug("After sending errorSearchResponse to assignmentServerId: " + assignmentServerId
					+ " for searchJobId: " + searchJobId);

			MetricsUtil.meter(BioComponentType.SC, assignmentServerId, errorType);
		}
	}

	private void sendErrorSearchResponse(String searchJobId, SearchResponse errorSearchResponse,
			String assignmentServerId) {
		try {
			if (isSearchJobMarkedAsError(searchJobId)) {
				return;
			}

			logger.info("In sendErrorSearchResponse: Before sending errorSearchResponse for searchJobId: " + searchJobId
					+ " to assignmentServerId: " + assignmentServerId + ", errorSearchResponse: "
					+ errorSearchResponse.toString());

			if (assignmentServerId.equals(LocalServerComponents.getSearchControllerId())) {
				SearchResultCallbackUtil.addToReceivedMessageQueue(searchJobId, errorSearchResponse);
			} else if (assignmentServerId.equals(LocalServerComponents.getSearchBrokerId())) {
				SearchResultCallbackUtil.addToReceivedMessageQueue(searchJobId, errorSearchResponse);
			} else {
				String searchResultCallbackUrl = getSearchResultCallbackUrl(assignmentServerId);
				ZmqPushConnection.sendMessage(searchResultCallbackUrl, errorSearchResponse.getMsgId(),
						errorSearchResponse.toByteArray());
			}

			markSearchJobAsError(searchJobId);
		} catch (Throwable th) {
			logger.error("Error in sendErrorSearchResponse for searchJobId: " + searchJobId + " : " + th.getMessage(),
					th);
		}
	}

	public void processMultiSnSegmentJobInfoList(byte[] multiSnSegmentJobInfoListBuf) {
		try {

			MultiSnSegmentJobInfoList multiSnSegmentJobInfoList = MultiSnSegmentJobInfoList
					.parseFrom(multiSnSegmentJobInfoListBuf);
			for (SnSegmentJobInfoList snSegmentJobInfoList : multiSnSegmentJobInfoList.getSnSegmentJobInfoListList()) {
				addToSearchRequestBuilderQueue(snSegmentJobInfoList);
			}
		} catch (Throwable th) {
			logger.error("Error in processMultiSnSegmentJobInfoList : while processing MultiSnSegmentJobInfoList : "
					+ th.getMessage(), th);
		}
	}

	private final String getSearchNodeConnectionUrl(String searchNodeId, BioConnectionType bioConnectionType)
			throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchNodeId, BioComponentType.SN,
				bioConnectionType, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException("Search node connection url is not configured for searchNodeId: "
					+ searchNodeId + ", BioComponentType: " + BioComponentType.SN + ", connectionType: "
					+ bioConnectionType + ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	private final String getSearchResultCallbackUrl(String assignmentServerId) throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(assignmentServerId, BioComponentType.SC,
				BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException(
					"Error in getSearchResultCallbackUrl: callback url is not configured for assignmentServerId: "
							+ assignmentServerId + ", connectionType: " + BioConnectionType.WORKER_CALLBACK
							+ ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	private final String getSearchBrokerJobDistributionUrl(String searchBrokerId)
			throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchBrokerId, BioComponentType.SB,
				BioConnectionType.JOB_DISTRIBUTOR, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException(
					"Search broker job distributor connection url is not configured for searchBrokerId: "
							+ searchBrokerId + ", BioComponentType: " + BioComponentType.SB + ", connectionType: "
							+ BioConnectionType.JOB_DISTRIBUTOR + ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	private BiKey<SearchJobRequestDto, Throwable> loadSearchJobRequestDto(String searchJobId,
			String searchControllerId) {
		try {
			BiKey<BioMatcherJobRequestPayload, Throwable> loadedKey = SearchJobPayloadCache
					.getSearchJobRequestPayload(searchJobId);
			if (loadedKey.getB() != null) {
				return new BiKey<>(null, loadedKey.getB());
			}

			BioMatcherJobRequestPayload bioMatcherJobRequestPayload = loadedKey.getA();

			SearchJobRequestDto request = bioMatcherJobRequestPayload.getSearchJobRequest();

			return new BiKey<>(request, null);
		} catch (Throwable th) {
			logger.error("Error in loadSearchJobRequestDto while unmarshal: " + th.getMessage(), th);
			return new BiKey<>(null,
					new Exception("Error in loadSearchJobRequestDto while unmarshal: " + th.getMessage(), th));
		}
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioSearchControllerManager(BioSearchControllerManager bioSearchControllerManager) {
		this.bioSearchControllerManager = bioSearchControllerManager;
	}

	public void setBioSearchBrokerManager(BioSearchBrokerManager bioSearchBrokerManager) {
		this.bioSearchBrokerManager = bioSearchBrokerManager;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In SegmentJobSnClientHelper.afterPropertiesSet");

		BioParameterService.bioParameterServiceRef.compareAndSet(null, bioParameterService);

		bioParameterService.deleteParameter("SB_TO_SN_SEG_JOB_SUBMITTER_CONCURRENCY_COUNT", "DEFAULT");

		int maxSearchJobRequestPayloadCacheCount = bioParameterService
				.getParameterValue("MAX_SEARCH_JOB_REQUEST_PAYLOAD_CACHE_COUNT", "DEFAULT", 200);
		long searchJobRequestPayloadCacheExpiryMilli = bioParameterService.getParameterValue(
				"SEARCH_JOB_REQUEST_PAYLOAD_CACHE_EXPIRY_MILLI", "DEFAULT", TimeUnit.SECONDS.toMillis(2));
		int maxSearchJobResultPayloadCacheCount = bioParameterService
				.getParameterValue("MAX_SEARCH_JOB_RESULT_PAYLOAD_CACHE_COUNT", "DEFAULT", 200);
		long searchJobResultPayloadCacheExpiryMilli = bioParameterService.getParameterValue(
				"SEARCH_JOB_RESULT_PAYLOAD_CACHE_EXPIRY_MILLI", "DEFAULT", TimeUnit.SECONDS.toMillis(2));

		long minSegmentSearchJobTimeoutMilli = bioParameterService
				.getParameterValue("MIN_SEGMENT_SEARCH_JOB_TIMEOUT_MILLI", "DEFAULT", 200);
		int zmqIoThreadCount = bioParameterService
				.getParameterValue("SEARCH_JOB_DISTRIBUTION_LISTINER_ZMQ_IO_THREAD_COUNT", "DEFAULT", 10);

		snSegmentJobSubmitterConcurrencySupplier = BioParameterService
				.getIntSupplier("SN_SEG_JOB_SUBMITTER_CONCURRENCY_COUNT", "DEFAULT", 2);
		snSegmentJobSubmitterConcurrencySupplier.get();

		messagSubmitterBatchSizeSupplier = BioParameterService.getIntSupplier("SN_SEG_JOB_SUBMITTER_BATCH_SIZE",
				"DEFAULT", 10);
		messagSubmitterBatchSizeSupplier.get();

		scToSnDirectFlagSupplier = BioParameterService
				.getBooleanSupplier("SC_TO_SN_DIRECT_SEGMENT_JOB_DISTRIBUTION_FLAG", "DEFAULT", false);
		scToSnDirectFlagSupplier.get();

		snWorkerConnectionUrlCache = CacheBuilder.newBuilder().concurrencyLevel(100).maximumSize(1024 * 2)
				.expireAfterAccess(10, TimeUnit.MINUTES).build(new CacheLoader<String, String>() {
					public String load(String searchNodeId) throws Exception {
						return getSearchNodeConnectionUrl(searchNodeId, BioConnectionType.WORKER);
					}
				});

		SpringCacheManager.registerGuavaCache("snWorkerConnectionUrlCache", snWorkerConnectionUrlCache);

		String searchControllerId = bioSearchControllerManager.getSearchControllerId();
		String searchBrokerId = bioSearchBrokerManager.getSearchBrokerId();

		if (searchControllerId != null || searchBrokerId != null) {

			final ConcurrentValuedHashMap<String, ConcurrentReader<Boolean>> scSearchNodeOnlineStatusMap = bioSearchControllerManager
					.getSearchNodeOnlineStatusMap();

			final ConcurrentValuedHashMap<String, BooleanLatch> sbSearchNodeOnlineStatusMap = bioSearchBrokerManager
					.getSearchNodeOnlineStatusMap();

			searchNodeOnlineCheckFunction = (searchNodeId) -> {
				boolean scToSnDirectFlag = scToSnDirectFlagSupplier.get();
				if (scToSnDirectFlag) {
					return scSearchNodeOnlineStatusMap.getValue(searchNodeId).get();
				} else {
					return sbSearchNodeOnlineStatusMap.getValue(searchNodeId).getFlag();
				}
			};

			notifySearchNodeOfflineFunction = (searchNodeId) -> {
				boolean scToSnDirectFlag = scToSnDirectFlagSupplier.get();
				if (scToSnDirectFlag == true) {
					bioSearchControllerManager.notifySearchNodeOffline(searchNodeId);
				} else {
					bioSearchBrokerManager.notifySearchNodeOffline(searchNodeId);
				}
			};

			if (searchBrokerId != null) {
				String sbJobDistributionUrl = getSearchBrokerJobDistributionUrl(searchBrokerId);

				Supplier<Integer> zmqIoThreadCountSupplier = BioParameterService
						.getIntSupplier("SEARCH_JOB_DISTRIBUTION_LISTINER_ZMQ_IO_THREAD_COUNT", "DEFAULT", 10);

				sbJobDistributionMessageListener = new ZmqPullMessageListener("SB_SEARCH_JOB_DISTRIBUTION_LISTINER",
						sbJobDistributionUrl, zmqIoThreadCountSupplier, () -> 5,
						(multiSnSegmentJobInfoListBuf) -> processMultiSnSegmentJobInfoList(
								multiSnSegmentJobInfoListBuf));
				sbJobDistributionMessageListener.startZmqPullListener();
			}
		}
	}
}
