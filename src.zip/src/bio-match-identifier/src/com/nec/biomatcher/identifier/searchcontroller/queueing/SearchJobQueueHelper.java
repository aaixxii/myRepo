package com.nec.biomatcher.identifier.searchcontroller.queueing;

import static com.nec.biomatcher.identifier.util.SearchConstants.STRICT_JOB_MODE;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.callback.CallbackService;
import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.inmemory.BioTaskType;
import com.nec.biomatcher.comp.inmemory.InMemoryManager;
import com.nec.biomatcher.comp.inmemory.callback.CallbackListener;
import com.nec.biomatcher.comp.inmemory.tasktimeout.TaskTimeoutListener;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.manager.exception.BioMatchManagerException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaPackingUtil;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.comp.util.JobEntry;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.ExceptionMessageFormatter;
import com.nec.biomatcher.core.framework.common.HessianSerializer;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.TriKey;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentProducerConsumer;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.exception.SerializationException;
import com.nec.biomatcher.core.framework.license.exception.InvalidLicenseException;
import com.nec.biomatcher.core.framework.license.impl.LicenseManager;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.extractor.service.exception.BioExtractionException;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.searchcontroller.service.exception.BioSearchContollerException;
import com.nec.biomatcher.identifier.searchcontroller.sync.complete.service.StrictSegmentSyncCallbackService;
import com.nec.biomatcher.identifier.searchcontroller.tasks.SearchJobHouseKeepingTask;
import com.nec.biomatcher.identifier.searchcontroller.tasks.SyncJobHouseKeepingTask;
import com.nec.biomatcher.identifier.searchcontroller.util.ScSearchJobInfo;
import com.nec.biomatcher.identifier.searchcontroller.util.SearchJobAssignmentBySearchNodeUtil;
import com.nec.biomatcher.identifier.util.ScSyncJobInfo;
import com.nec.biomatcher.identifier.util.SearchConstants;
import com.nec.biomatcher.identifier.util.SearchJaxbXmlConvertor;
import com.nec.biomatcher.identifier.util.SearchJobPayloadCache;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;
import com.nec.biomatcher.identifier.util.SearchProtobufUtil;
import com.nec.biomatcher.spec.services.BioExtractionJobService;
import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;
import com.nec.biomatcher.spec.transfer.biometrics.DeleteBiometricEventDto;
import com.nec.biomatcher.spec.transfer.biometrics.InsertBiometricEventDto;
import com.nec.biomatcher.spec.transfer.biometrics.UpdateBiometricEventUserFlagDto;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobType;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractInputPayloadDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobResultPayload;
import com.nec.biomatcher.spec.transfer.job.search.SearchItemInputPayloadDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchRequestItemDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.InsertTemplateInfo;
import com.nec.biomatcher.spec.transfer.model.TemplateInfo;
import com.nec.biomatcher.spec.transfer.model.TemplateType;
import com.nec.biomatcher.template.validator.TemplateValidatorService;
import com.nec.biomatcher.template.validator.exception.InvalidTemplateException;
import com.nec.megha.proto.search.SearchResponseProto.SearchResponse;

/**
 * The Class SearchJobQueueHelper.
 */
public class SearchJobQueueHelper implements InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchJobQueueHelper.class);

	/** The bio match manager service. */
	private BioMatchManagerService bioMatchManagerService;

	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio search controller manager. */
	private BioSearchControllerManager bioSearchControllerManager;

	/** The bio extraction job service. */
	private BioExtractionJobService bioExtractionJobService;

	private BiometricEventService biometricEventService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The lob image service. */
	private LobImageService lobImageService;

	private TemplateValidatorService templateValidatorService;

	private SearchJobAssignmentBySearchNodeUtil searchJobAssignmentBySearchNodeUtil;

	private CallbackService httpCallbackService;
	private CallbackService zmqCallbackService;

	/** The pending extract search job id set. */
	private ConcurrentSkipListSet<String> pendingExtractSearchJobIdSet = null;

	/** The pending search job queue. */
	private ConcurrentValuedHashMap<String, PriorityBlockingQueue<JobEntry>> pendingSearchJobQueueMap = null;

	/** The search job queue housekeeping queue. */
	private DelayQueue<DelayedItem<String>> searchJobQueueHousekeepingQueue = null;

	/** The search job info map. */
	private ConcurrentHashMap<String, ScSearchJobInfo> searchJobInfoMap = null;	

	private ConcurrentValuedHashMap<TriKey<String, String, String>, SearchNodeCapacityGroupLoadInfo> scSearchNodePartitionedLoadMap = null;
	private ConcurrentValuedHashMap<BiKey<String, String>, SearchNodeCapacityGroupLoadInfo> snPartitionedLoadMap = null;

	private boolean notifySearchCallabckInWorkerThreadFlag = false;

	private ConcurrentSkipListSet<String> pendingExtractSyncJobIdSet = null;
	private ConcurrentHashMap<String, ScSyncJobInfo> syncJobInfoMap;
	private LinkedBlockingQueue<String> pendingSyncJobQueue;
	private DelayQueue<DelayedItem<String>> syncJobQueueHousekeepingQueue;
	private boolean notifySyncCallabckInWorkerThreadFlag = false;
	// private ConcurrentExecutor syncJobExecutor;
	private ConcurrentProducerConsumer<String> syncJobExecutor;

	private MatcherFunctionControlUtil matcherFunctionControlUtil;

	/** The search jaxb xml convertor. */
	private final SearchJaxbXmlConvertor searchJaxbXmlConvertor = new SearchJaxbXmlConvertor();

	private final AtomicLong searchJobCounter = new AtomicLong();
	private final AtomicLong syncJobCounter = new AtomicLong();

	/** The initialization count. */
	private static AtomicInteger initializationCount = new AtomicInteger();

	private static LinkedBlockingQueue<String> completedExtractionJobIdQueue = new LinkedBlockingQueue<>();

	private StrictSegmentSyncCallbackService strictSegmentSyncCallbackService;

	/** The search controller id. */
	private String searchControllerId;
	
	private LicenseManager licenseManager;

	public void submitSyncJob(String syncJobId, SyncJobRequestDto syncJobRequestDto)
			throws BioSearchContollerException {
		logger.info("In submitSyncJob : Received sync job with syncJobId: " + syncJobId + ", jobTimeoutMill: "
				+ syncJobRequestDto.getJobTimeoutMill() + ", callbackUrl: " + syncJobRequestDto.getCallbackUrl());

		if (searchControllerId == null) {
			throw new BioSearchContollerException("Search controller is not configured for this server");
		}

		MetricsUtil.meter(BioComponentType.SC, searchControllerId, "SYNC_JOB_SUBMITTED");
		syncJobCounter.incrementAndGet();
		ScSyncJobInfo scSyncJobInfo = null;
		try {
			if (CollectionUtils.isEmpty(syncJobRequestDto.getEventSyncDtoList())) {
				throw new Exception("EventSyncDtoList is empty for syncJobId: " + syncJobId);
			}

			scSyncJobInfo = buildScSyncJobInfo(syncJobId, syncJobRequestDto);
			syncJobInfoMap.put(syncJobId, scSyncJobInfo);

			if (matcherFunctionControlUtil.acquireFunctionSlot(BioMatcherJobType.ENROLL.name())) {
				// No need to block for enrollments
				scSyncJobInfo.markFunctionSlotAcquired();
			}

			// Create dummy request
			BioMatcherJobRequestPayload bioMatcherJobRequestPayload = new BioMatcherJobRequestPayload();
			syncJobRequestDto.setEventSyncDto(new ArrayList<>());
			bioMatcherJobRequestPayload.setSyncJobRequestDto(syncJobRequestDto);
			lobImageService.createLob(syncJobId, HessianSerializer.marshal(bioMatcherJobRequestPayload), "req");

			boolean isExtractionRequired = false;
			List<byte[]> templateList = new ArrayList<>();
			for (BiometricEventSyncTypeDto biometricEventSyncTypeDto : scSyncJobInfo.getEventSyncTypeDtoList()) {
				if (biometricEventSyncTypeDto instanceof InsertBiometricEventDto) {
					InsertBiometricEventDto insertBiometricEventDto = (InsertBiometricEventDto) biometricEventSyncTypeDto;

					if (insertBiometricEventDto.getExtractInputPayloadDto() != null) {
						ExtractJobRequestDto exJobRequestDto = new ExtractJobRequestDto();
						exJobRequestDto.setJobMode(syncJobRequestDto.getJobMode());
						exJobRequestDto.setJobTimeoutMill(syncJobRequestDto.getJobTimeoutMill());
						exJobRequestDto.setExtractInputPayload(insertBiometricEventDto.getExtractInputPayloadDto());
						exJobRequestDto.setCallbackUrl("biosync://" + syncJobId);
						String extractionJobId = bioExtractionJobService.submitExtractionJob(exJobRequestDto);

						logger.debug("Extraction job: " + extractionJobId + " created for syncJobId: " + syncJobId);
						scSyncJobInfo.addExtractionJobInfo(extractionJobId, insertBiometricEventDto);

						insertBiometricEventDto.setExtractInputPayloadDto(null);

						isExtractionRequired = true;
					} else {
						for (InsertTemplateInfo insertTemplateInfo : insertBiometricEventDto
								.getInsertTemplateInfoList()) {
							if (insertTemplateInfo.getTemplatePayload() != null
									&& insertTemplateInfo.getTemplateData() == null) {
								MeghaTemplateConfig meghaTemplateConfig = bioMatcherConfigService
										.getMeghaTemplateConfig();
								// Feature data is passed instead of template
								// data, so we need to do packing
								byte[] templateData = MeghaPackingUtil.packTemplate(
										insertTemplateInfo.getTemplatePayload(), meghaTemplateConfig,
										TemplateType.valueOf(insertTemplateInfo.getTemplateType()));
								insertTemplateInfo.setTemplateData(templateData);
								insertTemplateInfo.setTemplatePayload(null);
							}
							if (insertTemplateInfo.getTemplateData() != null) {
								templateList.add(insertTemplateInfo.getTemplateData());
							}
						}
					}
				}
			}

			if (isExtractionRequired) {
				pendingExtractSyncJobIdSet.add(syncJobId);
			}

			long maxSyncJobTimeoutMilli = bioParameterService.getParameterValue("MAX_SYNC_JOB_TIMEOUT_MILLI", "DEFAULT",
					TimeUnit.SECONDS.toMillis(30));
			Long cappedTimeoutMilli = Math.min(maxSyncJobTimeoutMilli,
					MoreObjects.firstNonNull(syncJobRequestDto.getJobTimeoutMill(), maxSyncJobTimeoutMilli));

			long syncJobRetentionPeriodMilli = bioParameterService.getParameterValue("SYNC_JOB_RETENTION_PERIOD_MILLI",
					"DEFAULT", TimeUnit.MINUTES.toMillis(30));
			syncJobQueueHousekeepingQueue.add(new DelayedItem<String>(syncJobId,
					Math.max(cappedTimeoutMilli + 2000L, syncJobRetentionPeriodMilli)));

			if (isExtractionRequired) {
				InMemoryManager.registerEnrollForTimeout(syncJobId, cappedTimeoutMilli);
			} else {
				boolean templateValidatorFlag = bioParameterService
						.getParameterValue("SYNC_JOB_TEMPLATE_VALIDATOR_FLAG", "DEFAULT", true);
				if (templateValidatorFlag && templateList != null && templateList.size() > 0) {
					long templateValidatorStartTimestampMilli = System.currentTimeMillis();
					try {
						templateValidatorService.validateTemplates(templateList, cappedTimeoutMilli);
					} finally {
						scSyncJobInfo.setTemplateVerifyTimeTakenMilli(
								System.currentTimeMillis() - templateValidatorStartTimestampMilli);
					}
				}

				pendingSyncJobQueue.offer(syncJobId);
			}
		} catch (InvalidTemplateException ex) {
			pendingExtractSyncJobIdSet.remove(syncJobId);
			syncJobInfoMap.remove(syncJobId);
			releaseFunctionSlot(scSyncJobInfo);

			throw new BioSearchContollerException("Invalid template specified in syncJobRequestDto: " + ex.getMessage(),
					ex);
		} catch (Throwable th) {
			pendingExtractSyncJobIdSet.remove(syncJobId);
			syncJobInfoMap.remove(syncJobId);
			releaseFunctionSlot(scSyncJobInfo);

			throw new BioSearchContollerException(
					"Error in submitSyncJob for syncJobId: " + syncJobId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Submit search job.
	 *
	 * @param searchJobId
	 *            the search job id
	 * @param jobRequestDto
	 *            the job request dto
	 * @throws BioSearchContollerException
	 *             the bio search contoller exception
	 */
	public void submitSearchJob(String searchJobId, SearchJobRequestDto jobRequestDto)
			throws BioSearchContollerException {
		logger.info("In submitSearchJob : searchJobId: " + searchJobId + ", jobTimeoutMill: "
				+ jobRequestDto.getJobTimeoutMill() + ", searchFunctionId: " + jobRequestDto.getSearchFunctionId()
				+ ", capacityGroupKey: " + jobRequestDto.getCapacityGroupKey() + ", callbackUrl: "
				+ jobRequestDto.getCallbackUrl());

		if (searchControllerId == null) {
			throw new BioSearchContollerException("Search controller is not configured for this server");
		}

		if (CollectionUtils.isEmpty(jobRequestDto.getSearchRequestItemList())) {
			throw new BioSearchContollerException("SearchRequestItem list is not set in SearchJobRequestDto");
		}

		MetricsUtil.meter(BioComponentType.SC, searchControllerId, "SEARCH_JOB_SUBMITTED");
		searchJobCounter.incrementAndGet();

		ScSearchJobInfo scSearchJobInfo = null;
		try {
			// Integer binId = jobRequestDto.getSearchRequestItem().getBinId();
			int internalMaxCandidates = bioParameterService.getParameterValue("INTERNAL_SEARCH_RESULT_MAX_CANDIDATES",
					"DEFAULT", 500);

			boolean isFunctionCapacityGroupControlEnabled = bioParameterService
					.getParameterValue("FUNCTION_CAPACITY_GROUP_CONTROL_ENABLED_FLAG", "DEFAULT", false);

			long searchJobRetentionPeriodMilli = bioParameterService
					.getParameterValue("SEARCH_JOB_RETENTION_PERIOD_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(30));

			long maxSearchJobTimeoutMilli = TimeUnit.SECONDS.toMillis(1);

			ExtractInputPayloadDto extractInputPayloadDto = jobRequestDto.getExtractInputPayloadDto();
			jobRequestDto.setExtractInputPayloadDto(null);

			String defaultSearchFunctionId = StringUtils
					.trim(StringUtils.upperCase(jobRequestDto.getSearchFunctionId()));
			String capacityGroupKey = StringUtils
					.trim(StringUtils.upperCase(StringUtils.isBlank(jobRequestDto.getCapacityGroupKey()) ? "0"
							: jobRequestDto.getCapacityGroupKey()));

//			if (isFunctionCapacityGroupControlEnabled) {
//				if (StringUtils.isBlank(defaultSearchFunctionId)) {
//					throw new BioSearchContollerException(
//							"Function capacity group control is enabled but  search function is not specified");
//				}
//
//				if (!capacityGroupKey.contains("~")) {
//					capacityGroupKey = defaultSearchFunctionId + "~" + capacityGroupKey;
//				}
//			}

			HashSet<Integer> binIdSet = new HashSet<>();
			HashSet<String> searchNodeIdSet = new HashSet<>();
			HashMap<Integer, Long> taggedSegmentVersionMap = new HashMap<>();
			ConcurrentValuedHashMap<Integer, ConcurrentSkipListSet<String>> segmentIdRequestKeySetMap = new ConcurrentValuedHashMap<>(
					segmentId -> new ConcurrentSkipListSet<>());

			int requestItemKey = 0;
			Set<String> searchRequestKeySet = new HashSet<>();
			List<byte[]> templateList = new ArrayList<>();
			for (SearchRequestItemDto searchRequestItemDto : jobRequestDto.getSearchRequestItemList()) {

				// Make sure request item key is unique
				if (StringUtils.isBlank(searchRequestItemDto.getRequestItemKey())) {
					while (searchRequestKeySet.contains("REQ_" + (++requestItemKey)))
						;
					searchRequestItemDto.setRequestItemKey("REQ_" + requestItemKey);
					searchRequestKeySet.add(searchRequestItemDto.getRequestItemKey());
				} else if (searchRequestKeySet.contains(searchRequestItemDto.getRequestItemKey())) {
					searchRequestItemDto
							.setRequestItemKey(searchRequestItemDto.getRequestItemKey() + "_" + (++requestItemKey));
					searchRequestKeySet.add(searchRequestItemDto.getRequestItemKey());
				}

				if (CollectionUtils.isEmpty(searchRequestItemDto.getBinIdList())) {
					throw new BioSearchContollerException("Target binIdList is not set for search request key: "
							+ searchRequestItemDto.getRequestItemKey());
				}

				SearchItemInputPayloadDto searchItemInputPayloadDto = searchRequestItemDto.getSearchItemPayloadDto();
				if (searchItemInputPayloadDto == null) {
					throw new BioSearchContollerException(
							"SearchItemInputPayloadDto is not set for search request key: "
									+ searchRequestItemDto.getRequestItemKey());
				}

				if (StringUtils.isBlank(searchItemInputPayloadDto.getTemplateType())) {
					if (searchItemInputPayloadDto.getTemplateData() == null) {
						throw new BioSearchContollerException("TemplateType is not set for search request key: "
								+ searchRequestItemDto.getRequestItemKey());
					}
				}

				if (searchItemInputPayloadDto.getTemplatePayload() != null
						&& searchItemInputPayloadDto.getTemplateData() == null) {
					// Feature data is passed instead of template data, so we
					// need to do packing
					MeghaTemplateConfig meghaTemplateConfig = bioMatcherConfigService.getMeghaTemplateConfig();
					byte[] templateData = MeghaPackingUtil.packTemplate(searchItemInputPayloadDto.getTemplatePayload(),
							meghaTemplateConfig, TemplateType.valueOf(searchItemInputPayloadDto.getTemplateType()));
					searchItemInputPayloadDto.setTemplateData(templateData);
					searchItemInputPayloadDto.setTemplatePayload(null);
				}

				for (Integer binId : searchRequestItemDto.getBinIdList()) {

					BioMatcherBinInfo bioMatcherBinInfo = bioMatcherConfigService.getMatcherBinInfo(binId);
					if (bioMatcherBinInfo == null) {
						throw new BioSearchContollerException("Matcher Bin does not exit for binId: " + binId);
					}

					licenseManager.checkSearchLicense(bioMatcherBinInfo.getTemplateType());

					Set<Integer> missingAssignmentSegmentIdSet = bioMatcherConfigService
							.getMissingSegmentAssignmentsByBinId(binId, capacityGroupKey);
					if (missingAssignmentSegmentIdSet != null && !missingAssignmentSegmentIdSet.isEmpty()) {
						throw new BioSearchContollerException("Some segments of bin: " + binId
								+ " are not assigned to search nodes with capacityGroupKey: " + capacityGroupKey
								+ ", missingAssignmentSegmentIdSet : " + missingAssignmentSegmentIdSet);
						// logger.error("Some segments of bin: "+binId+" are not
						// assigned to search nodes with capacityGroupKey:
						// "+capacityGroupKey+", missingAssignmentSegmentIdSet :
						// "+missingAssignmentSegmentIdSet);
					}

					binIdSet.add(binId);

					searchNodeIdSet.addAll(
							bioMatcherConfigService.getAssignedSearchNodeIdListByBinId(binId, capacityGroupKey));

					Map<Integer, Long> matcherSegmentVersionMap = bioMatchManagerService
							.getLiveMatcherSegmentVersionMap(binId);

					if (matcherSegmentVersionMap.size() > 0) {
						matcherSegmentVersionMap.forEach((segmentId, segmentVersionId) -> {
							if (!missingAssignmentSegmentIdSet.contains(segmentId)) {
								segmentIdRequestKeySetMap.getValue(segmentId)
										.add(searchRequestItemDto.getRequestItemKey());
								taggedSegmentVersionMap.putIfAbsent(segmentId, segmentVersionId);
							}
						});
					}

					maxSearchJobTimeoutMilli = Math.max(maxSearchJobTimeoutMilli, bioParameterService.getParameterValue(
							"MAX_SEARCH_JOB_TIMEOUT_MILLI_FOR_BIN_" + binId, "DEFAULT", TimeUnit.MINUTES.toMillis(10)));
				}

				if (searchItemInputPayloadDto.getTemplateData() != null) {
					byte templateData[] = searchRequestItemDto.getSearchItemPayloadDto().getTemplateData();
					templateList.add(templateData);

					TemplateType templateType = MeghaTemplateUtil.getTemplateTypeFromTemplate(templateData);
					MeghaTemplateParser meghaTemplateParser = bioMatcherConfigService
							.getTemplateTypeMeghaTemplateParserMap().get(templateType);
					if (meghaTemplateParser == null) {
						throw new MeghaTemplateException("Template type code: " + templateType + " is not supported");
					}

					meghaTemplateParser.validateSearchTemplateData(templateData);
					searchItemInputPayloadDto.setTemplateType(templateType.name());

					searchRequestItemDto.getSearchItemPayloadDto().setTemplateData(templateData);
				}

				if (defaultSearchFunctionId == null) {
					Map<Integer, Integer> binIdTemplateTypeCodeMap = bioMatcherConfigService
							.getBinIdTemplateTypeCodeMap();
					int probeTemplateTypeCode = TemplateType.valueOf(searchItemInputPayloadDto.getTemplateType())
							.getTemplateTypeCode();
					int galleryTemplateTypeCode = binIdTemplateTypeCodeMap
							.get(searchRequestItemDto.getBinIdList().get(0));
					defaultSearchFunctionId = getDefaultSearchFunctionId(probeTemplateTypeCode,
							galleryTemplateTypeCode);
				}
			}

			boolean templateValidatorFlag = bioParameterService.getParameterValue("SEARCH_JOB_TEMPLATE_VALIDATOR_FLAG",
					"DEFAULT", true);
			long cappedTimeoutMilli = Math.min(maxSearchJobTimeoutMilli,
					MoreObjects.firstNonNull(jobRequestDto.getJobTimeoutMill(), maxSearchJobTimeoutMilli));
			jobRequestDto.setJobTimeoutMill(cappedTimeoutMilli);

			boolean isFunctionSlotAcquired = matcherFunctionControlUtil.tryAcquireFunctionSlot(defaultSearchFunctionId);
			if (!isFunctionSlotAcquired) {
				throw new BioSearchContollerException(
						"Unable to acquire function job slot for search functionId: " + defaultSearchFunctionId);
			}

			scSearchJobInfo = buildScSearchJobInfo(searchJobId, jobRequestDto, binIdSet, segmentIdRequestKeySetMap,
					taggedSegmentVersionMap, defaultSearchFunctionId, capacityGroupKey, internalMaxCandidates);
			scSearchJobInfo
					.setIncludeExtractionResultFlag(Boolean.TRUE.equals(jobRequestDto.getIncludeExtractionResult()));
			scSearchJobInfo.markFunctionSlotAcquired();
			searchJobInfoMap.put(searchJobId, scSearchJobInfo);

			// Save search request to lobStorage, This is required by Search broker			
			BioMatcherJobRequestPayload bioMatcherJobRequestPayload = new BioMatcherJobRequestPayload();
			bioMatcherJobRequestPayload.setCreateDateTimeMilli(System.currentTimeMillis());
			bioMatcherJobRequestPayload.setSearchJobRequest(jobRequestDto);
			lobImageService.createLob(searchJobId, HessianSerializer.marshal(bioMatcherJobRequestPayload), "req");

			searchJobQueueHousekeepingQueue.add(new DelayedItem<String>(searchJobId,
					Math.max(cappedTimeoutMilli + 2000L, searchJobRetentionPeriodMilli)));

			boolean isExtractionRequired = false;
			if (searchNodeIdSet.size() > 0 && segmentIdRequestKeySetMap.size() > 0 && extractInputPayloadDto != null) {
				ExtractJobRequestDto exJobRequestDto = new ExtractJobRequestDto();
				exJobRequestDto.setJobMode(jobRequestDto.getJobMode());
				exJobRequestDto.setJobTimeoutMill(jobRequestDto.getJobTimeoutMill());
				exJobRequestDto.setExtractInputPayload(extractInputPayloadDto);
				exJobRequestDto.setCallbackUrl("biosearch://" + searchJobId);
				String extractionJobId = bioExtractionJobService.submitExtractionJob(exJobRequestDto);
				logger.debug("Extraction job: " + extractionJobId + " created for searchJobId: " + searchJobId);

				scSearchJobInfo.setExtractionJobId(extractionJobId);

				pendingExtractSearchJobIdSet.add(searchJobId);
				isExtractionRequired = true;
			}

			if (searchNodeIdSet.size() > 0 && segmentIdRequestKeySetMap.size() > 0 && !isExtractionRequired) {
				if (templateValidatorFlag) {
					long templateValidatorStartTimestampMilli = System.currentTimeMillis();
					try {
						templateValidatorService.validateTemplates(templateList, cappedTimeoutMilli);
					} finally {
						scSearchJobInfo.setTemplateVerifyTimeTakenMilli(
								System.currentTimeMillis() - templateValidatorStartTimestampMilli);
					}
				}
			}

			InMemoryManager.registerSearchForTimeout(searchJobId, cappedTimeoutMilli);

			if (!isExtractionRequired) {
				SearchJobPayloadCache.cacheSearchJobRequestPayload(searchJobId, bioMatcherJobRequestPayload);
				if (segmentIdRequestKeySetMap.size() == 0) {
					logger.warn(
							"segmentIdRequestKeySetMap size is 0, completing the search job without searching for searchJobId: "
									+ searchJobId);

					SearchResponse searchResponse = SearchProtobufUtil.buildCompletedSearchResponse(searchJobId);

					ConcurrentLinkedQueue<SearchResponse> searchResponseQueue = new ConcurrentLinkedQueue<>();
					searchResponseQueue.add(searchResponse);

					processSearchResponses(searchJobId, searchResponseQueue);
				} else if (searchNodeIdSet.isEmpty()) {
					logger.warn("No search nodes assigned to capacityGroupKey: " + scSearchJobInfo.capacityGroupKey
							+ " to process search job with searchJobId: " + searchJobId);
					SearchResponse searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId,
							searchControllerId, SearchConstants.ERROR_CODE_SEARCH_JOB_EXECUTION,
							"No search nodes assigned to capacityGroupKey: " + scSearchJobInfo.capacityGroupKey
									+ " to process search job with searchJobId: " + searchJobId,
							null);

					ConcurrentLinkedQueue<SearchResponse> searchResponseQueue = new ConcurrentLinkedQueue<>();
					searchResponseQueue.add(searchResponse);

					processSearchResponses(searchJobId, searchResponseQueue);
				} else {
					// pendingSearchJobQueueMap.getValue(scSearchJobInfo.capacityGroupKey).add(scSearchJobInfo.getJobEntry());
					// capacityGroupLoadVersionMap.getValue(scSearchJobInfo.capacityGroupKey).incrementVersion();
					searchJobAssignmentBySearchNodeUtil.addJobEntryForAssignment(searchNodeIdSet,
							scSearchJobInfo.getJobEntry(), scSearchJobInfo.capacityGroupKey);

					MetricsUtil.meter(BioComponentType.SC, scSearchJobInfo.getDefaultSearchFunctionId(),
							"SEARCH_FUNCTION_SUBMITTED");
				}
			}
		} catch (BioSearchContollerException ex) {
			searchJobInfoMap.remove(searchJobId);
			releaseFunctionSlot(scSearchJobInfo);
			throw ex;
		} catch (InvalidTemplateException ex) {
			searchJobInfoMap.remove(searchJobId);
			releaseFunctionSlot(scSearchJobInfo);
			throw new BioSearchContollerException("Invalid template specified in syncJobRequestDto: " + ex.getMessage(),
					ex);
		} catch (InvalidLicenseException ex) {
			searchJobInfoMap.remove(searchJobId);
			releaseFunctionSlot(scSearchJobInfo);
			throw new BioSearchContollerException("Licence is not available : " + ex.getMessage(), ex);
		} catch (Throwable th) {
			searchJobInfoMap.remove(searchJobId);
			pendingExtractSearchJobIdSet.remove(searchJobId);
			releaseFunctionSlot(scSearchJobInfo);
			throw new BioSearchContollerException(
					"Error in submitSearchJob for searchJobId: " + searchJobId + " : " + th.getMessage(), th);
		}
	}

	private final void releaseFunctionSlot(ScSearchJobInfo scSearchJobInfo) {
		if (scSearchJobInfo != null && scSearchJobInfo.isFunctionSlotAcquiredFlag()) {
			scSearchJobInfo.releaseFunctionSlot(matcherFunctionControlUtil);
		}
	}

	private final void releaseFunctionSlot(ScSyncJobInfo scSyncJobInfo) {
		if (scSyncJobInfo != null && scSyncJobInfo.isFunctionSlotAcquiredFlag()) {
			scSyncJobInfo.releaseFunctionSlot(matcherFunctionControlUtil);
		}
	}

	/**
	 * Builds the sc search job info.
	 * 
	 * @param searchJobId
	 * @param searchJobRequestDto
	 * @param binIdSet
	 * @param segmentIdRequestKeySetMap
	 * @param taggedSegmentVersionMap
	 * @return
	 * @throws BioMatchManagerException
	 */
	private ScSearchJobInfo buildScSearchJobInfo(String searchJobId, SearchJobRequestDto searchJobRequestDto,
			Set<Integer> binIdSet,
			ConcurrentValuedHashMap<Integer, ConcurrentSkipListSet<String>> segmentIdRequestKeySetMap,
			Map<Integer, Long> taggedSegmentVersionMap, String defaultSearchFunctionId, String capacityGroupKey,
			int internalMaxCandidates) throws BioMatchManagerException {
		AtomicInteger maxCandidates = new AtomicInteger(10);

		searchJobRequestDto.getSearchRequestItemList().forEach(searchRequestItem -> {
			maxCandidates.set(MoreObjects.firstNonNull(searchRequestItem.getSearchItemPayloadDto().getMaxHitCount(),
					maxCandidates.get()));
		});

		ScSearchJobInfo scSearchJobInfo = new ScSearchJobInfo(searchJobId, searchJobRequestDto.getPriority(),
				maxCandidates.get(), searchJobRequestDto.getCallbackUrl(), searchJobRequestDto.getJobMode(),
				searchJobRequestDto.getJobTimeoutMill(), capacityGroupKey, binIdSet, segmentIdRequestKeySetMap,
				taggedSegmentVersionMap, defaultSearchFunctionId, internalMaxCandidates);

		return scSearchJobInfo;
	}

	private ScSyncJobInfo buildScSyncJobInfo(String syncJobId, SyncJobRequestDto syncJobRequestDto)
			throws BioMatchManagerException {
		ScSyncJobInfo scSyncJobInfo = new ScSyncJobInfo(syncJobId, syncJobRequestDto.getEventSyncDtoList(),
				syncJobRequestDto.getCallbackUrl(), syncJobRequestDto.getJobMode());
		return scSyncJobInfo;
	}

	/**
	 * Notify search job extraction completed.
	 *
	 * @param searchJobId
	 *            the search job id
	 * @param extractionResult
	 *            the extraction result
	 * @throws BioSearchContollerException
	 *             the bio search contoller exception
	 */
	public void notifySearchJobExtractionCompleted(String searchJobId, ExtractJobResultDto extractionResult)
			throws BioSearchContollerException {
		if (searchControllerId == null) {
			throw new BioSearchContollerException("Search controller is not configured for this server");
		}
		ScSearchJobInfo scSearchJobInfo = null;
		SearchResponse searchResponse = null;
		try {
			if (!pendingExtractSearchJobIdSet.remove(searchJobId)) {
				logger.warn(
						"In notifySearchJobExtractionCompleted: Cannot find searchJobId in PendingExtractSearchJobIdSet for searchJobId: "
								+ searchJobId);
				return;
			}

			scSearchJobInfo = searchJobInfoMap.get(searchJobId);
			if (scSearchJobInfo == null) {
				logger.warn("In notifySearchJobExtractionCompleted: Cannot find scSearchJobInfo for searchJobId: "
						+ searchJobId);
				return;
			}

			scSearchJobInfo.setExtractionCompletedDateTimeMilli(System.currentTimeMillis());

			if (extractionResult.getErrorList().size() > 0) {
				searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId, searchControllerId,
						extractionResult.getErrorList());
				logger.warn("In notifySearchJobExtractionCompleted: Extraction returned error list for searchJobId: "
						+ searchJobId);
				return;
			}

			byte lobData[] = null;
			try {
				lobData = lobImageService.getLobData(searchJobId, "req");
			} catch (Throwable th) {
				th = new BioSearchContollerException(
						"Error getting job request lob data for searchJobId: " + searchJobId + " : " + th.getMessage(),
						th);
				searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId, searchControllerId,
						SearchConstants.ERROR_CODE_LOBSTREAM_ACCESS, th.getMessage(),
						ExceptionMessageFormatter.format(th));
				return;
			}

			SearchJobRequestDto searchJobRequestDto = null;
			Long jobCreateDateTimeMilli = System.currentTimeMillis();
			try {
				BioMatcherJobRequestPayload bioMatcherJobRequestPayload = HessianSerializer.unmarshal(lobData);
				if (bioMatcherJobRequestPayload == null) {
					throw new Exception("bioMatcherJobRequestPayload is null");
				}

				jobCreateDateTimeMilli = bioMatcherJobRequestPayload.getCreateDateTimeMilli();

				searchJobRequestDto = bioMatcherJobRequestPayload.getSearchJobRequest();

				if (searchJobRequestDto == null) {
					throw new Exception("searchJobRequestDto is null");
				}
			} catch (Throwable th) {
				th = new BioSearchContollerException("Error during unmarshal of job request for searchJobId: "
						+ searchJobId + " : " + th.getMessage(), th);
				searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId, searchControllerId,
						SearchConstants.ERROR_CODE_SERIALIZATION, th.getMessage(),
						ExceptionMessageFormatter.format(th));
				return;
			}

			ArrayListMultimap<String, TemplateInfo> extractedTemplateInfoMap = ArrayListMultimap.create();
			for (TemplateInfo templateInfo : extractionResult.getTemplateInfoList()) {
				extractedTemplateInfoMap.put(templateInfo.getTemplateType(), templateInfo);
			}

			List<SearchRequestItemDto> newSearchRequestItemList = new ArrayList<>();
			boolean isNewSearchItemsAdded = false;
			for (SearchRequestItemDto searchRequestItemDto : searchJobRequestDto.getSearchRequestItemList()) {
				SearchItemInputPayloadDto searchItemInputPayloadDto = searchRequestItemDto.getSearchItemPayloadDto();
				if (searchItemInputPayloadDto != null) {
					String templateType = searchItemInputPayloadDto.getTemplateType();
					if (StringUtils.isBlank(templateType)) {
						Integer binId = searchRequestItemDto.getBinIdList().get(0);
						templateType = bioMatcherConfigService.getMatcherBinInfo(binId).getTemplateType();
						logger.warn("TemplateType is not specified in SearchItemPayloadDto, templateType of binId: "
								+ binId + ", templateType: " + templateType + " for searchJobId: " + searchJobId);

						searchItemInputPayloadDto.setTemplateType(templateType);
					}

					List<TemplateInfo> templateInfoList = extractedTemplateInfoMap.get(templateType);

					if (CollectionUtils.isEmpty(templateInfoList)) {
						searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId, searchControllerId,
								SearchConstants.ERROR_CODE_SEARCH_EXTRACTION,
								"Search image extraction did not return search template: " + templateType, null);
						logger.error(
								"In notifySearchJobExtractionCompleted: Search image extraction did not return search template: "
										+ templateType + ", templateInfoListSize: "
										+ extractionResult.getTemplateInfoList().size() + " for searchJobId: "
										+ searchJobId);
						return;
					}

					if (templateInfoList.size() == 1) {
						TemplateInfo templateInfo = templateInfoList.get(0);
						byte templateData[] = templateInfo.getTemplateData();
						searchItemInputPayloadDto.setTemplateData(templateData);
						newSearchRequestItemList.add(searchRequestItemDto);
					} else {
						for (int templateIndex = 0; templateIndex < templateInfoList.size(); templateIndex++) {
							TemplateInfo templateInfo = templateInfoList.get(templateIndex);
							String requestItemKey = searchRequestItemDto.getRequestItemKey();
							String newRequestItemKey = requestItemKey + "_" + (templateIndex + 1);

							SearchItemInputPayloadDto newSearchItemInputPayloadDto = new SearchItemInputPayloadDto();
							newSearchItemInputPayloadDto.setFunctionId(searchItemInputPayloadDto.getFunctionId());
							newSearchItemInputPayloadDto.setMaxHitCount(searchItemInputPayloadDto.getMaxHitCount());
							newSearchItemInputPayloadDto
									.setMinScoreThreshold(searchItemInputPayloadDto.getMinScoreThreshold());
							newSearchItemInputPayloadDto.setSearchOptions(searchItemInputPayloadDto.getSearchOptions());
							newSearchItemInputPayloadDto.setTemplateType(searchItemInputPayloadDto.getTemplateType());
							newSearchItemInputPayloadDto.setTemplateData(templateInfo.getTemplateData());

							SearchRequestItemDto newSearchRequestItemDto = new SearchRequestItemDto();
							newSearchRequestItemDto.setBinIdList(searchRequestItemDto.getBinIdList());
							newSearchRequestItemDto.setRequestItemKey(newRequestItemKey);
							newSearchRequestItemDto.setSearchItemPayloadDto(newSearchItemInputPayloadDto);

							newSearchRequestItemList.add(newSearchRequestItemDto);
							isNewSearchItemsAdded = true;
						}
					}
				}
			}

			searchJobRequestDto.setSearchRequestItemList(newSearchRequestItemList);

			if (isNewSearchItemsAdded) {
				ConcurrentValuedHashMap<Integer, ConcurrentSkipListSet<String>> segmentIdRequestKeySetMap = scSearchJobInfo
						.getPendingSegmentIdRequestKeySetMap();
				segmentIdRequestKeySetMap.clear();

				for (SearchRequestItemDto searchRequestItemDto : searchJobRequestDto.getSearchRequestItemList()) {

					for (Integer binId : searchRequestItemDto.getBinIdList()) {

						BioMatcherBinInfo bioMatcherBinInfo = bioMatcherConfigService.getMatcherBinInfo(binId);
						if (bioMatcherBinInfo == null) {
							throw new BioSearchContollerException("Matcher Bin does not exit for binId: " + binId);
						}

						Set<Integer> missingAssignmentSegmentIdSet = bioMatcherConfigService
								.getMissingSegmentAssignmentsByBinId(binId, scSearchJobInfo.capacityGroupKey);
						if (missingAssignmentSegmentIdSet != null && !missingAssignmentSegmentIdSet.isEmpty()) {
							throw new BioSearchContollerException("Some segments of bin: " + binId
									+ " are not assigned to search nodes with capacityGroupKey: "
									+ scSearchJobInfo.capacityGroupKey + ", missingAssignmentSegmentIdSet : "
									+ missingAssignmentSegmentIdSet);
							// logger.warn("Some segments of bin: "+binId+" are
							// not assigned to search nodes with
							// capacityGroupKey:
							// "+scSearchJobInfo.capacityGroupKey+",
							// missingAssignmentSegmentIdSet :
							// "+missingAssignmentSegmentIdSet);
						}

						Map<Integer, Long> matcherSegmentVersionMap = bioMatchManagerService
								.getLiveMatcherSegmentVersionMap(binId);

						if (matcherSegmentVersionMap.size() > 0) {
							matcherSegmentVersionMap.forEach((segmentId, segmentVersionId) -> {
								if (!missingAssignmentSegmentIdSet.contains(segmentId)) {
									segmentIdRequestKeySetMap.getValue(segmentId)
											.add(searchRequestItemDto.getRequestItemKey());
								}
							});
						}
					}
				}

				if (logger.isDebugEnabled())
					logger.debug("In notifySearchJobExtractionCompleted: searchJobId: " + searchJobId
							+ ", isNewSearchItemsAdded: " + isNewSearchItemsAdded + ", segmentIdRequestKeySetMapSize: "
							+ segmentIdRequestKeySetMap.size());
			}

			try {
				// Save the template along with jobRequest to lobStorage, as it
				// is required by search broker
				BioMatcherJobRequestPayload bioMatcherJobRequestPayload = new BioMatcherJobRequestPayload();
				bioMatcherJobRequestPayload.setCreateDateTimeMilli(jobCreateDateTimeMilli);
				bioMatcherJobRequestPayload.setSearchJobRequest(searchJobRequestDto);

				lobImageService.createLob(searchJobId, HessianSerializer.marshal(bioMatcherJobRequestPayload), "req");

				SearchJobPayloadCache.cacheSearchJobRequestPayload(searchJobId, bioMatcherJobRequestPayload);

				// pendingSearchJobQueueMap.getValue(scSearchJobInfo.capacityGroupKey).add(scSearchJobInfo.getJobEntry());
				// capacityGroupLoadVersionMap.getValue(scSearchJobInfo.capacityGroupKey).incrementVersion();

				HashSet<String> searchNodeIdSet = new HashSet<>();
				for (Integer binId : scSearchJobInfo.getBinIdSet()) {
					searchNodeIdSet.addAll(bioMatcherConfigService.getAssignedSearchNodeIdListByBinId(binId,
							scSearchJobInfo.capacityGroupKey));
				}

				if (searchNodeIdSet.isEmpty()) {
					logger.warn("No search nodes assigned to capacityGroupKey: " + scSearchJobInfo.capacityGroupKey
							+ " to process search job with searchJobId: " + searchJobId);
					searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId, searchControllerId,
							SearchConstants.ERROR_CODE_SEARCH_JOB_EXECUTION,
							"No search nodes assigned to capacityGroupKey: " + scSearchJobInfo.capacityGroupKey
									+ " to process search job with searchJobId: " + searchJobId,
							null);
					return;
				}

				searchJobAssignmentBySearchNodeUtil.addJobEntryForAssignment(searchNodeIdSet,
						scSearchJobInfo.getJobEntry(), scSearchJobInfo.capacityGroupKey);
			} catch (Throwable th) {
				th = new BioSearchContollerException(
						"Error during marshal of job request for searchJobId: " + searchJobId + " : " + th.getMessage(),
						th);
				searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId, searchControllerId,
						SearchConstants.ERROR_CODE_SERIALIZATION, th.getMessage(),
						ExceptionMessageFormatter.format(th));
				return;
			}
		} catch (Throwable th) {
			logger.error("Error during notifySearchJobExtractionCompleted : searchJobId: " + searchJobId + " : "
					+ th.getMessage(), th);
			th = new BioSearchContollerException("Error during notifySearchJobExtractionCompleted : searchJobId: "
					+ searchJobId + " : " + th.getMessage(), th);
			searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId, searchControllerId,
					SearchConstants.ERROR_CODE_SEARCH_EXTRACTION, th.getMessage(),
					ExceptionMessageFormatter.format(th));

		} finally {
			if (searchResponse != null) {
				if (scSearchJobInfo != null) {
					scSearchJobInfo.setSearchExtractErrorFlag(true);
				}

				ConcurrentLinkedQueue<SearchResponse> searchResponseQueue = new ConcurrentLinkedQueue<>();
				searchResponseQueue.add(searchResponse);

				processSearchResponses(searchJobId, searchResponseQueue);
			}
		}
	}

	public final void processSearchResponses(String searchJobId, Queue<SearchResponse> searchResponseQueue) {
		if (logger.isDebugEnabled())
			logger.debug("In processSearchResponses for searchJobId: " + searchJobId + ", searchResponseListSize: "
					+ searchResponseQueue.size());

		long startTimestampMilli = System.currentTimeMillis();

		ScSearchJobInfo scSearchJobInfo = searchJobInfoMap.get(searchJobId);
		if (scSearchJobInfo == null) {
			searchResponseQueue.clear();
			if (logger.isDebugEnabled())
				logger.debug("In processSearchResponses: Cannot find scSearchJobInfo for searchJobId: " + searchJobId);
			return;
		}

		try {
			boolean isTimeout = scSearchJobInfo.isTimeoutErrorFlag();

			boolean completeFlag = scSearchJobInfo.notifySegmentJobResults(searchResponseQueue, snPartitionedLoadMap);

			if (!completeFlag) {

				scSearchJobInfo.scSearchResultInfo.limitToMaxCandidates(bioMatcherConfigService.getSegmentIdBinIdMap(),
						bioMatcherConfigService.getBinIdMaxEventCountMap(), false);

				return;
			}

			InMemoryManager.removeFromTimeoutQueue(searchJobId);

			scSearchJobInfo = searchJobInfoMap.remove(searchJobId);
			if (scSearchJobInfo == null) {
				if (logger.isDebugEnabled())
					logger.debug(
							"In processSearchResponses: Cannot find scSearchJobInfo while completing for searchJobId:"
									+ searchJobId + ". do nothing.");
				return;
			}

			releaseFunctionSlot(scSearchJobInfo);

			// ScToSnClientHelper.searchJobIdSnSegmentJobInfoListMap.remove(searchJobId);

			pendingSearchJobQueueMap.getValue(scSearchJobInfo.capacityGroupKey).remove(scSearchJobInfo.getJobEntry());

			scSearchJobInfo.releasePendingSegmentJobs(snPartitionedLoadMap);

			SearchJobResultDto searchJobResultDto = scSearchJobInfo.scSearchResultInfo.getConsolidatedSearchResult(
					scSearchJobInfo, bioMatcherConfigService.getSegmentIdBinIdMap(),
					bioMatcherConfigService.getBinIdMaxEventCountMap());
			searchJobResultDto.getCandidateResultList().parallelStream().forEach(candidate -> {
				//candidate.setScore(candidate.getScore() * wight);
				//ToDo
				
			});
			boolean hasErrorList = searchJobResultDto.hasErrorList();

			logger.info("Search job completed for searchJobId: " + searchJobId + ", searchFunctionId: "
					+ scSearchJobInfo.getDefaultSearchFunctionId() + ", capacityGroupKey: "
					+ scSearchJobInfo.getCapacityGroupKey() + ", hitCandidateCount: "
					+ searchJobResultDto.getHitCandidateCount() + ", assignedSegmentJobCount: "
					+ scSearchJobInfo.totalAssignedSegmentJobCount.get() + ", batchedSegmentJobCount: "
					+ scSearchJobInfo.totalBatchedSegmentJobCount.get() + ", searchResponseCount: "
					+ scSearchJobInfo.getTotalSearchResponseCount() + ", jobRescheduledCount: "
					+ scSearchJobInfo.getJobRescheduledCount() + ", assignmentDelayMilli: "
					+ scSearchJobInfo.getAssignmentDelayMilli() + ", TotalTimeTakenMilli: "
					+ scSearchJobInfo.getDelayFromCreateDateTime() + (hasErrorList ? ", hasErrorList: true" : ""));

			if (!hasErrorList && scSearchJobInfo.isIncludeExtractionResultFlag()
					&& scSearchJobInfo.getExtractionJobId() != null) {
				try {
					ExtractJobResultDto extractJobResult = bioExtractionJobService
							.getExtractionJobResult(scSearchJobInfo.getExtractionJobId());
					searchJobResultDto.setExtractJobResult(extractJobResult);
				} catch (Throwable th) {
					logger.error(
							"Error in processSearchResponses while including the extraction job result for searchJobId: "
									+ searchJobId + ", extractionJobId: " + scSearchJobInfo.getExtractionJobId() + " : "
									+ th.getMessage(),
							th);
				}
			}

			long totalTimeTakenMilli = scSearchJobInfo.getDelayFromCreateDateTime();
			long searchTimeTakenMilli = scSearchJobInfo.getSearchTimeTakenMilli();

			BioMatcherJobResultPayload bioMatcherJobResultPayload = new BioMatcherJobResultPayload();
			bioMatcherJobResultPayload.setBioMatcherJobResult(searchJobResultDto);
			bioMatcherJobResultPayload.setCallbackUrl(scSearchJobInfo.getCallbackUrl());

			SearchJobPayloadCache.cacheSearchJobResultPayload(searchJobId, bioMatcherJobResultPayload);

			lobImageService.createLob(searchJobId, HessianSerializer.marshal(bioMatcherJobResultPayload), "res");

			if (StringUtils.isNotBlank(scSearchJobInfo.getCallbackUrl())) {
				if (notifySearchCallabckInWorkerThreadFlag) {
					notifySearchJobCompleted(searchJobId, scSearchJobInfo.getCallbackUrl(), searchJobResultDto);
				} else {
					if (CallbackService.isBatchCallbackUrl(scSearchJobInfo.getCallbackUrl())) {
						notifySearchJobCompleted(searchJobId, scSearchJobInfo.getCallbackUrl(), null);
					} else {
						InMemoryManager.submitForSearchCallback(searchJobId, scSearchJobInfo.getCallbackUrl());
					}
				}
			}

			SearchJobPayloadCache.clearSearchJobRequestPayloadCache(searchJobId);

			if (scSearchJobInfo.getExtractionJobId() != null) {
				completedExtractionJobIdQueue.add(scSearchJobInfo.getExtractionJobId());
			}

			MetricsUtil.time("FUNCTION." + scSearchJobInfo.getDefaultSearchFunctionId() + ".JOB_TIME_TAKEN",
					totalTimeTakenMilli, TimeUnit.MILLISECONDS);
			MetricsUtil.checkAndTime("FUNCTION." + scSearchJobInfo.getDefaultSearchFunctionId() + ".ASSIGN_TIME_TAKEN",
					scSearchJobInfo.getAssignmentDelayMilli(), TimeUnit.MILLISECONDS);

			MetricsUtil.time(BioComponentType.SC, searchControllerId, "SEARCH_JOB_TIME_TAKEN", totalTimeTakenMilli,
					TimeUnit.MILLISECONDS);

			MetricsUtil.time(BioComponentType.SC, searchControllerId,
					"SEARCH_FUNCTION_" + scSearchJobInfo.getDefaultSearchFunctionId(),
					searchTimeTakenMilli > 0 ? searchTimeTakenMilli : totalTimeTakenMilli, TimeUnit.MILLISECONDS);

			MetricsUtil.checkAndTime(BioComponentType.SC, searchControllerId, "SEARCH_ASSIGNMENT_TIME_TAKEN",
					scSearchJobInfo.getAssignmentDelayMilli(), TimeUnit.MILLISECONDS);

			if (isTimeout) {
				MetricsUtil.meter(BioComponentType.SC, searchControllerId, "SEARCH_TIMEOUT_ERROR");
			} else if (scSearchJobInfo.isSearchExtractErrorFlag()) {
				MetricsUtil.meter(BioComponentType.SC, searchControllerId, "SEARCH_EXTRACT_ERROR");
			} else if (searchJobResultDto.hasErrorList()) {
				logger.warn("Search job completed with error for scSearchJobInfo: " + scSearchJobInfo);
				MetricsUtil.meter(BioComponentType.SC, searchControllerId, "SEARCH_OTHER_ERROR");
			}
		} catch (Throwable th) {
			logger.error("Error in processSearchResponse: searchJobId: " + searchJobId + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (logger.isTraceEnabled() || timeTakenMilli > 50) {
				logger.info("In processSearchResponse: TimeTakenMilli: " + timeTakenMilli + " for searchJobId: "
						+ searchJobId);
			}
		}

	}

	/**
	 * Gets the search job status.
	 *
	 * @param searchJobId
	 *            the search job id
	 * @return the search job status
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public BioJobStatus getSearchJobStatus(String searchJobId) throws LobImageServiceException {
		logger.debug("In getSearchJobStatus: searchJobId: " + searchJobId);

		ScSearchJobInfo scSearchJobInfo = searchJobInfoMap.get(searchJobId);
		if (scSearchJobInfo != null && !scSearchJobInfo.isJobCompleted()) {
			return BioJobStatus.PENDING;
		}

		if (lobImageService.checkLobExists(searchJobId, "res")) {
			return BioJobStatus.COMPLETED;
		} else if (lobImageService.checkLobExists(searchJobId, "req")) {
			return BioJobStatus.PENDING;
		} else {
			return BioJobStatus.NOT_FOUND;
		}
	}

	/**
	 * Gets the search job result.
	 *
	 * @param searchJobId
	 *            the search job id
	 * @return the search job request
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 * @throws LobImageNotFoundException
	 *             the lob image not found exception
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public SearchJobResultDto getSearchJobResult(String searchJobId)
			throws LobImageServiceException, LobImageNotFoundException, SerializationException {
		logger.debug("In getSearchJobResult: searchJobId: " + searchJobId);

		ScSearchJobInfo scSearchJobInfo = searchJobInfoMap.get(searchJobId);
		if (scSearchJobInfo != null && !scSearchJobInfo.isJobCompleted()) {
			return new SearchJobResultDto(searchJobId, BioJobStatus.PENDING);
		}

		try {
			BiKey<BioMatcherJobResultPayload, Throwable> result = SearchJobPayloadCache
					.getSearchJobResultPayload(searchJobId);

			if (result.getB() != null) {
				throw result.getB();
			}

			BioMatcherJobResultPayload bioMatcherJobResultPayload = result.getA();
			return (SearchJobResultDto) bioMatcherJobResultPayload.getBioMatcherJobResult();
		} catch (Throwable th) {
			logger.error(th.getClass().getSimpleName() + " in getSearchJobResult: searchJobId: " + searchJobId + " : "
					+ th.getMessage(), th);
		}

		if (lobImageService.checkLobExists(searchJobId, "req")) {
			return new SearchJobResultDto(searchJobId, BioJobStatus.PENDING);
		} else {
			return new SearchJobResultDto(searchJobId, BioJobStatus.NOT_FOUND);
		}
	}

	/**
	 * Delete search job.
	 *
	 * @param searchJobId
	 *            the search job id
	 * @throws LobImageServiceException 
	 * @throws BioMatcherConfigServiceException 
	 */
	public void deleteSearchJob(String searchJobId) throws LobImageServiceException, BioMatcherConfigServiceException {
		logger.info("In deleteSearchJob: searchJobId: " + searchJobId);
		List<BioServerInfo> bioServerInfoList = bioMatcherConfigService.getServerInfoListByComponentType(BioComponentType.SC);
		if (bioServerInfoList.size() < 1) {
			logger.info("No active SC. return");
		}
		StringBuilder sb = new StringBuilder();
		for (BioServerInfo info : bioServerInfoList) {			
			sb.append(info.getServerId());
			sb.append(",");
		}
		sb.deleteCharAt(sb.length() -1);	
		String notifyMsg = sb.toString() + ":" + searchJobId; 
		logger.info("Notify message:" + " to sc:" + notifyMsg);
		bioSearchControllerManager.notifySearchJobCanceling(notifyMsg);
	}

	/**
	 * Notify search job completed.
	 *
	 * @param jobId
	 *            the job id
	 */
	private void notifySearchJobCompleted(String searchJobId, String callbackUrl) {
		logger.debug("In notifySearchJobCompleted: searchJobId: " + searchJobId + ", callbackUrl: " + callbackUrl);
		try {
			if (CallbackService.isBatchCallbackUrl(callbackUrl)) {
				notifySearchJobCompleted(searchJobId, callbackUrl, null);
			} else {
				BiKey<BioMatcherJobResultPayload, Throwable> result = SearchJobPayloadCache
						.getSearchJobResultPayload(searchJobId);
				if (result.getB() != null) {
					throw result.getB();
				}

				BioMatcherJobResultPayload bioMatcherJobResultPayload = result.getA();

				notifySearchJobCompleted(searchJobId, bioMatcherJobResultPayload.getCallbackUrl(),
						(SearchJobResultDto) bioMatcherJobResultPayload.getBioMatcherJobResult());
			}
		} catch (Throwable th) {
			logger.error(
					"Error during notifySearchJobCompleted for searchJobId: " + searchJobId + " : " + th.getMessage(),
					th);
		}
	}

	private void notifySyncJobCompleted(String jobId, String callbackUrl) {
		try {
			if (CallbackService.isBatchCallbackUrl(callbackUrl)) {
				notifySyncJobCompleted(jobId, callbackUrl, null);
			} else {
				byte[] lobData = lobImageService.getLobData(jobId, "res");

				BioMatcherJobResultPayload bioMatcherJobResultPayload = HessianSerializer.unmarshal(lobData);

				notifySyncJobCompleted(jobId, bioMatcherJobResultPayload.getCallbackUrl(),
						(SyncJobResultDto) bioMatcherJobResultPayload.getBioMatcherJobResult());
			}
		} catch (Throwable th) {
			logger.error("Error during notifySyncJobCompleted for jobId: " + jobId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Notify search job completed.
	 *
	 * @param searchJobId
	 *            the search job id
	 * @param callbackUrl
	 *            the callback url
	 * @param jobResultDto
	 *            the job result dto
	 */
	private void notifySearchJobCompleted(String searchJobId, String callbackUrl, SearchJobResultDto jobResultDto) {
		logger.info("In notifySearchJobCompleted: searchJobId: " + searchJobId + ", callbackUrl: " + callbackUrl);
		if (StringUtils.isBlank(callbackUrl)) {
			return;
		}
		try {
			if (jobResultDto != null && jobResultDto.getJobId() == null) {
				jobResultDto.setJobId(searchJobId);
			}

			if (callbackUrl.startsWith("http")) {
				httpCallbackService.postCallback(callbackUrl,
						jobResultDto == null ? null : searchJaxbXmlConvertor.marshal(jobResultDto));
			} else {
				zmqCallbackService.postCallback(callbackUrl,
						jobResultDto == null ? null : searchJaxbXmlConvertor.marshal(jobResultDto));
			}
		} catch (Throwable th) {
			th = new BioSearchContollerException("Error during callback for searchJobId: " + searchJobId + ", callbackUrl: "
					+ callbackUrl + " : " + th.getMessage(), th);
			createErrorLob(searchJobId, "cerror", th);
		} finally {
			logger.debug("After calling callback for searchJobId: " + searchJobId);
		}
	}

	/**
	 * Notify search job timeout.
	 *
	 * @param searchJobId
	 *            the search job id
	 */
	private void notifySearchJobTimeout(String searchJobId) {
		ScSearchJobInfo scSearchJobInfo = searchJobInfoMap.get(searchJobId);
		if (scSearchJobInfo == null) {
			// Already job is completed
			return;
		}

		if (!scSearchJobInfo.stagingSearchResponseQueue.isEmpty()) {
			processSearchResponses(searchJobId, scSearchJobInfo.stagingSearchResponseQueue);

			if (scSearchJobInfo.isJobCompleted()) {
				return;
			}
		}

		scSearchJobInfo.setTimeoutErrorFlag(true);

		String timeoutErrorMessage = "Error search timeout for searchJobId: " + searchJobId + " after delayMilli: "
				+ scSearchJobInfo.getDelayFromCreateDateTime();

		SearchResponse searchResponse = SearchProtobufUtil.buildErrorSearchResponse(searchJobId, searchControllerId,
				SearchConstants.ERROR_CODE_SEARCH_JOB_TIMEOUT, timeoutErrorMessage, null);

		ConcurrentLinkedQueue<SearchResponse> searchResponseQueue = new ConcurrentLinkedQueue<>();
		searchResponseQueue.add(searchResponse);

		processSearchResponses(searchJobId, searchResponseQueue);
	}

	private final void executeSyncJob(String syncJobId) {
		NDC.clear();
		NDC.push(syncJobId);

		List<BiometricEventSyncTypeDto> successfulEventSyncTypeDtoList = new ArrayList<>();

		logger.debug("In executeSyncJob");
		PFLogger.start();		
		try {
			ScSyncJobInfo scSyncJobInfo = syncJobInfoMap.get(syncJobId);
			if (scSyncJobInfo == null) {
				logger.warn("In executeSyncJob: Cannot find scSyncJobInfo for syncJobId: " + syncJobId);
				return;
			}

			scSyncJobInfo.setSyncStartDateTimeMilli(System.currentTimeMillis());

			if (CollectionUtils.isEmpty(scSyncJobInfo.getEventSyncTypeDtoList())) {
				throw new Exception("EventSyncTypeDtoList is empty in ScSyncJobInfo for syncJobId: " + syncJobId);
			}

			String localSiteId = bioParameterService.getParameterValue("LOCAL_SITE_ID", "DEFAULT", "DEFAULT");

			List<BiometricEventInfo> modifiedBiometricEventInfoList = new ArrayList<>();

			for (BiometricEventSyncTypeDto biometricEventSyncTypeDto : scSyncJobInfo.getEventSyncTypeDtoList()) {
				List<BiometricEventInfo> biometricEventInfoList = null;
				if (biometricEventSyncTypeDto instanceof InsertBiometricEventDto) {
					InsertBiometricEventDto insertBiometricEventDto = (InsertBiometricEventDto) biometricEventSyncTypeDto;
					biometricEventInfoList = biometricEventService.insertEvent(insertBiometricEventDto, localSiteId);

					insertBiometricEventDto.setExtractInputPayloadDto(null);
					insertBiometricEventDto.setInsertTemplateInfoList(null);

					successfulEventSyncTypeDtoList.add(insertBiometricEventDto);
				} else if (biometricEventSyncTypeDto instanceof DeleteBiometricEventDto) {
					DeleteBiometricEventDto deleteBiometricEventDto = (DeleteBiometricEventDto) biometricEventSyncTypeDto;
					biometricEventInfoList = biometricEventService.deleteEvent(deleteBiometricEventDto, localSiteId);

					successfulEventSyncTypeDtoList.add(biometricEventSyncTypeDto);
				} else if (biometricEventSyncTypeDto instanceof UpdateBiometricEventUserFlagDto) {
					UpdateBiometricEventUserFlagDto updateBiometricEventUserFlagDto = (UpdateBiometricEventUserFlagDto) biometricEventSyncTypeDto;
					biometricEventInfoList = biometricEventService.updateUserFlag(updateBiometricEventUserFlagDto,
							localSiteId);

					successfulEventSyncTypeDtoList.add(biometricEventSyncTypeDto);
				}

				if (biometricEventInfoList != null) {
					modifiedBiometricEventInfoList.addAll(biometricEventInfoList);				
				}
			}
			
			checkSyncJobStrictMode(syncJobId, scSyncJobInfo.getJobMode(), scSyncJobInfo.getCallbackUrl(),
					modifiedBiometricEventInfoList);

			bioSearchControllerManager.getBiometricEventVersionAssignmentTask()
					.notifyEventChangesForVersioning(modifiedBiometricEventInfoList.stream()
							.map(BiometricEventInfo::getAssignedSegmentId).collect(Collectors.toSet()));

			// Clear payload from memory
			scSyncJobInfo.setEventSyncTypeDtoList(null);
			scSyncJobInfo.setExtractionJobInsertEventMap(null);

			SyncJobResultDto syncJobResultDto = new SyncJobResultDto();
			syncJobResultDto.setJobId(syncJobId);
			syncJobResultDto.setStatus(BioJobStatus.COMPLETED);
			syncJobResultDto.setSuccessfulEventSyncTypeDtoList(successfulEventSyncTypeDtoList);

			notifySyncResults(syncJobId, syncJobResultDto);

		} catch (Throwable th) {
			logger.error("Error in executeSyncJob for syncJobId: " + syncJobId + " : " + th.getMessage(), th);

			SyncJobResultDto syncJobResultDto = buildErrorSyncJobResultDto(syncJobId,
					SearchConstants.ERROR_CODE_SYNC_EXECUTION, new BioSearchContollerException(
							"Error during executeSyncJob : syncJobId: " + syncJobId + " : " + th.getMessage(), th));
			syncJobResultDto.setSuccessfulEventSyncTypeDtoList(successfulEventSyncTypeDtoList);
			try {
				notifySyncResults(syncJobId, syncJobResultDto);
			} catch (Throwable th1) {
				logger.error("Error during notifySyncResults from executeSyncJob for syncJobId: " + syncJobId + " : "
						+ th1.getMessage(), th1);
			}
		} finally {
			PFLogger.end();

			NDC.pop();
		}
	}

	/**
	 * 
	 * @param jobId
	 * @param strictMode
	 * @param callbackUrl
	 * @param updatedBiometricEventInfoList
	 */
	private void checkSyncJobStrictMode(String jobId, String jobMode, String callbackUrl,
			List<BiometricEventInfo> updatedBiometricEventInfoList) {
		long maxSyncSegCompleteTimeoutMs = bioParameterService.getParameterValue(
				"MAX_SYNC_SEGMENTS_COMPLETED_TIMEOUT_MILLI", "DEFAULT", TimeUnit.SECONDS.toMillis(6));
		logger.info("Check strict mode for syncjob:" + jobId + ". jobMode=" + jobMode);
		if (jobMode != null && jobMode.toUpperCase().equals(STRICT_JOB_MODE)) {
			strictSegmentSyncCallbackService.registerStrictSyncCallbackData(jobId, callbackUrl,
					updatedBiometricEventInfoList);
			InMemoryManager.registerStrictSyncSegCallbackTimeout(jobId, maxSyncSegCompleteTimeoutMs);
		}
	}

	public void syncRemoteBiometricEvents(String sourceSiteId, String targetSiteId,
			List<BiometricEventSyncTypeDto> biometricEventSyncList) throws BioSearchContollerException {
		logger.debug("In syncRemoteBiometricEvents: sourceSiteId: " + sourceSiteId + ", targetSiteId: " + targetSiteId
				+ ", biometricEventSyncListSize: " + biometricEventSyncList.size());

		PFLogger.start();
		try {
			String localSiteId = bioParameterService.getParameterValue("LOCAL_SITE_ID", "DEFAULT", "DEFAULT");
			if (!StringUtils.equals(localSiteId, targetSiteId)) {
				throw new Exception("localSiteId: " + localSiteId + " does not match targetSiteId: " + targetSiteId);
			}

			List<BiometricEventInfo> modifiedBiometricEventInfoList = new ArrayList<>();

			for (BiometricEventSyncTypeDto biometricEventSyncTypeDto : biometricEventSyncList) {
				NDC.clear();

				List<BiometricEventInfo> biometricEventInfoList = null;
				if (biometricEventSyncTypeDto instanceof InsertBiometricEventDto) {
					InsertBiometricEventDto insertBiometricEventDto = (InsertBiometricEventDto) biometricEventSyncTypeDto;
					biometricEventInfoList = biometricEventService.insertEvent(insertBiometricEventDto, sourceSiteId);
				} else {
					DeleteBiometricEventDto deleteBiometricEventDto = (DeleteBiometricEventDto) biometricEventSyncTypeDto;
					biometricEventInfoList = biometricEventService.deleteEvent(deleteBiometricEventDto, sourceSiteId);
				}

				if (biometricEventInfoList != null) {
					modifiedBiometricEventInfoList.addAll(biometricEventInfoList);
				}
			}

			bioSearchControllerManager.getBiometricEventVersionAssignmentTask()
					.notifyEventChangesForVersioning(modifiedBiometricEventInfoList.stream()
							.map(BiometricEventInfo::getAssignedSegmentId).collect(Collectors.toSet()));

		} catch (Throwable th) {
			throw new BioSearchContollerException("Error in syncRemoteBiometricEvents for sourceSiteId: " + sourceSiteId
					+ ", targetSiteId: " + targetSiteId + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end();
		}
	}

	public void notifySyncJobExtractionCompleted(String syncJobId, ExtractJobResultDto extractionResult)
			throws BioSearchContollerException {
		if (searchControllerId == null) {
			throw new BioSearchContollerException("Search controller is not configured for this server");
		}

		ScSyncJobInfo scSyncJobInfo = null;
		SyncJobResultDto errorSyncJobResultDto = null;
		try {
			if (!pendingExtractSyncJobIdSet.contains(syncJobId)) {
				logger.warn(
						"In notifySyncJobExtractionCompleted: Cannot find syncJobId in pendingExtractSyncJobIdSet for syncJobId: "
								+ syncJobId);
				return;
			}

			scSyncJobInfo = syncJobInfoMap.get(syncJobId);
			if (scSyncJobInfo == null) {
				logger.warn(
						"In notifySyncJobExtractionCompleted: Cannot find scSyncJobInfo for syncJobId: " + syncJobId);
				return;
			}

			scSyncJobInfo.setExtractionCompletedDateTimeMilli(System.currentTimeMillis());

			if (scSyncJobInfo.hasExtractionError()) {
				logger.warn("In notifySyncJobExtractionCompleted: Sync job already had extraction error for syncJobId: "
						+ syncJobId);
				return;

			}

			if (extractionResult.hasErrorList()) {
				errorSyncJobResultDto = new SyncJobResultDto();
				errorSyncJobResultDto.setJobId(syncJobId);
				errorSyncJobResultDto.setStatus(BioJobStatus.COMPLETED);
				errorSyncJobResultDto.setErrorList(extractionResult.getErrorList());
				logger.warn("In notifySyncJobExtractionCompleted: Extraction returned error list for syncJobId: "
						+ syncJobId + ", extractionJobId: " + extractionResult.getJobId());
				return;
			}

			errorSyncJobResultDto = scSyncJobInfo.addExtractionResult(extractionResult, pendingSyncJobQueue,
					bioMatcherConfigService);
			if (errorSyncJobResultDto != null) {
				return;
			}

			if (scSyncJobInfo.hasPendingExtractionJobs()) {
				return;
			}

			// Since extraction is successful for sync, Its better to cancel the
			// timeout task and proceed with insertion as there is no external
			// dependency,
			InMemoryManager.removeFromTimeoutQueue(syncJobId);

		} catch (Throwable th) {
			logger.error("Error during notifySyncJobExtractionCompleted for syncJobId: " + syncJobId + " : "
					+ th.getMessage(), th);

			errorSyncJobResultDto = buildErrorSyncJobResultDto(syncJobId, SearchConstants.ERROR_CODE_SYNC_EXTRACTION,
					new BioSearchContollerException("Error during notifySyncJobExtractionCompleted : syncJobId: "
							+ syncJobId + " : " + th.getMessage(), th));
		} finally {
			if (errorSyncJobResultDto != null) {
				try {
					if (scSyncJobInfo != null) {
						scSyncJobInfo.setSyncExtractErrorFlag(true);
					}
					pendingExtractSyncJobIdSet.remove(syncJobId);
					notifySyncResults(syncJobId, errorSyncJobResultDto);
				} catch (Throwable th) {
					logger.error("Error during notifySyncResults from notifySyncJobExtractionCompleted for syncJobId: "
							+ syncJobId + " : " + th.getMessage(), th);
				}
			}
		}
	}

	private void notifySyncResults(String syncJobId, SyncJobResultDto jobResultDto) throws BioSearchContollerException {
		logger.debug("In notifySyncResults for syncJobId: " + syncJobId);
		try {
			ScSyncJobInfo scSyncJobInfo = syncJobInfoMap.get(syncJobId);
			if (scSyncJobInfo == null) {
				logger.warn("In notifySyncResults: Cannot find scSyncJobInfo for syncJobId: " + syncJobId);
				return;
			}

			releaseFunctionSlot(scSyncJobInfo);

			boolean isTimeout = scSyncJobInfo.isTimeoutErrorFlag();

			if (scSyncJobInfo.getJobMode() != null
					&& !scSyncJobInfo.getJobMode().toUpperCase().equals(STRICT_JOB_MODE)) {
				InMemoryManager.removeFromTimeoutQueue(syncJobId);
			}	

			logger.debug("Sync job completed for scSyncJobInfo: " + scSyncJobInfo);

			MetricsUtil.time(BioComponentType.SC, searchControllerId, "SYNC_JOB_TIME_TAKEN",
					scSyncJobInfo.getDelayFromCreateDateTime(), TimeUnit.MILLISECONDS);

			MetricsUtil.checkAndTime(BioComponentType.SC, searchControllerId, "SYNC_ONLY_TIME_TAKEN",
					scSyncJobInfo.getSyncTimeTakenMilli(), TimeUnit.MILLISECONDS);

			MetricsUtil.checkAndTime(BioComponentType.SC, searchControllerId, "SYNC_EXTRACT_JOB_TIME_TAKEN",
					scSyncJobInfo.getExtractTimeTakenMilli(), TimeUnit.MILLISECONDS);

			if (scSyncJobInfo.getTemplateVerifyTimeTakenMilli() > 0) {
				MetricsUtil.checkAndTime(BioComponentType.SC, searchControllerId, "TEMPLATE_VERIFY_TIME_TAKEN",
						scSyncJobInfo.getTemplateVerifyTimeTakenMilli(), TimeUnit.MILLISECONDS);
			}

			if (isTimeout) {
				MetricsUtil.meter(BioComponentType.SC, searchControllerId, "SYNC_TIMEOUT_ERROR");
			} else if (scSyncJobInfo.isSyncExtractErrorFlag()) {
				MetricsUtil.meter(BioComponentType.SC, searchControllerId, "SYNC_EXTRACT_ERROR");
			} else if (jobResultDto.hasErrorList()) {
				MetricsUtil.meter(BioComponentType.SC, searchControllerId, "SYNC_OTHER_ERROR");
			}

			BioMatcherJobResultPayload bioMatcherJobResultPayload = new BioMatcherJobResultPayload();
			bioMatcherJobResultPayload.setBioMatcherJobResult(jobResultDto);
			bioMatcherJobResultPayload.setCallbackUrl(scSyncJobInfo.getCallbackUrl());

			lobImageService.createLob(syncJobId, HessianSerializer.marshal(bioMatcherJobResultPayload), "res");
			scSyncJobInfo.setJobCompletedFlag(true);
			if (scSyncJobInfo.getJobMode() != null
					&& !scSyncJobInfo.getJobMode().toUpperCase().equals(STRICT_JOB_MODE)) {
				if (StringUtils.isNotBlank(scSyncJobInfo.getCallbackUrl())) {
					if (notifySyncCallabckInWorkerThreadFlag) {
						notifySyncJobCompleted(syncJobId, scSyncJobInfo.getCallbackUrl(), jobResultDto);
					} else {
						InMemoryManager.submitForEnrollCallback(syncJobId, scSyncJobInfo.getCallbackUrl());
					}
				}
			}

			if (CollectionUtils.isNotEmpty(scSyncJobInfo.getExtractionJobIdList())) {
				completedExtractionJobIdQueue.addAll(scSyncJobInfo.getExtractionJobIdList());
			}

		} catch (Throwable th) {
			throw new BioSearchContollerException(
					"Error in notifySyncResults for syncJobId: " + syncJobId + " : " + th.getMessage(), th);
		}
	}

	private void notifySyncJobCompleted(String syncJobId, String callbackUrl, SyncJobResultDto jobResultDto) {
		if (StringUtils.isBlank(callbackUrl)) {
			return;
		}

		ScSyncJobInfo scSyncJobInfo = syncJobInfoMap.get(syncJobId);
		if (scSyncJobInfo == null) return;
		if (scSyncJobInfo.getJobMode() != null && scSyncJobInfo.getJobMode().toUpperCase().equals(STRICT_JOB_MODE)) {
			return;
		}

		try {
			if (jobResultDto != null && jobResultDto.getJobId() == null) {
				jobResultDto.setJobId(syncJobId);
			}
			if (callbackUrl.startsWith("http")) {
				httpCallbackService.postCallback(callbackUrl,
						jobResultDto == null ? null : searchJaxbXmlConvertor.marshal(jobResultDto));
			} else {
				zmqCallbackService.postCallback(callbackUrl,
						jobResultDto == null ? null : searchJaxbXmlConvertor.marshal(jobResultDto));
			}	
			       		
		} catch (Throwable th) {
			th = new BioExtractionException("Error during callback for syncJobId: " + syncJobId + ", callbackUrl: "
					+ callbackUrl + " : " + th.getMessage(), th);
			createErrorLob(syncJobId, "cerror", th);
		} finally {
			logger.debug("After calling callback for syncJobId: " + syncJobId);			
		}
	}

	private void notifySyncJobTimeout(String syncJobId) {
		ScSyncJobInfo scSyncJobInfo = syncJobInfoMap.get(syncJobId);
		if (scSyncJobInfo == null) {
			// Already job is completed
			return;
		}

		scSyncJobInfo.setTimeoutErrorFlag(true);

		String timeoutErrorMessage = "Error sync timeout for syncJobId: " + syncJobId + " after delayMilli: "
				+ scSyncJobInfo.getDelayFromCreateDateTime();

		SyncJobResultDto jobResultDto = new SyncJobResultDto();
		jobResultDto.setJobId(syncJobId);
		jobResultDto.setStatus(BioJobStatus.COMPLETED);
		jobResultDto.getErrorList().add(new ErrorMessageDto(SearchConstants.ERROR_CODE_SYNC_JOB_TIMEOUT,
				timeoutErrorMessage, null, new Date()));

		try {
			notifySyncResults(syncJobId, jobResultDto);
		} catch (Throwable th) {
			logger.error("Error during notifySyncJobTimeout for syncJobId: " + syncJobId + " : " + th.getMessage(), th);
		}
	}

	public BioJobStatus getSyncJobStatus(String syncJobId) throws LobImageServiceException {
		ScSyncJobInfo scSyncJobInfo = syncJobInfoMap.get(syncJobId);
		if (scSyncJobInfo != null && !scSyncJobInfo.isJobCompletedFlag()) {
			return BioJobStatus.PENDING;
		}

		if (lobImageService.checkLobExists(syncJobId, "res")) {
			return BioJobStatus.COMPLETED;
		} else if (lobImageService.checkLobExists(syncJobId, "req")) {
			return BioJobStatus.PENDING;
		} else {
			return BioJobStatus.NOT_FOUND;
		}
	}

	public SyncJobResultDto getSyncJobResult(String syncJobId)
			throws LobImageServiceException, LobImageNotFoundException, SerializationException {
		ScSyncJobInfo scSyncJobInfo = syncJobInfoMap.get(syncJobId);
		if (scSyncJobInfo != null && !scSyncJobInfo.isJobCompletedFlag()) {
			return new SyncJobResultDto(syncJobId, BioJobStatus.PENDING);
		}

		try {
			byte lobData[] = lobImageService.getLobData(syncJobId, "res");

			if (lobData != null) {
				BioMatcherJobResultPayload bioMatcherJobResultPayload = HessianSerializer.unmarshal(lobData);
				return (SyncJobResultDto) bioMatcherJobResultPayload.getBioMatcherJobResult();
			}
		} catch (LobImageNotFoundException ex) {
		}

		if (lobImageService.checkLobExists(syncJobId, "req")) {
			return new SyncJobResultDto(syncJobId, BioJobStatus.PENDING);
		} else {
			return new SyncJobResultDto(syncJobId, BioJobStatus.NOT_FOUND);
		}
	}

	public void deleteSyncJob(String syncJobId) {
		try {
			InMemoryManager.removeFromTimeoutQueue(syncJobId);

			ScSyncJobInfo scSyncJobInfo = syncJobInfoMap.remove(syncJobId);

			releaseFunctionSlot(scSyncJobInfo);

			pendingSyncJobQueue.remove(syncJobId);

			lobImageService.deleteLobsByLobId(syncJobId);

			DelayedItem<String> delayItem = new DelayedItem<String>(syncJobId, 0);

			syncJobQueueHousekeepingQueue.remove(delayItem);
		} catch (Throwable th) {
			logger.error("Error deleting lob for syncJobId: " + syncJobId + " : " + th.getMessage(), th);
		}
	}

	private final SyncJobResultDto buildErrorSyncJobResultDto(String jobId, String errorCode, Throwable th) {
		SyncJobResultDto result = new SyncJobResultDto();
		result.setJobId(jobId);
		result.setStatus(BioJobStatus.COMPLETED);
		result.getErrorList()
				.add(new ErrorMessageDto(errorCode, th.getMessage(), null, new Date()));
		return result;
	}

	/**
	 * Creates the error lob.
	 *
	 * @param jobId
	 *            the job id
	 * @param lobType
	 *            the lob type
	 * @param th
	 *            the th
	 */
	private final void createErrorLob(String jobId, String lobType, Throwable th) {
		try {
			lobImageService.createLob(jobId, HessianSerializer.marshal(th), lobType);
		} catch (Throwable error) {
			logger.error("Error in createErrorLob while for jobId: " + jobId + " : " + error.getMessage(), error);
		}
	}

	public String getDefaultSearchFunctionId(int probeTemplateTypeCode, int galleryTemplateCode) {
		switch (probeTemplateTypeCode) {
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			return "FI";
		case 11:
		case 12:
		case 22:
			return "II";
		case 31:
		case 32:
		case 35:
		case 36:
			return "TI";
		case 33:
		case 41:
			return "TLI";
		case 42:
			return "TLI";
		case 43:
			return "TLI";
		case 44: {
			switch (galleryTemplateCode) {
			case 44:
				return "LLI";
			case 42:
			case 43:
				return "LI";
			default:
				return null;
			}
		}
		case 34: {
			switch (galleryTemplateCode) {
			case 34:
				return "LLI";
			case 33:
			case 41:
				return "LI";
			default:
				return null;
			}
		}
		case 37:
		case 38:
		case 39:
			return "TLIP";
		case 40: {
			switch (galleryTemplateCode) {
			case 40:
				return "LLIP";
			case 37:
			case 38:
			case 39:
				return "LIP";
			default:
				return null;
			}
		}
		case 45:			
		case 46: 
		case 47:
			return "TLIP";
			
		case 48:
			switch (galleryTemplateCode) {
			case 48:
				return "LLIP";
			case 45:
			case 46:
			case 47:
				return "LIP";
			default:
				return null;
			}
	
		default:
			return null;
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In afterPropertiesSet: " + initializationCount.get());

		synchronized (SearchJobQueueHelper.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			initializationCount.incrementAndGet();

			searchControllerId = bioSearchControllerManager.getSearchControllerId();

			if (searchControllerId == null) {
				return;
			}

			strictSegmentSyncCallbackService = SpringServiceManager.getBean("strictSegmentSyncCallbackService");

			matcherFunctionControlUtil = bioSearchControllerManager.getMatcherFunctionControlUtil();

			scSearchNodePartitionedLoadMap = bioSearchControllerManager.getScSearchNodePartitionedLoadMap();
			snPartitionedLoadMap = new ConcurrentValuedHashMap<>(key -> scSearchNodePartitionedLoadMap
					.getValue(new TriKey<>(searchControllerId, key.getA(), key.getB())));

			pendingExtractSyncJobIdSet = bioSearchControllerManager.getPendingExtractSyncJobIdSet();
			pendingSyncJobQueue = bioSearchControllerManager.getPendingSyncJobQueue();
			syncJobQueueHousekeepingQueue = bioSearchControllerManager.getSyncJobQueueHousekeepingQueue();
			syncJobInfoMap = bioSearchControllerManager.getSyncJobInfoMap();

			Supplier<Integer> syncWorkerConcurrencyCountSupplier = BioParameterService
					.getIntSupplier("SYNC_WORKER_THREAD_CONCURRENCY", "DEFAULT", 50);
			syncJobExecutor = new ConcurrentProducerConsumer<>("SC_SYNC_JOB_WORKER",
					() -> Uninterruptibles.takeUninterruptibly(pendingSyncJobQueue), (syncJobId) -> {
						executeSyncJob(syncJobId);
					}, syncWorkerConcurrencyCountSupplier);

			pendingExtractSearchJobIdSet = bioSearchControllerManager.getPendingExtractSearchJobIdSet();
			pendingSearchJobQueueMap = bioSearchControllerManager.getPendingSearchJobQueueMap();
			searchJobQueueHousekeepingQueue = bioSearchControllerManager.getSearchJobQueueHousekeepingQueue();
			searchJobInfoMap = bioSearchControllerManager.getSearchJobInfoMap();					

			bioParameterService.renameParameterIfExists("SEARCH_JOB_TEMPLATE_VERIFY_FLAG", "DEFAULT",
					"SEARCH_JOB_TEMPLATE_VALIDATOR_FLAG");
			bioParameterService.renameParameterIfExists("SYNC_JOB_TEMPLATE_VERIFY_FLAG", "DEFAULT",
					"SYNC_JOB_TEMPLATE_VALIDATOR_FLAG");

			boolean searchJobTemplateValidatorFlag = bioParameterService
					.getParameterValue("SEARCH_JOB_TEMPLATE_VALIDATOR_FLAG", "DEFAULT", true);
			boolean syncJobTemplateValidatorFlag = bioParameterService
					.getParameterValue("SYNC_JOB_TEMPLATE_VALIDATOR_FLAG", "DEFAULT", true);

			if (searchJobTemplateValidatorFlag || syncJobTemplateValidatorFlag) {
				if (StringUtils.isBlank(templateValidatorService.getTemplateValidatorControllerId())) {
					CommonLogger.STATUS_LOG
							.error("TemplateValidator controller is not configured on the search controller: "
									+ searchControllerId);
				}
			}
			CommonTaskScheduler.scheduleWithFixedDelay(new SearchJobHouseKeepingTask(), 1, 1, TimeUnit.MILLISECONDS);

			InMemoryManager.callbackListenerMap.put(BioTaskType.SEARCH, new CallbackListener() {
				@Override
				public void notifyCallback(String taskKey, String callbackUrl) {
					notifySearchJobCompleted(taskKey, callbackUrl);
				}
			});

			InMemoryManager.timeoutListenerMap.put(BioTaskType.SEARCH, new TaskTimeoutListener() {
				@Override
				public void notifyTaskTimeout(String jobId) {
					notifySearchJobTimeout(jobId);
				}
			});

			notifySearchCallabckInWorkerThreadFlag = bioParameterService
					.getParameterValue("NOTIFY_SEARCH_CALLBACK_IN_WORKER_THREAD_FLAG", "DEFAULT", false);

			if (!notifySearchCallabckInWorkerThreadFlag) {
				InMemoryManager.startCallbackExecutor();
			}
			CommonTaskScheduler.scheduleWithFixedDelay(new SyncJobHouseKeepingTask(), 100, 500, TimeUnit.MILLISECONDS);
			Runnable extractJobDeletionTask = () -> {
				Thread.currentThread().setName("SC_EX_JOB_HK_" + Thread.currentThread().getId());
				while (!ShutdownHook.isShutdownFlag) {
					String extractionJobId = null;
					try {
						extractionJobId = completedExtractionJobIdQueue.take();
						bioExtractionJobService.deleteExtractionJob(extractionJobId);
					} catch (Throwable th) {
						logger.error("Error deleting extractionJob: " + extractionJobId + " : " + th.getMessage(), th);
					}
				}
			};

			CommonTaskScheduler.scheduleWithFixedDelay(extractJobDeletionTask, 100, 20000, TimeUnit.MILLISECONDS);

			InMemoryManager.callbackListenerMap.put(BioTaskType.ENROLL, new CallbackListener() {
				@Override
				public void notifyCallback(String taskKey, String callbackUrl) {
					notifySyncJobCompleted(taskKey, callbackUrl);
				}
			});
			InMemoryManager.timeoutListenerMap.put(BioTaskType.ENROLL, new TaskTimeoutListener() {
				@Override
				public void notifyTaskTimeout(String jobId) {
					notifySyncJobTimeout(jobId);
				}
			});

			notifySyncCallabckInWorkerThreadFlag = bioParameterService
					.getParameterValue("NOTIFY_SYNC_CALLBACK_IN_WORKER_THREAD_FLAG", "DEFAULT", false);
			if (!notifySyncCallabckInWorkerThreadFlag) {
				InMemoryManager.startCallbackExecutor();
			}

			// Metrics
			// MetricsUtil.registerMetric(new
			// SearchControllerGuageSet(bioSearchControllerManager, this,
			// bioMatcherConfigService), "scDetails", searchControllerId);

			MetricsUtil.registerGauge(BioComponentType.SC, searchControllerId, "ACTIVE_SYNC_EXTRACT_JOB_COUNT", () -> {
				return pendingExtractSyncJobIdSet.size();
			});

			MetricsUtil.registerGauge(BioComponentType.SC, searchControllerId, "ACTIVE_SYNC_JOB_COUNT", () -> {
				return syncJobInfoMap.size();
			});

			MetricsUtil.registerGauge(BioComponentType.SC, searchControllerId, "ACTIVE_SEARCH_EXTRACT_JOB_COUNT",
					() -> {
						return pendingExtractSearchJobIdSet.size();
					});

			MetricsUtil.registerGauge(BioComponentType.SC, searchControllerId, "ACTIVE_SEARCH_JOB_COUNT", () -> {
				return searchJobInfoMap.size();
			});

		}
	}

	public void setBioSearchControllerManager(BioSearchControllerManager bioSearchControllerManager) {
		this.bioSearchControllerManager = bioSearchControllerManager;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioExtractionJobService(BioExtractionJobService bioExtractionJobService) {
		this.bioExtractionJobService = bioExtractionJobService;
	}

	public void setLobImageService(LobImageService lobImageService) {
		this.lobImageService = lobImageService;
	}

	public void setBioMatchManagerService(BioMatchManagerService bioMatchManagerService) {
		this.bioMatchManagerService = bioMatchManagerService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBiometricEventService(BiometricEventService biometricEventService) {
		this.biometricEventService = biometricEventService;
	}

	public ConcurrentValuedHashMap<String, PriorityBlockingQueue<JobEntry>> getPendingSearchJobQueueMap() {
		return pendingSearchJobQueueMap;
	}

	public DelayQueue<DelayedItem<String>> getSearchJobQueueHousekeepingQueue() {
		return searchJobQueueHousekeepingQueue;
	}

	public ConcurrentHashMap<String, ScSearchJobInfo> getSearchJobInfoMap() {
		return searchJobInfoMap;
	}

	public ConcurrentHashMap<String, ScSyncJobInfo> getSyncJobInfoMap() {
		return syncJobInfoMap;
	}

	public LinkedBlockingQueue<String> getPendingSyncJobQueue() {
		return pendingSyncJobQueue;
	}

	public DelayQueue<DelayedItem<String>> getSyncJobQueueHousekeepingQueue() {
		return syncJobQueueHousekeepingQueue;
	}

	public AtomicLong getSearchJobCounter() {
		return searchJobCounter;
	}

	public AtomicLong getSyncJobCounter() {
		return syncJobCounter;
	}

	public String getSearchControllerId() {
		return searchControllerId;
	}

	public void setSearchJobAssignmentBySearchNodeUtil(
			SearchJobAssignmentBySearchNodeUtil searchJobAssignmentBySearchNodeUtil) {
		this.searchJobAssignmentBySearchNodeUtil = searchJobAssignmentBySearchNodeUtil;
	}

	public void setHttpCallbackService(CallbackService httpCallbackService) {
		this.httpCallbackService = httpCallbackService;
	}

	public void setZmqCallbackService(CallbackService zmqCallbackService) {
		this.zmqCallbackService = zmqCallbackService;
	}

	public void setTemplateValidatorService(TemplateValidatorService templateValidatorService) {
		this.templateValidatorService = templateValidatorService;
	}

	public void setStrictSegmentSyncCallbackService(StrictSegmentSyncCallbackService strictService) {
		this.strictSegmentSyncCallbackService = strictService;
	}
	
	public void setLicenseManager(LicenseManager licenseManager) {
		this.licenseManager = licenseManager;
	}
}
