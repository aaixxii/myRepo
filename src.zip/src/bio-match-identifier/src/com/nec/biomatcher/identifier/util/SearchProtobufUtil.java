package com.nec.biomatcher.identifier.util;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.collect.Lists;
import com.google.common.primitives.UnsignedLong;
import com.google.protobuf.ByteString;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.exception.BioParameterServiceException;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.util.CommonProtobufUtil;
import com.nec.biomatcher.core.framework.cache.SpringCacheManager;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.GuavaCacheCleaner;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.spec.transfer.job.search.SearchItemInputPayloadDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchOptionsDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchRequestItemDto;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.BioParameterDto;
import com.nec.biomatcher.spec.transfer.model.BioParameterKeyEnum;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.MatchInputParameter;
import com.nec.biomatcher.spec.transfer.model.MetaInfoCommon;
import com.nec.biomatcher.spec.transfer.model.TemplateType;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.SnSegmentJobInfo;
import com.nec.megha.proto.common.CommonProto;
import com.nec.megha.proto.common.CommonProto.KeyValue;
import com.nec.megha.proto.common.CommonProto.KeyValueGroup;
import com.nec.megha.proto.common.CommonProto.KeyValueGroupHolder;
import com.nec.megha.proto.search.SearchRequestProto.SearchRequest;
import com.nec.megha.proto.search.SearchRequestProto.SegmentInfo;
import com.nec.megha.proto.search.SearchResponseProto.SearchResponse;

/**
 * The Class SearchProtobufUtil.
 */
public class SearchProtobufUtil {
	private static final Logger logger = Logger.getLogger(SearchProtobufUtil.class);

	private static BioMatcherConfigService bioMatcherConfigService;

	private static Cache<String, KeyValueGroupHolder> segJobRequestKeyValueGroupHolderCache;

	private static final KeyValueGroupHolder getCachedSegJobRequestKeyValueGroupHolder(String segJobRequestKey) {
		if (segJobRequestKeyValueGroupHolderCache == null) {
			initializeSegJobRequestKeyValueGroupHolderCache();
		}

		return segJobRequestKeyValueGroupHolderCache.getIfPresent(segJobRequestKey);
	}

	private static final KeyValueGroupHolder getSegJobRequestKeyValueGroupHolder(String segJobRequestKey,
			Callable<? extends KeyValueGroupHolder> valueLoader) throws ExecutionException {
		if (segJobRequestKeyValueGroupHolderCache == null) {
			initializeSegJobRequestKeyValueGroupHolderCache();
		}

		return segJobRequestKeyValueGroupHolderCache.get(segJobRequestKey, valueLoader);
	}

	private static final synchronized void initializeSegJobRequestKeyValueGroupHolderCache() {
		if (segJobRequestKeyValueGroupHolderCache == null) {
			logger.info("In initializeSegJobRequestKeyValueGroupHolderCache");

			int maxSearchJobRequestPayloadCacheCount = BioParameterService
					.getIntSupplier("MAX_SEARCH_JOB_REQUEST_PAYLOAD_CACHE_COUNT", "DEFAULT", 200).get();
			long searchJobRequestPayloadCacheExpiryMilli = BioParameterService.getLongSupplier(
					"SEARCH_JOB_REQUEST_PAYLOAD_CACHE_EXPIRY_MILLI", "DEFAULT", TimeUnit.SECONDS.toMillis(30)).get();

			segJobRequestKeyValueGroupHolderCache = CacheBuilder.newBuilder()
					.maximumSize(maxSearchJobRequestPayloadCacheCount).concurrencyLevel(200)
					.expireAfterAccess(searchJobRequestPayloadCacheExpiryMilli, TimeUnit.MILLISECONDS).build();
			SpringCacheManager.registerGuavaCache("segJobRequestKeyValueGroupHolderCache",
					segJobRequestKeyValueGroupHolderCache);

			boolean registerGuavaCacheCleanerFlag = BioParameterService
					.getBooleanSupplier("REGISTER_GUAVA_CACHE_CLEANER_FLAG", "DEFAULT", false).get();
			if (registerGuavaCacheCleanerFlag) {
				GuavaCacheCleaner.registerCache("SEG_JOB_REQUEST_KEY_VALUE_GROUP_HOLDER_CACHE",
						segJobRequestKeyValueGroupHolderCache);
			}

		}
	}

	/**
	 * To protobuf.
	 *
	 * @param jobId
	 *            the job id
	 * @param requestKey
	 *            the request key
	 * @param segmentIdVersionMap
	 *            the segment id version map
	 * @param request
	 *            the request
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the search request
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public static SearchRequest toProtobuf(String parentSearchJobId, SnSegmentJobInfo snSegmentJobInfoDto,
			String responseCallbackUrl, SearchJobRequestDto request, long jobTimeoutMilli,
			BioParameterService bioParameterService) throws Throwable {

		SearchRequestItemDto requestItem = request.getSearchRequestItemList().stream()
				.filter(searchRequestItemDto -> snSegmentJobInfoDto.getRequestKey()
						.equals(searchRequestItemDto.getRequestItemKey()))
				.findFirst().get();

		SearchItemInputPayloadDto searchItemInputPayloadDto = requestItem.getSearchItemPayloadDto();

		SearchRequest.Builder builder = SearchRequest.newBuilder();

		builder.setMsgId(snSegmentJobInfoDto.getSegmentJobId());
		int overCandidateFactor = bioParameterService.getParameterValue("OVER_CANDIDATE_FACTOR", "DEFAULT", 1);
		overCandidateFactor = overCandidateFactor < 1 ? 1: overCandidateFactor;
		int internalMaxCandidates = bioParameterService.getParameterValue("INTERNAL_SEARCH_RESULT_MAX_CANDIDATES","DEFAULT", 500);
		int clientMaxCandidates = searchItemInputPayloadDto.getMaxHitCount() == null || searchItemInputPayloadDto.getMaxHitCount() <= 0 ? 100 : searchItemInputPayloadDto.getMaxHitCount();
		int maxCandidatesToSn = Math.min(internalMaxCandidates, clientMaxCandidates * overCandidateFactor);			
		builder.setMaxCandidates(maxCandidatesToSn);
		
		builder.setProbe(ByteString.copyFrom(searchItemInputPayloadDto.getTemplateData()));
		builder.setResponseEndpoint(responseCallbackUrl);
		builder.setTimeoutMs(jobTimeoutMilli);

		if (StringUtils.isNotBlank(searchItemInputPayloadDto.getFunctionId())) {
			builder.setFunction(searchItemInputPayloadDto.getFunctionId());
		}

		List<MatchInputParameter> matchInputParameterList = request.hasMatchInputParameterList()
				? request.getMatchInputParameterList() : null;

		KeyValueGroupHolder keyValueGroupHolder = getKeyValueGroupHolder(parentSearchJobId,
				snSegmentJobInfoDto.getRequestKey(), searchItemInputPayloadDto, matchInputParameterList,
				bioParameterService);

		builder.setKvGroupHolder(keyValueGroupHolder);

		if (snSegmentJobInfoDto.getSegmentIdCount() > 0) {
			for (Integer segmentId : snSegmentJobInfoDto.getSegmentIdList()) {
				SegmentInfo.Builder segmentInfoBuilder = SegmentInfo.newBuilder();
				segmentInfoBuilder.setSegmentId(segmentId);
				segmentInfoBuilder.setVersion(-1L);

				builder.addSegInfo(segmentInfoBuilder.build());
			}
		}

		return builder.build();
	}

	private static KeyValueGroupHolder getKeyValueGroupHolder(String parentSearchJobId, String requestKey,
			SearchItemInputPayloadDto searchItemInputPayloadDto, List<MatchInputParameter> matchInputParameterList,
			BioParameterService bioParameterService) throws Throwable {
		String segJobRequestKey = parentSearchJobId + "|" + requestKey;

		KeyValueGroupHolder keyValueGroupHolder = getCachedSegJobRequestKeyValueGroupHolder(segJobRequestKey);
		if (keyValueGroupHolder != null) {
			return keyValueGroupHolder;
		}

		Callable<KeyValueGroupHolder> keyValueGroupHolderLoader = () -> {
			KeyValueGroupHolder.Builder keyValueGroupHolderBuilder = KeyValueGroupHolder.newBuilder();

			SearchOptionsDto searchOptions = searchItemInputPayloadDto.getSearchOptions() != null
					? searchItemInputPayloadDto.getSearchOptions() : null;
			MetaInfoCommon metaInfoCommon = searchOptions != null && searchOptions.getMetaInfoCommon() != null
					? searchOptions.getMetaInfoCommon() : null;
			Map<String, String> searchOptionsMap = buildSearchOptionsMap(metaInfoCommon,
					searchItemInputPayloadDto.getMinScoreThreshold(), bioParameterService);

			KeyValueGroup.Builder searchOptionsKeyValueGroupBuilder = KeyValueGroup.newBuilder();
			searchOptionsKeyValueGroupBuilder.setGroupName("SEARCH_OPTIONS");

			for (Entry<String, String> entry : searchOptionsMap.entrySet()) {
				KeyValue.Builder keyValueBuilder = KeyValue.newBuilder();
				keyValueBuilder.setKey(entry.getKey());
				keyValueBuilder.setValue(entry.getValue());
				searchOptionsKeyValueGroupBuilder.addKv(keyValueBuilder.build());
			}

			keyValueGroupHolderBuilder.addParamGroup(searchOptionsKeyValueGroupBuilder.build());

			BioMatcherConfigService bioMatcherConfigService = getBioMatcherConfigService();
			Set<AlgorithmType> algorithmTypeSet = new HashSet<>();

			TemplateType templateType = TemplateType.getByName(searchItemInputPayloadDto.getTemplateType());
			if (templateType != null) {
				algorithmTypeSet.addAll(bioMatcherConfigService.getTemplateTypeAlgorithmTypesMap()
						.getOrDefault(templateType, Collections.emptySet()));
			}

			Map<AlgorithmType, MatchInputParameter> algorithmTypeMatchInputParameterMap = new HashMap<>();

			if (matchInputParameterList != null) {
				for (MatchInputParameter matchInputParameter : matchInputParameterList) {
					algorithmTypeMatchInputParameterMap.put(matchInputParameter.getAlgorithmType(),
							matchInputParameter);
					algorithmTypeSet.add(matchInputParameter.getAlgorithmType());
				}
			}

			if (searchOptions != null && searchOptions.hasMatchInputParameterList()) {
				for (MatchInputParameter matchInputParameter : searchOptions.getMatchInputParameterList()) {
					algorithmTypeMatchInputParameterMap.put(matchInputParameter.getAlgorithmType(),
							matchInputParameter);
					algorithmTypeSet.add(matchInputParameter.getAlgorithmType());
				}
			}

			Map<String, Map<String, String>> kvGroupParameterMap = new HashMap<>();
			for (AlgorithmType algorithmType : algorithmTypeSet) {
				if (algorithmType == null) {
					continue;
				}

				Map<String, String> matchInputParameterMap = CommonProtobufUtil.buildMatchInputParameterMap(
						algorithmTypeMatchInputParameterMap.get(algorithmType), algorithmType, bioParameterService);

				String groupName = "MATCH_PARAM_" + algorithmType.name();

				if (kvGroupParameterMap.containsKey(groupName)) {
					kvGroupParameterMap.get(groupName).putAll(matchInputParameterMap);
				} else {
					kvGroupParameterMap.put(groupName, matchInputParameterMap);
				}
			}

			for (String groupName : kvGroupParameterMap.keySet()) {
				Map<String, String> matchInputParameterMap = kvGroupParameterMap.get(groupName);

				KeyValueGroup.Builder matchParamsKeyValueGroupBuilder = KeyValueGroup.newBuilder();
				matchParamsKeyValueGroupBuilder.setGroupName(groupName);

				for (Entry<String, String> entry : matchInputParameterMap.entrySet()) {
					KeyValue.Builder keyValueBuilder = KeyValue.newBuilder();
					keyValueBuilder.setKey(entry.getKey());
					keyValueBuilder.setValue(entry.getValue());
					matchParamsKeyValueGroupBuilder.addKv(keyValueBuilder.build());
				}

				keyValueGroupHolderBuilder.addParamGroup(matchParamsKeyValueGroupBuilder.build());
			}

			return keyValueGroupHolderBuilder.build();
		};

		try {
			return getSegJobRequestKeyValueGroupHolder(segJobRequestKey, keyValueGroupHolderLoader);
		} catch (ExecutionException ex) {
			Throwable th = ex.getCause();
			throw th != null ? th : ex;
		}

	}

	/**
	 * Builds the search options map.
	 *
	 * @param metaInfoCommon
	 *            the meta info common
	 * @param minScoreThreshold
	 *            the min score threshold
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the map
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public static Map<String, String> buildSearchOptionsMap(MetaInfoCommon metaInfoCommon, Integer minScoreThreshold,
			BioParameterService bioParameterService) throws BioParameterServiceException {

		Map<String, String> searchOptionsMap = new HashMap<>();

		if (minScoreThreshold != null) {
			searchOptionsMap.put(BioParameterKeyEnum.MATCH_THRESHOLD.name(), minScoreThreshold.toString());
		}

		if (metaInfoCommon != null) {
			if (StringUtils.isNotBlank(metaInfoCommon.getUserFlags())) {
				searchOptionsMap.put(BioParameterKeyEnum.USER_FLAG.name(), metaInfoCommon.getUserFlags());
			}

			if (metaInfoCommon.getRegionFlags() != null) {
				searchOptionsMap.put(BioParameterKeyEnum.REGION_FLAG.name(),
						UnsignedLong.fromLongBits(metaInfoCommon.getRegionFlags()).toString());
			}

			if (metaInfoCommon.getYob() != null && metaInfoCommon.getYob() >= 0) {
				searchOptionsMap.put(BioParameterKeyEnum.YOB.name(), metaInfoCommon.getYob().toString());
			}

			if (metaInfoCommon.getYobRange() != null && metaInfoCommon.getYobRange() >= 0) {
				searchOptionsMap.put(BioParameterKeyEnum.YOB_RANGE.name(), metaInfoCommon.getYobRange().toString());
			}

			if (metaInfoCommon.getGender() != null) {
				searchOptionsMap.put(BioParameterKeyEnum.GENDER.name(), metaInfoCommon.getGender().name());
			}

			if (metaInfoCommon.getRace() != null) {
				searchOptionsMap.put(BioParameterKeyEnum.RACE.name(), metaInfoCommon.getRace());
			}

			if (metaInfoCommon.getTargetQualityThreshold() != null && metaInfoCommon.getTargetQualityThreshold() >= 0) {
				searchOptionsMap.put(BioParameterKeyEnum.TARGET_QUALITY_THRESHOLD.name(),
						metaInfoCommon.getTargetQualityThreshold().toString());
			}

			if (metaInfoCommon.hasParameters()) {
				for (BioParameterDto bioParameterDto : metaInfoCommon.getParameters()) {
					if (StringUtils.isNotBlank(bioParameterDto.getKey())
							&& StringUtils.isNotBlank(bioParameterDto.getValue())) {
						searchOptionsMap.put(bioParameterDto.getKey(), bioParameterDto.getValue());
					}
				}
			}
		}

		Map<String, String> defaultParameters = bioParameterService.getPropertyMap("PROPERTIES_DEFAULT_SEARCH_OPTIONS",
				"DEFAULT");
		if (defaultParameters != null) {
			for (Entry<String, String> entry : defaultParameters.entrySet()) {
				if (!searchOptionsMap.containsKey(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())) {
					searchOptionsMap.put(entry.getKey(), entry.getValue());
				}
			}
		}

		Map<String, String> overwriteParameters = bioParameterService
				.getPropertyMap("PROPERTIES_OVERWRITE_SEARCH_OPTIONS", "DEFAULT");
		if (overwriteParameters != null) {
			for (Entry<String, String> entry : overwriteParameters.entrySet()) {
				if (StringUtils.isBlank(entry.getValue())) {
					searchOptionsMap.remove(entry.getKey());
				} else {
					searchOptionsMap.put(entry.getKey(), entry.getValue());
				}
			}
		}

		return searchOptionsMap;
	}

	public static final SearchResponse buildCompletedSearchResponse(String jobId) {

		CommonProto.Status.Builder statusBuilder = CommonProto.Status.newBuilder();
		statusBuilder.setSuccess(true);

		CommonProto.KeyValueGroupHolder.Builder keyValueGroupHolderBuilder = CommonProto.KeyValueGroupHolder
				.newBuilder();

		SearchResponse.Builder searchResponseBuilder = SearchResponse.newBuilder();
		searchResponseBuilder.setMsgId(jobId);
		searchResponseBuilder.setStatus(statusBuilder.build());
		searchResponseBuilder.setKvGroupHolder(keyValueGroupHolderBuilder.build());

		return searchResponseBuilder.build();
	}

	public static final SearchResponse buildErrorSearchResponse(String jobId, String errorSource, String errorCode,
			String errorMessage, String errorDetail) {
		ErrorMessageDto errorMessageDto = new ErrorMessageDto(errorCode, errorMessage, errorDetail, new Date());

		return buildErrorSearchResponse(jobId, errorSource, Lists.newArrayList(errorMessageDto));
	}

	public static final SearchResponse buildErrorSearchResponse(String jobId, String errorSource,
			Collection<ErrorMessageDto> errorMessageDtoList) {

		CommonProto.Status.Builder statusBuilder = CommonProto.Status.newBuilder();
		statusBuilder.setSuccess(false);

		for (ErrorMessageDto errorMessageDto : errorMessageDtoList) {
			String errorMessage = errorMessageDto.getErrorMessage();
			if (StringUtils.isNotBlank(errorSource)) {
				if (StringUtils.isBlank(errorMessage)) {
					errorMessage = "Error from errorSource: " + errorSource;
				} else {
					errorMessage = "Error from errorSource: " + errorSource + " : " + errorMessage;
				}
			}
			errorMessageDto.setErrorMessage(errorMessage);

			errorMessage = GsonSerializer.toJson(errorMessageDto);

			CommonProto.Error.Builder errorBuilder = CommonProto.Error.newBuilder();
			errorBuilder.setCode(99999);
			errorBuilder.setMsg(errorMessage);

			statusBuilder.addError(errorBuilder.build());
		}

		CommonProto.KeyValueGroupHolder.Builder keyValueGroupHolderBuilder = CommonProto.KeyValueGroupHolder
				.newBuilder();

		SearchResponse.Builder searchResponseBuilder = SearchResponse.newBuilder();
		searchResponseBuilder.setMsgId(jobId);
		searchResponseBuilder.setStatus(statusBuilder.build());
		searchResponseBuilder.setKvGroupHolder(keyValueGroupHolderBuilder.build());

		return searchResponseBuilder.build();
	}

	private static BioMatcherConfigService getBioMatcherConfigService() {
		if (bioMatcherConfigService == null) {
			bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		}
		return bioMatcherConfigService;
	}
}
