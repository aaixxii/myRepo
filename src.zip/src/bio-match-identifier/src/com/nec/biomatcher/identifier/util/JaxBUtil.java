package com.nec.biomatcher.identifier.util;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

public class JaxBUtil<T> {

	public T unmarshal(Class<T> clazz, String xmlString) throws JAXBException {
		T results = null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
			Unmarshaller unMarshal = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(xmlString);
			JAXBElement<T> root = unMarshal.unmarshal(new StreamSource(reader, xmlString), clazz);
			results = root.getValue();
		} catch (Exception e) {
			throw new JAXBException(e.getMessage(), e);
		}
		return results;
	}

	public String marshal(Class<T> clazz, T result) throws JAXBException {
		StringWriter writer = new StringWriter();
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
			Marshaller marshal = jaxbContext.createMarshaller();
			marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshal.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
			marshal.setProperty(Marshaller.JAXB_FRAGMENT, false);
			marshal.marshal(result, writer);
			String resuslt = writer.toString();
			writer.close();
			return resuslt;
		} catch (Exception e) {
			throw new JAXBException(e.getMessage(), e);
		}
	}
}
