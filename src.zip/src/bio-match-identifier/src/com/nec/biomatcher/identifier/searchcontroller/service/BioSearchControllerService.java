package com.nec.biomatcher.identifier.searchcontroller.service;

/**
 * The Interface BioSearchControllerService.
 */
public interface BioSearchControllerService {

}
