package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.hazelcast.core.Message;
import com.hazelcast.core.MessageListener;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.core.framework.common.StringUtil;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentSetProcessor;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;

/**
 * The listener interface for receiving searchNodeSegmentVersion events. The
 * class that is interested in processing a searchNodeSegmentVersion event
 * implements this interface, and the object created with that class is
 * registered with a component using the component's
 * <code>addSearchNodeSegmentVersionListener<code> method. When the
 * searchNodeSegmentVersion event occurs, that object's appropriate method is
 * invoked.
 *
 * @see SearchNodeSegmentVersionEvent
 */
public class SearchNodeSegmentVersionListener implements MessageListener<String> {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchNodeSegmentVersionListener.class);

	/** The bio match manager service. */
	private BioMatchManagerService bioMatchManagerService;

	private ConcurrentSetProcessor<Integer> searchBrokerNotificationProcessor;

	/**
	 * Instantiates a new search node segment version listener.
	 */
	public SearchNodeSegmentVersionListener() {
		logger.info("In SearchNodeSegmentVersionListener()");
	}

	@Override
	public void onMessage(final Message<String> message) {
		logger.debug("In SearchNodeSegmentVersionListener.onMessage");
		String searchNodeSegmentVersionRecord = message.getMessageObject();
		try {
			String searchNodeId = StringUtils.substringBefore(searchNodeSegmentVersionRecord, ":");
			Map<Integer, Long> newSegmentVersionMap = StringUtil
					.stringToIntLongValueMap(StringUtils.substringAfter(searchNodeSegmentVersionRecord, ":"), "=", ",");

			if (StringUtils.isNotBlank(searchNodeId) && newSegmentVersionMap.size() > 0) {
				ConcurrentSetProcessor<Integer> searchBrokerNotificationProcessor = getSearchBrokerNotificationProcessor();

				ConcurrentHashMap<Integer, Long> segmentIdVersionMap = getBioMatchManagerService()
						.getLiveMatcherNodeSegmentVersionMap(searchNodeId);

				for (Entry<Integer, Long> entry : newSegmentVersionMap.entrySet()) {
					if (segmentIdVersionMap.containsKey(entry.getKey())) {
						segmentIdVersionMap.put(entry.getKey(), entry.getValue());
					}

					if (searchBrokerNotificationProcessor != null) {
						searchBrokerNotificationProcessor.add(entry.getKey());
					}
				}
			}
			logger.debug(
					"In SearchNodeSegmentVersionListener: Updated searchController searchNodeVersionMap for searchNodeId: "
							+ searchNodeId);
		} catch (Throwable th) {
			logger.error("Error in onMessage for searchNodeSegmentVersionRecord: " + searchNodeSegmentVersionRecord
					+ " : " + th.getMessage(), th);
		}
	}

	private BioMatchManagerService getBioMatchManagerService() {
		if (bioMatchManagerService == null) {
			bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");
		}
		return bioMatchManagerService;
	}

	private ConcurrentSetProcessor<Integer> getSearchBrokerNotificationProcessor() {
		if (searchBrokerNotificationProcessor == null) {
			BioSearchControllerManager bioSearchControllerManager = SpringServiceManager
					.getBean("bioSearchControllerManager");
			searchBrokerNotificationProcessor = bioSearchControllerManager.getSearchBrokerNotificationProcessor();
		}
		return searchBrokerNotificationProcessor;
	}
}
