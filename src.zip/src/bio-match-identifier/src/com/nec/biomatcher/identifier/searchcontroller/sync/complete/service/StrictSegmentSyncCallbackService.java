package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.inmemory.BioTaskType;
import com.nec.biomatcher.comp.inmemory.InMemoryManager;
import com.nec.biomatcher.comp.inmemory.tasktimeout.TaskTimeoutListener;
import com.nec.biomatcher.comp.sync.complete.service.dataAccess.SyncSegCallbackServiceDao;
import com.nec.biomatcher.comp.sync.complete.service.dataAccess.impl.SyncSegCallbackServiceDaoImp;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.util.ScSyncJobInfo;
import com.nec.biomatcher.identifier.util.SearchConstants;
import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;

/**
 * 
 * @author 000001A006PBP<br/>
 *         StrictSegmentSyncCallbackService is a service for strict sync
 *         callback
 */
public class StrictSegmentSyncCallbackService implements InitializingBean, DisposableBean {

	private static final AtomicInteger initializationCount = new AtomicInteger();
	
	 // key	is syncJobId
	private static final ConcurrentHashMap<String, List<StrictSyncCallbackKey>> jobIdKeyMap = new ConcurrentHashMap<>();																												// is
																															
	private static final ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> preSnSegVerMap = new ConcurrentHashMap<>();
	private static List<BioMatcherSegmentInfo> preSegInfoList = new ArrayList<>();
	private static final ExecutorService strictSyncCallbackExecutor = Executors.newCachedThreadPool();
	private SyncSegCallbackServiceDao syncSegCallbackServiceDao;
	private BioParameterService bioParameterService;
	private BioSearchControllerManager bioSearchControllerManager;

	//private static final ConcurrentHashMap<String, Long> timesMap = new ConcurrentHashMap<>();

	private static final Logger logger = Logger.getLogger(StrictSegmentSyncCallbackService.class);	

	/**
	 * 
	 * @return
	 */
	public static ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> getStrictSyncCallbackMap() {
		return strictSyncCallbackMap;
	}

	/**
	 * 
	 * @return
	 */
	public static ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> getPreSnSegVerMap() {
		return preSnSegVerMap;	
	}

	/**
	 * 
	 * @return
	 */
	public static ConcurrentHashMap<String, List<StrictSyncCallbackKey>> getJobIdKeyMap() {
		return jobIdKeyMap;
	}

	/**
	 * 
	 * @param jobId
	 */
	public static void removeJobIdMapKey(String jobId) {
		jobIdKeyMap.remove(jobId);
	}

	/**
	 * 
	 * @param key
	 */
	public void removeStritctCallbackData(StrictSyncCallbackKey key) {
		if (key == null) return;
		strictSyncCallbackMap.remove(key);		
	}

	/**
	 * 
	 * @param keyList
	 */
	private void removeStrictCallbackKeys(List<StrictSyncCallbackKey> keyList) {
		if (keyList == null) return;
		
		for (StrictSyncCallbackKey key : keyList) {	
		   if (key != null) {	
			   if (strictSyncCallbackMap.contains(key)) {
				   strictSyncCallbackMap.remove(key);
			   }			   
		   }			
		}
	}
	
	/**
	 * 
	 */
	public void checkNewSegAssing() {
		//checkHaveNewSegAssingLock.lock();
		try {
			final List<BioMatcherSegmentInfo> currentSegInfoList = syncSegCallbackServiceDao.getAllSegmentInfo();
			if (currentSegInfoList.size() == preSegInfoList.size())
				return;
			Set<Integer> segIds = preSegInfoList.stream().map(BioMatcherSegmentInfo::getSegmentId)
					.collect(Collectors.toSet());
			List<BioMatcherSegmentInfo> diffs = currentSegInfoList.stream()
					.filter(info -> !segIds.contains(info.getSegmentId())).collect(Collectors.toList());
			if (diffs.isEmpty())
				return;
			final List<BioMatcherNodeSegmentInfo> snSegInfoLists = syncSegCallbackServiceDao.getAllActiveSnSegInfo();
			diffs.stream().forEach(bioMatcherSegmentInfo -> {
				Integer binId = bioMatcherSegmentInfo.getBinId();
				Integer segId = bioMatcherSegmentInfo.getSegmentId();
				preSnSegVerMap.put(new SegIdBinKey(segId, binId), getSyncSnSegVerInfo(segId, binId, snSegInfoLists));
			});
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			//checkHaveNewSegAssingLock.unlock();
		}
	}

	/**
	 * 
	 * @param syncJobId
	 * @param callbackurl
	 * @param modifiedBiometricEventInfoList
	 */
	public void registerStrictSyncCallbackData(String syncJobId, String callbackurl,
			List<BiometricEventInfo> modifiedBiometricEventInfoList) {
		StrictSyncCallbackDataRegister registetask = new StrictSyncCallbackDataRegister(syncJobId, callbackurl,
				modifiedBiometricEventInfoList);
		strictSyncCallbackExecutor.submit(registetask);
	}

	/**
	 * 
	 * @param reportMeg
	 */
	public void updateSnSegmentReportMegToMemory(String reportMeg) {
		ProcessSnReportTask processSnReportTask = new ProcessSnReportTask(reportMeg);
		strictSyncCallbackExecutor.submit(processSnReportTask);
	}

	/**
	 * 
	 * @param syncJobId
	 * @param jobKeys
	 */
	public void callbackToClient(String syncJobId, List<StrictSyncCallbackKey> jobKeys) {
		removeStrictCallbackKeys(jobKeys);
		removeJobIdMapKey(syncJobId);		
		SyncJobResultDto strictSyncResult = new SyncJobResultDto(syncJobId, BioJobStatus.COMPLETED);
		List<BiometricEventSyncTypeDto> successList = new ArrayList<>();
		jobKeys.stream().forEach(key -> {
			successList.add(new BiometricEventSyncTypeDto(key.getExternalId(), key.getEventId()));
		});
		strictSyncResult.getSuccessfulEventSyncTypeDtoList().addAll(successList);
		StrictSegmentSyncCallbackTask callbaker = new StrictSegmentSyncCallbackTask(jobKeys.get(0), strictSyncResult);
		strictSyncCallbackExecutor.submit(callbaker);		
	
		ConcurrentHashMap<String, ScSyncJobInfo> syncJobInfoMap = bioSearchControllerManager.getSyncJobInfoMap();
		ScSyncJobInfo syncJobInfo = syncJobInfoMap.get(jobKeys.get(0).getSyncJobId());
		if (syncJobInfo != null) {
			syncJobInfo.setJobCompletedFlag(true);
		}
	}

	/**
	 * 
	 * @param ex
	 * @param syncJobId
	 * @param jobKeys
	 */
	private void faildCallbackToClient(StrictSegmentSyncCallbackServiceException ex, String syncJobId,
			List<StrictSyncCallbackKey> jobKeys) {
		if (syncJobId == null || syncJobId.isEmpty() || jobKeys.isEmpty()) return;
		SyncJobResultDto faildSyncResult = new SyncJobResultDto(syncJobId, BioJobStatus.FAILED);
		// List<BiometricEventSyncTypeDto> faildList = new ArrayList<>();
		// jobKeys.stream().forEach(key -> {
		// faildList.add(new BiometricEventSyncTypeDto(key.getExternalId(),
		// key.getEventId()));
		// });
		// faildSyncResult.getSuccessfulEventSyncTypeDtoList().addAll(faildList);
		// //It will be add externalId to job results?
		faildSyncResult.getErrorList().add(new ErrorMessageDto(ex.getErrCode(), syncJobId + " Strict Sync Job is faild",
				String.format("%s", ex.getMessage()), new Date()));
		StrictSegmentSyncCallbackTask callbaker = new StrictSegmentSyncCallbackTask(jobKeys.get(0), faildSyncResult);
		strictSyncCallbackExecutor.submit(callbaker);
		jobIdKeyMap.remove(syncJobId);
	}

	/**
	 * 
	 * @param ex
	 */
	public void faildStrictSyncCallback(StrictSegmentSyncCallbackServiceException ex) {
		StrictSyncCallbackKey errKey = null;
		if (ex.getJobId() != null) {
			faildCallbackToClient(ex, ex.getJobId(), jobIdKeyMap.get(ex.getJobId()));
		} else if (ex.getSnId() != null && ex.getBinId() != null && ex.getSegId() != null) {
			errKey = getKeyBySnSegInfo(ex.getSnId(), ex.getBinId(), ex.getSegId());
			if (errKey == null) {
				logger.warn("Get empty key for SnId:Binid:SegmentId:" + ex.getJobId() + ":" + ex.getSnId() + ":"
						+ ex.getBinId() + ":" + ex.getSegId() + " .skip callback!!");
				return;
			}
			faildCallbackToClient(ex, errKey.getSyncJobId(), jobIdKeyMap.get(errKey.getSyncJobId()));
		} else if (ex.getSnId() != null && ex.getSegId() != null) {
			errKey = getKeyBySnIdSegId(ex.getSnId(), ex.getSegId());
			if (errKey == null) {
				return;
			}
			faildCallbackToClient(ex, errKey.getSyncJobId(), jobIdKeyMap.get(errKey.getSyncJobId()));
		}
	}

	/**
	 * 
	 * @param snId
	 * @param segId
	 * @return
	 */
	private StrictSyncCallbackKey getKeyBySnIdSegId(String snId, Integer segId) {
		final StrictSyncCallbackKey key = new StrictSyncCallbackKey();
		Predicate<SyncSnSegVerInfo> predicate = info -> info.getSegmentId().intValue() == segId.intValue()
				&& info.getSnNodeId().equals(snId);
		strictSyncCallbackMap.entrySet().stream().forEach(entry -> {
			if (entry.getValue().stream().filter(predicate).findAny().isPresent()) {
				key.setCallbackUrl(entry.getKey().getCallbackUrl());
				key.setSyncJobId(entry.getKey().getSyncJobId());
				key.setSyncJobId(entry.getKey().getSyncJobId());
				key.setEventId(entry.getKey().getEventId());
				key.setExternalId(entry.getKey().getExternalId());
			}
		});
		return key;
	}

	/**
	 * 
	 * @param snId
	 * @param binId
	 * @param segId
	 * @return
	 */
	private StrictSyncCallbackKey getKeyBySnSegInfo(String snId, Integer binId, Integer segId) {
		final StrictSyncCallbackKey key = new StrictSyncCallbackKey();
		Predicate<SyncSnSegVerInfo> predicate = info -> info.getBinId().intValue() == binId.intValue()
				&& info.getSegmentId().intValue() == segId.intValue() && info.getSnNodeId().equals(snId);
		strictSyncCallbackMap.entrySet().stream().forEach(entry -> {
			if (entry.getValue().stream().filter(predicate).findAny().isPresent()) {
				key.setCallbackUrl(entry.getKey().getCallbackUrl());
				key.setSyncJobId(entry.getKey().getSyncJobId());
				key.setSyncJobId(entry.getKey().getSyncJobId());
				key.setEventId(entry.getKey().getEventId());
				key.setExternalId(entry.getKey().getExternalId());
			}
		});
		return key;
	}

	/**
	 * 
	 * @param segmentId
	 * @param binId
	 * @param snSegInfoList
	 * @return
	 */
	private List<SyncSnSegVerInfo> getSyncSnSegVerInfo(Integer segmentId, Integer binId,
			List<BioMatcherNodeSegmentInfo> snSegInfoList) {
		List<SyncSnSegVerInfo> snSegVerInfos = new ArrayList<>();
		for (BioMatcherNodeSegmentInfo info : snSegInfoList) {
			if (info.getSegmentId().intValue() == segmentId.intValue() && info.getAssignedFlag().booleanValue()) {
				SyncSnSegVerInfo snSegInfo = new SyncSnSegVerInfo(info.getMatcherNodeId(), binId, info.getSegmentId(),
						info.getSegmentVersion(), Boolean.FALSE);
				snSegVerInfos.add(snSegInfo);
			}
		}
		return snSegVerInfos;
	}

	/**
	 * 
	 * @param syncJobId
	 */
	private void notifySyncSegCallbackTimeout(String syncJobId) {
		SyncJobResultDto errRespose = new SyncJobResultDto(syncJobId, BioJobStatus.FAILED);
		long timeaOut = bioParameterService.getParameterValue("MAX_SYNC_SEGMENTS＿COMPLETED_TIMEOUT_MILLI", "DEFAULT",
				TimeUnit.SECONDS.toMillis(6));
		logger.warn("Timeout occurred. syncJobId:" + syncJobId + " elapsedTime:" + String.valueOf(timeaOut));
		String timeoutErrorMessage = "Error strict sync segments timeout for syncJobId: " + syncJobId
				+ " after delayMilli: " + timeaOut;
		errRespose.getErrorList().add(new ErrorMessageDto(SearchConstants.ERROR_CODE_STRIC_SYNC_JOB_TIMEOUT,
				timeoutErrorMessage, null, new Date()));
		List<StrictSyncCallbackKey> callBackkeys = jobIdKeyMap.get(syncJobId);
		StrictSegmentSyncCallbackTask strictCallbackTask = new StrictSegmentSyncCallbackTask(callBackkeys.get(0),
				errRespose);
		strictSyncCallbackExecutor.submit(strictCallbackTask);
		removeJobIdMapKey(syncJobId);
		removeStrictCallbackKeys(callBackkeys);
	}

	/**
	 * Initialize instance of StrictSegmentSyncCallbackService
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		synchronized (this) {
			if (initializationCount.get() > 0) {
				return;
			}
			initializationCount.incrementAndGet();
		}
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		syncSegCallbackServiceDao = SpringServiceManager.getBean("syncSegCallbackServiceDao");
		bioSearchControllerManager = SpringServiceManager.getBean("bioSearchControllerManager");
		InMemoryManager.timeoutListenerMap.put(BioTaskType.STRICT_SYNC, new TaskTimeoutListener() {
			@Override
			public void notifyTaskTimeout(String jobId) {
				notifySyncSegCallbackTimeout(jobId);
			}
		});

		try {
			final List<BioMatcherSegmentInfo> allSegInfoList = syncSegCallbackServiceDao.getAllSegmentInfo();
			final List<BioMatcherNodeSegmentInfo> snSegInfoList = syncSegCallbackServiceDao.getAllActiveSnSegInfo();
			if (allSegInfoList == null || allSegInfoList.size() == 0) {
				logger.warn("No available segment!, skip...");
				return;
			}

			if (snSegInfoList == null || snSegInfoList.size() == 0) {
				logger.warn("No available SN that having assigned segment!, skip...");
				return;
			}
			preSegInfoList.addAll(allSegInfoList);
			allSegInfoList.stream().forEach(bioMatcherSegmentInfo -> {
				Integer binId = bioMatcherSegmentInfo.getBinId();
				Integer segId = bioMatcherSegmentInfo.getSegmentId();
				preSnSegVerMap.put(new SegIdBinKey(segId, binId), getSyncSnSegVerInfo(segId, binId, snSegInfoList));
			});
			
			logger.debug("In StandUP, preSnSegVerMap size=" + preSnSegVerMap.size());
			logger.debug("In registerStrictSyncCallbackData, strictSyncCallbackMap size=" + strictSyncCallbackMap.size());
			logger.debug("In registerStrictSyncCallbackData,jobIdKeyMap size=" + jobIdKeyMap.size());

		} catch (Exception e) {
			logger.info("Initialize StrictSegmentSyncCallbackService is failed");
			logger.error(e.getMessage(), e);
		}
		logger.info("Sucess initializied StrictSegmentSyncCallbackService.");
	}

	/**
	 * 
	 * @param syncSegCallbackServiceDaoImp
	 */
	public void setSyncSegCallbackServiceDao(SyncSegCallbackServiceDaoImp syncSegCallbackServiceDaoImp) {
		this.syncSegCallbackServiceDao = syncSegCallbackServiceDaoImp;
	}

	/**
	 * 
	 * @param bioParameterService
	 */
	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	@Override
	public void destroy() throws Exception {
		strictSyncCallbackExecutor.shutdown();
		strictSyncCallbackMap.clear();
		preSnSegVerMap.clear();
	}
}
