package com.nec.biomatcher.identifier.searchcontroller.manager.impl;

import java.io.File;
import java.net.InetSocketAddress;
import java.net.URI;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.hazelcast.config.Config;
import com.hazelcast.config.JoinConfig;
import com.hazelcast.config.NetworkConfig;
import com.hazelcast.config.TcpIpConfig;
import com.hazelcast.core.Client;
import com.hazelcast.core.ClientListener;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.ILock;
import com.hazelcast.core.IMap;
import com.hazelcast.core.IQueue;
import com.hazelcast.core.ISet;
import com.hazelcast.core.ITopic;
import com.hazelcast.core.MemberAttributeEvent;
import com.hazelcast.core.MembershipEvent;
import com.hazelcast.core.MembershipListener;
import com.nec.biomatcher.comp.cluster.ClusterInstanceRegistry;
import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.util.JobEntry;
import com.nec.biomatcher.comp.util.LocalServerComponents;
import com.nec.biomatcher.comp.util.ServerStatusMonitor;
import com.nec.biomatcher.core.framework.cache.SpringCacheManager;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.common.TriKey;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentExecutor;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentReader;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentSetProcessor;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.VersionLatch;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.searchcontroller.service.exception.BioSearchContollerException;
import com.nec.biomatcher.identifier.searchcontroller.sync.complete.service.StrictSyncSegmentCompleteListener;
import com.nec.biomatcher.identifier.searchcontroller.tasks.BiometricEventVersionAssignmentTask;
import com.nec.biomatcher.identifier.searchcontroller.tasks.SearchBrokerFailoverTask;
import com.nec.biomatcher.identifier.searchcontroller.tasks.SearchBrokerNotificationProcessorTask;
import com.nec.biomatcher.identifier.searchcontroller.tasks.SegmentChangeSetBacklogTask;
import com.nec.biomatcher.identifier.searchcontroller.tasks.SegmentFileWriterTask;
import com.nec.biomatcher.identifier.searchcontroller.tasks.SyncEventsToRemoteSiteTask;
import com.nec.biomatcher.identifier.searchcontroller.util.ScSearchJobInfo;
import com.nec.biomatcher.identifier.searchcontroller.util.SearchJobCancelingListener;
import com.nec.biomatcher.identifier.searchcontroller.util.SearchNodeSegmentVersionListener;
import com.nec.biomatcher.identifier.util.ScSyncJobInfo;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;

/**
 * The Class BioClusteredSearchControllerManagerImpl.
 */
public class BioClusteredSearchControllerManagerImpl
		implements BioSearchControllerManager, InitializingBean, MembershipListener, ClientListener, DisposableBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioClusteredSearchControllerManagerImpl.class);

	/** The hazelcast instance. */
	private HazelcastInstance hazelcastInstance;

	/** The segment change set writer backlog lock. */
	private ILock segmentChangeSetWriterBacklogLock;

	/** The segment change set backlog lock timestamp. */
	private IAtomicLong segmentChangeSetBacklogLockTimestamp;

	private IQueue<Integer> createFullSegmentFileRequestQueue;

	private IMap<Integer, String> createFullSegmentFileRequestMap;

	/** The notify segment changes to search broker topic. */
	private ITopic<String> notifySegmentChangesToSearchBrokerTopic;

	/** The notify search node segment version to controller topic. */
	private ITopic<String> notifySearchNodeSegmentVersionToControllerTopic;

	private ITopic<String> notifyStrictSyncCompleteTopic;

	private ITopic<String> notifySearchJobCancelingTopic;

	private String notifyStrictSyncCompleteTopicListenerId;

	private String notifySearchJobCancelingTopicListenerId;

	/**
	 * The notify search node segment version to controller topic listener id.
	 */
	private String notifySearchNodeSegmentVersionToControllerTopicListenerId;

	private ConcurrentValuedHashMap<TriKey<String, String, String>, SearchNodeCapacityGroupLoadInfo> scSearchNodePartitionedLoadMap;

	// IAtomicBoolean is not consistent
	private ConcurrentValuedHashMap<String, IAtomicLong> searchNodeOnlineFlagMap;

	private ConcurrentValuedHashMap<String, ConcurrentReader<Boolean>> searchNodeOnlineStatusMap;

	private ConcurrentValuedHashMap<String, ILock> searchNodeJobAssignmentLockMap;

	private ITopic<String> notifyOfflineSearchNodeTopic;

	/** The search controller id. */
	private String searchControllerId;

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	private ConcurrentExecutor segmentFileWriterExecutor;

	/** The pending extract search job id set. */
	private ConcurrentSkipListSet<String> pendingExtractSearchJobIdSet = new ConcurrentSkipListSet<>();

	private ConcurrentSkipListSet<String> pendingExtractSyncJobIdSet = new ConcurrentSkipListSet<>();

	/** The pending search job queue. */
	private ConcurrentValuedHashMap<String, PriorityBlockingQueue<JobEntry>> pendingSearchJobQueueMap = new ConcurrentValuedHashMap<>(
			(capacityGroupId) -> new PriorityBlockingQueue<JobEntry>());

	/** The search job queue housekeeping queue. */
	private DelayQueue<DelayedItem<String>> searchJobQueueHousekeepingQueue = new DelayQueue<>();

	private static ConcurrentHashMap<String, ScSearchJobInfo> searchJobInfoMap = new ConcurrentHashMap<>();

	private static ConcurrentHashMap<String, ScSyncJobInfo> syncJobInfoMap = new ConcurrentHashMap<>();

	private LinkedBlockingQueue<String> pendingSyncJobQueue = new LinkedBlockingQueue<>();

	private DelayQueue<DelayedItem<String>> syncJobQueueHousekeepingQueue = new DelayQueue<>();

	/** The search broker failover queue. */
	private DelayQueue<DelayedItem<String>> searchBrokerFailoverQueue = new DelayQueue<>();

	private VersionLatch buildMissingChangeSetFileRequestVersionLatch = new VersionLatch();

	/** The initialization count. */
	private static AtomicInteger initializationCount = new AtomicInteger();

	private static ConcurrentSetProcessor<Integer> eventVersionAssignmentProcesseor;

	private final BiometricEventVersionAssignmentTask biometricEventVersionAssignmentTask = new BiometricEventVersionAssignmentTask();

	private final SyncEventsToRemoteSiteTask syncEventsToRemoteSiteTask = new SyncEventsToRemoteSiteTask();

	private static ConcurrentSetProcessor<Integer> searchBrokerNotificationProcessor;

	private final SearchBrokerNotificationProcessorTask searchBrokerNotificationProcessorTask = new SearchBrokerNotificationProcessorTask();

	private MatcherFunctionControlUtil matcherFunctionControlUtil;

	// private String onlineSearchBrokerId;
	//
	// private String offlineSearchBrokerId;

	public HazelcastInstance getHazelcastInstance() {
		return hazelcastInstance;
	}

	public String getSearchControllerId() {
		return searchControllerId;
	}

	// public String getOnlineSearchBrokerId() {
	// return onlineSearchBrokerId;
	// }
	//
	// public String getOfflineSearchBrokerId() {
	// return offlineSearchBrokerId;
	// }

	public DelayQueue<DelayedItem<String>> getSearchBrokerFailoverQueue() {
		return searchBrokerFailoverQueue;
	}

	public ConcurrentHashMap<String, ScSearchJobInfo> getSearchJobInfoMap() {
		return searchJobInfoMap;
	}

	public void notifySegmentChangesToSearchBroker(Integer segmentId, Long segmentVersion) {
		notifySegmentChangesToSearchBrokerTopic.publish(segmentId + ":" + segmentVersion);
	}

	public void notifySearchJobCanceling(String msg) {
		notifySearchJobCancelingTopic.publish(msg);		
	}
	
	

	public void acquireSegmentChangeSetWriterBacklogLock() {
		segmentChangeSetWriterBacklogLock.lock();
	}

	public void releaseSegmentChangeSetWriterBacklogLock() {
		segmentChangeSetWriterBacklogLock.unlock();
	}

	public boolean tryAcquireSegmentChangeSetWriterLock(Integer segmentId) {
		ILock segmentWriterLock = hazelcastInstance.getLock("SegmentWriterLock_" + segmentId);
		return segmentWriterLock.tryLock();
	}

	public void releaseSegmentChangeSetWriterLock(Integer segmentId) {
		ILock segmentWriterLock = hazelcastInstance.getLock("SegmentWriterLock_" + segmentId);
		segmentWriterLock.unlock();
	}

	public IMap<String, String> getBuildMissingChangeSetFileRequestMap() {
		IMap<String, String> requestMap = hazelcastInstance.getMap("BuildMissingChangeSetFileRequestMap");
		return requestMap;
	}

	public VersionLatch getBuildMissingChangeSetFileRequestVersionLatch() {
		return buildMissingChangeSetFileRequestVersionLatch;
	}

	public void acquireSearchBrokerFailoverLock() {
		ILock failoverLock = hazelcastInstance.getLock("SEARCH_BROKER_FAILOVER_LOCK");
		failoverLock.lock();
	}

	public void releaseSearchBrokerFailoverLock() {
		ILock failoverLock = hazelcastInstance.getLock("SEARCH_BROKER_FAILOVER_LOCK");
		failoverLock.unlock();
	}

	public void acquireJobAssignmentLock(String searchNodeId) {
		ILock jobAssignmentLock = searchNodeJobAssignmentLockMap.getValue(searchNodeId);
		jobAssignmentLock.lock();
	}

	public boolean tryAcquireJobAssignmentLock(String lockKey) {
		long startTimestamp = System.currentTimeMillis();
		try {
			ILock jobAssignmentLock = searchNodeJobAssignmentLockMap.getValue(lockKey);
			return jobAssignmentLock.tryLock();
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestamp;
			if (logger.isTraceEnabled() || timeTakenMilli > 5) {
				logger.info(
						"In tryAcquireJobAssignmentLock: TimeTakenMilli: " + timeTakenMilli + ", lockKey: " + lockKey);
			}
		}
	}

	public boolean tryAcquireJobAssignmentLock(String lockKey, long lockWaitMilli) throws InterruptedException {
		long startTimestamp = System.currentTimeMillis();
		try {
			ILock jobAssignmentLock = searchNodeJobAssignmentLockMap.getValue(lockKey);
			return jobAssignmentLock.tryLock(lockWaitMilli, TimeUnit.MILLISECONDS);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestamp;
			if (logger.isTraceEnabled() || timeTakenMilli > lockWaitMilli) {
				logger.info(
						"In tryAcquireJobAssignmentLock: TimeTakenMilli: " + timeTakenMilli + ", lockKey: " + lockKey);
			}
		}
	}

	public void releaseJobAssignmentLock(String searchNodeId) {
		ILock jobAssignmentLock = searchNodeJobAssignmentLockMap.getValue(searchNodeId);
		jobAssignmentLock.unlock();
	}

	public long getSegmentChangeSetWriterBacklogTimestamp() {
		return segmentChangeSetBacklogLockTimestamp.get();
	}

	public void setSegmentChangeSetWriterBacklogTimestamp(long timestamp) {
		segmentChangeSetBacklogLockTimestamp.set(timestamp);
	}

	public ConcurrentSkipListSet<String> getPendingExtractSearchJobIdSet() {
		return pendingExtractSearchJobIdSet;
	}

	public ConcurrentValuedHashMap<String, PriorityBlockingQueue<JobEntry>> getPendingSearchJobQueueMap() {
		return pendingSearchJobQueueMap;
	}

	public DelayQueue<DelayedItem<String>> getSearchJobQueueHousekeepingQueue() {
		return searchJobQueueHousekeepingQueue;
	}

	public ConcurrentValuedHashMap<String, ConcurrentReader<Boolean>> getSearchNodeOnlineStatusMap() {
		return searchNodeOnlineStatusMap;
	}

	public boolean getSearchNodeOnlineFlag(String searchNodeId) {
		// IAtomicLong onlineFlagRef =
		// searchNodeOnlineFlagMap.getValue(searchNodeId);
		// return onlineFlagRef.get() == 1;

		return searchNodeOnlineStatusMap.getValue(searchNodeId).get();
	}

	public ConcurrentSkipListSet<String> getPendingExtractSyncJobIdSet() {
		return pendingExtractSyncJobIdSet;
	}

	public ConcurrentHashMap<String, ScSyncJobInfo> getSyncJobInfoMap() {
		return syncJobInfoMap;
	}

	public LinkedBlockingQueue<String> getPendingSyncJobQueue() {
		return pendingSyncJobQueue;
	}

	public DelayQueue<DelayedItem<String>> getSyncJobQueueHousekeepingQueue() {
		return syncJobQueueHousekeepingQueue;
	}

	public IQueue<Integer> getCreateFullSegmentFileRequestQueue() {
		return createFullSegmentFileRequestQueue;
	}

	public IMap<Integer, String> getCreateFullSegmentFileRequestMap() {
		return createFullSegmentFileRequestMap;
	}

	public void submitReSegmentationRequest(Integer segmentId) {
		logger.info("In submitReSegmentationRequest: segmentId: " + segmentId);

		boolean acquireFlag = createFullSegmentFileRequestMap.tryLock(segmentId);
		if (acquireFlag) {
			try {
				createFullSegmentFileRequestMap.put(segmentId, "Submitted");
			} finally {
				createFullSegmentFileRequestMap.unlock(segmentId);
			}
		}

		createFullSegmentFileRequestQueue.add(segmentId);
	}

	public ConcurrentSetProcessor<Integer> getEventVersionAssignmentProcesseor() {
		return eventVersionAssignmentProcesseor;
	}

	public ConcurrentSetProcessor<Integer> getSearchBrokerNotificationProcessor() {
		return searchBrokerNotificationProcessor;
	}

	public ConcurrentValuedHashMap<TriKey<String, String, String>, SearchNodeCapacityGroupLoadInfo> getScSearchNodePartitionedLoadMap() {
		return scSearchNodePartitionedLoadMap;
	}

	public ConcurrentValuedHashMap<String, IAtomicLong> getSearchNodeOnlineFlagMap() {
		return searchNodeOnlineFlagMap;
	}

	public void setSearchNodeOnlineFlag(String searchNodeId, boolean flag) {
		searchNodeOnlineFlagMap.getValue(searchNodeId).set(flag ? 1 : 0);
	}

	private void notifySearchBrokerOffline(String searchBrokerId) {
		try {
			CommonLogger.STATUS_LOG.warn("In notifySearchBrokerOffline for searchBrokerId: " + searchBrokerId);

			ServerStatusMonitor.notifyOffline(BioComponentType.SB, searchBrokerId);

			Set<String> searchNodeIdSet = bioMatcherConfigService
					.getAssignedSearchNodeIdListBySearchBrokerId(searchBrokerId);
			for (String searchNodeId : searchNodeIdSet) {
				try {
					setSearchNodeOnlineFlag(searchNodeId, false);
				} catch (Throwable th) {
					logger.error("Error in clientDisconnected during marking SN as offline for searchNodeId: "
							+ searchNodeId);
				} finally {
					CommonLogger.STATUS_LOG.warn("In notifySearchBrokerOffline for searchBrokerId: " + searchBrokerId
							+ " : marking SN as offline for searchNodeId: " + searchNodeId);
				}
			}
		} catch (Throwable th) {
			logger.error(
					"Error in notifySearchBrokerOffline: searchBrokerId: " + searchBrokerId + " : " + th.getMessage(),
					th);
		}
	}

	public void notifySearchNodeOffline(String searchNodeId) {
		try {
			ServerStatusMonitor.notifyOffline(BioComponentType.SN, searchNodeId);

			try {
				IAtomicLong onlineFlagRef = searchNodeOnlineFlagMap.getValue(searchNodeId);
				if (onlineFlagRef.get() != 0) {
					onlineFlagRef.set(0);
				}
			} catch (Throwable th) {
				logger.error("Error setting the onlineFlagRef for searchNodeId: " + searchNodeId);
			}

			notifyOfflineSearchNodeTopic.publish(searchNodeId);
		} catch (Throwable th) {
			logger.error("Error in notifySearchNodeOffline: " + th.getMessage(), th);
		}
	}

	/**
	 * Creates the default search controller settings.
	 *
	 * @param searchControllerId
	 *            the search controller id
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	public void createDefaultSearchControllerSettings(String searchControllerId)
			throws BioMatcherConfigServiceException {
		BioServerInfo searchController = bioMatcherConfigService.getServerInfo(searchControllerId);

		bioMatcherConfigService.createServerConnnections(searchController.getServerId(),
				searchController.getServerHost(), searchController.getComponentType());
	}

	/**
	 * Configure cluster objects.
	 *
	 * @throws Exception
	 *             the exception
	 */
	private void configureClusterObjects() throws Exception {
		logger.info("In configureClusterObjects");

		notifySegmentChangesToSearchBrokerTopic = hazelcastInstance.getTopic("NotifySegmentChangesToSearchBrokerTopic");

		notifyOfflineSearchNodeTopic = hazelcastInstance.getTopic("NotifyOfflineSearchNodeTopic");

		segmentChangeSetWriterBacklogLock = hazelcastInstance.getLock("SegmentChangeSetWriterBacklogLock");

		segmentChangeSetBacklogLockTimestamp = hazelcastInstance.getAtomicLong("SegmentChangeSetBacklogLockTimestamp");

		createFullSegmentFileRequestQueue = hazelcastInstance.getQueue("CreateFullSegmentFileRequestQueue");

		createFullSegmentFileRequestMap = hazelcastInstance.getMap("CreateFullSegmentFileRequestMap");
		notifyStrictSyncCompleteTopic = hazelcastInstance.getTopic("NotifyStrictSyncCompleteTopic");
		
		notifySearchJobCancelingTopic = hazelcastInstance.getTopic("NotifySearchJobCancelingTopic");
		
	}

	/**
	 * Builds the search controller cluster.
	 *
	 * @throws Exception
	 *             the exception
	 */
	private void buildSearchControllerCluster() throws Exception {
		logger.info("In buildSearchControllerCluster : " + searchControllerId + ", hostname: "
				+ HostnameUtil.getHostname() + ", ipAddress: " + HostnameUtil.getIpAddress());
		try {

			createDefaultSearchControllerSettings(searchControllerId);

			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchControllerId,
					BioComponentType.SC, BioConnectionType.CLUSTER, BioProtocolType.HAZELCAST);
			if (StringUtils.isBlank(connectionUrl)) {
				throw new IllegalArgumentException("Match controller connection url is not configured for serverId: "
						+ searchControllerId + ", BioComponentType: " + BioComponentType.SC + ", connectionType: "
						+ BioConnectionType.CLUSTER + ", protocolType: " + BioProtocolType.HAZELCAST);
			}

			URI uri = new URI(connectionUrl);

			if (uri.getHost() == null || uri.getPort() == 0) {
				throw new IllegalArgumentException(
						"Host and port for Match controller is not properly configured serverId: " + searchControllerId
								+ ", BioComponentType: " + BioComponentType.SC + ", connectionType: "
								+ BioConnectionType.CLUSTER + ", protocolType: " + BioProtocolType.HAZELCAST
								+ ", connectionUrl: " + connectionUrl);
			}

			String clusterInstanceId = BioComponentType.SC.name() + "_ControllerCluster";

			HazelcastInstance currentHazelcastInstance = Hazelcast.getHazelcastInstanceByName(clusterInstanceId);
			if (currentHazelcastInstance != null) {
				currentHazelcastInstance.shutdown();
			}

			Config config = new Config(clusterInstanceId);
			config.getGroupConfig().setName(clusterInstanceId).setPassword("nec");

			config.setProperty("hazelcast.shutdownhook.enabled", "true");

			NetworkConfig network = config.getNetworkConfig();

			network.setPort(uri.getPort());
			network.setPortAutoIncrement(false);
			network.setReuseAddress(true);

			// TODO: Need to check weather we need to set it
			// network.setPublicAddress(publicAddress);

			network.setPublicAddress(uri.getHost());

			JoinConfig join = network.getJoin();
			join.getMulticastConfig().setEnabled(false);
			TcpIpConfig tcpIpConfig = join.getTcpIpConfig();

			List<BioServerInfo> searchControllerList = bioMatcherConfigService
					.getServerInfoListByComponentType(BioComponentType.SC);
			for (BioServerInfo searchController : searchControllerList) {
				if (!BioServerState.ACTIVE.equals(searchController.getServerState())) {
					logger.warn(
							"Match controller state is not active for serverId : " + searchController.getServerId());
					continue;
				}

				createDefaultSearchControllerSettings(searchController.getServerId());

				connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchController.getServerId(),
						BioComponentType.SC, BioConnectionType.CLUSTER, BioProtocolType.HAZELCAST);
				if (StringUtils.isBlank(connectionUrl)) {
					throw new IllegalArgumentException(
							"Match controller connection url is not configured for serverId: "
									+ searchController.getServerId() + ", BioComponentType: " + BioComponentType.SC
									+ ", connectionType: " + BioConnectionType.CLUSTER + ", protocolType: "
									+ BioProtocolType.HAZELCAST);
				}

				URI clusterMemberUri = new URI(connectionUrl);

				if (clusterMemberUri.getHost() == null || clusterMemberUri.getPort() == 0) {
					throw new IllegalArgumentException(
							"Host and port for Match controller is not properly configured serverId: "
									+ searchController.getServerId() + ", BioComponentType: " + BioComponentType.SC
									+ ", connectionType: " + BioConnectionType.CLUSTER + ", protocolType: "
									+ BioProtocolType.HAZELCAST + ", connectionUrl: " + connectionUrl);
				}

				logger.info("After parsing connectionUrl: " + connectionUrl + ", host: " + clusterMemberUri.getHost()
						+ ", port: " + clusterMemberUri.getPort());

				tcpIpConfig.addMember(clusterMemberUri.getHost());
			}

			tcpIpConfig.setEnabled(true);

			// TODO: Need to check weather it is for binding on multiple IP
			// Address on this system
			network.getInterfaces().setEnabled(true).addInterface("*.*.*.*");
			// network.getInterfaces().setEnabled(true).addInterface(HostnameUtil.getIpAddress());

			hazelcastInstance = Hazelcast.getOrCreateHazelcastInstance(config);

			ClusterInstanceRegistry.register(BioComponentType.SC, hazelcastInstance);

			logger.info("Current cluster members: " + hazelcastInstance.getCluster().getMembers().size());

			matcherFunctionControlUtil = new MatcherFunctionControlUtil(BioComponentType.SC, searchControllerId,
					bioMatcherConfigService, hazelcastInstance);

			scSearchNodePartitionedLoadMap = new ConcurrentValuedHashMap<>((key) -> new SearchNodeCapacityGroupLoadInfo(
					hazelcastInstance, key.getA(), key.getB(), key.getC()));

			searchNodeOnlineFlagMap = new ConcurrentValuedHashMap<>(
					(searchNodeId) -> hazelcastInstance.getAtomicLong("SEARCH_NODE_ONLINE_FLAG_" + searchNodeId));

			final ConcurrentValuedHashMap<String, IAtomicLong> finalSearchNodeOnlineFlagMap = searchNodeOnlineFlagMap;

			searchNodeOnlineStatusMap = new ConcurrentValuedHashMap<>((searchNodeId) -> new ConcurrentReader<>(
					() -> finalSearchNodeOnlineFlagMap.getValue(searchNodeId).get() == 1));

			searchNodeJobAssignmentLockMap = new ConcurrentValuedHashMap<>(
					(searchNodeId) -> hazelcastInstance.getLock("SEARCH_JOB_ASSIGNMENT_LOCK_" + searchNodeId));

			hazelcastInstance.getCluster().addMembershipListener(this);

			hazelcastInstance.getClientService().addClientListener(this);

			notifySearchNodeSegmentVersionToControllerTopic = hazelcastInstance
					.getTopic("NotifySearchNodeSegmentVersionToControllerTopic");
			notifySearchNodeSegmentVersionToControllerTopicListenerId = notifySearchNodeSegmentVersionToControllerTopic
					.addMessageListener(new SearchNodeSegmentVersionListener());

			notifyStrictSyncCompleteTopic = hazelcastInstance.getTopic("NotifyStrictSyncCompleteTopic");
			notifyStrictSyncCompleteTopicListenerId = notifyStrictSyncCompleteTopic
					.addMessageListener(new StrictSyncSegmentCompleteListener());
			
			notifySearchJobCancelingTopic = hazelcastInstance.getTopic("NotifySearchJobCancelingTopic");
			notifySearchJobCancelingTopicListenerId = notifySearchJobCancelingTopic.addMessageListener(new SearchJobCancelingListener());
					
			
			

			logger.info("In buildSearchControllerCluster: hazelcastInstance created successfully");
		} catch (Throwable th) {
			logger.warn("Error in buildSearchControllerCluster: " + th.getMessage());
			throw new BioSearchContollerException("Error in buildSearchControllerCluster: " + th.getMessage(), th);
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In BioClusteredSearchControllerManagerImpl: afterPropertiesSet : ipaddress: "
				+ HostnameUtil.getIpAddress() + ", hostname: " + HostnameUtil.getHostname() + ", initializationCount: "
				+ initializationCount.get());

		// boolean extractionControllerClusterModeFlag =
		// bioParameterService.getParameterValue("EXTRACTION_CONTROLLER_CLUSTER_MODE_FLAG",
		// "DEFAULT", true);
		// if (!extractionControllerClusterModeFlag) {
		// logger.info("In BioClusteredSearchControllerManagerImpl:
		// afterPropertiesSet : Ignoring clusteredExtractionController startup,
		// current extractionControllerClusterModeFlag: " +
		// extractionControllerClusterModeFlag);
		// return;
		// }

		synchronized (BioClusteredSearchControllerManagerImpl.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			initializationCount.incrementAndGet();

			BioServerInfo currentSearchController = bioMatcherConfigService.getServerInfoByServerHost(
					HostnameUtil.getHostname(), HostnameUtil.getIpAddress(), BioComponentType.SC);
			
	          if (currentSearchController == null) {
	                currentSearchController = bioMatcherConfigService.getServerInfoByServerHost(HostnameUtil.LOCAL_HOSTNAME, HostnameUtil.LOCAL_IPADDRESS, BioComponentType.SC);
	                if (currentSearchController == null) {
	                    logger.warn("Search Controller is not configured for ipAddress : " + HostnameUtil.getIpAddress() + " or hostname: " + HostnameUtil.getHostname());
	                    return;
	                }
	            }	

			searchControllerId = currentSearchController.getServerId();

			LocalServerComponents.setSearchControllerId(searchControllerId);
			
	           // There should be on mandatory extraction controller assigned on search controller server
            BioServerInfo currentExtractController = bioMatcherConfigService.getServerInfoByServerHost(HostnameUtil.getHostname(), HostnameUtil.getIpAddress(), BioComponentType.EC);
            if (currentExtractController == null) {
                currentExtractController = bioMatcherConfigService.getServerInfoByServerHost(HostnameUtil.LOCAL_HOSTNAME, HostnameUtil.LOCAL_IPADDRESS, BioComponentType.EC);
                if (currentExtractController == null) {
                    CommonLogger.STATUS_LOG.warn("Extraction Controller should also be configured on same search controller server: " + searchControllerId + ", Extraction Controller is not configured for ipAddress : " + HostnameUtil.getIpAddress() + " or hostname: " + HostnameUtil.getHostname());
                }
            }

			logger.info("In afterPropertiesSet : searchControllerId: " + searchControllerId);

			buildSearchControllerCluster();

			logger.info("In afterPropertiesSet : searchControllerId: " + searchControllerId
					+ ", After buildSearchControllerCluster");

			configureClusterObjects();

			logger.info("In afterPropertiesSet : searchControllerId: " + searchControllerId
					+ ", After configureClusterObjects");

			CommonTaskScheduler.schedule(new SegmentChangeSetBacklogTask(), 1, TimeUnit.MINUTES);

			CommonTaskScheduler.schedule(new SearchBrokerFailoverTask(), 1, TimeUnit.MINUTES);

			{
				Supplier<Integer> eventVersionAssignmentConcurrencyCountSupplier = BioParameterService
						.getIntSupplier("EVENT_VERSION_ASSIGNMENT_THREAD_CONCURRENCY", "DEFAULT", 10);

				Consumer<Integer> consumer = (segmentId) -> {
					biometricEventVersionAssignmentTask.assignEventDataVersion(segmentId);
				};

				eventVersionAssignmentProcesseor = new ConcurrentSetProcessor<>("SC_EVT_VER_ASSIGN", consumer,
						eventVersionAssignmentConcurrencyCountSupplier);

				CommonTaskScheduler.scheduleWithFixedDelay(biometricEventVersionAssignmentTask, 100, 500,
						TimeUnit.MILLISECONDS);
			}

			{
				// CommonTaskScheduler.scheduleWithFixedDelay(syncEventsToRemoteSiteTask,
				// 500, 500, TimeUnit.MILLISECONDS);
			}

			{
				Supplier<Integer> searchBrokerNotificationConcurrencyCountSupplier = BioParameterService
						.getIntSupplier("SEARCH_BROKER_NOTIFICATION_PROCESSOR_THREAD_CONCURRENCY", "DEFAULT", 5);

				Consumer<Integer> consumer = (segmentId) -> {
					searchBrokerNotificationProcessorTask.processSearchBrokerNotifications(segmentId);
				};

				searchBrokerNotificationProcessor = new ConcurrentSetProcessor<>("SEG_NOTIFY_PROCESSOR", consumer,
						searchBrokerNotificationConcurrencyCountSupplier);

				CommonTaskScheduler.scheduleWithFixedDelay(searchBrokerNotificationProcessorTask, 100, 500,
						TimeUnit.MILLISECONDS);
			}

			{
				Supplier<Integer> segmentWriterConcurrencyCountSupplier = BioParameterService
						.getIntSupplier("SEGMENT_FILE_WRITER_THREAD_CONCURRENCY", "DEFAULT", 3);

				segmentFileWriterExecutor = new ConcurrentExecutor("SC_SEG_FILE_WRITER_WORKER",
						new SegmentFileWriterTask(), segmentWriterConcurrencyCountSupplier);
				segmentFileWriterExecutor.start();
			}

			Supplier<Set<String>> concurrencyGroupIdSetSupplier = () -> {
				try {
					return bioMatcherConfigService.getCapacityGroupSearchNodeIdListMap().keySet();
				} catch (Throwable th) {
					logger.error("Error in concurrencyGroupIdSetSupplier: " + th.getMessage(), th);
				}
				return Collections.emptySet();
			};

			// Create parameter with default value
			boolean isFunctionCapacityGroupControlEnabled = bioParameterService
					.getParameterValue("FUNCTION_CAPACITY_GROUP_CONTROL_ENABLED_FLAG", "DEFAULT", false);
			long searchBrokerFailoverDelayMilli = bioParameterService
					.getParameterValue("SEARCH_BROKER_FAILOVER_DELAY_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(2));
			String segmentChangeSetStorageBasePath = bioParameterService.getParameterValue(
					"SEGMENT_CHANGE_SET_STORAGE_PATH", "DEFAULT",
					new File(System.getProperty("user.home"), "storage/segchangesets/data/").getAbsolutePath());
			String fullSegmentStorageBasePath = bioParameterService.getParameterValue("FULL_SEGMENT_STORAGE_PATH",
					"DEFAULT",
					new File(System.getProperty("user.home"), "storage/segmentfiles/data/").getAbsolutePath());
		}
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void memberAdded(MembershipEvent membershipEvent) {
		InetSocketAddress socketAddress = membershipEvent.getMember().getSocketAddress();
		CommonLogger.STATUS_LOG.info("In BioClusteredSearchControllerManagerImpl.memberAdded: "
				+ membershipEvent.getEventType() + ", SocketAddress: " + socketAddress + ", memberHostname: "
				+ socketAddress.getHostName() + ", memberIpAddress: " + socketAddress.getAddress().getHostAddress());

	}

	@Override
	public void memberRemoved(MembershipEvent membershipEvent) {
		InetSocketAddress socketAddress = membershipEvent.getMember().getSocketAddress();
		CommonLogger.STATUS_LOG.info("In BioClusteredSearchControllerManagerImpl.memberRemoved: "
				+ membershipEvent.getEventType() + ", SocketAddress: " + socketAddress + ", memberHostname: "
				+ socketAddress.getHostName() + ", memberIpAddress: " + socketAddress.getAddress().getHostAddress());
		handlerMemberDown(socketAddress.getHostName(), socketAddress.getAddress().getHostAddress());
	}

	@Override
	public void memberAttributeChanged(MemberAttributeEvent memberAttributeEvent) {
	}

	private void handlerMemberDown(String memberHostname, String memberIpAddress) {
		CommonLogger.STATUS_LOG.warn(
				"In handlerMemberDown : memberHostname: " + memberHostname + ", memberIpAddress: " + memberIpAddress);

		try {
			BioServerInfo searchController = bioMatcherConfigService.getServerInfoByServerHost(memberHostname,
					memberIpAddress, BioComponentType.SC);
			if (searchController == null) {
				logger.warn("Search Controller cannot find the BioServerInfo for memberHostname : " + memberHostname
						+ ", memberIpAddress: " + memberIpAddress);
				return;
			}

			if (BioServerState.STANDBY.equals(searchController.getServerState())) {
				return;
			}

			final String searchControllerMemberId = searchController.getServerId();

			ILock lock = hazelcastInstance.getLock("SC_CLUSTER_LOCK");
			lock.lock();
			try {
				if (matcherFunctionControlUtil != null) {
					matcherFunctionControlUtil.releaseControllerFunctionLoad(searchControllerMemberId);
				}
				if (scSearchNodePartitionedLoadMap != null) {
					ISet<String> snCapacityGroupKeySet = hazelcastInstance.getSet("SN_CAPACITY_GROUP_KEY_SET");
					for (String snCapacityGroupKey : snCapacityGroupKeySet) {
						String splitParts[] = snCapacityGroupKey.split("\\|");
						String searchNodeId = splitParts[0];
						String capacityGroupId = splitParts[1];

						SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo = scSearchNodePartitionedLoadMap
								.getValue(new TriKey<String, String, String>(searchControllerMemberId, searchNodeId,
										capacityGroupId));
						int scCurrentLoad = searchNodeLoadInfo.getScCurrentLoad();
						if (scCurrentLoad > 0) {
							searchNodeLoadInfo.releaseScCurrentLoad();
						}
						CommonLogger.STATUS_LOG.info("In handlerMemberDown: After releasing scCurrentLoad: "
								+ scCurrentLoad + " from searchControllerMemberId: " + searchControllerMemberId
								+ ", searchNodeId: " + searchNodeId + ", capacityGroupId: " + capacityGroupId
								+ ", currentLoad: " + searchNodeLoadInfo.getCurrentLoadFromReader());
					}
				}
			} finally {
				lock.unlock();
				CommonLogger.STATUS_LOG.info("In handlerMemberDown finally: searchControllerMemberId: "
						+ searchControllerMemberId + ", clusterMemberSize: "
						+ hazelcastInstance.getCluster().getMembers().size() + ", localMember: "
						+ hazelcastInstance.getCluster().getLocalMember().getSocketAddress().getHostName());
			}
		} catch (Throwable th) {
			logger.error("Error in handlerMemberDown : memberHostname: " + memberHostname + ", memberIpAddress: "
					+ memberIpAddress + " : " + th.getMessage(), th);
		}
	}

	@Override
	public void clientConnected(Client client) {
		InetSocketAddress socketAddress = client.getSocketAddress();
		CommonLogger.STATUS_LOG.info("In BioClusteredSearchControllerManagerImpl.clientConnected: "
				+ client.getClientType() + ", SocketAddress: " + socketAddress + ", clientHostname: "
				+ socketAddress.getHostName() + ", clientIpAddress: " + socketAddress.getAddress().getHostAddress());

		SpringCacheManager cacheManager = (SpringCacheManager) SpringServiceManager.getBean("methodCacheManager");
		cacheManager.removeAll();

		try {
			BioServerInfo searchBroker = bioMatcherConfigService.getServerInfoByServerHost(socketAddress.getHostName(),
					socketAddress.getAddress().getHostAddress(), BioComponentType.SB);
			if (searchBroker == null) {
				logger.warn("Search Broker is not configured for ipAddress : "
						+ socketAddress.getAddress().getHostAddress() + " or hostname: " + socketAddress.getHostName());
			} else {
				ServerStatusMonitor.notifyOnline(BioComponentType.SB, searchBroker.getServerId());
			}
		} catch (Throwable th) {
			logger.error("Error during processing BioClusteredSearchControllerManagerImpl.clientConnected for "
					+ client.getClientType() + ", SocketAddress: " + socketAddress + ", clientHostname: "
					+ socketAddress.getHostName() + ", clientIpAddress: " + socketAddress.getAddress().getHostAddress()
					+ " : " + th.getMessage(), th);
		}
	}

	@Override
	public void clientDisconnected(Client client) {
		InetSocketAddress socketAddress = client.getSocketAddress();
		CommonLogger.STATUS_LOG.info("In BioClusteredSearchControllerManagerImpl.clientDisconnected: "
				+ client.getClientType() + ", SocketAddress: " + socketAddress + ", clientHostname: "
				+ socketAddress.getHostName() + ", clientIpAddress: " + socketAddress.getAddress().getHostAddress());

		try {
			BioServerInfo searchBroker = bioMatcherConfigService.getServerInfoByServerHost(socketAddress.getHostName(),
					socketAddress.getAddress().getHostAddress(), BioComponentType.SB);
			if (searchBroker == null) {
				logger.warn("Search Broker is not configured for ipAddress : "
						+ socketAddress.getAddress().getHostAddress() + " or hostname: " + socketAddress.getHostName());
			} else {
				notifySearchBrokerOffline(searchBroker.getServerId());

				CommonLogger.STATUS_LOG.warn("Detected Search Broker client disconnection for searchBrokerId: "
						+ searchBroker.getServerId());
				long searchBrokerFailoverDelayMilli = bioParameterService.getParameterValue(
						"SEARCH_BROKER_FAILOVER_DELAY_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(2));
				searchBrokerFailoverQueue
						.add(new DelayedItem<String>(searchBroker.getServerId(), searchBrokerFailoverDelayMilli));
			}
		} catch (Throwable th) {
			logger.error("Error during processing BioClusteredSearchControllerManagerImpl.clientDisconnected for "
					+ client.getClientType() + ", SocketAddress: " + socketAddress + ", clientHostname: "
					+ socketAddress.getHostName() + ", clientIpAddress: " + socketAddress.getAddress().getHostAddress()
					+ " : " + th.getMessage(), th);
		}
	}

	public MatcherFunctionControlUtil getMatcherFunctionControlUtil() {
		return matcherFunctionControlUtil;
	}

	public BiometricEventVersionAssignmentTask getBiometricEventVersionAssignmentTask() {
		return biometricEventVersionAssignmentTask;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

}
