package com.nec.biomatcher.identifier.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.bioevent.BiometricIdService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.util.SegmentationUtil.SegmentFileHeaderConstants;

public class SegmentFileReader {
	private static final Logger logger = Logger.getLogger(SegmentFileReader.class);

	private Integer segmentId;
	private Path segmentFilePath;

	public SegmentFileReader(Integer segmentId) {
		this.segmentId = segmentId;
	}

	private void buildSegmentFilePath() throws Exception {
		try {
			synchronized (SegmentFileReader.this) {
				if (segmentFilePath == null) {
					segmentFilePath = SegmentationUtil.GET_SEGMENT_FILE_PATH_FUNCTION.apply(segmentId);
				}
			}

		} catch (Throwable th) {
			logger.error("Error in SegmentFileReader.buildSegmentFilePath for segmentId: " + segmentId + " : "
					+ th.getMessage(), th);
			throw new Exception("Error in SegmentFileReader.buildSegmentFilePath for segmentId: " + segmentId + " : "
					+ th.getMessage(), th);
		}
	}

	public boolean checkExists() {
		try {
			if (segmentFilePath == null) {
				buildSegmentFilePath();
			}

			return segmentFilePath != null && Files.exists(segmentFilePath);
		} catch (Throwable th) {
			logger.error("Error in SegmentFileReader.checkExists for segmentId: " + segmentId + " : " + th.getMessage(),
					th);
		}
		return false;
	}

	public boolean isValid(long segmentVersion) {
		try {
			if (segmentFilePath == null) {
				buildSegmentFilePath();
			}

			if (!checkExists()) {
				return false;
			}

			BiometricIdService biometricIdService = SpringServiceManager.getBean("biometricIdService");
			BioMatchManagerService bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");
			BioMatcherConfigService bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");

			BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatchManagerService.getMatcherSegmentInfo(segmentId);
			if (bioMatcherSegmentInfo == null) {
				logger.error("Invalid segmentId specified, BioMatcherSegmentInfo is not configured for segmentId: "
						+ segmentId);
				return false;
			}

			BiometricIdInfo biometricIdInfo = biometricIdService.getBiometricIdInfoBySegmentId(segmentId);
			if (biometricIdInfo == null) {
				logger.error(
						"Invalid segmentId specified, BiometricIdInfo is not configured for segmentId: " + segmentId);
				return false;
			}

			BioMatcherBinInfo bioMatcherBinInfo = bioMatcherConfigService
					.getMatcherBinInfo(bioMatcherSegmentInfo.getBinId());

			final MeghaTemplateParser meghaTemplateParser = bioMatcherConfigService.getBinIdMeghaTemplateParserMap()
					.get(bioMatcherSegmentInfo.getBinId());

			int templateSize = meghaTemplateParser.getTemplateDataSize();

			long fileSize = SegmentFileHeaderConstants.HEADER_SIZE
					+ (biometricIdInfo.getEndBiometricId() - Math.max(1L, biometricIdInfo.getStartBiometricId()) + 1)
							* templateSize;

			File segmentFile = segmentFilePath.toFile();
			if (segmentFile.length() != fileSize) {
				logger.error("Invalid segment file size: " + segmentFile.length() + ", expectedSize : " + fileSize
						+ " for segmentId : " + segmentId + ", segmentFilePath: " + segmentFile.getAbsolutePath()
						+ ", startBiometricId: " + Math.max(1L, biometricIdInfo.getStartBiometricId())
						+ ", endBiometricId: " + biometricIdInfo.getEndBiometricId() + ", templateType: "
						+ bioMatcherBinInfo.getTemplateType() + ", templateSize: " + templateSize + ", HEADER_SIZE: "
						+ SegmentFileHeaderConstants.HEADER_SIZE);
				return false;
			}

			try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(segmentFilePath.toFile()))) {
				ByteBuffer headerBuf = ByteBuffer.allocate(SegmentFileHeaderConstants.HEADER_SIZE);

				int toReadCount = SegmentFileHeaderConstants.HEADER_SIZE;
				byte[] outBuf = new byte[SegmentFileHeaderConstants.HEADER_SIZE];
				int readCount = 0;
				while (toReadCount > 0 && (readCount = in.read(outBuf, 0, toReadCount)) >= 0) {
					headerBuf.put(outBuf, 0, readCount);
					toReadCount = toReadCount - readCount;
				}

				headerBuf.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
				headerBuf.position(0);

				int templateTypeCode = headerBuf.getInt();
				long startBiometricId = headerBuf.getLong();
				long endBiometricId = headerBuf.getLong();
				long maxEventSegmentVersion = headerBuf.getLong();
				byte maxEventCount = headerBuf.get();

				if (!biometricIdInfo.getStartBiometricId().equals(startBiometricId)) {
					logger.error("Start biometricId dosnt match for segmentId: " + segmentId
							+ ", configStartBiometricId: " + biometricIdInfo.getStartBiometricId()
							+ ", startBiometricId: " + startBiometricId + ", segmentFilePath: " + segmentFilePath);
					return false;
				}
				if (!biometricIdInfo.getEndBiometricId().equals(endBiometricId)) {
					logger.error("Start biometricId dosnt match for segmentId: " + segmentId
							+ ", configEndBiometricId: " + biometricIdInfo.getEndBiometricId() + ", endBiometricId: "
							+ endBiometricId + ", segmentFilePath: " + segmentFilePath);
					return false;
				}

				if (segmentVersion > 0) {
					if (segmentVersion > maxEventSegmentVersion) {
						logger.warn("Segment file is older than required segment version for segmentId: " + segmentId
								+ ", requiredSegmentVersion: " + segmentVersion + ", maxEventSegmentVersion: "
								+ maxEventSegmentVersion + ", segmentFilePath: " + segmentFilePath);
						return false;
					}
				}

				return true;
			}

		} catch (Throwable th) {
			logger.error("Error in SegmentFileReader.isValid for segmentId: " + segmentId + " : " + th.getMessage(),
					th);
		}
		return false;
	}

	public void transferSegmentData(HttpServletResponse response) throws Exception {
		if (segmentFilePath == null) {
			buildSegmentFilePath();
		}

		BioParameterService bioParameterService = SpringServiceManager.getBean("bioParameterService");
		BiometricIdService biometricIdService = SpringServiceManager.getBean("biometricIdService");
		BioMatcherConfigService bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		BioMatchManagerService bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");

		int readBufferSize = bioParameterService.getParameterValue("SEGMENT_FILE_TRANSFER_READ_BUFFER_SIZE", "DEFAULT",
				16 * 1024);
		boolean useNioFlag = bioParameterService.getParameterValue("SEGMENT_FILE_TRANSFER_USE_NIO_FLAG", "DEFAULT",
				false);

		BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatchManagerService.getMatcherSegmentInfo(segmentId);
		if (bioMatcherSegmentInfo == null) {
			throw new IOException(
					"Invalid segmentId specified, BioMatcherSegmentInfo is not configured for segmentId: " + segmentId);
		}

		BiometricIdInfo biometricIdInfo = biometricIdService.getBiometricIdInfoBySegmentId(segmentId);
		if (biometricIdInfo == null) {
			throw new IOException(
					"Invalid segmentId specified, BiometricIdInfo is not configured for segmentId: " + segmentId);
		}

		Map<Integer, Integer> binIdMaxEventCountMap = bioMatcherConfigService.getBinIdMaxEventCountMap();

		if (!Files.exists(segmentFilePath)) {
			throw new IOException("Segment file does not exists for segmentId: " + segmentId + ", segmentFilePath: "
					+ segmentFilePath.toFile().getAbsolutePath());
		}

		if (useNioFlag) {

			try (InputStream fis = Files.newInputStream(segmentFilePath)) {

				long segmentVersion = readHeaderAndGetSegmentVersion(fis);

				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition", "attachment;filename=" + segmentId);
				response.setHeader("segmentId", segmentId.toString());
				response.setHeader("version", String.valueOf(segmentVersion));
				response.setHeader("bioIdBegin", biometricIdInfo.getStartBiometricId().toString());
				response.setHeader("bioIdEnd", biometricIdInfo.getEndBiometricId().toString());
				response.setHeader("maxEventCount",
						binIdMaxEventCountMap.getOrDefault(biometricIdInfo.getBinId(), 1).toString());

				try (ReadableByteChannel inChannel = Channels.newChannel(fis);
						WritableByteChannel outChannel = Channels.newChannel(response.getOutputStream())) {

					ByteBuffer buffer = ByteBuffer.allocateDirect(readBufferSize);
					while (inChannel.read(buffer) >= 0 || buffer.position() > 0) {
						buffer.flip();
						outChannel.write(buffer);
						buffer.compact();
					}
				}
			}
		} else {
			try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(segmentFilePath.toFile()))) {

				long segmentVersion = readHeaderAndGetSegmentVersion(in);

				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition", "attachment;filename=" + segmentId);
				response.setHeader("segmentId", segmentId.toString());
				response.setHeader("version", String.valueOf(segmentVersion));
				response.setHeader("bioIdBegin", biometricIdInfo.getStartBiometricId().toString());
				response.setHeader("bioIdEnd", biometricIdInfo.getEndBiometricId().toString());
				response.setHeader("maxEventCount",
						binIdMaxEventCountMap.getOrDefault(biometricIdInfo.getBinId(), 1).toString());

				try (BufferedOutputStream out = new BufferedOutputStream(response.getOutputStream())) {
					int readCount = 0;
					byte[] outBuf = new byte[readBufferSize];
					while ((readCount = in.read(outBuf)) >= 0) {
						out.write(outBuf, 0, readCount);
					}

					out.flush();
				}
			}
		}
	}

	private long readHeaderAndGetSegmentVersion(InputStream in) throws Exception {
		ByteBuffer headerBuf = ByteBuffer.allocate(SegmentFileHeaderConstants.HEADER_SIZE);

		int toReadCount = SegmentFileHeaderConstants.HEADER_SIZE;
		byte[] outBuf = new byte[SegmentFileHeaderConstants.HEADER_SIZE];
		int readCount = 0;
		while (toReadCount > 0 && (readCount = in.read(outBuf, 0, toReadCount)) >= 0) {
			headerBuf.put(outBuf, 0, readCount);
			toReadCount = toReadCount - readCount;
		}

		headerBuf.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		headerBuf.position(0);

		int templateTypeCode = headerBuf.getInt();
		long startBiometricId = headerBuf.getLong();
		long endBiometricId = headerBuf.getLong();
		long maxEventSegmentVersion = headerBuf.getLong();
		byte maxEventCount = headerBuf.get();

		logger.info("In readHeaderAndGetSegmentVersion: segmentId: " + segmentId + ", templateTypeCode: "
				+ templateTypeCode + ", startBiometricId: " + startBiometricId + ", endBiometricId: " + endBiometricId
				+ ", maxEventSegmentVersion: " + maxEventSegmentVersion + ", maxEventCount: " + maxEventCount);

		return maxEventSegmentVersion;
	}

	public Path getSegmentFilePath() {
		return segmentFilePath;
	}

}
