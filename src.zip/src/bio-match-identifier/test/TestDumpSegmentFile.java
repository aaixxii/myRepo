import java.io.File;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.nec.biomatcher.identifier.util.SegmentationUtil.SegmentFileHeaderConstants;

public class TestDumpSegmentFile {
    private static final Logger logger = Logger.getLogger(TestDumpSegmentFile.class);
    
    public static final Map<Integer, Integer> templateSizeMap = new HashMap<>();
    static {
        templateSizeMap.put(1, 2664);
        templateSizeMap.put(11, 3648);
        templateSizeMap.put(12, 4224);
        templateSizeMap.put(22, 6528);
        templateSizeMap.put(31, 16132);
        templateSizeMap.put(32, 32148);
        templateSizeMap.put(33, 246464);
        templateSizeMap.put(34, 12545);
        templateSizeMap.put(35, 25634);
        templateSizeMap.put(36, 51148);
        templateSizeMap.put(37, 190607);
        templateSizeMap.put(38, 245915);
        templateSizeMap.put(39, 164007);
        templateSizeMap.put(40, 4235);
    }
    
    public static void main(String args[]) throws Exception {
        dump();
    }
    
    public static void dump() throws Exception {
        
        File file = new File("C:\\Mahesh\\Work\\Projects\\MEGHA\\temp\\14");
        RandomAccessFile raf = new RandomAccessFile(file, "r");
        FileChannel fc = raf.getChannel();
        
        MappedByteBuffer mappedByteBuffer = fc.map(MapMode.READ_ONLY, 0, fc.size());
        
        mappedByteBuffer.position(0);
        int templateType = mappedByteBuffer.getInt();
        long startBioId = mappedByteBuffer.getLong();
        long endBioId = mappedByteBuffer.getLong();
        long maxEventSegmentVersion = mappedByteBuffer.getLong();
        byte maxEventCount = mappedByteBuffer.get();
        
        //Pad 3 bytes
        mappedByteBuffer.get(new byte[3]);

        int templateSize = templateSizeMap.get(templateType);
        
        System.out.println("templateType: "+templateType+", startBioId: "+startBioId+", endBioId: "+endBioId+", maxEventSegmentVersion: "+maxEventSegmentVersion+", maxEventCount: "+maxEventCount+", templateSize: "+templateSize);
        
        int SEGMENT_FILE_HEADER_SIZE = SegmentFileHeaderConstants.HEADER_SIZE;
        long fcStartPosition = SEGMENT_FILE_HEADER_SIZE;
        int mappedRegionSize =  (int)((endBioId - startBioId +1) * templateSize);
        
        mappedByteBuffer = fc.map(MapMode.READ_ONLY, fcStartPosition, mappedRegionSize);
        mappedByteBuffer.position(0);
        
        byte[] templateRecord = new byte[templateSize];
        
        for(long biometricId = startBioId;biometricId<=endBioId;biometricId++) {
            mappedByteBuffer.position((int) ((biometricId - startBioId) * templateSize));
            mappedByteBuffer.get(templateRecord);
            if(templateRecord[2]==0) {
                //System.out.println("biometricId: "+ TemplateDataUtil.getBiometricId(ByteBuffer.wrap(templateRecord)));
            }
        }
        
        fc.close();
        raf.close();
        
    }
}
