//import static com.nec.biomatcher.identifier.util.segmentation.SegmentChangeSetFileConstants.HEADER_SIZE;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;

import org.apache.log4j.Logger;

public class TestDumpSegmentChangeset {
    private static final Logger logger = Logger.getLogger(TestDumpSegmentChangeset.class);
    
    public static void main(String args[]) throws Exception {
        dump();
    }
    
    public static void dump() throws Exception {
        long segementVersionAfter = 11001;
        /*
        File file = new File("C:\\Mahesh\\Work\\Projects\\MEGHA\\temp\\102_11001_12000.dat.bak");
        RandomAccessFile raf = new RandomAccessFile(file, "r");
        FileChannel fc = raf.getChannel();
        
        MappedByteBuffer mappedByteBuffer = fc.map(MapMode.READ_ONLY, 0, fc.size());
       
        int segmentId = mappedByteBuffer.getInt(HeaderFieldPositions.SEGMENT_ID);
        int templateSize = mappedByteBuffer.getInt(HeaderFieldPositions.TEMPLATE_SIZE);
        long firstRecordSegmentVersion = mappedByteBuffer.getLong(HeaderFieldPositions.SEG_VERSION_RANGE_FIRST);
        long lastRecordSegmentVersion = mappedByteBuffer.getLong(HeaderFieldPositions.SEG_VERSION_RANGE_LAST);
        int recordSize = RecordFieldPositions.TEMPLATE_DATA + templateSize;
                
        
        int nextRecordIndex = mappedByteBuffer.getInt(HeaderFieldPositions.NEXT_RECORD_INDEX);
        int readFromRecordIndex = -1;
        int lastValidRecordIndex = -1;
        while (nextRecordIndex > 0) {
            int previousRecordOffset = HEADER_SIZE + ((nextRecordIndex - 1) * recordSize);

            if (lastValidRecordIndex == -1) {
                if (mappedByteBuffer.get(previousRecordOffset + RecordFieldPositions.COMMIT_FLAG) == CommitFlag.COMMIT) {
                    lastValidRecordIndex = nextRecordIndex - 1;
                } else {
                    logger.warn("In getSegmentChangeSetAfter: Invalid record found in segmentReader for file: " + file + " at " + (previousRecordOffset + RecordFieldPositions.COMMIT_FLAG) + " for recordIndex: " + (nextRecordIndex - 1));
                }
            }

            if (lastValidRecordIndex > -1) {
                long previousRecordSegmentVersion = mappedByteBuffer.getLong(previousRecordOffset + RecordFieldPositions.SEGMENT_VERSION);

                if (segementVersionAfter >= previousRecordSegmentVersion) {
                    break;
                }
                readFromRecordIndex = nextRecordIndex - 1;
            }

            nextRecordIndex--;
        }
        
        byte[] templateBuf = new byte[templateSize];
        int changeCount = 0;
        long startSegmentVersion = Long.MAX_VALUE;
        long endSegmentVersion = Long.MIN_VALUE;

        int maxBufferSize = (1 + (lastValidRecordIndex - readFromRecordIndex)) * recordSize;

        // To achieve lock free approach, i need to duplicate the buffer since retrieving bulk bytes needs changing the position of buffer
        ByteBuffer readOnlyBuffer = mappedByteBuffer.duplicate();

        ByteArrayOutputStream baos = new ByteArrayOutputStream(maxBufferSize);
        DataOutputStream output = new DataOutputStream(baos);
        try {
            while (readFromRecordIndex <= lastValidRecordIndex) {
                int recordOffset = HEADER_SIZE + (readFromRecordIndex * recordSize);

                long recordSegmentVersion = readOnlyBuffer.getLong(recordOffset + RecordFieldPositions.SEGMENT_VERSION);
                byte recordType = readOnlyBuffer.get(recordOffset + RecordFieldPositions.RECORD_TYPE);
                long biometricId = readOnlyBuffer.getLong(recordOffset + RecordFieldPositions.BIOMETRIC_ID);
                System.out.println("recordSegmentVersion: "+recordSegmentVersion+", biometricId: "+biometricId+", recordType: "+recordType);
                //Skip invalid data
                if(recordSegmentVersion<=0 || biometricId<=0) {
                    readFromRecordIndex++;
                    continue;
                }
                
                startSegmentVersion = Math.min(startSegmentVersion, recordSegmentVersion);
                endSegmentVersion = Math.max(endSegmentVersion, recordSegmentVersion);

                output.writeLong(recordSegmentVersion);
                output.writeByte(recordType == RecordType.INSERT ? 0 : 1);
                output.writeLong(biometricId);

                if (recordType == RecordType.INSERT) {
                    readOnlyBuffer.position(recordOffset + RecordFieldPositions.TEMPLATE_DATA);
                    readOnlyBuffer.get(templateBuf, 0, templateBuf.length);

                    output.write(templateBuf);

                    maxBufferSize = maxBufferSize - recordSize;
                }

                changeCount++;
                readFromRecordIndex++;
            }
        } finally {
            IOUtils.closeQuietly(output);
            IOUtils.closeQuietly(baos);
        }
        */
    }
}
