package com.nec.biomatcher.identifier.searchcontroller.queueing;

import java.util.Date;

import javax.xml.bind.JAXBException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.nec.biomatcher.identifier.util.JaxBUtil;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;

public class JaxBUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testUnmarshal() throws JAXBException {
		SyncJobResultDto syncJobResultDto = new SyncJobResultDto();
		syncJobResultDto.setJobId("1000");
		syncJobResultDto.setStatus(BioJobStatus.COMPLETED);
		ErrorMessageDto error = new ErrorMessageDto();
		error.setErrorCode("testError");
		error.setErrorMessage("test error message");
		error.setErrorDateTime(new Date());
		syncJobResultDto.getErrorList().add(error);
		JaxBUtil<SyncJobResultDto> jaxb = new JaxBUtil<SyncJobResultDto>();
		String result = jaxb.marshal(SyncJobResultDto.class, syncJobResultDto);
		SyncJobResultDto syncResult = jaxb.unmarshal(SyncJobResultDto.class, result);
		Assert.assertEquals("1000", syncResult.getJobId());
		Assert.assertEquals(BioJobStatus.COMPLETED.name(), syncResult.getStatus().name());

	}

	@Test
	public void testMarshal() throws JAXBException {
		SyncJobResultDto syncJobResultDto = new SyncJobResultDto();
		syncJobResultDto.setJobId("1000");
		syncJobResultDto.setStatus(BioJobStatus.COMPLETED);
		ErrorMessageDto error = new ErrorMessageDto();
		error.setErrorCode("testError");
		error.setErrorMessage("test error message");
		error.setErrorDateTime(new Date());
		syncJobResultDto.getErrorList().add(error);
		JaxBUtil<SyncJobResultDto> jaxb = new JaxBUtil<SyncJobResultDto>();
		String resut = jaxb.marshal(SyncJobResultDto.class, syncJobResultDto);
		Assert.assertNotNull(resut);

	}

}
