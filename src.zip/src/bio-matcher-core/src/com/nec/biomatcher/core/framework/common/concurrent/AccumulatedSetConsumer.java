package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Collection;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.locks.Lock;
import java.util.function.Consumer;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Striped;
import com.nec.biomatcher.core.framework.common.CommonLogger;

public class AccumulatedSetConsumer<T> {
	private static final Logger logger = Logger.getLogger(AccumulatedSetConsumer.class);

	private final Striped<Lock> stripedLocks = Striped.lazyWeakLock(1024);
	private final ConcurrentSkipListSet<T> workingSet = new ConcurrentSkipListSet<>();
	private final String name;
	private final Consumer<T> consumer;
	private final DynamicSemaphore concurrencySemaphore;

	public AccumulatedSetConsumer(String name, Consumer<T> consumer) {
		this.name = name;
		this.consumer = consumer;
		this.concurrencySemaphore = null;
	}

	public AccumulatedSetConsumer(String name, Consumer<T> consumer, DynamicSemaphore concurrencySemaphore) {
		this.name = name;
		this.consumer = consumer;
		this.concurrencySemaphore = concurrencySemaphore;
	}

	public final void add(T value) {
		boolean addedFlag = workingSet.add(value);
		if (addedFlag) {
			executeConsumer(value);
		}
	}

	public final void addAll(Collection<T> values) {
		boolean addedFlag = workingSet.addAll(values);
		if (addedFlag) {
			executeConsumer(values);
		}
	}

	private final void executeConsumer(T value) {
		Lock lock = stripedLocks.get(value);
		if (lock.tryLock()) {
			try {
				boolean isRemovedFlag = workingSet.remove(value);
				if (isRemovedFlag) {
					try {
						consume(value);
					} catch (RuntimeException ex) {
						logger.error("Error in AccumulatedSetConsumer.executeConsumer: " + name + ", value: " + value
								+ ", err: " + ex.getMessage(), ex);
						throw ex;
					}
				}
			} finally {
				lock.unlock();
			}
		}
	}

	private final void executeConsumer(Collection<T> values) {
		RuntimeException ex = null;
		for (T value : values) {
			Lock lock = stripedLocks.get(value);
			if (lock.tryLock()) {
				try {
					boolean isRemovedFlag = workingSet.remove(value);
					if (isRemovedFlag) {
						try {
							consume(value);
						} catch (RuntimeException ex1) {
							ex = ex1;
						}
					}
				} finally {
					lock.unlock();
				}
			}
		}
		if (ex != null) {
			logger.error("Error in AccumulatedSetConsumer.executeConsumer: " + name + ", err: " + ex.getMessage(), ex);
			throw ex;
		}
	}

	private final void consume(T value) {
		if (concurrencySemaphore == null) {
			consumer.accept(value);
		} else {
			concurrencySemaphore.acquireUninterruptibly();
			try {
				consumer.accept(value);
			} finally {
				concurrencySemaphore.release();
			}
		}
	}

	public String getName() {
		return name;
	}
}
