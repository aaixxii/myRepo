package com.nec.biomatcher.core.framework.common.concurrent.semaphore;

import java.util.concurrent.Semaphore;

/**
 * The Class SimpleSemaphore.
 */
public final class SimpleSemaphore extends AbstractSemaphore {

	/** The semaphore. */
	private Semaphore semaphore;

	/** The max permits. */
	private int maxPermits;

	/**
	 * Instantiates a new simple semaphore.
	 *
	 * @param semaphoreId
	 *            the semaphore id
	 * @param maxPermits
	 *            the max permits
	 */
	public SimpleSemaphore(String semaphoreId, int maxPermits) {
		super(semaphoreId);
		semaphore = new Semaphore(maxPermits);
	}

	@Override
	public final void acquire() throws InterruptedException {
		semaphore.acquire();
	}

	@Override
	public final void release() {
		semaphore.release();
	}

	@Override
	public final void drainPermits() {
		semaphore.drainPermits();
	}

	@Override
	public final int availablePermits() {
		return semaphore.availablePermits();
	}

	@Override
	public final synchronized void setMaxPermits(int maxPermits) throws InterruptedException {
		int oldMaxPermits = this.maxPermits;
		if (oldMaxPermits < maxPermits) {
			semaphore.release(maxPermits - oldMaxPermits);
		} else if (oldMaxPermits > maxPermits) {
			semaphore.acquire(oldMaxPermits - maxPermits);
		}
	}
}
