package com.nec.biomatcher.core.framework.cache;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.google.common.cache.LoadingCache;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

/**
 * This class holds reference to cache manager object. This can be used to
 * manage cached objects.
 * 
 * @author Mahesh
 */
public class SpringCacheManager implements InitializingBean {

	/** The logger. */
	private static Logger logger = Logger.getLogger(SpringCacheManager.class);

	private static ConcurrentHashMap<String, com.google.common.cache.Cache> guavaCacheMap = new ConcurrentHashMap<>();

	/** The cache. */
	private Cache cache;

	public static void registerGuavaCache(String cacheKey, com.google.common.cache.Cache guavaCache) {
		guavaCacheMap.put(cacheKey, guavaCache);
	}

	/**
	 * Sets the cache.
	 *
	 * @param cache
	 *            the new cache
	 */
	public void setCache(Cache cache) {
		this.cache = cache;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(cache, "A cache is required. Use setCache(Cache) to provide one.");
		logger.info("Current SpringCacheManager: " + this.hashCode());
	}

	public synchronized void evictExpiredElements() {
		logger.info("In evictExpiredElements");
		try {
			cache.evictExpiredElements();
		} catch (Throwable th) {
			logger.error("Error during evictExpiredElements: " + th.getMessage(), th);
		}
	}

	/**
	 * Gets the keys.
	 *
	 * @return keys of cached objects
	 */
	public List getKeys() {
		return cache.getKeys();
	}

	public Element getCachedElement(String cacheKey) {
		return cache.get(cacheKey);
	}

	/**
	 * TODO: Not tested This method removes cached object with specified key.
	 *
	 * @param key
	 *            the key
	 */
	public void remove(String key) {
		cache.remove(key);
	}

	/**
	 * TODO: Not tested This method removes all cached objects.
	 */
	public void removeAll() {
		cache.removeAll();

		guavaCacheMap.forEach((cacheKey, guavaCache) -> {
			try {
				guavaCache.invalidateAll();
				logger.debug("After clearing guavaCache for cacheKey: " + cacheKey);
			} catch (Throwable th) {
				logger.error("Error clearing guavaCache for cacheKey: " + cacheKey + " : " + th.getMessage(), th);
			}
		});
	}

	/**
	 * TODO: Not tested This method remove cached objects with keys starting
	 * with specified keyStartsWith parameter.
	 *
	 * @param keyStartsWith
	 *            the key starts with
	 */
	public void removeKeysStartsWith(String keyStartsWith) {
		List<String> keys = cache.getKeys();
		if (keys != null) {
			for (String key : keys) {
				if (key.startsWith(keyStartsWith)) {
					cache.remove(key);
				}
			}
		}
	}

}
