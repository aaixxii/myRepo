package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.IntBinaryOperator;

public class CyclicIterator<T> implements Iterator<T> {
	private final AtomicInteger cyclicIndex = new AtomicInteger(-1);
	private final List<T> sourceColl;
	private final int size;
	private final IntBinaryOperator cyclicIndexFunction;

	public CyclicIterator(List<T> sourceColl) {
		this.sourceColl = sourceColl;
		this.size = sourceColl.size();
		this.cyclicIndexFunction = (oldVal, newVal) -> {
			int sumVal = oldVal + newVal;
			if (sumVal >= 0 && sumVal < size) {
				return sumVal;
			} else {
				return 0;
			}
		};
	}

	@Override
	public boolean hasNext() {
		return size > 0;
	}

	@Override
	public T next() {
		int index = cyclicIndex.accumulateAndGet(1, cyclicIndexFunction);
		return sourceColl.get(index);
	}
}
