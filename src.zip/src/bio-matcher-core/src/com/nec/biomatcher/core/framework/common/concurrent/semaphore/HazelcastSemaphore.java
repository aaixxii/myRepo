package com.nec.biomatcher.core.framework.common.concurrent.semaphore;

import com.hazelcast.core.ISemaphore;

/**
 * The Class HazelcastSemaphore.
 */
public final class HazelcastSemaphore extends AbstractSemaphore {

	/** The semaphore. */
	private final ISemaphore semaphore;

	/** The max permits. */
	private int maxPermits;

	/**
	 * Instantiates a new hazelcast semaphore.
	 *
	 * @param semaphoreId
	 *            the semaphore id
	 * @param semaphore
	 *            the semaphore
	 * @param maxPermits
	 *            the max permits
	 */
	public HazelcastSemaphore(String semaphoreId, ISemaphore semaphore, int maxPermits) {
		super(semaphoreId);
		this.semaphore = semaphore;
		this.maxPermits = maxPermits;
		semaphore.init(maxPermits);
	}

	@Override
	public final void acquire() throws InterruptedException {
		semaphore.acquire();
	}

	@Override
	public final void release() {
		semaphore.release();
	}

	@Override
	public final void drainPermits() {
		semaphore.drainPermits();
	}

	@Override
	public final int availablePermits() {
		return semaphore.availablePermits();
	}

	public final synchronized void setMaxPermits(int maxPermits) throws InterruptedException {
		int oldMaxPermits = this.maxPermits;
		if (oldMaxPermits < maxPermits) {
			semaphore.release(maxPermits - oldMaxPermits);
		} else if (oldMaxPermits > maxPermits) {
			semaphore.reducePermits(oldMaxPermits - maxPermits);
		}
	}
}
