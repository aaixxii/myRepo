package com.nec.biomatcher.core.framework.cache;

import java.util.function.BiFunction;
import java.util.function.Supplier;

import com.nec.biomatcher.core.framework.common.CheckedFunction;
import com.nec.biomatcher.core.framework.common.CheckedSupplier;

public interface FunctionalCacheService {

	@MethodCache
	public <K, V> V getCachedValue(K param, CheckedFunction<K, V> function) throws Throwable;

	@MethodCache
	public <K, V> V getCachedValue(K param, CheckedFunction<K, V> function, CacheExpiryParam cacheExpiryParam)
			throws Throwable;

	@MethodCache
	public <K, L, V> V getCachedValue(K param1, L param2, BiFunction<K, L, V> function);

	@MethodCache
	public <K, L, V> V getCachedValue(K param1, L param2, BiFunction<K, L, V> function,
			CacheExpiryParam cacheExpiryParam) throws Throwable;

	@MethodCache
	public <V> V getCachedValue(CheckedSupplier<V> supplier) throws Throwable;

	@MethodCache
	public <V> V getCachedValue(CheckedSupplier<V> supplier, CacheExpiryParam cacheExpiryParam) throws Throwable;

	@MethodCache
	public <V> V getUnCheckedCachedValue(Supplier<V> supplier);

	@MethodCache
	public <V> V getUnCheckedCachedValue(Supplier<V> supplier, CacheExpiryParam cacheExpiryParam);

}
