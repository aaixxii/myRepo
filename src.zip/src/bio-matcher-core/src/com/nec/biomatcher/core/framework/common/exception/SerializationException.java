package com.nec.biomatcher.core.framework.common.exception;

/**
 * The Class SerializationException.
 */
public class SerializationException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new serialization exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public SerializationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new serialization exception.
	 *
	 * @param message
	 *            the message
	 */
	public SerializationException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new serialization exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public SerializationException(Throwable cause) {
		super(cause);
	}

}
