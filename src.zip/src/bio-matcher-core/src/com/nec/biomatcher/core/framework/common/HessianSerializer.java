package com.nec.biomatcher.core.framework.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;

import org.apache.log4j.Logger;

import com.caucho.hessian.io.Hessian2Input;
import com.caucho.hessian.io.Hessian2Output;
import com.nec.biomatcher.core.framework.common.exception.SerializationException;

/**
 * The Class HessianSerializer.
 */
public class HessianSerializer {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(HessianSerializer.class);

	/**
	 * Marshal.
	 *
	 * @param obj
	 *            the obj
	 * @return the byte[]
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public static final byte[] marshal(Object obj) throws SerializationException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		marshal(obj, baos);
		return baos.toByteArray();
	}

	/**
	 * Marshal.
	 *
	 * @param obj
	 *            the obj
	 * @param out
	 *            the out
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public static final void marshal(Object obj, OutputStream out) throws SerializationException {
		Hessian2Output output = new Hessian2Output(out);
		try {
			output.writeObject(obj);
			output.flush();
		} catch (Throwable th) {
			throw new SerializationException(
					"Error in marshal for Class: " + obj.getClass().getName() + ": " + th.getMessage(), th);
		} finally {
			try {
				output.close();
			} catch (Throwable th) {
				logger.error("Error closing output while marshal: " + th.getMessage(), th);
			}
		}
	}

	/**
	 * Unmarshal.
	 *
	 * @param <T>
	 *            the generic type
	 * @param byteBuffer
	 *            the byte buffer
	 * @return the t
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public static final <T> T unmarshal(ByteBuffer byteBuffer) throws SerializationException {
		byte[] dataBuf = new byte[byteBuffer.position()];
		byteBuffer.get(dataBuf);
		return unmarshal(dataBuf, 0, dataBuf.length);
	}

	/**
	 * Unmarshal.
	 *
	 * @param <T>
	 *            the generic type
	 * @param dataBuf
	 *            the data buf
	 * @return the t
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public static final <T> T unmarshal(byte dataBuf[]) throws SerializationException {
		return unmarshal(dataBuf, 0, dataBuf.length);
	}

	/**
	 * Unmarshal.
	 *
	 * @param <T>
	 *            the generic type
	 * @param dataBuf
	 *            the data buf
	 * @param offset
	 *            the offset
	 * @param length
	 *            the length
	 * @return the t
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public static final <T> T unmarshal(byte dataBuf[], int offset, int length) throws SerializationException {
		return unmarshal(new ByteArrayInputStream(dataBuf, offset, length));
	}

	/**
	 * Unmarshal.
	 *
	 * @param <T>
	 *            the generic type
	 * @param in
	 *            the in
	 * @return the t
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public static final <T> T unmarshal(InputStream in) throws SerializationException {
		Hessian2Input input = new Hessian2Input(in);
		try {
			return (T) input.readObject();
		} catch (Throwable th) {
			throw new SerializationException("Error in unmarshal : " + th.getMessage(), th);
		} finally {
			try {
				input.close();
			} catch (Throwable th) {
				logger.error("Error closing input while unmarshal: " + th.getMessage(), th);
			}
		}
	}

}
