package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

public class ConcurrentValuedHashMap<K, V> extends ConcurrentHashMap<K, V> {
	private static final long serialVersionUID = 1L;

	private final Function<K, V> valueFunction;

	public ConcurrentValuedHashMap(Function<K, V> valueFunction) {
		this.valueFunction = valueFunction;
	}

	public final V getValue(K key) {
		V value = get(key);

		if (value == null) {
			do {
				value = computeIfAbsent(key, valueFunction);
			} while (value == null);
		}

		return value;
	}

}
