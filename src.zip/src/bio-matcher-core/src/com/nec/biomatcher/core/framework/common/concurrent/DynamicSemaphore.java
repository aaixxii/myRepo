package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.function.Supplier;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Striped;
import com.nec.biomatcher.core.framework.common.CommonLogger;

/**
 * DynamicSemaphore data structure allows semaphore permits to change
 * dynamically depending on the new permit value returned by the permit
 * supplier.
 * 
 * @author mreddy
 *
 */
public class DynamicSemaphore {
	private static final Logger logger = Logger.getLogger(DynamicSemaphore.class);
	private static final ConcurrentHashMap<String, DynamicSemaphore> DYNAMIC_SEMAPHORE_MAP = new ConcurrentHashMap<String, DynamicSemaphore>();
	private static final SemaphorePermitAdjuster SEMAPHORE_PERMIT_ADJUSTER = new SemaphorePermitAdjuster();
	private static final Striped<Lock> stripedLock = Striped.lazyWeakLock(100);

	private final String name;
	private final Semaphore semaphore;
	private final Supplier<Integer> permitsSupplier;
	private int maxPermits = 0;
	private int newMaxPermits = -1;

	private DynamicSemaphore(String name, Supplier<Integer> permitsSupplier) {
		this.name = name;
		this.semaphore = new Semaphore(0, true);
		this.permitsSupplier = permitsSupplier;

		try {
			maxPermits = permitsSupplier.get();
			semaphore.release(maxPermits);
		} catch (Throwable th) {
			logger.error("Error setting permits for DynamicSemaphore: " + name + " : " + th.getMessage(), th);
			// Permits will be set by adjuster
		}

		logger.info("DynamicSemaphore : " + name + " created with maxPermits: " + maxPermits);
	}

	public static DynamicSemaphore getInstance(String name, Supplier<Integer> permitsSupplier) {
		DynamicSemaphore dynamicSemaphore = DYNAMIC_SEMAPHORE_MAP.get(name);
		if (dynamicSemaphore == null) {
			Lock lock = stripedLock.get(name);
			lock.lock();
			try {
				dynamicSemaphore = DYNAMIC_SEMAPHORE_MAP.get(name);
				if (dynamicSemaphore == null) {
					dynamicSemaphore = new DynamicSemaphore(name, permitsSupplier);
					DYNAMIC_SEMAPHORE_MAP.put(name, dynamicSemaphore);
				}
			} finally {
				lock.unlock();
			}
		}
		return dynamicSemaphore;
	}

	public int getMaxPermits() {
		return maxPermits;
	}

	public final int acquiredCount() {
		return maxPermits - semaphore.availablePermits();
	}

	public final void acquire() throws InterruptedException {
		semaphore.acquire();
	}

	public final void release() {
		if (newMaxPermits > -1) {
			if (!reduceMaxPermit()) {
				semaphore.release();
			}
		} else {
			semaphore.release();
		}
	}

	public final int drainPermits() {
		return semaphore.drainPermits();
	}

	public final int availablePermits() {
		return semaphore.availablePermits();
	}

	public void acquireUninterruptibly() {
		semaphore.acquireUninterruptibly();
	}

	public boolean tryAcquire() {
		return semaphore.tryAcquire();
	}

	public boolean tryAcquire(long timeout, TimeUnit unit) throws InterruptedException {
		return semaphore.tryAcquire(timeout, unit);
	}

	public void acquire(int permits) throws InterruptedException {
		semaphore.acquire(permits);
	}

	public void acquireUninterruptibly(int permits) {
		semaphore.acquireUninterruptibly(permits);
	}

	public boolean tryAcquire(int permits) {
		return semaphore.tryAcquire(permits);
	}

	public boolean tryAcquire(int permits, long timeout, TimeUnit unit) throws InterruptedException {
		return semaphore.tryAcquire(permits, timeout, unit);
	}

	public void release(int permits) {
		if (newMaxPermits > -1) {
			if (permits <= 0) {
				return;
			}

			int reducedPermits = reduceMaxPermits(permits);
			if ((permits - reducedPermits) > 0) {
				semaphore.release(permits - reducedPermits);
			}
		} else {
			semaphore.release(permits);
		}
	}

	public final boolean hasQueuedThreads() {
		return semaphore.hasQueuedThreads();
	}

	public final int getQueueLength() {
		return semaphore.getQueueLength();
	}

	public final boolean hasPendingReleasePermits() {
		if (newMaxPermits > -1 && newMaxPermits < maxPermits) {
			return true;
		}
		return false;
	}

	public boolean tryReduceMaxPermitIfRequired() {
		if (newMaxPermits > -1 && newMaxPermits < maxPermits) {
			return reduceMaxPermit();
		}

		return false;
	}

	private synchronized boolean reduceMaxPermit() {
		if (newMaxPermits > -1) {
			if (newMaxPermits < maxPermits) {
				maxPermits--;
				logger.info("Adjusted DynamicSemaphore for name: " + name + " : maxPermits: " + maxPermits
						+ ", newMaxPermits: " + newMaxPermits);
				if (newMaxPermits >= maxPermits) {
					newMaxPermits = -1;
				}
				return true;
			} else {
				newMaxPermits = -1;
			}
		}
		return false;
	}

	private final synchronized int reduceMaxPermits(int permits) {
		if (newMaxPermits > -1 && permits > 0) {
			if (newMaxPermits < maxPermits) {
				int reducedPermits = 0;
				while (newMaxPermits < maxPermits && permits > 0) {
					maxPermits--;
					permits--;
					reducedPermits++;
					logger.info("Adjusted DynamicSemaphore for name: " + name + " : maxPermits: " + maxPermits
							+ ", newMaxPermits: " + newMaxPermits);
				}

				if (newMaxPermits >= maxPermits) {
					newMaxPermits = -1;
				}

				return reducedPermits;
			} else {
				newMaxPermits = -1;
			}
		}
		return 0;
	}

	private synchronized final void notifyMaxPermitsModified(int newMaxPermits) {
		CommonLogger.STATUS_LOG.info("In DynamicSemaphore.notifyMaxPermitsModified for name: " + name
				+ " : oldMaxPermits: " + maxPermits + ", newMaxPermits: " + newMaxPermits);
		if (newMaxPermits > maxPermits) {
			int oldMaxPermits = this.maxPermits;
			this.maxPermits = newMaxPermits;
			this.newMaxPermits = -1;
			semaphore.release(newMaxPermits - oldMaxPermits);
			CommonLogger.STATUS_LOG.info("Adjusted DynamicSemaphore for name: " + name + " : maxPermits: " + maxPermits
					+ ", newMaxPermits: " + newMaxPermits);
		} else if (newMaxPermits < maxPermits) {
			while (newMaxPermits < maxPermits && semaphore.tryAcquire()) {
				maxPermits--;
				CommonLogger.STATUS_LOG.info("Adjusted DynamicSemaphore for name: " + name + " : maxPermits: "
						+ maxPermits + ", newMaxPermits: " + newMaxPermits);
			}
			this.newMaxPermits = newMaxPermits < maxPermits ? newMaxPermits : -1;
		}
	}

	private static class SemaphorePermitAdjuster implements Runnable {
		public SemaphorePermitAdjuster() {
			schedule();
		}

		@Override
		public void run() {
			for (Map.Entry<String, DynamicSemaphore> entry : DYNAMIC_SEMAPHORE_MAP.entrySet()) {
				DynamicSemaphore dynamicSemaphore = entry.getValue();
				try {
					int newMaxPermits = dynamicSemaphore.permitsSupplier.get();
					if (dynamicSemaphore.maxPermits != newMaxPermits) {
						dynamicSemaphore.notifyMaxPermitsModified(newMaxPermits);
					}
				} catch (Throwable th) {
					logger.error("Error ajdusting permits for DynamicSemaphore: " + dynamicSemaphore.name + " : "
							+ th.getMessage(), th);
				}
			}
		}

		public void schedule() {
			CommonTaskScheduler.cancelTask(this, true);

			CommonTaskScheduler.scheduleWithFixedDelay(this, 60, 45, TimeUnit.SECONDS);
		}
	}

	@Override
	protected void finalize() throws Throwable {
		DYNAMIC_SEMAPHORE_MAP.clear();

		CommonTaskScheduler.cancelTask(SEMAPHORE_PERMIT_ADJUSTER, true);

		super.finalize();
	}
}
