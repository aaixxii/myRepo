package com.nec.biomatcher.core.framework.common.exception;

/**
 * The Class InvalidArgumentException.
 */
public class InvalidArgumentException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new invalid argument exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public InvalidArgumentException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new invalid argument exception.
	 *
	 * @param message
	 *            the message
	 */
	public InvalidArgumentException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new invalid argument exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public InvalidArgumentException(Throwable cause) {
		super(cause);
	}
}
