package com.nec.biomatcher.core.framework.cache;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * This is an Annotation class.
 * 
 * This annotation indicates to cache method results.
 * 
 * @author Mahesh
 */
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface MethodCache {

	/**
	 * If true, It will cache null value returned by the method.
	 *
	 * @return true, if successful
	 */
	public boolean cacheNullResult() default true;

	/**
	 * Time to live in seconds
	 * 
	 * @return int
	 */
	public int timeToLiveSeconds() default -1;

	/**
	 * Time to idle in seconds
	 * 
	 * @return int
	 */
	public int timeToIdleSeconds() default -1;

	public String timeToLiveSecondsParamName() default "";

	public String timeToIdleSecondsParamName() default "";

}