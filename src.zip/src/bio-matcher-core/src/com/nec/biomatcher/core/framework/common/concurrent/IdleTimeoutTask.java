package com.nec.biomatcher.core.framework.common.concurrent;

public abstract class IdleTimeoutTask implements Runnable {
	protected final long idleTimeoutMilli;
	private long lastActivityTimestampMilli = System.currentTimeMillis();

	public IdleTimeoutTask(long idleTimeoutMilli) {
		this.idleTimeoutMilli = idleTimeoutMilli;
	}

	protected final boolean isIdleTimeout() {
		return (System.currentTimeMillis() - lastActivityTimestampMilli) > idleTimeoutMilli;
	}

	protected final void notifyActivity() {
		lastActivityTimestampMilli = System.currentTimeMillis();
	}

}
