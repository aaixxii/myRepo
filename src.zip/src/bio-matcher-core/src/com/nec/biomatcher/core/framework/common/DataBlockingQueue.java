package com.nec.biomatcher.core.framework.common;

import java.util.Collection;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

import com.nec.biomatcher.core.framework.common.concurrent.BooleanLatch;

/**
 * This DataBlockingQueue data structure provides feature to wait for queue to
 * become empty or data to be available in queue.
 * 
 * @param <E>
 *            the element type
 */
public final class DataBlockingQueue<E> extends ConcurrentLinkedQueue<E> {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The data flag. */
	private final BooleanLatch dataFlag;

	/**
	 * Instantiates a new data blocking queue.
	 *
	 * @param name
	 *            the name
	 */
	public DataBlockingQueue(String name) {
		super();
		dataFlag = BooleanLatch.getInstance(name, false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.AbstractQueue#addAll(java.util.Collection)
	 */
	public final boolean addAll(Collection<? extends E> c) {
		boolean flag = super.addAll(c);
		dataFlag.setFlag(true);
		return flag;
	}

	public boolean offer(E e) {
		super.offer(e);
		dataFlag.setFlag(true);
		return true;
	}

	/**
	 * Put.
	 *
	 * @param e
	 *            the e
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public final void put(E e) throws InterruptedException {
		super.offer(e);
		dataFlag.setFlag(true);
	}

	public E poll() {
		E value = super.poll();
		dataFlag.setFlag(isEmpty());
		return value;
	}

	/**
	 * Take.
	 *
	 * @return the e
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public final E take() throws InterruptedException {

		E value = null;
		do {
			value = super.poll();
			dataFlag.setFlag(isEmpty());
			if (value == null) {
				dataFlag.waitForTrue();
			}
		} while (value == null);

		return value;
	}

	/**
	 * Wait for data.
	 */
	public final void waitForData() {
		dataFlag.waitForTrue();
	}

	/**
	 * Wait for data.
	 *
	 * @param timeoutInterval
	 *            the timeout interval
	 * @param timeUnit
	 *            the time unit
	 * @return true, if successful
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public final boolean waitForData(int timeoutInterval, TimeUnit timeUnit) throws InterruptedException {
		return dataFlag.waitForTrue(timeoutInterval, timeUnit);
	}

	/**
	 * Wait for empty.
	 */
	public final void waitForEmpty() {
		dataFlag.waitForFalse();
	}

	/**
	 * Wait for empty.
	 *
	 * @param timeoutInterval
	 *            the timeout interval
	 * @param timeUnit
	 *            the time unit
	 * @return true, if successful
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public final boolean waitForEmpty(int timeoutInterval, TimeUnit timeUnit) throws InterruptedException {
		return dataFlag.waitForFalse(timeoutInterval, timeUnit);
	}

}
