package com.nec.biomatcher.core.framework.cache;

public final class CacheExpiryParam {
	public static enum PARAM_TYPE {
		TTL, TTI
	}

	public int timeToLiveSeconds = -1;

	public int timeToIdleSeconds = -1;

	public String timeToLiveSecondsParamName = "";

	public String timeToIdleSecondsParamName = "";

	public CacheExpiryParam(int timeToLiveSeconds, int timeToIdleSeconds, String timeToLiveSecondsParamName,
			String timeToIdleSecondsParamName) {
		this.timeToLiveSeconds = timeToLiveSeconds;
		this.timeToIdleSeconds = timeToIdleSeconds;
		this.timeToLiveSecondsParamName = timeToLiveSecondsParamName;
		this.timeToIdleSecondsParamName = timeToIdleSecondsParamName;
	}

	public CacheExpiryParam(PARAM_TYPE paramType, int durationSeconds, String durationParamName) {
		if (PARAM_TYPE.TTL.equals(paramType)) {
			this.timeToLiveSeconds = durationSeconds;
			this.timeToLiveSecondsParamName = durationParamName;
		} else {
			this.timeToIdleSeconds = durationSeconds;
			this.timeToIdleSecondsParamName = durationParamName;
		}
	}

	public CacheExpiryParam(PARAM_TYPE paramType, int durationSeconds) {
		if (PARAM_TYPE.TTL.equals(paramType)) {
			this.timeToLiveSeconds = durationSeconds;
		} else {
			this.timeToIdleSeconds = durationSeconds;
		}
	}

	public static final CacheExpiryParam ttl(int durationSeconds, String durationParamName) {
		return new CacheExpiryParam(PARAM_TYPE.TTL, durationSeconds, durationParamName);
	}

	public static final CacheExpiryParam tti(int durationSeconds, String durationParamName) {
		return new CacheExpiryParam(PARAM_TYPE.TTI, durationSeconds, durationParamName);
	}
}
