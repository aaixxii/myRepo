package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Collection;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class ConcurrentSetProcessor<T> {
	private static final Logger logger = Logger.getLogger(ConcurrentSetProcessor.class);

	private static final ExecutorService cachedExecutorService = CommonTaskScheduler.CACHED_EXECUTORSERVICE;

	private final ConcurrentSkipListSet<T> setQueue = new ConcurrentSkipListSet<>();
	private final ConcurrentSkipListSet<T> workingSet = new ConcurrentSkipListSet<>();
	private final String name;
	private final Consumer<T> consumer;
	private final DynamicSemaphore concurrencySemaphore;
	private final Semaphore processSetQueueSemaphore = new Semaphore(0);
	// private final Striped<Semaphore> stripedWorkerSemaphore=
	// Striped.lazyWeakSemaphore(500,1);
	private final ConcurrentValuedHashMap<T, Semaphore> stripedWorkerSemaphore = new ConcurrentValuedHashMap<>(
			k -> new Semaphore(1));

	public ConcurrentSetProcessor(String name, Consumer<T> consumer) {
		this(name, consumer, () -> 1);
	}

	public ConcurrentSetProcessor(String name, Consumer<T> consumer, Supplier<Integer> concurrencyCountSupplier) {
		logger.info("In ConcurrentSetProcessor() for  name: " + name);
		this.name = name;
		this.consumer = consumer;
		this.concurrencySemaphore = DynamicSemaphore.getInstance(name + "_SEMAPHORE", concurrencyCountSupplier);

		Runnable runnable = () -> {
			Thread.currentThread().setName("CSP_SUB_" + name + "_" + Thread.currentThread().getId());
			submitToWorker();
		};

		CommonTaskScheduler.scheduleWithFixedDelay(runnable, 100, 500, TimeUnit.MILLISECONDS);
	}

	public final boolean add(T value) {
		final boolean isAdded = setQueue.add(value);
		if (isAdded) {
			if (logger.isTraceEnabled())
				logger.trace("In ConcurrentSetProcessor.add for name: " + name + ", value: " + value + ", isAdded: "
						+ isAdded);
			processSetQueueSemaphore.release();
		}

		return isAdded;
	}

	public final boolean addAll(Collection<T> values) {
		final boolean isAdded = setQueue.addAll(values);
		if (isAdded) {
			if (logger.isTraceEnabled())
				logger.trace("In ConcurrentSetProcessor.add for name: " + name + ", values: " + values + ", isAdded: "
						+ isAdded);
			processSetQueueSemaphore.release();
		}

		return isAdded;
	}

	public void waitForFreeSlot() {
		try {
			concurrencySemaphore.acquireUninterruptibly();
		} finally {
			concurrencySemaphore.release();
		}
	}

	private final void submitToWorker() {
		while (!ShutdownHook.isShutdownFlag) {
			processSetQueueSemaphore.acquireUninterruptibly();
			T value = null;
			while ((value = setQueue.pollFirst()) != null) {
				if (logger.isTraceEnabled())
					logger.trace("In ConcurrentSetProcessor.submitToWorker for name: " + name + ", value: " + value);
				concurrencySemaphore.acquireUninterruptibly();
				Semaphore workerSemaphore = stripedWorkerSemaphore.getValue(value);
				if (workerSemaphore.tryAcquire()) {
					try {
						workingSet.add(value);
						workerSemaphore.drainPermits();

						cachedExecutorService.execute(new CspWorkerThread(value, workerSemaphore));
					} catch (Throwable th) {
						logger.error("CspSubmitThread enountered error for name: " + name + ", value: " + value + " : "
								+ th.getMessage(), th);
						workerSemaphore.release();
						concurrencySemaphore.release();
						workingSet.remove(value);
					}
					processSetQueueSemaphore.drainPermits();
				} else {
					concurrencySemaphore.release();
					processSetQueueSemaphore.drainPermits();
					if (workingSet.contains(value)) {
						if (logger.isTraceEnabled())
							logger.trace(
									"CspWorkerThread already processing for name : " + name + ", value : " + value);
					} else {
						if (logger.isDebugEnabled())
							logger.debug("CspSubmitThread readding due to striped semphore overlap for name : " + name
									+ ", value : " + value);
						add(value);
					}
				}
			}
		}

		CommonLogger.STATUS_LOG.error("Exiting ConcurrentSetProcessor.submitToWorker for name: " + name);
	}

	class CspWorkerThread implements Runnable {
		private T value;
		private Semaphore workerSemaphore;

		public CspWorkerThread(T value, Semaphore workerSemaphore) {
			this.value = value;
			this.workerSemaphore = workerSemaphore;
		}

		@Override
		public void run() {
			try {
				Thread.currentThread().setName("CSP_WRK_" + name + "_" + value + "_" + Thread.currentThread().getId());
				NDC.clear();

				if (logger.isTraceEnabled())
					logger.trace("In CspWorkerThread.run for name: " + name + ", value: " + value);
				consumer.accept(value);
			} catch (Throwable th) {
				logger.error("CspWorkerThread enountered error for name: " + name + ", value: " + value + " : "
						+ th.getMessage(), th);
			} finally {
				workingSet.remove(value);
				workerSemaphore.release();
				workerSemaphore = null;
				concurrencySemaphore.release();
			}
		}

		@Override
		protected void finalize() throws Throwable {
			if (workerSemaphore != null) {
				workerSemaphore.release();
				logger.error("CspWorkerThread workerSemaphore released in finalize method for name: " + name
						+ ", value: " + value);
			}
			super.finalize();
		}
	}

}
