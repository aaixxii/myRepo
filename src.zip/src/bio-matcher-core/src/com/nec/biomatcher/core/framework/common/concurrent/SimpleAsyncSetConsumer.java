package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Collection;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class SimpleAsyncSetConsumer<T> {
	private static final Logger logger = Logger.getLogger(SimpleAsyncSetConsumer.class);

	private final ConcurrentSkipListSet<T> setQueue = new ConcurrentSkipListSet<>();
	private final Semaphore processSetQueueSemaphore = new Semaphore(0);
	private final String name;
	private final Consumer<T> consumer;

	public SimpleAsyncSetConsumer(String name, Consumer<T> consumer) {
		this.name = name;
		this.consumer = consumer;
		Runnable runnable = () -> {
			Thread.currentThread().setName("SASC_SUB_" + name + "_" + Thread.currentThread().getId());
			submitToConsumer();
		};

		CommonTaskScheduler.scheduleWithFixedDelay(runnable, 100, 500, TimeUnit.MILLISECONDS);
	}

	public final boolean add(T value) {
		if (value == null) {
			return false;
		}
		final boolean isAdded = setQueue.add(value);
		if (isAdded) {
			if (logger.isTraceEnabled())
				logger.trace("In SimpleAsyncSetConsumer.add for name: " + name + ", value: " + value + ", isAdded: "
						+ isAdded);
			processSetQueueSemaphore.release();
		}

		return isAdded;
	}

	public final boolean addAll(Collection<T> values) {
		if (values == null) {
			return false;
		}
		final boolean isAdded = setQueue.addAll(values);
		if (isAdded) {
			if (logger.isTraceEnabled())
				logger.trace("In SimpleAsyncSetConsumer.add for name: " + name + ", valuesSize: " + values.size()
						+ ", isAdded: " + isAdded);
			processSetQueueSemaphore.release();
		}

		return isAdded;
	}

	private final void submitToConsumer() {
		while (!ShutdownHook.isShutdownFlag) {
			processSetQueueSemaphore.acquireUninterruptibly();

			T value = null;
			while ((value = setQueue.pollFirst()) != null) {
				processSetQueueSemaphore.drainPermits();

				do {
					long startTimeMilli = System.currentTimeMillis();
					try {
						consumer.accept(value);
					} catch (Throwable th) {
						logger.error("SimpleAsyncSetConsumer.submitToConsumer enountered error for name: " + name
								+ ", value: " + value + " : " + th.getMessage(), th);
					} finally {
						if (logger.isTraceEnabled())
							logger.trace("In SimpleAsyncSetConsumer.submitToConsumer for name: " + name + ", value: "
									+ value + ", timeTakenMilli: " + (System.currentTimeMillis() - startTimeMilli));
					}
				} while ((value = setQueue.pollFirst()) != null);
			}
		}

		CommonLogger.STATUS_LOG.error("Exiting SimpleAsyncSetConsumer.submitToConsumer for name: " + name);
	}

}
