package com.nec.biomatcher.verifier.service.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioVerificationTimeoutException.
 */
public class BioVerificationTimeoutException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio verification timeout exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioVerificationTimeoutException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio verification timeout exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioVerificationTimeoutException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio verification timeout exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioVerificationTimeoutException(Throwable cause) {
		super(cause);
	}

}
