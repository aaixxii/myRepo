package com.nec.biomatcher.verifier.util;

/**
 * The Class VerifyConstants.
 */
public class VerifyConstants {

	/** The Constant ERROR_CODE_GENERAL. */
	public static final String ERROR_CODE_GENERAL = "VC001";

	/** The Constant ERROR_CODE_TIMEOUT. */
	public static final String ERROR_CODE_TIMEOUT = "VC002";

	/** The Constant ERROR_CODE_REJECTED. */
	public static final String ERROR_CODE_REJECTED = "VC003";

	/** The Constant ERROR_CODE_VERIFY_NODE_ERROR. */
	public static final String ERROR_CODE_VERIFY_NODE_ERROR = "VC004";

	/** The Constant ERROR_CODE_LOBSTREAM_ACCESS. */
	public static final String ERROR_CODE_LOBSTREAM_ACCESS = "VC005";

	/** The Constant ERROR_CODE_SERIALIZATION. */
	public static final String ERROR_CODE_SERIALIZATION = "VC006";

}
