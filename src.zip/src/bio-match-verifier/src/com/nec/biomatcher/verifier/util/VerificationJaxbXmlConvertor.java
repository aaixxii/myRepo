package com.nec.biomatcher.verifier.util;

import javax.xml.bind.JAXBContext;

import com.nec.biomatcher.core.framework.common.JaxbSerializer;
import com.nec.biomatcher.core.framework.common.exception.ObjectCreationException;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobResultPayload;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;

public class VerificationJaxbXmlConvertor extends JaxbSerializer {

	/** The jaxb context. */
	private static volatile JAXBContext jaxbContext;

	@Override
	protected JAXBContext getJAXBContext() {
		if (jaxbContext == null) {
			synchronized (VerificationJaxbXmlConvertor.class) {
				if (jaxbContext == null) {
					try {
						jaxbContext = JAXBContext.newInstance(VerifyJobRequestDto.class, VerifyJobResultDto.class,
								BioMatcherJobRequestPayload.class, BioMatcherJobResultPayload.class);
					} catch (Throwable th) {
						throw new ObjectCreationException(
								"Error while creating jaxb context for VerificationJaxbXmlConvertor: "
										+ th.getMessage(),
								th);
					}
				}
			}
		}
		return jaxbContext;
	}

}
