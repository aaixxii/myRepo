package com.nec.biomatcher.verifier.provider.impl;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.NDC;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.util.JobIdGenerator;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.spec.services.BioVerificationJobService;
import com.nec.biomatcher.spec.services.exception.BioVerificationJobServiceException;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.verifier.queueing.VerificationJobQueueHelper;
import com.nec.biomatcher.verifier.util.VerifyConstants;
import com.nec.biomatcher.verifier.util.VerifyJobInfo;

/**
 * The Class BioVerificationJobServiceImpl.
 */
public class BioVerificationJobServiceImpl implements BioVerificationJobService, InitializingBean {

	/** The verification job queue helper. */
	private VerificationJobQueueHelper verificationJobQueueHelper;
	private JobIdGenerator jobIdGenerator;
	private String verifyControllerId;

	@Override
	public VerifyJobResultDto verify(VerifyJobRequestDto jobRequestDto) throws BioVerificationJobServiceException {
		if (verifyControllerId == null) {
			throw new BioVerificationJobServiceException("Verification Controller is not configured on "
					+ HostnameUtil.getIpAddress() + ", " + HostnameUtil.getHostname());
		}

		String jobId = jobIdGenerator.nextId(verifyControllerId);

		NDC.clear();
		NDC.push("VI_JOBID#" + jobId);
		try {
			VerifyJobInfo verifyJobInfo = verificationJobQueueHelper.submitVerificationJob(jobId, jobRequestDto);

			verifyJobInfo.getWaitSemaphore().tryAcquire(verifyJobInfo.getJobTimeoutMill() + 100, TimeUnit.MILLISECONDS);

			VerifyJobResultDto verifyJobResultDto = verifyJobInfo.getJobResultDto();
			if (verifyJobResultDto == null) {
				verifyJobResultDto = new VerifyJobResultDto();
				verifyJobResultDto.setJobId(jobId);
				verifyJobResultDto.setStatus(BioJobStatus.COMPLETED);
				verifyJobResultDto.getErrorList().add(new ErrorMessageDto(VerifyConstants.ERROR_CODE_TIMEOUT,
						"Verify job not completed",
						"VerifyJobResultDto not available after jobTimeoutMill: " + verifyJobInfo.getJobTimeoutMill(),
						new Date()));
			}

			return verifyJobResultDto;
		} catch (Throwable th) {
			throw new BioVerificationJobServiceException("Error in verify: jobId: " + jobId + " : " + th.getMessage(),
					th);
		}
	}

	@Override
	public String submitVerificationJob(VerifyJobRequestDto jobRequestDto) throws BioVerificationJobServiceException {
		if (verifyControllerId == null) {
			throw new BioVerificationJobServiceException("Verification Controller is not configured on "
					+ HostnameUtil.getIpAddress() + ", " + HostnameUtil.getHostname());
		}

		String jobId = jobIdGenerator.nextId(verifyControllerId);

		NDC.clear();
		NDC.push("VI_JOBID#" + jobId);

		try {
			VerifyJobInfo verifyJobInfo = verificationJobQueueHelper.submitVerificationJob(jobId, jobRequestDto);

			return verifyJobInfo.getVerifyJobId();
		} catch (BioVerificationJobServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new BioVerificationJobServiceException(th.getMessage(), th);
		}
	}

	@Override
	public BioJobStatus getVerificationJobStatus(String jobId) throws BioVerificationJobServiceException {
		NDC.clear();
		NDC.push("VI_JOBID#" + jobId);
		try {
			return verificationJobQueueHelper.getVerificationJobStatus(jobId);
		} catch (Throwable th) {
			throw new BioVerificationJobServiceException(th.getMessage(), th);
		}
	}

	@Override
	public VerifyJobResultDto getVerificationJobResult(String jobId) throws BioVerificationJobServiceException {
		NDC.clear();
		NDC.push("VI_JOBID#" + jobId);

		try {
			return verificationJobQueueHelper.getVerificationJobResult(jobId);
		} catch (Throwable th) {
			throw new BioVerificationJobServiceException(th.getMessage(), th);
		}
	}

	@Override
	public void deleteVerificationJob(String jobId) throws BioVerificationJobServiceException {
		NDC.clear();
		NDC.push("VI_JOBID#" + jobId);

		try {
			verificationJobQueueHelper.deleteVerificationJob(jobId);
		} catch (Throwable th) {
			throw new BioVerificationJobServiceException(th.getMessage(), th);
		}
	}

	public void setVerificationJobQueueHelper(VerificationJobQueueHelper verificationJobQueueHelper) {
		this.verificationJobQueueHelper = verificationJobQueueHelper;
	}

	public void setJobIdGenerator(JobIdGenerator jobIdGenerator) {
		this.jobIdGenerator = jobIdGenerator;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		verifyControllerId = verificationJobQueueHelper.getVerificationControllerId();
	}

}
