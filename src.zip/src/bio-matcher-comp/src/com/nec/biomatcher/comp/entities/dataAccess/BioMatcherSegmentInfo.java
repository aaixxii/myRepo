package com.nec.biomatcher.comp.entities.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

public class BioMatcherSegmentInfo implements Dbo {
	private static final long serialVersionUID = 1L;

	private Integer segmentId;

	private Integer binId;

	private Long segmentVersion;

	private String tagId;

	private Date updateDateTime;

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Long getSegmentVersion() {
		return segmentVersion;
	}

	public void setSegmentVersion(Long segmentVersion) {
		this.segmentVersion = segmentVersion;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}
}
