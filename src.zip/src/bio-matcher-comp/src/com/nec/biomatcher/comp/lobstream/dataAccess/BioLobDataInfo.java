package com.nec.biomatcher.comp.lobstream.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

public class BioLobDataInfo implements Dbo {	
	private static final long serialVersionUID = -853021770020638278L;
	
	private String lobId;
	private String  lobType;
	private byte[] lobData;
	private Date createDateTime;
	public String getLobId() {
		return lobId;
	}
	public void setLobId(String lobId) {
		this.lobId = lobId;
	}
	public String getLobType() {
		return lobType;
	}
	public void setLobType(String lobType) {
		this.lobType = lobType;
	}
	public byte[] getLobData() {
		return lobData;
	}
	public void setLobData(byte[] lobData) {
		this.lobData = lobData;
	}
	public Date getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
}
