package com.nec.biomatcher.comp.bioevent.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.bioevent.BiometricIdService;
import com.nec.biomatcher.comp.bioevent.dataAccess.BiometricEventDao;
import com.nec.biomatcher.comp.bioevent.exception.BiometricIdServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdDetailInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.HostnameUtil;

/**
 * The Class BiometricIdServiceImpl.
 */
public class BiometricIdServiceImpl implements BiometricIdService {

	private static final Logger logger = Logger.getLogger(BiometricIdServiceImpl.class);
	private static final Logger CONFIG_LOGGER = Logger.getLogger("CONFIG_LOG");

	/** The biometric event dao. */
	private BiometricEventDao biometricEventDao;

	public List<BiometricIdInfo> getBiometricSequenceIdInfoList(Integer binId) throws BiometricIdServiceException {
		try {
			return biometricEventDao.getEntityListByField(BiometricIdInfo.class, "binId", binId);
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in getBiometricSequenceIdInfoList: " + th.getMessage(), th);
		}
	}

	public BiometricIdInfo getBiometricIdInfoBySegmentId(Integer segmentId) throws BiometricIdServiceException {
		try {
			return biometricEventDao.getEntityByField(BiometricIdInfo.class, "segmentId", segmentId);
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in getBiometricIdInfoBySegmentId: " + th.getMessage(), th);
		}
	}

	public List<BiometricIdDetailInfo> acquireBiometricIdList(Integer segmentId, Integer count)
			throws BiometricIdServiceException {
		try {
			BiometricIdInfo biometricSequenceIdInfo = biometricEventDao.getEntityForUpdate(BiometricIdInfo.class,
					segmentId);
			if (biometricSequenceIdInfo.getStartBiometricId() <= 0L) {
				CONFIG_LOGGER.warn("Start biometricId is less than 1, changing to 1 for BiometricIdInfo: "
						+ GsonSerializer.toJson(biometricSequenceIdInfo));
				biometricSequenceIdInfo.setStartBiometricId(1L);
			}

			List<BiometricIdDetailInfo> biometricIdDetailInfoList = new ArrayList<BiometricIdDetailInfo>(count);

			acquireBiometricIdList(biometricSequenceIdInfo, count, biometricIdDetailInfoList);

			return biometricIdDetailInfoList;
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in acquireBiometricIdList: " + th.getMessage(), th);
		}
	}

	public List<BiometricIdDetailInfo> acquireReleasedBiometricIdList(Integer segmentId, Integer count)
			throws BiometricIdServiceException {
		try {
			BiometricIdInfo biometricSequenceIdInfo = biometricEventDao.getEntityForUpdate(BiometricIdInfo.class,
					segmentId);
			if (biometricSequenceIdInfo.getStartBiometricId() <= 0L) {
				CONFIG_LOGGER.warn("Start biometricId is less than 1, changing to 1 for BiometricIdInfo: "
						+ GsonSerializer.toJson(biometricSequenceIdInfo));
				biometricSequenceIdInfo.setStartBiometricId(1L);
			}

			List<BiometricIdDetailInfo> biometricIdDetailInfoList = new ArrayList<BiometricIdDetailInfo>(count);

			List<BiometricIdDetailInfo> sequenceIdDetailInfoList = biometricEventDao.getEntityListByFields(
					BiometricIdDetailInfo.class, "segmentId", segmentId, "reuseFlag", Boolean.TRUE, count);

			Date now = new Date();

			for (BiometricIdDetailInfo biometricIdDetailInfo : sequenceIdDetailInfoList) {
				biometricIdDetailInfo.setOldReusedFlag(true); // Just an
																// indicator to
																// tell if its
																// reused

				biometricIdDetailInfo.setAcquireDateTime(now);
				biometricIdDetailInfo.setAcquireHost(HostnameUtil.getHostname());
				biometricIdDetailInfo.setReuseFlag(Boolean.FALSE);
				biometricEventDao.updateEntity(biometricSequenceIdInfo);
				biometricIdDetailInfoList.add(biometricIdDetailInfo);
			}

			if (count > biometricIdDetailInfoList.size()) {
				count = count - biometricIdDetailInfoList.size();

				acquireBiometricIdList(biometricSequenceIdInfo, count, biometricIdDetailInfoList);
			}

			return biometricIdDetailInfoList;
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in acquireReleasedBiometricIdList: " + th.getMessage(), th);
		}
	}

	public List<BiometricIdDetailInfo> acquireReleasedBiometricIdListByBinId(Integer binId, Integer count)
			throws BiometricIdServiceException {
		try {
			List<BiometricIdDetailInfo> biometricIdDetailInfoList = new ArrayList<BiometricIdDetailInfo>(count);

			BioMatcherBinInfo bioMatcherBinInfo = biometricEventDao.getEntityForUpdate(BioMatcherBinInfo.class, binId);
			if (bioMatcherBinInfo == null) {
				logger.error("Cannot find BioMatcherBinInfo with binId: " + binId);
				return biometricIdDetailInfoList;
			}

			List<BiometricIdDetailInfo> sequenceIdDetailInfoList = biometricEventDao.getEntityListByFields(
					BiometricIdDetailInfo.class, "binId", binId, "reuseFlag", Boolean.TRUE, count);

			Date now = new Date();

			for (BiometricIdDetailInfo biometricIdDetailInfo : sequenceIdDetailInfoList) {
				biometricIdDetailInfo.setOldReusedFlag(true); // Just an
																// indicator to
																// tell if its
																// reused

				biometricIdDetailInfo.setAcquireDateTime(now);
				biometricIdDetailInfo.setAcquireHost(HostnameUtil.getHostname());
				biometricIdDetailInfo.setReuseFlag(Boolean.FALSE);
				biometricIdDetailInfoList.add(biometricIdDetailInfo);
			}

			return biometricIdDetailInfoList;
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in acquireReleasedBiometricIdListByBinId: " + th.getMessage(),
					th);
		}
	}

	/**
	 * Acquire biometric id list.
	 *
	 * @param biometricSequenceIdInfo
	 *            the biometric sequence id info
	 * @param count
	 *            the count
	 * @param biometricIdDetailInfoList
	 *            the biometric id detail info list
	 * @throws BiometricIdServiceException
	 *             the biometric id service exception
	 */
	private final void acquireBiometricIdList(BiometricIdInfo biometricSequenceIdInfo, Integer count,
			List<BiometricIdDetailInfo> biometricIdDetailInfoList) throws BiometricIdServiceException {
		try {
			if (biometricSequenceIdInfo.getStartBiometricId() <= 0L) {
				CONFIG_LOGGER.warn("Start biometricId is less than 1, changing to 1 for BiometricIdInfo: "
						+ GsonSerializer.toJson(biometricSequenceIdInfo));
				biometricSequenceIdInfo.setStartBiometricId(1L);
			}

			if (biometricSequenceIdInfo.getStartBiometricId() > biometricSequenceIdInfo.getEndBiometricId()) {
				CONFIG_LOGGER.error("Invalid biometricId start and end assignment for BiometricIdInfo: "
						+ GsonSerializer.toJson(biometricSequenceIdInfo));
				return;
			}

			if (biometricSequenceIdInfo.getCurrentBiometricId() > biometricSequenceIdInfo.getEndBiometricId()) {
				CONFIG_LOGGER.warn("No biometricId's left to acquire from BiometricIdInfo: "
						+ GsonSerializer.toJson(biometricSequenceIdInfo));
				return;
			}

			if (biometricSequenceIdInfo.getCurrentBiometricId() < biometricSequenceIdInfo.getStartBiometricId()) {
				CONFIG_LOGGER
						.warn("Current biometricId is less than the start biometricId, so setting current biometricId to start biometricId, BiometricIdInfo: "
								+ GsonSerializer.toJson(biometricSequenceIdInfo));
				biometricSequenceIdInfo.setCurrentBiometricId(biometricSequenceIdInfo.getStartBiometricId());
			}

			long endBiometricId = biometricSequenceIdInfo.getEndBiometricId();
			long currentBiometricId = biometricSequenceIdInfo.getCurrentBiometricId();

			int availableIdCount = 0;
			if ((1L + endBiometricId - currentBiometricId) < count.longValue()) {
				availableIdCount = (int) (1L + endBiometricId - currentBiometricId);
			} else {
				availableIdCount = count;
			}

			if (availableIdCount <= 0) {
				return;
			}

			biometricSequenceIdInfo.setCurrentBiometricId(currentBiometricId + availableIdCount);

			biometricEventDao.updateEntity(biometricSequenceIdInfo);

			Date now = new Date();
			for (int i = 0; i < availableIdCount; i++) {
				BiometricIdDetailInfo biometricIdDetailInfo = new BiometricIdDetailInfo();
				biometricIdDetailInfo.setSegmentId(biometricSequenceIdInfo.getSegmentId());
				biometricIdDetailInfo.setBinId(biometricSequenceIdInfo.getBinId());
				biometricIdDetailInfo.setBiometricId(currentBiometricId + i);
				biometricIdDetailInfo.setAcquireHost(HostnameUtil.getHostname());
				biometricIdDetailInfo.setAcquireDateTime(now);
				biometricIdDetailInfo.setReuseFlag(Boolean.FALSE);

				biometricEventDao.saveEntity(biometricIdDetailInfo);

				biometricIdDetailInfoList.add(biometricIdDetailInfo);
			}
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in acquireBiometricIdList: " + th.getMessage(), th);
		}
	}

	public void releaseBiometricIds(List<BiometricIdDetailInfo> releasedBiometricIdList)
			throws BiometricIdServiceException {
		try {
			for (BiometricIdDetailInfo biometricIdDetailInfo : releasedBiometricIdList) {
				biometricIdDetailInfo.setAcquireHost(null);
				biometricIdDetailInfo.setAcquireDateTime(null);
				biometricIdDetailInfo.setReuseFlag(Boolean.TRUE);

				biometricEventDao.saveEntity(biometricIdDetailInfo);
			}
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in releaseBiometricIds: " + th.getMessage(), th);
		}
	}

	public void commitAcquiredBiometricIdList(List<Long> commitBiometricIdList) throws BiometricIdServiceException {
		try {
			if (commitBiometricIdList == null || commitBiometricIdList.size() == 0) {
				return;
			}

			biometricEventDao.deleteBiometricIdDetailInfoList(commitBiometricIdList);
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in commitAcquiredBiometricIdList: " + th.getMessage(), th);
		}
	}

	public void releaseOldBiometricIdsByAcquireHost() throws BiometricIdServiceException {
		try {
			biometricEventDao.releaseOldBiometricIdsByAcquireHost(HostnameUtil.getHostname());
		} catch (Throwable th) {
			throw new BiometricIdServiceException("Error in releaseBiometricIds: " + th.getMessage(), th);
		}
	}

	public void setBiometricEventDao(BiometricEventDao biometricEventDao) {
		this.biometricEventDao = biometricEventDao;
	}
}
