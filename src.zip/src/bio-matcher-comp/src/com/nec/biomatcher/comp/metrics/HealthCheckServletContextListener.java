package com.nec.biomatcher.comp.metrics;

import com.codahale.metrics.health.HealthCheckRegistry;
import com.codahale.metrics.servlets.HealthCheckServlet;

/**
 * The listener interface for receiving healthCheckServletContext events. The
 * class that is interested in processing a healthCheckServletContext event
 * implements this interface, and the object created with that class is
 * registered with a component using the component's
 * <code>addHealthCheckServletContextListener<code> method. When the
 * healthCheckServletContext event occurs, that object's appropriate method is
 * invoked.
 *
 * @see HealthCheckServletContextEvent
 */
public class HealthCheckServletContextListener extends HealthCheckServlet.ContextListener {

	@Override
	protected HealthCheckRegistry getHealthCheckRegistry() {
		return MetricsUtil.HEALTH_CHECK_REGISTRY;
	}

}
