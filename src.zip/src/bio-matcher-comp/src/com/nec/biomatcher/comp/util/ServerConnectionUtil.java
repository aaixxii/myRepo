package com.nec.biomatcher.comp.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nec.biomatcher.comp.entities.dataAccess.BioServerConnectionInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;

public class ServerConnectionUtil {
	public static final String defaultHessianUrl = "http://DEFAULTHOSTNAME:8080/bio-matcher-webservices/remoting/http/bioSearchBrokerService/httpBioSearchBrokerService";

	public static final String defaultEcHazelcastClusterUrl = "tcp://DEFAULTHOSTNAME:5901";
	public static final String defaultEcZmqCallbackUrl = "tcp://DEFAULTHOSTNAME:5905";
	public static final String defaultEnZmqAdminUrl = "tcp://DEFAULTHOSTNAME:5001";
	public static final String defaultEnZmqWorkerUrl = "tcp://DEFAULTHOSTNAME:5002";

	public static final String defaultVcHazelcastClusterUrl = "tcp://DEFAULTHOSTNAME:5900";
	public static final String defaultVcZmqCallbackUrl = "tcp://DEFAULTHOSTNAME:5906";
	public static final String defaultVnZmqAdminUrl = "tcp://DEFAULTHOSTNAME:5003";
	public static final String defaultVnZmqWorkerUrl = "tcp://DEFAULTHOSTNAME:5004";

	public static final String defaultScHessianUrl = "http://DEFAULTHOSTNAME:8080/bio-matcher-webservices/remoting/http/bioSearchJobControllerService/httpBioSearchJobControllerService";
	public static final String defaultSbHessianUrl = "http://DEFAULTHOSTNAME:8080/bio-matcher-webservices/remoting/http/bioSearchBrokerService/httpBioSearchBrokerService";
	public static final String defaultSbHttpSegServerUrl = "http://DEFAULTHOSTNAME:8080/bio-matcher-webservices/segServer";
	public static final String defaultSbZmqJobDistibutorListenerUrl = "tcp://DEFAULTHOSTNAME:5011";
	public static final String defaultScHazelcastClusterUrl = "tcp://DEFAULTHOSTNAME:5902";
	public static final String defaultScZmqCallbackUrl = "tcp://DEFAULTHOSTNAME:5903";
	public static final String defaultSnZmqAdminUrl = "tcp://DEFAULTHOSTNAME:5005";
	public static final String defaultSnZmqWorkerUrl = "tcp://DEFAULTHOSTNAME:5006";
	public static final String defaultSnHttpSegSyncUrl = "http://DEFAULTHOSTNAME:5007/seg-update";
	public static final String defaultSnHttpSegServerUrl = "http://DEFAULTHOSTNAME:5008/seg-server";

	public static final String defaultInflluxDbHttpUrl = "http://admin:admin@DEFAULTHOSTNAME:8086/biomatcher_influxdb";

	public static final String defaultTvcHazelcastClusterUrl = "tcp://DEFAULTHOSTNAME:5904";
	public static final String defaultTvnZmqAdminUrl = "tcp://DEFAULTHOSTNAME:5009";
	public static final String defaultTvnZmqWorkerUrl = "tcp://DEFAULTHOSTNAME:5010";

	public static final String defaultCassandraUrl = "tcp://DEFAULTHOSTNAME:9042";

	public static List<BioServerConnectionInfo> buildConnectionList(String serverId, String serverHost,
			BioComponentType bioComponentType) {
		List<BioServerConnectionInfo> connectonList = new ArrayList<>();
		if (BioComponentType.EC.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.CLUSTER,
					BioProtocolType.HAZELCAST, defaultEcHazelcastClusterUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType,
					BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ, defaultEcZmqCallbackUrl));
		} else if (BioComponentType.EN.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.ADMIN,
					BioProtocolType.ZEROMQ, defaultEnZmqAdminUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.WORKER,
					BioProtocolType.ZEROMQ, defaultEnZmqWorkerUrl));
		} else if (BioComponentType.VC.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.CLUSTER,
					BioProtocolType.HAZELCAST, defaultVcHazelcastClusterUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType,
					BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ, defaultVcZmqCallbackUrl));
		} else if (BioComponentType.VN.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.ADMIN,
					BioProtocolType.ZEROMQ, defaultVnZmqAdminUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.WORKER,
					BioProtocolType.ZEROMQ, defaultVnZmqWorkerUrl));
		} else if (BioComponentType.SC.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.COMPONENT,
					BioProtocolType.HESSIAN, defaultScHessianUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.CLUSTER,
					BioProtocolType.HAZELCAST, defaultScHazelcastClusterUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType,
					BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ, defaultScZmqCallbackUrl));
		} else if (BioComponentType.SB.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.COMPONENT,
					BioProtocolType.HESSIAN, defaultSbHessianUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.SEG_SERVER,
					BioProtocolType.HTTP, defaultSbHttpSegServerUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType,
					BioConnectionType.JOB_DISTRIBUTOR, BioProtocolType.ZEROMQ, defaultSbZmqJobDistibutorListenerUrl));
		} else if (BioComponentType.SN.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.ADMIN,
					BioProtocolType.ZEROMQ, defaultSnZmqAdminUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.WORKER,
					BioProtocolType.ZEROMQ, defaultSnZmqWorkerUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.SEG_SYNC,
					BioProtocolType.HTTP, defaultSnHttpSegSyncUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.SEG_SERVER,
					BioProtocolType.HTTP, defaultSnHttpSegServerUrl));
		} else if (BioComponentType.IF.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.SERVICE,
					BioProtocolType.HTTP, defaultInflluxDbHttpUrl));
		} else if (BioComponentType.TVC.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.CLUSTER,
					BioProtocolType.HAZELCAST, defaultTvcHazelcastClusterUrl));
		} else if (BioComponentType.TVN.equals(bioComponentType)) {
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.ADMIN,
					BioProtocolType.ZEROMQ, defaultTvnZmqAdminUrl));
			connectonList.add(buildConnectionInfo(serverId, serverHost, bioComponentType, BioConnectionType.WORKER,
					BioProtocolType.ZEROMQ, defaultTvnZmqWorkerUrl));
		} else if (BioComponentType.CDB.equals(bioComponentType)) {
			connectonList.add(buildCassandraConnectionInfo(serverId, serverHost, bioComponentType,
					BioConnectionType.SERVICE, BioProtocolType.HTTP, defaultCassandraUrl));
		} else {
			throw new IllegalArgumentException("BioComponentType: " + bioComponentType + " is not supported");
		}
		return connectonList;
	}

	private static BioServerConnectionInfo buildConnectionInfo(String serverId, String serverHost,
			BioComponentType componentType, BioConnectionType connectionType, BioProtocolType protocolType,
			String connectionUrl) {
		BioServerConnectionInfo connectionInfo = new BioServerConnectionInfo();
		connectionInfo.setServerId(serverId);
		connectionInfo.setComponentType(componentType);
		connectionInfo.setConnectionType(connectionType);
		connectionInfo.setProtocolType(protocolType);
		connectionInfo.setConnectionUrl(buildConnectionUrl(connectionUrl, serverHost));
		return connectionInfo;
	}

	private static BioServerConnectionInfo buildCassandraConnectionInfo(String serverId, String serverHost,
			BioComponentType componentType, BioConnectionType connectionType, BioProtocolType protocolType,
			String connectionUrl) {
		BioServerConnectionInfo connectionInfo = new BioServerConnectionInfo();
		connectionInfo.setServerId(serverId);
		connectionInfo.setComponentType(componentType);
		connectionInfo.setConnectionType(connectionType);
		connectionInfo.setProtocolType(protocolType);
		connectionInfo.setConnectionUrl(buildConnectionUrl(connectionUrl, serverHost));

		Map<String, String> connectionProperties = new HashMap<>();
		connectionProperties.put("keyspace", "bio_matcher");
		connectionProperties.put("coreConnectionsPerHost", "4");
		connectionProperties.put("maxConnectionsPerHost", "10");
		connectionProperties.put("maxRequestsPerLocalConnection", "32768");
		connectionProperties.put("maxRequestsPerRemoteConnection", "2000");
		connectionProperties.put("heartbeatIntervalSeconds", "120");

		connectionInfo.setConnectionProperties(connectionProperties);

		return connectionInfo;
	}

	private static String buildConnectionUrl(String defaultConnectionUrl, String serverHost) {
		return defaultConnectionUrl.replace("DEFAULTHOSTNAME", serverHost);
	}
}
