package com.nec.biomatcher.comp.common.locking.dataAccess;

import java.util.List;

import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

/**
 * Database access bean for LockInfo.
 *
 * @author Mahesh
 * @version 1.0
 * @since 22 June 2012
 * 
 */
public interface BioLockingServiceDao extends HibernateDao {

	/**
	 * Delete expired lock that matches the lock key suffix.
	 *
	 * @param lockKeySuffix
	 *            the lock key suffix
	 * @param lockTimeoutMilli
	 *            the lock timeout milli
	 * @throws DaoException
	 *             the dao exception
	 */
	public void deleteExpiredLockInfoByLockKeySuffix(String lockKeySuffix, long lockTimeoutMilli) throws DaoException;

	public List<String> getLockKeysWithPrefix(String prefix) throws DaoException;

}
