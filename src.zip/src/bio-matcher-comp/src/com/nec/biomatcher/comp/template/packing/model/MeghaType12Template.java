package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;

public class MeghaType12Template extends MeghaTemplate {
	private Map<Integer, MeghaType12Event> eventMap = new HashMap<Integer, MeghaType12Event>();

	public MeghaType12Template(int userFlagByteCount) {
		super(userFlagByteCount);
	}

	public Map<Integer, MeghaType12Event> getEventMap() {
		return eventMap;
	}

	public void setEventMap(Map<Integer, MeghaType12Event> eventMap) {
		this.eventMap = eventMap;
	}

	public void print(PrintStream printStream) {
		printStream.println("---------Header---------");
		if (templateHeader != null) {
			templateHeader.print(printStream);
		}
		eventMap.entrySet().forEach((entry) -> {
			printStream.println("---------Event Index: " + entry.getKey() + " ---------");
			((MeghaEvent) entry.getValue()).print(printStream);
		});
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (templateHeader == null) {
			templateHeader = new MeghaTemplateHeader(userFlagByteCount);
		}
		templateHeader.setTemplateTypeCode((byte) 12);
		templateHeader.setEventHoldFlag(0);
		templateHeader.setMaxEventCount((byte) eventMap.size());

		byte[] templateData = new byte[MeghaTemplate.calculateTemplateSize(templateHeader.getTemplateHeaderSize(),
				MeghaType12Event.getEventDataSize(meghaTemplateConfig), templateHeader.getMaxEventCount())];
		ByteBuffer templateDataBuf = ByteBuffer.wrap(templateData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		for (int eventIndex : eventMap.keySet()) {
			MeghaType12Event event = eventMap.get(eventIndex);
			templateDataBuf.position(templateHeader.getTemplateHeaderSize()
					+ (eventIndex * MeghaType12Event.getEventDataSize(meghaTemplateConfig)));
			templateDataBuf.put(event.pack(meghaTemplateConfig));
			templateHeader
					.setEventHoldFlag(HoldFlagUtil.setHoldFlag(templateHeader.getEventHoldFlag(), eventIndex, true));
		}

		templateDataBuf.position(0);
		templateDataBuf.put(templateHeader.pack());

		templateData[MeghaTemplateHeader.SANITY_BYTE_POSITION] = 0;
		templateData[MeghaTemplateHeader.SANITY_BYTE_POSITION] = MeghaTemplateUtil.calculateChecksum(templateData);

		return templateData;
	}

	@Override
	public void unpack(byte[] templateData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (templateData == null) {
			throw new MeghaTemplateException("templateData is null");
		}
		if ((templateData.length - MeghaTemplateUtil.getTemplateHeaderSize(userFlagByteCount))
				% MeghaType12Event.getEventDataSize(meghaTemplateConfig) != 0) {
			throw new MeghaTemplateException("Invalid template size. TemplateSize: " + templateData.length
					+ " minus HeaderSize: " + MeghaTemplateUtil.getTemplateHeaderSize(userFlagByteCount)
					+ " shuould be divisable by EvendDataSize: "
					+ MeghaType12Event.getEventDataSize(meghaTemplateConfig));
		}

		ByteBuffer templateDataBuf = ByteBuffer.wrap(templateData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		templateHeader = new MeghaTemplateHeader(userFlagByteCount);
		templateHeader.unpack(templateDataBuf);

		List<Integer> eventIndexList = HoldFlagUtil.getHoldFlagIndexList(templateHeader.getEventHoldFlag(),
				templateHeader.getMaxEventCount());
		for (int eventIndex : eventIndexList) {
			byte eventData[] = new byte[MeghaType12Event.getEventDataSize(meghaTemplateConfig)];

			templateDataBuf.position(templateHeader.getTemplateHeaderSize()
					+ (eventIndex * MeghaType12Event.getEventDataSize(meghaTemplateConfig)));
			templateDataBuf.get(eventData);

			MeghaType12Event event = new MeghaType12Event();
			event.unpack(eventData, meghaTemplateConfig);

			eventMap.put(eventIndex, event);
		}
	}

}
