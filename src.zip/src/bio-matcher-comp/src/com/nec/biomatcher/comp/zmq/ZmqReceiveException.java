package com.nec.biomatcher.comp.zmq;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class ZmqReceiveException extends CoreException {

	private static final long serialVersionUID = 1L;

	public ZmqReceiveException(String message, Throwable cause) {
		super(message, cause);
	}

	public ZmqReceiveException(String message) {
		super(message);
	}

	public ZmqReceiveException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

}
