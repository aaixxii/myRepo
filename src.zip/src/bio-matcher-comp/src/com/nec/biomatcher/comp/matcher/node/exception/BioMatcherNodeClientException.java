package com.nec.biomatcher.comp.matcher.node.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioMatcherNodeClientException.
 */
public class BioMatcherNodeClientException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio matcher node client exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioMatcherNodeClientException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio matcher node client exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioMatcherNodeClientException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio matcher node client exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioMatcherNodeClientException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

}
