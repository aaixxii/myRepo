package com.nec.biomatcher.comp.manager.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioDataSegmentationException.
 */
public class BioDataSegmentationException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio data segmentation exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioDataSegmentationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio data segmentation exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioDataSegmentationException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio data segmentation exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioDataSegmentationException(Throwable cause) {
		super(cause);
	}

}
