package com.nec.biomatcher.comp.entities.dataAccess.types;

/**
 * The Enum BioMatcherNodeType.
 */
public enum BioMatcherNodeType {

	/** The ex. */
	EX("Extraction Node"),

	/** The ii. */
	II("Iris Inquiry"),

	/** The fi. */
	FI("Face Inquiry"),

	/** The vi. */
	VI("Verification");

	/** The description. */
	private String description;

	/**
	 * Instantiates a new bio matcher node type.
	 *
	 * @param description
	 *            the description
	 */
	BioMatcherNodeType(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}
}
