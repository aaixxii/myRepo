package com.nec.biomatcher.comp.bioevent.util;

import java.util.List;
import java.util.function.Function;

import com.google.common.util.concurrent.AtomicLongMap;
import com.nec.biomatcher.comp.bioevent.BiometricIdService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdDetailInfo;

public abstract class AbstractAcquireBiometricIdsFunction implements Function<Integer, List<BiometricIdDetailInfo>> {
	protected static final AtomicLongMap<Integer> segmentIdBiometricIdCheckTimestampMap = AtomicLongMap.create();
	protected static final AtomicLongMap<Integer> binIdBiometricIdCheckTimestampMap = AtomicLongMap.create();

	protected BioParameterService bioParameterService;
	protected BioMatcherConfigService bioMatcherConfigService;
	protected BiometricIdService biometricIdService;

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBiometricIdService(BiometricIdService biometricIdService) {
		this.biometricIdService = biometricIdService;
	}
}
