package com.nec.biomatcher.comp.common.parameter.dataAccess;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioParameterScope.
 */
public class BioParameterScope implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The scope name. */
	private String scopeName;

	/** The description. */
	private String description;

	public String getScopeName() {
		return scopeName;
	}

	public void setScopeName(String scopeName) {
		this.scopeName = scopeName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
