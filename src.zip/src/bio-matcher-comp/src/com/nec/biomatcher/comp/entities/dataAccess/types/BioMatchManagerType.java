package com.nec.biomatcher.comp.entities.dataAccess.types;

/**
 * The Enum BioMatchManagerType.
 */
public enum BioMatchManagerType {

	/** The mc. */
	MC("Match Controller"),

	/** The mb. */
	MB("Match Broker"),

	/** The vc. */
	VC("Verify Controller");

	/** The description. */
	private String description;

	/**
	 * Instantiates a new bio match manager type.
	 *
	 * @param description
	 *            the description
	 */
	BioMatchManagerType(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}
}
