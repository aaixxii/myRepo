package com.nec.biomatcher.comp.util;

import java.util.function.BiFunction;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

public class TimeToIdleSecondsFunction implements BiFunction<String, Integer, Integer> {
	private static final Logger logger = Logger.getLogger(TimeToIdleSecondsFunction.class);

	private BioParameterService bioParameterService;

	@Override
	public Integer apply(String parameterName, Integer defaultTimeToIdleSeconds) {
		try {
			return getBioParameterService().getParameterValue(parameterName, "DEFAULT", defaultTimeToIdleSeconds);
		} catch (Throwable th) {
			logger.error("Error in TimeToIdleSecondsFunction for parameterName: " + parameterName
					+ ", defaultTimeToIdleSeconds: " + defaultTimeToIdleSeconds + " : " + th.getMessage(), th);
		}

		return defaultTimeToIdleSeconds;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public BioParameterService getBioParameterService() {
		if (bioParameterService == null) {
			bioParameterService = SpringServiceManager.getBean("bioParameterService");
		}
		return bioParameterService;
	}
}
