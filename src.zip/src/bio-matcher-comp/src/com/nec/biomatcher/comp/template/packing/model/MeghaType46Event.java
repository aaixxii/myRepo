package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Sets;
import com.google.common.primitives.UnsignedBytes;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;

public class MeghaType46Event extends MeghaEvent {
	private byte featureHoldFlag = 0;
	
	private MeghaPalmPartInfo lowerRight;
	private MeghaPalmPartInfo upperRight;
	private MeghaPalmPartInfo lowerLeft;
	private MeghaPalmPartInfo upperLeft;
	private MeghaPalmPartInfo writerRight;
	private MeghaPalmPartInfo writerLeft;

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "featureHoldFlag",
				StringUtils.leftPad(UnsignedBytes.toString(featureHoldFlag, 2), Byte.SIZE, "0"));
		if (lowerRight != null) {
			printStream.printf("%-20s - %s\n", "lowerRight", "");
			lowerRight.print(printStream);
		}

		if (upperRight != null) {
			printStream.printf("%-20s - %s\n", "upperRight", "");
			upperRight.print(printStream);
		}

		if (lowerLeft != null) {
			printStream.printf("%-20s - %s\n", "lowerLeft", "");
			lowerLeft.print(printStream);
		}

		if (upperLeft != null) {
			printStream.printf("%-20s - %s\n", "upperLeft", "");
			upperLeft.print(printStream);
		}

		if (writerRight != null) {
			printStream.printf("%-20s - %s\n", "writerRight", "");
			writerRight.print(printStream);
		}

		if (writerLeft != null) {
			printStream.printf("%-20s - %s\n", "writerLeft", "");
			writerLeft.print(printStream);
		}
	}

	public MeghaPalmPartInfo getLowerRight() {
		return lowerRight;
	}

	public void setLowerRight(Integer quality, byte[] lfmlFeatureData) {
		this.lowerRight = new MeghaPalmPartInfo((byte) ImagePosition.PALM_RLOWER.getPosition(), quality, lfmlFeatureData);
	}

	public MeghaPalmPartInfo getUpperRight() {
		return upperRight;
	}

	public void setUpperRight(Integer quality, byte[] lfmlFeatureData) {
		this.upperRight = new MeghaPalmPartInfo((byte) ImagePosition.PALM_RUPPER.getPosition(), quality, lfmlFeatureData);
	}

	public MeghaPalmPartInfo getLowerLeft() {
		return lowerLeft;
	}

	public void setLowerLeft(Integer quality, byte[] lfmlFeatureData) {
		this.lowerLeft = new MeghaPalmPartInfo((byte) ImagePosition.PALM_LLOWER.getPosition(), quality, lfmlFeatureData);
	}

	public MeghaPalmPartInfo getUpperLeft() {
		return upperLeft;
	}

	public void setUpperLeft(Integer quality, byte[] lfmlFeatureData) {
		this.upperLeft = new MeghaPalmPartInfo((byte) ImagePosition.PALM_LUPPER.getPosition(), quality, lfmlFeatureData);
	}

	public MeghaPalmPartInfo getWriterRight() {
		return writerRight;
	}

	public void setWriterRight(Integer quality, byte[] lfmlFeatureData) {
		this.writerRight = new MeghaPalmPartInfo((byte) ImagePosition.PALM_RWRITER.getPosition(), quality, lfmlFeatureData);
	}

	public MeghaPalmPartInfo getWriterLeft() {
		return writerLeft;
	}

	public void setWriterLeft(Integer quality, byte[] lfmlFeatureData) {
		this.writerLeft = new MeghaPalmPartInfo((byte) ImagePosition.PALM_LWRITER.getPosition(), quality, lfmlFeatureData);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).featureHoldFlag(1)
				.bytes(1).quality(1).featureDataLength(4).featureData(1, "PALM_LFML_SPLIT_FEATURE_DATA_SIZE")
				.bytes(1).quality(1).featureDataLength(4).featureData(1, "PALM_LFML_SPLIT_FEATURE_DATA_SIZE")
				.bytes(1).quality(1).featureDataLength(4).featureData(1, "PALM_LFML_SPLIT_FEATURE_DATA_SIZE")
				.bytes(1).quality(1).featureDataLength(4).featureData(1, "PALM_LFML_SPLIT_FEATURE_DATA_SIZE")
				.bytes(1).quality(1).featureDataLength(4).featureData(1, "PALM_LFML_WRITERS_FEATURE_DATA_SIZE")
				.bytes(1).quality(1).featureDataLength(4).featureData(1, "PALM_LFML_WRITERS_FEATURE_DATA_SIZE")
				.build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.PALM_LFML);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.PALM_LFML.getValue().byteValue());

		featureHoldFlag = 0;
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 0, lowerRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 1, upperRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 2, lowerLeft != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 3, upperLeft != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 4, writerRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 5, writerLeft != null);

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());
		eventDataBuf.put(featureHoldFlag);

		writePalmPartInfo(eventDataBuf, lowerRight,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_SPLIT_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, upperRight,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_SPLIT_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, lowerLeft,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_SPLIT_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, upperLeft,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_SPLIT_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, writerRight,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_WRITERS_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, writerLeft,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_WRITERS_FEATURE_DATA_SIZE"));

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		featureHoldFlag = eventDataBuf.get();

		List<Integer> featureIndexFlagList = HoldFlagUtil.getHoldFlagIndexList(featureHoldFlag, 6);

		lowerRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_SPLIT_FEATURE_DATA_SIZE"), featureIndexFlagList.contains(0));
		upperRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_SPLIT_FEATURE_DATA_SIZE"), featureIndexFlagList.contains(1));
		lowerLeft = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_SPLIT_FEATURE_DATA_SIZE"), featureIndexFlagList.contains(2));
		upperLeft = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_SPLIT_FEATURE_DATA_SIZE"), featureIndexFlagList.contains(3));
		writerRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_WRITERS_FEATURE_DATA_SIZE"), featureIndexFlagList.contains(4));
		writerLeft = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_LFML_WRITERS_FEATURE_DATA_SIZE"), featureIndexFlagList.contains(5));
	}

	private void writePalmPartInfo(ByteBuffer eventDataBuf, MeghaPalmPartInfo palmPartInfo, int featureDataSize)
			throws MeghaTemplateException {
		if (palmPartInfo != null && palmPartInfo.getFeatureData() != null) {
			if (palmPartInfo.getFeatureData().length == 0 || palmPartInfo.getFeatureData().length > featureDataSize) {
				throw new MeghaTemplateException("Invalid lfmlFeatureData length, actual: "
						+ palmPartInfo.getFeatureData().length + ", expected: " + featureDataSize
						+ " for palmPartNumber: " + palmPartInfo.getPartNumber());
			}
			eventDataBuf.put(palmPartInfo.getPartNumber());
			eventDataBuf.put(palmPartInfo.getQuality());
			eventDataBuf.putInt(palmPartInfo.getFeatureData().length);
			eventDataBuf.put(palmPartInfo.getFeatureData());

			eventDataBuf.position(eventDataBuf.position() + featureDataSize - palmPartInfo.getFeatureData().length);
		} else {
			eventDataBuf.position(eventDataBuf.position() + 1 + 1 + 4 + featureDataSize);
		}
	}

	private MeghaPalmPartInfo readPalmPartInfo(ByteBuffer eventDataBuf, int featureDataSize, boolean featureFlag)
			throws MeghaTemplateException {
		if (featureFlag) {
			MeghaPalmPartInfo palmPartInfo = new MeghaPalmPartInfo();
			palmPartInfo.setPartNumber(eventDataBuf.get());
			palmPartInfo.setQuality(eventDataBuf.get());

			int dataSize = eventDataBuf.getInt();
			if (dataSize == 0 || dataSize > featureDataSize) {
				throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
						+ featureDataSize + " for palmPartNumber: " + palmPartInfo.getPartNumber());
			}

			byte[] lfmlFeatureData = new byte[featureDataSize];
			eventDataBuf.get(lfmlFeatureData);

			palmPartInfo.setFeatureData(lfmlFeatureData);

			eventDataBuf.position(eventDataBuf.position() + featureDataSize - dataSize);

			return palmPartInfo;
		} else {
			eventDataBuf.position(eventDataBuf.position() + 1 + 1 + 4 + featureDataSize);
			return null;
		}
	}

}
