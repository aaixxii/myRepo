
package com.nec.biomatcher.comp.sync.complete.service.dataAccess.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.dao.DataAccessException;

import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.sync.complete.service.dataAccess.SyncSegCallbackServiceDao;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

public class SyncSegCallbackServiceDaoImp extends AbstractHibernateDao implements SyncSegCallbackServiceDao {

	private static final Logger logger = Logger.getLogger(SyncSegCallbackServiceDaoImp.class);

	@Override
	public List<BioMatcherNodeSegmentInfo> getAllActiveSnSegInfo() throws DaoException {
		try {
			List<BioMatcherNodeSegmentInfo> entityList = getAllEntity(BioMatcherNodeSegmentInfo.class);
			return entityList;
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	@Override
	public List<BioMatcherSegmentInfo> getAllSegmentInfo() throws DaoException {

		try {
			List<BioMatcherSegmentInfo> entityList = getAllEntity(BioMatcherSegmentInfo.class);
			return entityList;
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	public <T> List<T> getAllEntity(Class<T> entityClass) throws DaoException {
		return getHibernateTemplate().loadAll(entityClass);
	}

	@Override
	public List<BioMatcherNodeSegmentInfo> getNodeSegmentInfoBySegId(Integer segmentId) {
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(BioMatcherNodeSegmentInfo.class);

			if (segmentId != null) {
				criteria.add(Restrictions.eq("segmentId", segmentId));
			}
			criteria.add(Restrictions.eq("assignedFlag", true));
			criteria.addOrder(Order.asc("matcherNodeId"));
			return getEntityList(criteria);
		} catch (DataAccessException | DaoException ex) {
			logger.error(ex.getMessage(), ex);
			return null;
		}
	}

	@Override
	public List<BiometricEventInfo> getStrictBiometricEventInfoList(Integer segmentId, Long segmetVer, String siteId)
			throws DaoException {
		try {
			DetachedCriteria criteria = DetachedCriteria.forClass(BiometricEventInfo.class);

			if (segmentId != null) {
				criteria.add(Restrictions.eq("assignedSegmentId", segmentId));
			}

			if (segmetVer != null) {
				criteria.add(Restrictions.ge("dataVersion", segmetVer));
			}

			if (StringUtils.isNotBlank(siteId)) {
				criteria.add(Restrictions.eq("siteId", siteId));
			}

			criteria.addOrder(Order.desc("createDateTime"));

			return getEntityList(criteria);
		} catch (DataAccessException ex) {
			throw new DaoException(ex);
		}
	}

	@Override
	public void saveBioSegmentInfo(BioMatcherSegmentInfo segInfo) throws DaoException {
		try {
			saveEntity(segInfo);
			this.flush();
		} catch (DataAccessException ex) {
			throw new DaoException(ex);
		}
	}

	@Override
	public void saveBioNodeSegmentInfo(List<BioMatcherNodeSegmentInfo> snSegList) throws DaoException {
		try {
			for (BioMatcherNodeSegmentInfo info : snSegList) {
				saveEntity(info);
			}
		} catch (DataAccessException ex) {
			throw new DaoException(ex);
		}
	}

}
