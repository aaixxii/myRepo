package com.nec.biomatcher.comp.util;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.AtomicLongMap;
import com.nec.biomatcher.comp.common.sequence.BioSequenceGenerator;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;

/**
 * Utility class for generating sequence numbers.
 * 
 * This utility class tries to address following
 * 
 * 1) Sequence number is not supported by database 2) For scenarios where
 * sequence generator should not join the current business logic transaction. 4)
 * In order to remove the bottleneck on the sequence record during high volume
 * usage,
 * 
 * It will try to get next sequence incremented by sum of all incrementBy and
 * distribute it.
 * 
 * @author mreddy
 */
public class ConcurrentSequenceGenerator {

	private static final Logger logger = Logger.getLogger(ConcurrentSequenceGenerator.class);

	/** The Constant DEFAULT_SEQUENCE_GROUP. */
	private static final String DEFAULT_SEQUENCE_GROUP = "DEFAULT";

	/** The Constant executorService. */
	private static final ExecutorService executorService = Executors.newCachedThreadPool();

	/** The Constant stripedIncrementByMapLocks. */
	private static final ConcurrentValuedHashMap<String, Lock> stripedIncrementByMapLocks = new ConcurrentValuedHashMap<>(
			k -> new ReentrantLock()); // Striped.lazyWeakLock(512);

	/** The Constant incrementByMap. */
	private static final AtomicLongMap<String> incrementByMap = AtomicLongMap.create();

	/** The bio sequence generator. */
	private BioSequenceGenerator bioSequenceGenerator;

	private ConcurrentValuedHashMap<String, LinkedBlockingQueue<Long>> sequenceIdMap = new ConcurrentValuedHashMap<>(
			k -> new LinkedBlockingQueue<>());

	public final Long next(final String name) throws Exception {
		return next(name, DEFAULT_SEQUENCE_GROUP);
	}

	public final Long next(final String name, final String group) throws Exception {

		final String key = name + ":" + group;

		incrementByMap.incrementAndGet(key);

		LinkedBlockingQueue<Long> sequenceIdQueue = sequenceIdMap.getValue(key);

		Long acquiredSequenceId = sequenceIdQueue.poll();
		if (acquiredSequenceId != null) {
			return acquiredSequenceId;
		}

		final Lock mapLock = stripedIncrementByMapLocks.getValue(key);
		mapLock.lock();
		try {
			acquiredSequenceId = sequenceIdQueue.poll();
			if (acquiredSequenceId != null) {
				return acquiredSequenceId;
			}

			BiKey<Long, Integer> acquiredSequenceInfo = asyncNext(name, group, key);
			incrementByMap.addAndGet(key, -1 * acquiredSequenceInfo.b);

			logger.debug("In ConcurrentSequenceGenerator.next: name: " + name + ", sequenceNumber: "
					+ acquiredSequenceInfo.a + ", incrementBy: " + acquiredSequenceInfo.b);

			acquiredSequenceId = acquiredSequenceInfo.a;

			for (int index = 1; index < acquiredSequenceInfo.b; index++) {
				sequenceIdQueue.add(acquiredSequenceId + index);
			}
			return acquiredSequenceId;
		} finally {
			mapLock.unlock();
		}
	}

	public final Long bulkNext(final String name, final int count) throws Exception {
		return bulkNext(name, DEFAULT_SEQUENCE_GROUP, count);
	}

	public final Long bulkNext(final String name, final String group, final int count) throws Exception {

		Future<BiKey<Long, Integer>> future = executorService.submit(new Callable<BiKey<Long, Integer>>() {
			public BiKey<Long, Integer> call() throws Exception {
				long sequenceNumber = bioSequenceGenerator.next(name, group, count);
				logger.info("In bulkNext, After bioSequenceGenerator.next: name: " + name + ", sequenceNumber: "
						+ sequenceNumber + ", count: " + count);
				return new BiKey<>(sequenceNumber, count);
			}
		});

		BiKey<Long, Integer> acquiredSequenceInfo = future.get();

		return acquiredSequenceInfo.a;
	}

	/**
	 * Async next.
	 *
	 * @param name
	 *            the name
	 * @param group
	 *            the group
	 * @param key
	 *            the key
	 * @return the long
	 * @throws Exception
	 *             the exception
	 */
	private BiKey<Long, Integer> asyncNext(final String name, final String group, final String key) throws Exception {
		Future<BiKey<Long, Integer>> future = executorService.submit(new Callable<BiKey<Long, Integer>>() {
			public BiKey<Long, Integer> call() throws Exception {
				int incrementBy = (int) incrementByMap.get(key);
				long sequenceNumber = bioSequenceGenerator.next(name, group, incrementBy);
				logger.debug("In ConcurrentSequenceGenerator.asyncNext: name: " + name + ", sequenceNumber: "
						+ sequenceNumber + ", incrementBy: " + incrementBy);
				return new BiKey<>(sequenceNumber, incrementBy);
			}
		});

		return future.get();
	}

	public void setBioSequenceGenerator(BioSequenceGenerator bioSequenceGenerator) {
		this.bioSequenceGenerator = bioSequenceGenerator;
	}

}
