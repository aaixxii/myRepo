package com.nec.biomatcher.comp.common.query.criteria;

/**
 * @author srinivasarao
 *
 */
public class NotInCriteria extends CriteriaDto implements ValueCriteriaDto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The value. */
	private Object value;

	/**
	 * Instantiates a new equal criteria.
	 */
	public NotInCriteria() {

	}

	/**
	 * Instantiates a new equal criteria.
	 *
	 * @param value
	 *            the value
	 */
	public NotInCriteria(Object value) {
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value
	 *            the value to set
	 */
	public void setValue(Object value) {
		this.value = value;
	}
}