package com.nec.biomatcher.comp.admin.impl;

import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.collect.Sets;
import com.nec.biomatcher.comp.admin.BioAdminService;
import com.nec.biomatcher.comp.admin.exception.BioAdminServiceException;
import com.nec.biomatcher.comp.admin.model.BioUserInfo;
import com.nec.biomatcher.comp.admin.model.BioUserInfoList;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.JaxbSerializer;
import com.nec.biomatcher.core.framework.common.StringUtil;
import com.nec.biomatcher.core.framework.web.session.UserSession;

public class BioAdminServiceImpl implements BioAdminService, InitializingBean {
	private static final Logger logger = Logger.getLogger(BioAdminServiceImpl.class);

	private static final JaxbSerializer JAXB_SERIALIZER = JaxbSerializer.getInstance(BioUserInfoList.class,
			BioUserInfo.class);

	private static Function<String, Map<String, String>> GET_DISPLAY_LABEL_MAP_FUNCTION = null;

	private BioParameterService bioParameterService;

	public UserSession login(String userId, String password) throws BioAdminServiceException {
		BioUserInfo bioUserInfo = getUser(userId);

		if (bioUserInfo == null) {
			throw new BioAdminServiceException("User does not exists with userId: " + userId);
		}

		if (!bioUserInfo.getPassword().equals(password)) {
			throw new BioAdminServiceException("Password does not match");
		}

		UserSession userSession = new UserSession();
		userSession.setUserAcctId(bioUserInfo.getUserId());
		userSession.setUserId(bioUserInfo.getUserId());
		userSession.setUserName(bioUserInfo.getUserName());
		userSession.setRoles(new HashSet<>(bioUserInfo.getRoles()));

		return userSession;
	}

	public void saveUser(BioUserInfo bioUserInfo) throws BioAdminServiceException {
		try {
			BioUserInfoList bioUserInfoList = getUserInfoList();
			bioUserInfoList.addUser(bioUserInfo);
			saveUserInfoList(bioUserInfoList);
		} catch (Throwable th) {
			throw new BioAdminServiceException("Error in saveUser: " + th.getMessage(), th);
		}
	}

	public BioUserInfo getUser(String userId) throws BioAdminServiceException {
		try {
			BioUserInfoList bioUserInfoList = getUserInfoList();
			return bioUserInfoList.getUser(userId);
		} catch (Throwable th) {
			throw new BioAdminServiceException("Error creating User: " + th.getMessage(), th);
		}
	}

	public void deleteUser(String userId) throws BioAdminServiceException {
		try {
			BioUserInfoList bioUserInfoList = getUserInfoList();
			bioUserInfoList.removeUser(userId);
			saveUserInfoList(bioUserInfoList);
		} catch (Throwable th) {
			throw new BioAdminServiceException("Error in deleteUser: " + th.getMessage(), th);
		}
	}

	public BioUserInfoList getUserInfoList() throws BioAdminServiceException {
		try {
			String userInfoListXml = bioParameterService.getParameterValue("USER_INFO_LIST", "ADMIN");

			BioUserInfoList bioUserInfoList = (BioUserInfoList) JAXB_SERIALIZER.unmarshal(userInfoListXml);

			return bioUserInfoList;
		} catch (Throwable th) {
			throw new BioAdminServiceException("Error in getUserInfoList : " + th.getMessage(), th);
		}
	}

	private void saveUserInfoList(BioUserInfoList bioUserInfoList) throws BioAdminServiceException {
		try {
			String userInfoListXml = JAXB_SERIALIZER.marshal(bioUserInfoList);
			bioParameterService.saveParameterValue("USER_INFO_LIST", "ADMIN", userInfoListXml);
		} catch (Throwable th) {
			throw new BioAdminServiceException("Error in saveUserInfoList : " + th.getMessage(), th);
		}
	}

	public Map<String, String> getDisplayLabelMap(String displayLabelGroup) throws BioAdminServiceException {
		try {
			if (GET_DISPLAY_LABEL_MAP_FUNCTION == null) {
				GET_DISPLAY_LABEL_MAP_FUNCTION = (p) -> {
					if (StringUtils.isBlank(p)) {
						return Collections.emptyMap();
					} else {
						TreeMap<String, String> map = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
						map.putAll(StringUtil.stringToMap(p, "=", ","));
						return map;
					}
				};
			}

			Map<String, String> displayLabelMap = bioParameterService.getParameterValue(displayLabelGroup, "ADMIN",
					GET_DISPLAY_LABEL_MAP_FUNCTION);

			return displayLabelMap;
		} catch (Throwable th) {
			throw new BioAdminServiceException("Error creating User: " + th.getMessage(), th);
		}
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {

		BioUserInfo bioUserInfo = new BioUserInfo();
		bioUserInfo.setUserId("ADMIN");
		bioUserInfo.setUserName("Administrator");
		bioUserInfo.setPassword("password");
		bioUserInfo.setDateTimeCreate(new Date());
		bioUserInfo.setRoles(Sets.newHashSet("Administrator"));

		BioUserInfoList bioUserInfoList = new BioUserInfoList();
		bioUserInfoList.addUser(bioUserInfo);

		try {
			String userInfoListXml = JAXB_SERIALIZER.marshal(bioUserInfoList);
			bioParameterService.saveParameterValueIfNotExists("USER_INFO_LIST", "ADMIN", "STRING", "User List",
					userInfoListXml);
		} catch (Throwable th) {
			throw new BioAdminServiceException("Error in afterPropertiesSet while creating User: " + th.getMessage(),
					th);
		}

	}

}
