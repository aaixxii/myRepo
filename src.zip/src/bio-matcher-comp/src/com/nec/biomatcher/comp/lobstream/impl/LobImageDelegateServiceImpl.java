package com.nec.biomatcher.comp.lobstream.impl;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.cluster.ClusterInstance;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.comp.lobstream.util.LobStorageType;
import com.nec.biomatcher.comp.util.ValueChangeNotification;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ThreadUtils;

public class LobImageDelegateServiceImpl  implements LobImageService, InitializingBean {
    private static final Logger logger = Logger.getLogger(LobImageDelegateServiceImpl.class);
    
    private BioParameterService bioParameterService;
    private LobImageService lobImageFileService;
    private LobImageService lobImageCassandraService;
    private LobImageService lobImageMsSqlServerService;
    private ClusterInstance adminClusterInstance;
    
    private LobImageService lobImageDelegateService;
    
    @Override
    public String createLob(String lobId, byte[] lobData, String lobType) throws LobImageServiceException {
        return lobImageDelegateService.createLob(lobId, lobData, lobType);
    }

    @Override
    public String createLob(byte[] lobData, String lobType) throws LobImageServiceException {
        return lobImageDelegateService.createLob(lobData, lobType);
    }

    @Override
    public byte[] getLobData(String lobId, String lobType) throws LobImageServiceException, LobImageNotFoundException {
        return lobImageDelegateService.getLobData(lobId, lobType);
    }

    @Override
    public boolean checkLobExists(String lobId, String lobType) throws LobImageServiceException {
        return lobImageDelegateService.checkLobExists(lobId, lobType);
    }

    @Override
    public boolean deleteLob(String lobId, String lobType) throws LobImageServiceException {
        return lobImageDelegateService.deleteLob(lobId, lobType);
    }

    @Override
    public void deleteLobsByLobId(String lobId) throws LobImageServiceException {
        lobImageDelegateService.deleteLobsByLobId(lobId);
    }
    
    @Override
    public void performLobHousekeeping() {
        CommonLogger.STATUS_LOG.info("In performLobHousekeeping start");
        long startTimestampMilli = System.currentTimeMillis();
        try {
            lobImageDelegateService.performLobHousekeeping();
        }
        finally {
            CommonLogger.STATUS_LOG.info("In performLobHousekeeping end: timeTakenMilli: "+(System.currentTimeMillis()-startTimestampMilli));
        }
    }

    private void setLobStorageType(String logStorageTypeValue) {
        logger.info("In LobImageDelegateServiceImpl.setLobStorageType: logStorageTypeValue: "+logStorageTypeValue);
        LobStorageType lobStorageType = LobStorageType.FILE;
        try {
            lobStorageType = LobStorageType.valueOf(logStorageTypeValue);
        }
        catch(Throwable th) {
            CommonLogger.CONFIG_LOG.error("Error converting logStorageTypeValue("+logStorageTypeValue+") to valid LobStorageType {"+Arrays.asList(LobStorageType.values())+"}");
            lobStorageType = LobStorageType.FILE;
        }
        
        CommonLogger.CONFIG_LOG.info("In setLobStorageType: "+lobStorageType);
        
        switch (lobStorageType) {
        case FILE:
            lobImageDelegateService = lobImageFileService;
            break;
        case MSDB:
            lobImageDelegateService = lobImageMsSqlServerService;
            break;           
        case CASSANDRA:
            lobImageDelegateService = lobImageCassandraService;
            break;
        default:
            throw new RuntimeException(new LobImageServiceException("LobStorageType: " + lobStorageType + " is not supported"));
        }
    }   
    
    @Override
    public void afterPropertiesSet() throws Exception {
        logger.info("In LobImageDelegateServiceImpl.afterPropertiesSet");
        
        ValueChangeNotification<String> lobStorageTypeVCN = BioParameterService.getValueChangeNotification(bioParameterService, "LOB_STORAGE_TYPE", "DEFAULT", "FILE", value ->setLobStorageType(value));
        lobStorageTypeVCN.checkAndNotify();

        Runnable lobStorageHouseKeepingTask = () -> {
            ThreadUtils.prefixThreadName("LOBSTREAM_HOUSEKEEPING");
            int lobHousekeepingDelayMinutes = 60;
            Lock lobHousekeepingLock  = null;
            while (!ShutdownHook.isShutdownFlag) {
                try {
                    if(lobHousekeepingLock==null) {
                        lobHousekeepingLock = adminClusterInstance.getLock("LOBSTREAM_HOUSEKEEPING_LOCK");
                    }
                    
                    if(lobHousekeepingLock.tryLock()) {
                        try {
                            performLobHousekeeping();
                        }
                        finally {
                            lobHousekeepingLock.unlock();
                        }
                    }
                    lobHousekeepingDelayMinutes = bioParameterService.getParameterValue("LOBSTREAM_HOUSEKEEPING_DELAY_MINUTES", "DEFAULT", lobHousekeepingDelayMinutes);
                } catch (Throwable th) {
                    logger.error("Error during lobstream housekeeping : " + th.getMessage(), th);
                } finally {
                    Uninterruptibles.sleepUninterruptibly(lobHousekeepingDelayMinutes, TimeUnit.MINUTES);
                }
            }
        };

        CommonTaskScheduler.scheduleWithFixedDelay(lobStorageHouseKeepingTask, 90, 60, TimeUnit.SECONDS);
    }

    public void setBioParameterService(BioParameterService bioParameterService) {
        this.bioParameterService = bioParameterService;
    }

    public void setLobImageFileService(LobImageService lobImageFileService) {
        this.lobImageFileService = lobImageFileService;
    }
    
    public void setLobImageMsSqlServerService(LobImageService lobImageMsSqlServerService) {
        this.lobImageFileService = lobImageMsSqlServerService;
    }

    public void setLobImageCassandraService(LobImageService lobImageCassandraService) {
        this.lobImageCassandraService = lobImageCassandraService;
    }

    public void setAdminClusterInstance(ClusterInstance adminClusterInstance) {
        this.adminClusterInstance = adminClusterInstance;
    }
}
