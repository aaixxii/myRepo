package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;

public abstract class MeghaTemplate {
	protected MeghaTemplateHeader templateHeader;
	protected int userFlagByteCount = 8;

	public MeghaTemplate(int userFlagByteCount) {
		this.userFlagByteCount = userFlagByteCount;
	}

	public MeghaTemplateHeader getTemplateHeader() {
		return templateHeader;
	}

	public void setTemplateHeader(MeghaTemplateHeader templateHeader) {
		this.templateHeader = templateHeader;
	}

	public abstract byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException;

	public abstract void unpack(byte[] templateData, MeghaTemplateConfig meghaTemplateConfig)
			throws MeghaTemplateException;

	public abstract void print(PrintStream printStream);

	public static final int calculateTemplateSize(int templateHeaderSize, int eventDataSize, int maxEventCount) {
		return templateHeaderSize + eventDataSize * maxEventCount;
	}

}
