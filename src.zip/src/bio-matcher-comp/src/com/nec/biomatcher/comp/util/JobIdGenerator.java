package com.nec.biomatcher.comp.util;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.LongBinaryOperator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.sequence.BioSequenceGenerator;
import com.nec.biomatcher.core.framework.common.CommonLogger;

public class JobIdGenerator implements InitializingBean {
	private static final Logger logger = Logger.getLogger(JobIdGenerator.class);

	public static final String DEFAULT_PREFIX = "JOB-";
	private static final LongBinaryOperator accumulatorFunction = (ov, nv) -> ov + nv;
	private static final AtomicLong idCounter = new AtomicLong(0);

	private BioSequenceGenerator bioSequenceGenerator;
	private long jobIdOffsetIndex = System.currentTimeMillis();

	// public final String nextId() {
	// return DEFAULT_PREFIX+jobIdOffsetIndex+"-"+idCounter.accumulateAndGet(1,
	// accumulatorFunction);
	// }

	public final String nextId(String userPrefix) {
		return DEFAULT_PREFIX + userPrefix + "-" + jobIdOffsetIndex + "-"
				+ idCounter.accumulateAndGet(1, accumulatorFunction);
	}

	public static final String getUserPrefix(String jobId) {
		if (jobId.startsWith(DEFAULT_PREFIX)) {
			String[] splitParts = jobId.trim().split("-");
			if (splitParts.length == 4) {
				return splitParts[1];
			} else if (splitParts.length > 4) {
				StringBuilder sb = new StringBuilder(splitParts[1]);
				for (int i = 0; i < splitParts.length - 4; i++) {
					sb.append("-").append(splitParts[2 + i]);
				}
				return sb.toString();
			}
		}
		return null;
	}

	public void setBioSequenceGenerator(BioSequenceGenerator bioSequenceGenerator) {
		this.bioSequenceGenerator = bioSequenceGenerator;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		jobIdOffsetIndex = bioSequenceGenerator.next("JOB_ID_OFFSET_SEQ", BioSequenceGenerator.DEFAULT_SEQUENCE_GROUP,
				1);
		CommonLogger.STATUS_LOG.info("In JobIdGenerator: jobIdOffsetIndex: " + jobIdOffsetIndex);
	}

}
