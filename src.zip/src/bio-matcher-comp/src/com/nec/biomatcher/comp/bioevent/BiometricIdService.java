package com.nec.biomatcher.comp.bioevent;

import java.util.List;

import com.nec.biomatcher.comp.bioevent.exception.BiometricIdServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdDetailInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;

/**
 * The Interface BiometricIdService.
 */
public interface BiometricIdService {

	/**
	 * Gets the biometric sequence id info list.
	 *
	 * @param binId
	 *            the bin id
	 * @return the biometric sequence id info list
	 * @throws BiometricIdServiceException
	 *             the biometric id service exception
	 */
	public List<BiometricIdInfo> getBiometricSequenceIdInfoList(Integer binId) throws BiometricIdServiceException;

	public BiometricIdInfo getBiometricIdInfoBySegmentId(Integer segmentId) throws BiometricIdServiceException;

	/**
	 * Acquire biometric id list.
	 *
	 * @param segmentId
	 *            the segment id
	 * @param count
	 *            the count
	 * @return the list
	 * @throws BiometricIdServiceException
	 *             the biometric id service exception
	 */
	public List<BiometricIdDetailInfo> acquireBiometricIdList(Integer segmentId, Integer count)
			throws BiometricIdServiceException;

	/**
	 * Acquire released biometric id list.
	 *
	 * @param segmentId
	 *            the segment id
	 * @param count
	 *            the count
	 * @return the list
	 * @throws BiometricIdServiceException
	 *             the biometric id service exception
	 */
	public List<BiometricIdDetailInfo> acquireReleasedBiometricIdList(Integer segmentId, Integer count)
			throws BiometricIdServiceException;

	public List<BiometricIdDetailInfo> acquireReleasedBiometricIdListByBinId(Integer binId, Integer count)
			throws BiometricIdServiceException;

	/**
	 * Release biometric ids.
	 *
	 * @param releasedBiometricIdList
	 *            the released biometric id list
	 * @throws BiometricIdServiceException
	 *             the biometric id service exception
	 */
	public void releaseBiometricIds(List<BiometricIdDetailInfo> releasedBiometricIdList)
			throws BiometricIdServiceException;

	public void commitAcquiredBiometricIdList(List<Long> commitBiometricIdList) throws BiometricIdServiceException;

	public void releaseOldBiometricIdsByAcquireHost() throws BiometricIdServiceException;

}
