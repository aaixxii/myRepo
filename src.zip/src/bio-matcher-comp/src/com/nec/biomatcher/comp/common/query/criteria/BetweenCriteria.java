package com.nec.biomatcher.comp.common.query.criteria;

/**
 * Criteria for specifying between condition.
 *
 * @author Mahesh
 */
public class BetweenCriteria extends CriteriaDto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The from value. */
	private Object fromValue;

	/** The to value. */
	private Object toValue;

	/**
	 * Instantiates a new between criteria.
	 */
	public BetweenCriteria() {

	}

	/**
	 * Gets the from value.
	 *
	 * @return the fromValue
	 */
	public Object getFromValue() {
		return fromValue;
	}

	/**
	 * Sets the from value.
	 *
	 * @param fromValue
	 *            the fromValue to set
	 */
	public void setFromValue(Object fromValue) {
		this.fromValue = fromValue;
	}

	/**
	 * Gets the to value.
	 *
	 * @return the toValue
	 */
	public Object getToValue() {
		return toValue;
	}

	/**
	 * Sets the to value.
	 *
	 * @param toValue
	 *            the toValue to set
	 */
	public void setToValue(Object toValue) {
		this.toValue = toValue;
	}

}
