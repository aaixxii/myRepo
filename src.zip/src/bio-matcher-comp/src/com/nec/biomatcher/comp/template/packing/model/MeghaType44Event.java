package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Set;

import com.google.common.collect.Sets;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType44Event extends MeghaEvent {
	public static final int MAX_LATENT_PATTERNS_COUNT = 7;
	public static final int MAX_FINGER_COUNT = 10;

	byte fingerNumbers[];
	byte latentPatterns[];
	byte manualEdit;
	byte lfmlFeatureData[];

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "fingerNumbers", Arrays.toString(fingerNumbers));
		printStream.printf("%-20s - %s\n", "latentPatterns",
				Arrays.toString(new String(latentPatterns, StandardCharsets.UTF_8).toCharArray()));
		printStream.printf("%-20s - %s\n", "manualEdit", manualEdit);
		printStream.printf("%-20s - %s\n", "lfmlFeatureData", lfmlFeatureData != null);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).bytes(MAX_FINGER_COUNT)
				.bytes(MAX_LATENT_PATTERNS_COUNT).bytes(1).featureDataLength(4)
				.featureData(1, "LATENT_FINGER_LFML_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FINGER_LFML);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (lfmlFeatureData == null) {
			throw new MeghaTemplateException("Invalid lfmlFeatureData is not set");
		}

		if (lfmlFeatureData.length == 0 || lfmlFeatureData.length > meghaTemplateConfig
				.getFeatureSize("LATENT_FINGER_LFML_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid lfmlFeatureData length, actual: " + lfmlFeatureData.length
					+ ", expected: " + meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LFML_FEATURE_DATA_SIZE"));
		}

		if (fingerNumbers != null && fingerNumbers.length != MAX_FINGER_COUNT) {
			throw new MeghaTemplateException("Invalid fingerNumbers length, actual: " + fingerNumbers.length
					+ ", expected: " + MAX_FINGER_COUNT);
		}

		if (latentPatterns != null && latentPatterns.length != MAX_LATENT_PATTERNS_COUNT) {
			throw new MeghaTemplateException("Invalid latentPatterns length, actual: " + latentPatterns.length
					+ ", expected: " + MAX_LATENT_PATTERNS_COUNT);
		}

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());

		if (fingerNumbers == null) {
			fingerNumbers = new byte[MAX_FINGER_COUNT];
		}

		eventDataBuf.put(fingerNumbers);

		if (latentPatterns == null) {
			latentPatterns = new byte[MAX_LATENT_PATTERNS_COUNT];
		}

		eventDataBuf.put(latentPatterns);

		eventDataBuf.put(manualEdit);

		eventDataBuf.putInt(lfmlFeatureData.length);

		eventDataBuf.put(lfmlFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LFML_FEATURE_DATA_SIZE") - lfmlFeatureData.length);

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		fingerNumbers = new byte[MAX_FINGER_COUNT];
		eventDataBuf.get(fingerNumbers);

		latentPatterns = new byte[MAX_LATENT_PATTERNS_COUNT];
		eventDataBuf.get(latentPatterns);

		manualEdit = eventDataBuf.get();

		int dataSize = eventDataBuf.getInt();
		if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LFML_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
					+ meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LFML_FEATURE_DATA_SIZE"));
		}

		lfmlFeatureData = new byte[dataSize];
		eventDataBuf.get(lfmlFeatureData);
		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("LATENT_FINGER_LFML_FEATURE_DATA_SIZE") - dataSize);
	}

	public byte[] getLfmlFeatureData() {
		return lfmlFeatureData;
	}

	public void setLfmlFeatureData(byte[] lfmlFeatureData) {
		this.lfmlFeatureData = lfmlFeatureData;
	}

	public byte[] getFingerNumbers() {
		return fingerNumbers;
	}

	public void setFingerNumbers(byte[] fingerNumbers) {
		this.fingerNumbers = fingerNumbers;
	}

	public byte[] getLatentPatterns() {
		return latentPatterns;
	}

	public void setLatentPatterns(byte[] latentPatterns) {
		this.latentPatterns = latentPatterns;
	}

	public byte getManualEdit() {
		return manualEdit;
	}

	public void setManualEdit(byte manualEdit) {
		this.manualEdit = manualEdit;
	}

}
