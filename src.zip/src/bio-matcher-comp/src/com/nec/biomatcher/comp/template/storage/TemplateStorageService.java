package com.nec.biomatcher.comp.template.storage;

import java.util.List;
import java.util.Map;

import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateStorageInfo;
import com.nec.biomatcher.comp.template.storage.exception.TemplateStorageServiceException;
import com.nec.biomatcher.core.framework.cache.InvalidateMethodCache;
import com.nec.biomatcher.core.framework.cache.MethodCache;

/**
 * The Interface TemplateStorageService.
 */
public interface TemplateStorageService {

	/**
	 * Gets the template storage info.
	 *
	 * @param storageId
	 *            the storage id
	 * @return the template storage info
	 * @throws TemplateStorageServiceException
	 *             the template storage service exception
	 */
	@MethodCache
	public BioTemplateStorageInfo getTemplateStorageInfo(Integer storageId) throws TemplateStorageServiceException;

	@MethodCache
	public List<BioTemplateStorageInfo> getActiveTemplateStorageInfoList() throws TemplateStorageServiceException;

	@MethodCache
	public List<BioTemplateStorageInfo> getTemplateStorageInfoList() throws TemplateStorageServiceException;

	@MethodCache
	public Map<Integer, String> getTemplateStorageInfoMap() throws TemplateStorageServiceException;

	/**
	 * Activate template storage info.
	 *
	 * @param storageId
	 *            the storage id
	 * @throws TemplateStorageServiceException
	 *             the template storage service exception
	 */
	@InvalidateMethodCache
	public void activateTemplateStorageInfo(Integer storageId) throws TemplateStorageServiceException;

	/**
	 * Deactivate template storage info.
	 *
	 * @param storageId
	 *            the storage id
	 * @throws TemplateStorageServiceException
	 *             the template storage service exception
	 */
	@InvalidateMethodCache
	public void deactivateTemplateStorageInfo(Integer storageId) throws TemplateStorageServiceException;

	/**
	 * Save BioTemplateStorageInfo
	 * 
	 * @param templateStorageInfo
	 *            the template storage info
	 * @throws TemplateStorageServiceException
	 */
	@InvalidateMethodCache
	public void saveTemplateStorageInfo(BioTemplateStorageInfo templateStorageInfo)
			throws TemplateStorageServiceException;

	/**
	 * Updates BioTemplateStorageInfo
	 * 
	 * @param templateStorageInfo
	 *            the template storage info
	 * @throws TemplateStorageServiceException
	 */
	@InvalidateMethodCache
	public void updateTemplateStorageInfo(BioTemplateStorageInfo templateStorageInfo)
			throws TemplateStorageServiceException;

	/**
	 * Deletes BioTemplateStorageInfo
	 * 
	 * @param storageId
	 *            the storage id
	 * @throws TemplateStorageServiceException
	 */
	@InvalidateMethodCache
	public void deleteTemplateStorageInfo(Integer storageId) throws TemplateStorageServiceException;

}
