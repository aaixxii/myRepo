package com.nec.biomatcher.comp.matcher.node;

import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.zmq.ZmqConnectionException;
import com.nec.biomatcher.comp.zmq.ZmqReceiveException;
import com.nec.biomatcher.comp.zmq.ZmqSendException;

/**
 * The Class MatcherNodeClientHelper.
 */
public class MatcherNodeClientHelper {

	/**
	 * Handle send receive error.
	 * 
	 * @param serverId
	 * @param componentType
	 * @param th
	 */
	public void handleSendReceiveError(String serverId, BioComponentType componentType, Throwable th) {
		String componentTypePrefix = componentType != null ? componentType.name() + "_" : "";
		if (th instanceof BioMatcherNodeSendException || th instanceof ZmqSendException) {
			MetricsUtil.meter(componentType, serverId, componentTypePrefix + "SEND_TIMEOUT_ERROR");
		} else if (th instanceof BioMatcherNodeReceiveException || th instanceof ZmqReceiveException) {
			MetricsUtil.meter(componentType, serverId, componentTypePrefix + "RESPONSE_TIMEOUT_ERROR");
		} else if (th instanceof BioMatcherNodeConnectionException || th instanceof ZmqConnectionException) {
			MetricsUtil.meter(componentType, serverId, componentTypePrefix + "CONNECTION_ERROR");
		} else {
			MetricsUtil.meter(componentType, serverId, componentTypePrefix + "OTHER_ERROR");
		}
	}

	/**
	 * Handle sync send receive error.
	 *
	 * @param serverId
	 *            the server id
	 * @param componentType
	 *            the component type
	 * @param timeTakenMilli
	 *            the time taken milli
	 * @param th
	 *            the th
	 */
	public void handleSyncSendReceiveError(String serverId, BioComponentType componentType, long timeTakenMilli,
			Throwable th) {
		String componentTypePrefix = componentType != null ? componentType.name() + "_" : "";
		if (th instanceof BioMatcherNodeSendException || th instanceof ZmqSendException) {
			MetricsUtil.meter(componentType, serverId, componentTypePrefix + "SYNC_SEND_TIMEOUT_ERROR");
		} else if (th instanceof BioMatcherNodeReceiveException || th instanceof ZmqReceiveException) {
			MetricsUtil.meter(componentType, serverId, componentTypePrefix + "SYNC_RESPONSE_TIMEOUT_ERROR");
		} else if (th instanceof BioMatcherNodeConnectionException || th instanceof ZmqConnectionException) {
			MetricsUtil.meter(componentType, serverId, componentTypePrefix + "SYNC_CONNECTION_ERROR");
		} else {
			MetricsUtil.meter(componentType, serverId, componentTypePrefix + "SYNC_OTHER_ERROR");
		}
	}
}
