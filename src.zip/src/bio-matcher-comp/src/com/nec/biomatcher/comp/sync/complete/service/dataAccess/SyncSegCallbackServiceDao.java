package com.nec.biomatcher.comp.sync.complete.service.dataAccess;

import java.util.List;

import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

public interface SyncSegCallbackServiceDao extends HibernateDao {

	public void saveBioSegmentInfo(BioMatcherSegmentInfo segInfo) throws DaoException;

	public void saveBioNodeSegmentInfo(List<BioMatcherNodeSegmentInfo> snSegList) throws DaoException;

	public List<BioMatcherNodeSegmentInfo> getAllActiveSnSegInfo() throws DaoException;

	public List<BioMatcherSegmentInfo> getAllSegmentInfo() throws DaoException;

	public List<BioMatcherNodeSegmentInfo> getNodeSegmentInfoBySegId(Integer segmentId);

	public List<BiometricEventInfo> getStrictBiometricEventInfoList(Integer segmentId, Long segmetVer, String siteId)
			throws DaoException;

}
