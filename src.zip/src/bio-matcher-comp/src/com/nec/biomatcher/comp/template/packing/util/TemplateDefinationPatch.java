package com.nec.biomatcher.comp.template.packing.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameter;
import com.nec.biomatcher.core.framework.common.CommonLogger;

public class TemplateDefinationPatch {
	JsonParser jsonParser = new JsonParser();

	public void transformTemplateDefination(BioParameterService bioParameterService) {
		patchUserFlagByteCount(bioParameterService);
		patchMaxEventCount(bioParameterService);
	}

	public void patchMaxEventCount(BioParameterService bioParameterService) {
		CommonLogger.CONFIG_LOG.info("In patchMaxEventCount");
		try {
			BioParameter templateDefinationListParameter = bioParameterService.getParameter("TEMPLATE_DEFINITION_LIST",
					"DEFAULT");
			if (templateDefinationListParameter == null) {
				return;
			}

			if (StringUtils.isBlank(templateDefinationListParameter.getValue())) {
				CommonLogger.CONFIG_LOG.info(
						"In TemplateDefinationPatch.patchMaxEventCount: 'TEMPLATE_DEFINITION_LIST' parameter is blank, so ignoring the patch");
				bioParameterService.deleteParameter("TEMPLATE_DEFINITION_LIST", "DEFAULT");
				bioParameterService.deleteParameter("TEMPLATE_HEADER_DEFINITION_LIST", "DEFAULT");
				return;
			}

			BioParameter maxEventCountParameter = bioParameterService.getParameter("TEMPLATE_TYPE_MAX_EVENT_COUNT_MAP",
					"DEFAULT");
			if (maxEventCountParameter != null) {
				CommonLogger.CONFIG_LOG.info(
						"In TemplateDefinationPatch.patchMaxEventCount: 'TEMPLATE_TYPE_MAX_EVENT_COUNT_MAP' parameter already exists, so ignoring the patch");
				bioParameterService.deleteParameter("TEMPLATE_DEFINITION_LIST", "DEFAULT");
				bioParameterService.deleteParameter("TEMPLATE_HEADER_DEFINITION_LIST", "DEFAULT");
				return;
			}

			JsonObject jsonObject = jsonParser.parse(templateDefinationListParameter.getValue()).getAsJsonObject();
			JsonArray templateDefinitionList = jsonObject.getAsJsonArray("templateDefinitionList");
			Map<String, String> templateTypeMaxEventCountMap = new HashMap<>();
			for (int i = 0; i < templateDefinitionList.size(); i++) {
				JsonObject templateDefinition = templateDefinitionList.get(i).getAsJsonObject();
				JsonPrimitive templateTypeKeyObject = templateDefinition.getAsJsonPrimitive("templateTypeKey");
				JsonPrimitive maxEventCountObject = templateDefinition.getAsJsonPrimitive("maxEventCount");

				if (templateTypeKeyObject != null && maxEventCountObject != null) {
					String templateType = templateTypeKeyObject.getAsString();
					int maxEventCount = maxEventCountObject.getAsInt();
					templateTypeMaxEventCountMap.put(templateType, String.valueOf(maxEventCount));
					CommonLogger.CONFIG_LOG.info("In TemplateDefinationPatch.patchMaxEventCount: templateType: "
							+ templateType + ", maxEventCount: " + maxEventCount);
				}
			}
			if (!templateTypeMaxEventCountMap.isEmpty()) {
				bioParameterService.mergePropertyMap("TEMPLATE_TYPE_MAX_EVENT_COUNT_MAP", "DEFAULT",
						templateTypeMaxEventCountMap, Collections.emptySet(), "Template type max event count map");
				bioParameterService.deleteParameter("TEMPLATE_DEFINITION_LIST", "DEFAULT");
				bioParameterService.deleteParameter("TEMPLATE_HEADER_DEFINITION_LIST", "DEFAULT");
				CommonLogger.CONFIG_LOG.info(
						"In TemplateDefinationPatch.patchMaxEventCount: After saving the 'TEMPLATE_TYPE_MAX_EVENT_COUNT_MAP' parameter");
			}
		} catch (Throwable th) {
			CommonLogger.CONFIG_LOG.error("Error in patchMaxEventCount: " + th.getMessage(), th);
		}
	}

	public void patchUserFlagByteCount(BioParameterService bioParameterService) {
		CommonLogger.CONFIG_LOG.info("In patchUserFlagByteCount");
		try {
			BioParameter templateFieldsParameter = bioParameterService
					.getParameter("FIELD_CONTAINER_COMMON_TEMPLATE_FIELDS", "DEFAULT");
			if (templateFieldsParameter == null) {
				return;
			}

			if (StringUtils.isBlank(templateFieldsParameter.getValue())) {
				CommonLogger.CONFIG_LOG.info(
						"In TemplateDefinationPatch.patchUserFlagByteCount: 'FIELD_CONTAINER_COMMON_TEMPLATE_FIELDS' parameter is blank, so ignoring the patch");
				bioParameterService.deleteParameter("FIELD_CONTAINER_COMMON_TEMPLATE_FIELDS", "DEFAULT");
				bioParameterService.deleteParameter("TEMPLATE_HEADER_DEFINITION_LIST", "DEFAULT");
				return;
			}

			BioParameter userFlagsParameter = bioParameterService.getParameter("USER_FLAG_BYTE_COUNT", "DEFAULT");
			if (userFlagsParameter != null) {
				CommonLogger.CONFIG_LOG.info(
						"In TemplateDefinationPatch.patchUserFlagByteCount: 'USER_FLAG_BYTE_COUNT' parameter already exists, so ignoring the patch");
				bioParameterService.deleteParameter("FIELD_CONTAINER_COMMON_TEMPLATE_FIELDS", "DEFAULT");
				bioParameterService.deleteParameter("TEMPLATE_HEADER_DEFINITION_LIST", "DEFAULT");
				return;
			}

			JsonObject jsonObject = jsonParser.parse(templateFieldsParameter.getValue()).getAsJsonObject();
			JsonArray fieldDefinitionList = jsonObject.getAsJsonArray("fieldDefinitionList");
			for (int i = 0; i < fieldDefinitionList.size(); i++) {
				JsonObject fieldDefinition = fieldDefinitionList.get(i).getAsJsonObject();
				JsonPrimitive fieldIdObject = fieldDefinition.getAsJsonPrimitive("fieldId");
				if (fieldIdObject != null && "userFlags".equalsIgnoreCase(fieldIdObject.getAsString())) {
					int userFlagByteCount = fieldDefinition.getAsJsonPrimitive("fieldDataSize").getAsInt();
					bioParameterService.saveParameterValue("USER_FLAG_BYTE_COUNT", "DEFAULT", "NUMBER",
							"User Flag byte count", String.valueOf(userFlagByteCount));
					CommonLogger.CONFIG_LOG
							.info("In TemplateDefinationPatch.patchUserFlagByteCount: After saving the 'USER_FLAG_BYTE_COUNT' parameter with value: "
									+ userFlagByteCount);
					bioParameterService.deleteParameter("FIELD_CONTAINER_COMMON_TEMPLATE_FIELDS", "DEFAULT");
					bioParameterService.deleteParameter("TEMPLATE_HEADER_DEFINITION_LIST", "DEFAULT");
					break;
				}
			}
		} catch (Throwable th) {
			CommonLogger.CONFIG_LOG.error("Error in patchUserFlagByteCount: " + th.getMessage(), th);
		}
	}
}
