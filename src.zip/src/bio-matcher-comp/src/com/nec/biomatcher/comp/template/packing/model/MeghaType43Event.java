package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Sets;
import com.google.common.primitives.UnsignedInteger;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.PatternType;

public class MeghaType43Event extends MeghaEvent {
	public static final int COUNT_MAX_FINGERS = 20;

	private byte pad[] = new byte[6];

	private int featureHoldFlag = 0;

	private List<FingerInfo> fingerInfoList = new ArrayList<>();

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "featureHoldFlag",
				StringUtils.leftPad(UnsignedInteger.valueOf(featureHoldFlag).toString(2), Integer.SIZE, "0"));
		for (FingerInfo fingerInfo : fingerInfoList) {
			fingerInfo.print(printStream);
		}
	}

	private static int getFingerBlockSize(int featureDataSize) {
		return featureDataSize + 8;
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		int featureBlockSize = getFingerBlockSize(meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE"));
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).pad(6).featureHoldFlag(4)
				.bytes(COUNT_MAX_FINGERS * featureBlockSize).build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FINGER_LFML);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		featureHoldFlag = 0;

		for (FingerInfo fingerInfo : fingerInfoList) {
			int holdFlagIndex = fingerInfo.getFingerPosition() - 1;
			featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, holdFlagIndex, true);
		}

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());
		eventDataBuf.put(pad);
		eventDataBuf.putInt(featureHoldFlag);

		int fingerInfoOffsetPosition = eventDataBuf.position();

		for (FingerInfo fingerInfo : fingerInfoList) {
			int holdFlagIndex = fingerInfo.getFingerPosition() - 1;
			eventDataBuf.position(fingerInfoOffsetPosition + (holdFlagIndex
					* getFingerBlockSize(meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE"))));
			writeFingerInfo(fingerInfo, eventDataBuf, meghaTemplateConfig);
		}

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		eventDataBuf.position(eventDataBuf.position() + pad.length);

		featureHoldFlag = eventDataBuf.getInt();

		List<Integer> featureIndexFlagList = HoldFlagUtil.getHoldFlagIndexList(featureHoldFlag, 20);

		int fingerInfoOffsetPosition = eventDataBuf.position();

		for (int holdFlagIndex : featureIndexFlagList) {
			eventDataBuf.position(fingerInfoOffsetPosition + (holdFlagIndex
					* getFingerBlockSize(meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE"))));
			FingerInfo fingerInfo = new FingerInfo();
			readFingerInfo(fingerInfo, eventDataBuf, meghaTemplateConfig);
			fingerInfo.setFingerPosition(holdFlagIndex + 1);

			fingerInfoList.add(fingerInfo);
		}
	}

	private void writeFingerInfo(FingerInfo fingerInfo, ByteBuffer eventDataBuf,
			MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		eventDataBuf.put(fingerInfo.getPrimaryPatternType());
		eventDataBuf.put(fingerInfo.getSecondaryPatternType());
		eventDataBuf.put(fingerInfo.getQuality());
		eventDataBuf.put(new byte[1]);

		if (fingerInfo.getFeatureData() != null) {
			if (fingerInfo.getFeatureData().length > meghaTemplateConfig
					.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException(
						"Invalid lfmlFeatureData length, actual: " + fingerInfo.getFeatureData().length + ", expected: "
								+ meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE"));
			}

			eventDataBuf.putInt(fingerInfo.getFeatureData().length);

			eventDataBuf.put(fingerInfo.getFeatureData());

			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE")
							- fingerInfo.getFeatureData().length);

		} else {
			eventDataBuf.putInt(0);

			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE"));
		}
	}

	private void readFingerInfo(FingerInfo fingerInfo, ByteBuffer eventDataBuf, MeghaTemplateConfig meghaTemplateConfig)
			throws MeghaTemplateException {
		fingerInfo.setPrimaryPatternType(eventDataBuf.get());
		fingerInfo.setSecondaryPatternType(eventDataBuf.get());
		fingerInfo.setQuality(eventDataBuf.get());

		eventDataBuf.position(eventDataBuf.position() + 1);

		int dataSize = eventDataBuf.getInt();

		if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
					+ meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE"));
		}

		byte rdblFeatureData[] = new byte[dataSize];
		eventDataBuf.get(rdblFeatureData);
		fingerInfo.setFeatureData(rdblFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("FINGER_LFML_FEATURE_DATA_SIZE") - dataSize);
	}

	public List<FingerInfo> getFingerInfoList() {
		return fingerInfoList;
	}

	public void setFingerInfoList(List<FingerInfo> fingerInfoList) {
		this.fingerInfoList = fingerInfoList;
	}

	public void addFingerInfo(int fingerPosition, PatternType primaryPattern, PatternType secondaryPattern,
			Integer quality, byte[] rdblFeatureData) throws MeghaTemplateException {
		if (rdblFeatureData == null) {
			throw new MeghaTemplateException(
					"RDBL/SDBL LFML Feature data is null for fingerPosition: " + fingerPosition);
		}
		if (rdblFeatureData.length == 0) {
			throw new MeghaTemplateException(
					"RDBL/SDBL LFML Feature data size is 0 for fingerPosition: " + fingerPosition);
		}

		FingerInfo fingerInfo = new FingerInfo();
		fingerInfo.setFingerPosition(fingerPosition);
		fingerInfo.setFeatureData(rdblFeatureData);
		fingerInfo.setQuality(quality != null ? quality.byteValue() : 0);
		fingerInfo.setPrimaryPatternType(primaryPattern != null ? (byte) primaryPattern.getValue() : 0);
		fingerInfo.setSecondaryPatternType(secondaryPattern != null ? (byte) secondaryPattern.getValue() : 0);

		fingerInfoList.add(fingerInfo);
	}

	public class FingerInfo {
		int fingerPosition;
		byte primaryPatternType;
		byte secondaryPatternType;
		byte quality;
		byte featureData[];

		public void print(PrintStream printStream) {
			printStream.printf("%-20s - %s\n", "fingerPosition", fingerPosition);
			printStream.printf("%-20s - %s\n", "primaryPatternType", (char) primaryPatternType);
			printStream.printf("%-20s - %s\n", "secondaryPatternType", (char) secondaryPatternType);
			printStream.printf("%-20s - %s\n", "quality", quality);
			printStream.printf("%-20s - %s\n", "featureData", featureData != null);
		}

		public byte getPrimaryPatternType() {
			return primaryPatternType;
		}

		public void setPrimaryPatternType(byte primaryPatternType) {
			this.primaryPatternType = primaryPatternType;
		}

		public byte getSecondaryPatternType() {
			return secondaryPatternType;
		}

		public void setSecondaryPatternType(byte secondaryPatternType) {
			this.secondaryPatternType = secondaryPatternType;
		}

		public byte getQuality() {
			return quality;
		}

		public void setQuality(byte quality) {
			this.quality = quality;
		}

		public byte[] getFeatureData() {
			return featureData;
		}

		public void setFeatureData(byte[] featureData) {
			this.featureData = featureData;
		}

		public int getFingerPosition() {
			return fingerPosition;
		}

		public void setFingerPosition(int fingerPosition) {
			this.fingerPosition = fingerPosition;
		}
	}

}
