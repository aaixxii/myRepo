package com.nec.biomatcher.comp.entities.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BiometricIdDetailInfo.
 */
public class BiometricIdDetailInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The bin id. */
	private Integer binId;

	/** The segment id. */
	private Integer segmentId;

	/** The biometric id. */
	private Long biometricId;

	/** The reuse flag. */
	private Boolean reuseFlag = Boolean.FALSE;

	/** The acquire host. */
	private String acquireHost;

	/** The acquire date time. */
	private Date acquireDateTime;

	private transient boolean oldReusedFlag = false;

	/**
	 * Instantiates a new biometric id detail info.
	 */
	public BiometricIdDetailInfo() {

	}

	/**
	 * Instantiates a new biometric id detail info.
	 *
	 * @param binId
	 *            the bin id
	 * @param segmentId
	 *            the segment id
	 * @param biometricId
	 *            the biometric id
	 */
	public BiometricIdDetailInfo(Integer binId, Integer segmentId, Long biometricId) {
		this.binId = binId;
		this.segmentId = segmentId;
		this.biometricId = biometricId;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public Long getBiometricId() {
		return biometricId;
	}

	public void setBiometricId(Long biometricId) {
		this.biometricId = biometricId;
	}

	public Boolean getReuseFlag() {
		return reuseFlag;
	}

	public void setReuseFlag(Boolean reuseFlag) {
		this.reuseFlag = reuseFlag;
	}

	public String getAcquireHost() {
		return acquireHost;
	}

	public void setAcquireHost(String acquireHost) {
		this.acquireHost = acquireHost;
	}

	public Date getAcquireDateTime() {
		return acquireDateTime;
	}

	public void setAcquireDateTime(Date acquireDateTime) {
		this.acquireDateTime = acquireDateTime;
	}

	public boolean getOldReusedFlag() {
		return oldReusedFlag;
	}

	public void setOldReusedFlag(boolean oldReusedFlag) {
		this.oldReusedFlag = oldReusedFlag;
	}
}
