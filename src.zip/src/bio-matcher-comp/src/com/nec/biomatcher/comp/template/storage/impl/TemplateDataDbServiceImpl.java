package com.nec.biomatcher.comp.template.storage.impl;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateDataInfo;
import com.nec.biomatcher.comp.template.storage.dataAccess.TemplateStorageDao;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataServiceException;
import com.nec.biomatcher.core.framework.common.PFLogger;

public class TemplateDataDbServiceImpl implements TemplateDataService {
	private static final Logger logger = Logger.getLogger(TemplateDataDbServiceImpl.class);

	private TemplateStorageDao templateStorageDao;

	public String saveTemplateData(Integer binId, Long biometricId, byte[] templateData)
			throws TemplateDataServiceException {
		PFLogger.start();
		try {
			if (biometricId == null) {
				throw new TemplateDataServiceException("biometricId is null");
			}

			if (templateData == null || templateData.length == 0) {
				throw new TemplateDataServiceException(
						"Template data bytes is empty or null for biometricId: " + biometricId + ", binId: " + binId);
			}

			BioTemplateDataInfo bioTemplateDataInfo = new BioTemplateDataInfo();
			bioTemplateDataInfo.setTemplateDataId(biometricId.toString());
			bioTemplateDataInfo.setTemplateData(templateData);
			bioTemplateDataInfo.setCreateDateTime(new Date());
			bioTemplateDataInfo.setUpdateDateTime(bioTemplateDataInfo.getCreateDateTime());

			/**
			 * We can simply use saveOrUpdate, but this approach will
			 * unnecessarily load the blob record, Thats why we are deleting the
			 * existing record if any and inserting the new record
			 */

			templateStorageDao.deleteBioTemplateDataInfo(bioTemplateDataInfo.getTemplateDataId());

			templateStorageDao.saveEntity(bioTemplateDataInfo);

			templateStorageDao.flush();

			templateStorageDao.evict(bioTemplateDataInfo);

			return bioTemplateDataInfo.getTemplateDataId();
		} catch (TemplateDataServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new TemplateDataServiceException("Error saving template data: " + th.getMessage(), th);
		} finally {
			PFLogger.end(200, "biometricId: " + biometricId + ", binId: " + binId);
		}
	}

	public void updateTemplateData(String templateDataKey, byte[] templateData) throws TemplateDataServiceException {
		PFLogger.start();
		try {
			if (StringUtils.isBlank(templateDataKey)) {
				throw new TemplateDataServiceException("templateDataKey is null or empty");
			}

			if (templateData == null || templateData.length == 0) {
				throw new TemplateDataServiceException(
						"Template data bytes is empty or null for templateDataKey: " + templateDataKey);
			}

			BioTemplateDataInfo bioTemplateDataInfo = templateStorageDao.getEntity(BioTemplateDataInfo.class,
					templateDataKey);
			if (bioTemplateDataInfo == null) {
				bioTemplateDataInfo = new BioTemplateDataInfo();
				bioTemplateDataInfo.setTemplateDataId(templateDataKey);
				bioTemplateDataInfo.setTemplateData(templateData);
				bioTemplateDataInfo.setCreateDateTime(new Date());
				bioTemplateDataInfo.setUpdateDateTime(bioTemplateDataInfo.getCreateDateTime());
				templateStorageDao.saveEntity(bioTemplateDataInfo);
			} else {
				bioTemplateDataInfo.setTemplateData(templateData);
				bioTemplateDataInfo.setUpdateDateTime(new Date());
				templateStorageDao.updateEntity(bioTemplateDataInfo);
			}

			templateStorageDao.flush();

			templateStorageDao.evict(bioTemplateDataInfo);
		} catch (TemplateDataServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in updateTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end(200, "templateDataKey: " + templateDataKey);
		}
	}

	public void deleteTemplateData(String templateDataKey) throws TemplateDataServiceException {
		try {
			if (StringUtils.isBlank(templateDataKey)) {
				return;
			}
			templateStorageDao.deleteBioTemplateDataInfo(templateDataKey);
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in deleteTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		}
	}

	public byte[] getTemplateData(String templateDataKey) throws TemplateDataServiceException {
		PFLogger.start();
		try {
			if (StringUtils.isBlank(templateDataKey)) {
				throw new TemplateDataServiceException("templateDataKey is null or empty");
			}

			BioTemplateDataInfo bioTemplateDataInfo = templateStorageDao.getEntity(BioTemplateDataInfo.class,
					templateDataKey);
			if (bioTemplateDataInfo == null) {
				throw new TemplateDataServiceException(
						"BioTemplateDataInfo not found with templateDataKey: " + templateDataKey);
			}

			if (bioTemplateDataInfo.getTemplateData() == null || bioTemplateDataInfo.getTemplateData().length == 0) {
				throw new TemplateDataServiceException(
						"Template data bytes is null or empty for templateDataKey: " + templateDataKey);
			}

			templateStorageDao.evict(bioTemplateDataInfo);

			return bioTemplateDataInfo.getTemplateData();
		} catch (TemplateDataServiceException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new TemplateDataServiceException(
					"Error in getTemplateData : templateDataKey: " + templateDataKey + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end(100, "templateDataKey: " + templateDataKey);
		}
	}

	public void setTemplateStorageDao(TemplateStorageDao templateStorageDao) {
		this.templateStorageDao = templateStorageDao;
	}
}
