package com.nec.biomatcher.comp.bioevent.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.base.Throwables;
import com.nec.biomatcher.comp.bioevent.exception.BiometricIdServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdDetailInfo;

public class RoundRobinAcquireBiometricIdsFunction extends AbstractAcquireBiometricIdsFunction {
	private static final Logger logger = Logger.getLogger(RoundRobinAcquireBiometricIdsFunction.class);

	@Override
	public List<BiometricIdDetailInfo> apply(Integer binId) {
		logger.info("In RoundRobinAcquireBiometricIdsFunction: binId: " + binId);

		List<BiometricIdDetailInfo> biometricSequenceIdInfoList = new ArrayList<BiometricIdDetailInfo>();
		try {
			long releasedBiometricIdCheckDelayMilli = bioParameterService.getParameterValue(
					"RELEASED_BIOMETRIC_ID_CHECK_DELAY_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(10));

			int maxPreLoadBiometricIdCount = bioParameterService.getParameterValue("MAX_PRELOAD_BIOMETRIC_ID_COUNT",
					"DEFAULT", 50);

			int requiredBiometricIdCount = maxPreLoadBiometricIdCount;

			if (biometricSequenceIdInfoList.size() < requiredBiometricIdCount) {
				Iterator<Integer> cyclicSegmentIdIterator = bioMatcherConfigService
						.getCyclicSegmentIdListByBinId(binId);

				if (!cyclicSegmentIdIterator.hasNext()) {
					throw new BiometricIdServiceException("BiometricIdInfo is not configured for binId: " + binId);
				}

				Integer firstSegmentId = null;
				while (requiredBiometricIdCount > 0) {
					Integer segmentId = cyclicSegmentIdIterator.next();

					// Cyclic loop breaker
					if (firstSegmentId == null) {
						firstSegmentId = segmentId;
					} else if (firstSegmentId.equals(segmentId)) {
						break;
					}

					List<BiometricIdDetailInfo> newBiometricSequenceIdInfoList = null;
					if (segmentIdBiometricIdCheckTimestampMap
							.get(segmentId) < (System.currentTimeMillis() - releasedBiometricIdCheckDelayMilli)) {
						newBiometricSequenceIdInfoList = biometricIdService.acquireReleasedBiometricIdList(segmentId,
								requiredBiometricIdCount);
						if (newBiometricSequenceIdInfoList.size() < requiredBiometricIdCount) {
							segmentIdBiometricIdCheckTimestampMap.put(segmentId, System.currentTimeMillis());
						}
					} else {
						newBiometricSequenceIdInfoList = biometricIdService.acquireBiometricIdList(segmentId,
								requiredBiometricIdCount);
					}

					biometricSequenceIdInfoList.addAll(newBiometricSequenceIdInfoList);
					requiredBiometricIdCount = requiredBiometricIdCount - newBiometricSequenceIdInfoList.size();
				}
			}

			if (biometricSequenceIdInfoList.size() == 0) {
				throw new BiometricIdServiceException("BiometricId's are not available for binId: " + binId
						+ ", requiredBiometricIdCount: " + requiredBiometricIdCount);
			}

			return biometricSequenceIdInfoList;
		} catch (BiometricIdServiceException ex) {
			throw Throwables.propagate(ex);
		} catch (Throwable th) {
			throw Throwables.propagate(new BiometricIdServiceException(
					"Error in preAcquireBiometricIds for binId: " + binId + " : " + th.getMessage(), th));
		}
	}

}
