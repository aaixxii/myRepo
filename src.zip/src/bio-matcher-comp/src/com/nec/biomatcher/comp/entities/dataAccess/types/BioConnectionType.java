package com.nec.biomatcher.comp.entities.dataAccess.types;

/**
 * The Enum BioConnectionType.
 */
public enum BioConnectionType {

	/** The service. */
	SERVICE,

	/** The cluster. */
	CLUSTER,

	/** The component. */
	COMPONENT,

	/** The admin. */
	ADMIN,

	/** The worker. */
	WORKER,

	/** The segment data sync. */
	SEG_SYNC,

	/** The segment data server. */
	SEG_SERVER,

	JOB_DISTRIBUTOR,

	WORKER_CALLBACK;

	public String toString() {
		return name();
	}
}
