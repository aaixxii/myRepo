package com.nec.biomatcher.comp.entities.dataAccess;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BiometricIdInfo.
 */
public class BiometricIdInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The segment id. */
	private Integer segmentId;

	/** The bin id. */
	private Integer binId;

	/** The start biometric id. */
	private Long startBiometricId;

	/** The end biometric id. */
	private Long endBiometricId;

	/** The current biometric id. */
	private Long currentBiometricId;

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Long getStartBiometricId() {
		return startBiometricId;
	}

	public void setStartBiometricId(Long startBiometricId) {
		this.startBiometricId = startBiometricId;
	}

	public Long getEndBiometricId() {
		return endBiometricId;
	}

	public void setEndBiometricId(Long endBiometricId) {
		this.endBiometricId = endBiometricId;
	}

	public Long getCurrentBiometricId() {
		return currentBiometricId;
	}

	public void setCurrentBiometricId(Long currentBiometricId) {
		this.currentBiometricId = currentBiometricId;
	}

	public long getAvailableBiometricIdCount() {
		// In case user enters some wrong values for startBiometricId and
		// endBiometricId
		long startVal = startBiometricId == null || startBiometricId <= 0 ? 1L : startBiometricId;
		long endVal = endBiometricId == null ? 0L : endBiometricId;
		if (startVal > endVal) {
			return 0L;
		}

		long currVal = (currentBiometricId == null || currentBiometricId < startVal) ? startVal : currentBiometricId;
		if (currVal > endVal) {
			return 0L;
		}

		long availableCount = 1 + endVal - currVal;
		if (availableCount <= 0) {
			return 0L;
		}

		return availableCount;
	}
}
