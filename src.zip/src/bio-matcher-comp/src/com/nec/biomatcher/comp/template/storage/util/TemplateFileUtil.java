package com.nec.biomatcher.comp.template.storage.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.primitives.Longs;
import com.nec.biomatcher.core.framework.common.CommonLogger;

/**
 * The Class TemplateFileUtil.
 */
public class TemplateFileUtil {

	/**
	 * Builds the template file directory.
	 *
	 * @param storagePath
	 *            the storage path
	 * @param binId
	 *            the bin id
	 * @param biometricId
	 *            the biometric id
	 * @return the path
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static final Path buildTemplateFileDirectory(String storagePath, int binId, long biometricId)
			throws IOException {
		StringBuilder pathBuilder = new StringBuilder(storagePath).append(File.separator);
		pathBuilder.append(binId).append(File.separator);

		if (biometricId >= 1000) {
			String biometricIdStr = String.valueOf(biometricId);
			if (biometricIdStr.length() % 2 == 0) {
				biometricIdStr = "0" + biometricIdStr;
			}
			char[] pathArr = biometricIdStr.toCharArray();
			for (int i = 0; i < pathArr.length - 3; i += 2) {
				pathBuilder.append(pathArr[i]).append(pathArr[i + 1]).append(File.separator);
			}
		}

		try {
			return Paths.get(pathBuilder.toString());
		} catch (Throwable th) {
			throw new IOException("Error in buildTemplateFileDirectory: storagePath: " + storagePath + ", binId: "
					+ binId + ", biometricId: " + biometricId + ", path: " + pathBuilder + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Builds the template file path.
	 *
	 * @param storagePath
	 *            the storage path
	 * @param binId
	 *            the bin id
	 * @param biometricId
	 *            the biometric id
	 * @return the path
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static final Path buildTemplateFilePath(String storagePath, int binId, long biometricId) throws IOException {
		return buildTemplateFileDirectory(storagePath, binId, biometricId).resolve(biometricId + ".dat");
	}

	/**
	 * Creates the template file directories.
	 *
	 * @param templateFilePath
	 *            the template file path
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static final void createTemplateFileDirectories(Path templateFilePath) throws IOException {
		try {
			Path folderPath = templateFilePath.getParent();
			if (folderPath != null) {
				Files.createDirectories(folderPath);
			}
		} catch (Throwable th) {
			throw new IOException("Error creating parent directories for templateFile : "
					+ templateFilePath.toAbsolutePath() + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Creates the template file.
	 *
	 * @param templateFilePath
	 *            the template file path
	 * @param templateData
	 *            the template data
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static final void createTemplateFile(Path templateFilePath, byte templateData[]) throws IOException {
		long startTimestampMilli = System.currentTimeMillis();
		try {
			Files.write(templateFilePath, templateData);
		} catch (Throwable th) {
			throw new IOException(
					"Error writing templateFile : " + templateFilePath.toAbsolutePath() + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 100) {
				CommonLogger.PERF_LOG.warn("In createTemplateFile: TimeTakenMilli: " + timeTakenMilli
						+ ", templateFilePath: " + templateFilePath.toString());
			}
		}
	}

	/**
	 * Read template file data.
	 *
	 * @param templateFilePath
	 *            the template file path
	 * @return the byte[]
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static final byte[] readTemplateFileData(Path templateFilePath) throws IOException {
		long startTimestampMilli = System.currentTimeMillis();
		try {
			return Files.readAllBytes(templateFilePath);
		} catch (Throwable th) {
			throw new IOException(
					"Error reading templateFile : " + templateFilePath.toAbsolutePath() + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 100) {
				CommonLogger.PERF_LOG.warn("In readTemplateFileData: TimeTakenMilli: " + timeTakenMilli
						+ ", templateFilePath: " + templateFilePath.toString());
			}
		}
	}

	public static final byte[] getTemplateData(String templateDataKey, Map<Integer, String> templateStoragePathMap)
			throws IOException {
		String parts[] = templateDataKey.split(":");
		if (parts.length != 3) {
			throw new IOException("Invalid templateDataKey: " + templateDataKey);
		}

		String storagePath = templateStoragePathMap.get(Integer.parseInt(parts[0]));
		if (storagePath == null) {
			throw new IOException("Unable to determine storage path for storageId " + parts[0]);
		}

		Path templateFilePath = buildTemplateFilePath(storagePath, Integer.parseInt(parts[1]),
				Long.parseLong(parts[2]));

		long startTimestampMilli = System.currentTimeMillis();
		try {
			return Files.readAllBytes(templateFilePath);
		} catch (Throwable th) {
			throw new IOException(
					"Error reading templateFile : " + templateFilePath.toAbsolutePath() + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 100) {
				CommonLogger.PERF_LOG.warn("In getTemplateData: TimeTakenMilli: " + timeTakenMilli
						+ ", templateFilePath: " + templateFilePath.toString());
			}
		}
	}

	public static final void deleteTemplateData(String templateDataKey, Map<Integer, String> templateStoragePathMap)
			throws IOException {
		String parts[] = templateDataKey.split(":");
		if (parts.length != 3) {
			throw new IOException("Invalid templateDataKey: " + templateDataKey);
		}

		String storagePath = templateStoragePathMap.get(Integer.parseInt(parts[0]));
		if (storagePath == null) {
			throw new IOException("Unable to determine storage path for storageId " + parts[0]);
		}

		Path templateFilePath = buildTemplateFilePath(storagePath, Integer.parseInt(parts[1]),
				Long.parseLong(parts[2]));

		long startTimestampMilli = System.currentTimeMillis();
		try {
			Files.deleteIfExists(templateFilePath);
		} catch (Throwable th) {
			throw new IOException(
					"Error deleting templateFile : " + templateFilePath.toAbsolutePath() + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 100) {
				CommonLogger.PERF_LOG.warn("In deleteTemplateData: TimeTakenMilli: " + timeTakenMilli
						+ ", templateFilePath: " + templateFilePath.toString());
			}
		}
	}

	/**
	 * Delete template file.
	 *
	 * @param templateFilePath
	 *            the template file path
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static final void deleteTemplateFile(Path templateFilePath) throws IOException {
		long startTimestampMilli = System.currentTimeMillis();
		try {
			Files.deleteIfExists(templateFilePath);
		} catch (Throwable th) {
			throw new IOException(
					"Error deleting templateFile : " + templateFilePath.toAbsolutePath() + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 100) {
				CommonLogger.PERF_LOG.warn("In deleteTemplateFile: TimeTakenMilli: " + timeTakenMilli
						+ ", templateFilePath: " + templateFilePath.toString());
			}
		}
	}

	/**
	 * Gets the free space.
	 *
	 * @param rootPath
	 *            the root path
	 * @return the free space
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static final long getFreeSpace(String rootPath) throws IOException {
		long startTimestampMilli = System.currentTimeMillis();
		try {
			Path path = Paths.get(rootPath);
			return path.toFile().getFreeSpace();
		} catch (Throwable th) {
			throw new IOException("Error checking freeSpace for rootPath : " + rootPath + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 500) {
				CommonLogger.PERF_LOG
						.warn("In getFreeSpace: TimeTakenMilli: " + timeTakenMilli + ", rootPath: " + rootPath);
			}
		}
	}

	/**
	 * Builds the template data key.
	 *
	 * @param storageId
	 *            the storage id
	 * @param binId
	 *            the bin id
	 * @param biometricId
	 *            the biometric id
	 * @return the string
	 */
	public static final String buildTemplateDataKey(int storageId, int binId, long biometricId) {
		return Longs.join(":", storageId, binId, biometricId);
	}

	/**
	 * Parses the template data key.
	 *
	 * @param templateDataKey
	 *            the template data key
	 * @return the list
	 */
	public static final List<Long> parseTemplateDataKey(String templateDataKey) {
		List<Long> templateDataKeyParts = new ArrayList<Long>(3);
		for (String part : templateDataKey.split(":")) {
			templateDataKeyParts.add(Long.parseLong(part));
		}
		return templateDataKeyParts;
	}
}
