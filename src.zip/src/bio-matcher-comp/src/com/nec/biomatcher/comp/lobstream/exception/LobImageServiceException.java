package com.nec.biomatcher.comp.lobstream.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class LobImageServiceException.
 */
public class LobImageServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new lob image service exception.
	 *
	 * @param errorCode
	 *            the error code
	 * @param message
	 *            the message
	 */
	public LobImageServiceException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * Instantiates a new lob image service exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public LobImageServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new lob image service exception.
	 *
	 * @param message
	 *            the message
	 */
	public LobImageServiceException(String message) {
		super("LB001", message);
	}

	/**
	 * Instantiates a new lob image service exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public LobImageServiceException(Throwable cause) {
		super(cause);
	}

}
