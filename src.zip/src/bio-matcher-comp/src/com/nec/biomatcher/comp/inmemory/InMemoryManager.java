package com.nec.biomatcher.comp.inmemory;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.inmemory.callback.CallbackKey;
import com.nec.biomatcher.comp.inmemory.callback.CallbackListener;
import com.nec.biomatcher.comp.inmemory.tasktimeout.TaskTimeoutListener;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentProducerConsumer;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

public class InMemoryManager {
	private static final Logger logger = Logger.getLogger(InMemoryManager.class);

	public static final ConcurrentHashMap<String, BioTaskType> pendingTaskMap = new ConcurrentHashMap<String, BioTaskType>();

	public static final Map<BioTaskType, CallbackListener> callbackListenerMap = new HashMap<>();
	private static final LinkedBlockingDeque<CallbackKey> pendingTaskCallbackQueue = new LinkedBlockingDeque<CallbackKey>();
	private static ConcurrentProducerConsumer<CallbackKey> callbackExecutor;

	public static final Map<BioTaskType, TaskTimeoutListener> timeoutListenerMap = new HashMap<>();
	public static final DelayQueue<DelayedItem<BiKey<String, BioTaskType>>> taskTimeoutQueue = new DelayQueue<DelayedItem<BiKey<String, BioTaskType>>>();
	private static ConcurrentProducerConsumer<DelayedItem<BiKey<String, BioTaskType>>> timeoutExecutor;

	private static BioParameterService _bioParameterService;

	public static void submitForExtractCallback(String jobId, String callbackUrl) {
		pendingTaskCallbackQueue.add(new CallbackKey(jobId, BioTaskType.EXTRACT, callbackUrl));
	}

	public static void submitForVerifyCallback(String jobId, String callbackUrl) {
		pendingTaskCallbackQueue.add(new CallbackKey(jobId, BioTaskType.VERIFY, callbackUrl));
	}

	public static void submitForSearchCallback(String jobId, String callbackUrl) throws URISyntaxException {
		pendingTaskCallbackQueue.add(new CallbackKey(jobId, BioTaskType.SEARCH, callbackUrl));
	}

	public static void submitForEnrollCallback(String jobId, String callbackUrl) {
		pendingTaskCallbackQueue.add(new CallbackKey(jobId, BioTaskType.ENROLL, callbackUrl));
	}

	public static void registerExtractForTimeout(String jobId, long timeoutMilli) {
		pendingTaskMap.put(jobId, BioTaskType.EXTRACT);

		DelayedItem<BiKey<String, BioTaskType>> delayItem = new DelayedItem<>(new BiKey<>(jobId, BioTaskType.EXTRACT),
				timeoutMilli);

		taskTimeoutQueue.add(delayItem);
	}

	public static void registerVerifyForTimeout(String jobId, long timeoutMilli) {
		pendingTaskMap.put(jobId, BioTaskType.VERIFY);

		DelayedItem<BiKey<String, BioTaskType>> delayItem = new DelayedItem<>(new BiKey<>(jobId, BioTaskType.VERIFY),
				timeoutMilli);

		taskTimeoutQueue.add(delayItem);
	}

	public static void registerSearchForTimeout(String jobId, long timeoutMilli) {
		pendingTaskMap.put(jobId, BioTaskType.SEARCH);

		DelayedItem<BiKey<String, BioTaskType>> delayItem = new DelayedItem<>(new BiKey<>(jobId, BioTaskType.SEARCH),
				timeoutMilli);

		taskTimeoutQueue.add(delayItem);
	}

	public static void registerEnrollForTimeout(String jobId, long timeoutMilli) {
		pendingTaskMap.put(jobId, BioTaskType.ENROLL);

		DelayedItem<BiKey<String, BioTaskType>> delayItem = new DelayedItem<>(new BiKey<>(jobId, BioTaskType.ENROLL),
				timeoutMilli);

		taskTimeoutQueue.add(delayItem);
	}

	public static void registerStrictSyncSegCallbackTimeout(String jobId, long timeoutMilli) {
		pendingTaskMap.put(jobId, BioTaskType.STRICT_SYNC);

		DelayedItem<BiKey<String, BioTaskType>> delayItem = new DelayedItem<>(
				new BiKey<>(jobId, BioTaskType.STRICT_SYNC), timeoutMilli);

		taskTimeoutQueue.add(delayItem);
	}

	public static void removeFromTimeoutQueue(String jobId) {
		BioTaskType taskType = pendingTaskMap.remove(jobId);
		if (taskType != null) {
			DelayedItem<BiKey<String, BioTaskType>> delayItem = new DelayedItem<>(new BiKey<>(jobId, taskType), 0L);
			taskTimeoutQueue.remove(delayItem);
		}
	}

	private static final void notifyCallback(CallbackKey callbackKey) {
		try {
			pendingTaskMap.remove(callbackKey.getTaskKey());
		} catch (Throwable th) {
			logger.error("Error in InMemoryManager.notifyCallback while pendingTaskMap.remove: callbackKey: "
					+ callbackKey + " : " + th.getMessage(), th);
		}

		NDC.clear();
		NDC.push(callbackKey.getTaskType().name() + "#" + callbackKey.getTaskKey());
		long startTimestampMilli = System.currentTimeMillis();
		try {
			callbackListenerMap.get(callbackKey.getTaskType()).notifyCallback(callbackKey.getTaskKey(),
					callbackKey.getCallbackUrl());
		} catch (Throwable th) {
			logger.error("Error while InMemoryManager.notifyCallback for callbackKey: " + callbackKey + " : "
					+ th.getMessage(), th);
		} finally {
			NDC.clear();
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 100 || logger.isTraceEnabled()) {
				logger.info("In InMemoryManager.notifyCallback for callbackKey: " + callbackKey + ", timeTakenMilli: "
						+ timeTakenMilli);
			}
		}
	}

	private static final void notifyTimeout(DelayedItem<BiKey<String, BioTaskType>> timeoutItem) {
		try {
			String taskKey = timeoutItem.getItem().getA();
			BioTaskType taskType = timeoutItem.getItem().getB();

			if (pendingTaskMap.containsKey(taskKey)) {

				NDC.clear();
				NDC.push(taskType.name() + "#" + taskKey);
				long startTimeMilli = System.currentTimeMillis();
				try {
					timeoutListenerMap.get(taskType).notifyTaskTimeout(taskKey);
				} catch (Throwable th) {
					logger.error("Error while InMemoryManager.notifyTaskTimeout for taskType: " + taskType
							+ ", taskKey: " + taskKey + " : " + th.getMessage(), th);
				} finally {
					logger.trace("After InMemoryManager.notifyTaskTimeout: timetakenMilli:  "
							+ (System.currentTimeMillis() - startTimeMilli));
					pendingTaskMap.remove(taskKey);
				}
			}

		} catch (Throwable th) {
			logger.error("Error in InMemoryManager.notifyTimeout: " + th.getMessage(), th);
		}
	}

	public static long getPendingTaskCallbackQueueCount() {
		return pendingTaskCallbackQueue.size();
	}

	public static synchronized void startCallbackExecutor() {
		if (callbackExecutor != null) {
			return;
		}

		Supplier<Integer> callbackConcurrencyCountSupplier = BioParameterService
				.getIntSupplier("CALLBACK_THREAD_CONCURRENCY", "DEFAULT", 20);

		callbackExecutor = new ConcurrentProducerConsumer<>("JOB_CALLBACK_WORKER",
				() -> Uninterruptibles.takeUninterruptibly(pendingTaskCallbackQueue),
				(callbackKey) -> notifyCallback(callbackKey), callbackConcurrencyCountSupplier);

		MetricsUtil.registerGauge(null, null, "PENDING_CALLBACK_TASK_COUNT", () -> {
			return pendingTaskCallbackQueue.size();
		});
	}

	public static synchronized void startJobTimeoutExecutor() {
		if (timeoutExecutor != null) {
			return;
		}

		Supplier<Integer> jobTimeoutThreadConcurrencySupplier = BioParameterService
				.getIntSupplier("JOB_TIMEOUT_THREAD_CONCURRENCY", "DEFAULT", 20);

		timeoutExecutor = new ConcurrentProducerConsumer<>("JOB_TIMEOUT_WORKER",
				() -> Uninterruptibles.takeUninterruptibly(taskTimeoutQueue),
				(timeoutItem) -> notifyTimeout(timeoutItem), jobTimeoutThreadConcurrencySupplier);

		MetricsUtil.registerGauge(null, null, "JOB_TIMEOUT_QUEUE_SIZE", () -> {
			return taskTimeoutQueue.size();
		});
	}

	private static BioParameterService getBioParameterService() {
		if (_bioParameterService == null) {
			_bioParameterService = SpringServiceManager.getBean("bioParameterService");
		}
		return _bioParameterService;
	}
}
