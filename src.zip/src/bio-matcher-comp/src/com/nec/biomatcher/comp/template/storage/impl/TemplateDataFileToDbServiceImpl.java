package com.nec.biomatcher.comp.template.storage.impl;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.template.storage.TemplateDataService;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataNotFoundException;
import com.nec.biomatcher.comp.template.storage.exception.TemplateDataServiceException;

/**
 * This is hybrid template data service, It should be used only during the
 * transition period
 *
 */
public class TemplateDataFileToDbServiceImpl implements TemplateDataService {
	private static final Logger logger = Logger.getLogger(TemplateDataFileToDbServiceImpl.class);

	private TemplateDataService templateDataFileService;
	private TemplateDataService templateDataDbService;

	public String saveTemplateData(Integer binId, Long biometricId, byte[] templateData)
			throws TemplateDataServiceException {
		return templateDataDbService.saveTemplateData(binId, biometricId, templateData);
	}

	public void updateTemplateData(String templateDataKey, byte[] templateData) throws TemplateDataServiceException {
		templateDataDbService.updateTemplateData(templateDataKey, templateData);
	}

	public void deleteTemplateData(String templateDataKey) throws TemplateDataServiceException {
		templateDataDbService.deleteTemplateData(templateDataKey);
	}

	public byte[] getTemplateData(String templateDataKey)
			throws TemplateDataServiceException, TemplateDataNotFoundException {
		if (StringUtils.contains(templateDataKey, ":")) {
			return templateDataFileService.getTemplateData(templateDataKey);
		} else {
			return templateDataDbService.getTemplateData(templateDataKey);
		}
	}

	public void setTemplateDataFileService(TemplateDataService templateDataFileService) {
		this.templateDataFileService = templateDataFileService;
	}

	public void setTemplateDataDbService(TemplateDataService templateDataDbService) {
		this.templateDataDbService = templateDataDbService;
	}
}
