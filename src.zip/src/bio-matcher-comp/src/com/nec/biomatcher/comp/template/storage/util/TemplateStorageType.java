package com.nec.biomatcher.comp.template.storage.util;

public enum TemplateStorageType {
	FILE, DB, FILE_TO_DB, CASSANDRA
}
