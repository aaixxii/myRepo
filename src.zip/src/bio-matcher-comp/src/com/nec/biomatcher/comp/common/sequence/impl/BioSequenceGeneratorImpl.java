package com.nec.biomatcher.comp.common.sequence.impl;

import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.locking.BioLockingService;
import com.nec.biomatcher.comp.common.sequence.BioSequenceGenerator;
import com.nec.biomatcher.comp.common.sequence.dataAccess.BioSequenceGeneratorDao;
import com.nec.biomatcher.comp.common.sequence.dataAccess.BioSequenceNumber;
import com.nec.biomatcher.comp.common.sequence.exception.BioSequenceGeneratorException;
import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

/**
 * Implementation class for SequenceGenerator.
 *
 * @author Alvin Chua
 * @version 1.0
 * @since 24 Oct 2014
 */
public class BioSequenceGeneratorImpl implements BioSequenceGenerator, InitializingBean {

	/** The _logger. */
	private static Logger logger = Logger.getLogger(BioSequenceGeneratorImpl.class);

	/** The dao. */
	private BioSequenceGeneratorDao dao;

	/** The locking service. */
	private BioLockingService lockingService;

	@Override
	public BioSequenceNumber create(String sequenceName, String groupName, Long max, Long min, Long value,
			Integer resetPolicy) throws Exception {
		BioSequenceNumber sequenceNumber = new BioSequenceNumber();
		Date now = new Date();
		sequenceNumber.setMinimum(min);
		sequenceNumber.setMaximum(max);
		if (value == null) {
			sequenceNumber.setValue(min);
		} else {
			sequenceNumber.setValue(value);
		}
		sequenceNumber.setName(sequenceName);
		sequenceNumber.setGroup(groupName);
		sequenceNumber.setCreateDateTime(now);
		if (resetPolicy == null) {
			resetPolicy = BioSequenceNumber.RESET_POLICY_NONE;
		}
		sequenceNumber.setResetPolicy(resetPolicy);
		Calendar calendar = Calendar.getInstance();
		Date resetDateTime = null;
		if (resetPolicy == BioSequenceNumber.RESET_POLICY_HOURLY) {
			calendar.setTime(now);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			resetDateTime = calendar.getTime();
		} else if (resetPolicy == BioSequenceNumber.RESET_POLICY_YEARLY) {
			calendar.setTime(now);
			calendar.set(Calendar.HOUR, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			resetDateTime = calendar.getTime();
		} else if (resetPolicy == BioSequenceNumber.RESET_POLICY_DAILY) {
			calendar.setTime(now);
			calendar.set(Calendar.HOUR, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			resetDateTime = calendar.getTime();
		}
		sequenceNumber.setResetDateTime(resetDateTime);

		dao.create(sequenceNumber);
		return sequenceNumber;
	}

	@Override
	public Long next(String name, String group, Long maximum, Long minimum, Integer resetPolicy)
			throws BioSequenceGeneratorException {
		try {
			BioSequenceNumber sequenceNumber = dao.getSeqenceNumberForUpdate(name, group);

			Long currentValue = null;
			Date now = new Date();
			if (sequenceNumber == null) {
				lockingService.acquireTransactionLock(BioSequenceGenerator.class.getSimpleName());
				sequenceNumber = dao.getSeqenceNumberForUpdate(name, group);
				if (sequenceNumber == null) {
					sequenceNumber = this.create(name, group, maximum, minimum, null, resetPolicy);
				}
				return sequenceNumber.getValue();
			} else {
				resetPolicy = sequenceNumber.getResetPolicy();
				if (resetPolicy == null) {
					resetPolicy = BioSequenceNumber.RESET_POLICY_NONE;
				}

				if (sequenceNumber.getResetDateTime() != null && now.after(sequenceNumber.getResetDateTime())) {
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(sequenceNumber.getResetDateTime());
					if (resetPolicy == BioSequenceNumber.RESET_POLICY_HOURLY) {
						calendar.add(Calendar.HOUR, 1);
						if (calendar.getTime().before(now)) {
							this.resetSequence(sequenceNumber, now);
						}
					} else if (resetPolicy == BioSequenceNumber.RESET_POLICY_YEARLY) {
						calendar.add(Calendar.YEAR, 1);
						if (calendar.getTime().before(now)) {
							this.resetSequence(sequenceNumber, now);
						}
					} else if (resetPolicy == BioSequenceNumber.RESET_POLICY_DAILY) {
						calendar.add(Calendar.HOUR, 24);
						if (calendar.getTime().before(now)) {
							this.resetSequence(sequenceNumber, now);
						}
					}
				}
				currentValue = sequenceNumber.getValue();
				sequenceNumber.setValue(currentValue + 1);
				dao.update(sequenceNumber);
			}
			return currentValue;

		} catch (Exception e) {
			throw new BioSequenceGeneratorException(e);
		}
	}

	public Long next(String name, String group, int incrementBy) throws BioSequenceGeneratorException {
		try {
			BioSequenceNumber sequenceNumber = dao.getSeqenceNumberForUpdate(name, group);

			Long currentValue = null;
			Date now = new Date();

			if (sequenceNumber == null) {
				lockingService.acquireTransactionLock(BioSequenceGenerator.class.getSimpleName());
				sequenceNumber = dao.getSeqenceNumberForUpdate(name, group);
				if (sequenceNumber == null) {
					sequenceNumber = this.create(name, group, Long.MAX_VALUE, 1L, (long) incrementBy + 1,
							BioSequenceNumber.RESET_POLICY_NONE);
					return 1L;
				}
			}

			Integer resetPolicy = sequenceNumber.getResetPolicy();
			if (resetPolicy == null) {
				resetPolicy = BioSequenceNumber.RESET_POLICY_NONE;
			}

			if (sequenceNumber.getResetDateTime() != null && now.after(sequenceNumber.getResetDateTime())) {
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(sequenceNumber.getResetDateTime());
				if (resetPolicy == BioSequenceNumber.RESET_POLICY_HOURLY) {
					calendar.add(Calendar.HOUR, 1);
					if (calendar.getTime().before(now)) {
						this.resetSequence(sequenceNumber, now);
					}
				} else if (resetPolicy == BioSequenceNumber.RESET_POLICY_YEARLY) {
					calendar.add(Calendar.YEAR, 1);
					if (calendar.getTime().before(now)) {
						this.resetSequence(sequenceNumber, now);
					}
				} else if (resetPolicy == BioSequenceNumber.RESET_POLICY_DAILY) {
					calendar.add(Calendar.HOUR, 24);
					if (calendar.getTime().before(now)) {
						this.resetSequence(sequenceNumber, now);
					}
				}
			}
			currentValue = sequenceNumber.getValue();
			sequenceNumber.setValue(currentValue + incrementBy);
			dao.update(sequenceNumber);

			logger.debug("In BioSequenceGeneratorImpl.next for name: " + name + ", group: " + group + ", currentValue: "
					+ currentValue + ", incrementBy: " + incrementBy + ", updatedValue: " + sequenceNumber.getValue());
			return currentValue;

		} catch (Exception e) {
			throw new BioSequenceGeneratorException(e);
		}
	}

	@Override
	public void reset(String sequenceName, String groupName, Date resetTimeStamp) throws Exception {
		BioSequenceNumber sequenceNumber = dao.getSeqenceNumber(sequenceName, groupName);
		if (sequenceNumber != null) {
			this.resetSequence(sequenceNumber, resetTimeStamp);
			dao.update(sequenceNumber);
		} else {
			throw new Exception("Sequnce number(" + sequenceName + ", " + groupName + ") does not exists.");
		}

	}

	/**
	 * Reset sequence.
	 *
	 * @param sequenceNumber
	 *            the sequence number
	 * @param resetTimeStamp
	 *            the reset time stamp
	 * @throws Exception
	 *             the exception
	 */
	private void resetSequence(BioSequenceNumber sequenceNumber, Date resetTimeStamp) throws Exception {
		if (sequenceNumber != null) {
			sequenceNumber.setValue(sequenceNumber.getMinimum());
			this.setResetDatetime(sequenceNumber, resetTimeStamp);
		}

	}

	/**
	 * Sets the reset datetime.
	 *
	 * @param sequenceNumber
	 *            the sequence number
	 * @param now
	 *            the now
	 */
	private void setResetDatetime(BioSequenceNumber sequenceNumber, Date now) {
		Calendar calendar = Calendar.getInstance();
		if (sequenceNumber.getResetPolicy() == BioSequenceNumber.RESET_POLICY_HOURLY) {
			calendar.setTime(now);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			sequenceNumber.setResetDateTime(calendar.getTime());
		} else if (sequenceNumber.getResetPolicy() == BioSequenceNumber.RESET_POLICY_YEARLY) {
			calendar.setTime(now);
			calendar.set(Calendar.HOUR, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			sequenceNumber.setResetDateTime(calendar.getTime());
		} else if (sequenceNumber.getResetPolicy() == BioSequenceNumber.RESET_POLICY_DAILY) {
			calendar.setTime(now);
			calendar.set(Calendar.HOUR, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			sequenceNumber.setResetDateTime(calendar.getTime());
		}
	}

	@Override
	public void delete(String sequenceName, String groupName) throws Exception {
		BioSequenceNumber sequenceNumber = dao.getSeqenceNumber(sequenceName, groupName);
		if (sequenceNumber != null) {
			dao.delete(sequenceNumber);
		}
	}

	@Override
	public BioSequenceNumber get(String sequenceName, String groupName) throws Exception {
		return dao.getSeqenceNumber(sequenceName, groupName);
	}

	@Override
	public PageResult<BioSequenceNumber> getAllSequences(PageRequest pageRequest, String userId, String terminalId)
			throws Exception {
		try {
			return dao.getAllSeqences(pageRequest);
		} catch (DaoException e) {
			throw new Exception(e);
		}
	}

	@Override
	public void updateSequence(BioSequenceNumber sequenceNumber, String userId, String terminalId) throws Exception {
		dao.update(sequenceNumber);

	}

	public void setDao(BioSequenceGeneratorDao dao) {
		this.dao = dao;
	}

	public void setLockingService(BioLockingService lockingService) {
		this.lockingService = lockingService;
	}

	public void afterPropertiesSet() throws Exception {
		// Create the SequenceGenerator lock, which is used while creating the
		// new SequenceNumber record for first time
		lockingService.tryAcquireLock(BioSequenceGenerator.class.getSimpleName(), 0L);
	}

}
