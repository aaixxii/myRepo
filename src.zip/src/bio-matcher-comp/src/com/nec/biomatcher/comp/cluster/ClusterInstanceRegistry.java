package com.nec.biomatcher.comp.cluster;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.hazelcast.core.HazelcastInstance;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;

public class ClusterInstanceRegistry {
    private static final Map<BioComponentType, ClusterInstance> componentTypeClusterInstanceMap = new ConcurrentHashMap<>();

    public static final void register(BioComponentType bioComponentType, HazelcastInstance hazelcastInstance) {
        componentTypeClusterInstanceMap.compute(bioComponentType, (key, oldClusterInstance) -> {
            if (oldClusterInstance == null) {
                oldClusterInstance = new ClusterInstance(hazelcastInstance);
            } else {
                oldClusterInstance.setHazelcastInstance(hazelcastInstance);
            }

            return oldClusterInstance;
        });
    }

    public static final ClusterInstance getClusterInstance(BioComponentType bioComponentType) {
        return componentTypeClusterInstanceMap.get(bioComponentType);
    }
}
