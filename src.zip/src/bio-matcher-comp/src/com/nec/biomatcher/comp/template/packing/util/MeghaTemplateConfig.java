package com.nec.biomatcher.comp.template.packing.util;

import java.util.Map;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.spec.transfer.model.TemplateType;

public class MeghaTemplateConfig {
	private final int userFlagByteCount;
	private final Map<String, Integer> featureTypeFeatureSizeMap;
	private final Map<TemplateType, Integer> templateTypeMaxEventCountMap;

	public MeghaTemplateConfig(int userFlagByteCount, Map<String, Integer> featureTypeFeatureSizeMap,
			Map<TemplateType, Integer> templateTypeMaxEventCountMap) {
		this.userFlagByteCount = userFlagByteCount;
		this.featureTypeFeatureSizeMap = featureTypeFeatureSizeMap;
		this.templateTypeMaxEventCountMap = templateTypeMaxEventCountMap;
	}

	public final int getMaxEventCount(TemplateType templateType) throws MeghaTemplateException {
		Integer maxEventCount = templateTypeMaxEventCountMap.get(templateType);
		if (maxEventCount == null) {
			throw new MeghaTemplateException("Cannot find max event count for templateType: " + templateType);
		}
		return maxEventCount;
	}

	public final int getUserFlagByteCount() {
		return userFlagByteCount;
	}

	public final int getFeatureSize(String featureTypeKey) throws MeghaTemplateException {
		Integer featureSize = featureTypeFeatureSizeMap.get(featureTypeKey);
		if (featureSize == null) {
			throw new MeghaTemplateException("Cannot find feature size for featureTypeKey: " + featureTypeKey);
		}
		return featureSize;
	}

	public Map<TemplateType, Integer> getTemplateTypeMaxEventCountMap() {
		return templateTypeMaxEventCountMap;
	}
}
