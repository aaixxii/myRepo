package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Sets;
import com.google.common.primitives.UnsignedBytes;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType36Event extends MeghaEvent {
	public static final int COUNT_MAX_FINGERS = 10;

	private byte matchConfig; // Used to store the config based on which the
								// match param will be chosen.
	private byte featureHoldFlag = 0;
	private byte[] rolledQuality;
	private byte[] slapQuality;
	private byte rolledCmlFeatureData[];
	private byte slapCmlFeatureData[];

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "matchConfig", matchConfig);
		printStream.printf("%-20s - %s\n", "featureHoldFlag",
				StringUtils.leftPad(UnsignedBytes.toString(featureHoldFlag, 2), Byte.SIZE, "0"));
		printStream.printf("%-20s - %s\n", "rolledQuality", Arrays.toString(rolledQuality));
		printStream.printf("%-20s - %s\n", "slapQuality", Arrays.toString(slapQuality));
		printStream.printf("%-20s - %s\n", "rolledCmlFeatureData", rolledCmlFeatureData != null);
		printStream.printf("%-20s - %s\n", "slapCmlFeatureData", slapCmlFeatureData != null);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).bytes(1).bytes(1).quality(COUNT_MAX_FINGERS)
				.quality(COUNT_MAX_FINGERS).featureDataLength(4).featureData(1, "FINGER_CML_FEATURE_DATA_SIZE")
				.featureDataLength(4).featureData(1, "FINGER_CML_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FINGER_CML);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (rolledCmlFeatureData == null && slapCmlFeatureData == null) {
			throw new MeghaTemplateException("Both rolledCmlFeatureData and slapCmlFeatureData are not set");
		}

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.FINGER_CML.getValue().byteValue());

		if (rolledQuality == null) {
			rolledQuality = new byte[COUNT_MAX_FINGERS];
		}
		if (slapQuality == null) {
			slapQuality = new byte[COUNT_MAX_FINGERS];
		}

		featureHoldFlag = 0;
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 0, rolledCmlFeatureData != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 1, slapCmlFeatureData != null);

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());
		eventDataBuf.put(matchConfig);
		eventDataBuf.put(featureHoldFlag);
		eventDataBuf.put(rolledQuality);
		eventDataBuf.put(slapQuality);

		if (rolledCmlFeatureData != null) {
			if (rolledCmlFeatureData.length == 0 || rolledCmlFeatureData.length > meghaTemplateConfig
					.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException(
						"Invalid rolledCmlFeatureData length, actual: " + rolledCmlFeatureData.length + ", expected: "
								+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
			}

			eventDataBuf.putInt(rolledCmlFeatureData.length);

			eventDataBuf.put(rolledCmlFeatureData);

			eventDataBuf.position(eventDataBuf.position()
					+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE") - rolledCmlFeatureData.length);

		} else {
			eventDataBuf.putInt(0);

			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
		}

		if (slapCmlFeatureData != null) {
			if (slapCmlFeatureData.length == 0
					|| slapCmlFeatureData.length > meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException(
						"Invalid slapCmlFeatureData length, actual: " + slapCmlFeatureData.length + ", expected: "
								+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
			}

			eventDataBuf.putInt(slapCmlFeatureData.length);

			eventDataBuf.put(slapCmlFeatureData);

			eventDataBuf.position(eventDataBuf.position()
					+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE") - slapCmlFeatureData.length);
		} else {
			eventDataBuf.putInt(0);

			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
		}

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		matchConfig = eventDataBuf.get();

		featureHoldFlag = eventDataBuf.get();

		rolledQuality = new byte[COUNT_MAX_FINGERS];
		eventDataBuf.get(rolledQuality);

		slapQuality = new byte[COUNT_MAX_FINGERS];
		eventDataBuf.get(slapQuality);

		List<Integer> featureIndexFlagList = HoldFlagUtil.getHoldFlagIndexList(featureHoldFlag, 2);

		if (featureIndexFlagList.contains(0)) {
			int dataSize = eventDataBuf.getInt();

			if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
						+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
			}

			rolledCmlFeatureData = new byte[dataSize];

			eventDataBuf.get(rolledCmlFeatureData);

			eventDataBuf.position(eventDataBuf.position()
					+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE") - dataSize);

		} else {
			eventDataBuf.getInt();
			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
		}

		if (featureIndexFlagList.contains(1)) {
			int dataSize = eventDataBuf.getInt();

			if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
						+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
			}

			slapCmlFeatureData = new byte[dataSize];

			eventDataBuf.get(slapCmlFeatureData);

			eventDataBuf.position(eventDataBuf.position()
					+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE") - dataSize);
		} else {
			eventDataBuf.getInt();
			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
		}
	}

	public byte[] getRolledQuality() {
		return rolledQuality;
	}

	public void setRolledQuality(byte[] rolledQuality) {
		this.rolledQuality = rolledQuality;
	}

	public byte[] getSlapQuality() {
		return slapQuality;
	}

	public void setSlapQuality(byte[] slapQuality) {
		this.slapQuality = slapQuality;
	}

	public byte[] getRolledCmlFeatureData() {
		return rolledCmlFeatureData;
	}

	public void setRolledCmlFeatureData(byte[] rolledCmlFeatureData) {
		this.rolledCmlFeatureData = rolledCmlFeatureData;
	}

	public byte[] getSlapCmlFeatureData() {
		return slapCmlFeatureData;
	}

	public void setSlapCmlFeatureData(byte[] slapCmlFeatureData) {
		this.slapCmlFeatureData = slapCmlFeatureData;
	}

	public byte getMatchConfig() {
		return matchConfig;
	}

	public void setMatchConfig(byte matchConfig) {
		this.matchConfig = matchConfig;
	}

}
