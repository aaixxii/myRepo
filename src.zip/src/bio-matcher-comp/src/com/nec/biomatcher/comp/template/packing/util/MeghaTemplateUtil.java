package com.nec.biomatcher.comp.template.packing.util;

import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Set;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.model.MeghaEvent;
import com.nec.biomatcher.comp.template.packing.model.MeghaTemplate;
import com.nec.biomatcher.comp.template.packing.model.MeghaTemplateHeader;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.TemplateType;

public class MeghaTemplateUtil {

	public static final ByteOrder DEFAULT_BYTE_ORDER = ByteOrder.LITTLE_ENDIAN;

	public static final byte NULL_BYTE = '\0';

	public static Class<? extends MeghaTemplate> getTemplateTypeClass(byte[] templateData)
			throws MeghaTemplateException {
		TemplateType templateType = getTemplateTypeFromTemplate(templateData);
		return getTemplateTypeClass(templateType);
	}

	public static Class<? extends MeghaTemplate> getTemplateTypeClass(TemplateType templateType)
			throws MeghaTemplateException {
		String className = MeghaTemplate.class.getPackage().getName() + ".MeghaType"
				+ templateType.getTemplateTypeCode() + "Template";
		try {
			Class<? extends MeghaTemplate> templateTypeClass = (Class<? extends MeghaTemplate>) Class
					.forName(className);
			return templateTypeClass;
		} catch (Throwable th) {
			throw new MeghaTemplateException("TemplateType: " + templateType + " is not supported, templateClass: "
					+ className + " : " + th.getMessage(), th);
		}
	}

	public static Class<? extends MeghaEvent> getEventTypeClass(TemplateType templateType)
			throws MeghaTemplateException {
		String className = MeghaEvent.class.getPackage().getName() + ".MeghaType" + templateType.getTemplateTypeCode()
				+ "Event";
		try {
			Class<? extends MeghaEvent> eventTypeClass = (Class<? extends MeghaEvent>) Class.forName(className);
			return eventTypeClass;
		} catch (Throwable th) {
			throw new MeghaTemplateException("TemplateType: " + templateType + " is not supported, eventTypeClass: "
					+ className + " : " + th.getMessage(), th);
		}
	}

	public static TemplateType getTemplateTypeFromTemplate(byte[] templateData) throws MeghaTemplateException {
		int templateTypeCode = templateData[1];
		TemplateType templateType = TemplateType.enumOf(templateTypeCode);
		if (templateType == null) {
			throw new MeghaTemplateException("TemplateTypeCode: " + templateTypeCode + " is not supported");
		}
		return templateType;
	}

	public static int getEventSize(TemplateType templateType, MeghaTemplateConfig meghaTemplateConfig)
			throws MeghaTemplateException {
		Class<? extends MeghaEvent> eventTypeClass = getEventTypeClass(templateType);

		try {
			Method getEventDataSizeMethod = eventTypeClass.getDeclaredMethod("getEventDataSize",
					MeghaTemplateConfig.class);
			Integer eventDataSize = (Integer) getEventDataSizeMethod.invoke(null, meghaTemplateConfig);
			return eventDataSize;
		} catch (Throwable th) {
			throw new MeghaTemplateException("Unable to get event data size for templateType: " + templateType
					+ ", eventTypeClass: " + eventTypeClass.getName() + " : " + th.getMessage(), th);
		}
	}

	public static Set<AlgorithmType> getAlgorithmTypes(TemplateType templateType) throws MeghaTemplateException {
		Class<? extends MeghaEvent> eventTypeClass = getEventTypeClass(templateType);

		try {
			Method getAlgorithmTypesMethod = eventTypeClass.getDeclaredMethod("getAlgorithmTypes");
			Set<AlgorithmType> algorithmTypesSet = (Set<AlgorithmType>) getAlgorithmTypesMethod.invoke(null);
			return algorithmTypesSet;
		} catch (Throwable th) {
			throw new MeghaTemplateException("Unable to algorithm types for templateType: " + templateType
					+ ", eventTypeClass: " + eventTypeClass.getName() + " : " + th.getMessage(), th);
		}
	}

	public static int getTemplateSize(TemplateType templateType, int maxEventCount,
			MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		int useFlagSize = meghaTemplateConfig.getUserFlagByteCount();
		int templateHeaderSize = getTemplateHeaderSize(useFlagSize);
		int eventDataSize = getEventSize(templateType, meghaTemplateConfig);
		int templateSize = MeghaTemplate.calculateTemplateSize(templateHeaderSize, eventDataSize, maxEventCount);
		return templateSize;
	}

	public static int getTemplateSize(TemplateType templateType, MeghaTemplateConfig meghaTemplateConfig)
			throws MeghaTemplateException {
		int useFlagSize = meghaTemplateConfig.getUserFlagByteCount();
		int templateHeaderSize = getTemplateHeaderSize(useFlagSize);
		int eventDataSize = getEventSize(templateType, meghaTemplateConfig);
		int maxEventCount = meghaTemplateConfig.getMaxEventCount(templateType);
		int templateSize = MeghaTemplate.calculateTemplateSize(templateHeaderSize, eventDataSize, maxEventCount);
		return templateSize;
	}

	public static void printTemplateDetails(byte[] templateData, MeghaTemplateConfig meghaTemplateConfig,
			PrintStream printStream) throws Exception {
		Class<? extends MeghaTemplate> templateClass = getTemplateTypeClass(templateData);
		Constructor<?> constructor = templateClass.getDeclaredConstructors()[0];
		constructor.setAccessible(true);
		MeghaTemplate meghaTemplate = (MeghaTemplate) constructor
				.newInstance(meghaTemplateConfig.getUserFlagByteCount());
		meghaTemplate.unpack(templateData, meghaTemplateConfig);

		meghaTemplate.print(printStream);
	}

	public static final int getTemplateHeaderSize(int userFlagByteCount) {
		return MeghaTemplateHeader.TEMPLATE_HEADER_SIZE_WITHOUT_USERFLAG + userFlagByteCount;
	}

	public static String getStringData(final int maxValueSize, final ByteBuffer dataBuffer) {
		int position = dataBuffer.position();

		StringBuilder sb = new StringBuilder(maxValueSize);
		for (int i = 0; i < maxValueSize; i++) {
			byte b = dataBuffer.get();
			if (b == MeghaTemplateUtil.NULL_BYTE) {
				break;
			}
			sb.append((char) b);
		}

		dataBuffer.position(position + maxValueSize);

		return sb.toString();
	}

	public static final void setStringData(String strValue, final int maxValueSize, final ByteBuffer dataBuffer) {
		byte[] buf = null;

		if (strValue != null && strValue.length() > 0) {
			if (strValue.length() > maxValueSize) {
				strValue = strValue.substring(0, maxValueSize);
			}
			buf = strValue.getBytes(java.nio.charset.StandardCharsets.UTF_8);
			dataBuffer.put(buf);
		} else {
			buf = new byte[0];
		}

		if (buf.length < maxValueSize) {
			for (int i = buf.length; i < maxValueSize; i++) {
				dataBuffer.put(MeghaTemplateUtil.NULL_BYTE);
			}
		}
	}

	public static final void setByteData(byte[] inputBytes, final int maxSize, final ByteBuffer dataBuffer) {
		if (inputBytes == null) {
			dataBuffer.put(new byte[maxSize]);
		} else {
			dataBuffer.put(inputBytes, 0, Math.min(maxSize, inputBytes.length));
			if (inputBytes.length < maxSize) {
				dataBuffer.put(new byte[maxSize - inputBytes.length]);
			}
		}
	}

	public static final byte calculateChecksum(byte[] dataBuf) {
		int ret = 0;
		for (int i = 0; i < dataBuf.length; i++) {
			ret ^= (int) dataBuf[i];
		}

		// just mask other bytes
		// byte retByte =(byte)(0xff & ret);

		byte retByte = (byte) ((ret >>> 24));
		retByte |= (byte) ((ret >>> 16));
		retByte |= (byte) ((ret >>> 8));
		retByte |= (byte) ((ret >>> 0));

		return retByte;
	}

	public static int floorDiv(int x, int y) {
		int r = x / y;
		// if the signs are different and modulo not zero, round down
		if ((x ^ y) < 0 && (r * y != x)) {
			r--;
		}
		return r;
	}
}
