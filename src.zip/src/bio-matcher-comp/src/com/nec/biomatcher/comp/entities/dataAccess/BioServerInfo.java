package com.nec.biomatcher.comp.entities.dataAccess;

import java.util.Date;
import java.util.Map;

import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerType;
import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioServerInfo.
 */
public class BioServerInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The server id. */
	private String serverId;

	/** The server type. */
	private BioServerType serverType;

	/** The server state. */
	private BioServerState serverState;

	/** The server host. */
	private String serverHost;

	/** The component type. */
	private BioComponentType componentType;

	/** The server group id. */
	private String serverGroupId;

	/** The sub system group id. */
	private String subSystemGroupId;

	/** The max job count. */
	private Integer maxJobCount;

	/** The server properties. */
	private Map<String, String> serverProperties;

	/** The create date time. */
	private Date createDateTime;

	/** The update date time. */
	private Date updateDateTime;

	private boolean onlineFlag;

	private boolean lastOnlineDateTime;

	private boolean lastOfflineDateTime;

	public String getServerId() {
		return serverId;
	}

	public void setServerId(String serverId) {
		this.serverId = serverId;
	}

	public BioServerType getServerType() {
		return serverType;
	}

	public void setServerType(BioServerType serverType) {
		this.serverType = serverType;
	}

	public BioServerState getServerState() {
		return serverState;
	}

	public void setServerState(BioServerState serverState) {
		this.serverState = serverState;
	}

	public String getServerHost() {
		return serverHost;
	}

	public void setServerHost(String serverHost) {
		this.serverHost = serverHost;
	}

	public BioComponentType getComponentType() {
		return componentType;
	}

	public void setComponentType(BioComponentType componentType) {
		this.componentType = componentType;
	}

	public String getServerGroupId() {
		return serverGroupId;
	}

	public void setServerGroupId(String serverGroupId) {
		this.serverGroupId = serverGroupId;
	}

	public String getSubSystemGroupId() {
		return subSystemGroupId;
	}

	public void setSubSystemGroupId(String subSystemGroupId) {
		this.subSystemGroupId = subSystemGroupId;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public Integer getMaxJobCount() {
		return maxJobCount;
	}

	public void setMaxJobCount(Integer maxJobCount) {
		this.maxJobCount = maxJobCount;
	}

	public Map<String, String> getServerProperties() {
		return serverProperties;
	}

	public void setServerProperties(Map<String, String> serverProperties) {
		this.serverProperties = serverProperties;
	}

	public String getServerProperty(String key, String defaultValue) {
		if (serverProperties == null || !serverProperties.containsKey(key)) {
			return defaultValue;
		}
		return serverProperties.getOrDefault(key, defaultValue);
	}
}
