package com.nec.biomatcher.comp.entities.dataAccess.types;

/**
 * The Enum BioMatchManagerState.
 */
public enum BioMatchManagerState {

	/** The active. */
	ACTIVE,

	/** The offline. */
	OFFLINE,

	/** The standby. */
	STANDBY;

}
