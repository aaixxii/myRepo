package com.nec.biomatcher.comp.common.locking.dataAccess.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.nec.biomatcher.comp.common.locking.dataAccess.BioLockInfo;
import com.nec.biomatcher.comp.common.locking.dataAccess.BioLockingServiceDao;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

/**
 * Database access bean for LockInfo.
 *
 * @author Mahesh
 * @version 1.0
 * @since 22 June 2012
 * 
 *        Modification History: 08-Mar-2013 Mahesh: Modified to remove hostName
 *        from part of primary key due to some loophole in locking mechanism
 */
public class BioLockingServiceHibernateImpl extends AbstractHibernateDao implements BioLockingServiceDao {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nec.asia.baf.comp.locking.dataAccess.LockingServiceDao#
	 * deleteExpiredLockInfoByLockKeySuffix(java.lang.String, long)
	 */
	public void deleteExpiredLockInfoByLockKeySuffix(String lockKeySuffix, long lockTimeoutMilli) throws DaoException {
		try {
			Query query = this.currentSession().createQuery(
					"delete from BioLockInfo where lockKey like '(:lockKeySuffix)' and (lockAcquireMilli is NULL or (:currentMilli-lockAcquireMilli)>lockTimeoutMilli)");
			query.setParameter("lockKeySuffix", "%" + lockKeySuffix);
			query.setLong("currentMilli", System.currentTimeMillis());
		} catch (HibernateException ex) {
			throw new DaoException("Error in deleteLockInfo: " + ex.getMessage(), ex);
		}
	}

	@SuppressWarnings("unchecked")
	public List<String> getLockKeysWithPrefix(String prefix) throws DaoException {
		try {
			Criteria criteria = this.currentSession().createCriteria(BioLockInfo.class);
			criteria.add(Restrictions.like("lockKey", prefix, MatchMode.START));
			criteria.setProjection(Projections.property("lockKey"));
			return criteria.list();
		} catch (HibernateException ex) {
			throw new DaoException("Error in getLockKeysWithPrefix: prefix: " + prefix + " : " + ex.getMessage(), ex);
		}
	}

}
