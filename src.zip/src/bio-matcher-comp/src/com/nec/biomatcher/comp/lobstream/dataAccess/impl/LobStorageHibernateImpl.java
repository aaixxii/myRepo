package com.nec.biomatcher.comp.lobstream.dataAccess.impl;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import com.nec.biomatcher.comp.lobstream.dataAccess.BioLobDataInfo;
import com.nec.biomatcher.comp.lobstream.dataAccess.LobStrorageDao;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDaoException;

public class LobStorageHibernateImpl extends AbstractHibernateDao implements LobStrorageDao {

	@Override
	public int deleteBioLobDataInfo(String lobId) throws DaoException {
	    String hql = "delete from BioLobDataInfo where lobId=:lobId";
		try {
			int deleteCount = this.currentSession().createQuery(hql).setString("lobId", lobId)
					.executeUpdate();

			return deleteCount;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}
	
	@Override
	public boolean deleteLob(String lobId, String lobType) throws DaoException {
	    String hql = "delete from BioLobDataInfo where lobId=:lobId and lobType=:lobType";
        try {
            int deleteCount = this.currentSession().createQuery(hql)
                .setString("lobId", lobId)
                .setString("lobType", lobType)
                .executeUpdate();
            if (deleteCount > 0) {
                return true;
            }
           
        } catch (Throwable th) {
            throw new HibernateDaoException(th);
        }
        return false;
	    
	}

    @Override
    public int deleteLobDataBeforeDate(Date date) throws DaoException {
       // String hql = "delete from BioLobDataInfo where lobId=:lobId and lobType=:lobType and createDateTime<=:deletDate";
        String hql = "delete from BioLobDataInfo where createDateTime<=:deletDate";
        try {
            int deleteCount = this.currentSession().createQuery(hql)               
                .setDate("deletDate", date)
                .executeUpdate();
           return deleteCount;
           
        } catch (Throwable th) {
            throw new HibernateDaoException(th);
        }       
    }

	@SuppressWarnings("unchecked")
	@Override
	public List<BioLobDataInfo> getLobDataBeforeDate(Date date) throws DaoException {
		try {
			Criteria criteria = 
					this.currentSession()
					.createCriteria(BioLobDataInfo.class)
					.add(Restrictions.le("createDateTime", date));
		 criteria.setMaxResults(5000);	
		 return (List<BioLobDataInfo>) criteria.list();			
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}	
	}	
}
