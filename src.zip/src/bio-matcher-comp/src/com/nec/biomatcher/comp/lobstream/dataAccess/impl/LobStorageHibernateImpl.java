package com.nec.biomatcher.comp.lobstream.dataAccess.impl;

import java.util.Date;

import com.nec.biomatcher.comp.lobstream.dataAccess.LobStrorageDao;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDaoException;

public class LobStorageHibernateImpl extends AbstractHibernateDao implements LobStrorageDao {

	@Override
	public int deleteBioLobDataInfo(String lobId) throws DaoException {
	    String hql = "delete from BioLobDataInfo where lobId=:lobId";
		try {
			int deleteCount = this.currentSession().createQuery(hql).setString("lobId", lobId)
					.executeUpdate();

			return deleteCount;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}
	
	@Override
	public boolean deleteLob(String lobId, String lobType) throws DaoException {
	    String hql = "delete from BioLobDataInfo where lobId=:lobId and lobType=:lobType";
        try {
            int deleteCount = this.currentSession().createQuery(hql)
                .setString("lobId", lobId)
                .setString("lobType", lobType)
                .executeUpdate();
            if (deleteCount > 0) {
                return true;
            }
           
        } catch (Throwable th) {
            throw new HibernateDaoException(th);
        }
        return false;
	    
	}

    @Override
    public int deleteLobBeferDate(Date date) throws DaoException {
       // String hql = "delete from BioLobDataInfo where lobId=:lobId and lobType=:lobType and createDateTime<=:deletDate";
        String hql = "delete from BioLobDataInfo where createDateTime<=:deletDate";
        try {
            int deleteCount = this.currentSession().createQuery(hql)               
                .setDate("deletDate", date)
                .executeUpdate();
           return deleteCount;
           
        } catch (Throwable th) {
            throw new HibernateDaoException(th);
        }       
    }	
}
