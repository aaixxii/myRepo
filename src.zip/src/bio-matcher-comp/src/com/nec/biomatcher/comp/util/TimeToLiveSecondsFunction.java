package com.nec.biomatcher.comp.util;

import java.util.function.BiFunction;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

public class TimeToLiveSecondsFunction implements BiFunction<String, Integer, Integer> {
	private static final Logger logger = Logger.getLogger(TimeToLiveSecondsFunction.class);

	private BioParameterService bioParameterService;

	@Override
	public Integer apply(String parameterName, Integer defaultTimeToLiveSeconds) {
		try {
			return getBioParameterService().getParameterValue(parameterName, "DEFAULT", defaultTimeToLiveSeconds);
		} catch (Throwable th) {
			logger.error("Error in TimeToLiveSecondsFunction for parameterName: " + parameterName
					+ ", defaultTimeToLiveSeconds: " + defaultTimeToLiveSeconds + " : " + th.getMessage(), th);
		}

		return defaultTimeToLiveSeconds;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public BioParameterService getBioParameterService() {
		if (bioParameterService == null) {
			bioParameterService = SpringServiceManager.getBean("bioParameterService");
		}
		return bioParameterService;
	}
}
