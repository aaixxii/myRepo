package com.nec.biomatcher.comp.common.errorlog.dataAccess;

import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

public interface BioMatcherErrorLogDao extends HibernateDao {

}
