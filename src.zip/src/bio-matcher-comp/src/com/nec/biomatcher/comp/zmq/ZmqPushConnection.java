package com.nec.biomatcher.comp.zmq;

import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.commons.pool2.BaseKeyedPooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericKeyedObjectPool;
import org.apache.log4j.Logger;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;
import org.zeromq.ZMQ.Socket;

import com.google.common.util.concurrent.AtomicLongMap;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

public class ZmqPushConnection {
	public static final Logger logger = Logger.getLogger(ZmqPushConnection.class);

	private static final AtomicLongMap<String> concurrencyCounterMap = AtomicLongMap.create();

	private static final ZmqPushMgmtTask zmqPushMgmtTask = new ZmqPushMgmtTask();
	private static final ConcurrentHashMap<String, Context> contextMap = new ConcurrentHashMap<>();
	private static final ZmqPushSocketPoolableObjectFactory connectionFactory = new ZmqPushSocketPoolableObjectFactory();
	private static GenericKeyedObjectPool<String, ZmqPushSocket> zmqPushSocketPool = null;

	public static ZmqPushSocket createSocket(final String connectionUrl) throws ZmqConnectionException {
		try {
			return connectionFactory.createSocket(connectionUrl, true);
		} catch (ZmqConnectionException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new ZmqConnectionException(
					"Error creating socket for connectionUrl: " + connectionUrl + " : " + th.getMessage(), th);
		}
	}

	public static void closeSocket(final ZmqPushSocket zmqPushSocket) throws ZmqConnectionException {
		try {
			connectionFactory.closeSocket(zmqPushSocket, true);
		} catch (ZmqConnectionException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new ZmqConnectionException(
					"Error closing socket for connectionUrl: " + zmqPushSocket.connectionUrl + " : " + th.getMessage(),
					th);
		}
	}

	public static void closeSocketQuitely(final ZmqPushSocket zmqPushSocket) {
		try {
			connectionFactory.closeSocket(zmqPushSocket, false);
		} catch (Throwable th) {
			logger.error(
					"Error closing socket for connectionUrl: " + zmqPushSocket.connectionUrl + " : " + th.getMessage(),
					th);
		}
	}

	public static void sendMessage(final ZmqPushSocket zmqPushSocket, final String messageKey, final byte messageBuf[])
			throws ZmqSendException {
		try {
			if (messageBuf == null || messageBuf.length == 0) {
				logger.error("Message payload bytearray is null or empty for messageKey: " + messageKey);
				return;
			}

			if (logger.isTraceEnabled())
				logger.trace("In sendMessages: Before sending to connectionUrl: " + zmqPushSocket.connectionUrl
						+ ", messageKey: " + messageKey + ", messageBufSize: " + messageBuf.length);

			boolean sendFlag = false;
			long sendStartTimeMilli = System.currentTimeMillis();
			long concurrencyCount = concurrencyCounterMap.incrementAndGet(zmqPushSocket.connectionUrl);
			try {
				sendFlag = zmqPushSocket.send(messageBuf);
			} finally {
				concurrencyCounterMap.decrementAndGet(zmqPushSocket.connectionUrl);
			}

			long sendTimeTakenMilli = System.currentTimeMillis() - sendStartTimeMilli;

			if (sendFlag) {
				if (sendTimeTakenMilli > 100 || logger.isDebugEnabled())
					logger.info("In sendMessages: After sending to connectionUrl: " + zmqPushSocket.connectionUrl
							+ ", sendTimeTakenMilli: " + sendTimeTakenMilli + ", messageKey: " + messageKey
							+ ", messageBufSize: " + messageBuf.length + ", concurrencyCount: " + concurrencyCount);
			} else {
				logger.error("In sendMessages: sendFlag is false for messageKey: " + messageKey + ", messageBufSize: "
						+ messageBuf.length + " to connectionUrl: " + zmqPushSocket.connectionUrl
						+ ", sendTimeTakenMilli: " + sendTimeTakenMilli + ", concurrencyCount: " + concurrencyCount);

				throw new ZmqSendException("Send flag is false while sending message to connectionUrl: "
						+ zmqPushSocket.connectionUrl + ":  sendTimeTakenMilli: " + sendTimeTakenMilli
						+ ", messageKey: " + messageKey + ", messageBufSize: " + messageBuf.length);
			}

		} catch (ZmqSendException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new ZmqSendException(
					"Error sending message to connectionUrl: " + zmqPushSocket.connectionUrl + ", messageKey: "
							+ messageKey + ", messageBufSize: " + messageBuf.length + " : " + th.getMessage(),
					th);
		}
	}

	public static void sendMessages(final ZmqPushSocket zmqPushSocket, final List<BiKey<String, byte[]>> messageList)
			throws ZmqSendException {
		if (messageList == null || messageList.size() == 0) {
			return;
		}

		long startTimeMilli = System.currentTimeMillis();
		try {
			for (BiKey<String, byte[]> message : messageList) {
				if (message == null) {
					return;
				}

				if (message.b == null || message.b.length == 0) {
					logger.error("Message payload bytearray is null or empty for messageKey: " + message.a);
					return;
				}

				if (logger.isTraceEnabled())
					logger.trace("In sendMessages: Before sending to connectionUrl: " + zmqPushSocket.connectionUrl
							+ ", messageKey: " + message.a + ", messageBufSize: " + message.b.length);

				boolean sendFlag = false;
				long sendStartTimeMilli = System.currentTimeMillis();
				long concurrencyCount = concurrencyCounterMap.incrementAndGet(zmqPushSocket.connectionUrl);
				try {
					sendFlag = zmqPushSocket.send(message.b);
				} finally {
					concurrencyCounterMap.decrementAndGet(zmqPushSocket.connectionUrl);
				}

				long sendTimeTakenMilli = System.currentTimeMillis() - sendStartTimeMilli;

				if (sendFlag) {
					if (sendTimeTakenMilli > 100 || logger.isDebugEnabled())
						logger.info("In sendMessages: After sending to connectionUrl: " + zmqPushSocket.connectionUrl
								+ ", sendTimeTakenMilli: " + sendTimeTakenMilli + ", messageKey: " + message.a
								+ ", messageBufSize: " + message.b.length + ", concurrencyCount: " + concurrencyCount);
				} else {
					logger.error("In sendMessages: sendFlag is false for messageKey: " + message.a
							+ ", messageBufSize: " + message.b.length + " to connectionUrl: "
							+ zmqPushSocket.connectionUrl + ", sendTimeTakenMilli: " + sendTimeTakenMilli
							+ ", concurrencyCount: " + concurrencyCount);

					throw new ZmqSendException("Send flag is false while sending message to connectionUrl: "
							+ zmqPushSocket.connectionUrl + ":  sendTimeTakenMilli: " + sendTimeTakenMilli
							+ ", messageKey: " + message.a + ", messageBufSize: " + message.b.length);
				}
			}
		} catch (ZmqSendException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new ZmqSendException("Error sending message to connectionUrl: " + zmqPushSocket.connectionUrl
					+ ", sendTimeTakenMilli: " + (System.currentTimeMillis() - startTimeMilli) + ", messageListCount: "
					+ messageList.size() + " : " + th.getMessage(), th);
		}
	}

	public static void sendMessage(final String connectionUrl, final String messageKey, final byte messageBuf[])
			throws ZmqSendException {
		if (messageBuf == null || messageBuf.length == 0) {
			logger.error("Message payload bytearray is null or empty for messageKey: " + messageKey);
			return;
		}

		boolean exceptionFlag = false;
		long startTime = System.currentTimeMillis();
		ZmqPushSocket zmqPushSocket = null;
		try {
			zmqPushSocket = borrowSenderSocket(connectionUrl);

			sendMessage(zmqPushSocket, messageKey, messageBuf);
		} catch (ZmqSendException ex) {
			exceptionFlag = true;
			throw ex;
		} catch (Throwable th) {
			exceptionFlag = true;
			throw new ZmqSendException("Error sending message to connectionUrl: " + connectionUrl
					+ ", sendTimeTakenMilli: " + (System.currentTimeMillis() - startTime) + ", messageKey: "
					+ messageKey + ", messageBufSize: " + messageBuf.length + " : " + th.getMessage(), th);
		} finally {
			returnSenderSocket(zmqPushSocket);

			long totalTimeTakenMilli = System.currentTimeMillis() - startTime;

			if (exceptionFlag || totalTimeTakenMilli > 1000 || logger.isTraceEnabled())
				logger.info(
						"In sendMessage: After sending to connectionUrl: " + connectionUrl + ", totalTimeTakenMilli: "
								+ totalTimeTakenMilli + ", messageKey: " + messageKey + ", messageBufSize: "
								+ messageBuf.length + (exceptionFlag ? (", exceptionFlag: " + exceptionFlag) : ""));
		}
	}

	public static void sendMessages(final String connectionUrl, final List<BiKey<String, byte[]>> messageList)
			throws ZmqSendException {
		if (messageList == null || messageList.size() == 0) {
			return;
		}

		boolean exceptionFlag = false;
		long startTime = System.currentTimeMillis();
		ZmqPushSocket zmqPushSocket = null;
		try {
			zmqPushSocket = borrowSenderSocket(connectionUrl);
			sendMessages(zmqPushSocket, messageList);
		} catch (ZmqSendException ex) {
			exceptionFlag = true;
			throw ex;
		} catch (Throwable th) {
			exceptionFlag = true;
			throw new ZmqSendException("Error in sendMessages to connectionUrl: " + connectionUrl
					+ ", sendTimeTakenMilli: " + (System.currentTimeMillis() - startTime) + ", messageListSize: "
					+ messageList.size() + " : " + th.getMessage(), th);
		} finally {
			returnSenderSocket(zmqPushSocket);

			long totalTimeTakenMilli = System.currentTimeMillis() - startTime;

			if (exceptionFlag || totalTimeTakenMilli > 1000 || logger.isTraceEnabled())
				logger.info("In sendMessages: After sending to connectionUrl: " + connectionUrl
						+ ", totalTimeTakenMilli: " + totalTimeTakenMilli + ", messageListSize: " + messageList.size()
						+ (exceptionFlag ? (", exceptionFlag: " + exceptionFlag) : ""));
		}
	}

	public static final ZmqPushSocket borrowSenderSocket(String connectionUrl) throws ZmqConnectionException {
		if (zmqPushSocketPool == null) {
			initializePool();
		}

		long startTime = System.currentTimeMillis();
		try {
			return zmqPushSocketPool.borrowObject(connectionUrl);
		} catch (ZmqConnectionException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new ZmqConnectionException(
					"Error in borrowSenderSocket for connectionUrl: " + connectionUrl + " : " + th.getMessage(), th);
		} finally {
			long totalTimeTakenMilli = System.currentTimeMillis() - startTime;
			if (totalTimeTakenMilli > 100) {
				CommonLogger.PERF_LOG.info("In borrowSenderSocket: After borrowObject for connectionUrl: "
						+ connectionUrl + ", totalTimeTakenMilli: " + totalTimeTakenMilli + ", numActive: "
						+ zmqPushSocketPool.getNumActive(connectionUrl) + ", numIdle: "
						+ zmqPushSocketPool.getNumIdle(connectionUrl));
			}
		}
	}

	public static final void returnSenderSocket(ZmqPushSocket zmqPushSocket) {
		if (zmqPushSocket == null) {
			return;
		}

		try {
			if (zmqPushSocket.isErrorSendFlag()) {
				logger.error("Invalidating ZMQ socket for connectionUrl: " + zmqPushSocket.connectionUrl
						+ " due to send error");
				zmqPushSocketPool.invalidateObject(zmqPushSocket.connectionUrl, zmqPushSocket);
			} else {
				zmqPushSocketPool.returnObject(zmqPushSocket.connectionUrl, zmqPushSocket);
			}

		} catch (Throwable th) {
			logger.error("Error while returning sender socket to pool for connectionUrl: " + zmqPushSocket.connectionUrl
					+ " : " + th.getMessage(), th);
		}
	}

	public static final void returnSenderSocket(ZmqPushSocketRef zmqPushSocketRef) {
		if (zmqPushSocketRef == null) {
			return;
		}

		if (zmqPushSocketRef.zmqPushSocket != null) {
			returnSenderSocket(zmqPushSocketRef.zmqPushSocket);
			zmqPushSocketRef.zmqPushSocket = null;
		}
	}

	private static final void initializePool() {
		synchronized (ZmqPushConnection.class) {
			if (zmqPushSocketPool == null) {
				zmqPushSocketPool = buildPool();
			}
		}
	}

	private static GenericKeyedObjectPool<String, ZmqPushSocket> buildPool() {
		GenericKeyedObjectPool<String, ZmqPushSocket> zmqPushSocketPool = new GenericKeyedObjectPool<>(
				connectionFactory);
		zmqPushSocketPool.setLifo(false);

		adjustPool(zmqPushSocketPool);

		CommonTaskScheduler.scheduleWithFixedDelay(zmqPushMgmtTask, 1, 1, TimeUnit.SECONDS);

		return zmqPushSocketPool;
	}

	private static void adjustPool(GenericKeyedObjectPool<String, ZmqPushSocket> zmqPushSocketPool) {
		if (zmqPushSocketPool == null) {
			return;
		}

		boolean modifiedFlag = false;
		BioParameterService bioParameterService = SpringServiceManager.getBean("bioParameterService");
		int stubPoolMaxActiveCount = bioParameterService.getParameterValue("ZMQ_PUSH_POOL_MAX_SOCKETS_PER_KEY",
				"DEFAULT", 30);
		int stubPoolMaxIdleCount = bioParameterService.getParameterValue("ZMQ_PUSH_POOL_MAX_IDLE_SOCKETS_PER_KEY",
				"DEFAULT", 10);
		int stubPoolMinIdleCount = bioParameterService.getParameterValue("ZMQ_PUSH_POOL_MIN_IDLE_SOCKETS_PER_KEY",
				"DEFAULT", 0);
		long idleTimeoutMilli = bioParameterService.getParameterValue("ZMQ_PUSH_POOL_IDLE_TIMEOUT_MILLI", "DEFAULT",
				TimeUnit.MINUTES.toMillis(30));
		long evectionThreadIntervalMilli = bioParameterService.getParameterValue("ZMQ_PUSH_POOL_EVICT_INTERVAL_MILLI",
				"DEFAULT", -1L);
		boolean useSoftIdleTimeoutFlag = bioParameterService.getParameterValue("ZMQ_PUSH_USE_SOFT_IDLE_TIMEOUT_FLAG",
				"DEFAULT", false);

		if (stubPoolMaxActiveCount != zmqPushSocketPool.getMaxTotalPerKey()) {
			zmqPushSocketPool.setMaxTotalPerKey(stubPoolMaxActiveCount);
			modifiedFlag = true;
		}

		if (stubPoolMaxIdleCount != zmqPushSocketPool.getMaxIdlePerKey()) {
			zmqPushSocketPool.setMaxIdlePerKey(stubPoolMaxIdleCount);
			modifiedFlag = true;
		}

		if (stubPoolMinIdleCount != zmqPushSocketPool.getMinIdlePerKey()) {
			zmqPushSocketPool.setMinIdlePerKey(stubPoolMinIdleCount);
			modifiedFlag = true;
		}

		if (useSoftIdleTimeoutFlag) {
			int newStubPoolMinIdleCount = stubPoolMinIdleCount <= 0 ? stubPoolMaxIdleCount : stubPoolMinIdleCount;
			if (newStubPoolMinIdleCount != zmqPushSocketPool.getMinIdlePerKey()) {
				zmqPushSocketPool.setMinIdlePerKey(newStubPoolMinIdleCount);
				modifiedFlag = true;
			}

			zmqPushSocketPool.setMinEvictableIdleTimeMillis(-1);
			if (idleTimeoutMilli != zmqPushSocketPool.getSoftMinEvictableIdleTimeMillis()) {
				zmqPushSocketPool.setSoftMinEvictableIdleTimeMillis(idleTimeoutMilli);
				modifiedFlag = true;
			}
		} else {
			if (stubPoolMinIdleCount != zmqPushSocketPool.getMinIdlePerKey()) {
				zmqPushSocketPool.setMinIdlePerKey(stubPoolMinIdleCount);
				modifiedFlag = true;
			}

			zmqPushSocketPool.setSoftMinEvictableIdleTimeMillis(-1);
			if (idleTimeoutMilli != zmqPushSocketPool.getMinEvictableIdleTimeMillis()) {
				zmqPushSocketPool.setMinEvictableIdleTimeMillis(idleTimeoutMilli);
				modifiedFlag = true;
			}
		}

		if (idleTimeoutMilli != zmqPushSocketPool.getMinEvictableIdleTimeMillis()) {
			zmqPushSocketPool.setMinEvictableIdleTimeMillis(idleTimeoutMilli);
			modifiedFlag = true;
		}

		if (evectionThreadIntervalMilli != zmqPushSocketPool.getTimeBetweenEvictionRunsMillis()) {
			zmqPushSocketPool.setTimeBetweenEvictionRunsMillis(evectionThreadIntervalMilli);
			modifiedFlag = true;
		}

		if (modifiedFlag) {
			CommonLogger.CONFIG_LOG.info("In ZmqPushConnection.adjustPool: modifiedFlag: " + modifiedFlag
					+ ", stubPoolMaxActiveCount: " + stubPoolMaxActiveCount + ", stubPoolMaxIdleCount: "
					+ stubPoolMaxIdleCount + ", stubPoolMinIdleCount: " + zmqPushSocketPool.getMinIdlePerKey()
					+ ", minEvictableIdleTimeMilli: " + idleTimeoutMilli + ", useSoftIdleTimeoutFlag: "
					+ useSoftIdleTimeoutFlag + ", evectionThreadIntervalMilli: " + evectionThreadIntervalMilli
					+ ", createdCount: " + zmqPushSocketPool.getCreatedCount() + ", numActive: "
					+ zmqPushSocketPool.getNumActive() + ", numIdle: " + zmqPushSocketPool.getNumIdle()
					+ ", borrowedCount: " + zmqPushSocketPool.getBorrowedCount() + ", returnedCount: "
					+ zmqPushSocketPool.getReturnedCount());
		} else if (logger.isTraceEnabled()) {
			CommonLogger.STATUS_LOG.info("In ZmqPushConnection.adjustPool: modifiedFlag: " + modifiedFlag
					+ ", stubPoolMaxActiveCount: " + stubPoolMaxActiveCount + ", stubPoolMaxIdleCount: "
					+ stubPoolMaxIdleCount + ", stubPoolMinIdleCount: " + zmqPushSocketPool.getMinIdlePerKey()
					+ ", minEvictableIdleTimeMilli: " + idleTimeoutMilli + ", useSoftIdleTimeoutFlag: "
					+ useSoftIdleTimeoutFlag + ", evectionThreadIntervalMilli: " + evectionThreadIntervalMilli
					+ ", createdCount: " + zmqPushSocketPool.getCreatedCount() + ", numActive: "
					+ zmqPushSocketPool.getNumActive() + ", numIdle: " + zmqPushSocketPool.getNumIdle()
					+ ", borrowedCount: " + zmqPushSocketPool.getBorrowedCount() + ", returnedCount: "
					+ zmqPushSocketPool.getReturnedCount());
		}
	}

	private static final class ZmqPushSocketPoolableObjectFactory
			extends BaseKeyedPooledObjectFactory<String, ZmqPushSocket> {

		private final Supplier<Integer> zmqPushIoThreadCountSupplier = BioParameterService
				.getIntSupplier("ZMQ_PUSH_IO_THREAD_COUNT", "DEFAULT", 2);
		private final Supplier<Long> lingerTimeoutMilliSupplier = BioParameterService
				.getLongSupplier("ZMQ_PUSH_LINGER_TIMEOUT_MILLI", "DEFAULT", 1000L);
		private final Supplier<Integer> sendTimeoutMilliSupplier = BioParameterService
				.getIntSupplier("ZMQ_PUSH_SEND_TIMEOUT_MILLI", "DEFAULT", 5000);
		private final Supplier<Long> zmqPushSendHmwSupplier = BioParameterService
				.getLongSupplier("ZMQ_PUSH_SEND_HIGH_WATER_MARK", "DEFAULT", -1L);
		private final Supplier<Boolean> zmqPushUseCommonContextFlagSupplier = BioParameterService
				.getBooleanSupplier("ZMQ_PUSH_USE_COMMON_CONTEXT_FLAG", "DEFAULT", Boolean.FALSE);

		@Override
		public ZmqPushSocket create(String connectionUrl) throws Exception {
			return createSocket(connectionUrl, true);
		}

		@Override
		public void destroyObject(String connectionUrl, PooledObject<ZmqPushSocket> pooledObject) throws Exception {
			if (pooledObject == null) {
				return;
			}
			try {
				closeSocket(pooledObject.getObject(), true);
			} catch (Throwable th) {
				logger.error("Error in ZmqSocketPoolableObjectFactory.destroyObject for connectionUrl: " + connectionUrl
						+ " : " + th.getMessage(), th);
			}
		}

		@Override
		public PooledObject<ZmqPushSocket> wrap(ZmqPushSocket value) {
			return new DefaultPooledObject<>(value);
		}

		public final ZmqPushSocket createSocket(final String connectionUrl, final boolean logFlag)
				throws ZmqConnectionException {
			try {
				boolean useCommonContextFlag = zmqPushUseCommonContextFlagSupplier.get();
				Context context = useCommonContextFlag ? getContext(connectionUrl)
						: ZMQ.context(zmqPushIoThreadCountSupplier.get());

				long zmqPushLingerTimeoutMilli = lingerTimeoutMilliSupplier.get();
				long sendHighWaterMark = zmqPushSendHmwSupplier.get();
				int sendTimeoutMilli = sendTimeoutMilliSupplier.get();

				ZmqPushSocket socket = new ZmqPushSocket(connectionUrl, zmqPushLingerTimeoutMilli, sendHighWaterMark,
						sendTimeoutMilli, context, useCommonContextFlag);

				if (logFlag)
					logger.info("In createSocket: After creating the zmq socket for connectionUrl: " + connectionUrl
							+ " with zmqPushLingerTimeoutMilli: " + zmqPushLingerTimeoutMilli + ", sendHighWaterMark: "
							+ sendHighWaterMark + ", sendTimeoutMilli: " + sendTimeoutMilli + ", " + ", hashCode: "
							+ socket.hashCode());

				return socket;
			} catch (Throwable th) {
				throw new ZmqConnectionException(
						"Error creating socket for connectionUrl: " + connectionUrl + " : " + th.getMessage(), th);
			}
		}

		public void closeSocket(final ZmqPushSocket zmqPushSocket, final boolean logFlag)
				throws ZmqConnectionException {
			try {
				if (zmqPushSocket == null) {
					return;
				}

				zmqPushSocket.close();
				if (logFlag || zmqPushSocket.isErrorSendFlag())
					logger.info("In closeSocket: After closing the zmq socket for connectionUrl: "
							+ zmqPushSocket.connectionUrl + ", messageCounter: " + zmqPushSocket.getMessageCounter()
							+ ", isErrorSendFlag: " + zmqPushSocket.isErrorSendFlag() + ", delayFromLastSentMessage: "
							+ zmqPushSocket.getDelayFromLastSentMessage() + ", hashCode: " + zmqPushSocket.hashCode());

			} catch (Throwable th) {
				throw new ZmqConnectionException(
						"Error closing socket for connectionUrl: " + zmqPushSocket.connectionUrl + ", hashCode: "
								+ zmqPushSocket.hashCode() + " : " + th.getMessage(),
						th);
			}
		}

		private final Context getContext(final String contextKey) {
			Context context = contextMap.get(contextKey);
			if (context == null) {
				context = contextMap.computeIfAbsent(contextKey, contextKeyParam -> {
					int zmqPushIoThreadCount = zmqPushIoThreadCountSupplier.get();
					Context zmqContext = ZMQ.context(zmqPushIoThreadCount);
					logger.info("In makeObject: After creating the zmq context for contextKey: " + contextKey
							+ " with zmqPushIoThreadCount: " + zmqPushIoThreadCount + ", hashCode: "
							+ zmqContext.hashCode());
					return zmqContext;
				});
			}

			return context;
		}
	}

	public static final class ZmqPushSocket implements Closeable {
		private Context context;
		public final String connectionUrl;
		private final long sendTimeoutMilli;
		private Socket socket;
		private boolean errorSendFlag = false;
		private long messageCounter = 0;
		private long lastSendTimestampMilli = 0;

		public ZmqPushSocket(String connectionUrl, long zmqPushLingerTimeoutMilli, long sendHighWaterMark,
				int sendTimeoutMilli, Context context, boolean isCommonContext) {
			this.connectionUrl = connectionUrl;
			this.sendTimeoutMilli = sendTimeoutMilli;

			socket = context.socket(ZMQ.PUSH);

			if (!isCommonContext) {
				this.context = context;
			}

			if (zmqPushLingerTimeoutMilli >= -1) {
				socket.setLinger(zmqPushLingerTimeoutMilli);
			}

			if (sendHighWaterMark > 0) {
				socket.setSndHWM(sendHighWaterMark);
			}

			// Note: If sendTimeoutMilli is too small, it can result in send
			// method return false
			socket.setSendTimeOut(sendTimeoutMilli);

			socket.connect(connectionUrl);
		}

		public boolean send(byte[] messageBuf) {
			try {
				// Note: If sendTimeoutMilli of socket is too small, it can
				// result in send method return false
				boolean sendFlag = socket.send(messageBuf);

				messageCounter++;

				if (!sendFlag) {
					errorSendFlag = true;
				}
				return sendFlag;
			} catch (RuntimeException ex) {
				errorSendFlag = true;
				throw ex;
			} finally {
				lastSendTimestampMilli = System.currentTimeMillis();
			}
		}

		@Override
		public void close() throws IOException {
			try {
				if (socket != null) {
					socket.close();
					socket = null;
				}
			} finally {
				if (context != null) {
					context.close();
					context = null;
				}
			}
		}

		public long getMessageCounter() {
			return messageCounter;
		}

		public long getSendTimeoutMilli() {
			return sendTimeoutMilli;
		}

		public long getLastSendTimestampMilli() {
			return lastSendTimestampMilli;
		}

		public long getDelayFromLastSentMessage() {
			return lastSendTimestampMilli <= 0 ? 0 : (System.currentTimeMillis() - lastSendTimestampMilli);
		}

		public boolean isErrorSendFlag() {
			return errorSendFlag;
		}
	}

	private static class ZmqPushMgmtTask implements Runnable {

		@Override
		public void run() {
			Thread.currentThread().setName("ZmqPushMgmtTask_" + Thread.currentThread().getId());
			logger.info("In ZmqPushMgmtTask.run");

			try {
				while (!ShutdownHook.isShutdownFlag) {
					try {
						Uninterruptibles.sleepUninterruptibly(2, TimeUnit.MINUTES);

						adjustPool(zmqPushSocketPool);
					} catch (Throwable th) {
						logger.error("Error in ZmqPushMgmtTask loop: " + th.getMessage(), th);
					}
				}
			} catch (Throwable th) {
				logger.error("Error in ZmqPushMgmtTask: " + th.getMessage(), th);
			} finally {
				CommonLogger.STATUS_LOG.warn("Exiting ZmqPushMgmtTask: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
			}
		}
	}
}
