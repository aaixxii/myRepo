package com.nec.biomatcher.comp.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;

public class ValueChangeListener {
	private static final Logger logger = Logger.getLogger(ValueChangeListener.class);

	private static final ScheduledFuture<?> scheduledFuture = CommonTaskScheduler
			.scheduleWithFixedDelay(ValueChangeListener::checkAndNotify, 1, 1, TimeUnit.MINUTES);

	private static final List<ValueChangeNotification<?>> notificationList = Collections
			.synchronizedList(new ArrayList<>());

	public static final void registerValueChangeNotification(ValueChangeNotification<?> valueChangeNotification) {

		notificationList.add(valueChangeNotification);
	}

	private static final void checkAndNotify() {
		while (!ShutdownHook.isShutdownFlag) {
			try {
				for (ValueChangeNotification<?> valueChangeNotification : notificationList) {
					try {
						valueChangeNotification.checkAndNotify();
					} catch (Throwable th) {
						logger.error("Error during checkAndNotify for ValueChangeNotification: "
								+ valueChangeNotification + " : " + th.getMessage(), th);
					}
				}
			} finally {
				Uninterruptibles.sleepUninterruptibly(3, TimeUnit.MINUTES);
			}
		}
	}

}
