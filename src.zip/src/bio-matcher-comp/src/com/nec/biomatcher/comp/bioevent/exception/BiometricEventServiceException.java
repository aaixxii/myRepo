package com.nec.biomatcher.comp.bioevent.exception;

import com.nec.biomatcher.comp.bioevent.util.BiometricEventConstants;
import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BiometricEventServiceException.
 */
public class BiometricEventServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	public BiometricEventServiceException(String message) {
		super(BiometricEventConstants.ERROR_CODE_GENERAL, message);
	}

	public BiometricEventServiceException(String message, Throwable cause) {
		super(BiometricEventConstants.ERROR_CODE_GENERAL, message, cause);
	}

	public BiometricEventServiceException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}

}
