package com.nec.biomatcher.comp.bioevent.util;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.base.Throwables;
import com.nec.biomatcher.comp.bioevent.exception.BiometricIdServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdDetailInfo;
import com.nec.biomatcher.core.framework.common.BiKey;

public class StickyAcquireBiometricIdsFunction extends AbstractAcquireBiometricIdsFunction {
	private static final Logger logger = Logger.getLogger(StickyAcquireBiometricIdsFunction.class);

	private static final ConcurrentHashMap<Integer, BiKey<Integer, Long>> binIdLastUsedSegmentIdMap = new ConcurrentHashMap<>();

	@Override
	public List<BiometricIdDetailInfo> apply(Integer binId) {
		logger.info("In StickyAcquireBiometricIdsFunction: binId: " + binId);
		List<BiometricIdDetailInfo> biometricSequenceIdInfoList = new ArrayList<BiometricIdDetailInfo>();
		try {
			long releasedBiometricIdCheckDelayMilli = bioParameterService.getParameterValue(
					"RELEASED_BIOMETRIC_ID_CHECK_DELAY_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(10));
			long biometricIdStickyTimeoutMilli = bioParameterService.getParameterValue(
					"BIOMETRIC_ID_GENERATOR_STICKY_TIMEOUT_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(5));

			int maxPreLoadBiometricIdCount = bioParameterService.getParameterValue("MAX_PRELOAD_BIOMETRIC_ID_COUNT",
					"DEFAULT", 50);

			int requiredBiometricIdCount = maxPreLoadBiometricIdCount;

			if (biometricSequenceIdInfoList.size() < requiredBiometricIdCount) {
				TreeSet<Integer> segmentIdSet = bioMatcherConfigService.getOrderedSegmentIdSetByBinId(binId);

				if (segmentIdSet.isEmpty()) {
					throw new BiometricIdServiceException("BiometricIdInfo is not configured for binId: " + binId);
				}

				BiKey<Integer, Long> lastUsedSegmentIdRef = binIdLastUsedSegmentIdMap.get(binId);
				if (lastUsedSegmentIdRef != null) {
					if ((System.currentTimeMillis() - lastUsedSegmentIdRef.getB()) >= biometricIdStickyTimeoutMilli) {
						releaseStickySegmentId(binId, lastUsedSegmentIdRef);
						lastUsedSegmentIdRef = null;
					}
				}

				Integer firstSegmentId = null;
				while (requiredBiometricIdCount > 0) {
					Integer segmentId = null;
					if (firstSegmentId == null) {
						if (lastUsedSegmentIdRef != null && segmentIdSet.contains(lastUsedSegmentIdRef.getA())) {
							segmentId = lastUsedSegmentIdRef.getA();
						}
					} else if (lastUsedSegmentIdRef != null) {
						segmentId = segmentIdSet.higher(lastUsedSegmentIdRef.getA());
						if (segmentId != null) {
							lastUsedSegmentIdRef = attachStickySegmentId(binId, segmentId);
						}
					}

					if (segmentId == null) {
						segmentId = segmentIdSet.first();
						if (segmentId == null || (segmentId.equals(firstSegmentId))) {
							break;
						}
						lastUsedSegmentIdRef = attachStickySegmentId(binId, segmentId);
					}

					// Cyclic loop breaker
					if (firstSegmentId == null) {
						firstSegmentId = segmentId;
					} else if (firstSegmentId.equals(segmentId)) {
						break;
					}

					if (binIdBiometricIdCheckTimestampMap
							.get(binId) < (System.currentTimeMillis() - releasedBiometricIdCheckDelayMilli)) {
						List<BiometricIdDetailInfo> newBiometricSequenceIdInfoList = biometricIdService
								.acquireReleasedBiometricIdListByBinId(binId, requiredBiometricIdCount);

						if (newBiometricSequenceIdInfoList.size() == 0
								|| newBiometricSequenceIdInfoList.size() < requiredBiometricIdCount) {
							binIdBiometricIdCheckTimestampMap.put(binId, System.currentTimeMillis());
						}

						if (newBiometricSequenceIdInfoList.size() > 0) {
							requiredBiometricIdCount = requiredBiometricIdCount - newBiometricSequenceIdInfoList.size();
							biometricSequenceIdInfoList.addAll(newBiometricSequenceIdInfoList);
						}

						if (requiredBiometricIdCount > 0) {
							newBiometricSequenceIdInfoList = biometricIdService.acquireBiometricIdList(segmentId,
									requiredBiometricIdCount);

							requiredBiometricIdCount = requiredBiometricIdCount - newBiometricSequenceIdInfoList.size();
							biometricSequenceIdInfoList.addAll(newBiometricSequenceIdInfoList);
						}
					} else {
						List<BiometricIdDetailInfo> newBiometricSequenceIdInfoList = biometricIdService
								.acquireBiometricIdList(segmentId, requiredBiometricIdCount);

						requiredBiometricIdCount = requiredBiometricIdCount - newBiometricSequenceIdInfoList.size();
						biometricSequenceIdInfoList.addAll(newBiometricSequenceIdInfoList);

						if (requiredBiometricIdCount > 0) {
							if (binIdBiometricIdCheckTimestampMap
									.get(binId) < (System.currentTimeMillis() - releasedBiometricIdCheckDelayMilli)) {
								newBiometricSequenceIdInfoList = biometricIdService
										.acquireReleasedBiometricIdListByBinId(binId, requiredBiometricIdCount);

								if (newBiometricSequenceIdInfoList.size() == 0
										|| newBiometricSequenceIdInfoList.size() < requiredBiometricIdCount) {
									binIdBiometricIdCheckTimestampMap.put(binId, System.currentTimeMillis());
								}

								if (newBiometricSequenceIdInfoList.size() > 0) {
									requiredBiometricIdCount = requiredBiometricIdCount
											- newBiometricSequenceIdInfoList.size();
									biometricSequenceIdInfoList.addAll(newBiometricSequenceIdInfoList);
								}
							}
						}
					}
				}
			}

			if (biometricSequenceIdInfoList.size() == 0) {
				throw new BiometricIdServiceException("BiometricId's are not available for binId: " + binId
						+ ", requiredBiometricIdCount: " + requiredBiometricIdCount);
			}

			return biometricSequenceIdInfoList;
		} catch (BiometricIdServiceException ex) {
			throw Throwables.propagate(ex);
		} catch (Throwable th) {
			throw Throwables.propagate(new BiometricIdServiceException(
					"Error in preAcquireBiometricIds for binId: " + binId + " : " + th.getMessage(), th));
		}
	}

	private void releaseStickySegmentId(Integer binId, BiKey<Integer, Long> lastUsedSegmentIdRef) {
		if (lastUsedSegmentIdRef != null) {
			logger.info("Releasing sticky segmentId: " + lastUsedSegmentIdRef.getA() + " for binId: " + binId
					+ ", lastStickyTimestampMilli: " + lastUsedSegmentIdRef.getB());
			binIdLastUsedSegmentIdMap.remove(binId);
		}
	}

	private BiKey<Integer, Long> attachStickySegmentId(Integer binId, Integer segmentId) {
		BiKey<Integer, Long> lastUsedSegmentIdRef = new BiKey<Integer, Long>(segmentId, System.currentTimeMillis());
		binIdLastUsedSegmentIdMap.put(binId, lastUsedSegmentIdRef);
		logger.info("Attached sticky segmentId: " + lastUsedSegmentIdRef.getA() + " for binId: " + binId
				+ ", lastStickyTimestampMilli: " + lastUsedSegmentIdRef.getB());
		return lastUsedSegmentIdRef;
	}

}
