package com.nec.biomatcher.comp.admin.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class BioAdminServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	public BioAdminServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public BioAdminServiceException(String message) {
		super(message);
	}

	public BioAdminServiceException(Throwable cause) {
		super(cause);
	}

}
