package com.nec.biomatcher.comp.lobstream.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

public interface LobStrorageDao extends HibernateDao {
	public int deleteBioLobDataInfo(String lobId) throws DaoException;
	public boolean deleteLob(String lobId, String lobType) throws DaoException;
	public int deleteLobBeferDate(Date date) throws DaoException;
}
