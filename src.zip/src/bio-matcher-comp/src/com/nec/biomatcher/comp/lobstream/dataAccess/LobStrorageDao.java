package com.nec.biomatcher.comp.lobstream.dataAccess;

import java.util.Date;
import java.util.List;

import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

public interface LobStrorageDao extends HibernateDao {
	public int deleteBioLobDataInfo(String lobId) throws DaoException;
	public boolean deleteLob(String lobId, String lobType) throws DaoException;
	public int deleteLobDataBeforeDate(Date date) throws DaoException;
	public List<BioLobDataInfo> getLobDataBeforeDate(Date date) throws DaoException; 

}
