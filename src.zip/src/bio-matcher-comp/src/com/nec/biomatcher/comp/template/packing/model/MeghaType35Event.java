package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Set;

import com.google.common.collect.Sets;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType35Event extends MeghaEvent {
	public static final int COUNT_MAX_FINGERS = 10;

	private byte rollOrSlap; // Char indicating roll (R) or slap (S). Any other
								// value will be treated as roll.
	private byte matchConfig; // Used to store the config based on which the
								// match param will be chosen.
	private byte[] quality;
	private byte cmlFeatureData[];

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}
		printStream.printf("%-20s - %s\n", "rollOrSlap", (char) rollOrSlap);
		printStream.printf("%-20s - %s\n", "matchConfig", matchConfig);
		printStream.printf("%-20s - %s\n", "quality", Arrays.toString(quality));
		printStream.printf("%-20s - %s\n", "cmlFeatureData", cmlFeatureData != null);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).bytes(1).bytes(1).quality(COUNT_MAX_FINGERS)
				.featureDataLength(4).featureData(1, "FINGER_CML_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FINGER_CML);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (cmlFeatureData.length == 0
				|| cmlFeatureData.length > meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid cmlFeatureData length, actual: " + cmlFeatureData.length
					+ ", expected: " + meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
		}

		if (rollOrSlap != 'R' && rollOrSlap != 'S') {
			throw new MeghaTemplateException(
					"Invalid rollOrSlap flag: " + ((char) rollOrSlap) + ", expected: 'R' or 'S'");
		}

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.FINGER_CML.getValue().byteValue());

		if (quality == null) {
			quality = new byte[COUNT_MAX_FINGERS];
		}

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());

		eventDataBuf.put(rollOrSlap);
		eventDataBuf.put(matchConfig);

		eventDataBuf.put(quality);

		eventDataBuf.putInt(cmlFeatureData.length);

		eventDataBuf.put(cmlFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE") - cmlFeatureData.length);

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		rollOrSlap = eventDataBuf.get();
		matchConfig = eventDataBuf.get();

		quality = new byte[COUNT_MAX_FINGERS];
		eventDataBuf.get(quality);

		int dataSize = eventDataBuf.getInt();

		if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
					+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE"));
		}

		cmlFeatureData = new byte[dataSize];
		eventDataBuf.get(cmlFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("FINGER_CML_FEATURE_DATA_SIZE") - dataSize);
	}

	public byte[] getQuality() {
		return quality;
	}

	public void setQuality(byte[] quality) {
		this.quality = quality;
	}

	public byte[] getCmlFeatureData() {
		return cmlFeatureData;
	}

	public void setCmlFeatureData(byte[] cmlFeatureData) {
		this.cmlFeatureData = cmlFeatureData;
	}

	public byte getRollOrSlap() {
		return rollOrSlap;
	}

	public void setRollOrSlap(byte rollOrSlap) {
		this.rollOrSlap = rollOrSlap;
	}

	public byte getMatchConfig() {
		return matchConfig;
	}

	public void setMatchConfig(byte matchConfig) {
		this.matchConfig = matchConfig;
	}

}
