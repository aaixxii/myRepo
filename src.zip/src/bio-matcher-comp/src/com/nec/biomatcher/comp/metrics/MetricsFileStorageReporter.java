package com.nec.biomatcher.comp.metrics;

import java.io.IOException;
import java.util.Calendar;
import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.log4j.Logger;

import com.codahale.metrics.Counter;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.ScheduledReporter;
import com.codahale.metrics.Snapshot;
import com.codahale.metrics.Timer;
import com.google.common.base.Charsets;
import com.google.common.util.concurrent.Uninterruptibles;
import com.google.gson.JsonObject;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.util.ServerStatusMonitor;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class MetricsFileStorageReporter extends ScheduledReporter {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(MetricsFileStorageReporter.class);

	/** The hostname. */
	private String hostname;

	private MetricsFileStorage metricsFileStorage;

	private Supplier<Integer> schedulerDalaySeconds;

	/**
	 * For registry.
	 *
	 * @param registry
	 *            the registry
	 * @return the report builder
	 */
	public static ReportBuilder forRegistry(MetricRegistry registry) {
		return new ReportBuilder(registry);
	}

	/**
	 * The Class ReportBuilder.
	 */
	public static class ReportBuilder {

		/** The registry. */
		private final MetricRegistry registry;

		private MetricsFileStorage metricsFileStorage;

		private Supplier<Integer> schedulerDalaySeconds;

		/** The rate unit. */
		private TimeUnit rateUnit;

		/** The duration unit. */
		private TimeUnit durationUnit;

		/** The filter. */
		private MetricFilter filter;

		private String serverHost;

		/**
		 * Instantiates a new report builder.
		 *
		 * @param registry
		 *            the registry
		 */
		private ReportBuilder(MetricRegistry registry) {
			this.registry = registry;
			this.rateUnit = TimeUnit.SECONDS;
			this.durationUnit = TimeUnit.MILLISECONDS;
			this.filter = MetricFilter.ALL;
		}

		public ReportBuilder serverHost(String serverHost) {
			this.serverHost = serverHost;
			return this;
		}

		public ReportBuilder metricsFileStorage(MetricsFileStorage metricsFileStorage) {
			this.metricsFileStorage = metricsFileStorage;
			return this;
		}

		public ReportBuilder schedulerDalaySeconds(Supplier<Integer> schedulerDalaySeconds) {
			this.schedulerDalaySeconds = schedulerDalaySeconds;
			return this;
		}

		/**
		 * Convert rates to.
		 *
		 * @param rateUnit
		 *            the rate unit
		 * @return the report builder
		 */
		public ReportBuilder convertRatesTo(TimeUnit rateUnit) {
			this.rateUnit = rateUnit;
			return this;
		}

		/**
		 * Convert durations to.
		 *
		 * @param durationUnit
		 *            the duration unit
		 * @return the report builder
		 */
		public ReportBuilder convertDurationsTo(TimeUnit durationUnit) {
			this.durationUnit = durationUnit;
			return this;
		}

		/**
		 * Filter.
		 *
		 * @param filter
		 *            the filter
		 * @return the report builder
		 */
		public ReportBuilder filter(MetricFilter filter) {
			this.filter = filter;
			return this;
		}

		/**
		 * Builds the.
		 *
		 * @return the metrics filestorage reporter
		 */
		public MetricsFileStorageReporter build() {
			return new MetricsFileStorageReporter(metricsFileStorage, registry, filter, rateUnit, durationUnit,
					serverHost, schedulerDalaySeconds);
		}
	}

	/**
	 * Instantiates a new metrics influxdb reporter.
	 *
	 * @param registry
	 *            the registry
	 * @param connectionUrl
	 *            the connection url
	 * @param filter
	 *            the filter
	 * @param rateUnit
	 *            the rate unit
	 * @param durationUnit
	 *            the duration unit
	 */
	private MetricsFileStorageReporter(MetricsFileStorage metricsFileStorage, MetricRegistry registry,
			MetricFilter filter, TimeUnit rateUnit, TimeUnit durationUnit, String serverHost,
			Supplier<Integer> schedulerDalaySeconds) {
		super(registry, "filestorage-reporter", filter, rateUnit, durationUnit);
		this.hostname = serverHost;
		this.metricsFileStorage = metricsFileStorage;
		this.schedulerDalaySeconds = schedulerDalaySeconds;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void report(SortedMap<String, Gauge> gauges, SortedMap<String, Counter> counters,
			SortedMap<String, Histogram> histograms, SortedMap<String, Meter> meters, SortedMap<String, Timer> timers) {
		logger.info("In MetricsFileStorageReporter.report");

		// Looping to achieve fixed delay scheduler, because above report method
		// is called with fixed rate schedule
		while (!ShutdownHook.isShutdownFlag) {
			try {
				saveMetricsToFileStorage();
			} catch (Throwable th) {
				logger.error("Error in MetricsFileStorageReporter: Unable to report to lobStorage, forgot data : " + th,
						th);
			} finally {
				Uninterruptibles.sleepUninterruptibly(schedulerDalaySeconds.get(), TimeUnit.SECONDS);
			}
		}
	}

	private void saveMetricsToFileStorage() {
		logger.trace("In MetricsFileStorageReporter.saveMetricsToFileStorage");
		final long timestamp = System.currentTimeMillis();

		try {
			MetricRegistry registry = MetricsUtil.METRICS_REGISTRY;

			JsonObject json = new JsonObject();
			json.addProperty("timestamp", timestamp);
			json.addProperty("serverHost", hostname);

			JsonObject jsonCounters = new JsonObject();
			for (Map.Entry<String, Counter> entry : registry.getCounters().entrySet()) {
				jsonCounters.add(entry.getKey(), buildCounter(entry.getKey(), entry.getValue(), timestamp));
			}
			json.add("counters", jsonCounters);

			JsonObject jsonHistograms = new JsonObject();
			for (Map.Entry<String, Histogram> entry : registry.getHistograms().entrySet()) {
				jsonHistograms.add(entry.getKey(), buildHistogram(entry.getKey(), entry.getValue(), timestamp));
			}
			json.add("histograms", jsonHistograms);

			JsonObject jsonMeters = new JsonObject();
			for (Map.Entry<String, Meter> entry : registry.getMeters().entrySet()) {
				jsonMeters.add(entry.getKey(), buildMeter(entry.getKey(), entry.getValue(), timestamp));
			}
			json.add("meters", jsonMeters);

			JsonObject jsonTimers = new JsonObject();
			for (Map.Entry<String, Timer> entry : registry.getTimers().entrySet()) {
				jsonTimers.add(entry.getKey(), buildTimer(entry.getKey(), entry.getValue(), timestamp));
			}
			json.add("timers", jsonTimers);

			JsonObject jsonGauges = new JsonObject();
			for (Map.Entry<String, Gauge> entry : registry.getGauges().entrySet()) {
				jsonGauges.add(entry.getKey(), buildGauge(entry.getKey(), entry.getValue(), timestamp));
			}
			json.add("gauges", jsonGauges);

			// addNodeStatusInfo(json);

			byte[] metricData = json.toString().getBytes(Charsets.UTF_8);

			Calendar metricTimestamp = Calendar.getInstance();

			metricsFileStorage.saveMetricsData(hostname, metricTimestamp, metricData);
		} catch (Throwable th) {
			logger.error(
					"Error in MetricsFileStorageReporter.saveMetricsToFileStorage: Unable to report to lobStorage, forgot data : "
							+ th,
					th);
		}
	}

	private void addNodeStatusInfo(JsonObject parentJson) {
		// VerifyNodes
		if (ServerStatusMonitor.isMonitored(BioComponentType.VN)) {
			JsonObject jsonObject = new JsonObject();
			jsonObject.add("onlineList",
					GsonSerializer.toJsonArray(ServerStatusMonitor.getOnlineServerIdList(BioComponentType.VN)));
			jsonObject.add("offlineList",
					GsonSerializer.toJsonArray(ServerStatusMonitor.getOfflineServerIdList(BioComponentType.VN)));
			parentJson.add("componentType.VN.NODE_STATUS_INFO", jsonObject);
		}

		// ExtractNodes
		if (ServerStatusMonitor.isMonitored(BioComponentType.EN)) {
			JsonObject jsonObject = new JsonObject();
			jsonObject.add("onlineList",
					GsonSerializer.toJsonArray(ServerStatusMonitor.getOnlineServerIdList(BioComponentType.EN)));
			jsonObject.add("offlineList",
					GsonSerializer.toJsonArray(ServerStatusMonitor.getOfflineServerIdList(BioComponentType.EN)));
			parentJson.add("componentType.EN.NODE_STATUS_INFO", jsonObject);
		}

		// SearchNodes
		if (ServerStatusMonitor.isMonitored(BioComponentType.SN)) {
			JsonObject jsonObject = new JsonObject();
			jsonObject.add("onlineList",
					GsonSerializer.toJsonArray(ServerStatusMonitor.getOnlineServerIdList(BioComponentType.SN)));
			jsonObject.add("offlineList",
					GsonSerializer.toJsonArray(ServerStatusMonitor.getOfflineServerIdList(BioComponentType.SN)));
			parentJson.add("componentType.SN.NODE_STATUS_INFO", jsonObject);
		}

		// SearchBroker
		if (ServerStatusMonitor.isMonitored(BioComponentType.SB)) {
			JsonObject jsonObject = new JsonObject();
			jsonObject.add("onlineList",
					GsonSerializer.toJsonArray(ServerStatusMonitor.getOnlineServerIdList(BioComponentType.SB)));
			jsonObject.add("offlineList",
					GsonSerializer.toJsonArray(ServerStatusMonitor.getOfflineServerIdList(BioComponentType.SB)));
			parentJson.add("componentType.SB.NODE_STATUS_INFO", jsonObject);
		}
	}

	/**
	 * Build timer.
	 *
	 * @param name
	 *            the name
	 * @param timer
	 *            the timer
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private JsonObject buildTimer(String name, Timer timer, long timestamp) throws IOException {
		final Snapshot snapshot = timer.getSnapshot();

		JsonObject json = new JsonObject();
		json.addProperty("count", timer.getCount());
		json.addProperty("max", convertDuration(snapshot.getMax()));
		json.addProperty("mean", convertDuration(snapshot.getMean()));
		json.addProperty("min", convertDuration(snapshot.getMin()));

		json.addProperty("p50", convertDuration(snapshot.getMedian()));
		json.addProperty("p75", convertDuration(snapshot.get75thPercentile()));
		json.addProperty("p95", convertDuration(snapshot.get95thPercentile()));
		json.addProperty("p98", convertDuration(snapshot.get98thPercentile()));
		json.addProperty("p99", convertDuration(snapshot.get99thPercentile()));
		json.addProperty("p999", convertDuration(snapshot.get999thPercentile()));

		json.addProperty("stddev", convertDuration(snapshot.getStdDev()));
		json.addProperty("m15_rate", convertRate(timer.getFifteenMinuteRate()));
		json.addProperty("m1_rate", convertRate(timer.getOneMinuteRate()));
		json.addProperty("m5_rate", convertRate(timer.getFiveMinuteRate()));
		json.addProperty("mean_rate", convertRate(timer.getMeanRate()));
		json.addProperty("duration_units", getDurationUnit());
		json.addProperty("rate_units", "calls/" + getRateUnit());

		return json;
	}

	/**
	 * Report histogram.
	 *
	 * @param name
	 *            the name
	 * @param histogram
	 *            the histogram
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private JsonObject buildHistogram(String name, Histogram histogram, long timestamp) throws IOException {
		final Snapshot snapshot = histogram.getSnapshot();

		JsonObject json = new JsonObject();
		json.addProperty("count", histogram.getCount());
		json.addProperty("max", snapshot.getMax());
		json.addProperty("mean", snapshot.getMean());
		json.addProperty("min", snapshot.getMin());
		json.addProperty("p50", snapshot.getMedian());
		json.addProperty("p75", snapshot.get75thPercentile());
		json.addProperty("p95", snapshot.get95thPercentile());
		json.addProperty("p98", snapshot.get98thPercentile());
		json.addProperty("p99", snapshot.get99thPercentile());
		json.addProperty("p999", snapshot.get999thPercentile());
		json.addProperty("stddev", snapshot.getStdDev());

		return json;
	}

	/**
	 * Build counter.
	 *
	 * @param name
	 *            the name
	 * @param counter
	 *            the counter
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private JsonObject buildCounter(String name, Counter counter, long timestamp) throws IOException {
		JsonObject json = new JsonObject();
		json.addProperty("count", counter.getCount());

		return json;
	}

	/**
	 * Build gauge.
	 *
	 * @param name
	 *            the name
	 * @param gauge
	 *            the gauge
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private JsonObject buildGauge(String name, Gauge<?> gauge, long timestamp) throws IOException {
		JsonObject json = new JsonObject();

		Object value = gauge.getValue();
		if (value instanceof Number) {
			json.addProperty("value", (Number) value);
		} else if (value != null) {
			json.addProperty("value", String.valueOf(value));
		} else {
			json.addProperty("value", 0);
		}

		return json;
	}

	/**
	 * Build meter.
	 *
	 * @param name
	 *            the name
	 * @param meter
	 *            the meter
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private JsonObject buildMeter(String name, Meter meter, long timestamp) throws IOException {
		JsonObject json = new JsonObject();
		json.addProperty("count", meter.getCount());
		json.addProperty("m15_rate", convertRate(meter.getFifteenMinuteRate()));
		json.addProperty("m1_rate", convertRate(meter.getOneMinuteRate()));
		json.addProperty("m5_rate", convertRate(meter.getFiveMinuteRate()));
		json.addProperty("mean_rate", convertRate(meter.getMeanRate()));
		json.addProperty("units", "calls/" + getRateUnit());

		return json;
	}

	/**
	 * Builds the point.
	 *
	 * @param key
	 *            the key
	 * @return the builder
	 */
	private JsonObject buildPoint(String key) {
		JsonObject json = new JsonObject();

		String keyParts[] = key.split("\\.");
		if (keyParts.length % 2 == 0) {
			throw new IllegalArgumentException(
					"Unable to parse metricKey. Invalid metric key: " + key + ", mod: " + (keyParts.length % 2));
		}

		json.addProperty("measurement", keyParts[keyParts.length - 1]);

		for (int i = 0; i < keyParts.length - 1; i += 2) {
			json.addProperty(keyParts[i], keyParts[i + 1]);
		}
		json.addProperty("hostname", hostname);
		return json;
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 * @throws Exception
	 *             the exception
	 */
	public static void main(String args[]) throws Exception {
		String str = "nodeType.VC.nodeName.VC001.JJJ";
		System.out.println(str.split("\\.").length % 2);
		for (String s : str.split("\\.")) {
			System.out.println(s);
		}
	}

}
