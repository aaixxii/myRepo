package com.nec.biomatcher.comp.zmq;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class ZmqConnectionException extends CoreException {

	private static final long serialVersionUID = 1L;

	public ZmqConnectionException(String message, Throwable cause) {
		super(message, cause);
	}

	public ZmqConnectionException(String message) {
		super(message);
	}

	public ZmqConnectionException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

}
