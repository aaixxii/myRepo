package com.nec.biomatcher.comp.template.storage.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class TemplateDataNotFoundException extends CoreException {

	private static final long serialVersionUID = 1L;

	public TemplateDataNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public TemplateDataNotFoundException(String message) {
		super(message);
	}

	public TemplateDataNotFoundException(Throwable cause) {
		super(cause);
	}

}
