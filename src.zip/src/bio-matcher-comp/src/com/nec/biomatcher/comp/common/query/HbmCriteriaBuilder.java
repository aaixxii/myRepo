package com.nec.biomatcher.comp.common.query;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import com.nec.biomatcher.comp.common.query.criteria.BetweenCriteria;
import com.nec.biomatcher.comp.common.query.criteria.CriteriaDto;
import com.nec.biomatcher.comp.common.query.criteria.EqualCriteria;
import com.nec.biomatcher.comp.common.query.criteria.GreaterThanCriteria;
import com.nec.biomatcher.comp.common.query.criteria.ILikeCriteria;
import com.nec.biomatcher.comp.common.query.criteria.InCriteria;
import com.nec.biomatcher.comp.common.query.criteria.InOrNullCriteria;
import com.nec.biomatcher.comp.common.query.criteria.LessThanCriteria;
import com.nec.biomatcher.comp.common.query.criteria.LikeCriteria;
import com.nec.biomatcher.comp.common.query.criteria.NotEqualCriteria;
import com.nec.biomatcher.comp.common.query.criteria.NotInCriteria;
import com.nec.biomatcher.comp.common.query.criteria.NotInOrNullCriteria;
import com.nec.biomatcher.comp.common.query.criteria.NotNullCriteria;
import com.nec.biomatcher.comp.common.query.criteria.NullCriteria;
import com.nec.biomatcher.comp.common.query.criteria.ValueCriteriaDto;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

/**
 * This class is used for building hibernate criteria.
 *
 * @author Mahesh
 */
public class HbmCriteriaBuilder {

	/** The logger. */
	private static Logger logger = Logger.getLogger(HbmCriteriaBuilder.class);

	/** The criteria. */
	private Criteria criteria;

	/** The has crietria. */
	private boolean hasCrietria;

	/** The alias list. */
	private Set<String> aliasList = new HashSet<String>();

	/**
	 * Instantiates a new hbm criteria builder.
	 *
	 * @param criteria
	 *            the criteria
	 */
	public HbmCriteriaBuilder(Criteria criteria) {
		this.criteria = criteria;
	}

	/**
	 * Adds criteria condition.
	 *
	 * @param fieldName
	 *            the field name
	 * @param criteriaDto
	 *            the criteria dto
	 * @param aliasName
	 *            the alias name
	 * @return reference to this HbmCriteriaBuilder instance
	 * @throws DaoException
	 *             the dao exception
	 */
	public HbmCriteriaBuilder addCriteria(String fieldName, CriteriaDto criteriaDto, String aliasName)
			throws DaoException {
		if (criteriaDto != null) {
			if (aliasName != null) {
				if (!aliasList.contains(aliasName)) {
					aliasList.add(aliasName);
					logger.trace("*** aliasName: " + aliasName);
					criteria.createAlias(aliasName, aliasName);
				}
			}
			addCriteria(fieldName, criteriaDto);
		}
		return this;
	}

	/**
	 * Adds criteria condition.
	 *
	 * @param fieldName
	 *            the field name
	 * @param criteriaDto
	 *            the criteria dto
	 * @return reference to this HbmCriteriaBuilder instance
	 * @throws DaoException
	 *             the dao exception
	 */
	public HbmCriteriaBuilder addCriteria(String fieldName, CriteriaDto criteriaDto) throws DaoException {
		if (criteriaDto != null) {
			hasCrietria = true;
			if (criteriaDto instanceof ValueCriteriaDto || criteriaDto instanceof UserTypeCriteria) {

				Object value = getCriteriaValue(fieldName, criteriaDto);
				if (value == null) {
					throw new DaoException("Null value specified in value criteria for field: " + fieldName
							+ ", criteriaDto: " + ReflectionToStringBuilder.toString(criteriaDto));
				} else if (isInstanceOf(EqualCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.eq(fieldName, value));
				} else if (isInstanceOf(NotEqualCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.ne(fieldName, value));
				} else if (isInstanceOf(LikeCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.like(fieldName, value));
				} else if (isInstanceOf(ILikeCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.ilike(fieldName, value));
				} else if (isInstanceOf(InCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.in(fieldName, (Object[]) value));
				} else if (isInstanceOf(InOrNullCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.or(Restrictions.in(fieldName, (Object[]) value),
							Restrictions.isNull(fieldName)));
				} else if (isInstanceOf(NotInCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.not(Restrictions.in(fieldName, (Object[]) value)));
				} else if (isInstanceOf(NotInOrNullCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.or(Restrictions.not(Restrictions.in(fieldName, (Object[]) value)),
							Restrictions.isNull(fieldName)));
				} else if (isInstanceOf(GreaterThanCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.gt(fieldName, value));
				} else if (isInstanceOf(LessThanCriteria.class, criteriaDto)) {
					criteria.add(Restrictions.le(fieldName, value));
				} else {
					throw new DaoException("Unknown value criteria type specified for field: " + fieldName
							+ ", criteriaDto: " + ReflectionToStringBuilder.toString(criteriaDto));
				}
			} else if (criteriaDto instanceof BetweenCriteria) {
				criteria.add(Restrictions.between(fieldName, ((BetweenCriteria) criteriaDto).getFromValue(),
						((BetweenCriteria) criteriaDto).getToValue()));
			} else if (isInstanceOf(NullCriteria.class, criteriaDto)) {
				criteria.add(Restrictions.isNull(fieldName));
			} else if (isInstanceOf(NotNullCriteria.class, criteriaDto)) {
				criteria.add(Restrictions.isNotNull(fieldName));
			} else {
				throw new DaoException("Unknown criteria type specified for field: " + fieldName + ", criteriaDto: "
						+ ReflectionToStringBuilder.toString(criteriaDto));
			}
		}
		return this;
	}

	/**
	 * Gets the criteria.
	 *
	 * @return the criteria
	 */
	public Criteria getCriteria() {
		return criteria;
	}

	/**
	 * Checks if is checks for crietria.
	 *
	 * @return the hasCrietria
	 */
	public boolean isHasCrietria() {
		return hasCrietria;
	}

	/**
	 * Returns true of criteriaDto is instance of specified criteriaClass.
	 *
	 * @param criteriaClass
	 *            the criteria class
	 * @param criteriaDto
	 *            the criteria dto
	 * @return true, if is instance of
	 */
	private boolean isInstanceOf(Class criteriaClass, CriteriaDto criteriaDto) {
		if (criteriaClass.isInstance(criteriaDto)) {
			return true;
		} else if (criteriaDto instanceof UserTypeCriteria) {
			if (criteriaClass.isInstance(((UserTypeCriteria) criteriaDto).getMainCriteria())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Gets the criteria value.
	 *
	 * @param fieldName
	 *            the field name
	 * @param criteriaDto
	 *            the criteria dto
	 * @return the criteria value
	 * @throws DaoException
	 *             the dao exception
	 */
	private Object getCriteriaValue(String fieldName, CriteriaDto criteriaDto) throws DaoException {
		Object value = null;
		if (criteriaDto instanceof ValueCriteriaDto) {
			value = ((ValueCriteriaDto) criteriaDto).getValue();
		} else if (criteriaDto instanceof UserTypeCriteria) {
			value = ((UserTypeCriteria) criteriaDto).getValue();
		} else {
			throw new DaoException("Unknown criteria type specified for field: " + fieldName + ", criteriaDto: "
					+ ReflectionToStringBuilder.toString(criteriaDto));
		}
		return value;
	}
}
