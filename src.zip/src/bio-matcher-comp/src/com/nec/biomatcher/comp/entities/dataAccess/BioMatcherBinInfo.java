package com.nec.biomatcher.comp.entities.dataAccess;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioMatcherBinInfo.
 */
public class BioMatcherBinInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The bin id. */
	private Integer binId;

	/** The template type. */
	private String templateType;

	/** The data priority. */
	private Integer dataPriority = 1;

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public Integer getDataPriority() {
		return dataPriority;
	}

	public void setDataPriority(Integer dataPriority) {
		this.dataPriority = dataPriority;
	}
}
