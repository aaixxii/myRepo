package com.nec.biomatcher.comp.util;

public class JobEntry implements Comparable<JobEntry> {
	private final String jobId;
	private final long createTimestampMilli;
	private int priority;

	public JobEntry(String jobId) {
		this(jobId, 5, System.currentTimeMillis());
	}

	public JobEntry(String jobId, Integer priority) {
		this(jobId, priority, System.currentTimeMillis());
	}

	public JobEntry(String jobId, Integer priority, Long createTimestampMilli) {
		this.jobId = jobId;
		this.priority = (priority == null) ? 5 : Math.max(1, Math.min(10, priority));
		this.createTimestampMilli = createTimestampMilli == null ? System.currentTimeMillis() : createTimestampMilli;
	}

	public void setHighestPriority() {
		priority = 0;
	}

	public void increasePriority() {
		priority = Math.max(0, priority - 1);
	}

	public void decreasePriority() {
		priority = Math.min(10, priority + 1);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj instanceof JobEntry) {
			return jobId.equals(((JobEntry) obj).jobId);
		} else if (obj instanceof String) {
			return jobId.equals((String) obj);
		} else {
			return false;
		}
	}

	@Override
	public int compareTo(JobEntry o) {
		if (this == o) {
			return 0;
		} else if (o == null) {
			return Integer.MAX_VALUE;
		}

		int jobIdCompVal = jobId.compareTo(o.jobId);
		if (jobIdCompVal == 0) {
			return 0;
		}

		// a negative integer, zero, or a positive integer as this object is
		// less than, equal to, or greater than the specified object.
		int comp = Integer.compare(priority, o.priority);
		if (comp != 0) {
			return comp;
		}

		comp = Long.compare(createTimestampMilli, o.createTimestampMilli);
		if (comp != 0) {
			return comp;
		}

		return jobIdCompVal;
	}

	public String getJobId() {
		return jobId;
	}

	public long getCreateTimestampMilli() {
		return createTimestampMilli;
	}

	public int getPriority() {
		return priority;
	}

}
