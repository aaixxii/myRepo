package com.nec.biomatcher.comp.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameter;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.LoggerLevelConfig;

public class BioParameterConfigurator implements InitializingBean {
	private static final Logger logger = Logger.getLogger(LoggerLevelConfig.class);

	private BioParameterService bioParameterService;
	private List<String> bioParameters = new ArrayList<>();

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioParameters(List<String> bioParameters) {
		if (bioParameters != null) {
			this.bioParameters.addAll(bioParameters);
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In BioParameterConfigurator");

		for (String jsonBioParameter : bioParameters) {
			try {
				BioParameter bioParameter = GsonSerializer.fromJson(jsonBioParameter, BioParameter.class);
				BioParameter currentParameter = bioParameterService.getParameter(bioParameter.getName(),
						bioParameter.getScope());
				if (currentParameter == null) {
					String value = bioParameter.getValue();
					if (StringUtils.contains(value, "sys{user.home}")) {
						value = StringUtils.replace(value, "sys{user.home}", System.getProperty("user.home"));
					}
					bioParameterService.saveParameterValue(bioParameter.getName(), bioParameter.getScope(),
							bioParameter.getDataType(), bioParameter.getDescription(), value);
				} else {
					String newDescription = null;
					String newDataType = null;
					if (StringUtils.isBlank(currentParameter.getDescription())) {
						newDescription = bioParameter.getDescription();
					}
					if (StringUtils.isBlank(currentParameter.getDataType())) {
						newDataType = bioParameter.getDataType();
					}

					if (newDescription != null || newDataType != null) {
						bioParameterService.updateParameterDataTypeDescription(bioParameter.getName(),
								bioParameter.getScope(), newDataType, newDescription);
					}
				}
			} catch (Throwable th) {
				logger.error("Error in BioParameterConfigurator for jsonBioParameter: " + jsonBioParameter + " : "
						+ th.getMessage(), th);
			}
		}

		bioParameters.clear();
	}

}
