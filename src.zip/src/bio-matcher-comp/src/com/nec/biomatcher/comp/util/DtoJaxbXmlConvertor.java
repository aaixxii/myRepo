package com.nec.biomatcher.comp.util;

import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.JAXBContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;

import com.nec.biomatcher.core.framework.common.JaxbSerializer;
import com.nec.biomatcher.core.framework.common.exception.ObjectCreationException;
import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.KeyValuePair;

public class DtoJaxbXmlConvertor extends JaxbSerializer {
	private static final Logger logger = Logger.getLogger(DtoJaxbXmlConvertor.class);

	private JAXBContext jaxbContext;
	private Set<Class<?>> classesToBeExcluded = new HashSet<>();

	private static DtoJaxbXmlConvertor dtoJaxbXmlConvertor = null;

	private DtoJaxbXmlConvertor() {
		try {
			ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(
					false);
			provider.addIncludeFilter(new AssignableTypeFilter(Dto.class));

			classesToBeExcluded.add(KeyValuePair.class);

			Set<Class<?>> classesToBeBound = new HashSet<>();// Sets.newHashSet(new
																// Class[]{BioUserInfo.class,
																// BioUserInfoList.class});
			Set<BeanDefinition> components = provider.findCandidateComponents("com.nec");
			for (BeanDefinition component : components) {
				try {
					Class<?> cls = Class.forName(component.getBeanClassName());
					if (classesToBeExcluded.contains(cls)) {
						continue;
					}
					classesToBeBound.add(cls);
				} catch (Throwable th) {
					logger.error("Error in DtoJaxbXmlConvertor while building jaxbContext for class: "
							+ component.getBeanClassName() + " : " + th.getMessage(), th);
				}
			}

			jaxbContext = JAXBContext.newInstance(classesToBeBound.toArray(new Class[0]));
		} catch (Throwable th) {
			throw new ObjectCreationException(
					"Error while creating jaxbContext for DtoJaxbXmlConvertor: " + th.getMessage(), th);
		}
	}

	public static final DtoJaxbXmlConvertor getInstance() {
		if (dtoJaxbXmlConvertor == null) {
			synchronized (DtoJaxbXmlConvertor.class) {
				if (dtoJaxbXmlConvertor == null) {
					dtoJaxbXmlConvertor = new DtoJaxbXmlConvertor();
				}
			}
		}
		return dtoJaxbXmlConvertor;
	}

	@Override
	protected JAXBContext getJAXBContext() {
		return jaxbContext;
	}

	public Set<Class<?>> getClassesToBeExcluded() {
		return classesToBeExcluded;
	}

	public void setClassesToBeExcluded(Set<Class<?>> classesToBeExcluded) {
		this.classesToBeExcluded = classesToBeExcluded;
	}

}
