package com.nec.biomatcher.comp.common.locking;

import java.util.List;
import java.util.concurrent.ExecutionException;

import com.nec.biomatcher.comp.common.locking.dataAccess.BioLockInfo;
import com.nec.biomatcher.comp.common.locking.exception.BioLockingServiceException;

/**
 * This service provides the locking mechanism similar to semaphore across the
 * multiple instances in cluster.
 *
 * @author Mahesh
 * @version 1.0
 * @since 22 June 2012
 * 
 */
public interface BioLockingService {

	/**
	 * This method returns the LockInfo with specified lockKey and lockHost.
	 *
	 * @param lockKey
	 *            the lock key
	 * @return LockInfo
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public BioLockInfo getLockInfo(String lockKey) throws BioLockingServiceException;

	/**
	 * Delete lock information by lock key.
	 *
	 * @param lockKey
	 *            the lock key
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public void deleteLockInfo(String lockKey) throws BioLockingServiceException;

	/**
	 * Delete lock information by lock key suffix that has expired the lock
	 * timeout period.
	 *
	 * @param lockKeySuffix
	 *            the lock key suffix
	 * @param lockTimeoutMilli
	 *            the lock timeout milli
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public void deleteLockInfoByLockKeySuffix(String lockKeySuffix, long lockTimeoutMilli)
			throws BioLockingServiceException;

	/**
	 * This method will try to acquire the lock with specified lockKey. If you
	 * use this method to lock, No one can acquire the lock (including the
	 * locker) until lock is released or expired
	 *
	 * @param lockKey
	 *            the lock key
	 * @param lockTimeoutMilli
	 *            the lock timeout milli
	 * @return true if lock is acquired successfully
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public boolean tryAcquireLock(String lockKey, long lockTimeoutMilli) throws BioLockingServiceException;

	/**
	 * This method releases the lock with specified lockKey.
	 *
	 * @param lockKey
	 *            the lock key
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public void releaseLock(String lockKey) throws BioLockingServiceException;

	/**
	 * This method will try to acquire the lock with specified lockKey and
	 * current host. If you use this method to lock, Other hosts can acquire the
	 * lock only if released by the locking host or lock is expired
	 *
	 * @param lockKey
	 *            the lock key
	 * @param lockTimeoutMilli
	 *            the lock timeout milli
	 * @return true if lock is acquired successfully
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public boolean tryAcquireLockByHost(String lockKey, long lockTimeoutMilli) throws BioLockingServiceException;

	/**
	 * This method releases the lock with specified lockKey and current host.
	 *
	 * @param lockKey
	 *            the lock key
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public void releaseLockByHost(String lockKey) throws BioLockingServiceException;

	/**
	 * Acquire transaction lock.
	 *
	 * @param lockKey
	 *            the lock key
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public void acquireTransactionLock(String lockKey) throws BioLockingServiceException;

	/**
	 * Acquire transaction lock.
	 *
	 * @param lockKey
	 *            the lock key
	 * @param createIfNotExists
	 *            the create if not exists
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public void acquireTransactionLock(String lockKey, boolean createIfNotExists) throws BioLockingServiceException;

	/**
	 * Creates the lock if not exists.
	 *
	 * @param lockKey
	 *            the lock key
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public void createLockIfNotExists(String lockKey) throws BioLockingServiceException;

	public void executeInTransactionLock(String lockKey, Runnable runnable)
			throws BioLockingServiceException, ExecutionException;

	/**
	 * Gets the lock keys with prefix.
	 *
	 * @param prefix
	 *            the prefix
	 * @return the lock keys with prefix
	 * @throws BioLockingServiceException
	 *             the bio locking service exception
	 */
	public List<String> getLockKeysWithPrefix(String prefix) throws BioLockingServiceException;
}
