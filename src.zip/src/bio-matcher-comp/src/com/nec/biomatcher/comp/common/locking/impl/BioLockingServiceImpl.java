package com.nec.biomatcher.comp.common.locking.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.common.locking.BioLockingService;
import com.nec.biomatcher.comp.common.locking.dataAccess.BioLockInfo;
import com.nec.biomatcher.comp.common.locking.dataAccess.BioLockingServiceDao;
import com.nec.biomatcher.comp.common.locking.exception.BioLockingServiceException;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.springSupport.SpringSelfAssignmentMarker;

/**
 * This service provides the locking mechanism similar to semaphore across the
 * multiple instances in cluster.
 *
 * @author Mahesh
 * @version 1.0
 * @since 22 June 2012
 * 
 */
public class BioLockingServiceImpl implements BioLockingService, SpringSelfAssignmentMarker {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioLockingServiceImpl.class);

	/** The Constant DEFAULT_LOCKKEY. */
	private static final String DEFAULT_LOCKKEY = "DEFAULT";

	/** The Constant DEFAULT_LOCKHOST. */
	private static final String DEFAULT_LOCKHOST = "LOCALHOST";

	/** The bio locking service dao. */
	private BioLockingServiceDao bioLockingServiceDao;

	/** The server host. */
	private String serverHost;

	/**
	 * Instantiates a new bio locking service impl.
	 *
	 * @throws UnknownHostException
	 *             the unknown host exception
	 */
	public BioLockingServiceImpl() throws UnknownHostException {
		serverHost = InetAddress.getLocalHost().getHostName().toUpperCase();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nec.asia.baf.comp.locking.LockingService#getLockInfo(java.lang.String
	 * )
	 */
	public BioLockInfo getLockInfo(String lockKey) throws BioLockingServiceException {
		try {
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntity(BioLockInfo.class, lockKey);
			return bioLockInfo;
		} catch (DaoException ex) {
			throw new BioLockingServiceException("Error in getLockInfo: " + ex.getMessage(), ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nec.asia.baf.comp.locking.LockingService#deleteLockInfo(java.lang
	 * .String)
	 */
	public void deleteLockInfo(String lockKey) throws BioLockingServiceException {
		try {
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntity(BioLockInfo.class, lockKey);
			if (bioLockInfo != null)
				bioLockingServiceDao.deleteEntity(bioLockInfo);
		} catch (DaoException ex) {
			throw new BioLockingServiceException("Error in getLockInfo: " + ex.getMessage(), ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nec.asia.baf.comp.locking.LockingService#deleteLockInfo(java.lang
	 * .String)
	 */
	public void deleteLockInfoByLockKeySuffix(String lockKeySuffix, long lockTimeoutMilli)
			throws BioLockingServiceException {
		try {
			bioLockingServiceDao.deleteExpiredLockInfoByLockKeySuffix(lockKeySuffix, lockTimeoutMilli);
		} catch (DaoException ex) {
			throw new BioLockingServiceException("Error in getLockInfo: " + ex.getMessage(), ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nec.asia.baf.comp.locking.LockingService#tryAcquireLock(java.lang
	 * .String, long)
	 */
	public boolean tryAcquireLock(String lockKey, long lockTimeoutMilli) throws BioLockingServiceException {
		try {
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
			if (bioLockInfo != null) {
				if (!StringUtils.equals(bioLockInfo.getLockHost(), DEFAULT_LOCKHOST)) {
					throw new BioLockingServiceException(
							"Same lockKey cannot be used for global lock and lockByHost : currentLockHost: "
									+ bioLockInfo.getLockHost());
				}
				if (bioLockInfo.getLockAcquireMilli() == null
						|| bioLockInfo.getLockAcquireMilli() < (System.currentTimeMillis() - lockTimeoutMilli)) {
					bioLockInfo.setLockAcquireMilli(System.currentTimeMillis());
					bioLockInfo.setLockTimeoutMilli(lockTimeoutMilli);
					bioLockingServiceDao.updateEntity(bioLockInfo);
					return true;
				}
			} else {
				bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, DEFAULT_LOCKKEY);
				bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
				if (bioLockInfo == null) {
					bioLockInfo = new BioLockInfo();
					bioLockInfo.setLockKey(lockKey);
					bioLockInfo.setLockAcquireMilli(System.currentTimeMillis());
					bioLockInfo.setLockTimeoutMilli(lockTimeoutMilli);
					bioLockInfo.setLockHost(DEFAULT_LOCKHOST);
					bioLockingServiceDao.saveEntity(bioLockInfo);
					return true;
				}
			}
			return false;
		} catch (DaoException ex) {
			throw new BioLockingServiceException("Error in tryAcquireLock: " + ex.getMessage(), ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nec.asia.baf.comp.locking.LockingService#releaseLock(java.lang.String
	 * )
	 */
	public void releaseLock(String lockKey) throws BioLockingServiceException {
		try {
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
			if (bioLockInfo != null) {
				bioLockInfo.setLockAcquireMilli(null);
				bioLockInfo.setLockTimeoutMilli(null);
				bioLockingServiceDao.updateEntity(bioLockInfo);
			}
		} catch (DaoException ex) {
			throw new BioLockingServiceException("Error in releaseLock: " + ex.getMessage(), ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nec.asia.baf.comp.locking.LockingService#tryAcquireLockByHost(java
	 * .lang.String, long)
	 */
	public boolean tryAcquireLockByHost(String lockKey, long lockTimeoutMilli) throws BioLockingServiceException {
		try {
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
			if (bioLockInfo != null) {
				if (serverHost.equals(bioLockInfo.getLockHost())) {
					bioLockInfo.setLockAcquireMilli(System.currentTimeMillis());
					bioLockInfo.setLockTimeoutMilli(lockTimeoutMilli);
					bioLockingServiceDao.updateEntity(bioLockInfo);
					return true;
				} else if (bioLockInfo.getLockAcquireMilli() == null
						|| bioLockInfo.getLockAcquireMilli() < (System.currentTimeMillis() - lockTimeoutMilli)) {
					bioLockInfo.setLockHost(serverHost);
					bioLockInfo.setLockAcquireMilli(System.currentTimeMillis());
					bioLockInfo.setLockTimeoutMilli(lockTimeoutMilli);
					bioLockingServiceDao.updateEntity(bioLockInfo);
					return true;
				}
			} else {
				bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, DEFAULT_LOCKKEY); // Just
																								// making
																								// sure
																								// of
																								// real
																								// lock
				bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
				if (bioLockInfo == null) {
					bioLockInfo = new BioLockInfo();
					bioLockInfo.setLockKey(lockKey);
					bioLockInfo.setLockHost(serverHost);
					bioLockInfo.setLockAcquireMilli(System.currentTimeMillis());
					bioLockInfo.setLockTimeoutMilli(lockTimeoutMilli);
					bioLockingServiceDao.saveEntity(bioLockInfo);
					return true;
				}
			}

			return false;
		} catch (DaoException ex) {
			throw new BioLockingServiceException(
					"Error in tryAcquireLockByHost: lockKey: " + lockKey + " : " + ex.getMessage(), ex);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.nec.asia.baf.comp.locking.LockingService#releaseLockByHost(java.lang
	 * .String)
	 */
	public void releaseLockByHost(String lockKey) throws BioLockingServiceException {
		try {
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
			if (bioLockInfo != null && serverHost.equals(bioLockInfo.getLockHost())) {
				bioLockInfo.setLockAcquireMilli(null);
				bioLockInfo.setLockTimeoutMilli(null);
				bioLockingServiceDao.updateEntity(bioLockInfo);
			}
		} catch (DaoException ex) {
			throw new BioLockingServiceException(
					"Error in releaseLockByHost: lockKey: " + lockKey + " : " + ex.getMessage(), ex);
		}
	}

	public void acquireTransactionLock(String lockKey) throws BioLockingServiceException {
		try {
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
			if (bioLockInfo == null) {
				logger.debug("In acquireTransactionLock: BioLockInfo not found with lockKey: " + lockKey);
			}
		} catch (DaoException ex) {
			throw new BioLockingServiceException(
					"Error in acquireTransactionLock: lockKey: " + lockKey + " : " + ex.getMessage(), ex);
		}
	}

	public void acquireTransactionLock(String lockKey, boolean createIfNotExists) throws BioLockingServiceException {
		try {
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
			if (createIfNotExists && bioLockInfo == null) {
				createLockIfNotExists(lockKey);
			}
		} catch (DaoException ex) {
			throw new BioLockingServiceException(
					"Error in acquireTransactionLock: lockKey: " + lockKey + " : " + ex.getMessage(), ex);
		}
	}

	public void createLockIfNotExists(String lockKey) throws BioLockingServiceException {
		try {
			bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, DEFAULT_LOCKKEY);
			BioLockInfo bioLockInfo = bioLockingServiceDao.getEntityForUpdate(BioLockInfo.class, lockKey);
			if (bioLockInfo == null) {
				bioLockInfo = new BioLockInfo();
				bioLockInfo.setLockKey(lockKey);
				bioLockInfo.setLockAcquireMilli(System.currentTimeMillis());
				bioLockInfo.setLockTimeoutMilli(0L);
				bioLockInfo.setLockHost(DEFAULT_LOCKHOST);
				bioLockingServiceDao.saveEntity(bioLockInfo);
			}
		} catch (DaoException ex) {
			throw new BioLockingServiceException("Error in acquireTransactionLock: " + ex.getMessage(), ex);
		}
	}

	public void executeInTransactionLock(String lockKey, Runnable runnable)
			throws BioLockingServiceException, ExecutionException {
		try {
			acquireTransactionLock(lockKey, true);
			runnable.run();
		} catch (BioLockingServiceException ex) {
			throw new BioLockingServiceException("Error in executeInTransactionLock: lockKey: " + lockKey
					+ ", runnable: " + runnable.getClass().getName() + " : " + ex.getMessage(), ex);
		} catch (Throwable th) {
			throw new ExecutionException("Error in executeInTransactionLock: lockKey: " + lockKey + ", runnable: "
					+ runnable.getClass().getName() + " : " + th.getMessage(), th);
		}
	}

	public List<String> getLockKeysWithPrefix(String prefix) throws BioLockingServiceException {
		try {
			return bioLockingServiceDao.getLockKeysWithPrefix(prefix);
		} catch (Exception ex) {
			throw new BioLockingServiceException("Error in getLockKeysWithPrefix: " + ex.getMessage(), ex);
		}
	}

	public void setBioLockingServiceDao(BioLockingServiceDao bioLockingServiceDao) {
		this.bioLockingServiceDao = bioLockingServiceDao;
	}

	public void assignSelf(Object self) throws Exception {
		logger.info("In assignSelf of BioLockingServiceImpl");
		try {
			((BioLockingService) self).tryAcquireLock(DEFAULT_LOCKKEY, 0L);
		} catch (Throwable th) {
			logger.error("Error creating default lock record: " + th.getMessage(), th);
			// Suppress error, It will resolve the issue later during acquiring
			// lock
		}

	}

}
