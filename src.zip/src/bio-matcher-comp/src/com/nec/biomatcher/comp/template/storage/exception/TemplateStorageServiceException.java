package com.nec.biomatcher.comp.template.storage.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class TemplateStorageServiceException.
 */
public class TemplateStorageServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new template storage service exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public TemplateStorageServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new template storage service exception.
	 *
	 * @param message
	 *            the message
	 */
	public TemplateStorageServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new template storage service exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public TemplateStorageServiceException(Throwable cause) {
		super(cause);
	}

}
