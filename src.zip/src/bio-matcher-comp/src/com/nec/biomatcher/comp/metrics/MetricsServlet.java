package com.nec.biomatcher.comp.metrics;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

import org.apache.log4j.Logger;

import com.google.common.base.MoreObjects;

public class MetricsServlet extends com.codahale.metrics.servlets.MetricsServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger logger = Logger.getLogger(MetricsServlet.class);

	private String jsonpParamName;

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);

		jsonpParamName = MoreObjects.firstNonNull(config.getInitParameter("jsonpCallbackParamName"),
				"jsonpCallbackParamName");

		logger.info("In MetricsServlet.init: jsonpParamName: " + jsonpParamName);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String callbackFunction = req.getParameter(jsonpParamName);
		if (callbackFunction != null) {
			addBeforeAndAfterContent(req, resp, callbackFunction + "(", ")");
		} else {
			super.doGet(req, resp);
		}
	}

	public void addBeforeAndAfterContent(HttpServletRequest req, HttpServletResponse resp, String before, String after)
			throws IOException, ServletException {
		logger.info("In MetricsServlet.addBeforeAndAfterContent: before: " + before + ", after: " + after);
		JsonpResponseWrapper wrapper = new JsonpResponseWrapper(resp);
		super.doGet(req, wrapper);
		byte[] jsonpResponse = new StringBuilder().append(before).append(new String(wrapper.getData())).append(after)
				.toString().getBytes();
		resp.setContentLength(jsonpResponse.length);
		OutputStream out = resp.getOutputStream();
		out.write(jsonpResponse);
		out.close();
	}

	private static class JsonpResponseWrapper extends HttpServletResponseWrapper {
		private ByteArrayOutputStream out;
		private int contentLength;
		private String contentType;

		public JsonpResponseWrapper(HttpServletResponse response) {
			super(response);
			out = new ByteArrayOutputStream();
		}

		public byte[] getData() {
			return out.toByteArray();
		}

		public ServletOutputStream getOutputStream() {
			return new ServletOutputStream() {
				private DataOutputStream dos = new DataOutputStream(out);

				public void write(int b) throws IOException {
					dos.write(b);
				}

				public void write(byte[] b) throws IOException {
					dos.write(b);
				}

				public void write(byte[] b, int off, int len) throws IOException {
					dos.write(b, off, len);
				}
			};
		}

		public PrintWriter getWriter() {
			return new PrintWriter(getOutputStream(), true);
		}

		public void setContentLength(int length) {
			this.contentLength = length;
			super.setContentLength(length);
		}

		@SuppressWarnings("unused")
		public int getContentLength() {
			return contentLength;
		}

		public void setContentType(String type) {
			this.contentType = type;
			super.setContentType(type);
		}

		public String getContentType() {
			return contentType;
		}
	}

}
