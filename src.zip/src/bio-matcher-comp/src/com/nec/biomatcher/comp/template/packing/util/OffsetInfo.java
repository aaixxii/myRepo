package com.nec.biomatcher.comp.template.packing.util;

public class OffsetInfo {
	public final int START_POSITION;
	public final int SIZE;

	public OffsetInfo(int startPosition, int size) {
		this.START_POSITION = startPosition;
		this.SIZE = size;
	}
}
