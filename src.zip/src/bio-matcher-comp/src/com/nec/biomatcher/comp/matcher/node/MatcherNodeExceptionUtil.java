package com.nec.biomatcher.comp.matcher.node;

import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.zmq.ZmqClientException;
import com.nec.biomatcher.comp.zmq.ZmqConnectionException;
import com.nec.biomatcher.comp.zmq.ZmqReceiveException;
import com.nec.biomatcher.comp.zmq.ZmqSendException;

public class MatcherNodeExceptionUtil {
	public static final <T extends Throwable> T propogateZmqException(final T th) throws BioMatcherNodeClientException,
			BioMatcherNodeConnectionException, BioMatcherNodeSendException, BioMatcherNodeReceiveException {
		if (th instanceof ZmqClientException) {
			throw new BioMatcherNodeClientException(th);
		} else if (th instanceof ZmqConnectionException) {
			throw new BioMatcherNodeConnectionException(th);
		} else if (th instanceof ZmqSendException) {
			throw new BioMatcherNodeSendException(th);
		} else if (th instanceof ZmqReceiveException) {
			throw new BioMatcherNodeReceiveException(th);
		} else {
			return th;
		}
	}

	public static final <T extends Throwable> T propogateZmqException(String matcherNodeId, final T th)
			throws BioMatcherNodeClientException, BioMatcherNodeConnectionException, BioMatcherNodeSendException,
			BioMatcherNodeReceiveException {
		if (th instanceof ZmqClientException) {
			throw new BioMatcherNodeClientException(
					"Encountered ZmqClientException for matcherNodeId: " + matcherNodeId + " : " + th.getMessage(), th);
		} else if (th instanceof ZmqConnectionException) {
			throw new BioMatcherNodeConnectionException(
					"Encountered ZmqConnectionException for matcherNodeId: " + matcherNodeId + " : " + th.getMessage(),
					th);
		} else if (th instanceof ZmqSendException) {
			throw new BioMatcherNodeSendException(
					"Encountered ZmqSendException for matcherNodeId: " + matcherNodeId + " : " + th.getMessage(), th);
		} else if (th instanceof ZmqReceiveException) {
			throw new BioMatcherNodeReceiveException(
					"Encountered ZmqReceiveException for matcherNodeId: " + matcherNodeId + " : " + th.getMessage(),
					th);
		} else {
			return th;
		}
	}
}
