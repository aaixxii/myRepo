package com.nec.biomatcher.comp.bioevent.util;

import java.util.List;

import org.springframework.beans.factory.InitializingBean;

import com.hazelcast.core.IMap;
import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.bioevent.exception.BiometricEventServiceException;
import com.nec.biomatcher.comp.cluster.ClusterInstance;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.util.ValueChangeNotification;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;

public class BiometricEventBulkQuery implements InitializingBean {
    private BiometricEventService biometricEventService;
    private BioParameterService bioParameterService;
    private ClusterInstance adminClusterInstance;
    
    private IMap<Integer, Integer> biometricEventBulkQuerySegmentIdLockMap;
    private volatile boolean bulkQuerySegmentIdLockFlag=false;
    
    public List<BiometricEventInfo> getBiometricEventInfoListForVersioning(Integer segmentId, int maxRecords) throws BiometricEventServiceException {
        if(bulkQuerySegmentIdLockFlag) {
            biometricEventBulkQuerySegmentIdLockMap.lock(segmentId);
            try {
                return biometricEventService.getBiometricEventInfoListForVersioning(segmentId, maxRecords);
            }
            finally {
                biometricEventBulkQuerySegmentIdLockMap.unlock(segmentId);
            }
        }
        else {
            return biometricEventService.getBiometricEventInfoListForVersioning(segmentId, maxRecords);
        }
        
    }

    public List<BiometricEventInfo> getBiometricEventInfoListBySegmentIdForSync(Integer segmentId, Long afterDataVersion, int maxRecords) throws BiometricEventServiceException {
        if(bulkQuerySegmentIdLockFlag) {
            biometricEventBulkQuerySegmentIdLockMap.lock(segmentId);
            try {
                return biometricEventService.getBiometricEventInfoListBySegmentIdForSync(segmentId, afterDataVersion, maxRecords);
            }
            finally {
                biometricEventBulkQuerySegmentIdLockMap.unlock(segmentId);
            }
        }
        else {
            return biometricEventService.getBiometricEventInfoListBySegmentIdForSync(segmentId, afterDataVersion, maxRecords);
        }
    }

    public List<BiometricEventInfo> getBiometricEventInfoListBySegmentIdForRemoteSync(Integer segmentId, Long afterDataVersion, String siteId, BiometricEventStatus biometricEventStatus, int maxRecords) throws BiometricEventServiceException {
        if(bulkQuerySegmentIdLockFlag) {
            biometricEventBulkQuerySegmentIdLockMap.lock(segmentId);
            try {
                return biometricEventService.getBiometricEventInfoListBySegmentIdForRemoteSync(segmentId, afterDataVersion, siteId, biometricEventStatus, maxRecords);
            }
            finally {
                biometricEventBulkQuerySegmentIdLockMap.unlock(segmentId);
            }
        }
        else {
            return biometricEventService.getBiometricEventInfoListBySegmentIdForRemoteSync(segmentId, afterDataVersion, siteId, biometricEventStatus, maxRecords);
        }
        
    }

    public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentId(Integer segmentId, int maxRecords) throws BiometricEventServiceException {
        if(bulkQuerySegmentIdLockFlag) {
            biometricEventBulkQuerySegmentIdLockMap.lock(segmentId);
            try {
                return biometricEventService.getActiveBiometricEventInfoListBySegmentId(segmentId, maxRecords);
            }
            finally {
                biometricEventBulkQuerySegmentIdLockMap.unlock(segmentId);
            }
        }
        else {
            return biometricEventService.getActiveBiometricEventInfoListBySegmentId(segmentId, maxRecords);
        }
        
    }
    
    public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentId(Integer segmentId, Long afterBiometricId, Long afterDataVersion, int maxRecords) throws BiometricEventServiceException {
        if(bulkQuerySegmentIdLockFlag) {
            biometricEventBulkQuerySegmentIdLockMap.lock(segmentId);
            try {
                return biometricEventService.getActiveBiometricEventInfoListBySegmentId(segmentId, afterBiometricId, afterDataVersion, maxRecords);
            }
            finally {
                biometricEventBulkQuerySegmentIdLockMap.unlock(segmentId);
            }
        }
        else {
            return biometricEventService.getActiveBiometricEventInfoListBySegmentId(segmentId, afterBiometricId, afterDataVersion, maxRecords);
        }
    }

    public List<BiometricEventInfo> getBiometricEventInfoListBySegmentIdVersionRange(Integer segmentId, Long fromDataVersion, Long toDataVersion, BiometricEventPhase phase, int maxRecords) throws BiometricEventServiceException {
        if(bulkQuerySegmentIdLockFlag) {
            biometricEventBulkQuerySegmentIdLockMap.lock(segmentId);
            try {
                return biometricEventService.getBiometricEventInfoListBySegmentIdVersionRange(segmentId, fromDataVersion, toDataVersion, phase, maxRecords);
            }
            finally {
                biometricEventBulkQuerySegmentIdLockMap.unlock(segmentId);
            }
        }
        else {
            return biometricEventService.getBiometricEventInfoListBySegmentIdVersionRange(segmentId, fromDataVersion, toDataVersion, phase, maxRecords);
        }
    }


    
    public void afterPropertiesSet() throws Exception {
        biometricEventBulkQuerySegmentIdLockMap = adminClusterInstance.getMap("BiometricEventBulkQuerySegmentIdLockMap");
        ValueChangeNotification<String> bulkQuerySegmentIdLockFlagVCN = BioParameterService.getValueChangeNotification(bioParameterService, "BULK_QUERY_SEGMENT_ID_LOCK_FLAG", "DEFAULT", "false", value -> bulkQuerySegmentIdLockFlag = Boolean.valueOf(value));
        bulkQuerySegmentIdLockFlagVCN.checkAndNotify();
    }

    public void setBiometricEventService(BiometricEventService biometricEventService) {
        this.biometricEventService = biometricEventService;
    }

    public void setAdminClusterInstance(ClusterInstance adminClusterInstance) {
        this.adminClusterInstance = adminClusterInstance;
    }

    public void setBioParameterService(BioParameterService bioParameterService) {
        this.bioParameterService = bioParameterService;
    }

}
