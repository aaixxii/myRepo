package com.nec.biomatcher.comp.common.query.criteria;

/**
 * @author srinivasarao
 *
 */
public class GreaterThanCriteria extends CriteriaDto implements ValueCriteriaDto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The value. */
	private Object value;

	/**
	 * Instantiates a new equal criteria.
	 */
	public GreaterThanCriteria() {

	}

	/**
	 * Instantiates a new equal criteria.
	 *
	 * @param value
	 *            the value
	 */
	public GreaterThanCriteria(Object value) {
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value
	 *            the value to set
	 */
	public void setValue(Object value) {
		this.value = value;
	}
}