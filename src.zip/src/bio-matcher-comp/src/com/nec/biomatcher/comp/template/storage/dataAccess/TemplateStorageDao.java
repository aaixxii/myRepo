package com.nec.biomatcher.comp.template.storage.dataAccess;

import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

/**
 * The Interface TemplateStorageDao.
 */
public interface TemplateStorageDao extends HibernateDao {
	public int deleteBioTemplateDataInfo(String templateDataId) throws DaoException;
}
