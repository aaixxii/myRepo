package com.nec.biomatcher.comp.entities.dataAccess.types;

/**
 * The Enum BioServerState.
 */
public enum BioServerState {

	/** The active. */
	ACTIVE("Active"),

	/** The disabled. */
	DISABLED("Disabled"),

	/** The standby. */
	STANDBY("Standby");

	/** The description. */
	private final String description;

	/**
	 * Instantiates a new bio server state.
	 *
	 * @param description
	 *            the description
	 */
	BioServerState(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public String toString() {
		return name();
	}

}
