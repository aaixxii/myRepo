package com.nec.biomatcher.comp.manager.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioMatchManagerException.
 */
public class BioMatchManagerException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio match manager exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioMatchManagerException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio match manager exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioMatchManagerException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio match manager exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioMatchManagerException(Throwable cause) {
		super(cause);
	}

}
