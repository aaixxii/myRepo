package com.nec.biomatcher.comp.common.query.criteria;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * This is the base class for criteria.
 *
 * @author Mahesh
 */
public abstract class CriteriaDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

}
