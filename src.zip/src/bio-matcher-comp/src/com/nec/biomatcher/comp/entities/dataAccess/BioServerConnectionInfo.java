package com.nec.biomatcher.comp.entities.dataAccess;

import java.util.Map;

import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioServerConnectionInfo.
 */
public class BioServerConnectionInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The server id. */
	private String serverId;

	/** The component type. */
	private BioComponentType componentType;

	/** The connection type. */
	private BioConnectionType connectionType;

	/** The protocol type. */
	private BioProtocolType protocolType;

	/** The connection url. */
	private String connectionUrl;

	/** The connection properties. */
	private Map<String, String> connectionProperties;

	public String getServerId() {
		return serverId;
	}

	public void setServerId(String serverId) {
		this.serverId = serverId;
	}

	public BioComponentType getComponentType() {
		return componentType;
	}

	public void setComponentType(BioComponentType componentType) {
		this.componentType = componentType;
	}

	public BioConnectionType getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(BioConnectionType connectionType) {
		this.connectionType = connectionType;
	}

	public BioProtocolType getProtocolType() {
		return protocolType;
	}

	public void setProtocolType(BioProtocolType protocolType) {
		this.protocolType = protocolType;
	}

	public String getConnectionUrl() {
		return connectionUrl;
	}

	public void setConnectionUrl(String connectionUrl) {
		this.connectionUrl = connectionUrl;
	}

	public Map<String, String> getConnectionProperties() {
		return connectionProperties;
	}

	public void setConnectionProperties(Map<String, String> connectionProperties) {
		this.connectionProperties = connectionProperties;
	}
}
