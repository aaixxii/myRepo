package com.nec.biomatcher.comp.entities.dataAccess.types;

/**
 * The Enum BioComponentType.
 */
public enum BioComponentType {

	/** The vc. */
	VC("Verification Controller"),

	/** The vn. */
	VN("Verification Node"),

	/** The ec. */
	EC("Extraction Controller"),

	/** The en. */
	EN("Extraction Node"),

	/** The sc. */
	SC("Search Controller"),

	/** The sb. */
	SB("Search Broker"),

	/** The sn. */
	SN("Search Node"),

	TVC("Template Validator Controller"),

	TVN("Template Validator Node"),

	/** The dm. */
	DM("Data Manager"),

	/** The if. */
	IF("Influx Database"),

	CDB("Cassandra Database"),

	RSC("Remote Site Controller");

	/** The description. */
	private final String description;

	/**
	 * Instantiates a new bio component type.
	 *
	 * @param description
	 *            the description
	 */
	BioComponentType(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public String toString() {
		return name();
	}
}
