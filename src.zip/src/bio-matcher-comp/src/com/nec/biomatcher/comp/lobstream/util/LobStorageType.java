package com.nec.biomatcher.comp.lobstream.util;

public enum LobStorageType {
	FILE,
	MSDB,
	CASSANDRA
}
