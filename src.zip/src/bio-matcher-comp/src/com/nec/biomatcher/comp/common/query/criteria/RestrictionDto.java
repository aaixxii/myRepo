package com.nec.biomatcher.comp.common.query.criteria;

/**
 * The Class RestrictionDto.
 *
 * @author Alvin Chua
 */
public class RestrictionDto {

	/** The name. */
	private String name;

	/** The value. */
	private Object value;

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name
	 *            the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value
	 *            the new value
	 */
	public void setValue(Object value) {
		this.value = value;
	}
}
