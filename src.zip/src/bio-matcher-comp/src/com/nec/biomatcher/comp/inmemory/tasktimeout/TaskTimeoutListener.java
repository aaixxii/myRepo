package com.nec.biomatcher.comp.inmemory.tasktimeout;

@FunctionalInterface
public interface TaskTimeoutListener {
	public void notifyTaskTimeout(String jobId);
}
