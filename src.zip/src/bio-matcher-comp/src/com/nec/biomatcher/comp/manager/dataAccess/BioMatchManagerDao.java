package com.nec.biomatcher.comp.manager.dataAccess;

import java.util.Map;

import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

/**
 * The Interface BioMatchManagerDao.
 */
public interface BioMatchManagerDao extends HibernateDao {

	public int updateMatcherSegmentVersion(Integer segmentId, Long segmentVersion) throws DaoException;

	public int updateMatcherNodeSegmentVersion(String matcherNodeId, Map<Integer, Long> segmentIdVersionMap)
			throws DaoException;

	public Map<BiKey<Integer, Integer>, Long> getEventCountByBinIdSegmentId() throws DaoException;

	public Long getMaxMatcherNodeSegmentVersion(Integer segmentId) throws DaoException;
}
