package com.nec.biomatcher.extractor.util;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.model.PatternType;
import com.nec.megha.proto.common.CommonProto.AlgorithmType;
import com.nec.megha.proto.common.CommonProto.CapsuleType;
import com.nec.megha.proto.common.CommonProto.Error;
import com.nec.megha.proto.common.CommonProto.FeatureData;
import com.nec.megha.proto.common.CommonProto.KeyValueGroupHolder;
import com.nec.megha.proto.common.CommonProto.LfmlData;
import com.nec.megha.proto.common.CommonProto.MinutiaData;
import com.nec.megha.proto.common.CommonProto.Status;
import com.nec.megha.proto.common.CommonProto.SubType;
import com.nec.megha.proto.extract.ExtractResponseProto.Capsule;
import com.nec.megha.proto.extract.ExtractResponseProto.ExtractResponse;

public class ExtractProtobufUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testPringProtobufObject() {
		ExtractResponse.Builder extractReponseBuilder = ExtractResponse.newBuilder();
		extractReponseBuilder.setMsgId("extracjob1");
		extractReponseBuilder.setKvGroupHolder(KeyValueGroupHolder.newBuilder().build());
		extractReponseBuilder.setStatus(Status.newBuilder().setSuccess(true).build());
		Capsule.Builder capsuleBuilder = Capsule.newBuilder();
		capsuleBuilder.setCapsuleType(CapsuleType.CAPSULE_TYPE_35);
		String data = "type35TemplateData1234567890abccdefjhijklmnopqrstuvwxyz";
		byte[] type35TemplateData = data.getBytes();
		capsuleBuilder.setCapsuleData(ByteString.copyFrom(type35TemplateData));
		extractReponseBuilder.addCapsule(capsuleBuilder.build());
		 byte[] tempData = extractReponseBuilder.getCapsuleList().get(0).getCapsuleData().toByteArray();
		Assert.assertEquals(data, new String(tempData));
		System.out.println(extractReponseBuilder.toString());
		System.out.println(PatternType.LeftLoop.getValue());		
	}
	
	@Test
	public void testPringJsonMappingString() {
		long jobTimeoutMilli = TimeUnit.SECONDS.toMillis(60);
		ExtractJobRequestDto extractJobRequestDto = new ExtractJobRequestDto();		
		String callbackIp = "192.168.222.128";
		String callbackPort = "5679";
		String callbackUrl = "http://" + callbackIp + ":" + callbackPort;		
		extractJobRequestDto.setCallbackUrl(callbackUrl);				
		extractJobRequestDto.setPriority(10);
		extractJobRequestDto.setJobTimeoutMill(jobTimeoutMilli);
		extractJobRequestDto.setJobMode("live");
		
		ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
		try {
			String jsonInString = mapper.writeValueAsString(extractJobRequestDto);
			Assert.assertNotNull(jsonInString);
			System.out.println(jsonInString);
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}		
	}	

	@Test
	public void testGetExtractJobResult() throws InvalidProtocolBufferException {
		ExtractResponse exResult = createExtractResponse(true);		
		ExtractJobResultDto resultDto = ExtractProtobufUtil.getExtractJobResult(exResult);		
		Assert.assertNotNull(resultDto);
		Assert.assertEquals(1, resultDto.getTemplateInfoList().get(0).getFeatureDataList().size());
		Assert.assertEquals(3, resultDto.getTemplateInfoList().get(0).getFeatureDataList().get(0).getMinutiaDataList().size());	
		Assert.assertEquals(3, resultDto.getTemplateInfoList().get(0).getFeatureDataList().get(0).getLfmlDataList().size());
		Assert.assertEquals("MinutiaDataForTest", new String(resultDto.getTemplateInfoList().get(0).getFeatureDataList().get(0).getMinutiaDataList().get(0).getMinutia().getData()));
		Assert.assertEquals("lfmlDataList", new String(resultDto.getTemplateInfoList().get(0).getFeatureDataList().get(0).getLfmlDataList().get(0).getSkeleton().getData()));
		Assert.assertEquals("R", resultDto.getTemplateInfoList().get(0).getFeatureDataList().get(0).getPrimaryPattern());
		Assert.assertEquals("W", resultDto.getTemplateInfoList().get(0).getFeatureDataList().get(0).getSecondaryPattern());
		ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
		try {
			String jsonString = mapper.writeValueAsString(resultDto);			
			System.out.println(jsonString);			
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetExtractJobResult_no_featureData() throws InvalidProtocolBufferException {
		ExtractResponse exResult = createExtractResponse(false);		
		ExtractJobResultDto resultDto = ExtractProtobufUtil.getExtractJobResult(exResult);		
		Assert.assertNotNull(resultDto);
		Assert.assertEquals(0, resultDto.getTemplateInfoList().get(0).getFeatureDataList().size());		
		ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
		try {
			String jsonString = mapper.writeValueAsString(resultDto);			
			System.out.println(jsonString);			
		} catch (JsonProcessingException e) {			
			e.printStackTrace();
		}
	}
	
	private ExtractResponse createExtractResponse(boolean haveFeatureData) {
		String jobId = "10000";
		CapsuleType capsuleType = CapsuleType.CAPSULE_TYPE_35;
		String jobMode = "live";
		ExtractResponse exRespose = buildExtractResponse(jobId, capsuleType, jobMode, haveFeatureData);
		return exRespose;
		
	}
	
	private ExtractResponse buildExtractResponse(String jobId, CapsuleType capsuleType, String jobMode, boolean haveFeatureData) {
		ExtractResponse.Builder extractReponseBuilder = ExtractResponse.newBuilder();
		extractReponseBuilder.setMsgId(jobId);

		extractReponseBuilder.setKvGroupHolder(KeyValueGroupHolder.newBuilder().build());

		if (jobMode != null && jobMode.startsWith("dummy-failure")) {
			Error error = Error.newBuilder().setCode(1001).setMsg("dummy-failure Error from simulator").build();
			extractReponseBuilder.setStatus(Status.newBuilder().setSuccess(false).addError(error).build());
		} else {
			extractReponseBuilder.setStatus(Status.newBuilder().setSuccess(true).build());

			 Capsule.Builder capsuleBuilder = Capsule.newBuilder();
			capsuleBuilder.setCapsuleType(capsuleType);
			 byte[] type35TemplateData = "type35TemplateData1234567890abccdefjhijklmnopqrstuvwxyz".getBytes();

			if (CapsuleType.CAPSULE_TYPE_35.equals(capsuleType)) {
				capsuleBuilder.setCapsuleData(ByteString.copyFrom(type35TemplateData));	
				if (haveFeatureData) {
					final List<FeatureData> dataList = buildFeatureData(CapsuleType.CAPSULE_TYPE_35);
					capsuleBuilder.addAllFeature(dataList);	
				}			
							
			}			
			extractReponseBuilder.addCapsule(capsuleBuilder.build());
		}
		return extractReponseBuilder.build();
	}	
	
	private static final List<FeatureData> buildFeatureData(CapsuleType capsuleType) {	
		final List<FeatureData> FeatureDataList = new ArrayList<>();
		final FeatureData.Builder build = FeatureData.newBuilder();
		build.setAlgType(AlgorithmType.AlgFingerCML);
		build.setSubType(SubType.SUB_TYPE_PLANTAR_LMIDDLE_TOE);
		build.setKvGroupHolder(KeyValueGroupHolder.newBuilder().build());
		build.setData(ByteString.copyFrom("FeatureDataForTest".getBytes()));
		build.setPrimaryPattern("R");
		build.setSecondaryPattern("W");
		final List<MinutiaData> minutiaDataList = buildMinutiaDataList(3);
		build.addAllMinutiaData(minutiaDataList);
		
        final List<LfmlData> lfmlDataList = buildLfmlDataList(3);
        build.addAllLfmlData(lfmlDataList);		
		
		System.out.println(build.toString());
		FeatureDataList.add(build.build());
		return FeatureDataList;		
	}
	
	private static final List<MinutiaData> buildMinutiaDataList(int count) {	
		List<MinutiaData> minutiaDataList = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			MinutiaData.Builder md = MinutiaData.newBuilder();
			com.nec.megha.proto.common.CommonProto.Minutia.Builder mt = com.nec.megha.proto.common.CommonProto.Minutia.newBuilder();
			mt.setAlgType(AlgorithmType.AlgFingerCML);
			mt.setData(ByteString.copyFrom("MinutiaDataForTest".getBytes()));
			md.setIndex(i);
			md.setMinutia(mt.build());	

			minutiaDataList.add(md.build());
		}
		return minutiaDataList;
	}
	
    private static final List<LfmlData> buildLfmlDataList(int count) {    
        List<LfmlData> lfmlDataList = new ArrayList<>();
        for (int i = 0; i < count; i++) {           
            com.nec.megha.proto.common.CommonProto.LfmlData.Builder lfmlData = com.nec.megha.proto.common.CommonProto.LfmlData.newBuilder(); 
            com.nec.megha.proto.common.CommonProto.Minutia.Builder mt = com.nec.megha.proto.common.CommonProto.Minutia.newBuilder();
            mt.setAlgType(AlgorithmType.AlgFingerCML);
            mt.setData(ByteString.copyFrom("MinutiaDataForTest".getBytes()));
            lfmlData.setIndex(i);
            lfmlData.setMinutia(mt.build()); 
            com.nec.megha.proto.common.CommonProto.Skeleton.Builder skeleton = com.nec.megha.proto.common.CommonProto.Skeleton.newBuilder();
            skeleton.setAlgType(AlgorithmType.AlgFingerLFML);
            skeleton.setData(ByteString.copyFrom("lfmlDataList".getBytes()));
            lfmlData.setSkeleton(skeleton.build());
            lfmlDataList.add(lfmlData.build());
        }
        return lfmlDataList;
    }   	
}
