package com.nec.biomatcher.extractor.queueing;

import java.util.concurrent.DelayQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

/**
 * The Class ExtractJobHouseKeepingTask.
 */
public class ExtractJobHouseKeepingTask implements Runnable {
	private static final Logger logger = Logger.getLogger(ExtractJobHouseKeepingTask.class);

	private ExtractionJobQueueHelper extractionJobQueueHelper;
	private BioParameterService bioParameterService;

	private DelayQueue<DelayedItem<String>> extractJobQueueHousekeepingQueue;

	private boolean isInitialized = false;

	/**
	 * Instantiates a new extract job house keeping task.
	 *
	 * @param extractJobQueueHousekeepingQueue
	 *            the extract job queue housekeeping queue
	 */
	public ExtractJobHouseKeepingTask(DelayQueue<DelayedItem<String>> extractJobQueueHousekeepingQueue,
			ExtractionJobQueueHelper extractionJobQueueHelper, BioParameterService bioParameterService) {
		this.extractJobQueueHousekeepingQueue = extractJobQueueHousekeepingQueue;
		this.extractionJobQueueHelper = extractionJobQueueHelper;
		this.bioParameterService = bioParameterService;
	}

	@Override
	public void run() {
		Thread.currentThread().setName("EXTRACT_JOB_HOUSEKEEPING_TASK_" + Thread.currentThread().getId());

		logger.info("In ExtractJobHouseKeepingTask.run");

		while (!ShutdownHook.isShutdownFlag) {
			try {
				if (!isInitialized) {
					init();
				}

				DelayedItem<String> delayedItem = null;
				while ((delayedItem = extractJobQueueHousekeepingQueue.poll()) != null) {
					String extractJobId = delayedItem.getItem();
					NDC.clear();
					NDC.push("EX_JOBID#" + extractJobId);
					try {
						extractionJobQueueHelper.deleteExtractionJob(extractJobId);
					} catch (Throwable th) {
						logger.error("Error in ExtractJobHouseKeepingTask for extractJobId: " + extractJobId + " : "
								+ th.getMessage(), th);
					}
				}

				long extractJobRetentionPeriodMilli = bioParameterService.getParameterValue(
						"EXTRACT_JOB_RETENTION_PERIOD_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(30));
				Uninterruptibles.sleepUninterruptibly(extractJobRetentionPeriodMilli, TimeUnit.MILLISECONDS);

			} catch (Throwable th) {
				logger.error("Error in ExtractJobHouseKeepingTask: " + th.getMessage(), th);
				Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
			}
		}
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		extractionJobQueueHelper = SpringServiceManager.getBean("extractionJobQueueHelper");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");

		isInitialized = true;
	}

}
