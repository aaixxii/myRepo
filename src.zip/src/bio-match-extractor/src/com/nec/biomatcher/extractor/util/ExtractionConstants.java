package com.nec.biomatcher.extractor.util;

/**
 * The Class ExtractionConstants.
 */
public class ExtractionConstants {

	/** The Constant ERROR_CODE_GENERAL. */
	public static final String ERROR_CODE_GENERAL = "EC001";

	/** The Constant ERROR_CODE_JOB_EXECUTION. */
	public static final String ERROR_CODE_JOB_EXECUTION = "EC002";

	/** The Constant ERROR_CODE_JOB_TIMEOUT. */
	public static final String ERROR_CODE_JOB_TIMEOUT = "EC003";

	/** The Constant ERROR_CODE_REJECTED. */
	public static final String ERROR_CODE_REJECTED = "EC004";

	/** The Constant ERROR_CODE_LOBSTREAM_ACCESS. */
	public static final String ERROR_CODE_LOBSTREAM_ACCESS = "EC005";

	/** The Constant ERROR_CODE_SERIALIZATION. */
	public static final String ERROR_CODE_SERIALIZATION = "EC006";

	/** The Constant ERROR_CODE_EXTRACT_NODE_ERROR. */
	public static final String ERROR_CODE_EXTRACT_NODE_ERROR = "EC007";

}
