package com.nec.biomatcher.extractor.util;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.NDC;

import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobType;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;

public class ExtractJobInfo {
	private String extractJobId;
	private long jobTimeoutMill = -1;
	private long createTimestampMilli;
	private long assignmentTimestampMilli = -1;
	private long submitTimestampMilli = -1;
	private long jobCompletedTimestampMilli = -1;
	private String callbackUrl;
	private String assignedExtractNodeId;
	private ExtractJobRequestDto jobRequestDto;
	private volatile boolean jobCompletedFlag = false;
	private boolean functionSlotAcquiredFlag;
	private Integer priority;

	public ExtractJobInfo(String extractJobId, String callbackUrl, long jobTimeoutMill) {
		this.extractJobId = extractJobId;
		this.callbackUrl = callbackUrl;
		this.jobTimeoutMill = jobTimeoutMill;
		this.createTimestampMilli = System.currentTimeMillis();
	}

	public ExtractJobInfo(String extractJobId, ExtractJobRequestDto jobRequestDto) {
		this.extractJobId = extractJobId;
		this.jobRequestDto = jobRequestDto;
		this.callbackUrl = jobRequestDto.getCallbackUrl();
		this.createTimestampMilli = System.currentTimeMillis();
	}

	public void assignExtractNodeId(String extractNodeId) {
		assignedExtractNodeId = extractNodeId;
		assignmentTimestampMilli = System.currentTimeMillis();
	}

	public synchronized void notifyJobCompleted(JobSlotClusterService extractClusterService) {
		NDC.push(extractJobId);
		try {
			if (!jobCompletedFlag) {
				jobCompletedFlag = true;
				jobCompletedTimestampMilli = System.currentTimeMillis();

				if (assignedExtractNodeId != null) {
					extractClusterService.releaseJobSlot(assignedExtractNodeId);
					MetricsUtil.time(BioComponentType.EN, assignedExtractNodeId, "EN_JOB_TIME_TAKEN",
							getExtractNodeTimeTakenMilli(), TimeUnit.MILLISECONDS);
				}
			}
		} finally {
			NDC.pop();
		}
	}

	public String getExtractJobId() {
		return extractJobId;
	}

	public void setExtractJobId(String extractJobId) {
		this.extractJobId = extractJobId;
	}

	public long getSubmitTimestampMilli() {
		return submitTimestampMilli;
	}

	public void setSubmitTimestampMilli(long submitTimestampMilli) {
		this.submitTimestampMilli = submitTimestampMilli;
	}

	public long getJobCompletedTimestampMilli() {
		return jobCompletedTimestampMilli;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public ExtractJobRequestDto getJobRequestDto() {
		return jobRequestDto;
	}

	public void setJobRequestDto(ExtractJobRequestDto jobRequestDto) {
		this.jobRequestDto = jobRequestDto;
	}

	public long getCreateTimestampMilli() {
		return createTimestampMilli;
	}

	public void setCreateTimestampMilli(long createTimestampMilli) {
		this.createTimestampMilli = createTimestampMilli;
	}

	public long getDelayFromCreateDateTime() {
		return System.currentTimeMillis() - createTimestampMilli;
	}

	public long getAssignmentDelayMilli() {
		if (assignmentTimestampMilli == -1L) {
			return 0;
		} else {
			return assignmentTimestampMilli - createTimestampMilli;
		}
	}

	public long getSubmitTimeTakenMilli() {
		if (assignmentTimestampMilli == -1L || submitTimestampMilli == -1L) {
			return 0;
		} else {
			return submitTimestampMilli - assignmentTimestampMilli;
		}
	}

	public long getExtractNodeTimeTakenMilli() {
		if (submitTimestampMilli == -1L || jobCompletedTimestampMilli == -1L) {
			return 0;
		} else {
			return jobCompletedTimestampMilli - submitTimestampMilli;
		}
	}

	public long getAssignmentTimestampMilli() {
		return assignmentTimestampMilli;
	}

	public boolean getJobCompletedFlag() {
		return jobCompletedFlag;
	}

	public String getAssignedExtractNodeId() {
		return assignedExtractNodeId;
	}

	public long getJobTimeoutMill() {
		return jobTimeoutMill;
	}

	public void markFunctionSlotAcquired() {
		this.functionSlotAcquiredFlag = true;
	}

	public synchronized void releaseFunctionSlot(MatcherFunctionControlUtil matcherFunctionControlUtil) {
		if (functionSlotAcquiredFlag) {
			matcherFunctionControlUtil.releaseFunctionSlot(BioMatcherJobType.EXTRACT.name());
			functionSlotAcquiredFlag = false;
		}
	}

	public boolean isFunctionSlotAcquiredFlag() {
		return functionSlotAcquiredFlag;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	
}
