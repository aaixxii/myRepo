package com.nec.biomatcher.extractor.service;

import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.extractor.service.exception.BioExtractionTimeoutException;
import com.nec.biomatcher.extractor.util.ExtractJobInfo;

/**
 * The Interface BioExtractionService.
 */
public interface BioExtractionService {

	public String getExtractionControllerId();

	public JobSlotClusterService getExtractClusterService();

	public void submitExtractionJob(String extractJobId, ExtractJobInfo extractJobInfo)
			throws BioMatcherNodeClientException, BioMatcherNodeConnectionException, BioMatcherNodeSendException,
			BioMatcherNodeReceiveException, BioExtractionTimeoutException;

	public void notifyExtractJobCanceling(String msg);
}
