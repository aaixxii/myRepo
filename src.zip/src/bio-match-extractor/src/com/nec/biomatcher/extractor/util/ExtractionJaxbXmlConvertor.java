package com.nec.biomatcher.extractor.util;

import javax.xml.bind.JAXBContext;

import com.nec.biomatcher.core.framework.common.JaxbSerializer;
import com.nec.biomatcher.core.framework.common.exception.ObjectCreationException;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobResultPayload;

/**
 * The Class ExtractionJaxbXmlConvertor.
 */
public class ExtractionJaxbXmlConvertor extends JaxbSerializer {

	/** The jaxb context. */
	private static volatile JAXBContext jaxbContext;

	@Override
	protected JAXBContext getJAXBContext() {
		if (jaxbContext == null) {
			synchronized (ExtractionJaxbXmlConvertor.class) {
				if (jaxbContext == null) {
					try {
						jaxbContext = JAXBContext.newInstance(ExtractJobRequestDto.class, ExtractJobResultDto.class,
								BioMatcherJobRequestPayload.class, BioMatcherJobResultPayload.class);
					} catch (Throwable th) {
						throw new ObjectCreationException(
								"Error while creating jaxb context for ExtractionJaxbXmlConvertor: " + th.getMessage(),
								th);
					}
				}
			}
		}
		return jaxbContext;
	}

}
