#!/bin/sh -x

# ----------------------------------------------------------------------
# Checking   paramters  all are correctly!
# 1. xm_release_version
# 2. megha_developing_version 
# exsample : ./meghaRelease.sh 1.2.0 1.2.0 kallithea_project_name
# ----------------------------------------------------------------------

#check zip file is changed or not
function checkZipContentDiff(){
	if [ !$1 -o !$2 ]; then		
		 return 1
	fi
    local zip_1=$1
    local zip_2=$2
    mkdir -p tmp/$zip_1 tmp/$zip_2
    unzip -o -d tmp/$zip_1 $zip_1 > /dev/null
    unzip -o -d tmp/$zip_2 $zip_2 > /dev/null
    local checkNum=`diff -r tmp/$zip_1 tmp/$zip_2|wc -l`
    rm -rf tmp
    return $checkNum
}

# Begin
# CHECK Args of meghaRelease()
if test  $# != 3 ; then
	echo Usage : ./meghaRelease.sh  xm_release_version  megha_developing_version kallithea_project_name
	exit
fi


RELEASE_VER=$1
DVP_VER=$2
KALITH_PJ_NAME=$3

#Copy mehga db script and rpm to shipment

COPY_TO_DIR=http://dev01a/shipment/branches/Release/AIM-XM-GLOBAL-$RELEASE_VER/AIM-XM-GLOBAL-$RELEASE_VER-PKG

MEGHA_DB_SCRIPT_NAME=database.zip  
MEGHA_RPM_NAME=aim-xm-global-megha-$DVP_VER-0.x86_64.rpm

                       
count=0
SVN_USER=xia
SVN_PWD=xia

if [ -d ./release ]; then
sudo rm -rf ./release
fi

mkdir release
cd release

svn ls --username $SVN_USER --password $SVN_PWD $COPY_TO_DIR > /dev/null
if test $? = 1 ; then
	svn mkdir --username $SVN_USER --password $SVN_PWD --parents --message "Directory Created By $SVN_USER" $COPY_TO_DIR
	svn co --username $SVN_USER --password $SVN_PWD $COPY_TO_DIR
	cp -p -f ../$KALITH_PJ_NAME/src/bio-matcher-module/target/$MEGHA_DB_SCRIPT_NAME AIM-XM-GLOBAL-$RELEASE_VER-PKG/
    cp -p -f ../$KALITH_PJ_NAME/src/bio-matcher-module/target/rpm/aim-xm-global-megha/RPMS/x86_64/$MEGHA_RPM_NAME AIM-XM-GLOBAL-$RELEASE_VER-PKG/
    cd  AIM-XM-GLOBAL-$RELEASE_VER-PKG
   svn add *
   svn commit --username $SVN_USER --password $SVN_PWD --message "Update By $SVN_USER"   
else
	svn co --username $SVN_USER --password $SVN_PWD $COPY_TO_DIR
		cp -p -f ../$KALITH_PJ_NAME/src/bio-matcher-module/target/$MEGHA_DB_SCRIPT_NAME AIM-XM-GLOBAL-$RELEASE_VER-PKG/
        cp -p -f ../$KALITH_PJ_NAME/src/bio-matcher-module/target/rpm/aim-xm-global-megha/RPMS/x86_64/$MEGHA_RPM_NAME AIM-XM-GLOBAL-$RELEASE_VER-PKG/
        cd  AIM-XM-GLOBAL-$RELEASE_VER-PKG
        svn up --username $SVN_USER --password $SVN_PWD --depth=files ./*         
fi

cd ..
sudo rm -rf release

echo "Completed ......Done!"