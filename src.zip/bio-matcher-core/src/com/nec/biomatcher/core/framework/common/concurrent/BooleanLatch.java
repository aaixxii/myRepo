package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Map;
import java.util.Observable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Striped;

/**
 * The Class BooleanLatch.
 */
public class BooleanLatch extends Observable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BooleanLatch.class);

	/** The Constant booleanLatchMap. */
	private static final Map<String, BooleanLatch> booleanLatchMap = new ConcurrentHashMap<String, BooleanLatch>();

	/** The Constant TRUE_INSTANCE. */
	public static final BooleanLatch TRUE_INSTANCE = new BooleanLatch("TRUE_INSTANCE", true) {
		public void setFlag(boolean flag) {
		}
	};

	/** The Constant FALSE_INSTANCE. */
	public static final BooleanLatch FALSE_INSTANCE = new BooleanLatch("FALSE_INSTANCE", false) {
		public void setFlag(boolean flag) {
		}
	};

	/** The Constant stripedLock. */
	private static final Striped<Lock> stripedLock = Striped.lock(10);

	/** The lock. */
	private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

	/** The read lock. */
	private final Lock readLock = lock.readLock();

	/** The write lock. */
	private final Lock writeLock = lock.writeLock();

	/** The true condition. */
	private final Condition trueCondition = writeLock.newCondition();

	/** The false condition. */
	private final Condition falseCondition = writeLock.newCondition();

	/** The last true timestamp milli. */
	private long lastTrueTimestampMilli;

	/** The last false timestamp milli. */
	private long lastFalseTimestampMilli;

	/** The name. */
	private final String name;

	/** The flag. */
	private boolean flag = false;

	/**
	 * Instantiates a new boolean latch.
	 *
	 * @param name
	 *            the name
	 * @param flag
	 *            the flag
	 */
	BooleanLatch(String name, boolean flag) {
		this.name = name;
		this.flag = flag;
		booleanLatchMap.put(name, this);
		logger.info("Initialized BooleanLatch: " + name + ", flag:" + flag);

		setTimestamp(flag);
	}

	public void setFlag(boolean flag) {
		writeLock.lock();

		boolean isChanged = false;
		try {
			if (this.flag != flag) {
				isChanged = true;
				this.flag = flag;
				setTimestamp(flag);

				if (flag) {
					trueCondition.signalAll();
				} else {
					falseCondition.signalAll();
				}
			}
		} finally {
			writeLock.unlock();
		}

		if (isChanged) {
			notifyObservers();
		}
	}

	public final boolean getFlag() {
		readLock.lock();
		try {
			return flag;
		} finally {
			readLock.unlock();
		}
	}

	/**
	 * Wait for true.
	 *
	 * @return true, if successful
	 */
	public final boolean waitForTrue() {
		readLock.lock();
		try {
			if (flag)
				return flag;
		} finally {
			readLock.unlock();
		}

		writeLock.lock();
		try {
			if (!flag) {
				trueCondition.awaitUninterruptibly();
			}
			return flag;
		} finally {
			writeLock.unlock();
		}
	}

	/**
	 * Wait for true.
	 *
	 * @param time
	 *            the time
	 * @param timeUnit
	 *            the time unit
	 * @return true, if successful
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public final boolean waitForTrue(long time, TimeUnit timeUnit) throws InterruptedException {
		readLock.lock();
		try {
			if (flag)
				return flag;
		} finally {
			readLock.unlock();
		}

		writeLock.lock();
		try {
			if (!flag) {
				trueCondition.await(time, timeUnit);
			}
			return flag;
		} finally {
			writeLock.unlock();
		}
	}

	/**
	 * Wait for false.
	 *
	 * @return false, if successful
	 */
	public final boolean waitForFalse() {
		readLock.lock();
		try {
			if (!flag)
				return flag;
		} finally {
			readLock.unlock();
		}

		writeLock.lock();
		try {
			if (flag) {
				falseCondition.awaitUninterruptibly();
			}
			return flag;
		} finally {
			writeLock.unlock();
		}
	}

	/**
	 * Wait for false.
	 *
	 * @param time
	 *            the time
	 * @param timeUnit
	 *            the time unit
	 * @return false, if successful
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public final boolean waitForFalse(long time, TimeUnit timeUnit) throws InterruptedException {
		readLock.lock();
		try {
			if (!flag)
				return flag;
		} finally {
			readLock.unlock();
		}

		writeLock.lock();
		try {
			if (flag) {
				falseCondition.await(time, timeUnit);
			}
			return flag;
		} finally {
			writeLock.unlock();
		}
	}

	private final void setTimestamp(boolean flag) {
		if (flag) {
			lastTrueTimestampMilli = System.currentTimeMillis();
		} else {
			lastFalseTimestampMilli = System.currentTimeMillis();
		}
	}

	/**
	 * Gets the single instance of BooleanLatch.
	 *
	 * @param booleanLatchName
	 *            the boolean latch name
	 * @return single instance of BooleanLatch
	 */
	public static BooleanLatch getInstance(String booleanLatchName) {
		BooleanLatch booleanLatch = booleanLatchMap.get(booleanLatchName);
		if (booleanLatch == null) {
			stripedLock.get(booleanLatchName).lock();
			try {
				booleanLatch = booleanLatchMap.get(booleanLatchName);
				if (booleanLatch == null) {
					booleanLatch = new BooleanLatch(booleanLatchName, false);
				}
			} finally {
				stripedLock.get(booleanLatchName).unlock();
			}
		}

		return booleanLatch;
	}

	/**
	 * Gets the single instance of BooleanLatch.
	 *
	 * @param booleanLatchName
	 *            the boolean latch name
	 * @param defaultFlag
	 *            the default flag
	 * @return single instance of BooleanLatch
	 */
	public static BooleanLatch getInstance(String booleanLatchName, boolean defaultFlag) {
		BooleanLatch booleanLatch = booleanLatchMap.get(booleanLatchName);
		if (booleanLatch == null) {
			stripedLock.get(booleanLatchName).lock();
			try {
				booleanLatch = booleanLatchMap.get(booleanLatchName);
				if (booleanLatch == null) {
					booleanLatch = new BooleanLatch(booleanLatchName, defaultFlag);
				}
			} finally {
				stripedLock.get(booleanLatchName).unlock();
			}
		}

		return booleanLatch;
	}

	public long getLastTrueTimestampMilli() {
		return lastTrueTimestampMilli;
	}

	public long getLastFalseTimestampMilli() {
		return lastFalseTimestampMilli;
	}

	public String getName() {
		return name;
	}

}
