package com.nec.biomatcher.core.framework.web.filter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class ContentTypeFilter implements Filter {

	private static Logger _logger = Logger.getLogger(ContentTypeFilter.class.getName());

	private FilterConfig filterConfig;

	private String contentType;

	public ContentTypeFilter() {
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;

		contentType = filterConfig.getInitParameter("contentType");
	}

	public void destroy() {
		filterConfig = null;
		contentType = null;
	}

	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws java.io.IOException, javax.servlet.ServletException {
		HttpServletRequest req = (HttpServletRequest) servletRequest;

		_logger.info("Setting contentType :" + contentType + " for resource contextPath: " + req.getContextPath()
				+ ", requestUrl: " + req.getRequestURL());
		servletResponse.setContentType(contentType); // ("text/html;
														// charset=UTF-8");
		filterChain.doFilter(servletRequest, servletResponse);
		servletResponse.setContentType(contentType); // ("text/html;
														// charset=UTF-8");
	}

	/**
	 * Gets the filter config.
	 *
	 * @return the filter config
	 */
	public FilterConfig getFilterConfig() {
		return filterConfig;
	}

	/**
	 * Sets the filter config.
	 *
	 * @param cfg
	 *            the new filter config
	 */
	public void setFilterConfig(FilterConfig cfg) {
		filterConfig = cfg;
	}

}
