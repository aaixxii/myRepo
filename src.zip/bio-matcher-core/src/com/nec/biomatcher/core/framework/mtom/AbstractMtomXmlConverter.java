package com.nec.biomatcher.core.framework.mtom;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

/**
 * This class is responsible for Serializing the file and also responsible for
 * Deserializing the object and unmarshal the same.
 *
 * @author yogananda.nbec 1.
 * 
 *         Modification History:
 * 
 *         25 Jun 2012(Mahesh): Refactored the class name to
 *         AbstractMessagePayloadXmlConverter from JaxbXmlConvertor.
 * 
 *         26 June 2012 (Mahesh): Modified the class name from JAXBXmlConvertor
 *         to AbstractMessagePayloadXmlConverter.
 * 
 *         14 May 2013 (Mahesh): Modified to handle incomplete message.
 * 
 */
public abstract class AbstractMtomXmlConverter {

	/**
	 * Gets the jAXB context.
	 * 
	 * @return the jAXB context
	 */
	public abstract JAXBContext getJAXBContext();

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(AbstractMtomXmlConverter.class);

	/**
	 * Instantiates a new abstract message payload xml converter.
	 */
	public AbstractMtomXmlConverter() {
		super();
	}

	/**
	 * This class responsible for serializing the object. This class also Writes
	 * the message in the following format:
	 * [xml_length][xml][attach1_length][attach1]...[attachN_length][attachN]
	 *
	 * @param <T>
	 *            the generic type
	 * @param object
	 *            the object
	 * @return the byte[]
	 * @throws MtomXmlConvertorException
	 *             the jaxb xml convertor exception
	 */
	public <T> byte[] marshal(T object) throws MtomXmlConvertorException {
		DataOutputStream dataOutputStream = null;
		ByteArrayOutputStream byteOutputStream = null;
		try {
			// Create the marshaller, with customized attributes
			Marshaller marshaller = getJAXBContext().createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
			MtomAttachmentMarshaller attachmentMarshaller = new MtomAttachmentMarshaller();
			marshaller.setAttachmentMarshaller(attachmentMarshaller);
			// byte array to store the XML data
			byte[] xmlData = null;
			byteOutputStream = new ByteArrayOutputStream();
			marshaller.marshal(object, byteOutputStream);
			xmlData = byteOutputStream.toByteArray();

			if (xmlData == null || xmlData.length == 0) {
				throw new MtomXmlConvertorException("Error marshalling obj to xmlData, obj: " + object);
			}

			// Combine XML and Attachements to single stream
			byteOutputStream = new ByteArrayOutputStream();
			dataOutputStream = new DataOutputStream(byteOutputStream);

			// Store the XML length and the XML
			dataOutputStream.writeInt(xmlData.length); // [xml_length]
			dataOutputStream.write(xmlData); // [xml]

			for (MtomAttachmentMarshaller.Attachment attachment : attachmentMarshaller.getAttachments()) {
				// Store the attachment length and the attachment.
				dataOutputStream.writeInt(attachment.getLength()); // [attachX_length]
				dataOutputStream.write(attachment.getData(), attachment.getOffset(), attachment.getLength()); // [attachX]
			}
			return byteOutputStream.toByteArray();
		} catch (JAXBException ex) {
			throw new MtomXmlConvertorException("Error marshalling object: " + ex.getMessage(), ex);
		} catch (IOException ex) {
			throw new MtomXmlConvertorException(
					"Exception has occured while marshalling the object: " + ex.getMessage(), ex);
		} finally {
			try {
				if (null != dataOutputStream)
					dataOutputStream.close();
			} catch (IOException ex) {
				logger.error("Error occured while closing the stream: " + ex.getMessage(), ex);
			}
		}
	}

	/**
	 * This class is responsible for deserializing the object. Also this class
	 * reads the message from the following format:
	 * [xml_length][xml][attach1_length][attach1]...[attachN_length][attachN]
	 *
	 * @param <T>
	 *            the generic type
	 * @param xmlData
	 *            the xml data
	 * @return the object
	 * @throws MtomXmlConvertorException
	 *             the jaxb xml convertor exception
	 */

	public <T> T unmarshal(byte[] xmlData) throws MtomXmlConvertorException {
		DataInputStream inputStream = null;
		try {
			inputStream = new DataInputStream(new ByteArrayInputStream(xmlData));

			int xmlLength = inputStream.readInt(); // [xml_length]

			if (0 == xmlLength) {
				throw new MtomXmlConvertorException("Error unmarshalling object: The input xml is null");
			}
			// [xml] Read the XML content part
			byte[] xmlByteDataBuff = new byte[xmlLength];
			int readCount = inputStream.read(xmlByteDataBuff);
			if (readCount != xmlLength) {
				throw new IOException("Unable to read " + xmlLength + " bytes, read only readCount: " + readCount);
			}

			// This will read the XML attachement part
			MtomAttachmentUnmarshaller attachmentUnmarshaller = new MtomAttachmentUnmarshaller(inputStream);

			Unmarshaller unmarshaller = getJAXBContext().createUnmarshaller();
			unmarshaller.setAttachmentUnmarshaller(attachmentUnmarshaller);
			T object = (T) unmarshaller.unmarshal(new ByteArrayInputStream(xmlByteDataBuff));
			return object;
		} catch (JAXBException ex) {
			throw new MtomXmlConvertorException("Error unmarshalling object: " + ex.getMessage(), ex);
		} catch (IOException ex) {
			throw new MtomXmlConvertorException(
					"Exception has occured while unmarshalling the object: " + ex.getMessage(), ex);
		} catch (Throwable th) {
			throw new MtomXmlConvertorException("Error has occured while unmarshalling the object: " + th.getMessage(),
					th);
		} finally {
			try {
				if (null != inputStream)
					inputStream.close();
			} catch (IOException ex) {
				logger.error("Error occured while closing the stream: " + ex.getMessage(), ex);
			}
		}
	}
}
