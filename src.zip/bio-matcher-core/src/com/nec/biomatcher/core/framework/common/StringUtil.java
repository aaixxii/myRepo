package com.nec.biomatcher.core.framework.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;

/**
 * The Class StringUtil.
 */
public class StringUtil {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(StringUtil.class);

	/**
	 * Checks if is valid numeric.
	 *
	 * @param valueStr
	 *            the value str
	 * @return true, if is valid numeric
	 */
	public static boolean isValidNumeric(String valueStr) {
		return NumberUtils.isNumber(valueStr);
	}

	/**
	 * String to short.
	 *
	 * @param valueStr
	 *            the value str
	 * @return the short
	 */
	public static Short stringToShort(String valueStr) {
		if (isValidNumeric(valueStr)) {
			try {
				return Short.parseShort(valueStr);
			} catch (Throwable th) {
				logger.error("Error converting string('" + valueStr + "') to short: " + th.getMessage(), th);
			}
		}
		return null;
	}

	/**
	 * String to int.
	 *
	 * @param valueStr
	 *            the value str
	 * @return the integer
	 */
	public static Integer stringToInt(String valueStr) {
		if (isValidNumeric(valueStr)) {
			try {
				return Integer.parseInt(valueStr);
			} catch (Throwable th) {
				logger.error("Error converting string('" + valueStr + "') to int: " + th.getMessage(), th);
			}
		}
		return null;
	}

	/**
	 * String to long.
	 *
	 * @param valueStr
	 *            the value str
	 * @return the long
	 */
	public static Long stringToLong(String valueStr) {
		if (isValidNumeric(valueStr)) {
			try {
				return Long.parseLong(valueStr);
			} catch (Throwable th) {
				logger.error("Error converting string('" + valueStr + "') to long: " + th.getMessage(), th);
			}
		}
		return null;
	}

	/**
	 * String to double.
	 *
	 * @param valueStr
	 *            the value str
	 * @return the double
	 */
	public static Double stringToDouble(String valueStr) {
		if (StringUtils.isNotBlank(valueStr)) {
			try {
				return Double.parseDouble(valueStr.trim());
			} catch (Throwable th) {
				logger.error("Error converting string('" + valueStr + "') to double: " + th.getMessage(), th);
			}
		}
		return null;
	}

	/**
	 * String to float.
	 *
	 * @param valueStr
	 *            the value str
	 * @return the float
	 */
	public static Float stringToFloat(String valueStr) {
		if (StringUtils.isNotBlank(valueStr)) {
			try {
				return Float.parseFloat(valueStr.trim());
			} catch (Throwable th) {
				logger.error("Error converting string('" + valueStr + "') to float: " + th.getMessage(), th);
			}
		}
		return null;
	}

	public static float stringToFloat(String valueStr, float defaultValue) {
		Float value = stringToFloat(valueStr);
		return (value == null) ? defaultValue : value;
	}

	/**
	 * String to long.
	 *
	 * @param valueStr
	 *            the value str
	 * @param defaultValue
	 *            the default value
	 * @return the long
	 */
	public static long stringToLong(String valueStr, long defaultValue) {
		Long value = stringToLong(valueStr);
		return (value == null) ? defaultValue : value;
	}

	/**
	 * String to int.
	 *
	 * @param valueStr
	 *            the value str
	 * @param defaultValue
	 *            the default value
	 * @return the int
	 */
	public static int stringToInt(String valueStr, int defaultValue) {
		Integer value = stringToInt(valueStr);
		return (value == null) ? defaultValue : value;
	}

	/**
	 * String to boolean.
	 *
	 * @param valueStr
	 *            the value str
	 * @return the boolean
	 */
	public static Boolean stringToBoolean(String valueStr) {
		if (valueStr != null && ("true".equalsIgnoreCase(valueStr) || "false".equalsIgnoreCase(valueStr))) {
			return Boolean.valueOf(valueStr);
		} else {
			return null;
		}
	}

	/**
	 * String to boolean.
	 *
	 * @param valueStr
	 *            the value str
	 * @param defaultValue
	 *            the default value
	 * @return true, if successful
	 */
	public static boolean stringToBoolean(String valueStr, boolean defaultValue) {
		valueStr = StringUtils.trimToNull(valueStr);
		if (valueStr == null) {
			return defaultValue;
		}
		return Boolean.valueOf(valueStr);
	}

	public static List<String> stringToList(String listStr, String seperator) {
		List<String> list = new ArrayList<>();
		if (listStr != null) {
			String listArr[] = listStr.split(seperator);
			if (listArr != null) {
				for (String listItem : listArr) {
					list.add(listItem != null ? listItem.trim() : listItem);
				}
			}
		}
		return list;
	}

	public static Set<String> stringToSet(String listStr, String seperator) {
		Set<String> list = new HashSet<>();
		if (listStr != null) {
			String listArr[] = listStr.split(seperator);
			if (listArr != null) {
				for (String listItem : listArr) {
					list.add(listItem != null ? listItem.trim() : listItem);
				}
			}
		}
		return list;
	}

	public static List<Integer> splitToIntList(String listStr, String seprator) {
		List<String> strList = stringToList(listStr, seprator);
		List<Integer> intList = new ArrayList<Integer>(strList.size());
		for (String valueStr : strList) {
			Integer value = stringToInt(valueStr);
			if (value != null) {
				intList.add(value);
			}
		}
		return intList;
	}

	/**
	 * String to map.
	 *
	 * @param mapStr
	 *            the map str
	 * @param keyValuePairSep
	 *            the key value pair sep
	 * @param entrySep
	 *            the entry sep
	 * @return the map
	 */
	public static Map<String, String> stringToMap(String mapStr, String keyValuePairSep, String entrySep) {
		HashMap<String, String> map = new HashMap<String, String>();
		if (mapStr != null) {
			String keyValueArr[] = mapStr.split(entrySep);
			if (keyValueArr != null) {
				for (String keyValue : keyValueArr) {
					String keyValuePair[] = keyValue.split(keyValuePairSep);
					if (keyValuePair != null && keyValuePair.length == 2) {
						map.put(keyValuePair[0] != null ? keyValuePair[0].trim() : keyValuePair[0],
								keyValuePair[1] != null ? keyValuePair[1].trim() : keyValuePair[1]);
					}
				}
			}
		}
		return map;
	}

	public static Map<String, Long> stringToLongValueMap(String mapStr, String keyValuePairSep, String entrySep) {
		HashMap<String, Long> map = new HashMap<String, Long>();
		if (mapStr != null) {
			String keyValueArr[] = mapStr.split(entrySep);
			if (keyValueArr != null) {
				for (String keyValue : keyValueArr) {
					String keyValuePair[] = keyValue.split(keyValuePairSep);
					if (keyValuePair != null && keyValuePair.length == 2) {
						map.put(keyValuePair[0], Longs.tryParse(keyValuePair[1]));
					}
				}
			}
		}
		return map;
	}

	public static Map<Integer, Long> stringToIntLongValueMap(String mapStr, String keyValuePairSep, String entrySep) {
		HashMap<Integer, Long> map = new HashMap<Integer, Long>();
		if (mapStr != null) {
			String keyValueArr[] = mapStr.split(entrySep);
			if (keyValueArr != null) {
				for (String keyValue : keyValueArr) {
					String keyValuePair[] = keyValue.split(keyValuePairSep);
					if (keyValuePair != null && keyValuePair.length == 2) {
						map.put(Ints.tryParse(keyValuePair[0]), Longs.tryParse(keyValuePair[1]));
					}
				}
			}
		}
		return map;
	}

	/**
	 * Map to string.
	 *
	 * @param map
	 *            the map
	 * @param keyValuePairSep
	 *            the key value pair sep
	 * @param entrySep
	 *            the entry sep
	 * @return the string
	 */
	public static String mapToString(Map<?, ?> map, String keyValuePairSep, String entrySep) {
		String result = null;
		if (map != null && map.size() > 0) {
			StringBuffer sb = new StringBuffer();
			boolean appendSep = false;
			for (Entry<?, ?> entry : map.entrySet()) {
				if (appendSep) {
					sb.append(entrySep);
				}
				sb.append(entry.getKey()).append(keyValuePairSep).append(entry.getValue());
				appendSep = true;
			}
			result = sb.toString();
		}
		return result;
	}
}
