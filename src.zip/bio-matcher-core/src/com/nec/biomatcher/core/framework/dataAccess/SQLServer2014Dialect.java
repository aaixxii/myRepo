package com.nec.biomatcher.core.framework.dataAccess;

import java.sql.Types;

import org.hibernate.dialect.SQLServer2005Dialect;
import org.hibernate.dialect.function.NoArgSQLFunction;
import org.hibernate.type.DoubleType;
import org.hibernate.type.StandardBasicTypes;

public class SQLServer2014Dialect extends SQLServer2005Dialect {
	public SQLServer2014Dialect() {
		registerColumnType(Types.DECIMAL, DoubleType.INSTANCE.getName());
		registerColumnType(Types.DATE, "date");
		registerColumnType(Types.TIME, "time");
		registerColumnType(Types.TIMESTAMP, "datetime2");

		registerFunction("current_timestamp",
				new NoArgSQLFunction("current_timestamp", StandardBasicTypes.TIMESTAMP, false));
	}

	public boolean supportsSequences() {
		return true;
	}

	public boolean supportsPooledSequences() {
		return true;
	}

	public String getCreateSequenceString(String sequenceName) {
		return "create sequence " + sequenceName;
	}

	public String getDropSequenceString(String sequenceName) {
		return "drop sequence " + sequenceName;
	}

	public String getSelectSequenceNextValString(String sequenceName) {
		return "next value for " + sequenceName;
	}

	public String getSequenceNextValString(String sequenceName) {
		return "select " + getSelectSequenceNextValString(sequenceName);
	}

	public String getQuerySequencesString() {
		return "select name from sys.sequences";
	}
}
