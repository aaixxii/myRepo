package com.nec.biomatcher.core.framework.common.pagination;

import java.io.Serializable;
import java.util.List;

/**
 * The Class PageResult.
 *
 * @author Mahesh
 * @param <T>
 *            the generic type
 */
public class PageResult<T> implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The total records. */
	private Integer totalRecords;

	/** The result list. */
	private List<T> resultList;

	/**
	 * Gets the total records.
	 *
	 * @return the total records
	 */
	public Integer getTotalRecords() {
		return totalRecords;
	}

	/**
	 * Sets the total records.
	 *
	 * @param totalRecords
	 *            the new total records
	 */
	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	/**
	 * Gets the result list.
	 *
	 * @return the result list
	 */
	public List<T> getResultList() {
		return resultList;
	}

	/**
	 * Sets the result list.
	 *
	 * @param resultList
	 *            the new result list
	 */
	public void setResultList(List<T> resultList) {
		this.resultList = resultList;
	}

}
