package com.nec.biomatcher.core.framework.common.exception;

import org.apache.log4j.Logger;

/**
 * The Class ObjectCreationException.
 */
public class ObjectCreationException extends RuntimeException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Constant errorLogger. */
	protected static final Logger errorLogger = Logger.getLogger("ERRORS");

	/**
	 * Default Constructor.
	 */
	public ObjectCreationException() {
		errorLogger.error(this.getMessage(), this);
	}

	/**
	 * The Constructor.
	 *
	 * @param message
	 *            the message
	 */
	public ObjectCreationException(String message) {
		super(message);
		errorLogger.error(message, this);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause
	 *            the cause
	 */
	public ObjectCreationException(Throwable cause) {
		super("ObjectCreationException. Cause: " + cause.getMessage(), cause);
		if (!(cause instanceof CoreException)) {
			errorLogger.error(this.getMessage(), this);
		}
	}

	/**
	 * The Constructor.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public ObjectCreationException(String message, Throwable cause) {
		super(message, cause);
		if (!(cause instanceof CoreException)) {
			errorLogger.error(message, this);
		}
	}

	/**
	 * Log.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public static void log(String message, Throwable cause) {
		errorLogger.error(message, cause);
	}
}
