package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.atomic.AtomicBoolean;

public interface CustomValuedRunnable<V> {
	public void run(AtomicBoolean stopFlag, V value);
}
