package com.nec.biomatcher.core.framework.mtom;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.xml.bind.attachment.AttachmentUnmarshaller;

/**
 * This class is provides the necessary support needed for writing MTOM message,
 * for the unmarshalling functionality.
 *
 * @author yogananda.nbec
 * 
 *         Modification History:
 * 
 *         14 May 2013 (Mahesh): Modified to handle incomplete message.
 * 
 */
public class MtomAttachmentUnmarshaller extends AttachmentUnmarshaller {

	/** The attachments. */
	private Map<String, byte[]> attachments = new HashMap<String, byte[]>();

	/**
	 * Instantiates a new message payload attachment unmarshaller.
	 */
	public MtomAttachmentUnmarshaller() {
		super();
	}

	/**
	 * Instantiates a new message payload attachment unmarshaller.
	 *
	 * @param inputStream
	 *            the input stream
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public MtomAttachmentUnmarshaller(DataInputStream inputStream) throws IOException {
		int id = 1;
		while (inputStream.available() > 0) {
			int length = inputStream.readInt(); // [attachX_length]
			byte[] data = new byte[length]; // [attachX]
			int readCount = inputStream.read(data);
			if (readCount != length) {
				throw new IOException("Unable to read " + length + " bytes, read only readCount: " + readCount);
			}

			this.getAttachments().put("cid:" + String.valueOf(id++), data);
		}
	}

	/**
	 * Gets the attachments.
	 *
	 * @return the attachments
	 */
	public Map<String, byte[]> getAttachments() {
		return attachments;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.xml.bind.attachment.AttachmentUnmarshaller#
	 * getAttachmentAsDataHandler (java.lang.String)
	 */
	@Override
	public DataHandler getAttachmentAsDataHandler(String cid) {
		byte[] bytes = attachments.get(cid);
		return new DataHandler(new ByteArrayDataSource(bytes));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.xml.bind.attachment.AttachmentUnmarshaller#getAttachmentAsByteArray
	 * (java.lang.String)
	 */
	@Override
	public byte[] getAttachmentAsByteArray(String cid) {
		return attachments.get(cid);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.xml.bind.attachment.AttachmentUnmarshaller#isXOPPackage()
	 */
	@Override
	public boolean isXOPPackage() {
		return true;
	}

	/**
	 * The Class ByteArrayDataSource.
	 */
	private static class ByteArrayDataSource implements DataSource {

		/** The bytes. */
		private byte[] bytes;

		/**
		 * Instantiates a new byte array data source.
		 *
		 * @param bytes
		 *            the bytes
		 */
		public ByteArrayDataSource(byte[] bytes) {
			this.bytes = bytes;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.activation.DataSource#getContentType()
		 */
		public String getContentType() {
			return "application/octet-stream";
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.activation.DataSource#getInputStream()
		 */
		public InputStream getInputStream() throws IOException {
			return new ByteArrayInputStream(bytes);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.activation.DataSource#getName()
		 */
		public String getName() {
			return null;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see javax.activation.DataSource#getOutputStream()
		 */
		public OutputStream getOutputStream() throws IOException {
			return null;
		}

	}

}