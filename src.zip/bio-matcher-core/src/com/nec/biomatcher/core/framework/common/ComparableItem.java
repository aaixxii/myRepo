package com.nec.biomatcher.core.framework.common;

import java.util.concurrent.atomic.AtomicLong;

public final class ComparableItem<T> implements Comparable<ComparableItem<T>> {
	private static final AtomicLong STATIC_COUNTER = new AtomicLong();

	private final T value;
	private final long orderNumber;

	public ComparableItem(T value) {
		this.value = value;
		this.orderNumber = STATIC_COUNTER.accumulateAndGet(1, (currVal, newVal) -> currVal + newVal);
	}

	public ComparableItem(T value, long orderNumber) {
		this.value = value;
		this.orderNumber = orderNumber;
	}

	public final T getValue() {
		return value;
	}

	public final boolean equals(Object other) {
		return value.equals(other);
	}

	@Override
	public final int hashCode() {
		return value.hashCode();
	}

	@Override
	public final int compareTo(ComparableItem<T> other) {
		if (this == other || value.equals(other.value)) {
			return 0;
		}
		return Long.compare(orderNumber, other.orderNumber);
	}

}
