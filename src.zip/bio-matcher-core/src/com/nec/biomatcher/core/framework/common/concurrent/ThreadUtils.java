package com.nec.biomatcher.core.framework.common.concurrent;

public class ThreadUtils {
    public static void prefixThreadName(String name) {
        Thread currentThread = Thread.currentThread();
        currentThread.setName(name + "_" + currentThread.getId());
    }
}
