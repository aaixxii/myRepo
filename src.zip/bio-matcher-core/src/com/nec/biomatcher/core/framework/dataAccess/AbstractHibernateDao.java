package com.nec.biomatcher.core.framework.dataAccess;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.hibernate.LockMode;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.hibernate.id.Configurable;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.id.UUIDGenerator;
import org.hibernate.type.StandardBasicTypes;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

/**
 * The Class AbstractHibernateDao.
 *
 * @author Alvin Chua
 */
public abstract class AbstractHibernateDao extends HibernateDaoSupport implements HibernateDao {

	/**
	 * Merge entity.
	 *
	 * @param entity
	 *            the entity
	 * @return the object
	 */
	public Object mergeEntity(Object entity) throws DaoException {
		return this.getHibernateTemplate().merge(entity);
	}

	/**
	 * Save entity.
	 *
	 * @param entity
	 *            the entity
	 * @return the object
	 */
	public Object saveEntity(Object entity) throws DaoException {
		return this.getHibernateTemplate().save(entity);
	}

	/**
	 * Delete entity.
	 *
	 * @param entity
	 *            the entity
	 */
	public void deleteEntity(Object entity) throws DaoException {
		this.getHibernateTemplate().delete(entity);
	}

	public void deleteEntities(Collection<?> entities) throws DaoException {
		this.getHibernateTemplate().deleteAll(entities);
	}

	public <T> T getEntity(Class<T> entityClass, Serializable primaryKey) throws DaoException {
		return (T) this.getHibernateTemplate().get(entityClass, primaryKey);
	}

	public <T> T getEntityForUpdate(final Class<T> entityClass, final Serializable primaryKey) throws DaoException {
		return this.getHibernateTemplate().get(entityClass, primaryKey, LockMode.PESSIMISTIC_WRITE);
	}

	/**
	 * Gets the entity.
	 *
	 * @param <T>
	 *            the generic type
	 * @param criteria
	 *            the criteria
	 * @return the entity
	 * @throws DaoException
	 *             the dao exception
	 */
	@SuppressWarnings("unchecked")
	public <T> T getEntity(DetachedCriteria criteria) throws DaoException {
		List<T> list = (List<T>) getHibernateTemplate().findByCriteria(criteria, -1, 1);
		if (list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

	/**
	 * Gets the entity for update.
	 *
	 * @param <T>
	 *            the generic type
	 * @param criteria
	 *            the criteria
	 * @return the entity for update
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> T getEntityForUpdate(DetachedCriteria criteria) throws DaoException {
		criteria.setLockMode(LockMode.PESSIMISTIC_WRITE);
		return getEntity(criteria);
	}

	public <T> List<T> getEntityList(DetachedCriteria criteria) throws DaoException {
		return (List<T>) getHibernateTemplate().findByCriteria(criteria);
	}

	public <T> List<T> getEntityList(DetachedCriteria criteria, int firstResult, int maxResults) throws DaoException {
		return (List<T>) getHibernateTemplate().findByCriteria(criteria, firstResult, maxResults);
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getEntityListByField(final Class<T> entityClass, final String fieldName,
			final Serializable fieldValue) throws DaoException {

		Criterion criterion = fieldValue == null ? Restrictions.isNull(fieldName)
				: Restrictions.eq(fieldName, fieldValue);

		return getSessionFactory().getCurrentSession().createCriteria(entityClass).add(criterion).list();
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getEntityListByField(final Class<T> entityClass, final String fieldName,
			final Serializable fieldValue, int maxResults) throws DaoException {

		Criterion criterion = fieldValue == null ? Restrictions.isNull(fieldName)
				: Restrictions.eq(fieldName, fieldValue);

		return getSessionFactory().getCurrentSession().createCriteria(entityClass).add(criterion)
				.setMaxResults(maxResults).list();
	}

	@SuppressWarnings("unchecked")
	public <T> T getEntityByField(final Class<T> entityClass, final String fieldName, final Serializable fieldValue)
			throws DaoException {
		Criterion criterion = fieldValue == null ? Restrictions.isNull(fieldName)
				: Restrictions.eq(fieldName, fieldValue);

		return (T) getSessionFactory().getCurrentSession().createCriteria(entityClass).add(criterion).uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getEntityListByFields(final Class<T> entityClass, final String fieldName1,
			final Serializable fieldValue1, final String fieldName2, final Serializable fieldValue2)
			throws DaoException {

		Criterion criterion1 = fieldValue1 == null ? Restrictions.isNull(fieldName1)
				: Restrictions.eq(fieldName1, fieldValue1);
		Criterion criterion2 = fieldValue2 == null ? Restrictions.isNull(fieldName2)
				: Restrictions.eq(fieldName2, fieldValue2);

		return getSessionFactory().getCurrentSession().createCriteria(entityClass).add(criterion1).add(criterion2)
				.list();
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> getEntityListByFields(final Class<T> entityClass, final String fieldName1,
			final Serializable fieldValue1, final String fieldName2, final Serializable fieldValue2, int maxResults)
			throws DaoException {
		Criterion criterion1 = fieldValue1 == null ? Restrictions.isNull(fieldName1)
				: Restrictions.eq(fieldName1, fieldValue1);
		Criterion criterion2 = fieldValue2 == null ? Restrictions.isNull(fieldName2)
				: Restrictions.eq(fieldName2, fieldValue2);

		return getSessionFactory().getCurrentSession().createCriteria(entityClass).add(criterion1).add(criterion2)
				.setMaxResults(maxResults).list();
	}

	@SuppressWarnings("unchecked")
	public <T> T getEntityByFields(final Class<T> entityClass, final String fieldName1, final Serializable fieldValue1,
			final String fieldName2, final Serializable fieldValue2) throws DaoException {

		Criterion criterion1 = fieldValue1 == null ? Restrictions.isNull(fieldName1)
				: Restrictions.eq(fieldName1, fieldValue1);
		Criterion criterion2 = fieldValue2 == null ? Restrictions.isNull(fieldName2)
				: Restrictions.eq(fieldName2, fieldValue2);

		return (T) getSessionFactory().getCurrentSession().createCriteria(entityClass).add(criterion1).add(criterion2)
				.setMaxResults(1).uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public <T> T getEntityByFields(final Class<T> entityClass, final String fieldName1, final Serializable fieldValue1,
			final String fieldName2, final Serializable fieldValue2, final String fieldName3,
			final Serializable fieldValue3) throws DaoException {

		Criterion criterion1 = fieldValue1 == null ? Restrictions.isNull(fieldName1)
				: Restrictions.eq(fieldName1, fieldValue1);
		Criterion criterion2 = fieldValue2 == null ? Restrictions.isNull(fieldName2)
				: Restrictions.eq(fieldName2, fieldValue2);
		Criterion criterion3 = fieldValue3 == null ? Restrictions.isNull(fieldName3)
				: Restrictions.eq(fieldName3, fieldValue3);

		return (T) getSessionFactory().getCurrentSession().createCriteria(entityClass).add(criterion1).add(criterion2)
				.add(criterion3).setMaxResults(1).uniqueResult();
	}

	@SuppressWarnings("unchecked")
	public <T> T getEntityByFields(final Class<T> entityClass, final String fieldName1, final Serializable fieldValue1,
			final String fieldName2, final Serializable fieldValue2, final String fieldName3,
			final Serializable fieldValue3, final String fieldName4, final Serializable fieldValue4)
			throws DaoException {

		Criterion criterion1 = fieldValue1 == null ? Restrictions.isNull(fieldName1)
				: Restrictions.eq(fieldName1, fieldValue1);
		Criterion criterion2 = fieldValue2 == null ? Restrictions.isNull(fieldName2)
				: Restrictions.eq(fieldName2, fieldValue2);
		Criterion criterion3 = fieldValue3 == null ? Restrictions.isNull(fieldName3)
				: Restrictions.eq(fieldName3, fieldValue3);
		Criterion criterion4 = fieldValue4 == null ? Restrictions.isNull(fieldName4)
				: Restrictions.eq(fieldName4, fieldValue4);

		return (T) getSessionFactory().getCurrentSession().createCriteria(entityClass).add(criterion1).add(criterion2)
				.add(criterion3).add(criterion4).setMaxResults(1).uniqueResult();
	}

	/**
	 * Gets the all entity.
	 *
	 * @param entityClass
	 *            the entity class
	 * @return the all entity
	 */
	public <T> List<T> getAllEntity(Class<T> entityClass) throws DaoException {
		return getHibernateTemplate().loadAll(entityClass);
	}

	/**
	 * Update entity.
	 *
	 * @param entity
	 *            the entity
	 */
	public void updateEntity(Object entity) throws DaoException {
		this.getHibernateTemplate().update(entity);
	}

	/**
	 * Save or update entity.
	 *
	 * @param entity
	 *            the entity
	 */
	public void saveOrUpdateEntity(Object entity) throws DaoException {
		this.getHibernateTemplate().saveOrUpdate(entity);
	}

	/**
	 * Evict all.
	 *
	 * @param collObj
	 *            the coll obj
	 */
	public void evictAll(Collection<?> collObj) throws DaoException {
		HibernateTemplate hbTemplate = this.getHibernateTemplate();
		for (Object entity : collObj) {
			hbTemplate.evict(entity);
		}
	}

	public void evict(Object entity) throws DaoException {
		if (entity != null) {
			this.getHibernateTemplate().evict(entity);
		}
	}

	public void flush() throws DaoException {
		this.currentSession().flush();
	}

	public String createUUID() throws DaoException {
		Properties props = new Properties();
		props.setProperty("separator", "");
		IdentifierGenerator generator = new UUIDGenerator();
		((Configurable) generator).configure(StandardBasicTypes.STRING, props, null);

		String id = (String) generator.generate(null, null);
		return id;
	}

}
