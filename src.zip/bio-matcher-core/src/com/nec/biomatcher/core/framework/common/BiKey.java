package com.nec.biomatcher.core.framework.common;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class BiKey<A, B> implements Comparable<BiKey<A, B>>, Serializable {
	private static final long serialVersionUID = 1L;

	public A a;
	public B b;
	public Comparator<BiKey<A, B>> comparator;

	public BiKey() {

	}

	public BiKey(A a, B b) {
		this.a = a;
		this.b = b;
	}

	public BiKey(A a, B b, Comparator<BiKey<A, B>> comparator) {
		this.a = a;
		this.b = b;
		this.comparator = comparator;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof BiKey)) {
			return false;
		}

		BiKey other = (BiKey) obj;
		return new EqualsBuilder().append(a, other.a).append(b, other.b).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(a).append(b).toHashCode();
	}

	@Override
	public int compareTo(BiKey<A, B> other) {
		if (this == other) {
			return 0;
		}

		if (comparator != null) {
			return comparator.compare(this, other);
		}
		if (other == null) {
			return Integer.MAX_VALUE;
		}
		return new CompareToBuilder().append(a, other.a).append(b, other.b).toComparison();
	}

	@Override
	public String toString() {
		return new StringBuilder().append(a).append(":").append(b).toString();
	}

	public A getA() {
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}

	public B getB() {
		return b;
	}

	public void setB(B b) {
		this.b = b;
	}
}
