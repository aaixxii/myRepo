package com.nec.biomatcher.core.framework.springSupport;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

/**
 * The Class SpringSelfAssignmentBean.
 */
public class SpringSelfAssignmentBean implements InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SpringSelfAssignmentBean.class);

	/** The source target bean map. */
	private Map<Object, SpringSelfAssignmentMarker> sourceTargetBeanMap = new HashMap<Object, SpringSelfAssignmentMarker>();

	public void setSourceTargetBeanMap(Map<Object, SpringSelfAssignmentMarker> sourceTargetBeanMap) {
		this.sourceTargetBeanMap = sourceTargetBeanMap;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		if (sourceTargetBeanMap == null) {
			return;
		}
		for (Entry<Object, SpringSelfAssignmentMarker> entry : sourceTargetBeanMap.entrySet()) {
			try {
				entry.getValue().assignSelf(entry.getKey());
			} catch (Exception ex) {
				logger.error("Exception during selfAssignment for : " + entry.getValue() + " : " + ex.getMessage(), ex);
				throw ex;
			} catch (Throwable th) {
				logger.error("Error during selfAssignment for : " + entry.getValue() + " : " + th.getMessage(), th);
				throw new Exception(th.getMessage(), th);
			}
		}
	}
}
