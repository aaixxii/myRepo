package com.nec.biomatcher.core.framework.web.filter;

import java.io.IOException;
import java.util.Locale;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.jstl.core.Config;

import org.apache.log4j.Logger;

/**
 * This filter class is used to set the encoding and locale.
 *
 * @author Mahesh
 * @version 1.0
 */
/*
 * Modification History: 11 Feb 2011 (Mahesh): Modified to detect locale from
 * request object if session locale is not yet set
 */
public class LocaleFilter implements Filter {

	/** The _logger. */
	private static Logger _logger = Logger.getLogger(LocaleFilter.class.getName());

	/** The filter config. */
	private FilterConfig filterConfig;

	/** The init encoding. */
	private String initEncoding;

	/** The init locale. */
	private Locale initLocale = null;

	/** The supported locale list. */
	private String supportedLocaleList = null;

	/**
	 * Instantiates a new locale filter.
	 */
	public LocaleFilter() {
	}

	/**
	 * Load the initial setting from configuration.
	 *
	 * @param filterConfig
	 *            FilterConfig
	 * @throws ServletException
	 *             the servlet exception
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		_logger.debug("In LocaleFilter.init()..");
		this.filterConfig = filterConfig;

		initEncoding = filterConfig.getInitParameter("encoding");
		String initLocaleParam = filterConfig.getInitParameter("locale");

		supportedLocaleList = filterConfig.getInitParameter("supportedLocaleList");

		_logger.debug("In LocaleFilter.init()..initEncoding: " + initEncoding + ", initLocaleParam: " + initLocaleParam
				+ ", supportedLocaleList: " + supportedLocaleList);

		initLocale = getLocaleObj(initLocaleParam);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		_logger.debug("In LocaleFilter.destroy()..");
		filterConfig = null;
		initEncoding = null;
		initLocale = null;
		supportedLocaleList = null;
	}

	/**
	 * Sets the locale and encoding.
	 *
	 * @param servletRequest
	 *            ServletRequest
	 * @param servletResponse
	 *            ServletResponse
	 * @param filterChain
	 *            FilterChain
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws ServletException
	 *             the servlet exception
	 */
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws java.io.IOException, javax.servlet.ServletException {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		HttpSession session = ((HttpServletRequest) request).getSession(false);
		if (session != null) {
			_logger.trace("[LocaleFilter] Session: " + session.getId());
		}

		_logger.trace("[LocaleFilter] URI: " + request.getRequestURI() + " Content Type:"
				+ response.getCharacterEncoding() + "Request Encoding:" + request.getCharacterEncoding());

		request.setCharacterEncoding(initEncoding);
		// response.setCharacterEncoding(initEncoding);

		Locale currentLocale = null;
		if (session != null) {
			currentLocale = (Locale) session.getAttribute(Locale.class.getName());

			if (currentLocale == null) {
				Locale requestLocale = request.getLocale();
				currentLocale = isLocaleSupported(requestLocale) ? requestLocale : initLocale;
				// session.setAttribute(org.apache.struts.Globals.LOCALE_KEY,
				// currentLocale);
				// session.setAttribute(org.apache.struts2.interceptor.I18nInterceptor.DEFAULT_SESSION_ATTRIBUTE,
				// currentLocale);
				Config.set(session, Config.FMT_LOCALE, currentLocale);
				session.setAttribute(Locale.class.getName(), currentLocale);
				session.setAttribute("org.apache.tiles.LOCALE", currentLocale);
			}
		} else {
			currentLocale = initLocale;
		}

		response.setLocale(currentLocale);
		response.setContentType("text/html; charset=UTF-8");

		_logger.trace("[LocaleFilter] Response Encoding:" + response.getCharacterEncoding() + "Request Encoding:"
				+ request.getCharacterEncoding());
		filterChain.doFilter(request, response);
	}

	/**
	 * Checks if is locale supported.
	 *
	 * @param locale
	 *            the locale
	 * @return true, if is locale supported
	 */
	private boolean isLocaleSupported(Locale locale) {
		if (locale != null && supportedLocaleList != null) {
			String localeKey = locale.getLanguage() + "_" + locale.getCountry();
			return supportedLocaleList.toUpperCase().indexOf(localeKey.toUpperCase()) > -1;
		}
		return false;
	}

	/**
	 * Gets the locale obj.
	 *
	 * @param localeParam
	 *            the locale param
	 * @return the locale obj
	 */
	private Locale getLocaleObj(String localeParam) {
		return new Locale(localeParam.substring(0, 2), localeParam.substring(3));
	}

	/**
	 * Gets the filter config.
	 *
	 * @return the filter config
	 */
	public FilterConfig getFilterConfig() {
		return filterConfig;
	}

	/**
	 * Sets the filter config.
	 *
	 * @param cfg
	 *            the new filter config
	 */
	public void setFilterConfig(FilterConfig cfg) {
		filterConfig = cfg;
	}
}
