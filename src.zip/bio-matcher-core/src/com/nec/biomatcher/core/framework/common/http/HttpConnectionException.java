package com.nec.biomatcher.core.framework.common.http;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class HttpConnectionException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	public HttpConnectionException(String message, Throwable cause) {
		super(message, cause);
	}

	public HttpConnectionException(String message) {
		super(message);
	}

	public HttpConnectionException(Throwable cause) {
		super(cause.getMessage(), cause);
	}
}
