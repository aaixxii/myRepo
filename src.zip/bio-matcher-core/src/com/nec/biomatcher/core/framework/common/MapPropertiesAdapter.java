package com.nec.biomatcher.core.framework.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.adapters.XmlAdapter;

/**
 * The Class MapPropertiesAdapter.
 */
public class MapPropertiesAdapter extends XmlAdapter<MapPropertiesAdapter.AdaptedProperties, Map<String, String>> {

	/**
	 * The Class AdaptedProperties.
	 */
	public static class AdaptedProperties {

		/** The property. */
		public List<Property> property = new ArrayList<Property>();
	}

	/**
	 * The Class Property.
	 */
	public static class Property {

		/** The name. */
		@XmlAttribute
		public String name;

		/** The value. */
		public byte[] value;
	}

	@Override
	public Map<String, String> unmarshal(AdaptedProperties adaptedProperties) throws Exception {
		if (null == adaptedProperties) {
			return null;
		}
		Map<String, String> map = new HashMap<String, String>(adaptedProperties.property.size());
		for (Property property : adaptedProperties.property) {
			map.put(property.name, property.value != null ? new String(property.value) : null);
		}
		return map;
	}

	@Override
	public AdaptedProperties marshal(Map<String, String> map) throws Exception {
		if (null == map) {
			return null;
		}
		AdaptedProperties adaptedProperties = new AdaptedProperties();
		for (Entry<String, String> entry : map.entrySet()) {
			Property property = new Property();
			property.name = entry.getKey();
			property.value = entry.getValue() != null ? entry.getValue().getBytes() : null;
			adaptedProperties.property.add(property);
		}
		return adaptedProperties;
	}

}
