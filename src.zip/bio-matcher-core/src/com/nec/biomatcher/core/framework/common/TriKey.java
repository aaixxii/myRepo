package com.nec.biomatcher.core.framework.common;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class TriKey<A, B, C> implements Comparable<TriKey<A, B, C>>, Serializable {
	private static final long serialVersionUID = 1L;

	public A a;
	public B b;
	public C c;
	public Comparator<TriKey<A, B, C>> comparator;

	public TriKey(A a, B b, C c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public TriKey(A a, B b, C c, Comparator<TriKey<A, B, C>> comparator) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.comparator = comparator;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TriKey)) {
			return false;
		}

		TriKey other = (TriKey) obj;
		return new EqualsBuilder().append(a, other.a).append(b, other.b).append(c, other.c).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(a).append(b).append(c).toHashCode();
	}

	@Override
	public String toString() {
		return new StringBuilder().append(a).append(":").append(b).append(":").append(c).toString();
	}

	@Override
	public int compareTo(TriKey<A, B, C> other) {
		if (this == other) {
			return 0;
		}

		if (comparator != null) {
			return comparator.compare(this, other);
		}
		if (other == null) {
			return Integer.MAX_VALUE;
		}
		return new CompareToBuilder().append(a, other.a).append(b, other.b).append(c, other.c).toComparison();
	}

	public A getA() {
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}

	public B getB() {
		return b;
	}

	public void setB(B b) {
		this.b = b;
	}

	public C getC() {
		return c;
	}

	public void setC(C c) {
		this.c = c;
	}

}
