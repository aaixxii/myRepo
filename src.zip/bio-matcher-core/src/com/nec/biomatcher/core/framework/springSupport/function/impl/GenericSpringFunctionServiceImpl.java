package com.nec.biomatcher.core.framework.springSupport.function.impl;

import com.google.common.base.Function;
import com.nec.biomatcher.core.framework.springSupport.function.GenericSpringFunctionService;

/**
 * The Class GenericSpringFunctionServiceImpl.
 */
public class GenericSpringFunctionServiceImpl implements GenericSpringFunctionService {
	public <F, T> T executeFunction(Function<F, T> function, F input) throws Exception {
		return function.apply(input);
	}
}
