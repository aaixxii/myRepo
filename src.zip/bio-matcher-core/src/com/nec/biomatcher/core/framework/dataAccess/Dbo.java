package com.nec.biomatcher.core.framework.dataAccess;

import java.io.Serializable;

/**
 * The Interface Dbo.
 */
public interface Dbo extends Serializable {

}
