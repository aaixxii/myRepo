package com.nec.biomatcher.core.framework.springSupport;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;

import com.google.common.base.Function;
import com.nec.biomatcher.core.framework.springSupport.function.GenericSpringFunctionService;

/**
 * Initializing bean whose afterPropertiesSet will called from within
 * transaction context.
 * 
 * We need to do this because in Spring 4, afterPropertiesSet is not called
 * withing the transaction
 * 
 * @author Mahesh
 *
 */
public class SpringTxInitializingBean implements InitializingBean, ApplicationContextAware {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SpringTxInitializingBean.class);

	/** The spring function service. */
	private GenericSpringFunctionService springFunctionService;

	/** The application context. */
	private ApplicationContext applicationContext;

	/** The bean names. */
	private List<String> beanNames;

	public void setBeanNames(String... beanNames) {
		logger.info("SpringTxInitializingBean.setBeanNames called");
		Assert.notEmpty(beanNames, "'beanNames' must not be empty");
		this.beanNames = new ArrayList<String>(beanNames.length);
		for (String mappedName : beanNames) {
			this.beanNames.add(StringUtils.trimWhitespace(mappedName));
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("SpringTxInitializingBean.afterPropertiesSet called : beanNames: "
				+ (beanNames != null ? beanNames.size() : 0));
		if (beanNames != null) {
			for (String beanName : beanNames) {
				logger.info("SpringTxInitializingBean: Before initializing bean : " + beanName);
				try {
					Object bean = applicationContext.getBean(beanName);

					String className = bean.getClass().getName();

					final Method afterPropertiesSet = ReflectionUtils.findMethod(bean.getClass(), "afterPropertiesSet");

					if (afterPropertiesSet == null) {
						throw new Exception("afterPropertiesSet method is not found in bean: " + beanName + ", class: "
								+ className);
					}

					boolean flag = springFunctionService.executeFunction(new Function<Object, Boolean>() {
						public Boolean apply(Object input) {
							ReflectionUtils.invokeMethod(afterPropertiesSet, input);
							return true;
						}
					}, bean);

					logger.info("SpringTxInitializingBean: Initialized bean (" + beanName + ") successfully : ");

				} catch (Exception ex) {
					logger.info(
							"SpringTxInitializingBean: Error initializing bean : " + beanName + " : " + ex.getMessage(),
							ex);
					throw ex;
				}
			}
		}
	}

	public void setSpringFunctionService(GenericSpringFunctionService springFunctionService) {
		this.springFunctionService = springFunctionService;
		logger.info("SpringTxInitializingBean.setSpringFunctionService called");
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
		logger.info("SpringTxInitializingBean.setApplicationContext called");
	}
}
