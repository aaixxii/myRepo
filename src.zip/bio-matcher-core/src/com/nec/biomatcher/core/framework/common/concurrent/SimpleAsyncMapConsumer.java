package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class SimpleAsyncMapConsumer<K, V> {
	private static final Logger logger = Logger.getLogger(SimpleAsyncMapConsumer.class);

	private final ConcurrentSkipListMap<K, V> kvMap = new ConcurrentSkipListMap<>();
	private final Semaphore processSetQueueSemaphore = new Semaphore(0);
	private final String name;
	private final BiConsumer<K, V> consumer;

	public SimpleAsyncMapConsumer(String name, BiConsumer<K, V> consumer) {
		this.name = name;
		this.consumer = consumer;
		Runnable runnable = () -> {
			Thread.currentThread().setName("SAMC_SUB_" + name + "_" + Thread.currentThread().getId());
			submitToConsumer();
		};

		CommonTaskScheduler.scheduleWithFixedDelay(runnable, 100, 500, TimeUnit.MILLISECONDS);
	}

	public final void put(K key, V value) {
		if (key == null || value == null) {
			return;
		}
		V oldValue = kvMap.put(key, value);
		if (oldValue == null) {
			if (logger.isTraceEnabled())
				logger.trace("In SimpleAsyncMapConsumer.put for name: " + name + ", key: " + key + ", value: " + value);
			processSetQueueSemaphore.release();
		}
	}

	public final void merge(K key, V value, BiFunction<V, V, V> remappingFunction) {
		if (key == null || value == null) {
			return;
		}
		V newValue = kvMap.merge(key, value, remappingFunction);
		if (newValue == value) {
			if (logger.isTraceEnabled())
				logger.trace("In SimpleAsyncMapConsumer.put for name: " + name + ", key: " + key + ", value: " + value);
			processSetQueueSemaphore.release();
		}
	}

	public final void putAll(Map<K, V> map) {
		if (map == null) {
			return;
		}
		boolean isAdded = false;
		for (Entry<K, V> entry : map.entrySet()) {
			if (kvMap.put(entry.getKey(), entry.getValue()) == null) {
				isAdded = true;
			}
		}
		if (isAdded) {
			if (logger.isTraceEnabled())
				logger.trace("In SimpleAsyncMapConsumer.putAll for name: " + name + ", mapSize: " + map.size());
			processSetQueueSemaphore.release();
		}
	}

	private final void submitToConsumer() {
		while (!ShutdownHook.isShutdownFlag) {
			processSetQueueSemaphore.acquireUninterruptibly();

			Entry<K, V> entry = null;
			while ((entry = kvMap.pollFirstEntry()) != null) {
				processSetQueueSemaphore.drainPermits();

				do {
					long startTimeMilli = System.currentTimeMillis();
					try {
						consumer.accept(entry.getKey(), entry.getValue());
					} catch (Throwable th) {
						logger.error(
								"SimpleAsyncMapConsumer.submitToConsumer enountered error for name: " + name + ", key: "
										+ entry.getKey() + ", value: " + entry.getValue() + " : " + th.getMessage(),
								th);
					} finally {
						if (logger.isTraceEnabled())
							logger.trace("In SimpleAsyncMapConsumer.submitToConsumer for name: " + name + ", key: "
									+ entry.getKey() + ", value: " + entry.getValue() + ", timeTakenMilli: "
									+ (System.currentTimeMillis() - startTimeMilli));
					}
				} while ((entry = kvMap.pollFirstEntry()) != null);
			}
		}

		CommonLogger.STATUS_LOG.error("Exiting SimpleAsyncMapConsumer.submitToConsumer for name: " + name);
	}

}
