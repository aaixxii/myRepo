package com.nec.biomatcher.core.framework.mtom;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.bind.JAXBContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.core.framework.common.CompressUtil;

/**
 * The Class MtomXmlConvertor.
 */
public class MtomXmlConvertor extends AbstractMtomXmlConverter implements InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(MtomXmlConvertor.class);

	/** The initialization count. */
	private static int initializationCount = 0;

	/** The classes to be bound. */
	private List<Class<?>> classesToBeBound;

	/** The compression threshold size. */
	private int compressionThresholdSize = 1024 * 4;

	/** The jaxb context. */
	private JAXBContext jaxbContext;

	/**
	 * Instantiates a new message payload xml converter.
	 */
	public MtomXmlConvertor() {

	}

	@Override
	public JAXBContext getJAXBContext() {
		return jaxbContext;
	}

	public void setClassesToBeBound(List<Class<?>> classesToBeBound) {
		this.classesToBeBound = classesToBeBound;
	}

	public <T> byte[] marshal(T object) throws MtomXmlConvertorException {

		try {
			byte[] xmlData = super.marshal(object);
			if (xmlData != null && xmlData.length > compressionThresholdSize) {
				xmlData = CompressUtil.byteToGzip(xmlData);
			}
			return xmlData;
		} catch (IOException ex) {
			throw new MtomXmlConvertorException(ex);
		}
	}

	public <T> T unmarshal(byte[] xmlData) throws MtomXmlConvertorException {
		try {
			if (CompressUtil.isGzipCompressed(xmlData)) {
				xmlData = CompressUtil.gzipToBytes(xmlData);
			}
			return super.unmarshal(xmlData);
		} catch (IOException ex) {
			throw new MtomXmlConvertorException(ex);
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In MtomXmlConvertor.afterPropertiesSet. initializationCount: " + initializationCount
				+ ", hashCode: " + hashCode());
		if (initializationCount > 0) {
			initializationCount++;
			logger.warn("MtomXmlConvertor is already initialized. initializationCount: " + initializationCount);
			return;
		}
		Set<Class<?>> classesSet = new HashSet<Class<?>>();
		if (classesToBeBound != null && classesToBeBound.size() > 0) {
			classesSet.addAll(classesToBeBound);
		}

		if (classesSet == null || classesSet.size() == 0) {
			logger.warn("In MtomXmlConvertor, classesToBeBound is null or empty");
			jaxbContext = JAXBContext.newInstance();
		} else {
			logger.info("In MtomXmlConvertor, List of classesToBeBound: " + classesSet);
			jaxbContext = JAXBContext.newInstance(classesSet.toArray(new Class[classesSet.size()]));
		}
		initializationCount++;
	}

	public void setCompressionThresholdSize(int compressionThresholdSize) {
		this.compressionThresholdSize = compressionThresholdSize;
	}

}
