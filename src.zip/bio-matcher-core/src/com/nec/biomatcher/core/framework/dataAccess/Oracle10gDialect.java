package com.nec.biomatcher.core.framework.dataAccess;

public class Oracle10gDialect extends org.hibernate.dialect.Oracle10gDialect {

	public Oracle10gDialect() {
		super();
	}

	@Override
	public boolean useFollowOnLocking() {
		return false;
	}
}
