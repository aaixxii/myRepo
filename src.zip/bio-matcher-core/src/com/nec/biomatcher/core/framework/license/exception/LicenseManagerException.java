package com.nec.biomatcher.core.framework.license.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class LicenseManagerException extends CoreException {

	/**
	 * The Constructor.
	 */
	public LicenseManagerException() {
		super("Invalid license.");
	}

	/**
	 * The Constructor.
	 * 
	 * @param message
	 *            the message
	 */
	public LicenseManagerException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public LicenseManagerException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause
	 *            the cause
	 */
	public LicenseManagerException(Throwable cause) {
		super("LicenseManagerException: Cause: " + cause.getMessage(), cause);
	}

}
