package com.nec.biomatcher.core.framework.dataAccess.types;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.AbstractSingleColumnStandardBasicType;
import org.hibernate.type.AbstractStandardBasicType;
import org.hibernate.type.TypeResolver;
import org.hibernate.usertype.ParameterizedType;
import org.hibernate.usertype.UserType;

/**
 * <pre>
 * This is enum user type is used for persisting enums whose custom value needs to be stored in database.
 * Enum should implement two methods to get value and get enum from value.
 * And this method names needs to be configured in hbm file.
 * By default the method names used are  'value' and 'enumOf'
 * 
 * Note: get value from enum (enumOf) method should be static
 * </pre>
 * 
 * @author mreddy
 *
 */
public class ValuedEnumUserType implements UserType, ParameterizedType, Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5993020929647717601L;

    /** The Constant ENUM. */
    public static final String ENUM = "enumClass";

    /** The Constant VALUE_FROM_ENUM_METHOD. */
    public static final String VALUE_FROM_ENUM_METHOD = "valueFromEnumMethod";

    /** The Constant ENUM_FROM_VALUE_METHOD. */
    public static final String ENUM_FROM_VALUE_METHOD = "enumFromValueMethod";

    /** The Constant DEFAULT_VALUE_FROM_ENUM_METHOD_NAME. */
    private static final String DEFAULT_VALUE_FROM_ENUM_METHOD_NAME = "getValue";

    /** The Constant DEFAULT_ENUM_FROM_VALUE_METHOD_NAME. */
    private static final String DEFAULT_ENUM_FROM_VALUE_METHOD_NAME = "enumOf";

    /** The enum class. */
    @SuppressWarnings("rawtypes")
    private Class<? extends Enum> enumClass;

    /** The value type. */
    private Class<?> valueType;

    /** The value from enum method. */
    private Method valueFromEnumMethod;

    /** The enum from value method. */
    private Method enumFromValueMethod;

    /** The type. */
    private AbstractStandardBasicType<? extends Object> type;

    /** The sql types. */
    private int[] sqlTypes;

    @SuppressWarnings({ "unchecked" })
    public void setParameterValues(Properties parameters) {
        String enumClassName = parameters.getProperty("enumClass");
        try {
            enumClass = Class.forName(enumClassName).asSubclass(Enum.class);
        } catch (ClassNotFoundException cfne) {
            throw new HibernateException("Enum class not found", cfne);
        }

        String valueFromEnumMethodName = parameters.getProperty(VALUE_FROM_ENUM_METHOD, DEFAULT_VALUE_FROM_ENUM_METHOD_NAME);

        try {
            valueFromEnumMethod = enumClass.getMethod(valueFromEnumMethodName, new Class[0]);
            valueType = valueFromEnumMethod.getReturnType();
        } catch (Exception e) {
            throw new HibernateException("Failed to obtain valueFromEnum method  (" + valueFromEnumMethodName + ") for enumClass: " + enumClass.getName() + " : " + e.getMessage(), e);
        }

        type = (AbstractSingleColumnStandardBasicType<? extends Object>) new TypeResolver().heuristicType(valueType.getName(), parameters);

        if (type == null)
            throw new HibernateException("Unsupported value type " + valueType.getName() + " for while mapping enumClass: " + enumClass.getName());

        sqlTypes = new int[] { ((AbstractSingleColumnStandardBasicType<?>) type).sqlType() };

        String valueOfMethodName = parameters.getProperty(ENUM_FROM_VALUE_METHOD, DEFAULT_ENUM_FROM_VALUE_METHOD_NAME);

        try {
            enumFromValueMethod = enumClass.getMethod(valueOfMethodName, new Class[] { valueType });
        } catch (Exception e) {
            throw new HibernateException("Failed to obtain enumFromValue method (" + valueOfMethodName + ") for enumClass: " + enumClass.getName() + " : " + e.getMessage(), e);
        }
    }

    @SuppressWarnings("rawtypes")
    public Class<? extends Enum> returnedClass() {
        return enumClass;
    }

    @Override
    public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner) throws HibernateException, SQLException {
        Object value = null;
        if(valueType!=null) {
            if(valueType.equals(String.class)) {
                value = rs.getString(names[0]);
            }
//            else if(valueType.equals(Integer.class)) {
//                value = rs.getInt(names[0]);
//            }
//            else if(valueType.equals(Short.class)) {
//                value = rs.getShort(names[0]);
//            }
//            else if(valueType.equals(Long.class)) {
//                value = rs.getLong(names[0]);
//            }
            else {
                value = rs.getObject(names[0], valueType);
            }
        }
        else {
            value = rs.getObject(names[0]);
        }
        
        try {
            return enumFromValueMethod.invoke(enumClass, new Object[] { value });
        } catch (Exception e) {
            throw new HibernateException("Exception while invoking valueOf method '" + enumFromValueMethod.getName() + "' of " + "enumeration class '" + enumClass.getName() + "' : " + e.getMessage(), e);
        }
    }

    @Override
    public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws SQLException {
        try {
            if (value == null) {
                st.setNull(index, sqlTypes[0]);
            } else {
                value = valueFromEnumMethod.invoke(value, new Object[0]);
                if (value == null) {
                    st.setNull(index, sqlTypes[0]);
                } else {
                    st.setObject(index, value);
                }
            }
        } catch (Exception e) {
            throw new HibernateException("Exception while invoking valueFromEnumMethod '" + valueFromEnumMethod.getName() + "' of " + "enumeration class '" + enumClass + "'", e);
        }
    }

    public int[] sqlTypes() {
        return sqlTypes;
    }

    public Object assemble(Serializable cached, Object owner) throws HibernateException {
        return cached;
    }

    public Object deepCopy(Object value) throws HibernateException {
        return value;
    }

    public Serializable disassemble(Object value) throws HibernateException {
        return (Serializable) value;
    }

    public boolean equals(Object x, Object y) throws HibernateException {
        return x == y;
    }

    public int hashCode(Object x) throws HibernateException {
        return x != null ? x.hashCode() : 1978;
    }

    public boolean isMutable() {
        return false;
    }

    public Object replace(Object original, Object target, Object owner) throws HibernateException {
        return original;
    }
}
