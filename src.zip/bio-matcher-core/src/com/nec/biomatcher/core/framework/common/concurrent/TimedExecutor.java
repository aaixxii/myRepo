package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.log4j.Logger;

/**
 * The Class TimedExecutor.
 * 
 * @author Mahesh
 * @since 04 June 2013
 * 
 */
public class TimedExecutor {

	/** The Constant _logger. */
	private static final Logger _logger = Logger.getLogger(TimedExecutor.class);

	/** The Constant executorService. */
	private static final ExecutorService executorService = Executors.newCachedThreadPool();

	/**
	 * Execute.
	 *
	 * @param <T>
	 *            the generic type
	 * @param callable
	 *            the callable
	 * @param timeoutMilliSeconds
	 *            the timeout milli seconds
	 * @return the t
	 * @throws Throwable
	 *             the throwable
	 */
	public static final <T> T execute(Callable<T> callable, long timeoutMilliSeconds) throws Throwable {
		Future<T> task = executorService.submit(callable);
		try {
			T result = task.get(timeoutMilliSeconds, TimeUnit.MILLISECONDS);
			return result;
		} catch (InterruptedException e) {
			_logger.error("Encountered InterruptedException: " + e.getMessage(), e);
			throw e;
		} catch (ExecutionException e) {
			_logger.error("Encountered ExecutionException: " + e.getMessage(), e.getCause());
			throw e.getCause();
		} catch (TimeoutException e) {
			boolean cancelFlag = cancelTask(task);
			_logger.error("Encountered TimeoutException after timeoutMilliSeconds: " + timeoutMilliSeconds
					+ ", cancelFlag: " + cancelFlag + " : " + e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Execute.
	 *
	 * @param runnable
	 *            the runnable
	 * @param timeoutMilliSeconds
	 *            the timeout milli seconds
	 * @throws Throwable
	 *             the throwable
	 */
	public static final void execute(Runnable runnable, long timeoutMilliSeconds) throws Throwable {
		Future<?> task = executorService.submit(runnable);
		try {
			task.get(timeoutMilliSeconds, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			_logger.error("Encountered InterruptedException: " + e.getMessage(), e);
			throw e;
		} catch (ExecutionException e) {
			_logger.error("Encountered ExecutionException: " + e.getMessage(), e.getCause());
			throw e.getCause();
		} catch (TimeoutException e) {
			boolean cancelFlag = cancelTask(task);
			_logger.error("Encountered TimeoutException after timeoutMilliSeconds: " + timeoutMilliSeconds
					+ ", cancelFlag: " + cancelFlag + " : " + e.getMessage(), e);
			throw e;
		}
	}

	/**
	 * Cancel task.
	 *
	 * @param task
	 *            the task
	 * @return true, if successful
	 */
	private static final boolean cancelTask(Future<?> task) {
		try {
			if (task == null) {
				return true;
			}

			// It will only try to cancel
			return task.cancel(true);
		} catch (Throwable th) {
			_logger.error("Encountered error during cancelTask: " + th.getMessage(), th);
		}
		return false;
	}
}
