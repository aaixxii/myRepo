package com.nec.biomatcher.core.framework.cache;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.BiFunction;
import java.util.function.Supplier;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

import com.google.common.util.concurrent.Striped;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

/**
 * This class intercepts method invocation and checks for MethodCache
 * annotation. If this annotation is specified for this method, then it will
 * cache the results.
 * 
 * @author Mahesh
 */
public class SpringMethodCacheInterceptor implements MethodInterceptor, InitializingBean {

	/** The logger. */
	private static Logger logger = Logger.getLogger(SpringMethodCacheInterceptor.class);

	// private static final Striped<ReadWriteLock> stripedRwLocks =
	// Striped.lazyWeakReadWriteLock(2048);
	private static final ConcurrentValuedHashMap<String, ReadWriteLock> stripedRwLocks = new ConcurrentValuedHashMap<>(
			key -> new ReentrantReadWriteLock());

	/** The cache. */
	private Cache cache;

	private BiFunction<String, Integer, Integer> timeToIdleSecondsFunction;

	private BiFunction<String, Integer, Integer> timeToLiveSecondsFunction;

	/**
	 * sets cache name to be used.
	 *
	 * @param cache
	 *            the new cache
	 */
	public void setCache(Cache cache) {
		this.cache = cache;
	}

	/**
	 * Checks if required attributes are provided.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(cache, "A cache is required. Use setCache(Cache) to provide one.");
		logger.debug("[MethodCache] Current SpringMethodCacheInterceptor: " + this.hashCode());
	}

	/**
	 * main method caches method result if method is configured for caching
	 * method results must be serializable.
	 *
	 * @param invocation
	 *            the invocation
	 * @return the object
	 * @throws Throwable
	 *             the throwable
	 */
	public Object invoke(MethodInvocation invocation) throws Throwable {

		MethodCache methodCacheAnnotation = invocation.getMethod().getAnnotation(MethodCache.class);
		if (methodCacheAnnotation != null) {
			String targetName = invocation.getThis().getClass().getName();
			String methodName = invocation.getMethod().getName();
			Object[] arguments = invocation.getArguments();
			final String cacheKey = getCacheKey(targetName, methodName, arguments);

			// cache method results
			Element element = cache.get(cacheKey); // 99.99 percent of times the
													// element will exist

			if (element == null) {
				// ReadWriteLock rwLock = stripedRwLocks.get(cacheKey);
				ReadWriteLock rwLock = stripedRwLocks.getValue(cacheKey);
				Lock readLock = rwLock.readLock();

				readLock.lock();
				try {
					element = cache.get(cacheKey);
				} finally {
					readLock.unlock();
				}

				if (element == null) {
					Lock writeLock = rwLock.writeLock();

					writeLock.lock();
					try {
						element = cache.get(cacheKey);
						if (element == null) {
							if (logger.isTraceEnabled())
								logger.trace("[MethodCache] Data not found in cache for cacheKey: " + cacheKey);
							Object result = invocation.proceed();
							if (result != null || methodCacheAnnotation.cacheNullResult()) {
								element = new Element(cacheKey, result);

								int timeToLiveSeconds = methodCacheAnnotation.timeToLiveSeconds();
								int timeToIdleSeconds = methodCacheAnnotation.timeToIdleSeconds();
								String timeToLiveSecondsParamName = methodCacheAnnotation.timeToLiveSecondsParamName();
								String timeToIdleSecondsParamName = methodCacheAnnotation.timeToIdleSecondsParamName();

								// Parameter level cache expiry
								if (methodName.equals("getCachedValue")) {
									CacheExpiryParam cacheExpiryParam = getCacheExpiryParam(arguments);
									if (cacheExpiryParam != null) {
										if (cacheExpiryParam.timeToLiveSeconds > 0) {
											timeToLiveSeconds = cacheExpiryParam.timeToLiveSeconds;
										}
										if (cacheExpiryParam.timeToIdleSeconds > 0) {
											timeToIdleSeconds = cacheExpiryParam.timeToIdleSeconds;
										}
										timeToLiveSecondsParamName = cacheExpiryParam.timeToLiveSecondsParamName;
										timeToIdleSecondsParamName = cacheExpiryParam.timeToIdleSecondsParamName;
									}
								}

								if (timeToLiveSecondsFunction != null && timeToLiveSecondsParamName != null
										&& timeToLiveSecondsParamName.length() > 0) {
									timeToLiveSeconds = timeToLiveSecondsFunction.apply(timeToLiveSecondsParamName,
											timeToLiveSeconds);
								}

								if (timeToIdleSecondsFunction != null && timeToIdleSecondsParamName != null
										&& timeToIdleSecondsParamName.length() > 0) {
									timeToIdleSeconds = timeToIdleSecondsFunction.apply(timeToIdleSecondsParamName,
											timeToIdleSeconds);
								}

								if (timeToLiveSeconds > 0) {
									element.setTimeToLive(timeToLiveSeconds);
								}

								if (timeToIdleSeconds > 0) {
									element.setTimeToIdle(timeToIdleSeconds);
								}
								cache.put(element);

								return result;
							}
						}
					} finally {
						writeLock.unlock();
					}
				}
			}

			return element == null ? null : element.getObjectValue();
		} else if (invocation.getMethod().getAnnotation(InvalidateMethodCache.class) != null) {
			try {
				return invocation.proceed();
			} finally {
				// Clears every thing from cache whose keys starts with
				// targetName
				long startTime = System.currentTimeMillis();
				int cleardCount = 0;
				String targetName = invocation.getThis().getClass().getName() + ".";
				List<String> keys = cache.getKeys();
				if (keys != null) {
					for (String key : keys) {
						if (key.startsWith(targetName)) {
							cache.remove(key);
							cleardCount++;
						}
					}
				}
				logger.info("[MethodCache] Cleard cache for targetName: " + targetName + ", cleardCount: " + cleardCount
						+ ", took: " + (System.currentTimeMillis() - startTime) + "ms");
			}
		} else {
			// Results are not cachable, so proceed with normal invocation
			return invocation.proceed();
		}
	}

	/**
	 * creates cache key: targetName.methodName.argument0.argument1...
	 *
	 * @param targetName
	 *            the target name
	 * @param methodName
	 *            the method name
	 * @param arguments
	 *            the arguments
	 * @return the cache key
	 */
	private String getCacheKey(String targetName, String methodName, Object[] arguments) {

		StringBuilder sb = new StringBuilder();
		sb.append(targetName).append(".").append(methodName);

		if ((arguments != null) && (arguments.length != 0)) {
			for (int i = 0; i < arguments.length; i++) {
				if (arguments[i] == null) {
					sb.append(".").append(arguments[i]);
				} else if (arguments[i] instanceof String) {
					// To overcome issue where string value is same asprimitive
					// value
					sb.append(".str:").append(arguments[i]);
				} else {

					if (arguments[i] instanceof Collection) {
						for (Object obj : (Collection) arguments[i]) {
							sb.append(".").append(String.valueOf(obj));
						}
					} else if (arguments[i].getClass().isArray()) {
						if (arguments[i] instanceof long[]) {
							sb.append(".").append(Arrays.toString((long[]) arguments[i]));
						} else if (arguments[i] instanceof int[]) {
							sb.append(".").append(Arrays.toString((int[]) arguments[i]));
						} else if (arguments[i] instanceof short[]) {
							sb.append(".").append(Arrays.toString((short[]) arguments[i]));
						} else if (arguments[i] instanceof char[]) {
							sb.append(".").append(Arrays.toString((char[]) arguments[i]));
						} else if (arguments[i] instanceof byte[]) {
							sb.append(".").append(Arrays.toString((byte[]) arguments[i]));
						} else if (arguments[i] instanceof double[]) {
							sb.append(".").append(Arrays.toString((double[]) arguments[i]));
						} else if (arguments[i] instanceof float[]) {
							sb.append(".").append(Arrays.toString((float[]) arguments[i]));
						} else if (arguments[i] instanceof boolean[]) {
							sb.append(".").append(Arrays.toString((boolean[]) arguments[i]));
						} else if (arguments[i] instanceof Object[]) {
							for (Object obj : (Object[]) arguments[i]) {
								sb.append(".").append(obj);
							}
						} else {// not possible
							sb.append(".").append(arguments[i]);
						}
					} else if (arguments[i].getClass().getAnnotation(FunctionalInterface.class) != null) {
						sb.append(".").append(arguments[i].getClass().getName());
					} else if (arguments[i] instanceof Supplier) {
						sb.append(".").append(arguments[i].getClass().getName());
					} else if (ClassUtils.isPrimitiveOrWrapper(arguments[i].getClass())) {
						sb.append(".").append(arguments[i].getClass().getName()).append(":").append(arguments[i]);
					} else if (arguments[i] instanceof CacheExpiryParam) {
						sb.append(".").append(arguments[i].getClass().getName());
					} else {
						sb.append(".").append(arguments[i]);
					}
				}
			}
		}
		return sb.toString();
	}

	private CacheExpiryParam getCacheExpiryParam(Object[] arguments) {
		if ((arguments != null) && (arguments.length != 0)) {
			for (int i = 0; i < arguments.length; i++) {
				if (arguments[i] instanceof CacheExpiryParam) {
					return (CacheExpiryParam) arguments[i];
				}
			}
		}
		return null;
	}

	public void setTimeToIdleSecondsFunction(BiFunction<String, Integer, Integer> timeToIdleSecondsFunction) {
		this.timeToIdleSecondsFunction = timeToIdleSecondsFunction;
	}

	public void setTimeToLiveSecondsFunction(BiFunction<String, Integer, Integer> timeToLiveSecondsFunction) {
		this.timeToLiveSecondsFunction = timeToLiveSecondsFunction;
	}
}
