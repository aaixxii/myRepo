package com.nec.biomatcher.core.framework.web.filter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.web.session.UserSession;

/**
 * The Class AuthenticationFilter.
 *
 * @author Alvin Chua
 */
public class AuthenticationFilter implements Filter {
	/* CDI fixes */
	/** The log. */
	protected static final Logger log = Logger.getLogger(AuthenticationFilter.class);

	/** The filter config. */
	private FilterConfig filterConfig;

	/**
	 * Instantiates a new authentication filter.
	 */
	public AuthenticationFilter() {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		this.filterConfig = null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 * javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws java.io.IOException, javax.servlet.ServletException {

		String redirectPage = filterConfig.getInitParameter("redirect-page");
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		HttpSession session = ((HttpServletRequest) request).getSession(false);
		log.trace("[AuthenticationFilter] Session: " + session);

		String uri = request.getRequestURI();

		// login form is avaliable
		UserSession userSession = null;
		String loginUserId = null;

		if (session != null) {
			userSession = (UserSession) session.getAttribute(UserSession.attributeName);
		}

		if (userSession != null) {
			if (log.isDebugEnabled()) {
				log.debug("UserSessionFound");
			}
			loginUserId = userSession.getUserId();
		}

		if (loginUserId == null) {
			// get User Access Credential here
			RequestDispatcher requestDispatcher = request.getRequestDispatcher(redirectPage);

			if (requestDispatcher == null) {
				log.error("Page not available " + redirectPage);
				return;
			}
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			requestDispatcher.forward(request, response);
		} else {
			filterChain.doFilter(request, response);
		}
	}

	/**
	 * Gets the filter config.
	 *
	 * @return the filter config
	 */
	public FilterConfig getFilterConfig() {
		return filterConfig;
	}

	/**
	 * Sets the filter config.
	 *
	 * @param cfg
	 *            the new filter config
	 */
	public void setFilterConfig(FilterConfig cfg) {
		filterConfig = cfg;
	}
}
