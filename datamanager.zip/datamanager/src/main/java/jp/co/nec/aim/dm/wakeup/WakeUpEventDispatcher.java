package jp.co.nec.aim.dm.wakeup;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

import jp.co.nec.aim.dm.comm.CommunicationHelper;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Dispatcher of WakeUp Event
 * 
 * @author liuyq
 * 
 */
public class WakeUpEventDispatcher implements Runnable {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(WakeUpEventDispatcher.class);

	/** The thread pool Executor of wakeUp **/
	private final WakeUpThreadExecutor executor;
	private final int port; // UDP listen port
	private final Long unitId; // unitId
	private final CommunicationHelper helper; // helper of Communication
	private volatile DatagramSocket socket; // DatagramSocket
	private static final String ANY_IP = "0.0.0.0"; // accept any Address
	private static final int MAX_RECEIVE_SIZE = 2048; // max receive bytes size

	/**
	 * the WakeUpEventDispatcher default constructor
	 */
	public WakeUpEventDispatcher(int port, Long unitId,
			CommunicationHelper helper) {
		// Create UDP event handler thread pool
		this.executor = WakeUpThreadExecutor.getInstance();
		this.port = port;
		this.unitId = unitId;
		this.helper = helper;
		try {
			this.socket = new DatagramSocket(this.port,
					InetAddress.getByName(ANY_IP));
		} catch (SocketException | UnknownHostException e) {
			log.error("SocketException and UnknownHostException occurred "
					+ "when create instance of DatagramSocket");
		}
	}

	@Override
	public void run() {
		log.info("Ready to listening UDP wakeUp " + "port: {}.", port);
		final Thread t = Thread.currentThread();
		while (!t.isInterrupted()) {
			try {
				if (socket == null || socket.isClosed()) {
					log.warn("DatagramSocket is already closed");
					break;
				}

				final byte[] bytes = new byte[MAX_RECEIVE_SIZE];
				DatagramPacket receivePkg = new DatagramPacket(bytes,
						MAX_RECEIVE_SIZE);
				// This method blocks until a dataGram
				// is received.
				socket.receive(receivePkg);

				// convert byte array to String
				final String msg = new String(receivePkg.getData(),
						receivePkg.getOffset(), receivePkg.getLength());
				// bytes from MM or DM unit id is null return
				if (StringUtils.isBlank(msg)) {
					log.warn("Receive empty message from MM.");
					return;
				}

				log.info("Received notify message from MM." + msg);

				if (executor.isStoped()) {
					log.warn("Udp wakeup Thread pool already stoped..");
					break;
				}
				// Receive an UDP package
				executor.execute(new WakeUpWorker(msg, unitId, helper));

			} catch (Exception ex) {
				t.interrupt(); // interrupt the current thread
				log.error("Exception occurred when WakeUpEventDispatcher..", ex);
			}
		}
	}

	/**
	 * is the UDP port listening
	 * 
	 * @return is the UDP port listening
	 */
	public boolean isListening() {
		return (socket != null && !socket.isClosed());
	}

	/**
	 * close DatagramSocket
	 */
	public void closeSocket() {
		if (socket != null) {
			socket.close();
			socket = null;
		}
	}
}
