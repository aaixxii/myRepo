package jp.co.nec.aim.dm.comm;

import java.net.InetAddress;
import java.net.UnknownHostException;

import jp.co.nec.aim.dm.exception.DataManagerException;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;
import jp.co.nec.aim.dm.properties.Version;

import org.jboss.logging.NDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Communication worker <br>
 * 
 * 
 * @author liuyq
 * 
 */
public class CommunicationThread implements Runnable {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(CommunicationThread.class);

	private int sleepTime; // heartBeat interval
	private Long unitId; // DM unit id after enter
	private CommunicationHelper helper; // Communication Helper

	// private Date lastReportTime;

	/**
	 * CommunicationThread constructor
	 */
	public CommunicationThread() {
		DynamicProperties properties = DynamicProperties.getInstance();
		sleepTime = Integer.parseInt(properties
				.getPropertyValue(DynamicPropertyNames.SLEEP_TIME));

		String ipAddress = generateIPAddress();
		String uniqueId = "DM:" + ipAddress; // allow a DM and MU to be
												// collocated
		log.debug("uniqueId=" + uniqueId);

		String contactURL = getContactURL(ipAddress);
		log.info("DM contactURL=" + contactURL);

		String version = Version.getVersion();
		log.info("DM version=" + version);

		String urlBase = properties
				.getPropertyValue(DynamicPropertyNames.MM_URL_BASE);
		log.info("DM using MM url=" + urlBase);
		String enterURL = urlBase + "/Enter";
		String heartbeatURL = urlBase + "/HeartBeat";
		int soTimeOut = readSoTimeout();
		this.helper = new CommunicationHelper(uniqueId, urlBase, enterURL,
				heartbeatURL, contactURL, version, soTimeOut);
	}

	public void run() {
		try {						
			NDC.push("DM|COMM");
			while (true) {
				if (Thread.currentThread().isInterrupted()) {
					log.debug("Tested isInterrupted() and found that "
							+ "communication thread has been interrupted, exiting.");
					return;
				}
				synchronized (this) { // all changes to shared state accessible
					// in the view occur in here.
					if (unitId == null) {
						unitId = helper.sendEnter();
					}

					if (unitId != null) {
						if (helper.sendHeartbeat()) {
							unitId = null;
						}
					}
				}
				log.debug("SegmentCommunicator (muId {}) about to sleep",
						unitId);
				Thread.sleep(sleepTime);
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt(); // restore interrupted status
			// for code higher on call
			// stack.
			log.error("Communication Thread has been interrupted, exiting...");
		} catch (RuntimeException e) {
			log.error("RuntimeException in CommunicationThread", e);
		} finally {
			NDC.clear();
		}
	}

	/**
	 * get value of SO_TIME_OUT (socket timeout millisecond) from
	 * aim.dm.properties.
	 * 
	 * If SO_TIME_OUT entry is not found in the properties, set default 5000
	 * millisecond without error.
	 * 
	 * @return
	 */
	private int readSoTimeout() {
		int intSoTimeOut = 300000;
		try {
			String soTimeOut = DynamicProperties.getInstance()
					.getPropertyValue(DynamicPropertyNames.SO_TIME_OUT);
			intSoTimeOut = Integer.parseInt(soTimeOut);
			if (log.isDebugEnabled()) {
				log.debug("set default socket timeout is {}", intSoTimeOut);
			}
		} catch (Exception e) {
			log.warn("set default socket timeout is " + intSoTimeOut + ".\n"
					+ e.getMessage(), e);
		}
		return intSoTimeOut;
	}

	/**
	 * generate the IP Address
	 * 
	 * @return Ip address
	 */
	private String generateIPAddress() {
		String ip = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.DM_IP_ADDRESS, false);
		if (ip != null) {
			log.info("Using DM IP Address '" + ip + "' set in config file");
			return ip;
		} else {
			try {
				InetAddress addr = InetAddress.getLocalHost();
				ip = addr.getHostAddress();
				log.info("No DM IP Address set in config file, using detected IP '"
						+ ip + "'");
				return ip;
			} catch (UnknownHostException e) {
				throw new DataManagerException(e);
			}
		}
	}

	/**
	 * get ContactURL
	 * 
	 * @param ipAddress
	 *            IP address
	 * @return ContactURL
	 */
	private String getContactURL(String ipAddress) {
		DynamicProperties properties = DynamicProperties.getInstance();
		StringBuffer result = new StringBuffer();
		result.append("http://");
		result.append(ipAddress);
		result.append(":");
		result.append(properties.getPropertyValue(DynamicPropertyNames.PORT));
		// result.append(properties
		// .getPropertyValue(DynamicPropertyNames.CONTEXT_PATH));
		return result.toString();
	}

	/**
	 * send Exit event to MM
	 */
	public void sendExit() {
		if (helper == null) {
			log.warn("CommunicationHelper was not init..");
		}
		helper.sendExit();
	}

	/**
	 * release wakeUp related resource
	 */
	public void releaseWakeup() {
		if (helper == null) {
			log.warn("CommunicationHelper was not init..");
			return;
		} else {
			helper.close();
		}
	}

}
