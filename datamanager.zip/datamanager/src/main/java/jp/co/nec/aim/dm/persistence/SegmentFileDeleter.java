package jp.co.nec.aim.dm.persistence;

import java.io.File;

import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.exception.SegmentFileWritingException;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.manager.IndexManager;
import jp.co.nec.aim.dm.util.StopWatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SegmentFileDeleter implements SegmentFileWriter {

	private static final Logger log = LoggerFactory.getLogger(SegmentFileDeleter.class);

	public SegmentFileDeleter() {

	}

	public synchronized String getJobState() {
		return "(no details)";
	}

	@Override
	public SegmentFileWriteResult execute(int segmentId, Integer version) {
		return execute(segmentId);
	}

	private SegmentFileWriteResult execute(int segmentId) throws SegmentFileWritingException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		SegmentFileName segFileName = new SegmentFileName(segmentId);
		File f = new File(segFileName.getName());
		if (f.exists()) {
			boolean success = f.delete();
			if (success) {
				log.info("Successfully deleted segment file:" + segmentId);
				IndexManager.getInstance().removeIndex(segmentId);
			} else {
				log.error("Segment file deletion failed: " + segmentId);
			}
		} else {
			log.info("Skipping delete of segment file " + f.getName()
					+ " because file does not exist.");
		}

		stopWatch.stop();
		PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
				.getSimpleName(), LogConstants.FUNCTION_execute, stopWatch
				.elapsedTime());

		return SegmentFileWriteResult.constructDeleteResult();

	}

}
