package jp.co.nec.aim.dm.util;

import static jp.co.nec.aim.dm.domain.SumFileName.EXTENTION;

import java.io.File;
import java.io.IOException;
import java.util.List;

import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.domain.SumFileName;
import jp.co.nec.aim.dm.exception.SegmentFileWritingException;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SumFileUtil {
	private static final Logger log = LoggerFactory
			.getLogger(SumFileUtil.class);

	/**
	 * Returns true if 00000[segmentId].sum exists
	 * 
	 * @param segmentId
	 * @return
	 */
	public static boolean exists(int segmentId) {
		File sumFile = new File((new SumFileName(segmentId).getName()));
		return sumFile.exists();
	}

	/**
	 * Returns true if removing 00000[segmentId].sum, or it does not exist
	 * 
	 * @param segmentId
	 * @return
	 */
	public static boolean remove(int segmentId) {
		File sumFile = new File((new SumFileName(segmentId).getName()));
		if (sumFile.exists()) {
			if (sumFile.delete()) {
				return true;
			} else {
				return false;
			}
		} else {
			return true;
		}
	}

	public static void create(int segmentId) throws IOException {
		File sumFile = new File((new SumFileName(segmentId).getName()));
		FileUtils.writeStringToFile(sumFile, "");
	}

	/**
	 * Remove all .*.sum and *.seg file
	 */
	public static void removeSumAndSegment() {
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		// List all files which has "sum" extension , under dir includes sub
		// directory.
		List<File> fileList = (List<File>) FileUtils.listFiles(new File(dir),
				new String[] { EXTENTION.substring(1, EXTENTION.length()) },
				true);
		for (File sumFile : fileList) {
			log.warn("[{}] is found. It must be removed.", sumFile);
			String name = sumFile.getName();
			int index = name.indexOf(EXTENTION);
			Integer segmentId = Integer.valueOf(name.substring(1, index));
			SegmentFileName segFileName = new SegmentFileName(segmentId);
			File segFile = new File(segFileName.getName());
			if (segFile.exists()) {
				if (!segFile.delete()) {
					String message = name + " exists, but can't delete "
							+ segFileName.getName();
					log.error(message);
					throw new SegmentFileWritingException(message);
				}
			}
			if (sumFile.exists()) {
				if (!sumFile.delete()) {
					String message = name + " exists, but can't delete";
					log.error(message);
					throw new SegmentFileWritingException(message);
				}
			}
		}
	}

}
