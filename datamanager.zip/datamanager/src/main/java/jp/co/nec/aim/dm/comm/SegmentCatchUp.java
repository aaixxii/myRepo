package jp.co.nec.aim.dm.comm;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.dm.manager.SegmentFileManager;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncInfo;

/**
 * the common of SegmentCatchUp
 * 
 * @author liuyq
 * 
 */
public class SegmentCatchUp {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(SegmentCatchUp.class);

	private SegmentFileManager sfm; // segment file manage

	/**
	 * the constructor of SegmentCatchUp
	 */
	public SegmentCatchUp() {
		sfm = SegmentFileManager.getInstance();
	}

	/**
	 * CatchUp the segment
	 * 
	 * @param syncInfos
	 *            the list of PBSegmentSyncInfo
	 */
	public void segmentCatchUp(final List<PBSegmentSyncInfo> syncInfos) {
		if (syncInfos == null || syncInfos.isEmpty()) {
			log.debug("Without any PBSegmentSyncInfo. ");
			return;
		}

		for (final PBSegmentSyncInfo syncInfo : syncInfos) {
			if (!syncInfo.hasSyncItem()) {
				log.warn("Without any PBSegmetSyncItem . ");
				continue;
			}

			final long segmentId = syncInfo.getId(); // get segment id
			sfm.scheduleWrite((int) segmentId, syncInfo.getAssignedState());
		}
	}

}
