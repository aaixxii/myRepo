package jp.co.nec.aim.dm.util;

import static jp.co.nec.aim.dm.constants.DMConstants.SEG_FILE_EXTENSION;
import static jp.co.nec.aim.dm.domain.SumFileName.EXTENTION;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.List;

import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.domain.SumFileName;
import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Test;

public class SumFileUtilTest {
	@After
	public void after() {
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		// List all files which has "sum" extension , under dir includes sub
		// directory.
		List<File> sumFileList = (List<File>) FileUtils
				.listFiles(
						new File(dir),
				new String[] { EXTENTION.substring(1, EXTENTION.length()) },
				true);
		for (File sumFile : sumFileList) {
			sumFile.delete();
		}
		List<File> segFileList = (List<File>) FileUtils.listFiles(
				new File(dir), new String[] { SEG_FILE_EXTENSION.substring(1,
						SEG_FILE_EXTENSION.length()) }, true);
		for (File segFile : segFileList) {
			segFile.delete();
		}
	}

	@Test
	public void testExists() throws IOException {
		int segmentId = 1;
		SumFileName sumFileName = new SumFileName(new Integer(segmentId));
		File sumFile = new File(sumFileName.getName());
		assertFalse(sumFile.exists());
		assertFalse(SumFileUtil.exists(segmentId));
		FileUtils.writeStringToFile(sumFile, "");
		assertTrue(SumFileUtil.exists(segmentId));
	}

	@Test
	public void testCreate() throws IOException {
		int segmentId = 1;
		SumFileName sumFileName = new SumFileName(new Integer(segmentId));
		File sumFile = new File(sumFileName.getName());
		assertFalse(sumFile.exists());
		SumFileUtil.create(segmentId);
		assertTrue(sumFile.exists());
	}

	@Test
	public void testRemove() throws IOException {
		int segmentId = 1;
		SumFileName sumFileName = new SumFileName(new Integer(segmentId));
		File sumFile = new File(sumFileName.getName());
		FileUtils.writeStringToFile(sumFile, "");
		assertTrue(sumFile.exists());
		SumFileUtil.remove(segmentId);
		assertFalse(sumFile.exists());
	}

	/**
	 * Create segmetFile id=1,2,3,4 sumFile id=1,2,3
	 * SumFileUtil.removeSumAndSegments() removes id=1,2,3
	 * 
	 * @throws IOException
	 */
	@Test
	public void testRemoveSumAndSement() throws IOException {
		for (int segmentId = 1; segmentId <= 3; segmentId++) {
			createSumFile(segmentId);
		}
		for (int segmentId = 1; segmentId <= 4; segmentId++) {
			createSegFile(segmentId);
		}
		SumFileUtil.removeSumAndSegment();
		List<File> segFiles = findFiles("seg");
		assertEquals(1, segFiles.size());
		assertEquals("4.seg", segFiles.get(0).getName());
		List<File> sumFiles = findFiles("sum");
		assertEquals(0, sumFiles.size());
	}

	private List<File> findFiles(String extention) {
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		return (List<File>) FileUtils.listFiles(
				new File(dir), new String[] { extention }, true);
	}

	private File createSegFile(int segmentId) throws IOException {
		File segFile = new File(
				(new SegmentFileName(new Integer(segmentId))).getName());
		FileUtils.writeByteArrayToFile(segFile, new byte[] { 1, 2, 3, 4 });
		return segFile;
	}

	private File createSumFile(int segmentId) throws IOException {
		File sumFile = new File(
				(new SumFileName(new Integer(segmentId))).getName());
		FileUtils.writeStringToFile(sumFile, "");
		return sumFile;
	}

}
