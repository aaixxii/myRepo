/**
 * 
 */
package jp.co.nec.aim.dm.domain;

import static org.junit.Assert.assertEquals;

import org.junit.Ignore;
import org.junit.Test;

/**
 * @author RKumarak
 * 
 */
@Ignore
public class SegmentFileNameTest {

	/**
	 * Test method for
	 * {@link jp.co.nec.aim.dm.domain.SegmentFileName#SegmentFileName(jp.co.nec.aim.dm.domain.SegmentId)}
	 * .
	 */
	@Test
	public final void testSegmentFileName() {
		// fail("Not yet implemented"); // TODO

	}

	/**
	 * Test method for {@link jp.co.nec.aim.dm.domain.SegmentFileName#getName()}
	 * .
	 */
	@Test
	public final void testGetName() {
		// fail("Not yet implemented"); // TODO
		int id = 1345;
		String expected = new StringBuffer().append("C:/DM_SEGMENT_FILES/")
				.append(id).append(".seg").toString();
		SegmentFileName actual = new SegmentFileName(new Integer(id));
		assertEquals(expected, actual.getName());
	}

	/**
	 * Test method for
	 * {@link jp.co.nec.aim.dm.domain.SegmentFileName#getSegmentIdFromName(java.lang.String)}
	 * .
	 */
	@Test
	public final void testGetSegmentIdFromName() {
		int id = 1345;
		String name = new StringBuffer().append(id).append(".seg").toString();

		Integer expected = new Integer(id);
		assertEquals(expected, SegmentFileName.getSegmentIdFromName(name));
	}

}
