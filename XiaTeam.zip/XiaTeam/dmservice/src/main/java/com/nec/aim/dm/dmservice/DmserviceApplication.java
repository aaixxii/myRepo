package com.nec.aim.dm.dmservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.nec.aim.dm.dmservice.socket.HeartBeatSocketServer;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class DmserviceApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(DmserviceApplication.class, args);
		log.info("DM service success started");
		String socketPort = null;
		if (args.length == 3 && args[1] != null) {
			socketPort = args[1];
			HeartBeatSocketServer server = new HeartBeatSocketServer();
			server.start(Integer.valueOf(socketPort));
		} else if (args.length == 2 && args[0] != null) {
			socketPort = args[0];
			HeartBeatSocketServer server = new HeartBeatSocketServer();
			server.start(Integer.valueOf(socketPort));
		} else if (args.length == 1 && args[0] != null) {
			socketPort = args[0];
			try {
				int port = Integer.valueOf(socketPort);
				HeartBeatSocketServer server = new HeartBeatSocketServer();
				server.start(port);
			} catch (NumberFormatException e) {
			}
		}
	}
}
