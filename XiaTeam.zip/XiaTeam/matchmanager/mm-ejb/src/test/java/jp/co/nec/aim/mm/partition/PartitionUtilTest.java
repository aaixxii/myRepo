
package jp.co.nec.aim.mm.partition;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;

/**
 * @author xia
 *
 */
public class PartitionUtilTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}
	
	public  long caculateHashAtThisToday(LocalDate thisDay) {
	
		Long saveDays = 7L;
		Long adjust = 0L;
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + adjust.longValue()) % (saveDays.longValue());
	}	
	
	public  long caculateNewHashAtThisToday(Long newSaveDays, Long newAdust, LocalDate thisDay) {		
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + newAdust.longValue()) % (newSaveDays.longValue());
	}
	
	public long caculateNewAdjustAtThisDay(Long newN, Long oldSaveDays, LocalDate firstAddDay) {
		//Long oldSaveDays = systemInitDao.getSegChangeLogSaveDays();		
		long firstAddDayHashValue = caculateHashAtThisToday(firstAddDay);		
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstAddDay);
		long quotient = epochDays/oldSaveDays;
		long deltaX = oldSaveDays * quotient + firstAddDayHashValue - epochDays;
		long X = (epochDays + deltaX) % oldSaveDays;
		long Y = epochDays % newN;		
		long adjustNew = (X - Y + newN) % newN;			
		return adjustNew;
		//long hashNew = (epochDays + adjustNew) % newN;
	}

	
	@Test
	public void testCaculateHashAtThisToday() {	
		LocalDate day = LocalDate.now().plusDays(5);
		long hashValue = caculateHashAtThisToday(day);
		System.out.println(hashValue);		
	}
	
	@Test
	public void caculateNewAdjustAtThisDayBySu() {		
		long adjust = 0;
		long N = 7l;
		long Nnew = 5l;
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch,  LocalDate.now().plusDays(2));		
		long X = (epochDays + adjust)%N;
		long Y = (epochDays)%Nnew;
		long newAdjust = (X-Y+ Nnew)% Nnew;
		System.out.println(newAdjust);		
	}

	
	@Test
	public void testCaculateNewHashAtThisToday() {
		long newAdjuest = caculateNewAdjustAtThisDay(5l, 7l, LocalDate.now().plusDays(0));
		System.out.println(newAdjuest);
	}
	
	

	
	@Test
	public void testCaculateNewAdjustAtThisDay() {
		
	}

}
