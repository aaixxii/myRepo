package jp.co.nec.aim.mm.constants;

public enum UidReasonCode {
	SUCESS("0","sucess"),
	INTERNL_ERR("1", "unknown internal error"),
	ABORTED("2", "aborted"),
	INVALID_REQUEST_XML("3", "invalid reqeust xml error"),
	INVALID_REQUEST_PARAMETER("4", "invalid reqeust Parameter value invalid"),
	INVALID_REQUEST_REFERENCE_ID_DUPLICATE("5", "invalid reqeust referenceId already in use "),
	INVALID_REQUEST_REFERENCE_ID_NOT_FOUND("6", "invalid reqeust referenceId not in use "),
	UNEXPECTED_BIOMETRIC_DATA("7","unexpected error – unable to access biometric data "),
	INVALID_ABIS_STATUS("8","Unable to perform request"),
	SIMULTANEOUS_INSERT_REQUEST_ERROR("8","Unable to process the request as there are simultaneous Insert Requests");
	
	
	private String uidCode;
	private String errMessage;	
	
	UidReasonCode(String uidCode, String errMessage) {
		this.uidCode = uidCode;
		this.errMessage = errMessage;		
	}

	public String getUidCode() {
		return uidCode;
	}

	public void setUidCode(String uidCode) {
		this.uidCode = uidCode;
	}

	public String getErrMessage() {
		return errMessage;
	}

	public void setErrMessage(String errMessage) {
		this.errMessage = errMessage;
	}
}
