package jp.co.nec.aim.mm.acceptor.service;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.hazelcast.HazelcastService;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimInquiryRemoveService implements AimInquiryRemote {
	
	private static Logger log = LoggerFactory.getLogger(AimInquiryRemoveService.class);
	
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	
	@EJB
	private Inquiry inquiry;
	
	
	
	public AimInquiryRemoveService() {
		// zero-arg ctor for container.
	}

	@PostConstruct
	public void init() {		
	}
	
	@Override
	public void getExtResAndDoInquriy(RemoteJobItem inqJobInfo) {
		Long feJobId = inqJobInfo.getFeJobId();
		//String requestId = inqJobInfo.getRequestId();		
		//String inqRequest = inqJobInfo.getRequst();
		Optional<PBMuExtractJobResultItem> onejobResult = Optional.ofNullable(HazelcastService.getInstance().getExtractJobResult(feJobId.toString()));
		if (onejobResult.isPresent()) {
			log.info("Get PBMuExtractJobResultItem for identify feJobId({}) result success", feJobId);
			AimManager.saveToExtractJobResutQueue(String.valueOf(feJobId), onejobResult.get()); 
		} else {
			log.warn("Got empty PBMuExtractJobResultItem, key={}", feJobId);		
		}
	}
}
