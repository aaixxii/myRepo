package jp.co.nec.aim.mm.scheduler;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.sessionbeans.PollBean;
import jp.co.nec.aim.mm.util.JndiLookup;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class MMHeartBeatSchedulable implements Job {

	private static final Logger log = LoggerFactory
			.getLogger(MMHeartBeatSchedulable.class);

	public PollBean pollBean;

	public MMHeartBeatSchedulable() {
		pollBean = JndiLookup.lookUp(JNDIConstants.POLLBEAN, PollBean.class);
	}

	@Override
	public void execute(JobExecutionContext context)
			throws JobExecutionException {
		if (log.isDebugEnabled()) {
			log.debug("MMHeartBeatSchedulable start...");
		}
		pollBean.updateHeartBeatTS();
		if (log.isDebugEnabled()) {
			log.debug("MMHeartBeatSchedulable end...");
		}
	}

}
