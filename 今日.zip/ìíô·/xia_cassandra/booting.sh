#!/bin/bash

docker-compose exec cassandra-1 cqlsh cassandra-1 -f /home/cassandra/cassandra_init.cql
sleep 2

docker-compose exec megha /home/megha/wildfly-9.0.2.Final/start-server.sh
