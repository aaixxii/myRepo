package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.entities.InquiryTrafficEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class CompleteJobProcedureTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	private InquiryJobDao inquiryjobdao;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private CompleteJobProcedure completejobprocedure;

	@Before
	public void setUp() throws Exception {
		completejobprocedure = new CompleteJobProcedure(ds);
		inquiryjobdao = new InquiryJobDao(entityManager);
		jdbcTemplate.execute("delete from job_queue");
		prepareData();
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from job_queue");
	}

	@Test
	public void testAction_faild_true() {
		byte[] result = "101101010".getBytes();
		boolean failed = true;
		long jobId = 20;
		String xml = "101101010";	
		
		Integer count = jdbcTemplate.queryForObject("select JOB_COMPLETE_COUNT from INQUIRY_TRAFFIC", Integer.class);
		
	 completejobprocedure.action(jobId, xml, result, failed);
		JobQueueEntity jobQueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(20, jobQueue.getJobId());
		assertEquals(JobState.DONE, jobQueue.getJobState());
		assertNotNull(jobQueue.getResultsTS());
		assertEquals(true, jobQueue.getFailedFlag());
		Integer newCount = jdbcTemplate.queryForObject("select JOB_COMPLETE_COUNT from INQUIRY_TRAFFIC", Integer.class);
		assertEquals(count.intValue() + 1, newCount.intValue());
		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
				.getInquiryTraffic(jobId);
		assertEquals(jobQueue.getFamilyId(), inquiryTraffic.getFamilyId());
		assertEquals("MI", inquiryTraffic.getFamilyName());
		
	}
	
	@Test
	public void testAction_faild_false() {
		byte[] result = "101101010".getBytes();
		boolean failed = false;
		long jobId = 20;
		String xml = "101101010";	
		Integer count = jdbcTemplate.queryForObject("select JOB_COMPLETE_COUNT from INQUIRY_TRAFFIC", Integer.class);
		
	 completejobprocedure.action(jobId, xml, result, failed);
		JobQueueEntity jobQueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(20, jobQueue.getJobId());
		assertEquals(JobState.DONE, jobQueue.getJobState());
		assertNotNull(jobQueue.getResultsTS());
		assertEquals(false, jobQueue.getFailedFlag());
		Integer newCount = jdbcTemplate.queryForObject("select JOB_COMPLETE_COUNT from INQUIRY_TRAFFIC", Integer.class);
		assertEquals(count.intValue() + 1, newCount.intValue());
		InquiryTrafficEntity inquiryTraffic = inquiryjobdao
				.getInquiryTraffic(jobId);
		assertEquals(jobQueue.getFamilyId(), inquiryTraffic.getFamilyId());
		assertEquals("MI", inquiryTraffic.getFamilyName());
		
	}
	
	private void prepareData() {
		jdbcTemplate.update("INSERT INTO JOB_QUEUE(JOB_ID,UIDAI_REQUEST_ID, PRIORITY,JOB_STATE,SUBMISSION_TS,FAILED_FLAG,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID) "
				+ "VALUES(20,'test',5,1,123,1,0,123,0,0,1)");
		
	}

}
