package jp.co.nec.aim.mm.dm.client;

import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.squareup.okhttp.Call;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncRequest;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncResponce;
import jp.co.nec.aim.mm.dm.client.mgmt.UidDmJobRunManager;
import jp.co.nec.aim.mm.sessionbeans.SystemInitializationBean;
import jp.co.nec.aim.mm.util.JndiLookup;
import jp.co.nec.aim.mm.util.StopWatch;

public class DmJobPoster {
	private static Logger logger = LoggerFactory.getLogger(DmJobPoster.class);
	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");

	public static Boolean post(String url, PBDmSyncRequest dmSegReq) {
		Callable<Boolean> newPostTask = () -> {
			String cmmd = dmSegReq.getCmd().name().toLowerCase();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dmSegReq.toByteArray())).build();
			try {
				Response response = client.newCall(request).execute();
				t.stop();
				logger.info("Post PBDmSyncRequest(segmentId={}) to {} used time={} and status={}",
						dmSegReq.getTargetSegment().getId(), url, t.elapsedTime(), response.code());
				PBDmSyncResponce dmRes = PBDmSyncResponce.parseFrom(response.body().bytes());
				Boolean jobResult = Boolean.valueOf(dmRes.getSuccess());
				logger.info(
						"Post PBDmSyncRequest(cmd= {} segmentId={}) to {} used time={}, and status={} job success is {}",
						cmmd, dmSegReq.getTargetSegment().getId(), url, t.elapsedTime(), response.code(), jobResult);
				return jobResult;
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				return Boolean.valueOf(false);
			}
		};
		try {
			return UidDmJobRunManager.submit(newPostTask);
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
	}

	public static Boolean tryPostToDM(String requestId, PBDmSyncRequest dmSegReq) {
		String lastDmUrl = UidDmJobRunManager.getLastActiveDmUrl();
		if (lastDmUrl != null) {
			lastDmUrl = lastDmUrl.endsWith("/") ? lastDmUrl : lastDmUrl + "/";
			lastDmUrl = lastDmUrl + jp.co.nec.aim.mm.constants.Constants.dmSync;
			AtomicBoolean fSbResult = new AtomicBoolean();
			int lastIndex = UidDmJobRunManager.getLastDM().get();
			int fResult = DmJobPoster.postByOneDm(lastDmUrl, dmSegReq, fSbResult, lastIndex);
			if (fResult >= 0) {
				UidDmJobRunManager.updateDmList(lastIndex, 0);
				return Boolean.valueOf(fSbResult.get());
			} else {
				UidDmJobRunManager.updateDmList(lastIndex, -1);
			}
		}

		DmIndexInfo[] dmList = UidDmJobRunManager.getDM_LIST();
		java.util.List<DmIndexInfo> tmpDmList = Arrays.asList(dmList);
		Collections.shuffle(tmpDmList);
		Collections.sort(tmpDmList, new DmIndexInfo());
		for (int i = 0; i < dmList.length; i++) {
			String dmUrl = dmList[i].getUrl();
			if (dmUrl != null) {
				dmUrl = dmUrl.endsWith("/") ? dmUrl : dmUrl + "/";
				dmUrl = dmUrl + jp.co.nec.aim.mm.constants.Constants.dmSync;
				AtomicBoolean sbResult = new AtomicBoolean();
				int postResult = DmJobPoster.postByOneDm(dmUrl, dmSegReq, sbResult, i);
				if (postResult >= 0) {
					UidDmJobRunManager.setLastDM(i);
					UidDmJobRunManager.updateDmList(i, 0);
					return Boolean.valueOf(sbResult.get());
				} else {
					UidDmJobRunManager.updateDmList(i, -1);
				}
			}
		}
		logger.warn("Try post to all dms are failed, dmCount:{}, reload dm from db", dmList.length);
		SystemInitializationBean initEjb = JndiLookup.lookUp(
				jp.co.nec.aim.mm.constants.JNDIConstants.SystemInitializationBean, SystemInitializationBean.class);
		initEjb.getDmServiceSetting();
		return Boolean.valueOf(false);
	}

	public static int postByOneDm(String url, PBDmSyncRequest dmSegReq, final AtomicBoolean sbResult, int lastDm) {
		Callable<Integer> newPostTask = () -> {
			String cmmd = dmSegReq.getCmd().name().toLowerCase();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dmSegReq.toByteArray())).build();
			try {
				Response response = client.newCall(request).execute();
				t.stop();
				logger.info("Post PBDmSyncRequest(segmentId={}) to {} used time={} and status={}",
						dmSegReq.getTargetSegment().getId(), url, t.elapsedTime(), response.code());
				PBDmSyncResponce dmRes = PBDmSyncResponce.parseFrom(response.body().bytes());
				sbResult.set(dmRes.getSuccess());
				logger.info(
						"Post PBDmSyncRequest(cmd= {} segmentId={}) to {} used time={}, and status={} job success is {}",
						cmmd, dmSegReq.getTargetSegment().getId(), url, t.elapsedTime(), response.code(),
						sbResult.get());
				return lastDm;
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				return -1;
			}
		};
		try {
			return UidDmJobRunManager.submitAndReturnInteger(newPostTask);
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return -1;
		}
	}

	public static byte[] getTemplate(String url, String refId) throws InterruptedException, ExecutionException {

		String getUrl = url + "/?refId=" + refId;
		Callable<byte[]> newGetTask = () -> {
			final StopWatch t = new StopWatch();
			t.start();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			if (response.code() == 200) {
				logger.info("Send getTemplate request(refId={}) to {} used time={} and status={}", refId, getUrl,
						t.elapsedTime(), response.code());
				return response.body().bytes();
			} else {
				logger.warn("Faild to get template data from dm cluster, sendUrl={} refId={} and status={}", getUrl,
						refId, response.code());
				return null;
			}
		};
		return UidDmJobRunManager.submitGetRequest(newGetTask);
	}

	public static byte[] tryGetTemplateFromDm(Long segId, Long bioId) throws InterruptedException, ExecutionException {
		String lastDmUrl = UidDmJobRunManager.getLastActiveDmUrl();
		if (lastDmUrl != null) {
			lastDmUrl = lastDmUrl.endsWith("/") ? lastDmUrl : lastDmUrl + "/";
			lastDmUrl = lastDmUrl + jp.co.nec.aim.mm.constants.Constants.dmGetTemplate;		
			TemplateDataWrapper fSbResult = new TemplateDataWrapper();
			int lastDmIndex = UidDmJobRunManager.getLastDM().get();
			int fResult = DmJobPoster.getTemplateByOneDm(lastDmUrl, segId, bioId, lastDmIndex, fSbResult);
			if (fResult >= 0) {
				UidDmJobRunManager.updateDmList(lastDmIndex, 0);
				logger.info("Post to lastDmUrl={} successed", lastDmUrl);
				return fSbResult.getTemplate();
			} else {
				UidDmJobRunManager.updateDmList(lastDmIndex, -1);
			}
		}

		DmIndexInfo[] dmList = UidDmJobRunManager.getDM_LIST();
		java.util.List<DmIndexInfo> tmpDmList = Arrays.asList(dmList);
		Collections.shuffle(tmpDmList);
		Collections.sort(tmpDmList, new DmIndexInfo());
		for (int i = 0; i < dmList.length; i++) {
			String dmUrl = dmList[i].getUrl();
			if (dmUrl != null) {
				dmUrl = dmUrl.endsWith("/") ? dmUrl : dmUrl + "/";
				dmUrl = dmUrl + jp.co.nec.aim.mm.constants.Constants.dmGetTemplate;				
				TemplateDataWrapper sbResult = new TemplateDataWrapper();
				int postResult = DmJobPoster.getTemplateByOneDm(dmUrl, segId, bioId, i, sbResult);
				if (postResult >= 0) {
					UidDmJobRunManager.setLastDM(i);
					UidDmJobRunManager.updateDmList(i, 0);
					logger.info("Post to dmUrl={} successed", dmUrl);					
					return sbResult.getTemplate();
				} else {
					UidDmJobRunManager.updateDmList(i, -1);
				}
			}
		}
		logger.warn("Try get template from all dms are failed, dmCount:{}, reload dm from db", dmList.length);
		SystemInitializationBean initEjb = JndiLookup.lookUp(
				jp.co.nec.aim.mm.constants.JNDIConstants.SystemInitializationBean, SystemInitializationBean.class);
		initEjb.getDmServiceSetting();
		return null;
	}

	public static Integer getTemplateByOneDm(String url, Long segId, Long bioId, int dmIndex,
			final TemplateDataWrapper templateWapper) throws InterruptedException, ExecutionException {
		String getUrl = url + "/?segId=" + segId + "&bioId=" + bioId;
		
		Callable<Integer> newGetTask = () -> {
			final StopWatch t = new StopWatch();
			t.start();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);
			Request request = new Request.Builder().get().url(getUrl).build();
			try {
				Call call = client.newCall(request);
				Response response = call.execute();
				t.stop();
				logger.info("Send getTemplate request(segId={}, bioId={}) to {} used time={} and status={}", segId,
						bioId, getUrl, t.elapsedTime(), response.code());
				templateWapper.setTemplate(response.body().bytes());
				return Integer.valueOf(dmIndex);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				return Integer.valueOf(-1);
			}
		};
		return UidDmJobRunManager.submitGetRequestByOne(newGetTask);
	}

	public static byte[] getTemplate(String url, Long segId, Long bioId)
			throws InterruptedException, ExecutionException {
		String getUrl = url + "/?segId=" + segId + "&bioId=" + bioId;
		Callable<byte[]> newGetTask = () -> {
			final StopWatch t = new StopWatch();
			t.start();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			if (response.code() == 200) {
				logger.info("Send getTemplate request(segId={}, bioId={}) to {} used time={} and status={}", segId,
						bioId, getUrl, t.elapsedTime(), response.code());
				return response.body().bytes();
			} else {
				logger.warn("Faild to get template data from dm cluster, sendUrl={} segId={}  bioId = {} and status={}",
						getUrl, segId, bioId, response.code());
				return null;
			}
		};
		return UidDmJobRunManager.submitGetRequest(newGetTask);
	}

	public static byte[] getSegment(String getUrl, Long segId) throws InterruptedException, ExecutionException {
		Callable<byte[]> newGetTask = () -> {
			final StopWatch t = new StopWatch();
			t.start();
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(10, TimeUnit.SECONDS);
			client.setReadTimeout(10, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			if (response.code() == 200) {
				logger.info("Send getSegment request(segmentId={}) to {} used time={} and status={}", segId, getUrl,
						t.elapsedTime(), response.code());
				return response.body().bytes();
			} else {
				logger.warn("Faild to get segment data from dm cluster, sendUrl={} segmentId={} and status={}", getUrl,
						segId, response.code());
				return null;
			}
		};
		return UidDmJobRunManager.submitGetRequest(newGetTask);
	}
}
