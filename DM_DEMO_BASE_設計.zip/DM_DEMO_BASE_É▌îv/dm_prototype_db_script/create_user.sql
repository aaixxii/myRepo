#create dmdb user

CREATE USER 'dmuser'@'%' IDENTIFIED BY 'dmuser@SV02';
GRANT ALL PRIVILEGES ON *.* TO 'dmuser'@'%' WITH GRANT OPTION;
flush privileges;

