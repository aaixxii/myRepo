package com.nec.aim.uid.client.post;

import static com.nec.aim.uid.client.common.UidClientConstants.DM_CONCURRENT_COUNT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_SERVICES_URLS;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_POST_TIMEOUT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_WEB_CONTENT;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_TEMPLATES_PATH;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.proerties.PropertyNames;
import com.nec.aim.uid.client.util.FileUtil;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;

public class DmJobPoster {
	private static Logger logger = LoggerFactory.getLogger(DmJobPoster.class);
	private static int postTimeOut = 6000;
	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");	
	
	public static void addJobToDm(List<String> fileList) {
		String concurentJobCount = UidCommonManager.getValue(DM_CONCURRENT_COUNT);
		String userPostTimeOut = UidCommonManager.getValue(DM_POST_TIMEOUT);
		if (userPostTimeOut != null &&  !userPostTimeOut.isEmpty()) {
			postTimeOut = Integer.valueOf(userPostTimeOut);
		}
		if (fileList.size() == 1 && concurentJobCount != null && Integer.valueOf(concurentJobCount) > 0) {
			for (int i = 0; i< Integer.valueOf(concurentJobCount); i++) {
				 buildDmJobRequest(fileList.get(0));
			}
		} else {
			for (String one : fileList) {
				 buildDmJobRequest(one);
			}
		}		
	}
	
	private static void buildDmJobRequest(String dmRequestFile) {
		Properties prop = new Properties();
		PBDmSyncRequest.Builder dmRequest = PBDmSyncRequest.newBuilder();
		try (InputStream input = new FileInputStream(dmRequestFile)) {
			prop.load(input);
			String dmWebContent = UidCommonManager.getValue(DM_WEB_CONTENT);
			String dmIpAndport = UidCommonManager.getValue(DM_SERVICES_URLS);
			String[] urlArr = dmIpAndport.split(",");
			//Collections.shuffle(Arrays.asList(urlArr));
			String dmUrl = "http://" + urlArr[0] + "/" + dmWebContent + "/dmSyncSegment";
			String dmDownLoadUrl = "http://" + urlArr[0] + "/" + dmWebContent + "/seg/";
						
			String dmReqCmd = prop.getProperty(PropertyNames.DM_REQ_CMD.name());
			if (dmReqCmd != null &&!dmReqCmd.isEmpty() && !dmReqCmd.equals("-1")) {
			    if (String.format(dmReqCmd).startsWith("INSERT")) {
			        dmRequest.setCmd(SegmentSyncCommandType.valueOf(1));
			    } else if (String.format(dmReqCmd).startsWith("DELETE")) {
			        dmRequest.setCmd(SegmentSyncCommandType.valueOf(2));
			    }				
			}
			String dmReqBioId = prop.getProperty(PropertyNames.DM_REQ_BIO_ID.name());
			if (dmReqBioId != null && !dmReqBioId.isEmpty() && !dmReqBioId.equals("-1")) {
				dmRequest.setBioId(Long.valueOf(dmReqBioId));
			}
			PBTemplateInfo.Builder templateInfo = PBTemplateInfo.newBuilder();
			String dmReqExternalId = prop.getProperty(PropertyNames.DM_REQ_REF_ID.name());
			if (!dmReqExternalId.isEmpty() && !dmReqExternalId.equals("-1")) {
				templateInfo.setReferenceId(dmReqExternalId);
			}
			String dmReqTemplatePath = prop.getProperty(PropertyNames.DM_REQ_TEMPLATE_DATA_PATH.name());
			if (dmReqTemplatePath == null || dmReqTemplatePath.isEmpty() || dmReqTemplatePath.equals("-1")) {
				String templatePath = UidCommonManager.getValue(JOB_TEMPLATES_PATH);
				File templateDir = new File(templatePath);
				String[] files = templateDir.list();
				 byte[] data = FileUtil.getDataFromFile(templatePath + "/" + files[0]);				 
				 templateInfo.setData(ByteString.copyFrom(data));
				 logger.info("Get template data from default path:{}", templatePath);
			} else if (!dmReqTemplatePath.isEmpty()) {
				 byte[] data = FileUtil.getDataFromFile(dmReqTemplatePath);		          
				 templateInfo.setData(ByteString.copyFrom(data));
				 logger.info("Get template data from  path:{}", dmReqTemplatePath);
			}
			dmRequest.setTemplateData(templateInfo.build());
			
			PBTargetSegmentVersion.Builder segVerBuilder = PBTargetSegmentVersion.newBuilder();
			String dmReqSegVer = prop.getProperty(PropertyNames.DM_REQ_SEG_VER.name());
			if (dmReqSegVer != null && !dmReqSegVer.isEmpty() && !dmReqSegVer.equals("-1")) {				
				segVerBuilder.setVersion(Long.valueOf(dmReqSegVer));				
			}
			String dmReqSegId = prop.getProperty(PropertyNames.DM_REQ_SEG_ID.name());
			if (dmReqSegId != null && !dmReqSegId.isEmpty() && !dmReqSegId.equals("-1")) {
				segVerBuilder.setId(Long.valueOf(dmReqSegVer));
			}
			
			dmRequest.setTargetSegments(segVerBuilder);
			Boolean result = post(dmUrl, dmRequest.build());
			logger.info("Success send dm request to DM cluster.");
			logger.info("Get response from dm,result ={}", result);
			
			String dmDownloadSegId = prop.getProperty(PropertyNames.DM_DOWNLOAD_SEG_ID.name());
			if (dmDownloadSegId != null && !dmDownloadSegId.isEmpty() && !dmDownloadSegId.equals("-1")) {
				byte[] downloaded = getSegment(dmDownLoadUrl, Long.valueOf(dmDownloadSegId));
				if (downloaded != null) {
					logger.info("Download segmentData from dm , data size  ={}", downloaded.length);
				}
			}

		} catch (Exception e) {
			throw new UidClientException(e.getMessage(), e);
		} finally {
			prop.clear();
			prop = null;
		}
	}

	public static Boolean post(String url, PBDmSyncRequest dmSegReq) {
		Callable<Boolean> newPostTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setReadTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setWriteTimeout(postTimeOut / 2, TimeUnit.MILLISECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dmSegReq.toByteArray())).build();
			try {
				Response response = client.newCall(request).execute();				
				t.stop();
				logger.info("Post PBDmSyncRequest(bioId={}) to {} used time={}, and status={}", dmSegReq.getBioId(),
						url, t.elapsedTime(), response.code());
				 PBDmSyncResponce dmRes = PBDmSyncResponce.parseFrom(response.body().bytes());
				 return Boolean.valueOf(dmRes.getSuccess());				
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				return Boolean.valueOf(false);
			}
		};
		try {
			return UidDmJobRunManager.submit(newPostTask);
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
	}

	public static byte[] getSegment(String getUrl, Long segId) throws InterruptedException, ExecutionException {
		Callable<byte[]> newGetTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setReadTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setWriteTimeout(postTimeOut / 2, TimeUnit.MILLISECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			logger.info("Post getSegment request(segmentId={}) to {} used time={}, and status={}", segId,
					getUrl, t.elapsedTime(), response.code());
			if (response.isSuccessful()) {
				 return response.body().bytes();
			} else {
				return null;
			}			
		};		
		return UidDmJobRunManager.submitGetRequest(newGetTask);		
	}
}
