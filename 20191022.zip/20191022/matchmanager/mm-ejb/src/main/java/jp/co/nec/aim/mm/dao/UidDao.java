package jp.co.nec.aim.mm.dao;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.Map;

import javax.sql.DataSource;
import javax.sql.rowset.serial.SerialException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

public class UidDao {	
	private DataSource dataSource;
	private static Logger logger = LoggerFactory.getLogger(UidDao.class);
	private String newFeJobSql = "match_manager_api.create_new_fe_job";
	private String newBatchJobInfoSql = "match_manager_api.create_new_batch_job_info";
	
	public UidDao(DataSource dataSource) {
		this.dataSource = dataSource;		
	}
	
	public long createNewFeJob(String externalId, byte[] payload) throws SerialException, SQLException {
		Blob blob = new javax.sql.rowset.serial.SerialBlob(payload);
		SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource).withFunctionName(newFeJobSql)
				.declareParameters(new SqlParameter("p_exteral_id", java.sql.Types.BIGINT),
						new SqlParameter("p_payload", java.sql.Types.BLOB),
						 new SqlOutParameter("l_fe_job_id", java.sql.Types.BIGINT));
		SqlParameterSource in = new MapSqlParameterSource()
				.addValue("p_exteral_id", externalId)
				.addValue("p_payload", blob);		    
		Map<String,Object> out = jdbcCall.execute(in);	   
		long feJobId = (long) out.get("l_fe_job_id");
		return feJobId;		
	}
	
	public String createNewBatchJobInfo(long batchJobId, String reqesutId, String batchType, long feJobId) {
		SimpleJdbcCall jdbcCall = new SimpleJdbcCall(dataSource).withFunctionName(newBatchJobInfoSql)
				.declareParameters(new SqlParameter("p_batch_job_id", java.sql.Types.BIGINT),
						new SqlParameter("p_reqeust_id", java.sql.Types.VARCHAR),
						new SqlParameter("p_batch_type", java.sql.Types.VARCHAR),
						new SqlParameter("p_fe_job_id", java.sql.Types.BIGINT),
						 new SqlOutParameter("l_rtn", java.sql.Types.VARCHAR));
		SqlParameterSource in = new MapSqlParameterSource()
				.addValue("p_batch_job_id", batchJobId)
				.addValue("p_reqeust_id", reqesutId)
				.addValue("p_batch_type", batchType)
				.addValue("p_fe_job_id", feJobId);
		Map<String,Object> out = jdbcCall.execute(in);	   
		String ok = (String) out.get("l_rtn");
		return ok;
		
	}
			

}
