package jp.co.nec.aim.mm.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.JobState;

@Entity
@Table(name = "JOB_QUEUE")
public class JobQueueEntity {

	@Id
	@SequenceGenerator(name = "jobqueue_generator", sequenceName = "JOB_QUEUE_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "jobqueue_generator")
	@Column(name = "JOB_ID")
	private long jobId;

	@Column(name = "ASSIGNED_TS")
	private Long assignedTs;

	@Column(name = "CALLBACK_STYLE")
	@Enumerated(EnumType.ORDINAL)
	private CallbackStyle callbackStyle;

	@Column(name = "CALLBACK_URL")
	private String callbackUrl;

	@Column(name = "DYNTHRESH_PERCENTAGE_POINT")
	private Double percentagePoint;

	@Column(name = "DYNTHRESH_HIT_THRESHOLD")
	private Integer hitThreshold;

	@Column(name = "FAILED_FLAG")
	private Boolean failedFlag;

	@Column(name = "FAILURE_COUNT")
	private int failureCount;

	@Column(name = "JOB_STATE")
	@Enumerated(EnumType.ORDINAL)
	private JobState jobState;

	@Column(name = "MAX_CANDIDATES")
	private Integer maxCandidates;

	@Column(name = "PRIORITY")
	private int priority;

	@Column(name = "REMAIN_JOBS")
	private int remainJobs;

	@Column(name = "\"RESULT\"")
	private byte[] results;

	@Column(name = "RESULT_TS")
	private Long resultsTS;

	@Column(name = "SUBMISSION_TS")
	private long submissionTS;

	@Column(name = "TIMEOUTS")
	private int timeouts;

	@Column(name = "FAMILY_ID")
	private int familyId;

	public long getJobId() {
		return jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public JobState getJobState() {
		return jobState;
	}

	public void setJobState(JobState jobState) {
		this.jobState = jobState;
	}

	public byte[] getResults() {
		return results;
	}

	public void setResults(byte[] results) {
		this.results = results;
	}

	public Boolean getFailedFlag() {
		return failedFlag;
	}

	public void setFailedFlag(Boolean failedFlag) {
		this.failedFlag = failedFlag;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public Long getResultsTS() {
		return resultsTS;
	}

	public void setResultsTS(Long resultsTS) {
		this.resultsTS = resultsTS;
	}

	public long getSubmissionTS() {
		return submissionTS;
	}

	public void setSubmissionTS(long submissionTS) {
		this.submissionTS = submissionTS;
	}

	public Integer getMaxCandidates() {
		return maxCandidates;
	}

	public void setMaxCandidates(Integer maxCandidates) {
		this.maxCandidates = maxCandidates;
	}

	public void setPercentagePoint(Double percentagePoint) {
		this.percentagePoint = percentagePoint;
	}

	public Double getPercentagePoint() {
		return percentagePoint;
	}

	public void setHitThreshold(Integer hitThreshold) {
		this.hitThreshold = hitThreshold;
	}

	public Integer getHitThreshold() {
		return hitThreshold;
	}

	/**
	 * @param failureCount
	 *            the failureCount to set
	 */
	public void setFailureCount(int failureCount) {
		this.failureCount = failureCount;
	}

	/**
	 * @return the failureCount
	 */
	public int getFailureCount() {
		return failureCount;
	}

	/**
	 * @param remainJobs
	 *            the remainJobs to set
	 */
	public void setRemainJobs(int remainJobs) {
		this.remainJobs = remainJobs;
	}

	/**
	 * @return the remainJobs
	 */
	public int getRemainJobs() {
		return remainJobs;
	}

	public int getTimeouts() {
		return timeouts;
	}

	public void setTimeouts(int timeouts) {
		this.timeouts = timeouts;
	}

	/**
	 * @return the assignedTs
	 */
	public Long getAssignedTs() {
		return assignedTs;
	}

	/**
	 * @param assignedTs
	 *            the assignedTs to set
	 */
	public void setAssignedTs(Long assignedTs) {
		this.assignedTs = assignedTs;
	}

	/**
	 * @return the callbackStyle
	 */
	public CallbackStyle getCallbackStyle() {
		return callbackStyle;
	}

	/**
	 * @param callbackStyle
	 *            the callbackStyle to set
	 */
	public void setCallbackStyle(CallbackStyle callbackStyle) {
		this.callbackStyle = callbackStyle;
	}

	/**
	 * @return the familyId
	 */
	public int getFamilyId() {
		return familyId;
	}

	/**
	 * @param familyId
	 *            the familyId to set
	 */
	public void setFamilyId(int familyId) {
		this.familyId = familyId;
	}
}
