package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the DM_SEGMENTS database table.
 * 
 */
@Embeddable
public class DmSegmentEntityPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "DM_ID", insertable = false, updatable = false)
	private long dmId;

	@Column(name = "SEGMENT_ID", insertable = false, updatable = false)
	private long segmentId;

	public DmSegmentEntityPK() {
	}

	public long getDmId() {
		return this.dmId;
	}

	public void setDmId(long dmId) {
		this.dmId = dmId;
	}

	public long getSegmentId() {
		return this.segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DmSegmentEntityPK)) {
			return false;
		}
		DmSegmentEntityPK castOther = (DmSegmentEntityPK) other;
		return (this.dmId == castOther.dmId)
				&& (this.segmentId == castOther.segmentId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.dmId ^ (this.dmId >>> 32)));
		hash = hash * prime
				+ ((int) (this.segmentId ^ (this.segmentId >>> 32)));

		return hash;
	}
}