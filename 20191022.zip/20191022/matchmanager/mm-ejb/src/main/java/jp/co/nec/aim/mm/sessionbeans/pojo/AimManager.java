package jp.co.nec.aim.mm.sessionbeans.pojo;

import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;


public class AimManager {
	private static Logger logger = LoggerFactory.getLogger(AimManager.class);
	private static final ConcurrentHashMap<String, Object> inquiryCilientJobLockerQueue = new ConcurrentHashMap<>(); //key is jobId used get job result
	private static final ConcurrentHashMap<String, Object> extractCilientJobLockerQueue = new ConcurrentHashMap<>();
	
	private static final ConcurrentHashMap<String, IdentifyResponse> inquiryClientJobResultsQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, ExtractResponse> extractClientJobResultsQueue = new ConcurrentHashMap<>();
	
	private static final ConcurrentHashMap<String, Object> inquiryLockQueue = new ConcurrentHashMap<>(); 
	private static final ConcurrentHashMap<String, IdentifyResponse> inquiryJobResutQueue = new ConcurrentHashMap<>(); //key is top_job_id 	
	private static final ConcurrentHashMap<String, Object> extractLockQueue = new ConcurrentHashMap<>(); //key is fe_job_id
	private static final ConcurrentHashMap<String, PBMuExtractJobResultItem> extractJobResutQueue = new ConcurrentHashMap<>(); //key is fe_job_id 	
	
	
	public static void finishInquryClientJob(String topJobId) {
		inquiryCilientJobLockerQueue.remove(topJobId);
		inquiryClientJobResultsQueue.remove(topJobId);
		logger.info("Indetify Job is completed, jobid:{}", topJobId);
	}
	
	public static void finishExtractClientJob(String feJobId) {
		extractCilientJobLockerQueue.remove(feJobId);
		extractClientJobResultsQueue.remove(feJobId);
		logger.info("Extract Job is completed, jobid:{}", feJobId);
	}	
	
	public static void saveInquryClientJobLocker(String key , Object locker) {
		inquiryCilientJobLockerQueue.put(key, locker);		
	}

	public static void saveExtractClientJobLocker(String key , Object locker) {
		logger.info("save key={}", key);
		extractCilientJobLockerQueue.put(key, locker);		
	}
	
	public static void saveInquryClientJobResult(String key , IdentifyResponse idyRes) {
		inquiryClientJobResultsQueue.putIfAbsent(key, idyRes);
		Object iqyLocker = inquiryCilientJobLockerQueue.get(key);
		synchronized (iqyLocker) {			
			iqyLocker.notify();
			logger.info("identify job:{} is completed. notified to AimIdentifyServlet.");
		}			
	}
	
	public static void saveExtractClientJobResult(String key , ExtractResponse extRes) {
		extractClientJobResultsQueue.putIfAbsent(key, extRes);
		Object extLocker = extractCilientJobLockerQueue.get(key);
		synchronized (extLocker) {			
			extLocker.notify();
			logger.info("extract job:{} is completed. notified to AimExtractServlet.");
		}			
	}
	
	public static IdentifyResponse getIdentifyClientResponse(String key) {
		return inquiryClientJobResultsQueue.get(key);
	}
	
	public static ExtractResponse getExtractClientResponse(String key) {
		return extractClientJobResultsQueue.get(key);
	}
	
	
	
	public static void finishInquiryJob(String topJobId) {
		inquiryLockQueue.remove(topJobId);
		inquiryJobResutQueue.remove(topJobId);
	}
	
	public static PBMuExtractJobResultItem getExtractJobResult(String feJobId) {
		return extractJobResutQueue.get(feJobId);
	}
	
	public static void saveToExtractJobResutQueue(String key, PBMuExtractJobResultItem oneFejobResut) {
		extractJobResutQueue.put(key, oneFejobResut);		
		Object locker = extractLockQueue.get(key);
		synchronized (locker) {			
			locker.notify();
			logger.info("extract job:{} is completed. notified to AimSyncService.");
		}		
	}
	
	public static void saveToInquiryJobResutQueue(String key, IdentifyResponse iqyRes) {
		inquiryJobResutQueue.putIfAbsent(key, iqyRes);
	}
	
	public static IdentifyResponse getIdentifyResponse(String key) {
		return inquiryJobResutQueue.get(key);
	}	
	
	public static void saveToExtractLockQueue(String key, Object obj) {
		extractLockQueue.putIfAbsent(key, obj);		
	}
	
	public static void saveToInquiryLockQueue(String key, Object obj) {
		inquiryLockQueue.put(key, obj);
	}
	
	public static void finishExtractJob(String extJobId) {
		extractLockQueue.remove(extJobId);
		extractJobResutQueue.remove(extJobId);
	}

	public static ConcurrentHashMap<String, Object> getInquirylockqueue() {
		return inquiryLockQueue;
	}

	public static ConcurrentHashMap<String, Object> getExtractlockqueue() {
		return extractLockQueue;
	}
	
	

}
