use DMDB;
source ddl/create_tab.sql
source seed/insert_init_dm_db.sql






