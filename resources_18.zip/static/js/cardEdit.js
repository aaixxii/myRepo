$(function() {
    $.datepicker.setDefaults($.extend($.datepicker.regional['ja']));
    $('.datepicker').datepicker( {
        showOn: 'button',
        duration: 100,
        buttonImage: 'img/date.png',
        buttonImageOnly: true,
        beforeShow : function() {
          $('#ui-datepicker-div').css( 'font-size', '80%' );
        },
        // Datepicker �N���[�Y���ɁA���Z�����̓��t�e�L�X�g�ɐݒ�
        onClose : function(date) {
          if ( date.length > 0 ) {
            datetext = $(this).parent().children().get(2);
            $(datetext).val(date);
          }
        }
    });
  }
);
