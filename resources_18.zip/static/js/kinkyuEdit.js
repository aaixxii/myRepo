function ChangeColor(idName){
	document.getElementById('line1').style.backgroundColor = '#FFFFFF';
	document.getElementById('line2').style.backgroundColor = '#FFFFCC';
	document.getElementById('line3').style.backgroundColor = '#FFFFFF';
	document.getElementById('line4').style.backgroundColor = '#FFFFCC';
	document.getElementById(idName).style.backgroundColor = '#FF9966';
	}
