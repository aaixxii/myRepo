$( function(){
    //多言語選択の選択値を取得
    var multiLingualSelected_val = $("#multiLingualSelected").val();
    //多言語選択の選択値を元にDatepickerの設定を変更する関数
    function datepickerSetRegion(){
        multiLingualSelected_val = $("#multiLingualSelected").val();
        if( multiLingualSelected_val == "J" ){ multiLingualSelected_val = "ja";    }
        if( multiLingualSelected_val == "E" ){ multiLingualSelected_val = "en";    }
        if( multiLingualSelected_val == "C" ){ multiLingualSelected_val = "zh-TW"; }
        //選択された言語に対応した表示設定を、Datepickerに適用する
        $( ".datepicker" ).datepicker( "option" , $.datepicker.regional[ multiLingualSelected_val ] );
    };
    //Datepickerの初期設定はデフォルト
    $.datepicker.setDefaults( $.datepicker.regional[ "" ] );
    //Datepickerの設定
    $(".datepicker").datepicker(
        {   showOn: "button"           //カレンダ表示イベント｢ focus：テキスト選択時 ｣｢ button：アイコンクリック時 ｣｢ both：両方 ｣
        ,   duration: 100              //カレンダーの表示タイミング、ミリ秒指定、または｢ Fast ｣｢ slow ｣｢ normal ｣
        ,   buttonImageOnly: true      //画像表示設定｢ true：画像のみ ｣｢ false：ボタン上に画像表示 ｣
        ,   buttonImage: "../../img/date.png"   //カレンダアイコン画像設定、相対パス
        ,   beforeShow: function() {
                datepickerSetRegion();     //表示前に、言語設定、フォントサイズを変更
                $("#ui-datepicker-div").css( "font-size", "80%" );
            }
        ,   onClose : function(date) {              //クローズ時に、別テキストに設定
                $("#datepicker_getVal_getFormat").val( "" );
                if ( date.length > 0 ) {
                    $("#datepicker_getVal_getFormat").val( date + " , " + $(".datepicker").datepicker( "option", "dateFormat" ) );
                    $(this).focus();
                }
            }
        }
    );
});
