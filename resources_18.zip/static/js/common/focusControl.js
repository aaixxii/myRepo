/**
 * @fileoverview 画面項目のfocus制御に係る共通処理.
 */

/**
 * 画面項目のfocus制御に係る共通処理.
 */
;(function (global) {

var FocusControl = {}; // focus制御オブジェクト

FocusControl.TYPES = ['text', 'password', 'textarea']; //イベント追加可能なinputForm
FocusControl.KEYS = {
	ENTER: 'Enter',
};

FocusControl.INVALID_KEY = {
		TAB: 'Tab',
		SHIFT: 'Shift',
		ALT: 'Alt',
		CTRL: 'Ctrl'

	};
FocusControl.keyPressed = false;

FocusControl.SELECTOR = {
	autoFocus: 'autoFocus'
};

/**
 * 次のinputFormへフォーカスを移動する.
 * @param {Event} e イベントオブジェクト
 */
FocusControl.nextFocus = function (e) {
	if (FocusControl.INVALID_KEY[e.key.toUpperCase()]) {
		return;
	}

	var type = this.type.toLowerCase() || '';
	if (FocusControl.canNextFocus(e)) {
		FocusControl.moveToNextFocus(e);
	}
	FocusControl.keyPressed = false;
};

/**
 * 次のtabIndexを持つ要素へ移動できるか判定する.
 * @param {Event} e イベントオブジェクト
 */
FocusControl.canNextFocus = function (e) {
	var type =  e.currentTarget.type.toLowerCase() || '';
	if (type === 'text' && FocusControl.onKeyEnter(e)) {
		return true;
	}

	if (FocusControl.isMaxLengthOver(e)) {
		return true;
	}

	return false;

};

/**
 * 次のtabIndexを持つ要素へ移動する.
 * @param {Event} e イベントオブジェクト
 */
FocusControl.moveToNextFocus = function (e) {
	var tabIndexs
		, targetElements = []
		, index
	;

	// tabIndex指定のある要素を取得
	tabIndexs = document.querySelectorAll('[tabIndex]:not(:disabled)');
	if (!tabIndexs) {
		return;
	}

	// 取得した要素を非表示要素を除いた配列に変換
	Array.prototype.forEach.call(tabIndexs, function(element) {
			var style = window.getComputedStyle(element);
			if (style.display !== 'none' && 0 <= element.tabIndex) {
				this.push(element)
			}
		},
		targetElements
	);

	targetElements.sort(function (el1, el2) {
		if (el1.tabIndex < el2.tabIndex) {
			return -1;
		} else if (el1.tabIndex > el2.tabIndex) {
			return 1;
		}else {
			return 0;
		}
	});

	// 次のtabIndexを取得し、フォーカス移動する.
	if (!!e.currentTarget.tabIndex) {
		index = targetElements.indexOf(e.currentTarget);
		if (index + 1 < targetElements.length) {
			targetElements[index + 1].focus();
		} else {
			targetElements[0].focus();
		}
	}
};

/**
 * Enterキーが入力されたか判定する.
 * @param {Event} e イベントオブジェクト
 */
FocusControl.onKeyEnter = function (e) {
	if (FocusControl.keyPressed && e.key === FocusControl.KEYS.ENTER) {
		return true;
	}

	return false;
};

/**
 * 最大入力桁数に達しているか判定する.
 * @param {Element} element 入力されたinputForm
 */
FocusControl.isMaxLengthOver = function (e) {
	var element = e.currentTarget;
	if (element.maxLength <= element.value.length
			&& (FocusControl.keyPressed || e.key === FocusControl.KEYS.ENTER)) {
		return true;
	}
	return false;
};


/**
 * フォーカス移動のイベントを追加する.
 *     フォーカス移動の条件は入力文字が最大桁数に達した場合、またはEnterキー入力時.
 *     ※TextAreaでのEnterキー入力は改行を許容するためフォーカス移動の対象外
 */
FocusControl.addAutoFocusEvent = function() {
	Array.prototype.forEach.call(
			document.getElementsByClassName(FocusControl.SELECTOR.autoFocus)
			, function (element) {
				if (0 <= this.TYPES.indexOf(element.type.toLowerCase())) {
					element.addEventListener('keypress', function () {
						FocusControl.keyPressed = true;
						}, false);
					element.addEventListener('keyup', FocusControl.nextFocus, false);
				}}
			, FocusControl);
};


if (global === window) {
	global.FocusControl = FocusControl;
}

return FocusControl;

})( typeof window !== "undefined" ? window : this);

document.addEventListener( 'DOMContentLoaded', FocusControl.addAutoFocusEvent, false );


