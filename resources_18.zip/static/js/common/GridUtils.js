/**
 * @fileoverview 一覧表ユーティリティに係る共通処理.
 */

/**
 * 画面項目のfocus制御に係る共通処理.
 */
;(function (global) {

var GridUtils = {}; // 一覧表ユーティリティオブジェクト

GridUtils.SELECT_TYPE = {
	SINGLE: 'single-select'
	, MULTI: 'multi-select'
};

GridUtils.SELECTOR = {
	SELECTED: 'selected'
};


/**
 * フォーカス(クリック)行に背景色をつける.
 *     既に選択状態の場合は背景色を削除する
 */
/**
 * クリック行に背景色をつける.
 * @param {Event} e イベントオブジェクト
 */
GridUtils.clickRow = function (e) {

	var tbl = GridUtils.getParentElementByTagName(e.currentTarget, 'table');
	if (tbl
			&& tbl.classList.contains(GridUtils.SELECT_TYPE.SINGLE)) {

		if (!event.currentTarget.classList.contains(GridUtils.SELECTOR.SELECTED)) {
			Array.prototype.forEach.call(
					tbl.getElementsByTagName('tr')
					, function (element) {
						element.classList.remove(GridUtils.SELECTOR.SELECTED);
					});
		}

		event.currentTarget.classList.toggle(GridUtils.SELECTOR.SELECTED);
	}

	if (tbl && tbl.classList.contains(GridUtils.SELECT_TYPE.MULTI)) {

		var checkbox = event.currentTarget.querySelectorAll('[type="checkbox"]:not(:disabled)');
		if (checkbox && 0 < checkbox.length) {
			if (event.target.type === 'checkbox') {
				return;
			} else {
				var style = window.getComputedStyle(checkbox[0]);
				if (style.display !== 'none') {
					checkbox[0].checked = !checkbox[0].checked;
					event.currentTarget.classList.toggle(GridUtils.SELECTOR.SELECTED);
				}
			}
		}
	}
};

/**
 * チェックボックスのON/OFFによる行背景色制御.
 *     既に選択状態の場合は背景色を削除する
 * @param {Event} e イベントオブジェクト
 */
GridUtils.changeCheckBox = function (e) {
	var tr = GridUtils.getParentElementByTagName(e.target, 'tr');
	tr.classList.toggle(GridUtils.SELECTOR.SELECTED);
};

/**
 * すべてのチェックボックスをON/OFFに設定する.
 * @param {String} tableId 制御対象となるテーブルのID属性
 * @param {boolean} checked チェックボックスのチェック状態
 */
GridUtils.setSelectedAll = function (tableId, checked) {
	var tbl = document.getElementById(tableId);
	if (!tbl) {
		return;
	}

	Array.prototype.forEach.call(
			tbl.getElementsByTagName('tr')
			, function (element) {
				var checkbox = element.querySelectorAll('[type="checkbox"]:not(:disabled)');
				if (checkbox && 0 < checkbox.length) {
					var style = window.getComputedStyle(checkbox[0]);
					if (style.display !== 'none') {
						checkbox[0].checked = this.checked;
						if (this.checked) {
							element.classList.add(GridUtils.SELECTOR.SELECTED);
						} else {
							element.classList.remove(GridUtils.SELECTOR.SELECTED);
						}
					}
				}
			}
			, {
				'checked': checked
			}
	);
};

/**
 * 指定した要素から直近の、指定されたタグ要素を返却する.
 * @param {Element} element 起点となる要素
 * @param {String} tagName タグ名称
 *
 */
GridUtils.getParentElementByTagName = function (element, tagName) {
		var p = element.parentElement;
		if (!p) {
			return null;
		}

		if (p.tagName.toLowerCase() === tagName.toLowerCase()) {
			return p;
		} else {
			return GridUtils.getParentElementByTagName(p, tagName);
		}

};


/*
 * 選択行の背景色設定イベントを追加する.
 */
GridUtils.addClickRowEvent = function() {
	Array.prototype.forEach.call(
			document.getElementsByClassName(GridUtils.SELECT_TYPE.SINGLE)
			, function (element) {
					// 行クリックイベント
					Array.prototype.forEach.call(
							element.getElementsByTagName('tr')
							, function (element) {
								element.addEventListener('click', GridUtils.clickRow, false);
					});
	});

	Array.prototype.forEach.call(
			document.getElementsByClassName(GridUtils.SELECT_TYPE.MULTI)
			, function (element) {
					// 行クリックイベント
					Array.prototype.forEach.call(
							element.getElementsByTagName('tr')
							, function (element) {
								element.addEventListener('click', GridUtils.clickRow, false);

								var checkbox = element.querySelectorAll('[type="checkbox"]');
								if (checkbox && 0 < checkbox.length) {
									checkbox[0].addEventListener('change', GridUtils.changeCheckBox, false);
								}
					});
	});
};


if (global === window) {
	global.GridUtils = GridUtils;
}

return GridUtils;

})( typeof window !== "undefined" ? window : this);

document.addEventListener( 'DOMContentLoaded', GridUtils.addClickRowEvent, false );


