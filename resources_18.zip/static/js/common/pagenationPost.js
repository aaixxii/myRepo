// 表示件数をhiddenに退避
// 引数：formName：submit()する画面名
function pagenationSizeChng( formName ){
    pagenationPost( 0 , formName );
};

// ページ変更時に、リクエストパラメータでページ数と表示件数を渡す
// 引数：pageSu  ：(クリックされたページ数)－１
// 引数：formName：submit()する画面名
function pagenationPost( pageSu , formName ){
    $("#commonPager>#selectedPage").val( pageSu );
    var actionName = "";
    if ( formName.slice(0,1) == "/" ) {
        actionName = formName + "/pagemove"
    } else {
        actionName = "/" + formName + "/pagemove"
    }
    var form = $("form").attr("method","post").attr("action",actionName);
    form.submit();
};
