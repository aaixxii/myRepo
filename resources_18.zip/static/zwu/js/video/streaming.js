


$(document).ready(function() {
	// 処理不要
})

function janusInit(url, targetTag, dummyFile) {
	
	console.log("url : " + url);

	// Janusの初期化
	Janus.init({debug: "all", callback: function() {

		console.log("------ janus.init start -------");
		
		var $video;
		var initDone;
		//var spinner;
		var streaming;
		var opaqueId = "streamingtest-" + Janus.randomString(12);
		
		var server = null;
		if (window.location.protocol === 'http:'){
			server = "http://" + url + ":8088/janus";
		} else {
			server = "https://" + url + ":8089/janus";
		}
		var stunUrl = "stun:" + url + ":3478";
		var turnUrl = "turn:" + url + ":3478";

		console.log("stunUrl : " + stunUrl);
		console.log("turnUrl : " + turnUrl);

		var janus = new Janus({
			server: server,
			iceServers: [
				//{urls: "stun:stun.l.google.com:19302"},
				{urls: stunUrl},
				{urls: turnUrl, username: 'myuser', credential: 'mypassword'}
				],
			success: function() {
				initDone = true;
			},
			error: function(error) {
				// ダミー画像に差し替え
				targetTag.removeAttr("src");
				targetTag.removeAttr("poster");
				targetTag.attr("poster", dummyFile);

				bootbox.alert(error, function() {
					// window.location.reload();
				});
			},
			destroyed: function() {
				window.location.reload();
			}
		});
		
		// ストリームの再生
		play = function(key, value) {

			console.log("play start");

			if (initDone === undefined) {
				setTimeout(function() { play(key, value) }, 100);
				return;
			}
			
			_play(key, value);
		}
		
		_play = function(_id, streamNo) {

			console.log("_play start");

			// WebRTCのサポートチェック
			if (!Janus.isWebrtcSupported()){
				return;
			}
			// 引数チェック
			if (_id === undefined || _id === null || streamNo === undefined || streamNo === null){
				return;
			}
			$video = $("#" + _id);
			if ($video.length === 0){
				return;
			}
			
			// videoタグにストリームを割り当てる
			janus.attach({
				plugin: "janus.plugin.streaming",
				opaqueId: opaqueId,
				success: function(pluginHandle) {
					streaming = pluginHandle;
					startStream(streamNo);
				},
				error: function(error) {
					alert("error!");
				},
				onmessage: function(msg, jsep) {
					var result = msg["result"];
					if (result !== null && result !== undefined) {
						if (result["status"] !== undefined && result["status"] !== null) {
							var status = result["status"];
							if (status === 'stopped'){
								stopStream();
							}
						}
					} else if (msg["error"] !== undefined && msg["error"] !== null) {


						bootbox.alert(msg["error"]);
						stopStream();
						return;
					}
					if (jsep !== undefined && jsep !== null) {
						streaming.createAnswer(
							{
								jsep: jsep,
								media: { audioSend: false, videoSend: false },
								success: function(jsep) {
									var body = { "request": "start" };
									streaming.send({"message": body, "jsep": jsep});
								},
								error: function(error) {
									bootbox.alert("WebRTC error... " + JSON.stringify(error));
								}
							});
					}
				},
				onremotestream: function(stream) {
					if (flg) {
						flg = false;
					} else {
						flg = true;
					}
					$video.bind("playing", function () {
						var videoTracks = stream.getVideoTracks();
						if (videoTracks === null || videoTracks === undefined || videoTracks.length === 0)
							return;
					});
					
					Janus.attachMediaStream($video.get(0), stream);
				},
				oncleanup: function() {
				}
			});
		};
		var flg;
		
		startStream = function(streamNo) {
			streaming.send({"message": {"request": "watch", id: parseInt(streamNo)}});
		};
		
		stopStream = function() {
			streaming.send({"message": {"request": "stop"}});
			streaming.hangup();
		}
	}});

};
