function play(e){

	  var player = e;
	  var seekbar = document.getElementById("seekbar");
	  var flg = 0;
	  seekbar.min = 0; 
	  seekbar.value = 0;
	  player.play();//自動再生
	  var intervalRewind;
	  
	  // データのロードイベント
	  player.on('loadeddata', function () {
	      seekbar.max =player.duration();
	    });
	  
	  // 映像の更新イベント
	  player.on('timeupdate', function () {
		  seekbar.value = player.currentTime();
	    });
	  

	  // シークバーの更新イベント場合
	  seekbar.addEventListener("input",function(){
		  player.currentTime(this.valueAsNumber);
		    },false);

	 // コマ送り(１０ｓ)
	 $("#next").click(function(){
	     clearInterval(intervalRewind);
	     player.playbackRate(1.0);
	     var t=player.currentTime();
	     player.currentTime(t+10);
	     });

	 // コマ戻し（１０s）
	 $("#prev").click(function(){
	     clearInterval(intervalRewind);
	     player.playbackRate(1.0);
	     var t=player.currentTime();
	     player.currentTime(t-10);
	     });
	 
	 // 早送り
	 $("#fast").click(function(){
	     clearInterval(intervalRewind);
	     player.playbackRate(2.0);
	     });

	 // 巻き戻し
	 $("#back").click(function(){
	    player.playbackRate(1.0);
	    player.pause();
	    document.getElementById("img").src = "/alsok-g6-wu/zwu/img/play.png"
	    clearInterval(intervalRewind);
	    intervalRewind = setInterval(function(){
	      var t=player.currentTime();
	      if(t == 0){
	       clearInterval(intervalRewind);
	     }else{
	       player.currentTime(t-1);
	     }
	     },500); 

	   //player.playbackRate(-1.0);   
	    });

	 // 再生
	 $("#start").click(function(){
	     var t=player.currentTime();
	     player.currentTime(t); 
	     player.playbackRate(1.0);
	     player.play();//自動再生
	     clearInterval(intervalRewind);
	     });

	 // 一時停止
	 $("#stop").click(function(){
	     player.pause();
	     clearInterval(intervalRewind);
	     });
	 
	 // 再生/一時停止
	 $("#startstop").click(function(){
		 if(flg == 1){
		     var t=player.currentTime();
		     player.currentTime(t); 
		     player.playbackRate(1.0);
		     player.play();//自動再生
		     clearInterval(intervalRewind);
		     document.getElementById("img").src = "/alsok-g6-wu/zwu/img/stop.png"
			 flg = 0;
		 } else {
		     player.pause();
		     clearInterval(intervalRewind);
		       document.getElementById("img").src = "/alsok-g6-wu/zwu/img/play.png"
			 flg = 1;
		 }
	     });
	player.on("ended", function() {
	    document.getElementById("img").src = "/alsok-g6-wu/zwu/img/play.png"
		});

	$('#myvideo').click(function(event){
	    var idStr = $(this).attr('id');
	    console.log(idStr);
	  });
}

