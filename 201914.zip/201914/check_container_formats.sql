CREATE DEFINER=`aimuser`@`%` PROCEDURE `check_container_formats`(
	IN p_function_id          INT,
	IN p_candidate_containers VARCHAR(1024),
	OUT result                VARCHAR(1024)
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
my_label:BEGIN
    -- p_candidate_containers="1,2,3,321,322,323"； 
	DECLARE tmp_count INT;
	DECLARE l_actual_format_name VARCHAR(255);
	DECLARE l_target_format_name VARCHAR(255);
	DECLARE l_target_format_id INT;
	DECLARE l_length INT;
	DECLARE l_function_name VARCHAR(20);
	DECLARE v_idx INT DEFAULT 999;
	DECLARE v_tmp_str VARCHAR(20);
	DECLARE t_error INTEGER DEFAULT 0; 
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
	DROP TEMPORARY TABLE IF EXISTS arr_container_ids;
	CREATE temporary TABLE arr_container_ids(id int) engine=memory; 
	while_lab:WHILE v_idx > 0 do
          SET v_idx = INSTR(p_candidate_containers,',');
          IF v_idx <=0 then
            INSERT INTO arr_container_ids (id)  VALUES (CAST(p_candidate_containers AS UNSIGNED));
            LEAVE while_lab;
		 END IF;
		 SET v_tmp_str = substr(p_candidate_containers,1,v_idx-1);    
		 INSERT INTO arr_container_ids (id)  values (CAST(v_tmp_str AS UNSIGNED));
		 SET p_candidate_containers=substr(p_candidate_containers,v_idx +1 ,LENGTH(p_candidate_containers));             
	END WHILE;  
    
	SELECT count(id) INTO l_length FROM arr_container_ids;    
	SELECT Count(*) INTO tmp_count	
	FROM (SELECT c.CONTAINER_ID
          FROM CONTAINERS c
          WHERE c.CONTAINER_ID IN (SELECT id FROM arr_container_ids)) AS q1;                                  
	IF tmp_count != l_length THEN
		SET result = 'containerId miss match!';
		LEAVE my_label;
	END IF;      
	
	SELECT f.TARGET_FORMAT_ID,f.FUNCTION_NAME INTO l_target_format_id,l_target_format_name
    FROM FUNCTION_TYPES f WHERE f.FUNCTION_ID = P_FUNCTION_ID; 
    
 	SET tmp_count = 0;
	SELECT Count(*) INTO tmp_count	
	FROM (SELECT c.CONTAINER_ID,
                 c.FORMAT_ID
          FROM CONTAINERS c,
               FORMAT_TYPES f
          WHERE c.FORMAT_ID = f.FORMAT_ID
          AND c.FORMAT_ID = l_target_format_id
		  AND c.FORMAT_ID IS NOT NULL
		  AND f.FORMAT_ID IS NOT NULL
		  AND c.CONTAINER_ID IN (SELECT id FROM arr_container_ids)) AS q3; 
	IF tmp_count != l_length THEN
       SET result = 'FORMAT_ID miss match';
       LEAVE my_label;
	END IF;   
    
	SELECT Count(*)  INTO tmp_count
	FROM (SELECT f.TARGET_FORMAT_ID,
                 f.FUNCTION_NAME
		  FROM FUNCTION_TYPES f
          WHERE f.FUNCTION_ID = P_FUNCTION_ID) AS q4;         
	IF tmp_count < 1 THEN
	   SET result = 'function name miss match';
	   LEAVE my_label;
	END IF; 
    
 	SELECT Count(*) INTO tmp_count	
	FROM (SELECT c.CONTAINER_ID,
                 c.FORMAT_ID
          FROM  CONTAINERS c,
               FUNCTION_TYPES f
         WHERE  c.FORMAT_ID = f.TARGET_FORMAT_ID
			   AND c.FORMAT_ID = l_target_format_id
               AND f.TARGET_FORMAT_ID = l_target_format_id
               AND f.FUNCTION_NAME = l_target_format_name
               AND c.FORMAT_ID IS NOT NULL
               AND f.TARGET_FORMAT_ID IS NOT NULL
               AND c.CONTAINER_ID IN (SELECT id FROM arr_container_ids)) AS q2;                                      
	IF tmp_count != l_length THEN
	   SET result = 'function name miss match';
       LEAVE my_label;
	END IF;     
    
	SET tmp_count = 0;
	SELECT Count(*) INTO  tmp_count	
	FROM (SELECT c.CONTAINER_NAME
          FROM CONTAINERS c,FORMAT_TYPES f
          WHERE c.FORMAT_ID = f.FORMAT_ID
		  AND c.CONTAINER_ID IN (SELECT id  FROM arr_container_ids)                                     
		  AND EXISTS (SELECT fy.FORMAT_NAME
					  FROM FORMAT_TYPES fy  WHERE  fy.FORMAT_ID = c.FORMAT_ID)) AS q5;                      
	IF tmp_count != l_length THEN
       SET result = 'FORMAT_ID miss match';
       LEAVE my_label;
	END IF;
	SELECT "OK" INTO result;
END