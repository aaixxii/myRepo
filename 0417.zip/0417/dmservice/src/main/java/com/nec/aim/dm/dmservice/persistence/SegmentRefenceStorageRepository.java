package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import com.nec.aim.dm.dmservice.entity.SegBioNsmUrl;

public interface SegmentRefenceStorageRepository {
	public void insertSegRefStorageWitoutRefId(Integer storageId, Long segId, Long bioId) throws SQLException;
	public void inserSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId, String externalId)  throws SQLException;
	public int deleteSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId)  throws SQLException;
	public int updateSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId, String externalId)  throws SQLException;
	public List<SegBioNsmUrl> getInfoForGetTemplate(String externalId)  throws SQLException;
}
