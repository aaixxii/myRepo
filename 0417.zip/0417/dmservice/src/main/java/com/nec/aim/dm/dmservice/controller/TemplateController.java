package com.nec.aim.dm.dmservice.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nec.aim.dm.dmservice.dispatch.Dispatcher;
import com.nec.aim.dm.dmservice.exception.DmServiceException;

import lombok.extern.slf4j.Slf4j;



@Controller
@Slf4j
public class TemplateController extends HttpServlet {		
	
	private static final long serialVersionUID = -5368691957495983136L;
	@Autowired
	Dispatcher dispatcher;
	
	
	@RequestMapping("/getTemplate/")
	public void getTemplate(HttpServletRequest req, HttpServletResponse res, @RequestParam("segId") Long segId, @RequestParam("bioId") Long bioId) throws IOException {
		
		
	
	}	
	
	
	

	@RequestMapping("/getTemplate/")
	public void getTemplateByRefId(HttpServletRequest req, HttpServletResponse res, @RequestParam("refId") String refId) throws IOException {
		
		
	
	}	
}
