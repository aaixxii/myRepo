package com.nec.aim.dm.dmservice.controller;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nec.aim.dm.dmservice.dispatch.Dispatcher;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class SegmentController extends HttpServlet{	
	private static final long serialVersionUID = 8978225136377187339L;
	
	@Autowired
	Dispatcher dispatcher;

	@RequestMapping(value = "/dmSyncSegment", method = RequestMethod.POST)
	public void dmSegmentHandler(HttpServletRequest req, HttpServletResponse res) {
		log.info("Received dmSyncSegment from {}", req.getRemoteHost());
		PBDmSyncResponce.Builder dmRes = PBDmSyncResponce.newBuilder();	
		try {
			PBDmSyncRequest dmSegReq =PBDmSyncRequest.parseFrom(req.getInputStream());
			log.info(dmSegReq.toString());
			boolean result = dispatcher.handlePostRequest(dmSegReq);
			dmRes.setSuccess(result);
			log.info("Got respone from node storage, response = {}", result);
			dmRes.build().writeTo(res.getOutputStream());			
		} catch (Exception e) {
			log.error(e.getMessage());
			dmRes.setSuccess(false);
			try {
				dmRes.build().writeTo(res.getOutputStream());
			} catch (IOException e1) {				
				log.error(e1.getMessage());
			}
		}
	}
}
