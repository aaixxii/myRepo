package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.nec.aim.dm.dmservice.entity.SegBioNsmUrl;

public class SegmentRefenceStorageRepositoryImpl implements SegmentRefenceStorageRepository {
	
	private static final String insertSql = "insert into segment_ref_storage_info(storage_id, segment_id, external_id) values(?,?,?)";
	private static final String getSql = "select ng.url,srs.segment_id, srs.bio_id from segment_ref_storage_info srs, node_storage ng where srs.storage_id = ng.storage_id and ng.status=1 and srs.external_id=?";
	
	@Autowired
    private JdbcTemplate jdbcTemplate;	
	
	RowMapper<SegBioNsmUrl> segBioNsmUrlMapper = (rs, rowNum) -> {
		SegBioNsmUrl segBioNsmUrl = new SegBioNsmUrl();
		segBioNsmUrl.setUrl(rs.getString("url"));
		segBioNsmUrl.setSegmentId(rs.getLong("segment_id"));
		segBioNsmUrl.setBioId(rs.getLong("bio_id"));
		return segBioNsmUrl;

	};

	@Override
	public void insertSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId, String externalId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql, new Object[] {segId, storageId, externalId});
		
	}

	@Override
	public int deleteSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId, String externalId) throws SQLException {
		return 0;
	}

	@Override
	public int updateSegmentRefenceStorageInfo(Integer storageId, Long segId, Long bioId, String externalId) throws SQLException {
		return 0;
	}

	@Override
	public List<SegBioNsmUrl> getInfoForGetTemplate(String externalId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		 List<SegBioNsmUrl> result = jdbcTemplate.query(getSql, new Object[] {externalId}, segBioNsmUrlMapper);
		return result;
	}

}
