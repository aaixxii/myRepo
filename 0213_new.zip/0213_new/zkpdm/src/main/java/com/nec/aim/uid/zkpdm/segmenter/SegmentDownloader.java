package com.nec.aim.uid.zkpdm.segmenter;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Optional;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;



import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")
@Slf4j
public class SegmentDownloader {
	
	
	public byte[] getSegmentData(long segmentId) {	
		//Optional<Segments> SegInfo = segmentsRepository.findById(segmentId);
		byte[] byteData = null;	
			Blob segBlob = null;
			try {
				 byteData = segBlob.getBytes(0, (int) segBlob.length());
				 log.info("Success get segment({}) data", segmentId);
			} catch (SQLException e) {
				log.error(e.getMessage(), e);
				byteData =  null;
			}
		
		
		return byteData;		
	}	

}
