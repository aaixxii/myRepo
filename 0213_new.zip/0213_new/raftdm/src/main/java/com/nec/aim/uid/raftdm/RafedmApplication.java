package com.nec.aim.uid.raftdm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RafedmApplication {

	public static void main(String[] args) {
		SpringApplication.run(RafedmApplication.class, args);
	}

}
