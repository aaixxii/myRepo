package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.EventLogLevel;
import jp.co.nec.aim.mm.sessionbeans.pojo.EventSender;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EventLogBeanTest {

	@Resource
	private DataSource dataSource;
	@Resource
	private EventLogBean logBean;

	private String message;

	@Before
	public void setUp() throws Exception {
		message = "";
		new MockUp<EventSender>() {
			@Mock
			public void sendEvent(String reasonCode, String eventType,
					Long unitId, String description, EventLogLevel level,
					Date date) {
				message = description;
				return;
			}
		};
	}

	@After
	public void tearDown() throws Exception {		
	}

	@Test
	public void testLogEvent() {

		logBean.logEvent("reasonCode", "eventType", 1l, "description",
				EventLogLevel.INFO);

		assertEquals("description", message);
	}

}
