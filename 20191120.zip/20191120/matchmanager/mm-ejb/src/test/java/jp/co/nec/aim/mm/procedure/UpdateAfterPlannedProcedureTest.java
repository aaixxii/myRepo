package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.ExecutePlanEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class UpdateAfterPlannedProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {

	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private UpdateAfterPlannedProcedure identifyPlannerDao;

	@Before
	public void setUp() throws Exception {
		identifyPlannerDao = new UpdateAfterPlannedProcedure(dataSource);
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("delete from mu_job_execute_plans");
		jdbcTemplate.execute("commit");

	}

	@After
	public void tearDown() throws Exception {
		identifyPlannerDao = null;
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("delete from mu_job_execute_plans");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testUpdateTablesAfterPlanned() {
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,0,3000,0,0,1,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,?)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,fusion_job_id,job_state) values(?,?,?,0)";
		Long jobId = 10L;
		Long[] fusionJobId = { 200L, 201L };
		Long[] containerJobId = { 300L, 301L };
		Integer containerId = 1;
		Integer functionId = 1;
		String planStrings = "abcdefjhijklmnopqrstuvwxyz";

		jdbcTemplate.update(jobQueueSql, new Object[] { jobId });
		for (int i = 0; i < 2; i++) {
			jdbcTemplate.update(fusionJobSql, new Object[] { fusionJobId[i],
					jobId, new Integer(i) });
			jdbcTemplate.update(contaiJobSql, new Object[] { containerJobId[i],
					containerId, fusionJobId[i] });
		}
		jdbcTemplate.update("commit");
		Long results = null;
		try {
			results = identifyPlannerDao.executeUpdate(jobId, containerId,
					containerJobId[0].longValue(), functionId, planStrings);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(results);
		String selectJobQueue = "select failure_count from job_queue where job_id = ?";
		String getMaxPlanId = "select max(plan_id) from mu_job_execute_plans";
		Integer failureCount = jdbcTemplate.queryForObject(selectJobQueue,
				new Object[] { jobId }, Integer.class);
		Long planId = jdbcTemplate.queryForObject(getMaxPlanId, Long.class);

		JobQueueEntity jobQueue = entityManager.find(JobQueueEntity.class,
				jobId.longValue());
		Assert.assertEquals(1, jobQueue.getJobState().ordinal());
		Assert.assertNotNull(jobQueue.getAssignedTs());

		ContainerJobEntity containerJob1 = entityManager.find(
				ContainerJobEntity.class, containerJobId[0]);
		Assert.assertEquals(1, containerJob1.getJobState().ordinal());
		Assert.assertEquals(1, containerJob1.getJobState().ordinal());
		Assert.assertEquals(planId, containerJob1.getPlanId());

		ContainerJobEntity containerJob2 = entityManager.find(
				ContainerJobEntity.class, containerJobId[0]);
		Assert.assertEquals(1, containerJob2.getJobState().ordinal());
		Assert.assertEquals(planId, containerJob2.getPlanId());

		ExecutePlanEntity jobPlan = entityManager.find(ExecutePlanEntity.class,
				planId);
		Assert.assertEquals(planId.longValue(), jobPlan.getPlanId());
		Assert.assertEquals(failureCount.intValue() + 1,
				jobPlan.getPlanedCount());
		Assert.assertEquals(planStrings, jobPlan.getPlan());
	}

}
