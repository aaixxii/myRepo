package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;

@SuppressWarnings("serial")
public class MuSegReportPK implements Serializable {
	private long muId;
	private long segmentId;

	@Column(name = "MU_ID")
	public long getMuId() {
		return muId;
	}

	public void setMuId(long muId) {
		this.muId = muId;
	}

	@Column(name = "SEGMENT_ID")
	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (obj == null || obj.getClass() != this.getClass())
			return false;
		MuSegReportPK other = (MuSegReportPK) obj;
		return other.getMuId() == getMuId()
				&& other.getSegmentId() == getSegmentId();
	}

	public int hashCode() {
		return (int) muId + (int) segmentId;
	}
}
