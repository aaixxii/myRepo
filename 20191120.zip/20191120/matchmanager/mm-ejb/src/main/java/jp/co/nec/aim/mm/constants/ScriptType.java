package jp.co.nec.aim.mm.constants;

public enum ScriptType {
	INQUIRY, DELETE, REGISTER
}
