package com.nec.aim.ribbon.user.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import com.nec.aim.ribbon.user.entity.User;

import lombok.extern.slf4j.Slf4j;


@RequestMapping("/movies")
@RestController
@Slf4j
public class RibbonController {
  @Autowired
  private RestTemplate restTemplate;

  @HystrixCommand(fallbackMethod = "findByIdFallback")
  @GetMapping("/users/{id}")
  public User findById(@PathVariable Long id) {    
    User user = this.restTemplate.getForObject(
      "http://template-service/users/{id}",
      User.class,
      id
    );   
    return user;
  }
  
  public User findByIdFallback(Long id, Throwable throwable) {
	    log.error("fallbak called", throwable);
	    return new User(id, "default user", "default user", 0, new BigDecimal(1));
	  }

}
