  CREATE OR REPLACE PROCEDURE SAKURA_MANKAI_TOOL_WITH_EDIT AUTHID CURRENT_USER IS 
  l_template_data  BIO_TEMPLATE_DATA_INFO.TEMPLATE_DATA%TYPE;  
  l_event_info_rec  BIO_EVENT_INFO%ROWTYPE;
  l_bin_id  NUMBER; 
  l_semgnet_id NUMBER;  
  l_expand_size  NUMBER;  
  l_init_biometricId  NUMBER;
  l_init_external_id VARCHAR2(36);
  l_init_event_id VARCHAR2(36);
  l_event_info_count NUMBER;
  --l_curret_seg_version NUMBER;
  --l_last_segmet_version NUMBER;
  l_base_biometricId  NUMBER;
  l_base_seg_ver  NUMBER;
  l_exist_event_count NUMBER;
  l_insert_count NUMBER;
  g_idx NUMBER;
  l_buffer    RAW(10);
  l_strat     NUMBER :=5;
  l_len       NUMBER :=16;
  l_biometricId  NUMBER;
  l_template_data_edit blob; 
  
BEGIN
   FOR rec IN (SELECT * FROM XM_PERF_TEST) LOOP
     l_bin_id := rec.BIN_ID;
     l_semgnet_id:= rec.SEGMENT_ID;   
     l_expand_size := rec.EXPAND_SIZE; 
     l_insert_count :=0;
     l_base_seg_ver := 0;
     g_idx := 0;
     SELECT count(BIOMETRIC_ID) INTO l_exist_event_count from BIO_EVENT_INFO WHERE BIN_ID=l_bin_id  AND ASSIGNED_SEGMENT_ID=l_semgnet_id; 
     IF (l_exist_event_count < 1) THEN
       dbms_output.put_line('No data to process,  for binId:' || to_char(l_bin_id) ||' semgnetId:' ||l_semgnet_id  || ' .skip');
       CONTINUE;
     END IF; 
     SELECT MAX(BIOMETRIC_ID), MAX(EXTERNAL_ID), MAX(EVENT_ID),max(DATA_VERSION) INTO l_init_biometricId,l_init_external_id,l_init_event_id, l_base_seg_ver from BIO_EVENT_INFO WHERE BIN_ID=l_bin_id  AND ASSIGNED_SEGMENT_ID=l_semgnet_id ;
     FOR i IN 1..l_expand_size LOOP  
       FOR event_rec IN (SELECT * FROM BIO_EVENT_INFO WHERE BIN_ID=l_bin_id  AND ASSIGNED_SEGMENT_ID=l_semgnet_id AND BIOMETRIC_ID <= l_init_biometricId) LOOP           
          IF (l_insert_count >= l_expand_size) THEN           
              CONTINUE;
          END IF;         
          l_base_seg_ver := l_base_seg_ver +1;
          g_idx := g_idx +1;
          SELECT TEMPLATE_DATA into l_template_data FROM BIO_TEMPLATE_DATA_INFO WHERE TEMPLATE_DATA_ID= event_rec.BIOMETRIC_ID;
          INSERT INTO /*+ append parallel nologging */ BIO_EVENT_INFO(BIOMETRIC_ID,EXTERNAL_ID,EVENT_ID,BIN_ID,STATUS,PHASE,CREATE_DATETIME,UPDATE_DATETIME,TEMPLATE_DATA_KEY,TEMPLATE_SIZE,DATA_VERSION,ASSIGNED_SEGMENT_ID,SITE_ID)
          VALUES(l_init_biometricId+g_idx,l_init_external_id||g_idx, l_init_event_id||g_idx, event_rec.BIN_ID, event_rec.STATUS,'PS', SYSTIMESTAMP,SYSTIMESTAMP,
                 l_init_biometricId+g_idx,event_rec.TEMPLATE_SIZE, l_base_seg_ver, event_rec.ASSIGNED_SEGMENT_ID, event_rec.SITE_ID); 
          INSERT INTO /*+ append parallel nologging */ BIO_TEMPLATE_DATA_INFO(TEMPLATE_DATA_ID, TEMPLATE_DATA,CREATE_DATETIME,UPDATE_DATETIME ) VALUES(TO_CHAR(l_init_biometricId + g_idx),l_template_data, SYSTIMESTAMP, SYSTIMESTAMP);
          SELECT TEMPLATE_DATA into l_template_data_edit FROM BIO_TEMPLATE_DATA_INFO WHERE TEMPLATE_DATA_ID=TO_CHAR(l_init_biometricId + g_idx) for update; 
          l_buffer := DEC_TO_LE_RAW5_BYTE(l_init_biometricId + g_idx);
          --dbms_output.put_line('l_buffer in procesure is: ' || l_buffer);
          l_len := utl_raw.length(l_buffer);
          DBMS_LOB.WRITE(l_template_data_edit, l_len,  l_strat, l_buffer); 
          l_insert_count := l_insert_count + 1;
          IF (mod(l_insert_count,1000) = 0) THEN
            commit;
          END IF;     
       END LOOP;        
     END LOOP;  
     UPDATE BIO_MATCHER_SEGMENT_INFO SET SEGMENT_VERSION= l_base_seg_ver ,UPDATE_DATETIME=SYSTIMESTAMP WHERE SEGMENT_ID=l_semgnet_id;     
    commit; 
    dbms_output.put_line ('BIN_ID:' || to_char(l_bin_id) ||' SEGMENT_ID:' ||l_semgnet_id || ' add count:' || to_char( l_insert_count));
   END LOOP;
     EXCEPTION
    WHEN OTHERS THEN
        dbms_output.Put_line ('Error Code:' 
                                   || To_char(SQLCODE) 
                                   || '  Error Message:' 
                                   || SQLERRM);
      ROLLBACK;   
END SAKURA_MANKAI_TOOL_WITH_EDIT;

/
