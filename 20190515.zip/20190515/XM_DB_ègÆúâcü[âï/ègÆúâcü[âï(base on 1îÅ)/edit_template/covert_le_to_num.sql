CREATE OR REPLACE FUNCTION  COVERT_LE_RAW5_TO_NUM
(
  RAW_DATA IN VARCHAR2 
) RETURN NUMBER  AUTHID CURRENT_USER AS 
  v_raw_data RAW(10);
  v_hexstr varchar2(10);
  v_inx number :=10;
  v_pad varchar2(10);
  v_rt number:=0;
BEGIN  
   v_inx := utl_raw.length(RAW_DATA) * 2;
   dbms_output.put_line(RAW_DATA);
   dbms_output.put_line(v_inx);   
   if ((nvl(utl_raw.length(RAW_DATA), 0)<=0) ) then
      return v_rt;
    end if;
    if (v_inx >= 10) then    
      v_raw_data := substr(RAW_DATA, 1, 10);
      v_hexstr := rawtohex(v_raw_data);
       dbms_output.put_line(v_hexstr);
    else
    v_inx := 10 - v_inx -1;
      v_pad := '0';
      for i in 1..v_inx loop
       v_pad := v_pad || '0';
     end loop;
      dbms_output.put_line(v_pad);     
      v_hexstr := rawtohex(RAW_DATA) || v_pad;  
      dbms_output.put_line(v_hexstr);
    end if;
      v_hexstr := substr(v_hexstr, 9, 2)
      || substr(v_hexstr, 7, 2)
      || substr(v_hexstr, 5, 2)
      || substr(v_hexstr, 3, 2)
      || substr(v_hexstr, 1, 2);
       dbms_output.put_line(v_hexstr);
    v_rt := to_number(trim(v_hexstr),'XXXXXXXXXX');
    dbms_output.put_line(v_rt);
    return v_rt;
END COVERT_LE_RAW5_TO_NUM;

/
