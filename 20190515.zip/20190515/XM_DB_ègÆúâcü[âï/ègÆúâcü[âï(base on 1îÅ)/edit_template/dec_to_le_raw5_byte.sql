
CREATE OR REPLACE FUNCTION  DEC_TO_LE_RAW5_BYTE
(
  DEC_NUM IN NUMBER  
) RETURN RAW  AUTHID CURRENT_USER IS 
  v_raw_data RAW(10);
  v_hexstr varchar2(10);
  v_inx_byte number :=10;
  v_pad varchar2(10);
   v_raw_tmp RAW(10);
BEGIN
  v_hexstr := to_char(DEC_NUM, 'XXXXXXXX'); 
   v_hexstr := trim(v_hexstr);
  v_inx_byte := 10- length(v_hexstr) -1;
  --dbms_output.put_line(v_inx_byte);
  v_pad := '0';
  for i in 1..v_inx_byte loop
     v_pad := v_pad || '0';
  end loop;
  v_hexstr := v_pad || v_hexstr;
  --dbms_output.put_line(v_hexstr);
  --dbms_output.put_line(length(v_hexstr));
   v_hexstr := substr(v_hexstr, 9, 2)
      || substr(v_hexstr, 7, 2)
      || substr(v_hexstr, 5, 2)
      || substr(v_hexstr, 3, 2)
      || substr(v_hexstr, 1, 2);
  --dbms_output.put_line(v_hexstr);
  --dbms_output.put_line(length(v_hexstr));    

  v_raw_data := hextoraw(v_hexstr);  
  --dbms_output.put_line(v_raw_data);
  --dbms_output.put_line(utl_raw.length(v_raw_data));

  RETURN v_raw_data;
END DEC_TO_LE_RAW5_BYTE;

/
