
DB 拡張ツールの使い方：

1. 条件
　　　XM DB user が普通に作る。
　　　Sync　データが1件以上に登録される（手動入力ではなく、Megha経由の登録。要は整合性があるデータ登録される)。

2． xm db userに　権限を与える
　　　sqlplus 実行環境で、以下を実行：
        sqlplus / as sysdba;
　　　　　　　GRANT CREATE ANY PROCEDURE TO 「xmuser」;

3. Load procedure to DB:
    sqlplus 実行環境で、以下を実行：
     sqlplus xmdbusr/xmdbuser@xmdb;
      SET SERVEROUTPUT ON;
      host cd to sakura_mannkai_xxx.sql が存在するディレクトリー
      @sakura_mannkai_muilt.sql;
      @sakura_mannkai.sql


 4. プロシージャの実行方法：     
　　　　  sqlplus xmdbusr/xmdbuser@xmdb;
      SET SERVEROUTPUT ON;
       exec SAKURA_MANKAI('TEMPLATE_TYPE_35',35, 10035,50);
        parameterの順序：templateType, binId, segmentId, expandSize


 5. PROCEDURE SAKURA_MANKAIの説明
　　　　これが一回の実行で、一つのBINに、一つのSegmentIDにデータ拡張して行く。

 6. PROCEDURE SAKURA_MANKAI_MUILTの説明
 　　　これが一回の実行で、複数のSegmentｓにデータを拡張していく
 　　　パラメータを多くで、入力が面倒であるため、XM_PERF_TEST　テーブルを作って、必要なパラメータはこのテーブルに入力することで、実行時には、入力不要になります。
       a. XM_PERF_TEST テーブル作成：
       　　　　 @create_xm_perf_table.sql
       b. XM_PERF_TEST テーブルにパラメータを登録：         　　
       　入力例：　 　　　　
     　　　　BIN_ID　　　TEMPLATE_TYPE　　　　　  　SEGMENT_ID　　　　　　EXPAND_SIZE
     　　　　　　1　　　　　　TEMPLATE_TYPE_1	　　　　  10001	　　　　　　　20000
     　　　　　　35	TEMPLATE_TYPE_35　　　　 1003501	　　　　　　　20000
　    　　　　　　35	TEMPLATE_TYPE_35     10003502	        20000

　　　　　 c. プロシージャを実行：　exec SAKURA_MANKAI_MUILT();

PROCEDURE SAKURA_MANKAI、SAKURA_MANKAI_MUILTのどちらを必要の応じて、ご利用ください。

===以上===

 
 　　　
     