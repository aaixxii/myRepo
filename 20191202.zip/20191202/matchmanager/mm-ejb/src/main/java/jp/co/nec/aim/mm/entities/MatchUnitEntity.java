package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MATCH_UNITS database table.
 * 
 */
@Entity
@Table(name = "MATCH_UNITS")
public class MatchUnitEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "MATCH_UNITS_MUID_GENERATOR", sequenceName = "SERVER_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MATCH_UNITS_MUID_GENERATOR")
	@Column(name = "MU_ID")
	private long muId;

	@Column(name = "CONTACT_URL")
	private String contactUrl;

	@Column(name = "NUMBER_OF_EXTRACTORS")
	private Integer numberOfExtractors;

	@Column(name = "NUMBER_OF_MATCHERS")
	private Integer numberOfMatchers;

	@Column(name = "PRIMARY_SIZE")
	private Long primarySize;

	@Column(name = "REPORTED_PERFORMANCE_FACTOR")
	private Double reportedPerformanceFactor;

	@Column(name = "SECONDARY_SIZE")
	private Long secondarySize;

	@Column(name = "\"STATE\"")
	@Enumerated(EnumType.STRING)
	private UnitState state;

	@Column(name = "UNIQUE_ID")
	private String uniqueId;

	@Column(name = "\"VERSION\"")
	private String version;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "MU_ID")
	private MuContactEntity times;
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "MU_ID")
	private MuInquiryLoadEntity inquiryLoad;
	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "MU_ID")
	private MuExtractLoadEntity extractLoad;

	public MatchUnitEntity() {
	}

	public long getMuId() {
		return this.muId;
	}

	public void setMuId(long muId) {
		this.muId = muId;
	}

	public String getContactUrl() {
		return this.contactUrl;
	}

	public void setContactUrl(String contactUrl) {
		this.contactUrl = contactUrl;
	}

	public Integer getNumberOfExtractors() {
		return this.numberOfExtractors;
	}

	public void setNumberOfExtractors(Integer numberOfExtractors) {
		this.numberOfExtractors = numberOfExtractors;
	}

	public Integer getNumberOfMatchers() {
		return this.numberOfMatchers;
	}

	public void setNumberOfMatchers(Integer numberOfMatchers) {
		this.numberOfMatchers = numberOfMatchers;
	}

	public Long getPrimarySize() {
		return this.primarySize;
	}

	public void setPrimarySize(Long primarySize) {
		this.primarySize = primarySize;
	}

	public Double getReportedPerformanceFactor() {
		return this.reportedPerformanceFactor;
	}

	public void setReportedPerformanceFactor(Double reportedPerformanceFactor) {
		this.reportedPerformanceFactor = reportedPerformanceFactor;
	}

	public Long getSecondarySize() {
		return this.secondarySize;
	}

	public void setSecondarySize(Long secondarySize) {
		this.secondarySize = secondarySize;
	}

	public UnitState getState() {
		return this.state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public String getUniqueId() {
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public MuContactEntity getTimes() {
		return times;
	}

	public void setTimes(MuContactEntity times) {
		this.times = times;
	}

	public MuInquiryLoadEntity getInquiryLoad() {
		return inquiryLoad;
	}

	public void setInquiryLoad(MuInquiryLoadEntity inquiryLoad) {
		this.inquiryLoad = inquiryLoad;
	}

	public MuExtractLoadEntity getExtractLoad() {
		return extractLoad;
	}

	public void setExtractLoad(MuExtractLoadEntity extractLoad) {
		this.extractLoad = extractLoad;
	}

}