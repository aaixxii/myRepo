package jp.co.nec.aim.mm.acceptor.service;

import java.io.IOException;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.ejb.EJBException;
import javax.ejb.ScheduleExpression;
import javax.ejb.Timer;
import javax.ejb.TimerConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.mm.common.HttpTestServer;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimManageServiceTest {

	@Resource
	private DataSource dataSource;
	@Resource
	private AimManageService aimManageService;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.execute("commit");

	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.execute("commit");

	}

	private static HttpTestServer _server = null;

	Map<String, String> contain = new HashMap<String, String>();

	@BeforeClass
	public static void init() throws Exception {
		_server = new HttpTestServer(65521);
		_server.start(getMockHandler());
	}

	@AfterClass
	public static void after() throws Exception {
		if (_server != null) {
			_server.stop();
		}
	}

	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				response.setStatus(200);
				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}

	@Test
	public void testInitialize() {
		new MockUp<AimManageService>() {
			@Mock
			public void initialize() {
				return;
			}
		};

		aimManageService.initialize();
	}

	static class TimeTest implements javax.ejb.TimerService {

		@Override
		public Timer createCalendarTimer(ScheduleExpression schedule)
				throws IllegalArgumentException, IllegalStateException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createCalendarTimer(ScheduleExpression schedule,
				TimerConfig timerConfig) throws IllegalArgumentException,
				IllegalStateException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createIntervalTimer(Date initialExpiration,
				long intervalDuration, TimerConfig timerConfig)
				throws IllegalArgumentException, IllegalStateException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createIntervalTimer(long initialDuration,
				long intervalDuration, TimerConfig timerConfig)
				throws IllegalArgumentException, IllegalStateException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createSingleActionTimer(Date expiration,
				TimerConfig timerConfig) throws IllegalArgumentException,
				IllegalStateException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createSingleActionTimer(long duration,
				TimerConfig timerConfig) throws IllegalArgumentException,
				IllegalStateException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createTimer(long duration, Serializable info)
				throws IllegalArgumentException, IllegalStateException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createTimer(long initialDuration, long intervalDuration,
				Serializable info) throws IllegalArgumentException,
				IllegalStateException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createTimer(Date expiration, Serializable info)
				throws IllegalArgumentException, IllegalStateException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Timer createTimer(Date initialExpiration, long intervalDuration,
				Serializable info) throws IllegalArgumentException,
				IllegalStateException, EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Collection<Timer> getTimers() throws IllegalStateException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public Collection<Timer> getAllTimers() throws IllegalStateException,
				EJBException {
			// TODO Auto-generated method stub
			return null;
		}

	}

}
