package jp.co.nec.aim.mm.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBCandidate;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataBlock;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBDataGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;

public class ProtobufCreater {
	
	public ProtobufCreater() {		
	}
	
	public SyncResponse createSyncResponse() {
		SyncResponse.Builder syncRes = SyncResponse.newBuilder();
		syncRes.setBatchJobId(1);
		syncRes.setType(BatchType.ENROLL);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);		
		pq.setEnrollmentId("enrollId1");
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		PBResponse.Builder pbRes = PBResponse.newBuilder();
		pbRes.setStatus("0:sucess");
		PBDataBlock.Builder dataBlock = PBDataBlock.newBuilder();
		PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
		template.setData(ByteString.copyFrom("template data".getBytes()));
		template.setReferenceId("enrollId1");
		dataBlock.setTemplateInfo(template.build());
		pbMsg.setDataBlock(dataBlock.build());
		syncRes.addBusinessMessage(pbMsg.build().toByteString());
		return syncRes.build();
		
	}
	
	
	public  SyncRequest createInsertRequest(E_REQUESET_TYPE reqType) {
		SyncRequest.Builder insertReq = SyncRequest.newBuilder();
		insertReq.setBatchJobId(1);
		insertReq.setType(BatchType.ENROLL);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(reqType);
		
		pq.setEnrollmentId("enrollId1");
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        if (reqType == E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
        	PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
        	template.setReferenceId("referenceId1");
		} else if (reqType == E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
			pbEl.setFilePath("/testpath");
			pbEl.setChecksum("checkSun");
		} 		
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		insertReq.addBusinessMessage(pbMsg.build().toByteString());
		return insertReq.build();
	}
	
	public IdentifyRequest createIdentifyRequest(E_REQUESET_TYPE type) {
		IdentifyRequest.Builder iqyReq = IdentifyRequest.newBuilder();
		iqyReq.setBatchJobId(11111);
		iqyReq.setType(BatchType.IDENTIFY);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("request1");
		pq.setEnrollmentId("enrollId1");
		pq.setRequestType(type);
		pq.setMaxResults(10);
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
		if (type == E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT) {			
			template.setReferenceId("enrollId1");			
		} else if (type == E_REQUESET_TYPE.IDENTIFY_DEFAULT) {
			template.setData(ByteString.copyFrom("I am aim uid template".getBytes()));
		}
		pbEl.setTemplateInfo(template.build());
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq).build();
		iqyReq.addBusinessMessage(pbMsg.build().toByteString());
		return iqyReq.build();	
	}
	
	public IdentifyRequest createIdentifyRequestWithErr(E_REQUESET_TYPE type) {
		IdentifyRequest.Builder iqyReq = IdentifyRequest.newBuilder();
		iqyReq.setBatchJobId(11111);
		iqyReq.setType(BatchType.IDENTIFY);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
		PBRequest.Builder pq = PBRequest.newBuilder();
		pbMsg.setRequest(pq.build());
		iqyReq.addBusinessMessage(pbMsg.build().toByteString());
		return iqyReq.build();		
	}
	
	public  ExtractRequest createExtractRequest() {
		ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
		extReq.setBatchJobId(11111);
		extReq.setType(BatchType.EXTRACT);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("request1");
		pq.setEnrollmentId("enroll1");
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pbEl.setFilePath("/testpath");
		pbEl.setChecksum("checkSun");
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		extReq.addBusinessMessage(pbMsg.build().toByteString());
		return extReq.build();
	}
	
	public  ExtractRequest createExtractRequestHaveErr() {
		ExtractRequest.Builder extReq = ExtractRequest.newBuilder();		
		extReq.setType(BatchType.EXTRACT);
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();			
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("request1");
		pq.setEnrollmentId("enroll1");
		pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
		PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
		pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
		PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
		pbEl.setFilePath("/testpath");
		pbEl.setChecksum("checkSun");
		pdBiData.setBiometricElement(pbEl.build());
		pq.setBiometricsData(pdBiData.build());
		pbMsg.setRequest(pq.build());
		extReq.addBusinessMessage(pbMsg.build().toByteString());
		return extReq.build();
	}
	
	
	
	
	public PBMuExtractJobResult createPBMuExtractJobResult(long muId, long lotJobId, long feJobid) {
		PBBusinessMessage pbMsg = createPBBusinessMessage();
		PBMuExtractJobResultItem.Builder muItem = PBMuExtractJobResultItem.newBuilder();
		muItem.setJobId(feJobid);
		muItem.setResult(pbMsg.toByteString());
		PBMuExtractJobResult.Builder pBMuExtractJobResult = PBMuExtractJobResult.newBuilder();
		pBMuExtractJobResult.setMuId(muId);
		pBMuExtractJobResult.setLotJobId(lotJobId);
		pBMuExtractJobResult.addResult(0, muItem.build());
		return pBMuExtractJobResult.build();		
		
	}
	
	public PBBusinessMessage createPBBusinessMessage() {
		PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();		
		PBRequest.Builder pq = PBRequest.newBuilder();
		pq.setRequestId("12");
		pq.setRequestType(E_REQUESET_TYPE.IDENTIFY_DEFAULT);
		pbMsg.setRequest(pq);
		PBResponse.Builder ps = PBResponse.newBuilder();
		ps.setStatus("0");
		pbMsg.setResponse(ps);
		PBDataBlock.Builder pd = PBDataBlock.newBuilder();
		List<PBCandidate> pbList = Lists.newArrayList();
		for (int i = 0 ; i < 5; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("enroll");
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 4; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("external");
			pb.setScaledScore(10 + i);			
			pbList.add(pb.build());
		}
		
		for (int i = 0 ; i < 7; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("test" );
			pb.setScaledScore(27 + i);			
			pbList.add(pb.build());
		}
		for (int i = 0 ; i < 10; i++) {
			PBCandidate.Builder pb = PBCandidate.newBuilder();
			pb.setEnrollmentId("xia" + i);
			pb.setScaledScore(100 + i);			
			pbList.add(pb.build());
		}	
		
		Collections.shuffle(pbList); 		
		
		pd.getCandidateListBuilder().addAllCandidates(pbList);
		pd.getCandidateListBuilder().setMore(false);
		
		List<PBDataElement> pbDeList= new ArrayList<>();
		for (int i = 0 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("read");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 3 ; i < 6; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("rmf");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		for (int i = 1 ; i < 5; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("iris");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		
		for (int i = 5; i < 10; i++) {
			PBDataElement.Builder pb = PBDataElement.newBuilder();
			pb.setElementName("face");
			pb.setElementValue(String.valueOf(i));
			pbDeList.add(pb.build());
		}
		System.out.print(pbDeList.toString());
		Collections.shuffle(pbDeList); 		
		PBDataGroup.Builder pg = PBDataGroup.newBuilder();
		pg.setGroupName("amr");
		for (int i = 0; i < pbDeList.size(); i++) {
			pg.addDataElement(i, pbDeList.get(i));
		}
		
		pd.addDataGroup(pg.build());		
		pbMsg.setDataBlock(pd.build());
		return pbMsg.build();
		
	}

}
