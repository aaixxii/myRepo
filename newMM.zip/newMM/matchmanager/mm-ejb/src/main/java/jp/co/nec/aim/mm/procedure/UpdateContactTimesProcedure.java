package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * UpdateContactTimesProcedure
 * 
 * @author liuyq
 * 
 */
public class UpdateContactTimesProcedure extends StoredProcedure {
	private static final String SQL = "MATCH_MANAGER_API.update_contact_times";
	private Long unitId;
	private int unitType;

	/**
	 * UpdateContactTimesProcedure constructor
	 * 
	 * @param dataSource
	 *            the instance of dataSource
	 */
	public UpdateContactTimesProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_unit_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_unit_type", Types.INTEGER));
		compile();
	}

	/**
	 * execute the Procedure
	 */
	public void execute() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_unit_id", getUnitId());
		map.put("p_unit_type", getUnitType());
		execute(map);
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());
	}

	public int getUnitType() {
		return unitType;
	}

	public void setUnitType(int unitType) {
		this.unitType = unitType;
	}

	public Long getUnitId() {
		return unitId;
	}

	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

}
