package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * IncreaseRUCProcedure
 * 
 * @author liuyq
 * 
 */
public class UpdateInquiryLoadProcedure extends StoredProcedure {
	/** SQL **/
	private static final String SQL = "MATCH_MANAGER_API.update_inquiry_load";

	private Integer muId; // MU id
	private Long inquiryLoad; // inquiry load

	/**
	 * IncreaseRUCProcedure
	 * 
	 * @param dataSource
	 */
	public UpdateInquiryLoadProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);

		declareParameter(new SqlParameter("p_mu_id", Types.INTEGER));
		declareParameter(new SqlParameter("p_inquiry_load", Types.INTEGER));

		compile();
	}

	/**
	 * execute IncreaseRUCProcedure
	 */
	public void execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_id", getMuId());
		map.put("p_inquiry_load", getInquiryLoad());

		execute(map);
	}

	public Integer getMuId() {
		return muId;
	}

	public void setMuId(Integer muId) {
		this.muId = muId;
	}

	public Long getInquiryLoad() {
		return inquiryLoad;
	}

	public void setInquiryLoad(Long inquiryLoad) {
		this.inquiryLoad = inquiryLoad;
	}

}
