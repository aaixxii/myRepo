package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the SCOPES database table.
 * 
 */
@Entity
@Table(name = "SCOPES")
@NamedQuery(name = "ScopeEntity.findAll", query = "SELECT s FROM ScopeEntity s")
public class ScopeEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SCOPES_SCOPEID_GENERATOR", sequenceName = "SCOPES", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SCOPES_SCOPEID_GENERATOR")
	@Column(name = "SCOPE_ID")
	private long scopeId;

	public ScopeEntity() {
	}

	public long getScopeId() {
		return this.scopeId;
	}

	public void setScopeId(long scopeId) {
		this.scopeId = scopeId;
	}

}