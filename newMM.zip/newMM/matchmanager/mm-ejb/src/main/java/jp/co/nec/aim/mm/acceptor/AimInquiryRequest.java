package jp.co.nec.aim.mm.acceptor;

import java.io.Serializable;
import java.util.List;

import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;



/**
 * InquiryRequest
 * 
 * @author liuyq
 * 
 */
public final class AimInquiryRequest implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1485113056588337155L;

	private String functionName; // inquiry functionName
	private List<Integer> containerId; // container id list unique
	// Request instance Serialization
	// Fusion job [INQUIRY_JOB_DATA]
	private IdentifyRequest.Builder request;

	/**
	 * InquiryRequest
	 * 
	 * @param containerId
	 * @param binary
	 * @param eventId
	 * @param externalId
	 */
	public AimInquiryRequest(String functionName, List<Integer> containerId,
			IdentifyRequest.Builder request) {
		this.functionName = functionName;
		this.containerId = containerId;
		this.setRequest(request);
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public List<Integer> getContainerId() {
		return containerId;
	}

	public void setContainerId(List<Integer> containerId) {
		this.containerId = containerId;
	}

	public IdentifyRequest.Builder getRequest() {
		return request;
	}

	public void setRequest(IdentifyRequest.Builder request) {
		this.request = request;
	}

}
