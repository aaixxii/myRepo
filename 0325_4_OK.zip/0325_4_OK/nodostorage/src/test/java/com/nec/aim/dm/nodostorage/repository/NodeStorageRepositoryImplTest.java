package com.nec.aim.dm.nodostorage.repository;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.nec.aim.dm.nodostorage.NodostorageApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { NodostorageApplication.class })
public class NodeStorageRepositoryImplTest {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;	
	
	@Autowired
    private NodeStorageRepository nodeStorageRepository;
	

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetMyMailFlag() {
		fail("まだ実装されていません");
	}

	@Test
	public void testGetStorageSize() {
		fail("まだ実装されていません");
	}

	@Test
	public void testUpdateStorageSize()  {
	
		try {
			nodeStorageRepository.updateStorageSize(26, 1, "dm_storage1");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
