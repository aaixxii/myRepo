package com.nec.aim.dm.monitor.utp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UdpMulticastSender {
	private int multCastPort;
	private String multCastIP = "230.1.1.1";

	public void init() {
	}
	//224.0.1.0～224.0.1.255 muit ips
	public void send() {
		DatagramSocket udpSocket = null;
		try {
			udpSocket = new DatagramSocket();
		    InetAddress mcIPAddress = InetAddress.getByName(multCastIP);
		    byte[] msg = "Hello".getBytes();
		    DatagramPacket packet = new DatagramPacket(msg, msg.length);
		    packet.setAddress(mcIPAddress);
		    packet.setPort(multCastPort);
		    udpSocket.send(packet);
		    System.out.println("Sent a  multicast message.");
		    System.out.println("Exiting application");	    
			
		} catch (Exception e) {
			
		} finally {
			udpSocket.close();
		}
	
	}

}
