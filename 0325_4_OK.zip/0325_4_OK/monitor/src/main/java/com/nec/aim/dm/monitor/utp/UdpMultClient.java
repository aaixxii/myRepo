package com.nec.aim.dm.monitor.utp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class UdpMultClient {
	   public static void main(String[] args) throws IOException{
	        MulticastSocket ms=null; 
	        DatagramPacket dataPacket = null; 
	        ms = new MulticastSocket();
	        ms.setTimeToLive(32); 
	         byte[] data = "街上的美女们".getBytes();   
	         InetAddress address = InetAddress.getByName("239.0.1.255");   
	         dataPacket = new DatagramPacket(data, data.length, address,8899);  
	         ms.send(dataPacket);  
	         ms.close();   
	    }

}
