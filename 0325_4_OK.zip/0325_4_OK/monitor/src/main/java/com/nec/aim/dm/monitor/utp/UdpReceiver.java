package com.nec.aim.dm.monitor.utp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.util.Iterator;

public class UdpReceiver {
	 private int port;
	  private DatagramChannel channel;
	  private Selector selector;
	  
	  public void init () throws IOException {
		  selector = Selector.open();
		    channel = DatagramChannel.open();		  
		    channel.configureBlocking(false);
		    channel.socket().bind(new InetSocketAddress(port));		   
		    channel.register(selector, SelectionKey.OP_READ);
	  }
	  
	public void service() {
		try {
			while (selector.select() > 0) {
				Iterator<SelectionKey> iterator = selector.selectedKeys().iterator();
				while (iterator.hasNext()) {
					SelectionKey key = null;
					try {
						key = iterator.next();
						iterator.remove();
						if (!key.isValid()) {
							continue;
						}
						if (key.isReadable()) {
							doReceive(key);
						}

					} catch (Exception e) {
						e.printStackTrace();
						if (key != null) {
							key.cancel();
							key.channel().close();
						}
					}
				}//#while
			}// #while
		} catch (IOException e) {			
			e.printStackTrace();
		}
	}

	private void doReceive(SelectionKey key) {
		String content = "";
		try {
			DatagramChannel sc = (DatagramChannel) key.channel();
			ByteBuffer buffer = ByteBuffer.allocate(4);
			buffer.clear();
			sc.receive(buffer);
			buffer.flip();
			while (buffer.hasRemaining()) {
				byte[] buf = new byte[buffer.limit()];
				buffer.get(buf);
				content += new String(buf);
			}
			buffer.clear();
			System.out.print(content);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
