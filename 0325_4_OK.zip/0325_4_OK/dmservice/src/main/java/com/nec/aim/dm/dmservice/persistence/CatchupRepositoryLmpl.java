package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.Catchup;

@Repository
public class CatchupRepositoryLmpl implements CatchupRepository{
	
	private static final String insertForNewSql = "insert into catchup(storage_id,segment_id,segment_version, change_type) values(?,?,?,?)";
	private static final String insertSql = "insert into catchup(storage_id,biometrics_id,external_id,template_data,segment_id,segment_version, change_type) values(?,?,?,?,?,?,?)";
	private static final String deleteSql = "insert into catchup(storage_id,biometrics_id,external_id,segment_id,segment_version, change_type) values(?,?,?,?,?,?)";
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Override
	public void insertForNewSegment(Integer storageId, Long segmentId, Long segmentVer, Integer catchUp) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertForNewSql, new Object[] {storageId, segmentId, segmentVer, catchUp});
		
	}

	@Override
	public void insert(Catchup catchUp) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql, new Object[] {catchUp.getStorageId(), catchUp.getBiometricsId(), catchUp.getExternalId(), catchUp.getTemplateData(), catchUp.getSegmentId(), catchUp.getSegmentVersion(),catchUp.getChangeType()});
	}

	@Override
	public void delete(Catchup catchUp) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(deleteSql, new Object[] {catchUp.getStorageId(), catchUp.getBiometricsId(), catchUp.getExternalId(), catchUp.getSegmentId(), catchUp.getSegmentVersion(),catchUp.getChangeType()});
	}
}
