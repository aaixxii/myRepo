package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

import com.nec.aim.dm.dmservice.entity.Catchup;

public interface CatchupRepository {
	public void insertForNewSegment(Integer storageId, Long segmentId, Long segmentVer, Integer catchUpp) throws SQLException;
	public void insert(Catchup catchUp) throws SQLException;
	public void delete(Catchup catchUp) throws SQLException;
}
