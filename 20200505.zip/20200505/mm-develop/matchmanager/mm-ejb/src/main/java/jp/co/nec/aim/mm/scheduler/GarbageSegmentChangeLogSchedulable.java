package jp.co.nec.aim.mm.scheduler;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.sessionbeans.GarbageSegChangeLogBean;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.util.JndiLookup;
import jp.co.nec.aim.mm.util.TimeHelper;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class GarbageSegmentChangeLogSchedulable extends AbstractJob {

	private static final Logger log = LoggerFactory
			.getLogger(GarbageSegmentChangeLogSchedulable.class);
	private static final String TITLE = "GarbageSegmentChangeLog";
	private GarbageSegChangeLogBean garbageSegChangeLogBean;

	public GarbageSegmentChangeLogSchedulable() {
		garbageSegChangeLogBean = JndiLookup.lookUp(
				JNDIConstants.GARBAGESEGCHANGELOGBEAN,
				GarbageSegChangeLogBean.class);
	}

	@Override
	public void executeJob(JobExecutionContext context)
			throws JobExecutionException {
		if (log.isDebugEnabled()) {
			log.debug("GarbageSegmentChangeLogSchedulable start...");
		}
		TimeHelper timeHelper = new TimeHelper(TITLE);
		timeHelper.t();
		try {
			garbageSegChangeLogBean.execute();
		} catch (Exception e) {
			String message = "Exception during " + TITLE;
			log.error(message, e);
			AimError error = AimError.SCHEDULABLE_ERROR;
			ExceptionSender exceptionSender = new ExceptionSender();
			exceptionSender.sendAimException(error.getErrorCode(),
					String.format(error.getMessage(), e.getMessage()), e);
		}
		timeHelper.t();
		if (log.isDebugEnabled()) {
			log.debug(timeHelper.message());
			log.debug("GarbageSegmentChangeLogSchedulable end...");
		}
	}

	@Override
	protected String getTitle() {
		return TITLE;
	}
}
