package jp.co.nec.aim.mm.procedure;

import java.sql.Array;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleTypes;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class GetMuPressureAbilityProcedure extends StoredProcedure {
	private static final String GET_MU_PRESSURE_ABILITY = "MATCH_MANAGER_API.get_mu_pressure_ability";
	private static final String NUM_TABLE_TYPE = "NUM_TABLE_TYPE";
	private Integer[] muIdArray;

	public GetMuPressureAbilityProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(GET_MU_PRESSURE_ABILITY);
		declareParameter(new SqlParameter("p_mu_ids", Types.ARRAY,
				NUM_TABLE_TYPE));
		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
				new CursorMapper()));
		compile();
	}

	public Integer[] getMuIdArray() {
		return muIdArray;
	}

	public void setMuIdArray(Integer[] muIdArray) {
		this.muIdArray = muIdArray;
	}

	/**
	 * 
	 * @param muId
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	@SuppressWarnings("unchecked")
	public List<MuCpuAndPressure> getMuPressureAndAbility(Integer[] muIds)
			throws DataAccessException, SQLException {
		if (muIds.length < 1) {
			throw new IllegalArgumentException(
					"muIds == null when call getMuPressureAndAbility procedure");
		}
		setMuIdArray(muIds);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_ids", new AbstractSqlTypeValue() {
			public Object createTypeValue(Connection con, int sqlType,
					String typeName) throws SQLException {
				return createMuIdsArrayType(con);
			}
		});

		Map<String, Object> resultMap = execute(map);
		List<MuCpuAndPressure> muCpuandPressureList = (List<MuCpuAndPressure>) resultMap
				.get("p_refcursor");
		return muCpuandPressureList;
	}

	private Array createMuIdsArrayType(Connection con) throws SQLException {
		OracleConnection oraConn = con.unwrap(OracleConnection.class);
		return oraConn.createARRAY(NUM_TABLE_TYPE, getMuIdArray());
	}

	/**
	 * 
	 * @author xiazp
	 *
	 */
	private class CursorMapper implements RowMapper<MuCpuAndPressure> {
		@Override
		public MuCpuAndPressure mapRow(ResultSet rs, int row)
				throws SQLException {
			MuCpuAndPressure oneResult = new MuCpuAndPressure();
			oneResult.setMuId(rs.getInt("mu_id"));
			oneResult.setAbility(rs.getDouble("ability"));
			oneResult.setPressure(rs.getLong("pressure"));
			oneResult.setReportTs(rs.getLong("report_ts"));
			return oneResult;
		}
	}
}
