(function(metricsDatabase, $, undefined) {
	var metricsDb = {
	};
	
	var latestSnapshotDb = {
	};

	var defaultTimezone;
	var browserServerTimestampDiff=0;
	var metricDataDownloadUrl;
	var pollIntervalMilli=30000;
	var pollTimeoutVar;
	var downloadUpdatesOnly = "false";
	var downloadListeners={};
	var defaultChartWindowMinutes=5;
	
	metricsDatabase.startDownloadingServerMetrics=function(metricDataDownloadUrlVal, pollIntervalMilliVal, defaultChartWindowMinutesVal, timezoneDataBasePathVal, serverTimeZone) {
		if(timezoneDataBasePathVal) {
			timezoneDataBasePath = timezoneDataBasePathVal;
		}
		
		if(metricDataDownloadUrlVal) {
			metricDataDownloadUrl = metricDataDownloadUrlVal;	
		}
		
		if(serverTimeZone && timezoneDataBasePathVal) {
			if(!(serverTimeZone===defaultTimezone)){
				metricsDatabase.setTimeZone(serverTimeZone, timezoneDataBasePath);
			}
		}
		
		if(pollTimeoutVar) {
			return;
		}
		
		if(defaultChartWindowMinutesVal) {
			defaultChartWindowMinutes = defaultChartWindowMinutesVal;
		}
		
		if(pollIntervalMilliVal) {
			pollIntervalMilli = pollIntervalMilliVal;
		}
		
		console.log("In startDownloadingServerMetrics: pollIntervalMilliVal: "+pollIntervalMilliVal+", defaultChartWindowMinutesVal: "+defaultChartWindowMinutesVal+", metricDataDownloadUrlVal: "+metricDataDownloadUrlVal);
		
		pollTimeoutVar = window.setTimeout(downloadServerMetrics, 10);
	}
	
	metricsDatabase.registerDownloadListenerFunction=function(downloadListenerName, downloadListenerFunction) {
		downloadListeners[downloadListenerName]=downloadListenerFunction;
		console.log("After registerDownloadListenerFunction: "+downloadListenerName);
	}

	metricsDatabase.unregisterDownloadListenerFunction=function(downloadListenerName) {
		if(downloadListeners){
			for(var tempDownloadListenerName in downloadListeners) {
				try {
					downloadListeners[downloadListenerName]=null;
					delete downloadListeners[downloadListenerName];
					console.log("After unregisterDownloadListenerFunction: "+downloadListenerName);
				}
				catch(err) {
					console.log("Error in metricsDatabase.unregisterDownloadListenerFunction for tempDownloadListenerName: "+tempDownloadListenerName+", err: "+err);
				}
			}
		}
		
	}

	metricsDatabase.getServerTimezone=function(){
		return defaultTimezone;
	}

	metricsDatabase.setTimeZone = function(serverTimezone, timezoneDataBasePath, serverTimestamp) {
		console.log("In metricsDatabase.setTimeZone");
		try {
			if(!serverTimezone) {
				console.log("Error in metricsDatabase.setTimeZone: serverTimezone is not set, current defaultTimezone: "+defaultTimezone);
				return;
			}
			
			if(!timezoneDataBasePath) {
				console.log("Error in metricsDatabase.setTimeZone: timezoneDataBasePath is not set, current defaultTimezone: "+defaultTimezone);
				return;
			}
			
			if(serverTimezone===defaultTimezone) {
				return;
			}
			
			timezoneJS.timezone.zoneFileBasePath = timezoneDataBasePath;
			timezoneJS.timezone.defaultZoneFile = [];
			timezoneJS.timezone.init({async: false});
			
			defaultTimezone = serverTimezone;
			
			if(serverTimestamp) {
				//Adjust timestamp diff between browser and server
				browserServerTimestampDiff = (new Date()).getTime()-serverTimestamp; 
			}
			
		}
		catch(err) {
			console.log("Error in metricsDatabase.setTimeZone: setting the server timezone: "+serverTimezone+", timezoneDataBasePath: "+timezoneDataBasePath+", err : "+err);
		}
	}
	
	
	
	metricsDatabase.getLatestSnapshot=function() {
		return latestSnapshotDb;
	}
	
	metricsDatabase.getXYSeriesData=function(filterFunc, xAxisValueFunc, yAxisValueFunc) {

		var seriesData=[];
		for(var metricKey in metricsDb) {
			var metricRow = metricsDb[metricKey];
			var metricValues = metricRow["metricValues"];
			
			if(!metricValues) {
				continue;
			}
			
			if(!filterFunc(metricRow)) {
				continue;
			}
			
			for(var i=0;i<metricValues.length;i++) {
				var metric = metricValues[i];
				var xValue = xAxisValueFunc(metricRow, metric);
				var yValue = yAxisValueFunc(metricRow, metric);
				
				if((!xValue && xValue!==0) || (!yValue && yValue!==0)){
					console.log("Invalid xValue("+xValue+") or yValue("+yValue+") for i: "+i+", metricKey: "+metricKey+", metric: "+JSON.stringify(metric));
					continue;
				}
				
				seriesData.push([xValue, yValue]);
			}
		}
		
		return seriesData;
	}
	
	metricsDatabase.getXYMultiSeriesData=function(filterFunc, multiSeriesFieldName, xAxisValueFunc, yAxisValueFunc, yAxisAggrigateFunc) {
		var multiSeriesData={};
		for(var metricKey in metricsDb) {
			var metricRow = metricsDb[metricKey];
			var metricValues = metricRow["metricValues"];
			
			if(!metricValues) {
				continue;
			}
			
			var multiSeriesFieldValue=metricRow[multiSeriesFieldName];
			if(!multiSeriesFieldValue) {
				continue;
			}
			
			if(!filterFunc(metricRow)) {
				//console.log("metric row is ignored due to filter function for metricKey: "+metricKey);
				continue;
			}
			
			
			for(var i=0;i<metricValues.length;i++) {
				var metric = metricValues[i];
				var xValue = xAxisValueFunc(metricRow, metric);
				var yValue = yAxisValueFunc(metricRow, metric);
				
				if((!xValue && xValue!==0) || (!yValue && yValue!==0)){
					console.log("Invalid xValue("+xValue+") or yValue("+yValue+") for i: "+i+", metricKey: "+metricKey+", metric: "+JSON.stringify(metric));
					continue;
				}
				
				var seriesData = multiSeriesData[multiSeriesFieldValue];
				
				if(yAxisAggrigateFunc) {
					if(!seriesData) {
						seriesData = {};
						multiSeriesData[multiSeriesFieldValue] = seriesData; 
					}
					
					var yValues = seriesData[xValue];
					if(!yValues) {
						yValues = [];
						seriesData[xValue] = yValues; 
					}
					yValues.push(yValue);
				}
				else {
					if(!seriesData) {
						seriesData = [];
						multiSeriesData[multiSeriesFieldValue] = seriesData; 
					}
					seriesData.push([xValue, yValue]);
				}
			}
		}
		
		if(yAxisAggrigateFunc) {
			var newMultiSeriesData={};
			for(var multiSeriesFieldValue in multiSeriesData) {
				var seriesData = multiSeriesData[multiSeriesFieldValue];
				var newSeriesData = [];
				
				for(var xValue in seriesData) {
					var yValues = seriesData[xValue];
					var yValue = yAxisAggrigateFunc(yValues);
					newSeriesData.push([xValue, yValue]);
				}
				newMultiSeriesData[multiSeriesFieldValue]=newSeriesData;
			}
			
			return newMultiSeriesData;
		}
		else {
			return multiSeriesData;
		}
	}
	
	metricsDatabase.addData = function(metricsDataObj) {
		
		var serverHost = metricsDataObj["serverHost"];
		var timestamp = metricsDataObj["timestamp"];
		
		//console.log("In addData: serverHost: "+serverHost+", timestamp: "+timestamp);//+", metricsDataObj: "+JSON.stringify(metricsDataObj));

		for(var metricType in metricsDataObj) {
			if(metricType =="version" || metricType =="timestamp" || metricType =="serverHost") {
				continue;
			}

			var metricList = metricsDataObj[metricType];
			for(var metricKey in metricList) {
				var metric = metricList[metricKey];
				metric["timestamp"]=timestamp;
				
				var recordKey = "serverHost."+serverHost+"."+ metricKey				
				
				var metricRow = metricsDb[recordKey];
				if(!metricRow) {
					metricRow = buildMetricRow(metricType, metricKey, serverHost, true);
					if(!metricRow) {
						continue;
					}
					metricsDb[recordKey] =  metricRow;
				}
				
				if(metricType==="timers" || metricType==="meters" || metricType==="histograms"){
					metric["currentCount"]=Math.min(300, metric["count"]);
				}
				
				//Pouplate to metrics database
				var metricValues = metricRow["metricValues"];
				
				if(metricValues.length>0) {
					var oldTimestamp = metricValues[metricValues.length-1]["timestamp"];
					if(!oldTimestamp || oldTimestamp>timestamp) {
						continue;
					}
					
					if(oldTimestamp===timestamp) {
						metricValues[metricValues.length-1] = metric;
						
						if(metricValues.length>1 && (metricType==="timers" || metricType==="meters" || metricType==="histograms")){
							if(metric["count"]>metricValues[metricValues.length-2]["count"]) {
								metric["currentCount"]=Math.min(300, metric["count"]-metricValues[metricValues.length-2]["count"]);
							}
							else {
								metric["currentCount"]=Math.min(300, metric["count"]);
							}
						}
						
						continue;
					}
					else if(oldTimestamp<timestamp) {
						if(metricType==="timers" || metricType==="meters" || metricType==="histograms"){
							if(metric["count"]>metricValues[metricValues.length-1]["count"]) {
								metric["currentCount"]=Math.min(300, metric["count"]-metricValues[metricValues.length-1]["count"]);
							}
							else {
								metric["currentCount"]=Math.min(300, metric["count"]);
							}
						}
					}
					
					if(browserServerTimestampDiff) {
						//Remove old metric data from memory
						var loopCount = 0;
						var removeTimestamp = (new Date()).getTime()-(defaultChartWindowMinutes*60*1000)-browserServerTimestampDiff;
						while(loopCount<10 && metricValues.length>0 && metricValues[0]["timestamp"]<removeTimestamp) {
							metricValues.shift();
							loopCount = loopCount +1;
							console.log("Clearing metricValues loopCount: "+loopCount);
						}
					}
				}
				
				metricValues.push(metric);
				
				//Update latest snapshot
				if(!latestSnapshotDb[recordKey]) {
					latestSnapshotDb[recordKey] = buildMetricRow(metricType, metricKey, serverHost, false);
				}
				latestSnapshotDb[recordKey]["metricValues"] =  metric;
			}
		}
		
		//console.log(JSON.stringify(metricsDb));
	};
	
	function buildMetricRow(metricType, metricKey, serverHost, includeMetricValuesFieldFlag) {
		var jsonObj ={};
		jsonObj["metricType"] = metricType;
		jsonObj["serverHost"] = serverHost;
		var keyParts = metricKey.split(".");
		if (keyParts.length % 2 == 0) {
			console.log("Invalid metricKey: "+metricKey);
			return;
		}
		jsonObj["measurement"] = keyParts[keyParts.length - 1];
		for (var i = 0; i < keyParts.length - 1; i += 2) {
			jsonObj[keyParts[i]] = keyParts[i + 1];
		}
		
		if(includeMetricValuesFieldFlag) {
			jsonObj["metricValues"]=[];
		}
		
		//Indexing
		/*
		if(jsonObj["componentType"] && jsonObj["serverId"]) {
			if(!componentTypeServerIdList[jsonObj["componentType"]]) {
				componentTypeServerIdList[jsonObj["componentType"]]=[];
			}
			var serverIdList = componentTypeServerIdList[jsonObj["componentType"]];
			
			if ($.inArray(jsonObj["serverId"], serverIdList) === -1) {
				serverIdList.push(jsonObj["serverId"]);
		    }
		}
		*/
		return jsonObj;
	}
	
	function downloadServerMetrics() {
		if(pollTimeoutVar) {
			window.clearTimeout(pollTimeoutVar);
		}
		
		try {
			$.ajax({
				dataType: "json",
				type : 'GET',
				url : metricDataDownloadUrl,
				cache: false,
				async: true,
				data: {
					updatesFlag: downloadUpdatesOnly,
				},
				success : function(metricDataPayload){
					saveMetricData(metricDataPayload);
					notifyDownloadCompleted();
					pollTimeoutVar = window.setTimeout(downloadServerMetrics, pollIntervalMilli);
				},
				error : function(XMLHttpRequest, textStatus, errorThrown){
					console.log("Error getting metrics data, downloadUpdatesOnly: "+downloadUpdatesOnly , ""+XMLHttpRequest.responseText+"");
					pollTimeoutVar = window.setTimeout(downloadServerMetrics, pollIntervalMilli);
				}
			});
		}
		catch(err) {
			errorAlert("Error in downloadServerMetrics: "+err.message);
		}
	}
	
	function saveMetricData(metricDataPayload) {
		downloadUpdatesOnly="true";
		
		if(!metricDataPayload || $.isEmptyObject(metricDataPayload)) {
			return;
		}
		
		if(!metricDataPayload["data"] || $.isEmptyObject(metricDataPayload["data"])) {
			return;
		}
		
		for(var i=0;i<metricDataPayload["data"].length;i++) {
			try {
				metricsDatabase.addData(metricDataPayload["data"][i]);	
			}
			catch(err){
				console.log("Error in saveMetricData: adding index : "+i+" : "+err);
			}
		}
	}
	
	function notifyDownloadCompleted() {
		for(var listenerName in downloadListeners) {
			var listenerFunc = downloadListeners[listenerName];
			if(!listenerFunc) {
				console.log("Error in notifyDownloadCompleted: cannot find listener function for listenerName: "+listenerName);
				continue;
			}
			try {
				//console.log("In notifyDownloadCompleted before calling listener for listenerName: "+listenerName);
				listenerFunc();
			}
			catch(err) {
				console.log("Error in notifyDownloadCompleted for listenerName: "+listenerName + " : "+err);
			}
		}
	}
	
	function getUniqueItems(items, filterField) {
		var uniqueList = [];
		var uniqueResult = [];

		$.each(items, function(index, item) {
			var chkValue =  filterField?item[filterField]:item;
		    if ($.inArray(chkValue, uniqueList) === -1) {
		    	uniqueList.push(chkValue);
		    	uniqueResult.push(item);
		    }
		});	
		
		return uniqueResult;
	}
	
	function getUniqueValues(items, filterField) {
		var uniqueList = [];
		$.each(items, function(index, item) {
			var chkValue =  filterField?item[filterField]:item;
		    if ($.inArray(chkValue, uniqueList) === -1) {
		    	uniqueList.push(chkValue);
		    }
		});	
		
		return uniqueList;
	}
	
}(window.metricsDatabase = window.metricsDatabase || {}, jQuery));