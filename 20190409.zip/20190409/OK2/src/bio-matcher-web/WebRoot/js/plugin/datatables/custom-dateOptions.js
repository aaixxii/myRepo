var dateFormat = 'MM/DD/YYYY HH:mm:ss';
function initgetdateRange(dateId){
	var id = '#' + dateId;
	var span = id + " span";
	function getDateRangePickerOptions(){
		var rangeOptions = {
			startDate: moment().subtract(29, 'days').startOf('days'),
			endDate: moment().endOf('days'),
			minDate: '01/01/1900',
			maxDate: '12/31/2100',
			dateLimit: { days: 1000000 },
			showDropdowns: true,
			showWeekNumbers: true,
			timePicker: true,
			timePickerIncrement: 1,
			timePicker12Hour: false,
			timePicker24Hour: true,
			timePickerSeconds: true,
			ranges: {
			   'Today': [moment().startOf('days'), moment().endOf('days')],
			   'Yesterday': [moment().subtract(1, 'days').startOf('days'), moment().subtract(1, 'days').endOf('days')],
			   'Last 7 Days': [moment().subtract(6, 'days').startOf('days'), moment().endOf('days')],
			   'Last 30 Days': [moment().subtract(29, 'days').startOf('days'), moment().endOf('days')],
			   'This Month': [moment().startOf('month').startOf('days'), moment().endOf('month').endOf('days')],
			   'Last Month': [moment().subtract(1, 'month').startOf('month').startOf('days'), moment().subtract(1, 'month').endOf('month').endOf('days')]
			},
			opens: 'left',
			buttonClasses: ['btn btn-default'],
			applyClass: 'btn-small btn-primary',
			cancelClass: 'btn-small',
			separator: ' to ',
			locale: {
				applyLabel: 'Submit',	
				cancelLabel: 'Clear',
				fromLabel: 'From',
				toLabel: 'To',
				customRangeLabel: 'Custom',
				format : dateFormat,
				daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr','Sa'],
				monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
				firstDay: 1
			}
		}; 
		return rangeOptions;
	}
	var rangeOptions = getDateRangePickerOptions(); 
	var cb = function(start, end, label) {
		$(span).html(start.format(dateFormat) + ' - ' + end.format(dateFormat));
	}
	$('[id^=date_] span').html('From - To <i class="fa fa-calendar"></i>');
	$(id).daterangepicker(rangeOptions, cb);
}

function initgetDate(dateId){
	var id = '#' + dateId;
	var span = id + " span";
	
	function getDateOption(){
		var dateOptions ={
		startDate : moment().subtract(29, 'days').startOf('month'),
		endDate : moment().startOf('month'),
		minDate : '01/01/1900',
		maxDate : '12/31/2100',
		dateLimit : {
			days : 1000000
		},
		showDropdowns : true,
		opens : 'right',
		buttonClasses : [ 'btn btn-default' ],
		applyClass : 'btn-small btn-primary',
		cancelClass : 'btn-small',
		separator : ' to ',
		singleDatePicker : true,
		"timePicker": true,
		"timePicker12Hour": false,
		"timePicker24Hour": true,
		"timePickerSeconds": true,
        "timePickerIncrement": 1,
		locale : {
			applyLabel : 'Submit',
			cancelLabel : 'Clear',
			fromLabel : 'From',
			toLabel : 'To',
			firstDay : 1
			}
		}; 
		return dateOptions;
	}
	
	var dateOptions = getDateOption();
	
	$(id).daterangepicker(dateOptions, function(start, end, label) {
		$(id).val(start.format(dateFormat));
	});
	
	$(id).on('apply.daterangepicker',function(ev, picker) {
		$(span).html(picker.startDate.format(dateFormat));
	});
	
	$(id).on('cancel.daterangepicker',function(ev, picker) {
		$(span).html("");
	});
	
}
