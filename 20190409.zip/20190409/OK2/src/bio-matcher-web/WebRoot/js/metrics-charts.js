(function(metricsCharts, $, undefined) {
	var chartTimeZone="browser";
	var maxTimeIntervalMinutes = 15;
	
	var formatDecimal = function(val) {
		return parseFloat(val.toFixed(2));
	};

	var formatInt = function(val) {
		return Math.round(val);
	};
	
	var customColors =["#0000ff", "#008000", "#00ff00", "#800000", "#000080", "#808000", "#800080", "#ff0000", "#c0c0c0", "#008080", "#ffff00", "#00ffff", "#f0ffff", "#f5f5dc", "#a52a2a", "#00ffff", "#00008b", "#008b8b", "#a9a9a9", "#006400", "#bdb76b", "#8b008b", "#556b2f", "#ff8c00", "#9932cc", "#8b0000", "#e9967a", "#9400d3", "#ffd700", "#4b0082", "#f0e68c", "#add8e6", "#e0ffff", "#90ee90", "#d3d3d3", "#ffb6c1", "#ffffe0", "#ff00ff", "#ffa500", "#ffc0cb", "#ff00ff", "#808080", "#800080"];
	
	function getConfiguredTimeZone(){
//		var tempTimeZone = metricsDatabase.getServerTimezone();
//		if(!tempTimeZone) {
			return chartTimeZone;
//		}
//		else {
//			return tempTimeZone;
//		}
	}
	
	metricsCharts.plotChart = function(chartVar, chartElementId, chartData, chartOptions) {
		var chartElement = $("#"+chartElementId);
		
		if (!chartElement || !chartElement.length) {
			console.log("In plotChart: ChartElement not found for chartElementId: "+chartElementId);
			return chartVar;
		}

		//console.log("In plotChart chartElementId: "+chartElementId+", chartTimeZone: "+getConfiguredTimeZone());
		try {
			
			/* chart */
			if(!chartVar) {
				chartVar = $.plot(chartElement, chartData, chartOptions);
			}
			
			chartVar.setData(chartData);
			chartVar.setupGrid();
			chartVar.draw();
			
			return chartVar;
		}
		catch(err) {
			console.log("Error in metricsCharts.plotChart for chartElementId: "+chartElementId+" : "+err+"");
		}		
	}
	
	metricsCharts.plotPieChart = function(chartVar, chartElementId, chartData) {
		try {
			var chartOptions = {
				series : {
					pie : {
						show : true,
						label : {
							show : true
						}
					}
				},
				legend : {
					show : false,
					noColumns : 1, // number of colums in legend table
					labelFormatter : null, // fn: string -> string
					labelBoxBorderColor : "#000", // border color for the little label boxes
					container : null, // container (as jQuery object) to put legend in, null means default on top of graph
					position : "ne", // position of default legend container within plot
					margin : [5, 10], // distance from grid edge to default legend container within plot
					backgroundColor : "#efefef", // null means auto-detect
					backgroundOpacity : 1 // set to 0 to avoid background
				},
				grid : {
					hoverable : true,
					clickable : true
				},
				colors: customColors
			};
		
			chartVar = metricsCharts.plotChart(chartVar, chartElementId, chartData, chartOptions);
		}
		catch(err) {
			console.log("Error in metricsCharts.plotPieChart for chartElementId: "+chartElementId +" : "+err+"");
		}		
	}
	
	metricsCharts.plotBarChart = function(chartVar, chartElementId, chartData, xAxisLabel, yAxisLabel, ticks, barWidth) {
		try {
			if(!xAxisLabel) {
				xAxisLabel="";
			}
			
			if(!yAxisLabel) {
				yAxisLabel="";
			}
			
			if(!ticks) {
				ticks=[];
				for(var i=0;i<chartData.length;i++) {
					ticks[i]=[i, chartData[i][0]];
				}
			}
			
			if(!barWidth) {
				barWidth=0.2;
			}
			
			var chartOptions ={
					series: {
						bars: {
							show: true,
							barWidth: barWidth,
							align: "center"
						}
					},
					xaxis: {
						mode: "categories",
		                axisLabel: xAxisLabel,
		                axisLabelUseCanvas: true,
		                axisLabelFontSizePixels: 12,
		                axisLabelFontFamily: 'Verdana, Arial',
		                axisLabelPadding: 10,
		                ticks: ticks							
					},
					yaxis: {
		                axisLabel: yAxisLabel,
		                axisLabelUseCanvas: true,
		                axisLabelFontSizePixels: 12,
		                axisLabelFontFamily: 'Verdana, Arial',
		                axisLabelPadding: 3
		            },						
					grid : {
						show : true,
						hoverable : true,
						clickable : true,
						borderWidth : 0,
					},						
					tooltip : true,
					tooltipOpts : {
						content : "<span>%y</span>",
						defaultTheme : false
					},
					colors: customColors
				};
			
			chartVar = metricsCharts.plotChart(chartVar, chartElementId, [chartData], chartOptions);
		
			/* end bar chart */	
			
			return chartVar;
		}
		catch(err) {
			console.log("Error in metricsCharts.plotBarChart for chartElementId: "+chartElementId +" : "+err+"");
		}		
	}
	
	metricsCharts.plotJobStatisticsByServerId = function(plotChartRefVar, measurement, timetakenValueField, jobCountValueField, chartElementId) {
		try {
			var legendElement = $("#"+chartElementId+"_legend");
			if(!legendElement || legendElement.length==0) {
				legendElement = null; 
			}
			
 			var filterFunc = function(metricRow) {
				if(metricRow["measurement"]===measurement) {
					return true;
				}
				return false;
			};
			
			var xValueFunc = function(metricRow, metric){
				return metric["timestamp"];
			};
			

			
			var jobCount_yValueFunc = function(metricRow, metric){
				return formatInt(metric[jobCountValueField]);
			}
 
			var timeTaken_yValueFunc = function(metricRow, metric){
				if(jobCount_yValueFunc(metricRow, metric)===0){
					return 0;
				}
				return formatDecimal(metric[timetakenValueField]);
			}
			
			var multiSeriesJobTimeTakenData = metricsDatabase.getXYMultiSeriesData(filterFunc, "serverId", xValueFunc, timeTaken_yValueFunc);
			var multiSeriesJobCountData = metricsDatabase.getXYMultiSeriesData(filterFunc, "serverId", xValueFunc, jobCount_yValueFunc);
			
			//console.log("In plotJobStatisticsByServerId: chartElementId: "+chartElementId+", multiSeriesJobTimeTakenData: "+JSON.stringify(multiSeriesJobTimeTakenData));
			//console.log("In plotJobStatisticsByServerId: chartElementId: "+chartElementId+", multiSeriesJobCountData: "+JSON.stringify(multiSeriesJobCountData));
			
			if(!multiSeriesJobTimeTakenData || $.isEmptyObject(multiSeriesJobTimeTakenData)) {
				//console.log("Error in plotJobStatisticsByServerId: chartName: "+chartElementId+" : multiSeriesJobTimeTakenData is empty");
				multiSeriesJobTimeTakenData[""]=[[]];
			}

			if(!multiSeriesJobCountData || $.isEmptyObject(multiSeriesJobCountData)) {
				//console.log("Error in plotJobStatisticsByServerId: chartName: "+chartElementId+" : multiSeriesJobCountData is empty");
				multiSeriesJobCountData[""]=[[]];
			}
			
			var chartData=[];
			for(var serverId in multiSeriesJobTimeTakenData) {
				var seriesDataLength = multiSeriesJobTimeTakenData[serverId].length;
				
				var timeTakenRow = {
					label: serverId,
					yaxis: 1,
					data: multiSeriesJobTimeTakenData[serverId]
				};
				
				chartData.push(timeTakenRow);
				
				var jobCountRow = {
					label: serverId+".COUNT",
					yaxis: 2,
					data: multiSeriesJobCountData[serverId]
				};

				chartData.push(jobCountRow);
			} 
			
			var yAxis=[{
			        position: "left",
			        color: "black",
			        tickDecimals: 2,
			        min: 0,
			        //max: 10,
			        axisLabel: "Time Taken (Secs)",
			        axisLabelUseCanvas: true,
			        axisLabelFontSizePixels: 12,
			        axisLabelFontFamily: 'Verdana, Arial',
			        axisLabelPadding: 5
			    }, {
			        position: "right",           
			        color: "black",
			        tickDecimals: 0,
			        min: 0,
			        //max: 100,
			        axisLabel: "Job Count",
			        axisLabelUseCanvas: true,
			        axisLabelFontSizePixels: 12,
			        axisLabelFontFamily: 'Verdana, Arial',
			        axisLabelPadding: 5
			    }];
	 
			var xAxis=[{
					mode: "time",
					min: (new Date().getTime()-(maxTimeIntervalMinutes*60*1000)),
					//max: (new Date().getTime()-1000),
					timezone: getConfiguredTimeZone(),
				}];
			
			var chartOptions = {
					xaxes: xAxis,
					yaxes: yAxis,
					series: { lines: { show: true }, points: { show: true,  radius: 1} },
					grid : {
						show : true,
						hoverable : true,
						clickable : true,
						borderWidth : 1,
					},						
					tooltip : true,
					tooltipOpts : {
						content : "<span>%y</span>",
						defaultTheme : false
					},
					legend:{         
				        container:legendElement,            
				        noColumns: 0
				    },
				    colors: customColors,
			};
			
			
			plotChartRefVar = metricsCharts.plotChart(plotChartRefVar, chartElementId, chartData, chartOptions);
			
			

			
		}
		catch(err) {
			console.log("Error in plotJobStatisticsByServerId for chartElementId: "+chartElementId+" : "+err);
		}
		return plotChartRefVar;
	}

}(window.metricsCharts = window.metricsCharts || {}, jQuery));