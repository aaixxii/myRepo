(function(commonUtil, $, undefined) {
	
	commonUtil.populateFormData=function(formName, formData){
		if(!formData) {
			return;
		}
		var $inputs = $('#'+formName+' :input');
		 
		$inputs.each(function() {
			if(formData[this.name] || formData[this.name]===0) {
				$(this).val(formData[this.name]);
			}
	    });
	}
	
	commonUtil.enableFormFields=function(formName, formFields){
		if(!formFields) {
			return;
		}
		 
		$(formFields).each(function() {
			var formField = $("#"+formName+" input[name="+this+"]");
			if(formField) {
				formField.removeAttr('disabled');
			}
	    });
	}
	
	commonUtil.disableFormFields=function(formName, formFields){
		if(!formFields) {
			return;
		}
		 
		$(formFields).each(function() {
			var formField = $("#"+formName+" input[name="+this+"]");
			if(formField) {
				formField.attr('disabled','disabled');
			}
	    });
	}
	
}(window.commonUtil = window.commonUtil || {}, jQuery));