package com.nec.biomatcher.web.controller.caching;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.nec.biomatcher.comp.util.ClearRemoteCacheUtil;
import com.nec.biomatcher.core.framework.cache.SpringCacheManager;
import com.nec.biomatcher.core.framework.common.DateUtil;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.web.controller.common.BaseController;

import net.sf.ehcache.Element;

@Controller
@RequestMapping(value = "/admin/caching")
public class CachingController extends BaseController {

	private static final Logger logger = Logger.getLogger(CachingController.class);

	private SpringCacheManager cacheManager = (SpringCacheManager) SpringServiceManager.getBean("methodCacheManager");

	@RequestMapping(value = "/clearAll", method = { RequestMethod.GET, RequestMethod.POST })
	public ResponseEntity<String> clearAll(HttpServletRequest request) {
		logger.info("In CachingController.clearAll");
		ClearRemoteCacheUtil.clearRemoteCache();
		return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
	}

	@RequestMapping(value = "/clearCache", method = { RequestMethod.GET, RequestMethod.POST })
	public ResponseEntity<String> clearCache(HttpServletRequest request) {
		logger.info("In CachingController.clearCache");
		cacheManager.removeAll();
		return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView index(HttpServletRequest request) {
		logger.debug("In CachingController.index");
		return new ModelAndView("caching.list");
	}

	@RequestMapping(value = "/getCacheCountList", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public ResponseEntity<String> getCacheCountList(HttpServletRequest request) {
		logger.info("In CachingController.getCacheCountList: " + new Date());

		JsonArray jsonServerGroupArray = new JsonArray();
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty("NAME", "Cached Elements");
		jsonObject.addProperty("CACHED_COUNT", cacheManager.getKeys().size());
		jsonServerGroupArray.add(jsonObject);

		JsonObject jsonResponse = new JsonObject();
		jsonResponse.add("data", jsonServerGroupArray);
		return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = "/getCachedKeyList", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public ResponseEntity<String> getCachedKeyList(HttpServletRequest request) {
		logger.info("In CachingController.getCachedKeyList: " + new Date());

		JsonArray jsonServerGroupArray = new JsonArray();

		List cachedKeyList = cacheManager.getKeys();
		for (int i = 0; i < cachedKeyList.size(); i++) {
			Object keyObj = cachedKeyList.get(i);

			if (!(keyObj instanceof String)) {
				keyObj = keyObj.toString();
			}

			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("key", (String) keyObj);

			jsonServerGroupArray.add(jsonObject);
		}

		JsonObject jsonResponse = new JsonObject();
		jsonResponse.add("data", jsonServerGroupArray);
		return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = "/getCachedValue", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public ResponseEntity<String> getCachedValue(HttpServletRequest request) {
		logger.info("In CachingController.getCachedValue: " + new Date());
		String cacheKey = request.getParameter("cacheKey");

		JsonObject jsonElement = new JsonObject();

		Element element = cacheManager.getCachedElement(cacheKey);
		if (element != null) {
			String createDateTime = DateUtil.parseDate(new Date(element.getCreationTime()),
					DateUtil.FORMAT_DD_MM_YYYY_HH24_MM_SS);
			String lastAccessDateTime = DateUtil.parseDate(new Date(element.getLastAccessTime()),
					DateUtil.FORMAT_DD_MM_YYYY_HH24_MM_SS);
			jsonElement.addProperty("hitCount", element.getHitCount());
			jsonElement.addProperty("isExpired", element.isExpired());
			jsonElement.addProperty("creationTime", createDateTime);
			jsonElement.addProperty("lastAccessTime", lastAccessDateTime);
			jsonElement.addProperty("timeToIdle", element.getTimeToIdle());
			jsonElement.addProperty("timeToLive", element.getTimeToLive());

			String cacheValue = "null";
			Object value = element.getObjectValue();
			if (value != null) {
				try {
					cacheValue = GsonSerializer.toJson(value);
				} catch (Throwable th) {
					logger.error("Error serilizing ehCache element to json for cacheKey: " + cacheKey + " : "
							+ th.getMessage(), th);
					cacheValue = "Error, Cache element not found";
				}
			}

			jsonElement.addProperty("value", cacheValue);
		} else {
			jsonElement.addProperty("value", "Cache element not found");
		}

		JsonObject jsonResponse = new JsonObject();
		jsonResponse.add("data", jsonElement);

		return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
	}
}
