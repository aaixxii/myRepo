package com.nec.biomatcher.web.controller.dashboard;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/admin/dashboard")
public class DashboardController {
	private static final Logger logger = Logger.getLogger(DashboardController.class);

	@RequestMapping(value = "/dashboardIndex", method = RequestMethod.GET)
	public ModelAndView index(HttpServletRequest request) {
		logger.debug("In DashboardController.index");

		return new ModelAndView("dashboard.init");
	}
}
