package com.nec.biomatcher.web.modules.home;

import com.nec.biomatcher.web.modules.common.BaseForm;

public class HomeForm extends BaseForm {

	private static final long serialVersionUID = 1L;
}
