package com.nec.biomatcher.web.modules.home;

import com.nec.biomatcher.web.modules.common.BaseAction;
import com.nec.biomatcher.web.modules.common.BaseForm;

public class HomeAction extends BaseAction {
	private static final long serialVersionUID = 1L;

	private static final String SUCCESS = "SUCCESS";

	private HomeForm form = new HomeForm();

	public BaseForm getModel() {
		return form;
	}

	public String initPage() {
		return SUCCESS;
	}

}
