package com.nec.biomatcher.web.controller.monitoring;

public class ChartController {

}
