package com.nec.biomatcher.web.controller.logging;

import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.nec.biomatcher.web.controller.common.BaseController;

@Controller
@RequestMapping(value = "/secured/admin/logging")
public class LoggingController extends BaseController {

	private static final Logger logger = Logger.getLogger(LoggingController.class);

	@RequestMapping(value = "/updateLogLevel", method = RequestMethod.POST)
	public ResponseEntity<String> updateLogLevel(HttpServletRequest request) {
		String logCategory = request.getParameter("pk");
		String logLevel = request.getParameter("value");
		logger.info("In LoggingController.updateLogLevel: logCategory: " + logCategory + ", logLevel: " + logLevel);

		Logger catLogger = Logger.getLogger(logCategory);
		if (catLogger != null) {
			try {
				catLogger.setLevel(Level.toLevel(logLevel));
			} catch (Throwable th) {
				logger.error("Unable to update logLevel: " + logLevel + " for logCategory: " + logCategory + " : "
						+ th.getMessage(), th);
			}
		} else
			logger.warn("Cannot find logger for logCategory: " + logCategory);

		return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView index(HttpServletRequest request) {
		logger.debug("In LoggingController.index");
		return new ModelAndView("logging.list");
	}

	@RequestMapping(value = "/getLogCategoriesList", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<String> getLogCategoriesList(HttpServletRequest request) {
		logger.info("In LoggingController.getLogCategoriesList: " + new Date());

		TreeMap<String, String> loggingCategoriesMap = getCurrentCategoriesMap();
		JsonArray jsonArray = new JsonArray();
		for (Entry<String, String> entry : loggingCategoriesMap.entrySet()) {
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("LOG_CATEGORY", entry.getKey());
			jsonObject.addProperty("LOG_LEVEL", entry.getValue());
			jsonArray.add(jsonObject);
		}

		JsonObject jsonResponse = new JsonObject();
		jsonResponse.add("data", jsonArray);
		return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = "/getLogLevelList", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<String> getLogLevelList(HttpServletRequest request) {
		logger.info("In LoggingController.getLogLevelList: " + new Date());

		JsonArray jsonArray = new JsonArray();
		for (Level level : Lists.newArrayList(Level.FATAL, Level.ERROR, Level.WARN, Level.INFO, Level.DEBUG,
				Level.TRACE, Level.ALL)) {
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("id", level.toString());
			jsonObject.addProperty("text", level.toString());
			jsonArray.add(jsonObject);
		}

		JsonObject jsonResponse = new JsonObject();
		jsonResponse.add("data", jsonArray);
		return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
	}

	private static TreeMap<String, String> getCurrentCategoriesMap() {
		final String defaultCategory = "com.nec"; // default
		Comparator<String> comparator = (o1, o2) -> {
			if (o1 == o2) {
				return 0;
			} else if (o1 != null && o2 != null) {
				if (o1.indexOf(".") == -1 && o2.indexOf(".") > -1) {
					return -1;
				} else if (o1.indexOf(".") > -1 && o2.indexOf(".") == -1) {
					return 1;
				} else {
					return o1.compareTo(o2);
				}
			} else {
				return o1 == null ? -1 : 1;
			}
		};
		TreeMap<String, String> loggingCategories = new TreeMap<>(comparator);

		Enumeration loggerEnum = LogManager.getCurrentLoggers();

		while (loggerEnum.hasMoreElements()) {
			Logger currLogger = (Logger) loggerEnum.nextElement();
			if (currLogger == null || currLogger.getName() == null || currLogger.getName().trim().length() == 0) {
				continue;
			}
			loggingCategories.put(currLogger.getName(), getLogLevel(currLogger.getName()).toString());
		}

		if (loggingCategories.size() == 0) { // Add default category
			loggingCategories.put(defaultCategory, getLogLevel(defaultCategory).toString());
		}

		return loggingCategories;
	}

	private static Level getLogLevel(String category) {
		Logger catLogger = Logger.getLogger(category);
		if (catLogger != null) {
			return catLogger.getLevel() != null ? catLogger.getLevel() : Level.INFO;
		} else {
			logger.warn("Cannot find logger for category: " + category);
		}
		return Level.INFO;
	}
}
