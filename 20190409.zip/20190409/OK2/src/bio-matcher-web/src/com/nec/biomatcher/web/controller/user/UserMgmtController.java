package com.nec.biomatcher.web.controller.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.nec.biomatcher.comp.admin.BioAdminService;
import com.nec.biomatcher.comp.admin.model.BioUserInfo;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.CommonFunctions;
import com.nec.biomatcher.core.framework.common.StringUtil;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.web.controller.common.BaseController;

@Controller
@RequestMapping(value = "/secured/admin/user")
public class UserMgmtController extends BaseController {

    private static final Logger logger = Logger.getLogger(UserMgmtController.class);

    private BioParameterService bioParameterService = (BioParameterService) SpringServiceManager.getBean("bioParameterService");
    private BioAdminService bioAdminService = (BioAdminService) SpringServiceManager.getBean("bioAdminService");

    private enum UserInfoColumnOrder {
        USER_ID, USER_NAME, PASSWORD, ROLES;
    }

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public ModelAndView index(HttpServletRequest request) {
        logger.debug("In UserMgmtController.index");
        return new ModelAndView("user.list");
    }

    @RequestMapping(value = "/getUserList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getUserList(HttpServletRequest request) {
        logger.info("In UserMgmtController.getUserList: " + new Date());
        List<BioUserInfo> userList = null;
        try {
            userList = bioAdminService.getUserInfoList().getUserList();
        } catch (Throwable th) {
            userList = new ArrayList<BioUserInfo>();
            logger.error("Error in getUserList: " + th.getMessage(), th);
        }

        JsonArray jsonUserArray = new JsonArray();
        if (CollectionUtils.isNotEmpty(userList)) {
            for (BioUserInfo bioUserInfo : userList) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(UserInfoColumnOrder.USER_ID.name(), StringUtils.trimToEmpty(bioUserInfo.getUserId()));
                jsonObject.addProperty(UserInfoColumnOrder.USER_NAME.name(), StringUtils.trimToEmpty(bioUserInfo.getUserName()));
                jsonObject.addProperty(UserInfoColumnOrder.PASSWORD.name(), StringUtils.trimToEmpty(bioUserInfo.getPassword()));

                JsonArray rolesJsonArray = new JsonArray();
                for (String role : bioUserInfo.getRoles()) {
                    JsonPrimitive jsonRole = new JsonPrimitive(role);
                    rolesJsonArray.add(jsonRole);
                }
                jsonObject.add(UserInfoColumnOrder.ROLES.name(), rolesJsonArray);

                jsonUserArray.add(jsonObject);
            }
        }
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonUserArray);
        logger.info("Total User Records : " + userList.size());
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getRoleList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getRoleList(HttpServletRequest request) {
        logger.info("In UserMgmtController.getRoleList: " + new Date());

        JsonArray rolesJsonArray = new JsonArray();
        for (String role : getRoleList()) {
            JsonObject roleJson = new JsonObject();
            roleJson.addProperty("id", role);
            roleJson.addProperty("text", role);
            rolesJsonArray.add(roleJson);
        }

        JsonObject jsonObject = new JsonObject();
        jsonObject.add("data", rolesJsonArray);

        return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
    }

    @ModelAttribute("roleList")
    public List<String> getRoleList() {
        try {
            return bioParameterService.getParameterValue("USER_ROLES", "ADMIN", CommonFunctions.STRING_TO_LIST, "Administrator, Monitoring");
        } catch (Throwable th) {
            logger.error("Error in getRoleList: " + th.getMessage(), th);
        }
        return new ArrayList<>();
    }

    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> addUser(HttpServletRequest request, BioUserInfo userInfo) {
        try {
            if (StringUtils.isNotBlank(userInfo.getUserId())) {

                BioUserInfo existingUser = bioAdminService.getUser(userInfo.getUserId());
                if (existingUser != null) {
                    return new ResponseEntity<>(this.getMessage("errors.userManagement.already.exists", new Object[] { userInfo.getUserId() }, request), HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }

            bioAdminService.saveUser(userInfo);

            return new ResponseEntity<>(this.getMessage("messages.userManagement.save.success", new Object[] { userInfo.getUserName() }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in addUser: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.userManagement.SaveFailed", new Object[] { userInfo.getUserId() }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/updateUser", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> updateUser(HttpServletRequest request) {
        String userId = request.getParameter("pk");
        String updatedColName = request.getParameter("name");
        String value = request.getParameter("value");
        try {
            logger.info("In updateUser: userId: " + userId + ", updatedColName: " + updatedColName + ", value: " + value);

            if (StringUtils.isBlank(userId)) {
                return new ResponseEntity<>("User ID can not be blank", HttpStatus.BAD_REQUEST);
            }

            BioUserInfo existingUser = bioAdminService.getUser(userId);
            if (existingUser == null) {
                return new ResponseEntity<>("User does not exist", HttpStatus.BAD_REQUEST);
            }

            if ("userName".equalsIgnoreCase(updatedColName)) {

                if (StringUtils.isBlank(value)) {
                    return new ResponseEntity<>("User Name can not be blank", HttpStatus.BAD_REQUEST);
                }
                existingUser.setUserName(value);
            } else if ("password".equalsIgnoreCase(updatedColName)) {
                if (StringUtils.isBlank(value)) {
                    return new ResponseEntity<>("Password can not be blank", HttpStatus.BAD_REQUEST);
                }
                existingUser.setPassword(value);

            } else if ("assignedRoles".equalsIgnoreCase(updatedColName)) {
                if (StringUtils.isBlank(value)) {
                    return new ResponseEntity<>("Roles can not be blank", HttpStatus.BAD_REQUEST);
                }
                existingUser.setRoles(new HashSet<>(StringUtil.stringToList(value, ",")));
            }

            bioAdminService.saveUser(existingUser);

            return new ResponseEntity<>(this.getMessage("messages.userManagement.update.success", new Object[] { existingUser.getUserName() }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in updateUser: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.userManagement.UpdateFailed", new Object[] { userId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> deleteUser(HttpServletRequest request) {
        String userId = request.getParameter("userId");
        logger.info("In deleteUser: userId: " + userId);
        try {
            BioUserInfo existingUser = bioAdminService.getUser(userId);

            bioAdminService.deleteUser(userId);
            return new ResponseEntity<>(this.getMessage("messages.userManagement.del.success", new Object[] { existingUser.getUserName() }, request), HttpStatus.OK);
        } catch (Throwable th) {
            logger.error("Error in deleteUser: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.userManagement.DelFailed", new Object[] { userId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
