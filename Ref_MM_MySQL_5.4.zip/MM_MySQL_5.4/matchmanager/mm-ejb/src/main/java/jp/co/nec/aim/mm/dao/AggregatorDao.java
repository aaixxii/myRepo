package jp.co.nec.aim.mm.dao;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.procedure.CompleteJobProcedure;
import jp.co.nec.aim.mm.procedure.CorrectInquiryJobProcedure;
import jp.co.nec.aim.mm.procedure.FailureInquiryJobProcedure;
import jp.co.nec.aim.mm.procedure.GetAllContainerJobsProcedure;
import jp.co.nec.aim.mm.procedure.RetryInquiryJobProcedure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

public class AggregatorDao {

	private static Logger log = LoggerFactory.getLogger(AggregatorDao.class);

	private DataSource ds;

	public AggregatorDao(DataSource ds) {
		this.ds = ds;
	}

	public List<byte[]> getAllContainerJobs(long topleveljob) {
		if (log.isDebugEnabled()) {
			log.debug("Get containerJob results for Top Level Job: {}",
					topleveljob);
		}
		try {
			GetAllContainerJobsProcedure allcjProcedure = new GetAllContainerJobsProcedure(
					ds);
			List<byte[]> result = allcjProcedure.action(topleveljob);
			return result;
		} catch (DataAccessException e) {
			throw new AimRuntimeException(e.getMessage(), e);
		}
	}

	public void callCompleteTopLevelJob(long jobId, byte[] result,
			boolean failed) {
		if (log.isDebugEnabled()) {
			log.debug(
					"Call complete_top_level_job procedure for Top Level Job: {}",
					jobId);
		}
		try {
			CompleteJobProcedure ctljProcedure = new CompleteJobProcedure(ds);
			ctljProcedure.action(jobId, result, failed);
		} catch (DataAccessException e) {
			throw new AimRuntimeException(e.getMessage(), e);
		}
	}

	public long updateJobResult(long jobId, int messageSequence,
			long containerJobId, byte[] result) {
		if (log.isDebugEnabled()) {
			log.debug("update containerJob results for Top Level Job: {}",
					jobId);
		}
		try {
			CorrectInquiryJobProcedure cijProcedure = new CorrectInquiryJobProcedure(
					ds);
			long remain_jobs = cijProcedure.action(jobId, messageSequence,
					containerJobId, result);
			return remain_jobs;
		} catch (DataAccessException e) {
			throw new AimRuntimeException(e.getMessage(), e);
		}
	}

	public long failJobResult(PBServiceState serviceState, byte[] bJobResult,
			long containerJobId, Long segmentId) {
		log.warn("fail containerJob results for container Job: {}",
				containerJobId);

		try {
			FailureInquiryJobProcedure fijProcedure = new FailureInquiryJobProcedure(
					ds);
			long jobId = fijProcedure.action(serviceState, bJobResult,
					containerJobId, segmentId);
			return jobId;
		} catch (DataAccessException e) {
			throw new AimRuntimeException(e.getMessage(), e);
		}
	}

	public long retryJob(long topLevelJobId) {
		if (log.isDebugEnabled()) {
			log.debug("retryJob containerJob results for Top Level Job: {}",
					topLevelJobId);
		}
		try {
			RetryInquiryJobProcedure rijProcedure = new RetryInquiryJobProcedure(
					ds);
			return rijProcedure.execute(topLevelJobId);
		} catch (DataAccessException e) {
			throw new AimRuntimeException(e.getMessage(), e);
		}
	}
}
