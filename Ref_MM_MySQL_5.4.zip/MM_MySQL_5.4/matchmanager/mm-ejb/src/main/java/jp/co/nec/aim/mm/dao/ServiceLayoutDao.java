package jp.co.nec.aim.mm.dao;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.HighLevelServiceLayoutEntity;

/**
 * ServiceLayoutDao
 * 
 * @author liuyq
 * 
 */
public class ServiceLayoutDao {

	private EntityManager em;

	/**
	 * ServiceLayoutDao
	 * 
	 * @param em
	 *            EntityManager instance
	 */
	public ServiceLayoutDao(EntityManager em) {
		this.em = em;
	}

	/**
	 * findScriptXmlByName
	 * 
	 * @param name
	 * 
	 * @return script XML
	 */
	public String findScriptXmlByName(String name) {
		Query query = em.createNamedQuery("NQ::findScriptXmlByName");
		query.setParameter("name", name);
		HighLevelServiceLayoutEntity entity = (HighLevelServiceLayoutEntity) query
				.getSingleResult();
		return entity.getScriptXml();
	}

}
