package jp.co.nec.aim.mm.dao;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * @author mozj
 */
public class DateDao {
	private static final String TIMESTAMP_SQL = "Select current_timestamp";
	private static final String TIMESTAMP_MILLIONS_SQL = "SELECT UNIX_TIMESTAMP(NOW()) AS MILLIONS";

	private JdbcTemplate jdbcTemplate;
	private static Logger log = LoggerFactory.getLogger(DateDao.class);

	public DateDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * get current Data
	 * 
	 * @return
	 */
	public Date getDatabaseDate() {
		Date date = (Date) jdbcTemplate.queryForObject(TIMESTAMP_SQL,
				Date.class);
		if (log.isDebugEnabled()) {
			log.debug("DateHelper Oracle Date = " + date);
		}
		return date;
	}

	/**
	 * get epoch time of current Data
	 * 
	 * @return
	 */
	public Long getCurrentTimeMS() {
		Long timestamp = (Long) jdbcTemplate.queryForObject(
				TIMESTAMP_MILLIONS_SQL, Long.class);
		if (log.isDebugEnabled()) {
			log.debug("DateHelper Oracle Timestamp = " + timestamp);
		}
		return timestamp;
	}

	/**
	 * getReasonTime
	 * 
	 * @return dd-MM-yyyy HH:mm:ss
	 */
	public String getReasonTime() {
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		return format.format(getDatabaseDate());
	}

}
