package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.mm.dao.DateDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FailExtractJobProcedureTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private DateDao dateDao;
	private long curTime;

	@Before
	public void setUp() throws Exception {
		clearDB();
		dateDao = new DateDao(dataSource);
		curTime = dateDao.getCurrentTimeMS();

		intsertUnit();
		insertFeJob();

	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	private void intsertUnit() {
		for (int id = 1; id <= 3; id++) {
			jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"
					+ " values(" + id + ", " + curTime + ")");
			jdbcTemplate.execute("insert into MU_EXTRACT_LOAD(MU_ID, PRESSURE,"
					+ " UPDATE_TS) values(" + id + ", 3, " + curTime + ")");
		}
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from FE_JOB_QUEUE");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	private void insertFeJob() {
		String fljSQL = "insert into FE_LOT_JOBS(LOT_JOB_ID, MU_ID,"
				+ " ASSIGNED_TS, TIMEOUTS) values(?, ?, ?, ?)";

		String fejSQL = "insert into FE_JOB_QUEUE(JOB_ID, LOT_JOB_ID, PRIORITY,"
				+ " FUNCTION_ID, JOB_STATE, SUBMISSION_TS, ASSIGNED_TS, MU_ID,"
				+ " CALLBACK_STYLE, CALLBACK_URL, FAILURE_COUNT) values(?, ?,"
				+ "  5,17, ?, 1421206612748, ?, ?, 1, 'test Url', ?)";

		int fljId = 1;
		jdbcTemplate.update(fljSQL, new Object[] { fljId, fljId, curTime,
				300 * 1000 });
		for (int fejId = 1; fejId <= 3; fejId++) {
			jdbcTemplate.update(fejSQL, new Object[] { (fljId - 1) * 3 + fejId,
					fljId, fejId - 1, curTime, fejId, 0 });
		}
	}

	private PBExtractJobResult createPBExtractJobResult() {
		PBServiceStateReason.Builder reason = PBServiceStateReason.newBuilder();
		reason.setCode("test code");
		reason.setDescription("test reason");
		reason.setTime("test time");

		PBServiceState.Builder state = PBServiceState.newBuilder();
		state.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		state.setReason(reason);

		PBExtractJobResult.Builder resultBuilder = PBExtractJobResult
				.newBuilder();
		resultBuilder.setServiceState(state);
		resultBuilder.setJobId(3);
		PBExtractJobResult result = resultBuilder.build();

		return result;
	}

	private void assertProcedureResult(int jobbId) {
		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE where JOB_ID="
						+ jobbId);
		assertEquals(1, listFeJ.size());

		assertEquals("" + jobbId, listFeJ.get(0).get("JOB_ID").toString());
		assertNull(listFeJ.get(0).get("LOT_JOB_ID"));
		assertEquals("2", listFeJ.get(0).get("JOB_STATE").toString());
		assertEquals("1", listFeJ.get(0).get("FAILED_FLAG").toString());
		assertEquals("" + jobbId, listFeJ.get(0).get("MU_ID").toString());
		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
		assertNotNull(listFeJ.get(0).get("RESULT_TS"));
		assertNotNull(listFeJ.get(0).get("RESULT"));
		assertEquals("1", listFeJ.get(0).get("FAILURE_COUNT").toString());

		List<Map<String, Object>> listFeR = jdbcTemplate
				.queryForList("select * from FE_RESULTS order by RESULT_ID");
		assertEquals(0, listFeR.size());

		List<Map<String, Object>> listFeReason = jdbcTemplate
				.queryForList("select * from FE_JOB_FAILURE_REASONS");
		assertEquals(1, listFeReason.size());

		assertEquals("" + jobbId, listFeReason.get(0).get("JOB_ID").toString());
		assertEquals("" + jobbId, listFeReason.get(0).get("MU_ID").toString());
		assertEquals("test code", listFeReason.get(0).get("CODE").toString());
		assertEquals("test reason", listFeReason.get(0).get("REASON")
				.toString());
		assertEquals("test time", listFeReason.get(0).get("FAILURE_TIME")
				.toString());
	}

	private void assertUndoProcedureResult(int jobbId) {
		// Extract Job
		List<Map<String, Object>> listFeJ = jdbcTemplate
				.queryForList("select JOB_ID, LOT_JOB_ID, JOB_STATE, FAILED_FLAG,"
						+ " MU_ID, ASSIGNED_TS, RESULT_TS, RESULT,"
						+ " FAILURE_COUNT from FE_JOB_QUEUE where JOB_ID="
						+ jobbId);
		assertEquals(1, listFeJ.size());

		assertEquals("" + jobbId, listFeJ.get(0).get("JOB_ID").toString());
		assertEquals("1", listFeJ.get(0).get("LOT_JOB_ID").toString());
		assertEquals("" + (jobbId - 1), listFeJ.get(0).get("JOB_STATE")
				.toString());
		assertNull(listFeJ.get(0).get("FAILED_FLAG"));
		assertEquals("" + jobbId, listFeJ.get(0).get("MU_ID").toString());
		assertEquals("" + curTime, listFeJ.get(0).get("ASSIGNED_TS").toString());
		assertNull(listFeJ.get(0).get("RESULT_TS"));
		assertNull(listFeJ.get(0).get("RESULT"));
		assertEquals("0", listFeJ.get(0).get("FAILURE_COUNT").toString());

		List<Map<String, Object>> listFeR = jdbcTemplate
				.queryForList("select * from FE_RESULTS order by RESULT_ID");
		assertEquals(0, listFeR.size());

		List<Map<String, Object>> listFeReason = jdbcTemplate
				.queryForList("select * from FE_JOB_FAILURE_REASONS");
		assertEquals(0, listFeReason.size());
	}

	@Test
	public void test_UndoQueuedExtractJob() {
		PBExtractJobResult result = createPBExtractJobResult();

		FailExtractJobProcedure procedure = new FailExtractJobProcedure(
				dataSource);

		int count = procedure.execute(1, 1, result.getServiceState()
				.getReason(), result.toByteArray());

		assertEquals(0, count);

		assertUndoProcedureResult(1);
	}

	@Test
	public void test_Undo_Diff_MU_WorkingExtractJob() {
		PBExtractJobResult result = createPBExtractJobResult();

		FailExtractJobProcedure procedure = new FailExtractJobProcedure(
				dataSource);

		int count = procedure.execute(2, 1, result.getServiceState()
				.getReason(), result.toByteArray());

		assertEquals(0, count);

		assertUndoProcedureResult(2);
	}

	@Test
	public void test_FailWorkingExtractJob() {
		PBExtractJobResult result = createPBExtractJobResult();

		FailExtractJobProcedure procedure = new FailExtractJobProcedure(
				dataSource);

		int count = procedure.execute(2, 2, result.getServiceState()
				.getReason(), result.toByteArray());

		assertEquals(1, count);

		assertProcedureResult(2);
	}

	@Test
	public void test_UndoDoneExtractJob() {
		PBExtractJobResult result = createPBExtractJobResult();

		FailExtractJobProcedure procedure = new FailExtractJobProcedure(
				dataSource);

		int count = procedure.execute(3, 1, result.getServiceState()
				.getReason(), result.toByteArray());

		assertEquals(0, count);

		assertUndoProcedureResult(3);
	}

	@Test
	public void test_IllegalArgument_MUID() {
		PBExtractJobResult result = createPBExtractJobResult();

		FailExtractJobProcedure procedure = new FailExtractJobProcedure(
				dataSource);
		try {
			procedure.execute(1, 0, result.getServiceState().getReason(),
					result.toByteArray());
		} catch (IllegalArgumentException e) {
			assertEquals("muId is less than 1", e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void test_IllegalArgument_ExractJobId() {
		PBExtractJobResult result = createPBExtractJobResult();

		FailExtractJobProcedure procedure = new FailExtractJobProcedure(
				dataSource);
		try {
			procedure.execute(0, 1, result.getServiceState().getReason(),
					result.toByteArray());
		} catch (IllegalArgumentException e) {
			assertEquals("extractJobId is less than 1", e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void test_IllegalArgument_Results() {
		PBExtractJobResult result = createPBExtractJobResult();

		FailExtractJobProcedure procedure = new FailExtractJobProcedure(
				dataSource);
		try {
			procedure.execute(1, 1, result.getServiceState().getReason(), null);
		} catch (IllegalArgumentException e) {
			assertEquals("results is null", e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void test_IllegalArgument_Reason() {
		PBExtractJobResult result = createPBExtractJobResult();

		FailExtractJobProcedure procedure = new FailExtractJobProcedure(
				dataSource);
		try {
			procedure.execute(1, 1, null, result.toByteArray());
		} catch (IllegalArgumentException e) {
			assertEquals("reason is null", e.getMessage());
			return;
		}
		fail();
	}
}
