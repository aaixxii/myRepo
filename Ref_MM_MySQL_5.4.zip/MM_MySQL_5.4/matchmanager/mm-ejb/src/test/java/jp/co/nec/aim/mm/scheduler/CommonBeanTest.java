package jp.co.nec.aim.mm.scheduler;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.constants.SchedulerEnum;
import jp.co.nec.aim.mm.dao.SystemConfigDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class CommonBeanTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;

	@Resource
	private CommonBean commonbean;

	private SystemConfigDao systemconfigdao;
	private JdbcTemplateHelper helper = new JdbcTemplateHelper();

	@Before
	public void setUp() throws Exception {

		systemconfigdao = new SystemConfigDao(entityManager);
		helper = new JdbcTemplateHelper();

		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteSystemConfig(jdbcTemplate);
		systemconfigdao.writeAllMissingProperties(ds);
	}

	@After
	public void tearDown() throws Exception {

		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteSystemConfig(jdbcTemplate);
	}

	@Test
	public void testCheckAndRescheduleJob() {
	}

	@Test
	public void testCanIDoIt_null() {
		try {
			commonbean.canIDoIt(null);
			assertTrue(false);
		} catch (IllegalArgumentException ex) {
			assertTrue(true);
		}

	}

	@Test
	public void testCanIDoIt_Item01() {
		for (SchedulerEnum schedulerEnum : SchedulerEnum.values()) {
			if (schedulerEnum.equals(SchedulerEnum.MMHeartBeatSchedulable)) {
				continue;
			}
			boolean bcanIdoIt = commonbean.canIDoIt(schedulerEnum);
			assertEquals(bcanIdoIt, true);
		}
	}

	@Test
	public void testCanIDoIt_psssedEnough_null() {
		helper.insertMM_SameMMId_pass(jdbcTemplate);
		try {
			commonbean.canIDoIt(null);
			assertTrue(false);
		} catch (IllegalArgumentException ex) {
			assertTrue(true);
		}
	}

	@Test
	public void testCanIDoIt_psssedEnough() {
		helper.insertMM_SameMMId_pass(jdbcTemplate);

		boolean bcanIdoIt = commonbean
				.canIDoIt(SchedulerEnum.FePlannerSchedulable);
		assertEquals(true, bcanIdoIt);

	}

	@Test
	public void testCanIDoIt_psssedEnough_false() {
		helper.insertMM_SameMMId_pass(jdbcTemplate);

		boolean bcanIdoIt = commonbean
				.canIDoIt(SchedulerEnum.DefragSchedulable);
		assertEquals(false, bcanIdoIt);

	}

	@Test
	public void testUpdateLastTimeStamp() {
		for (SchedulerEnum schedulerEnum : SchedulerEnum.values()) {
			if (schedulerEnum.equals(SchedulerEnum.MMHeartBeatSchedulable)) {
				continue;
			}
			boolean bUpdate = commonbean.updateLastTimeStamp(schedulerEnum);
			assertEquals(true, bUpdate);
		}

		for (SchedulerEnum schedulerEnum : SchedulerEnum.values()) {
			if (schedulerEnum.equals(SchedulerEnum.MMHeartBeatSchedulable)) {
				continue;
			}
			boolean bUpdate = commonbean.updateLastTimeStamp(schedulerEnum);
			assertEquals(true, bUpdate);
		}

		try {
			commonbean.updateLastTimeStamp(null);
			assertTrue(false);
		} catch (IllegalArgumentException ex) {
			assertTrue(true);
		}

		boolean bUpdate = commonbean
				.updateLastTimeStamp(SchedulerEnum.MMHeartBeatSchedulable);
		assertEquals(false, bUpdate);
	}
}
