package jp.co.nec.aim.mm.acceptor;

/**
 * 
 * @author liuyq
 * 
 */
public class CommonOptions {	
	private Integer maxCandidates;
	private String callBackUrl;	
	private boolean isFromServlet;
	private String functioName;

	public Integer getMaxCandidates() {
		return maxCandidates;
	}

	public void setMaxCandidates(Integer maxCandidates) {
		this.maxCandidates = maxCandidates;
	}

	public String getCallBackUrl() {
		return callBackUrl;
	}

	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}

	public boolean isFromServlet() {
		return isFromServlet;
	}

	public void setFromServlet(boolean isFromServlet) {
		this.isFromServlet = isFromServlet;
	}

	public String getFunctioName() {
		return functioName;
	}

	public void setFunctioName(String functioName) {
		this.functioName = functioName;
	}

}
