package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the SEGMENTS database table.
 * 
 */
@Entity
@Table(name = "SEGMENTS")
@NamedQuery(name = "SegmentEntity.findAll", query = "SELECT s FROM SegmentEntity s")
public class SegmentEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SEGMENT_ID")
	private long segmentId;

	@Column(name = "BINARY_LENGTH")
	private long binaryLength;
	

	@Column(name = "BIO_ID_END")
	private long bioIdEnd;

	@Column(name = "BIO_ID_START")
	private long bioIdStart;

	@Column(name = "CONTAINER_ID")
	private long containerId;

	@Column(name = "RECORD_COUNT")
	private long recordCount;

	private long revision;

	@Column(name = "\"VERSION\"")
	private long version;

	public SegmentEntity() {
	}

	public long getSegmentId() {
		return this.segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}	

	public long getBinaryLength() {
		return binaryLength;
	}

	public void setBinaryLength(long binaryLength) {
		this.binaryLength = binaryLength;
	}

	public long getBioIdEnd() {
		return this.bioIdEnd;
	}

	public void setBioIdEnd(long bioIdEnd) {
		this.bioIdEnd = bioIdEnd;
	}

	public long getBioIdStart() {
		return this.bioIdStart;
	}

	public void setBioIdStart(long bioIdStart) {
		this.bioIdStart = bioIdStart;
	}

	public long getContainerId() {
		return this.containerId;
	}

	public void setContainerId(long containerId) {
		this.containerId = containerId;
	}

	public long getRecordCount() {
		return this.recordCount;
	}

	public void setRecordCount(long recordCount) {
		this.recordCount = recordCount;
	}

	public long getRevision() {
		return this.revision;
	}

	public void setRevision(long revision) {
		this.revision = revision;
	}

	public long getVersion() {
		return this.version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

}