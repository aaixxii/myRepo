package jp.co.nec.aim.mm.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.Set;
import java.util.TreeSet;

import jp.co.nec.aim.mm.common.SocketReceiveUtil;
import jp.co.nec.aim.mm.common.TestLogger;
import jp.co.nec.aim.mm.exception.UDPNotifyException;
import mockit.Deencapsulation;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * UDPNotifyHelperTest Test UDPNotifyHelper SocketReceiveUtil provide a thread
 * to receive Msg from Client
 * 
 * @author mozj
 * 
 */
public class UDPNotifyHelperTest {

	private boolean isException;
	private Exception exception;

	@Before
	public void setUp() {
		TestLogger.isDebugEnabled = false;
		TestLogger.level = "";
		TestLogger.message = "";
		isException = false;

		new MockUp<LoggerFactory>() {
			@Mock
			public Logger getLogger(String name) {
				return new TestLogger();
			}
		};
	}

	@After
	public void tearDown() throws Exception {		
	}

	/**
	 * Test Normal : UDPNotifyHelper convert:privode a method to Write formatted
	 * output to String send Msg to Addrs And Receive Msg
	 * 
	 * @throws InterruptedException
	 * @throws SecurityException
	 * @throws NoSuchFieldException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 */
	@Ignore
	@Test
	public void testOneHostReceive_UNIT() throws InterruptedException,
			NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException {
		TestLogger.isDebugEnabled = true;

		SocketReceiveUtil listen = null;
		try {
			final int port = 12334;
			listen = new SocketReceiveUtil(port);
			Set<Long> unitList = new TreeSet<Long>();
			unitList.add(23L);
			unitList.add(24L);
			unitList.add(27L);
			unitList.add(7L);
			unitList.add(4L);
			final String message = UDPNotifyHelper.convert(unitList);

			UDPNotifyHelper helper = new UDPNotifyHelper();
			// IP 127.0.0.1~127.0.0.255
			helper.addIPAddress("127.0.0.1", port);
			Deencapsulation.setField(UDPNotifyHelper.class,
					"SOCKET_TIMEOUT_MS", 2000);

			helper.notifyCompoent(message);
			listen.join();
			String[] msgArray = listen.getDatagramPacketMsg().split(",");
			assertEquals("4", msgArray[0]);
			assertEquals("7", msgArray[1]);
			assertEquals("23", msgArray[2]);
			assertEquals("24", msgArray[3]);
			assertEquals("27", msgArray[4]);
		} finally {
			if (listen != null) {
				listen.closeSocket();
				listen = null;
			}
		}
	}

	/**
	 * Test ERROR: send Msg to Adds but not Received
	 * 
	 * @throws InterruptedException
	 */
	@Test
	public void testNotReceiveAbnormally() throws InterruptedException,
			SocketTimeoutException {
		SocketReceiveUtil listen = null;
		try {
			final int port = 1234;
			listen = new SocketReceiveUtil(port);
			Set<Long> muIdSet = new TreeSet<Long>();
			muIdSet.add(23L);
			muIdSet.add(24L);
			muIdSet.add(27L);
			muIdSet.add(7L);
			muIdSet.add(4L);
			final String message = UDPNotifyHelper.convert(muIdSet);

			UDPNotifyHelper helper = new UDPNotifyHelper();
			// IP 192.168.100.1~192.168.100.255
			helper.addIPAddress("192.168.100.2", port);

			helper.notifyCompoent(message);
			listen.join();
			assertEquals(17, listen.getDatagramPacketLen());
			assertEquals("Receive timed out", listen.getDatagramPacketMsg());
		} finally {
			if (listen != null) {
				listen.closeSocket();
				listen = null;
			}
		}
	}

	@Test
	public void testOutRangePort() {
		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("qweqw", 0);
		assertEquals("warn", TestLogger.level);
		assertEquals("the port is out of range, skip..", TestLogger.message);
	}

	@Test
	public void testOutRangePort2() {
		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("qweqw", 1000000);
		assertEquals("warn", TestLogger.level);
		assertEquals("the port is out of range, skip..", TestLogger.message);
	}

	@Test
	public void testEmptyIp() {
		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("", 23);
		assertEquals("warn", TestLogger.level);
		assertEquals("ip is null while add Unit broadcast ip address, skip..",
				TestLogger.message);
	}

	@Test
	public void testEmptyMessage() {
		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("ere", 1231);
		helper.notifyCompoent("");
		assertEquals("error", TestLogger.level);
		assertEquals("the message will be send is null or empty, skip notify.",
				TestLogger.message);
	}

	@Test
	public void testEmptySocketAddrs() {
		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.notifyCompoent("teterer");
		assertEquals("error", TestLogger.level);
		assertEquals("please confirm the notify ip and port is exist "
				+ "in table SYSTEM_INIT due to the ip address is empty,"
				+ " nothing to send..", TestLogger.message);
	}

	@Test
	@Ignore
	public void testIOException() {
		new MockUp<DatagramSocket>() {
			@Mock
			public void send(DatagramPacket p) throws Exception {
				if (isException) {
					throw exception;
				}
				return;
			}
		};

		isException = true;
		exception = new IOException("");

		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("127.0.0.1", 1231);
		helper.notifyCompoent("Test Message");
		assertEquals("error", TestLogger.level);
		assertEquals("IOException occurred while send UDP package to unit, "
				+ "ip address-> {}, port-> {}, message-> {}",
				TestLogger.message);
	}

	@Test
	@Ignore
	public void testException() {
		new MockUp<DatagramSocket>() {
			@Mock
			public void send(DatagramPacket p) throws Exception {
				if (isException) {
					throw exception;
				}
				return;
			}
		};

		isException = true;
		exception = new Exception("");

		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("127.0.0.1", 1231);
		helper.notifyCompoent("Test Message");
		assertEquals("error", TestLogger.level);
		assertEquals("Unknown Exception occurred while send UDP package to "
				+ "unit, ip address-> {}, port-> {}, message-> {}",
				TestLogger.message);
	}

	@Test
	@Ignore
	public void testUnsupportedEncodingException() {
		new MockUp<DatagramSocket>() {
			@Mock
			public synchronized void setSoTimeout(int timeout) throws Exception {
				if (isException) {
					throw exception;
				}
				return;
			}
		};
		isException = true;
		exception = new UnsupportedEncodingException("");

		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("ere", 1231);
		try {
			helper.notifyCompoent("Test Message");
		} catch (UDPNotifyException e) {
			assertEquals("error", TestLogger.level);
			assertEquals("UnsupportedEncodingException occurred while"
					+ " convert the message to bytes using charsetName UTF-8",
					TestLogger.message);
			return;
		}
		fail();
	}

	@Test
	@Ignore
	public void testSocketException() {
		new MockUp<DatagramSocket>() {
			@Mock
			public synchronized void setSoTimeout(int timeout) throws Exception {
				if (isException) {
					throw exception;
				}
				return;
			}
		};
		isException = true;
		exception = new SocketException("");

		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("ere", 1231);
		try {
			helper.notifyCompoent("Test Message");
		} catch (UDPNotifyException e) {
			assertEquals("error", TestLogger.level);
			assertEquals("SocketException occurred while"
					+ " create instance DatagramSocket", TestLogger.message);
			return;
		}
		fail();
	}

	@Test
	@Ignore
	public void testException2() {
		new MockUp<DatagramSocket>() {
			@Mock
			public synchronized void setSoTimeout(int timeout) throws Exception {
				if (isException) {
					throw exception;
				}
				return;
			}
		};
		isException = true;
		exception = new Exception("");

		UDPNotifyHelper helper = new UDPNotifyHelper();
		helper.addIPAddress("ere", 1231);
		try {
			helper.notifyCompoent("Test Message");
		} catch (UDPNotifyException e) {
			assertEquals("error", TestLogger.level);
			assertEquals("Unknown exception occurred while notify to unit.",
					TestLogger.message);
			return;
		}
		fail();
	}
}
