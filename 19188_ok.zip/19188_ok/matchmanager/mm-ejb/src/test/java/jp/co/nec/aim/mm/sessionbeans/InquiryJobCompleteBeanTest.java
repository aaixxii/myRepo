package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class InquiryJobCompleteBeanTest {
	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private InquiryJobCompleteBean inquiryBean;
	

	private InquiryJobDao inquiryJobDao;
	private DateDao dateDao;

	private SystemConfigDao systemConfigDao;	

	@Before
	public void setUp() throws Exception {		
		inquiryJobDao = new InquiryJobDao(entityManager);		
		systemConfigDao = new SystemConfigDao(entityManager);		
		systemConfigDao.writeAllMissingProperties(ds);
		dateDao = new DateDao(ds);
		clearDB();
		setMockMethod();
	}
	
	public void clearDB() {		
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FUSION_JOBS");
		jdbcTemplate.execute("delete from CONTAINER_JOBS");		
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		
		jdbcTemplate.execute("commit");
	}
	
	private void setMockMethod() {	
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};		
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	@Test
	public void testCompleteJob_remain_job_0() {
		long topJobId = 1000;
		long fusionJobId = 10001;
		long  containerJobId =10001; 
		long planId = 3000;
		long mrId = 5000;
		long[] muIds = {111,222,333};
		long curTime = dateDao.getCurrentTimeMS();
		PBMapInquiryJobResult mrResult = buildMrResult(mrId, muIds, topJobId, planId, false);		
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,1,3000,0,0,1,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,0)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,plan_id,fusion_job_id,mr_id,RESULT_TS,job_state) "
				+ " values(?,1,?,?,?,?,1)";
		jdbcTemplate.update(jobQueueSql, new Object[] {topJobId});		
		jdbcTemplate.update(fusionJobSql, new Object[] {fusionJobId, topJobId});	
		
		jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
				+ " RING_LOCATION, STATE) values(" + mrId + ", '" + mrId
				+ "', " + mrId + ", 'WORKING')");
		jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
				+ " values(" + mrId+ ", " + curTime + ")");
	
	jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
			+ " ASSIGNED_TS) values(1, " + (curTime - 100000) + ")");
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId, planId, fusionJobId, mrId, dateDao.getCurrentTimeMS()});	
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId+1, planId, fusionJobId, mrId,  dateDao.getCurrentTimeMS()});
		inquiryBean.completeJob(mrResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);		
		assertNotNull(cj.getContainerJobResult());
	}
	
	@Test
	public void testCompleteJob_remain_job_1() {
		long topJobId = 1000;
		long fusionJobId = 10001;
		long  containerJobId =10001; 
		long planId = 3000;
		long mrId = 5000;
		long[] muIds = {111,222,333};
		long curTime = dateDao.getCurrentTimeMS();
		PBMapInquiryJobResult mrResult = buildMrResult(mrId, muIds, topJobId, planId, false);		
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,1,3000,0,0,2,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,0)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,plan_id,fusion_job_id,mr_id,RESULT_TS,job_state) "
				+ " values(?,1,?,?,?,?,1)";
		jdbcTemplate.update(jobQueueSql, new Object[] {topJobId});		
		jdbcTemplate.update(fusionJobSql, new Object[] {fusionJobId, topJobId});	
		
		jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
				+ " RING_LOCATION, STATE) values(" + mrId + ", '" + mrId
				+ "', " + mrId + ", 'WORKING')");
		jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
				+ " values(" + mrId+ ", " + curTime + ")");
	
	jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
			+ " ASSIGNED_TS) values(1, " + (curTime - 100000) + ")");
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId, planId, fusionJobId, mrId, dateDao.getCurrentTimeMS()});	
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId+1, planId, fusionJobId, mrId,  dateDao.getCurrentTimeMS()});
		inquiryBean.completeJob(mrResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);		
		assertNotNull(cj.getContainerJobResult());
	}
	
	@Test
	public void testCompleteJob_result_faild_update() {
		long topJobId = 1000;
		long fusionJobId = 10001;
		long  containerJobId =10001; 
		long planId = 3000;
		long mrId = 5000;
		long[] muIds = {111,222,333};
		long curTime = dateDao.getCurrentTimeMS();
		PBMapInquiryJobResult mrResult = buildMrResult(mrId, muIds, topJobId, planId, true);		
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,1,3000,0,0,1,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,0)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,plan_id,fusion_job_id,mr_id,RESULT_TS,job_state) "
				+ " values(?,1,?,?,?,?,1)";
		jdbcTemplate.update(jobQueueSql, new Object[] {topJobId});		
		jdbcTemplate.update(fusionJobSql, new Object[] {fusionJobId, topJobId});	
		
		jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
				+ " RING_LOCATION, STATE) values(" + mrId + ", '" + mrId
				+ "', " + mrId + ", 'WORKING')");
		jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
				+ " values(" + mrId+ ", " + curTime + ")");
	
	jdbcTemplate.execute("insert into LAST_ASSIGNED_MR(ASSIGNED_LOCATION,"
			+ " ASSIGNED_TS) values(1, " + (curTime - 100000) + ")");
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId, planId, fusionJobId, mrId, dateDao.getCurrentTimeMS()});	
		jdbcTemplate.update(contaiJobSql, new Object[] {containerJobId+1, planId, fusionJobId, mrId,  dateDao.getCurrentTimeMS()});
		inquiryBean.completeJob(mrResult);
		ContainerJobEntity cj = inquiryJobDao.getContainerJob(containerJobId);
		assertNotNull(cj);		
		assertNull(cj.getContainerJobResult());
		List<Map<String, Object>> mapValue = jdbcTemplate.queryForList("select * from container_job_failure_reasons where container_job_id=10001");
		assertNotNull(mapValue);	
		assertEquals(1, mapValue.size());
	}
	
	private  PBMapInquiryJobResult buildMrResult(long mrId, long[] muIds, long topLevelJobId,long planId, boolean setingFailed) {	
		PBMapInquiryJobResult.Builder builder = PBMapInquiryJobResult.newBuilder();				
		builder.setMrId(mrId);
		builder.setPlanId(planId);	
		for (int i = 0; i < muIds.length; i++) {
			PBInquiryJobInfoInternal.Builder jobInfo = builder.getJobInfoBuilder(0);
			jobInfo.setTopLevelJobId(topLevelJobId);
			jobInfo.setRequestIndex(1);
			jobInfo.setContainerId(1);
			jobInfo.setMessageSequence(0);
			jobInfo.setJobTimeout(5000);			
			jobInfo.setMuJobPopTime(7);				
		}			
		return builder.build();
	}	
	
	

	
	

}
