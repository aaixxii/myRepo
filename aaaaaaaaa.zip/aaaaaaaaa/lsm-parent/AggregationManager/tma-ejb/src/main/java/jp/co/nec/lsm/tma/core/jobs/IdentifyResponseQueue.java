package jp.co.nec.lsm.tma.core.jobs;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;

/**
 * @author dongqk <br>
 *         just for test
 * 
 */
public class IdentifyResponseQueue {

	private Map<Long, IdentifyResultRequest> responseMap;

	private static IdentifyResponseQueue queue = new IdentifyResponseQueue();

	private final int existSize = 120;

	private IdentifyResponseQueue() {
		responseMap = new ConcurrentHashMap<Long, IdentifyResultRequest>();
	}

	public synchronized static IdentifyResponseQueue getInstance() {
		return queue;
	}

	public void add(IdentifyResultRequest response) {
		responseMap.put(response.getBatchJobId(), response);
		final int removeSize = responseMap.size() - existSize;
		if (removeSize > 0) {
			Set<Long> keys = responseMap.keySet();
			Arrays.sort(keys.toArray());
			Object[] sortedKeys = keys.toArray();
			for (int i = 0; i < removeSize; i++) {
				responseMap.remove(sortedKeys[i]);
			}
		}
	}

	public void remove(long batchJobId) {
		responseMap.remove(batchJobId);
	}

	public IdentifyResultRequest get(long batchJobId) {
		return responseMap.get(batchJobId);
	}
	
	public Map<Long, IdentifyResultRequest> getResponseMap() {
		return responseMap;
	}

	public Collection<IdentifyResultRequest> getAll() {
		return responseMap.values();
	}

	public int size() {
		return responseMap.size();
	}

	public void removeAll() {
		responseMap.clear();
	}

}
