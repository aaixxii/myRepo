package jp.co.nec.lsm.tme.service.pojo;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.ByteString;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJob;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJobResponse;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResult;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResultRequest;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.util.TMETestUtil;

public class EnrollReportServiceBeanTest {

	private EnrollReportServiceBean enrollReportServiceBean;

	private final String referentID = "abcde1234_";

	@Before
	public void setUp() {
		enrollReportServiceBean = new EnrollReportServiceBean();
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}
	}

	/**
	 * prepare data for EnrollRequest
	 * 
	 * @param muIdFirst
	 * @param assignedFirst
	 * @param jobCount
	 * @param batchJobId
	 * @param batchJobId
	 * @param extractJobCount
	 * @return
	 */
	private LocalEnrollBatchJob prepareLocalEnrollBatchJob(long batchJobId,
			int jobCount, int assigned, int muIdFirst) {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		enrollBatchJob.setBatchJobId(batchJobId);
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
		enrollBatchJob.setBatchJobType(BatchType.ENROLL);
		enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());

		enrollBatchJob.setExtractEndTS(DateUtil.getCurrentDate());
		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo jobInfo = new LocalExtractJobInfo();
			jobInfo.setExtractEndTS(DateUtil.getCurrentDate());
			jobInfo.setExtractStartTS(DateUtil.getCurrentDate());
			jobInfo.setFailureCount(i);
			jobInfo.setJobId(i);
			jobInfo.setMUId(muIdFirst);
			jobInfo.setReferenceId(referentID + i);
			jobInfo.setRequestId(String.valueOf(i));
			jobInfo.setReturnCode(ReturnCode.NotUsed);
			if (i <= assigned) {
				jobInfo.setStatus(LocalExtractJobStatus.EXTRACTING);
			} else {
				jobInfo.setStatus(LocalExtractJobStatus.READY);
			}
			jobInfo.setTemplate(prepareTemplate(String.valueOf(i))
					.toByteArray());
			jobInfo.setRequest(TMETestUtil.preperaResponse(batchJobId, i));
			enrollBatchJob.putExtractJobInfo(jobInfo);
		}
		return enrollBatchJob;
	}

	/**
	 * prepare data for Template
	 * 
	 * @param jobId
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	private ExtractJobResponse prepareExtractJobResponse(long batchJobId,
			int start, int end) {

		List<ExtractJob> jobInfoList = new ArrayList<ExtractJob>();
		for (int i = start + 1; i <= start + end; i++) {

			ExtractJob.Builder extractJobInfo = ExtractJob.newBuilder();
			extractJobInfo.setJobIndex(i);
			extractJobInfo.setRequest(TMETestUtil
					.preperaResponse(batchJobId, i).toByteString());
			jobInfoList.add(extractJobInfo.build());
		}

		ExtractJobResponse.Builder extractJob = ExtractJobResponse.newBuilder();
		extractJob.addAllExtractJob(jobInfoList);
		extractJob.setBatchJobId(batchJobId);
		return extractJob.build();
	}

	/**
	 * prepare data for ExtractResult
	 * 
	 * @param extractJob
	 * @return
	 */
	private ExtractJobResultRequest prepareExtractResult(
			ExtractJobResponse extractJob) {
		ExtractJobResultRequest.Builder extractResult = ExtractJobResultRequest
				.newBuilder();
		extractResult.setBatchJobId(extractJob.getBatchJobId());
		List<ExtractJobResult> extractJobResult = new ArrayList<ExtractJobResult>();

		for (int i = 1; i <= extractJob.getExtractJobCount(); i++) {
			ExtractJobResult.Builder jobResult = ExtractJobResult.newBuilder();
			jobResult.setJobIndex(extractJob.getExtractJobList().get(i - 1)
					.getJobIndex());
			// jobResult.setReason(Reason + i);
			jobResult.setErrorCode(i);
			if (i % 2 == 0) {
				jobResult.setReturnCode(ReturnCode.JobFailed);
				jobResult.setResendable(true);
				jobResult.setErrorMessage("ErrorMessage_" + i);
			} else {
				jobResult.setReturnCode(ReturnCode.JobSuccess);
			}
			jobResult.setTemplate(prepareTemplate(String.valueOf(jobResult
					.getJobIndex())));
			jobResult.setResponse(TMETestUtil.preperaResponse(
					extractJob.getBatchJobId(), i).toByteString());
			extractJobResult.add(jobResult.build());
		}
		extractResult.addAllExtractJobResult(extractJobResult);

		return extractResult.build();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testdoReport]<br/>
	 * 1 - prepare EnrollRequest For test<br/>
	 * 2 - call FetchExtractJobs<br/>
	 * 3 - prepare EnrollRequest For test<br/>
	 * 4 - call doReport<br/>
	 * 5 - query database to get data<br/>
	 * 6 - assert concerning information<br/>
	 */
	@Test
	public void testdoReport() {

		long batchJobId = 15;
		int jobCount = 15;
		int assignedFirst = jobCount / 2;
		int assignedSecond = jobCount - assignedFirst;
		int muIdFirst = 15;
		int muIdSecond = 16;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		// 1 - prepare EnrollRequest For test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchJobId, jobCount, assignedFirst, muIdFirst);
		queueManage.addEnrollBatchJob(enrollBatchJob);

		// 2 - call FetchExtractJobs

		ExtractJobResponse extractJobFirst = prepareExtractJobResponse(
				batchJobId, 0, assignedFirst);

		// 3 - prepare EnrollRequest For test
		ExtractJobResultRequest extractResultFirst = prepareExtractResult(extractJobFirst);

		// 4 - call doReport
		enrollReportServiceBean.doReport(extractResultFirst);

		// 5 - query database to get JobInf
		LocalEnrollBatchJob enrollBatchJobFirst = queueManage
				.getEnrollBatchJobById(batchJobId);

		// 6 - assert concerning information
		assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJobFirst
				.getBatchJobStatus());
		assertEquals(assignedFirst, enrollBatchJobFirst
				.getCompletedExtractJobCount());

		List<ExtractJobResult> extractJobResultListFirst = extractResultFirst
				.getExtractJobResultList();

		for (int j = 1; j <= assignedFirst; j++) {

			byte[] bs = prepareTemplate(
					String.valueOf(extractJobResultListFirst.get(j - 1)
							.getJobIndex())).toByteArray();

			ExtractJobResult extractJobResult = extractJobResultListFirst
					.get(j - 1);
			assertNotNull(extractJobResult);

			LocalExtractJobInfo enrollBatchJobInfo = enrollBatchJobFirst
					.getExtractJobInfo(extractJobResult.getJobIndex());
			assertNotNull(enrollBatchJobInfo);

			assertTrue(enrollBatchJobInfo.isStatus(LocalExtractJobStatus.DONE));
			assertNotNull(enrollBatchJobInfo.getExtractStartTS());
			assertEquals(muIdFirst, enrollBatchJobInfo.getMUId());

			assertEquals(enrollBatchJobInfo.getRequestId(), String.valueOf(j));
			assertEquals(enrollBatchJobInfo.getReferenceId(), referentID + j);
			assertEquals(enrollBatchJobInfo.getErrorCode(), String.valueOf(j));
			if (j % 2 == 0) {
				assertEquals(enrollBatchJobInfo.getReturnCode(),
						ReturnCode.JobFailed);
				assertEquals(true, enrollBatchJobInfo.isReSendable());
				assertEquals("ErrorMessage_" + j, enrollBatchJobInfo
						.getErrorMessage());
			} else {
				assertEquals(enrollBatchJobInfo.getReturnCode(),
						ReturnCode.JobSuccess);
				assertNull(enrollBatchJobInfo.getErrorMessage());
			}
			assertEquals(enrollBatchJobInfo.getFailureCount(), j);

			assertTrue(enrollBatchJobInfo.getRequest().toByteArray().length > 0);
			for (int i = 0; i < enrollBatchJobInfo.getRequest().toByteArray().length; i++) {
				assertEquals(enrollBatchJobInfo.getRequest().toByteArray()[i],
						TMETestUtil.preperaResponse(batchJobId, j)
								.toByteArray()[i]);
			}

			assertTrue(enrollBatchJobInfo.getResponse().toByteArray().length > 0);
			for (int i = 0; i < enrollBatchJobInfo.getResponse().toByteArray().length; i++) {
				assertEquals(enrollBatchJobInfo.getResponse().toByteArray()[i],
						TMETestUtil.preperaResponse(batchJobId, j)
								.toByteArray()[i]);
			}

			assertEquals(enrollBatchJobInfo.getBiometricId(), -1);
			for (int len = 0; len < bs.length; len++) {
				assertEquals(bs[len], enrollBatchJobInfo.getTemplate()[len]);
			}
			assertNotNull(enrollBatchJobInfo.getExtractEndTS());
		}

		LocalEnrollBatchJob enrollBatchJob2 = queueManage
				.getEnrollBatchJobById(batchJobId);

		update(enrollBatchJob2, muIdSecond);

		// 2 - call FetchExtractJobs
		ExtractJobResponse extractJobSecond = prepareExtractJobResponse(
				batchJobId, assignedFirst, assignedSecond);

		// 3 - prepare EnrollRequest For test
		ExtractJobResultRequest extractResultSecond = prepareExtractResult(extractJobSecond);

		LocalEnrollBatchJob batchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		// update BatchJob information
		enrollReportServiceBean.updateBatchJob(extractResultSecond, batchJob);

		// 5 - query database to get JobInf
		LocalEnrollBatchJob enrollBatchJobSecond = queueManage
				.getEnrollBatchJobById(batchJobId);

		// 6 - assert concerning information
		assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJobSecond
				.getBatchJobStatus());
		assertEquals(assignedFirst + assignedSecond, enrollBatchJobSecond
				.getCompletedExtractJobCount());
		assertNotNull(enrollBatchJobSecond.getExtractEndTS());

		List<ExtractJobResult> extractJobResultListSecond = extractResultSecond
				.getExtractJobResultList();

		for (int j = 1; j <= assignedSecond; j++) {

			byte[] bs = prepareTemplate(
					String.valueOf(extractJobResultListSecond.get(j - 1)
							.getJobIndex())).toByteArray();

			ExtractJobResult extractJobResult = extractJobResultListSecond
					.get(j - 1);
			assertNotNull(extractJobResult);

			LocalExtractJobInfo enrollBatchJobInfo = enrollBatchJobSecond
					.getExtractJobInfo(extractJobResult.getJobIndex());
			assertNotNull(enrollBatchJobInfo);

			assertTrue(enrollBatchJobInfo.isStatus(LocalExtractJobStatus.DONE));
			assertNotNull(enrollBatchJobInfo.getExtractStartTS());
			assertEquals(muIdSecond, enrollBatchJobInfo.getMUId());

			assertEquals(enrollBatchJobInfo.getRequestId(), String.valueOf(j
					+ assignedFirst));
			assertEquals(enrollBatchJobInfo.getReferenceId(), referentID
					+ (j + assignedFirst));
			assertEquals(enrollBatchJobInfo.getErrorCode(), String.valueOf(j));
			if (j % 2 == 0) {
				assertEquals(enrollBatchJobInfo.getReturnCode(),
						ReturnCode.JobFailed);
				assertEquals(true, enrollBatchJobInfo.isReSendable());
				assertEquals("ErrorMessage_" + j, enrollBatchJobInfo
						.getErrorMessage());
			} else {
				assertEquals(enrollBatchJobInfo.getReturnCode(),
						ReturnCode.JobSuccess);
				assertNull(enrollBatchJobInfo.getErrorMessage());
			}
			assertEquals(enrollBatchJobInfo.getFailureCount(), j
					+ assignedFirst);

			assertTrue(enrollBatchJobInfo.getRequest().toByteArray().length > 0);
			for (int i = 0; i < enrollBatchJobInfo.getRequest().toByteArray().length; i++) {
				assertEquals(enrollBatchJobInfo.getRequest().toByteArray()[i],
						TMETestUtil.preperaResponse(batchJobId,
								j + assignedFirst).toByteArray()[i]);
			}

			assertTrue(enrollBatchJobInfo.getResponse().toByteArray().length > 0);
			for (int i = 0; i < enrollBatchJobInfo.getResponse().toByteArray().length; i++) {
				CPBBusinessMessage bmJob = enrollBatchJobInfo.getResponse();
				CPBBusinessMessage bmNew = TMETestUtil.preperaResponse(
						batchJobId, j + assignedFirst);
				assertEquals(bmJob.toByteArray()[i], bmNew.toByteArray()[i]);
			}

			assertEquals(enrollBatchJobInfo.getBiometricId(), -1);
			for (int len = 0; len < bs.length; len++) {
				assertEquals(bs[len], enrollBatchJobInfo.getTemplate()[len]);
			}
			assertNotNull(enrollBatchJobInfo.getExtractEndTS());
		}
	}

	private void update(LocalEnrollBatchJob enrollBatchJob, int muIdSecond) {

		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);

		enrollBatchJob.setExtractEndTS(DateUtil.getCurrentDate());

		for (int i = 1; i <= enrollBatchJob.getExtractJobCount(); i++) {
			LocalExtractJobInfo jobInfo = enrollBatchJob.getExtractJobInfo(i);
			jobInfo.setMUId(muIdSecond);
			jobInfo.setReturnCode(ReturnCode.NotUsed);
			if (jobInfo.isStatus(LocalExtractJobStatus.READY)) {
				jobInfo.setStatus(LocalExtractJobStatus.EXTRACTING);
			}
		}
		return;

	}

	/**
	 * 
	 */
	@Test
	public void testdoReport_MultThread() {

		long batchJobId = 1500;
		int batchJobCount = 5;
		int extractjobCount = 100;
		int assignedCount = 10;
		int muId = 15;
		int threadCount = 10;

		class ReportTask implements Callable<String> {

			ExtractJobResultRequest extractResultRequest;

			public ReportTask(ExtractJobResultRequest extractResultRequest) {
				this.extractResultRequest = extractResultRequest;
			}

			public String call() throws Exception {
				EnrollReportServiceBean enrollReportServiceBean = new EnrollReportServiceBean();

				// call doReport
				enrollReportServiceBean.doReport(extractResultRequest);

				return null;
			}
		}

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		for (int i = 0; i < batchJobCount; i++) {
			// 1 - prepare EnrollRequest For test
			LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
					batchJobId + i, extractjobCount, extractjobCount, muId);
			queueManage.addEnrollBatchJob(enrollBatchJob);
		}

		// prepare test data
		List<ReportTask> postArray = new ArrayList<ReportTask>();
		for (int i = 0; i < extractjobCount * batchJobCount / assignedCount; i++) {
			long batchid = batchJobId + (i * assignedCount / extractjobCount);
			int startIndex = i * assignedCount
					- (i * assignedCount / extractjobCount) * extractjobCount;
			int endIndex = (i + 1) * assignedCount
					- ((i + 1) * assignedCount / extractjobCount)
					* extractjobCount;

			// prepare ExtractJobResponse
			ExtractJobResponse extractJobResponse = prepareExtractJobResponse(
					batchid, startIndex, endIndex);

			// prepare EnrollRequest For test
			ExtractJobResultRequest extractResultRequest = prepareExtractResult(extractJobResponse);

			postArray.add(new ReportTask(extractResultRequest));
		}

		// invoke mult-thread to do EnrollReportServiceBean.doReport
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(threadCount);
			try {
				service.invokeAll(postArray);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} finally {
			if (service != null) {
				service.shutdown();
			}
		}

		// assert result
		for (int i = 0; i < batchJobCount; i++) {
			// 1 - prepare EnrollRequest For test
			LocalEnrollBatchJob enrollBatchJob = queueManage
					.getEnrollBatchJobById(batchJobId + i);
			assertTrue(enrollBatchJob.areAllExtractJobsDone());
		}

	}

	@Test
	public void testdoReport_2() {
		long batchJobId = 15;
		int jobCount = 15;
		int assignedFirst = jobCount / 2;
		int muIdFirst = 15;

		// 1 - prepare EnrollRequest For test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchJobId, jobCount, assignedFirst, muIdFirst);

		// 2 - call FetchExtractJobs
		ExtractJobResponse extractJobFirst = prepareExtractJobResponse(
				batchJobId, 0, assignedFirst);

		// 3 - prepare EnrollRequest For test
		ExtractJobResultRequest extractResultFirst = prepareExtractResult(extractJobFirst);

		enrollReportServiceBean.doReport(extractResultFirst);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTED);
		queueManage.addEnrollBatchJob(enrollBatchJob);

		enrollReportServiceBean.doReport(extractResultFirst);

		try {
			enrollReportServiceBean.doReport(extractResultFirst);
		} catch (IllegalArgumentException e) {
			assertEquals("ExtractResultRequest can not be null.", e
					.getMessage());
		}
	}
}
