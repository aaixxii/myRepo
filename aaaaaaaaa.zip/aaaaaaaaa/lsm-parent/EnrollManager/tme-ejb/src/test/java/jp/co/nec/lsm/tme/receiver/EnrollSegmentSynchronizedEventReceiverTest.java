//package jp.co.nec.lsm.tme.receiver;
//
//import javax.jms.ConnectionFactory;
//import javax.jms.MessageListener;
//import javax.jms.Queue;
//
//import org.apache.activemq.ActiveMQConnectionFactory;
//import org.apache.activemq.broker.BrokerService;
//import org.apache.activemq.command.ActiveMQQueue;
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import org.springframework.jms.connection.SingleConnectionFactory;
//import org.springframework.jms.listener.DefaultMessageListenerContainer;
//
//import jp.co.nec.lsm.event.enroll.EnrollAbstractEvent;
//import jp.co.nec.lsm.event.enroll.EnrollSegmentSynchronizedEvent;
//import jp.co.nec.lsm.event.enroll.EnrollTemplateUpdatedEvent;
//import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
//import jp.co.nec.lsm.event.enroll.common.EnrollReceiverEnum;
//import jp.co.nec.lsm.event.enroll.notifier.EnrollNotifier;
//import jp.co.nec.lsm.tm.common.constants.DeployName;
//import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
//import jp.co.nec.lsm.tm.common.util.ServiceLocator;
//import jp.co.nec.lsm.tme.service.sessionbean.EnrollResponseServiceBean;
//import jp.co.nec.lsm.tme.sessionbeans.api.EnrollResponseServiceLocal;
//import junit.framework.Assert;
//import mockit.Mock;
//import mockit.MockUp;
//
//public class EnrollSegmentSynchronizedEventReceiverTest {
//
//	private ConnectionFactory jmsFactory;
//	private Queue queueDestination;
//	private static BrokerService broker;
//	private static boolean isNotReceived = true;
//	private static String receiveMessage;
//	private static long receiveBatchJobId;
//	private static int rerunLimit = 50;
//	private DefaultMessageListenerContainer listener = new DefaultMessageListenerContainer();
//
//	@BeforeClass
//	public static void startBrokerService() throws Exception {
//		broker = new BrokerService();
//		// configure the broker
//		broker.setBrokerName("BrokerService");
//		broker.addConnector("vm://localhost");
//		broker.setPersistent(false);
//		broker.start();
//	}
//
//	@AfterClass
//	public static void stopBrokerService() throws Exception {
//		broker.stop();
//	}
//
//	@Before
//	public void setUp() {
//		receiveMessage = "";
//		receiveBatchJobId = 0;
//	}
//
//	@After
//	public void tearDown() {
//		listener.stop();
//		listener.destroy();
//	}
//
//	/**
//	 * setMockMethod
//	 */
//	public void setJMSMockMethod(final String queueName, final String message,
//			final String beanName) {
//
//		class ResponseSer implements EnrollResponseServiceLocal {
//
//			@Override
//			public void doResponse(long batchJobId) {
//				isNotReceived = false;
//				receiveMessage = message;
//				receiveBatchJobId = batchJobId;
//			}
//
//		}
//
//		new MockUp<ServiceLocator>() {
//			@SuppressWarnings( { "unchecked" })
//			@Mock
//			private <T> T getLookUpJndiObject(String jndiName, Class<T> clazz) {
//				if (jndiName.equals(JNDIConstants.JmsFactory)) {
//					return (T) jmsFactory;
//				} else if (jndiName.equals(queueName)) {
//					return (T) queueDestination;
//				} else if (jndiName.equals(beanName)) {
//					return (T) new ResponseSer();
//				}
//				return null;
//			}
//		};
//
//	}
//
//	@Test
//	public void testDispatchEvent_Response() throws Exception {
//		long batchJobId = 75347;
//		isNotReceived = true;
//		String jndiName = DeployName.ENROLL_EARFILE + JNDIConstants.SPLIT
//				+ EnrollResponseServiceBean.class.getSimpleName();
//				;
//		String message = "testDispatchEvent_Response";
//		setJMSMockMethod(JNDIConstants.ENROLL_QUEUE, message, jndiName);
//
//		EnrollSegmentSynchronizedEventReceiver receiver = new EnrollSegmentSynchronizedEventReceiver();
//		prepearContext(JNDIConstants.ENROLL_QUEUE, receiver);
//
//		Thread.sleep(1000);
//
//		EnrollAbstractEvent event = new EnrollSegmentSynchronizedEvent(
//				batchJobId, EnrollNotifierEnum.EnrollSegmentSyncService,
//				EnrollReceiverEnum.EnrollResponseService);
//
//		Thread thread = new TestEventSender(batchJobId, event);
//		thread.start();
//		thread.join();
//
//		assertResult(message, batchJobId);
//	}
//
//	@Test
//	public void testDispatchEvent_Response_NotReceive() throws Exception {
//		long batchJobId = 75347;
//		isNotReceived = true;
//		String jndiName = DeployName.ENROLL_EARFILE + JNDIConstants.SPLIT
//				+ EnrollResponseServiceBean.class.getSimpleName();
//				
//		String message = "testDispatchEvent_Response";
//		setJMSMockMethod(JNDIConstants.ENROLL_QUEUE, message, jndiName);
//
//		EnrollSegmentSynchronizedEventReceiver receiver = new EnrollSegmentSynchronizedEventReceiver();
//		prepearContext(JNDIConstants.ENROLL_QUEUE, receiver);
//
//		Thread.sleep(1000);
//
//		EnrollAbstractEvent event = new EnrollTemplateUpdatedEvent(batchJobId,
//				EnrollNotifierEnum.EnrollSegmentSyncService,
//				EnrollReceiverEnum.EnrollResponseService, false);
//
//		Thread thread = new TestEventSender(batchJobId, event);
//		thread.start();
//		thread.join();
//
//		assertResult_NotReceive();
//	}
//
//	/**
//	 * 
//	 * @param BrokerName
//	 * @param QueueName
//	 * @return
//	 * @throws Exception
//	 */
//	private void prepearContext(String QueueName,
//			MessageListener messageListener) throws Exception {
//
//		jmsFactory = new ActiveMQConnectionFactory(
//				"vm://ConnectionFactory?broker.persistent=false");
//		queueDestination = new ActiveMQQueue(QueueName);
//
//		final SingleConnectionFactory singleConnectionFactory = new SingleConnectionFactory(
//				jmsFactory);
//
//		listener.setConnectionFactory(singleConnectionFactory);
//		listener.setDestination(queueDestination);
//
//		listener.setMessageListener(messageListener);
//		listener.afterPropertiesSet();
//		listener.start();
//
//		return;
//	}
//
//	class TestEventSender extends Thread {
//		EnrollAbstractEvent event;
//		long batchJobId;
//
//		public TestEventSender(long batchJobId, EnrollAbstractEvent event) {
//			this.event = event;
//			this.batchJobId = batchJobId;
//		}
//
//		@Override
//		public void run() {
//			EnrollNotifier notify = new EnrollNotifier();
//			notify.sendEvent(event);
//		}
//	}
//
//	/**
//	 * asserts
//	 */
//	private void assertResult(String message, long batchJobId) {
//		int run = 0;
//		while (isNotReceived && run++ <= rerunLimit) {
//			try {
//				Thread.sleep(100);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}
//
//		if (run > rerunLimit) {
//			Assert.fail();
//		}
//
//		Assert.assertEquals(receiveMessage, message);
//		Assert.assertEquals(receiveBatchJobId, batchJobId);
//	}
//
//	/**
//	 * asserts
//	 */
//	private void assertResult_NotReceive() {
//		int run = 0;
//		while (isNotReceived && run++ <= rerunLimit) {
//			try {
//				Thread.sleep(100);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}
//
//		if (run > rerunLimit) {
//			Assert.assertTrue(run > rerunLimit);
//		} else {
//			Assert.fail();
//		}
//	}
//}
