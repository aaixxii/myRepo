package jp.co.nec.lsm.tme.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.enroll.EnrollSegmentSynchronizedEvent;
import jp.co.nec.lsm.event.receiver.AbstractEventReceiver;
import jp.co.nec.lsm.tm.common.constants.DeployName;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollResponseServiceBean;

/**
 * @author liuyq <br>
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.ENROLL_QUEUE),
		@ActivationConfigProperty(propertyName = "messageSelector", propertyValue = "messageReceiver = 'EnrollResponseService'") })
public class EnrollSegmentSynchronizedEventReceiver extends
		AbstractEventReceiver implements MessageListener {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollSegmentSynchronizedEventReceiver.class);

	/**
	 * receiver: EnrollResponseService.. after Enroll Segment Sync Service done
	 * notify EnrollResponseService
	 * 
	 * @param event
	 */
	@Override
	protected void dispatchEvent(Event event) {
		printLogMessage("start private function dispatchEvent()..");

		if (!(event instanceof EnrollSegmentSynchronizedEvent)) {
			log.error("event is not a EnrollSegmentSynchronizedEvent instance.");
			return;
		}

		String jndiName = DeployName.ENROLL_EARFILE + JNDIConstants.SPLIT
				+ EnrollResponseServiceBean.class.getSimpleName();				
		EnrollResponseServiceBean template = ServiceLocator
				.getLookUpJndiObject(jndiName, EnrollResponseServiceBean.class);
		template.doResponse(event.getBatchJobId());

		printLogMessage("end private function dispatchEvent()..");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
