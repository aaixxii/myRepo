package jp.co.nec.lsm.tme.snapshot;

import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;

public class EnrollBatchJobSnapShotDetail {
	private long batchJobId;
	private int jobCount;
	private EnrollBatchJobStatus status;
	private int extractingJobCount;
	private int extractedJobCount;
	private int templatesCount;
	private String syncingGMV;
	private long holdingTime;

	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}

	public long getBatchJobId() {
		return batchJobId;
	}

	public void setJobCount(int jobCount) {
		this.jobCount = jobCount;
	}

	public int getJobCount() {
		return jobCount;
	}

	public void setStatus(EnrollBatchJobStatus status) {
		this.status = status;
	}

	public EnrollBatchJobStatus getStatus() {
		return status;
	}

	public void setExtractingJobCount(int extractingJobCount) {
		this.extractingJobCount = extractingJobCount;
	}

	public int getExtractingJobCount() {
		return extractingJobCount;
	}

	public String getExtractingJobCount(EnrollBatchJobStatus status) {
		if (this.status == status)
			return String.valueOf(extractingJobCount);
		else
			return "-";
	}

	public void setExtractedJobCount(int extractedJobCount) {
		this.extractedJobCount = extractedJobCount;
	}

	public int getExtractedJobCount() {
		return extractedJobCount;
	}

	public String getExtractedJobCount(EnrollBatchJobStatus status) {
		if (this.status == status)
			return String.valueOf(extractedJobCount);
		else
			return "-";
	}

	public void setTemplatesCount(int templatesCount) {
		this.templatesCount = templatesCount;
	}

	public int getTemplatesCount() {
		return templatesCount;
	}

	public String getTemplatesCount(EnrollBatchJobStatus status) {
		if (this.status == status) {
			if (templatesCount < jobCount) {
				return "<div style=\"color:Red\">" + templatesCount + "</div>";
			} else {
				return String.valueOf(templatesCount);
			}
		} else
			return "-";
	}

	public void setHoldingTime(long holdingTime) {
		this.holdingTime = holdingTime;
	}

	public long getHoldingTime() {
		return holdingTime;
	}

	public String getHoldingTime(EnrollBatchJobStatus status) {
		if (this.status == status)
			return String.valueOf(holdingTime / 1000) + "s";
		else
			return "-";
	}

	public void setSyncingGMV(String syncingGMV) {
		this.syncingGMV = syncingGMV;
	}

	public String getSyncingGMV() {
		return syncingGMV;
	}

	public String getSyncingGMV(EnrollBatchJobStatus status) {
		if (this.status == status && syncingGMV != null)
			return syncingGMV;
		else
			return "-";
	}
}
