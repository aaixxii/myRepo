package jp.co.nec.lsm.event.identify;

import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;

/**
 * @author jimy <br>
 *         IdentifyBatchJobResultEvent
 */
public class IdentifyBatchJobResultEvent extends IdentifyAbstractEvent {

	private static final long serialVersionUID = 1L;

	public IdentifyBatchJobResultEvent(long batchJobId,
			IdentifyNotifierEnum identifyNotifier,
			IdentifyReceiverEnum identifyReceiver) {
		setBatchJobId(batchJobId);
		setIdentifyNotifier(identifyNotifier);
		setIdentifyReceiver(identifyReceiver);
	}

	private BatchSegmentJobMap batchSegmentJobMap;

	public BatchSegmentJobMap getBatchSegmentJobMap() {
		return batchSegmentJobMap;
	}

	public void setBatchSegmentJobMap(BatchSegmentJobMap batchSegmentJobMap) {
		this.batchSegmentJobMap = batchSegmentJobMap;
	}

}
