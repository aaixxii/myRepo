#!/bin/sh
./bin/shutdown.sh

#ps -u aimruser
PWD=`pwd`
while(true); do
        RET=`ps -ef | grep java |grep -v grep | grep $PWD|wc | awk '{print $1}'`
        if [ "$RET" = "0" ]; then
                echo "============================================================"
                echo
                echo "  $PWD is stopped!"
                echo
                echo "============================================================"
                break;
        else
                echo "......... $PWD is still running ......."
        fi
        sleep 1
done

rm -rf webapps/matchmanager
rm -rf work/Catalina/localhost/matchmanager
