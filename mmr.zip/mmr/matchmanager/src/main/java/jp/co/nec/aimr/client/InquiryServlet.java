package jp.co.nec.aimr.client;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.service.inquiry.AimrInquiryService;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author xiazp <br/>
 * InquiryServlet response to get inquiry request from client <br/>       
 * 
 */
@WebServlet(name = "InquiryServlet", urlPatterns = { "/AIMInquiryService/identify" })
public class InquiryServlet extends BaseServlet {
	private static final long serialVersionUID = 4333650079708919605L;
	private static Logger log = LoggerFactory.getLogger(InquiryServlet.class);
	private static final String INQUIRY_URL_PATTERN = "/AIMInquiryService/identify";

	public void init() throws ServletException {
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		StopWatch t = new StopWatch();		
		t.start();
		final String url = req.getRequestURL().toString().toLowerCase();
		log.info("Received servlet request! form URL", url);
		if (url.endsWith((INQUIRY_URL_PATTERN.toLowerCase()))) {
			doInquiry(req, res);
		} else {
			doNoSuport(req, res, NOT_SUPPORT_METHOD);
		}
		t.stop();		
		log.info("****MMr server used {} ms to process this request.****", t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "doPost", null, null, t.elapsedTime());
		t = null;
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		final String url = req.getRequestURL().toString().toLowerCase();
		if (url.endsWith(INQUIRY_URL_PATTERN.toLowerCase())) {
			doNoSuport(req, res, "inquiry with get is not supported");
		} else {
			final String unknownMsg = String.format(NOT_SUPPORT_METHOD, "unknown");
			log.error(unknownMsg);
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST, unknownMsg, null);
			return;
		}
	}

	/**
	 * @param req
	 * @param res
	 * @throws IOException
	 */
	private void doInquiry(final HttpServletRequest req, final HttpServletResponse res) throws IOException {
		if (isContextSizeEmpty(req)) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST, EMPTY_REQUEST_MSG, null);
			return;
		}		
		log.debug("ready to deSerial from inputStream..");		
		PBIdentifyRequest request = null;

		try {
			request = PBIdentifyRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST, ex.getMessage(), ex);
			return;
		}		
		log.debug("ready to call inquiry with parameter PBInquiryJobRequest..");
		
		PBIdentifyResponse clientResp = null;
		AimrInquiryService inquiryService = new AimrInquiryService(request);
		try {
			clientResp = inquiryService.processIdentifyRequest();
			log.info("MMR return result is success = {}", clientResp != null);
			if (clientResp == null) {
				String errMsg = " The inqury job results is empty!";
				writeErrorToResponse(req, res, HttpStatus.SC_INTERNAL_SERVER_ERROR, errMsg, null);
				return;
			}

		} catch (Exception ex) {
			String errMsg = "Internal exception is accored!";
			writeErrorToResponse(req, res, HttpStatus.SC_INTERNAL_SERVER_ERROR, errMsg, ex);
		}		
		log.debug("ready to Serial the PBInquiryJobResponse and write into outputstream..");
		
		clientResp.writeTo(res.getOutputStream());
		res.setStatus(HttpStatus.SC_OK);
		log.info("Success to send identify job respose to client. Http status = {}", HttpStatus.SC_OK);
		inquiryService = null;
	}
	public void destroy() {
	}
}
