package jp.co.nec.aimr.service.extract;

import jp.co.nec.aimr.common.JobState;

public class ExtractJobStatus {
	private long extJobId;
	private JobState extJobStatus;
	private String errFlg;
	private String resion;
	private long queuedTime;

	public long getExtJobId() {
		return extJobId;
	}

	public void setExtJobId(long extJobId) {
		this.extJobId = extJobId;
	}

	public JobState getExtJobStatus() {
		return extJobStatus;
	}

	public void setExtJobStatus(JobState extJobStatus) {
		this.extJobStatus = extJobStatus;
	}

	public String getErrFlg() {
		return errFlg;
	}

	public void setErrFlg(String errFlg) {
		this.errFlg = errFlg;
	}

	public String getResion() {
		return resion;
	}

	public void setResion(String resion) {
		this.resion = resion;
	}

	public long getQueuedTime() {
		return queuedTime;
	}

	public void setQueuedTime(long queuedTime) {
		this.queuedTime = queuedTime;
	}
}
