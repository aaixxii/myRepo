package jp.co.nec.aimr.exception;

import jp.co.nec.aimr.common.ErrorDifinitions;

public class AimRuntimeException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 5670653981311541162L;

	public AimRuntimeException() {
	}

	public AimRuntimeException(String detail) {
		super(detail);
	}

	public AimRuntimeException(Throwable ex) {
		super(ex);
	}

	public AimRuntimeException(String detail, Throwable ex) {
		super(detail, ex);
	}

	public AimRuntimeException(ErrorDifinitions errorDifinition) {
		super(errorDifinition.toString());
	}
}
