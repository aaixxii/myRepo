package jp.co.nec.aimr.persistence.aimdb;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import jp.co.nec.aimr.management.AIMrManger;

public class GetTableNameDaoImp implements GetTableNameDao {
	private JdbcTemplate jdbcTemplate;

	public GetTableNameDaoImp(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<AimrTableNameMapper> getAimrTableNames() throws DataAccessException {
		String dbDriver = AIMrManger.getInstance().getDB_DRIVER().toUpperCase();
		String sql = null;
		switch (dbDriver) {
		case "ORACLE":
		case "MYSQL":
			sql = "SELECT CONTAINER_ID, CONTAINER_TABLE_NAME,CONTAINER_LOG_TABLE_NAME FROM CONTAINERS";			
			break;
		case "POSTGRESQL":
			sql = "SELECT \"CONTAINER_ID\", \"CONTAINER_TABLE_NAME\",\"CONTAINER_LOG_TABLE_NAME\" FROM \"CONTAINERS\"";	
			break;			
		case "SQLSERVER":
			sql = "SELECT CONTAINER_ID, CONTAINER_TABLE_NAME,CONTAINER_LOG_TABLE_NAME FROM CONTAINERS";	
			break;
		default:
			break;
		}		
		List<AimrTableNameMapper> results = jdbcTemplate.query(sql, new TableMapper());
		return results;
	}

	private static class TableMapper implements RowMapper<AimrTableNameMapper> {

		@Override
		public AimrTableNameMapper mapRow(ResultSet rs, int rowNum) throws SQLException {
			AimrTableNameMapper at = new AimrTableNameMapper();
			at.setContainerId(rs.getInt("CONTAINER_ID"));
			at.setPersonBiometricsTableName(rs.getString("CONTAINER_TABLE_NAME"));
			at.setPersonBiometricsChangeLogName(rs.getString("CONTAINER_LOG_TABLE_NAME"));
			return at;
		}
	}
	
	@Override
	public void commit() {
		jdbcTemplate.execute("COMMIT");
	}
	
	@Override
	public void rollback() {
		jdbcTemplate.execute("ROLLBACK");
	}
}
