package jp.co.nec.aimr.spring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BeanFactory {
	private static Logger log = LoggerFactory.getLogger(BeanFactory.class);

	/**
	 * ApplicationContext filed will load applicationContext.xml and
	 * spring-jms.xml
	 */
	private static AbstractApplicationContext applicationContext;

	private static BeanFactory instance;

	public static BeanFactory getInstance() {
		if (instance == null) {
			log.info("new BeanFactory()");
			instance = new BeanFactory();
		}
		log.info("call getInstance()");
		return instance;
	}

	private BeanFactory() {
		applicationContext = new ClassPathXmlApplicationContext(new String[] { "applicationContext.xml" });
	}

	/**
	 * get bean instance
	 * 
	 * @param name
	 *            - bean name defined Spring bean xml file.
	 * @return - bean instance
	 */
	public Object getBean(String name) {
		if (name == null) {
			throw new IllegalArgumentException("name == null");
		}
		log.info("call getBean()");
		return applicationContext.getBean(name);
	}
}
