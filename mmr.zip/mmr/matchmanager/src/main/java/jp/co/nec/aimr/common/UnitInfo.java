package jp.co.nec.aimr.common;

public class UnitInfo {
	private long unitId;
	private String url;
	private int port;

	public UnitInfo(long muId, String url, int port) {
		this.unitId = muId;
		this.url = url;
		this.port = port;
	}

	public long getMuId() {
		return unitId;
	}

	public void setMuId(long muId) {
		this.unitId = muId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
}
