package jp.co.nec.aimr.common;

public enum JobIdType {
	VERIFY_ID(0), //
	ENROLL_ID(1), //
	INQUIRY_ID(2), //
	EXTEACT_ID(3), //
	UNIT_ID(4);//

	private int val;

	private JobIdType(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}
}
