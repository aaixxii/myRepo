package jp.co.nec.aimr.persistence.aimdb;

public interface TransactionDao {
	public void COMMIT();

	public void rollback();

}
