package jp.co.nec.aimr.persistence.aimdb;

public class AimrTableNameMapper {
	private Integer containerId;
	private String personBiometricsTableName;
	private String personBiometricsChangeLogName;

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public String getPersonBiometricsTableName() {
		return personBiometricsTableName;
	}

	public void setPersonBiometricsTableName(String personBiometricsTableName) {
		this.personBiometricsTableName = personBiometricsTableName;
	}

	public String getPersonBiometricsChangeLogName() {
		return personBiometricsChangeLogName;
	}

	public void setPersonBiometricsChangeLogName(String personBiometricsChangeLogName) {
		this.personBiometricsChangeLogName = personBiometricsChangeLogName;
	}
}
