package jp.co.nec.aimr.common;

public class Constants {

	public static final String ENCODING_UTF8 = "UTF-8";
	public static final int BUF_HEAD_SIZE = 48;
	
	public static final String DB_ORACLE_DRIVER_NAME = "ORACLE";
	public static final String DB_MYSQL_DRIVER_NAME = "MYSQL";
	public static final String DB_POSTGRESQL_DRIVER_NAME = "POSTGRESQL";
	public static final String DB_SQLSERVER_DRIVER_NAME = "SQLSERVER";	

}
