package jp.co.nec.aimr.client;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.sql.DataSource;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aimr.agent.AimRSocketServer;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.common.XmlUtil;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AimrTableNameMapper;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.persistence.aimdb.GetTableNameDao;
import jp.co.nec.aimr.persistence.aimdb.GetTableNameDaoImp;

/**
 * @author xiazp <br/> 
 * MMrListener is a context listener of web application <br/>
 */
@WebListener
public class MMrListener implements ServletContextListener {
	private static Logger logger = LoggerFactory.getLogger(MMrListener.class);	
	private static final String LOG_FILE_NAME = "conf/mmrConf/log4j.properties";
	private static String LOG_PROPERTY;
	Thread server;	

	/*
	 * Initialize MMr server(server socket and thread pool)
	 * 
	 * @see
	 * javax.servlet.ServletContextListener#contextInitialized(javax.servlet
	 * .ServletContextEvent)
	 */
	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		AimRSocketServer aimrSocketServer = null;
		try {
			aimrSocketServer = new AimRSocketServer();
			server = new Thread(aimrSocketServer);
			server.start();
		} catch (IOException e1) {
			logger.error(e1.getMessage(), e1.getCause());
		}		
		EventNotifier.getInstance().addSystemListener(aimrSocketServer);
		
		String dbName = AIMrManger.getInstance().getDB_DRIVER();
		XmlUtil.setResourceRef(dbName);			
		DataSource ds = DataBaseUtil.lookupDataSource();
		GetTableNameDao dao = new GetTableNameDaoImp(ds);	
		try {			
			List<AimrTableNameMapper> aimrTableNameList = dao.getAimrTableNames();
			for (AimrTableNameMapper mapper : aimrTableNameList) {
				AIMrManger.saveTopersonBiometricsTabMap(mapper.getContainerId(), mapper.getPersonBiometricsTableName());
				AIMrManger.saveTopersonBiometricsChangeLogTabMap(mapper.getContainerId(), mapper.getPersonBiometricsChangeLogName());
				dao.commit();
			}			
		} catch (Exception e) {
			dao.rollback();
			logger.error(e.getMessage(), e);			
		}		
		loadLog4jConfigFile();	
		
		stopWatch.stop();
		logger.info("MMr booting used time {}", stopWatch.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "MMr booting", null, null, stopWatch.elapsedTime());
		stopWatch = null;
	}

	/*
	 * shutdown mmr server and close tread pool
	 * 
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.
	 * ServletContextEvent)
	 */
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();	
		logger.info("Shutdown Mmr...");
		AIMrManger mm = AIMrManger.getInstance();
		mm.getUnitReceiveExecutor().shutdown();		
		try {
			EventNotifier.getInstance().fireOnStop();
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
		stopWatch.stop();
		logger.info("MMr is stoped. used time={}", stopWatch.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "MMr shutdown", null, null, stopWatch.elapsedTime());
		stopWatch = null;
	}
	
	private void loadLog4jConfigFile() {
		logger.info("loading log config file...");
		try {
			String tomcatBase = System.getProperty("catalina.base");
			if (!tomcatBase.endsWith("/")) {
				tomcatBase = tomcatBase + "/";
			}
			LOG_PROPERTY = tomcatBase + LOG_FILE_NAME;
			PropertyConfigurator.configure(LOG_PROPERTY);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			 BasicConfigurator.configure(); 
		}		
		logger.info("Success loaded log4j config file.");		
	}
}
