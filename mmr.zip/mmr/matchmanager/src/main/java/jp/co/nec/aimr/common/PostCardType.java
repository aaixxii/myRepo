package jp.co.nec.aimr.common;

public enum PostCardType {
	identify(0),//	
	sync(1);

	private int val;

	private PostCardType(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}
}
