package jp.co.nec.aimr.client;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aimr.common.Constants;
import jp.co.nec.aimr.common.ErrorDifinitions;

/**
 * @author xiazp <br/>
 * base servlet with common functions <br/>
 */
public class BaseServlet extends HttpServlet {	
	private static final long serialVersionUID = -2984095648339259882L;
	private static Logger log = LoggerFactory.getLogger(BaseServlet.class);
	protected static final String NOT_SUPPORT_METHOD = ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD.getDescription();
	protected static final String EMPTY_REQUEST_MSG =  ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getDescription();

	/**
	 * @param req
	 * @return
	 */
	protected boolean isContextSizeEmpty(ServletRequest req) {
		if (req == null || req.getContentLength() <= 0) {
			return true;
		}
		return false;
	}

	/**
	 * @param response
	 * @param statusCode
	 * @param array
	 * @param e
	 */
	protected void writeToResponse(HttpServletResponse response, int statusCode, byte[] array, Exception e) {
		if (array == null || array.length == 0) {
			log.error("Argument byte[] is null when writeToResponse..");
			return;
		}
		if (e != null) {
			log.error(e.getMessage(), e);
		}		
		response.setContentLength(array.length);
		response.setStatus(statusCode);
		response.setCharacterEncoding(Constants.ENCODING_UTF8);
		writeResultToResponse(array, response);
	}

	/**
	 * @param request
	 * @param response
	 * @param statusCode
	 * @param message
	 * @param t
	 */
	protected void writeErrorToResponse(HttpServletRequest request, HttpServletResponse response, int statusCode, String message, Exception t) {
		if (t == null) {
			log.error(message);
		} else {
			log.error(message, t);
		}

		String clientInfo = buildClientInfo(request, message);
		int contentLength = clientInfo.length();
		response.setContentLength(contentLength);
		response.setStatus(statusCode);
		response.setCharacterEncoding(Constants.ENCODING_UTF8);
		writeResultToResponse(clientInfo, response);
	}

	/**
	 * writeResultToResponse
	 * 
	 * @param output
	 * @param res
	 */
	protected void writeResultToResponse(byte[] output, HttpServletResponse res) {
		try (BufferedOutputStream bos = new BufferedOutputStream(res.getOutputStream())) {
			bos.write(output);
			bos.flush();
		} catch (IOException e) {
			String errorMessage = "error write to response " + e.getMessage();
			log.error(errorMessage, e);
		}
	}

	/**
	 * writeResultToResponse
	 * 
	 * @param output
	 * @param res
	 */
	protected void writeResultToResponse(String output, HttpServletResponse res) {
		try (PrintWriter pw = res.getWriter()) {
			pw.write(output);
			pw.flush();
		} catch (IOException e) {
			String errorMessage = "error write to response " + e.getMessage();
			log.error(errorMessage, e);
		}
	}

	/**
	 * buildClientInfo
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param errorMessage
	 *            error message
	 * @return ClientInfo
	 */
	private String buildClientInfo(HttpServletRequest request, String errorMessage) {
		StringBuilder clientInfo = new StringBuilder();
		if (errorMessage != null) {
			clientInfo.append(errorMessage);
		}
		clientInfo.append(" information:");
		clientInfo.append(" RemoteHost:");
		clientInfo.append(request.getRemoteHost());
		clientInfo.append(" RemoteAddress:");
		clientInfo.append(request.getRemoteAddr());
		clientInfo.append(" RemotePort:");
		clientInfo.append(request.getRemotePort());
		clientInfo.append(" RemoteUser:");
		clientInfo.append(request.getRemoteUser());
		return clientInfo.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doHead(javax.servlet.http.
	 * HttpServletRequest , javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doNoSuport(req, resp, "HEAD");
		return;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doPut(javax.servlet.http.
	 * HttpServletRequest , javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doNoSuport(req, resp, "PUT");
		return;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doDelete(javax.servlet.http.
	 * HttpServletRequest , javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		log.error(NOT_SUPPORT_METHOD);
		doNoSuport(req, resp, "DELETE");
		return;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doTrace(javax.servlet.http.
	 * HttpServletRequest , javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public void doTrace(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doNoSuport(req, resp, "TRACE");
		return;
	}

	/**
	 * @param req
	 * @param resp
	 * @param method
	 */
	public void doNoSuport(HttpServletRequest req, HttpServletResponse resp, String method) {
		final String notSupportMsg = String.format(NOT_SUPPORT_METHOD, method);
		resp.setStatus(HttpStatus.SC_METHOD_NOT_ALLOWED);
		writeErrorToResponse(req, resp, HttpStatus.SC_METHOD_NOT_ALLOWED, notSupportMsg, null);
	}
}
