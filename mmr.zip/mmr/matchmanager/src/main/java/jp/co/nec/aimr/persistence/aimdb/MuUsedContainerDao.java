package jp.co.nec.aimr.persistence.aimdb;

import java.util.List;

import org.springframework.dao.DataAccessException;

/**
 * 
 * @author xiazp
 * MuUsedContainerDao used to get Eligible Container Info for units
 *
 */
public interface MuUsedContainerDao {
	/**
	 * 
	 * @param muId
	 * @return
	 * @throws DataAccessException
	 */
	List<ContainerInfo> getMuEligibleContainerInfo(Long muId) throws DataAccessException;
}
