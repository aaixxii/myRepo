package jp.co.nec.aimr.persistence.aimdb;

import java.util.List;

import org.springframework.dao.DataAccessException;

/**
 * 
 * @author xiazp
 * GetTableNameDao get table name from databas
 */
public interface GetTableNameDao {
	/**
	 * 
	 * @return
	 * @throws DataAccessException
	 */
	public List<AimrTableNameMapper> getAimrTableNames() throws DataAccessException;
	
	public void commit();
	public void rollback();
}
