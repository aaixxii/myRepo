package jp.co.nec.aimr.exception;

import jp.co.nec.aimr.common.ErrorDifinitions;

public class NoActiveUnitException extends RuntimeException {
	private static final long serialVersionUID = 3571636000569813505L;
	
	public NoActiveUnitException() {
	}

	public NoActiveUnitException(String detail) {
		super(detail);
	}

	public NoActiveUnitException(Throwable ex) {
		super(ex);
	}

	public NoActiveUnitException(String detail, Throwable ex) {
		super(detail, ex);
	}

	public NoActiveUnitException(ErrorDifinitions errorDifinition) {
		super(errorDifinition.toString());
	}
}
