package jp.co.nec.aimr.common;

public enum UnitStatus {
	connected(0x10),//
	ready(0x20),//
	hold(0x30), //
	exit(0x40);

	private int val;

	private UnitStatus(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}
}
