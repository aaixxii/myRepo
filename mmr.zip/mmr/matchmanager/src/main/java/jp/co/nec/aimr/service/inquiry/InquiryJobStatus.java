package jp.co.nec.aimr.service.inquiry;

import jp.co.nec.aimr.common.JobState;

public class InquiryJobStatus {
	private long inqJobId;
	private long extjobId;
	private JobState exJobStates;
	private JobState inqJobStatus;
	private String errFlg;
	private String resion;
	private long queuedTime;

	public long getInqJobId() {
		return inqJobId;
	}

	public void setInqJobId(long inqJobId) {
		this.inqJobId = inqJobId;
	}

	public long getExtjobId() {
		return extjobId;
	}

	public void setExtjobId(long extjobId) {
		this.extjobId = extjobId;
	}

	public JobState getExJobStates() {
		return exJobStates;
	}

	public void setExJobStates(JobState exJobStates) {
		this.exJobStates = exJobStates;
	}

	public JobState getInqJobStatus() {
		return inqJobStatus;
	}

	public void setInqJobStatus(JobState inqJobStatus) {
		this.inqJobStatus = inqJobStatus;
	}

	public String getErrFlg() {
		return errFlg;
	}

	public void setErrFlg(String errFlg) {
		this.errFlg = errFlg;
	}

	public String getResion() {
		return resion;
	}

	public void setResion(String resion) {
		this.resion = resion;
	}

	public long getQueuedTime() {
		return queuedTime;
	}

	public void setQueuedTime(long queuedTime) {
		this.queuedTime = queuedTime;
	}
}
