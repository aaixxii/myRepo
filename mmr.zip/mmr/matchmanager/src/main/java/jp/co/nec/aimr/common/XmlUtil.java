package jp.co.nec.aimr.common;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * @author xiazp
 * XmlUtil setting datasource ref to web.xml
 */
public class XmlUtil {
 private static Logger logger = LoggerFactory.getLogger(XmlUtil.class);
 private static final String WEB_XML_PATH = "webapps/matchmanager/WEB-INF/";
 private static final String WEB_XML_NAME = "web.xml";

 /*
  * @param dbName
  * 
  * @return
  * 
  * @throws JDOMException,IOException
  */
 @SuppressWarnings("unchecked")
 public static void setResourceRef(String dbName) {
  logger.info("MMr will setting datasource ref to web.xml...");
  String tomcatBase = getTomcatBase();
  if (!tomcatBase.endsWith("/")) {
   tomcatBase = tomcatBase + "/";
  }
  String fullWebXmlName = tomcatBase + WEB_XML_PATH + WEB_XML_NAME;
  String description = null;
  String resRefName = null;

  switch (dbName.toUpperCase()) {
  case "ORACLE":
   description = "Oracle JNDI Datasource";
   resRefName = "jdbc/oracle";
   break;
  case "POSTGRESQL":
   description = "Postgres JNDI Datasource";
   resRefName = "jdbc/postgresql";
   break;
  case "MYSQL":
   description = "Mysql JNDI Datasource";
   resRefName = "jdbc/mysql";
   break;
  case "SQLSERVER":
   description = "";
   resRefName = "";
   break;
  default:
   break;
  }
  try {
   SAXReader reader = new SAXReader();
   Document document = reader.read(new File(fullWebXmlName));
   Element root = document.getRootElement();
   List<Element> resourceRefs = root.elements("resource-ref");
   Element resourceRef = resourceRefs.get(0);
   Element des = resourceRef.element("description");
   des.setText(description);
   Element refNameNode = resourceRef.element("res-ref-name");
   refNameNode.setText(resRefName);

   OutputFormat outputFormat = OutputFormat.createPrettyPrint();
   outputFormat.setEncoding("utf-8");
   XMLWriter xmlWriter = new XMLWriter(new FileOutputStream(fullWebXmlName), outputFormat);
   xmlWriter.write(document);
   xmlWriter.close();
   logger.info("Success write db driver name to web.xml");
  } catch (Exception e) {
   logger.error(e.getMessage(), e);
  }
 }

 private static String getTomcatBase() {
  return System.getProperty("catalina.base");
 }
}