package jp.co.nec.aimr.persistence.aimdb;


import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.QueryTimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DeadlockLoserDataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.PermissionDeniedDataAccessException;
import org.springframework.dao.TypeMismatchDataAccessException;
import org.springframework.dao.UncategorizedDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobCreator;
import org.springframework.jdbc.support.lob.LobHandler;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ContainerAssignedStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBContainerCatchUpInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateResponse;
import jp.co.nec.aim.message.proto.ManageService.PBTemplateRefInfo;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.common.ProtobufUtil;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.exception.AimRuntimeException;
import jp.co.nec.aimr.exception.DbProcessResultEmptyException;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDao;
import jp.co.nec.aimr.persistence.aimdb.SequenceDao;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;
import jp.co.nec.aimr.persistence.aimdb.TemplatesInfo;

public class AIMrTemplatesPostgresDaoImp implements AIMrTemplatesDao {	
	private JdbcTemplate jdbcTemplate;	
	private static Logger logger = LoggerFactory.getLogger(AIMrTemplatesPostgresDaoImp.class);

	public AIMrTemplatesPostgresDaoImp(JdbcTemplate jdbcTemplate) {		
		this.jdbcTemplate = jdbcTemplate;
	}	
	
	@Override
	public PBGetTemplateResponse getTemplates(final Integer containerId, String externalId, Integer eventId) {
		StopWatch t = new StopWatch();		
		t.start();		
		PBGetTemplateResponse pbResponse = null;				
		String personBioTableName = null;
		String strQuery = null;
		String selSql = null;
		List<TemplatesInfo> templateInfos = new ArrayList<>();		
		final LobHandler lobHandler = new DefaultLobHandler();
		try {
			personBioTableName = AIMrManger.getPersonBiometricsTabName(containerId);
			personBioTableName = "\"" + personBioTableName + "\"";
			if (eventId == null) {
				strQuery = "SELECT \"USER_KEY\",\"USER_EVENT_ID\",\"BIOMETRICS_DATA\" FROM %s WHERE \"USER_KEY\"=? ";
				selSql = String.format(strQuery, personBioTableName);
				templateInfos = jdbcTemplate.query(selSql, new Object[] { externalId },
						new RowMapper<TemplatesInfo>() {
							@Override
							public TemplatesInfo mapRow(ResultSet rs, int rowNum) throws SQLException {																
								 byte[] bytesData = lobHandler.getBlobAsBytes(rs,"BIOMETRICS_DATA");
								 TemplatesInfo info = new TemplatesInfo();
									info.setContainerId(containerId);
									info.setExternalId(rs.getString("USER_KEY"));									
									info.setEventId(rs.getInt("USER_EVENT_ID"));
									info.setTemplate( bytesData);
								return info;
							}});				
			} else {
				strQuery = "SELECT \"USER_KEY\",\"USER_EVENT_ID\",\"BIOMETRICS_DATA\" FROM %s WHERE \"USER_KEY\"=? AND \"USER_EVENT_ID\"=?";
				selSql = String.format(strQuery, personBioTableName);
				templateInfos = jdbcTemplate.query(selSql, new Object[] { externalId, eventId },
						new RowMapper<TemplatesInfo>() {
							@Override
							public TemplatesInfo mapRow(ResultSet rs, int rowNum) throws SQLException {																
								 byte[] bytesData = lobHandler.getBlobAsBytes(rs,"BIOMETRICS_DATA");
								 TemplatesInfo info = new TemplatesInfo();
									info.setContainerId(containerId);
									info.setExternalId(rs.getString("USER_KEY"));									
									info.setEventId(rs.getInt("USER_EVENT_ID"));
									info.setTemplate( bytesData);
								return info;
							}});				
			}
			if (templateInfos.isEmpty() || templateInfos.size() == 0) {
				PBServiceState pbServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY, containerId, externalId, eventId);
				PBGetTemplateResponse.Builder errorResponse = PBGetTemplateResponse.newBuilder();
				errorResponse.setServiceState(pbServiceState);
				pbResponse = errorResponse.build();
				return pbResponse;
			}
			pbResponse = buildPBGetTemplateResponse(templateInfos);			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);			
			PBServiceState pbServiceState = handlerException(e, containerId, externalId, eventId);
			PBGetTemplateResponse.Builder errorResponse = PBGetTemplateResponse.newBuilder();
			errorResponse.setServiceState(pbServiceState);
			pbResponse = errorResponse.build();
		}
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "getTemplates", null, null, t.elapsedTime());
		t = null;
		return pbResponse;
	}

	@Override
	public SyncResultWithStatus insertTemplate(Integer containerId, final String userKey, final Integer eventId, final byte[] data) {	
		StopWatch t = new StopWatch();		
		t.start();
		SequenceDao seqDao = new SequenceDaoImp(jdbcTemplate);		
		PBContainerSyncRequest pbSyncToMuData = null;
		PBServiceState pBServiceState = null;
		PBContainerCatchUpInfo catchUpInfo = null;
		SyncResultWithStatus syncResultWithStatus = new SyncResultWithStatus() ;
		long realVersion = -1;
		try {
			if (isOverMaxRecordCount(containerId)) {				
				String errMsg = "The record count is over max record count in containerId=" + String.valueOf(containerId.intValue());
				logger.error(errMsg);
				pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_CONTAINERS_OVER_MAX_RECORD_COUNT, containerId, userKey, eventId);
				syncResultWithStatus.setpBServiceState(pBServiceState);
				syncResultWithStatus.setpBContainerSyncRequest(null);
				return syncResultWithStatus;
			}
			final String currentTime =  ProtobufUtil.getCurrentTime();
			String personBioTableName = AIMrManger.getPersonBiometricsTabName(containerId);
			String personBioChangeLogTableName = AIMrManger.getPersonBiometricsChangeLogTabName(containerId);
			String newPersonBioTableName = "\"" + personBioTableName + "\"";
			String newPersonBioChangeLogTableName = "\"" + personBioChangeLogTableName + "\"";
			final long biometricsId = seqDao.getNextBiometricsId();

			String strQuery = "INSERT INTO $TABLENAME (\"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") VALUES (?, ?, ?, ?, ?, ?)";
			String insTemplateSql = strQuery.replace("$TABLENAME", newPersonBioTableName);
			LobHandler lobHandler = new DefaultLobHandler();
			jdbcTemplate.execute(insTemplateSql,				    
				     new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
						@Override
						protected void setValues(PreparedStatement ps, LobCreator lobCreator)
								throws SQLException, DataAccessException {
							ps.setLong(1, biometricsId);
							ps.setString(2, userKey);
							ps.setInt(3, eventId);
							lobCreator.setBlobAsBytes(ps, 4, data);							
							ps.setInt(5, data.length);
							ps.setString(6, currentTime);
						}
			});		
			
			long changeId = seqDao.getNextChangeLogId();
			realVersion  = seqDao.getNextChangeLogVersion(personBioChangeLogTableName);
			if (realVersion < 0) {
				String faildVerErr = "Faild get version form " + personBioChangeLogTableName + "mmr will skip process";
				throw new AimRuntimeException(faildVerErr);
			}
			String strLogQuery = "INSERT INTO $LOGTABLENAME (\"CHANGE_ID\", \"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"CHANGE_TYPE\", \"VERSION\") VALUES (?, ?, ?, ?, ?, ?)";
			String insLogSql = strLogQuery.replace("$LOGTABLENAME", newPersonBioChangeLogTableName);
			jdbcTemplate.update(insLogSql, new Object[] { changeId, biometricsId, userKey, eventId, 1, realVersion });			
			String updateContainersSql = ""
			+ "UPDATE \"CONTAINERS\" SET \"VERSION\" = ?, \"RECORD_COUNT\" = \"RECORD_COUNT\" + 1, "
			+ "\"LAST_ENROLLED_BIO_ID\" = ? "
		    + "WHERE \"CONTAINER_ID\" = ?";
			jdbcTemplate.update(updateContainersSql, new Object[] { Long.valueOf(realVersion), biometricsId , containerId });			
			catchUpInfo = buildCatchUpInfo(realVersion, SyncFunctionType.INSERT, data, userKey, eventId.intValue());
			List<PBContainerCatchUpInfo> catchUpInfoList = new ArrayList<>();
			catchUpInfoList.add(catchUpInfo);
			pbSyncToMuData = buildSyncToMuRequest(containerId, catchUpInfoList);
			jdbcTemplate.execute("COMMIT");			
		} catch (Exception e) {
			jdbcTemplate.execute("ROLLBACK");			
			logger.error(e.getMessage(), e);
			pBServiceState = handlerException(e,  containerId, userKey, eventId);
		}
		syncResultWithStatus.setpBContainerSyncRequest(pbSyncToMuData);
		syncResultWithStatus.setpBServiceState(pBServiceState);
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "insertTemplate", null, null, t.elapsedTime());
		t = null;
		return syncResultWithStatus;
	}

	@Override
	public SyncResultWithStatus updateTemplate(final Integer containerId, final String userKey, final Integer eventId, final byte[] data) {	
		StopWatch t = new StopWatch();		
		t.start();		
		PBContainerSyncRequest pbSyncToMuData = null;
		PBServiceState pBServiceState = null;
		SyncResultWithStatus syncResultWithStatus = new SyncResultWithStatus() ;
		SequenceDao seqDao = new SequenceDaoImp(jdbcTemplate);		
		try {			
			String personBioTableName = AIMrManger.getPersonBiometricsTabName(containerId);
			String personBioChangeLogTableName = AIMrManger.getPersonBiometricsChangeLogTabName(containerId);	
			String newPersonBioTableName = "\"" + personBioTableName + "\"";
			String newPersonBioChangeLogTableName = "\"" + personBioChangeLogTableName + "\"";
			final List<Map<String, Object>> updatedIetmIds = updateTemplatesAndGetUpdatedItemIds(jdbcTemplate, newPersonBioTableName, userKey, eventId, data);			

			final long changeId = seqDao.getNextChangeLogId();
			final long realVersion = seqDao.getNextChangeLogVersion(personBioChangeLogTableName);
			if (realVersion < 0) {
				String faildVerErr = "Faild get version form " + personBioChangeLogTableName + "mmr will skip process";
				throw new AimRuntimeException(faildVerErr);
			}
			final long containerVersion = realVersion + updatedIetmIds.size() - 1;
			String strLogQuery = "INSERT INTO $LOGTABLENAME (\"CHANGE_ID\",\"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"CHANGE_TYPE\", \"VERSION\") VALUES (?, ?, ?, ?, ?, ?)";
			String insLogSql = strLogQuery.replace("$LOGTABLENAME", newPersonBioChangeLogTableName);
			jdbcTemplate.batchUpdate(insLogSql, new BatchPreparedStatementSetter() {
				@Override
				public int getBatchSize() {
					return updatedIetmIds.size();
				}
				@Override
				public void setValues(PreparedStatement pstm, int i) throws SQLException {
					pstm.setLong(1, changeId + i);
					BigDecimal tbd = (BigDecimal) updatedIetmIds.get(i).get("BIOMETRICS_ID");
					pstm.setLong(2, tbd.longValue());
					BigDecimal tbe = (BigDecimal) updatedIetmIds.get(i).get("USER_EVENT_ID");
					pstm.setInt(4, tbe.intValue());
					pstm.setString(3, userKey);
					pstm.setInt(5, 3);
					pstm.setLong(6, realVersion + i);
				}
			});

			String updateContainersSql = "" 
			        + "UPDATE \"CONTAINERS\" SET \"VERSION\" = ? WHERE \"CONTAINER_ID\" = ?";					
			jdbcTemplate.update(updateContainersSql, new Object[] {Long.valueOf(containerVersion), containerId });
			if (updatedIetmIds.size() > 1) {
				seqDao.updateChangeLogId(updatedIetmIds.size() - 1);
			}
			List<PBContainerCatchUpInfo> catchUpInfoList = new ArrayList<>();
			for (int i = 0; i < updatedIetmIds.size(); i++) {
				PBContainerCatchUpInfo catchUpInfo = null;				
				catchUpInfo = buildCatchUpInfo(realVersion + i, SyncFunctionType.UPDATE, data, userKey,
						((BigDecimal) updatedIetmIds.get(i).get("user_event_id")).intValue());
				catchUpInfoList.add(catchUpInfo);
			}

			pbSyncToMuData = buildSyncToMuRequest(containerId, catchUpInfoList);
			jdbcTemplate.execute("COMMIT");	

		} catch (Exception e) {
			jdbcTemplate.execute("ROLLBACK");			
			logger.error(e.getMessage(), e);
			if ( e instanceof DbProcessResultEmptyException) {
				pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_UPDATE_COUNT_ZERO, containerId, userKey, eventId);
			} else {
				pBServiceState = handlerException(e,  containerId, userKey, eventId);
			}
		}
		syncResultWithStatus.setpBContainerSyncRequest(pbSyncToMuData);
		syncResultWithStatus.setpBServiceState(pBServiceState);
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "updateTemplate", null, null, t.elapsedTime());
		t = null;
		return syncResultWithStatus;
	}

	@Override
	public SyncResultWithStatus deleteTemplate(final Integer containerId, final String userKey, final Integer eventId) {
		StopWatch t = new StopWatch();		
		t.start();
		logger.info("Get to delet template....");		
		PBContainerSyncRequest pbSyncToMuData = null;
		PBServiceState pBServiceState = null;
		SyncResultWithStatus syncResultWithStatus = new SyncResultWithStatus() ;
		SequenceDao seqDao = new SequenceDaoImp(jdbcTemplate);			
		try {
			String personBioTableName = AIMrManger.getPersonBiometricsTabName(containerId);
			String personBioChangeLogTableName = AIMrManger.getPersonBiometricsChangeLogTabName(containerId);
			String newPersonBioTableName = "\"" + personBioTableName + "\"";
			String newPersonBioChangeLogTableName = "\"" + personBioChangeLogTableName + "\"";
			final List<Map<String, Object>> deletedIetemId = deleteTemplateAndGetDeletedItemIds(newPersonBioTableName, userKey, eventId, jdbcTemplate);
			logger.info("deletedIetemId", deletedIetemId.size());
			final long changeId = seqDao.getNextChangeLogId();			
			final long realVersion = seqDao.getNextChangeLogVersion(personBioChangeLogTableName);	
			if (realVersion < 0) {
				String faildVerErr = "Faild get version form " + personBioChangeLogTableName + "mmr will skip process";
				throw new AimRuntimeException(faildVerErr);
			}			
			String strLogQuery = "INSERT INTO $LOGTABLENAME (\"CHANGE_ID\", \"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"CHANGE_TYPE\", \"VERSION\") VALUES (?, ?, ?, ?, ?, ?)";
			String insLogSql = strLogQuery.replace("$LOGTABLENAME", newPersonBioChangeLogTableName);
			jdbcTemplate.batchUpdate(insLogSql, new BatchPreparedStatementSetter() {
				@Override
				public int getBatchSize() {
					return deletedIetemId.size();
				}
				@Override
				public void setValues(PreparedStatement pstm, int i) throws SQLException {
					pstm.setLong(1, changeId + i);					
					BigDecimal tbd = (BigDecimal) deletedIetemId.get(i).get("BIOMETRICS_ID");
					pstm.setLong(2, tbd.longValue());
					pstm.setString(3, userKey);
					BigDecimal tbe = (BigDecimal) deletedIetemId.get(i).get("USER_EVENT_ID");					
					pstm.setInt(4, tbe.intValue());		
					pstm.setInt(5, 2);
					pstm.setLong(6, realVersion + i);
				}
			});

			String updateContainersSql = "" 
			+ "UPDATE \"CONTAINERS\" SET \"VERSION\" = \"VERSION\" + ?, \"RECORD_COUNT\" = \"RECORD_COUNT\" - ? " + "WHERE \"CONTAINER_ID\" = ?";
			jdbcTemplate.update(updateContainersSql, new Object[] { Integer.valueOf(deletedIetemId.size()),  Integer.valueOf(deletedIetemId.size()), containerId });
			
			if (deletedIetemId.size() > 1) {
				seqDao.updateChangeLogId(deletedIetemId.size() - 1);
			}
			List<PBContainerCatchUpInfo> catchUpInfoList = new ArrayList<>();
			for (int i = 0; i < deletedIetemId.size(); i++) {
				PBContainerCatchUpInfo catchUpInfo = null;				
				catchUpInfo = buildCatchUpInfo(realVersion + i, SyncFunctionType.DELETE, null, userKey, ((BigDecimal)deletedIetemId.get(i).get("user_event_id")).intValue());		
				catchUpInfoList.add(catchUpInfo);
			}			
			logger.info("PBContainerCatchUpInfo size", catchUpInfoList);
			pbSyncToMuData = buildSyncToMuRequest(containerId, catchUpInfoList);
			jdbcTemplate.execute("COMMIT");	

		} catch (Exception e) {
			jdbcTemplate.execute("ROLLBACK");			
			logger.warn(e.getMessage(), e);
			if ( e instanceof DbProcessResultEmptyException) {
				pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_DELETE_COUNT_ZERO, containerId,  userKey, eventId);
			} else {
				pBServiceState = handlerException(e,  containerId,  userKey, eventId);
			}			
		}
		syncResultWithStatus.setpBContainerSyncRequest(pbSyncToMuData);
		syncResultWithStatus.setpBServiceState(pBServiceState);
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "deleteTemplate", null, null, t.elapsedTime());
		t = null;
		return syncResultWithStatus;
	}

	@Override
	public void commit() {		
		jdbcTemplate.execute("COMMIT");		
	}

	@Override
	public void rollback() {		
		jdbcTemplate.execute("ROLLBACK");		
	}

	private PBContainerSyncRequest buildSyncToMuRequest(int containerId, List<PBContainerCatchUpInfo> pbCatchUpInfos) {
		PBContainerSyncRequest.Builder pbSyncToMuData = PBContainerSyncRequest.newBuilder();
		pbSyncToMuData.setContainerId(containerId);
		pbSyncToMuData.addAllContainerSyncInfo(pbCatchUpInfos);
		pbSyncToMuData.setAssignedState(ContainerAssignedStateType.CONTAINER_ASSIGNED);
		return pbSyncToMuData.build();
	}

	private PBContainerCatchUpInfo buildCatchUpInfo(long version, SyncFunctionType command, byte[] templates, String externalId, int eventId) {
		PBContainerCatchUpInfo.Builder catchUpInfo = PBContainerCatchUpInfo.newBuilder();
		catchUpInfo.setCommand(command);
		catchUpInfo.setEventId(eventId);
		catchUpInfo.setExternalId(externalId);
		if (templates != null) {
			catchUpInfo.setTemplate(ByteString.copyFrom(templates));
		}
		catchUpInfo.setVersion(version);
		return catchUpInfo.build();
	}

	public boolean isOverMaxRecordCount(Integer containerId) {
		Boolean isOver = null;
		String sql = "SELECT \"RECORD_COUNT\"+1 - \"MAX_RECORD_COUNT\" FROM \"CONTAINERS\" WHERE \"CONTAINER_ID\"=?";
		Integer result = jdbcTemplate.queryForObject(sql, new Object[] { containerId }, Integer.class);
		if (result.intValue() > 0) {
			isOver = Boolean.valueOf(true);
		} else {
			isOver = Boolean.valueOf(false);
		}
		return isOver.booleanValue();
	}

	private List<Map<String, Object>> deleteTemplateAndGetDeletedItemIds(String tableName, String userKey, Integer eventId, JdbcTemplate jdbcTemplate) {
		String selectQuery = null;
		String selSql = null;
		String deleQuery = null;
		String deleSql = null;
		int deletedCount = -1;		
		List<Map<String, Object>> mapList = null;		
		if (eventId == null) {
			selectQuery = "SELECT \"USER_EVENT_ID\", \"BIOMETRICS_ID\" FROM %s WHERE \"USER_KEY\" = ?";
			selSql = String.format(selectQuery, tableName);	
			//selSql = selectQuery.replace("$TABLENAME", tableName);			
			mapList = jdbcTemplate.queryForList(selSql, new Object[] { userKey });
			deleQuery = "DELETE FROM $TABLENAME WHERE \"USER_KEY\" = ?";
			deleSql = deleQuery.replace("$TABLENAME", tableName);
			deletedCount = jdbcTemplate.update(deleSql, new Object[] { userKey });
		} else {
			selectQuery = "SELECT \"USER_EVENT_ID\", \"BIOMETRICS_ID\" FROM %s WHERE \"USER_KEY\" = ? AND \"USER_EVENT_ID\" = ?";
			selSql = String.format(selectQuery, tableName);						
			mapList = jdbcTemplate.queryForList(selSql, new Object[] { userKey, eventId });
			deleQuery = "DELETE FROM $TABLENAME WHERE \"USER_KEY\" = ? AND \"USER_EVENT_ID\" = ?";
			deleSql = deleQuery.replace("$TABLENAME", tableName);
			deletedCount = jdbcTemplate.update(deleSql, new Object[] { userKey, eventId });
			jdbcTemplate.execute("commit");
		}
		if (deletedCount <= 0) {
			throw new DbProcessResultEmptyException(ErrorDifinitions.DB_DELETE_COUNT_ZERO);
		}
		return mapList;
	}
	
	private List<Map<String, Object>> updateTemplatesAndGetUpdatedItemIds(JdbcTemplate jdbcTemplate, String personBioTableName, final String userKey, final Integer eventId, final byte[]data) {
		String selectBiometricsSql = null;
		String strBioQuery = null;
		String strUpQuery = null;
		String updateTemplateSql = null;
		int updatedCount = 0;
		 List<Map<String, Object>> updatedIetmIdList = null;		
		if (eventId == null) {
			strBioQuery = "SELECT \"USER_EVENT_ID\", \"BIOMETRICS_ID\" FROM %s WHERE \"USER_KEY\" = ?";
			selectBiometricsSql = String.format(strBioQuery, personBioTableName);
			updatedIetmIdList = jdbcTemplate.queryForList(selectBiometricsSql, new Object[] {userKey });
			
			strUpQuery = "UPDATE %s SET \"BIOMETRICS_DATA\" = ? , \"BIOMETRICS_DATA_LEN\" = ? , \"REGISTERED_TS\" = ? WHERE \"USER_KEY\" = ?";
			updateTemplateSql = String.format(strUpQuery, personBioTableName);
			LobHandler lobHandler = new DefaultLobHandler();
			updatedCount = jdbcTemplate.execute(updateTemplateSql,				    
				     new AbstractLobCreatingPreparedStatementCallback(lobHandler) {
						@Override
						protected void setValues(PreparedStatement ps, LobCreator lobCreator)
								throws SQLException, DataAccessException {
							lobCreator.setBlobAsBytes(ps, 1, data);
							ps.setInt(2, data.length);
							ps.setString(3, ProtobufUtil.getCurrentTime());
							ps.setString(4, userKey);
						}
				
			}).intValue();
		
			//updatedCount = jdbcTemplate.update(updateTemplateSql, new Object[] { data, data.length,  ProtobufUtil.getCurrentTime(), userKey });			
		} else {	
			strBioQuery = "SELECT \"USER_EVENT_ID\", \"BIOMETRICS_ID\" FROM %s WHERE \"USER_KEY\" = ?  AND \"USER_EVENT_ID\" = ?";
			selectBiometricsSql = String.format(strBioQuery, personBioTableName);
			updatedIetmIdList = jdbcTemplate.queryForList(selectBiometricsSql, new Object[] { userKey, eventId });
			
			strUpQuery = "UPDATE %s SET \"BIOMETRICS_DATA\" = ? , \"BIOMETRICS_DATA_LEN\" = ? , \"REGISTERED_TS\" = ? WHERE \"USER_KEY\" = ? AND \"USER_EVENT_ID\" = ?";
			updateTemplateSql = String.format(strUpQuery, personBioTableName);
			LobHandler lobHandler1 = new DefaultLobHandler();
			updatedCount = jdbcTemplate.execute(updateTemplateSql,				    
				     new AbstractLobCreatingPreparedStatementCallback(lobHandler1) {
						@Override
						protected void setValues(PreparedStatement ps, LobCreator lobCreator)
								throws SQLException, DataAccessException {
							lobCreator.setBlobAsBytes(ps, 1, data);
							ps.setInt(2, data.length);
							ps.setString(3, ProtobufUtil.getCurrentTime());
							ps.setString(4, userKey);
							ps.setInt(5, eventId);
						}
				
			}).intValue();			
			//updatedCount = jdbcTemplate.update(updateTemplateSql, new Object[] { data, data.length,  ProtobufUtil.getCurrentTime(), userKey, eventId });
		}
		if (updatedCount <= 0) {
			throw new DbProcessResultEmptyException(ErrorDifinitions.DB_UPDATE_COUNT_ZERO);
		}		
		return updatedIetmIdList;
	}

	private PBGetTemplateResponse buildPBGetTemplateResponse(List<TemplatesInfo> templateInfos) {
		PBGetTemplateResponse.Builder pbGtResponse = PBGetTemplateResponse.newBuilder();
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		pbGtResponse.setServiceState(pBServiceState);
		for (TemplatesInfo info : templateInfos) {
			PBTemplateRefInfo.Builder pbTmInfo = PBTemplateRefInfo.newBuilder();
			pbTmInfo.setContainerId(info.getContainerId());
			pbTmInfo.setEventId(info.getEventId());
			pbTmInfo.setExternalId(info.getExternalId());
			pbTmInfo.setTemplate(ByteString.copyFrom(info.getTemplate()));
			pbGtResponse.addTemplateRefInfo(pbTmInfo);
		}
		return pbGtResponse.build();
	}
	
	private PBServiceState handlerException(Exception e, Integer conainerId, String userKey, Integer eventId) {
		PBServiceState pBServiceState = null;		
	
		if (e instanceof DbProcessResultEmptyException) {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_EMPTY_RESULT, conainerId, userKey, eventId);
		} else if (e instanceof DuplicateKeyException) {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_DUPLICATE_KEY, conainerId, userKey, eventId);
		} else if (e instanceof EmptyResultDataAccessException) {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_EMPTY_RESULT, conainerId, userKey, eventId);
		} else if (e instanceof DeadlockLoserDataAccessException) {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_DEAD_LOCK, conainerId, userKey, eventId);
		} else if (e instanceof PermissionDeniedDataAccessException) {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_PERMISSION_DENIED, conainerId, userKey, eventId);
		} else if (e instanceof QueryTimeoutException) {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_QUERY_TIMOUT, conainerId, userKey, eventId);
		} else if (e instanceof TypeMismatchDataAccessException) {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_TYPE_MISMATCH, conainerId, userKey, eventId);
		} else if (e instanceof UncategorizedDataAccessException) {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_UNCATEGORIZE_DATA, conainerId, userKey, eventId);
		} else {
			pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.DB_PROCESS_ERROR, conainerId, userKey, eventId);
		}
		return pBServiceState;		
	}

}
