package jp.co.nec.aimr.event;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aimr.common.UnitCard;
import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.common.UnitType;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.matchunit.UnitMessageSender;
import jp.co.nec.aimr.persistence.aimdb.ContainerInfo;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

public class TestCaculateNextMu {
	
	private MockUp<PropertyUtil> propertyUtilMock;
	private MockUp<AIMrManger> aIMrMangerMock;

	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {		
		propertyUtilMock = 
		new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}
			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}			
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};
		
		aIMrMangerMock =
				new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}			
		};
		
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectEu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		
		Field field1 = cls.getDeclaredField("lastSelectMu");
		field1.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		
		Field field2 = cls.getDeclaredField("euSenderListenerList");
		field2.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listEu = ((CopyOnWriteArrayList<EventListener>) field2.get(EventNotifier.getInstance()));
		listEu.clear();
		
		Field field3 = cls.getDeclaredField("muSenderListenerList");
		field3.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listMu = ((CopyOnWriteArrayList<EventListener>) field3.get(EventNotifier.getInstance()));
		listMu.clear();
		
		Field field4 = cls.getDeclaredField("systemListenerQueue");
		field4.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listSys = ((CopyOnWriteArrayList<EventListener>) field4.get(EventNotifier.getInstance()));
		listSys.clear();		
	}

	@After
	public void tearDown() throws Exception {
		propertyUtilMock.tearDown();
		aIMrMangerMock.tearDown();
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextMu() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		setMuMuEligibleMap();
		int size = 3;
		for (int i = 0 ; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.MATCHER);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addMuSenderListener(sender);
		}
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectMu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		for (int i = 0 ; i < 2; i++) {
			EventNotifier.getInstance().caculateNextMu(1);
			int result = ((AtomicInteger)field.get(EventNotifier.getInstance())).intValue();
			if (i == 0) {
				Assert.assertEquals(0, result);
			} else {
				Assert.assertEquals(2, result);
			}			
		}		
		Field field1 = cls.getDeclaredField("muSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance());
		copyOnWriteArrayList.clear();		
		
	}
	
	private void setMuMuEligibleMap() {
		AIMrManger.getMuEligiblecontaineinfoMap().clear();
		List<ContainerInfo> infos = new ArrayList<>();
		ContainerInfo info1 = new ContainerInfo();
		info1.setContainerId(1);
		info1.setPersonBiTtableName("PERSON_BIOMETRICS_1");
		info1.setConatainerLogTableName("PERSON_BIO_CHANGE_LOG_1");				
		infos.add(info1);
		
		ContainerInfo info2 = new ContainerInfo();
		info2.setContainerId(1);
		info2.setPersonBiTtableName("PERSON_BIOMETRICS_1");
		info2.setConatainerLogTableName("PERSON_BIO_CHANGE_LOG_1");		
		infos.add(info2);
		AIMrManger.getMuEligiblecontaineinfoMap().put(1L,infos);		
		AIMrManger.getMuEligiblecontaineinfoMap().put(3L,infos);
		
		List<ContainerInfo> infoas = new ArrayList<>();
		ContainerInfo infoa = new ContainerInfo();
		infoa.setContainerId(2);
		infoa.setPersonBiTtableName("PERSON_BIOMETRICS_1");
		infoa.setConatainerLogTableName("PERSON_BIO_CHANGE_LOG_1");				
		infoas.add(infoa);
		AIMrManger.getMuEligiblecontaineinfoMap().put(2L,infoas);
	}

}
