package jp.co.nec.aimr.agent;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aimr.common.SocketMessageUtil;

public class EuClinet {
	private final int SERVERPORT = 8765;
	private SocketChannel client = null;

	public EuClinet() {
		InetSocketAddress hostAddress = new InetSocketAddress("10.197.23.100", SERVERPORT);
		try {
			System.out.println("Go to connected to server!");
			client = SocketChannel.open(hostAddress);
			client.socket().setSoTimeout(500000);
			System.out.println("Success to connected to server!");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public void run() {		
		sendConnect();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {			
			e1.printStackTrace();
		}	
		
		 sendReady();
		 
			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {			
				e1.printStackTrace();
			}
			
			sendHold();			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {			
				e1.printStackTrace();
			}
		
//		for (int i = 0 ; i < 50; i++) {
//			 sendReady();
//			 
//				try {
//					Thread.sleep(500);
//				} catch (InterruptedException e1) {			
//					e1.printStackTrace();
//				}
//				
//				sendHold();			
//				try {
//					Thread.sleep(500);
//				} catch (InterruptedException e1) {			
//					e1.printStackTrace();
//				}		
//				
//				sendMuJobResult(i + 1);
//				try {
//					Thread.sleep(500);
//				} catch (InterruptedException e1) {			
//					e1.printStackTrace();
//				}			
//			
//		}			
		 
		  sendExit();
		 
		 try {
			Thread.sleep(24 * 5000000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	private void sendConnect() {		
		System.out.println("Send  msg to server....");
		
		String postCard = new String(SocketMessageUtil.createPostCardMessage("sync"));
		PBComponentInfo pbInfo = buildEnterRequest();
		byte[] enterRequest = pbInfo.toByteArray();
		int size = enterRequest.length;
		ByteBuffer buffer = ByteBuffer.allocate(48 + enterRequest.length);
		 buffer.order(ByteOrder.BIG_ENDIAN);
		 buffer.putLong(16L); //For enter		
		 buffer.putInt(size);
		 buffer.putInt(size);
		 buffer.putLong(1L);
		 buffer.putLong(0L);
		 buffer.put(new String(postCard).getBytes());
		 buffer.put(enterRequest);
		 buffer.flip();
		buffer.remaining();

		try {
			while (buffer.hasRemaining()) {
				client.write(buffer);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}				
		System.out.println("Sended messageId:" + 16);
		buffer.clear();

	}

	private void sendReady() {		
		String postCard = new String(SocketMessageUtil.createPostCardMessage("sync"));
		ByteBuffer head = ByteBuffer.allocate(48);
		head.order(ByteOrder.BIG_ENDIAN);		
		head.putLong(32L); // For ready
		head.putInt(0);
		head.putInt(0);
		head.putLong(1L);
		head.putLong(0L);
		head.put(new String(postCard).getBytes());
		head.flip();
		head.remaining();
		try {
			while (head.hasRemaining()) {
				client.write(head);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		head.clear();		
		
		head.clear();		
	}
	
	private void sendExit() {		
		String postCard = new String(SocketMessageUtil.createPostCardMessage("sync"));
		ByteBuffer head = ByteBuffer.allocate(48);
		head.order(ByteOrder.BIG_ENDIAN);		
		head.putLong(128L); // For exit
		head.putInt(0);
		head.putInt(0);
		head.putLong(1L);
		head.putLong(0L);
		head.put(new String(postCard).getBytes());
		head.flip();
		head.remaining();
		try {
			while (head.hasRemaining()) {
				client.write(head);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		head.clear();					
	}
	
	private void sendHold() {		
		String postCard = new String(SocketMessageUtil.createPostCardMessage("sync"));
		ByteBuffer head = ByteBuffer.allocate(48);
		head.order(ByteOrder.BIG_ENDIAN);		
		head.putLong(64L); // For exit
		head.putInt(0);
		head.putInt(0);
		head.putLong(1L);
		head.putLong(0L);
		head.put(new String(postCard).getBytes());
		head.flip();
		head.remaining();
		try {
			while (head.hasRemaining()) {
				client.write(head);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		head.clear();					
	}
	
	private PBComponentInfo buildEnterRequest() {
		PBComponentInfo.Builder pBComponentInfo = PBComponentInfo.newBuilder();
		pBComponentInfo.setComponent(ComponentType.EXTRACT_UNIT);
		pBComponentInfo.setVersion(String.valueOf(123));
		int port = client.socket().getLocalPort();
		pBComponentInfo.setUniqueId("127.0.0.1:" + String.valueOf(port));
		return pBComponentInfo.build();		
	}
	
	public void sendMuJobResult(long jobId) {
		System.out.println("Send  msg to mu ....");
		Long head = 513L;
		PBIdentifyResponse muJobResult = CreateInquiryJobResult();
		byte[] jobRequst = muJobResult.toByteArray();		
		int size = jobRequst.length;
		ByteBuffer headBuff = ByteBuffer.allocate(32 + jobRequst.length);
		headBuff.putLong(head);
		headBuff.putInt(size);
		headBuff.putInt(size);
		headBuff.putLong(1L);
		headBuff.putLong(jobId);
		headBuff.put(jobRequst);
		headBuff.flip();
		try {
			while (headBuff.hasRemaining()) {
				client.write(headBuff);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		headBuff.clear();

	}

	private PBIdentifyResponse CreateInquiryJobResult() {
		PBIdentifyResponse.Builder jobResult = PBIdentifyResponse.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		jobResult.setServiceState(status);
		return jobResult.build();
	}

}
