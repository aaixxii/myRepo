package jp.co.nec.aimr.common;

import java.lang.reflect.Field;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class StopWatchTest {
	private StopWatch watcher;

	@Before
	public void setUp() throws Exception {
		watcher = new StopWatch();
	}

	@After
	public void tearDown() throws Exception {
		watcher = null;
	}

	@Test
	public void testStopWatch()  {
		Assert.assertNotNull(watcher);
		Assert.assertTrue(watcher instanceof StopWatch);		
	}

	@Test
	public void testStart() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		Class<StopWatch> cls = StopWatch.class;
		Field fieldStart = cls.getDeclaredField("startTime");
		Field fieldEnd = cls.getDeclaredField("stopTime");
		fieldStart.setAccessible(true);
		fieldEnd.setAccessible(true);
		long cTime = System.currentTimeMillis();
		watcher.start();
		long result = fieldStart.getLong(watcher);
		Assert.assertEquals(cTime, result);		
	}

	@Test
	public void testStop() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		Class<StopWatch> cls = StopWatch.class;
		Field fieldStart = cls.getDeclaredField("startTime");
		Field fieldEnd = cls.getDeclaredField("stopTime");
		fieldStart.setAccessible(true);
		fieldEnd.setAccessible(true);
		long cTime = System.currentTimeMillis();
		watcher.stop();
		long result = fieldEnd.getLong(watcher);
		Assert.assertEquals(cTime, result);	
		
	}

	@SuppressWarnings("static-access")
	@Test
	public void testElapsedTime() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, InterruptedException {
		Class<StopWatch> cls = StopWatch.class;
		Field fieldStart = cls.getDeclaredField("startTime");
		Field fieldEnd = cls.getDeclaredField("stopTime");
		fieldStart.setAccessible(true);
		fieldEnd.setAccessible(true);			
		watcher.start();
		Thread.currentThread().sleep(1000);
		watcher.stop();
		long result = watcher.elapsedTime();
		long start = fieldStart.getLong(watcher);
		long end = fieldEnd.getLong(watcher);
		Assert.assertEquals(end - start, result);				
	}

	@Test
	public void testReset() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		Class<StopWatch> cls = StopWatch.class;
		Field fieldStart = cls.getDeclaredField("startTime");
		Field fieldEnd = cls.getDeclaredField("stopTime");
		fieldStart.setAccessible(true);
		fieldEnd.setAccessible(true);			
		watcher.reset();		
		long start = fieldStart.getLong(watcher);
		long end = fieldEnd.getLong(watcher);
		Assert.assertEquals(0l, start);
		Assert.assertEquals(0l, end);		
	}

}
