package jp.co.nec.aimr.agent;

public class MuSender {

	public static void main(String[] args) {
		MuClinet client = new MuClinet();
		client.run();

	}

}
