package jp.co.nec.aimr.common;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * @author xiazp
 * XmlUtil setting datasource ref to web.xml
 */
public class XmlUtilMocker {
	private static Logger logger = LoggerFactory.getLogger(XmlUtil.class);

	/*
	 * @param dbName
	 * 
	 * @return
	 * 
	 * @throws JDOMException,IOException
	 */
	@SuppressWarnings("unchecked")
	public static void setResourceRef(String dbName) {
		logger.info("MMr will setting datasource ref to web.xml...");
		URL url = Thread.currentThread().getContextClassLoader().getResource("web.xml");
		String testWebXmlPath = url.getPath();
		String description = null;
		String resRefName = null;

		switch (dbName.toUpperCase()) {
		case "ORACLE":
			description = "Oracle JNDI Datasource";
			resRefName = "jdbc/oracle";
			break;
		case "POSTGRESQL":
			description = "Postgres JNDI Datasource";
			resRefName = "jdbc/postgres";
			break;
		case "MYSQL":
			description = "Mysql JNDI Datasource";
			resRefName = "jdbc/mysql";
			break;
		case "SQLSERVER":
			description = "";
			resRefName = "";
			break;
		default:
			break;
		}

		try {
			SAXReader reader = new SAXReader();
			Document document = reader.read(new File(testWebXmlPath));
			Element root = document.getRootElement();
			List<Element> resourceRefs = root.elements("resource-ref");
			Element resourceRef = resourceRefs.get(0);
			Element des = resourceRef.element("description");
			des.setText(description);
			System.out.println(des.getText());

			Element refNameNode = resourceRef.element("res-ref-name");
			refNameNode.setText(resRefName);
			System.out.println(refNameNode.getText());

			OutputFormat outputFormat = OutputFormat.createPrettyPrint();
			outputFormat.setEncoding("utf-8");

			XMLWriter xmlWriter = new XMLWriter(new FileOutputStream(testWebXmlPath), outputFormat);
			xmlWriter.write(document);
			xmlWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String args[]) {
		testMySql();
		testOracle();
		testPostgres();
		System.out.println("Test OK!!");
		

	}
	
	@SuppressWarnings("unchecked")
	private static void testMySql() {
		XmlUtilMocker.setResourceRef("mySql");
		URL url = Thread.currentThread().getContextClassLoader().getResource("web.xml");
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(url.getPath());
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element root = document.getRootElement();
		List<Element> resourceRefs = root.elements("resource-ref");
		Element resourceRef = resourceRefs.get(0);
		Element des = resourceRef.element("description");
		Assert.assertEquals("Mysql JNDI Datasource", des.getText());
		Element refNameNode = resourceRef.element("res-ref-name");
		Assert.assertEquals("jdbc/mysql", refNameNode.getText());
		
	}
	
	@SuppressWarnings("unchecked")
	private static void testOracle() {
		XmlUtilMocker.setResourceRef("oracle");
		URL url = Thread.currentThread().getContextClassLoader().getResource("web.xml");
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(url.getPath());
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element root = document.getRootElement();
		List<Element> resourceRefs = root.elements("resource-ref");
		Element resourceRef = resourceRefs.get(0);
		Element des = resourceRef.element("description");
		Assert.assertEquals("Oracle JNDI Datasource", des.getText());
		Element refNameNode = resourceRef.element("res-ref-name");
		Assert.assertEquals("jdbc/oracle", refNameNode.getText());
		
	}
	
	@SuppressWarnings("unchecked")
	private static void testPostgres() {
		XmlUtilMocker.setResourceRef("postgresql");
		URL url = Thread.currentThread().getContextClassLoader().getResource("web.xml");
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(url.getPath());
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element root = document.getRootElement();
		List<Element> resourceRefs = root.elements("resource-ref");
		Element resourceRef = resourceRefs.get(0);
		Element des = resourceRef.element("description");
		Assert.assertEquals("Postgres JNDI Datasource", des.getText());
		Element refNameNode = resourceRef.element("res-ref-name");
		Assert.assertEquals("jdbc/postgres", refNameNode.getText());
		
	}
}