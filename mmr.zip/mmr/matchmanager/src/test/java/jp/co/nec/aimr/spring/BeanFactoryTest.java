package jp.co.nec.aimr.spring;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BeanFactoryTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetInstance() {
		Assert.assertNotNull(BeanFactory.getInstance());		
	}

	@Test
	public void testGetBean() {
		Assert.assertNotNull(BeanFactory.getInstance().getBean("dataSource"));		
	}
	
	@Test
	public void testGetBean1() {
		Assert.assertNotNull(BeanFactory.getInstance().getBean("inquiryServlet"));		
	}
}
