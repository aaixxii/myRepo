package jp.co.nec.aimr.client;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.sql.DataSource;

import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerCatchUpInfo;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncRequest;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDaoImp;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;
import jp.co.nec.aimr.properties.PropertyUtil;
import jp.co.nec.aimr.service.extract.ExtractService;
import jp.co.nec.aimr.service.template.SyncTemplateService;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/applicationContext.xml" })
public class SyncTemplateServletTest {
	private static final String SYNC_SERVICE_URL = "/AIMSyncService/sync";
	@Autowired
	private SyncTemplateServlet syncTemplateServlet;
	
	@Resource
	private DataSource ds;

	private JdbcTemplate jdbcTemplate;
	
	private MockUp<DataBaseUtil> dataBaseUtilMock;
	private MockUp<PropertyUtil> propertyUtilMock;
	private MockUp<AIMrManger> aIMrMangerMock;


	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);
		new AIMrTemplatesDaoImp(jdbcTemplate);
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();

		dataBaseUtilMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
		propertyUtilMock = 
		new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}
			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}
			
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};
		
		aIMrMangerMock =
				new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			@Mock
			public String getDB_DRIVER() {
				return "Oracle";
			}
		};		
		
	}

	@After
	public void tearDown() throws Exception {
		dataBaseUtilMock.tearDown();
		propertyUtilMock.tearDown();
		aIMrMangerMock.tearDown();
		jdbcTemplate.execute("COMMIT");
	}

	@Test	
	public void testSyncTemplte_insert_OK() {
		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.INSERT, containerId, userKey, eventId, data);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);
			jdbcTemplate.execute("COMMIT");

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state);
		
		extServiceMock.tearDown();			
	}
	
	@Test
	public void testSyncTemplte_insert_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		Integer containerId = 1;
		String userKey = "test";
		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
		pBSyncJobRequest.setFunction(SyncFunctionType.INSERT);
		pBSyncJobRequest.setContainerId(containerId.intValue());
		pBSyncJobRequest.setExternalId(userKey);	
		pBSyncRequest.setSyncJobRequest(pBSyncJobRequest.build());
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(pBSyncRequest.build().toByteArray());
		
		try {
			syncTemplateServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
	
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		
		Assert.assertEquals(ErrorDifinitions.SYNC_INSERT_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD.getStringCode(), pBServiceState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.SYNC_INSERT_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD.getDescription(), pBServiceState.getReason().getDescription());	
	}
	
	
	
	@Test
	public void testSyncTemplte_insert_error() {
		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		
		MockUp<SyncTemplateService> syncTemplateServiceMock =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1L);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.INSERT, containerId, userKey, eventId, data);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		
		extServiceMock.tearDown();
		syncTemplateServiceMock.tearDown();		
	}
	
	@Test
	public void testSyncTemplte_insert_rollback() {
		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		
		MockUp<SyncTemplateService> syncTemplateServiceMock =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ROLLBACK, 1L);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.INSERT, containerId, userKey, eventId, data);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, state);
		
		extServiceMock.tearDown();
		syncTemplateServiceMock.tearDown();	
	}
	
	
	@Test
	public void testSyncTemplte_delete_OK() {	
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;		
		long  biometricsId = jdbcTemplate.queryForObject("select SEQUENCE_VALUE from sequence where SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id, user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}	

		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};		

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.DELETE, containerId, userKey, null, null);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);
			jdbcTemplate.execute("COMMIT");

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state);		
		extServiceMock.tearDown();				
	}
	
	@Test
	public void testSyncTemplte_delete_error() {	
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;		
		long  biometricsId = jdbcTemplate.queryForObject("select SEQUENCE_VALUE from sequence where SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id, user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}	

		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		
		MockUp<SyncTemplateService> syncTemplateServiceMock =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1L);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.DELETE, containerId, userKey, null, null);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		
		extServiceMock.tearDown();
		syncTemplateServiceMock.tearDown();			
	}
	
	
	@Test
	public void testSyncTemplte_delete_REQUEST_HAVE_EXTRACT_PAYLOAD() {	
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;		
		long  biometricsId = jdbcTemplate.queryForObject("select SEQUENCE_VALUE from sequence where SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id, user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}		

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
		pBSyncJobRequest.setFunction(SyncFunctionType.DELETE);
		pBSyncJobRequest.setContainerId(containerId.intValue());
		pBSyncJobRequest.setExternalId(userKey);
		
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();	
		pBSyncRequest.setSyncJobRequest(pBSyncJobRequest.build());
		pBSyncRequest.setExtractInputPayload(pBExtractInputPayload.build());		
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(pBSyncRequest.build().toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		
		Assert.assertEquals(ErrorDifinitions.SYNC_DELETE_REQUEST_HAVE_EXTRACT_PAYLOAD.getStringCode(), pBServiceState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.SYNC_DELETE_REQUEST_HAVE_EXTRACT_PAYLOAD.getDescription(), pBServiceState.getReason().getDescription());			
	}
	
	@Test
	public void testSyncTemplte_delete_rollback() {	
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;		
		long  biometricsId = jdbcTemplate.queryForObject("select SEQUENCE_VALUE from sequence where SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id, user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}	

		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		
		MockUp<SyncTemplateService> syncTemplateServiceMock =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ROLLBACK, 1L);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.DELETE, containerId, userKey, null, null);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, state);
		
		extServiceMock.tearDown();
		syncTemplateServiceMock.tearDown();			
	}
	
	@Test
	public void testSyncTemplte_update_OK() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();

		long  biometricsId = jdbcTemplate.queryForObject("select SEQUENCE_VALUE from sequence where SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		
		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};		

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.UPDATE, containerId, userKey, null, tobeUpdateData);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);
			jdbcTemplate.execute("COMMIT");

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state);
		
		extServiceMock.tearDown();		
	}
	
	
	@Test
	public void testSyncTemplte_update_error() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();

		long  biometricsId = jdbcTemplate.queryForObject("select SEQUENCE_VALUE from sequence where SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		
		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		
		MockUp<SyncTemplateService> syncTemplateServiceMock =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1L);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.UPDATE, containerId, userKey, null, tobeUpdateData);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		
		extServiceMock.tearDown();
		syncTemplateServiceMock.tearDown();
	}
	
	
	@Test
	public void testSyncTemplte_update_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;	
		long  biometricsId = jdbcTemplate.queryForObject("select SEQUENCE_VALUE from sequence where SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
		pBSyncJobRequest.setFunction(SyncFunctionType.UPDATE);
		pBSyncJobRequest.setContainerId(containerId.intValue());
		pBSyncJobRequest.setExternalId(userKey);	
		pBSyncRequest.setSyncJobRequest(pBSyncJobRequest.build());		
		
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(pBSyncRequest.build().toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);
			jdbcTemplate.execute("COMMIT");

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		Assert.assertEquals(ErrorDifinitions.SYNC_UPDATE_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD.getStringCode(), pBServiceState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.SYNC_UPDATE_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD.getDescription(), pBServiceState.getReason().getDescription());		
	}
	
	@Test
	public void testSyncTemplte_update_rollback() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();

		long  biometricsId = jdbcTemplate.queryForObject("select SEQUENCE_VALUE from sequence where SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		
		MockUp<ExtractService> extServiceMock =
		new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		
		MockUp<SyncTemplateService> syncTemplateServiceMock =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ROLLBACK, 1L);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		PBSyncRequest syncReq = createPBSyncJobRequest(SyncFunctionType.UPDATE, containerId, userKey, null, tobeUpdateData);
		req.setRequestURI(SYNC_SERVICE_URL);
		req.setContent(syncReq.toByteArray());
		try {
			syncTemplateServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBServiceState pBServiceState = null;
		try {
			pBServiceState = PBServiceState.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBServiceState);
		ServiceStateType state =pBServiceState.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, state);
		
		extServiceMock.tearDown();
		syncTemplateServiceMock.tearDown();
	}
	
	@Test
	public void testDoGet() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		req.setRequestURI(SYNC_SERVICE_URL);		
			try {
				syncTemplateServlet.doGet(req, res);
			} catch (ServletException e) {				
				e.printStackTrace();
			} catch (IOException e) {				
				e.printStackTrace();
			}	
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);		
	}
	
	@Test
	public void testDoGet_unkown() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		req.setRequestURI("/AIMSyncService/syncs");		
			try {
				syncTemplateServlet.doGet(req, res);
			} catch (ServletException e) {				
				e.printStackTrace();
			} catch (IOException e) {				
				e.printStackTrace();
			}	
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_BAD_REQUEST);		
	}
	
	@Test
	public void testDoPostUrlNotSupport() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();

		req.setRequestURI("/AIMSyncService/syncs");	
		try {
			syncTemplateServlet.doPost(req, res);
		} catch (IOException e) {			
			e.printStackTrace();
		}

		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);	
		
	}
	
	private PBSyncRequest createPBSyncJobRequest(SyncFunctionType type, Integer containerId, String externalId, Integer eventId, byte[] templates) {
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
		pBSyncJobRequest.setFunction(type);
		pBSyncJobRequest.setContainerId(containerId.intValue());
		pBSyncJobRequest.setExternalId(externalId);
		if (eventId != null) {
			pBSyncJobRequest.setEventId(eventId.intValue());
		}		
		if (templates != null && templates.length > 0) {
			pBSyncJobRequest.setTemplate(ByteString.copyFrom(templates));
		}	
		pBSyncRequest.setSyncJobRequest(pBSyncJobRequest.build());
		return pBSyncRequest.build();
	}
	
	private PBExtractJobResult createExtractResult(ServiceStateType state) {
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(state);
		pBExtractJobResult.setServiceState(status);
		pBExtractJobResult.setTemplate(ByteString.copyFrom("abcdefjhijklm".getBytes()));
		return pBExtractJobResult.build();
	}
	
	private SyncResultWithStatus creatSyncResultWithStatus(ServiceStateType type, long version ) {
		SyncResultWithStatus syncResultWithStatus = new SyncResultWithStatus();		
		PBContainerCatchUpInfo.Builder pBContainerCatchUpInfo = PBContainerCatchUpInfo.newBuilder();
		pBContainerCatchUpInfo.setCommand(SyncFunctionType.INSERT);
		pBContainerCatchUpInfo.setVersion(version);	
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(type);
		syncResultWithStatus.setpBServiceState(pBServiceState.build());		
		return syncResultWithStatus;		
	}
	
	private void recoverConatainerData() {
		String sql = "update containers set TEMPLATE_SIZE =15680 ,VERSION =0 ,RECORD_COUNT=0 where CONTAINER_ID=1";
		jdbcTemplate.update(sql);
		jdbcTemplate.execute("COMMIT");
	}
}
