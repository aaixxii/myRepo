package jp.co.nec.aimr.service.extract;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.common.PostCardType;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

public class ExtractServiceTest {
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}

			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testExtractService() {
		PostCardType postCardType = PostCardType.identify;
		byte[] parentRequst = "Iam a extract request".getBytes();
		ExtractService extractService = new ExtractService(parentRequst, postCardType);
		Assert.assertNotNull(extractService);
		Assert.assertTrue(extractService instanceof ExtractService);
	}

	@Test
	public void testDoExtract_normal() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnExtractJobqueueing(Long extractJobId) {
				return;
			}
		};
		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBExtractJobResult getOneExtJobResult(Long extJobId) {
				PBExtractJobResult result = createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
				return result;
			}
		};

		PostCardType postCardType = PostCardType.identify;
		byte[] parentRequst = "Iam a extract request".getBytes();
		ExtractService extractService = new ExtractService(parentRequst, postCardType);
		PBExtractJobResult result = extractService.doExtract();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		ServiceStateType stateType = sate.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, stateType);
		notifyMocker.tearDown();
		jobMangerMocker.tearDown();
	}

	@Test
	public void testDoExtract_timeout() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnExtractJobqueueing(Long extractJobId) {
				return;
			}
		};

		PostCardType postCardType = PostCardType.identify;
		byte[] parentRequst = "Iam a extract request".getBytes();
		ExtractService extractService = new ExtractService(parentRequst, postCardType);
		PBExtractJobResult result = extractService.doExtract();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_TIMEOUT.getDescriptionWithKey(null, null, null), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_TIMEOUT.getStringCode(), sate.getReason().getCode());
		notifyMocker.tearDown();
	}

	@Test
	public void testDoExtract_no_active_eu() {

		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBExtractJobResult getOneExtJobResult(Long extJobId) {
				PBExtractJobResult result = createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
				return result;
			}
		};

		PostCardType postCardType = PostCardType.identify;
		byte[] parentRequst = "Iam a extract request".getBytes();
		ExtractService extractService = new ExtractService(parentRequst, postCardType);
		PBExtractJobResult result = extractService.doExtract();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU.getDescriptionWithKey(null, null, null), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU.getStringCode(), sate.getReason().getCode());
		jobMangerMocker.tearDown();
	}	

	private PBExtractJobResult createExtractResult(ServiceStateType state) {
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(state);
		pBExtractJobResult.setServiceState(status);
		pBExtractJobResult.setTemplate(ByteString.copyFrom("abcdefjhijklm".getBytes()));
		return pBExtractJobResult.build();
	}

}
