package jp.co.nec.aimr.exception;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aimr.common.ErrorDifinitions;

public class NoActiveUnitExceptionTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testNoActiveUnitException() {
		NoActiveUnitException ae = new NoActiveUnitException();
		Assert.assertNotNull(ae);
		Assert.assertTrue(ae instanceof NoActiveUnitException);		
	}

	@Test
	public void testNoActiveUnitExceptionString() {
		String eMsg = "no active mu!";
		NoActiveUnitException ae = new NoActiveUnitException( eMsg);
		Assert.assertNotNull(ae);
		Assert.assertTrue(ae instanceof NoActiveUnitException);			
	}

	@Test
	public void testNoActiveUnitExceptionThrowable() {
		Throwable e = new Throwable();
		NoActiveUnitException ae = new NoActiveUnitException( e);
		Assert.assertNotNull(ae);
		Assert.assertTrue(ae instanceof NoActiveUnitException);	
		
	}

	@Test
	public void testNoActiveUnitExceptionStringThrowable() {
		String eMsg = "no active mu!";
		Throwable e = new Throwable();
		NoActiveUnitException ae = new NoActiveUnitException(eMsg, e);
		Assert.assertNotNull(ae);
		Assert.assertTrue(ae instanceof NoActiveUnitException);	
		
		
	}

	@Test
	public void testNoActiveUnitExceptionErrorDifinitions() {
		ErrorDifinitions e = ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU;
		NoActiveUnitException ae = new NoActiveUnitException(e);
		Assert.assertNotNull(ae);
		Assert.assertTrue(ae instanceof NoActiveUnitException);	
	}
}
