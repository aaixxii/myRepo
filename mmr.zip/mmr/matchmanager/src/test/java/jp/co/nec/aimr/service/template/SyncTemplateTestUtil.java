package jp.co.nec.aimr.service.template;

import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerCatchUpInfo;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputImage;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncRequest;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;

public class SyncTemplateTestUtil {
	public PBSyncRequest createPBSyncJobRequestWithTemplate(SyncFunctionType type, Integer containerId, String externalId, Integer eventId, byte[] templates) {
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
		pBSyncJobRequest.setFunction(type);
		pBSyncJobRequest.setContainerId(containerId.intValue());
		pBSyncJobRequest.setExternalId(externalId);
		if (eventId != null) {
			pBSyncJobRequest.setEventId(eventId.intValue());
		}		
		if (templates != null && templates.length > 0) {
			pBSyncJobRequest.setTemplate(ByteString.copyFrom(templates));
		}	
		pBSyncRequest.setSyncJobRequest(pBSyncJobRequest.build());
		return pBSyncRequest.build();
	}
	
	public PBSyncRequest createPBSyncJobRequestNoTemplateNoPayload(SyncFunctionType type, Integer containerId, String externalId, Integer eventId) {
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
		pBSyncJobRequest.setFunction(type);
		pBSyncJobRequest.setContainerId(containerId.intValue());
		pBSyncJobRequest.setExternalId(externalId);
		if (eventId != null) {
			pBSyncJobRequest.setEventId(eventId.intValue());
		}	
		pBSyncRequest.setSyncJobRequest(pBSyncJobRequest.build());
		return pBSyncRequest.build();
	}
	
	public PBSyncRequest createPBSyncJobRequestWithExtract(SyncFunctionType type, Integer containerId, String externalId, Integer eventId) {
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();		
		List<PBExtractInputImage> extInputImageList = new ArrayList<>();
		PBExtractInputImage.Builder pBExtractInputImage = PBExtractInputImage.newBuilder();
		pBExtractInputImage.setType(ImageFormatType.BMP);	
		pBExtractInputImage.setData(ByteString.copyFrom("must be bmp data".getBytes()));
		extInputImageList.add(pBExtractInputImage.build());
		pBExtractInputPayload.addAllTenprintImage(extInputImageList);
		
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
		pBSyncJobRequest.setFunction(type);
		pBSyncJobRequest.setContainerId(containerId.intValue());
		pBSyncJobRequest.setExternalId(externalId);
		if (eventId != null) {
			pBSyncJobRequest.setEventId(eventId.intValue());
		}		
		pBSyncRequest.setSyncJobRequest(pBSyncJobRequest.build());
		pBSyncRequest.setExtractInputPayload(pBExtractInputPayload.build());
		return pBSyncRequest.build();
	}
	
	public PBExtractJobResult createExtractResult(ServiceStateType state) {
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(state);
		pBExtractJobResult.setServiceState(status);
		pBExtractJobResult.setTemplate(ByteString.copyFrom("abcdefjhijklm".getBytes()));
		return pBExtractJobResult.build();
	}
	
	public SyncResultWithStatus creatSyncResultWithStatus(ServiceStateType type, long version ) {
		SyncResultWithStatus syncResultWithStatus = new SyncResultWithStatus();		
		PBContainerCatchUpInfo.Builder pBContainerCatchUpInfo = PBContainerCatchUpInfo.newBuilder();
		pBContainerCatchUpInfo.setCommand(SyncFunctionType.INSERT);
		pBContainerCatchUpInfo.setVersion(version);	
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(type);
		syncResultWithStatus.setpBServiceState(pBServiceState.build());		
		return syncResultWithStatus;		
	}
	

}
