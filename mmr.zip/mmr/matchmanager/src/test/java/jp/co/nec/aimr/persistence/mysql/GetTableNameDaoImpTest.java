package jp.co.nec.aimr.persistence.mysql;

import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AimrTableNameMapper;
import jp.co.nec.aimr.persistence.aimdb.GetTableNameDao;
import jp.co.nec.aimr.persistence.aimdb.GetTableNameDaoImp;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationMysqlContext.xml" })
@Transactional
public class GetTableNameDaoImpTest {
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Resource
	private DataSource ds;

	private GetTableNameDao dao;

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 3;
			}

			@Mock
			public String getPropertyValue(String name) {
				return "mysql";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}

			@Mock
			public String getDB_DRIVER() {
				return "mysql";
			}
		};
		dao = new GetTableNameDaoImp(ds);
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testGetTableNameDaoImp() {
		Assert.assertNotNull(dao);
		Assert.assertTrue(dao instanceof GetTableNameDaoImp);
	}

	@Test
	public void testGetAimrTableNames() {
		List<AimrTableNameMapper> testResults = dao.getAimrTableNames();
		Assert.assertNotNull(testResults);
		for (AimrTableNameMapper at : testResults) {
			switch (at.getContainerId()) {
			case 1:
				Assert.assertEquals("PERSON_BIOMETRICS_1", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_1", at.getPersonBiometricsChangeLogName());
				break;
			case 2:
				Assert.assertEquals("PERSON_BIOMETRICS_2", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_2", at.getPersonBiometricsChangeLogName());
				break;
			case 3:
				Assert.assertEquals("PERSON_BIOMETRICS_3", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_3", at.getPersonBiometricsChangeLogName());
				break;
			case 4:
				Assert.assertEquals("PERSON_BIOMETRICS_4", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_4", at.getPersonBiometricsChangeLogName());
				break;
			case 5:
				Assert.assertEquals("PERSON_BIOMETRICS_5", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_5", at.getPersonBiometricsChangeLogName());
				break;
			case 6:
				Assert.assertEquals("PERSON_BIOMETRICS_6", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_6", at.getPersonBiometricsChangeLogName());
				break;
			case 7:
				Assert.assertEquals("PERSON_BIOMETRICS_7", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_7", at.getPersonBiometricsChangeLogName());
				break;
			case 8:
				Assert.assertEquals("PERSON_BIOMETRICS_8", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_8", at.getPersonBiometricsChangeLogName());
				break;
			case 9:
				Assert.assertEquals("PERSON_BIOMETRICS_9", at.getPersonBiometricsTableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_9", at.getPersonBiometricsChangeLogName());
				break;
			}
		}
	}
}
