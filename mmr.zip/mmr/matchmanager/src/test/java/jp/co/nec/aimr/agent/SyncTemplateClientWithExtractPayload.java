package jp.co.nec.aimr.agent;
import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputImage;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncRequest;

public class SyncTemplateClientWithExtractPayload {

	public static void main(String[] args) {
		AimrHttpClientUtil util = new AimrHttpClientUtil();
		String postUrl = "http://10.197.23.100:8080/matchmanager//AIMSyncService/sync";
		PBSyncRequest syncbRequst = CreateSyncTemplateJobRequst();
		//PBSyncRequest test = null;	
		byte[] byteJobRespose = null;
		for (int i = 0 ; i < 50; i++) {
			byteJobRespose = util.postByteData(postUrl, syncbRequst.toByteArray());	
			assert byteJobRespose != null;
		}
		
		
	
		
	}
	
	private static PBSyncRequest CreateSyncTemplateJobRequst() {
		
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		
			
		List<PBSyncRequest> pBSyncRequests = new ArrayList<>();
		for (int i = 0; i< 50; i++) {
			PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();
			PBExtractInputImage.Builder pBExtractInputImage = PBExtractInputImage.newBuilder();
			pBExtractInputImage.setType(ImageFormatType.BMP);
			pBExtractInputImage.setData(ByteString.copyFrom("abcdefghijklmnoprqstuvwxyx".getBytes()));
			pBExtractInputPayload.addTenprintImage(pBExtractInputImage);
			PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
			pBSyncJobRequest.setContainerId(1);
			pBSyncJobRequest.setEventId(i + 2);
			pBSyncJobRequest.setExternalId("test");
			pBSyncJobRequest.setFunction(SyncFunctionType.INSERT);
			//String data = "aaaabccccdeedddd";
			//pBSyncJobRequest.setTemplate(ByteString.copyFrom(data.getBytes()));		
			pBSyncRequest.setSyncJobRequest(pBSyncJobRequest);			
			pBSyncRequest.setExtractInputPayload(pBExtractInputPayload.build());
			pBSyncRequests.add(pBSyncRequest.build());
		}		
		return pBSyncRequest.build();
	}

}
