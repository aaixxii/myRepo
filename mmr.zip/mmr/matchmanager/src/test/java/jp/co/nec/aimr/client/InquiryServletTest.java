package jp.co.nec.aimr.client;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.servlet.ServletException;

import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.UninitializedMessageException;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2RotationLimitType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.properties.PropertyUtil;
import jp.co.nec.aimr.service.extract.ExtractService;
import jp.co.nec.aimr.service.inquiry.AimrInquiryService;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/applicationContext.xml" })
public class InquiryServletTest {

	private static final String INQ_REQ_URL = "/AIMInquiryService/identify";
	@Autowired
	private InquiryServlet inquiryServlet;	
	
	private  MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}			
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		 manager =new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			@Mock
			public String getDB_DRIVER() {
				return "Oracle";
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testDoPostInquiry_OK() {

		MockUp<PropertyUtil> proMocker = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}
			
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}			
			
		};

		MockUp<AIMrManger> managerMocker = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};

		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnIdentifyJobqueueing(int containerId, Long inquiryJobId) {
				return;
			}	
		};
		
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		MockUp<AimrInquiryService> inqMock = new MockUp<AimrInquiryService>() {
			@Mock
			private PBIdentifyResponse doIquiry(PBInquiryJobRequest inquiryJobRequest) {
				return CreateInquiryJobResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBIdentifyRequest inqJobReq = CreateInquiryJobRequst();
		req.setRequestURI(INQ_REQ_URL);
		req.setContent(inqJobReq.toByteArray());
		try {
			inquiryServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBIdentifyResponse pBIdentifyResponse = null;
		try {
			pBIdentifyResponse = PBIdentifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotNull(pBIdentifyResponse);
		ServiceStateType state = pBIdentifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state);
		extMock.tearDown();
		inqMock.tearDown();
		notifyMocker.tearDown();
		proMocker.tearDown();
		managerMocker.tearDown();
	}	

	@Test
	public void testDoPostInquiry_Error() {
		MockUp<PropertyUtil> proMocker = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			
		};


		MockUp<AIMrManger> managerMocker = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnIdentifyJobqueueing(int containerId, Long inquiryJobId) {
				return;
			}
		};
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_ERROR);
			}
		};

		MockUp<AimrInquiryService> inqMock = new MockUp<AimrInquiryService>() {
			@Mock
			private PBIdentifyResponse doIquiry(PBInquiryJobRequest inquiryJobRequest) {
				return CreateInquiryJobResult(ServiceStateType.SERVICE_STATE_ERROR);
			}
		};
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBIdentifyRequest inqJobReq = CreateInquiryJobRequst();
		req.setRequestURI(INQ_REQ_URL);
		req.setContent(inqJobReq.toByteArray());
		try {
			inquiryServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBIdentifyResponse pBIdentifyResponse = null;
		try {
			pBIdentifyResponse = PBIdentifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotNull(pBIdentifyResponse);
		ServiceStateType state = pBIdentifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		extMock.tearDown();
		inqMock.tearDown();
		notifyMocker.tearDown();
		proMocker.tearDown();
		managerMocker.tearDown();
	}

	@Test
	public void testDoPostInquiry_NoActiveMu() {		
		
		MockUp<ExtractService> extMocker =  new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBIdentifyRequest inqJobReq = CreateInquiryJobRequst();
		req.setRequestURI(INQ_REQ_URL);
		req.setContent(inqJobReq.toByteArray());
		System.out.println("Save result to memory!");
		try {
			inquiryServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBIdentifyResponse pBIdentifyResponse = null;
		try {
			pBIdentifyResponse = PBIdentifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}

		Assert.assertNotNull(pBIdentifyResponse);
		ServiceStateType state = pBIdentifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, state);
		String code = pBIdentifyResponse.getServiceState().getReason().getCode();
		String description = pBIdentifyResponse.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU.getDescriptionWithKey(null, null, null), description);
		extMocker.tearDown();
	}

	@Test
	public void testDoPostInquiry_TimeOut() {
		MockUp<MMrJobManager> mmrMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBIdentifyResponse getOneInqJobResult(Long inqJobId) {
				return null;

			}
		};

		MockUp<PropertyUtil> proMocker =new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}			
		};

		MockUp<AIMrManger> managerMocker = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnIdentifyJobqueueing(int containerId, Long inquiryJobId) {
				return;
			}
		};

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBIdentifyRequest inqJobReq = CreateInquiryJobRequstHasTemplagte();
		req.setRequestURI(INQ_REQ_URL);
		req.setContent(inqJobReq.toByteArray());
		try {
			inquiryServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBIdentifyResponse pBIdentifyResponse = null;
		try {
			pBIdentifyResponse = PBIdentifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertNotNull(pBIdentifyResponse);
		ServiceStateType state = pBIdentifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, state);
		String code = pBIdentifyResponse.getServiceState().getReason().getCode();
		String description = pBIdentifyResponse.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT.getDescriptionWithKey(null, null, null), description);
		mmrMocker.tearDown();
		notifyMocker.tearDown();
		proMocker.tearDown();
		managerMocker.tearDown();		
	}
	
	@Test
	public void testDoGet() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBIdentifyRequest inqJobReq = CreateInquiryJobRequst();
		req.setRequestURI(INQ_REQ_URL);
		req.setContent(inqJobReq.toByteArray());
	
			try {
				inquiryServlet.doGet(req, res);
			} catch (ServletException e) {				
				e.printStackTrace();
			} catch (IOException e) {				
				e.printStackTrace();
			}
	
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
		
	}
	
	@Test
	public void testDoGet_unkown() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBIdentifyRequest inqJobReq = CreateInquiryJobRequst();
		req.setRequestURI("/AIMInquiryService/identifys");
		req.setContent(inqJobReq.toByteArray());
	
			try {
				inquiryServlet.doGet(req, res);
			} catch (ServletException e) {				
				e.printStackTrace();
			} catch (IOException e) {				
				e.printStackTrace();
			}	
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_BAD_REQUEST);		
	}
	
	@Test
	public void testDoPostUrlNotSupport() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBIdentifyRequest inqJobReq = CreateInquiryJobRequst();
		req.setRequestURI("/AIMInquiryService/identifys");
		req.setContent(inqJobReq.toByteArray());
	
			try {
				inquiryServlet.doPost(req, res);
			} catch (IOException e) {				
				e.printStackTrace();
			}	
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);		
	}

	private static PBIdentifyRequest CreateInquiryJobRequstHasTemplagte() {
		PBIdentifyRequest.Builder pbIdentiyReq = PBIdentifyRequest.newBuilder();
		// PBExtractInputPayload.Builder pbExtPayload =
		// PBExtractInputPayload.newBuilder();
		PBCMLOptions.Builder pmCm = PBCMLOptions.newBuilder();
		pmCm.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
		pmCm.setParameterId(1);
		// pbIdentiyReq.setExtractInputPayload(pbExtPayload);
		PBInquiryJobRequest.Builder jobRequest = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder info = PBInquiryJobInfo.newBuilder();
		info.setContainerId(1);
		info.setMaxCandidate(100);
		jobRequest.setJobInfo(info);
		jobRequest.setTemplate(ByteString.copyFrom("abcdefghijklmnoprqstuvwxyz".getBytes()));
		pbIdentiyReq.setInquiryJobRequest(jobRequest);
		return pbIdentiyReq.build();
	}
	
	@Test(expected = UninitializedMessageException.class)
	public void testDoPostInquiry_Request_protobuf_error() {	
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		
		PBIdentifyRequest.Builder pbIdentiyReq = PBIdentifyRequest.newBuilder();
		PBExtractInputPayload.Builder pbExtPayload = PBExtractInputPayload.newBuilder();
		PBCMLOptions.Builder pmCm = PBCMLOptions.newBuilder();
		pmCm.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
		pmCm.setParameterId(1);
		pbIdentiyReq.setExtractInputPayload(pbExtPayload);		
		req.setRequestURI(INQ_REQ_URL);
		req.setContent(pbIdentiyReq.build().toByteArray());
		try {
			inquiryServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_BAD_REQUEST);
		byte[] results = res.getContentAsByteArray();	
		Assert.assertNull(results);
	}
	
	@Test
	public void testDoPostInquiry_Request_NO_EXTACTPAYLOAD_NO_TEMPLATE() {	
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		
		PBIdentifyRequest.Builder pbIdentiyReq = PBIdentifyRequest.newBuilder();		
		PBCMLOptions.Builder pmCm = PBCMLOptions.newBuilder();
		pmCm.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
		pmCm.setParameterId(1);		
		PBInquiryJobRequest.Builder jobRequest = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder info = PBInquiryJobInfo.newBuilder();
		info.setContainerId(1);
		info.setMaxCandidate(100);
		jobRequest.setJobInfo(info);
		pbIdentiyReq.setInquiryJobRequest(jobRequest);		
		req.setRequestURI(INQ_REQ_URL);
		req.setContent(pbIdentiyReq.build().toByteArray());
		try {
			inquiryServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();	
		Assert.assertNotNull(results);		
		PBIdentifyResponse pBIdentifyResponse = null;
		try {
			pBIdentifyResponse = PBIdentifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotNull(pBIdentifyResponse);
		ServiceStateType state = pBIdentifyResponse.getServiceState().getState();		
		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_REQUEST_NO_EXTACTPAYLOAD_NO_TEMPLATE.getDescriptionWithKey(null, null, null), pBIdentifyResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_REQUEST_NO_EXTACTPAYLOAD_NO_TEMPLATE.getStringCode(), pBIdentifyResponse.getServiceState().getReason().getCode());		
	}	

	private static PBIdentifyRequest CreateInquiryJobRequst() {
		PBIdentifyRequest.Builder pbIdentiyReq = PBIdentifyRequest.newBuilder();
		PBExtractInputPayload.Builder pbExtPayload = PBExtractInputPayload.newBuilder();
		PBCMLOptions.Builder pmCm = PBCMLOptions.newBuilder();
		pmCm.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
		pmCm.setParameterId(1);
		pbIdentiyReq.setExtractInputPayload(pbExtPayload);
		PBInquiryJobRequest.Builder jobRequest = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder info = PBInquiryJobInfo.newBuilder();
		info.setContainerId(1);
		info.setMaxCandidate(100);
		jobRequest.setJobInfo(info);

		pbIdentiyReq.setInquiryJobRequest(jobRequest);
		return pbIdentiyReq.build();
	}

	private PBExtractJobResult createExtractResult(ServiceStateType state) {
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(state);
		pBExtractJobResult.setServiceState(status);
		pBExtractJobResult.setTemplate(ByteString.copyFrom("abcdefjhijklm".getBytes()));
		return pBExtractJobResult.build();
	}

	private PBIdentifyResponse CreateInquiryJobResult(ServiceStateType state) {
		PBIdentifyResponse.Builder jobResult = PBIdentifyResponse.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		jobResult.setServiceState(status);
		return jobResult.build();
	}
	
}
