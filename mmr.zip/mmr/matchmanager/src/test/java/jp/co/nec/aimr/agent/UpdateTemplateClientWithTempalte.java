package jp.co.nec.aimr.agent;
import java.util.ArrayList;
import java.util.List;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncRequest;

public class UpdateTemplateClientWithTempalte {

	public static void main(String[] args) {
		AimrHttpClientUtil util = new AimrHttpClientUtil();
		String postUrl = "http://10.197.23.100:8080/matchmanager//AIMSyncService/sync";
		List<PBSyncRequest> syncbRequstList = CreateSyncTemplateJobRequst();			
		
		byte[] byteJobRespose = null;
		for (int i = 0 ; i < syncbRequstList.size(); i++) {
			PBSyncRequest syncbRequst = syncbRequstList.get(i);
			byteJobRespose = util.postByteData(postUrl, syncbRequst.toByteArray());	
			assert byteJobRespose != null;
		}		
	}
	
	private static List<PBSyncRequest> CreateSyncTemplateJobRequst() {
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();
		
//		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();
//		PBExtractInputImage.Builder pBExtractInputImage = PBExtractInputImage.newBuilder();
//		pBExtractInputImage.setType(ImageFormatType.BMP);
//		pBExtractInputImage.setData(ByteString.copyFrom("abcdefghijklmnoprqstuvwxyx".getBytes()));
//		pBExtractInputPayload.addTenprintImage(pBExtractInputImage);		
		List<PBSyncRequest> pBSyncRequests = new ArrayList<>();
		for (int i = 0; i< 500; i++) {
			PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
			pBSyncJobRequest.setContainerId(1);
			pBSyncJobRequest.setEventId(i + 2);
			pBSyncJobRequest.setExternalId("test");
			pBSyncJobRequest.setFunction(SyncFunctionType.UPDATE);
			String data = "aaaabccccdeeddddfffeee";
			pBSyncJobRequest.setTemplate(ByteString.copyFrom(data.getBytes()));		
			pBSyncRequest.setSyncJobRequest(pBSyncJobRequest);
			pBSyncRequests.add(pBSyncRequest.build());			
		}

		//pBSyncRequest.setExtractInputPayload(pBExtractInputPayload);
		
		return pBSyncRequests;
		
		
	}

}
