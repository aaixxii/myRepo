package jp.co.nec.aimr.agent;
import java.util.ArrayList;
import java.util.List;

import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncRequest;

public class SyncTemplateWithDeleteNoEventId {

	public static void main(String[] args) {
		AimrHttpClientUtil util = new AimrHttpClientUtil();
		String postUrl = "http://10.197.23.100:8080/matchmanager//AIMSyncService/sync";
		List<PBSyncRequest> syncbRequstList = CreateSyncTemplateJobRequst();			
		
		byte[] byteJobRespose = null;
		for (int i = 0 ; i < syncbRequstList.size(); i++) {
			PBSyncRequest syncbRequst = syncbRequstList.get(i);
			byteJobRespose = util.postByteData(postUrl, syncbRequst.toByteArray());	
			assert byteJobRespose != null;
		}		
	}
	
	private static List<PBSyncRequest> CreateSyncTemplateJobRequst() {
		PBSyncRequest.Builder pBSyncRequest = PBSyncRequest.newBuilder();		

		List<PBSyncRequest> pBSyncRequests = new ArrayList<>();
	
			PBSyncJobRequest.Builder pBSyncJobRequest = PBSyncJobRequest.newBuilder();
			pBSyncJobRequest.setContainerId(1);			
			pBSyncJobRequest.setExternalId("test");
			pBSyncJobRequest.setFunction(SyncFunctionType.DELETE);					
			pBSyncRequest.setSyncJobRequest(pBSyncJobRequest);
			pBSyncRequests.add(pBSyncRequest.build());			
				
		
		return pBSyncRequests;
		
		
	}

}
