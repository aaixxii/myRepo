package jp.co.nec.aimr.agent;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AimrHttpClientUtil {
	private static final int SO_TIMEOUT = 115000;
	private static final int CON_TIMEOUT = 100000;
	public static final int DEFAULT_RETRY_COUNT = 3;
	private static final String USER_AGENT = "Mozilla/5.0";
	private static final Logger logger = LoggerFactory.getLogger(AimrHttpClientUtil.class);

	public AimrHttpClientUtil() {
	}

	public byte[] postByteData(final String postUrl, byte[] bytes) {
		HttpPost httpPost = new HttpPost(postUrl);
		httpPost.addHeader("User-Agent", USER_AGENT);

		RequestConfig config = RequestConfig.custom().setConnectTimeout(CON_TIMEOUT).setConnectionRequestTimeout(CON_TIMEOUT).setSocketTimeout(SO_TIMEOUT).build();
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();

		ByteArrayEntity entity = new ByteArrayEntity(bytes, ContentType.APPLICATION_OCTET_STREAM);
		httpPost.setEntity(entity);
		byte[] byteArrayResult = null;
		try {
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			HttpEntity result = httpResponse.getEntity();
			byteArrayResult = EntityUtils.toByteArray(result);
			int statusCode = httpResponse.getStatusLine().getStatusCode();
			logger.info("Http response's status is {}", statusCode);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
		return byteArrayResult;
	}

	public String postByteData(final String postUrl, String stringData) {
		HttpPost httpPost = new HttpPost(postUrl);
		httpPost.addHeader("User-Agent", USER_AGENT);

		RequestConfig config = RequestConfig.custom().setConnectTimeout(CON_TIMEOUT).setConnectionRequestTimeout(CON_TIMEOUT).setSocketTimeout(SO_TIMEOUT).build();
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();

		StringEntity entity = new StringEntity(stringData, ContentType.TEXT_XML);
		httpPost.setEntity(entity);

		String StringResult = null;
		try {
			CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
			HttpEntity result = httpResponse.getEntity();
			StringResult = EntityUtils.toString(result, "UTF-8");
			int statusCode = httpResponse.getStatusLine().getStatusCode();
			logger.info("Http response's status is {}", statusCode);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
		return StringResult;
	}

	// public static void main(String[] args) throws IOException {
	// System.setProperty("org.apache.commons.logging.Log",
	// "org.apache.commons.logging.impl.SimpleLog");
	// System.setProperty("org.apache.commons.logging.simplelog.showdatetime",
	// "true");
	// System.setProperty(
	// "org.apache.commons.logging.simplelog.log.org.apache.http",
	// "debug");
	// }

}
