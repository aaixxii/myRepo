package jp.co.nec.aimr.service.template;

import java.io.IOException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncRequest;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;
import jp.co.nec.aimr.properties.PropertyUtil;
import jp.co.nec.aimr.service.extract.ExtractService;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/applicationContext.xml" })
public class SyncTemplateServiceDeleteTest {
	private SyncTemplateTestUtil util;
	
	@Resource
	private DataSource ds;

	
	private MockUp<DataBaseUtil> dataBaseUtilMock;
	private MockUp<PropertyUtil> propertyUtilMock;
	private MockUp<AIMrManger> aIMrMangerMock;

	@Before
	public void setUp() throws Exception {
		util = new SyncTemplateTestUtil();
		dataBaseUtilMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
		propertyUtilMock = 
		new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}
			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}
			
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};
		
		aIMrMangerMock =
				new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			@Mock
			public String getDB_DRIVER() {
				return "postgresql";
			}
		};		
	}

	@After
	public void tearDown() throws Exception {
		dataBaseUtilMock.tearDown();
		propertyUtilMock.tearDown();
		aIMrMangerMock.tearDown();
		util = null;
	}
	
	@Test
	public void testSyncTemplateService() {
		Integer containerId = 1;
		String userKey = "test";				
		Integer eventId = 1;
		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithTemplate(SyncFunctionType.DELETE, containerId, userKey, eventId, null));
		Assert.assertNotNull(service);
		Assert.assertTrue(service instanceof SyncTemplateService);
	}

	@Test
	public void testProcessSyncRequest_delete_normal() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";	
		Integer eventId = 1;
		PBSyncRequest request = util.createPBSyncJobRequestWithTemplate(SyncFunctionType.DELETE, containerId, userKey, eventId, null);
		SyncTemplateService service = new SyncTemplateService(request);
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_delete_no_eventid_normal() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";
		
		PBSyncRequest request = util.createPBSyncJobRequestWithTemplate(SyncFunctionType.DELETE, containerId, userKey, null, null);
		SyncTemplateService service = new SyncTemplateService(request);
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
	}
	
	
	public void testProcessSyncRequest_delete_has_extractpayload() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";			
		Integer eventId = 1;
		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithExtract(SyncFunctionType.DELETE, containerId, userKey, eventId));		
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		Assert.assertEquals(ErrorDifinitions.SYNC_DELETE_REQUEST_HAVE_EXTRACT_PAYLOAD.getStringCode(), state.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.SYNC_DELETE_REQUEST_HAVE_EXTRACT_PAYLOAD.getDescription(), state.getReason().getDescription());
		
		extMocker.tearDown();
		syncMocker.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_hasTemplate_delete_no_eventid() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";		
		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithExtract(SyncFunctionType.DELETE, containerId, userKey, null));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());		
		extMocker.tearDown();
		syncMocker.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_delete_errror() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";		
		Integer eventId = 1;

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithTemplate(SyncFunctionType.DELETE, containerId, userKey, eventId, null));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_delete_no_eventid_errror() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";		

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithTemplate(SyncFunctionType.DELETE, containerId, userKey, null, null));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
	}


}
