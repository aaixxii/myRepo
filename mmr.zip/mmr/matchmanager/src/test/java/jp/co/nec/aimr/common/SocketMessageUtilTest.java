package jp.co.nec.aimr.common;

import java.io.UnsupportedEncodingException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;



public class SocketMessageUtilTest {

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreatePostCardMessage() {
		byte[] results = SocketMessageUtil.createPostCardMessage(PostCardType.identify.name());
		String postCard = new String(results);
		Assert.assertEquals("identify\0\0\0\0\0\0\0\0", postCard);
		System.out.println(postCard);
	}
	
	@Test
	public void testCreatePostCardMessage2() {
		byte[] results = SocketMessageUtil.createPostCardMessage(PostCardType.sync.name());
		String postCard = new String(results);
		Assert.assertEquals("sync\0\0\0\0\0\0\0\0\0\0\0\0", postCard);
		System.out.println(postCard);
	}
	
	@Test 
	public void testConvertNullToSpace() {
		String postCard = "sync\0\0\0\0\0\0\0\0\0\0\0\0";
		String result = SocketMessageUtil.convertNullToSpace(postCard);
		System.out.println(result);
		Assert.assertEquals(16, result.length());
		Assert.assertEquals( "sync            ", result);		
	}
	
	@Test 
	public void testConvertNullToSpace2() {
		String postCard = null;
		try {
			postCard = new String(SocketMessageUtil.createPostCardMessage("identify"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String result = SocketMessageUtil.convertNullToSpace(postCard);
		System.out.println(result);
		Assert.assertEquals(16, result.length());
		Assert.assertEquals( "identify        ", result);		
	}
	
	@Test 
	public void testConvertNullToSpace3() {
		String postCard = null;
		try {
			postCard = new String(SocketMessageUtil.createPostCardMessage("sync"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String result = SocketMessageUtil.convertNullToSpace(postCard);
		System.out.println(result);
		Assert.assertEquals(16, result.length());
		Assert.assertEquals( "sync            ", result);		
	}
}
