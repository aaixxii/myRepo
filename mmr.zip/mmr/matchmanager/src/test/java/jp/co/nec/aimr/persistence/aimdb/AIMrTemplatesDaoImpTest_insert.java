package jp.co.nec.aimr.persistence.aimdb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ContainerAssignedStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBContainerCatchUpInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDao;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDaoImp;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class AIMrTemplatesDaoImpTest_insert {

	@Resource
	private DataSource ds;

	@Resource
	private DataSource testDs;

	private AIMrTemplatesDao dao;
	private JdbcTemplate jdbcTemplate;
	private MockUp<DataBaseUtil> dbMock;
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);
		dao = new AIMrTemplatesDaoImp(jdbcTemplate);
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();
		dbMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 3;
			}

			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};

	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();
		dbMock.tearDown();
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testInsertTemplate() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 11;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");

		syncResultWithStatus = dao.insertTemplate(containerId, userKey, eventId, data);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		JdbcTemplate testJdbcTemplate = new JdbcTemplate(testDs);
		Assert.assertNotNull(pbSyncRequet);
		Assert.assertEquals(containerId.intValue(), pbSyncRequet.getContainerId());
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoCount());
		Assert.assertEquals("CONTAINER_ASSIGNED", pbSyncRequet.getAssignedState().name());
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoList().get(0).getVersion());
		Assert.assertEquals(eventId.intValue(), pbSyncRequet.getContainerSyncInfoList().get(0).getEventId());
		Assert.assertEquals("INSERT", pbSyncRequet.getContainerSyncInfoList().get(0).getCommand().name());
		Assert.assertEquals(userKey, pbSyncRequet.getContainerSyncInfoList().get(0).getExternalId());
		Assert.assertEquals(sdata,
				new String(pbSyncRequet.getContainerSyncInfoList().get(0).getTemplate().toByteArray()));
		Assert.assertEquals(changeId + 1, testJdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometricsId + 1,
				testJdbcTemplate
						.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'",
								Long.class)
						.longValue());
		Assert.assertEquals(biometricsId + 1, testJdbcTemplate
				.queryForObject("SELECT LAST_ENROLLED_BIO_ID FROM CONTAINERS WHERE CONTAINER_ID = 1", Long.class)
				.longValue());
		testJdbcTemplate = null;
	}

	@Test
	public void testInsertTemplate_duplicate_key() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 11;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		String insertSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS)  VALUES (?, ?, ?, ?, ?, ?)";
		jdbcTemplate.update(insertSql,
				new Object[] { biometricsId, userKey, eventId, data, data.length, System.currentTimeMillis() });

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");

		syncResultWithStatus = dao.insertTemplate(containerId, userKey, eventId, data);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(ErrorDifinitions.DB_DUPLICATE_KEY.getStringCode(),
				syncResultWithStatus.getpBServiceState().getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_DUPLICATE_KEY.getDescriptionWithKey(containerId, userKey, eventId),
				syncResultWithStatus.getpBServiceState().getReason().getDescription());
	}

	@Test
	public void testInsertTemplate_rollback() {
		JdbcTemplate testJdbcTemplate = new JdbcTemplate(ds);
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 11;
		byte[] data = null;

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long lastEnrollId = jdbcTemplate
				.queryForObject("SELECT LAST_ENROLLED_BIO_ID FROM CONTAINERS WHERE CONTAINER_ID = 1", Long.class)
				.longValue();
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");

		syncResultWithStatus = dao.insertTemplate(containerId, userKey, eventId, data);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);

		Assert.assertEquals(changeId, testJdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		// Assert.assertEquals(biometricsId.longValue() ,
		// jdbcTemplate.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE
		// WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class).longValue());
		Assert.assertEquals(lastEnrollId, testJdbcTemplate
				.queryForObject("SELECT LAST_ENROLLED_BIO_ID FROM CONTAINERS WHERE CONTAINER_ID = 1", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout, testJdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
		testJdbcTemplate = null;
		PBServiceState sysStatus = syncResultWithStatus.getpBServiceState();
		Assert.assertNotNull(sysStatus);
		System.out.println(sysStatus.toString());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(),
				syncResultWithStatus.getpBServiceState().getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(containerId, userKey, eventId),
				syncResultWithStatus.getpBServiceState().getReason().getDescription());
	}

	@Test
	public void testInsertTemplate_overMaxRecord() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 11;
		byte[] data = "abcdefghi".getBytes();

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);

		long lastEnrollId = jdbcTemplate
				.queryForObject("SELECT LAST_ENROLLED_BIO_ID FROM CONTAINERS WHERE CONTAINER_ID = 1", Long.class)
				.longValue();
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();

		int maxRecordCount = jdbcTemplate
				.queryForObject("SELECT MAX_RECORD_COUNT FROM CONTAINERS WHERE CONTAINER_ID = 1", Integer.class)
				.intValue();
		String updateContainersSql = "UPDATE CONTAINERS SET  RECORD_COUNT = 1 + MAX_RECORD_COUNT "
				+ "WHERE CONTAINER_ID = ?";
		jdbcTemplate.update(updateContainersSql, 1L);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");

		syncResultWithStatus = dao.insertTemplate(containerId, userKey, eventId, data);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);

		Assert.assertEquals(changeId, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		// Assert.assertEquals(biometricsId.longValue() ,
		// jdbcTemplate.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE
		// WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class).longValue());
		Assert.assertEquals(lastEnrollId, jdbcTemplate
				.queryForObject("SELECT LAST_ENROLLED_BIO_ID FROM CONTAINERS WHERE CONTAINER_ID = 1", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
		Assert.assertEquals(maxRecordCount,
				jdbcTemplate
						.queryForObject("SELECT MAX_RECORD_COUNT FROM CONTAINERS WHERE CONTAINER_ID = 1", Integer.class)
						.intValue());
		Assert.assertEquals(maxRecordCount + 1,
				jdbcTemplate.queryForObject("select RECORD_COUNT from CONTAINERS where container_id = 1", Integer.class)
						.intValue());
		Assert.assertEquals(ErrorDifinitions.DB_CONTAINERS_OVER_MAX_RECORD_COUNT.getStringCode(),
				syncResultWithStatus.getpBServiceState().getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_CONTAINERS_OVER_MAX_RECORD_COUNT.getDescriptionWithKey(containerId,
				userKey, eventId), syncResultWithStatus.getpBServiceState().getReason().getDescription());
	}

	@Test
	public void testInsertTemplate_rollback_1() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		String userKey = "test";
		Integer eventId = 11;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		Long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);
		long lastEnrollId = jdbcTemplate
				.queryForObject("SELECT LAST_ENROLLED_BIO_ID FROM CONTAINERS WHERE CONTAINER_ID = 1", Long.class)
				.longValue();
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");

		syncResultWithStatus = dao.insertTemplate(-9999, userKey, eventId, data);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);

		Assert.assertEquals(changeId, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometricsId.longValue(),
				jdbcTemplate
						.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'",
								Long.class)
						.longValue());
		Assert.assertEquals(lastEnrollId, jdbcTemplate
				.queryForObject("SELECT LAST_ENROLLED_BIO_ID FROM CONTAINERS WHERE CONTAINER_ID = 1", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
		Assert.assertEquals(ErrorDifinitions.DB_EMPTY_RESULT.getStringCode(),
				syncResultWithStatus.getpBServiceState().getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_EMPTY_RESULT.getDescriptionWithKey(-9999, userKey, eventId),
				syncResultWithStatus.getpBServiceState().getReason().getDescription());
	}

	@Test
	public void prirnt() {
		PBContainerSyncRequest.Builder pBContainerSyncRequest = PBContainerSyncRequest.newBuilder();
		pBContainerSyncRequest.setContainerId(1);
		pBContainerSyncRequest.setAssignedState(ContainerAssignedStateType.CONTAINER_ASSIGNED);
		List<PBContainerCatchUpInfo> syncList = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			PBContainerCatchUpInfo.Builder pBContainerCatchUpInfo = PBContainerCatchUpInfo.newBuilder();
			pBContainerCatchUpInfo.setCommand(SyncFunctionType.INSERT);
			pBContainerCatchUpInfo.setEventId(i);
			pBContainerCatchUpInfo.setExternalId("test");
			pBContainerCatchUpInfo.setVersion(i);
			syncList.add(pBContainerCatchUpInfo.build());
		}
		pBContainerSyncRequest.addAllContainerSyncInfo(syncList);
		System.out.println(pBContainerSyncRequest.toString());

	}

	private void recoverConatainerData() {
		String sql = "update CONTAINERS set TEMPLATE_SIZE =15680 ,VERSION =0 ,RECORD_COUNT=0 where CONTAINER_ID=1";
		jdbcTemplate.update(sql);
		jdbcTemplate.execute("COMMIT");
	}

}
