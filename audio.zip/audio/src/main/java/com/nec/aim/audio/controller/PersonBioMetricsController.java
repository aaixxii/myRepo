package com.nec.aim.audio.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nec.aim.audio.persistence.entity.PersonBioMetrics;
import com.nec.aim.audio.persistence.repository.PersonBioMetricsRepository;

@RequestMapping("/pernsonBio")
@RestController
public class PersonBioMetricsController {
  @Autowired
  private PersonBioMetricsRepository pRepository;

  @GetMapping("/{id}")
  public Optional<PersonBioMetrics> findById(@PathVariable Long id) {
    return this.pRepository.findById(id);
  }
  
  @GetMapping("/all")
  public List<PersonBioMetrics> getAll() {
    return this.pRepository.findAll();
  }  
}
