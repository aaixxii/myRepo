package com.nec.aim.audio;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.nec.wrapper.SpeakerDiarizationWrapper;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AudioApplicationTests {

	@Test
	public void contextLoads() {
		String tmp = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		int index = tmp.lastIndexOf("audio");
		String rootPath = tmp.substring(0, index + 5);
		String toolPath = rootPath + "/SpeakerDiarization_JNI/data/trump_hillary_caster.mp3";
		String configPath = rootPath + "/SpeakerDiarization_JNI/config";		
		 SpeakerDiarizationWrapper SDWrap = new SpeakerDiarizationWrapper();
		 String strXml = SDWrap.Diariztion("D:\\ICF_AutoCapsule_disabled\\audio\\SpeakerDiarization_JNI\\data\\trump_hillary_caster.mp3"
, "D:\\ICF_AutoCapsule_disabled\\audio\\SpeakerDiarization_JNI\\config");
		 System.out.println(strXml);
		 
	}

}
