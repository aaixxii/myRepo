import com.nec.wrapper.SpeakerDiarizationWrapper;


public class TestDiarization{
    public static void main(String[] args){
        SpeakerDiarizationWrapper SDWrap = new SpeakerDiarizationWrapper();

	    String strXml = SDWrap.Diariztion("data\\trump_hillary_caster.mp3", "config");
	    System.out.println(strXml);
     
   }
}
