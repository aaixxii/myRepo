package jp.co.nec.aim.mm.partition;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PartitionUtilTestReduce {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}	
	
	private  long caculateHashAtThisToday(LocalDate thisDay) {
		Long saveDays = 11L;
		Long adjust = 5L;
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + adjust.longValue()) % (saveDays.longValue());
	}
	
	@Test
	public void testcaculate11HashAtThisToday() {
		String date = "2020-04-03";
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate thisDay = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));
		long todayHashValue = caculateHashAtThisToday(thisDay);
		System.out.print(todayHashValue);
	}	
	
	public long caculate5NewAdjustAtThisDay(long newN, LocalDate firstAddDay) {
		Long oldSaveDays = 11L;		
		long firstAddDayHashValue = caculateHashAtThisToday(firstAddDay);
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstAddDay);
		long quotient = epochDays/oldSaveDays.longValue();
		long deltaX = oldSaveDays * quotient + firstAddDayHashValue - epochDays;
		long X = (epochDays + deltaX) % oldSaveDays;
		long Y = epochDays % newN;		
		long adjustNew = (X - Y + newN) % newN;		
		return adjustNew;
		//long hashNew = (epochDays + adjustNew) % newN;
	}
	
	@Test
	public void testcaculate5NewAdjustAtThisDay() {
		String date = "2020-04-17";
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate thisDay = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));		
		long adjust = caculate5NewAdjustAtThisDay(5l, thisDay);
		System.out.print(adjust);
	}
	
	@Test
	public void testcaculateNewAdjustAtThisDay() {
		String firstDayStr = "2020-04-17";		
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate firstDay = LocalDate.parse(firstDayStr, DateTimeFormatter.ofPattern(DATE_FORMAT));
		 long adjust = caculate5NewAdjustAtThisDay(5l, firstDay);
		 LocalDate epoch = LocalDate.ofEpochDay(0);
		 String date = "2020-04-26";
		 LocalDate at21Day = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));
		 long epochDays = ChronoUnit.DAYS.between(epoch, at21Day);
		 long hashNew = (epochDays + adjust) % 5;
		System.out.print(hashNew);
	}
}
