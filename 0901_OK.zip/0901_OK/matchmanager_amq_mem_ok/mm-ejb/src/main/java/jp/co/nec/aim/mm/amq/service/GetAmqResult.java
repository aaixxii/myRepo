package jp.co.nec.aim.mm.amq.service;


@FunctionalInterface
public interface GetAmqResult<T> {
	 void accept(T amqResult) throws Throwable;
}
