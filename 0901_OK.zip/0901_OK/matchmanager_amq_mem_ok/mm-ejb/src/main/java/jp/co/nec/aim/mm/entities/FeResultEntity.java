package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the FE_RESULTS database table.
 * 
 */
@Entity
@Table(name = "FE_RESULTS")
public class FeResultEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "RESULT_ID")
	private long resultId;

	@Column(name = "JOB_ID")
	private long jobId;

	@Column(name = "RESULT_DATA")
	private byte[] resultData;

	@Column(name = "TEMPLATE_INDEX")
	private int templateIndex;

	@Column(name = "TEMPLATE_KEY")
	private String templateKey;

	public FeResultEntity() {
	}

	public long getResultId() {
		return this.resultId;
	}

	public void setResultId(long resultId) {
		this.resultId = resultId;
	}

	public long getJobId() {
		return this.jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public byte[] getResultData() {
		return this.resultData;
	}

	public void setResultData(byte[] resultData) {
		this.resultData = resultData;
	}

	public int getTemplateIndex() {
		return this.templateIndex;
	}

	public void setTemplateIndex(int templateIndex) {
		this.templateIndex = templateIndex;
	}

	public String getTemplateKey() {
		return this.templateKey;
	}

	public void setTemplateKey(String templateKey) {
		this.templateKey = templateKey;
	}

}