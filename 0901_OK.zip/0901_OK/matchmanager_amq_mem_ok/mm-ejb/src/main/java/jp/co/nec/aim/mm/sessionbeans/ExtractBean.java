package jp.co.nec.aim.mm.sessionbeans;

import static jp.co.nec.aim.mm.constants.MMConfigProperty.INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT;

import java.util.Objects;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.UidTimeoutException;
import jp.co.nec.aim.mm.hazelcast.HazelcastService;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.procedure.FeJobProcedures;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ExtractBean {
	
	private static Logger log = LoggerFactory.getLogger(ExtractBean.class);
	
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;	
	
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	
	private FEJobDao feJobDao;
	private FunctionDao functionDao;
	private SystemConfigDao sysConfigDao;
	private FeJobProcedures feJobProcedures;
	

	public ExtractBean() {
		// zero-arg ctor for container.
	}

	@PostConstruct
	public void init() {		
		this.feJobDao = new FEJobDao(manager);
		this.functionDao = new FunctionDao(manager);
		this.sysConfigDao = new SystemConfigDao(manager);
		this.feJobProcedures = new FeJobProcedures(dataSource);		
		feJobDao = new FEJobDao(manager);
	}
	
	public byte[] doExtract(String inquiryRequest, String refId, String requestId, String url) {
		FunctionTypeEntity fte = functionDao.getExtractFunction();
		if (fte == null) {
			AimError dbErr = AimError.SYNC_FUNCTIONTYPE;
			throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(),
					String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
		}
		Long newFeJobId = null;
		try {
			newFeJobId = feJobProcedures.createNewFeJob(refId, requestId, UidRequestType.Identify.name(),
					inquiryRequest);
		} catch (Exception e1) {
			feJobDao.deleteExtractJob(newFeJobId);	
			AimError dbErr = AimError.SYNC_DB;			
			throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(),
					String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
		}

		JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
				String.format("create extract job id: %s", newFeJobId));
		Integer syncJobWaitTime = sysConfigDao.getMMPropertyInt(INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT);
		if (Objects.isNull(syncJobWaitTime) || syncJobWaitTime < 0) {
			syncJobWaitTime = 100000;
		}
		String key = String.valueOf(newFeJobId.longValue());
		Long extractJoblocker = Long.valueOf(key);
		//AimManager.saveToExtractLockQueue(key, extractJoblocker);
		HazelcastService.getInstance().saveToExtractLockQueue(key, extractJoblocker);
		Optional<PBMuExtractJobResultItem> onejobResult = null;
		synchronized (extractJoblocker) {
			long startGetExtResultTime = System.currentTimeMillis();
			try {
				extractJoblocker.wait(syncJobWaitTime);
			} catch (InterruptedException e) {
				log.error(e.getMessage(), e);
				Thread.currentThread().interrupt();
			}
			try {
				//onejobResult = Optional.ofNullable(AimManager.getExtractJobResult(key));
				onejobResult = Optional.ofNullable(HazelcastService.getInstance().getExtractJobResult(key));
			} catch (NullPointerException e) {
				log.warn("can't get extractResponse, it may be timeout.");
				AimError aimErr = AimError.INQ_INTERNAL;
				String errMsg = String.format(e.getMessage() + "inquiry exract internal error.");
				aimErr.setMessage(errMsg);
				throw new UidTimeoutException(aimErr.getErrorCode(), aimErr.getMessage(),
						String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
			}
			if (onejobResult.isPresent()) {
				log.info("Get insert by url jobId({}) result success", newFeJobId);
				long endGetResultTime = System.currentTimeMillis();
				log.info("*****MM get insert by url job results used time = {}****",
						endGetResultTime - startGetExtResultTime);
			} else {
				log.warn("Got empty PBMuExtractJobResultItem, key={}", key);
				long currentTime = System.currentTimeMillis();
				if (currentTime - startGetExtResultTime >= syncJobWaitTime) {
					log.warn("Timeout is happend! the waiting time = ({}), jobId({})",
							currentTime - startGetExtResultTime, newFeJobId.longValue());
					AimError timeoutErr = AimError.JOB_TIMEOUT;
					String errMsg = String.format(timeoutErr.getMessage() +  " .sync insert by url job timeout.");
					timeoutErr.setMessage(errMsg);
					throw new UidTimeoutException(timeoutErr.getErrorCode(), timeoutErr.getMessage(),
							String.valueOf(System.currentTimeMillis()), timeoutErr.getUidCode());
				}
			}
		}
		//AimManager.finishExtractJob(key);
		HazelcastService.getInstance().finishExtractJob(key);
		byte[] extResult = onejobResult.get().getBisonTemplate().toByteArray();
		return extResult;
	}
}
