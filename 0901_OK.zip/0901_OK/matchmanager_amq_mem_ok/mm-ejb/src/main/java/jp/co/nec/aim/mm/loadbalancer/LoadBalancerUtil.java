package jp.co.nec.aim.mm.loadbalancer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import jp.co.nec.aim.mm.entities.UnitSegMap;
import jp.co.nec.aim.mm.util.CollectionsUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility Class for SLB.
 * 
 * @author mozj
 * 
 */
public class LoadBalancerUtil {
	private static final Logger slbLog = LoggerFactory.getLogger("slb");

	/**
	 * Create SLB boolean matrix from List of UnitSegMap
	 * 
	 * @param unitSegMaps
	 *            List of UnitSegMap
	 * @param segIds
	 *            List of Segment Ids
	 * @param unitIdList
	 *            List of unit Ids
	 * @return boolean matrix of SLB result. If there is no UnitSegMap, returns
	 *         0 size matrix.
	 */
	public boolean[][] createMatrix(List<UnitSegMap> unitSegMaps,
			List<Long> segIds, List<Long> unitIdList) {
		if (unitSegMaps == null) {
			throw new IllegalArgumentException("unitSegMaps == null");
		}
		if (segIds == null) {
			throw new IllegalArgumentException("segIds == null");
		}
		if (unitIdList == null) {
			throw new IllegalArgumentException("unitIdList == null");
		}

		boolean[][] matrix = new boolean[unitIdList.size()][segIds.size()];

		for (UnitSegMap unitSegMap : unitSegMaps) {
			long unitId = unitSegMap.getUnitId();
			long segmentId = unitSegMap.getSegmentId();
			int unitIndex = unitIdList.indexOf(unitId);
			int segIndex = segIds.indexOf(segmentId);
			if (unitIndex != -1 && segIndex != -1) {
				matrix[unitIndex][segIndex] = true;
			}
		}
		return matrix;
	}

	/**
	 * Find UnitSegMap which does not exist in unitSegMaps1 but exists in
	 * unitSegMaps2
	 * 
	 * @param unitSegMaps1
	 * @param unitSegMaps2
	 * @return Map<Long, List<UnitSegMap>>
	 */
	private Map<Long, List<UnitSegMap>> findAddedUnitSegMap(
			List<UnitSegMap> unitSegMaps1, List<UnitSegMap> unitSegMaps2) {
		// key is SEGMENT_ID, value is list of UnitSegMap, sorted by
		// SEGMENT_ID
		Map<Long, List<UnitSegMap>> addedMap = new TreeMap<Long, List<UnitSegMap>>();
		for (UnitSegMap unitSegMap2 : unitSegMaps2) {
			boolean exists = false;
			for (UnitSegMap unitSegMap1 : unitSegMaps1) {
				if (unitSegMap1.equals(unitSegMap2)) {
					exists = true;
					break;
				}
			}
			if (!exists) {
				List<UnitSegMap> list = addedMap.get(new Long(unitSegMap2
						.getSegmentId()));
				if (list == null) {
					list = new ArrayList<UnitSegMap>();
					addedMap.put(new Long(unitSegMap2.getSegmentId()), list);
				}
				list.add(unitSegMap2);
			}
		}
		return addedMap;
	}

	/**
	 * Find UnitSegMap which exists in unitSegMaps1 but does not exist in
	 * unitSegMaps2
	 * 
	 * @param unitSegMaps1
	 * @param unitSegMaps2
	 * @return List of UnitSegMap
	 */
	private Map<Long, List<UnitSegMap>> findRemovedUnitSegMap(
			List<UnitSegMap> unitSegMaps1, List<UnitSegMap> unitSegMaps2) {
		// key is SEGMENT_ID, value is list of UnitSegMap, sorted by
		// SEGMENT_ID
		Map<Long, List<UnitSegMap>> removedMap = new TreeMap<Long, List<UnitSegMap>>();
		for (UnitSegMap unitSegMap1 : unitSegMaps1) {
			boolean exists = false;
			for (UnitSegMap unitSegMap2 : unitSegMaps2) {
				if (unitSegMap1.equals(unitSegMap2)) {
					exists = true;
					break;
				}
			}
			if (!exists) {
				List<UnitSegMap> list = removedMap.get(new Long(unitSegMap1
						.getSegmentId()));
				if (list == null) {
					list = new ArrayList<UnitSegMap>();
					removedMap.put(new Long(unitSegMap1.getSegmentId()), list);
				}
				list.add(unitSegMap1);
			}
		}
		return removedMap;
	}

	/**
	 * Create SLB List of UnitSegMap from boolean matrix
	 * 
	 * @param matrix
	 *            boolean matrix of SLB result
	 * @param segIds
	 *            List of Segment Ids
	 * @param unitIds
	 *            List of unit Ids
	 * @return List of UnitSegMap
	 */
	public List<UnitSegMap> createUnitSegMaps(boolean[][] matrix,
			List<Long> segIds, List<Long> unitIds) {
		if (matrix == null) {
			throw new IllegalArgumentException("matrix == null");
		}
		if (segIds == null) {
			throw new IllegalArgumentException("segIds == null");
		}
		if (unitIds == null) {
			throw new IllegalArgumentException("unitIds == null");
		}
		if (matrix.length != unitIds.size()) {
			throw new IllegalArgumentException("matrix.length != units.size()");
		}
		if (matrix.length == 0) {
			slbLog.info("matrix.length == 0");
			return null;
		}
		if (segIds.size() == 0) {
			slbLog.info("segIds.size() == 0");
			return null;
		}

		List<UnitSegMap> unitSegMaps = new ArrayList<UnitSegMap>();

		for (int unitIndex = 0; unitIndex < unitIds.size(); unitIndex++) {
			long unitId = unitIds.get(unitIndex);
			for (int segIndex = 0; segIndex < segIds.size(); segIndex++) {
				if (matrix[unitIndex][segIndex]) {
					long segmentId = segIds.get(segIndex);
					UnitSegMap map = new UnitSegMap();
					map.setUnitId(unitId);
					map.setSegmentId(segmentId);
					unitSegMaps.add(map);
				}
			}
		}

		return unitSegMaps;
	}

	/**
	 * 
	 * @param preUnitSegMaps
	 * @param unitSegMaps
	 */
	public void exportSLBLog(List<UnitSegMap> preUnitSegMaps,
			List<UnitSegMap> unitSegMaps) {
		// pre SLB UnitIds and SegmentIds
		List<Long> preUnitIds = new ArrayList<Long>();
		List<Long> preSegmentIds = new ArrayList<Long>();
		for (UnitSegMap unitSegMap : preUnitSegMaps) {
			long unitId = unitSegMap.getUnitId();
			long segmentId = unitSegMap.getSegmentId();
			if (!preUnitIds.contains(unitId)) {
				preUnitIds.add(unitId);
			}
			if (!preSegmentIds.contains(segmentId)) {
				preSegmentIds.add(segmentId);
			}
		}

		// SLB UnitIds and SegmentIds
		List<Long> unitIds = new ArrayList<Long>();
		List<Long> segmentIds = new ArrayList<Long>();
		for (UnitSegMap unitSegMap : unitSegMaps) {
			long unitId = unitSegMap.getUnitId();
			long segmentId = unitSegMap.getSegmentId();
			if (!unitIds.contains(unitId)) {
				unitIds.add(unitId);
			}
			if (!segmentIds.contains(segmentId)) {
				segmentIds.add(segmentId);
			}
		}

		// add Unit
		List<Long> unitAddedIds = new ArrayList<Long>();
		unitAddedIds.addAll(unitIds);
		unitAddedIds.removeAll(preUnitIds);
		exportUnitLog(unitAddedIds, "Added");

		// remove Unit
		List<Long> unitRemoveddIds = new ArrayList<Long>();
		unitRemoveddIds.addAll(preUnitIds);
		unitRemoveddIds.removeAll(unitIds);
		exportUnitLog(unitRemoveddIds, "Removed");

		// add Segment
		List<Long> segAddedIds = new ArrayList<Long>();
		segAddedIds.addAll(segmentIds);
		segAddedIds.removeAll(preSegmentIds);
		exportSegmentLog(segAddedIds, "Added");

		// remove Segment
		List<Long> segRemoveddIds = new ArrayList<Long>();
		segRemoveddIds.addAll(preSegmentIds);
		segRemoveddIds.removeAll(segmentIds);
		exportSegmentLog(segRemoveddIds, "Removed");

		// Moved mu-segment
		exportMovedSegmentLog(preUnitSegMaps, unitSegMaps);
	}

	/**
	 * 
	 * @param ids
	 * @param action
	 */
	private void exportSegmentLog(List<Long> ids, String action) {
		if (CollectionsUtil.isEmpty(ids)) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		sb.append(action);
		sb.append(" SEGMETN_IDs = ");
		for (Long id : ids) {
			sb.append(id);
			sb.append(", ");
		}
		sb.delete(sb.length() - ", ".length(), sb.length());
		slbLog.info(sb.toString());
	}

	/**
	 * 
	 * @param unitIds
	 * @param action
	 */
	private void exportUnitLog(List<Long> unitIds, String action) {
		if (CollectionsUtil.isEmpty(unitIds)) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		sb.append(action);
		sb.append(" MU_IDs = ");
		for (Long unitId : unitIds) {
			sb.append(unitId);
			sb.append(", ");
		}
		sb.delete(sb.length() - ", ".length(), sb.length());
		slbLog.info(sb.toString());
	}

	/**
	 * 
	 * @param preUnitSegMaps
	 * @param unitSegMaps
	 */
	private void exportMovedSegmentLog(List<UnitSegMap> preUnitSegMaps,
			List<UnitSegMap> unitSegMaps) {

		Map<Long, List<UnitSegMap>> addedMap = findAddedUnitSegMap(
				preUnitSegMaps, unitSegMaps);
		Map<Long, List<UnitSegMap>> removedMap = findRemovedUnitSegMap(
				preUnitSegMaps, unitSegMaps);

		Set<Long> removedKey = removedMap.keySet();
		Set<Long> addedKey = addedMap.keySet();
		Set<Long> mergedKey = new TreeSet<Long>();

		mergedKey.addAll(removedKey);
		mergedKey.addAll(addedKey);

		boolean firstSLB = CollectionsUtil.isEmpty(preUnitSegMaps);
		for (Long segmentId : mergedKey) {
			List<UnitSegMap> removed = removedMap.get(segmentId);
			List<UnitSegMap> added = addedMap.get(segmentId);
			exportMuSegMapLog(firstSLB, "Removed", removed);
			exportMuSegMapLog(firstSLB, "Added", added);
		}
	}

	/**
	 * 
	 * @param firstSLB
	 * @param action
	 * @param unitSegMaps
	 */
	private void exportMuSegMapLog(boolean firstSLB, String action,
			List<UnitSegMap> unitSegMaps) {
		if (CollectionsUtil.isEmpty(unitSegMaps)) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		sb.append(action);
		sb.append(" {SEMENT_ID, MU_ID} = ");
		for (UnitSegMap unitSegMap : unitSegMaps) {
			sb.append("{");
			sb.append(unitSegMap.getSegmentId());
			sb.append(", ");
			sb.append(unitSegMap.getUnitId());
			sb.append("}");
			sb.append(", ");
		}
		sb.delete(sb.length() - ", ".length(), sb.length());
		if (firstSLB) {
			slbLog.debug(sb.toString());
		} else {
			slbLog.info(sb.toString());
		}
	}
}