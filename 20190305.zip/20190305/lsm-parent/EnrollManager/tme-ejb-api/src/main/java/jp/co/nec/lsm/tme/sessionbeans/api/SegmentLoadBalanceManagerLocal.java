package jp.co.nec.lsm.tme.sessionbeans.api;

import javax.ejb.Local;

/**
 * @author mozj <br>
 * 
 */
@Local
public interface SegmentLoadBalanceManagerLocal {

	/**
	 * get boolean[][] for new MU-Segment Maps, and update changes into DB
	 * 
	 * 1. prepare Parameters for redeploy
	 * 
	 * 2. get boolean[][] for new MU-Segment Maps
	 * 
	 * 3. update changes into DB
	 * 
	 * @return boolean[][] for new MU-Segment Maps
	 * @throws EnrollDeployException
	 */
	public void excuteSLB();

}
