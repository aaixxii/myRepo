package jp.co.nec.lsm.tme.sessionbeans.api;

import javax.ejb.Local;

/**
 * @author mozj <br>
 * 
 */
@Local
public interface EnrollSegmentSyncServiceLocal {
	public void synchronizeSegment(long batchJobId);
}
