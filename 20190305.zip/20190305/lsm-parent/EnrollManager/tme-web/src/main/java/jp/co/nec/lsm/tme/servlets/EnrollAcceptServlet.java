package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServletRequestUtil;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.exception.DuplicateEnrollBatchJobException;
import jp.co.nec.lsm.tme.exception.EmptyRequestIDException;
import jp.co.nec.lsm.tme.sessionbeans.api.EnrollAcceptServiceLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

/**
 * @author mozj Accept Enroll batch job from transformer or Identify server and
 *         add the enroll request into local enroll queue.
 * 
 * @web.servlet name="EnrollAcceptServletRemote"
 * @web.servlet-mapping url-pattern="/EnrollAccept"
 */
public class EnrollAcceptServlet extends AbstractTMServlet {

	/**
	 * serialVersionUID value
	 */
	private static final long serialVersionUID = 1574015561334122999L;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollAcceptServlet.class);

	/** Enroll Accept Service instance **/
	@EJB
	private EnrollAcceptServiceLocal enrollAcceptService;

	/**
	 * initiate
	 * 
	 * @see javax.servlet.GenericServlet#init()
	 */
	public void init() throws ServletException {

	}

	/**
	 * parse EnrollRequest instance from Stream and add the enroll request into
	 * local enroll queue.
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		printLogMessage("start public function doGet()..");

		if (ServletRequestUtil.isRequestContextSizeEmpty(req)) {
			log.warn("Received an empty POST request.");
			return;
		}

		if (isSystemExpiredOrPassive()) {
			log.warn("TME is expired or passive, reject all jobs.");
			return;
		}

		EnrollRequest enrollRequest = null;
		List<CPBBusinessMessage> businessMessageList;
		try {
			// parse EnrollRequest instance from Stream
			enrollRequest = EnrollRequest.parseFrom(req.getInputStream());

			businessMessageList = new ArrayList<CPBBusinessMessage>();
			for (ByteString byteString : enrollRequest.getBusinessMessageList()) {
				try {
					CPBBusinessMessage businessMessage = CPBBusinessMessage
							.parseFrom(byteString);
					businessMessageList.add(businessMessage);
				} catch (InvalidProtocolBufferException ex) {
					log.error("error occured in parse CPBBusinessMessage."
							+ " skip this top level job.", ex);
				}
			}

			if (log.isInfoEnabled()) {
				int totalCount = enrollRequest.getBusinessMessageCount();
				int receiveCount = businessMessageList.size();
				log.info("The CPBBusinessMessages from transformer "
						+ "serialize completely, reject job count: {}, "
						+ "receive job count: {}, total count: {}",
						new Object[] { totalCount - receiveCount, receiveCount,
								totalCount });
			}

			validateRequest(enrollRequest, businessMessageList);

		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpServletResponse.SC_BAD_REQUEST,
					ex.getMessage(), ex);
			return;
		}

		try {
			// add the enroll request into local enroll queue.
			enrollAcceptService.doAccept(enrollRequest.getBatchJobId(),
					enrollRequest.getType(), businessMessageList);
		} catch (Exception ex) {
			Throwable exception = ex.getCause() == null ? ex : ex.getCause();
			if (exception instanceof DuplicateEnrollBatchJobException) {
				writeErrorToResponse(req, res,
						HttpServletResponse.SC_BAD_REQUEST, ex.getMessage(), ex);
			} else if (exception instanceof EmptyRequestIDException) {
				writeErrorToResponse(req, res,
						HttpServletResponse.SC_BAD_REQUEST, ex.getMessage(), ex);
			} else {
				writeErrorToResponse(req, res,
						HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ex
								.getMessage(), ex);
			}
			return;
		}
		printLogMessage("end public function doGet()..");
	}

	/**
	 * parse EnrollRequest instance from Stream and add the enroll request into
	 * local enroll queue.
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}

	/**
	 * isSystemExpiredOrPassive
	 * 
	 * @return
	 */
	private boolean isSystemExpiredOrPassive() {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();
		if (jobGetter.isStop() || jobGetter.isStandBy()) {
			return true;
		}
		return false;
	}

	/**
	 * validate all data in enroll request whether there are correct.
	 * 
	 * @param request
	 *            enroll request from Transformer
	 * @return false: there are incorrect data in enroll request. true: all data
	 *         in enroll request are correct.
	 */
	private void validateRequest(EnrollRequest enrollRequest,
			List<CPBBusinessMessage> businessMessageList) {
		printLogMessage("start private function validateRequest().");

		enrollAcceptService.validateRequest(enrollRequest, businessMessageList);

		// all data in enroll request are correct.
		printLogMessage("end private function validateRequest().");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
