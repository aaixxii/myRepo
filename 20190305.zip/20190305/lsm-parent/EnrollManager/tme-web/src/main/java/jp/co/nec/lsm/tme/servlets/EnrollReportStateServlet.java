package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.proto.segment.ReportStateRequestProto.ReportStateRequest;
import jp.co.nec.lsm.proto.segment.ReportStateResponseProto.ReportStateResponse;
import jp.co.nec.lsm.tm.common.constants.ReportResponseReturnStatus;
import jp.co.nec.lsm.tm.common.core.jobs.ReportResponseReturn;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServletRequestUtil;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollStatusManagerBean;

/**
 * @author mozj
 * @web.servlet name="EnrollReportStateServlet"
 * @web.servlet-mapping url-pattern="/HeartBeat"
 */
public class EnrollReportStateServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6221588064740175669L;
	private static final Logger log = LoggerFactory
			.getLogger(EnrollReportStateServlet.class);
	
	@EJB
	private EnrollStatusManagerBean statusManager;

	public void init() throws ServletException {

	}

	/**
	 * Gets information about the segment, then constructs the segment file
	 * using the SegmentFileCreator helper object. Sends the resulting file out
	 * via the HttpServletResponse's output stream.
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		if (ServletRequestUtil.isRequestContextSizeEmpty(req)) {
			log.warn("Received an empty POST request");
			return;
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		ReportStateRequest reportStateRequest = null;
		try {
			reportStateRequest = ReportStateRequest.parseFrom(req
					.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpServletResponse.SC_BAD_REQUEST,
					"parse ExtractJobRequest object error", ex);
			return;
		}

		ReportResponseReturn reportResponseReturn = null;
		try {
			reportResponseReturn = statusManager
					.reportState(reportStateRequest);
		} catch (Exception ex) {
			writeErrorToResponse(req, res,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"enroll report state error.", ex);
			return;
		}
		// get response Status
		ReportResponseReturnStatus responseStatus = reportResponseReturn
				.getReturnStatus();

		// if unit is not enter in match unit
		// or state not in working status
		if (responseStatus == ReportResponseReturnStatus.REPORT_UNIT_STATUS_UNNORMAL) {
			res.setStatus(HttpServletResponse.SC_SEE_OTHER);
			res.setContentLength(0);
			log.warn("UNIT_ID " + reportStateRequest.getGmvId()
					+ " is not in WORKING state."
					+ " Sending ReEnter signal, HTTP code "
					+ HttpServletResponse.SC_SEE_OTHER);
		}
		// else slb flag is on and return the response normally
		else if (responseStatus == ReportResponseReturnStatus.REPORT_NORMAL_RETURNED) {

			ReportStateResponse reportStateResponse = reportResponseReturn
					.getReportStateResponse();
			// add ContentType,ContentLength,Status
			res.setContentType("application/octet-stream");
			res.setContentLength(reportStateResponse.getSerializedSize());
			res.setStatus(HttpServletResponse.SC_OK);
			reportStateResponse.writeTo(res.getOutputStream());
			res.flushBuffer();
		}

		stopWatch.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_REPORT_STATE_SERVLET_TME,
				LogConstants.FUNCTION_DO_POST, stopWatch.getTime());
	}

}
