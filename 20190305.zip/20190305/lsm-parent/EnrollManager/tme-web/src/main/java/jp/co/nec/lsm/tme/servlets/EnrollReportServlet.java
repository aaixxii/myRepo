package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResultRequest;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServletRequestUtil;
import jp.co.nec.lsm.tme.service.pojo.EnrollReportServiceBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj update extract result into the extract jobs of the local enroll
 *         queue. and notify that Batch Job Completed
 * 
 * @web.servlet name="EnrollReportServletRemote"
 * @web.servlet-mapping url-pattern="/EnrollReport"
 */
public class EnrollReportServlet extends AbstractTMServlet {
	/**
	 * serialVersionUID value
	 */
	private static final long serialVersionUID = 6719111829920781660L;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollReportServlet.class);

	/** Enroll Report Service instance **/
	private EnrollReportServiceBean enrollReportService;

	public void init() throws ServletException {
		enrollReportService = new EnrollReportServiceBean();
	}

	/**
	 * update extract result into the extract jobs of the local enroll queue.
	 * and notify that Batch Job Completed
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		printLogMessage("start public function doGet()..");

		if (ServletRequestUtil.isRequestContextSizeEmpty(req)) {
			log.warn("Received an empty POST request");
			return;
		}

		ExtractJobResultRequest extractResultRequest = null;
		try {
			// parse ExtractResult instance from Stream
			extractResultRequest = ExtractJobResultRequest.parseFrom(req
					.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpServletResponse.SC_BAD_REQUEST,
					"parse ExtractJobRequest object error", ex);
			return;
		}

		try {
			// update extract result into the extract jobs of the local enroll
			// queue, and notify that Batch Job Completed
			enrollReportService.doReport(extractResultRequest);
		} catch (Exception ex) {
			writeErrorToResponse(req, res,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"enroll report error.", ex);
			return;
		}

		printLogMessage("end public function doGet()..");

	}

	/**
	 * update extract result into the extract jobs of the local enroll queue.
	 * and notify that Batch Job Completed
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
