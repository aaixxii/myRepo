package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.db.common.entityhelpers.ContactTimesSPHelper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = false)
public class ContactTimesSPHelperTest {

	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;

	@Before
	public void before() {
	}

	@Test
	public void testUpdateContactTimesBoth() throws SQLException,
			ParseException {
		try {
			prepateTestData();
			ContactTimesSPHelper.updateContactTimes(entityManager, 1, true,
					true);
			confirmBothTimestampUpdated();
		} finally {
			cleanTestData();
		}
	}

	@Test
	public void testUpdateContactTimesOnlyReport() throws SQLException,
			ParseException {
		try {
			prepateTestData();
			ContactTimesSPHelper.updateContactTimes(entityManager, 1, true,
					false);
			confirmOnlyHeartbeatTimestampUpdated();
		} finally {
			cleanTestData();
		}
	}

	@Test
	public void testUpdateContactTimesOnlyHeartBeat() throws SQLException,
			ParseException {
		try {
			prepateTestData();
			ContactTimesSPHelper.updateContactTimes(entityManager, 1, false,
					true);
			confirmOnlyReportTimestampUpdated();
		} finally {
			cleanTestData();
		}
	}

	private void prepateTestData() throws SQLException {

		cleanTestData();

		JdbcTemplate template = new JdbcTemplate(dataSource);
		String insertMatchUnit1 = "insert into match_units (mu_id, unique_id, state, type, "
				+ "revision, balanced_flag,ip_address) values(1, 1, 'stop', 1, 1, 1,'192.168.1.131')";
		template.update(insertMatchUnit1);
		String insertMuCantacts = "insert into mu_contacts (MU_ID, LAST_CONTACT_TS,"
				+ "LAST_REPORT_TS, IDLE_FLAG) values(1, "
				+ "to_timestamp('2006/02/21 00:00:00.000','yyyy/mm/dd hh24:mi:ss.ff3'),"
				+ "to_timestamp('2006/12/12 00:00:00.000','yyyy/mm/dd hh24:mi:ss.ff3'), 1)";
		template.update(insertMuCantacts);
		template.execute("commit");
	}

	private void confirmBothTimestampUpdated() throws ParseException {
		JdbcTemplate template = new JdbcTemplate(dataSource);
		// template.execute("delete from mu_contacts");

		String sql = "select last_contact_ts, last_report_ts from mu_contacts";
		Map<String, Object> map = template.queryForMap(sql);
		Timestamp lastContactTs = (Timestamp) map.get("LAST_CONTACT_TS");
		Timestamp lastReportTs = (Timestamp) map.get("LAST_REPORT_TS");
		// create data 2006/12/12
		Date date = create2006Dec12th();
		assertTrue(lastContactTs.after(date));
		assertTrue(lastReportTs.after(date));
	}

	private void confirmOnlyHeartbeatTimestampUpdated() throws ParseException {
		JdbcTemplate template = new JdbcTemplate(dataSource);
		// template.execute("delete from mu_contacts");

		String sql = "select last_contact_ts, last_report_ts from mu_contacts";
		Map<String, Object> map = template.queryForMap(sql);
		Timestamp lastContactTs = (Timestamp) map.get("LAST_CONTACT_TS");
		Timestamp lastReportTs = (Timestamp) map.get("LAST_REPORT_TS");
		// create data 2006/12/12
		Date date = create2006Dec12th();
		assertTrue(lastContactTs.after(date));
		Calendar cal = Calendar.getInstance();
		cal.setTime(lastReportTs);
		assertEquals(2006, cal.get(Calendar.YEAR));
		assertEquals(11, cal.get(Calendar.MONTH));
	}

	private void confirmOnlyReportTimestampUpdated() throws ParseException {
		JdbcTemplate template = new JdbcTemplate(dataSource);
		// template.execute("delete from mu_contacts");

		String sql = "select last_contact_ts, last_report_ts from mu_contacts";
		Map<String, Object> map = template.queryForMap(sql);
		Timestamp lastContactTs = (Timestamp) map.get("LAST_CONTACT_TS");
		Timestamp lastReportTs = (Timestamp) map.get("LAST_REPORT_TS");
		// create data 2006/12/12
		Date date = create2006Dec12th();
		assertTrue(lastReportTs.after(date));
		Calendar cal = Calendar.getInstance();
		cal.setTime(lastContactTs);
		assertEquals(2006, cal.get(Calendar.YEAR));
		assertEquals(1, cal.get(Calendar.MONTH));
	}

	private Date create2006Dec12th() throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd-HH:mm:ss");
		return format.parse("20061112-00:00:00");
	}

	private void cleanTestData() {
		JdbcTemplate template = new JdbcTemplate(dataSource);
		template.execute("delete from mu_contacts");
		template.execute("delete from match_units");
		template.execute("commit");
	}
}
