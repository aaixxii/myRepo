package jp.co.nec.lsm.tme.db.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.communication.PersonReferenceID;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.util.TMETestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollPersonBiometricDaoTest {

	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	@EJB
	EnrollPersonBiometricDao personBiometricDao;

	@Before
	public void setUp() {
		clearDatabase();
	}

	@After
	public void tearDown() {
		clearDatabase();
	}

	private ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	private LocalEnrollBatchJob prepareLocalEnrollBatchJobInfo(int startIds) {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		for (int i = 1; i <= 10; i++) {
			LocalExtractJobInfo extractjob = new LocalExtractJobInfo();
			extractjob.setJobId(i);
			extractjob.setTemplate(prepareTemplate(String.valueOf(i))
					.toByteArray());

			extractjob.setReferenceId("reference123456789123456789123456"
					+ (i + startIds));
			extractjob.setReturnCode(ReturnCode.JobSuccess);
			enrollBatchJob.putExtractJobInfo(extractjob);

		}
		return enrollBatchJob;
	}

	@Test
	public void testUpdateBiometrics() {

		updateDatabase();

		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";

		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		// one segment create.
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJobInfo(0);

		List<SegmentPosition> segPos = personBiometricDao.updateBiometrics(
				enrollBatchJob, duplicateIds, personReferenceIDList);

		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_segment_version_detail = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(10, list_person_biometrics.size());
		assertEquals(10, personReferenceIDList.size());

		assertEquals(1, list_segment_version_detail.size());
		assertEquals("0", list_segment_version_detail.get(0).get("VERSION")
				.toString());
		assertEquals("10", list_segment_version_detail.get(0).get(
				"RECORD_COUNT").toString());

		assertEquals(1, list_segments.size());
		assertEquals("0", list_segments.get(0).get("VERSION").toString());
		assertEquals("10", list_segments.get(0).get("RECORD_COUNT").toString());

		assertEquals(0, duplicateIds.size());

		assertEquals(1, segPos.size());
		assertEquals(0, segPos.get(0).getVersion());
	}

	@Test
	public void testUpdateBiometrics_DataAccessException() {
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJobInfo(100000);

		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		try {
			personBiometricDao.updateBiometrics(enrollBatchJob, duplicateIds,
					personReferenceIDList);

		} catch (EnrollRuntimeException ex) {
			return;
		} catch (Exception ex) {
		}

		fail();
	}

	@Test
	public void testUpdateBiometrics_Param_1() {
		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		try {
			personBiometricDao.updateBiometrics(null, duplicateIds,
					personReferenceIDList);
			fail();
		} catch (IllegalArgumentException ex) {
		} catch (Exception ex) {
			fail();
		}
	}

	@Test
	public void testUpdateBiometrics_Param_2() {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		try {
			personBiometricDao.updateBiometrics(enrollBatchJob, null,
					personReferenceIDList);
			fail();
		} catch (IllegalArgumentException ex) {
		} catch (Exception ex) {
			fail();
		}
	}

	@Test
	public void testUpdateBiometrics_Param_3() {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		List<String> duplicateIds = new ArrayList<String>();

		try {
			personBiometricDao.updateBiometrics(enrollBatchJob, duplicateIds,
					null);
			fail();
		} catch (IllegalArgumentException ex) {
		} catch (Exception ex) {
			fail();
		}
	}

	private void clearDatabase() {
		jdbcTemplate.execute("delete FROM PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
	}

	private void updateDatabase() {
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (1,'BEHAVIOR.MAX_SEGMENT_SIZE','204510')");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG(CONFIG_ID,"
				+ " PROPERTY_NAME, PROPERTY_VALUE) values(100, "
				+ "'PERSON_TEMPLATE_SIZE', '"
				+ TMETestUtil.PERSON_TEMPLATE_SIZE + "')");
	}
}
