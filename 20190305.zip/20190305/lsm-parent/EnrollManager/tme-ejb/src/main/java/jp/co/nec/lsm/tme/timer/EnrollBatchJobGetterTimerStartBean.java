package jp.co.nec.lsm.tme.timer;

import java.io.IOException;
import java.util.Collection;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.xml.ws.http.HTTPException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;

/**
 * @author xia <br>
 *         start GetEnrollBatchJobNormalTimer.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollBatchJobGetterTimerStartBean {
		
	private static Logger log = LoggerFactory
			.getLogger(EnrollBatchJobGetterTimerStartBean.class);

	@Resource
	TimerService timerService;
	private EnrollBatchJobGetterPollBean batchJobGetterPoll;

	@PostConstruct
	public void init() {
		printLogMessage("CNTR: EnrollBatchJobGetterTimerStartBean init");
	}

	/**
	 * constructor
	 */
	public EnrollBatchJobGetterTimerStartBean() {
	}

	/**
	 * 
	 */

	public void startTimer() {
		Timer timer = findTimerUsingName();
		if (timer == null) {
			log.info("REGISTERING NEW BATCHJOB GETTER TIMER");
			timerService.createTimer(EnrollConstants.POLLING_JOB_DURATION,
					EnrollConstants.TIMER_STARTED_BEAN);
		} else {
			log.info("TIMER ALREADY REGISTERED");
		}
	}

	private Timer findTimerUsingName() {
		Collection<Timer> existingTimers = timerService.getTimers();
		for (Object obj : existingTimers) {
			javax.ejb.Timer timer = (javax.ejb.Timer) obj;
			String scheduled = (String) timer.getInfo();
			if (scheduled != null
					&& scheduled.equals(EnrollConstants.TIMER_STARTED_BEAN)) {
				return timer;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param timer
	 * @throws IOException
	 * @throws HTTPException
	 */
	@Timeout
	public void timeout(javax.ejb.Timer timer) {

		EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
				.getInstance();
		while (!batchJobGetterTimer.isStop()) {
			long intervals = EnrollConstants.DEFAULT_INTERVAL;
			if (batchJobGetterTimer.isActive()) {
				if (batchJobGetterPoll == null) {
					try {
						lookUpPollBean();
					} catch (Exception e) {
						log
								.warn("EnrollBatchJobGetterPollBean has not bound yet.");
					}
				}

				try {
					if (batchJobGetterPoll != null) {
						batchJobGetterPoll.poll();
					}
				} catch (Exception e) {
					log.warn("EnrollBatchJobGetterPollBean poll error.", e);
				}
				Date nextGetJobTime = batchJobGetterTimer.getNextGetJobTime();

				if (nextGetJobTime != null) {
					intervals = nextGetJobTime.getTime()
							- DateUtil.getCurrentDate().getTime();
				}
			}

			try {
				batchJobGetterTimer.setSleepThread(Thread.currentThread());
				if(intervals <= 0){
					intervals = EnrollConstants.DEFAULT_INTERVAL;
				}
				Thread.sleep(intervals);
			} catch (Exception e) {
				log.warn("Thread sleep error.");
			}
		}
	}

	/**
	 * look up poll bean
	 */
	private void lookUpPollBean() {
		batchJobGetterPoll = ServiceLocator.getLookUpJndiObject(
				JNDIConstants.TME_BATCHJOB_GETTER_POLL_BEAN,
				EnrollBatchJobGetterPollBean.class);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
