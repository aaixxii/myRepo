package jp.co.nec.lsm.tme.core.jobs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DeletionJobManager {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(DeletionJobManager.class);

	private static DeletionJobManager deletionJobManager;

	private ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue;

	public synchronized static DeletionJobManager getInstance() {
		if (deletionJobManager == null) {
			deletionJobManager = new DeletionJobManager();
		}
		return deletionJobManager;
	}

	private DeletionJobManager() {
		deletionJobQueue = new ConcurrentLinkedQueue<LocalDeletionJob>();
	}

	/**
	 * get local enroll queue instance
	 * 
	 * @return local enroll queue instance
	 */
	public ConcurrentLinkedQueue<LocalDeletionJob> getDeletionJobQueue() {
		printLogMessage("called public function getDeletionJobQueue().");

		return deletionJobQueue;
	}

	/**
	 * add an enroll Batch Job into local deletion queue.
	 */
	public void enqueueDeletionJob(LocalDeletionJob deletionJob) {
		printLogMessage("start public function addEnrollBatchJob()..");
		synchronized (deletionJobQueue) {
			deletionJobQueue.add(deletionJob);
		}
		printLogMessage("end public function addEnrollBatchJob()..");

	}

	/**
	 * add an enroll Batch Job into local deletion queue.
	 */
	public LocalDeletionJob getDeletionJob(long batchJobId) {
		printLogMessage("start public function getDeletionJob()..");
		// loop the enroll local queue to get the enroll batch job.
		printLogMessage("get the delete batch job by batchJobId " + batchJobId);
		Iterator<LocalDeletionJob> iterator = deletionJobQueue.iterator();
		while (iterator.hasNext()) {
			LocalDeletionJob batchJob = iterator.next();
			if (batchJobId == batchJob.getBatchJobId()) {
				return batchJob;
			}
		}
		printLogMessage("end public function getDeletionJob()..");
		return null;
	}

	/**
	 * get Not Synchronized Deletion Job List
	 * 
	 * @return Deletion Job List
	 */
	public List<LocalDeletionJob> getNotSynchronizedDeletionJobs() {
		printLogMessage("start public function getNotSynchronizedDeletionJobs().");

		// loop the enroll local queue to get the enroll batch job.
		List<LocalDeletionJob> unSynchedDeletionJobs = new ArrayList<LocalDeletionJob>();

		Iterator<LocalDeletionJob> iterator = deletionJobQueue.iterator();
		while (iterator.hasNext()) {
			LocalDeletionJob batchJob = iterator.next();
			if (batchJob != null && !batchJob.isSynchronized()) {
				unSynchedDeletionJobs.add(batchJob);
			}
		}

		if (unSynchedDeletionJobs.isEmpty()) {
			return unSynchedDeletionJobs;
		}

		LocalDeletionJob[] arrays = new LocalDeletionJob[unSynchedDeletionJobs
				.size()];

		Arrays.sort(unSynchedDeletionJobs.toArray(arrays),
				new Comparator<LocalDeletionJob>() {
					@Override
					public int compare(final LocalDeletionJob entry1,
							final LocalDeletionJob entry2) {
						return compareOrderBySegmentIdAndVersion(entry1, entry2);
					}
				});

		printLogMessage("Not synchronized deletion jobs count: "
				+ unSynchedDeletionJobs.size());

		printLogMessage("end public function getNotSynchronizedDeletionJobs().");

		return Arrays.asList(arrays);
	}

	/**
	 * 
	 * @param entry1
	 * @param entry2
	 * @return
	 */
	private int compareOrderBySegmentIdAndVersion(LocalDeletionJob entry1,
			LocalDeletionJob entry2) {
		if (entry1.getSegmentId() == entry2.getSegmentId()
				&& entry1.getVersion() < entry2.getVersion()) {
			return -1;
		} else if (entry1.getSegmentId() < entry2.getSegmentId()) {
			return -1;
		}
		return 1;
	}

	/**
	 * delete Deletion Job
	 * 
	 * @param batchJob
	 * @return
	 */
	public boolean deleteDeletionJob(LocalDeletionJob deletionJob) {
		printLogMessage("start public function deleteDeletionJob().");
		synchronized (deletionJobQueue) {

			boolean bResult = deletionJobQueue.remove(deletionJob);

			printLogMessage("start public function deleteDeletionJob().");

			return bResult;
		}
	}

	/**
	 * get enrollinkQueue Summary
	 * 
	 * @return Summary Information
	 */
	public String getSummary() {
		printLogMessage("start public function getSummary()..");

		StringBuffer stringBuffer = new StringBuffer();
		// get identifyLinkQueue iterator
		Iterator<LocalDeletionJob> iterator = deletionJobQueue.iterator();

		// do loop until find a instance match batchJobId
		while (iterator.hasNext()) {
			LocalDeletionJob deletionJob = iterator.next();
			if (deletionJob == null) {
				printLogMessage("this deletionJobQueue instance is null");

				continue;
			}

			stringBuffer.append("\n");
			stringBuffer
					.append("======================================================");
			stringBuffer.append("\n");

			stringBuffer.append(deletionJob.getSummary());

			stringBuffer
					.append("======================================================");
			stringBuffer.append("\n");
		}

		printLogMessage("end public function getSummary()..");

		return stringBuffer.toString();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
