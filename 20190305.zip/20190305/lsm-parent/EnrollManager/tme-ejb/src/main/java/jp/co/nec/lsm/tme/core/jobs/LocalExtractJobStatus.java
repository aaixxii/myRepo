package jp.co.nec.lsm.tme.core.jobs;

/**
 * @author zhulk <br>
 * 
 */
public enum LocalExtractJobStatus {
	READY,EXTRACTING,DONE
}
