package jp.co.nec.lsm.event.enroll.common;

/**
 * @author mozj
 */
public final class EnrollEventConstants {
	public static final String DEFAULT_IP_ADDRESS = "127.0.0.1";
}
