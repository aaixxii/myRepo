package jp.co.nec.lsm.tma.service.sessionbean;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tma.common.util.AggregationEventBus;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.db.dao.AggregationSystemConfigDao;
import jp.co.nec.lsm.tma.receiver.BatchJobCreater;
import junit.framework.Assert;
import mockit.Deencapsulation;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.integration.junit4.JMockit;

@RunWith(JMockit.class)
public class AggregationDeadLevelQueueServiceTest {
    private BatchSegmentJobManager queueManager;
    
    private IdentifyResult identifyResult;
    
    private BatchSegmentJobMap batchMap;
    
    private AggregationDeadLevelQueueService dlq;
    
    @Mocked
    AggregationSystemConfigDao mockSysDao;
    
    @Before
    public void setUp() throws Exception {
        queueManager = BatchSegmentJobManager.getInstance();
        queueManager.clear();
        dlq = new AggregationDeadLevelQueueService();
    }
    
    @After
    public void tearDown() throws Exception {
        queueManager = null;
        identifyResult = null;
        batchMap = null;
        dlq = null;
    }
    
    @Test
    public void testcheckBatchJob_IdentifyResultsIsZero() {
        long batchJobId = 100l;
        batchMap = new BatchSegmentJobMap();
        batchMap.setbJobId(batchJobId);
        IdentifyResult identifyResult = new IdentifyResult();
        queueManager.getIdentifyResults().put(batchJobId, identifyResult);
        queueManager.add(batchMap);        
        dlq.checkBatchJob(batchJobId);
        BatchJobMapStatus status = queueManager
            .getBatchSegmentJobMapStatus(batchJobId);
        Assert.assertEquals(
            BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR,
            status);
    }
    
    @Test
    public void testcheckBatchJob_BatchSegmentJobMapIsNull() {
        long batchJobId = 101l;
        batchMap = new BatchSegmentJobMap();
        batchMap.setbJobId(batchJobId);       
        queueManager.getBatchSegmentJobMaps().put(batchJobId, batchMap);
        dlq.checkBatchJob(batchJobId);
        BatchJobMapStatus status = queueManager
            .getBatchSegmentJobMapStatus(batchJobId);
        Assert.assertEquals(
            BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR,
            status);
    }
    
    @Test
    public void testcheckBatchJob_OK() {
        
        long batchJobId = 100l;
        int topJobIndex = 0;
        BatchJobCreater creater = new BatchJobCreater();
        batchMap = creater.createBatchSegmentJobMap(batchJobId, topJobIndex);
        identifyResult = creater.createBatchJobResult(batchJobId, topJobIndex);
        BatchSegmentJobManager queueManager = BatchSegmentJobManager
            .getInstance();
        queueManager.getBatchSegmentJobMaps().put(batchJobId, batchMap);
        queueManager.getIdentifyResults().put(batchJobId, identifyResult);        
        
        dlq.checkBatchJob(batchJobId);
        BatchJobMapStatus status = queueManager
            .getBatchSegmentJobMapStatus(batchJobId);
        
        Assert.assertEquals(BatchJobMapStatus.TMA_WORKING_DONE, status);
        Assert.assertEquals(false, queueManager.getIdentifyResult(batchJobId)
            .getSearchJobResults().get(0).isOverMaxCandidates());
    }
    
    @Test
    public void testreSendResultsToTr_OK() throws NoSuchFieldException, SecurityException {        
        Deencapsulation.setField(dlq, mockSysDao);        
        new Expectations() {
            {
                mockSysDao.getPostToTransformerUrl();
                result = "http://192.168.1.127:65521/cgi-bin/sendIdentifyResultBatch.cgi";  
                mockSysDao.getTransformerPostTimeout();
                result = 1000;
            }
        };         
        new MockUp<AggregationEventBus>() {
            @Mock
            public boolean sendIdentifyResponseToTransformer(
                IdentifyResult identifyResult, String endPoint, Integer timeout) {
                return true;
            }            
        }; 
        long batchJobId = 100l;
        int topJobIndex = 0;
        BatchJobCreater creater = new BatchJobCreater();
        batchMap = creater.createBatchSegmentJobMap(batchJobId, topJobIndex);
        identifyResult = creater.createBatchJobResult(batchJobId, topJobIndex);
        BatchSegmentJobManager queueManager = BatchSegmentJobManager
            .getInstance();
        queueManager.getBatchSegmentJobMaps().put(batchJobId, batchMap);
        queueManager.getIdentifyResults().put(batchJobId, identifyResult);
        dlq.reSendResultsToTr(batchJobId);
        BatchJobMapStatus status = queueManager
            .getBatchSegmentJobMapStatus(batchJobId);
        Assert.assertEquals(BatchJobMapStatus.NOTIFY_TRANSFORMER_DONE, status);        
    }
    
    @Test
    public void testreSendResultsToTr_failed() {
        Deencapsulation.setField(dlq, mockSysDao);        
        new Expectations() {
            {
                mockSysDao.getPostToTransformerUrl();
                result = "http://192.168.1.127:65521/cgi-bin/sendIdentifyResultBatch.cgi";  
                mockSysDao.getTransformerPostTimeout();
                result = 1000L;
            }
        };  
        
        long batchJobId = 100l;
        int topJobIndex = 0;
        BatchJobCreater creater = new BatchJobCreater();
        batchMap = creater.createBatchSegmentJobMap(batchJobId, topJobIndex);
        identifyResult = creater.createBatchJobResult(batchJobId, topJobIndex);
        BatchSegmentJobManager queueManager = BatchSegmentJobManager
            .getInstance();
        queueManager.getBatchSegmentJobMaps().put(batchJobId, batchMap);
        queueManager.getIdentifyResults().put(batchJobId, identifyResult);
        
       
        new MockUp<AggregationEventBus>() {
            @Mock
            public boolean sendIdentifyResponseToTransformer(
                IdentifyResult identifyResult, String endPoint,
                Integer timeout) {
                return false;
            }
        };      
   
        dlq.reSendResultsToTr(batchJobId);
        BatchJobMapStatus status = queueManager
            .getBatchSegmentJobMapStatus(batchJobId);
        Assert.assertEquals(
            BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR,
            status);
        
    }
    
    @Test
    public void testsendBatchJobMapToTMI_OK() {        
        Deencapsulation.setField(dlq, mockSysDao);        
        new Expectations() {
            {               
                mockSysDao.getTmiIpAddress();
                result = "127.0.0.1";               
            }
        };  
        
        long batchJobId = 100l;
        int topJobIndex = 0;
        BatchJobCreater creater = new BatchJobCreater();
        batchMap = creater.createBatchSegmentJobMap(batchJobId, topJobIndex);
        identifyResult = creater.createBatchJobResult(batchJobId, topJobIndex);
        BatchSegmentJobManager queueManager = BatchSegmentJobManager
            .getInstance();
        queueManager.getBatchSegmentJobMaps().put(batchJobId, batchMap);
        queueManager.getIdentifyResults().put(batchJobId, identifyResult);
        BatchJobMapStatus st = BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR;
        queueManager.getBatchSegmentJobMap(batchJobId).setBatchJobStatus(st);     
        new MockUp<AggregationEventBus>() {
            @Mock
            public boolean sendBatchSegmentJobMapToTMI(
                BatchSegmentJobMap batchMap, String tmiIpAddress) {
                return true;
            }
        };
        
        dlq.sendBatchJobMapToTMI(batchJobId);
        BatchJobMapStatus status = queueManager
            .getBatchSegmentJobMapStatus(batchJobId);
        Assert.assertEquals(BatchJobMapStatus.NOTIFY_TMI_DONE, status);        
     
    }
    
    @Test
    public void testsendBatchJobMapToTMI_Failed() {
        Deencapsulation.setField(dlq, mockSysDao);        
        new Expectations() {
            {               
                mockSysDao.getTmiIpAddress();
                result = "127.0.0.1";                  
            }
        }; 
        long batchJobId = 100l;
        int topJobIndex = 0;
        BatchJobCreater creater = new BatchJobCreater();
        batchMap = creater.createBatchSegmentJobMap(batchJobId, topJobIndex);
        identifyResult = creater.createBatchJobResult(batchJobId, topJobIndex);
        BatchSegmentJobManager queueManager = BatchSegmentJobManager
            .getInstance();
        queueManager.getBatchSegmentJobMaps().put(batchJobId, batchMap);
        queueManager.getIdentifyResults().put(batchJobId, identifyResult);
        BatchJobMapStatus st = BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR;
        queueManager.getBatchSegmentJobMap(batchJobId).setBatchJobStatus(st);   
        new MockUp<AggregationEventBus>() {
            @Mock
            public boolean sendBatchSegmentJobMapToTMI(
                BatchSegmentJobMap batchMap, String tmiIpAddress) {
                return false;
            }
        };
        
        dlq.sendBatchJobMapToTMI(batchJobId);
        BatchJobMapStatus status = queueManager
            .getBatchSegmentJobMapStatus(batchJobId);
        Assert.assertEquals(
            BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR,
            status);        
    }
    
    @Test
    public void testLastProcess_SEND_RESULTS_TO_TRANSFORMER_ERROR() {
        Deencapsulation.setField(dlq, mockSysDao);        
        new Expectations() {
            {               
                mockSysDao.getTmiIpAddress();
                result = "127.0.0.1";                  
            }
        }; 
        
        long batchJobId = 100l;
        int topJobIndex = 0;
        BatchJobCreater creater = new BatchJobCreater();
        batchMap = creater.createBatchSegmentJobMap(batchJobId, topJobIndex);
        identifyResult = creater.createBatchJobResult(batchJobId, topJobIndex);
        BatchSegmentJobManager queueManager = BatchSegmentJobManager
            .getInstance();
        queueManager.getBatchSegmentJobMaps().put(batchJobId, batchMap);
        queueManager.getIdentifyResults().put(batchJobId, identifyResult);
        BatchJobMapStatus st = BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR;
        queueManager.getBatchSegmentJobMap(batchJobId).setBatchJobStatus(st);   
        new MockUp<AggregationEventBus>() {
            @Mock
            public boolean notifyIdentifyBatchjobSendFailed(long batchJobId,
                String tmiIP) {
                return true;
            }
        };       
        dlq.lastProcess(batchJobId);
        Assert.assertNull(queueManager.getBatchSegmentJobMap(batchJobId));
        Assert.assertNull(queueManager.getIdentifyResult(batchJobId)); 
    }
    
}
