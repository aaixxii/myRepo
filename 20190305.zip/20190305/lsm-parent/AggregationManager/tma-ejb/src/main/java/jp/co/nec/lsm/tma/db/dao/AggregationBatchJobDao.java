package jp.co.nec.lsm.tma.db.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobDBStatus;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.identify.entityhelpers.IdentifyBatchJobHelper;

/**
 * @author dongqk <br>
 */

public class AggregationBatchJobDao {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationBatchJobDao.class);
	
	private DataSource dataSource;		
	private IdentifyBatchJobHelper identfyJobHelper;

	/**
	 * constructor
	 */
	public AggregationBatchJobDao(DataSource ds, EntityManager manager) {		
		this.dataSource = ds;
		
		identfyJobHelper = new IdentifyBatchJobHelper(manager, dataSource);
		printLogMessage("AggregationBatchJobDao init");
	}

	/**
	 * getAllRunningBatchJobs
	 */
	public List<IdentifyBatchJobQueueEntity> getAllRunningBatchJobs(
			IdentifyBatchJobDBStatus status) {
		printLogMessage("start public function getAllRunningBatchJobs()..");

		List<IdentifyBatchJobQueueEntity> allRunningJobs = identfyJobHelper
				.getAllRunningBatchJobs(status);

		printLogMessage("end public function getAllRunningBatchJobs()..");
		return allRunningJobs;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
