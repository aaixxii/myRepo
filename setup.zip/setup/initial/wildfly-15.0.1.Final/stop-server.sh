pkill -9 -f jboss
