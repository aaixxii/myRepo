#!/bin/sh

DEBUG=0

if [ $DEBUG -ne 0 ]; then
	if [ ! -e log ]; then
		mkdir log
	fi
	
	if [ $# -ne 3 ]; then
		echo Usage: sh ./lmx_agent.sh port majorversion featurename
		exit
	fi
fi

export LMX_LIB_PATH="$JBOSS_HOME/license/lmx/linux_x64"
java -jar -Djava.library.path=$LMX_LIB_PATH lmx-agent.jar $*
