echo "In AutoDeploy.sh"
echo "present working directory" $PWD
ls -lart
new_installer=$(ls *.ear)
echo "new_installer" $new_installer
cd /home/megha/wildfly-9.0.0.Final
echo "present working directory" $PWD
sh stop-server.sh
cd /home/megha/wildfly-9.0.0.Final/standalone/deployments
echo "present working directory" $PWD
echo "removing existing directory"
rm -rf *.ear*
rm -f *.ear
echo "creating new directory" $new_installer
mkdir $new_installer
echo ' '> $new_installer.dodeploy
cd /home/megha/Temp
echo "present working directory" $PWD
unzip $new_installer -d /home/megha/wildfly-9.0.0.Final/standalone/deployments/$new_installer
echo "present working directory" $PWD
cd /home/megha/wildfly-9.0.0.Final
sh start-server.sh &
cd /home/megha/Temp
ls -lart
rm -rf *.ear*
rm -f *.ear
