package jp.co.nec.aim.mm.acceptor.service;

import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;
import jp.co.nec.aim.mm.acceptor.Record;
import jp.co.nec.aim.mm.acceptor.Registration;
import jp.co.nec.aim.mm.acceptor.SyncRequest;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager.ScriptFunction;
import jp.co.nec.aim.mm.dao.ServiceLayoutDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.PBStateUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;
import jp.co.nec.aim.mm.validator.TemplateValidator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;

/**
 * The main work flow of Sync <br>
 * 
 * Include following public method:
 * <p>
 * syncData
 * <p>
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimSyncService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimSyncService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	@EJB
	private TemplateValidator templateValidator;
	private Registration reg;
	private ScriptManager scriptManager;
	private AcceptorValidator validator;
	private ServiceLayoutDao layoutDao;

	/**
	 * default constructor
	 */
	public AimSyncService() {
	}

	@PostConstruct
	private void init() {
		this.reg = new Registration(dataSource, manager);
		this.validator = new AcceptorValidator(manager, dataSource);
		this.scriptManager = ScriptManager.getInstance();
		this.layoutDao = new ServiceLayoutDao(manager);
	}

	/**
	 * The main work flow of syncData
	 * 
	 * @param request
	 *            PBSyncJobRequest instance
	 * @return the instance of PBSyncJobResponse
	 */
	public SyncResponse syncData(final SyncRequest request) {
		return syncData(request, null);
	}

	/**
	 * The main work flow of syncData
	 * 
	 * @param syncRequest
	 *            PBSyncJobRequest instance
	 * @param delCount
	 *            delete count
	 * @return PBSyncJobResponse instance
	 */
	public SyncResponse syncData(final SyncRequest request,
			final AtomicInteger delCount) {
		// first check the parameter PBSyncJobRequest
		// if any error occurred, throw IllegalArgumentException
		// servLet will response 400 bad request
		// at the meanwhile convert to new Request
		SyncRequest.Builder newRequest = validator.checkSyncJobRequest(request);
				

		final SyncFunctionType type = request.getFunction(); // required
		// template Validation
		if (type == SyncFunctionType.INSERT || type == SyncFunctionType.UPDATE) {
			templateValidator.validate(newRequest.build());
		}

		// eventId optional(default 0 or null for Redmine#15917)
		final String externalId = request.getExternalId(); // required

		final PBSyncInsertPayload insertPayload = newRequest.getInsertPayload(); // optional
		final PBSyncDeletePayload delPayload = request.hasDeletePayload() ? request
				.getDeletePayload() : null; // optional

		addSyncScript(request.getFunction());
		switch (type) {
		case INSERT:
			if (log.isDebugEnabled()) {
				log.debug("syncData insert begin..");
			}
			reg.insert(request.hasEventId() ? request.getEventId() : 0,
					externalId, getSyncRequests(insertPayload));
			break;
		case UPDATE:
			if (log.isDebugEnabled()) {
				log.debug("syncData update begin..");
			}
			reg.update(request.hasEventId() ? request.getEventId() : 0,
					externalId, getDeleteContainers(delPayload),
					getSyncRequests(insertPayload));
			break;
		case DELETE:
			if (log.isDebugEnabled()) {
				log.debug("syncData delete begin..");
			}
			int count = reg.delete(request.hasEventId() ? request.getEventId()
					: null, externalId, getDeleteContainers(delPayload));
			if (delCount != null) {
				delCount.set(count);
			}
			break;
		default:
			throw new IllegalArgumentException("Function type:" + type.name()
					+ " is not support.");
		}
		final PBSyncJobResponse.Builder b = PBSyncJobResponse.newBuilder()
				.setServiceState(PBStateUtil.creatSuccessState());
		return b.build();
	}

	/**
	 * getDeleteContainers
	 * 
	 * @param delPayload
	 *            the instance of PBSyncDeletePayload
	 * @return list of delete container id
	 */
	private List<Integer> getDeleteContainers(PBSyncDeletePayload delPayload) {
		final Set<Integer> containerIds = scriptManager
				.findDelContainerIds(delPayload);
		if (CollectionsUtil.isEmpty(containerIds)) {
			throw new AimRuntimeException(
					"Could not find the deletion container id "
							+ "with specified parameter PBSyncDeletePayload..");
		}
		return Lists.newArrayList(containerIds);
	}

	/**
	 * Get Sync Requests list with specified payLoad
	 * 
	 * @param payload
	 *            PBSyncInsertPayload instance
	 * @return SyncRequest list
	 */
	private List<SyncRequest> getSyncRequests(final PBSyncInsertPayload payload) {
		final Integer scope = payload.hasScope() ? payload.getScope() : null;
		final List<PBKeyedTemplateData> l = payload.getKeyedTemplateDataList();

		final List<SyncRequest> requests = Lists.newArrayList();
		for (final PBKeyedTemplateData template : l) {
			if (!template.hasKeyedTemplate()) {
				throw new AimRuntimeException(
						"KeyedTemplate must be specified after convert..");
			}

			final PBKeyedTemplate kTemplate = template.getKeyedTemplate();
			final Set<Integer> containerIds = scriptManager
					.findRegContainerIds(kTemplate, scope);

			// get TemplateBinary, ready for register
			final ByteString bytes = kTemplate.getTemplateBinary();
			requests.add(new SyncRequest(
					CollectionsUtil.getFirst(containerIds), new Record(bytes
							.toByteArray())));
		}
		return requests;
	}

	/**
	 * scriptManager already exist specified function <br>
	 * it means that already has this function in memory <br>
	 * so skip to fetch from database, otherwise must fetch it <br>
	 * from database and cache into memory..
	 * 
	 * @param function
	 *            SyncFunctionType instance
	 */
	private void addSyncScript(final SyncFunctionType function) {
		final List<ScriptFunction> functions = Lists.newArrayList();
		switch (function) {
		case INSERT:
			functions.add(ScriptFunction.REGISTRATION);
			break;
		case DELETE:
			functions.add(ScriptFunction.DELETION);
			break;
		case UPDATE:
			functions.add(ScriptFunction.REGISTRATION);
			functions.add(ScriptFunction.DELETION);
			break;
		default:
			throw new IllegalArgumentException("SyncFunctionType: "
					+ function.name() + " is not support.");
		}

		// IF function is UPDATE, we will fetch the script XML twice
		for (final ScriptFunction f : functions) {
			// thread safe must be considering,
			// if MUTLIP-THREAD reached, one thread
			// add script XML is allowed..
			// otherwise will fetch from DB many times
			// synchronized by ScriptFunction instance
			synchronized (f) {
				// if scriptManager already exist specified function
				// it means that already has this function in memory
				// so skip to fetch from database, otherwise must fetch it
				// from database and cache into memory..
				if (!scriptManager.isExistFunction(f)) {
					String scriptXml = layoutDao.findScriptXmlByName(f.name());
					scriptManager.addScriptXml(f, scriptXml);
				}
			}
		}
	}
}
