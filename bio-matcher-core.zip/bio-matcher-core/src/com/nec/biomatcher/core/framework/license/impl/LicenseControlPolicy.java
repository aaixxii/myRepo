package com.nec.biomatcher.core.framework.license.impl;

import java.util.Date;

/**
 * The Class LicenseControlPolicy.
 */
public class LicenseControlPolicy {

	/** The purpose. */
	private String purpose = "Evaluation";

	/** The valid start date. */
	private Date validStartDate;

	/** The valid end date. */
	private Date validEndDate;

	/** The daily transaction allowed. */
	private Long dailyTransactionAllowed;

	/** The total transaction allowed. */
	private Long totalTransactionAllowed;

	/** The hardware address. */
	private String hardwareAddress;

	/** The max client allowed. */
	private Long maxClientAllowed;

	/** The max client allowed. */
	private Long maxDevicesAllowed;

	/** The hardware ip. */
	private String hardwareIp;

	/** The issue to. */
	private String issueTo;

	/** The issue by. */
	private String issueBy;

	private String featureId;

	private boolean isFeatureEnabled;

	private String errorCode;

	private String errorMessage;

	public LicenseControlPolicy() {
	}

	public LicenseControlPolicy(String featureId) {
		this.featureId = featureId;
	}

	/**
	 * Gets the valid start date.
	 *
	 * @return the valid start date
	 */
	public Date getValidStartDate() {
		return validStartDate;
	}

	/**
	 * Sets the valid start date.
	 *
	 * @param validStartDate
	 *            the new valid start date
	 */
	public void setValidStartDate(Date validStartDate) {
		this.validStartDate = validStartDate;
	}

	/**
	 * Gets the valid end date.
	 *
	 * @return the valid end date
	 */
	public Date getValidEndDate() {
		return validEndDate;
	}

	/**
	 * Sets the valid end date.
	 *
	 * @param validEndDate
	 *            the new valid end date
	 */
	public void setValidEndDate(Date validEndDate) {
		this.validEndDate = validEndDate;
	}

	/**
	 * Gets the daily transaction allowed.
	 *
	 * @return the daily transaction allowed
	 */
	public Long getDailyTransactionAllowed() {
		return dailyTransactionAllowed;
	}

	/**
	 * Sets the daily transaction allowed.
	 *
	 * @param dailyTransactionAllowed
	 *            the new daily transaction allowed
	 */
	public void setDailyTransactionAllowed(Long dailyTransactionAllowed) {
		this.dailyTransactionAllowed = dailyTransactionAllowed;
	}

	/**
	 * Gets the total transaction allowed.
	 *
	 * @return the total transaction allowed
	 */
	public Long getTotalTransactionAllowed() {
		return totalTransactionAllowed;
	}

	/**
	 * Sets the total transaction allowed.
	 *
	 * @param totalTransactionAllowed
	 *            the new total transaction allowed
	 */
	public void setTotalTransactionAllowed(Long totalTransactionAllowed) {
		this.totalTransactionAllowed = totalTransactionAllowed;
	}

	/**
	 * Gets the hardware address.
	 *
	 * @return the hardware address
	 */
	public String getHardwareAddress() {
		return hardwareAddress;
	}

	/**
	 * Sets the hardware address.
	 *
	 * @param hardwareAddress
	 *            the new hardware address
	 */
	public void setHardwareAddress(String hardwareAddress) {
		this.hardwareAddress = hardwareAddress;
	}

	/**
	 * Gets the issue to.
	 *
	 * @return the issue to
	 */
	public String getIssueTo() {
		return issueTo;
	}

	/**
	 * Sets the issue to.
	 *
	 * @param issueTo
	 *            the new issue to
	 */
	public void setIssueTo(String issueTo) {
		this.issueTo = issueTo;
	}

	/**
	 * Gets the issue by.
	 *
	 * @return the issue by
	 */
	public String getIssueBy() {
		return issueBy;
	}

	/**
	 * Sets the issue by.
	 *
	 * @param issueBy
	 *            the new issue by
	 */
	public void setIssueBy(String issueBy) {
		this.issueBy = issueBy;
	}

	/**
	 * Gets the purpose.
	 *
	 * @return the purpose
	 */
	public String getPurpose() {
		return purpose;
	}

	/**
	 * Sets the purpose.
	 *
	 * @param purpose
	 *            the new purpose
	 */
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	/**
	 * Gets the max client allowed.
	 *
	 * @return the max client allowed
	 */
	public Long getMaxClientAllowed() {
		return maxClientAllowed;
	}

	/**
	 * Sets the max client allowed.
	 *
	 * @param maxClientAllowed
	 *            the new max client allowed
	 */
	public void setMaxClientAllowed(Long maxClientAllowed) {
		this.maxClientAllowed = maxClientAllowed;
	}

	/**
	 * Gets the hardware ip.
	 *
	 * @return the hardware ip
	 */
	public String getHardwareIp() {
		return hardwareIp;
	}

	/**
	 * Sets the hardware ip.
	 *
	 * @param hardwareIp
	 *            the new hardware ip
	 */
	public void setHardwareIp(String hardwareIp) {
		this.hardwareIp = hardwareIp;
	}

	public Long getMaxDevicesAllowed() {
		// return maxDevicesAllowed;
		return 100L;
	}

	public void setMaxDevicesAllowed(Long maxDevicesAllowed) {
		this.maxDevicesAllowed = maxDevicesAllowed;
	}

	public String getFeatureId() {
		return featureId;
	}

	public void setFeatureId(String featureId) {
		this.featureId = featureId;
	}

	public boolean isFeatureEnabled() {
		return isFeatureEnabled;
	}

	public void setFeatureEnabled(boolean isFeatureEnabled) {
		this.isFeatureEnabled = isFeatureEnabled;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
