package com.nec.biomatcher.core.framework.common;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

/**
 * Generic Delayed entry used for Delayed Queue
 * 
 * @author mreddy
 *
 */
public class DelayedItem<T> implements Delayed {
	private final T item;
	private final long delayMilli;
	private final long originMilli;

	public DelayedItem(T item, long delayMilli) {
		this.item = item;
		this.delayMilli = delayMilli;
		this.originMilli = System.currentTimeMillis();
	}

	public T getItem() {
		return item;
	}

	@Override
	public int compareTo(Delayed delayed) {
		if (delayed == this) {
			return 0;
		} else if (delayed == null) {
			return Integer.MAX_VALUE;
		}

		if (delayed instanceof DelayedItem) {
			DelayedItem<?> otherDelayedItem = (DelayedItem<?>) delayed;

			if (this.item == otherDelayedItem.item) {
				return 0;
			} else if (this.item != null && otherDelayedItem.item != null) {
				try {
					if (this.item.equals(otherDelayedItem.item)) {
						return 0;
					}
				} catch (Throwable th) {
				}
			}
			//
			// long diff = delayMilli - otherDelayedItem.delayMilli;
			// return ((diff == 0) ? 0 : ((diff < 0) ? -1 : 1));
		}

		return Long.compare(getDelay(TimeUnit.MILLISECONDS), delayed.getDelay(TimeUnit.MILLISECONDS));
	}

	@Override
	public long getDelay(TimeUnit unit) {
		return unit.convert(delayMilli - (System.currentTimeMillis() - originMilli), TimeUnit.MILLISECONDS);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((item == null) ? 0 : item.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		if (!(obj instanceof DelayedItem)) {
			return false;
		}

		final DelayedItem<?> other = (DelayedItem<?>) obj;
		if (item == null) {
			if (other.item != null) {
				return false;
			}
		} else if (!item.equals(other.item)) {
			return false;
		}

		return true;
	}
}
