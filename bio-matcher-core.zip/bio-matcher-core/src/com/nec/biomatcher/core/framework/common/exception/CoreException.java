package com.nec.biomatcher.core.framework.common.exception;

import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.CommonLogger;

/**
 * Parent class for all Exceptions.
 *
 * @author $Author: alvin $
 * 
 * @version $Revision: 1.1.1.1 $
 */

public class CoreException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	public static final String ERROR_CODE_GENERAL = "CE001";

	/** The Constant errorLogger. */
	public static final Logger ERRORS = CommonLogger.ERROR_LOG;

	/** The error code. */
	protected String errorCode;

	/** The is audited flag. */
	private transient boolean isAuditedFlag = false;

	/**
	 * The Constructor.
	 *
	 * @param message
	 *            the message
	 */
	public CoreException(String message) {
		super(message);
		this.errorCode = ERROR_CODE_GENERAL;
		getErrorLogger().error(this.getClass().getSimpleName() + ": " + this.errorCode + " : " + message, this);
	}

	/**
	 * Instantiates a new core exception.
	 *
	 * @param errorCode
	 *            the error code
	 * @param message
	 *            the message
	 */
	public CoreException(String errorCode, String message) {
		super(message);
		this.errorCode = errorCode == null ? ERROR_CODE_GENERAL : errorCode;
		getErrorLogger().error(this.getClass().getSimpleName() + ": " + this.errorCode + " : " + message, this);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause
	 *            the cause
	 */
	public CoreException(Throwable cause) {
		super("CoreException. Cause: " + cause.getMessage(), cause);
		this.errorCode = ERROR_CODE_GENERAL;
		if (!(cause instanceof CoreException)) {
			getErrorLogger().error(this.getClass().getSimpleName() + ": " + this.errorCode + " : " + this.getMessage(),
					this);
		}
	}

	public CoreException(String errorCode, String message, Throwable cause) {
		super(message, cause);
		this.errorCode = errorCode == null ? ERROR_CODE_GENERAL : errorCode;
		if (!(cause instanceof CoreException)) {
			getErrorLogger().error(this.getClass().getSimpleName() + ": " + message, this);
		}
	}

	/**
	 * The Constructor.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public CoreException(String message, Throwable cause) {
		super(message, cause);
		this.errorCode = ERROR_CODE_GENERAL;
		if (!(cause instanceof CoreException)) {
			getErrorLogger().error(this.getClass().getSimpleName() + ": " + message, this);
		}
	}

	protected Logger getErrorLogger() {
		return ERRORS;
	}

	public boolean isAuditedFlag() {
		return isAuditedFlag;
	}

	public void setAuditedFlag(boolean isAuditedFlag) {
		this.isAuditedFlag = isAuditedFlag;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
