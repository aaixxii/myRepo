package com.nec.biomatcher.core.framework.common;

@FunctionalInterface
public interface CheckedConsumer<T> {
	void accept(T t) throws Throwable;
}
