package com.nec.biomatcher.core.framework.common;

import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

import com.google.common.base.Suppliers;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.cache.RemovalListener;

/**
 * Utility for memorizing the java 8 suppliers and functions values. Basically
 * this is Java8 Functional Interface implementation of Guava suppliers.
 * 
 * @author mreddy
 *
 */
public class Memonizer {

	/**
	 * Memonize.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @return the function
	 */
	public static <T, R> Function<T, R> memonize(Function<T, R> func) {
		// Intentionally using size based expiration, as without expiration, it
		// might lead to memory leak
		return memonizeWithExpiration(func, 5000);
	}

	/**
	 * Memonize.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <U>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @return the bi function
	 */
	public static <T, U, R> BiFunction<T, U, R> memonize(BiFunction<T, U, R> func) {
		// Intentionally using size based expiration, as without expiration, it
		// might lead to memory leak
		return memonizeWithExpiration(func, 5000);
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the function
	 */
	public static <T, R> Function<T, R> memonizeWithExpiration(Function<T, R> func, long duration, TimeUnit timeUnit) {
		final class FuncMemonizer implements Function<T, R> {
			final LoadingCache<T, R> cached = CacheBuilder.newBuilder().expireAfterWrite(duration, timeUnit)
					.build(new CacheLoader<T, R>() {
						public R load(T key) {
							return func.apply(key);
						}
					});

			@Override
			public R apply(T t) {
				return cached.getUnchecked(t);
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param size
	 *            the size
	 * @return the function
	 */
	public static <T, R> Function<T, R> memonizeWithExpiration(Function<T, R> func, long size) {
		final class FuncMemonizer implements Function<T, R> {
			final LoadingCache<T, R> cached = CacheBuilder.newBuilder().maximumSize(size)
					.build(new CacheLoader<T, R>() {
						public R load(T key) {
							return func.apply(key);
						}
					});

			@Override
			public R apply(T t) {
				return cached.getUnchecked(t);
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param size
	 *            the size
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the function
	 */
	public static <T, R> Function<T, R> memonizeWithExpiration(Function<T, R> func, long size, long duration,
			TimeUnit timeUnit) {
		final class FuncMemonizer implements Function<T, R> {
			final LoadingCache<T, R> cached = CacheBuilder.newBuilder().maximumSize(size)
					.expireAfterWrite(duration, timeUnit).build(new CacheLoader<T, R>() {
						public R load(T key) {
							return func.apply(key);
						}
					});

			@Override
			public R apply(T t) {
				return cached.getUnchecked(t);
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <U>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param size
	 *            the size
	 * @return the bi function
	 */
	public static <T, U, R> BiFunction<T, U, R> memonizeWithExpiration(BiFunction<T, U, R> func, long size) {
		final class FuncMemonizer implements BiFunction<T, U, R> {
			final LoadingCache<BiKey<T, U>, R> cached = CacheBuilder.newBuilder().maximumSize(size)
					.build(new CacheLoader<BiKey<T, U>, R>() {
						public R load(BiKey<T, U> key) {
							return func.apply(key.a, key.b);
						}
					});

			@Override
			public R apply(T t, U u) {
				return cached.getUnchecked(new BiKey<T, U>(t, u));
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <U>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the bi function
	 */
	public static <T, U, R> BiFunction<T, U, R> memonizeWithExpiration(BiFunction<T, U, R> func, long duration,
			TimeUnit timeUnit) {
		final class FuncMemonizer implements BiFunction<T, U, R> {
			final LoadingCache<BiKey<T, U>, R> cached = CacheBuilder.newBuilder().expireAfterWrite(duration, timeUnit)
					.build(new CacheLoader<BiKey<T, U>, R>() {
						public R load(BiKey<T, U> key) {
							return func.apply(key.a, key.b);
						}
					});

			@Override
			public R apply(T t, U u) {
				return cached.getUnchecked(new BiKey<T, U>(t, u));
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <U>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param size
	 *            the size
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the bi function
	 */
	public static <T, U, R> BiFunction<T, U, R> memonizeWithExpiration(BiFunction<T, U, R> func, long size,
			long duration, TimeUnit timeUnit) {
		final class FuncMemonizer implements BiFunction<T, U, R> {
			final LoadingCache<BiKey<T, U>, R> cached = CacheBuilder.newBuilder().maximumSize(size)
					.expireAfterWrite(duration, timeUnit).build(new CacheLoader<BiKey<T, U>, R>() {
						public R load(BiKey<T, U> key) {
							return func.apply(key.a, key.b);
						}
					});

			@Override
			public R apply(T t, U u) {
				return cached.getUnchecked(new BiKey<T, U>(t, u));
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with idle timeout.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the function
	 */
	public static <T, R> Function<T, R> memonizeWithIdleTimeout(Function<T, R> func, long duration, TimeUnit timeUnit) {
		final class FuncMemonizer implements Function<T, R> {
			final LoadingCache<T, R> cached = CacheBuilder.newBuilder().expireAfterAccess(duration, timeUnit)
					.build(new CacheLoader<T, R>() {
						public R load(T key) {
							return func.apply(key);
						}
					});

			@Override
			public R apply(T t) {
				return cached.getUnchecked(t);
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with idle timeout.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <U>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the bi function
	 */
	public static <T, U, R> BiFunction<T, U, R> memonizeWithIdleTimeout(BiFunction<T, U, R> func, long duration,
			TimeUnit timeUnit) {
		final class FuncMemonizer implements BiFunction<T, U, R> {
			final LoadingCache<BiKey<T, U>, R> cached = CacheBuilder.newBuilder().expireAfterAccess(duration, timeUnit)
					.build(new CacheLoader<BiKey<T, U>, R>() {
						public R load(BiKey<T, U> key) {
							return func.apply(key.a, key.b);
						}
					});

			@Override
			public R apply(T t, U u) {
				return cached.getUnchecked(new BiKey<T, U>(t, u));
			}
		}
		return new FuncMemonizer();
	}

	public static <T, U, R> BiFunction<T, U, R> memonizeWithIdleTimeoutAndExpiration(BiFunction<T, U, R> func,
			long idleDuration, long expirationDuration, TimeUnit timeUnit) {
		final class FuncMemonizer implements BiFunction<T, U, R> {
			final LoadingCache<BiKey<T, U>, R> cached = CacheBuilder.newBuilder()
					.expireAfterAccess(idleDuration, timeUnit).expireAfterWrite(expirationDuration, timeUnit)
					.build(new CacheLoader<BiKey<T, U>, R>() {
						public R load(BiKey<T, U> key) {
							return func.apply(key.a, key.b);
						}
					});

			@Override
			public R apply(T t, U u) {
				return cached.getUnchecked(new BiKey<T, U>(t, u));
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <U>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param size
	 *            the size
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @param removalListener
	 *            the removal listener
	 * @return the bi function
	 */
	public static <T, U, R> BiFunction<T, U, R> memonizeWithExpiration(BiFunction<T, U, R> func, long size,
			long duration, TimeUnit timeUnit, RemovalListener<BiKey<T, U>, R> removalListener) {
		final class FuncMemonizer implements BiFunction<T, U, R> {
			final LoadingCache<BiKey<T, U>, R> cached = CacheBuilder.newBuilder().maximumSize(size)
					.expireAfterWrite(duration, timeUnit).removalListener(removalListener)
					.build(new CacheLoader<BiKey<T, U>, R>() {
						public R load(BiKey<T, U> key) {
							return func.apply(key.a, key.b);
						}
					});

			@Override
			public R apply(T t, U u) {
				return cached.getUnchecked(new BiKey<T, U>(t, u));
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <U>
	 *            the generic type
	 * @param <S>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the tri function
	 */
	public static <T, U, S, R> TriFunction<T, U, S, R> memonizeWithExpiration(TriFunction<T, U, S, R> func,
			long duration, TimeUnit timeUnit) {
		final class FuncMemonizer implements TriFunction<T, U, S, R> {
			final LoadingCache<TriKey<T, U, S>, R> cached = CacheBuilder.newBuilder()
					.expireAfterWrite(duration, timeUnit).build(new CacheLoader<TriKey<T, U, S>, R>() {
						public R load(TriKey<T, U, S> key) {
							return func.apply(key.a, key.b, key.c);
						}
					});

			@Override
			public R apply(T t, U u, S s) {
				return cached.getUnchecked(new TriKey<T, U, S>(t, u, s));
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with idle timeout.
	 *
	 * @param <T>
	 *            the generic type
	 * @param <U>
	 *            the generic type
	 * @param <S>
	 *            the generic type
	 * @param <R>
	 *            the generic type
	 * @param func
	 *            the func
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the tri function
	 */
	public static <T, U, S, R> TriFunction<T, U, S, R> memonizeWithIdleTimeout(TriFunction<T, U, S, R> func,
			long duration, TimeUnit timeUnit) {
		final class FuncMemonizer implements TriFunction<T, U, S, R> {
			final LoadingCache<TriKey<T, U, S>, R> cached = CacheBuilder.newBuilder()
					.expireAfterAccess(duration, timeUnit).build(new CacheLoader<TriKey<T, U, S>, R>() {
						public R load(TriKey<T, U, S> key) {
							return func.apply(key.a, key.b, key.c);
						}
					});

			@Override
			public R apply(T t, U u, S s) {
				return cached.getUnchecked(new TriKey<T, U, S>(t, u, s));
			}
		}
		return new FuncMemonizer();
	}

	/**
	 * Memonize with expiration.
	 *
	 * @param <T>
	 *            the generic type
	 * @param supp
	 *            the supp
	 * @param duration
	 *            the duration
	 * @param timeUnit
	 *            the time unit
	 * @return the supplier
	 */
	public static <T> Supplier<T> memonizeWithExpiration(Supplier<T> supp, long duration, TimeUnit timeUnit) {
		final class SuppMemonizer implements Supplier<T> {
			final com.google.common.base.Supplier<T> cachedSupp = Suppliers
					.memoizeWithExpiration(new com.google.common.base.Supplier<T>() {
						@Override
						public T get() {
							return supp.get();
						}
					}, duration, timeUnit);

			@Override
			public T get() {
				return cachedSupp.get();
			}
		}
		return new SuppMemonizer();
	}

	/**
	 * Memonize.
	 *
	 * @param <T>
	 *            the generic type
	 * @param supp
	 *            the supp
	 * @return the supplier
	 */
	public static <T> Supplier<T> memonize(Supplier<T> supp) {
		final class SuppMemonizer implements Supplier<T> {
			final com.google.common.base.Supplier<T> cachedSupp = Suppliers
					.memoize(new com.google.common.base.Supplier<T>() {
						@Override
						public T get() {
							return supp.get();
						}
					});

			@Override
			public T get() {
				return cachedSupp.get();
			}
		}
		return new SuppMemonizer();
	}
}
