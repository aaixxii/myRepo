package com.nec.biomatcher.core.framework.common.http;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpConnectionParams;
import org.apache.log4j.Logger;

public class HttpPostUtil {
	private static final Logger logger = Logger.getLogger(HttpPostUtil.class);

	public static final byte[] post(String serverId, String connectionUrl, byte[] request, long timeoutMilli)
			throws HttpConnectionException {
		if (logger.isTraceEnabled())
			logger.trace("In sendReceive: serverId: " + serverId + ", connectionUrl: " + connectionUrl + ", request: "
					+ request.length);

		long startTimeMilli = System.currentTimeMillis();
		long postTimeTaken = 0;
		try {
			PostMethod httpPost = new PostMethod(connectionUrl);
			try {
				httpPost.setRequestHeader("Content-type", "application/octet-stream");
				httpPost.setRequestHeader("instance_id", serverId);
				httpPost.setRequestEntity(new ByteArrayRequestEntity(request));

				HttpClientParams httpParam = new HttpClientParams();
				httpParam.setParameter(HttpConnectionParams.SO_LINGER, (int) 1);
				httpParam.setSoTimeout(Math.max(100, (int) timeoutMilli));

				HttpClient httpClient = new HttpClient(httpParam);

				int statusCode = httpClient.executeMethod(httpPost);

				postTimeTaken = System.currentTimeMillis() - startTimeMilli;

				if (statusCode != HttpStatus.SC_OK) {
					throw new HttpConnectionException("Error connecting to serverId: " + serverId + ",  connectionUrl: "
							+ connectionUrl + ", timeoutMilli: " + timeoutMilli + ", postTimeTaken: " + postTimeTaken
							+ ", statusCode: " + statusCode + ", statusLine: " + httpPost.getStatusLine());
				}

				byte[] response = httpPost.getResponseBody();

				if (response == null) {
					logger.debug("Received bytearray is null from serverId: " + serverId + ",  connectionUrl: "
							+ connectionUrl + ", timeoutMilli: " + timeoutMilli + ", postTimeTaken: " + postTimeTaken
							+ ", statusCode: " + statusCode + ", statusLine: " + httpPost.getStatusLine());
				}

				return response;
			} finally {
				postTimeTaken = System.currentTimeMillis() - startTimeMilli;
				if (httpPost != null) {
					try {
						httpPost.releaseConnection();
					} catch (Throwable th) {
						logger.error(
								"Error closing httpPost: connectionUrl: " + connectionUrl + " : " + th.getMessage(),
								th);
					}
				}
			}
		} catch (HttpConnectionException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new HttpConnectionException("SendReceive error  serverId: " + serverId + ",  connectionUrl: "
					+ connectionUrl + ", request: " + request.length + ", timeoutMilli: " + timeoutMilli
					+ ", startTime: " + startTimeMilli + ", postTimeTaken: " + postTimeTaken + " : " + th.getMessage(),
					th);
		}
	}
}
