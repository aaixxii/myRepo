package com.nec.biomatcher.core.framework.common;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.function.Predicate;

import org.apache.log4j.Logger;

public class FileUtils {
	private static final Logger logger = Logger.getLogger(FileUtils.class);

	public static final boolean saveFile(Path filePath, byte[] fileDataBuf) {
		try {
			Files.write(filePath, fileDataBuf);
			return true;
		} catch (Throwable th) {
			try {
				Files.createDirectories(filePath.getParent());
				Files.write(filePath, fileDataBuf);
				return true;
			} catch (Throwable th1) {
				logger.error("Error in saveFile: for filePath : " + filePath + " : " + th1.getMessage(), th1);
			}
		}
		return false;
	}

	public static final byte[] readAllBytes(File file) throws IOException {
		return org.apache.commons.io.FileUtils.readFileToByteArray(file);
	}

	public static final byte[] readAllBytes(Path filePath) throws IOException {
		return org.apache.commons.io.FileUtils.readFileToByteArray(filePath.toFile());
	}

	public static void closeQuietly(AutoCloseable closeable) {
		if (closeable != null) {
			try {
				closeable.close();
			} catch (Throwable th) {
			}
		}
	}

	public static void deleteFileQuietly(Path fileToDelete) {
		try {
			Files.deleteIfExists(fileToDelete);
		} catch (Throwable th) {
			logger.error("Error deleting the file: " + fileToDelete + " : " + th.getMessage(), th);
		}
	}

	public static void deleteFileQuietly(File fileToDelete) {
		try {
			org.apache.commons.io.FileUtils.deleteQuietly(fileToDelete);
		} catch (Throwable th) {
			logger.error("Error deleting the file: " + fileToDelete + " : " + th.getMessage(), th);
		}
	}

	public static boolean deleteFilesInCurrentFolder(File currentFolder, FilenameFilter filenameFilter) {
		boolean anyDeletedFlag = false;
		try {
			if (currentFolder.isDirectory()) {
				File[] files = currentFolder.listFiles(filenameFilter);
				if (files != null) {
					for (File file : files) {
						try {
							file.delete();
							anyDeletedFlag = true;
						} catch (Throwable th) {
							logger.error("Error in deleteFilesInCurrentFolder while deleting file : " + file + " : "
									+ th.getMessage(), th);
						}
					}
				}
			}
		} catch (Throwable th) {
			logger.error(
					"Error in deleteFilesInCurrentFolder: currentFolder: " + currentFolder + " : " + th.getMessage(),
					th);
		}
		return anyDeletedFlag;
	}

	public static boolean deleteFolderQuietly(File directoryToDelete) {
		long startTimestampMilli = System.currentTimeMillis();
		boolean deleteFlag = false;
		try {
			deleteFlag = org.apache.commons.io.FileUtils.deleteQuietly(directoryToDelete);
		} catch (Throwable th) {
			logger.error("Error deleting the directory: " + directoryToDelete + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (logger.isTraceEnabled() || timeTakenMilli > 1000) {
				CommonLogger.PERF_LOG.trace("In deleteFolderQuietly: TimeTakenMilli: " + timeTakenMilli
						+ ", directoryToDelete: " + directoryToDelete + ", deleteFlag: " + deleteFlag);
			}
		}
		return deleteFlag;
	}

	public static void deleteFolderQuietly(Path directoryToDelete) {
		DeletingFileVisitor delFileVisitor = new DeletingFileVisitor();
		long startTimestampMilli = System.currentTimeMillis();
		try {
			Files.walkFileTree(directoryToDelete, delFileVisitor);
		} catch (Throwable th) {
			logger.error("Error deleting the directory: " + directoryToDelete + " : " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (logger.isTraceEnabled() || timeTakenMilli > 1000) {
				CommonLogger.PERF_LOG.trace("In deleteFolderQuietly: TimeTakenMilli: " + timeTakenMilli
						+ ", directoryToDelete: " + directoryToDelete + ", deletedFolderCount: "
						+ delFileVisitor.getDeletedFolderCount() + ", deletedFileCount: "
						+ delFileVisitor.getDeletedFileCount() + ", errorCount: " + delFileVisitor.getErrorCount());
			}
		}
	}

	private static class DeletingFileVisitor extends SimpleFileVisitor<Path> {
		private long deletedFileCount = 0;
		private long deletedFolderCount = 0;
		private long errorCount = 0;
		private final Predicate<BasicFileAttributes> predicate;
		private final boolean deleteFolders;

		public DeletingFileVisitor() {
			predicate = null;
			deleteFolders = true;
		}

		public DeletingFileVisitor(Predicate<BasicFileAttributes> predicate, boolean deleteFolders) {
			this.predicate = predicate;
			this.deleteFolders = deleteFolders;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
			if (file != null && attrs != null && attrs.isRegularFile()) {
				try {
					if (predicate == null || predicate.test(attrs)) {
						Files.deleteIfExists(file);
						deletedFileCount++;
					}
				} catch (Throwable th) {
					logger.warn("Error deleting file: " + file + " : " + th.getMessage(), th);
					errorCount++;
				}
			}
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
			try {
				if (deleteFolders) {
					Files.deleteIfExists(dir);
					deletedFolderCount++;
				}
			} catch (Throwable th) {
				logger.warn("Error deleting folder: " + dir + " : " + th.getMessage(), th);
				errorCount++;
			}
			return FileVisitResult.CONTINUE;
		}

		public long getDeletedFileCount() {
			return deletedFileCount;
		}

		public long getDeletedFolderCount() {
			return deletedFolderCount;
		}

		public long getErrorCount() {
			return errorCount;
		}
	}

}
