package com.nec.biomatcher.core.framework.common;

import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.google.common.primitives.UnsignedInts;

public class HoldFlagUtil {
	public static final byte setHoldFlag(byte holdFlag, int bitIndex, boolean setFlag) {
		if (bitIndex < 0 || bitIndex >= Byte.SIZE) {
			throw new RuntimeException(
					"Invalid bitIndex: " + bitIndex + " passed to setHoldFlag, should be between 0.." + Byte.SIZE);
		}

		return (byte) setHoldFlag(UnsignedInts.toLong(holdFlag), bitIndex, setFlag);
	}

	public static final short setHoldFlag(short holdFlag, int bitIndex, boolean setFlag) {
		if (bitIndex < 0 || bitIndex >= Short.SIZE) {
			throw new RuntimeException(
					"Invalid bitIndex: " + bitIndex + " passed to setHoldFlag, should be between 0.." + Short.SIZE);
		}

		return (short) setHoldFlag(UnsignedInts.toLong(holdFlag), bitIndex, setFlag);
	}

	public static final int setHoldFlag(int holdFlag, int bitIndex, boolean setFlag) {
		if (bitIndex < 0 || bitIndex >= Integer.SIZE) {
			throw new RuntimeException(
					"Invalid bitIndex: " + bitIndex + " passed to setHoldFlag, should be between 0.." + Integer.SIZE);
		}

		return (int) setHoldFlag(UnsignedInts.toLong(holdFlag), bitIndex, setFlag);
	}

	public static final long setHoldFlag(long holdFlag, int bitIndex, boolean setFlag) {
		if (bitIndex < 0 || bitIndex >= Long.SIZE) {
			throw new RuntimeException(
					"Invalid bitIndex: " + bitIndex + " passed to setHoldFlag, should be between 0.." + Long.SIZE);
		}

		long maskVal = 1L << bitIndex;

		if (setFlag) {
			holdFlag = holdFlag | maskVal;
		} else {
			if (holdFlag != 0 && maskVal != 0) {
				holdFlag = holdFlag & ~maskVal;
			}
		}
		return holdFlag;
	}

	public static final List<Integer> getHoldFlagIndexList(long holdFlag, final int maxFlagCount) {

		List<Integer> holdFlagIndexList = new ArrayList<>(maxFlagCount);

		for (int bitIndex = 0; bitIndex < maxFlagCount; bitIndex++) {
			long maskVal = 1L << bitIndex;

			if (maskVal == (maskVal & holdFlag)) {
				holdFlagIndexList.add(bitIndex);
			}
		}

		return holdFlagIndexList;
	}

	public static final List<Integer> getFreeSlotsIndexList(long holdFlag, final int maxFlagCount) {

		List<Integer> freeSlotIndexList = new ArrayList<>(maxFlagCount);

		for (int bitIndex = 0; bitIndex < maxFlagCount; bitIndex++) {
			long maskVal = 1L << bitIndex;

			if (maskVal != (maskVal & holdFlag)) {
				freeSlotIndexList.add(bitIndex);
			}
		}

		return freeSlotIndexList;
	}

	public static final Integer getFirstFreeSlotIndex(long holdFlag, final int maxFlagCount) {

		for (int bitIndex = 0; bitIndex < maxFlagCount; bitIndex++) {
			long maskVal = 1L << bitIndex;

			if (maskVal != (maskVal & holdFlag)) {
				return bitIndex;
			}
		}

		return null;
	}

	public static final void setHoldFlag(byte holdFlag[], int bitIndex, boolean setFlag, ByteOrder byteOrder) {
		if (bitIndex < 0 || bitIndex >= holdFlag.length * 8) {
			throw new RuntimeException("Invalid bitIndex: " + bitIndex + " passed to setHoldFlag, should be between 0.."
					+ (holdFlag.length * 8));
		}

		int byteIndex = 0;
		if (ByteOrder.BIG_ENDIAN == byteOrder) {
			byteIndex = holdFlag.length - 1 - Math.floorDiv(bitIndex, 8);
			bitIndex = Math.floorMod(bitIndex, 8);
		} else {
			byteIndex = Math.floorDiv(bitIndex, 8);
			bitIndex = Math.floorMod(bitIndex, 8);
		}

		byte maskVal = (byte) (1 << bitIndex);

		if (setFlag) {
			holdFlag[byteIndex] = (byte) (holdFlag[byteIndex] | maskVal);
		} else {
			if (holdFlag[byteIndex] != 0 && maskVal != 0) {
				holdFlag[byteIndex] = (byte) (holdFlag[byteIndex] & ~maskVal);
			}
		}
	}

	public static final void setHoldFlags(byte holdFlag[], String csvBitIndex, boolean setFlag, ByteOrder byteOrder) {
		if (StringUtils.isBlank(csvBitIndex)) {
			throw new RuntimeException("Invalid csvBitIndex: " + csvBitIndex + " passed to setHoldFlags");
		}
		List<Integer> bitIndexList = StringUtil.splitToIntList(csvBitIndex, ",");
		for (Integer bitIndex : bitIndexList) {
			setHoldFlag(holdFlag, bitIndex, setFlag, byteOrder);
		}
	}
}
