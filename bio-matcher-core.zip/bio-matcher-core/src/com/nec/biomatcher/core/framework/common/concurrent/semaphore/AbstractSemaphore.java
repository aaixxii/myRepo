package com.nec.biomatcher.core.framework.common.concurrent.semaphore;

/**
 * The Class AbstractSemaphore.
 */
public abstract class AbstractSemaphore {

	/** The semaphore id. */
	protected String semaphoreId;

	/**
	 * Instantiates a new abstract semaphore.
	 *
	 * @param semaphoreId
	 *            the semaphore id
	 */
	public AbstractSemaphore(String semaphoreId) {
		this.semaphoreId = semaphoreId;
	}

	/**
	 * Acquire.
	 *
	 * @throws InterruptedException
	 *             the interrupted exception
	 */
	public abstract void acquire() throws InterruptedException;

	/**
	 * Release.
	 */
	public abstract void release();

	/**
	 * Drain permits.
	 */
	public abstract void drainPermits();

	/**
	 * Available permits.
	 *
	 * @return the int
	 */
	public abstract int availablePermits();

	public abstract void setMaxPermits(int maxPermits) throws InterruptedException;

}
