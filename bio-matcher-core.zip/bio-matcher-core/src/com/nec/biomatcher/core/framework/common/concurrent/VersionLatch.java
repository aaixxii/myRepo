package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class VersionLatch {
	private AtomicLong version = new AtomicLong(Long.MIN_VALUE + 1);

	private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

	private final Lock readLock = lock.readLock();

	private final Lock writeLock = lock.writeLock();

	private final Condition changeCondition = writeLock.newCondition();

	public long getVersion() {
		return version.get();
	}

	public long incrementVersion() {
		if (writeLock.tryLock()) {
			try {
				long newVersion = version.incrementAndGet();
				changeCondition.signalAll();
				return newVersion;
			} finally {
				writeLock.unlock();
			}
		} else {
			return version.incrementAndGet();
		}
	}

	public long waitForChange(long checkVersion) {
		long currentVersion = version.get();
		if (checkVersion != currentVersion) {
			return currentVersion;
		}

		writeLock.lock();
		try {
			currentVersion = version.get();
			if (checkVersion != currentVersion) {
				return currentVersion;
			}

			changeCondition.awaitUninterruptibly();

			return version.get();
		} finally {
			writeLock.unlock();
		}
	}

	public long waitForChange(long checkVersion, long duration, TimeUnit timeUnit) throws InterruptedException {
		long currentVersion = version.get();
		if (checkVersion != version.get()) {
			return currentVersion;
		}

		writeLock.lock();
		try {
			currentVersion = version.get();
			if (checkVersion != currentVersion) {
				return currentVersion;
			}

			changeCondition.await(duration, timeUnit);

			return version.get();
		} finally {
			writeLock.unlock();
		}
	}

	public long waitForChange(long duration, TimeUnit timeUnit) throws InterruptedException {
		writeLock.lock();
		try {
			changeCondition.await(duration, timeUnit);

			return version.get();
		} finally {
			writeLock.unlock();
		}
	}

	public long waitForChange() {
		writeLock.lock();
		try {
			changeCondition.awaitUninterruptibly();

			return version.get();
		} finally {
			writeLock.unlock();
		}
	}

	public void lockForRead() {
		readLock.lock();
	}

	public void unlockRead() {
		readLock.unlock();
	}

	public void lockForWrite() {
		writeLock.lock();
	}

	public void unlockWrite() {
		writeLock.unlock();
	}

	public boolean isVersionChanged(long checkVersion) {
		return checkVersion != version.get();
	}

	public void syncPoint() {
		writeLock.lock();
		writeLock.unlock();
	}
}
