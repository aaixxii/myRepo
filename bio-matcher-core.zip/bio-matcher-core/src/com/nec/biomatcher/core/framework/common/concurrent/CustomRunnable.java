package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.atomic.AtomicBoolean;

public interface CustomRunnable {
	public void run(AtomicBoolean stopFlag);
}
