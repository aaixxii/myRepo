package com.nec.biomatcher.core.framework.cache;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.common.PFLogger;

/**
 * The Class CacheRemovalClient.
 */
public class CacheRemovalClient {

	/** The Constant _logger. */
	private static final Logger _logger = Logger.getLogger(CacheRemovalClient.class);

	/** The host name. */
	private String hostName;

	/**
	 * Instantiates a new cache removal client.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public CacheRemovalClient() throws Exception {
		hostName = HostnameUtil.getHostname();
		_logger.debug("In CacheRemovalClient hostName: " + hostName);
	}

	/**
	 * Notify clear cache.
	 *
	 * @param cacheNodeList
	 *            the cache node list
	 * @param cacheRemovalServletUrl
	 *            the cache removal servlet url
	 */
	public void notifyClearCache(String cacheNodeList, String cacheRemovalServletUrl) {
		_logger.info("In notifyClearCache. cacheNodeList: " + cacheNodeList + ", cacheRemovalServletUrl: "
				+ cacheRemovalServletUrl);

		if (StringUtils.isNotBlank(cacheNodeList) && StringUtils.isNotBlank(cacheRemovalServletUrl)) {
			HttpClient client = new HttpClient();
			for (String otherNodehostName : cacheNodeList.split(",")) {
				if (!otherNodehostName.equalsIgnoreCase(hostName)) {
					PostMethod postMethod = new PostMethod(
							cacheRemovalServletUrl.replace("DEFAULTHOSTNAME", otherNodehostName));
					PFLogger.start();
					try {
						postMethod.addParameter("CACHEKEYS", "CLEARALL");
						_logger.debug("Before cache clear notification for ClusterNode: " + otherNodehostName);
						int returnCode = client.executeMethod(postMethod);
						_logger.trace("Response from hostName: " + otherNodehostName + ", returnCode: " + returnCode
								+ ", : " + postMethod.getResponseBodyAsString());
					} catch (Throwable th) {
						_logger.error("Error while  clear notification for ClusterNode: " + otherNodehostName
								+ ", Msg: " + th.getMessage(), th);
					} finally {
						PFLogger.end("After notify clearCache for otherNodehostName: " + otherNodehostName);
						postMethod.releaseConnection();
					}
				}
			}
		}
	}

}
