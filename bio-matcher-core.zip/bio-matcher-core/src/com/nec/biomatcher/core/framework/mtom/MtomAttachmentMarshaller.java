package com.nec.biomatcher.core.framework.mtom;

import java.util.ArrayList;
import java.util.List;

import javax.activation.DataHandler;
import javax.xml.bind.attachment.AttachmentMarshaller;

/**
 * The Class MtomAttachmentMarshaller.
 *
 * @author yogananda.nbec This class is provides the necessary support needed
 *         for reading MTOM message, for the marshalling functionality
 */
public class MtomAttachmentMarshaller extends AttachmentMarshaller {

	/** The Constant THRESHOLD. */
	private static final int THRESHOLD = 10;

	/** The attachments. */
	private List<Attachment> attachments = new ArrayList<Attachment>();

	public List<Attachment> getAttachments() {
		return attachments;
	}

	@Override
	public String addMtomAttachment(DataHandler data, String elementNamespace, String elementLocalName) {
		return null;
	}

	@Override
	public String addMtomAttachment(byte[] data, int offset, int length, String mimeType, String elementNamespace,
			String elementLocalName) {
		if (data == null || data.length < THRESHOLD) {
			return null;
		}
		int id = attachments.size() + 1;
		attachments.add(new Attachment(data, offset, length));
		return "cid:" + String.valueOf(id);
	}

	@Override
	public String addSwaRefAttachment(DataHandler data) {
		return null;
	}

	@Override
	public boolean isXOPPackage() {
		return true;
	}

	/**
	 * The Class Attachment.
	 */
	public static class Attachment {

		/** The data. */
		private byte[] data;

		/** The offset. */
		private int offset;

		/** The length. */
		private int length;

		/**
		 * Instantiates a new attachment.
		 *
		 * @param data
		 *            the data
		 * @param offset
		 *            the offset
		 * @param length
		 *            the length
		 */
		public Attachment(byte[] data, int offset, int length) {
			this.data = data;
			this.offset = offset;
			this.length = length;
		}

		public byte[] getData() {
			return data;
		}

		public int getOffset() {
			return offset;
		}

		public int getLength() {
			return length;
		}

	}

}