package com.nec.biomatcher.core.framework.dataAccess;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

/**
 * The Interface HibernateDao.
 */
public interface HibernateDao {

	/**
	 * Merge entity.
	 *
	 * @param entity
	 *            the entity
	 * @return the object
	 * @throws DaoException
	 *             the dao exception
	 */
	public Object mergeEntity(Object entity) throws DaoException;

	/**
	 * Save entity.
	 *
	 * @param entity
	 *            the entity
	 * @return the object
	 * @throws DaoException
	 *             the dao exception
	 */
	public Object saveEntity(Object entity) throws DaoException;

	/**
	 * Delete entity.
	 *
	 * @param entity
	 *            the entity
	 * @throws DaoException
	 *             the dao exception
	 */
	public void deleteEntity(Object entity) throws DaoException;

	/**
	 * Delete entities.
	 *
	 * @param entities
	 *            the entities
	 * @throws DaoException
	 *             the dao exception
	 */
	public void deleteEntities(Collection<?> entities) throws DaoException;

	/**
	 * Gets the all entity.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @return the all entity
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> List<T> getAllEntity(Class<T> entityClass) throws DaoException;

	/**
	 * Update entity.
	 *
	 * @param entity
	 *            the entity
	 * @throws DaoException
	 *             the dao exception
	 */
	public void updateEntity(Object entity) throws DaoException;

	/**
	 * Save or update entity.
	 *
	 * @param entity
	 *            the entity
	 * @throws DaoException
	 *             the dao exception
	 */
	public void saveOrUpdateEntity(Object entity) throws DaoException;

	/**
	 * Evict all.
	 *
	 * @param collObj
	 *            the coll obj
	 * @throws DaoException
	 *             the dao exception
	 */
	public void evictAll(Collection<?> collObj) throws DaoException;

	public void evict(Object entity) throws DaoException;

	/**
	 * Gets the entity.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param primaryKey
	 *            the primary key
	 * @return the entity
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> T getEntity(Class<T> entityClass, Serializable primaryKey) throws DaoException;

	/**
	 * Gets the entity for update.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param primaryKey
	 *            the primary key
	 * @return the entity for update
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> T getEntityForUpdate(final Class<T> entityClass, final Serializable primaryKey) throws DaoException;

	/**
	 * Gets the entity list.
	 *
	 * @param <T>
	 *            the generic type
	 * @param criteria
	 *            the criteria
	 * @return the entity list
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> List<T> getEntityList(DetachedCriteria criteria) throws DaoException;

	/**
	 * Gets the entity list.
	 *
	 * @param <T>
	 *            the generic type
	 * @param criteria
	 *            the criteria
	 * @param firstResult
	 *            the first result
	 * @param maxResults
	 *            the max results
	 * @return the entity list
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> List<T> getEntityList(DetachedCriteria criteria, int firstResult, int maxResults) throws DaoException;

	/**
	 * Gets the entity list by field.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param fieldName
	 *            the field name
	 * @param fieldValue
	 *            the field value
	 * @return the entity list by field
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> List<T> getEntityListByField(final Class<T> entityClass, final String fieldName,
			final Serializable fieldValue) throws DaoException;

	/**
	 * Gets the entity list by field.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param fieldName
	 *            the field name
	 * @param fieldValue
	 *            the field value
	 * @param maxResults
	 *            the max results
	 * @return the entity list by field
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> List<T> getEntityListByField(final Class<T> entityClass, final String fieldName,
			final Serializable fieldValue, int maxResults) throws DaoException;

	/**
	 * Gets the entity by field.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param fieldName
	 *            the field name
	 * @param fieldValue
	 *            the field value
	 * @return the entity by field
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> T getEntityByField(final Class<T> entityClass, final String fieldName, final Serializable fieldValue)
			throws DaoException;

	/**
	 * Gets the entity list by fields.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param fieldName1
	 *            the field name1
	 * @param fieldValue1
	 *            the field value1
	 * @param fieldName2
	 *            the field name2
	 * @param fieldValue2
	 *            the field value2
	 * @return the entity list by fields
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> List<T> getEntityListByFields(final Class<T> entityClass, final String fieldName1,
			final Serializable fieldValue1, final String fieldName2, final Serializable fieldValue2)
			throws DaoException;

	/**
	 * Gets the entity list by fields.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param fieldName1
	 *            the field name1
	 * @param fieldValue1
	 *            the field value1
	 * @param fieldName2
	 *            the field name2
	 * @param fieldValue2
	 *            the field value2
	 * @param maxResults
	 *            the max results
	 * @return the entity list by fields
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> List<T> getEntityListByFields(final Class<T> entityClass, final String fieldName1,
			final Serializable fieldValue1, final String fieldName2, final Serializable fieldValue2, int maxResults)
			throws DaoException;

	/**
	 * Gets the entity by fields.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param fieldName1
	 *            the field name1
	 * @param fieldValue1
	 *            the field value1
	 * @param fieldName2
	 *            the field name2
	 * @param fieldValue2
	 *            the field value2
	 * @return the entity by fields
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> T getEntityByFields(final Class<T> entityClass, final String fieldName1, final Serializable fieldValue1,
			final String fieldName2, final Serializable fieldValue2) throws DaoException;

	/**
	 * Gets the entity by fields.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param fieldName1
	 *            the field name1
	 * @param fieldValue1
	 *            the field value1
	 * @param fieldName2
	 *            the field name2
	 * @param fieldValue2
	 *            the field value2
	 * @param fieldName3
	 *            the field name3
	 * @param fieldValue3
	 *            the field value3
	 * @return the entity by fields
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> T getEntityByFields(final Class<T> entityClass, final String fieldName1, final Serializable fieldValue1,
			final String fieldName2, final Serializable fieldValue2, final String fieldName3,
			final Serializable fieldValue3) throws DaoException;

	/**
	 * Gets the entity by fields.
	 *
	 * @param <T>
	 *            the generic type
	 * @param entityClass
	 *            the entity class
	 * @param fieldName1
	 *            the field name1
	 * @param fieldValue1
	 *            the field value1
	 * @param fieldName2
	 *            the field name2
	 * @param fieldValue2
	 *            the field value2
	 * @param fieldName3
	 *            the field name3
	 * @param fieldValue3
	 *            the field value3
	 * @param fieldName4
	 *            the field name4
	 * @param fieldValue4
	 *            the field value4
	 * @return the entity by fields
	 * @throws DaoException
	 *             the dao exception
	 */
	public <T> T getEntityByFields(final Class<T> entityClass, final String fieldName1, final Serializable fieldValue1,
			final String fieldName2, final Serializable fieldValue2, final String fieldName3,
			final Serializable fieldValue3, final String fieldName4, final Serializable fieldValue4)
			throws DaoException;

	/**
	 * Creates the uuid.
	 *
	 * @return the string
	 * @throws DaoException
	 *             the dao exception
	 */
	public String createUUID() throws DaoException;

	public void flush() throws DaoException;

}
