package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.function.Consumer;

import com.google.common.util.concurrent.AtomicLongMap;
import com.google.common.util.concurrent.Striped;

public class ConcurrentConsumer<K> {
	private static final String DUMMY = "DUMMY";

	private final Striped<Lock> stripedLocks = Striped.lazyWeakLock(1024);
	private final AtomicLongMap<K> keyAccessCounterMap = AtomicLongMap.create();
	private final ConcurrentHashMap<K, AtomicInteger> keyConcurrencyCounterMap = new ConcurrentHashMap<>();
	private final ConcurrentHashMap<K, String> currentAccessMap = new ConcurrentHashMap<>();
	private final Consumer<K> consumer;
	private final int maxCachedConsumerAccessCount;

	private final String name;

	public ConcurrentConsumer(String name, Consumer<K> consumer) {
		this.name = name;
		this.consumer = consumer;
		this.maxCachedConsumerAccessCount = Integer.MAX_VALUE;
	}

	public ConcurrentConsumer(String name, Consumer<K> consumer, int maxCachedConsumerAccessCount) {
		this.name = name;
		this.consumer = consumer;
		this.maxCachedConsumerAccessCount = maxCachedConsumerAccessCount;
	}

	public void invoke(K key) {
		if (key == null) {
			return;
		}

		keyAccessCounterMap.incrementAndGet(key);

		Lock lock = stripedLocks.get(key);
		if (lock.tryLock()) {
			try {
				keyAccessCounterMap.put(key, 0);

				consumer.accept(key);
			} finally {
				lock.unlock();
			}
		}
	}

	public void invokeAll(Collection<K> keys) {
		if (keys == null) {
			return;
		}

		for (K key : keys) {
			invoke(key);
		}
	}

	/**
	 * First concurrent thread which enters this method will execute the
	 * consumer.
	 * 
	 * @param key
	 * @throws Throwable
	 */
	public void invokeFirst(K key) {
		if (key == null) {
			return;
		}

		keyAccessCounterMap.incrementAndGet(key);

		AtomicInteger counter = getConcurrencyCounter(key);

		counter.incrementAndGet();

		try {
			String value = currentAccessMap.computeIfAbsent(key, (newKey) -> {
				keyAccessCounterMap.put(newKey, 0);
				consumer.accept(newKey);
				return DUMMY;
			});
		} finally {
			counter.accumulateAndGet(-1, (currVal, newVal) -> {
				int computedVal = currVal + newVal;
				if (computedVal == 0 || keyAccessCounterMap.get(key) >= maxCachedConsumerAccessCount) {
					currentAccessMap.remove(key);
				}
				return computedVal;
			});
		}

	}

	/**
	 * Last concurrent thread which leaves this method will invoke the consumer.
	 * 
	 * @param key
	 */
	public void invokeLast(final K key) {
		if (key == null) {
			return;
		}

		keyAccessCounterMap.incrementAndGet(key);

		AtomicInteger counter = getConcurrencyCounter(key);
		counter.incrementAndGet();

		counter.accumulateAndGet(-1, (currVal, newVal) -> {
			int computedVal = currVal + newVal;
			if (computedVal == 0 || keyAccessCounterMap.get(key) >= maxCachedConsumerAccessCount) {
				currentAccessMap.remove(key);
			}
			return computedVal;
		});

		String value = currentAccessMap.computeIfAbsent(key, (newKey) -> {
			keyAccessCounterMap.put(newKey, 0);
			consumer.accept(newKey);
			return DUMMY;
		});
	}

	private final AtomicInteger getConcurrencyCounter(K key) {
		AtomicInteger counter = keyConcurrencyCounterMap.get(key);
		if (counter == null) {
			counter = keyConcurrencyCounterMap.computeIfAbsent(key, (newKey) -> new AtomicInteger());
		}
		return counter;
	}

	public String getName() {
		return name;
	}

}
