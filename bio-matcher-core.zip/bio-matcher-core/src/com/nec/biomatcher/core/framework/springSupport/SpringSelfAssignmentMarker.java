package com.nec.biomatcher.core.framework.springSupport;

/**
 * The Interface SpringSelfAssignmentMarker.
 * 
 * Used when we need to access self reference which is proxied by spring.
 */
public interface SpringSelfAssignmentMarker {

	/**
	 * Assign self.
	 *
	 * @param self
	 *            the self
	 * @throws Exception
	 *             the exception
	 */
	public void assignSelf(Object self) throws Exception;
}
