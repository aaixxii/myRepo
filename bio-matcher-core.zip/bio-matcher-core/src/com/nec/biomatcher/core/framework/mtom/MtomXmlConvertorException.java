package com.nec.biomatcher.core.framework.mtom;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class MtomXmlConvertorException.
 */
public class MtomXmlConvertorException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new mtom xml convertor exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public MtomXmlConvertorException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new mtom xml convertor exception.
	 *
	 * @param message
	 *            the message
	 */
	public MtomXmlConvertorException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new mtom xml convertor exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public MtomXmlConvertorException(Throwable cause) {
		super(cause);
	}

}
