package com.nec.biomatcher.core.framework.common;

import java.util.HashMap;
import java.util.function.Function;

public class ValuedHashMap<K, V> extends HashMap<K, V> {
	private static final long serialVersionUID = 1L;

	private final Function<K, V> valueFunction;

	public ValuedHashMap(Function<K, V> valueFunction) {
		this.valueFunction = valueFunction;
	}

	public final V getValue(K key) {
		V value = get(key);

		if (value == null) {
			value = computeIfAbsent(key, valueFunction);
		}

		return value;
	}
}
