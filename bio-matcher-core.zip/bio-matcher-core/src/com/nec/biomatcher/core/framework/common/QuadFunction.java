package com.nec.biomatcher.core.framework.common;

@FunctionalInterface
public interface QuadFunction<T, U, S, P, R> {
	/**
	 * Applies this function to the given arguments.
	 *
	 * @param t
	 *            the first function argument
	 * @param u
	 *            the second function argument
	 * @param s
	 *            the third function argument
	 * @param p
	 *            the forth function argument
	 * @return the function result
	 */
	R apply(T t, U u, S s, P p);

}
