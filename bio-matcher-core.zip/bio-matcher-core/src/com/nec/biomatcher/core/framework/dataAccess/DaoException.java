package com.nec.biomatcher.core.framework.dataAccess;

/**
 * The Class DaoException.
 */
public class DaoException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new dao exception.
	 *
	 * @param message
	 *            the message
	 * @param th
	 *            the th
	 */
	public DaoException(String message, Throwable th) {
		super(message, th);
	}

	/**
	 * Instantiates a new dao exception.
	 *
	 * @param th
	 *            the th
	 */
	public DaoException(Throwable th) {
		super(th.getMessage(), th);
	}

	/**
	 * Instantiates a new dao exception.
	 *
	 * @param message
	 *            the message
	 */
	public DaoException(String message) {
		super(message);
	}

}
