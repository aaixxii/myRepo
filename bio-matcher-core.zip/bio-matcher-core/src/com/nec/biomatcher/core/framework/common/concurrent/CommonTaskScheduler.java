package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

/**
 * The Class CommonTaskScheduler.
 */
public class CommonTaskScheduler {

	/** The Constant _logger. */
	private static final Logger _logger = Logger.getLogger(CommonTaskScheduler.class);

	public static final ExecutorService CACHED_EXECUTORSERVICE = Executors.newCachedThreadPool();

	/** The Constant scheduledExecutor. */
	private static final ScheduledThreadPoolExecutor scheduledExecutor = new ScheduledThreadPoolExecutor(10);

	/** The Constant scheduledTaskMap. */
	private static final Map<Runnable, ScheduledFuture<?>> scheduledTaskMap = new IdentityHashMap<Runnable, ScheduledFuture<?>>();

	/**
	 * Schedule with fixed delay.
	 *
	 * @param command
	 *            the command
	 * @param initialDelay
	 *            the initial delay
	 * @param delay
	 *            the delay
	 * @param unit
	 *            the unit
	 * @return the scheduled future
	 */
	public static synchronized ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay,
			long delay, TimeUnit unit) {
		_logger.info("Before scheduleWithFixedDelay " + command.getClass().getSimpleName() + ", initialDelay: "
				+ initialDelay + ", delay: " + delay + ", unit: " + unit);

		scheduledExecutor.setCorePoolSize(scheduledExecutor.getCorePoolSize() + 1);
		ScheduledFuture<?> scheduledFuture = scheduledExecutor.scheduleWithFixedDelay(command, initialDelay, delay,
				unit);
		scheduledTaskMap.put(command, scheduledFuture);
		_logger.info("After scheduleWithFixedDelay " + command.getClass().getSimpleName() + ", CorePoolSize: "
				+ scheduledExecutor.getCorePoolSize());

		return scheduledFuture;
	}

	/**
	 * Schedule.
	 *
	 * @param command
	 *            the command
	 * @param delay
	 *            the delay
	 * @param unit
	 *            the unit
	 * @return the scheduled future
	 */
	public static synchronized ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
		_logger.info("Before schedule " + command.getClass().getSimpleName() + ", delay: " + delay + ", unit: " + unit);

		scheduledExecutor.setCorePoolSize(scheduledExecutor.getCorePoolSize() + 1);
		ScheduledFuture<?> scheduledFuture = scheduledExecutor.schedule(command, delay, unit);
		scheduledTaskMap.put(command, scheduledFuture);
		_logger.info("After schedule " + command.getClass().getSimpleName() + ", CorePoolSize: "
				+ scheduledExecutor.getCorePoolSize());

		return scheduledFuture;
	}

	/**
	 * Checks if is task scheduled.
	 *
	 * @param command
	 *            the command
	 * @return true, if is task scheduled
	 */
	public static boolean isTaskScheduled(Runnable command) {
		return scheduledTaskMap.containsKey(command);
	}

	/**
	 * Cancel task.
	 *
	 * @param command
	 *            the command
	 */
	public static void cancelTask(Runnable command) {
		try {
			if (command == null) {
				return;
			}

			ScheduledFuture<?> scheduledFuture = scheduledTaskMap.get(command);
			if (scheduledFuture != null) {
				scheduledExecutor.setRemoveOnCancelPolicy(true);

				scheduledFuture.cancel(false);

				scheduledTaskMap.remove(command);
				_logger.info("After canceling the scheduled task " + command.getClass().getName());
			}
		} catch (Throwable th) {
			_logger.error("Error while canceling the scheduled task " + command.getClass().getName() + " : "
					+ th.getMessage(), th);
		}
	}

	/**
	 * Cancel task.
	 *
	 * @param command
	 *            the command
	 * @param interrupt
	 *            the interrupt
	 */
	public static void cancelTask(Runnable command, boolean interrupt) {
		try {
			if (command == null) {
				return;
			}

			ScheduledFuture<?> scheduledFuture = scheduledTaskMap.get(command);
			if (scheduledFuture != null) {
				scheduledExecutor.setRemoveOnCancelPolicy(true);

				try {
					scheduledFuture.cancel(interrupt);
				} finally {
					scheduledTaskMap.remove(command);
				}

				_logger.info("After canceling the scheduled task " + command.getClass().getName() + " : "
						+ command.toString());
			}
		} catch (Throwable th) {
			_logger.error("Error while canceling the scheduled task " + command.getClass().getName() + " : "
					+ command.toString() + " : " + th.getMessage(), th);
		}
	}
}
