package com.nec.biomatcher.core.framework.dataAccess;

import org.apache.log4j.Logger;
import org.hibernate.dialect.Dialect;
import org.hibernate.dialect.MySQL57InnoDBDialect;
import org.hibernate.dialect.MySQL5InnoDBDialect;
import org.hibernate.dialect.PostgreSQL9Dialect;
import org.hibernate.engine.jdbc.dialect.internal.StandardDialectResolver;
import org.hibernate.engine.jdbc.dialect.spi.DialectResolutionInfo;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.dataAccess.postgres.PostgreSQL94Dialect;
import com.nec.biomatcher.core.framework.dataAccess.postgres.PostgreSQL95Dialect;

/**
 * Custom dialect resolver is used to switch the default dialect and to make the hibernate configuration database independent.
 * 
 * @author MAHESH
 *
 */
public class CustomDialectResolver extends StandardDialectResolver {
    private static final long serialVersionUID = 1L;

    private static final Logger logger = Logger.getLogger(CustomDialectResolver.class);

    public static final CustomDialectResolver INSTANCE = new CustomDialectResolver();

    @Override
    public Dialect resolveDialect(DialectResolutionInfo info) {
        logger.info("In CustomDialectResolver");
        try {
            final String databaseName = info.getDatabaseName();
            CommonLogger.CONFIG_LOG.info("In CustomDialectResolver: databaseName: " + databaseName);
            
            int majorVersions = info.getDatabaseMajorVersion();            
            CommonLogger.CONFIG_LOG.info("In CustomDialectResolver: majorVersion: " +  majorVersions);
            
            int minorVerison = info.getDatabaseMinorVersion();            
            CommonLogger.CONFIG_LOG.info("In CustomDialectResolver: MinorVersion: " +  minorVerison);
            
           String driverName = info.getDriverName();           
           CommonLogger.CONFIG_LOG.info("In CustomDialectResolver: DriverName: " +  driverName);

            Dialect dialect = null;

            if (databaseName == null) {
                CommonLogger.CONFIG_LOG.error("In CustomDialectResolver: databaseName is null");
                dialect = super.resolveDialect(info);
            } else {
                if ("Oracle".equalsIgnoreCase(databaseName)) {
                    dialect = new Oracle10gDialect();
                } else if ("MySQL".equalsIgnoreCase(databaseName)) {
                    final int majorVersion = info.getDatabaseMajorVersion();
                    if (majorVersion == 5) {
                        final int minorVersion = info.getDatabaseMinorVersion();
                        if (minorVersion >= 7) {
                            dialect = new MySQL57InnoDBDialect();
                        } else {
                            dialect = new MySQL5InnoDBDialect();
                        }  
                        	
                    }
                } else if (databaseName.toUpperCase().contains("MARIA")) {
                    dialect = new MySQL57InnoDBDialect();
                }  else if ("PostgreSQL".equalsIgnoreCase(databaseName)) { 
                	 int majorVer = info.getDatabaseMajorVersion(); 
                	 int minorVer = info.getDatabaseMinorVersion();
                  	if (majorVer >= 9 && minorVer == 4) {
                		return new PostgreSQL94Dialect();
                	}
                	if (majorVersions >= 10) {
                		return new PostgreSQL95Dialect();
                	}
                	 //return new PostgreSQL9Dialect();                	 
                }

                if (dialect == null) {
                    dialect = super.resolveDialect(info);
                }
            }

            if (dialect != null) {
                CommonLogger.CONFIG_LOG.info("In CustomDialectResolver: dialect: " + dialect.getClass().getName());
            } else {
                CommonLogger.CONFIG_LOG.error("In CustomDialectResolver: dialect is null");
            }

            return dialect;
        } catch (RuntimeException ex) {
            logger.error("Error in CustomDialectResolver.resolveDialect: " + ex.getMessage(), ex);
            throw ex;
        }
    }
}
