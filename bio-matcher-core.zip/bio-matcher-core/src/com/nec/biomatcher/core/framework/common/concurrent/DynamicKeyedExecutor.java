package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.log4j.Logger;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

/**
 * The DynamicKeyedExecutor represents Multi Value map whose data will be
 * processed concurrently, Once value list becomes empty the key will be
 * removed. Execution concurrency can be configured per key and for overall map.
 * 
 * @author Mahesh
 *
 * @param <K>
 * @param <V>
 */
public class DynamicKeyedExecutor<K, V> {
	private static final Logger logger = Logger.getLogger(DynamicKeyedExecutor.class);

	private static final ExecutorService cachedExecutorService = CommonTaskScheduler.CACHED_EXECUTORSERVICE;
	private final String name;
	private final ConcurrentSkipListMap<K, ConcurrentLinkedQueue<V>> keyValueQueueMap = new ConcurrentSkipListMap<>();
	private final ConcurrentSkipListMap<K, Semaphore> keySemaphoreMap = new ConcurrentSkipListMap<>();
	private final AtomicReference<K> globalCurrentPolledKey = new AtomicReference<>();
	private final DynamicSemaphore totalConcurrencySemaphore;
	private final BiConsumer<K, ConcurrentLinkedQueue<V>> consumer;
	private final LoadingCache<K, ConcurrentLinkedQueue<V>> queueCache;

	private final BiFunction<ConcurrentLinkedQueue<V>, ConcurrentLinkedQueue<V>, ConcurrentLinkedQueue<V>> keyValueQueueMergeFunction = (
			currVal, newVal) -> {
		if (currVal == newVal || newVal == null) {
			return currVal;
		}

		if (currVal == null) {
			return newVal;
		}

		V value = null;
		while ((value = newVal.poll()) != null) {
			currVal.add(value);
		}

		return currVal;
	};

	private final BiFunction<K, ConcurrentLinkedQueue<V>, ConcurrentLinkedQueue<V>> keyValueQueueRemoveIfEmptyFunction = (
			key, currVal) -> {
		if (currVal == null || currVal.isEmpty()) {
			keyValueQueueMap.remove(key);
			return null;
		}
		return currVal;
	};

	private final BiFunction<K, ConcurrentLinkedQueue<V>, ConcurrentLinkedQueue<V>> keyValueQueueRemoveFunction = (key,
			currVal) -> {
		if (currVal != null) {
			currVal.clear();
		}

		keyValueQueueMap.remove(key);
		return null;
	};

	private final BinaryOperator<K> findNextKeyFunction = (currVal, nextVal) -> {
		if (currVal != null) {
			K newVal = keyValueQueueMap.ceilingKey(currVal);
			if (newVal != null) {
				return newVal;
			}
		}

		Entry<K, ConcurrentLinkedQueue<V>> firstEntry = keyValueQueueMap.firstEntry();
		if (firstEntry != null) {
			return firstEntry.getKey();
		}

		return null;
	};

	private final Function<K, Semaphore> keySemaphoreFunction;

	public DynamicKeyedExecutor(String name, BiConsumer<K, ConcurrentLinkedQueue<V>> consumer,
			Supplier<Integer> concurrencyPerKeySupplier, Supplier<Integer> totalConcurrencySupplier) {
		this.name = name;
		this.consumer = consumer;
		this.totalConcurrencySemaphore = DynamicSemaphore.getInstance(name + "_semaphore", totalConcurrencySupplier);
		this.keySemaphoreFunction = (key) -> new Semaphore(concurrencyPerKeySupplier.get());

		this.queueCache = CacheBuilder.newBuilder().maximumSize(1024).concurrencyLevel(100)
				.expireAfterWrite(30, TimeUnit.SECONDS).build(new CacheLoader<K, ConcurrentLinkedQueue<V>>() {
					public ConcurrentLinkedQueue<V> load(K key) {
						return new ConcurrentLinkedQueue<>();
					}
				});

	}

	public final ConcurrentLinkedQueue<V> get(K key) {
		return keyValueQueueMap.get(key);
	}

	public final ConcurrentLinkedQueue<V> remove(K key) {
		ConcurrentLinkedQueue<V> valueQueue = keyValueQueueMap.computeIfPresent(key, keyValueQueueRemoveFunction);
		if (valueQueue == null) {
			keySemaphoreMap.remove(key);
		}
		return valueQueue;
	}

	public final ConcurrentLinkedQueue<V> removeIfEmpty(K key) {
		ConcurrentLinkedQueue<V> valueQueue = keyValueQueueMap.computeIfPresent(key,
				keyValueQueueRemoveIfEmptyFunction);
		if (valueQueue == null) {
			keySemaphoreMap.remove(key);
		}
		return valueQueue;
	}

	public final void put(K key, final V value) {
		ConcurrentLinkedQueue<V> valueQueue = keyValueQueueMap.get(key);
		if (valueQueue == null) {
			try {
				valueQueue = queueCache.get(key);
			} catch (Throwable th) {
				logger.error(
						"Error during queueCache.get for key: " + key + ", name: " + name + " : " + th.getMessage(),
						th);
				valueQueue = new ConcurrentLinkedQueue<>();
			}
		}

		valueQueue.add(value);

		keyValueQueueMap.merge(key, valueQueue, keyValueQueueMergeFunction);

		if (totalConcurrencySemaphore.tryAcquire()) {
			try {
				cachedExecutorService.submit(new WorkerThread(key));
			} catch (Throwable th) {
				totalConcurrencySemaphore.release();
				logger.error("Error during cachedExecutorService.submit in DynamicKeyedExecutor:" + name + " : "
						+ th.getMessage(), th);
			}
		}
	}

	private class WorkerThread implements Runnable {
		private K currKey;

		public WorkerThread(K currKey) {
			this.currKey = currKey;
		}

		@Override
		public void run() {
			Thread currentThread = Thread.currentThread();
			currentThread.setName("DKE_WRK_" + name + "_" + currentThread.getId());

			K prevKey = null;
			do {
				if (currKey == null) {
					currKey = globalCurrentPolledKey.accumulateAndGet(null, findNextKeyFunction);
					if (currKey == null) {
						totalConcurrencySemaphore.release();
						break;
					}
				}

				try {
					do {
						Semaphore keyConcurrencySemaphore = keySemaphoreMap.get(currKey);
						if (keyConcurrencySemaphore == null) {
							keyConcurrencySemaphore = keySemaphoreMap.computeIfAbsent(currKey, keySemaphoreFunction);
						}

						if (keyConcurrencySemaphore.tryAcquire()) {
							try {
								ConcurrentLinkedQueue<V> valueQueue = keyValueQueueMap.get(currKey);
								if (valueQueue != null && !valueQueue.isEmpty()) {
									consumer.accept(currKey, valueQueue);
								}
							} finally {
								keyConcurrencySemaphore.release();
								prevKey = currKey;

								removeIfEmpty(currKey);
							}
						}
					} while (!ShutdownHook.isShutdownFlag
							&& (currKey = globalCurrentPolledKey.accumulateAndGet(null, findNextKeyFunction)) != null);
				} finally {
					totalConcurrencySemaphore.release();
				}
			} while (!ShutdownHook.isShutdownFlag && !keySemaphoreMap.isEmpty()
					&& totalConcurrencySemaphore.tryAcquire());
		}
	}
}
