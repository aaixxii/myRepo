package com.nec.biomatcher.core.framework.common;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.cache.Cache;
import com.google.common.collect.Maps;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;

public class GuavaCacheCleaner implements Runnable {
	private static final Logger logger = Logger.getLogger(Logger.class);
	private static Map<String, Cache<?, ?>> cacheMap = Maps.newIdentityHashMap();

	private static final GuavaCacheCleaner GUAVA_CACHE_CLEANER = new GuavaCacheCleaner();

	private GuavaCacheCleaner() {
		CommonTaskScheduler.scheduleWithFixedDelay(this, 100, 100, TimeUnit.SECONDS);
	}

	public static synchronized void registerCache(String cacheName, Cache<?, ?> cache) {
		if (cacheName != null && cache != null) {
			cacheMap.put(cacheName, cache);
		}
	}

	private static synchronized void cleanCache() {
		cacheMap.entrySet().forEach(cacheEntry -> {
			long oldSize = 0;
			long newSize = 0;
			boolean errorFlag = false;
			PFLogger.start();
			try {
				oldSize = cacheEntry.getValue().size();
				cacheEntry.getValue().cleanUp();
				newSize = cacheEntry.getValue().size();
			} catch (Throwable th) {
				errorFlag = true;
				logger.error("Error during cache cleanUp: " + th.getMessage(), th);
			} finally {
				PFLogger.end(500,
						"cacheName: " + cacheEntry.getKey() + ", cacheSize: " + newSize + ", removedEntryCount: "
								+ (newSize - oldSize) + ", stats: " + cacheEntry.getValue().stats()
								+ (errorFlag ? ", errorFlag=true" : ""));
			}
		});
	}

	@Override
	public void run() {
		try {
			while (!ShutdownHook.isShutdownFlag) {
				try {
					cleanCache();
				} catch (Throwable th) {
					logger.error("Error in GuavaCacheCleaner: " + th.getMessage(), th);
				} finally {
					Uninterruptibles.sleepUninterruptibly(1, TimeUnit.MINUTES);
				}
			}
		} finally {
			CommonLogger.STATUS_LOG.warn("Exiting GuavaCacheCleaner: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
		}
	}

}
