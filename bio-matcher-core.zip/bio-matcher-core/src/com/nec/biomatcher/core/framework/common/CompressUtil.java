package com.nec.biomatcher.core.framework.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * The Class CompressUtil.
 *
 * @author Alvin Chua
 */

public class CompressUtil {

	/**
	 * String to gzip.
	 *
	 * @param data
	 *            the data
	 * @param charset
	 *            the charset
	 * @return the byte[]
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static byte[] stringToGzip(String data, String charset) throws IOException {
		GZIPOutputStream gzOut = null;
		try {
			ByteArrayOutputStream bOut = new ByteArrayOutputStream();

			gzOut = new GZIPOutputStream(bOut);
			if (charset == null) {
				gzOut.write(data.getBytes());
			} else {
				gzOut.write(data.getBytes(charset));
			}
			gzOut.close();
			gzOut = null;

			return bOut.toByteArray();
		} finally {
			if (gzOut != null) {
				gzOut.close();
			}
		}
	}

	/**
	 * Gzip to string.
	 *
	 * @param data
	 *            the data
	 * @param charset
	 *            the charset
	 * @return the string
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static String gzipToString(byte data[], String charset) throws IOException {
		GZIPInputStream gzIn = null;
		try {
			byte tmpBuf[] = new byte[data.length];
			int len = 0;
			ByteArrayOutputStream bOut = new ByteArrayOutputStream();
			gzIn = new GZIPInputStream(new ByteArrayInputStream(data));
			while ((len = gzIn.read(tmpBuf, 0, tmpBuf.length)) > 0) {
				bOut.write(tmpBuf, 0, len);
			}
			gzIn.close();
			gzIn = null;
			if (charset == null) {
				return bOut.toString();
			} else {
				return bOut.toString(charset);
			}
		} finally {
			if (gzIn != null) {
				gzIn.close();
			}
		}
	}

	/**
	 * Byte to gzip.
	 *
	 * @param data
	 *            the data
	 * @return the byte[]
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static byte[] byteToGzip(byte data[]) throws IOException {
		GZIPOutputStream gzOut = null;
		try {
			ByteArrayOutputStream bOut = new ByteArrayOutputStream();

			gzOut = new GZIPOutputStream(bOut);
			gzOut.write(data);
			gzOut.close();
			gzOut = null;

			return bOut.toByteArray();

		} finally {
			if (gzOut != null) {
				gzOut.close();
			}
		}
	}

	/**
	 * Gzip to bytes.
	 *
	 * @param data
	 *            the data
	 * @return the byte[]
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static byte[] gzipToBytes(byte data[]) throws IOException {
		GZIPInputStream gzIn = null;
		try {
			byte tmpBuf[] = new byte[data.length];
			int len = 0;
			ByteArrayOutputStream bOut = new ByteArrayOutputStream();
			gzIn = new GZIPInputStream(new ByteArrayInputStream(data));
			while ((len = gzIn.read(tmpBuf, 0, tmpBuf.length)) > 0) {
				bOut.write(tmpBuf, 0, len);
			}
			gzIn.close();
			gzIn = null;
			return bOut.toByteArray();
		} finally {
			if (gzIn != null) {
				gzIn.close();
			}
		}
	}

	/**
	 * Checks if is gzip compressed.
	 *
	 * @param bytes
	 *            the bytes
	 * @return true, if is gzip compressed
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public static boolean isGzipCompressed(byte[] bytes) throws IOException {
		if ((bytes == null) || (bytes.length < 2)) {
			return false;
		} else {
			return ((bytes[0] == (byte) (GZIPInputStream.GZIP_MAGIC))
					&& (bytes[1] == (byte) (GZIPInputStream.GZIP_MAGIC >> 8)));
		}
	}
}
