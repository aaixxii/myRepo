package com.nec.biomatcher.core.framework.common.pagination;

import java.io.Serializable;

/**
 * The Class OrderedColumn.
 *
 * @author Mahesh
 */
public class OrderedColumn implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Constant ASCENDING. */
	public static final int ASCENDING = 0;

	/** The Constant DESCNDING. */
	public static final int DESCNDING = 1;

	/** The column name. */
	private String columnName;

	/** The order type. */
	private int orderType;

	/**
	 * Instantiates a new ordered column.
	 */
	public OrderedColumn() {

	}

	/**
	 * Instantiates a new ordered column.
	 *
	 * @param columnName
	 *            the column name
	 * @param orderType
	 *            the order type
	 */
	public OrderedColumn(String columnName, int orderType) {
		this.columnName = columnName;
		this.orderType = orderType;
	}

	/**
	 * Gets the column name.
	 *
	 * @return the column name
	 */
	public String getColumnName() {
		return columnName;
	}

	/**
	 * Sets the column name.
	 *
	 * @param columnName
	 *            the new column name
	 */
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	/**
	 * Gets the order type.
	 *
	 * @return the order type
	 */
	public int getOrderType() {
		return orderType;
	}

	/**
	 * Sets the order type.
	 *
	 * @param orderType
	 *            the new order type
	 */
	public void setOrderType(int orderType) {
		this.orderType = orderType;
	}

	/**
	 * Checks if is ascending.
	 *
	 * @return true, if is ascending
	 */
	public boolean isAscending() {
		return orderType == ASCENDING;
	}

	/**
	 * Asc.
	 *
	 * @param columnName
	 *            the column name
	 * @return the ordered column
	 */
	public static OrderedColumn asc(String columnName) {
		return new OrderedColumn(columnName, ASCENDING);
	}

	/**
	 * Desc.
	 *
	 * @param columnName
	 *            the column name
	 * @return the ordered column
	 */
	public static OrderedColumn desc(String columnName) {
		return new OrderedColumn(columnName, DESCNDING);
	}
}
