package com.nec.biomatcher.core.framework.license.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class InvalidLicenseException.
 */
public class InvalidLicenseException extends CoreException {

	/**
	 * The Constructor.
	 */
	public InvalidLicenseException() {
		super("Invalid license.");
	}

	/**
	 * The Constructor.
	 * 
	 * @param message
	 *            the message
	 */
	public InvalidLicenseException(String message) {
		super(message);
	}

	/**
	 * The Constructor.
	 * 
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public InvalidLicenseException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * The Constructor.
	 * 
	 * @param cause
	 *            the cause
	 */
	public InvalidLicenseException(Throwable cause) {
		super("Invalid license. Cause: " + cause.getMessage(), cause);
	}
}
