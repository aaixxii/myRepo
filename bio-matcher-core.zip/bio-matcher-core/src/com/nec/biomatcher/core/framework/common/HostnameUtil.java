package com.nec.biomatcher.core.framework.common;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

/**
 * The Class HostnameUtil.
 */
public class HostnameUtil {

    /** The Constant logger. */
    private static final Logger logger = Logger.getLogger(HostnameUtil.class);
    
    public static final String LOCAL_HOSTNAME="LOCALHOST";
    public static final String LOCAL_IPADDRESS="127.0.0.1";
    

    /** The current hostname. */
    private static String currentHostname;

    /** The current ip address. */
    private static String currentIpAddress;

    private static Set<String> currentHostNameIpAddressSet;

    public static String getHostname() {
        if (currentHostname == null) {
            String tempHostname = null;
            try {
                InetAddress resolvedInetAddress = InetAddress.getLocalHost();

                if (!isValidHostInetAddress(resolvedInetAddress)) {
                    try {
                        resolvedInetAddress = null;

                        Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();

                        for (NetworkInterface netint : Collections.list(nets)) {
                            System.out.println("[HostnameUtil] Interface Name : " + netint.getDisplayName() + ", isUp: " + netint.isUp());
                            if (!netint.isUp()) {
                                continue;
                            }
                            Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
                            for (InetAddress inetAddress : Collections.list(inetAddresses)) {
                                if (isValidHostInetAddress(inetAddress)) {
                                    resolvedInetAddress = inetAddress;
                                    break;
                                }
                            }
                            if (resolvedInetAddress != null) {
                                tempHostname = resolvedInetAddress.getHostName().toUpperCase();
                                break;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace(System.err);
                    }
                    if (tempHostname == null) {
                        tempHostname = InetAddress.getLocalHost().getHostName();
                    }
                }

                if (tempHostname == null) {
                    tempHostname = InetAddress.getLocalHost().getHostName();
                }

            } catch (UnknownHostException ex) {
                throw new RuntimeException("Error resolving hostname, hostname is null or empty: " + tempHostname + " : " + ex.getMessage(), ex);
            }

            logger.info("Resolved hostname: " + tempHostname);

            if (tempHostname == null || tempHostname.trim().length() == 0) {
                throw new RuntimeException("Error resolving hostname, hostname is null or empty: " + tempHostname);
            }

            currentHostname = tempHostname;
        }
        return currentHostname;
    }

    public static String getIpAddress() {
        if (currentIpAddress == null) {
            String tempIpAddress = null;
            try {
                tempIpAddress = InetAddress.getLocalHost().getHostAddress();
            } catch (UnknownHostException ex) {
                throw new RuntimeException("Error resolving hostname, hostname is null or empty: " + tempIpAddress + " : " + ex.getMessage(), ex);
            }

            logger.info("Resolved ipAddress: " + tempIpAddress);

            if (tempIpAddress == null || tempIpAddress.trim().length() == 0) {
                throw new RuntimeException("Error resolving ipAddress, ipAddress is null or empty: " + tempIpAddress);
            }

            currentIpAddress = tempIpAddress;
        }
        return currentIpAddress;
    }

    /**
     * Gets the ip address.
     *
     * @param hostname
     *            the hostname
     * @return the ip address
     * @throws UnknownHostException
     *             the unknown host exception
     */
    public static String getIpAddress(String hostname) throws UnknownHostException {
        if (hostname == null || hostname.trim().length() == 0) {
            return hostname;
        }

        InetAddress[] inetAddressList = InetAddress.getAllByName(hostname);
        if (inetAddressList == null || inetAddressList.length == 0) {
            return hostname;
        }

        for (InetAddress inetAddress : inetAddressList) {
            if (isValidHostInetAddress(inetAddress)) {
                return inetAddress.getHostAddress();
            }
        }

        return hostname;
    }

    public static Set<String> getHostnameIpAddressList(String hostname) {
        Set<String> hostnameIpAddressSet = new HashSet<>();

        if (hostname == null || hostname.trim().length() == 0) {
            return hostnameIpAddressSet;
        }

        hostnameIpAddressSet.add(hostname);

        try {
            InetAddress[] inetAddressList = InetAddress.getAllByName(hostname);
            if (inetAddressList == null || inetAddressList.length == 0) {
                return hostnameIpAddressSet;
            }

            for (InetAddress inetAddress : inetAddressList) {
                if (isValidHostInetAddress(inetAddress)) {
                    hostnameIpAddressSet.add(inetAddress.getHostAddress());
                }
            }

        } catch (Throwable th) {
            logger.error("Error in getHostnameIpAddressList for hostname: " + hostname + " : " + th.getMessage(), th);
        }

        return hostnameIpAddressSet;
    }

    /**
     * Gets the hostname.
     *
     * @param ipAddress
     *            the ip address
     * @return the hostname
     * @throws UnknownHostException
     *             the unknown host exception
     */
    public static String getHostname(String ipAddress) throws UnknownHostException {
        if (ipAddress == null || ipAddress.trim().length() == 0) {
            return ipAddress;
        }

        InetAddress[] inetAddressList = InetAddress.getAllByName(ipAddress);
        if (inetAddressList == null || inetAddressList.length == 0) {
            return ipAddress;
        }

        for (InetAddress inetAddress : inetAddressList) {
            if (isValidHostInetAddress(inetAddress)) {
                return inetAddress.getHostName();
            }
        }

        return ipAddress;
    }

    public static Set<String> getHostnameIpAddressList() {
        if (currentHostNameIpAddressSet != null) {
            return currentHostNameIpAddressSet;
        }
        synchronized (HostnameUtil.class) {
            if (currentHostNameIpAddressSet != null) {
                return currentHostNameIpAddressSet;
            }

            try {
                Set<String> hostnameIpAddressSet = new HashSet<>();

                InetAddress resolvedInetAddress = InetAddress.getLocalHost();
                if (isValidHostInetAddress(resolvedInetAddress)) {
                    hostnameIpAddressSet.add(resolvedInetAddress.getHostName());
                    hostnameIpAddressSet.add(resolvedInetAddress.getHostAddress());
                }

                try {
                    Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();

                    for (NetworkInterface netint : Collections.list(nets)) {
                        System.out.println("[HostnameUtil] Interface Name : " + netint.getDisplayName() + ", isUp: " + netint.isUp());
                        if (!netint.isUp()) {
                            continue;
                        }
                        Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
                        for (InetAddress inetAddress : Collections.list(inetAddresses)) {
                            if (isValidHostInetAddress(inetAddress)) {
                                hostnameIpAddressSet.add(inetAddress.getHostName());
                                hostnameIpAddressSet.add(inetAddress.getHostAddress());
                            }
                        }
                    }
                } catch (Throwable th) {
                    logger.error("Error in getHostnameIpAddressList: " + th.getMessage(), th);
                }

                if (hostnameIpAddressSet.isEmpty()) {
                    throw new RuntimeException("hostnameIpAddressSet is empty");
                }

                currentHostNameIpAddressSet = hostnameIpAddressSet;
            } catch (Throwable th) {
                throw new RuntimeException("Error in getHostnameIpAddressList: " + th.getMessage(), th);
            }
        }

        return currentHostNameIpAddressSet;
    }

    /**
     * Checks if is valid host inet address.
     *
     * @param inetAddress
     *            the inet address
     * @return true, if is valid host inet address
     */
    public static boolean isValidHostInetAddress(InetAddress inetAddress) {
        if (inetAddress == null) {
            System.out.println("[HostnameUtil] InetAddress is null");
            return false;
        }
        System.out.println("[HostnameUtil] validating inetAddress Local host Name: " + inetAddress.getHostName() + ", Host Address: " + inetAddress.getHostAddress());

        if (inetAddress.getHostName() == null || inetAddress.getHostName().trim().length() == 0) {
            return false;
        }
        if (inetAddress.getHostAddress() == null || inetAddress.getHostAddress().trim().length() == 0) {
            return false;
        } else if ("localhost".equalsIgnoreCase(inetAddress.getHostName()) || "127.0.0.1".equalsIgnoreCase(inetAddress.getHostName())) {
            return false;
        } else if ("localhost".equalsIgnoreCase(inetAddress.getHostAddress()) || "127.0.0.1".equalsIgnoreCase(inetAddress.getHostAddress())) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Checks if is valid host name.
     *
     * @param hostname
     *            the hostname
     * @return true, if is valid host name
     */
    public static boolean isValidHostName(String hostname) {
        if (hostname == null || hostname.trim().length() == 0) {
            return false;
        } else if ("localhost".equalsIgnoreCase(hostname) || "127.0.0.1".equalsIgnoreCase(hostname)) {
            return false;
        } else {
            return true;
        }
    }
    
    public static boolean isCurrentHost(String hostname) {
        if (hostname == null || hostname.trim().length() == 0) {
            return false;
        }
        
        if( hostname.equalsIgnoreCase(getHostname()) || hostname.equalsIgnoreCase(getIpAddress()) || hostname.equalsIgnoreCase(LOCAL_HOSTNAME) || hostname.equalsIgnoreCase(LOCAL_IPADDRESS)) {
            return true;
        }

        try {
            if(getHostnameIpAddressList().contains(hostname)) {
                return true;
            }
        }
        catch(Throwable th) {
        }
        
        return false;
    }
    
    public static boolean isLocalhost(String hostname) {
        if (hostname == null) {
            return false;
        }
        
        return hostname.equalsIgnoreCase(LOCAL_HOSTNAME) || hostname.equalsIgnoreCase(LOCAL_IPADDRESS);
    }
    
}
