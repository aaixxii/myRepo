package com.nec.biomatcher.core.framework.cache;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

/**
 * The Class CacheRemovalListenerServlet.
 */
public class CacheRemovalListenerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/** The Constant _logger. */
	private static final Logger _logger = Logger.getLogger(CacheRemovalListenerServlet.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.GenericServlet#init()
	 */
	public void init() throws ServletException {
		_logger.info("In CacheRemovalListenerServlet.init() - Start");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.
	 * HttpServletRequest , javax.servlet.http.HttpServletResponse)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		_logger.info("In CacheRemovalListenerServlet.doPost() - Start");

		String cacheKeys = req.getParameter("CACHEKEYS");
		if (StringUtils.isBlank(cacheKeys)) {
			_logger.warn("cacheKeys is empty: " + cacheKeys);
			resp.getWriter().println("EMPTYKEYS");
			resp.getWriter().println("To clear all cache entries pass parameter as <URL>?CACHEKEYS=CLEARALL");
			return;
		}

		SpringCacheManager cacheManager = (SpringCacheManager) SpringServiceManager.getBean("methodCacheManager");

		if (cacheKeys.indexOf("CLEARALL") > -1) {
			cacheManager.removeAll();
			_logger.debug("After clearing all cacheKeys");
			resp.getWriter().println("SUCCESS");
		} else {
			String cacheKeyArr[] = cacheKeys.split(",");
			for (String cacheKey : cacheKeyArr) {
				if (StringUtils.isNotBlank(cacheKey)) {
					cacheManager.removeKeysStartsWith(cacheKey);
					_logger.debug("After clearing cacheKey: " + cacheKey);
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.
	 * HttpServletRequest , javax.servlet.http.HttpServletResponse)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		_logger.info("In CacheRemovalListenerServlet.doGet() - Start");
		doPost(req, resp);
	}

}
