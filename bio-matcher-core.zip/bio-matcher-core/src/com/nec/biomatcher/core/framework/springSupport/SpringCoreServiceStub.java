package com.nec.biomatcher.core.framework.springSupport;

/**
 * The Class SpringCoreServiceStub.
 *
 * @author Alvin Chua
 */
public class SpringCoreServiceStub extends AbstractService {

	/** The name. */
	String name = "__SpringCoreServiceStub";

	/**
	 * Sets the name.
	 *
	 * @param name
	 *            the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nec.asia.baf.framework.springSupport.AbstractService#getName()
	 */
	public String getName() {
		if (name == null)
			return "__SpringCoreServiceStub";
		return name;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nec.asia.baf.framework.springSupport.AbstractService#start()
	 */
	public void start() {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.nec.asia.baf.framework.springSupport.AbstractService#stop()
	 */
	public void stop() throws Exception {
		// TODO Auto-generated method stub

	}

}
