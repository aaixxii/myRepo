package com.nec.biomatcher.core.framework.common;

import java.util.Stack;

import org.apache.log4j.Logger;

/**
 * Performance logger util to track the time taken to execute the method.
 *
 * @author Mahesh
 */
public class PFLogger {

	/** The Constant pflogger. */
	public static final Logger pflogger = Logger.getLogger("PFLogger");

	/** The Constant loggerClassName. */
	private static final String loggerClassName = PFLogger.class.getName();

	/** The CALLE r_ stacktrac e_ index. */
	private static int CALLER_STACKTRACE_INDEX = 3;

	/** The local context. */
	private static ThreadLocal<Stack<Long>> localContext = new ThreadLocal<Stack<Long>>() {
		protected synchronized Stack<Long> initialValue() {
			return new Stack<Long>();
		}
	};

	/**
	 * Start.
	 */
	public static void start() {
		localContext.get().push(System.currentTimeMillis());
	}

	/**
	 * End.
	 */
	public static void end() {
		end(pflogger, -1L, null, CALLER_STACKTRACE_INDEX);
	}

	/**
	 * End.
	 *
	 * @param message
	 *            the message
	 */
	public static void end(String message) {
		end(pflogger, -1L, message, CALLER_STACKTRACE_INDEX);
	}

	public static void end(long timeTakenMilliThreshold, String message) {
		end(pflogger, timeTakenMilliThreshold, message, CALLER_STACKTRACE_INDEX);
	}

	/**
	 * End.
	 *
	 * @param logger
	 *            the logger
	 * @param message
	 *            the message
	 */
	public static void end(Logger logger, String message) {
		end(logger, -1L, message, CALLER_STACKTRACE_INDEX);
	}

	/**
	 * End.
	 *
	 * @param logger
	 *            the logger
	 * @param message
	 *            the message
	 * @param stackTraceIndex
	 *            the stack trace index
	 */
	private static final void end(Logger logger, long timeTakenMilliThreshold, String message, int stackTraceIndex) {
		long endTime = System.currentTimeMillis();
		Stack<Long> stack = localContext.get();
		try {
			if (stack.size() == 0) {
				return;
			}
			Long startTime = stack.pop();
			long timeTakenMilli = endTime - startTime;
			if (logger.isTraceEnabled()
					&& (timeTakenMilliThreshold <= -1L || timeTakenMilli >= timeTakenMilliThreshold)) {
				StackTraceElement stElements[] = Thread.currentThread().getStackTrace();
				while (stElements.length > stackTraceIndex) {
					String className = stElements[stackTraceIndex].getClassName();
					if (loggerClassName.equals(className)) {
						stackTraceIndex++;
						continue;
					}

					String methodName = stElements[stackTraceIndex].getMethodName();
					int classNameIndex = className.lastIndexOf(".") + 1;
					className = className.substring(classNameIndex);
					if (message != null) {
						logger.trace("[" + className + "." + methodName + "] TimetakenMilli: " + timeTakenMilli
								+ " ,message: " + message);
					} else {
						logger.trace("[" + className + "." + methodName + "] TimetakenMilli: " + timeTakenMilli);
					}
					break;
				}

			}
		} finally {
			if (stack.size() == 0) {
				localContext.remove();
			}
		}
	}

	public static final long getTimeTakenMilli() {
		long startTime = System.currentTimeMillis();
		long endTime = startTime;

		Stack<Long> stack = localContext.get();
		try {
			if (stack.size() > 0) {
				startTime = stack.pop();
			}
		} finally {
			if (stack.size() == 0) {
				localContext.remove();
			}
		}

		return endTime - startTime;
	}

	/**
	 * Peek time taken milli.
	 *
	 * @return the long
	 */
	public static final long peekTimeTakenMilli() {
		long startTime = System.currentTimeMillis();
		long endTime = startTime;

		Stack<Long> stack = localContext.get();
		if (stack.size() > 0) {
			startTime = stack.peek();
		}

		return endTime - startTime;
	}

}
