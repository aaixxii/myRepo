var CANVAS_F_ID = 'canvas_f';
var CANVAS_S_ID = 'canvas_S';

function enhancePicxels() {
    var canvasf = document.getElementById("canvas_f");
    var cxtf = canvasf.getContext("2d");
    var imageDataf = cxtf.getImageData(0, 0, canvasf.width, canvasf.height);
    var data = imageDataf.data;
    var size = data.size / 4;
    for (var i = 0; i < size; i = i + 5) {
        var posx = randomPosition(size);
        var posy = randomPosition(size);
        var color = randomRGB();
        setPixel(canvasf, posx, posy.color);
    }
}

function setPixel(canvasId, xpos, ypos, col) {
    var element = document.getElementById(canvasId);
    var ctx = element.getContext("2d");
    ctx.fillStyle = col;
    ctx.fillRect(xpos, ypos, 1, 1);
}


function drawPixel(context, x, y, color) {
    context.save();
    context.translate(x, y);
    context.fillStyle = color;
    context.fillRect(0, 0, 1, 1);
    context.restore();
}

function randomRGB() {
    var r = Math.floor(Math.random() * 256);
    var g = Math.floor(Math.random() * 256);
    var b = Math.floor(Math.random() * 256);
    return `rgb(${r},${g},${b})`;
}

function randomPosition(maxPosition) {
    var t = random() * 10;
    if (t % 2 === 0) {
        return maxPosition - random() * 10;
    } else {
        return maxPosition - random() * 50;
    }
}

function canvasMounseMove(canvasId) {
    canvas.addEventListener('mousemove', pick);
}

function pick(event, ctx) {
    var x = event.layerX;
    var y = event.layerY;
    var pixel = ctx.getImageData(x, y, 1, 1);
    var data = pixel.data;
    var rgba = 'rgba(' + data[0] + ',' + data[1] +
        ',' + data[2] + ',' + (data[3] / 255) + ')';
    color.style.background = rgba;
    color.textContent = rgba;
}

