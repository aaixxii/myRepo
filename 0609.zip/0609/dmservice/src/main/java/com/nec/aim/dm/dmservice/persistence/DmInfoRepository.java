package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import com.nec.aim.dm.dmservice.entity.DmInfo;
import com.nec.aim.dm.dmservice.entity.NsmIdUrl;

public interface DmInfoRepository {
	
	public DmInfo  getDmInfoByDmId(String dmId) throws SQLException;
	public List<String> getAllActiveNodeStorageUrl(int redundancy) throws SQLException;
	public String getNodeStorageUrl(int nodeStorageId) throws SQLException;
	public List<String> getAllDmServiceUrl() throws SQLException;
	public List<NsmIdUrl> getNodeStorageUrlAndId() throws SQLException;
}
