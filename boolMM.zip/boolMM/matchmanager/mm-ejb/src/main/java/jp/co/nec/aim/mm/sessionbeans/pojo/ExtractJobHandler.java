package jp.co.nec.aim.mm.sessionbeans.pojo;

import java.io.IOException;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.callbakSender.AmqExecutorManager;
import jp.co.nec.aim.mm.callbakSender.AmqSocketSender;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
import jp.co.nec.aim.mm.procedure.FailExtractJobProcedure;
import jp.co.nec.aim.mm.procedure.FinishExtractJobProcedure;
import jp.co.nec.aim.mm.procedure.RetryExtractJobProcedure;
import jp.co.nec.aim.mm.util.ObjectUtil;
import jp.co.nec.aim.mm.util.XmlUtil;

/**
 * @author mozj
 */

public class ExtractJobHandler {
	private static Logger log = LoggerFactory.getLogger(ExtractJobHandler.class);
	private SystemInitDao systemInitDao;
	private DataSource dataSource;
	private FeJobDoneLogger feJobDoneLogger;

	/**
	 * Constructor is called by Java EE Container.
	 */
	public ExtractJobHandler(EntityManager entityManager, DataSource dataSource) {
		this.dataSource = dataSource;
		systemInitDao = new SystemInitDao(entityManager);
		this.feJobDoneLogger = new FeJobDoneLogger(dataSource);
	}

	public int failExtractJob(PBMuExtractJobResultItem ejrItem, FeJobQueueEntity eje, long muId, AimServiceState reason,
			boolean timeout, Integer maxCount) {
		log.warn("Extract job " + ((timeout) ? "or MU timedout" : "failure") + ": (muId " + eje.getMuId()
				+ ") Extract Job ID " + eje.getId() + " failed for reason: '" + reason.getErrorcode() + " : "
				+ reason.getErrMsg() + "'");

		Integer numFailures = (eje.getFailureCount() == null ? 0 : eje.getFailureCount().intValue());

		log.debug("Job " + eje.getId() + " has failed " + numFailures + " times already.");

		if (numFailures >= maxCount - 1) {
			log.warn("Extract job id " + eje.getId() + " failed too many times:" + (numFailures + 1) + ", completing.");

			int numCompleted = 0;
			try {
				FailExtractJobProcedure failProcedure = new FailExtractJobProcedure(dataSource);
				String result = ejrItem != null ? ejrItem.getResult() : "failed";
				numCompleted = failProcedure.execute(eje.getId(), muId, reason, result);
				if (0 < numCompleted) {
					feJobDoneLogger.info(eje.getId());
					// AimManager.saveExtractClientJobResult(String.valueOf(eje.getId()),
					// ejrItem.getResult());
				} else {
					log.warn("complete_extract_job called against nonexistent or already-complete extract job Id "
							+ eje.getId());
				}

				String reqFrom = systemInitDao.getRequestFromSetting();
				if (reqFrom.toUpperCase().equals("AMQ")) {
					log.info("Prepare send falid extract result to AMQ. jobId:{}", eje.getId());
					Integer port = AmqExecutorManager.getInstance().getCallbackIpPort("1");
					UidAimAmqResponse uidAimAmqResponse = new UidAimAmqResponse();
					uidAimAmqResponse.setRequestType(UidRequestType.Quality.name());
					if (!result.equals("failed")) {
						uidAimAmqResponse.setRequestId(XmlUtil.getRequestId(result));
					}
					uidAimAmqResponse.setXmlResult(result);
					byte[] uidResData = null;
					try {
						uidResData = ObjectUtil.serializeAmqResults(uidAimAmqResponse);
					} catch (IOException e) {
						uidResData = result.getBytes();
					}
					AmqSocketSender sendTask = new AmqSocketSender(port, uidResData);
					AmqExecutorManager.getInstance().commitTask(sendTask);
				}

			} catch (Exception ex) {
				log.error("@@ debug log", ex);
				AimError dbErr = AimError.EXTRACT_DB;
				String errMsg = String.format(dbErr.getMessage(), ex.getMessage());
				dbErr.setMessage(errMsg);
				throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(),
						String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
			}
			return numCompleted;
		} else {
			try {
				log.warn("Extract job id " + eje.getId() + " failed, retry.");
				RetryExtractJobProcedure retryProcedure = new RetryExtractJobProcedure(dataSource);
				return retryProcedure.execute(eje.getId(), muId, reason);
			} catch (DataAccessException ex) {
				String message = "DataAccessException when Retry Extract Job";
				log.error(message, ex);
				throw new AimRuntimeException(message, ex);
			}
		}
	}

	/**
	 *
	 * @param jobId
	 * @param muId
	 * @param result
	 * @param failed
	 * @return
	 * @throws SQLException
	 * @throws InvalidProtocolBufferException
	 * @throws IOException
	 */
	public int completeExtractJob(long jobId, long muId, String result, byte[] template, byte[] diagnostics,
			boolean failed) throws SQLException, InvalidProtocolBufferException {
		if (failed) {
			return -1;
		} else {
			int numCompleted = 0;
			FinishExtractJobProcedure finishProcedure = new FinishExtractJobProcedure(dataSource);
			numCompleted = finishProcedure.execute(muId, jobId, result, diagnostics, "UID", template);
			return numCompleted;
		}
	}
}
