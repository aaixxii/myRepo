package jp.co.nec.aim.mm.logger;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 * Logger for FE_JOB_QUEUE Table.
 * 
 * The log created by this class would send to SM.
 * 
 * @author 000001A0026BC
 * 
 */
public class FeJobDoneLogger {
	private static Logger log = LoggerFactory.getLogger("feJobDoneLogger");
	private static final String SQL = "SELECT JOB_ID, ASSIGNED_TS, CALLBACK_STYLE,"
			+ " CALLBACK_URL, FAILED_FLAG,FAILURE_COUNT, FUNCTION_ID, RESULT_TS,"
			+ "JOB_STATE, LOT_JOB_ID, MU_ID, PRIORITY, SUBMISSION_TS FROM FE_JOB_QUEUE WHERE JOB_ID=? ";

	private JdbcTemplate jdbcTemplate;

	/**
	 * 
	 * @param dataSource
	 */
	public FeJobDoneLogger(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void info(long jobId) {
		FeJobQueueEntity message = jdbcTemplate.queryForObject(SQL,
				new FeJobMapper(), new Long(jobId));
		log.info(message.toString());
	}

	/**
	 * FeJobMapper
	 * 
	 * @author liuyq
	 * 
	 */
	private class FeJobMapper implements RowMapper<FeJobQueueEntity> {

		@Override
		public FeJobQueueEntity mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			FeJobQueueEntity message = new FeJobQueueEntity();
			try {
				message.setId(rs.getLong("JOB_ID"));
				message.setFunctionId(rs.getInt("FUNCTION_ID"));
				message.setPriority(rs.getInt("PRIORITY"));
				int jobState = rs.getInt("JOB_STATE");
				message.setStatus(JobState.values()[jobState]);
				message.setFailedFlag(rs.getBoolean("FAILED_FLAG"));
				message.setMuId(rs.getInt("MU_ID"));
				message.setAssignedTs(rs.getLong("ASSIGNED_TS"));
				message.setResultTs(rs.getLong("RESULT_TS"));
				message.setSubmissionTs(rs.getLong("SUBMISSION_TS"));
				message.setFailureCount(rs.getLong("FAILURE_COUNT"));
				message.setCallbackUrl(rs.getString("CALLBACK_URL"));
				int callbackStyle = rs.getInt("CALLBACK_STYLE");
				message.setCallbackStyle(CallbackStyle.values()[callbackStyle]);
			} catch (Exception e) {
				log.error(
						"Exception occurred when Map Fe job: {} to instance FeJobQueueEntity.",
						(message.getId() <= 0) ? "UNKNOWN" : message.getId(), e);
			}
			return message;
		}
	}

}
