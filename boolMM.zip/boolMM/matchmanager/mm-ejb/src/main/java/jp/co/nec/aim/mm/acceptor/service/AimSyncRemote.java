/**this is file AimSyncInterface.java
 * @author xia
   @date 2020/09/24
 */
package jp.co.nec.aim.mm.acceptor.service;

import javax.ejb.Remote;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;

/**
 * @author xia
 *
 */
@Remote
public interface AimSyncRemote {
	public void getExtResAndDoSync(PBMuExtractJobResultItem ejrItem);	
}
