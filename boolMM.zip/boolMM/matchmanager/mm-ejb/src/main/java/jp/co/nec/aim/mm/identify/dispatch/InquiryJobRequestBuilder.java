package jp.co.nec.aim.mm.identify.dispatch;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInput;
import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuJobMapInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.identify.planner.MuJobExecutePlan;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.google.protobuf.ByteString;

/**
 * PBMapInquiryJobRequest instance Builder
 * 
 * @author liuyq
 * 
 */
public final class InquiryJobRequestBuilder {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(InquiryJobRequestBuilder.class);

	private static final String FIRST_SPLIT = "/";
	private static final String SECOND_SPLIT = ",";
	private static final String THIRD_SPLIT = ":";

	/** matchunit/InquiryJob **/
	private static final String MU_URL = "matchunit/InquiryJob";

	private UnitDao unitDao; // unitDao

	/**
	 * InquiryJobRequestBuilder constructor
	 * 
	 * @param UnitDao
	 *            unitDao
	 * @param DateDao
	 *            dateDao
	 */
	public InquiryJobRequestBuilder(UnitDao unitDao) {
		this.unitDao = unitDao;
	}

	/**
	 * create PBMapInquiryJobRequest instance
	 * 
	 * @return InqDispatchInfo the instance of InqDispatchInfo
	 */
	public PBMapInquiryJobRequest.Builder createRequest(
			final InqDispatchInfo info, MuJobExecutePlan plan) {
		PBMapInquiryJobRequest.Builder b = PBMapInquiryJobRequest.newBuilder();

		// set plan id
		b.setPlanId(plan.getPlanId());
		long containerJobTimeOut = (info.getJobTimeout() < 0 ? Long.MAX_VALUE : info.getJobTimeout());
		
		List<PBInquiryJobInfoInternal> internalJobList = new ArrayList<>();		

		PBInquiryJobInfoInternal.Builder pbInternal	= PBInquiryJobInfoInternal.newBuilder();
		 pbInternal.setTopLevelJobId(plan.getJobId());
		 pbInternal.setContainerId(plan.getContainerId());
		 pbInternal.setRequestIndex(info.getRequestIndex());
		 pbInternal.setMessageSequence(info.getMessageSequence());
		 pbInternal.setJobTimeout(containerJobTimeOut);		
		 PBInquiryJobInfoInput.Builder pBInquiryJobInfoInput = PBInquiryJobInfoInput.newBuilder();
		 pBInquiryJobInfoInput.setBisonTemplate(ByteString.copyFrom(info.getInquiryData()));
		 pBInquiryJobInfoInput.setRequest(info.getInquiryRequstXml());
		 pbInternal.setIn(pBInquiryJobInfoInput.build());		 
		internalJobList.add(pbInternal.build());
		b.addAllJobInfo(internalJobList);		

		// create PBMuJobMapInfo instance
		createPBMuJobMapInfo(b, plan.getPlan());

		// muJobMap build failure
		if (b.getMuJobMapCount() <= 0) {
			final String error = String.format(
					"muJobMap is empty when generate PBMapInquiryJobRequest, "
							+ "plan id: %s, job id: %s", plan.getPlanId(),
					plan.getPlanId());
			log.error(error);
			throw new AimRuntimeException(error);
		}

		return b;
	}

	/**
	 * generate the PBMuJobMapInfo instance with specified string
	 * 
	 * <p>
	 * muId,segmentId:version,segmentId:version/muId,segmentId:vesion
	 * </p>
	 * 
	 * @param b
	 *            PBMapInquiryJobRequest Builder
	 * @param plan
	 *            plan String
	 */
	private void createPBMuJobMapInfo(PBMapInquiryJobRequest.Builder b, String plan) {			
		String muSegStr = plan;
		if (StringUtils.isBlank(muSegStr)) {
			throw new AimRuntimeException("plan bytes is null or empty..");
		}

		final StringTokenizer muSegs = new StringTokenizer(muSegStr,
				FIRST_SPLIT);
		while (muSegs.hasMoreTokens()) {
			final String muSeg = muSegs.nextToken();
			if (StringUtils.isBlank(muSeg)) {
				log.warn("ip segment item is null or empty..");
				continue;
			}

			String[] array = muSeg.split(SECOND_SPLIT);
			if (array == null || array.length <= 1) {
				log.warn("mu id must be specified.");
				continue;
			}

			PBMuJobMapInfo.Builder mujob = PBMuJobMapInfo.newBuilder();
			Long muId = Long.valueOf(array[0]);
			mujob.setMuId(muId);

			MatchUnitEntity mu = unitDao.findMU(muId);
			if (mu != null && !Strings.isNullOrEmpty(mu.getContactUrl())) {
				String contactUrl = mu.getContactUrl();
				if (contactUrl.endsWith("/")) {
					contactUrl += MU_URL;
				} else {
					contactUrl += "/" + MU_URL;
				}
				mujob.setUrl(contactUrl);
			} else {
				throw new AimRuntimeException(String.format(
						"Can not get MU(%s) contact URL.", muId));
			}

			for (int i = 1; i < array.length; i++) {
				String item = array[i];
				if (Strings.isNullOrEmpty(item)) {
					throw new AimRuntimeException(
							"Seg:Version is null or empty.");
				}

				String[] SegVers = item.split(THIRD_SPLIT);
				if (SegVers == null || SegVers.length != 2) {
					throw new AimRuntimeException(
							"Seg:Version length is not 2.");
				}

				try {
					mujob.addTargetSegments(PBTargetSegmentVersion.newBuilder()
							.setId(Long.valueOf(SegVers[0]))
							.setVersion(Long.valueOf(SegVers[1])));
				} catch (Exception e) {
					throw new AimRuntimeException(
							"Exception occurred when create "
									+ "PBTargetSegmentVersion instance", e);
				}
			}
			b.addMuJobMap(mujob);
		}
	}
	
	@SuppressWarnings("unused")
	private List<PBMuJobMapInfo> buildPBMuJobMapInfo(String plan) {
		List<PBMuJobMapInfo> pBMuJobMapInfoList = new ArrayList<>();
		String muSegStr = plan;
		if (StringUtils.isBlank(muSegStr)) {
			throw new AimRuntimeException("plan bytes is null or empty..");
		}

		final StringTokenizer muSegs = new StringTokenizer(muSegStr, FIRST_SPLIT);				
		while (muSegs.hasMoreTokens()) {
			final String muSeg = muSegs.nextToken();
			if (StringUtils.isBlank(muSeg)) {
				log.warn("ip segment item is null or empty..");
				continue;
			}

			String[] array = muSeg.split(SECOND_SPLIT);
			if (array == null || array.length <= 1) {
				log.warn("mu id must be specified.");
				continue;
			}

			PBMuJobMapInfo.Builder mujob = PBMuJobMapInfo.newBuilder();
			Long muId = Long.valueOf(array[0]);
			mujob.setMuId(muId);

			MatchUnitEntity mu = unitDao.findMU(muId);
			if (mu != null && !Strings.isNullOrEmpty(mu.getContactUrl())) {
				String contactUrl = mu.getContactUrl();
				if (contactUrl.endsWith("/")) {
					contactUrl += MU_URL;
				} else {
					contactUrl += "/" + MU_URL;
				}
				mujob.setUrl(contactUrl);
			} else {
				throw new AimRuntimeException(String.format(
						"Can not get MU(%s) contact URL.", muId));
			}

			for (int i = 1; i < array.length; i++) {
				String item = array[i];
				if (Strings.isNullOrEmpty(item)) {
					throw new AimRuntimeException(
							"Seg:Version is null or empty.");
				}

				String[] SegVers = item.split(THIRD_SPLIT);
				if (SegVers == null || SegVers.length != 2) {
					throw new AimRuntimeException(
							"Seg:Version length is not 2.");
				}

				try {
					mujob.addTargetSegments(PBTargetSegmentVersion.newBuilder()
							.setId(Long.valueOf(SegVers[0]))
							.setVersion(Long.valueOf(SegVers[1])));
				} catch (Exception e) {
					throw new AimRuntimeException(
							"Exception occurred when create "
									+ "PBTargetSegmentVersion instance", e);
				}
			}
			pBMuJobMapInfoList.add(mujob.build());
		}
		return pBMuJobMapInfoList ;
	}
	
}
