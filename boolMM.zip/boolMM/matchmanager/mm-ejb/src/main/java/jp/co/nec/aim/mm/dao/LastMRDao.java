package jp.co.nec.aim.mm.dao;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.procedure.IncreaseRUCProcedure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LastMR checkPoint
 * 
 * @author liuyq
 * 
 */
public class LastMRDao {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(LastMRDao.class);
	private DataSource dataSource;

	/**
	 * 
	 * @param dataSource
	 */
	public LastMRDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * increaseRUC
	 */
	public void saveLastMR() {
		log.info("Ready to increase RUC.");
		IncreaseRUCProcedure procedure = new IncreaseRUCProcedure(dataSource);
		procedure.execute();
	}

}
