/**this is file ObjectUtil.java
 * @author xia
   @date 2020/07/21
 */
package jp.co.nec.aim.mm.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

/**
 * @author xia
 *
 */
public class ObjectUtil {	
	
	public static byte[] serializeAmqResults(UidAimAmqResponse uidRespose) throws IOException {
	      ByteArrayOutputStream bos = new ByteArrayOutputStream();
	      ObjectOutputStream oos = new ObjectOutputStream(bos);
	      oos.writeObject(uidRespose);
	      oos.flush();
	      byte [] data =bos.toByteArray();
	      return data;
	}	
	
	public static UidAimAmqResponse deserializeAmqResults(byte[] data) throws IOException, ClassNotFoundException {
	    ByteArrayInputStream in = new ByteArrayInputStream(data);
	    ObjectInputStream is = new ObjectInputStream(in);
	    UidAimAmqResponse uidRes = (UidAimAmqResponse) is.readObject();
	    in.close();
	    return uidRes;
	}	
	
}
