package jp.co.nec.aim.mm.scheduler;

import java.time.LocalDate;
import java.util.List;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.sessionbeans.ClearPartitionAtDelayBean;
import jp.co.nec.aim.mm.util.JndiLookup;


@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class ClearPartitionAtDelayScheduler implements Job{

	private static final Logger logger = LoggerFactory.getLogger(ClearPartitionAtDelayScheduler.class);
	
	ClearPartitionAtDelayBean clearOldPartitionBean;
	
	@SuppressWarnings("unchecked")
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		if (clearOldPartitionBean == null) {
			clearOldPartitionBean = JndiLookup.lookUp(
					JNDIConstants.CLEARPARTITIONATDELAYBEAN,ClearPartitionAtDelayBean.class);
		}
	    if (logger.isDebugEnabled()) {
            logger.debug("ClearOldPartitionScheduler is run...");
        }
	    List<LocalDate> targetDays = (List<LocalDate>) context.getJobDetail().getJobDataMap().get("targetDays");
		clearOldPartitionBean.execute(targetDays);
	}
}
