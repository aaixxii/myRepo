package jp.co.nec.aim.mm.notifier;

import java.util.Date;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.util.JndiLookup;
import jp.co.nec.aim.mm.util.SafeCloseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IdentifyPlanCreatedNotifer {
	private static Logger logger = LoggerFactory
			.getLogger(IdentifyPlanCreatedNotifer.class);

	private ConnectionFactory jmsConnectionFactory;
	private static final String IDENTIFY_PLANNER_DISPATCH_QUQUE = "java:/jms/queue/IdentifyDispatchQueue";

	public IdentifyPlanCreatedNotifer() {
	}

	/**
	 * 
	 * @param plans
	 * @return
	 */
	public boolean sendTxtMessage(String planId) {
		logger.info("Send JMS to queue:IdentifyDispatchQueue");
		if (this.jmsConnectionFactory == null) {
			jmsConnectionFactory = JndiLookup.lookUp(JNDIConstants.JmsFactory,
					ConnectionFactory.class);
		}
		Queue queue = JndiLookup.lookUp(IDENTIFY_PLANNER_DISPATCH_QUQUE,
				Queue.class);
		Session session = null;
		MessageProducer producer = null;
		Connection connection = null;
		try {
			connection = jmsConnectionFactory.createConnection(
					JNDIConstants.Principal, JNDIConstants.Credentials);
			session = connection.createSession(false,
					Session.DUPS_OK_ACKNOWLEDGE);
			producer = session.createProducer(queue);
			TextMessage txtMessage = session.createTextMessage(planId);
			txtMessage.setJMSDeliveryTime(new Date().getTime());
			producer.send(txtMessage);
			if (logger.isDebugEnabled()) {
				logger.debug("Send message to Queue:"
						+ IDENTIFY_PLANNER_DISPATCH_QUQUE + ", Message:"
						+ planId);
			}
			return true;

		} catch (JMSException e) {
			String errorMessage = "JMSException while queueing:"
					+ IDENTIFY_PLANNER_DISPATCH_QUQUE;
			logger.error(errorMessage);
			return false;
		} finally {
			SafeCloseUtil.close(producer);
			SafeCloseUtil.close(session);
			SafeCloseUtil.close(connection);
		}
	}

	/**
	 * 
	 * @param compressedJms
	 * @return
	 */
	public boolean sendCompressedByte(byte[] compressedJms) {
		logger.info("Send JMS to queue:IdentifyDispatchQueue");

		if (this.jmsConnectionFactory == null) {
			jmsConnectionFactory = JndiLookup.lookUp(JNDIConstants.JmsFactory,
					ConnectionFactory.class);
		}
		Queue queue = JndiLookup.lookUp(IDENTIFY_PLANNER_DISPATCH_QUQUE,
				Queue.class);
		Session session = null;
		MessageProducer producer = null;
		Connection connection = null;
		try {
			connection = jmsConnectionFactory.createConnection(
					JNDIConstants.Principal, JNDIConstants.Credentials);
			session = connection.createSession(false,
					Session.DUPS_OK_ACKNOWLEDGE);
			producer = session.createProducer(queue);
			BytesMessage byteMessage = session.createBytesMessage();
			byteMessage.writeBytes(compressedJms);			
			producer.send(byteMessage);
			if (logger.isDebugEnabled()) {
				logger.debug("success send message to IdentifyDispatchQueue");
			}
			return true;

		} catch (JMSException e) {
			String errorMessage = "JMSException while queueing:"
					+ IDENTIFY_PLANNER_DISPATCH_QUQUE;
			logger.error(errorMessage);
			return false;
		} finally {
			SafeCloseUtil.close(producer);
			SafeCloseUtil.close(session);
			SafeCloseUtil.close(connection);
		}
	}

}
