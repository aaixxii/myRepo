package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.EventLogLevel;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.sessionbeans.pojo.EventSender;

/**
 * @author mozj
 */
@Stateless
public class EventLogBean {

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	private EventSender eventSender;
	private DateDao dateDao;

	public EventLogBean() {
		// must provide no-arg ctor for EJB container
	}

	@PostConstruct
	public void init() {
		eventSender = new EventSender();
		dateDao = new DateDao(dataSource);
	}

	/**
	 * When the log write, this log will send to SM.
	 * 
	 * @param reasonCode
	 * @param eventType
	 * @param muId
	 * @param description
	 * @param level
	 */
	public void logEvent(String reasonCode, String eventType, Long muId,
			String description, EventLogLevel level) {
		eventSender.sendEvent(reasonCode, eventType, muId, description, level,
				dateDao.getDatabaseDate());
	}

}
