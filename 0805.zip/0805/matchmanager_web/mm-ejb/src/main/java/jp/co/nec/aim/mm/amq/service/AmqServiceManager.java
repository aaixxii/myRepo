package jp.co.nec.aim.mm.amq.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;

import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

public class AmqServiceManager {	
	private  static final AmqServiceManager INSTANCE = new AmqServiceManager();	
	
	public static AmqServiceManager getInstance() {
		return INSTANCE;
	}
	
	private final ConcurrentHashMap<String, Consumer<UidAimAmqResponse>> amqMap = new ConcurrentHashMap<>(); 	
	private final  BlockingQueue<UidAimAmqResponse> amqQueue = new LinkedBlockingQueue<>(30);	
	
	public void registerAmqResGetter(String type, Consumer<UidAimAmqResponse> resGegger) {
		amqMap.put(type, resGegger);
	}
	
	public boolean addToAmqQueue(UidAimAmqResponse amqRes)  {	
	boolean result = amqQueue.offer(amqRes);
	 amqMap.get(amqRes.getRequestType()).accept(amqRes);
	 return result;		
	}
	
	public UidAimAmqResponse getFromAmqQueue() throws InterruptedException {
		return amqQueue.take();	
	}
	
	public List<UidAimAmqResponse> getAll() {
		int remain = amqQueue.size();				
		List<UidAimAmqResponse> temp = new ArrayList<>(remain);
		amqQueue.drainTo(temp);
		return temp;
	}	
	
	private final ConcurrentHashMap<String, Consumer<String>> amqXmlMap = new ConcurrentHashMap<>(); 
	private final  BlockingQueue<String> amqXmlQueue = new LinkedBlockingQueue<>(30);
	
	public void registerXmlResGetter(String type, Consumer<String> xmlGegger) {
		amqXmlMap.put(type, xmlGegger);
	}
	
	public boolean addToAmqXmlQueue(String type, String amqRes)  {	
		boolean result =  amqXmlQueue.offer(amqRes);
		amqXmlMap.get(type).accept(amqRes);
		return result;
	}
	
	public String getFromAmqXmlQueue() throws InterruptedException {
		return amqXmlQueue.take();	
	}
	
	public List<String> getAllXmlResult() {
		int remain = amqXmlQueue.size();				
		List<String> temp = new ArrayList<>(remain);
		amqXmlQueue.drainTo(temp);
		return temp;
	}
	
	public  String getAmqConfigFilePath() {
		String path = System.getProperty("jboss.server.config.dir") + "aim.mq.properties";	
		return path;
	}	
}
