package jp.co.nec.aim.mm.callbakSender;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Set;

public class SocketServer  {
	
	private ServerSocketChannel serverSocketChannel = null;
	private Selector selector;	
	private ByteBuffer amqBuffer = ByteBuffer.allocate(256);

	public static void main(String[] args) {
		SocketServer server = new SocketServer();
		server.init();
		try {
			server.service();
		} catch (IOException e) {			
			e.printStackTrace();
		}

	}
	
	private void init() {
		int port = 8888;
		int serverSocketTimeout = 6000;			
		try {
			selector = Selector.open();
			serverSocketChannel = ServerSocketChannel.open();
			serverSocketChannel.socket().setReuseAddress(true);
			serverSocketChannel.socket().setSoTimeout(serverSocketTimeout);
			serverSocketChannel.configureBlocking(false);			
			serverSocketChannel.socket().bind(new InetSocketAddress(port));
			serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);			
		} catch (IOException e) {
			String errmsg = "Can't starting Amq Socket Server!";
			System.out.println(errmsg);
		}
		System.out.println("Amq Socket Server is started!");
	}
	
	public void service() throws IOException {		
		while (selector.select() > 0) {
			Set<SelectionKey> readyKeys = selector.selectedKeys();
			Iterator<SelectionKey> it = readyKeys.iterator();
			while (it.hasNext()) {
				SelectionKey key = null;
				try {
					key = (SelectionKey) it.next();
					it.remove();
					if (!key.isValid()) {
						continue;
					}
					 if (key.isAcceptable()) {
						 SocketChannel socketChannel = serverSocketChannel.accept();
						socketChannel.configureBlocking(false);	
					        System.out.println("Accepted client: " + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());
					        socketChannel.register(selector, SelectionKey.OP_READ);					       					
					 }
					 
					 if (key.isReadable()) {
						 //readFrom(key); test ok
						 //readbyStringcontent(key); //test ok
						 readToArray(key); //ok too
					 }
				} catch (Exception e) {
					e.printStackTrace();
					try {
						if (key != null) {
							key.cancel();
							key.channel().close();
						}
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				}
			} // #while
		} // #while
	}  

	@SuppressWarnings("unused")
	private void readFrom(SelectionKey key) {
		 SocketChannel myClient = (SocketChannel) key.channel();
		 ByteBuffer myBuffer = ByteBuffer.allocate(256);
		 try {
			myClient.read(myBuffer);
			 String data = new String(myBuffer.array()).trim();
			 System.out.println(data);
			 myBuffer.clear();
		} catch (IOException e) {			
			e.printStackTrace();
		}		
	}
	
	@SuppressWarnings("unused")
	private void  readbyStringcontent(SelectionKey key) {
		 SocketChannel myClient = (SocketChannel) key.channel();
		 ByteBuffer myBuffer = ByteBuffer.allocate(256);		
		 Charset charse = Charset.forName("UTF-8");
		 String content = "";  
		 try {
			 while (myClient.read(myBuffer) > 0) {
				 myBuffer.flip();
				 content += charse.decode(myBuffer);				 
			 }	
		     System.out.println(content.trim());
		     myBuffer.clear();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	private void readToArray(SelectionKey key) {        
        amqBuffer.clear();
        amqBuffer.order(ByteOrder.BIG_ENDIAN); 
   	 SocketChannel myClient = (SocketChannel) key.channel();
	 ByteBuffer myBuffer = ByteBuffer.allocate(256);
	 byte[] byteArr = new byte[256];
	 int readSize = 0;	 
        	  try {        		  
        		  while ((readSize = myClient.read(myBuffer)) > 0) {
        			  System.out.println("Socket server readed data size =" + readSize);
        			  myBuffer.flip();
        			  myBuffer.get(byteArr, 0, readSize);
        		  }					
				String received = new String(byteArr, "UTF-8").trim();
				System.out.println(received);	
				 myBuffer.clear();
			} catch (IOException e) {
				try {
					myClient.close();
				} catch (IOException e1) {					
				}
			} 
    }
}
