//package jp.co.nec.aim.mm.license;
//
//import java.io.InputStream;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.concurrent.Callable;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//
//import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
//import jp.co.nec.aim.license.LicenseComponent;
//import jp.co.nec.aim.license.LicenseManagementException;
//import jp.co.nec.aim.license.LicenseValidation;
//import jp.co.nec.aim.license.LicenseValidationException;
//import jp.co.nec.aim.mm.constants.AimError;
//import jp.co.nec.aim.mm.exception.LicenseException;
//
//import org.apache.commons.lang3.StringUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
///**
// * the manage class of license
// * 
// * @author liuyq
// * 
// */
//public class LicenseManager {
//
//	/** log instance **/
//	private static Logger log = LoggerFactory.getLogger(LicenseManager.class);
//
//	private final LicenseValidation validator;
//	private InputStream is = null;
//
//	/**
//	 * private constructor
//	 */
//	private LicenseManager() {
//		validator = LicenseValidation.getInstance();
//	}
//
//	/**
//	 * Validate the MM inquiry workFlow with the specified function and current
//	 * date
//	 * 
//	 * @param function
//	 *            the function name
//	 * @param now
//	 *            the current time
//	 */
//	public void check(String function, Date now) {
//		try {
//			synchronized (this) {
//				if (is == null) {
//					log.debug("init the instance of LicenseValidation..");
//					this.is = this.getClass().getClassLoader()
//							.getResourceAsStream("license.xml");
//					this.validator.init(is);
//				}
//			}
//			AfisLowLevelFunctionEnum functionEnum = AfisLowLevelFunctionEnum
//					.valueOf(function);
//			validator.validate(functionEnum, now, LicenseComponent.MM);
//		} catch (LicenseValidationException e) {
//			log.error("LicenseValidationException occurred"
//					+ " when validate the function name: " + function + "..", e);
//			throwLicenseException(function, now, e);
//		} catch (LicenseManagementException e) {
//			log.error("LicenseManagementException occurred"
//					+ " when validate the function name: " + function + "..", e);
//			throwLicenseException(function, now, e);
//		} catch (Exception e) {
//			log.error("Exception occurred"
//					+ " when check the License with the function name: "
//					+ function + "..", e);
//			throwLicenseException(function, now, e);
//		}
//	}
//
//	/**
//	 * throw license exception with function name, current date and exception
//	 * instance
//	 * 
//	 * @param function
//	 *            function name
//	 * @param now
//	 *            current date
//	 * @param e
//	 *            the instance of excption
//	 */
//	private void throwLicenseException(String function, Date now, Throwable e) {
//		final AimError aimError = AimError.LICENSE_ERROR;
//		final String message = String.format(
//				aimError.getMessage(),
//				function,
//				StringUtils.isBlank(e.getMessage()) ? "Unknow Exception" : e
//						.getMessage());
//		throw new LicenseException(aimError.getErrorCode(), message,
//				String.valueOf(now.getTime()));
//	}
//
//	/**
//	 * SingletonHolder class
//	 * 
//	 * @author liuyq
//	 * 
//	 */
//	static class SingletonHolder {
//		public static final LicenseManager LICENSEMANAGER = new LicenseManager();
//	}
//
//	/**
//	 * get Singleton instance
//	 * 
//	 * @return
//	 */
//	public static LicenseManager getInstance() {
//		return SingletonHolder.LICENSEMANAGER;
//	}
//
//	public static void main(String[] args) {
//		final Date date = new Date(1432610352449L);
//		final LicenseManager manager = LicenseManager.getInstance();
//
//		ExecutorService service = null;
//		try {
//			service = Executors.newFixedThreadPool(100);
//			List<Callable<Void>> tasks = new ArrayList<Callable<Void>>();
//			for (int i = 0; i < 1000; i++) {
//				tasks.add(new Callable<Void>() {
//					@Override
//					public Void call() throws Exception {
//						manager.check("TI", date);
//						return null;
//					}
//				});
//			}
//			service.invokeAll(tasks);
//
//			Thread.sleep(10000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		} finally {
//			if (service != null) {
//				service.shutdown();
//			}
//		}
//
//	}
//}
