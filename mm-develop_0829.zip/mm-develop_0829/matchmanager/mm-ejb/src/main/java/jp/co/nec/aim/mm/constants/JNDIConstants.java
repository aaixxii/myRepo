package jp.co.nec.aim.mm.constants;

public class JNDIConstants {

	public static final String Principal = "aimuser";
	public static final String Credentials = "aim_user_500";

	public static final String SLB_TIMEOUT = "600";

	public static final String JmsFactory = "java:/JmsXA";
	public static final String QueueHead = "java:/jms/queue/";
	public static final String ASYNCH_QUEUE = QueueHead + "AimAsynchHttpQueue";
	public static final String EXTRACT_JOB_DISPATCH_QUEUE = QueueHead
			+ "FeDispatchQueue";
	public static final String EXTRACT_JOB_PLANNER_QUEUE = QueueHead
			+ "FEPlanerQueue";
	public static final String INQUIRY_JOB_PLANNER_QUEUE = QueueHead
			+ "IdentifyPlanerQueue";
	public static final String INQUIRY_JOB_DISPATCH_QUEUE = QueueHead
			+ "IdentifyDispatchQueue";
	public static final String SLB_QUEUE = QueueHead + "loadbalancerQueue";

	public static final String INFO_QUEUE = QueueHead + "infoQueue";

	public static final String ERROR_QUEUE = QueueHead + "errorQueue";

	public static final String EntityManagerName = "java:/EntityManager/aim-db";
	public static final String DataSourceName = "java:jboss/MySqlDS";
	

	public static final String BeanHead = "java:global/matchmanager/mm-ejb/";	
	public static final String POLLBEAN = BeanHead + "PollBean!jp.co.nec.aim.mm.sessionbeans.PollBean";	
	public static final String AimExtractService = BeanHead + "AimExtractService!jp.co.nec.aim.mm.acceptor.service.AimExtractService";	
	public static final String AimInquiryService = BeanHead + "AimInquiryService!jp.co.nec.aim.mm.acceptor.service.AimInquiryService";	
	public static final String AimSyncService = BeanHead + "AimSyncService!jp.co.nec.aim.mm.acceptor.service.AimSyncService";
	public static final String AmqServiceBean = BeanHead + "AmqServiceBean!jp.co.nec.aim.mm.sessionbeans.AmqServiceBean";	
	
	public static final String GARBAGESEGCHANGELOGBEAN = BeanHead
			+ "GarbageSegChangeLogBean!jp.co.nec.aim.mm.sessionbeans.GarbageSegChangeLogBean";
	
    public static final String SETTODAYBEAN = BeanHead
           + "SetTodayPnoBean!jp.co.nec.aim.mm.sessionbeans.SetTodayPnoBean";
    
    public static final String CLEARPARTITIONATDELAYBEAN = BeanHead
            + "ClearPartitionAtDelayBean!jp.co.nec.aim.mm.sessionbeans.ClearPartitionAtDelayBean";   
    
    public static final String CREATENEXTDAYPARTITIONBEAN = BeanHead
            + "CreateNextDayPartitionBean!jp.co.nec.aim.mm.sessionbeans.CreateNextDayPartitionBean";
    
    public static final String RESERVAIONREDUCEPARTITIONBEAN = BeanHead
            + "ReservationReducePartitionBean!jp.co.nec.aim.mm.sessionbeans.ReservationReducePartitionBean";
    
    public static final String ROTATIONTASKBEAN = BeanHead
            + "RotationTaskBean!jp.co.nec.aim.mm.sessionbeans.RotationTaskBean";
	   
	
	public static final String COMMONBEAN = BeanHead
			+ "CommonBean!jp.co.nec.aim.mm.scheduler.CommonBean";
	public static final String MATCH_MANAGER_EARFILE = "matchmanager";

}
