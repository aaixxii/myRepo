package jp.co.nec.aim.mm.extract.dispatch;

import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.HttpResponseInfo;
import mockit.Mock;
import mockit.MockUp;

import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ExtractRequestPosterTest {
	private ExtractRequestPoster fePoster;
	private static final String URL = "http://localhost:7878";
	private final String postString = "this is message from aim poster, pealse receive it and response to me";
	private int muPostRetryCount = 3;
	private static final int EXTRACT_TIMEOUT = 60000;

	@Before
	public void setUp() throws Exception {
		fePoster = new ExtractRequestPoster();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPostRequestStringIntByteArray_response_200() {
		int status = HttpStatus.SC_OK;
		final HttpResponseInfo info = new HttpResponseInfo(status);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info;
			}
		};
		boolean results = fePoster.postRequest(URL, muPostRetryCount,
				postString.getBytes());
		Assert.assertEquals(true, results);
	}

	@Test
	public void testPostRequestStringIntByteArray_response_503_retry_OK() {
		int status = HttpStatus.SC_SERVICE_UNAVAILABLE;
		final HttpResponseInfo info = new HttpResponseInfo(status);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info;
			}
		};
		new MockUp<ExtractRequestPoster>() {
			@Mock
			public boolean retryPost(String Url, byte[] request,
					int muPostRetryCount, int EXTRACT_TIMEOUT) {
				return true;
			}
		};
		boolean results = fePoster.postRequest(URL, muPostRetryCount,
				postString.getBytes());
		Assert.assertEquals(true, results);
	}

	@Test
	public void testPostRequestStringIntByteArray_response_503_retry_failed() {
		int status = HttpStatus.SC_SERVICE_UNAVAILABLE;
		final HttpResponseInfo info = new HttpResponseInfo(status);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info;
			}
		};
		new MockUp<ExtractRequestPoster>() {
			@Mock
			public boolean retryPost(String Url, byte[] request,
					int muPostRetryCount, int EXTRACT_TIMEOUT) {
				return false;
			}
		};
		boolean results = fePoster.postRequest(URL, muPostRetryCount,
				postString.getBytes());
		Assert.assertEquals(false, results);
	}

	@Test
	public void testPostRequestStringIntByteArray_response_400() {
		int status = HttpStatus.SC_NOT_FOUND;
		final HttpResponseInfo info = new HttpResponseInfo(status);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info;
			}
		};
		boolean results = fePoster.postRequest(URL, muPostRetryCount,
				postString.getBytes());
		Assert.assertEquals(false, results);
	}

	@Test
	public void testPostRequestStringIntByteArray_httpException() {
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				throw new HttpPostException("I am a HttpPostException",null, null, null);
			}
		};
		new MockUp<ExceptionSender>() {
			@Mock
			public void sendAimException(String reasonCode, String message,
					Exception e) {
				return;
			}
		};
		boolean results = fePoster.postRequest(URL, muPostRetryCount,
				postString.getBytes());
		Assert.assertEquals(false, results);
	}

	@Test
	public void testRetryPostStringByteArrayIntInt_response_200() {
		int status = HttpStatus.SC_OK;
		final HttpResponseInfo info = new HttpResponseInfo(status);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info;
			}
		};
		boolean results = fePoster.retryPost(URL, postString.getBytes(),
				muPostRetryCount, EXTRACT_TIMEOUT);
		Assert.assertEquals(true, results);
	}

	@Test
	public void testRetryPostStringByteArrayIntInt_response_503_retry_OK() {
		int status = HttpStatus.SC_SERVICE_UNAVAILABLE;
		final HttpResponseInfo info = new HttpResponseInfo(status);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info;
			}
		};

		int status2 = HttpStatus.SC_SERVICE_UNAVAILABLE;
		final HttpResponseInfo info2 = new HttpResponseInfo(status2);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info2;
			}
		};
		int status3 = HttpStatus.SC_OK;
		final HttpResponseInfo info3 = new HttpResponseInfo(status3);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info3;
			}
		};
		boolean results = fePoster.retryPost(URL, postString.getBytes(),
				muPostRetryCount, EXTRACT_TIMEOUT);
		Assert.assertEquals(true, results);
	}

	@Test
	public void testRetryPostStringByteArrayIntInt_response_503_retry_faild() {
		int status = HttpStatus.SC_SERVICE_UNAVAILABLE;
		final HttpResponseInfo info = new HttpResponseInfo(status);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info;
			}
		};

		int status2 = HttpStatus.SC_SERVICE_UNAVAILABLE;
		final HttpResponseInfo info2 = new HttpResponseInfo(status2);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info2;
			}
		};
		int status3 = HttpStatus.SC_INTERNAL_SERVER_ERROR;
		final HttpResponseInfo info3 = new HttpResponseInfo(status3);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info3;
			}
		};
		boolean results = fePoster.retryPost(URL, postString.getBytes(),
				muPostRetryCount, EXTRACT_TIMEOUT);
		Assert.assertEquals(false, results);
	}

	@Test
	public void testRetryPostStringByteArrayIntInt_response_503_HttpException() {
		new MockUp<ExceptionSender>() {
			@Mock
			public void sendAimException(String reasonCode, String message,
					Exception e) {
				return;
			}
		};
		int status = HttpStatus.SC_SERVICE_UNAVAILABLE;
		final HttpResponseInfo info = new HttpResponseInfo(status);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info;
			}
		};

		int status2 = HttpStatus.SC_SERVICE_UNAVAILABLE;
		final HttpResponseInfo info2 = new HttpResponseInfo(status2);
		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				return info2;
			}
		};

		new MockUp<HttpPoster>() {
			@Mock
			public final HttpResponseInfo post(final String url, byte[] bytes,
					Integer retryCount, Integer timeout)
					throws HttpPostException {
				throw new HttpPostException("I am a HttpPostException", null,null,null);
			}
		};
		boolean results = fePoster.retryPost(URL, postString.getBytes(),
				muPostRetryCount, EXTRACT_TIMEOUT);
		Assert.assertEquals(false, results);
	}
}
