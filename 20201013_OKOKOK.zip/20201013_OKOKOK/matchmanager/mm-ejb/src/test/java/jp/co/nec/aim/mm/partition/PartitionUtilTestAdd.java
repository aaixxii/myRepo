package jp.co.nec.aim.mm.partition;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PartitionUtilTestAdd {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}	
	
	private  long caculateHashAtThisToday(LocalDate thisDay) {
		Long saveDays = 7L;
		Long adjust = 0L;
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + adjust.longValue()) % (saveDays.longValue());
	}
	
	@Test
	public void testcaculate7HashAtThisToday() {
		String date = "2020-04-11";
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate thisDay = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));
		long todayHashValue = caculateHashAtThisToday(thisDay);
		System.out.print(todayHashValue);
	}	
	
	public long caculate7NewAdjustAtThisDay(long newN, LocalDate firstAddDay) {
		Long oldSaveDays = 7L;		
		long firstAddDayHashValue = caculateHashAtThisToday(firstAddDay);
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstAddDay);
		long quotient = epochDays/oldSaveDays.longValue();
		long deltaX = oldSaveDays * quotient + firstAddDayHashValue - epochDays;
		long X = (epochDays + deltaX) % oldSaveDays;
		long Y = epochDays % newN;
		long t = X - Y;	
		long adjustNew = (X - Y + newN) % newN;		
		return adjustNew;		
	}

	
	@Test
	public void testcaculate7NewAdjustAtThisDay() {
		String date = "2020-04-03";
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate thisDay = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));		
		long adjust = caculate7NewAdjustAtThisDay(11l, thisDay);
		System.out.print(adjust);
	}
	
	@Test
	public void testcaculateNewAdjustAtThisDay() {
		String firstDayStr = "2020-04-03";		
		 String DATE_FORMAT = "yyyy-MM-dd";
		 LocalDate firstDay = LocalDate.parse(firstDayStr, DateTimeFormatter.ofPattern(DATE_FORMAT));
		 long adjust = caculate7NewAdjustAtThisDay(11l, firstDay);
		 LocalDate epoch = LocalDate.ofEpochDay(0);
		 String date = "2020-04-13";
		 LocalDate at13Day = LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_FORMAT));
		 long epochDays = ChronoUnit.DAYS.between(epoch, at13Day);
		 long hashNew = (epochDays + adjust) % 11;
		System.out.print(hashNew);
	}

}
