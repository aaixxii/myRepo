package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the MM_EVENTS database table.
 * 
 */
@Entity
@Table(name = "MM_EVENTS")
@NamedQuery(name = "MmEventEntity.findAll", query = "SELECT m FROM MmEventEntity m")
public class MmEventEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String name;

	@Column(name = "LAST_TS")
	private long lastTs;

	@Column(name = "MM_ID")
	private long mmId;

	public MmEventEntity() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getLastTs() {
		return this.lastTs;
	}

	public void setLastTs(long lastTs) {
		this.lastTs = lastTs;
	}

	public long getMmId() {
		return this.mmId;
	}

	public void setMmId(long mmId) {
		this.mmId = mmId;
	}

}