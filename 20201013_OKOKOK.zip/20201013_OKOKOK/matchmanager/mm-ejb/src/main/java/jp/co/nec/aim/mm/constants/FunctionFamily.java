package jp.co.nec.aim.mm.constants;

import jp.co.nec.aim.mm.exception.AimRuntimeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum FunctionFamily {
	TI(1), TIM(1), LI(2), LIS(2), LIM(2), LIX(2), TLI(3), TLIM(3), TLIX(3), TLIS(
			3), LLI(4), LLIS(4), LLIM(4), LLIX(4), LIP(5), TLIP(6), LLIP(7), FI(
			8), II(9);

	private static Logger log = LoggerFactory.getLogger(FunctionFamily.class);

	private int val;

	public int getVal() {
		return val;
	}

	private FunctionFamily(int val) {
		this.val = val;
	}

	public static FunctionFamily fromVal(Integer val) {
		for (FunctionFamily p : FunctionFamily.values()) {
			if (p.getVal() == val)
				return p;
		}
		String message = "Unexpected function family value encountered: " + val
				+ ", returning TI.";
		log.error(message);
		return TI;
	}

	/**
	 * getFamilyId
	 * 
	 * @param functionName
	 * @return FamilyId
	 */
	public static Integer getFamilyId(String functionName) {
		for (FunctionFamily p : FunctionFamily.values()) {
			if (p.name() == functionName)
				return p.getVal();
		}
		throw new AimRuntimeException(
				"can not find FamilyId with function name:" + functionName);
	}
}
