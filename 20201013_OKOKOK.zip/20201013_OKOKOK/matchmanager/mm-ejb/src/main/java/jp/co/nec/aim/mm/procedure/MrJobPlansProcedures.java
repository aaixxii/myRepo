package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class MrJobPlansProcedures extends StoredProcedure {
	private static final String CREATE_NEW_MR_PLAN = "create_new_mr_plan";

	public MrJobPlansProcedures(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(CREATE_NEW_MR_PLAN);
		setFunction(true);
		// We must set SqlOutParameter FIRST!
		declareParameter(new SqlOutParameter("r_batch_plan_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_mr_id", Types.INTEGER));
		
		compile();
	}

	public Long createNewMrJob(long mrId) throws SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mr_id", mrId);
		Map<String, Object> resultMap = execute(map);
		Long batchPlanId = (Long) resultMap.get("r_batch_plan_id");
		return Long.valueOf(batchPlanId.longValue());
	}
}
