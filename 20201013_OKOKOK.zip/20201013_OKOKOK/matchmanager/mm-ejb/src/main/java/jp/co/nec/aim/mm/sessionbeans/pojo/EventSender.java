package jp.co.nec.aim.mm.sessionbeans.pojo;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;

import jp.co.nec.aim.baton.EventLogMessage;
import jp.co.nec.aim.baton.constant.LogKey;
import jp.co.nec.aim.baton.constant.LogType;
import jp.co.nec.aim.mm.constants.EventLogLevel;

/**
 * EventSender is send the event to MM inner queue(infoQueue)
 * 
 * @author mozj
 * 
 */
public class EventSender {
	private static Logger log = LoggerFactory.getLogger(EventSender.class);


	/**
	 * Default Constructor
	 */
	public EventSender() {		
	}

	/**
	 * Write log instead of writing EVENT_LOG TABLE.
	 * 
	 * @param reasonCode
	 * @param eventType
	 * @param unitId
	 * @param description
	 * @param level
	 */
	public void sendEvent(String reasonCode, String eventType, Long unitId,
			String description, EventLogLevel level, Date date) {
		log.info("logging event: " + eventType + " (muId " + unitId + "): "
				+ reasonCode + " " + description);
		if (unitId == null) {
			unitId = -1L;
		}
		EventLogMessage eventLogMessage = new EventLogMessage();
		// eventLogMessage.setId(-1L);
		eventLogMessage.setMuId(unitId);
		eventLogMessage.setType(eventType);
		eventLogMessage.setDescription(description);
		eventLogMessage.setLevel(level.getVal());
		eventLogMessage.setTime(date);

		Map<String, Serializable> map = Maps.newHashMap();
		map.put(LogKey.REASON_CODE.getKey(), reasonCode);
		map.put(LogKey.EVENT_LOG.getKey(), eventLogMessage);
		map.put(LogKey.TYPE.getKey(), LogType.EVENT_LOG.getType());
		map.put(LogKey.MESSAGE.getKey(), description);
		
		//jmsSender.sendToInfoQueue(map);
	}
}
