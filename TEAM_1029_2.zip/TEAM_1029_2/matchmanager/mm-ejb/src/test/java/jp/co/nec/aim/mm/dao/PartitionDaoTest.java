package jp.co.nec.aim.mm.dao;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class PartitionDaoTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private PartitionDao dao;
	@Before
	public void setUp() throws Exception {
		dao = new PartitionDao(dataSource);
	}
	
	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testGetTodayRecordCount() {
		int result = dao.getTodayRecordCount(2);
		System.out.print(result);
	}
	
	@Test
	public void testSqlScript() {
		String initSql = "ALTER TABLE SEGMENT_CHANGE_LOG "
			      + " ADD PARTITION BY LIST (P_NO)"
			      + " (PARTITION p0 VALUES IN (0))";
		System.out.println(initSql);
		
		String sql = "ALTER TABLE  SEGMENT_CHANGE_LOG ADD PARTITION (PARTITION p";
		sql = sql + 1;
		sql = sql + " VALUES IN (";
		sql = sql + 1;
		sql = sql + "))";		
		System.out.println(sql);
		
		List<Long> pNos = new ArrayList<>();
		pNos.add(12L);
		pNos.add(13L);
		pNos.add(14L);
		pNos.add(15L);
		pNos.add(16L);
		pNos.add(17L);
		
		StringBuilder sb = new StringBuilder();
		int last = pNos.size() - 1;		
		sb.append("ALTER TABLE SEGMENT_CHANGE_LOG　ADD PARTITION (");
		for (int i = 0; i < pNos.size(); i++) {
			sb.append("PARTITION p");
			sb.append(String.valueOf(pNos.get(i)));
			sb.append(" VALUES IN (");
			sb.append(String.valueOf(pNos.get(i)));
			if (i != last) {
				sb.append("),");
			} else {
				sb.append(")");
			}
		}
		sb.append(")");
		String sbStr = sb.toString();
		sbStr = String.format(sbStr);		
		System.out.println(sbStr);		
	}
	
	@Test
	public void testSqlScriptMoreOne() {
		int pNo=20;
		String sql1 = "ALTER TABLE SEGMENT_CHANGE_LOG DROP PARTITION p";
		sql1 = sql1 + pNo;
		System.out.println(sql1);
		int newPNo=11;
		String sql = "ALTER TABLE  SEGMENT_CHANGE_LOG ADD PARTITION (PARTITION p";
		sql = sql + newPNo;
		sql = sql + " VALUES IN (";
		sql = sql + newPNo;
		sql = sql + "))";
		System.out.println(sql);
		Integer intPNo = 1;
		String getCountInOnePartionSQL = "SELECT * FROM SEGMENT_CHANGE_LOG PARTITION (p" + intPNo.toString() + ")";
		System.out.println(getCountInOnePartionSQL);		
	}	
	
	@Test
	public void testPatitionPnoList() {
		LocalDate updateAtToday = LocalDate.now();
		List<LocalDate> targetDays = new ArrayList<>();		
		for (long i = 1; i<= 5; i++) {
			targetDays.add(updateAtToday.plusDays(i));
		}				
		List<Long> pNoList = targetDays.stream().map(one -> Long.valueOf(caculateHashAtThisToday(one))).collect(Collectors.toList());
		Assert.assertEquals(5,pNoList.size());
	}
	
	public  long caculateHashAtThisToday(LocalDate thisDay) {
		Long saveDays = 7L;
		Long adjust = 0L;
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + adjust.longValue()) % (saveDays.longValue());
	}		
	
	@Test
	public void testSetTodayPno() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		int updated = dao.setTodayPno(0);
		jdbcTemplate.execute("commit");
		System.out.print(updated);
	}
	
	@Test 
	public void deletePartitionsScript() {
		List<Long> pNos = new ArrayList<>();		
		pNos.add(14L);
		pNos.add(15L);
		pNos.add(16L);
		pNos.add(17L);
		StringBuilder sb = new StringBuilder();
		int last = pNos.size() - 1;
		sb.append("ALTER TABLE SEGMENT_CHANGE_LOG DROP PARTITION ");		
		 for (int i = 0; i < pNos.size(); i++) {
				sb.append("p");							
				if (i != last) {
					sb.append(pNos.get(i));	
					sb.append(",");
				} else {
					sb.append(pNos.get(i));	
				}
			}			
		 System.out.print(sb.toString());
	}
	
	@Test
	public void createNewPartitionsScript() {
		List<Long> pNos = new ArrayList<>();		
		pNos.add(14L);
		pNos.add(15L);
		pNos.add(16L);
		pNos.add(17L);
		StringBuilder sb = new StringBuilder();
		int last = pNos.size() - 1;
		sb.append("ALTER TABLE SEGMENT_CHANGE_LOG ADD PARTITION (");
		for (int i = 0; i < pNos.size(); i++) {
			sb.append("PARTITION p");
			sb.append(pNos.get(i));
			sb.append(" VALUES IN (");
			sb.append(pNos.get(i));
			if (i != last) {
				sb.append("),");
			} else {
				sb.append(")");
			}
		}
		sb.append(")");
		System.out.println(sb.toString());
		System.out.println();
	}
	
	@Test
	public void testutilDate() {
		LocalDate firstRunDay = LocalDate.now();
		java.util.Date utilDate = Date.from(firstRunDay.atStartOfDay(ZoneId.systemDefault()).toInstant());
		System.out.println(utilDate);
	}
	
	@Test
	public void testListJoner() {
		List<Long> pNos = new ArrayList<>();		
		pNos.add(14L);
		pNos.add(15L);
		pNos.add(16L);
		pNos.add(17L);
		String str = pNos.stream().map(one -> one.toString()).collect(Collectors.joining(","));
		System.out.println(str);
		
	}
}
