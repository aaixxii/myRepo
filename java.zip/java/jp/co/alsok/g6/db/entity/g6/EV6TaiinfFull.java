package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EV6TaiinfFull extends EV6TaiinfFullKey implements Serializable {
    /**
     * 隊員種別
     */
    private String TAIIN_KIND;

    /**
     * 号機番号
     */
    private String GOUKI;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * サブアドレス
     */
    private String SUBADDR;

    /**
     * 契約ＩＤ
     */
    private String KEIYAKU_ID;

    /**
     * 略称名称
     */
    private String ABBR_NM;

    /**
     * 住所コード
     */
    private String ADDRESS_CD;

    /**
     * 担当応援区分
     */
    private String TANTOU_OUEN_KBN;

    /**
     * 出動区分
     */
    private String SYUTUDOU_KBN;

    /**
     * 直行区分
     */
    private String CHOKKOU_KBN;

    /**
     * 車両管理番号
     */
    private String CAR_NUM;

    /**
     * 指示方法
     */
    private String SIJI_METHOD;

    /**
     * 指示
     */
    private String SIJI;

    /**
     * 直行
     */
    private String CHOKKOU;

    /**
     * 見込
     */
    private String MIKOMI;

    /**
     * 現着
     */
    private String GENCHAKU;

    /**
     * 所要
     */
    private String SYOYOU;

    /**
     * 入館
     */
    private String NYUUKAN;

    /**
     * 退館
     */
    private String TAIKAN;

    /**
     * 退館区分
     */
    private String TAIKAN_KBN;

    /**
     * ブレイク
     */
    private String INTERRUPT;

    /**
     * ブレイク解除
     */
    private String INTERRUPT_CANCEL;

    /**
     * 応援要請
     */
    private String OUEN_YOUSEI;

    /**
     * 応援要請解除
     */
    private String OUEN_YOUSEI_CANCEL;

    /**
     * 終了
     */
    private String END;

    /**
     * 取消
     */
    private String CANCEL;

    /**
     * 帰還
     */
    private String RTRN;

    /**
     * 待機所コード
     */
    private String TAIKISYO_CD;

    /**
     * 事業所コード
     */
    private String JIGYO_CD;

    /**
     * 警報発生時分
     */
    private String SIG_HASSEI_TS;

    /**
     * 隊員事態コード
     */
    private String TAIIN_JITAI_CD;

    /**
     * 鍵所持指示優先度
     */
    private String KEY_SIJI_PRIORITY;

    /**
     * 鍵無し指示優先度
     */
    private String NO_KEY_SIJI_PRIORITY;

    /**
     * 事態更新時刻
     */
    private String JITAI_UPDATE_TS;

    /**
     * 自動運用監視外フラグ
     */
    private String NO_AUTO_UNYO_FLG;

    /**
     * 同行者
     */
    private String DOUKOUSYA;

    /**
     * 最終更新日時
     */
    private Date LASTUPD_TS;

    /**
     * 状態フラグ
     */
    private String STATUS_FLG;

    /**
     * 隊員電話番号
     */
    private String TAIIN_TEL_NUM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_V6_TAIINF_FULL
     */
    private static final long serialVersionUID = 1L;

    /**
     * 隊員種別
     * @return TAIIN_KIND 隊員種別
     */
    public String getTAIIN_KIND() {
        return TAIIN_KIND;
    }

    /**
     * 隊員種別
     * @param TAIIN_KIND 隊員種別
     */
    public void setTAIIN_KIND(String TAIIN_KIND) {
        this.TAIIN_KIND = TAIIN_KIND == null ? null : TAIIN_KIND.trim();
    }

    /**
     * 号機番号
     * @return GOUKI 号機番号
     */
    public String getGOUKI() {
        return GOUKI;
    }

    /**
     * 号機番号
     * @param GOUKI 号機番号
     */
    public void setGOUKI(String GOUKI) {
        this.GOUKI = GOUKI == null ? null : GOUKI.trim();
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * サブアドレス
     * @return SUBADDR サブアドレス
     */
    public String getSUBADDR() {
        return SUBADDR;
    }

    /**
     * サブアドレス
     * @param SUBADDR サブアドレス
     */
    public void setSUBADDR(String SUBADDR) {
        this.SUBADDR = SUBADDR == null ? null : SUBADDR.trim();
    }

    /**
     * 契約ＩＤ
     * @return KEIYAKU_ID 契約ＩＤ
     */
    public String getKEIYAKU_ID() {
        return KEIYAKU_ID;
    }

    /**
     * 契約ＩＤ
     * @param KEIYAKU_ID 契約ＩＤ
     */
    public void setKEIYAKU_ID(String KEIYAKU_ID) {
        this.KEIYAKU_ID = KEIYAKU_ID == null ? null : KEIYAKU_ID.trim();
    }

    /**
     * 略称名称
     * @return ABBR_NM 略称名称
     */
    public String getABBR_NM() {
        return ABBR_NM;
    }

    /**
     * 略称名称
     * @param ABBR_NM 略称名称
     */
    public void setABBR_NM(String ABBR_NM) {
        this.ABBR_NM = ABBR_NM == null ? null : ABBR_NM.trim();
    }

    /**
     * 住所コード
     * @return ADDRESS_CD 住所コード
     */
    public String getADDRESS_CD() {
        return ADDRESS_CD;
    }

    /**
     * 住所コード
     * @param ADDRESS_CD 住所コード
     */
    public void setADDRESS_CD(String ADDRESS_CD) {
        this.ADDRESS_CD = ADDRESS_CD == null ? null : ADDRESS_CD.trim();
    }

    /**
     * 担当応援区分
     * @return TANTOU_OUEN_KBN 担当応援区分
     */
    public String getTANTOU_OUEN_KBN() {
        return TANTOU_OUEN_KBN;
    }

    /**
     * 担当応援区分
     * @param TANTOU_OUEN_KBN 担当応援区分
     */
    public void setTANTOU_OUEN_KBN(String TANTOU_OUEN_KBN) {
        this.TANTOU_OUEN_KBN = TANTOU_OUEN_KBN == null ? null : TANTOU_OUEN_KBN.trim();
    }

    /**
     * 出動区分
     * @return SYUTUDOU_KBN 出動区分
     */
    public String getSYUTUDOU_KBN() {
        return SYUTUDOU_KBN;
    }

    /**
     * 出動区分
     * @param SYUTUDOU_KBN 出動区分
     */
    public void setSYUTUDOU_KBN(String SYUTUDOU_KBN) {
        this.SYUTUDOU_KBN = SYUTUDOU_KBN == null ? null : SYUTUDOU_KBN.trim();
    }

    /**
     * 直行区分
     * @return CHOKKOU_KBN 直行区分
     */
    public String getCHOKKOU_KBN() {
        return CHOKKOU_KBN;
    }

    /**
     * 直行区分
     * @param CHOKKOU_KBN 直行区分
     */
    public void setCHOKKOU_KBN(String CHOKKOU_KBN) {
        this.CHOKKOU_KBN = CHOKKOU_KBN == null ? null : CHOKKOU_KBN.trim();
    }

    /**
     * 車両管理番号
     * @return CAR_NUM 車両管理番号
     */
    public String getCAR_NUM() {
        return CAR_NUM;
    }

    /**
     * 車両管理番号
     * @param CAR_NUM 車両管理番号
     */
    public void setCAR_NUM(String CAR_NUM) {
        this.CAR_NUM = CAR_NUM == null ? null : CAR_NUM.trim();
    }

    /**
     * 指示方法
     * @return SIJI_METHOD 指示方法
     */
    public String getSIJI_METHOD() {
        return SIJI_METHOD;
    }

    /**
     * 指示方法
     * @param SIJI_METHOD 指示方法
     */
    public void setSIJI_METHOD(String SIJI_METHOD) {
        this.SIJI_METHOD = SIJI_METHOD == null ? null : SIJI_METHOD.trim();
    }

    /**
     * 指示
     * @return SIJI 指示
     */
    public String getSIJI() {
        return SIJI;
    }

    /**
     * 指示
     * @param SIJI 指示
     */
    public void setSIJI(String SIJI) {
        this.SIJI = SIJI == null ? null : SIJI.trim();
    }

    /**
     * 直行
     * @return CHOKKOU 直行
     */
    public String getCHOKKOU() {
        return CHOKKOU;
    }

    /**
     * 直行
     * @param CHOKKOU 直行
     */
    public void setCHOKKOU(String CHOKKOU) {
        this.CHOKKOU = CHOKKOU == null ? null : CHOKKOU.trim();
    }

    /**
     * 見込
     * @return MIKOMI 見込
     */
    public String getMIKOMI() {
        return MIKOMI;
    }

    /**
     * 見込
     * @param MIKOMI 見込
     */
    public void setMIKOMI(String MIKOMI) {
        this.MIKOMI = MIKOMI == null ? null : MIKOMI.trim();
    }

    /**
     * 現着
     * @return GENCHAKU 現着
     */
    public String getGENCHAKU() {
        return GENCHAKU;
    }

    /**
     * 現着
     * @param GENCHAKU 現着
     */
    public void setGENCHAKU(String GENCHAKU) {
        this.GENCHAKU = GENCHAKU == null ? null : GENCHAKU.trim();
    }

    /**
     * 所要
     * @return SYOYOU 所要
     */
    public String getSYOYOU() {
        return SYOYOU;
    }

    /**
     * 所要
     * @param SYOYOU 所要
     */
    public void setSYOYOU(String SYOYOU) {
        this.SYOYOU = SYOYOU == null ? null : SYOYOU.trim();
    }

    /**
     * 入館
     * @return NYUUKAN 入館
     */
    public String getNYUUKAN() {
        return NYUUKAN;
    }

    /**
     * 入館
     * @param NYUUKAN 入館
     */
    public void setNYUUKAN(String NYUUKAN) {
        this.NYUUKAN = NYUUKAN == null ? null : NYUUKAN.trim();
    }

    /**
     * 退館
     * @return TAIKAN 退館
     */
    public String getTAIKAN() {
        return TAIKAN;
    }

    /**
     * 退館
     * @param TAIKAN 退館
     */
    public void setTAIKAN(String TAIKAN) {
        this.TAIKAN = TAIKAN == null ? null : TAIKAN.trim();
    }

    /**
     * 退館区分
     * @return TAIKAN_KBN 退館区分
     */
    public String getTAIKAN_KBN() {
        return TAIKAN_KBN;
    }

    /**
     * 退館区分
     * @param TAIKAN_KBN 退館区分
     */
    public void setTAIKAN_KBN(String TAIKAN_KBN) {
        this.TAIKAN_KBN = TAIKAN_KBN == null ? null : TAIKAN_KBN.trim();
    }

    /**
     * ブレイク
     * @return INTERRUPT ブレイク
     */
    public String getINTERRUPT() {
        return INTERRUPT;
    }

    /**
     * ブレイク
     * @param INTERRUPT ブレイク
     */
    public void setINTERRUPT(String INTERRUPT) {
        this.INTERRUPT = INTERRUPT == null ? null : INTERRUPT.trim();
    }

    /**
     * ブレイク解除
     * @return INTERRUPT_CANCEL ブレイク解除
     */
    public String getINTERRUPT_CANCEL() {
        return INTERRUPT_CANCEL;
    }

    /**
     * ブレイク解除
     * @param INTERRUPT_CANCEL ブレイク解除
     */
    public void setINTERRUPT_CANCEL(String INTERRUPT_CANCEL) {
        this.INTERRUPT_CANCEL = INTERRUPT_CANCEL == null ? null : INTERRUPT_CANCEL.trim();
    }

    /**
     * 応援要請
     * @return OUEN_YOUSEI 応援要請
     */
    public String getOUEN_YOUSEI() {
        return OUEN_YOUSEI;
    }

    /**
     * 応援要請
     * @param OUEN_YOUSEI 応援要請
     */
    public void setOUEN_YOUSEI(String OUEN_YOUSEI) {
        this.OUEN_YOUSEI = OUEN_YOUSEI == null ? null : OUEN_YOUSEI.trim();
    }

    /**
     * 応援要請解除
     * @return OUEN_YOUSEI_CANCEL 応援要請解除
     */
    public String getOUEN_YOUSEI_CANCEL() {
        return OUEN_YOUSEI_CANCEL;
    }

    /**
     * 応援要請解除
     * @param OUEN_YOUSEI_CANCEL 応援要請解除
     */
    public void setOUEN_YOUSEI_CANCEL(String OUEN_YOUSEI_CANCEL) {
        this.OUEN_YOUSEI_CANCEL = OUEN_YOUSEI_CANCEL == null ? null : OUEN_YOUSEI_CANCEL.trim();
    }

    /**
     * 終了
     * @return END 終了
     */
    public String getEND() {
        return END;
    }

    /**
     * 終了
     * @param END 終了
     */
    public void setEND(String END) {
        this.END = END == null ? null : END.trim();
    }

    /**
     * 取消
     * @return CANCEL 取消
     */
    public String getCANCEL() {
        return CANCEL;
    }

    /**
     * 取消
     * @param CANCEL 取消
     */
    public void setCANCEL(String CANCEL) {
        this.CANCEL = CANCEL == null ? null : CANCEL.trim();
    }

    /**
     * 帰還
     * @return RTRN 帰還
     */
    public String getRTRN() {
        return RTRN;
    }

    /**
     * 帰還
     * @param RTRN 帰還
     */
    public void setRTRN(String RTRN) {
        this.RTRN = RTRN == null ? null : RTRN.trim();
    }

    /**
     * 待機所コード
     * @return TAIKISYO_CD 待機所コード
     */
    public String getTAIKISYO_CD() {
        return TAIKISYO_CD;
    }

    /**
     * 待機所コード
     * @param TAIKISYO_CD 待機所コード
     */
    public void setTAIKISYO_CD(String TAIKISYO_CD) {
        this.TAIKISYO_CD = TAIKISYO_CD == null ? null : TAIKISYO_CD.trim();
    }

    /**
     * 事業所コード
     * @return JIGYO_CD 事業所コード
     */
    public String getJIGYO_CD() {
        return JIGYO_CD;
    }

    /**
     * 事業所コード
     * @param JIGYO_CD 事業所コード
     */
    public void setJIGYO_CD(String JIGYO_CD) {
        this.JIGYO_CD = JIGYO_CD == null ? null : JIGYO_CD.trim();
    }

    /**
     * 警報発生時分
     * @return SIG_HASSEI_TS 警報発生時分
     */
    public String getSIG_HASSEI_TS() {
        return SIG_HASSEI_TS;
    }

    /**
     * 警報発生時分
     * @param SIG_HASSEI_TS 警報発生時分
     */
    public void setSIG_HASSEI_TS(String SIG_HASSEI_TS) {
        this.SIG_HASSEI_TS = SIG_HASSEI_TS == null ? null : SIG_HASSEI_TS.trim();
    }

    /**
     * 隊員事態コード
     * @return TAIIN_JITAI_CD 隊員事態コード
     */
    public String getTAIIN_JITAI_CD() {
        return TAIIN_JITAI_CD;
    }

    /**
     * 隊員事態コード
     * @param TAIIN_JITAI_CD 隊員事態コード
     */
    public void setTAIIN_JITAI_CD(String TAIIN_JITAI_CD) {
        this.TAIIN_JITAI_CD = TAIIN_JITAI_CD == null ? null : TAIIN_JITAI_CD.trim();
    }

    /**
     * 鍵所持指示優先度
     * @return KEY_SIJI_PRIORITY 鍵所持指示優先度
     */
    public String getKEY_SIJI_PRIORITY() {
        return KEY_SIJI_PRIORITY;
    }

    /**
     * 鍵所持指示優先度
     * @param KEY_SIJI_PRIORITY 鍵所持指示優先度
     */
    public void setKEY_SIJI_PRIORITY(String KEY_SIJI_PRIORITY) {
        this.KEY_SIJI_PRIORITY = KEY_SIJI_PRIORITY == null ? null : KEY_SIJI_PRIORITY.trim();
    }

    /**
     * 鍵無し指示優先度
     * @return NO_KEY_SIJI_PRIORITY 鍵無し指示優先度
     */
    public String getNO_KEY_SIJI_PRIORITY() {
        return NO_KEY_SIJI_PRIORITY;
    }

    /**
     * 鍵無し指示優先度
     * @param NO_KEY_SIJI_PRIORITY 鍵無し指示優先度
     */
    public void setNO_KEY_SIJI_PRIORITY(String NO_KEY_SIJI_PRIORITY) {
        this.NO_KEY_SIJI_PRIORITY = NO_KEY_SIJI_PRIORITY == null ? null : NO_KEY_SIJI_PRIORITY.trim();
    }

    /**
     * 事態更新時刻
     * @return JITAI_UPDATE_TS 事態更新時刻
     */
    public String getJITAI_UPDATE_TS() {
        return JITAI_UPDATE_TS;
    }

    /**
     * 事態更新時刻
     * @param JITAI_UPDATE_TS 事態更新時刻
     */
    public void setJITAI_UPDATE_TS(String JITAI_UPDATE_TS) {
        this.JITAI_UPDATE_TS = JITAI_UPDATE_TS == null ? null : JITAI_UPDATE_TS.trim();
    }

    /**
     * 自動運用監視外フラグ
     * @return NO_AUTO_UNYO_FLG 自動運用監視外フラグ
     */
    public String getNO_AUTO_UNYO_FLG() {
        return NO_AUTO_UNYO_FLG;
    }

    /**
     * 自動運用監視外フラグ
     * @param NO_AUTO_UNYO_FLG 自動運用監視外フラグ
     */
    public void setNO_AUTO_UNYO_FLG(String NO_AUTO_UNYO_FLG) {
        this.NO_AUTO_UNYO_FLG = NO_AUTO_UNYO_FLG == null ? null : NO_AUTO_UNYO_FLG.trim();
    }

    /**
     * 同行者
     * @return DOUKOUSYA 同行者
     */
    public String getDOUKOUSYA() {
        return DOUKOUSYA;
    }

    /**
     * 同行者
     * @param DOUKOUSYA 同行者
     */
    public void setDOUKOUSYA(String DOUKOUSYA) {
        this.DOUKOUSYA = DOUKOUSYA == null ? null : DOUKOUSYA.trim();
    }

    /**
     * 最終更新日時
     * @return LASTUPD_TS 最終更新日時
     */
    public Date getLASTUPD_TS() {
        return LASTUPD_TS;
    }

    /**
     * 最終更新日時
     * @param LASTUPD_TS 最終更新日時
     */
    public void setLASTUPD_TS(Date LASTUPD_TS) {
        this.LASTUPD_TS = LASTUPD_TS;
    }

    /**
     * 状態フラグ
     * @return STATUS_FLG 状態フラグ
     */
    public String getSTATUS_FLG() {
        return STATUS_FLG;
    }

    /**
     * 状態フラグ
     * @param STATUS_FLG 状態フラグ
     */
    public void setSTATUS_FLG(String STATUS_FLG) {
        this.STATUS_FLG = STATUS_FLG == null ? null : STATUS_FLG.trim();
    }

    /**
     * 隊員電話番号
     * @return TAIIN_TEL_NUM 隊員電話番号
     */
    public String getTAIIN_TEL_NUM() {
        return TAIIN_TEL_NUM;
    }

    /**
     * 隊員電話番号
     * @param TAIIN_TEL_NUM 隊員電話番号
     */
    public void setTAIIN_TEL_NUM(String TAIIN_TEL_NUM) {
        this.TAIIN_TEL_NUM = TAIIN_TEL_NUM == null ? null : TAIIN_TEL_NUM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}