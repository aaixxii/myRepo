package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class EV6JianKey implements Serializable {
    /**
     * GC番号
     */
    private String GC_NUM;

    /**
     * LN_ＳＧＳ論理番号
     */
    private String LN_SGS;

    /**
     * 事案発生日付
     */
    private String HASSEI_TS;

    /**
     * E_V6_JIAN
     */
    private static final long serialVersionUID = 1L;

    /**
     * GC番号
     * @return GC_NUM GC番号
     */
    public String getGC_NUM() {
        return GC_NUM;
    }

    /**
     * GC番号
     * @param GC_NUM GC番号
     */
    public void setGC_NUM(String GC_NUM) {
        this.GC_NUM = GC_NUM == null ? null : GC_NUM.trim();
    }

    /**
     * LN_ＳＧＳ論理番号
     * @return LN_SGS LN_ＳＧＳ論理番号
     */
    public String getLN_SGS() {
        return LN_SGS;
    }

    /**
     * LN_ＳＧＳ論理番号
     * @param LN_SGS LN_ＳＧＳ論理番号
     */
    public void setLN_SGS(String LN_SGS) {
        this.LN_SGS = LN_SGS == null ? null : LN_SGS.trim();
    }

    /**
     * 事案発生日付
     * @return HASSEI_TS 事案発生日付
     */
    public String getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 事案発生日付
     * @param HASSEI_TS 事案発生日付
     */
    public void setHASSEI_TS(String HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS == null ? null : HASSEI_TS.trim();
    }
}