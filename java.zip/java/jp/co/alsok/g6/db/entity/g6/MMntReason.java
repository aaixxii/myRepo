package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MMntReason implements Serializable {
    /**
     * 理由ID
     */
    private String REASON_ID;

    /**
     * 理由
     */
    private String REASON;

    /**
     * 表示順
     */
    private String ORDER_NUM;

    /**
     * M_MNT_REASON
     */
    private static final long serialVersionUID = 1L;

    /**
     * 理由ID
     * @return REASON_ID 理由ID
     */
    public String getREASON_ID() {
        return REASON_ID;
    }

    /**
     * 理由ID
     * @param REASON_ID 理由ID
     */
    public void setREASON_ID(String REASON_ID) {
        this.REASON_ID = REASON_ID == null ? null : REASON_ID.trim();
    }

    /**
     * 理由
     * @return REASON 理由
     */
    public String getREASON() {
        return REASON;
    }

    /**
     * 理由
     * @param REASON 理由
     */
    public void setREASON(String REASON) {
        this.REASON = REASON == null ? null : REASON.trim();
    }

    /**
     * 表示順
     * @return ORDER_NUM 表示順
     */
    public String getORDER_NUM() {
        return ORDER_NUM;
    }

    /**
     * 表示順
     * @param ORDER_NUM 表示順
     */
    public void setORDER_NUM(String ORDER_NUM) {
        this.ORDER_NUM = ORDER_NUM == null ? null : ORDER_NUM.trim();
    }
}