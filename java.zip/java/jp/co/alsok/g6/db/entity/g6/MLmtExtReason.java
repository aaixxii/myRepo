package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MLmtExtReason implements Serializable {
    /**
     * LN_リミットタイマ延長理由論理番号
     */
    private String LN_LMT_EXT_REASON;

    /**
     * 表示順番
     */
    private String ORDER_NUM;

    /**
     * 内容
     */
    private String LMT_EXT_REASON_NAIYOU;

    /**
     * M_LMT_EXT_REASON
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_リミットタイマ延長理由論理番号
     * @return LN_LMT_EXT_REASON LN_リミットタイマ延長理由論理番号
     */
    public String getLN_LMT_EXT_REASON() {
        return LN_LMT_EXT_REASON;
    }

    /**
     * LN_リミットタイマ延長理由論理番号
     * @param LN_LMT_EXT_REASON LN_リミットタイマ延長理由論理番号
     */
    public void setLN_LMT_EXT_REASON(String LN_LMT_EXT_REASON) {
        this.LN_LMT_EXT_REASON = LN_LMT_EXT_REASON == null ? null : LN_LMT_EXT_REASON.trim();
    }

    /**
     * 表示順番
     * @return ORDER_NUM 表示順番
     */
    public String getORDER_NUM() {
        return ORDER_NUM;
    }

    /**
     * 表示順番
     * @param ORDER_NUM 表示順番
     */
    public void setORDER_NUM(String ORDER_NUM) {
        this.ORDER_NUM = ORDER_NUM == null ? null : ORDER_NUM.trim();
    }

    /**
     * 内容
     * @return LMT_EXT_REASON_NAIYOU 内容
     */
    public String getLMT_EXT_REASON_NAIYOU() {
        return LMT_EXT_REASON_NAIYOU;
    }

    /**
     * 内容
     * @param LMT_EXT_REASON_NAIYOU 内容
     */
    public void setLMT_EXT_REASON_NAIYOU(String LMT_EXT_REASON_NAIYOU) {
        this.LMT_EXT_REASON_NAIYOU = LMT_EXT_REASON_NAIYOU == null ? null : LMT_EXT_REASON_NAIYOU.trim();
    }
}