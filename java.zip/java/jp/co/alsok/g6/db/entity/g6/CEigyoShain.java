package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CEigyoShain extends CEigyoShainKey implements Serializable {
    /**
     * 適用開始年月日
     */
    private String TEKIYO_KAISHI_YMD;

    /**
     * 適用終了年月日
     */
    private String TEKIYO_SHURYO_YMD;

    /**
     * 入社年月日
     */
    private String NYUSHA_YMD;

    /**
     * 退職年月日
     */
    private String TAISHOKU_YMD;

    /**
     * 社員氏名
     */
    private String SHAIN_NM;

    /**
     * 社員姓氏名
     */
    private String SHAINSEI_NM;

    /**
     * 社員名氏名
     */
    private String SHAIMMEI_NM;

    /**
     * 社員半角カナ氏名
     */
    private String SHAIN_HKN_NM;

    /**
     * 社員カナ氏名
     */
    private String SHAIN_KN_NM;

    /**
     * 身分コード
     */
    private String MIBUN_CD;

    /**
     * 身分名称
     */
    private String MIBUN_NM;

    /**
     * 性別区分
     */
    private String SEIBETSU_KBN;

    /**
     * 性別名称
     */
    private String SEIBETSU_NM;

    /**
     * 採用区分
     */
    private String SHAIN_SAIYO_KBN;

    /**
     * 採用名称
     */
    private String SHAIN_SAIYO__NM;

    /**
     * 社会保険加入フラグ
     */
    private String SHAKAI_HOKEN_KANYU_FLG;

    /**
     * 社会保険加入名称
     */
    private String SHAKAI_HOKEN_KANYU_NM;

    /**
     * 役職コード
     */
    private String YAKUSHOKU_CD;

    /**
     * 役職名称
     */
    private String YAKUSHOKU_NM;

    /**
     * 役職略称
     */
    private String YAKUSHOKU_RNM;

    /**
     * 職務コード
     */
    private String SHOKUMU_CD;

    /**
     * 職務名称
     */
    private String SHOKUMU_NM;

    /**
     * 職務略称
     */
    private String SHOKUMU_RNM;

    /**
     * 事業セグメントコード
     */
    private String JIGYO_SEGMENT_CD;

    /**
     * 事業セグメント名称
     */
    private String JIGYO_SEGMENT_NM;

    /**
     * 職種コード
     */
    private String SHOKUSHU_CD;

    /**
     * 職種名称
     */
    private String SHOKUSHU_NM;

    /**
     * 予備項目01
     */
    private String YOBI_KOMOKU_01;

    /**
     * 予備項目02
     */
    private String YOBI_KOMOKU_02;

    /**
     * 予備項目03
     */
    private String YOBI_KOMOKU_03;

    /**
     * 予備項目04
     */
    private String YOBI_KOMOKU_04;

    /**
     * 予備項目05
     */
    private String YOBI_KOMOKU_05;

    /**
     * 予備項目06
     */
    private String YOBI_KOMOKU_06;

    /**
     * 予備項目07
     */
    private String YOBI_KOMOKU_07;

    /**
     * 予備項目08
     */
    private String YOBI_KOMOKU_08;

    /**
     * 予備項目09
     */
    private String YOBI_KOMOKU_09;

    /**
     * 予備項目10
     */
    private String YOBI_KOMOKU_10;

    /**
     * 登録タイムスタンプ
     */
    private Date REGST_TMSTMP;

    /**
     * 登録者会社コード
     */
    private String REGSTR_CO_CD;

    /**
     * 登録者組織コード
     */
    private String REGSTR_SOSHIKI_CD;

    /**
     * 登録者社員番号
     */
    private String REGSTR_EMP_NO;

    /**
     * 登録画面ＩＤ
     */
    private String REGST_GAMEN_ID;

    /**
     * 登録プログラムＩＤ
     */
    private String REGST_PGM_ID;

    /**
     * 更新タイムスタンプ
     */
    private Date UPD_TMSTMP;

    /**
     * 更新者会社コード
     */
    private String UPDTR_CO_CD;

    /**
     * 更新者組織コード
     */
    private String UPDTR_SOSHIKI_CD;

    /**
     * 更新者社員番号
     */
    private String UPDTR_EMP_NO;

    /**
     * 更新画面ＩＤ
     */
    private String UPD_GAMEN_ID;

    /**
     * 更新プログラムＩＤ
     */
    private String UPD_PGM_ID;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_EIGYO_SHAIN
     */
    private static final long serialVersionUID = 1L;

    /**
     * 適用開始年月日
     * @return TEKIYO_KAISHI_YMD 適用開始年月日
     */
    public String getTEKIYO_KAISHI_YMD() {
        return TEKIYO_KAISHI_YMD;
    }

    /**
     * 適用開始年月日
     * @param TEKIYO_KAISHI_YMD 適用開始年月日
     */
    public void setTEKIYO_KAISHI_YMD(String TEKIYO_KAISHI_YMD) {
        this.TEKIYO_KAISHI_YMD = TEKIYO_KAISHI_YMD == null ? null : TEKIYO_KAISHI_YMD.trim();
    }

    /**
     * 適用終了年月日
     * @return TEKIYO_SHURYO_YMD 適用終了年月日
     */
    public String getTEKIYO_SHURYO_YMD() {
        return TEKIYO_SHURYO_YMD;
    }

    /**
     * 適用終了年月日
     * @param TEKIYO_SHURYO_YMD 適用終了年月日
     */
    public void setTEKIYO_SHURYO_YMD(String TEKIYO_SHURYO_YMD) {
        this.TEKIYO_SHURYO_YMD = TEKIYO_SHURYO_YMD == null ? null : TEKIYO_SHURYO_YMD.trim();
    }

    /**
     * 入社年月日
     * @return NYUSHA_YMD 入社年月日
     */
    public String getNYUSHA_YMD() {
        return NYUSHA_YMD;
    }

    /**
     * 入社年月日
     * @param NYUSHA_YMD 入社年月日
     */
    public void setNYUSHA_YMD(String NYUSHA_YMD) {
        this.NYUSHA_YMD = NYUSHA_YMD == null ? null : NYUSHA_YMD.trim();
    }

    /**
     * 退職年月日
     * @return TAISHOKU_YMD 退職年月日
     */
    public String getTAISHOKU_YMD() {
        return TAISHOKU_YMD;
    }

    /**
     * 退職年月日
     * @param TAISHOKU_YMD 退職年月日
     */
    public void setTAISHOKU_YMD(String TAISHOKU_YMD) {
        this.TAISHOKU_YMD = TAISHOKU_YMD == null ? null : TAISHOKU_YMD.trim();
    }

    /**
     * 社員氏名
     * @return SHAIN_NM 社員氏名
     */
    public String getSHAIN_NM() {
        return SHAIN_NM;
    }

    /**
     * 社員氏名
     * @param SHAIN_NM 社員氏名
     */
    public void setSHAIN_NM(String SHAIN_NM) {
        this.SHAIN_NM = SHAIN_NM == null ? null : SHAIN_NM.trim();
    }

    /**
     * 社員姓氏名
     * @return SHAINSEI_NM 社員姓氏名
     */
    public String getSHAINSEI_NM() {
        return SHAINSEI_NM;
    }

    /**
     * 社員姓氏名
     * @param SHAINSEI_NM 社員姓氏名
     */
    public void setSHAINSEI_NM(String SHAINSEI_NM) {
        this.SHAINSEI_NM = SHAINSEI_NM == null ? null : SHAINSEI_NM.trim();
    }

    /**
     * 社員名氏名
     * @return SHAIMMEI_NM 社員名氏名
     */
    public String getSHAIMMEI_NM() {
        return SHAIMMEI_NM;
    }

    /**
     * 社員名氏名
     * @param SHAIMMEI_NM 社員名氏名
     */
    public void setSHAIMMEI_NM(String SHAIMMEI_NM) {
        this.SHAIMMEI_NM = SHAIMMEI_NM == null ? null : SHAIMMEI_NM.trim();
    }

    /**
     * 社員半角カナ氏名
     * @return SHAIN_HKN_NM 社員半角カナ氏名
     */
    public String getSHAIN_HKN_NM() {
        return SHAIN_HKN_NM;
    }

    /**
     * 社員半角カナ氏名
     * @param SHAIN_HKN_NM 社員半角カナ氏名
     */
    public void setSHAIN_HKN_NM(String SHAIN_HKN_NM) {
        this.SHAIN_HKN_NM = SHAIN_HKN_NM == null ? null : SHAIN_HKN_NM.trim();
    }

    /**
     * 社員カナ氏名
     * @return SHAIN_KN_NM 社員カナ氏名
     */
    public String getSHAIN_KN_NM() {
        return SHAIN_KN_NM;
    }

    /**
     * 社員カナ氏名
     * @param SHAIN_KN_NM 社員カナ氏名
     */
    public void setSHAIN_KN_NM(String SHAIN_KN_NM) {
        this.SHAIN_KN_NM = SHAIN_KN_NM == null ? null : SHAIN_KN_NM.trim();
    }

    /**
     * 身分コード
     * @return MIBUN_CD 身分コード
     */
    public String getMIBUN_CD() {
        return MIBUN_CD;
    }

    /**
     * 身分コード
     * @param MIBUN_CD 身分コード
     */
    public void setMIBUN_CD(String MIBUN_CD) {
        this.MIBUN_CD = MIBUN_CD == null ? null : MIBUN_CD.trim();
    }

    /**
     * 身分名称
     * @return MIBUN_NM 身分名称
     */
    public String getMIBUN_NM() {
        return MIBUN_NM;
    }

    /**
     * 身分名称
     * @param MIBUN_NM 身分名称
     */
    public void setMIBUN_NM(String MIBUN_NM) {
        this.MIBUN_NM = MIBUN_NM == null ? null : MIBUN_NM.trim();
    }

    /**
     * 性別区分
     * @return SEIBETSU_KBN 性別区分
     */
    public String getSEIBETSU_KBN() {
        return SEIBETSU_KBN;
    }

    /**
     * 性別区分
     * @param SEIBETSU_KBN 性別区分
     */
    public void setSEIBETSU_KBN(String SEIBETSU_KBN) {
        this.SEIBETSU_KBN = SEIBETSU_KBN == null ? null : SEIBETSU_KBN.trim();
    }

    /**
     * 性別名称
     * @return SEIBETSU_NM 性別名称
     */
    public String getSEIBETSU_NM() {
        return SEIBETSU_NM;
    }

    /**
     * 性別名称
     * @param SEIBETSU_NM 性別名称
     */
    public void setSEIBETSU_NM(String SEIBETSU_NM) {
        this.SEIBETSU_NM = SEIBETSU_NM == null ? null : SEIBETSU_NM.trim();
    }

    /**
     * 採用区分
     * @return SHAIN_SAIYO_KBN 採用区分
     */
    public String getSHAIN_SAIYO_KBN() {
        return SHAIN_SAIYO_KBN;
    }

    /**
     * 採用区分
     * @param SHAIN_SAIYO_KBN 採用区分
     */
    public void setSHAIN_SAIYO_KBN(String SHAIN_SAIYO_KBN) {
        this.SHAIN_SAIYO_KBN = SHAIN_SAIYO_KBN == null ? null : SHAIN_SAIYO_KBN.trim();
    }

    /**
     * 採用名称
     * @return SHAIN_SAIYO__NM 採用名称
     */
    public String getSHAIN_SAIYO__NM() {
        return SHAIN_SAIYO__NM;
    }

    /**
     * 採用名称
     * @param SHAIN_SAIYO__NM 採用名称
     */
    public void setSHAIN_SAIYO__NM(String SHAIN_SAIYO__NM) {
        this.SHAIN_SAIYO__NM = SHAIN_SAIYO__NM == null ? null : SHAIN_SAIYO__NM.trim();
    }

    /**
     * 社会保険加入フラグ
     * @return SHAKAI_HOKEN_KANYU_FLG 社会保険加入フラグ
     */
    public String getSHAKAI_HOKEN_KANYU_FLG() {
        return SHAKAI_HOKEN_KANYU_FLG;
    }

    /**
     * 社会保険加入フラグ
     * @param SHAKAI_HOKEN_KANYU_FLG 社会保険加入フラグ
     */
    public void setSHAKAI_HOKEN_KANYU_FLG(String SHAKAI_HOKEN_KANYU_FLG) {
        this.SHAKAI_HOKEN_KANYU_FLG = SHAKAI_HOKEN_KANYU_FLG == null ? null : SHAKAI_HOKEN_KANYU_FLG.trim();
    }

    /**
     * 社会保険加入名称
     * @return SHAKAI_HOKEN_KANYU_NM 社会保険加入名称
     */
    public String getSHAKAI_HOKEN_KANYU_NM() {
        return SHAKAI_HOKEN_KANYU_NM;
    }

    /**
     * 社会保険加入名称
     * @param SHAKAI_HOKEN_KANYU_NM 社会保険加入名称
     */
    public void setSHAKAI_HOKEN_KANYU_NM(String SHAKAI_HOKEN_KANYU_NM) {
        this.SHAKAI_HOKEN_KANYU_NM = SHAKAI_HOKEN_KANYU_NM == null ? null : SHAKAI_HOKEN_KANYU_NM.trim();
    }

    /**
     * 役職コード
     * @return YAKUSHOKU_CD 役職コード
     */
    public String getYAKUSHOKU_CD() {
        return YAKUSHOKU_CD;
    }

    /**
     * 役職コード
     * @param YAKUSHOKU_CD 役職コード
     */
    public void setYAKUSHOKU_CD(String YAKUSHOKU_CD) {
        this.YAKUSHOKU_CD = YAKUSHOKU_CD == null ? null : YAKUSHOKU_CD.trim();
    }

    /**
     * 役職名称
     * @return YAKUSHOKU_NM 役職名称
     */
    public String getYAKUSHOKU_NM() {
        return YAKUSHOKU_NM;
    }

    /**
     * 役職名称
     * @param YAKUSHOKU_NM 役職名称
     */
    public void setYAKUSHOKU_NM(String YAKUSHOKU_NM) {
        this.YAKUSHOKU_NM = YAKUSHOKU_NM == null ? null : YAKUSHOKU_NM.trim();
    }

    /**
     * 役職略称
     * @return YAKUSHOKU_RNM 役職略称
     */
    public String getYAKUSHOKU_RNM() {
        return YAKUSHOKU_RNM;
    }

    /**
     * 役職略称
     * @param YAKUSHOKU_RNM 役職略称
     */
    public void setYAKUSHOKU_RNM(String YAKUSHOKU_RNM) {
        this.YAKUSHOKU_RNM = YAKUSHOKU_RNM == null ? null : YAKUSHOKU_RNM.trim();
    }

    /**
     * 職務コード
     * @return SHOKUMU_CD 職務コード
     */
    public String getSHOKUMU_CD() {
        return SHOKUMU_CD;
    }

    /**
     * 職務コード
     * @param SHOKUMU_CD 職務コード
     */
    public void setSHOKUMU_CD(String SHOKUMU_CD) {
        this.SHOKUMU_CD = SHOKUMU_CD == null ? null : SHOKUMU_CD.trim();
    }

    /**
     * 職務名称
     * @return SHOKUMU_NM 職務名称
     */
    public String getSHOKUMU_NM() {
        return SHOKUMU_NM;
    }

    /**
     * 職務名称
     * @param SHOKUMU_NM 職務名称
     */
    public void setSHOKUMU_NM(String SHOKUMU_NM) {
        this.SHOKUMU_NM = SHOKUMU_NM == null ? null : SHOKUMU_NM.trim();
    }

    /**
     * 職務略称
     * @return SHOKUMU_RNM 職務略称
     */
    public String getSHOKUMU_RNM() {
        return SHOKUMU_RNM;
    }

    /**
     * 職務略称
     * @param SHOKUMU_RNM 職務略称
     */
    public void setSHOKUMU_RNM(String SHOKUMU_RNM) {
        this.SHOKUMU_RNM = SHOKUMU_RNM == null ? null : SHOKUMU_RNM.trim();
    }

    /**
     * 事業セグメントコード
     * @return JIGYO_SEGMENT_CD 事業セグメントコード
     */
    public String getJIGYO_SEGMENT_CD() {
        return JIGYO_SEGMENT_CD;
    }

    /**
     * 事業セグメントコード
     * @param JIGYO_SEGMENT_CD 事業セグメントコード
     */
    public void setJIGYO_SEGMENT_CD(String JIGYO_SEGMENT_CD) {
        this.JIGYO_SEGMENT_CD = JIGYO_SEGMENT_CD == null ? null : JIGYO_SEGMENT_CD.trim();
    }

    /**
     * 事業セグメント名称
     * @return JIGYO_SEGMENT_NM 事業セグメント名称
     */
    public String getJIGYO_SEGMENT_NM() {
        return JIGYO_SEGMENT_NM;
    }

    /**
     * 事業セグメント名称
     * @param JIGYO_SEGMENT_NM 事業セグメント名称
     */
    public void setJIGYO_SEGMENT_NM(String JIGYO_SEGMENT_NM) {
        this.JIGYO_SEGMENT_NM = JIGYO_SEGMENT_NM == null ? null : JIGYO_SEGMENT_NM.trim();
    }

    /**
     * 職種コード
     * @return SHOKUSHU_CD 職種コード
     */
    public String getSHOKUSHU_CD() {
        return SHOKUSHU_CD;
    }

    /**
     * 職種コード
     * @param SHOKUSHU_CD 職種コード
     */
    public void setSHOKUSHU_CD(String SHOKUSHU_CD) {
        this.SHOKUSHU_CD = SHOKUSHU_CD == null ? null : SHOKUSHU_CD.trim();
    }

    /**
     * 職種名称
     * @return SHOKUSHU_NM 職種名称
     */
    public String getSHOKUSHU_NM() {
        return SHOKUSHU_NM;
    }

    /**
     * 職種名称
     * @param SHOKUSHU_NM 職種名称
     */
    public void setSHOKUSHU_NM(String SHOKUSHU_NM) {
        this.SHOKUSHU_NM = SHOKUSHU_NM == null ? null : SHOKUSHU_NM.trim();
    }

    /**
     * 予備項目01
     * @return YOBI_KOMOKU_01 予備項目01
     */
    public String getYOBI_KOMOKU_01() {
        return YOBI_KOMOKU_01;
    }

    /**
     * 予備項目01
     * @param YOBI_KOMOKU_01 予備項目01
     */
    public void setYOBI_KOMOKU_01(String YOBI_KOMOKU_01) {
        this.YOBI_KOMOKU_01 = YOBI_KOMOKU_01 == null ? null : YOBI_KOMOKU_01.trim();
    }

    /**
     * 予備項目02
     * @return YOBI_KOMOKU_02 予備項目02
     */
    public String getYOBI_KOMOKU_02() {
        return YOBI_KOMOKU_02;
    }

    /**
     * 予備項目02
     * @param YOBI_KOMOKU_02 予備項目02
     */
    public void setYOBI_KOMOKU_02(String YOBI_KOMOKU_02) {
        this.YOBI_KOMOKU_02 = YOBI_KOMOKU_02 == null ? null : YOBI_KOMOKU_02.trim();
    }

    /**
     * 予備項目03
     * @return YOBI_KOMOKU_03 予備項目03
     */
    public String getYOBI_KOMOKU_03() {
        return YOBI_KOMOKU_03;
    }

    /**
     * 予備項目03
     * @param YOBI_KOMOKU_03 予備項目03
     */
    public void setYOBI_KOMOKU_03(String YOBI_KOMOKU_03) {
        this.YOBI_KOMOKU_03 = YOBI_KOMOKU_03 == null ? null : YOBI_KOMOKU_03.trim();
    }

    /**
     * 予備項目04
     * @return YOBI_KOMOKU_04 予備項目04
     */
    public String getYOBI_KOMOKU_04() {
        return YOBI_KOMOKU_04;
    }

    /**
     * 予備項目04
     * @param YOBI_KOMOKU_04 予備項目04
     */
    public void setYOBI_KOMOKU_04(String YOBI_KOMOKU_04) {
        this.YOBI_KOMOKU_04 = YOBI_KOMOKU_04 == null ? null : YOBI_KOMOKU_04.trim();
    }

    /**
     * 予備項目05
     * @return YOBI_KOMOKU_05 予備項目05
     */
    public String getYOBI_KOMOKU_05() {
        return YOBI_KOMOKU_05;
    }

    /**
     * 予備項目05
     * @param YOBI_KOMOKU_05 予備項目05
     */
    public void setYOBI_KOMOKU_05(String YOBI_KOMOKU_05) {
        this.YOBI_KOMOKU_05 = YOBI_KOMOKU_05 == null ? null : YOBI_KOMOKU_05.trim();
    }

    /**
     * 予備項目06
     * @return YOBI_KOMOKU_06 予備項目06
     */
    public String getYOBI_KOMOKU_06() {
        return YOBI_KOMOKU_06;
    }

    /**
     * 予備項目06
     * @param YOBI_KOMOKU_06 予備項目06
     */
    public void setYOBI_KOMOKU_06(String YOBI_KOMOKU_06) {
        this.YOBI_KOMOKU_06 = YOBI_KOMOKU_06 == null ? null : YOBI_KOMOKU_06.trim();
    }

    /**
     * 予備項目07
     * @return YOBI_KOMOKU_07 予備項目07
     */
    public String getYOBI_KOMOKU_07() {
        return YOBI_KOMOKU_07;
    }

    /**
     * 予備項目07
     * @param YOBI_KOMOKU_07 予備項目07
     */
    public void setYOBI_KOMOKU_07(String YOBI_KOMOKU_07) {
        this.YOBI_KOMOKU_07 = YOBI_KOMOKU_07 == null ? null : YOBI_KOMOKU_07.trim();
    }

    /**
     * 予備項目08
     * @return YOBI_KOMOKU_08 予備項目08
     */
    public String getYOBI_KOMOKU_08() {
        return YOBI_KOMOKU_08;
    }

    /**
     * 予備項目08
     * @param YOBI_KOMOKU_08 予備項目08
     */
    public void setYOBI_KOMOKU_08(String YOBI_KOMOKU_08) {
        this.YOBI_KOMOKU_08 = YOBI_KOMOKU_08 == null ? null : YOBI_KOMOKU_08.trim();
    }

    /**
     * 予備項目09
     * @return YOBI_KOMOKU_09 予備項目09
     */
    public String getYOBI_KOMOKU_09() {
        return YOBI_KOMOKU_09;
    }

    /**
     * 予備項目09
     * @param YOBI_KOMOKU_09 予備項目09
     */
    public void setYOBI_KOMOKU_09(String YOBI_KOMOKU_09) {
        this.YOBI_KOMOKU_09 = YOBI_KOMOKU_09 == null ? null : YOBI_KOMOKU_09.trim();
    }

    /**
     * 予備項目10
     * @return YOBI_KOMOKU_10 予備項目10
     */
    public String getYOBI_KOMOKU_10() {
        return YOBI_KOMOKU_10;
    }

    /**
     * 予備項目10
     * @param YOBI_KOMOKU_10 予備項目10
     */
    public void setYOBI_KOMOKU_10(String YOBI_KOMOKU_10) {
        this.YOBI_KOMOKU_10 = YOBI_KOMOKU_10 == null ? null : YOBI_KOMOKU_10.trim();
    }

    /**
     * 登録タイムスタンプ
     * @return REGST_TMSTMP 登録タイムスタンプ
     */
    public Date getREGST_TMSTMP() {
        return REGST_TMSTMP;
    }

    /**
     * 登録タイムスタンプ
     * @param REGST_TMSTMP 登録タイムスタンプ
     */
    public void setREGST_TMSTMP(Date REGST_TMSTMP) {
        this.REGST_TMSTMP = REGST_TMSTMP;
    }

    /**
     * 登録者会社コード
     * @return REGSTR_CO_CD 登録者会社コード
     */
    public String getREGSTR_CO_CD() {
        return REGSTR_CO_CD;
    }

    /**
     * 登録者会社コード
     * @param REGSTR_CO_CD 登録者会社コード
     */
    public void setREGSTR_CO_CD(String REGSTR_CO_CD) {
        this.REGSTR_CO_CD = REGSTR_CO_CD == null ? null : REGSTR_CO_CD.trim();
    }

    /**
     * 登録者組織コード
     * @return REGSTR_SOSHIKI_CD 登録者組織コード
     */
    public String getREGSTR_SOSHIKI_CD() {
        return REGSTR_SOSHIKI_CD;
    }

    /**
     * 登録者組織コード
     * @param REGSTR_SOSHIKI_CD 登録者組織コード
     */
    public void setREGSTR_SOSHIKI_CD(String REGSTR_SOSHIKI_CD) {
        this.REGSTR_SOSHIKI_CD = REGSTR_SOSHIKI_CD == null ? null : REGSTR_SOSHIKI_CD.trim();
    }

    /**
     * 登録者社員番号
     * @return REGSTR_EMP_NO 登録者社員番号
     */
    public String getREGSTR_EMP_NO() {
        return REGSTR_EMP_NO;
    }

    /**
     * 登録者社員番号
     * @param REGSTR_EMP_NO 登録者社員番号
     */
    public void setREGSTR_EMP_NO(String REGSTR_EMP_NO) {
        this.REGSTR_EMP_NO = REGSTR_EMP_NO == null ? null : REGSTR_EMP_NO.trim();
    }

    /**
     * 登録画面ＩＤ
     * @return REGST_GAMEN_ID 登録画面ＩＤ
     */
    public String getREGST_GAMEN_ID() {
        return REGST_GAMEN_ID;
    }

    /**
     * 登録画面ＩＤ
     * @param REGST_GAMEN_ID 登録画面ＩＤ
     */
    public void setREGST_GAMEN_ID(String REGST_GAMEN_ID) {
        this.REGST_GAMEN_ID = REGST_GAMEN_ID == null ? null : REGST_GAMEN_ID.trim();
    }

    /**
     * 登録プログラムＩＤ
     * @return REGST_PGM_ID 登録プログラムＩＤ
     */
    public String getREGST_PGM_ID() {
        return REGST_PGM_ID;
    }

    /**
     * 登録プログラムＩＤ
     * @param REGST_PGM_ID 登録プログラムＩＤ
     */
    public void setREGST_PGM_ID(String REGST_PGM_ID) {
        this.REGST_PGM_ID = REGST_PGM_ID == null ? null : REGST_PGM_ID.trim();
    }

    /**
     * 更新タイムスタンプ
     * @return UPD_TMSTMP 更新タイムスタンプ
     */
    public Date getUPD_TMSTMP() {
        return UPD_TMSTMP;
    }

    /**
     * 更新タイムスタンプ
     * @param UPD_TMSTMP 更新タイムスタンプ
     */
    public void setUPD_TMSTMP(Date UPD_TMSTMP) {
        this.UPD_TMSTMP = UPD_TMSTMP;
    }

    /**
     * 更新者会社コード
     * @return UPDTR_CO_CD 更新者会社コード
     */
    public String getUPDTR_CO_CD() {
        return UPDTR_CO_CD;
    }

    /**
     * 更新者会社コード
     * @param UPDTR_CO_CD 更新者会社コード
     */
    public void setUPDTR_CO_CD(String UPDTR_CO_CD) {
        this.UPDTR_CO_CD = UPDTR_CO_CD == null ? null : UPDTR_CO_CD.trim();
    }

    /**
     * 更新者組織コード
     * @return UPDTR_SOSHIKI_CD 更新者組織コード
     */
    public String getUPDTR_SOSHIKI_CD() {
        return UPDTR_SOSHIKI_CD;
    }

    /**
     * 更新者組織コード
     * @param UPDTR_SOSHIKI_CD 更新者組織コード
     */
    public void setUPDTR_SOSHIKI_CD(String UPDTR_SOSHIKI_CD) {
        this.UPDTR_SOSHIKI_CD = UPDTR_SOSHIKI_CD == null ? null : UPDTR_SOSHIKI_CD.trim();
    }

    /**
     * 更新者社員番号
     * @return UPDTR_EMP_NO 更新者社員番号
     */
    public String getUPDTR_EMP_NO() {
        return UPDTR_EMP_NO;
    }

    /**
     * 更新者社員番号
     * @param UPDTR_EMP_NO 更新者社員番号
     */
    public void setUPDTR_EMP_NO(String UPDTR_EMP_NO) {
        this.UPDTR_EMP_NO = UPDTR_EMP_NO == null ? null : UPDTR_EMP_NO.trim();
    }

    /**
     * 更新画面ＩＤ
     * @return UPD_GAMEN_ID 更新画面ＩＤ
     */
    public String getUPD_GAMEN_ID() {
        return UPD_GAMEN_ID;
    }

    /**
     * 更新画面ＩＤ
     * @param UPD_GAMEN_ID 更新画面ＩＤ
     */
    public void setUPD_GAMEN_ID(String UPD_GAMEN_ID) {
        this.UPD_GAMEN_ID = UPD_GAMEN_ID == null ? null : UPD_GAMEN_ID.trim();
    }

    /**
     * 更新プログラムＩＤ
     * @return UPD_PGM_ID 更新プログラムＩＤ
     */
    public String getUPD_PGM_ID() {
        return UPD_PGM_ID;
    }

    /**
     * 更新プログラムＩＤ
     * @param UPD_PGM_ID 更新プログラムＩＤ
     */
    public void setUPD_PGM_ID(String UPD_PGM_ID) {
        this.UPD_PGM_ID = UPD_PGM_ID == null ? null : UPD_PGM_ID.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}