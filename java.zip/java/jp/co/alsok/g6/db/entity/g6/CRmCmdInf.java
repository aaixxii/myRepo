package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CRmCmdInf implements Serializable {
    /**
     * 送信機ID
     */
    private String TRANS_ID;

    /**
     * コマンドシーケンス番号
     */
    private String CMD_SEQ_NUM;

    /**
     * 優先レベル
     */
    private String PRIORITY;

    /**
     * 実行コマンド
     */
    private String EXEC_CMD;

    /**
     * コマンド状態
     */
    private String CMD_STS;

    /**
     * 実行日時
     */
    private Date EXE_TS;

    /**
     * タイムアウト時間
     */
    private String CMD_TIMEOUT_TM;

    /**
     * タイムアウト日時
     */
    private Date CMD_TIMEOUT_TS;

    /**
     * RMDBSVディレクトリ名
     */
    private String RMDB_DIR_NM;

    /**
     * FTPSVディレクトリ名
     */
    private String FTP_DIR_NM;

    /**
     * 業務APディレクトリ名
     */
    private String GYOUMU_DIR_NM;

    /**
     * リトライ回数
     */
    private Integer RETRY_NUM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_RM_CMD_INF
     */
    private static final long serialVersionUID = 1L;

    /**
     * 送信機ID
     * @return TRANS_ID 送信機ID
     */
    public String getTRANS_ID() {
        return TRANS_ID;
    }

    /**
     * 送信機ID
     * @param TRANS_ID 送信機ID
     */
    public void setTRANS_ID(String TRANS_ID) {
        this.TRANS_ID = TRANS_ID == null ? null : TRANS_ID.trim();
    }

    /**
     * コマンドシーケンス番号
     * @return CMD_SEQ_NUM コマンドシーケンス番号
     */
    public String getCMD_SEQ_NUM() {
        return CMD_SEQ_NUM;
    }

    /**
     * コマンドシーケンス番号
     * @param CMD_SEQ_NUM コマンドシーケンス番号
     */
    public void setCMD_SEQ_NUM(String CMD_SEQ_NUM) {
        this.CMD_SEQ_NUM = CMD_SEQ_NUM == null ? null : CMD_SEQ_NUM.trim();
    }

    /**
     * 優先レベル
     * @return PRIORITY 優先レベル
     */
    public String getPRIORITY() {
        return PRIORITY;
    }

    /**
     * 優先レベル
     * @param PRIORITY 優先レベル
     */
    public void setPRIORITY(String PRIORITY) {
        this.PRIORITY = PRIORITY == null ? null : PRIORITY.trim();
    }

    /**
     * 実行コマンド
     * @return EXEC_CMD 実行コマンド
     */
    public String getEXEC_CMD() {
        return EXEC_CMD;
    }

    /**
     * 実行コマンド
     * @param EXEC_CMD 実行コマンド
     */
    public void setEXEC_CMD(String EXEC_CMD) {
        this.EXEC_CMD = EXEC_CMD == null ? null : EXEC_CMD.trim();
    }

    /**
     * コマンド状態
     * @return CMD_STS コマンド状態
     */
    public String getCMD_STS() {
        return CMD_STS;
    }

    /**
     * コマンド状態
     * @param CMD_STS コマンド状態
     */
    public void setCMD_STS(String CMD_STS) {
        this.CMD_STS = CMD_STS == null ? null : CMD_STS.trim();
    }

    /**
     * 実行日時
     * @return EXE_TS 実行日時
     */
    public Date getEXE_TS() {
        return EXE_TS;
    }

    /**
     * 実行日時
     * @param EXE_TS 実行日時
     */
    public void setEXE_TS(Date EXE_TS) {
        this.EXE_TS = EXE_TS;
    }

    /**
     * タイムアウト時間
     * @return CMD_TIMEOUT_TM タイムアウト時間
     */
    public String getCMD_TIMEOUT_TM() {
        return CMD_TIMEOUT_TM;
    }

    /**
     * タイムアウト時間
     * @param CMD_TIMEOUT_TM タイムアウト時間
     */
    public void setCMD_TIMEOUT_TM(String CMD_TIMEOUT_TM) {
        this.CMD_TIMEOUT_TM = CMD_TIMEOUT_TM == null ? null : CMD_TIMEOUT_TM.trim();
    }

    /**
     * タイムアウト日時
     * @return CMD_TIMEOUT_TS タイムアウト日時
     */
    public Date getCMD_TIMEOUT_TS() {
        return CMD_TIMEOUT_TS;
    }

    /**
     * タイムアウト日時
     * @param CMD_TIMEOUT_TS タイムアウト日時
     */
    public void setCMD_TIMEOUT_TS(Date CMD_TIMEOUT_TS) {
        this.CMD_TIMEOUT_TS = CMD_TIMEOUT_TS;
    }

    /**
     * RMDBSVディレクトリ名
     * @return RMDB_DIR_NM RMDBSVディレクトリ名
     */
    public String getRMDB_DIR_NM() {
        return RMDB_DIR_NM;
    }

    /**
     * RMDBSVディレクトリ名
     * @param RMDB_DIR_NM RMDBSVディレクトリ名
     */
    public void setRMDB_DIR_NM(String RMDB_DIR_NM) {
        this.RMDB_DIR_NM = RMDB_DIR_NM == null ? null : RMDB_DIR_NM.trim();
    }

    /**
     * FTPSVディレクトリ名
     * @return FTP_DIR_NM FTPSVディレクトリ名
     */
    public String getFTP_DIR_NM() {
        return FTP_DIR_NM;
    }

    /**
     * FTPSVディレクトリ名
     * @param FTP_DIR_NM FTPSVディレクトリ名
     */
    public void setFTP_DIR_NM(String FTP_DIR_NM) {
        this.FTP_DIR_NM = FTP_DIR_NM == null ? null : FTP_DIR_NM.trim();
    }

    /**
     * 業務APディレクトリ名
     * @return GYOUMU_DIR_NM 業務APディレクトリ名
     */
    public String getGYOUMU_DIR_NM() {
        return GYOUMU_DIR_NM;
    }

    /**
     * 業務APディレクトリ名
     * @param GYOUMU_DIR_NM 業務APディレクトリ名
     */
    public void setGYOUMU_DIR_NM(String GYOUMU_DIR_NM) {
        this.GYOUMU_DIR_NM = GYOUMU_DIR_NM == null ? null : GYOUMU_DIR_NM.trim();
    }

    /**
     * リトライ回数
     * @return RETRY_NUM リトライ回数
     */
    public Integer getRETRY_NUM() {
        return RETRY_NUM;
    }

    /**
     * リトライ回数
     * @param RETRY_NUM リトライ回数
     */
    public void setRETRY_NUM(Integer RETRY_NUM) {
        this.RETRY_NUM = RETRY_NUM;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}