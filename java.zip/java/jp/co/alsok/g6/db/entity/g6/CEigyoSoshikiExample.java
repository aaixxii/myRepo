package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CEigyoSoshikiExample {
    /**
     * C_EIGYO_SOSHIKI
     */
    protected String orderByClause;

    /**
     * C_EIGYO_SOSHIKI
     */
    protected boolean distinct;

    /**
     * C_EIGYO_SOSHIKI
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public CEigyoSoshikiExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * C_EIGYO_SOSHIKI null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andKAISHA_CDIsNull() {
            addCriterion("KAISHA_CD is null");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDIsNotNull() {
            addCriterion("KAISHA_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDEqualTo(String value) {
            addCriterion("KAISHA_CD =", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotEqualTo(String value) {
            addCriterion("KAISHA_CD <>", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDGreaterThan(String value) {
            addCriterion("KAISHA_CD >", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KAISHA_CD >=", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLessThan(String value) {
            addCriterion("KAISHA_CD <", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLessThanOrEqualTo(String value) {
            addCriterion("KAISHA_CD <=", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLike(String value) {
            addCriterion("KAISHA_CD like", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotLike(String value) {
            addCriterion("KAISHA_CD not like", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDIn(List<String> values) {
            addCriterion("KAISHA_CD in", values, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotIn(List<String> values) {
            addCriterion("KAISHA_CD not in", values, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDBetween(String value1, String value2) {
            addCriterion("KAISHA_CD between", value1, value2, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotBetween(String value1, String value2) {
            addCriterion("KAISHA_CD not between", value1, value2, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDIsNull() {
            addCriterion("SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDIsNotNull() {
            addCriterion("SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDEqualTo(String value) {
            addCriterion("SOSHIKI_CD =", value, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDNotEqualTo(String value) {
            addCriterion("SOSHIKI_CD <>", value, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDGreaterThan(String value) {
            addCriterion("SOSHIKI_CD >", value, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SOSHIKI_CD >=", value, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDLessThan(String value) {
            addCriterion("SOSHIKI_CD <", value, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("SOSHIKI_CD <=", value, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDLike(String value) {
            addCriterion("SOSHIKI_CD like", value, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDNotLike(String value) {
            addCriterion("SOSHIKI_CD not like", value, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDIn(List<String> values) {
            addCriterion("SOSHIKI_CD in", values, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDNotIn(List<String> values) {
            addCriterion("SOSHIKI_CD not in", values, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("SOSHIKI_CD between", value1, value2, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("SOSHIKI_CD not between", value1, value2, "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIsNull() {
            addCriterion("TEKIYO_KAISHI_YMD is null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIsNotNull() {
            addCriterion("TEKIYO_KAISHI_YMD is not null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD =", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <>", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDGreaterThan(String value) {
            addCriterion("TEKIYO_KAISHI_YMD >", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDGreaterThanOrEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD >=", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLessThan(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLessThanOrEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <=", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLike(String value) {
            addCriterion("TEKIYO_KAISHI_YMD like", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotLike(String value) {
            addCriterion("TEKIYO_KAISHI_YMD not like", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIn(List<String> values) {
            addCriterion("TEKIYO_KAISHI_YMD in", values, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotIn(List<String> values) {
            addCriterion("TEKIYO_KAISHI_YMD not in", values, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDBetween(String value1, String value2) {
            addCriterion("TEKIYO_KAISHI_YMD between", value1, value2, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotBetween(String value1, String value2) {
            addCriterion("TEKIYO_KAISHI_YMD not between", value1, value2, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIsNull() {
            addCriterion("TEKIYO_SHURYO_YMD is null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIsNotNull() {
            addCriterion("TEKIYO_SHURYO_YMD is not null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD =", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <>", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDGreaterThan(String value) {
            addCriterion("TEKIYO_SHURYO_YMD >", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDGreaterThanOrEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD >=", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLessThan(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLessThanOrEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <=", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLike(String value) {
            addCriterion("TEKIYO_SHURYO_YMD like", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotLike(String value) {
            addCriterion("TEKIYO_SHURYO_YMD not like", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIn(List<String> values) {
            addCriterion("TEKIYO_SHURYO_YMD in", values, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotIn(List<String> values) {
            addCriterion("TEKIYO_SHURYO_YMD not in", values, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDBetween(String value1, String value2) {
            addCriterion("TEKIYO_SHURYO_YMD between", value1, value2, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotBetween(String value1, String value2) {
            addCriterion("TEKIYO_SHURYO_YMD not between", value1, value2, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMIsNull() {
            addCriterion("SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMIsNotNull() {
            addCriterion("SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMEqualTo(String value) {
            addCriterion("SOSHIKI_NM =", value, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMNotEqualTo(String value) {
            addCriterion("SOSHIKI_NM <>", value, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMGreaterThan(String value) {
            addCriterion("SOSHIKI_NM >", value, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SOSHIKI_NM >=", value, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMLessThan(String value) {
            addCriterion("SOSHIKI_NM <", value, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("SOSHIKI_NM <=", value, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMLike(String value) {
            addCriterion("SOSHIKI_NM like", value, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMNotLike(String value) {
            addCriterion("SOSHIKI_NM not like", value, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMIn(List<String> values) {
            addCriterion("SOSHIKI_NM in", values, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMNotIn(List<String> values) {
            addCriterion("SOSHIKI_NM not in", values, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("SOSHIKI_NM between", value1, value2, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("SOSHIKI_NM not between", value1, value2, "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMIsNull() {
            addCriterion("SOSHIKI_RNM is null");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMIsNotNull() {
            addCriterion("SOSHIKI_RNM is not null");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMEqualTo(String value) {
            addCriterion("SOSHIKI_RNM =", value, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMNotEqualTo(String value) {
            addCriterion("SOSHIKI_RNM <>", value, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMGreaterThan(String value) {
            addCriterion("SOSHIKI_RNM >", value, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMGreaterThanOrEqualTo(String value) {
            addCriterion("SOSHIKI_RNM >=", value, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMLessThan(String value) {
            addCriterion("SOSHIKI_RNM <", value, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMLessThanOrEqualTo(String value) {
            addCriterion("SOSHIKI_RNM <=", value, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMLike(String value) {
            addCriterion("SOSHIKI_RNM like", value, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMNotLike(String value) {
            addCriterion("SOSHIKI_RNM not like", value, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMIn(List<String> values) {
            addCriterion("SOSHIKI_RNM in", values, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMNotIn(List<String> values) {
            addCriterion("SOSHIKI_RNM not in", values, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMBetween(String value1, String value2) {
            addCriterion("SOSHIKI_RNM between", value1, value2, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMNotBetween(String value1, String value2) {
            addCriterion("SOSHIKI_RNM not between", value1, value2, "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDIsNull() {
            addCriterion("JOI_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDIsNotNull() {
            addCriterion("JOI_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDEqualTo(String value) {
            addCriterion("JOI_SOSHIKI_CD =", value, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("JOI_SOSHIKI_CD <>", value, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("JOI_SOSHIKI_CD >", value, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JOI_SOSHIKI_CD >=", value, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDLessThan(String value) {
            addCriterion("JOI_SOSHIKI_CD <", value, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("JOI_SOSHIKI_CD <=", value, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDLike(String value) {
            addCriterion("JOI_SOSHIKI_CD like", value, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDNotLike(String value) {
            addCriterion("JOI_SOSHIKI_CD not like", value, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDIn(List<String> values) {
            addCriterion("JOI_SOSHIKI_CD in", values, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("JOI_SOSHIKI_CD not in", values, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("JOI_SOSHIKI_CD between", value1, value2, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("JOI_SOSHIKI_CD not between", value1, value2, "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDIsNull() {
            addCriterion("SHISHABU_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDIsNotNull() {
            addCriterion("SHISHABU_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDEqualTo(String value) {
            addCriterion("SHISHABU_SOSHIKI_CD =", value, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("SHISHABU_SOSHIKI_CD <>", value, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("SHISHABU_SOSHIKI_CD >", value, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SHISHABU_SOSHIKI_CD >=", value, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDLessThan(String value) {
            addCriterion("SHISHABU_SOSHIKI_CD <", value, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("SHISHABU_SOSHIKI_CD <=", value, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDLike(String value) {
            addCriterion("SHISHABU_SOSHIKI_CD like", value, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDNotLike(String value) {
            addCriterion("SHISHABU_SOSHIKI_CD not like", value, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDIn(List<String> values) {
            addCriterion("SHISHABU_SOSHIKI_CD in", values, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("SHISHABU_SOSHIKI_CD not in", values, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("SHISHABU_SOSHIKI_CD between", value1, value2, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("SHISHABU_SOSHIKI_CD not between", value1, value2, "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGIsNull() {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG is null");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGIsNotNull() {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGEqualTo(String value) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG =", value, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGNotEqualTo(String value) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG <>", value, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGGreaterThan(String value) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG >", value, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG >=", value, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGLessThan(String value) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG <", value, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGLessThanOrEqualTo(String value) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG <=", value, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGLike(String value) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG like", value, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGNotLike(String value) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG not like", value, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGIn(List<String> values) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG in", values, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGNotIn(List<String> values) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG not in", values, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGBetween(String value1, String value2) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG between", value1, value2, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGNotBetween(String value1, String value2) {
            addCriterion("KTH_HIFMT_TIS_HNS_BMN_SSK_FLG not between", value1, value2, "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGIsNull() {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG is null");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGIsNotNull() {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGEqualTo(String value) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG =", value, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGNotEqualTo(String value) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG <>", value, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGGreaterThan(String value) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG >", value, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG >=", value, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGLessThan(String value) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG <", value, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGLessThanOrEqualTo(String value) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG <=", value, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGLike(String value) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG like", value, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGNotLike(String value) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG not like", value, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGIn(List<String> values) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG in", values, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGNotIn(List<String> values) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG not in", values, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGBetween(String value1, String value2) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG between", value1, value2, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGNotBetween(String value1, String value2) {
            addCriterion("KTH_HIFSK_TIS_ZNS_SEGMENT_FLG not between", value1, value2, "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNIsNull() {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN is null");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNIsNotNull() {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNEqualTo(String value) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN =", value, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNNotEqualTo(String value) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN <>", value, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNGreaterThan(String value) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN >", value, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN >=", value, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNLessThan(String value) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN <", value, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNLessThanOrEqualTo(String value) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN <=", value, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNLike(String value) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN like", value, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNNotLike(String value) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN not like", value, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNIn(List<String> values) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN in", values, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNNotIn(List<String> values) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN not in", values, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNBetween(String value1, String value2) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN between", value1, value2, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNNotBetween(String value1, String value2) {
            addCriterion("KNKY_KIHTS_BMN_SSHK_KBN not between", value1, value2, "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDIsNull() {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDIsNotNull() {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDEqualTo(String value) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD =", value, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD <>", value, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD >", value, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD >=", value, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDLessThan(String value) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD <", value, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD <=", value, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDLike(String value) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD like", value, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDNotLike(String value) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD not like", value, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDIn(List<String> values) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD in", values, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD not in", values, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD between", value1, value2, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("HIYO_FUTAN_BUMON_SOSHIKI_CD not between", value1, value2, "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDIsNull() {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD is null");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDIsNotNull() {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDEqualTo(String value) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD =", value, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDNotEqualTo(String value) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD <>", value, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDGreaterThan(String value) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD >", value, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD >=", value, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDLessThan(String value) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD <", value, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDLessThanOrEqualTo(String value) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD <=", value, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDLike(String value) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD like", value, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDNotLike(String value) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD not like", value, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDIn(List<String> values) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD in", values, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDNotIn(List<String> values) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD not in", values, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDBetween(String value1, String value2) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD between", value1, value2, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDNotBetween(String value1, String value2) {
            addCriterion("KIH_ICHJ_SHNN_BMN_SSHK_CD not between", value1, value2, "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDIsNull() {
            addCriterion("SHISHA_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDIsNotNull() {
            addCriterion("SHISHA_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDEqualTo(String value) {
            addCriterion("SHISHA_SOSHIKI_CD =", value, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("SHISHA_SOSHIKI_CD <>", value, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("SHISHA_SOSHIKI_CD >", value, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SHISHA_SOSHIKI_CD >=", value, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDLessThan(String value) {
            addCriterion("SHISHA_SOSHIKI_CD <", value, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("SHISHA_SOSHIKI_CD <=", value, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDLike(String value) {
            addCriterion("SHISHA_SOSHIKI_CD like", value, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDNotLike(String value) {
            addCriterion("SHISHA_SOSHIKI_CD not like", value, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDIn(List<String> values) {
            addCriterion("SHISHA_SOSHIKI_CD in", values, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("SHISHA_SOSHIKI_CD not in", values, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("SHISHA_SOSHIKI_CD between", value1, value2, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("SHISHA_SOSHIKI_CD not between", value1, value2, "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDIsNull() {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDIsNotNull() {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDEqualTo(String value) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD =", value, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD <>", value, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD >", value, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD >=", value, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDLessThan(String value) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD <", value, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD <=", value, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDLike(String value) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD like", value, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDNotLike(String value) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD not like", value, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDIn(List<String> values) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD in", values, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD not in", values, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD between", value1, value2, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("CHIIKI_HOMBU_SOSHIKI_CD not between", value1, value2, "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGIsNull() {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGIsNotNull() {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGEqualTo(String value) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG =", value, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGNotEqualTo(String value) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG <>", value, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGGreaterThan(String value) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG >", value, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG >=", value, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGLessThan(String value) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG <", value, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG <=", value, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGLike(String value) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG like", value, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGNotLike(String value) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG not like", value, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGIn(List<String> values) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG in", values, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGNotIn(List<String> values) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG not in", values, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGBetween(String value1, String value2) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG between", value1, value2, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGNotBetween(String value1, String value2) {
            addCriterion("JIGYO_HOMBU_SANSHOKA_FLG not between", value1, value2, "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGIsNull() {
            addCriterion("ZENSHA_SANSHOKA_FLG is null");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGIsNotNull() {
            addCriterion("ZENSHA_SANSHOKA_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGEqualTo(String value) {
            addCriterion("ZENSHA_SANSHOKA_FLG =", value, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGNotEqualTo(String value) {
            addCriterion("ZENSHA_SANSHOKA_FLG <>", value, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGGreaterThan(String value) {
            addCriterion("ZENSHA_SANSHOKA_FLG >", value, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("ZENSHA_SANSHOKA_FLG >=", value, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGLessThan(String value) {
            addCriterion("ZENSHA_SANSHOKA_FLG <", value, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGLessThanOrEqualTo(String value) {
            addCriterion("ZENSHA_SANSHOKA_FLG <=", value, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGLike(String value) {
            addCriterion("ZENSHA_SANSHOKA_FLG like", value, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGNotLike(String value) {
            addCriterion("ZENSHA_SANSHOKA_FLG not like", value, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGIn(List<String> values) {
            addCriterion("ZENSHA_SANSHOKA_FLG in", values, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGNotIn(List<String> values) {
            addCriterion("ZENSHA_SANSHOKA_FLG not in", values, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGBetween(String value1, String value2) {
            addCriterion("ZENSHA_SANSHOKA_FLG between", value1, value2, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGNotBetween(String value1, String value2) {
            addCriterion("ZENSHA_SANSHOKA_FLG not between", value1, value2, "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDIsNull() {
            addCriterion("SHISHABU_CD is null");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDIsNotNull() {
            addCriterion("SHISHABU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDEqualTo(String value) {
            addCriterion("SHISHABU_CD =", value, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDNotEqualTo(String value) {
            addCriterion("SHISHABU_CD <>", value, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDGreaterThan(String value) {
            addCriterion("SHISHABU_CD >", value, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SHISHABU_CD >=", value, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDLessThan(String value) {
            addCriterion("SHISHABU_CD <", value, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDLessThanOrEqualTo(String value) {
            addCriterion("SHISHABU_CD <=", value, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDLike(String value) {
            addCriterion("SHISHABU_CD like", value, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDNotLike(String value) {
            addCriterion("SHISHABU_CD not like", value, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDIn(List<String> values) {
            addCriterion("SHISHABU_CD in", values, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDNotIn(List<String> values) {
            addCriterion("SHISHABU_CD not in", values, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDBetween(String value1, String value2) {
            addCriterion("SHISHABU_CD between", value1, value2, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDNotBetween(String value1, String value2) {
            addCriterion("SHISHABU_CD not between", value1, value2, "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOIsNull() {
            addCriterion("SOSHIKI_RANK_NO is null");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOIsNotNull() {
            addCriterion("SOSHIKI_RANK_NO is not null");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOEqualTo(Integer value) {
            addCriterion("SOSHIKI_RANK_NO =", value, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NONotEqualTo(Integer value) {
            addCriterion("SOSHIKI_RANK_NO <>", value, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOGreaterThan(Integer value) {
            addCriterion("SOSHIKI_RANK_NO >", value, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOGreaterThanOrEqualTo(Integer value) {
            addCriterion("SOSHIKI_RANK_NO >=", value, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOLessThan(Integer value) {
            addCriterion("SOSHIKI_RANK_NO <", value, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOLessThanOrEqualTo(Integer value) {
            addCriterion("SOSHIKI_RANK_NO <=", value, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOIn(List<Integer> values) {
            addCriterion("SOSHIKI_RANK_NO in", values, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NONotIn(List<Integer> values) {
            addCriterion("SOSHIKI_RANK_NO not in", values, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NOBetween(Integer value1, Integer value2) {
            addCriterion("SOSHIKI_RANK_NO between", value1, value2, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RANK_NONotBetween(Integer value1, Integer value2) {
            addCriterion("SOSHIKI_RANK_NO not between", value1, value2, "SOSHIKI_RANK_NO");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDIsNull() {
            addCriterion("RANK_01_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_01_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_01_SOSHIKI_CD =", value, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_01_SOSHIKI_CD <>", value, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_01_SOSHIKI_CD >", value, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_01_SOSHIKI_CD >=", value, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_01_SOSHIKI_CD <", value, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_01_SOSHIKI_CD <=", value, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_01_SOSHIKI_CD like", value, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_01_SOSHIKI_CD not like", value, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_01_SOSHIKI_CD in", values, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_01_SOSHIKI_CD not in", values, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_01_SOSHIKI_CD between", value1, value2, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_01_SOSHIKI_CD not between", value1, value2, "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDIsNull() {
            addCriterion("RANK_02_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_02_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_02_SOSHIKI_CD =", value, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_02_SOSHIKI_CD <>", value, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_02_SOSHIKI_CD >", value, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_02_SOSHIKI_CD >=", value, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_02_SOSHIKI_CD <", value, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_02_SOSHIKI_CD <=", value, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_02_SOSHIKI_CD like", value, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_02_SOSHIKI_CD not like", value, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_02_SOSHIKI_CD in", values, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_02_SOSHIKI_CD not in", values, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_02_SOSHIKI_CD between", value1, value2, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_02_SOSHIKI_CD not between", value1, value2, "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDIsNull() {
            addCriterion("RANK_03_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_03_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_03_SOSHIKI_CD =", value, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_03_SOSHIKI_CD <>", value, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_03_SOSHIKI_CD >", value, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_03_SOSHIKI_CD >=", value, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_03_SOSHIKI_CD <", value, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_03_SOSHIKI_CD <=", value, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_03_SOSHIKI_CD like", value, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_03_SOSHIKI_CD not like", value, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_03_SOSHIKI_CD in", values, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_03_SOSHIKI_CD not in", values, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_03_SOSHIKI_CD between", value1, value2, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_03_SOSHIKI_CD not between", value1, value2, "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDIsNull() {
            addCriterion("RANK_04_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_04_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_04_SOSHIKI_CD =", value, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_04_SOSHIKI_CD <>", value, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_04_SOSHIKI_CD >", value, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_04_SOSHIKI_CD >=", value, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_04_SOSHIKI_CD <", value, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_04_SOSHIKI_CD <=", value, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_04_SOSHIKI_CD like", value, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_04_SOSHIKI_CD not like", value, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_04_SOSHIKI_CD in", values, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_04_SOSHIKI_CD not in", values, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_04_SOSHIKI_CD between", value1, value2, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_04_SOSHIKI_CD not between", value1, value2, "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDIsNull() {
            addCriterion("RANK_05_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_05_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_05_SOSHIKI_CD =", value, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_05_SOSHIKI_CD <>", value, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_05_SOSHIKI_CD >", value, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_05_SOSHIKI_CD >=", value, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_05_SOSHIKI_CD <", value, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_05_SOSHIKI_CD <=", value, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_05_SOSHIKI_CD like", value, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_05_SOSHIKI_CD not like", value, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_05_SOSHIKI_CD in", values, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_05_SOSHIKI_CD not in", values, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_05_SOSHIKI_CD between", value1, value2, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_05_SOSHIKI_CD not between", value1, value2, "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDIsNull() {
            addCriterion("RANK_06_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_06_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_06_SOSHIKI_CD =", value, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_06_SOSHIKI_CD <>", value, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_06_SOSHIKI_CD >", value, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_06_SOSHIKI_CD >=", value, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_06_SOSHIKI_CD <", value, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_06_SOSHIKI_CD <=", value, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_06_SOSHIKI_CD like", value, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_06_SOSHIKI_CD not like", value, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_06_SOSHIKI_CD in", values, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_06_SOSHIKI_CD not in", values, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_06_SOSHIKI_CD between", value1, value2, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_06_SOSHIKI_CD not between", value1, value2, "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDIsNull() {
            addCriterion("RANK_07_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_07_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_07_SOSHIKI_CD =", value, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_07_SOSHIKI_CD <>", value, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_07_SOSHIKI_CD >", value, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_07_SOSHIKI_CD >=", value, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_07_SOSHIKI_CD <", value, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_07_SOSHIKI_CD <=", value, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_07_SOSHIKI_CD like", value, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_07_SOSHIKI_CD not like", value, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_07_SOSHIKI_CD in", values, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_07_SOSHIKI_CD not in", values, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_07_SOSHIKI_CD between", value1, value2, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_07_SOSHIKI_CD not between", value1, value2, "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDIsNull() {
            addCriterion("RANK_08_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_08_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_08_SOSHIKI_CD =", value, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_08_SOSHIKI_CD <>", value, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_08_SOSHIKI_CD >", value, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_08_SOSHIKI_CD >=", value, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_08_SOSHIKI_CD <", value, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_08_SOSHIKI_CD <=", value, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_08_SOSHIKI_CD like", value, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_08_SOSHIKI_CD not like", value, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_08_SOSHIKI_CD in", values, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_08_SOSHIKI_CD not in", values, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_08_SOSHIKI_CD between", value1, value2, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_08_SOSHIKI_CD not between", value1, value2, "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDIsNull() {
            addCriterion("RANK_09_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_09_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_09_SOSHIKI_CD =", value, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_09_SOSHIKI_CD <>", value, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_09_SOSHIKI_CD >", value, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_09_SOSHIKI_CD >=", value, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_09_SOSHIKI_CD <", value, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_09_SOSHIKI_CD <=", value, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_09_SOSHIKI_CD like", value, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_09_SOSHIKI_CD not like", value, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_09_SOSHIKI_CD in", values, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_09_SOSHIKI_CD not in", values, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_09_SOSHIKI_CD between", value1, value2, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_09_SOSHIKI_CD not between", value1, value2, "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDIsNull() {
            addCriterion("RANK_10_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_10_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_10_SOSHIKI_CD =", value, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_10_SOSHIKI_CD <>", value, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_10_SOSHIKI_CD >", value, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_10_SOSHIKI_CD >=", value, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_10_SOSHIKI_CD <", value, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_10_SOSHIKI_CD <=", value, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_10_SOSHIKI_CD like", value, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_10_SOSHIKI_CD not like", value, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_10_SOSHIKI_CD in", values, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_10_SOSHIKI_CD not in", values, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_10_SOSHIKI_CD between", value1, value2, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_10_SOSHIKI_CD not between", value1, value2, "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDIsNull() {
            addCriterion("RANK_11_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_11_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_11_SOSHIKI_CD =", value, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_11_SOSHIKI_CD <>", value, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_11_SOSHIKI_CD >", value, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_11_SOSHIKI_CD >=", value, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_11_SOSHIKI_CD <", value, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_11_SOSHIKI_CD <=", value, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_11_SOSHIKI_CD like", value, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_11_SOSHIKI_CD not like", value, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_11_SOSHIKI_CD in", values, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_11_SOSHIKI_CD not in", values, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_11_SOSHIKI_CD between", value1, value2, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_11_SOSHIKI_CD not between", value1, value2, "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDIsNull() {
            addCriterion("RANK_12_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_12_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_12_SOSHIKI_CD =", value, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_12_SOSHIKI_CD <>", value, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_12_SOSHIKI_CD >", value, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_12_SOSHIKI_CD >=", value, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_12_SOSHIKI_CD <", value, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_12_SOSHIKI_CD <=", value, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_12_SOSHIKI_CD like", value, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_12_SOSHIKI_CD not like", value, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_12_SOSHIKI_CD in", values, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_12_SOSHIKI_CD not in", values, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_12_SOSHIKI_CD between", value1, value2, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_12_SOSHIKI_CD not between", value1, value2, "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDIsNull() {
            addCriterion("RANK_13_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_13_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_13_SOSHIKI_CD =", value, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_13_SOSHIKI_CD <>", value, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_13_SOSHIKI_CD >", value, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_13_SOSHIKI_CD >=", value, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_13_SOSHIKI_CD <", value, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_13_SOSHIKI_CD <=", value, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_13_SOSHIKI_CD like", value, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_13_SOSHIKI_CD not like", value, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_13_SOSHIKI_CD in", values, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_13_SOSHIKI_CD not in", values, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_13_SOSHIKI_CD between", value1, value2, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_13_SOSHIKI_CD not between", value1, value2, "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDIsNull() {
            addCriterion("RANK_14_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_14_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_14_SOSHIKI_CD =", value, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_14_SOSHIKI_CD <>", value, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_14_SOSHIKI_CD >", value, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_14_SOSHIKI_CD >=", value, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_14_SOSHIKI_CD <", value, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_14_SOSHIKI_CD <=", value, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_14_SOSHIKI_CD like", value, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_14_SOSHIKI_CD not like", value, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_14_SOSHIKI_CD in", values, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_14_SOSHIKI_CD not in", values, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_14_SOSHIKI_CD between", value1, value2, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_14_SOSHIKI_CD not between", value1, value2, "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDIsNull() {
            addCriterion("RANK_15_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_15_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_15_SOSHIKI_CD =", value, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_15_SOSHIKI_CD <>", value, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_15_SOSHIKI_CD >", value, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_15_SOSHIKI_CD >=", value, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_15_SOSHIKI_CD <", value, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_15_SOSHIKI_CD <=", value, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_15_SOSHIKI_CD like", value, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_15_SOSHIKI_CD not like", value, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_15_SOSHIKI_CD in", values, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_15_SOSHIKI_CD not in", values, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_15_SOSHIKI_CD between", value1, value2, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_15_SOSHIKI_CD not between", value1, value2, "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDIsNull() {
            addCriterion("RANK_16_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_16_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_16_SOSHIKI_CD =", value, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_16_SOSHIKI_CD <>", value, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_16_SOSHIKI_CD >", value, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_16_SOSHIKI_CD >=", value, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_16_SOSHIKI_CD <", value, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_16_SOSHIKI_CD <=", value, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_16_SOSHIKI_CD like", value, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_16_SOSHIKI_CD not like", value, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_16_SOSHIKI_CD in", values, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_16_SOSHIKI_CD not in", values, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_16_SOSHIKI_CD between", value1, value2, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_16_SOSHIKI_CD not between", value1, value2, "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDIsNull() {
            addCriterion("RANK_17_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_17_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_17_SOSHIKI_CD =", value, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_17_SOSHIKI_CD <>", value, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_17_SOSHIKI_CD >", value, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_17_SOSHIKI_CD >=", value, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_17_SOSHIKI_CD <", value, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_17_SOSHIKI_CD <=", value, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_17_SOSHIKI_CD like", value, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_17_SOSHIKI_CD not like", value, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_17_SOSHIKI_CD in", values, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_17_SOSHIKI_CD not in", values, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_17_SOSHIKI_CD between", value1, value2, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_17_SOSHIKI_CD not between", value1, value2, "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDIsNull() {
            addCriterion("RANK_18_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_18_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_18_SOSHIKI_CD =", value, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_18_SOSHIKI_CD <>", value, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_18_SOSHIKI_CD >", value, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_18_SOSHIKI_CD >=", value, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_18_SOSHIKI_CD <", value, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_18_SOSHIKI_CD <=", value, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_18_SOSHIKI_CD like", value, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_18_SOSHIKI_CD not like", value, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_18_SOSHIKI_CD in", values, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_18_SOSHIKI_CD not in", values, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_18_SOSHIKI_CD between", value1, value2, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_18_SOSHIKI_CD not between", value1, value2, "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDIsNull() {
            addCriterion("RANK_19_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_19_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_19_SOSHIKI_CD =", value, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_19_SOSHIKI_CD <>", value, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_19_SOSHIKI_CD >", value, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_19_SOSHIKI_CD >=", value, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_19_SOSHIKI_CD <", value, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_19_SOSHIKI_CD <=", value, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_19_SOSHIKI_CD like", value, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_19_SOSHIKI_CD not like", value, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_19_SOSHIKI_CD in", values, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_19_SOSHIKI_CD not in", values, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_19_SOSHIKI_CD between", value1, value2, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_19_SOSHIKI_CD not between", value1, value2, "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDIsNull() {
            addCriterion("RANK_20_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDIsNotNull() {
            addCriterion("RANK_20_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDEqualTo(String value) {
            addCriterion("RANK_20_SOSHIKI_CD =", value, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("RANK_20_SOSHIKI_CD <>", value, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("RANK_20_SOSHIKI_CD >", value, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_20_SOSHIKI_CD >=", value, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDLessThan(String value) {
            addCriterion("RANK_20_SOSHIKI_CD <", value, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("RANK_20_SOSHIKI_CD <=", value, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDLike(String value) {
            addCriterion("RANK_20_SOSHIKI_CD like", value, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDNotLike(String value) {
            addCriterion("RANK_20_SOSHIKI_CD not like", value, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDIn(List<String> values) {
            addCriterion("RANK_20_SOSHIKI_CD in", values, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("RANK_20_SOSHIKI_CD not in", values, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("RANK_20_SOSHIKI_CD between", value1, value2, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("RANK_20_SOSHIKI_CD not between", value1, value2, "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMIsNull() {
            addCriterion("RANK_01_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_01_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_01_SOSHIKI_NM =", value, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_01_SOSHIKI_NM <>", value, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_01_SOSHIKI_NM >", value, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_01_SOSHIKI_NM >=", value, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_01_SOSHIKI_NM <", value, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_01_SOSHIKI_NM <=", value, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_01_SOSHIKI_NM like", value, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_01_SOSHIKI_NM not like", value, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_01_SOSHIKI_NM in", values, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_01_SOSHIKI_NM not in", values, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_01_SOSHIKI_NM between", value1, value2, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_01_SOSHIKI_NM not between", value1, value2, "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMIsNull() {
            addCriterion("RANK_02_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_02_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_02_SOSHIKI_NM =", value, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_02_SOSHIKI_NM <>", value, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_02_SOSHIKI_NM >", value, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_02_SOSHIKI_NM >=", value, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_02_SOSHIKI_NM <", value, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_02_SOSHIKI_NM <=", value, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_02_SOSHIKI_NM like", value, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_02_SOSHIKI_NM not like", value, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_02_SOSHIKI_NM in", values, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_02_SOSHIKI_NM not in", values, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_02_SOSHIKI_NM between", value1, value2, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_02_SOSHIKI_NM not between", value1, value2, "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMIsNull() {
            addCriterion("RANK_03_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_03_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_03_SOSHIKI_NM =", value, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_03_SOSHIKI_NM <>", value, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_03_SOSHIKI_NM >", value, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_03_SOSHIKI_NM >=", value, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_03_SOSHIKI_NM <", value, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_03_SOSHIKI_NM <=", value, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_03_SOSHIKI_NM like", value, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_03_SOSHIKI_NM not like", value, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_03_SOSHIKI_NM in", values, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_03_SOSHIKI_NM not in", values, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_03_SOSHIKI_NM between", value1, value2, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_03_SOSHIKI_NM not between", value1, value2, "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMIsNull() {
            addCriterion("RANK_04_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_04_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_04_SOSHIKI_NM =", value, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_04_SOSHIKI_NM <>", value, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_04_SOSHIKI_NM >", value, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_04_SOSHIKI_NM >=", value, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_04_SOSHIKI_NM <", value, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_04_SOSHIKI_NM <=", value, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_04_SOSHIKI_NM like", value, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_04_SOSHIKI_NM not like", value, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_04_SOSHIKI_NM in", values, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_04_SOSHIKI_NM not in", values, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_04_SOSHIKI_NM between", value1, value2, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_04_SOSHIKI_NM not between", value1, value2, "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMIsNull() {
            addCriterion("RANK_05_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_05_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_05_SOSHIKI_NM =", value, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_05_SOSHIKI_NM <>", value, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_05_SOSHIKI_NM >", value, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_05_SOSHIKI_NM >=", value, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_05_SOSHIKI_NM <", value, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_05_SOSHIKI_NM <=", value, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_05_SOSHIKI_NM like", value, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_05_SOSHIKI_NM not like", value, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_05_SOSHIKI_NM in", values, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_05_SOSHIKI_NM not in", values, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_05_SOSHIKI_NM between", value1, value2, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_05_SOSHIKI_NM not between", value1, value2, "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMIsNull() {
            addCriterion("RANK_06_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_06_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_06_SOSHIKI_NM =", value, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_06_SOSHIKI_NM <>", value, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_06_SOSHIKI_NM >", value, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_06_SOSHIKI_NM >=", value, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_06_SOSHIKI_NM <", value, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_06_SOSHIKI_NM <=", value, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_06_SOSHIKI_NM like", value, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_06_SOSHIKI_NM not like", value, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_06_SOSHIKI_NM in", values, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_06_SOSHIKI_NM not in", values, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_06_SOSHIKI_NM between", value1, value2, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_06_SOSHIKI_NM not between", value1, value2, "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMIsNull() {
            addCriterion("RANK_07_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_07_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_07_SOSHIKI_NM =", value, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_07_SOSHIKI_NM <>", value, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_07_SOSHIKI_NM >", value, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_07_SOSHIKI_NM >=", value, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_07_SOSHIKI_NM <", value, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_07_SOSHIKI_NM <=", value, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_07_SOSHIKI_NM like", value, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_07_SOSHIKI_NM not like", value, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_07_SOSHIKI_NM in", values, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_07_SOSHIKI_NM not in", values, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_07_SOSHIKI_NM between", value1, value2, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_07_SOSHIKI_NM not between", value1, value2, "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMIsNull() {
            addCriterion("RANK_08_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_08_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_08_SOSHIKI_NM =", value, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_08_SOSHIKI_NM <>", value, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_08_SOSHIKI_NM >", value, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_08_SOSHIKI_NM >=", value, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_08_SOSHIKI_NM <", value, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_08_SOSHIKI_NM <=", value, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_08_SOSHIKI_NM like", value, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_08_SOSHIKI_NM not like", value, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_08_SOSHIKI_NM in", values, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_08_SOSHIKI_NM not in", values, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_08_SOSHIKI_NM between", value1, value2, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_08_SOSHIKI_NM not between", value1, value2, "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMIsNull() {
            addCriterion("RANK_09_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_09_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_09_SOSHIKI_NM =", value, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_09_SOSHIKI_NM <>", value, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_09_SOSHIKI_NM >", value, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_09_SOSHIKI_NM >=", value, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_09_SOSHIKI_NM <", value, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_09_SOSHIKI_NM <=", value, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_09_SOSHIKI_NM like", value, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_09_SOSHIKI_NM not like", value, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_09_SOSHIKI_NM in", values, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_09_SOSHIKI_NM not in", values, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_09_SOSHIKI_NM between", value1, value2, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_09_SOSHIKI_NM not between", value1, value2, "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMIsNull() {
            addCriterion("RANK_10_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_10_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_10_SOSHIKI_NM =", value, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_10_SOSHIKI_NM <>", value, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_10_SOSHIKI_NM >", value, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_10_SOSHIKI_NM >=", value, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_10_SOSHIKI_NM <", value, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_10_SOSHIKI_NM <=", value, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_10_SOSHIKI_NM like", value, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_10_SOSHIKI_NM not like", value, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_10_SOSHIKI_NM in", values, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_10_SOSHIKI_NM not in", values, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_10_SOSHIKI_NM between", value1, value2, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_10_SOSHIKI_NM not between", value1, value2, "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMIsNull() {
            addCriterion("RANK_11_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_11_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_11_SOSHIKI_NM =", value, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_11_SOSHIKI_NM <>", value, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_11_SOSHIKI_NM >", value, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_11_SOSHIKI_NM >=", value, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_11_SOSHIKI_NM <", value, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_11_SOSHIKI_NM <=", value, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_11_SOSHIKI_NM like", value, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_11_SOSHIKI_NM not like", value, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_11_SOSHIKI_NM in", values, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_11_SOSHIKI_NM not in", values, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_11_SOSHIKI_NM between", value1, value2, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_11_SOSHIKI_NM not between", value1, value2, "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMIsNull() {
            addCriterion("RANK_12_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_12_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_12_SOSHIKI_NM =", value, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_12_SOSHIKI_NM <>", value, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_12_SOSHIKI_NM >", value, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_12_SOSHIKI_NM >=", value, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_12_SOSHIKI_NM <", value, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_12_SOSHIKI_NM <=", value, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_12_SOSHIKI_NM like", value, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_12_SOSHIKI_NM not like", value, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_12_SOSHIKI_NM in", values, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_12_SOSHIKI_NM not in", values, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_12_SOSHIKI_NM between", value1, value2, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_12_SOSHIKI_NM not between", value1, value2, "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMIsNull() {
            addCriterion("RANK_13_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_13_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_13_SOSHIKI_NM =", value, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_13_SOSHIKI_NM <>", value, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_13_SOSHIKI_NM >", value, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_13_SOSHIKI_NM >=", value, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_13_SOSHIKI_NM <", value, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_13_SOSHIKI_NM <=", value, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_13_SOSHIKI_NM like", value, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_13_SOSHIKI_NM not like", value, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_13_SOSHIKI_NM in", values, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_13_SOSHIKI_NM not in", values, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_13_SOSHIKI_NM between", value1, value2, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_13_SOSHIKI_NM not between", value1, value2, "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMIsNull() {
            addCriterion("RANK_14_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_14_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_14_SOSHIKI_NM =", value, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_14_SOSHIKI_NM <>", value, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_14_SOSHIKI_NM >", value, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_14_SOSHIKI_NM >=", value, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_14_SOSHIKI_NM <", value, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_14_SOSHIKI_NM <=", value, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_14_SOSHIKI_NM like", value, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_14_SOSHIKI_NM not like", value, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_14_SOSHIKI_NM in", values, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_14_SOSHIKI_NM not in", values, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_14_SOSHIKI_NM between", value1, value2, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_14_SOSHIKI_NM not between", value1, value2, "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMIsNull() {
            addCriterion("RANK_15_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_15_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_15_SOSHIKI_NM =", value, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_15_SOSHIKI_NM <>", value, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_15_SOSHIKI_NM >", value, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_15_SOSHIKI_NM >=", value, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_15_SOSHIKI_NM <", value, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_15_SOSHIKI_NM <=", value, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_15_SOSHIKI_NM like", value, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_15_SOSHIKI_NM not like", value, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_15_SOSHIKI_NM in", values, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_15_SOSHIKI_NM not in", values, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_15_SOSHIKI_NM between", value1, value2, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_15_SOSHIKI_NM not between", value1, value2, "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMIsNull() {
            addCriterion("RANK_16_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_16_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_16_SOSHIKI_NM =", value, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_16_SOSHIKI_NM <>", value, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_16_SOSHIKI_NM >", value, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_16_SOSHIKI_NM >=", value, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_16_SOSHIKI_NM <", value, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_16_SOSHIKI_NM <=", value, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_16_SOSHIKI_NM like", value, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_16_SOSHIKI_NM not like", value, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_16_SOSHIKI_NM in", values, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_16_SOSHIKI_NM not in", values, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_16_SOSHIKI_NM between", value1, value2, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_16_SOSHIKI_NM not between", value1, value2, "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMIsNull() {
            addCriterion("RANK_17_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_17_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_17_SOSHIKI_NM =", value, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_17_SOSHIKI_NM <>", value, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_17_SOSHIKI_NM >", value, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_17_SOSHIKI_NM >=", value, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_17_SOSHIKI_NM <", value, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_17_SOSHIKI_NM <=", value, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_17_SOSHIKI_NM like", value, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_17_SOSHIKI_NM not like", value, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_17_SOSHIKI_NM in", values, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_17_SOSHIKI_NM not in", values, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_17_SOSHIKI_NM between", value1, value2, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_17_SOSHIKI_NM not between", value1, value2, "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMIsNull() {
            addCriterion("RANK_18_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_18_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_18_SOSHIKI_NM =", value, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_18_SOSHIKI_NM <>", value, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_18_SOSHIKI_NM >", value, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_18_SOSHIKI_NM >=", value, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_18_SOSHIKI_NM <", value, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_18_SOSHIKI_NM <=", value, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_18_SOSHIKI_NM like", value, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_18_SOSHIKI_NM not like", value, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_18_SOSHIKI_NM in", values, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_18_SOSHIKI_NM not in", values, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_18_SOSHIKI_NM between", value1, value2, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_18_SOSHIKI_NM not between", value1, value2, "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMIsNull() {
            addCriterion("RANK_19_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_19_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_19_SOSHIKI_NM =", value, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_19_SOSHIKI_NM <>", value, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_19_SOSHIKI_NM >", value, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_19_SOSHIKI_NM >=", value, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_19_SOSHIKI_NM <", value, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_19_SOSHIKI_NM <=", value, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_19_SOSHIKI_NM like", value, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_19_SOSHIKI_NM not like", value, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_19_SOSHIKI_NM in", values, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_19_SOSHIKI_NM not in", values, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_19_SOSHIKI_NM between", value1, value2, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_19_SOSHIKI_NM not between", value1, value2, "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMIsNull() {
            addCriterion("RANK_20_SOSHIKI_NM is null");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMIsNotNull() {
            addCriterion("RANK_20_SOSHIKI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMEqualTo(String value) {
            addCriterion("RANK_20_SOSHIKI_NM =", value, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMNotEqualTo(String value) {
            addCriterion("RANK_20_SOSHIKI_NM <>", value, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMGreaterThan(String value) {
            addCriterion("RANK_20_SOSHIKI_NM >", value, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RANK_20_SOSHIKI_NM >=", value, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMLessThan(String value) {
            addCriterion("RANK_20_SOSHIKI_NM <", value, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMLessThanOrEqualTo(String value) {
            addCriterion("RANK_20_SOSHIKI_NM <=", value, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMLike(String value) {
            addCriterion("RANK_20_SOSHIKI_NM like", value, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMNotLike(String value) {
            addCriterion("RANK_20_SOSHIKI_NM not like", value, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMIn(List<String> values) {
            addCriterion("RANK_20_SOSHIKI_NM in", values, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMNotIn(List<String> values) {
            addCriterion("RANK_20_SOSHIKI_NM not in", values, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMBetween(String value1, String value2) {
            addCriterion("RANK_20_SOSHIKI_NM between", value1, value2, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMNotBetween(String value1, String value2) {
            addCriterion("RANK_20_SOSHIKI_NM not between", value1, value2, "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01IsNull() {
            addCriterion("YOBI_KOMOKU_01 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01IsNotNull() {
            addCriterion("YOBI_KOMOKU_01 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 =", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 <>", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_01 >", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 >=", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LessThan(String value) {
            addCriterion("YOBI_KOMOKU_01 <", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 <=", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01Like(String value) {
            addCriterion("YOBI_KOMOKU_01 like", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotLike(String value) {
            addCriterion("YOBI_KOMOKU_01 not like", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01In(List<String> values) {
            addCriterion("YOBI_KOMOKU_01 in", values, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_01 not in", values, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_01 between", value1, value2, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_01 not between", value1, value2, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02IsNull() {
            addCriterion("YOBI_KOMOKU_02 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02IsNotNull() {
            addCriterion("YOBI_KOMOKU_02 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 =", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 <>", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_02 >", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 >=", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LessThan(String value) {
            addCriterion("YOBI_KOMOKU_02 <", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 <=", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02Like(String value) {
            addCriterion("YOBI_KOMOKU_02 like", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotLike(String value) {
            addCriterion("YOBI_KOMOKU_02 not like", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02In(List<String> values) {
            addCriterion("YOBI_KOMOKU_02 in", values, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_02 not in", values, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_02 between", value1, value2, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_02 not between", value1, value2, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03IsNull() {
            addCriterion("YOBI_KOMOKU_03 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03IsNotNull() {
            addCriterion("YOBI_KOMOKU_03 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 =", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 <>", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_03 >", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 >=", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LessThan(String value) {
            addCriterion("YOBI_KOMOKU_03 <", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 <=", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03Like(String value) {
            addCriterion("YOBI_KOMOKU_03 like", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotLike(String value) {
            addCriterion("YOBI_KOMOKU_03 not like", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03In(List<String> values) {
            addCriterion("YOBI_KOMOKU_03 in", values, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_03 not in", values, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_03 between", value1, value2, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_03 not between", value1, value2, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04IsNull() {
            addCriterion("YOBI_KOMOKU_04 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04IsNotNull() {
            addCriterion("YOBI_KOMOKU_04 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 =", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 <>", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_04 >", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 >=", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LessThan(String value) {
            addCriterion("YOBI_KOMOKU_04 <", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 <=", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04Like(String value) {
            addCriterion("YOBI_KOMOKU_04 like", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotLike(String value) {
            addCriterion("YOBI_KOMOKU_04 not like", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04In(List<String> values) {
            addCriterion("YOBI_KOMOKU_04 in", values, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_04 not in", values, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_04 between", value1, value2, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_04 not between", value1, value2, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05IsNull() {
            addCriterion("YOBI_KOMOKU_05 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05IsNotNull() {
            addCriterion("YOBI_KOMOKU_05 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 =", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 <>", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_05 >", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 >=", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LessThan(String value) {
            addCriterion("YOBI_KOMOKU_05 <", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 <=", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05Like(String value) {
            addCriterion("YOBI_KOMOKU_05 like", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotLike(String value) {
            addCriterion("YOBI_KOMOKU_05 not like", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05In(List<String> values) {
            addCriterion("YOBI_KOMOKU_05 in", values, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_05 not in", values, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_05 between", value1, value2, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_05 not between", value1, value2, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06IsNull() {
            addCriterion("YOBI_KOMOKU_06 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06IsNotNull() {
            addCriterion("YOBI_KOMOKU_06 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 =", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 <>", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_06 >", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 >=", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LessThan(String value) {
            addCriterion("YOBI_KOMOKU_06 <", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 <=", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06Like(String value) {
            addCriterion("YOBI_KOMOKU_06 like", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotLike(String value) {
            addCriterion("YOBI_KOMOKU_06 not like", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06In(List<String> values) {
            addCriterion("YOBI_KOMOKU_06 in", values, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_06 not in", values, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_06 between", value1, value2, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_06 not between", value1, value2, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07IsNull() {
            addCriterion("YOBI_KOMOKU_07 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07IsNotNull() {
            addCriterion("YOBI_KOMOKU_07 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 =", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 <>", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_07 >", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 >=", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LessThan(String value) {
            addCriterion("YOBI_KOMOKU_07 <", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 <=", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07Like(String value) {
            addCriterion("YOBI_KOMOKU_07 like", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotLike(String value) {
            addCriterion("YOBI_KOMOKU_07 not like", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07In(List<String> values) {
            addCriterion("YOBI_KOMOKU_07 in", values, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_07 not in", values, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_07 between", value1, value2, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_07 not between", value1, value2, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08IsNull() {
            addCriterion("YOBI_KOMOKU_08 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08IsNotNull() {
            addCriterion("YOBI_KOMOKU_08 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 =", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 <>", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_08 >", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 >=", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LessThan(String value) {
            addCriterion("YOBI_KOMOKU_08 <", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 <=", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08Like(String value) {
            addCriterion("YOBI_KOMOKU_08 like", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotLike(String value) {
            addCriterion("YOBI_KOMOKU_08 not like", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08In(List<String> values) {
            addCriterion("YOBI_KOMOKU_08 in", values, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_08 not in", values, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_08 between", value1, value2, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_08 not between", value1, value2, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09IsNull() {
            addCriterion("YOBI_KOMOKU_09 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09IsNotNull() {
            addCriterion("YOBI_KOMOKU_09 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 =", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 <>", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_09 >", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 >=", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LessThan(String value) {
            addCriterion("YOBI_KOMOKU_09 <", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 <=", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09Like(String value) {
            addCriterion("YOBI_KOMOKU_09 like", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotLike(String value) {
            addCriterion("YOBI_KOMOKU_09 not like", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09In(List<String> values) {
            addCriterion("YOBI_KOMOKU_09 in", values, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_09 not in", values, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_09 between", value1, value2, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_09 not between", value1, value2, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10IsNull() {
            addCriterion("YOBI_KOMOKU_10 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10IsNotNull() {
            addCriterion("YOBI_KOMOKU_10 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 =", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 <>", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_10 >", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 >=", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LessThan(String value) {
            addCriterion("YOBI_KOMOKU_10 <", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 <=", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10Like(String value) {
            addCriterion("YOBI_KOMOKU_10 like", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotLike(String value) {
            addCriterion("YOBI_KOMOKU_10 not like", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10In(List<String> values) {
            addCriterion("YOBI_KOMOKU_10 in", values, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_10 not in", values, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_10 between", value1, value2, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_10 not between", value1, value2, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIsNull() {
            addCriterion("REGST_TMSTMP is null");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIsNotNull() {
            addCriterion("REGST_TMSTMP is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPEqualTo(Date value) {
            addCriterion("REGST_TMSTMP =", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotEqualTo(Date value) {
            addCriterion("REGST_TMSTMP <>", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPGreaterThan(Date value) {
            addCriterion("REGST_TMSTMP >", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPGreaterThanOrEqualTo(Date value) {
            addCriterion("REGST_TMSTMP >=", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPLessThan(Date value) {
            addCriterion("REGST_TMSTMP <", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPLessThanOrEqualTo(Date value) {
            addCriterion("REGST_TMSTMP <=", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIn(List<Date> values) {
            addCriterion("REGST_TMSTMP in", values, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotIn(List<Date> values) {
            addCriterion("REGST_TMSTMP not in", values, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPBetween(Date value1, Date value2) {
            addCriterion("REGST_TMSTMP between", value1, value2, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotBetween(Date value1, Date value2) {
            addCriterion("REGST_TMSTMP not between", value1, value2, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIsNull() {
            addCriterion("REGSTR_CO_CD is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIsNotNull() {
            addCriterion("REGSTR_CO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDEqualTo(String value) {
            addCriterion("REGSTR_CO_CD =", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotEqualTo(String value) {
            addCriterion("REGSTR_CO_CD <>", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDGreaterThan(String value) {
            addCriterion("REGSTR_CO_CD >", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_CO_CD >=", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLessThan(String value) {
            addCriterion("REGSTR_CO_CD <", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_CO_CD <=", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLike(String value) {
            addCriterion("REGSTR_CO_CD like", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotLike(String value) {
            addCriterion("REGSTR_CO_CD not like", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIn(List<String> values) {
            addCriterion("REGSTR_CO_CD in", values, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotIn(List<String> values) {
            addCriterion("REGSTR_CO_CD not in", values, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDBetween(String value1, String value2) {
            addCriterion("REGSTR_CO_CD between", value1, value2, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotBetween(String value1, String value2) {
            addCriterion("REGSTR_CO_CD not between", value1, value2, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIsNull() {
            addCriterion("REGSTR_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIsNotNull() {
            addCriterion("REGSTR_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD =", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <>", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("REGSTR_SOSHIKI_CD >", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD >=", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLessThan(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <=", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLike(String value) {
            addCriterion("REGSTR_SOSHIKI_CD like", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotLike(String value) {
            addCriterion("REGSTR_SOSHIKI_CD not like", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIn(List<String> values) {
            addCriterion("REGSTR_SOSHIKI_CD in", values, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("REGSTR_SOSHIKI_CD not in", values, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("REGSTR_SOSHIKI_CD between", value1, value2, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("REGSTR_SOSHIKI_CD not between", value1, value2, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIsNull() {
            addCriterion("REGSTR_EMP_NO is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIsNotNull() {
            addCriterion("REGSTR_EMP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO =", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO <>", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOGreaterThan(String value) {
            addCriterion("REGSTR_EMP_NO >", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO >=", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLessThan(String value) {
            addCriterion("REGSTR_EMP_NO <", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO <=", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLike(String value) {
            addCriterion("REGSTR_EMP_NO like", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotLike(String value) {
            addCriterion("REGSTR_EMP_NO not like", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIn(List<String> values) {
            addCriterion("REGSTR_EMP_NO in", values, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotIn(List<String> values) {
            addCriterion("REGSTR_EMP_NO not in", values, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOBetween(String value1, String value2) {
            addCriterion("REGSTR_EMP_NO between", value1, value2, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotBetween(String value1, String value2) {
            addCriterion("REGSTR_EMP_NO not between", value1, value2, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIsNull() {
            addCriterion("REGST_GAMEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIsNotNull() {
            addCriterion("REGST_GAMEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID =", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID <>", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDGreaterThan(String value) {
            addCriterion("REGST_GAMEN_ID >", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID >=", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLessThan(String value) {
            addCriterion("REGST_GAMEN_ID <", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLessThanOrEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID <=", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLike(String value) {
            addCriterion("REGST_GAMEN_ID like", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotLike(String value) {
            addCriterion("REGST_GAMEN_ID not like", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIn(List<String> values) {
            addCriterion("REGST_GAMEN_ID in", values, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotIn(List<String> values) {
            addCriterion("REGST_GAMEN_ID not in", values, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDBetween(String value1, String value2) {
            addCriterion("REGST_GAMEN_ID between", value1, value2, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotBetween(String value1, String value2) {
            addCriterion("REGST_GAMEN_ID not between", value1, value2, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIsNull() {
            addCriterion("REGST_PGM_ID is null");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIsNotNull() {
            addCriterion("REGST_PGM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDEqualTo(String value) {
            addCriterion("REGST_PGM_ID =", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotEqualTo(String value) {
            addCriterion("REGST_PGM_ID <>", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDGreaterThan(String value) {
            addCriterion("REGST_PGM_ID >", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REGST_PGM_ID >=", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLessThan(String value) {
            addCriterion("REGST_PGM_ID <", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLessThanOrEqualTo(String value) {
            addCriterion("REGST_PGM_ID <=", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLike(String value) {
            addCriterion("REGST_PGM_ID like", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotLike(String value) {
            addCriterion("REGST_PGM_ID not like", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIn(List<String> values) {
            addCriterion("REGST_PGM_ID in", values, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotIn(List<String> values) {
            addCriterion("REGST_PGM_ID not in", values, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDBetween(String value1, String value2) {
            addCriterion("REGST_PGM_ID between", value1, value2, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotBetween(String value1, String value2) {
            addCriterion("REGST_PGM_ID not between", value1, value2, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIsNull() {
            addCriterion("UPD_TMSTMP is null");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIsNotNull() {
            addCriterion("UPD_TMSTMP is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPEqualTo(Date value) {
            addCriterion("UPD_TMSTMP =", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotEqualTo(Date value) {
            addCriterion("UPD_TMSTMP <>", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPGreaterThan(Date value) {
            addCriterion("UPD_TMSTMP >", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPGreaterThanOrEqualTo(Date value) {
            addCriterion("UPD_TMSTMP >=", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPLessThan(Date value) {
            addCriterion("UPD_TMSTMP <", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPLessThanOrEqualTo(Date value) {
            addCriterion("UPD_TMSTMP <=", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIn(List<Date> values) {
            addCriterion("UPD_TMSTMP in", values, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotIn(List<Date> values) {
            addCriterion("UPD_TMSTMP not in", values, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPBetween(Date value1, Date value2) {
            addCriterion("UPD_TMSTMP between", value1, value2, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotBetween(Date value1, Date value2) {
            addCriterion("UPD_TMSTMP not between", value1, value2, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIsNull() {
            addCriterion("UPDTR_CO_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIsNotNull() {
            addCriterion("UPDTR_CO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDEqualTo(String value) {
            addCriterion("UPDTR_CO_CD =", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotEqualTo(String value) {
            addCriterion("UPDTR_CO_CD <>", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDGreaterThan(String value) {
            addCriterion("UPDTR_CO_CD >", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_CO_CD >=", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLessThan(String value) {
            addCriterion("UPDTR_CO_CD <", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_CO_CD <=", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLike(String value) {
            addCriterion("UPDTR_CO_CD like", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotLike(String value) {
            addCriterion("UPDTR_CO_CD not like", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIn(List<String> values) {
            addCriterion("UPDTR_CO_CD in", values, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotIn(List<String> values) {
            addCriterion("UPDTR_CO_CD not in", values, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDBetween(String value1, String value2) {
            addCriterion("UPDTR_CO_CD between", value1, value2, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotBetween(String value1, String value2) {
            addCriterion("UPDTR_CO_CD not between", value1, value2, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIsNull() {
            addCriterion("UPDTR_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIsNotNull() {
            addCriterion("UPDTR_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD =", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <>", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("UPDTR_SOSHIKI_CD >", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD >=", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLessThan(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <=", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLike(String value) {
            addCriterion("UPDTR_SOSHIKI_CD like", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotLike(String value) {
            addCriterion("UPDTR_SOSHIKI_CD not like", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIn(List<String> values) {
            addCriterion("UPDTR_SOSHIKI_CD in", values, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("UPDTR_SOSHIKI_CD not in", values, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("UPDTR_SOSHIKI_CD between", value1, value2, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("UPDTR_SOSHIKI_CD not between", value1, value2, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIsNull() {
            addCriterion("UPDTR_EMP_NO is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIsNotNull() {
            addCriterion("UPDTR_EMP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO =", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO <>", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOGreaterThan(String value) {
            addCriterion("UPDTR_EMP_NO >", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO >=", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLessThan(String value) {
            addCriterion("UPDTR_EMP_NO <", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO <=", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLike(String value) {
            addCriterion("UPDTR_EMP_NO like", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotLike(String value) {
            addCriterion("UPDTR_EMP_NO not like", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIn(List<String> values) {
            addCriterion("UPDTR_EMP_NO in", values, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotIn(List<String> values) {
            addCriterion("UPDTR_EMP_NO not in", values, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOBetween(String value1, String value2) {
            addCriterion("UPDTR_EMP_NO between", value1, value2, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotBetween(String value1, String value2) {
            addCriterion("UPDTR_EMP_NO not between", value1, value2, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIsNull() {
            addCriterion("UPD_GAMEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIsNotNull() {
            addCriterion("UPD_GAMEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID =", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID <>", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDGreaterThan(String value) {
            addCriterion("UPD_GAMEN_ID >", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID >=", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLessThan(String value) {
            addCriterion("UPD_GAMEN_ID <", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLessThanOrEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID <=", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLike(String value) {
            addCriterion("UPD_GAMEN_ID like", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotLike(String value) {
            addCriterion("UPD_GAMEN_ID not like", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIn(List<String> values) {
            addCriterion("UPD_GAMEN_ID in", values, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotIn(List<String> values) {
            addCriterion("UPD_GAMEN_ID not in", values, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDBetween(String value1, String value2) {
            addCriterion("UPD_GAMEN_ID between", value1, value2, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotBetween(String value1, String value2) {
            addCriterion("UPD_GAMEN_ID not between", value1, value2, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIsNull() {
            addCriterion("UPD_PGM_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIsNotNull() {
            addCriterion("UPD_PGM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDEqualTo(String value) {
            addCriterion("UPD_PGM_ID =", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotEqualTo(String value) {
            addCriterion("UPD_PGM_ID <>", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDGreaterThan(String value) {
            addCriterion("UPD_PGM_ID >", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPD_PGM_ID >=", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLessThan(String value) {
            addCriterion("UPD_PGM_ID <", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLessThanOrEqualTo(String value) {
            addCriterion("UPD_PGM_ID <=", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLike(String value) {
            addCriterion("UPD_PGM_ID like", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotLike(String value) {
            addCriterion("UPD_PGM_ID not like", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIn(List<String> values) {
            addCriterion("UPD_PGM_ID in", values, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotIn(List<String> values) {
            addCriterion("UPD_PGM_ID not in", values, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDBetween(String value1, String value2) {
            addCriterion("UPD_PGM_ID between", value1, value2, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotBetween(String value1, String value2) {
            addCriterion("UPD_PGM_ID not between", value1, value2, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLikeInsensitive(String value) {
            addCriterion("upper(KAISHA_CD) like", value.toUpperCase(), "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(SOSHIKI_CD) like", value.toUpperCase(), "SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLikeInsensitive(String value) {
            addCriterion("upper(TEKIYO_KAISHI_YMD) like", value.toUpperCase(), "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLikeInsensitive(String value) {
            addCriterion("upper(TEKIYO_SHURYO_YMD) like", value.toUpperCase(), "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(SOSHIKI_NM) like", value.toUpperCase(), "SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andSOSHIKI_RNMLikeInsensitive(String value) {
            addCriterion("upper(SOSHIKI_RNM) like", value.toUpperCase(), "SOSHIKI_RNM");
            return (Criteria) this;
        }

        public Criteria andJOI_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(JOI_SOSHIKI_CD) like", value.toUpperCase(), "JOI_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(SHISHABU_SOSHIKI_CD) like", value.toUpperCase(), "SHISHABU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFMT_TIS_HNS_BMN_SSK_FLGLikeInsensitive(String value) {
            addCriterion("upper(KTH_HIFMT_TIS_HNS_BMN_SSK_FLG) like", value.toUpperCase(), "KTH_HIFMT_TIS_HNS_BMN_SSK_FLG");
            return (Criteria) this;
        }

        public Criteria andKTH_HIFSK_TIS_ZNS_SEGMENT_FLGLikeInsensitive(String value) {
            addCriterion("upper(KTH_HIFSK_TIS_ZNS_SEGMENT_FLG) like", value.toUpperCase(), "KTH_HIFSK_TIS_ZNS_SEGMENT_FLG");
            return (Criteria) this;
        }

        public Criteria andKNKY_KIHTS_BMN_SSHK_KBNLikeInsensitive(String value) {
            addCriterion("upper(KNKY_KIHTS_BMN_SSHK_KBN) like", value.toUpperCase(), "KNKY_KIHTS_BMN_SSHK_KBN");
            return (Criteria) this;
        }

        public Criteria andHIYO_FUTAN_BUMON_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(HIYO_FUTAN_BUMON_SOSHIKI_CD) like", value.toUpperCase(), "HIYO_FUTAN_BUMON_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andKIH_ICHJ_SHNN_BMN_SSHK_CDLikeInsensitive(String value) {
            addCriterion("upper(KIH_ICHJ_SHNN_BMN_SSHK_CD) like", value.toUpperCase(), "KIH_ICHJ_SHNN_BMN_SSHK_CD");
            return (Criteria) this;
        }

        public Criteria andSHISHA_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(SHISHA_SOSHIKI_CD) like", value.toUpperCase(), "SHISHA_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andCHIIKI_HOMBU_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(CHIIKI_HOMBU_SOSHIKI_CD) like", value.toUpperCase(), "CHIIKI_HOMBU_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_HOMBU_SANSHOKA_FLGLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_HOMBU_SANSHOKA_FLG) like", value.toUpperCase(), "JIGYO_HOMBU_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andZENSHA_SANSHOKA_FLGLikeInsensitive(String value) {
            addCriterion("upper(ZENSHA_SANSHOKA_FLG) like", value.toUpperCase(), "ZENSHA_SANSHOKA_FLG");
            return (Criteria) this;
        }

        public Criteria andSHISHABU_CDLikeInsensitive(String value) {
            addCriterion("upper(SHISHABU_CD) like", value.toUpperCase(), "SHISHABU_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_01_SOSHIKI_CD) like", value.toUpperCase(), "RANK_01_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_02_SOSHIKI_CD) like", value.toUpperCase(), "RANK_02_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_03_SOSHIKI_CD) like", value.toUpperCase(), "RANK_03_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_04_SOSHIKI_CD) like", value.toUpperCase(), "RANK_04_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_05_SOSHIKI_CD) like", value.toUpperCase(), "RANK_05_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_06_SOSHIKI_CD) like", value.toUpperCase(), "RANK_06_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_07_SOSHIKI_CD) like", value.toUpperCase(), "RANK_07_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_08_SOSHIKI_CD) like", value.toUpperCase(), "RANK_08_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_09_SOSHIKI_CD) like", value.toUpperCase(), "RANK_09_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_10_SOSHIKI_CD) like", value.toUpperCase(), "RANK_10_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_11_SOSHIKI_CD) like", value.toUpperCase(), "RANK_11_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_12_SOSHIKI_CD) like", value.toUpperCase(), "RANK_12_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_13_SOSHIKI_CD) like", value.toUpperCase(), "RANK_13_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_14_SOSHIKI_CD) like", value.toUpperCase(), "RANK_14_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_15_SOSHIKI_CD) like", value.toUpperCase(), "RANK_15_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_16_SOSHIKI_CD) like", value.toUpperCase(), "RANK_16_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_17_SOSHIKI_CD) like", value.toUpperCase(), "RANK_17_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_18_SOSHIKI_CD) like", value.toUpperCase(), "RANK_18_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_19_SOSHIKI_CD) like", value.toUpperCase(), "RANK_19_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(RANK_20_SOSHIKI_CD) like", value.toUpperCase(), "RANK_20_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andRANK_01_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_01_SOSHIKI_NM) like", value.toUpperCase(), "RANK_01_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_02_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_02_SOSHIKI_NM) like", value.toUpperCase(), "RANK_02_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_03_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_03_SOSHIKI_NM) like", value.toUpperCase(), "RANK_03_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_04_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_04_SOSHIKI_NM) like", value.toUpperCase(), "RANK_04_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_05_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_05_SOSHIKI_NM) like", value.toUpperCase(), "RANK_05_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_06_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_06_SOSHIKI_NM) like", value.toUpperCase(), "RANK_06_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_07_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_07_SOSHIKI_NM) like", value.toUpperCase(), "RANK_07_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_08_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_08_SOSHIKI_NM) like", value.toUpperCase(), "RANK_08_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_09_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_09_SOSHIKI_NM) like", value.toUpperCase(), "RANK_09_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_10_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_10_SOSHIKI_NM) like", value.toUpperCase(), "RANK_10_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_11_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_11_SOSHIKI_NM) like", value.toUpperCase(), "RANK_11_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_12_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_12_SOSHIKI_NM) like", value.toUpperCase(), "RANK_12_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_13_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_13_SOSHIKI_NM) like", value.toUpperCase(), "RANK_13_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_14_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_14_SOSHIKI_NM) like", value.toUpperCase(), "RANK_14_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_15_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_15_SOSHIKI_NM) like", value.toUpperCase(), "RANK_15_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_16_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_16_SOSHIKI_NM) like", value.toUpperCase(), "RANK_16_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_17_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_17_SOSHIKI_NM) like", value.toUpperCase(), "RANK_17_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_18_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_18_SOSHIKI_NM) like", value.toUpperCase(), "RANK_18_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_19_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_19_SOSHIKI_NM) like", value.toUpperCase(), "RANK_19_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andRANK_20_SOSHIKI_NMLikeInsensitive(String value) {
            addCriterion("upper(RANK_20_SOSHIKI_NM) like", value.toUpperCase(), "RANK_20_SOSHIKI_NM");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_01) like", value.toUpperCase(), "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_02) like", value.toUpperCase(), "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_03) like", value.toUpperCase(), "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_04) like", value.toUpperCase(), "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_05) like", value.toUpperCase(), "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_06) like", value.toUpperCase(), "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_07) like", value.toUpperCase(), "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_08) like", value.toUpperCase(), "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_09) like", value.toUpperCase(), "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_10) like", value.toUpperCase(), "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_CO_CD) like", value.toUpperCase(), "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_SOSHIKI_CD) like", value.toUpperCase(), "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_EMP_NO) like", value.toUpperCase(), "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLikeInsensitive(String value) {
            addCriterion("upper(REGST_GAMEN_ID) like", value.toUpperCase(), "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLikeInsensitive(String value) {
            addCriterion("upper(REGST_PGM_ID) like", value.toUpperCase(), "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_CO_CD) like", value.toUpperCase(), "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_SOSHIKI_CD) like", value.toUpperCase(), "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_EMP_NO) like", value.toUpperCase(), "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLikeInsensitive(String value) {
            addCriterion("upper(UPD_GAMEN_ID) like", value.toUpperCase(), "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLikeInsensitive(String value) {
            addCriterion("upper(UPD_PGM_ID) like", value.toUpperCase(), "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * C_EIGYO_SOSHIKI
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * C_EIGYO_SOSHIKI null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}