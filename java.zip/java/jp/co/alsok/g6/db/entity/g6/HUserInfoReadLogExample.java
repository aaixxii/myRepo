package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HUserInfoReadLogExample {
    /**
     * H_USER_INFO_READ_LOG
     */
    protected String orderByClause;

    /**
     * H_USER_INFO_READ_LOG
     */
    protected boolean distinct;

    /**
     * H_USER_INFO_READ_LOG
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HUserInfoReadLogExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_USER_INFO_READ_LOG null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_USER_INFO_READ_LOGIsNull() {
            addCriterion("LN_USER_INFO_READ_LOG is null");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGIsNotNull() {
            addCriterion("LN_USER_INFO_READ_LOG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGEqualTo(String value) {
            addCriterion("LN_USER_INFO_READ_LOG =", value, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGNotEqualTo(String value) {
            addCriterion("LN_USER_INFO_READ_LOG <>", value, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGGreaterThan(String value) {
            addCriterion("LN_USER_INFO_READ_LOG >", value, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_USER_INFO_READ_LOG >=", value, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGLessThan(String value) {
            addCriterion("LN_USER_INFO_READ_LOG <", value, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGLessThanOrEqualTo(String value) {
            addCriterion("LN_USER_INFO_READ_LOG <=", value, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGLike(String value) {
            addCriterion("LN_USER_INFO_READ_LOG like", value, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGNotLike(String value) {
            addCriterion("LN_USER_INFO_READ_LOG not like", value, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGIn(List<String> values) {
            addCriterion("LN_USER_INFO_READ_LOG in", values, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGNotIn(List<String> values) {
            addCriterion("LN_USER_INFO_READ_LOG not in", values, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGBetween(String value1, String value2) {
            addCriterion("LN_USER_INFO_READ_LOG between", value1, value2, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGNotBetween(String value1, String value2) {
            addCriterion("LN_USER_INFO_READ_LOG not between", value1, value2, "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGIsNull() {
            addCriterion("LN_QUE_CTRL_SIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGIsNotNull() {
            addCriterion("LN_QUE_CTRL_SIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGEqualTo(String value) {
            addCriterion("LN_QUE_CTRL_SIG =", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGNotEqualTo(String value) {
            addCriterion("LN_QUE_CTRL_SIG <>", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGGreaterThan(String value) {
            addCriterion("LN_QUE_CTRL_SIG >", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_QUE_CTRL_SIG >=", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGLessThan(String value) {
            addCriterion("LN_QUE_CTRL_SIG <", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGLessThanOrEqualTo(String value) {
            addCriterion("LN_QUE_CTRL_SIG <=", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGLike(String value) {
            addCriterion("LN_QUE_CTRL_SIG like", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGNotLike(String value) {
            addCriterion("LN_QUE_CTRL_SIG not like", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGIn(List<String> values) {
            addCriterion("LN_QUE_CTRL_SIG in", values, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGNotIn(List<String> values) {
            addCriterion("LN_QUE_CTRL_SIG not in", values, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGBetween(String value1, String value2) {
            addCriterion("LN_QUE_CTRL_SIG between", value1, value2, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGNotBetween(String value1, String value2) {
            addCriterion("LN_QUE_CTRL_SIG not between", value1, value2, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBIIsNull() {
            addCriterion("LN_KEIBI is null");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBIIsNotNull() {
            addCriterion("LN_KEIBI is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBIEqualTo(String value) {
            addCriterion("LN_KEIBI =", value, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBINotEqualTo(String value) {
            addCriterion("LN_KEIBI <>", value, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBIGreaterThan(String value) {
            addCriterion("LN_KEIBI >", value, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBIGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KEIBI >=", value, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBILessThan(String value) {
            addCriterion("LN_KEIBI <", value, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBILessThanOrEqualTo(String value) {
            addCriterion("LN_KEIBI <=", value, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBILike(String value) {
            addCriterion("LN_KEIBI like", value, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBINotLike(String value) {
            addCriterion("LN_KEIBI not like", value, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBIIn(List<String> values) {
            addCriterion("LN_KEIBI in", values, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBINotIn(List<String> values) {
            addCriterion("LN_KEIBI not in", values, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBIBetween(String value1, String value2) {
            addCriterion("LN_KEIBI between", value1, value2, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBINotBetween(String value1, String value2) {
            addCriterion("LN_KEIBI not between", value1, value2, "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDIsNull() {
            addCriterion("USERINF_KIND is null");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDIsNotNull() {
            addCriterion("USERINF_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDEqualTo(String value) {
            addCriterion("USERINF_KIND =", value, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDNotEqualTo(String value) {
            addCriterion("USERINF_KIND <>", value, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDGreaterThan(String value) {
            addCriterion("USERINF_KIND >", value, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("USERINF_KIND >=", value, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDLessThan(String value) {
            addCriterion("USERINF_KIND <", value, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDLessThanOrEqualTo(String value) {
            addCriterion("USERINF_KIND <=", value, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDLike(String value) {
            addCriterion("USERINF_KIND like", value, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDNotLike(String value) {
            addCriterion("USERINF_KIND not like", value, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDIn(List<String> values) {
            addCriterion("USERINF_KIND in", values, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDNotIn(List<String> values) {
            addCriterion("USERINF_KIND not in", values, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDBetween(String value1, String value2) {
            addCriterion("USERINF_KIND between", value1, value2, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDNotBetween(String value1, String value2) {
            addCriterion("USERINF_KIND not between", value1, value2, "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYIsNull() {
            addCriterion("MIMAMORI_TY is null");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYIsNotNull() {
            addCriterion("MIMAMORI_TY is not null");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYEqualTo(String value) {
            addCriterion("MIMAMORI_TY =", value, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYNotEqualTo(String value) {
            addCriterion("MIMAMORI_TY <>", value, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYGreaterThan(String value) {
            addCriterion("MIMAMORI_TY >", value, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYGreaterThanOrEqualTo(String value) {
            addCriterion("MIMAMORI_TY >=", value, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYLessThan(String value) {
            addCriterion("MIMAMORI_TY <", value, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYLessThanOrEqualTo(String value) {
            addCriterion("MIMAMORI_TY <=", value, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYLike(String value) {
            addCriterion("MIMAMORI_TY like", value, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYNotLike(String value) {
            addCriterion("MIMAMORI_TY not like", value, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYIn(List<String> values) {
            addCriterion("MIMAMORI_TY in", values, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYNotIn(List<String> values) {
            addCriterion("MIMAMORI_TY not in", values, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYBetween(String value1, String value2) {
            addCriterion("MIMAMORI_TY between", value1, value2, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYNotBetween(String value1, String value2) {
            addCriterion("MIMAMORI_TY not between", value1, value2, "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMIsNull() {
            addCriterion("MIMAMORI_TM is null");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMIsNotNull() {
            addCriterion("MIMAMORI_TM is not null");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMEqualTo(String value) {
            addCriterion("MIMAMORI_TM =", value, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMNotEqualTo(String value) {
            addCriterion("MIMAMORI_TM <>", value, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMGreaterThan(String value) {
            addCriterion("MIMAMORI_TM >", value, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMGreaterThanOrEqualTo(String value) {
            addCriterion("MIMAMORI_TM >=", value, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMLessThan(String value) {
            addCriterion("MIMAMORI_TM <", value, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMLessThanOrEqualTo(String value) {
            addCriterion("MIMAMORI_TM <=", value, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMLike(String value) {
            addCriterion("MIMAMORI_TM like", value, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMNotLike(String value) {
            addCriterion("MIMAMORI_TM not like", value, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMIn(List<String> values) {
            addCriterion("MIMAMORI_TM in", values, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMNotIn(List<String> values) {
            addCriterion("MIMAMORI_TM not in", values, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMBetween(String value1, String value2) {
            addCriterion("MIMAMORI_TM between", value1, value2, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMNotBetween(String value1, String value2) {
            addCriterion("MIMAMORI_TM not between", value1, value2, "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1IsNull() {
            addCriterion("TEIKOKU_TM1 is null");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1IsNotNull() {
            addCriterion("TEIKOKU_TM1 is not null");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1EqualTo(String value) {
            addCriterion("TEIKOKU_TM1 =", value, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1NotEqualTo(String value) {
            addCriterion("TEIKOKU_TM1 <>", value, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1GreaterThan(String value) {
            addCriterion("TEIKOKU_TM1 >", value, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1GreaterThanOrEqualTo(String value) {
            addCriterion("TEIKOKU_TM1 >=", value, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1LessThan(String value) {
            addCriterion("TEIKOKU_TM1 <", value, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1LessThanOrEqualTo(String value) {
            addCriterion("TEIKOKU_TM1 <=", value, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1Like(String value) {
            addCriterion("TEIKOKU_TM1 like", value, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1NotLike(String value) {
            addCriterion("TEIKOKU_TM1 not like", value, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1In(List<String> values) {
            addCriterion("TEIKOKU_TM1 in", values, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1NotIn(List<String> values) {
            addCriterion("TEIKOKU_TM1 not in", values, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1Between(String value1, String value2) {
            addCriterion("TEIKOKU_TM1 between", value1, value2, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1NotBetween(String value1, String value2) {
            addCriterion("TEIKOKU_TM1 not between", value1, value2, "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2IsNull() {
            addCriterion("TEIKOKU_TM2 is null");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2IsNotNull() {
            addCriterion("TEIKOKU_TM2 is not null");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2EqualTo(String value) {
            addCriterion("TEIKOKU_TM2 =", value, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2NotEqualTo(String value) {
            addCriterion("TEIKOKU_TM2 <>", value, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2GreaterThan(String value) {
            addCriterion("TEIKOKU_TM2 >", value, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2GreaterThanOrEqualTo(String value) {
            addCriterion("TEIKOKU_TM2 >=", value, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2LessThan(String value) {
            addCriterion("TEIKOKU_TM2 <", value, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2LessThanOrEqualTo(String value) {
            addCriterion("TEIKOKU_TM2 <=", value, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2Like(String value) {
            addCriterion("TEIKOKU_TM2 like", value, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2NotLike(String value) {
            addCriterion("TEIKOKU_TM2 not like", value, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2In(List<String> values) {
            addCriterion("TEIKOKU_TM2 in", values, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2NotIn(List<String> values) {
            addCriterion("TEIKOKU_TM2 not in", values, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2Between(String value1, String value2) {
            addCriterion("TEIKOKU_TM2 between", value1, value2, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2NotBetween(String value1, String value2) {
            addCriterion("TEIKOKU_TM2 not between", value1, value2, "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3IsNull() {
            addCriterion("TEIKOKU_TM3 is null");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3IsNotNull() {
            addCriterion("TEIKOKU_TM3 is not null");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3EqualTo(String value) {
            addCriterion("TEIKOKU_TM3 =", value, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3NotEqualTo(String value) {
            addCriterion("TEIKOKU_TM3 <>", value, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3GreaterThan(String value) {
            addCriterion("TEIKOKU_TM3 >", value, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3GreaterThanOrEqualTo(String value) {
            addCriterion("TEIKOKU_TM3 >=", value, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3LessThan(String value) {
            addCriterion("TEIKOKU_TM3 <", value, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3LessThanOrEqualTo(String value) {
            addCriterion("TEIKOKU_TM3 <=", value, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3Like(String value) {
            addCriterion("TEIKOKU_TM3 like", value, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3NotLike(String value) {
            addCriterion("TEIKOKU_TM3 not like", value, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3In(List<String> values) {
            addCriterion("TEIKOKU_TM3 in", values, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3NotIn(List<String> values) {
            addCriterion("TEIKOKU_TM3 not in", values, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3Between(String value1, String value2) {
            addCriterion("TEIKOKU_TM3 between", value1, value2, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3NotBetween(String value1, String value2) {
            addCriterion("TEIKOKU_TM3 not between", value1, value2, "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMIsNull() {
            addCriterion("TEISI_TM is null");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMIsNotNull() {
            addCriterion("TEISI_TM is not null");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMEqualTo(String value) {
            addCriterion("TEISI_TM =", value, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMNotEqualTo(String value) {
            addCriterion("TEISI_TM <>", value, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMGreaterThan(String value) {
            addCriterion("TEISI_TM >", value, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMGreaterThanOrEqualTo(String value) {
            addCriterion("TEISI_TM >=", value, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMLessThan(String value) {
            addCriterion("TEISI_TM <", value, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMLessThanOrEqualTo(String value) {
            addCriterion("TEISI_TM <=", value, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMLike(String value) {
            addCriterion("TEISI_TM like", value, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMNotLike(String value) {
            addCriterion("TEISI_TM not like", value, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMIn(List<String> values) {
            addCriterion("TEISI_TM in", values, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMNotIn(List<String> values) {
            addCriterion("TEISI_TM not in", values, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMBetween(String value1, String value2) {
            addCriterion("TEISI_TM between", value1, value2, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMNotBetween(String value1, String value2) {
            addCriterion("TEISI_TM not between", value1, value2, "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_USER_INFO_READ_LOGLikeInsensitive(String value) {
            addCriterion("upper(LN_USER_INFO_READ_LOG) like", value.toUpperCase(), "LN_USER_INFO_READ_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGLikeInsensitive(String value) {
            addCriterion("upper(LN_QUE_CTRL_SIG) like", value.toUpperCase(), "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBILikeInsensitive(String value) {
            addCriterion("upper(LN_KEIBI) like", value.toUpperCase(), "LN_KEIBI");
            return (Criteria) this;
        }

        public Criteria andUSERINF_KINDLikeInsensitive(String value) {
            addCriterion("upper(USERINF_KIND) like", value.toUpperCase(), "USERINF_KIND");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TYLikeInsensitive(String value) {
            addCriterion("upper(MIMAMORI_TY) like", value.toUpperCase(), "MIMAMORI_TY");
            return (Criteria) this;
        }

        public Criteria andMIMAMORI_TMLikeInsensitive(String value) {
            addCriterion("upper(MIMAMORI_TM) like", value.toUpperCase(), "MIMAMORI_TM");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM1LikeInsensitive(String value) {
            addCriterion("upper(TEIKOKU_TM1) like", value.toUpperCase(), "TEIKOKU_TM1");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM2LikeInsensitive(String value) {
            addCriterion("upper(TEIKOKU_TM2) like", value.toUpperCase(), "TEIKOKU_TM2");
            return (Criteria) this;
        }

        public Criteria andTEIKOKU_TM3LikeInsensitive(String value) {
            addCriterion("upper(TEIKOKU_TM3) like", value.toUpperCase(), "TEIKOKU_TM3");
            return (Criteria) this;
        }

        public Criteria andTEISI_TMLikeInsensitive(String value) {
            addCriterion("upper(TEISI_TM) like", value.toUpperCase(), "TEISI_TM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_USER_INFO_READ_LOG
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_USER_INFO_READ_LOG null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}