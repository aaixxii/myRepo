package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MAddrExample {
    /**
     * M_ADDR
     */
    protected String orderByClause;

    /**
     * M_ADDR
     */
    protected boolean distinct;

    /**
     * M_ADDR
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MAddrExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_ADDR null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andADDR_CD1_IDIsNull() {
            addCriterion("ADDR_CD1_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDIsNotNull() {
            addCriterion("ADDR_CD1_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDEqualTo(String value) {
            addCriterion("ADDR_CD1_ID =", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD1_ID <>", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDGreaterThan(String value) {
            addCriterion("ADDR_CD1_ID >", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD1_ID >=", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDLessThan(String value) {
            addCriterion("ADDR_CD1_ID <", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD1_ID <=", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDLike(String value) {
            addCriterion("ADDR_CD1_ID like", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDNotLike(String value) {
            addCriterion("ADDR_CD1_ID not like", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDIn(List<String> values) {
            addCriterion("ADDR_CD1_ID in", values, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD1_ID not in", values, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD1_ID between", value1, value2, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD1_ID not between", value1, value2, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDIsNull() {
            addCriterion("ADDR_CD2_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDIsNotNull() {
            addCriterion("ADDR_CD2_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDEqualTo(String value) {
            addCriterion("ADDR_CD2_ID =", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD2_ID <>", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDGreaterThan(String value) {
            addCriterion("ADDR_CD2_ID >", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD2_ID >=", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDLessThan(String value) {
            addCriterion("ADDR_CD2_ID <", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD2_ID <=", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDLike(String value) {
            addCriterion("ADDR_CD2_ID like", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDNotLike(String value) {
            addCriterion("ADDR_CD2_ID not like", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDIn(List<String> values) {
            addCriterion("ADDR_CD2_ID in", values, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD2_ID not in", values, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD2_ID between", value1, value2, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD2_ID not between", value1, value2, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDIsNull() {
            addCriterion("ADDR_CD3_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDIsNotNull() {
            addCriterion("ADDR_CD3_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDEqualTo(String value) {
            addCriterion("ADDR_CD3_ID =", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD3_ID <>", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDGreaterThan(String value) {
            addCriterion("ADDR_CD3_ID >", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD3_ID >=", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDLessThan(String value) {
            addCriterion("ADDR_CD3_ID <", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD3_ID <=", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDLike(String value) {
            addCriterion("ADDR_CD3_ID like", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDNotLike(String value) {
            addCriterion("ADDR_CD3_ID not like", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDIn(List<String> values) {
            addCriterion("ADDR_CD3_ID in", values, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD3_ID not in", values, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD3_ID between", value1, value2, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD3_ID not between", value1, value2, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDIsNull() {
            addCriterion("ADDR_CD4_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDIsNotNull() {
            addCriterion("ADDR_CD4_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDEqualTo(String value) {
            addCriterion("ADDR_CD4_ID =", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD4_ID <>", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDGreaterThan(String value) {
            addCriterion("ADDR_CD4_ID >", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD4_ID >=", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDLessThan(String value) {
            addCriterion("ADDR_CD4_ID <", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD4_ID <=", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDLike(String value) {
            addCriterion("ADDR_CD4_ID like", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDNotLike(String value) {
            addCriterion("ADDR_CD4_ID not like", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDIn(List<String> values) {
            addCriterion("ADDR_CD4_ID in", values, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD4_ID not in", values, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD4_ID between", value1, value2, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD4_ID not between", value1, value2, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDIsNull() {
            addCriterion("ADDR_CD5_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDIsNotNull() {
            addCriterion("ADDR_CD5_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDEqualTo(String value) {
            addCriterion("ADDR_CD5_ID =", value, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD5_ID <>", value, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDGreaterThan(String value) {
            addCriterion("ADDR_CD5_ID >", value, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD5_ID >=", value, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDLessThan(String value) {
            addCriterion("ADDR_CD5_ID <", value, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD5_ID <=", value, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDLike(String value) {
            addCriterion("ADDR_CD5_ID like", value, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDNotLike(String value) {
            addCriterion("ADDR_CD5_ID not like", value, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDIn(List<String> values) {
            addCriterion("ADDR_CD5_ID in", values, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD5_ID not in", values, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD5_ID between", value1, value2, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD5_ID not between", value1, value2, "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDIsNull() {
            addCriterion("ADDR_CD6_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDIsNotNull() {
            addCriterion("ADDR_CD6_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDEqualTo(String value) {
            addCriterion("ADDR_CD6_ID =", value, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD6_ID <>", value, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDGreaterThan(String value) {
            addCriterion("ADDR_CD6_ID >", value, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD6_ID >=", value, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDLessThan(String value) {
            addCriterion("ADDR_CD6_ID <", value, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD6_ID <=", value, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDLike(String value) {
            addCriterion("ADDR_CD6_ID like", value, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDNotLike(String value) {
            addCriterion("ADDR_CD6_ID not like", value, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDIn(List<String> values) {
            addCriterion("ADDR_CD6_ID in", values, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD6_ID not in", values, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD6_ID between", value1, value2, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD6_ID not between", value1, value2, "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMIsNull() {
            addCriterion("POST_NUM is null");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMIsNotNull() {
            addCriterion("POST_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMEqualTo(String value) {
            addCriterion("POST_NUM =", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMNotEqualTo(String value) {
            addCriterion("POST_NUM <>", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMGreaterThan(String value) {
            addCriterion("POST_NUM >", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("POST_NUM >=", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMLessThan(String value) {
            addCriterion("POST_NUM <", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMLessThanOrEqualTo(String value) {
            addCriterion("POST_NUM <=", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMLike(String value) {
            addCriterion("POST_NUM like", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMNotLike(String value) {
            addCriterion("POST_NUM not like", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMIn(List<String> values) {
            addCriterion("POST_NUM in", values, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMNotIn(List<String> values) {
            addCriterion("POST_NUM not in", values, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMBetween(String value1, String value2) {
            addCriterion("POST_NUM between", value1, value2, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMNotBetween(String value1, String value2) {
            addCriterion("POST_NUM not between", value1, value2, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1IsNull() {
            addCriterion("ADDR_NM1 is null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1IsNotNull() {
            addCriterion("ADDR_NM1 is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1EqualTo(String value) {
            addCriterion("ADDR_NM1 =", value, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1NotEqualTo(String value) {
            addCriterion("ADDR_NM1 <>", value, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1GreaterThan(String value) {
            addCriterion("ADDR_NM1 >", value, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1GreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_NM1 >=", value, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1LessThan(String value) {
            addCriterion("ADDR_NM1 <", value, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1LessThanOrEqualTo(String value) {
            addCriterion("ADDR_NM1 <=", value, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1Like(String value) {
            addCriterion("ADDR_NM1 like", value, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1NotLike(String value) {
            addCriterion("ADDR_NM1 not like", value, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1In(List<String> values) {
            addCriterion("ADDR_NM1 in", values, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1NotIn(List<String> values) {
            addCriterion("ADDR_NM1 not in", values, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1Between(String value1, String value2) {
            addCriterion("ADDR_NM1 between", value1, value2, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1NotBetween(String value1, String value2) {
            addCriterion("ADDR_NM1 not between", value1, value2, "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2IsNull() {
            addCriterion("ADDR_NM2 is null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2IsNotNull() {
            addCriterion("ADDR_NM2 is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2EqualTo(String value) {
            addCriterion("ADDR_NM2 =", value, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2NotEqualTo(String value) {
            addCriterion("ADDR_NM2 <>", value, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2GreaterThan(String value) {
            addCriterion("ADDR_NM2 >", value, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2GreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_NM2 >=", value, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2LessThan(String value) {
            addCriterion("ADDR_NM2 <", value, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2LessThanOrEqualTo(String value) {
            addCriterion("ADDR_NM2 <=", value, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2Like(String value) {
            addCriterion("ADDR_NM2 like", value, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2NotLike(String value) {
            addCriterion("ADDR_NM2 not like", value, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2In(List<String> values) {
            addCriterion("ADDR_NM2 in", values, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2NotIn(List<String> values) {
            addCriterion("ADDR_NM2 not in", values, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2Between(String value1, String value2) {
            addCriterion("ADDR_NM2 between", value1, value2, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2NotBetween(String value1, String value2) {
            addCriterion("ADDR_NM2 not between", value1, value2, "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3IsNull() {
            addCriterion("ADDR_NM3 is null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3IsNotNull() {
            addCriterion("ADDR_NM3 is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3EqualTo(String value) {
            addCriterion("ADDR_NM3 =", value, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3NotEqualTo(String value) {
            addCriterion("ADDR_NM3 <>", value, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3GreaterThan(String value) {
            addCriterion("ADDR_NM3 >", value, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3GreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_NM3 >=", value, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3LessThan(String value) {
            addCriterion("ADDR_NM3 <", value, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3LessThanOrEqualTo(String value) {
            addCriterion("ADDR_NM3 <=", value, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3Like(String value) {
            addCriterion("ADDR_NM3 like", value, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3NotLike(String value) {
            addCriterion("ADDR_NM3 not like", value, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3In(List<String> values) {
            addCriterion("ADDR_NM3 in", values, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3NotIn(List<String> values) {
            addCriterion("ADDR_NM3 not in", values, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3Between(String value1, String value2) {
            addCriterion("ADDR_NM3 between", value1, value2, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3NotBetween(String value1, String value2) {
            addCriterion("ADDR_NM3 not between", value1, value2, "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4IsNull() {
            addCriterion("ADDR_NM4 is null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4IsNotNull() {
            addCriterion("ADDR_NM4 is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4EqualTo(String value) {
            addCriterion("ADDR_NM4 =", value, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4NotEqualTo(String value) {
            addCriterion("ADDR_NM4 <>", value, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4GreaterThan(String value) {
            addCriterion("ADDR_NM4 >", value, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4GreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_NM4 >=", value, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4LessThan(String value) {
            addCriterion("ADDR_NM4 <", value, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4LessThanOrEqualTo(String value) {
            addCriterion("ADDR_NM4 <=", value, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4Like(String value) {
            addCriterion("ADDR_NM4 like", value, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4NotLike(String value) {
            addCriterion("ADDR_NM4 not like", value, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4In(List<String> values) {
            addCriterion("ADDR_NM4 in", values, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4NotIn(List<String> values) {
            addCriterion("ADDR_NM4 not in", values, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4Between(String value1, String value2) {
            addCriterion("ADDR_NM4 between", value1, value2, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4NotBetween(String value1, String value2) {
            addCriterion("ADDR_NM4 not between", value1, value2, "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5IsNull() {
            addCriterion("ADDR_NM5 is null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5IsNotNull() {
            addCriterion("ADDR_NM5 is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5EqualTo(String value) {
            addCriterion("ADDR_NM5 =", value, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5NotEqualTo(String value) {
            addCriterion("ADDR_NM5 <>", value, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5GreaterThan(String value) {
            addCriterion("ADDR_NM5 >", value, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5GreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_NM5 >=", value, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5LessThan(String value) {
            addCriterion("ADDR_NM5 <", value, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5LessThanOrEqualTo(String value) {
            addCriterion("ADDR_NM5 <=", value, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5Like(String value) {
            addCriterion("ADDR_NM5 like", value, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5NotLike(String value) {
            addCriterion("ADDR_NM5 not like", value, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5In(List<String> values) {
            addCriterion("ADDR_NM5 in", values, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5NotIn(List<String> values) {
            addCriterion("ADDR_NM5 not in", values, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5Between(String value1, String value2) {
            addCriterion("ADDR_NM5 between", value1, value2, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5NotBetween(String value1, String value2) {
            addCriterion("ADDR_NM5 not between", value1, value2, "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6IsNull() {
            addCriterion("ADDR_NM6 is null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6IsNotNull() {
            addCriterion("ADDR_NM6 is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6EqualTo(String value) {
            addCriterion("ADDR_NM6 =", value, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6NotEqualTo(String value) {
            addCriterion("ADDR_NM6 <>", value, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6GreaterThan(String value) {
            addCriterion("ADDR_NM6 >", value, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6GreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_NM6 >=", value, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6LessThan(String value) {
            addCriterion("ADDR_NM6 <", value, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6LessThanOrEqualTo(String value) {
            addCriterion("ADDR_NM6 <=", value, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6Like(String value) {
            addCriterion("ADDR_NM6 like", value, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6NotLike(String value) {
            addCriterion("ADDR_NM6 not like", value, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6In(List<String> values) {
            addCriterion("ADDR_NM6 in", values, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6NotIn(List<String> values) {
            addCriterion("ADDR_NM6 not in", values, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6Between(String value1, String value2) {
            addCriterion("ADDR_NM6 between", value1, value2, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6NotBetween(String value1, String value2) {
            addCriterion("ADDR_NM6 not between", value1, value2, "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANAIsNull() {
            addCriterion("ADDR_1_KANA is null");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANAIsNotNull() {
            addCriterion("ADDR_1_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANAEqualTo(String value) {
            addCriterion("ADDR_1_KANA =", value, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANANotEqualTo(String value) {
            addCriterion("ADDR_1_KANA <>", value, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANAGreaterThan(String value) {
            addCriterion("ADDR_1_KANA >", value, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_1_KANA >=", value, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANALessThan(String value) {
            addCriterion("ADDR_1_KANA <", value, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANALessThanOrEqualTo(String value) {
            addCriterion("ADDR_1_KANA <=", value, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANALike(String value) {
            addCriterion("ADDR_1_KANA like", value, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANANotLike(String value) {
            addCriterion("ADDR_1_KANA not like", value, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANAIn(List<String> values) {
            addCriterion("ADDR_1_KANA in", values, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANANotIn(List<String> values) {
            addCriterion("ADDR_1_KANA not in", values, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANABetween(String value1, String value2) {
            addCriterion("ADDR_1_KANA between", value1, value2, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANANotBetween(String value1, String value2) {
            addCriterion("ADDR_1_KANA not between", value1, value2, "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANAIsNull() {
            addCriterion("ADDR_2_KANA is null");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANAIsNotNull() {
            addCriterion("ADDR_2_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANAEqualTo(String value) {
            addCriterion("ADDR_2_KANA =", value, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANANotEqualTo(String value) {
            addCriterion("ADDR_2_KANA <>", value, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANAGreaterThan(String value) {
            addCriterion("ADDR_2_KANA >", value, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_2_KANA >=", value, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANALessThan(String value) {
            addCriterion("ADDR_2_KANA <", value, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANALessThanOrEqualTo(String value) {
            addCriterion("ADDR_2_KANA <=", value, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANALike(String value) {
            addCriterion("ADDR_2_KANA like", value, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANANotLike(String value) {
            addCriterion("ADDR_2_KANA not like", value, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANAIn(List<String> values) {
            addCriterion("ADDR_2_KANA in", values, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANANotIn(List<String> values) {
            addCriterion("ADDR_2_KANA not in", values, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANABetween(String value1, String value2) {
            addCriterion("ADDR_2_KANA between", value1, value2, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANANotBetween(String value1, String value2) {
            addCriterion("ADDR_2_KANA not between", value1, value2, "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANAIsNull() {
            addCriterion("ADDR_3_KANA is null");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANAIsNotNull() {
            addCriterion("ADDR_3_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANAEqualTo(String value) {
            addCriterion("ADDR_3_KANA =", value, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANANotEqualTo(String value) {
            addCriterion("ADDR_3_KANA <>", value, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANAGreaterThan(String value) {
            addCriterion("ADDR_3_KANA >", value, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_3_KANA >=", value, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANALessThan(String value) {
            addCriterion("ADDR_3_KANA <", value, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANALessThanOrEqualTo(String value) {
            addCriterion("ADDR_3_KANA <=", value, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANALike(String value) {
            addCriterion("ADDR_3_KANA like", value, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANANotLike(String value) {
            addCriterion("ADDR_3_KANA not like", value, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANAIn(List<String> values) {
            addCriterion("ADDR_3_KANA in", values, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANANotIn(List<String> values) {
            addCriterion("ADDR_3_KANA not in", values, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANABetween(String value1, String value2) {
            addCriterion("ADDR_3_KANA between", value1, value2, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANANotBetween(String value1, String value2) {
            addCriterion("ADDR_3_KANA not between", value1, value2, "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANAIsNull() {
            addCriterion("ADDR_4_KANA is null");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANAIsNotNull() {
            addCriterion("ADDR_4_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANAEqualTo(String value) {
            addCriterion("ADDR_4_KANA =", value, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANANotEqualTo(String value) {
            addCriterion("ADDR_4_KANA <>", value, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANAGreaterThan(String value) {
            addCriterion("ADDR_4_KANA >", value, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_4_KANA >=", value, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANALessThan(String value) {
            addCriterion("ADDR_4_KANA <", value, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANALessThanOrEqualTo(String value) {
            addCriterion("ADDR_4_KANA <=", value, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANALike(String value) {
            addCriterion("ADDR_4_KANA like", value, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANANotLike(String value) {
            addCriterion("ADDR_4_KANA not like", value, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANAIn(List<String> values) {
            addCriterion("ADDR_4_KANA in", values, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANANotIn(List<String> values) {
            addCriterion("ADDR_4_KANA not in", values, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANABetween(String value1, String value2) {
            addCriterion("ADDR_4_KANA between", value1, value2, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANANotBetween(String value1, String value2) {
            addCriterion("ADDR_4_KANA not between", value1, value2, "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANAIsNull() {
            addCriterion("ADDR_5_KANA is null");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANAIsNotNull() {
            addCriterion("ADDR_5_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANAEqualTo(String value) {
            addCriterion("ADDR_5_KANA =", value, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANANotEqualTo(String value) {
            addCriterion("ADDR_5_KANA <>", value, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANAGreaterThan(String value) {
            addCriterion("ADDR_5_KANA >", value, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_5_KANA >=", value, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANALessThan(String value) {
            addCriterion("ADDR_5_KANA <", value, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANALessThanOrEqualTo(String value) {
            addCriterion("ADDR_5_KANA <=", value, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANALike(String value) {
            addCriterion("ADDR_5_KANA like", value, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANANotLike(String value) {
            addCriterion("ADDR_5_KANA not like", value, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANAIn(List<String> values) {
            addCriterion("ADDR_5_KANA in", values, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANANotIn(List<String> values) {
            addCriterion("ADDR_5_KANA not in", values, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANABetween(String value1, String value2) {
            addCriterion("ADDR_5_KANA between", value1, value2, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANANotBetween(String value1, String value2) {
            addCriterion("ADDR_5_KANA not between", value1, value2, "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGIsNull() {
            addCriterion("TOORINA_FLG is null");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGIsNotNull() {
            addCriterion("TOORINA_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGEqualTo(String value) {
            addCriterion("TOORINA_FLG =", value, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGNotEqualTo(String value) {
            addCriterion("TOORINA_FLG <>", value, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGGreaterThan(String value) {
            addCriterion("TOORINA_FLG >", value, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("TOORINA_FLG >=", value, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGLessThan(String value) {
            addCriterion("TOORINA_FLG <", value, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGLessThanOrEqualTo(String value) {
            addCriterion("TOORINA_FLG <=", value, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGLike(String value) {
            addCriterion("TOORINA_FLG like", value, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGNotLike(String value) {
            addCriterion("TOORINA_FLG not like", value, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGIn(List<String> values) {
            addCriterion("TOORINA_FLG in", values, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGNotIn(List<String> values) {
            addCriterion("TOORINA_FLG not in", values, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGBetween(String value1, String value2) {
            addCriterion("TOORINA_FLG between", value1, value2, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGNotBetween(String value1, String value2) {
            addCriterion("TOORINA_FLG not between", value1, value2, "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANAIsNull() {
            addCriterion("ADDR_6_KANA is null");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANAIsNotNull() {
            addCriterion("ADDR_6_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANAEqualTo(String value) {
            addCriterion("ADDR_6_KANA =", value, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANANotEqualTo(String value) {
            addCriterion("ADDR_6_KANA <>", value, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANAGreaterThan(String value) {
            addCriterion("ADDR_6_KANA >", value, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_6_KANA >=", value, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANALessThan(String value) {
            addCriterion("ADDR_6_KANA <", value, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANALessThanOrEqualTo(String value) {
            addCriterion("ADDR_6_KANA <=", value, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANALike(String value) {
            addCriterion("ADDR_6_KANA like", value, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANANotLike(String value) {
            addCriterion("ADDR_6_KANA not like", value, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANAIn(List<String> values) {
            addCriterion("ADDR_6_KANA in", values, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANANotIn(List<String> values) {
            addCriterion("ADDR_6_KANA not in", values, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANABetween(String value1, String value2) {
            addCriterion("ADDR_6_KANA between", value1, value2, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANANotBetween(String value1, String value2) {
            addCriterion("ADDR_6_KANA not between", value1, value2, "ADDR_6_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD1_ID) like", value.toUpperCase(), "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD2_ID) like", value.toUpperCase(), "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD3_ID) like", value.toUpperCase(), "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD4_ID) like", value.toUpperCase(), "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD5_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD5_ID) like", value.toUpperCase(), "ADDR_CD5_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD6_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD6_ID) like", value.toUpperCase(), "ADDR_CD6_ID");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMLikeInsensitive(String value) {
            addCriterion("upper(POST_NUM) like", value.toUpperCase(), "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andADDR_NM1LikeInsensitive(String value) {
            addCriterion("upper(ADDR_NM1) like", value.toUpperCase(), "ADDR_NM1");
            return (Criteria) this;
        }

        public Criteria andADDR_NM2LikeInsensitive(String value) {
            addCriterion("upper(ADDR_NM2) like", value.toUpperCase(), "ADDR_NM2");
            return (Criteria) this;
        }

        public Criteria andADDR_NM3LikeInsensitive(String value) {
            addCriterion("upper(ADDR_NM3) like", value.toUpperCase(), "ADDR_NM3");
            return (Criteria) this;
        }

        public Criteria andADDR_NM4LikeInsensitive(String value) {
            addCriterion("upper(ADDR_NM4) like", value.toUpperCase(), "ADDR_NM4");
            return (Criteria) this;
        }

        public Criteria andADDR_NM5LikeInsensitive(String value) {
            addCriterion("upper(ADDR_NM5) like", value.toUpperCase(), "ADDR_NM5");
            return (Criteria) this;
        }

        public Criteria andADDR_NM6LikeInsensitive(String value) {
            addCriterion("upper(ADDR_NM6) like", value.toUpperCase(), "ADDR_NM6");
            return (Criteria) this;
        }

        public Criteria andADDR_1_KANALikeInsensitive(String value) {
            addCriterion("upper(ADDR_1_KANA) like", value.toUpperCase(), "ADDR_1_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_2_KANALikeInsensitive(String value) {
            addCriterion("upper(ADDR_2_KANA) like", value.toUpperCase(), "ADDR_2_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_3_KANALikeInsensitive(String value) {
            addCriterion("upper(ADDR_3_KANA) like", value.toUpperCase(), "ADDR_3_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_4_KANALikeInsensitive(String value) {
            addCriterion("upper(ADDR_4_KANA) like", value.toUpperCase(), "ADDR_4_KANA");
            return (Criteria) this;
        }

        public Criteria andADDR_5_KANALikeInsensitive(String value) {
            addCriterion("upper(ADDR_5_KANA) like", value.toUpperCase(), "ADDR_5_KANA");
            return (Criteria) this;
        }

        public Criteria andTOORINA_FLGLikeInsensitive(String value) {
            addCriterion("upper(TOORINA_FLG) like", value.toUpperCase(), "TOORINA_FLG");
            return (Criteria) this;
        }

        public Criteria andADDR_6_KANALikeInsensitive(String value) {
            addCriterion("upper(ADDR_6_KANA) like", value.toUpperCase(), "ADDR_6_KANA");
            return (Criteria) this;
        }
    }

    /**
     * M_ADDR
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_ADDR null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}