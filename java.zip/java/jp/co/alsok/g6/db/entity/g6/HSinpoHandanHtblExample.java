package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HSinpoHandanHtblExample {
    /**
     * H_SINPO_HANDAN_HTBL
     */
    protected String orderByClause;

    /**
     * H_SINPO_HANDAN_HTBL
     */
    protected boolean distinct;

    /**
     * H_SINPO_HANDAN_HTBL
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HSinpoHandanHtblExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_SINPO_HANDAN_HTBL null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_SINPO_HANDANIsNull() {
            addCriterion("LN_SINPO_HANDAN is null");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANIsNotNull() {
            addCriterion("LN_SINPO_HANDAN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANEqualTo(String value) {
            addCriterion("LN_SINPO_HANDAN =", value, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANNotEqualTo(String value) {
            addCriterion("LN_SINPO_HANDAN <>", value, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANGreaterThan(String value) {
            addCriterion("LN_SINPO_HANDAN >", value, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANGreaterThanOrEqualTo(String value) {
            addCriterion("LN_SINPO_HANDAN >=", value, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANLessThan(String value) {
            addCriterion("LN_SINPO_HANDAN <", value, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANLessThanOrEqualTo(String value) {
            addCriterion("LN_SINPO_HANDAN <=", value, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANLike(String value) {
            addCriterion("LN_SINPO_HANDAN like", value, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANNotLike(String value) {
            addCriterion("LN_SINPO_HANDAN not like", value, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANIn(List<String> values) {
            addCriterion("LN_SINPO_HANDAN in", values, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANNotIn(List<String> values) {
            addCriterion("LN_SINPO_HANDAN not in", values, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANBetween(String value1, String value2) {
            addCriterion("LN_SINPO_HANDAN between", value1, value2, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANNotBetween(String value1, String value2) {
            addCriterion("LN_SINPO_HANDAN not between", value1, value2, "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNull() {
            addCriterion("LN_JIAN is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNotNull() {
            addCriterion("LN_JIAN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANEqualTo(String value) {
            addCriterion("LN_JIAN =", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotEqualTo(String value) {
            addCriterion("LN_JIAN <>", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThan(String value) {
            addCriterion("LN_JIAN >", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN >=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThan(String value) {
            addCriterion("LN_JIAN <", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN <=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLike(String value) {
            addCriterion("LN_JIAN like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotLike(String value) {
            addCriterion("LN_JIAN not like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIn(List<String> values) {
            addCriterion("LN_JIAN in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotIn(List<String> values) {
            addCriterion("LN_JIAN not in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANBetween(String value1, String value2) {
            addCriterion("LN_JIAN between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN not between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELIsNull() {
            addCriterion("MSG_LEVEL is null");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELIsNotNull() {
            addCriterion("MSG_LEVEL is not null");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELEqualTo(String value) {
            addCriterion("MSG_LEVEL =", value, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELNotEqualTo(String value) {
            addCriterion("MSG_LEVEL <>", value, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELGreaterThan(String value) {
            addCriterion("MSG_LEVEL >", value, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELGreaterThanOrEqualTo(String value) {
            addCriterion("MSG_LEVEL >=", value, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELLessThan(String value) {
            addCriterion("MSG_LEVEL <", value, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELLessThanOrEqualTo(String value) {
            addCriterion("MSG_LEVEL <=", value, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELLike(String value) {
            addCriterion("MSG_LEVEL like", value, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELNotLike(String value) {
            addCriterion("MSG_LEVEL not like", value, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELIn(List<String> values) {
            addCriterion("MSG_LEVEL in", values, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELNotIn(List<String> values) {
            addCriterion("MSG_LEVEL not in", values, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELBetween(String value1, String value2) {
            addCriterion("MSG_LEVEL between", value1, value2, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELNotBetween(String value1, String value2) {
            addCriterion("MSG_LEVEL not between", value1, value2, "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNIsNull() {
            addCriterion("SYUTUDOU_YOUSEI_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNIsNotNull() {
            addCriterion("SYUTUDOU_YOUSEI_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNEqualTo(String value) {
            addCriterion("SYUTUDOU_YOUSEI_KBN =", value, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNNotEqualTo(String value) {
            addCriterion("SYUTUDOU_YOUSEI_KBN <>", value, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNGreaterThan(String value) {
            addCriterion("SYUTUDOU_YOUSEI_KBN >", value, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SYUTUDOU_YOUSEI_KBN >=", value, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNLessThan(String value) {
            addCriterion("SYUTUDOU_YOUSEI_KBN <", value, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNLessThanOrEqualTo(String value) {
            addCriterion("SYUTUDOU_YOUSEI_KBN <=", value, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNLike(String value) {
            addCriterion("SYUTUDOU_YOUSEI_KBN like", value, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNNotLike(String value) {
            addCriterion("SYUTUDOU_YOUSEI_KBN not like", value, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNIn(List<String> values) {
            addCriterion("SYUTUDOU_YOUSEI_KBN in", values, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNNotIn(List<String> values) {
            addCriterion("SYUTUDOU_YOUSEI_KBN not in", values, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNBetween(String value1, String value2) {
            addCriterion("SYUTUDOU_YOUSEI_KBN between", value1, value2, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNNotBetween(String value1, String value2) {
            addCriterion("SYUTUDOU_YOUSEI_KBN not between", value1, value2, "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMIsNull() {
            addCriterion("LASTUPD_NM is null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMIsNotNull() {
            addCriterion("LASTUPD_NM is not null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMEqualTo(String value) {
            addCriterion("LASTUPD_NM =", value, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMNotEqualTo(String value) {
            addCriterion("LASTUPD_NM <>", value, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMGreaterThan(String value) {
            addCriterion("LASTUPD_NM >", value, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMGreaterThanOrEqualTo(String value) {
            addCriterion("LASTUPD_NM >=", value, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMLessThan(String value) {
            addCriterion("LASTUPD_NM <", value, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMLessThanOrEqualTo(String value) {
            addCriterion("LASTUPD_NM <=", value, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMLike(String value) {
            addCriterion("LASTUPD_NM like", value, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMNotLike(String value) {
            addCriterion("LASTUPD_NM not like", value, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMIn(List<String> values) {
            addCriterion("LASTUPD_NM in", values, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMNotIn(List<String> values) {
            addCriterion("LASTUPD_NM not in", values, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMBetween(String value1, String value2) {
            addCriterion("LASTUPD_NM between", value1, value2, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMNotBetween(String value1, String value2) {
            addCriterion("LASTUPD_NM not between", value1, value2, "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTIsNull() {
            addCriterion("SINPO_SELECT is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTIsNotNull() {
            addCriterion("SINPO_SELECT is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTEqualTo(String value) {
            addCriterion("SINPO_SELECT =", value, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTNotEqualTo(String value) {
            addCriterion("SINPO_SELECT <>", value, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTGreaterThan(String value) {
            addCriterion("SINPO_SELECT >", value, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_SELECT >=", value, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTLessThan(String value) {
            addCriterion("SINPO_SELECT <", value, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTLessThanOrEqualTo(String value) {
            addCriterion("SINPO_SELECT <=", value, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTLike(String value) {
            addCriterion("SINPO_SELECT like", value, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTNotLike(String value) {
            addCriterion("SINPO_SELECT not like", value, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTIn(List<String> values) {
            addCriterion("SINPO_SELECT in", values, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTNotIn(List<String> values) {
            addCriterion("SINPO_SELECT not in", values, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTBetween(String value1, String value2) {
            addCriterion("SINPO_SELECT between", value1, value2, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTNotBetween(String value1, String value2) {
            addCriterion("SINPO_SELECT not between", value1, value2, "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKAIsNull() {
            addCriterion("SINPO_HOJO_KEKKA is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKAIsNotNull() {
            addCriterion("SINPO_HOJO_KEKKA is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKAEqualTo(String value) {
            addCriterion("SINPO_HOJO_KEKKA =", value, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKANotEqualTo(String value) {
            addCriterion("SINPO_HOJO_KEKKA <>", value, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKAGreaterThan(String value) {
            addCriterion("SINPO_HOJO_KEKKA >", value, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKAGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_HOJO_KEKKA >=", value, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKALessThan(String value) {
            addCriterion("SINPO_HOJO_KEKKA <", value, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKALessThanOrEqualTo(String value) {
            addCriterion("SINPO_HOJO_KEKKA <=", value, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKALike(String value) {
            addCriterion("SINPO_HOJO_KEKKA like", value, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKANotLike(String value) {
            addCriterion("SINPO_HOJO_KEKKA not like", value, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKAIn(List<String> values) {
            addCriterion("SINPO_HOJO_KEKKA in", values, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKANotIn(List<String> values) {
            addCriterion("SINPO_HOJO_KEKKA not in", values, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKABetween(String value1, String value2) {
            addCriterion("SINPO_HOJO_KEKKA between", value1, value2, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKANotBetween(String value1, String value2) {
            addCriterion("SINPO_HOJO_KEKKA not between", value1, value2, "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKAIsNull() {
            addCriterion("SINPO_KEKKA is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKAIsNotNull() {
            addCriterion("SINPO_KEKKA is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKAEqualTo(String value) {
            addCriterion("SINPO_KEKKA =", value, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKANotEqualTo(String value) {
            addCriterion("SINPO_KEKKA <>", value, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKAGreaterThan(String value) {
            addCriterion("SINPO_KEKKA >", value, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKAGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_KEKKA >=", value, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKALessThan(String value) {
            addCriterion("SINPO_KEKKA <", value, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKALessThanOrEqualTo(String value) {
            addCriterion("SINPO_KEKKA <=", value, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKALike(String value) {
            addCriterion("SINPO_KEKKA like", value, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKANotLike(String value) {
            addCriterion("SINPO_KEKKA not like", value, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKAIn(List<String> values) {
            addCriterion("SINPO_KEKKA in", values, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKANotIn(List<String> values) {
            addCriterion("SINPO_KEKKA not in", values, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKABetween(String value1, String value2) {
            addCriterion("SINPO_KEKKA between", value1, value2, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKANotBetween(String value1, String value2) {
            addCriterion("SINPO_KEKKA not between", value1, value2, "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGIsNull() {
            addCriterion("SINPO_MSG is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGIsNotNull() {
            addCriterion("SINPO_MSG is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGEqualTo(String value) {
            addCriterion("SINPO_MSG =", value, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGNotEqualTo(String value) {
            addCriterion("SINPO_MSG <>", value, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGGreaterThan(String value) {
            addCriterion("SINPO_MSG >", value, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_MSG >=", value, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGLessThan(String value) {
            addCriterion("SINPO_MSG <", value, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGLessThanOrEqualTo(String value) {
            addCriterion("SINPO_MSG <=", value, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGLike(String value) {
            addCriterion("SINPO_MSG like", value, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGNotLike(String value) {
            addCriterion("SINPO_MSG not like", value, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGIn(List<String> values) {
            addCriterion("SINPO_MSG in", values, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGNotIn(List<String> values) {
            addCriterion("SINPO_MSG not in", values, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGBetween(String value1, String value2) {
            addCriterion("SINPO_MSG between", value1, value2, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGNotBetween(String value1, String value2) {
            addCriterion("SINPO_MSG not between", value1, value2, "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUIsNull() {
            addCriterion("SINPO_REASON_NAIYOU is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUIsNotNull() {
            addCriterion("SINPO_REASON_NAIYOU is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUEqualTo(String value) {
            addCriterion("SINPO_REASON_NAIYOU =", value, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUNotEqualTo(String value) {
            addCriterion("SINPO_REASON_NAIYOU <>", value, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUGreaterThan(String value) {
            addCriterion("SINPO_REASON_NAIYOU >", value, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_REASON_NAIYOU >=", value, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOULessThan(String value) {
            addCriterion("SINPO_REASON_NAIYOU <", value, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOULessThanOrEqualTo(String value) {
            addCriterion("SINPO_REASON_NAIYOU <=", value, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOULike(String value) {
            addCriterion("SINPO_REASON_NAIYOU like", value, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUNotLike(String value) {
            addCriterion("SINPO_REASON_NAIYOU not like", value, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUIn(List<String> values) {
            addCriterion("SINPO_REASON_NAIYOU in", values, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUNotIn(List<String> values) {
            addCriterion("SINPO_REASON_NAIYOU not in", values, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUBetween(String value1, String value2) {
            addCriterion("SINPO_REASON_NAIYOU between", value1, value2, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOUNotBetween(String value1, String value2) {
            addCriterion("SINPO_REASON_NAIYOU not between", value1, value2, "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGIsNull() {
            addCriterion("SINPO_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGIsNotNull() {
            addCriterion("SINPO_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGEqualTo(String value) {
            addCriterion("SINPO_FLG =", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGNotEqualTo(String value) {
            addCriterion("SINPO_FLG <>", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGGreaterThan(String value) {
            addCriterion("SINPO_FLG >", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG >=", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGLessThan(String value) {
            addCriterion("SINPO_FLG <", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGLessThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG <=", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGLike(String value) {
            addCriterion("SINPO_FLG like", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGNotLike(String value) {
            addCriterion("SINPO_FLG not like", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGIn(List<String> values) {
            addCriterion("SINPO_FLG in", values, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGNotIn(List<String> values) {
            addCriterion("SINPO_FLG not in", values, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGBetween(String value1, String value2) {
            addCriterion("SINPO_FLG between", value1, value2, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGNotBetween(String value1, String value2) {
            addCriterion("SINPO_FLG not between", value1, value2, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGIsNull() {
            addCriterion("SINPO_REASON_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGIsNotNull() {
            addCriterion("SINPO_REASON_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGEqualTo(String value) {
            addCriterion("SINPO_REASON_FLG =", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGNotEqualTo(String value) {
            addCriterion("SINPO_REASON_FLG <>", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGGreaterThan(String value) {
            addCriterion("SINPO_REASON_FLG >", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_REASON_FLG >=", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGLessThan(String value) {
            addCriterion("SINPO_REASON_FLG <", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGLessThanOrEqualTo(String value) {
            addCriterion("SINPO_REASON_FLG <=", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGLike(String value) {
            addCriterion("SINPO_REASON_FLG like", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGNotLike(String value) {
            addCriterion("SINPO_REASON_FLG not like", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGIn(List<String> values) {
            addCriterion("SINPO_REASON_FLG in", values, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGNotIn(List<String> values) {
            addCriterion("SINPO_REASON_FLG not in", values, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGBetween(String value1, String value2) {
            addCriterion("SINPO_REASON_FLG between", value1, value2, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGNotBetween(String value1, String value2) {
            addCriterion("SINPO_REASON_FLG not between", value1, value2, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1IsNull() {
            addCriterion("SIG_KIND_1 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1IsNotNull() {
            addCriterion("SIG_KIND_1 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1EqualTo(String value) {
            addCriterion("SIG_KIND_1 =", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotEqualTo(String value) {
            addCriterion("SIG_KIND_1 <>", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1GreaterThan(String value) {
            addCriterion("SIG_KIND_1 >", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_1 >=", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LessThan(String value) {
            addCriterion("SIG_KIND_1 <", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_1 <=", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1Like(String value) {
            addCriterion("SIG_KIND_1 like", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotLike(String value) {
            addCriterion("SIG_KIND_1 not like", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1In(List<String> values) {
            addCriterion("SIG_KIND_1 in", values, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotIn(List<String> values) {
            addCriterion("SIG_KIND_1 not in", values, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1Between(String value1, String value2) {
            addCriterion("SIG_KIND_1 between", value1, value2, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_1 not between", value1, value2, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2IsNull() {
            addCriterion("SIG_KIND_2 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2IsNotNull() {
            addCriterion("SIG_KIND_2 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2EqualTo(String value) {
            addCriterion("SIG_KIND_2 =", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotEqualTo(String value) {
            addCriterion("SIG_KIND_2 <>", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2GreaterThan(String value) {
            addCriterion("SIG_KIND_2 >", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_2 >=", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LessThan(String value) {
            addCriterion("SIG_KIND_2 <", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_2 <=", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2Like(String value) {
            addCriterion("SIG_KIND_2 like", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotLike(String value) {
            addCriterion("SIG_KIND_2 not like", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2In(List<String> values) {
            addCriterion("SIG_KIND_2 in", values, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotIn(List<String> values) {
            addCriterion("SIG_KIND_2 not in", values, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2Between(String value1, String value2) {
            addCriterion("SIG_KIND_2 between", value1, value2, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_2 not between", value1, value2, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMIsNull() {
            addCriterion("EVENT_KIND_NM is null");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMIsNotNull() {
            addCriterion("EVENT_KIND_NM is not null");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMEqualTo(String value) {
            addCriterion("EVENT_KIND_NM =", value, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMNotEqualTo(String value) {
            addCriterion("EVENT_KIND_NM <>", value, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMGreaterThan(String value) {
            addCriterion("EVENT_KIND_NM >", value, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMGreaterThanOrEqualTo(String value) {
            addCriterion("EVENT_KIND_NM >=", value, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMLessThan(String value) {
            addCriterion("EVENT_KIND_NM <", value, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMLessThanOrEqualTo(String value) {
            addCriterion("EVENT_KIND_NM <=", value, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMLike(String value) {
            addCriterion("EVENT_KIND_NM like", value, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMNotLike(String value) {
            addCriterion("EVENT_KIND_NM not like", value, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMIn(List<String> values) {
            addCriterion("EVENT_KIND_NM in", values, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMNotIn(List<String> values) {
            addCriterion("EVENT_KIND_NM not in", values, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMBetween(String value1, String value2) {
            addCriterion("EVENT_KIND_NM between", value1, value2, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMNotBetween(String value1, String value2) {
            addCriterion("EVENT_KIND_NM not between", value1, value2, "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMIsNull() {
            addCriterion("SINPO_HANDAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMIsNotNull() {
            addCriterion("SINPO_HANDAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMEqualTo(Date value) {
            addCriterion("SINPO_HANDAN_TM =", value, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMNotEqualTo(Date value) {
            addCriterion("SINPO_HANDAN_TM <>", value, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMGreaterThan(Date value) {
            addCriterion("SINPO_HANDAN_TM >", value, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMGreaterThanOrEqualTo(Date value) {
            addCriterion("SINPO_HANDAN_TM >=", value, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMLessThan(Date value) {
            addCriterion("SINPO_HANDAN_TM <", value, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMLessThanOrEqualTo(Date value) {
            addCriterion("SINPO_HANDAN_TM <=", value, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMIn(List<Date> values) {
            addCriterion("SINPO_HANDAN_TM in", values, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMNotIn(List<Date> values) {
            addCriterion("SINPO_HANDAN_TM not in", values, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMBetween(Date value1, Date value2) {
            addCriterion("SINPO_HANDAN_TM between", value1, value2, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andSINPO_HANDAN_TMNotBetween(Date value1, Date value2) {
            addCriterion("SINPO_HANDAN_TM not between", value1, value2, "SINPO_HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMIsNull() {
            addCriterion("HANDAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMIsNotNull() {
            addCriterion("HANDAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMEqualTo(Date value) {
            addCriterion("HANDAN_TM =", value, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMNotEqualTo(Date value) {
            addCriterion("HANDAN_TM <>", value, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMGreaterThan(Date value) {
            addCriterion("HANDAN_TM >", value, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMGreaterThanOrEqualTo(Date value) {
            addCriterion("HANDAN_TM >=", value, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMLessThan(Date value) {
            addCriterion("HANDAN_TM <", value, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMLessThanOrEqualTo(Date value) {
            addCriterion("HANDAN_TM <=", value, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMIn(List<Date> values) {
            addCriterion("HANDAN_TM in", values, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMNotIn(List<Date> values) {
            addCriterion("HANDAN_TM not in", values, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMBetween(Date value1, Date value2) {
            addCriterion("HANDAN_TM between", value1, value2, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andHANDAN_TMNotBetween(Date value1, Date value2) {
            addCriterion("HANDAN_TM not between", value1, value2, "HANDAN_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMIsNull() {
            addCriterion("TOTAL_TM is null");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMIsNotNull() {
            addCriterion("TOTAL_TM is not null");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMEqualTo(Date value) {
            addCriterion("TOTAL_TM =", value, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMNotEqualTo(Date value) {
            addCriterion("TOTAL_TM <>", value, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMGreaterThan(Date value) {
            addCriterion("TOTAL_TM >", value, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMGreaterThanOrEqualTo(Date value) {
            addCriterion("TOTAL_TM >=", value, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMLessThan(Date value) {
            addCriterion("TOTAL_TM <", value, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMLessThanOrEqualTo(Date value) {
            addCriterion("TOTAL_TM <=", value, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMIn(List<Date> values) {
            addCriterion("TOTAL_TM in", values, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMNotIn(List<Date> values) {
            addCriterion("TOTAL_TM not in", values, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMBetween(Date value1, Date value2) {
            addCriterion("TOTAL_TM between", value1, value2, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andTOTAL_TMNotBetween(Date value1, Date value2) {
            addCriterion("TOTAL_TM not between", value1, value2, "TOTAL_TM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMIsNull() {
            addCriterion("JIGYOU_NM is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMIsNotNull() {
            addCriterion("JIGYOU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMEqualTo(String value) {
            addCriterion("JIGYOU_NM =", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMNotEqualTo(String value) {
            addCriterion("JIGYOU_NM <>", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMGreaterThan(String value) {
            addCriterion("JIGYOU_NM >", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOU_NM >=", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMLessThan(String value) {
            addCriterion("JIGYOU_NM <", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMLessThanOrEqualTo(String value) {
            addCriterion("JIGYOU_NM <=", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMLike(String value) {
            addCriterion("JIGYOU_NM like", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMNotLike(String value) {
            addCriterion("JIGYOU_NM not like", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMIn(List<String> values) {
            addCriterion("JIGYOU_NM in", values, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMNotIn(List<String> values) {
            addCriterion("JIGYOU_NM not in", values, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMBetween(String value1, String value2) {
            addCriterion("JIGYOU_NM between", value1, value2, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMNotBetween(String value1, String value2) {
            addCriterion("JIGYOU_NM not between", value1, value2, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIsNull() {
            addCriterion("USER_NM is null");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIsNotNull() {
            addCriterion("USER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUSER_NMEqualTo(String value) {
            addCriterion("USER_NM =", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotEqualTo(String value) {
            addCriterion("USER_NM <>", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMGreaterThan(String value) {
            addCriterion("USER_NM >", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("USER_NM >=", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLessThan(String value) {
            addCriterion("USER_NM <", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLessThanOrEqualTo(String value) {
            addCriterion("USER_NM <=", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLike(String value) {
            addCriterion("USER_NM like", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotLike(String value) {
            addCriterion("USER_NM not like", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIn(List<String> values) {
            addCriterion("USER_NM in", values, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotIn(List<String> values) {
            addCriterion("USER_NM not in", values, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMBetween(String value1, String value2) {
            addCriterion("USER_NM between", value1, value2, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotBetween(String value1, String value2) {
            addCriterion("USER_NM not between", value1, value2, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_SINPO_HANDANLikeInsensitive(String value) {
            addCriterion("upper(LN_SINPO_HANDAN) like", value.toUpperCase(), "LN_SINPO_HANDAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN) like", value.toUpperCase(), "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andMSG_LEVELLikeInsensitive(String value) {
            addCriterion("upper(MSG_LEVEL) like", value.toUpperCase(), "MSG_LEVEL");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_YOUSEI_KBNLikeInsensitive(String value) {
            addCriterion("upper(SYUTUDOU_YOUSEI_KBN) like", value.toUpperCase(), "SYUTUDOU_YOUSEI_KBN");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_NMLikeInsensitive(String value) {
            addCriterion("upper(LASTUPD_NM) like", value.toUpperCase(), "LASTUPD_NM");
            return (Criteria) this;
        }

        public Criteria andSINPO_SELECTLikeInsensitive(String value) {
            addCriterion("upper(SINPO_SELECT) like", value.toUpperCase(), "SINPO_SELECT");
            return (Criteria) this;
        }

        public Criteria andSINPO_HOJO_KEKKALikeInsensitive(String value) {
            addCriterion("upper(SINPO_HOJO_KEKKA) like", value.toUpperCase(), "SINPO_HOJO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_KEKKALikeInsensitive(String value) {
            addCriterion("upper(SINPO_KEKKA) like", value.toUpperCase(), "SINPO_KEKKA");
            return (Criteria) this;
        }

        public Criteria andSINPO_MSGLikeInsensitive(String value) {
            addCriterion("upper(SINPO_MSG) like", value.toUpperCase(), "SINPO_MSG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_NAIYOULikeInsensitive(String value) {
            addCriterion("upper(SINPO_REASON_NAIYOU) like", value.toUpperCase(), "SINPO_REASON_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGLikeInsensitive(String value) {
            addCriterion("upper(SINPO_FLG) like", value.toUpperCase(), "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGLikeInsensitive(String value) {
            addCriterion("upper(SINPO_REASON_FLG) like", value.toUpperCase(), "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_1) like", value.toUpperCase(), "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_2) like", value.toUpperCase(), "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andEVENT_KIND_NMLikeInsensitive(String value) {
            addCriterion("upper(EVENT_KIND_NM) like", value.toUpperCase(), "EVENT_KIND_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMLikeInsensitive(String value) {
            addCriterion("upper(JIGYOU_NM) like", value.toUpperCase(), "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLikeInsensitive(String value) {
            addCriterion("upper(USER_NM) like", value.toUpperCase(), "USER_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_SINPO_HANDAN_HTBL
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_SINPO_HANDAN_HTBL null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}