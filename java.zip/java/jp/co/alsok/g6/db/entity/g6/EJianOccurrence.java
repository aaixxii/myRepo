package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EJianOccurrence implements Serializable {
    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * お客様番号１
     */
    private String CUSTOMER_NUM1;

    /**
     * お客様番号２
     */
    private String CUSTOMER_NUM2;

    /**
     * お客様番号３
     */
    private String CUSTOMER_NUM3;

    /**
     * 地区
     */
    private String CHIKU;

    /**
     * 号機番号
     */
    private String GOUKI;

    /**
     * サブアドレス
     */
    private String SUBADDR;

    /**
     * 真報判断フラグ（システム）
     */
    private String SINPO_FLG1;

    /**
     * 真報判断フラグ（警備先）
     */
    private String SINPO_FLG2;

    /**
     * 真報判断フラグ（地区）
     */
    private String SINPO_FLG3;

    /**
     * 真報判断フラグ（任務区分）
     */
    private String SINPO_FLG4;

    /**
     * 重要顧客フラグ
     */
    private String IMPORTANT_FLG;

    /**
     * 契約先名
     */
    private String KEIYAKU_NM;

    /**
     * GC_ID
     */
    private String GC_ID;

    /**
     * エリアID
     */
    private String AREA_ID;

    /**
     * 警備先名１
     */
    private String KEIBI_NM1;

    /**
     * 警備先名２
     */
    private String KEIBI_NM2;

    /**
     * 警備先略称名称
     */
    private String KEIBISAKI_ABBR_NM;

    /**
     * 物件郵便番号
     */
    private String POST_NUM;

    /**
     * 都道府県_ID
     */
    private String ADDR_CD1_ID;

    /**
     * 市区町村コード_ID
     */
    private String ADDR_CD2_ID;

    /**
     * 大字町コード_ID
     */
    private String ADDR_CD3_ID;

    /**
     * 小字町コード_ID
     */
    private String ADDR_CD4_ID;

    /**
     * 所在地付記１
     */
    private String ADDRESS_OPT1;

    /**
     * 所在地付記２
     */
    private String ADDRESS_OPT2;

    /**
     * 契約種別１
     */
    private String KEIYAKU_KIND1;

    /**
     * 契約種別２
     */
    private String KEIYAKU_KIND2;

    /**
     * 警備開始予定日
     */
    private Date START_YOTEI_DATE;

    /**
     * 個別名称
     */
    private String KOBETU_NM;

    /**
     * 業務コード
     */
    private String GYOUMU_CD;

    /**
     * 補足コード
     */
    private String HOSOKU_CD;

    /**
     * 実施事業所_ID
     */
    private String JIGYO_JISSI_ID;

    /**
     * 受注事業所_ID
     */
    private String JIGYO_JYUTYU_ID;

    /**
     * 受注実績事業所_ID
     */
    private String JIGYO_JISSEKI_ID;

    /**
     * 請求事業所_ID
     */
    private String JIGYO_SEIKYU_ID;

    /**
     * 問合せ事業所_ID
     */
    private String JIGYO_TOIAWASE_ID;

    /**
     * 営業窓口事業所_ID
     */
    private String JIGYO_EIGYOU_ID;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_JIAN_OCCURRENCE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * お客様番号１
     * @return CUSTOMER_NUM1 お客様番号１
     */
    public String getCUSTOMER_NUM1() {
        return CUSTOMER_NUM1;
    }

    /**
     * お客様番号１
     * @param CUSTOMER_NUM1 お客様番号１
     */
    public void setCUSTOMER_NUM1(String CUSTOMER_NUM1) {
        this.CUSTOMER_NUM1 = CUSTOMER_NUM1 == null ? null : CUSTOMER_NUM1.trim();
    }

    /**
     * お客様番号２
     * @return CUSTOMER_NUM2 お客様番号２
     */
    public String getCUSTOMER_NUM2() {
        return CUSTOMER_NUM2;
    }

    /**
     * お客様番号２
     * @param CUSTOMER_NUM2 お客様番号２
     */
    public void setCUSTOMER_NUM2(String CUSTOMER_NUM2) {
        this.CUSTOMER_NUM2 = CUSTOMER_NUM2 == null ? null : CUSTOMER_NUM2.trim();
    }

    /**
     * お客様番号３
     * @return CUSTOMER_NUM3 お客様番号３
     */
    public String getCUSTOMER_NUM3() {
        return CUSTOMER_NUM3;
    }

    /**
     * お客様番号３
     * @param CUSTOMER_NUM3 お客様番号３
     */
    public void setCUSTOMER_NUM3(String CUSTOMER_NUM3) {
        this.CUSTOMER_NUM3 = CUSTOMER_NUM3 == null ? null : CUSTOMER_NUM3.trim();
    }

    /**
     * 地区
     * @return CHIKU 地区
     */
    public String getCHIKU() {
        return CHIKU;
    }

    /**
     * 地区
     * @param CHIKU 地区
     */
    public void setCHIKU(String CHIKU) {
        this.CHIKU = CHIKU == null ? null : CHIKU.trim();
    }

    /**
     * 号機番号
     * @return GOUKI 号機番号
     */
    public String getGOUKI() {
        return GOUKI;
    }

    /**
     * 号機番号
     * @param GOUKI 号機番号
     */
    public void setGOUKI(String GOUKI) {
        this.GOUKI = GOUKI == null ? null : GOUKI.trim();
    }

    /**
     * サブアドレス
     * @return SUBADDR サブアドレス
     */
    public String getSUBADDR() {
        return SUBADDR;
    }

    /**
     * サブアドレス
     * @param SUBADDR サブアドレス
     */
    public void setSUBADDR(String SUBADDR) {
        this.SUBADDR = SUBADDR == null ? null : SUBADDR.trim();
    }

    /**
     * 真報判断フラグ（システム）
     * @return SINPO_FLG1 真報判断フラグ（システム）
     */
    public String getSINPO_FLG1() {
        return SINPO_FLG1;
    }

    /**
     * 真報判断フラグ（システム）
     * @param SINPO_FLG1 真報判断フラグ（システム）
     */
    public void setSINPO_FLG1(String SINPO_FLG1) {
        this.SINPO_FLG1 = SINPO_FLG1 == null ? null : SINPO_FLG1.trim();
    }

    /**
     * 真報判断フラグ（警備先）
     * @return SINPO_FLG2 真報判断フラグ（警備先）
     */
    public String getSINPO_FLG2() {
        return SINPO_FLG2;
    }

    /**
     * 真報判断フラグ（警備先）
     * @param SINPO_FLG2 真報判断フラグ（警備先）
     */
    public void setSINPO_FLG2(String SINPO_FLG2) {
        this.SINPO_FLG2 = SINPO_FLG2 == null ? null : SINPO_FLG2.trim();
    }

    /**
     * 真報判断フラグ（地区）
     * @return SINPO_FLG3 真報判断フラグ（地区）
     */
    public String getSINPO_FLG3() {
        return SINPO_FLG3;
    }

    /**
     * 真報判断フラグ（地区）
     * @param SINPO_FLG3 真報判断フラグ（地区）
     */
    public void setSINPO_FLG3(String SINPO_FLG3) {
        this.SINPO_FLG3 = SINPO_FLG3 == null ? null : SINPO_FLG3.trim();
    }

    /**
     * 真報判断フラグ（任務区分）
     * @return SINPO_FLG4 真報判断フラグ（任務区分）
     */
    public String getSINPO_FLG4() {
        return SINPO_FLG4;
    }

    /**
     * 真報判断フラグ（任務区分）
     * @param SINPO_FLG4 真報判断フラグ（任務区分）
     */
    public void setSINPO_FLG4(String SINPO_FLG4) {
        this.SINPO_FLG4 = SINPO_FLG4 == null ? null : SINPO_FLG4.trim();
    }

    /**
     * 重要顧客フラグ
     * @return IMPORTANT_FLG 重要顧客フラグ
     */
    public String getIMPORTANT_FLG() {
        return IMPORTANT_FLG;
    }

    /**
     * 重要顧客フラグ
     * @param IMPORTANT_FLG 重要顧客フラグ
     */
    public void setIMPORTANT_FLG(String IMPORTANT_FLG) {
        this.IMPORTANT_FLG = IMPORTANT_FLG == null ? null : IMPORTANT_FLG.trim();
    }

    /**
     * 契約先名
     * @return KEIYAKU_NM 契約先名
     */
    public String getKEIYAKU_NM() {
        return KEIYAKU_NM;
    }

    /**
     * 契約先名
     * @param KEIYAKU_NM 契約先名
     */
    public void setKEIYAKU_NM(String KEIYAKU_NM) {
        this.KEIYAKU_NM = KEIYAKU_NM == null ? null : KEIYAKU_NM.trim();
    }

    /**
     * GC_ID
     * @return GC_ID GC_ID
     */
    public String getGC_ID() {
        return GC_ID;
    }

    /**
     * GC_ID
     * @param GC_ID GC_ID
     */
    public void setGC_ID(String GC_ID) {
        this.GC_ID = GC_ID == null ? null : GC_ID.trim();
    }

    /**
     * エリアID
     * @return AREA_ID エリアID
     */
    public String getAREA_ID() {
        return AREA_ID;
    }

    /**
     * エリアID
     * @param AREA_ID エリアID
     */
    public void setAREA_ID(String AREA_ID) {
        this.AREA_ID = AREA_ID == null ? null : AREA_ID.trim();
    }

    /**
     * 警備先名１
     * @return KEIBI_NM1 警備先名１
     */
    public String getKEIBI_NM1() {
        return KEIBI_NM1;
    }

    /**
     * 警備先名１
     * @param KEIBI_NM1 警備先名１
     */
    public void setKEIBI_NM1(String KEIBI_NM1) {
        this.KEIBI_NM1 = KEIBI_NM1 == null ? null : KEIBI_NM1.trim();
    }

    /**
     * 警備先名２
     * @return KEIBI_NM2 警備先名２
     */
    public String getKEIBI_NM2() {
        return KEIBI_NM2;
    }

    /**
     * 警備先名２
     * @param KEIBI_NM2 警備先名２
     */
    public void setKEIBI_NM2(String KEIBI_NM2) {
        this.KEIBI_NM2 = KEIBI_NM2 == null ? null : KEIBI_NM2.trim();
    }

    /**
     * 警備先略称名称
     * @return KEIBISAKI_ABBR_NM 警備先略称名称
     */
    public String getKEIBISAKI_ABBR_NM() {
        return KEIBISAKI_ABBR_NM;
    }

    /**
     * 警備先略称名称
     * @param KEIBISAKI_ABBR_NM 警備先略称名称
     */
    public void setKEIBISAKI_ABBR_NM(String KEIBISAKI_ABBR_NM) {
        this.KEIBISAKI_ABBR_NM = KEIBISAKI_ABBR_NM == null ? null : KEIBISAKI_ABBR_NM.trim();
    }

    /**
     * 物件郵便番号
     * @return POST_NUM 物件郵便番号
     */
    public String getPOST_NUM() {
        return POST_NUM;
    }

    /**
     * 物件郵便番号
     * @param POST_NUM 物件郵便番号
     */
    public void setPOST_NUM(String POST_NUM) {
        this.POST_NUM = POST_NUM == null ? null : POST_NUM.trim();
    }

    /**
     * 都道府県_ID
     * @return ADDR_CD1_ID 都道府県_ID
     */
    public String getADDR_CD1_ID() {
        return ADDR_CD1_ID;
    }

    /**
     * 都道府県_ID
     * @param ADDR_CD1_ID 都道府県_ID
     */
    public void setADDR_CD1_ID(String ADDR_CD1_ID) {
        this.ADDR_CD1_ID = ADDR_CD1_ID == null ? null : ADDR_CD1_ID.trim();
    }

    /**
     * 市区町村コード_ID
     * @return ADDR_CD2_ID 市区町村コード_ID
     */
    public String getADDR_CD2_ID() {
        return ADDR_CD2_ID;
    }

    /**
     * 市区町村コード_ID
     * @param ADDR_CD2_ID 市区町村コード_ID
     */
    public void setADDR_CD2_ID(String ADDR_CD2_ID) {
        this.ADDR_CD2_ID = ADDR_CD2_ID == null ? null : ADDR_CD2_ID.trim();
    }

    /**
     * 大字町コード_ID
     * @return ADDR_CD3_ID 大字町コード_ID
     */
    public String getADDR_CD3_ID() {
        return ADDR_CD3_ID;
    }

    /**
     * 大字町コード_ID
     * @param ADDR_CD3_ID 大字町コード_ID
     */
    public void setADDR_CD3_ID(String ADDR_CD3_ID) {
        this.ADDR_CD3_ID = ADDR_CD3_ID == null ? null : ADDR_CD3_ID.trim();
    }

    /**
     * 小字町コード_ID
     * @return ADDR_CD4_ID 小字町コード_ID
     */
    public String getADDR_CD4_ID() {
        return ADDR_CD4_ID;
    }

    /**
     * 小字町コード_ID
     * @param ADDR_CD4_ID 小字町コード_ID
     */
    public void setADDR_CD4_ID(String ADDR_CD4_ID) {
        this.ADDR_CD4_ID = ADDR_CD4_ID == null ? null : ADDR_CD4_ID.trim();
    }

    /**
     * 所在地付記１
     * @return ADDRESS_OPT1 所在地付記１
     */
    public String getADDRESS_OPT1() {
        return ADDRESS_OPT1;
    }

    /**
     * 所在地付記１
     * @param ADDRESS_OPT1 所在地付記１
     */
    public void setADDRESS_OPT1(String ADDRESS_OPT1) {
        this.ADDRESS_OPT1 = ADDRESS_OPT1 == null ? null : ADDRESS_OPT1.trim();
    }

    /**
     * 所在地付記２
     * @return ADDRESS_OPT2 所在地付記２
     */
    public String getADDRESS_OPT2() {
        return ADDRESS_OPT2;
    }

    /**
     * 所在地付記２
     * @param ADDRESS_OPT2 所在地付記２
     */
    public void setADDRESS_OPT2(String ADDRESS_OPT2) {
        this.ADDRESS_OPT2 = ADDRESS_OPT2 == null ? null : ADDRESS_OPT2.trim();
    }

    /**
     * 契約種別１
     * @return KEIYAKU_KIND1 契約種別１
     */
    public String getKEIYAKU_KIND1() {
        return KEIYAKU_KIND1;
    }

    /**
     * 契約種別１
     * @param KEIYAKU_KIND1 契約種別１
     */
    public void setKEIYAKU_KIND1(String KEIYAKU_KIND1) {
        this.KEIYAKU_KIND1 = KEIYAKU_KIND1 == null ? null : KEIYAKU_KIND1.trim();
    }

    /**
     * 契約種別２
     * @return KEIYAKU_KIND2 契約種別２
     */
    public String getKEIYAKU_KIND2() {
        return KEIYAKU_KIND2;
    }

    /**
     * 契約種別２
     * @param KEIYAKU_KIND2 契約種別２
     */
    public void setKEIYAKU_KIND2(String KEIYAKU_KIND2) {
        this.KEIYAKU_KIND2 = KEIYAKU_KIND2 == null ? null : KEIYAKU_KIND2.trim();
    }

    /**
     * 警備開始予定日
     * @return START_YOTEI_DATE 警備開始予定日
     */
    public Date getSTART_YOTEI_DATE() {
        return START_YOTEI_DATE;
    }

    /**
     * 警備開始予定日
     * @param START_YOTEI_DATE 警備開始予定日
     */
    public void setSTART_YOTEI_DATE(Date START_YOTEI_DATE) {
        this.START_YOTEI_DATE = START_YOTEI_DATE;
    }

    /**
     * 個別名称
     * @return KOBETU_NM 個別名称
     */
    public String getKOBETU_NM() {
        return KOBETU_NM;
    }

    /**
     * 個別名称
     * @param KOBETU_NM 個別名称
     */
    public void setKOBETU_NM(String KOBETU_NM) {
        this.KOBETU_NM = KOBETU_NM == null ? null : KOBETU_NM.trim();
    }

    /**
     * 業務コード
     * @return GYOUMU_CD 業務コード
     */
    public String getGYOUMU_CD() {
        return GYOUMU_CD;
    }

    /**
     * 業務コード
     * @param GYOUMU_CD 業務コード
     */
    public void setGYOUMU_CD(String GYOUMU_CD) {
        this.GYOUMU_CD = GYOUMU_CD == null ? null : GYOUMU_CD.trim();
    }

    /**
     * 補足コード
     * @return HOSOKU_CD 補足コード
     */
    public String getHOSOKU_CD() {
        return HOSOKU_CD;
    }

    /**
     * 補足コード
     * @param HOSOKU_CD 補足コード
     */
    public void setHOSOKU_CD(String HOSOKU_CD) {
        this.HOSOKU_CD = HOSOKU_CD == null ? null : HOSOKU_CD.trim();
    }

    /**
     * 実施事業所_ID
     * @return JIGYO_JISSI_ID 実施事業所_ID
     */
    public String getJIGYO_JISSI_ID() {
        return JIGYO_JISSI_ID;
    }

    /**
     * 実施事業所_ID
     * @param JIGYO_JISSI_ID 実施事業所_ID
     */
    public void setJIGYO_JISSI_ID(String JIGYO_JISSI_ID) {
        this.JIGYO_JISSI_ID = JIGYO_JISSI_ID == null ? null : JIGYO_JISSI_ID.trim();
    }

    /**
     * 受注事業所_ID
     * @return JIGYO_JYUTYU_ID 受注事業所_ID
     */
    public String getJIGYO_JYUTYU_ID() {
        return JIGYO_JYUTYU_ID;
    }

    /**
     * 受注事業所_ID
     * @param JIGYO_JYUTYU_ID 受注事業所_ID
     */
    public void setJIGYO_JYUTYU_ID(String JIGYO_JYUTYU_ID) {
        this.JIGYO_JYUTYU_ID = JIGYO_JYUTYU_ID == null ? null : JIGYO_JYUTYU_ID.trim();
    }

    /**
     * 受注実績事業所_ID
     * @return JIGYO_JISSEKI_ID 受注実績事業所_ID
     */
    public String getJIGYO_JISSEKI_ID() {
        return JIGYO_JISSEKI_ID;
    }

    /**
     * 受注実績事業所_ID
     * @param JIGYO_JISSEKI_ID 受注実績事業所_ID
     */
    public void setJIGYO_JISSEKI_ID(String JIGYO_JISSEKI_ID) {
        this.JIGYO_JISSEKI_ID = JIGYO_JISSEKI_ID == null ? null : JIGYO_JISSEKI_ID.trim();
    }

    /**
     * 請求事業所_ID
     * @return JIGYO_SEIKYU_ID 請求事業所_ID
     */
    public String getJIGYO_SEIKYU_ID() {
        return JIGYO_SEIKYU_ID;
    }

    /**
     * 請求事業所_ID
     * @param JIGYO_SEIKYU_ID 請求事業所_ID
     */
    public void setJIGYO_SEIKYU_ID(String JIGYO_SEIKYU_ID) {
        this.JIGYO_SEIKYU_ID = JIGYO_SEIKYU_ID == null ? null : JIGYO_SEIKYU_ID.trim();
    }

    /**
     * 問合せ事業所_ID
     * @return JIGYO_TOIAWASE_ID 問合せ事業所_ID
     */
    public String getJIGYO_TOIAWASE_ID() {
        return JIGYO_TOIAWASE_ID;
    }

    /**
     * 問合せ事業所_ID
     * @param JIGYO_TOIAWASE_ID 問合せ事業所_ID
     */
    public void setJIGYO_TOIAWASE_ID(String JIGYO_TOIAWASE_ID) {
        this.JIGYO_TOIAWASE_ID = JIGYO_TOIAWASE_ID == null ? null : JIGYO_TOIAWASE_ID.trim();
    }

    /**
     * 営業窓口事業所_ID
     * @return JIGYO_EIGYOU_ID 営業窓口事業所_ID
     */
    public String getJIGYO_EIGYOU_ID() {
        return JIGYO_EIGYOU_ID;
    }

    /**
     * 営業窓口事業所_ID
     * @param JIGYO_EIGYOU_ID 営業窓口事業所_ID
     */
    public void setJIGYO_EIGYOU_ID(String JIGYO_EIGYOU_ID) {
        this.JIGYO_EIGYOU_ID = JIGYO_EIGYOU_ID == null ? null : JIGYO_EIGYOU_ID.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}