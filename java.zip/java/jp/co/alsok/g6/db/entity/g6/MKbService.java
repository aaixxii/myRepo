package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MKbService implements Serializable {
    /**
     * 警備サービス種別コード
     */
    private String KB_SERVICE_CD;

    /**
     * 警備サービス種別名称
     */
    private String KB_SERVICE_NM;

    /**
     * GC送信フラグ
     */
    private String GC_SEND_FLG;

    /**
     * WEB利用可否フラグ
     */
    private String WEB_USABLE_FLG;

    /**
     * M_KB_SERVICE
     */
    private static final long serialVersionUID = 1L;

    /**
     * 警備サービス種別コード
     * @return KB_SERVICE_CD 警備サービス種別コード
     */
    public String getKB_SERVICE_CD() {
        return KB_SERVICE_CD;
    }

    /**
     * 警備サービス種別コード
     * @param KB_SERVICE_CD 警備サービス種別コード
     */
    public void setKB_SERVICE_CD(String KB_SERVICE_CD) {
        this.KB_SERVICE_CD = KB_SERVICE_CD == null ? null : KB_SERVICE_CD.trim();
    }

    /**
     * 警備サービス種別名称
     * @return KB_SERVICE_NM 警備サービス種別名称
     */
    public String getKB_SERVICE_NM() {
        return KB_SERVICE_NM;
    }

    /**
     * 警備サービス種別名称
     * @param KB_SERVICE_NM 警備サービス種別名称
     */
    public void setKB_SERVICE_NM(String KB_SERVICE_NM) {
        this.KB_SERVICE_NM = KB_SERVICE_NM == null ? null : KB_SERVICE_NM.trim();
    }

    /**
     * GC送信フラグ
     * @return GC_SEND_FLG GC送信フラグ
     */
    public String getGC_SEND_FLG() {
        return GC_SEND_FLG;
    }

    /**
     * GC送信フラグ
     * @param GC_SEND_FLG GC送信フラグ
     */
    public void setGC_SEND_FLG(String GC_SEND_FLG) {
        this.GC_SEND_FLG = GC_SEND_FLG == null ? null : GC_SEND_FLG.trim();
    }

    /**
     * WEB利用可否フラグ
     * @return WEB_USABLE_FLG WEB利用可否フラグ
     */
    public String getWEB_USABLE_FLG() {
        return WEB_USABLE_FLG;
    }

    /**
     * WEB利用可否フラグ
     * @param WEB_USABLE_FLG WEB利用可否フラグ
     */
    public void setWEB_USABLE_FLG(String WEB_USABLE_FLG) {
        this.WEB_USABLE_FLG = WEB_USABLE_FLG == null ? null : WEB_USABLE_FLG.trim();
    }
}