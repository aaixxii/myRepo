package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EV6GamKubunMst implements Serializable {
    /**
     * 画面登録区分コード
     */
    private String KUBUN_CD;

    /**
     * 信号種別
     */
    private String SIG_KIND;

    /**
     * LN_信号種別論理番号
     */
    private String LN_SIGSYUBF;

    /**
     * GC番号
     */
    private String GC_NUM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_V6_GAM_KUBUN_MST
     */
    private static final long serialVersionUID = 1L;

    /**
     * 画面登録区分コード
     * @return KUBUN_CD 画面登録区分コード
     */
    public String getKUBUN_CD() {
        return KUBUN_CD;
    }

    /**
     * 画面登録区分コード
     * @param KUBUN_CD 画面登録区分コード
     */
    public void setKUBUN_CD(String KUBUN_CD) {
        this.KUBUN_CD = KUBUN_CD == null ? null : KUBUN_CD.trim();
    }

    /**
     * 信号種別
     * @return SIG_KIND 信号種別
     */
    public String getSIG_KIND() {
        return SIG_KIND;
    }

    /**
     * 信号種別
     * @param SIG_KIND 信号種別
     */
    public void setSIG_KIND(String SIG_KIND) {
        this.SIG_KIND = SIG_KIND == null ? null : SIG_KIND.trim();
    }

    /**
     * LN_信号種別論理番号
     * @return LN_SIGSYUBF LN_信号種別論理番号
     */
    public String getLN_SIGSYUBF() {
        return LN_SIGSYUBF;
    }

    /**
     * LN_信号種別論理番号
     * @param LN_SIGSYUBF LN_信号種別論理番号
     */
    public void setLN_SIGSYUBF(String LN_SIGSYUBF) {
        this.LN_SIGSYUBF = LN_SIGSYUBF == null ? null : LN_SIGSYUBF.trim();
    }

    /**
     * GC番号
     * @return GC_NUM GC番号
     */
    public String getGC_NUM() {
        return GC_NUM;
    }

    /**
     * GC番号
     * @param GC_NUM GC番号
     */
    public void setGC_NUM(String GC_NUM) {
        this.GC_NUM = GC_NUM == null ? null : GC_NUM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}