package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MMlKindExample {
    /**
     * M_ML_KIND
     */
    protected String orderByClause;

    /**
     * M_ML_KIND
     */
    protected boolean distinct;

    /**
     * M_ML_KIND
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MMlKindExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_ML_KIND null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andKB_SERVICE_CDIsNull() {
            addCriterion("KB_SERVICE_CD is null");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDIsNotNull() {
            addCriterion("KB_SERVICE_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDEqualTo(String value) {
            addCriterion("KB_SERVICE_CD =", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDNotEqualTo(String value) {
            addCriterion("KB_SERVICE_CD <>", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDGreaterThan(String value) {
            addCriterion("KB_SERVICE_CD >", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KB_SERVICE_CD >=", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDLessThan(String value) {
            addCriterion("KB_SERVICE_CD <", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDLessThanOrEqualTo(String value) {
            addCriterion("KB_SERVICE_CD <=", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDLike(String value) {
            addCriterion("KB_SERVICE_CD like", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDNotLike(String value) {
            addCriterion("KB_SERVICE_CD not like", value, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDIn(List<String> values) {
            addCriterion("KB_SERVICE_CD in", values, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDNotIn(List<String> values) {
            addCriterion("KB_SERVICE_CD not in", values, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDBetween(String value1, String value2) {
            addCriterion("KB_SERVICE_CD between", value1, value2, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDNotBetween(String value1, String value2) {
            addCriterion("KB_SERVICE_CD not between", value1, value2, "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1IsNull() {
            addCriterion("SIG_KIND1 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1IsNotNull() {
            addCriterion("SIG_KIND1 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1EqualTo(String value) {
            addCriterion("SIG_KIND1 =", value, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1NotEqualTo(String value) {
            addCriterion("SIG_KIND1 <>", value, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1GreaterThan(String value) {
            addCriterion("SIG_KIND1 >", value, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND1 >=", value, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1LessThan(String value) {
            addCriterion("SIG_KIND1 <", value, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND1 <=", value, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1Like(String value) {
            addCriterion("SIG_KIND1 like", value, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1NotLike(String value) {
            addCriterion("SIG_KIND1 not like", value, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1In(List<String> values) {
            addCriterion("SIG_KIND1 in", values, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1NotIn(List<String> values) {
            addCriterion("SIG_KIND1 not in", values, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1Between(String value1, String value2) {
            addCriterion("SIG_KIND1 between", value1, value2, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND1 not between", value1, value2, "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2IsNull() {
            addCriterion("SIG_KIND2 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2IsNotNull() {
            addCriterion("SIG_KIND2 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2EqualTo(String value) {
            addCriterion("SIG_KIND2 =", value, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2NotEqualTo(String value) {
            addCriterion("SIG_KIND2 <>", value, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2GreaterThan(String value) {
            addCriterion("SIG_KIND2 >", value, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND2 >=", value, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2LessThan(String value) {
            addCriterion("SIG_KIND2 <", value, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND2 <=", value, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2Like(String value) {
            addCriterion("SIG_KIND2 like", value, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2NotLike(String value) {
            addCriterion("SIG_KIND2 not like", value, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2In(List<String> values) {
            addCriterion("SIG_KIND2 in", values, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2NotIn(List<String> values) {
            addCriterion("SIG_KIND2 not in", values, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2Between(String value1, String value2) {
            addCriterion("SIG_KIND2 between", value1, value2, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND2 not between", value1, value2, "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andML_KINDIsNull() {
            addCriterion("ML_KIND is null");
            return (Criteria) this;
        }

        public Criteria andML_KINDIsNotNull() {
            addCriterion("ML_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andML_KINDEqualTo(String value) {
            addCriterion("ML_KIND =", value, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDNotEqualTo(String value) {
            addCriterion("ML_KIND <>", value, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDGreaterThan(String value) {
            addCriterion("ML_KIND >", value, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("ML_KIND >=", value, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDLessThan(String value) {
            addCriterion("ML_KIND <", value, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDLessThanOrEqualTo(String value) {
            addCriterion("ML_KIND <=", value, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDLike(String value) {
            addCriterion("ML_KIND like", value, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDNotLike(String value) {
            addCriterion("ML_KIND not like", value, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDIn(List<String> values) {
            addCriterion("ML_KIND in", values, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDNotIn(List<String> values) {
            addCriterion("ML_KIND not in", values, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDBetween(String value1, String value2) {
            addCriterion("ML_KIND between", value1, value2, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andML_KINDNotBetween(String value1, String value2) {
            addCriterion("ML_KIND not between", value1, value2, "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDIsNull() {
            addCriterion("KEIHO_NAME_CD is null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDIsNotNull() {
            addCriterion("KEIHO_NAME_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDEqualTo(String value) {
            addCriterion("KEIHO_NAME_CD =", value, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDNotEqualTo(String value) {
            addCriterion("KEIHO_NAME_CD <>", value, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDGreaterThan(String value) {
            addCriterion("KEIHO_NAME_CD >", value, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHO_NAME_CD >=", value, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDLessThan(String value) {
            addCriterion("KEIHO_NAME_CD <", value, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDLessThanOrEqualTo(String value) {
            addCriterion("KEIHO_NAME_CD <=", value, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDLike(String value) {
            addCriterion("KEIHO_NAME_CD like", value, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDNotLike(String value) {
            addCriterion("KEIHO_NAME_CD not like", value, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDIn(List<String> values) {
            addCriterion("KEIHO_NAME_CD in", values, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDNotIn(List<String> values) {
            addCriterion("KEIHO_NAME_CD not in", values, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDBetween(String value1, String value2) {
            addCriterion("KEIHO_NAME_CD between", value1, value2, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDNotBetween(String value1, String value2) {
            addCriterion("KEIHO_NAME_CD not between", value1, value2, "KEIHO_NAME_CD");
            return (Criteria) this;
        }

        public Criteria andKB_SERVICE_CDLikeInsensitive(String value) {
            addCriterion("upper(KB_SERVICE_CD) like", value.toUpperCase(), "KB_SERVICE_CD");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND1LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND1) like", value.toUpperCase(), "SIG_KIND1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND2LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND2) like", value.toUpperCase(), "SIG_KIND2");
            return (Criteria) this;
        }

        public Criteria andML_KINDLikeInsensitive(String value) {
            addCriterion("upper(ML_KIND) like", value.toUpperCase(), "ML_KIND");
            return (Criteria) this;
        }

        public Criteria andKEIHO_NAME_CDLikeInsensitive(String value) {
            addCriterion("upper(KEIHO_NAME_CD) like", value.toUpperCase(), "KEIHO_NAME_CD");
            return (Criteria) this;
        }
    }

    /**
     * M_ML_KIND
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_ML_KIND null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}