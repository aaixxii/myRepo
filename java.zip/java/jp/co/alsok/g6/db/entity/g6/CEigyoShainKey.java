package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CEigyoShainKey implements Serializable {
    /**
     * 会社コード
     */
    private String KAISHA_CD;

    /**
     * 社員番号
     */
    private String SHAIN_NO;

    /**
     * C_EIGYO_SHAIN
     */
    private static final long serialVersionUID = 1L;

    /**
     * 会社コード
     * @return KAISHA_CD 会社コード
     */
    public String getKAISHA_CD() {
        return KAISHA_CD;
    }

    /**
     * 会社コード
     * @param KAISHA_CD 会社コード
     */
    public void setKAISHA_CD(String KAISHA_CD) {
        this.KAISHA_CD = KAISHA_CD == null ? null : KAISHA_CD.trim();
    }

    /**
     * 社員番号
     * @return SHAIN_NO 社員番号
     */
    public String getSHAIN_NO() {
        return SHAIN_NO;
    }

    /**
     * 社員番号
     * @param SHAIN_NO 社員番号
     */
    public void setSHAIN_NO(String SHAIN_NO) {
        this.SHAIN_NO = SHAIN_NO == null ? null : SHAIN_NO.trim();
    }
}