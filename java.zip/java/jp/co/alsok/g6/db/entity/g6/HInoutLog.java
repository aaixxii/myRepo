package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HInoutLog implements Serializable {
    /**
     * LN_出入管理情報履歴論理番号
     */
    private String LN_INOUT_LOG;

    /**
     * 発生日時
     */
    private Date HASSEI_TS;

    /**
     * 警備先名称
     */
    private String KEIBI_NM;

    /**
     * 地区名称
     */
    private String SD_KOBETU_NM;

    /**
     * 入室先部屋名称
     */
    private String ROOM_NM;

    /**
     * 入室前部屋名称
     */
    private String PRE_ROOM_NM;

    /**
     * カード番号
     */
    private String KOKUIN_NUM;

    /**
     * 氏名
     */
    private String USER_NM;

    /**
     * 部署
     */
    private String DEPA_NM;

    /**
     * 役職
     */
    private String POSI_NM;

    /**
     * 画像利用フラグ
     */
    private String GAZO_USE_FLG;

    /**
     * 出入り画像ファイル情報
     */
    private String GAZO_FILE_PATH;

    /**
     * 履歴種別
     */
    private String HIST_KIND;

    /**
     * 履歴名称
     */
    private String HIST_NM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_INOUT_LOG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_出入管理情報履歴論理番号
     * @return LN_INOUT_LOG LN_出入管理情報履歴論理番号
     */
    public String getLN_INOUT_LOG() {
        return LN_INOUT_LOG;
    }

    /**
     * LN_出入管理情報履歴論理番号
     * @param LN_INOUT_LOG LN_出入管理情報履歴論理番号
     */
    public void setLN_INOUT_LOG(String LN_INOUT_LOG) {
        this.LN_INOUT_LOG = LN_INOUT_LOG == null ? null : LN_INOUT_LOG.trim();
    }

    /**
     * 発生日時
     * @return HASSEI_TS 発生日時
     */
    public Date getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 発生日時
     * @param HASSEI_TS 発生日時
     */
    public void setHASSEI_TS(Date HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS;
    }

    /**
     * 警備先名称
     * @return KEIBI_NM 警備先名称
     */
    public String getKEIBI_NM() {
        return KEIBI_NM;
    }

    /**
     * 警備先名称
     * @param KEIBI_NM 警備先名称
     */
    public void setKEIBI_NM(String KEIBI_NM) {
        this.KEIBI_NM = KEIBI_NM == null ? null : KEIBI_NM.trim();
    }

    /**
     * 地区名称
     * @return SD_KOBETU_NM 地区名称
     */
    public String getSD_KOBETU_NM() {
        return SD_KOBETU_NM;
    }

    /**
     * 地区名称
     * @param SD_KOBETU_NM 地区名称
     */
    public void setSD_KOBETU_NM(String SD_KOBETU_NM) {
        this.SD_KOBETU_NM = SD_KOBETU_NM == null ? null : SD_KOBETU_NM.trim();
    }

    /**
     * 入室先部屋名称
     * @return ROOM_NM 入室先部屋名称
     */
    public String getROOM_NM() {
        return ROOM_NM;
    }

    /**
     * 入室先部屋名称
     * @param ROOM_NM 入室先部屋名称
     */
    public void setROOM_NM(String ROOM_NM) {
        this.ROOM_NM = ROOM_NM == null ? null : ROOM_NM.trim();
    }

    /**
     * 入室前部屋名称
     * @return PRE_ROOM_NM 入室前部屋名称
     */
    public String getPRE_ROOM_NM() {
        return PRE_ROOM_NM;
    }

    /**
     * 入室前部屋名称
     * @param PRE_ROOM_NM 入室前部屋名称
     */
    public void setPRE_ROOM_NM(String PRE_ROOM_NM) {
        this.PRE_ROOM_NM = PRE_ROOM_NM == null ? null : PRE_ROOM_NM.trim();
    }

    /**
     * カード番号
     * @return KOKUIN_NUM カード番号
     */
    public String getKOKUIN_NUM() {
        return KOKUIN_NUM;
    }

    /**
     * カード番号
     * @param KOKUIN_NUM カード番号
     */
    public void setKOKUIN_NUM(String KOKUIN_NUM) {
        this.KOKUIN_NUM = KOKUIN_NUM == null ? null : KOKUIN_NUM.trim();
    }

    /**
     * 氏名
     * @return USER_NM 氏名
     */
    public String getUSER_NM() {
        return USER_NM;
    }

    /**
     * 氏名
     * @param USER_NM 氏名
     */
    public void setUSER_NM(String USER_NM) {
        this.USER_NM = USER_NM == null ? null : USER_NM.trim();
    }

    /**
     * 部署
     * @return DEPA_NM 部署
     */
    public String getDEPA_NM() {
        return DEPA_NM;
    }

    /**
     * 部署
     * @param DEPA_NM 部署
     */
    public void setDEPA_NM(String DEPA_NM) {
        this.DEPA_NM = DEPA_NM == null ? null : DEPA_NM.trim();
    }

    /**
     * 役職
     * @return POSI_NM 役職
     */
    public String getPOSI_NM() {
        return POSI_NM;
    }

    /**
     * 役職
     * @param POSI_NM 役職
     */
    public void setPOSI_NM(String POSI_NM) {
        this.POSI_NM = POSI_NM == null ? null : POSI_NM.trim();
    }

    /**
     * 画像利用フラグ
     * @return GAZO_USE_FLG 画像利用フラグ
     */
    public String getGAZO_USE_FLG() {
        return GAZO_USE_FLG;
    }

    /**
     * 画像利用フラグ
     * @param GAZO_USE_FLG 画像利用フラグ
     */
    public void setGAZO_USE_FLG(String GAZO_USE_FLG) {
        this.GAZO_USE_FLG = GAZO_USE_FLG == null ? null : GAZO_USE_FLG.trim();
    }

    /**
     * 出入り画像ファイル情報
     * @return GAZO_FILE_PATH 出入り画像ファイル情報
     */
    public String getGAZO_FILE_PATH() {
        return GAZO_FILE_PATH;
    }

    /**
     * 出入り画像ファイル情報
     * @param GAZO_FILE_PATH 出入り画像ファイル情報
     */
    public void setGAZO_FILE_PATH(String GAZO_FILE_PATH) {
        this.GAZO_FILE_PATH = GAZO_FILE_PATH == null ? null : GAZO_FILE_PATH.trim();
    }

    /**
     * 履歴種別
     * @return HIST_KIND 履歴種別
     */
    public String getHIST_KIND() {
        return HIST_KIND;
    }

    /**
     * 履歴種別
     * @param HIST_KIND 履歴種別
     */
    public void setHIST_KIND(String HIST_KIND) {
        this.HIST_KIND = HIST_KIND == null ? null : HIST_KIND.trim();
    }

    /**
     * 履歴名称
     * @return HIST_NM 履歴名称
     */
    public String getHIST_NM() {
        return HIST_NM;
    }

    /**
     * 履歴名称
     * @param HIST_NM 履歴名称
     */
    public void setHIST_NM(String HIST_NM) {
        this.HIST_NM = HIST_NM == null ? null : HIST_NM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}