package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HErrInf implements Serializable {
    /**
     * LN_エラー情報履歴論理番号
     */
    private String LN_ERR_INF;

    /**
     * 受信日時
     */
    private Date RCV_TS;

    /**
     * 発生時刻
     */
    private Date HASSEI_TS;

    /**
     * ホスト名
     */
    private String HOST_NM;

    /**
     * 処理ID
     */
    private String SYORI_ID;

    /**
     * エラーID
     */
    private String ERR_ID;

    /**
     * GC番号
     */
    private String GC_NUM;

    /**
     * 実施GC番号
     */
    private String JISSI_GC_NUM;

    /**
     * 契約種別２（CD）
     */
    private String KEIYAKU_KIND2_CD;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * 号機番号
     */
    private String GOUKI;

    /**
     * 地区番号
     */
    private String CHIKU_NUM;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * エラーレベル
     */
    private String ERR_LVL;

    /**
     * エラー名称
     */
    private String ERR_NM;

    /**
     * 対処名称
     */
    private String RECOVER_MSG_NM;

    /**
     * 備考
     */
    private String BIKOU;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_ERR_INF
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_エラー情報履歴論理番号
     * @return LN_ERR_INF LN_エラー情報履歴論理番号
     */
    public String getLN_ERR_INF() {
        return LN_ERR_INF;
    }

    /**
     * LN_エラー情報履歴論理番号
     * @param LN_ERR_INF LN_エラー情報履歴論理番号
     */
    public void setLN_ERR_INF(String LN_ERR_INF) {
        this.LN_ERR_INF = LN_ERR_INF == null ? null : LN_ERR_INF.trim();
    }

    /**
     * 受信日時
     * @return RCV_TS 受信日時
     */
    public Date getRCV_TS() {
        return RCV_TS;
    }

    /**
     * 受信日時
     * @param RCV_TS 受信日時
     */
    public void setRCV_TS(Date RCV_TS) {
        this.RCV_TS = RCV_TS;
    }

    /**
     * 発生時刻
     * @return HASSEI_TS 発生時刻
     */
    public Date getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 発生時刻
     * @param HASSEI_TS 発生時刻
     */
    public void setHASSEI_TS(Date HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS;
    }

    /**
     * ホスト名
     * @return HOST_NM ホスト名
     */
    public String getHOST_NM() {
        return HOST_NM;
    }

    /**
     * ホスト名
     * @param HOST_NM ホスト名
     */
    public void setHOST_NM(String HOST_NM) {
        this.HOST_NM = HOST_NM == null ? null : HOST_NM.trim();
    }

    /**
     * 処理ID
     * @return SYORI_ID 処理ID
     */
    public String getSYORI_ID() {
        return SYORI_ID;
    }

    /**
     * 処理ID
     * @param SYORI_ID 処理ID
     */
    public void setSYORI_ID(String SYORI_ID) {
        this.SYORI_ID = SYORI_ID == null ? null : SYORI_ID.trim();
    }

    /**
     * エラーID
     * @return ERR_ID エラーID
     */
    public String getERR_ID() {
        return ERR_ID;
    }

    /**
     * エラーID
     * @param ERR_ID エラーID
     */
    public void setERR_ID(String ERR_ID) {
        this.ERR_ID = ERR_ID == null ? null : ERR_ID.trim();
    }

    /**
     * GC番号
     * @return GC_NUM GC番号
     */
    public String getGC_NUM() {
        return GC_NUM;
    }

    /**
     * GC番号
     * @param GC_NUM GC番号
     */
    public void setGC_NUM(String GC_NUM) {
        this.GC_NUM = GC_NUM == null ? null : GC_NUM.trim();
    }

    /**
     * 実施GC番号
     * @return JISSI_GC_NUM 実施GC番号
     */
    public String getJISSI_GC_NUM() {
        return JISSI_GC_NUM;
    }

    /**
     * 実施GC番号
     * @param JISSI_GC_NUM 実施GC番号
     */
    public void setJISSI_GC_NUM(String JISSI_GC_NUM) {
        this.JISSI_GC_NUM = JISSI_GC_NUM == null ? null : JISSI_GC_NUM.trim();
    }

    /**
     * 契約種別２（CD）
     * @return KEIYAKU_KIND2_CD 契約種別２（CD）
     */
    public String getKEIYAKU_KIND2_CD() {
        return KEIYAKU_KIND2_CD;
    }

    /**
     * 契約種別２（CD）
     * @param KEIYAKU_KIND2_CD 契約種別２（CD）
     */
    public void setKEIYAKU_KIND2_CD(String KEIYAKU_KIND2_CD) {
        this.KEIYAKU_KIND2_CD = KEIYAKU_KIND2_CD == null ? null : KEIYAKU_KIND2_CD.trim();
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * 号機番号
     * @return GOUKI 号機番号
     */
    public String getGOUKI() {
        return GOUKI;
    }

    /**
     * 号機番号
     * @param GOUKI 号機番号
     */
    public void setGOUKI(String GOUKI) {
        this.GOUKI = GOUKI == null ? null : GOUKI.trim();
    }

    /**
     * 地区番号
     * @return CHIKU_NUM 地区番号
     */
    public String getCHIKU_NUM() {
        return CHIKU_NUM;
    }

    /**
     * 地区番号
     * @param CHIKU_NUM 地区番号
     */
    public void setCHIKU_NUM(String CHIKU_NUM) {
        this.CHIKU_NUM = CHIKU_NUM == null ? null : CHIKU_NUM.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * エラーレベル
     * @return ERR_LVL エラーレベル
     */
    public String getERR_LVL() {
        return ERR_LVL;
    }

    /**
     * エラーレベル
     * @param ERR_LVL エラーレベル
     */
    public void setERR_LVL(String ERR_LVL) {
        this.ERR_LVL = ERR_LVL == null ? null : ERR_LVL.trim();
    }

    /**
     * エラー名称
     * @return ERR_NM エラー名称
     */
    public String getERR_NM() {
        return ERR_NM;
    }

    /**
     * エラー名称
     * @param ERR_NM エラー名称
     */
    public void setERR_NM(String ERR_NM) {
        this.ERR_NM = ERR_NM == null ? null : ERR_NM.trim();
    }

    /**
     * 対処名称
     * @return RECOVER_MSG_NM 対処名称
     */
    public String getRECOVER_MSG_NM() {
        return RECOVER_MSG_NM;
    }

    /**
     * 対処名称
     * @param RECOVER_MSG_NM 対処名称
     */
    public void setRECOVER_MSG_NM(String RECOVER_MSG_NM) {
        this.RECOVER_MSG_NM = RECOVER_MSG_NM == null ? null : RECOVER_MSG_NM.trim();
    }

    /**
     * 備考
     * @return BIKOU 備考
     */
    public String getBIKOU() {
        return BIKOU;
    }

    /**
     * 備考
     * @param BIKOU 備考
     */
    public void setBIKOU(String BIKOU) {
        this.BIKOU = BIKOU == null ? null : BIKOU.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}