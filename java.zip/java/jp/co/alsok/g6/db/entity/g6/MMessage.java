package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MMessage implements Serializable {
    /**
     * メッセージID
     */
    private String MESSAGE_ID;

    /**
     * サイト区分
     */
    private String SITE_KBN;

    /**
     * 内容_日本語
     */
    private String MSG_NAIYOU_JP;

    /**
     * 内容_英語
     */
    private String MSG_NAIYOU_EN;

    /**
     * 内容_中国語
     */
    private String MSG_NAIYOU_ZH;

    /**
     * 備考
     */
    private String BIKOU;

    /**
     * M_MESSAGE
     */
    private static final long serialVersionUID = 1L;

    /**
     * メッセージID
     * @return MESSAGE_ID メッセージID
     */
    public String getMESSAGE_ID() {
        return MESSAGE_ID;
    }

    /**
     * メッセージID
     * @param MESSAGE_ID メッセージID
     */
    public void setMESSAGE_ID(String MESSAGE_ID) {
        this.MESSAGE_ID = MESSAGE_ID == null ? null : MESSAGE_ID.trim();
    }

    /**
     * サイト区分
     * @return SITE_KBN サイト区分
     */
    public String getSITE_KBN() {
        return SITE_KBN;
    }

    /**
     * サイト区分
     * @param SITE_KBN サイト区分
     */
    public void setSITE_KBN(String SITE_KBN) {
        this.SITE_KBN = SITE_KBN == null ? null : SITE_KBN.trim();
    }

    /**
     * 内容_日本語
     * @return MSG_NAIYOU_JP 内容_日本語
     */
    public String getMSG_NAIYOU_JP() {
        return MSG_NAIYOU_JP;
    }

    /**
     * 内容_日本語
     * @param MSG_NAIYOU_JP 内容_日本語
     */
    public void setMSG_NAIYOU_JP(String MSG_NAIYOU_JP) {
        this.MSG_NAIYOU_JP = MSG_NAIYOU_JP == null ? null : MSG_NAIYOU_JP.trim();
    }

    /**
     * 内容_英語
     * @return MSG_NAIYOU_EN 内容_英語
     */
    public String getMSG_NAIYOU_EN() {
        return MSG_NAIYOU_EN;
    }

    /**
     * 内容_英語
     * @param MSG_NAIYOU_EN 内容_英語
     */
    public void setMSG_NAIYOU_EN(String MSG_NAIYOU_EN) {
        this.MSG_NAIYOU_EN = MSG_NAIYOU_EN == null ? null : MSG_NAIYOU_EN.trim();
    }

    /**
     * 内容_中国語
     * @return MSG_NAIYOU_ZH 内容_中国語
     */
    public String getMSG_NAIYOU_ZH() {
        return MSG_NAIYOU_ZH;
    }

    /**
     * 内容_中国語
     * @param MSG_NAIYOU_ZH 内容_中国語
     */
    public void setMSG_NAIYOU_ZH(String MSG_NAIYOU_ZH) {
        this.MSG_NAIYOU_ZH = MSG_NAIYOU_ZH == null ? null : MSG_NAIYOU_ZH.trim();
    }

    /**
     * 備考
     * @return BIKOU 備考
     */
    public String getBIKOU() {
        return BIKOU;
    }

    /**
     * 備考
     * @param BIKOU 備考
     */
    public void setBIKOU(String BIKOU) {
        this.BIKOU = BIKOU == null ? null : BIKOU.trim();
    }
}