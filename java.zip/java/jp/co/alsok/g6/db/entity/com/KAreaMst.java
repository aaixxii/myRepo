package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KAreaMst extends KAreaMstKey implements Serializable {
    /**
     * エリア名
     */
    private String AREA_NM;

    /**
     * 事業所_ID
     */
    private String ID_JIGYOU;

    /**
     * 真報判断機能使用有無フラグ
     */
    private String SINPO_FLG;

    /**
     * 未配信監視対象フラグ
     */
    private String MIHAISHIN_CHK_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_AREA_MST
     */
    private static final long serialVersionUID = 1L;

    /**
     * エリア名
     * @return AREA_NM エリア名
     */
    public String getAREA_NM() {
        return AREA_NM;
    }

    /**
     * エリア名
     * @param AREA_NM エリア名
     */
    public void setAREA_NM(String AREA_NM) {
        this.AREA_NM = AREA_NM == null ? null : AREA_NM.trim();
    }

    /**
     * 事業所_ID
     * @return ID_JIGYOU 事業所_ID
     */
    public String getID_JIGYOU() {
        return ID_JIGYOU;
    }

    /**
     * 事業所_ID
     * @param ID_JIGYOU 事業所_ID
     */
    public void setID_JIGYOU(String ID_JIGYOU) {
        this.ID_JIGYOU = ID_JIGYOU == null ? null : ID_JIGYOU.trim();
    }

    /**
     * 真報判断機能使用有無フラグ
     * @return SINPO_FLG 真報判断機能使用有無フラグ
     */
    public String getSINPO_FLG() {
        return SINPO_FLG;
    }

    /**
     * 真報判断機能使用有無フラグ
     * @param SINPO_FLG 真報判断機能使用有無フラグ
     */
    public void setSINPO_FLG(String SINPO_FLG) {
        this.SINPO_FLG = SINPO_FLG == null ? null : SINPO_FLG.trim();
    }

    /**
     * 未配信監視対象フラグ
     * @return MIHAISHIN_CHK_FLG 未配信監視対象フラグ
     */
    public String getMIHAISHIN_CHK_FLG() {
        return MIHAISHIN_CHK_FLG;
    }

    /**
     * 未配信監視対象フラグ
     * @param MIHAISHIN_CHK_FLG 未配信監視対象フラグ
     */
    public void setMIHAISHIN_CHK_FLG(String MIHAISHIN_CHK_FLG) {
        this.MIHAISHIN_CHK_FLG = MIHAISHIN_CHK_FLG == null ? null : MIHAISHIN_CHK_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}