package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class HLmtTmrExtHtblKey implements Serializable {
    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * 延長回数
     */
    private String EXT_CNT;

    /**
     * H_LMT_TMR_EXT_HTBL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * 延長回数
     * @return EXT_CNT 延長回数
     */
    public String getEXT_CNT() {
        return EXT_CNT;
    }

    /**
     * 延長回数
     * @param EXT_CNT 延長回数
     */
    public void setEXT_CNT(String EXT_CNT) {
        this.EXT_CNT = EXT_CNT == null ? null : EXT_CNT.trim();
    }
}