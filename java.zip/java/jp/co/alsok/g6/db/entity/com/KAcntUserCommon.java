package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KAcntUserCommon implements Serializable {
    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * アカウントID
     */
    private String ACNT_ID;

    /**
     * メールアドレス
     */
    private String ML_ADDR;

    /**
     * パスワード
     */
    private String PASSWD;

    /**
     * アカウント名称
     */
    private String ACNT_NM;

    /**
     * アカウント名称カナ
     */
    private String ACNT_NM_KANA;

    /**
     * 社員コード
     */
    private String SYAIN_CD;

    /**
     * 部署名
     */
    private String BUSYO_NM;

    /**
     * 部署名カナ
     */
    private String BUSYO_NM_KANA;

    /**
     * 役職名
     */
    private String YAKUSYOKU_NM;

    /**
     * 役職名カナ
     */
    private String YAKUSYOKU_KANA;

    /**
     * 利用者アカウント区分
     */
    private String ACNT_USER_KBN;

    /**
     * 電話番号１
     */
    private String TEL_NUM_1;

    /**
     * 電話番号２
     */
    private String TEL_NUM_2;

    /**
     * 問い合わせ事業所
     */
    private String JIGYOU_TOIAWASE;

    /**
     * 問い合わせ電話番号
     */
    private String TEL_NUM_TOIAWASE;

    /**
     * 秘密の質問1
     */
    private String QUESTION_1;

    /**
     * 答え1
     */
    private String ANSWER_1;

    /**
     * 秘密の質問2
     */
    private String QUESTION_2;

    /**
     * 答え2
     */
    private String ANSWER_2;

    /**
     * 秘密の質問3
     */
    private String QUESTION_3;

    /**
     * 答え3
     */
    private String ANSWER_3;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_ACNT_USER_COMMON
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * アカウントID
     * @return ACNT_ID アカウントID
     */
    public String getACNT_ID() {
        return ACNT_ID;
    }

    /**
     * アカウントID
     * @param ACNT_ID アカウントID
     */
    public void setACNT_ID(String ACNT_ID) {
        this.ACNT_ID = ACNT_ID == null ? null : ACNT_ID.trim();
    }

    /**
     * メールアドレス
     * @return ML_ADDR メールアドレス
     */
    public String getML_ADDR() {
        return ML_ADDR;
    }

    /**
     * メールアドレス
     * @param ML_ADDR メールアドレス
     */
    public void setML_ADDR(String ML_ADDR) {
        this.ML_ADDR = ML_ADDR == null ? null : ML_ADDR.trim();
    }

    /**
     * パスワード
     * @return PASSWD パスワード
     */
    public String getPASSWD() {
        return PASSWD;
    }

    /**
     * パスワード
     * @param PASSWD パスワード
     */
    public void setPASSWD(String PASSWD) {
        this.PASSWD = PASSWD == null ? null : PASSWD.trim();
    }

    /**
     * アカウント名称
     * @return ACNT_NM アカウント名称
     */
    public String getACNT_NM() {
        return ACNT_NM;
    }

    /**
     * アカウント名称
     * @param ACNT_NM アカウント名称
     */
    public void setACNT_NM(String ACNT_NM) {
        this.ACNT_NM = ACNT_NM == null ? null : ACNT_NM.trim();
    }

    /**
     * アカウント名称カナ
     * @return ACNT_NM_KANA アカウント名称カナ
     */
    public String getACNT_NM_KANA() {
        return ACNT_NM_KANA;
    }

    /**
     * アカウント名称カナ
     * @param ACNT_NM_KANA アカウント名称カナ
     */
    public void setACNT_NM_KANA(String ACNT_NM_KANA) {
        this.ACNT_NM_KANA = ACNT_NM_KANA == null ? null : ACNT_NM_KANA.trim();
    }

    /**
     * 社員コード
     * @return SYAIN_CD 社員コード
     */
    public String getSYAIN_CD() {
        return SYAIN_CD;
    }

    /**
     * 社員コード
     * @param SYAIN_CD 社員コード
     */
    public void setSYAIN_CD(String SYAIN_CD) {
        this.SYAIN_CD = SYAIN_CD == null ? null : SYAIN_CD.trim();
    }

    /**
     * 部署名
     * @return BUSYO_NM 部署名
     */
    public String getBUSYO_NM() {
        return BUSYO_NM;
    }

    /**
     * 部署名
     * @param BUSYO_NM 部署名
     */
    public void setBUSYO_NM(String BUSYO_NM) {
        this.BUSYO_NM = BUSYO_NM == null ? null : BUSYO_NM.trim();
    }

    /**
     * 部署名カナ
     * @return BUSYO_NM_KANA 部署名カナ
     */
    public String getBUSYO_NM_KANA() {
        return BUSYO_NM_KANA;
    }

    /**
     * 部署名カナ
     * @param BUSYO_NM_KANA 部署名カナ
     */
    public void setBUSYO_NM_KANA(String BUSYO_NM_KANA) {
        this.BUSYO_NM_KANA = BUSYO_NM_KANA == null ? null : BUSYO_NM_KANA.trim();
    }

    /**
     * 役職名
     * @return YAKUSYOKU_NM 役職名
     */
    public String getYAKUSYOKU_NM() {
        return YAKUSYOKU_NM;
    }

    /**
     * 役職名
     * @param YAKUSYOKU_NM 役職名
     */
    public void setYAKUSYOKU_NM(String YAKUSYOKU_NM) {
        this.YAKUSYOKU_NM = YAKUSYOKU_NM == null ? null : YAKUSYOKU_NM.trim();
    }

    /**
     * 役職名カナ
     * @return YAKUSYOKU_KANA 役職名カナ
     */
    public String getYAKUSYOKU_KANA() {
        return YAKUSYOKU_KANA;
    }

    /**
     * 役職名カナ
     * @param YAKUSYOKU_KANA 役職名カナ
     */
    public void setYAKUSYOKU_KANA(String YAKUSYOKU_KANA) {
        this.YAKUSYOKU_KANA = YAKUSYOKU_KANA == null ? null : YAKUSYOKU_KANA.trim();
    }

    /**
     * 利用者アカウント区分
     * @return ACNT_USER_KBN 利用者アカウント区分
     */
    public String getACNT_USER_KBN() {
        return ACNT_USER_KBN;
    }

    /**
     * 利用者アカウント区分
     * @param ACNT_USER_KBN 利用者アカウント区分
     */
    public void setACNT_USER_KBN(String ACNT_USER_KBN) {
        this.ACNT_USER_KBN = ACNT_USER_KBN == null ? null : ACNT_USER_KBN.trim();
    }

    /**
     * 電話番号１
     * @return TEL_NUM_1 電話番号１
     */
    public String getTEL_NUM_1() {
        return TEL_NUM_1;
    }

    /**
     * 電話番号１
     * @param TEL_NUM_1 電話番号１
     */
    public void setTEL_NUM_1(String TEL_NUM_1) {
        this.TEL_NUM_1 = TEL_NUM_1 == null ? null : TEL_NUM_1.trim();
    }

    /**
     * 電話番号２
     * @return TEL_NUM_2 電話番号２
     */
    public String getTEL_NUM_2() {
        return TEL_NUM_2;
    }

    /**
     * 電話番号２
     * @param TEL_NUM_2 電話番号２
     */
    public void setTEL_NUM_2(String TEL_NUM_2) {
        this.TEL_NUM_2 = TEL_NUM_2 == null ? null : TEL_NUM_2.trim();
    }

    /**
     * 問い合わせ事業所
     * @return JIGYOU_TOIAWASE 問い合わせ事業所
     */
    public String getJIGYOU_TOIAWASE() {
        return JIGYOU_TOIAWASE;
    }

    /**
     * 問い合わせ事業所
     * @param JIGYOU_TOIAWASE 問い合わせ事業所
     */
    public void setJIGYOU_TOIAWASE(String JIGYOU_TOIAWASE) {
        this.JIGYOU_TOIAWASE = JIGYOU_TOIAWASE == null ? null : JIGYOU_TOIAWASE.trim();
    }

    /**
     * 問い合わせ電話番号
     * @return TEL_NUM_TOIAWASE 問い合わせ電話番号
     */
    public String getTEL_NUM_TOIAWASE() {
        return TEL_NUM_TOIAWASE;
    }

    /**
     * 問い合わせ電話番号
     * @param TEL_NUM_TOIAWASE 問い合わせ電話番号
     */
    public void setTEL_NUM_TOIAWASE(String TEL_NUM_TOIAWASE) {
        this.TEL_NUM_TOIAWASE = TEL_NUM_TOIAWASE == null ? null : TEL_NUM_TOIAWASE.trim();
    }

    /**
     * 秘密の質問1
     * @return QUESTION_1 秘密の質問1
     */
    public String getQUESTION_1() {
        return QUESTION_1;
    }

    /**
     * 秘密の質問1
     * @param QUESTION_1 秘密の質問1
     */
    public void setQUESTION_1(String QUESTION_1) {
        this.QUESTION_1 = QUESTION_1 == null ? null : QUESTION_1.trim();
    }

    /**
     * 答え1
     * @return ANSWER_1 答え1
     */
    public String getANSWER_1() {
        return ANSWER_1;
    }

    /**
     * 答え1
     * @param ANSWER_1 答え1
     */
    public void setANSWER_1(String ANSWER_1) {
        this.ANSWER_1 = ANSWER_1 == null ? null : ANSWER_1.trim();
    }

    /**
     * 秘密の質問2
     * @return QUESTION_2 秘密の質問2
     */
    public String getQUESTION_2() {
        return QUESTION_2;
    }

    /**
     * 秘密の質問2
     * @param QUESTION_2 秘密の質問2
     */
    public void setQUESTION_2(String QUESTION_2) {
        this.QUESTION_2 = QUESTION_2 == null ? null : QUESTION_2.trim();
    }

    /**
     * 答え2
     * @return ANSWER_2 答え2
     */
    public String getANSWER_2() {
        return ANSWER_2;
    }

    /**
     * 答え2
     * @param ANSWER_2 答え2
     */
    public void setANSWER_2(String ANSWER_2) {
        this.ANSWER_2 = ANSWER_2 == null ? null : ANSWER_2.trim();
    }

    /**
     * 秘密の質問3
     * @return QUESTION_3 秘密の質問3
     */
    public String getQUESTION_3() {
        return QUESTION_3;
    }

    /**
     * 秘密の質問3
     * @param QUESTION_3 秘密の質問3
     */
    public void setQUESTION_3(String QUESTION_3) {
        this.QUESTION_3 = QUESTION_3 == null ? null : QUESTION_3.trim();
    }

    /**
     * 答え3
     * @return ANSWER_3 答え3
     */
    public String getANSWER_3() {
        return ANSWER_3;
    }

    /**
     * 答え3
     * @param ANSWER_3 答え3
     */
    public void setANSWER_3(String ANSWER_3) {
        this.ANSWER_3 = ANSWER_3 == null ? null : ANSWER_3.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}