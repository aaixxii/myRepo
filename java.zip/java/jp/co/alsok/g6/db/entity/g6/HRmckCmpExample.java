package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HRmckCmpExample {
    /**
     * H_RMCK_CMP
     */
    protected String orderByClause;

    /**
     * H_RMCK_CMP
     */
    protected boolean distinct;

    /**
     * H_RMCK_CMP
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HRmckCmpExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_RMCK_CMP null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_RMCK_CMPIsNull() {
            addCriterion("LN_RMCK_CMP is null");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPIsNotNull() {
            addCriterion("LN_RMCK_CMP is not null");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPEqualTo(String value) {
            addCriterion("LN_RMCK_CMP =", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPNotEqualTo(String value) {
            addCriterion("LN_RMCK_CMP <>", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPGreaterThan(String value) {
            addCriterion("LN_RMCK_CMP >", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPGreaterThanOrEqualTo(String value) {
            addCriterion("LN_RMCK_CMP >=", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPLessThan(String value) {
            addCriterion("LN_RMCK_CMP <", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPLessThanOrEqualTo(String value) {
            addCriterion("LN_RMCK_CMP <=", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPLike(String value) {
            addCriterion("LN_RMCK_CMP like", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPNotLike(String value) {
            addCriterion("LN_RMCK_CMP not like", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPIn(List<String> values) {
            addCriterion("LN_RMCK_CMP in", values, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPNotIn(List<String> values) {
            addCriterion("LN_RMCK_CMP not in", values, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPBetween(String value1, String value2) {
            addCriterion("LN_RMCK_CMP between", value1, value2, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPNotBetween(String value1, String value2) {
            addCriterion("LN_RMCK_CMP not between", value1, value2, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIsNull() {
            addCriterion("LN_DEV is null");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIsNotNull() {
            addCriterion("LN_DEV is not null");
            return (Criteria) this;
        }

        public Criteria andLN_DEVEqualTo(String value) {
            addCriterion("LN_DEV =", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotEqualTo(String value) {
            addCriterion("LN_DEV <>", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVGreaterThan(String value) {
            addCriterion("LN_DEV >", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVGreaterThanOrEqualTo(String value) {
            addCriterion("LN_DEV >=", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLessThan(String value) {
            addCriterion("LN_DEV <", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLessThanOrEqualTo(String value) {
            addCriterion("LN_DEV <=", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLike(String value) {
            addCriterion("LN_DEV like", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotLike(String value) {
            addCriterion("LN_DEV not like", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIn(List<String> values) {
            addCriterion("LN_DEV in", values, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotIn(List<String> values) {
            addCriterion("LN_DEV not in", values, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVBetween(String value1, String value2) {
            addCriterion("LN_DEV between", value1, value2, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotBetween(String value1, String value2) {
            addCriterion("LN_DEV not between", value1, value2, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNull() {
            addCriterion("DEV_NUM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNotNull() {
            addCriterion("DEV_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMEqualTo(String value) {
            addCriterion("DEV_NUM =", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotEqualTo(String value) {
            addCriterion("DEV_NUM <>", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThan(String value) {
            addCriterion("DEV_NUM >", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_NUM >=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThan(String value) {
            addCriterion("DEV_NUM <", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThanOrEqualTo(String value) {
            addCriterion("DEV_NUM <=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLike(String value) {
            addCriterion("DEV_NUM like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotLike(String value) {
            addCriterion("DEV_NUM not like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIn(List<String> values) {
            addCriterion("DEV_NUM in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotIn(List<String> values) {
            addCriterion("DEV_NUM not in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMBetween(String value1, String value2) {
            addCriterion("DEV_NUM between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotBetween(String value1, String value2) {
            addCriterion("DEV_NUM not between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andWAKE_STIsNull() {
            addCriterion("WAKE_ST is null");
            return (Criteria) this;
        }

        public Criteria andWAKE_STIsNotNull() {
            addCriterion("WAKE_ST is not null");
            return (Criteria) this;
        }

        public Criteria andWAKE_STEqualTo(String value) {
            addCriterion("WAKE_ST =", value, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STNotEqualTo(String value) {
            addCriterion("WAKE_ST <>", value, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STGreaterThan(String value) {
            addCriterion("WAKE_ST >", value, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STGreaterThanOrEqualTo(String value) {
            addCriterion("WAKE_ST >=", value, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STLessThan(String value) {
            addCriterion("WAKE_ST <", value, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STLessThanOrEqualTo(String value) {
            addCriterion("WAKE_ST <=", value, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STLike(String value) {
            addCriterion("WAKE_ST like", value, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STNotLike(String value) {
            addCriterion("WAKE_ST not like", value, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STIn(List<String> values) {
            addCriterion("WAKE_ST in", values, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STNotIn(List<String> values) {
            addCriterion("WAKE_ST not in", values, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STBetween(String value1, String value2) {
            addCriterion("WAKE_ST between", value1, value2, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andWAKE_STNotBetween(String value1, String value2) {
            addCriterion("WAKE_ST not between", value1, value2, "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andSENS_STSIsNull() {
            addCriterion("SENS_STS is null");
            return (Criteria) this;
        }

        public Criteria andSENS_STSIsNotNull() {
            addCriterion("SENS_STS is not null");
            return (Criteria) this;
        }

        public Criteria andSENS_STSEqualTo(String value) {
            addCriterion("SENS_STS =", value, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSNotEqualTo(String value) {
            addCriterion("SENS_STS <>", value, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSGreaterThan(String value) {
            addCriterion("SENS_STS >", value, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSGreaterThanOrEqualTo(String value) {
            addCriterion("SENS_STS >=", value, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSLessThan(String value) {
            addCriterion("SENS_STS <", value, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSLessThanOrEqualTo(String value) {
            addCriterion("SENS_STS <=", value, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSLike(String value) {
            addCriterion("SENS_STS like", value, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSNotLike(String value) {
            addCriterion("SENS_STS not like", value, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSIn(List<String> values) {
            addCriterion("SENS_STS in", values, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSNotIn(List<String> values) {
            addCriterion("SENS_STS not in", values, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSBetween(String value1, String value2) {
            addCriterion("SENS_STS between", value1, value2, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andSENS_STSNotBetween(String value1, String value2) {
            addCriterion("SENS_STS not between", value1, value2, "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSIsNull() {
            addCriterion("WRBK_STS is null");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSIsNotNull() {
            addCriterion("WRBK_STS is not null");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSEqualTo(String value) {
            addCriterion("WRBK_STS =", value, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSNotEqualTo(String value) {
            addCriterion("WRBK_STS <>", value, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSGreaterThan(String value) {
            addCriterion("WRBK_STS >", value, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSGreaterThanOrEqualTo(String value) {
            addCriterion("WRBK_STS >=", value, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSLessThan(String value) {
            addCriterion("WRBK_STS <", value, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSLessThanOrEqualTo(String value) {
            addCriterion("WRBK_STS <=", value, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSLike(String value) {
            addCriterion("WRBK_STS like", value, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSNotLike(String value) {
            addCriterion("WRBK_STS not like", value, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSIn(List<String> values) {
            addCriterion("WRBK_STS in", values, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSNotIn(List<String> values) {
            addCriterion("WRBK_STS not in", values, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSBetween(String value1, String value2) {
            addCriterion("WRBK_STS between", value1, value2, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSNotBetween(String value1, String value2) {
            addCriterion("WRBK_STS not between", value1, value2, "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSIsNull() {
            addCriterion("DSTB_STS is null");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSIsNotNull() {
            addCriterion("DSTB_STS is not null");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSEqualTo(String value) {
            addCriterion("DSTB_STS =", value, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSNotEqualTo(String value) {
            addCriterion("DSTB_STS <>", value, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSGreaterThan(String value) {
            addCriterion("DSTB_STS >", value, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSGreaterThanOrEqualTo(String value) {
            addCriterion("DSTB_STS >=", value, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSLessThan(String value) {
            addCriterion("DSTB_STS <", value, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSLessThanOrEqualTo(String value) {
            addCriterion("DSTB_STS <=", value, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSLike(String value) {
            addCriterion("DSTB_STS like", value, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSNotLike(String value) {
            addCriterion("DSTB_STS not like", value, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSIn(List<String> values) {
            addCriterion("DSTB_STS in", values, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSNotIn(List<String> values) {
            addCriterion("DSTB_STS not in", values, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSBetween(String value1, String value2) {
            addCriterion("DSTB_STS between", value1, value2, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSNotBetween(String value1, String value2) {
            addCriterion("DSTB_STS not between", value1, value2, "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSIsNull() {
            addCriterion("ENVI_STS is null");
            return (Criteria) this;
        }

        public Criteria andENVI_STSIsNotNull() {
            addCriterion("ENVI_STS is not null");
            return (Criteria) this;
        }

        public Criteria andENVI_STSEqualTo(String value) {
            addCriterion("ENVI_STS =", value, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSNotEqualTo(String value) {
            addCriterion("ENVI_STS <>", value, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSGreaterThan(String value) {
            addCriterion("ENVI_STS >", value, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSGreaterThanOrEqualTo(String value) {
            addCriterion("ENVI_STS >=", value, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSLessThan(String value) {
            addCriterion("ENVI_STS <", value, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSLessThanOrEqualTo(String value) {
            addCriterion("ENVI_STS <=", value, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSLike(String value) {
            addCriterion("ENVI_STS like", value, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSNotLike(String value) {
            addCriterion("ENVI_STS not like", value, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSIn(List<String> values) {
            addCriterion("ENVI_STS in", values, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSNotIn(List<String> values) {
            addCriterion("ENVI_STS not in", values, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSBetween(String value1, String value2) {
            addCriterion("ENVI_STS between", value1, value2, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSNotBetween(String value1, String value2) {
            addCriterion("ENVI_STS not between", value1, value2, "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSIsNull() {
            addCriterion("POST_STS is null");
            return (Criteria) this;
        }

        public Criteria andPOST_STSIsNotNull() {
            addCriterion("POST_STS is not null");
            return (Criteria) this;
        }

        public Criteria andPOST_STSEqualTo(String value) {
            addCriterion("POST_STS =", value, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSNotEqualTo(String value) {
            addCriterion("POST_STS <>", value, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSGreaterThan(String value) {
            addCriterion("POST_STS >", value, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSGreaterThanOrEqualTo(String value) {
            addCriterion("POST_STS >=", value, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSLessThan(String value) {
            addCriterion("POST_STS <", value, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSLessThanOrEqualTo(String value) {
            addCriterion("POST_STS <=", value, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSLike(String value) {
            addCriterion("POST_STS like", value, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSNotLike(String value) {
            addCriterion("POST_STS not like", value, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSIn(List<String> values) {
            addCriterion("POST_STS in", values, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSNotIn(List<String> values) {
            addCriterion("POST_STS not in", values, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSBetween(String value1, String value2) {
            addCriterion("POST_STS between", value1, value2, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSNotBetween(String value1, String value2) {
            addCriterion("POST_STS not between", value1, value2, "POST_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSIsNull() {
            addCriterion("DROP_STS is null");
            return (Criteria) this;
        }

        public Criteria andDROP_STSIsNotNull() {
            addCriterion("DROP_STS is not null");
            return (Criteria) this;
        }

        public Criteria andDROP_STSEqualTo(String value) {
            addCriterion("DROP_STS =", value, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSNotEqualTo(String value) {
            addCriterion("DROP_STS <>", value, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSGreaterThan(String value) {
            addCriterion("DROP_STS >", value, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSGreaterThanOrEqualTo(String value) {
            addCriterion("DROP_STS >=", value, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSLessThan(String value) {
            addCriterion("DROP_STS <", value, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSLessThanOrEqualTo(String value) {
            addCriterion("DROP_STS <=", value, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSLike(String value) {
            addCriterion("DROP_STS like", value, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSNotLike(String value) {
            addCriterion("DROP_STS not like", value, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSIn(List<String> values) {
            addCriterion("DROP_STS in", values, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSNotIn(List<String> values) {
            addCriterion("DROP_STS not in", values, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSBetween(String value1, String value2) {
            addCriterion("DROP_STS between", value1, value2, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSNotBetween(String value1, String value2) {
            addCriterion("DROP_STS not between", value1, value2, "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSIsNull() {
            addCriterion("BLOU_STS is null");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSIsNotNull() {
            addCriterion("BLOU_STS is not null");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSEqualTo(String value) {
            addCriterion("BLOU_STS =", value, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSNotEqualTo(String value) {
            addCriterion("BLOU_STS <>", value, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSGreaterThan(String value) {
            addCriterion("BLOU_STS >", value, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSGreaterThanOrEqualTo(String value) {
            addCriterion("BLOU_STS >=", value, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSLessThan(String value) {
            addCriterion("BLOU_STS <", value, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSLessThanOrEqualTo(String value) {
            addCriterion("BLOU_STS <=", value, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSLike(String value) {
            addCriterion("BLOU_STS like", value, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSNotLike(String value) {
            addCriterion("BLOU_STS not like", value, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSIn(List<String> values) {
            addCriterion("BLOU_STS in", values, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSNotIn(List<String> values) {
            addCriterion("BLOU_STS not in", values, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSBetween(String value1, String value2) {
            addCriterion("BLOU_STS between", value1, value2, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSNotBetween(String value1, String value2) {
            addCriterion("BLOU_STS not between", value1, value2, "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSIsNull() {
            addCriterion("TANP_STS is null");
            return (Criteria) this;
        }

        public Criteria andTANP_STSIsNotNull() {
            addCriterion("TANP_STS is not null");
            return (Criteria) this;
        }

        public Criteria andTANP_STSEqualTo(String value) {
            addCriterion("TANP_STS =", value, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSNotEqualTo(String value) {
            addCriterion("TANP_STS <>", value, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSGreaterThan(String value) {
            addCriterion("TANP_STS >", value, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSGreaterThanOrEqualTo(String value) {
            addCriterion("TANP_STS >=", value, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSLessThan(String value) {
            addCriterion("TANP_STS <", value, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSLessThanOrEqualTo(String value) {
            addCriterion("TANP_STS <=", value, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSLike(String value) {
            addCriterion("TANP_STS like", value, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSNotLike(String value) {
            addCriterion("TANP_STS not like", value, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSIn(List<String> values) {
            addCriterion("TANP_STS in", values, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSNotIn(List<String> values) {
            addCriterion("TANP_STS not in", values, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSBetween(String value1, String value2) {
            addCriterion("TANP_STS between", value1, value2, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSNotBetween(String value1, String value2) {
            addCriterion("TANP_STS not between", value1, value2, "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andBKDW_STIsNull() {
            addCriterion("BKDW_ST is null");
            return (Criteria) this;
        }

        public Criteria andBKDW_STIsNotNull() {
            addCriterion("BKDW_ST is not null");
            return (Criteria) this;
        }

        public Criteria andBKDW_STEqualTo(String value) {
            addCriterion("BKDW_ST =", value, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STNotEqualTo(String value) {
            addCriterion("BKDW_ST <>", value, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STGreaterThan(String value) {
            addCriterion("BKDW_ST >", value, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STGreaterThanOrEqualTo(String value) {
            addCriterion("BKDW_ST >=", value, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STLessThan(String value) {
            addCriterion("BKDW_ST <", value, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STLessThanOrEqualTo(String value) {
            addCriterion("BKDW_ST <=", value, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STLike(String value) {
            addCriterion("BKDW_ST like", value, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STNotLike(String value) {
            addCriterion("BKDW_ST not like", value, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STIn(List<String> values) {
            addCriterion("BKDW_ST in", values, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STNotIn(List<String> values) {
            addCriterion("BKDW_ST not in", values, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STBetween(String value1, String value2) {
            addCriterion("BKDW_ST between", value1, value2, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andBKDW_STNotBetween(String value1, String value2) {
            addCriterion("BKDW_ST not between", value1, value2, "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STIsNull() {
            addCriterion("LWVL_ST is null");
            return (Criteria) this;
        }

        public Criteria andLWVL_STIsNotNull() {
            addCriterion("LWVL_ST is not null");
            return (Criteria) this;
        }

        public Criteria andLWVL_STEqualTo(String value) {
            addCriterion("LWVL_ST =", value, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STNotEqualTo(String value) {
            addCriterion("LWVL_ST <>", value, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STGreaterThan(String value) {
            addCriterion("LWVL_ST >", value, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STGreaterThanOrEqualTo(String value) {
            addCriterion("LWVL_ST >=", value, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STLessThan(String value) {
            addCriterion("LWVL_ST <", value, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STLessThanOrEqualTo(String value) {
            addCriterion("LWVL_ST <=", value, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STLike(String value) {
            addCriterion("LWVL_ST like", value, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STNotLike(String value) {
            addCriterion("LWVL_ST not like", value, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STIn(List<String> values) {
            addCriterion("LWVL_ST in", values, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STNotIn(List<String> values) {
            addCriterion("LWVL_ST not in", values, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STBetween(String value1, String value2) {
            addCriterion("LWVL_ST between", value1, value2, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STNotBetween(String value1, String value2) {
            addCriterion("LWVL_ST not between", value1, value2, "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLED_STSIsNull() {
            addCriterion("LED_STS is null");
            return (Criteria) this;
        }

        public Criteria andLED_STSIsNotNull() {
            addCriterion("LED_STS is not null");
            return (Criteria) this;
        }

        public Criteria andLED_STSEqualTo(String value) {
            addCriterion("LED_STS =", value, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSNotEqualTo(String value) {
            addCriterion("LED_STS <>", value, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSGreaterThan(String value) {
            addCriterion("LED_STS >", value, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSGreaterThanOrEqualTo(String value) {
            addCriterion("LED_STS >=", value, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSLessThan(String value) {
            addCriterion("LED_STS <", value, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSLessThanOrEqualTo(String value) {
            addCriterion("LED_STS <=", value, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSLike(String value) {
            addCriterion("LED_STS like", value, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSNotLike(String value) {
            addCriterion("LED_STS not like", value, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSIn(List<String> values) {
            addCriterion("LED_STS in", values, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSNotIn(List<String> values) {
            addCriterion("LED_STS not in", values, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSBetween(String value1, String value2) {
            addCriterion("LED_STS between", value1, value2, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andLED_STSNotBetween(String value1, String value2) {
            addCriterion("LED_STS not between", value1, value2, "LED_STS");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKIsNull() {
            addCriterion("VIDE_LK is null");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKIsNotNull() {
            addCriterion("VIDE_LK is not null");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKEqualTo(String value) {
            addCriterion("VIDE_LK =", value, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKNotEqualTo(String value) {
            addCriterion("VIDE_LK <>", value, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKGreaterThan(String value) {
            addCriterion("VIDE_LK >", value, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKGreaterThanOrEqualTo(String value) {
            addCriterion("VIDE_LK >=", value, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKLessThan(String value) {
            addCriterion("VIDE_LK <", value, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKLessThanOrEqualTo(String value) {
            addCriterion("VIDE_LK <=", value, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKLike(String value) {
            addCriterion("VIDE_LK like", value, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKNotLike(String value) {
            addCriterion("VIDE_LK not like", value, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKIn(List<String> values) {
            addCriterion("VIDE_LK in", values, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKNotIn(List<String> values) {
            addCriterion("VIDE_LK not in", values, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKBetween(String value1, String value2) {
            addCriterion("VIDE_LK between", value1, value2, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKNotBetween(String value1, String value2) {
            addCriterion("VIDE_LK not between", value1, value2, "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOIsNull() {
            addCriterion("CAMR_NO is null");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOIsNotNull() {
            addCriterion("CAMR_NO is not null");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOEqualTo(String value) {
            addCriterion("CAMR_NO =", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NONotEqualTo(String value) {
            addCriterion("CAMR_NO <>", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOGreaterThan(String value) {
            addCriterion("CAMR_NO >", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOGreaterThanOrEqualTo(String value) {
            addCriterion("CAMR_NO >=", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOLessThan(String value) {
            addCriterion("CAMR_NO <", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOLessThanOrEqualTo(String value) {
            addCriterion("CAMR_NO <=", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOLike(String value) {
            addCriterion("CAMR_NO like", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NONotLike(String value) {
            addCriterion("CAMR_NO not like", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOIn(List<String> values) {
            addCriterion("CAMR_NO in", values, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NONotIn(List<String> values) {
            addCriterion("CAMR_NO not in", values, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOBetween(String value1, String value2) {
            addCriterion("CAMR_NO between", value1, value2, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NONotBetween(String value1, String value2) {
            addCriterion("CAMR_NO not between", value1, value2, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andVFILENMIsNull() {
            addCriterion("VFILENM is null");
            return (Criteria) this;
        }

        public Criteria andVFILENMIsNotNull() {
            addCriterion("VFILENM is not null");
            return (Criteria) this;
        }

        public Criteria andVFILENMEqualTo(String value) {
            addCriterion("VFILENM =", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMNotEqualTo(String value) {
            addCriterion("VFILENM <>", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMGreaterThan(String value) {
            addCriterion("VFILENM >", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMGreaterThanOrEqualTo(String value) {
            addCriterion("VFILENM >=", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMLessThan(String value) {
            addCriterion("VFILENM <", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMLessThanOrEqualTo(String value) {
            addCriterion("VFILENM <=", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMLike(String value) {
            addCriterion("VFILENM like", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMNotLike(String value) {
            addCriterion("VFILENM not like", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMIn(List<String> values) {
            addCriterion("VFILENM in", values, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMNotIn(List<String> values) {
            addCriterion("VFILENM not in", values, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMBetween(String value1, String value2) {
            addCriterion("VFILENM between", value1, value2, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMNotBetween(String value1, String value2) {
            addCriterion("VFILENM not between", value1, value2, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIsNull() {
            addCriterion("FL_RATE is null");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIsNotNull() {
            addCriterion("FL_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andFL_RATEEqualTo(String value) {
            addCriterion("FL_RATE =", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotEqualTo(String value) {
            addCriterion("FL_RATE <>", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEGreaterThan(String value) {
            addCriterion("FL_RATE >", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEGreaterThanOrEqualTo(String value) {
            addCriterion("FL_RATE >=", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELessThan(String value) {
            addCriterion("FL_RATE <", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELessThanOrEqualTo(String value) {
            addCriterion("FL_RATE <=", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELike(String value) {
            addCriterion("FL_RATE like", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotLike(String value) {
            addCriterion("FL_RATE not like", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIn(List<String> values) {
            addCriterion("FL_RATE in", values, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotIn(List<String> values) {
            addCriterion("FL_RATE not in", values, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEBetween(String value1, String value2) {
            addCriterion("FL_RATE between", value1, value2, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotBetween(String value1, String value2) {
            addCriterion("FL_RATE not between", value1, value2, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEIsNull() {
            addCriterion("VR_TIME is null");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEIsNotNull() {
            addCriterion("VR_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEEqualTo(String value) {
            addCriterion("VR_TIME =", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMENotEqualTo(String value) {
            addCriterion("VR_TIME <>", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEGreaterThan(String value) {
            addCriterion("VR_TIME >", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("VR_TIME >=", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMELessThan(String value) {
            addCriterion("VR_TIME <", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMELessThanOrEqualTo(String value) {
            addCriterion("VR_TIME <=", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMELike(String value) {
            addCriterion("VR_TIME like", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMENotLike(String value) {
            addCriterion("VR_TIME not like", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEIn(List<String> values) {
            addCriterion("VR_TIME in", values, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMENotIn(List<String> values) {
            addCriterion("VR_TIME not in", values, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEBetween(String value1, String value2) {
            addCriterion("VR_TIME between", value1, value2, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMENotBetween(String value1, String value2) {
            addCriterion("VR_TIME not between", value1, value2, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTIsNull() {
            addCriterion("VR_ACNT is null");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTIsNotNull() {
            addCriterion("VR_ACNT is not null");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTEqualTo(String value) {
            addCriterion("VR_ACNT =", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTNotEqualTo(String value) {
            addCriterion("VR_ACNT <>", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTGreaterThan(String value) {
            addCriterion("VR_ACNT >", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTGreaterThanOrEqualTo(String value) {
            addCriterion("VR_ACNT >=", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTLessThan(String value) {
            addCriterion("VR_ACNT <", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTLessThanOrEqualTo(String value) {
            addCriterion("VR_ACNT <=", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTLike(String value) {
            addCriterion("VR_ACNT like", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTNotLike(String value) {
            addCriterion("VR_ACNT not like", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTIn(List<String> values) {
            addCriterion("VR_ACNT in", values, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTNotIn(List<String> values) {
            addCriterion("VR_ACNT not in", values, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTBetween(String value1, String value2) {
            addCriterion("VR_ACNT between", value1, value2, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTNotBetween(String value1, String value2) {
            addCriterion("VR_ACNT not between", value1, value2, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTIsNull() {
            addCriterion("VR_STRT is null");
            return (Criteria) this;
        }

        public Criteria andVR_STRTIsNotNull() {
            addCriterion("VR_STRT is not null");
            return (Criteria) this;
        }

        public Criteria andVR_STRTEqualTo(String value) {
            addCriterion("VR_STRT =", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTNotEqualTo(String value) {
            addCriterion("VR_STRT <>", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTGreaterThan(String value) {
            addCriterion("VR_STRT >", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTGreaterThanOrEqualTo(String value) {
            addCriterion("VR_STRT >=", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTLessThan(String value) {
            addCriterion("VR_STRT <", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTLessThanOrEqualTo(String value) {
            addCriterion("VR_STRT <=", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTLike(String value) {
            addCriterion("VR_STRT like", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTNotLike(String value) {
            addCriterion("VR_STRT not like", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTIn(List<String> values) {
            addCriterion("VR_STRT in", values, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTNotIn(List<String> values) {
            addCriterion("VR_STRT not in", values, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTBetween(String value1, String value2) {
            addCriterion("VR_STRT between", value1, value2, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTNotBetween(String value1, String value2) {
            addCriterion("VR_STRT not between", value1, value2, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTIsNull() {
            addCriterion("VFCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTIsNotNull() {
            addCriterion("VFCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTEqualTo(String value) {
            addCriterion("VFCOUNT =", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTNotEqualTo(String value) {
            addCriterion("VFCOUNT <>", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTGreaterThan(String value) {
            addCriterion("VFCOUNT >", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTGreaterThanOrEqualTo(String value) {
            addCriterion("VFCOUNT >=", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTLessThan(String value) {
            addCriterion("VFCOUNT <", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTLessThanOrEqualTo(String value) {
            addCriterion("VFCOUNT <=", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTLike(String value) {
            addCriterion("VFCOUNT like", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTNotLike(String value) {
            addCriterion("VFCOUNT not like", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTIn(List<String> values) {
            addCriterion("VFCOUNT in", values, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTNotIn(List<String> values) {
            addCriterion("VFCOUNT not in", values, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTBetween(String value1, String value2) {
            addCriterion("VFCOUNT between", value1, value2, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTNotBetween(String value1, String value2) {
            addCriterion("VFCOUNT not between", value1, value2, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKIsNull() {
            addCriterion("MCSP_LK is null");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKIsNotNull() {
            addCriterion("MCSP_LK is not null");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKEqualTo(String value) {
            addCriterion("MCSP_LK =", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKNotEqualTo(String value) {
            addCriterion("MCSP_LK <>", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKGreaterThan(String value) {
            addCriterion("MCSP_LK >", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKGreaterThanOrEqualTo(String value) {
            addCriterion("MCSP_LK >=", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKLessThan(String value) {
            addCriterion("MCSP_LK <", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKLessThanOrEqualTo(String value) {
            addCriterion("MCSP_LK <=", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKLike(String value) {
            addCriterion("MCSP_LK like", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKNotLike(String value) {
            addCriterion("MCSP_LK not like", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKIn(List<String> values) {
            addCriterion("MCSP_LK in", values, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKNotIn(List<String> values) {
            addCriterion("MCSP_LK not in", values, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKBetween(String value1, String value2) {
            addCriterion("MCSP_LK between", value1, value2, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKNotBetween(String value1, String value2) {
            addCriterion("MCSP_LK not between", value1, value2, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andINTP_NOIsNull() {
            addCriterion("INTP_NO is null");
            return (Criteria) this;
        }

        public Criteria andINTP_NOIsNotNull() {
            addCriterion("INTP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andINTP_NOEqualTo(String value) {
            addCriterion("INTP_NO =", value, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NONotEqualTo(String value) {
            addCriterion("INTP_NO <>", value, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NOGreaterThan(String value) {
            addCriterion("INTP_NO >", value, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("INTP_NO >=", value, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NOLessThan(String value) {
            addCriterion("INTP_NO <", value, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NOLessThanOrEqualTo(String value) {
            addCriterion("INTP_NO <=", value, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NOLike(String value) {
            addCriterion("INTP_NO like", value, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NONotLike(String value) {
            addCriterion("INTP_NO not like", value, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NOIn(List<String> values) {
            addCriterion("INTP_NO in", values, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NONotIn(List<String> values) {
            addCriterion("INTP_NO not in", values, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NOBetween(String value1, String value2) {
            addCriterion("INTP_NO between", value1, value2, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andINTP_NONotBetween(String value1, String value2) {
            addCriterion("INTP_NO not between", value1, value2, "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOIsNull() {
            addCriterion("MICP_NO is null");
            return (Criteria) this;
        }

        public Criteria andMICP_NOIsNotNull() {
            addCriterion("MICP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andMICP_NOEqualTo(String value) {
            addCriterion("MICP_NO =", value, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NONotEqualTo(String value) {
            addCriterion("MICP_NO <>", value, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOGreaterThan(String value) {
            addCriterion("MICP_NO >", value, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("MICP_NO >=", value, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOLessThan(String value) {
            addCriterion("MICP_NO <", value, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOLessThanOrEqualTo(String value) {
            addCriterion("MICP_NO <=", value, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOLike(String value) {
            addCriterion("MICP_NO like", value, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NONotLike(String value) {
            addCriterion("MICP_NO not like", value, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOIn(List<String> values) {
            addCriterion("MICP_NO in", values, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NONotIn(List<String> values) {
            addCriterion("MICP_NO not in", values, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOBetween(String value1, String value2) {
            addCriterion("MICP_NO between", value1, value2, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NONotBetween(String value1, String value2) {
            addCriterion("MICP_NO not between", value1, value2, "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOIsNull() {
            addCriterion("SPKR_NO is null");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOIsNotNull() {
            addCriterion("SPKR_NO is not null");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOEqualTo(String value) {
            addCriterion("SPKR_NO =", value, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NONotEqualTo(String value) {
            addCriterion("SPKR_NO <>", value, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOGreaterThan(String value) {
            addCriterion("SPKR_NO >", value, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOGreaterThanOrEqualTo(String value) {
            addCriterion("SPKR_NO >=", value, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOLessThan(String value) {
            addCriterion("SPKR_NO <", value, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOLessThanOrEqualTo(String value) {
            addCriterion("SPKR_NO <=", value, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOLike(String value) {
            addCriterion("SPKR_NO like", value, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NONotLike(String value) {
            addCriterion("SPKR_NO not like", value, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOIn(List<String> values) {
            addCriterion("SPKR_NO in", values, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NONotIn(List<String> values) {
            addCriterion("SPKR_NO not in", values, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOBetween(String value1, String value2) {
            addCriterion("SPKR_NO between", value1, value2, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NONotBetween(String value1, String value2) {
            addCriterion("SPKR_NO not between", value1, value2, "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andAFILENMIsNull() {
            addCriterion("AFILENM is null");
            return (Criteria) this;
        }

        public Criteria andAFILENMIsNotNull() {
            addCriterion("AFILENM is not null");
            return (Criteria) this;
        }

        public Criteria andAFILENMEqualTo(String value) {
            addCriterion("AFILENM =", value, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMNotEqualTo(String value) {
            addCriterion("AFILENM <>", value, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMGreaterThan(String value) {
            addCriterion("AFILENM >", value, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMGreaterThanOrEqualTo(String value) {
            addCriterion("AFILENM >=", value, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMLessThan(String value) {
            addCriterion("AFILENM <", value, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMLessThanOrEqualTo(String value) {
            addCriterion("AFILENM <=", value, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMLike(String value) {
            addCriterion("AFILENM like", value, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMNotLike(String value) {
            addCriterion("AFILENM not like", value, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMIn(List<String> values) {
            addCriterion("AFILENM in", values, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMNotIn(List<String> values) {
            addCriterion("AFILENM not in", values, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMBetween(String value1, String value2) {
            addCriterion("AFILENM between", value1, value2, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAFILENMNotBetween(String value1, String value2) {
            addCriterion("AFILENM not between", value1, value2, "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAR_TIMEIsNull() {
            addCriterion("AR_TIME is null");
            return (Criteria) this;
        }

        public Criteria andAR_TIMEIsNotNull() {
            addCriterion("AR_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andAR_TIMEEqualTo(String value) {
            addCriterion("AR_TIME =", value, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMENotEqualTo(String value) {
            addCriterion("AR_TIME <>", value, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMEGreaterThan(String value) {
            addCriterion("AR_TIME >", value, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("AR_TIME >=", value, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMELessThan(String value) {
            addCriterion("AR_TIME <", value, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMELessThanOrEqualTo(String value) {
            addCriterion("AR_TIME <=", value, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMELike(String value) {
            addCriterion("AR_TIME like", value, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMENotLike(String value) {
            addCriterion("AR_TIME not like", value, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMEIn(List<String> values) {
            addCriterion("AR_TIME in", values, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMENotIn(List<String> values) {
            addCriterion("AR_TIME not in", values, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMEBetween(String value1, String value2) {
            addCriterion("AR_TIME between", value1, value2, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andAR_TIMENotBetween(String value1, String value2) {
            addCriterion("AR_TIME not between", value1, value2, "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andSDCD_STIsNull() {
            addCriterion("SDCD_ST is null");
            return (Criteria) this;
        }

        public Criteria andSDCD_STIsNotNull() {
            addCriterion("SDCD_ST is not null");
            return (Criteria) this;
        }

        public Criteria andSDCD_STEqualTo(String value) {
            addCriterion("SDCD_ST =", value, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STNotEqualTo(String value) {
            addCriterion("SDCD_ST <>", value, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STGreaterThan(String value) {
            addCriterion("SDCD_ST >", value, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STGreaterThanOrEqualTo(String value) {
            addCriterion("SDCD_ST >=", value, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STLessThan(String value) {
            addCriterion("SDCD_ST <", value, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STLessThanOrEqualTo(String value) {
            addCriterion("SDCD_ST <=", value, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STLike(String value) {
            addCriterion("SDCD_ST like", value, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STNotLike(String value) {
            addCriterion("SDCD_ST not like", value, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STIn(List<String> values) {
            addCriterion("SDCD_ST in", values, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STNotIn(List<String> values) {
            addCriterion("SDCD_ST not in", values, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STBetween(String value1, String value2) {
            addCriterion("SDCD_ST between", value1, value2, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD_STNotBetween(String value1, String value2) {
            addCriterion("SDCD_ST not between", value1, value2, "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STIsNull() {
            addCriterion("SDCD1_ST is null");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STIsNotNull() {
            addCriterion("SDCD1_ST is not null");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STEqualTo(String value) {
            addCriterion("SDCD1_ST =", value, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STNotEqualTo(String value) {
            addCriterion("SDCD1_ST <>", value, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STGreaterThan(String value) {
            addCriterion("SDCD1_ST >", value, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STGreaterThanOrEqualTo(String value) {
            addCriterion("SDCD1_ST >=", value, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STLessThan(String value) {
            addCriterion("SDCD1_ST <", value, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STLessThanOrEqualTo(String value) {
            addCriterion("SDCD1_ST <=", value, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STLike(String value) {
            addCriterion("SDCD1_ST like", value, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STNotLike(String value) {
            addCriterion("SDCD1_ST not like", value, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STIn(List<String> values) {
            addCriterion("SDCD1_ST in", values, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STNotIn(List<String> values) {
            addCriterion("SDCD1_ST not in", values, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STBetween(String value1, String value2) {
            addCriterion("SDCD1_ST between", value1, value2, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STNotBetween(String value1, String value2) {
            addCriterion("SDCD1_ST not between", value1, value2, "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STIsNull() {
            addCriterion("SDCD2_ST is null");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STIsNotNull() {
            addCriterion("SDCD2_ST is not null");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STEqualTo(String value) {
            addCriterion("SDCD2_ST =", value, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STNotEqualTo(String value) {
            addCriterion("SDCD2_ST <>", value, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STGreaterThan(String value) {
            addCriterion("SDCD2_ST >", value, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STGreaterThanOrEqualTo(String value) {
            addCriterion("SDCD2_ST >=", value, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STLessThan(String value) {
            addCriterion("SDCD2_ST <", value, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STLessThanOrEqualTo(String value) {
            addCriterion("SDCD2_ST <=", value, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STLike(String value) {
            addCriterion("SDCD2_ST like", value, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STNotLike(String value) {
            addCriterion("SDCD2_ST not like", value, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STIn(List<String> values) {
            addCriterion("SDCD2_ST in", values, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STNotIn(List<String> values) {
            addCriterion("SDCD2_ST not in", values, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STBetween(String value1, String value2) {
            addCriterion("SDCD2_ST between", value1, value2, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STNotBetween(String value1, String value2) {
            addCriterion("SDCD2_ST not between", value1, value2, "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STIsNull() {
            addCriterion("SDCD3_ST is null");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STIsNotNull() {
            addCriterion("SDCD3_ST is not null");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STEqualTo(String value) {
            addCriterion("SDCD3_ST =", value, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STNotEqualTo(String value) {
            addCriterion("SDCD3_ST <>", value, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STGreaterThan(String value) {
            addCriterion("SDCD3_ST >", value, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STGreaterThanOrEqualTo(String value) {
            addCriterion("SDCD3_ST >=", value, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STLessThan(String value) {
            addCriterion("SDCD3_ST <", value, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STLessThanOrEqualTo(String value) {
            addCriterion("SDCD3_ST <=", value, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STLike(String value) {
            addCriterion("SDCD3_ST like", value, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STNotLike(String value) {
            addCriterion("SDCD3_ST not like", value, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STIn(List<String> values) {
            addCriterion("SDCD3_ST in", values, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STNotIn(List<String> values) {
            addCriterion("SDCD3_ST not in", values, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STBetween(String value1, String value2) {
            addCriterion("SDCD3_ST between", value1, value2, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STNotBetween(String value1, String value2) {
            addCriterion("SDCD3_ST not between", value1, value2, "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPLikeInsensitive(String value) {
            addCriterion("upper(LN_RMCK_CMP) like", value.toUpperCase(), "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLikeInsensitive(String value) {
            addCriterion("upper(LN_DEV) like", value.toUpperCase(), "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLikeInsensitive(String value) {
            addCriterion("upper(DEV_NUM) like", value.toUpperCase(), "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andWAKE_STLikeInsensitive(String value) {
            addCriterion("upper(WAKE_ST) like", value.toUpperCase(), "WAKE_ST");
            return (Criteria) this;
        }

        public Criteria andSENS_STSLikeInsensitive(String value) {
            addCriterion("upper(SENS_STS) like", value.toUpperCase(), "SENS_STS");
            return (Criteria) this;
        }

        public Criteria andWRBK_STSLikeInsensitive(String value) {
            addCriterion("upper(WRBK_STS) like", value.toUpperCase(), "WRBK_STS");
            return (Criteria) this;
        }

        public Criteria andDSTB_STSLikeInsensitive(String value) {
            addCriterion("upper(DSTB_STS) like", value.toUpperCase(), "DSTB_STS");
            return (Criteria) this;
        }

        public Criteria andENVI_STSLikeInsensitive(String value) {
            addCriterion("upper(ENVI_STS) like", value.toUpperCase(), "ENVI_STS");
            return (Criteria) this;
        }

        public Criteria andPOST_STSLikeInsensitive(String value) {
            addCriterion("upper(POST_STS) like", value.toUpperCase(), "POST_STS");
            return (Criteria) this;
        }

        public Criteria andDROP_STSLikeInsensitive(String value) {
            addCriterion("upper(DROP_STS) like", value.toUpperCase(), "DROP_STS");
            return (Criteria) this;
        }

        public Criteria andBLOU_STSLikeInsensitive(String value) {
            addCriterion("upper(BLOU_STS) like", value.toUpperCase(), "BLOU_STS");
            return (Criteria) this;
        }

        public Criteria andTANP_STSLikeInsensitive(String value) {
            addCriterion("upper(TANP_STS) like", value.toUpperCase(), "TANP_STS");
            return (Criteria) this;
        }

        public Criteria andBKDW_STLikeInsensitive(String value) {
            addCriterion("upper(BKDW_ST) like", value.toUpperCase(), "BKDW_ST");
            return (Criteria) this;
        }

        public Criteria andLWVL_STLikeInsensitive(String value) {
            addCriterion("upper(LWVL_ST) like", value.toUpperCase(), "LWVL_ST");
            return (Criteria) this;
        }

        public Criteria andLED_STSLikeInsensitive(String value) {
            addCriterion("upper(LED_STS) like", value.toUpperCase(), "LED_STS");
            return (Criteria) this;
        }

        public Criteria andVIDE_LKLikeInsensitive(String value) {
            addCriterion("upper(VIDE_LK) like", value.toUpperCase(), "VIDE_LK");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOLikeInsensitive(String value) {
            addCriterion("upper(CAMR_NO) like", value.toUpperCase(), "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andVFILENMLikeInsensitive(String value) {
            addCriterion("upper(VFILENM) like", value.toUpperCase(), "VFILENM");
            return (Criteria) this;
        }

        public Criteria andFL_RATELikeInsensitive(String value) {
            addCriterion("upper(FL_RATE) like", value.toUpperCase(), "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andVR_TIMELikeInsensitive(String value) {
            addCriterion("upper(VR_TIME) like", value.toUpperCase(), "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTLikeInsensitive(String value) {
            addCriterion("upper(VR_ACNT) like", value.toUpperCase(), "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTLikeInsensitive(String value) {
            addCriterion("upper(VR_STRT) like", value.toUpperCase(), "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTLikeInsensitive(String value) {
            addCriterion("upper(VFCOUNT) like", value.toUpperCase(), "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKLikeInsensitive(String value) {
            addCriterion("upper(MCSP_LK) like", value.toUpperCase(), "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andINTP_NOLikeInsensitive(String value) {
            addCriterion("upper(INTP_NO) like", value.toUpperCase(), "INTP_NO");
            return (Criteria) this;
        }

        public Criteria andMICP_NOLikeInsensitive(String value) {
            addCriterion("upper(MICP_NO) like", value.toUpperCase(), "MICP_NO");
            return (Criteria) this;
        }

        public Criteria andSPKR_NOLikeInsensitive(String value) {
            addCriterion("upper(SPKR_NO) like", value.toUpperCase(), "SPKR_NO");
            return (Criteria) this;
        }

        public Criteria andAFILENMLikeInsensitive(String value) {
            addCriterion("upper(AFILENM) like", value.toUpperCase(), "AFILENM");
            return (Criteria) this;
        }

        public Criteria andAR_TIMELikeInsensitive(String value) {
            addCriterion("upper(AR_TIME) like", value.toUpperCase(), "AR_TIME");
            return (Criteria) this;
        }

        public Criteria andSDCD_STLikeInsensitive(String value) {
            addCriterion("upper(SDCD_ST) like", value.toUpperCase(), "SDCD_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD1_STLikeInsensitive(String value) {
            addCriterion("upper(SDCD1_ST) like", value.toUpperCase(), "SDCD1_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD2_STLikeInsensitive(String value) {
            addCriterion("upper(SDCD2_ST) like", value.toUpperCase(), "SDCD2_ST");
            return (Criteria) this;
        }

        public Criteria andSDCD3_STLikeInsensitive(String value) {
            addCriterion("upper(SDCD3_ST) like", value.toUpperCase(), "SDCD3_ST");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_RMCK_CMP
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_RMCK_CMP null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}