package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MGcSend extends MGcSendKey implements Serializable {
    /**
     * GC送信（DN0）フラグ
     */
    private String GC_DN0_SEND_FLG;

    /**
     * GC送信（DF0）フラグ
     */
    private String GC_DF0_SEND_FLG;

    /**
     * M_GC_SEND
     */
    private static final long serialVersionUID = 1L;

    /**
     * GC送信（DN0）フラグ
     * @return GC_DN0_SEND_FLG GC送信（DN0）フラグ
     */
    public String getGC_DN0_SEND_FLG() {
        return GC_DN0_SEND_FLG;
    }

    /**
     * GC送信（DN0）フラグ
     * @param GC_DN0_SEND_FLG GC送信（DN0）フラグ
     */
    public void setGC_DN0_SEND_FLG(String GC_DN0_SEND_FLG) {
        this.GC_DN0_SEND_FLG = GC_DN0_SEND_FLG == null ? null : GC_DN0_SEND_FLG.trim();
    }

    /**
     * GC送信（DF0）フラグ
     * @return GC_DF0_SEND_FLG GC送信（DF0）フラグ
     */
    public String getGC_DF0_SEND_FLG() {
        return GC_DF0_SEND_FLG;
    }

    /**
     * GC送信（DF0）フラグ
     * @param GC_DF0_SEND_FLG GC送信（DF0）フラグ
     */
    public void setGC_DF0_SEND_FLG(String GC_DF0_SEND_FLG) {
        this.GC_DF0_SEND_FLG = GC_DF0_SEND_FLG == null ? null : GC_DF0_SEND_FLG.trim();
    }
}