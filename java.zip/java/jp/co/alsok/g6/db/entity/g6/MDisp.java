package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MDisp implements Serializable {
    /**
     * 画面ID
     */
    private String DISP_ID;

    /**
     * 画面名
     */
    private String DISP_NM;

    /**
     * 表示順
     */
    private String ORDER_NUM;

    /**
     * メニューパス情報
     */
    private String MENUPASS_INF;

    /**
     * 地区別権限有無
     */
    private String CHIKU_FLG;

    /**
     * M_DISP
     */
    private static final long serialVersionUID = 1L;

    /**
     * 画面ID
     * @return DISP_ID 画面ID
     */
    public String getDISP_ID() {
        return DISP_ID;
    }

    /**
     * 画面ID
     * @param DISP_ID 画面ID
     */
    public void setDISP_ID(String DISP_ID) {
        this.DISP_ID = DISP_ID == null ? null : DISP_ID.trim();
    }

    /**
     * 画面名
     * @return DISP_NM 画面名
     */
    public String getDISP_NM() {
        return DISP_NM;
    }

    /**
     * 画面名
     * @param DISP_NM 画面名
     */
    public void setDISP_NM(String DISP_NM) {
        this.DISP_NM = DISP_NM == null ? null : DISP_NM.trim();
    }

    /**
     * 表示順
     * @return ORDER_NUM 表示順
     */
    public String getORDER_NUM() {
        return ORDER_NUM;
    }

    /**
     * 表示順
     * @param ORDER_NUM 表示順
     */
    public void setORDER_NUM(String ORDER_NUM) {
        this.ORDER_NUM = ORDER_NUM == null ? null : ORDER_NUM.trim();
    }

    /**
     * メニューパス情報
     * @return MENUPASS_INF メニューパス情報
     */
    public String getMENUPASS_INF() {
        return MENUPASS_INF;
    }

    /**
     * メニューパス情報
     * @param MENUPASS_INF メニューパス情報
     */
    public void setMENUPASS_INF(String MENUPASS_INF) {
        this.MENUPASS_INF = MENUPASS_INF == null ? null : MENUPASS_INF.trim();
    }

    /**
     * 地区別権限有無
     * @return CHIKU_FLG 地区別権限有無
     */
    public String getCHIKU_FLG() {
        return CHIKU_FLG;
    }

    /**
     * 地区別権限有無
     * @param CHIKU_FLG 地区別権限有無
     */
    public void setCHIKU_FLG(String CHIKU_FLG) {
        this.CHIKU_FLG = CHIKU_FLG == null ? null : CHIKU_FLG.trim();
    }
}