package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MMlKindKey implements Serializable {
    /**
     * 警備サービス種別コード
     */
    private String KB_SERVICE_CD;

    /**
     * 信号種別１
     */
    private String SIG_KIND1;

    /**
     * 信号種別２
     */
    private String SIG_KIND2;

    /**
     * M_ML_KIND
     */
    private static final long serialVersionUID = 1L;

    /**
     * 警備サービス種別コード
     * @return KB_SERVICE_CD 警備サービス種別コード
     */
    public String getKB_SERVICE_CD() {
        return KB_SERVICE_CD;
    }

    /**
     * 警備サービス種別コード
     * @param KB_SERVICE_CD 警備サービス種別コード
     */
    public void setKB_SERVICE_CD(String KB_SERVICE_CD) {
        this.KB_SERVICE_CD = KB_SERVICE_CD == null ? null : KB_SERVICE_CD.trim();
    }

    /**
     * 信号種別１
     * @return SIG_KIND1 信号種別１
     */
    public String getSIG_KIND1() {
        return SIG_KIND1;
    }

    /**
     * 信号種別１
     * @param SIG_KIND1 信号種別１
     */
    public void setSIG_KIND1(String SIG_KIND1) {
        this.SIG_KIND1 = SIG_KIND1 == null ? null : SIG_KIND1.trim();
    }

    /**
     * 信号種別２
     * @return SIG_KIND2 信号種別２
     */
    public String getSIG_KIND2() {
        return SIG_KIND2;
    }

    /**
     * 信号種別２
     * @param SIG_KIND2 信号種別２
     */
    public void setSIG_KIND2(String SIG_KIND2) {
        this.SIG_KIND2 = SIG_KIND2 == null ? null : SIG_KIND2.trim();
    }
}