package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CRmCmdInfWithBLOBs extends CRmCmdInf implements Serializable {
    /**
     * コマンド情報タグ
     */
    private String CMD_INF_TAG_MSG;

    /**
     * 完了通知用タグ
     */
    private String CMD_CMP_TAG_MSG;

    /**
     * C_RM_CMD_INF
     */
    private static final long serialVersionUID = 1L;

    /**
     * コマンド情報タグ
     * @return CMD_INF_TAG_MSG コマンド情報タグ
     */
    public String getCMD_INF_TAG_MSG() {
        return CMD_INF_TAG_MSG;
    }

    /**
     * コマンド情報タグ
     * @param CMD_INF_TAG_MSG コマンド情報タグ
     */
    public void setCMD_INF_TAG_MSG(String CMD_INF_TAG_MSG) {
        this.CMD_INF_TAG_MSG = CMD_INF_TAG_MSG == null ? null : CMD_INF_TAG_MSG.trim();
    }

    /**
     * 完了通知用タグ
     * @return CMD_CMP_TAG_MSG 完了通知用タグ
     */
    public String getCMD_CMP_TAG_MSG() {
        return CMD_CMP_TAG_MSG;
    }

    /**
     * 完了通知用タグ
     * @param CMD_CMP_TAG_MSG 完了通知用タグ
     */
    public void setCMD_CMP_TAG_MSG(String CMD_CMP_TAG_MSG) {
        this.CMD_CMP_TAG_MSG = CMD_CMP_TAG_MSG == null ? null : CMD_CMP_TAG_MSG.trim();
    }
}