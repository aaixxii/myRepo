package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;

public class KRoleAuthKey implements Serializable {
    /**
     * LN_ALSOKロール論理番号
     */
    private String LN_ROLE_ALSOK;

    /**
     * ALSOKアカウント権限ID
     */
    private String ALSOK_ACNT_AUTH_ID;

    /**
     * K_ROLE_AUTH
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ALSOKロール論理番号
     * @return LN_ROLE_ALSOK LN_ALSOKロール論理番号
     */
    public String getLN_ROLE_ALSOK() {
        return LN_ROLE_ALSOK;
    }

    /**
     * LN_ALSOKロール論理番号
     * @param LN_ROLE_ALSOK LN_ALSOKロール論理番号
     */
    public void setLN_ROLE_ALSOK(String LN_ROLE_ALSOK) {
        this.LN_ROLE_ALSOK = LN_ROLE_ALSOK == null ? null : LN_ROLE_ALSOK.trim();
    }

    /**
     * ALSOKアカウント権限ID
     * @return ALSOK_ACNT_AUTH_ID ALSOKアカウント権限ID
     */
    public String getALSOK_ACNT_AUTH_ID() {
        return ALSOK_ACNT_AUTH_ID;
    }

    /**
     * ALSOKアカウント権限ID
     * @param ALSOK_ACNT_AUTH_ID ALSOKアカウント権限ID
     */
    public void setALSOK_ACNT_AUTH_ID(String ALSOK_ACNT_AUTH_ID) {
        this.ALSOK_ACNT_AUTH_ID = ALSOK_ACNT_AUTH_ID == null ? null : ALSOK_ACNT_AUTH_ID.trim();
    }
}