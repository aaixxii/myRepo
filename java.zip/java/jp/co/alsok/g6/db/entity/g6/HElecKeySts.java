package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HElecKeySts implements Serializable {
    /**
     * LN_制御状態読出履歴論理番号
     */
    private String LN_ELEC_KEY_STS;

    /**
     * LN_設置機器論理番号
     */
    private String LN_DEV;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * 施解錠状態
     */
    private String EKTM_SJ_STS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_ELEC_KEY_STS
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_制御状態読出履歴論理番号
     * @return LN_ELEC_KEY_STS LN_制御状態読出履歴論理番号
     */
    public String getLN_ELEC_KEY_STS() {
        return LN_ELEC_KEY_STS;
    }

    /**
     * LN_制御状態読出履歴論理番号
     * @param LN_ELEC_KEY_STS LN_制御状態読出履歴論理番号
     */
    public void setLN_ELEC_KEY_STS(String LN_ELEC_KEY_STS) {
        this.LN_ELEC_KEY_STS = LN_ELEC_KEY_STS == null ? null : LN_ELEC_KEY_STS.trim();
    }

    /**
     * LN_設置機器論理番号
     * @return LN_DEV LN_設置機器論理番号
     */
    public String getLN_DEV() {
        return LN_DEV;
    }

    /**
     * LN_設置機器論理番号
     * @param LN_DEV LN_設置機器論理番号
     */
    public void setLN_DEV(String LN_DEV) {
        this.LN_DEV = LN_DEV == null ? null : LN_DEV.trim();
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * 施解錠状態
     * @return EKTM_SJ_STS 施解錠状態
     */
    public String getEKTM_SJ_STS() {
        return EKTM_SJ_STS;
    }

    /**
     * 施解錠状態
     * @param EKTM_SJ_STS 施解錠状態
     */
    public void setEKTM_SJ_STS(String EKTM_SJ_STS) {
        this.EKTM_SJ_STS = EKTM_SJ_STS == null ? null : EKTM_SJ_STS.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}