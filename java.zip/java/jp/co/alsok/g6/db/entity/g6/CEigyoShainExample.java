package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CEigyoShainExample {
    /**
     * C_EIGYO_SHAIN
     */
    protected String orderByClause;

    /**
     * C_EIGYO_SHAIN
     */
    protected boolean distinct;

    /**
     * C_EIGYO_SHAIN
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public CEigyoShainExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * C_EIGYO_SHAIN null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andKAISHA_CDIsNull() {
            addCriterion("KAISHA_CD is null");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDIsNotNull() {
            addCriterion("KAISHA_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDEqualTo(String value) {
            addCriterion("KAISHA_CD =", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotEqualTo(String value) {
            addCriterion("KAISHA_CD <>", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDGreaterThan(String value) {
            addCriterion("KAISHA_CD >", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KAISHA_CD >=", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLessThan(String value) {
            addCriterion("KAISHA_CD <", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLessThanOrEqualTo(String value) {
            addCriterion("KAISHA_CD <=", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLike(String value) {
            addCriterion("KAISHA_CD like", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotLike(String value) {
            addCriterion("KAISHA_CD not like", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDIn(List<String> values) {
            addCriterion("KAISHA_CD in", values, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotIn(List<String> values) {
            addCriterion("KAISHA_CD not in", values, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDBetween(String value1, String value2) {
            addCriterion("KAISHA_CD between", value1, value2, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotBetween(String value1, String value2) {
            addCriterion("KAISHA_CD not between", value1, value2, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOIsNull() {
            addCriterion("SHAIN_NO is null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOIsNotNull() {
            addCriterion("SHAIN_NO is not null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOEqualTo(String value) {
            addCriterion("SHAIN_NO =", value, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NONotEqualTo(String value) {
            addCriterion("SHAIN_NO <>", value, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOGreaterThan(String value) {
            addCriterion("SHAIN_NO >", value, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOGreaterThanOrEqualTo(String value) {
            addCriterion("SHAIN_NO >=", value, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOLessThan(String value) {
            addCriterion("SHAIN_NO <", value, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOLessThanOrEqualTo(String value) {
            addCriterion("SHAIN_NO <=", value, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOLike(String value) {
            addCriterion("SHAIN_NO like", value, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NONotLike(String value) {
            addCriterion("SHAIN_NO not like", value, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOIn(List<String> values) {
            addCriterion("SHAIN_NO in", values, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NONotIn(List<String> values) {
            addCriterion("SHAIN_NO not in", values, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOBetween(String value1, String value2) {
            addCriterion("SHAIN_NO between", value1, value2, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NONotBetween(String value1, String value2) {
            addCriterion("SHAIN_NO not between", value1, value2, "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIsNull() {
            addCriterion("TEKIYO_KAISHI_YMD is null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIsNotNull() {
            addCriterion("TEKIYO_KAISHI_YMD is not null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD =", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <>", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDGreaterThan(String value) {
            addCriterion("TEKIYO_KAISHI_YMD >", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDGreaterThanOrEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD >=", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLessThan(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLessThanOrEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <=", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLike(String value) {
            addCriterion("TEKIYO_KAISHI_YMD like", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotLike(String value) {
            addCriterion("TEKIYO_KAISHI_YMD not like", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIn(List<String> values) {
            addCriterion("TEKIYO_KAISHI_YMD in", values, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotIn(List<String> values) {
            addCriterion("TEKIYO_KAISHI_YMD not in", values, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDBetween(String value1, String value2) {
            addCriterion("TEKIYO_KAISHI_YMD between", value1, value2, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotBetween(String value1, String value2) {
            addCriterion("TEKIYO_KAISHI_YMD not between", value1, value2, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIsNull() {
            addCriterion("TEKIYO_SHURYO_YMD is null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIsNotNull() {
            addCriterion("TEKIYO_SHURYO_YMD is not null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD =", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <>", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDGreaterThan(String value) {
            addCriterion("TEKIYO_SHURYO_YMD >", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDGreaterThanOrEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD >=", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLessThan(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLessThanOrEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <=", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLike(String value) {
            addCriterion("TEKIYO_SHURYO_YMD like", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotLike(String value) {
            addCriterion("TEKIYO_SHURYO_YMD not like", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIn(List<String> values) {
            addCriterion("TEKIYO_SHURYO_YMD in", values, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotIn(List<String> values) {
            addCriterion("TEKIYO_SHURYO_YMD not in", values, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDBetween(String value1, String value2) {
            addCriterion("TEKIYO_SHURYO_YMD between", value1, value2, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotBetween(String value1, String value2) {
            addCriterion("TEKIYO_SHURYO_YMD not between", value1, value2, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDIsNull() {
            addCriterion("NYUSHA_YMD is null");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDIsNotNull() {
            addCriterion("NYUSHA_YMD is not null");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDEqualTo(String value) {
            addCriterion("NYUSHA_YMD =", value, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDNotEqualTo(String value) {
            addCriterion("NYUSHA_YMD <>", value, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDGreaterThan(String value) {
            addCriterion("NYUSHA_YMD >", value, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDGreaterThanOrEqualTo(String value) {
            addCriterion("NYUSHA_YMD >=", value, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDLessThan(String value) {
            addCriterion("NYUSHA_YMD <", value, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDLessThanOrEqualTo(String value) {
            addCriterion("NYUSHA_YMD <=", value, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDLike(String value) {
            addCriterion("NYUSHA_YMD like", value, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDNotLike(String value) {
            addCriterion("NYUSHA_YMD not like", value, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDIn(List<String> values) {
            addCriterion("NYUSHA_YMD in", values, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDNotIn(List<String> values) {
            addCriterion("NYUSHA_YMD not in", values, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDBetween(String value1, String value2) {
            addCriterion("NYUSHA_YMD between", value1, value2, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDNotBetween(String value1, String value2) {
            addCriterion("NYUSHA_YMD not between", value1, value2, "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDIsNull() {
            addCriterion("TAISHOKU_YMD is null");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDIsNotNull() {
            addCriterion("TAISHOKU_YMD is not null");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDEqualTo(String value) {
            addCriterion("TAISHOKU_YMD =", value, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDNotEqualTo(String value) {
            addCriterion("TAISHOKU_YMD <>", value, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDGreaterThan(String value) {
            addCriterion("TAISHOKU_YMD >", value, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDGreaterThanOrEqualTo(String value) {
            addCriterion("TAISHOKU_YMD >=", value, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDLessThan(String value) {
            addCriterion("TAISHOKU_YMD <", value, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDLessThanOrEqualTo(String value) {
            addCriterion("TAISHOKU_YMD <=", value, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDLike(String value) {
            addCriterion("TAISHOKU_YMD like", value, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDNotLike(String value) {
            addCriterion("TAISHOKU_YMD not like", value, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDIn(List<String> values) {
            addCriterion("TAISHOKU_YMD in", values, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDNotIn(List<String> values) {
            addCriterion("TAISHOKU_YMD not in", values, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDBetween(String value1, String value2) {
            addCriterion("TAISHOKU_YMD between", value1, value2, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDNotBetween(String value1, String value2) {
            addCriterion("TAISHOKU_YMD not between", value1, value2, "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMIsNull() {
            addCriterion("SHAIN_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMIsNotNull() {
            addCriterion("SHAIN_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMEqualTo(String value) {
            addCriterion("SHAIN_NM =", value, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMNotEqualTo(String value) {
            addCriterion("SHAIN_NM <>", value, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMGreaterThan(String value) {
            addCriterion("SHAIN_NM >", value, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHAIN_NM >=", value, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMLessThan(String value) {
            addCriterion("SHAIN_NM <", value, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMLessThanOrEqualTo(String value) {
            addCriterion("SHAIN_NM <=", value, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMLike(String value) {
            addCriterion("SHAIN_NM like", value, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMNotLike(String value) {
            addCriterion("SHAIN_NM not like", value, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMIn(List<String> values) {
            addCriterion("SHAIN_NM in", values, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMNotIn(List<String> values) {
            addCriterion("SHAIN_NM not in", values, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMBetween(String value1, String value2) {
            addCriterion("SHAIN_NM between", value1, value2, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMNotBetween(String value1, String value2) {
            addCriterion("SHAIN_NM not between", value1, value2, "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMIsNull() {
            addCriterion("SHAINSEI_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMIsNotNull() {
            addCriterion("SHAINSEI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMEqualTo(String value) {
            addCriterion("SHAINSEI_NM =", value, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMNotEqualTo(String value) {
            addCriterion("SHAINSEI_NM <>", value, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMGreaterThan(String value) {
            addCriterion("SHAINSEI_NM >", value, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHAINSEI_NM >=", value, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMLessThan(String value) {
            addCriterion("SHAINSEI_NM <", value, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMLessThanOrEqualTo(String value) {
            addCriterion("SHAINSEI_NM <=", value, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMLike(String value) {
            addCriterion("SHAINSEI_NM like", value, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMNotLike(String value) {
            addCriterion("SHAINSEI_NM not like", value, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMIn(List<String> values) {
            addCriterion("SHAINSEI_NM in", values, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMNotIn(List<String> values) {
            addCriterion("SHAINSEI_NM not in", values, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMBetween(String value1, String value2) {
            addCriterion("SHAINSEI_NM between", value1, value2, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMNotBetween(String value1, String value2) {
            addCriterion("SHAINSEI_NM not between", value1, value2, "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMIsNull() {
            addCriterion("SHAIMMEI_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMIsNotNull() {
            addCriterion("SHAIMMEI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMEqualTo(String value) {
            addCriterion("SHAIMMEI_NM =", value, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMNotEqualTo(String value) {
            addCriterion("SHAIMMEI_NM <>", value, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMGreaterThan(String value) {
            addCriterion("SHAIMMEI_NM >", value, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHAIMMEI_NM >=", value, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMLessThan(String value) {
            addCriterion("SHAIMMEI_NM <", value, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMLessThanOrEqualTo(String value) {
            addCriterion("SHAIMMEI_NM <=", value, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMLike(String value) {
            addCriterion("SHAIMMEI_NM like", value, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMNotLike(String value) {
            addCriterion("SHAIMMEI_NM not like", value, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMIn(List<String> values) {
            addCriterion("SHAIMMEI_NM in", values, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMNotIn(List<String> values) {
            addCriterion("SHAIMMEI_NM not in", values, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMBetween(String value1, String value2) {
            addCriterion("SHAIMMEI_NM between", value1, value2, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMNotBetween(String value1, String value2) {
            addCriterion("SHAIMMEI_NM not between", value1, value2, "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMIsNull() {
            addCriterion("SHAIN_HKN_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMIsNotNull() {
            addCriterion("SHAIN_HKN_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMEqualTo(String value) {
            addCriterion("SHAIN_HKN_NM =", value, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMNotEqualTo(String value) {
            addCriterion("SHAIN_HKN_NM <>", value, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMGreaterThan(String value) {
            addCriterion("SHAIN_HKN_NM >", value, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHAIN_HKN_NM >=", value, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMLessThan(String value) {
            addCriterion("SHAIN_HKN_NM <", value, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMLessThanOrEqualTo(String value) {
            addCriterion("SHAIN_HKN_NM <=", value, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMLike(String value) {
            addCriterion("SHAIN_HKN_NM like", value, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMNotLike(String value) {
            addCriterion("SHAIN_HKN_NM not like", value, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMIn(List<String> values) {
            addCriterion("SHAIN_HKN_NM in", values, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMNotIn(List<String> values) {
            addCriterion("SHAIN_HKN_NM not in", values, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMBetween(String value1, String value2) {
            addCriterion("SHAIN_HKN_NM between", value1, value2, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMNotBetween(String value1, String value2) {
            addCriterion("SHAIN_HKN_NM not between", value1, value2, "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMIsNull() {
            addCriterion("SHAIN_KN_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMIsNotNull() {
            addCriterion("SHAIN_KN_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMEqualTo(String value) {
            addCriterion("SHAIN_KN_NM =", value, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMNotEqualTo(String value) {
            addCriterion("SHAIN_KN_NM <>", value, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMGreaterThan(String value) {
            addCriterion("SHAIN_KN_NM >", value, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHAIN_KN_NM >=", value, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMLessThan(String value) {
            addCriterion("SHAIN_KN_NM <", value, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMLessThanOrEqualTo(String value) {
            addCriterion("SHAIN_KN_NM <=", value, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMLike(String value) {
            addCriterion("SHAIN_KN_NM like", value, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMNotLike(String value) {
            addCriterion("SHAIN_KN_NM not like", value, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMIn(List<String> values) {
            addCriterion("SHAIN_KN_NM in", values, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMNotIn(List<String> values) {
            addCriterion("SHAIN_KN_NM not in", values, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMBetween(String value1, String value2) {
            addCriterion("SHAIN_KN_NM between", value1, value2, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMNotBetween(String value1, String value2) {
            addCriterion("SHAIN_KN_NM not between", value1, value2, "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDIsNull() {
            addCriterion("MIBUN_CD is null");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDIsNotNull() {
            addCriterion("MIBUN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDEqualTo(String value) {
            addCriterion("MIBUN_CD =", value, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDNotEqualTo(String value) {
            addCriterion("MIBUN_CD <>", value, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDGreaterThan(String value) {
            addCriterion("MIBUN_CD >", value, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("MIBUN_CD >=", value, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDLessThan(String value) {
            addCriterion("MIBUN_CD <", value, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDLessThanOrEqualTo(String value) {
            addCriterion("MIBUN_CD <=", value, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDLike(String value) {
            addCriterion("MIBUN_CD like", value, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDNotLike(String value) {
            addCriterion("MIBUN_CD not like", value, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDIn(List<String> values) {
            addCriterion("MIBUN_CD in", values, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDNotIn(List<String> values) {
            addCriterion("MIBUN_CD not in", values, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDBetween(String value1, String value2) {
            addCriterion("MIBUN_CD between", value1, value2, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDNotBetween(String value1, String value2) {
            addCriterion("MIBUN_CD not between", value1, value2, "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMIsNull() {
            addCriterion("MIBUN_NM is null");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMIsNotNull() {
            addCriterion("MIBUN_NM is not null");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMEqualTo(String value) {
            addCriterion("MIBUN_NM =", value, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMNotEqualTo(String value) {
            addCriterion("MIBUN_NM <>", value, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMGreaterThan(String value) {
            addCriterion("MIBUN_NM >", value, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMGreaterThanOrEqualTo(String value) {
            addCriterion("MIBUN_NM >=", value, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMLessThan(String value) {
            addCriterion("MIBUN_NM <", value, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMLessThanOrEqualTo(String value) {
            addCriterion("MIBUN_NM <=", value, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMLike(String value) {
            addCriterion("MIBUN_NM like", value, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMNotLike(String value) {
            addCriterion("MIBUN_NM not like", value, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMIn(List<String> values) {
            addCriterion("MIBUN_NM in", values, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMNotIn(List<String> values) {
            addCriterion("MIBUN_NM not in", values, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMBetween(String value1, String value2) {
            addCriterion("MIBUN_NM between", value1, value2, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMNotBetween(String value1, String value2) {
            addCriterion("MIBUN_NM not between", value1, value2, "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNIsNull() {
            addCriterion("SEIBETSU_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNIsNotNull() {
            addCriterion("SEIBETSU_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNEqualTo(String value) {
            addCriterion("SEIBETSU_KBN =", value, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNNotEqualTo(String value) {
            addCriterion("SEIBETSU_KBN <>", value, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNGreaterThan(String value) {
            addCriterion("SEIBETSU_KBN >", value, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SEIBETSU_KBN >=", value, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNLessThan(String value) {
            addCriterion("SEIBETSU_KBN <", value, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNLessThanOrEqualTo(String value) {
            addCriterion("SEIBETSU_KBN <=", value, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNLike(String value) {
            addCriterion("SEIBETSU_KBN like", value, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNNotLike(String value) {
            addCriterion("SEIBETSU_KBN not like", value, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNIn(List<String> values) {
            addCriterion("SEIBETSU_KBN in", values, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNNotIn(List<String> values) {
            addCriterion("SEIBETSU_KBN not in", values, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNBetween(String value1, String value2) {
            addCriterion("SEIBETSU_KBN between", value1, value2, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNNotBetween(String value1, String value2) {
            addCriterion("SEIBETSU_KBN not between", value1, value2, "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMIsNull() {
            addCriterion("SEIBETSU_NM is null");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMIsNotNull() {
            addCriterion("SEIBETSU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMEqualTo(String value) {
            addCriterion("SEIBETSU_NM =", value, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMNotEqualTo(String value) {
            addCriterion("SEIBETSU_NM <>", value, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMGreaterThan(String value) {
            addCriterion("SEIBETSU_NM >", value, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SEIBETSU_NM >=", value, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMLessThan(String value) {
            addCriterion("SEIBETSU_NM <", value, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMLessThanOrEqualTo(String value) {
            addCriterion("SEIBETSU_NM <=", value, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMLike(String value) {
            addCriterion("SEIBETSU_NM like", value, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMNotLike(String value) {
            addCriterion("SEIBETSU_NM not like", value, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMIn(List<String> values) {
            addCriterion("SEIBETSU_NM in", values, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMNotIn(List<String> values) {
            addCriterion("SEIBETSU_NM not in", values, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMBetween(String value1, String value2) {
            addCriterion("SEIBETSU_NM between", value1, value2, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMNotBetween(String value1, String value2) {
            addCriterion("SEIBETSU_NM not between", value1, value2, "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNIsNull() {
            addCriterion("SHAIN_SAIYO_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNIsNotNull() {
            addCriterion("SHAIN_SAIYO_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNEqualTo(String value) {
            addCriterion("SHAIN_SAIYO_KBN =", value, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNNotEqualTo(String value) {
            addCriterion("SHAIN_SAIYO_KBN <>", value, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNGreaterThan(String value) {
            addCriterion("SHAIN_SAIYO_KBN >", value, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SHAIN_SAIYO_KBN >=", value, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNLessThan(String value) {
            addCriterion("SHAIN_SAIYO_KBN <", value, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNLessThanOrEqualTo(String value) {
            addCriterion("SHAIN_SAIYO_KBN <=", value, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNLike(String value) {
            addCriterion("SHAIN_SAIYO_KBN like", value, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNNotLike(String value) {
            addCriterion("SHAIN_SAIYO_KBN not like", value, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNIn(List<String> values) {
            addCriterion("SHAIN_SAIYO_KBN in", values, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNNotIn(List<String> values) {
            addCriterion("SHAIN_SAIYO_KBN not in", values, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNBetween(String value1, String value2) {
            addCriterion("SHAIN_SAIYO_KBN between", value1, value2, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNNotBetween(String value1, String value2) {
            addCriterion("SHAIN_SAIYO_KBN not between", value1, value2, "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMIsNull() {
            addCriterion("SHAIN_SAIYO__NM is null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMIsNotNull() {
            addCriterion("SHAIN_SAIYO__NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMEqualTo(String value) {
            addCriterion("SHAIN_SAIYO__NM =", value, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMNotEqualTo(String value) {
            addCriterion("SHAIN_SAIYO__NM <>", value, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMGreaterThan(String value) {
            addCriterion("SHAIN_SAIYO__NM >", value, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHAIN_SAIYO__NM >=", value, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMLessThan(String value) {
            addCriterion("SHAIN_SAIYO__NM <", value, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMLessThanOrEqualTo(String value) {
            addCriterion("SHAIN_SAIYO__NM <=", value, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMLike(String value) {
            addCriterion("SHAIN_SAIYO__NM like", value, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMNotLike(String value) {
            addCriterion("SHAIN_SAIYO__NM not like", value, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMIn(List<String> values) {
            addCriterion("SHAIN_SAIYO__NM in", values, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMNotIn(List<String> values) {
            addCriterion("SHAIN_SAIYO__NM not in", values, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMBetween(String value1, String value2) {
            addCriterion("SHAIN_SAIYO__NM between", value1, value2, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMNotBetween(String value1, String value2) {
            addCriterion("SHAIN_SAIYO__NM not between", value1, value2, "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGIsNull() {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGIsNotNull() {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGEqualTo(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG =", value, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGNotEqualTo(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG <>", value, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGGreaterThan(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG >", value, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG >=", value, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGLessThan(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG <", value, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGLessThanOrEqualTo(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG <=", value, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGLike(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG like", value, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGNotLike(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG not like", value, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGIn(List<String> values) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG in", values, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGNotIn(List<String> values) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG not in", values, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGBetween(String value1, String value2) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG between", value1, value2, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGNotBetween(String value1, String value2) {
            addCriterion("SHAKAI_HOKEN_KANYU_FLG not between", value1, value2, "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMIsNull() {
            addCriterion("SHAKAI_HOKEN_KANYU_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMIsNotNull() {
            addCriterion("SHAKAI_HOKEN_KANYU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMEqualTo(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM =", value, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMNotEqualTo(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM <>", value, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMGreaterThan(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM >", value, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM >=", value, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMLessThan(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM <", value, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMLessThanOrEqualTo(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM <=", value, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMLike(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM like", value, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMNotLike(String value) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM not like", value, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMIn(List<String> values) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM in", values, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMNotIn(List<String> values) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM not in", values, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMBetween(String value1, String value2) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM between", value1, value2, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMNotBetween(String value1, String value2) {
            addCriterion("SHAKAI_HOKEN_KANYU_NM not between", value1, value2, "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDIsNull() {
            addCriterion("YAKUSHOKU_CD is null");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDIsNotNull() {
            addCriterion("YAKUSHOKU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDEqualTo(String value) {
            addCriterion("YAKUSHOKU_CD =", value, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDNotEqualTo(String value) {
            addCriterion("YAKUSHOKU_CD <>", value, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDGreaterThan(String value) {
            addCriterion("YAKUSHOKU_CD >", value, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("YAKUSHOKU_CD >=", value, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDLessThan(String value) {
            addCriterion("YAKUSHOKU_CD <", value, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDLessThanOrEqualTo(String value) {
            addCriterion("YAKUSHOKU_CD <=", value, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDLike(String value) {
            addCriterion("YAKUSHOKU_CD like", value, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDNotLike(String value) {
            addCriterion("YAKUSHOKU_CD not like", value, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDIn(List<String> values) {
            addCriterion("YAKUSHOKU_CD in", values, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDNotIn(List<String> values) {
            addCriterion("YAKUSHOKU_CD not in", values, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDBetween(String value1, String value2) {
            addCriterion("YAKUSHOKU_CD between", value1, value2, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDNotBetween(String value1, String value2) {
            addCriterion("YAKUSHOKU_CD not between", value1, value2, "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMIsNull() {
            addCriterion("YAKUSHOKU_NM is null");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMIsNotNull() {
            addCriterion("YAKUSHOKU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMEqualTo(String value) {
            addCriterion("YAKUSHOKU_NM =", value, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMNotEqualTo(String value) {
            addCriterion("YAKUSHOKU_NM <>", value, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMGreaterThan(String value) {
            addCriterion("YAKUSHOKU_NM >", value, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("YAKUSHOKU_NM >=", value, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMLessThan(String value) {
            addCriterion("YAKUSHOKU_NM <", value, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMLessThanOrEqualTo(String value) {
            addCriterion("YAKUSHOKU_NM <=", value, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMLike(String value) {
            addCriterion("YAKUSHOKU_NM like", value, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMNotLike(String value) {
            addCriterion("YAKUSHOKU_NM not like", value, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMIn(List<String> values) {
            addCriterion("YAKUSHOKU_NM in", values, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMNotIn(List<String> values) {
            addCriterion("YAKUSHOKU_NM not in", values, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMBetween(String value1, String value2) {
            addCriterion("YAKUSHOKU_NM between", value1, value2, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMNotBetween(String value1, String value2) {
            addCriterion("YAKUSHOKU_NM not between", value1, value2, "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMIsNull() {
            addCriterion("YAKUSHOKU_RNM is null");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMIsNotNull() {
            addCriterion("YAKUSHOKU_RNM is not null");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMEqualTo(String value) {
            addCriterion("YAKUSHOKU_RNM =", value, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMNotEqualTo(String value) {
            addCriterion("YAKUSHOKU_RNM <>", value, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMGreaterThan(String value) {
            addCriterion("YAKUSHOKU_RNM >", value, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMGreaterThanOrEqualTo(String value) {
            addCriterion("YAKUSHOKU_RNM >=", value, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMLessThan(String value) {
            addCriterion("YAKUSHOKU_RNM <", value, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMLessThanOrEqualTo(String value) {
            addCriterion("YAKUSHOKU_RNM <=", value, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMLike(String value) {
            addCriterion("YAKUSHOKU_RNM like", value, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMNotLike(String value) {
            addCriterion("YAKUSHOKU_RNM not like", value, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMIn(List<String> values) {
            addCriterion("YAKUSHOKU_RNM in", values, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMNotIn(List<String> values) {
            addCriterion("YAKUSHOKU_RNM not in", values, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMBetween(String value1, String value2) {
            addCriterion("YAKUSHOKU_RNM between", value1, value2, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMNotBetween(String value1, String value2) {
            addCriterion("YAKUSHOKU_RNM not between", value1, value2, "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDIsNull() {
            addCriterion("SHOKUMU_CD is null");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDIsNotNull() {
            addCriterion("SHOKUMU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDEqualTo(String value) {
            addCriterion("SHOKUMU_CD =", value, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDNotEqualTo(String value) {
            addCriterion("SHOKUMU_CD <>", value, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDGreaterThan(String value) {
            addCriterion("SHOKUMU_CD >", value, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SHOKUMU_CD >=", value, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDLessThan(String value) {
            addCriterion("SHOKUMU_CD <", value, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDLessThanOrEqualTo(String value) {
            addCriterion("SHOKUMU_CD <=", value, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDLike(String value) {
            addCriterion("SHOKUMU_CD like", value, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDNotLike(String value) {
            addCriterion("SHOKUMU_CD not like", value, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDIn(List<String> values) {
            addCriterion("SHOKUMU_CD in", values, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDNotIn(List<String> values) {
            addCriterion("SHOKUMU_CD not in", values, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDBetween(String value1, String value2) {
            addCriterion("SHOKUMU_CD between", value1, value2, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDNotBetween(String value1, String value2) {
            addCriterion("SHOKUMU_CD not between", value1, value2, "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMIsNull() {
            addCriterion("SHOKUMU_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMIsNotNull() {
            addCriterion("SHOKUMU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMEqualTo(String value) {
            addCriterion("SHOKUMU_NM =", value, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMNotEqualTo(String value) {
            addCriterion("SHOKUMU_NM <>", value, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMGreaterThan(String value) {
            addCriterion("SHOKUMU_NM >", value, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHOKUMU_NM >=", value, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMLessThan(String value) {
            addCriterion("SHOKUMU_NM <", value, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMLessThanOrEqualTo(String value) {
            addCriterion("SHOKUMU_NM <=", value, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMLike(String value) {
            addCriterion("SHOKUMU_NM like", value, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMNotLike(String value) {
            addCriterion("SHOKUMU_NM not like", value, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMIn(List<String> values) {
            addCriterion("SHOKUMU_NM in", values, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMNotIn(List<String> values) {
            addCriterion("SHOKUMU_NM not in", values, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMBetween(String value1, String value2) {
            addCriterion("SHOKUMU_NM between", value1, value2, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMNotBetween(String value1, String value2) {
            addCriterion("SHOKUMU_NM not between", value1, value2, "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMIsNull() {
            addCriterion("SHOKUMU_RNM is null");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMIsNotNull() {
            addCriterion("SHOKUMU_RNM is not null");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMEqualTo(String value) {
            addCriterion("SHOKUMU_RNM =", value, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMNotEqualTo(String value) {
            addCriterion("SHOKUMU_RNM <>", value, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMGreaterThan(String value) {
            addCriterion("SHOKUMU_RNM >", value, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMGreaterThanOrEqualTo(String value) {
            addCriterion("SHOKUMU_RNM >=", value, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMLessThan(String value) {
            addCriterion("SHOKUMU_RNM <", value, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMLessThanOrEqualTo(String value) {
            addCriterion("SHOKUMU_RNM <=", value, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMLike(String value) {
            addCriterion("SHOKUMU_RNM like", value, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMNotLike(String value) {
            addCriterion("SHOKUMU_RNM not like", value, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMIn(List<String> values) {
            addCriterion("SHOKUMU_RNM in", values, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMNotIn(List<String> values) {
            addCriterion("SHOKUMU_RNM not in", values, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMBetween(String value1, String value2) {
            addCriterion("SHOKUMU_RNM between", value1, value2, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMNotBetween(String value1, String value2) {
            addCriterion("SHOKUMU_RNM not between", value1, value2, "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDIsNull() {
            addCriterion("JIGYO_SEGMENT_CD is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDIsNotNull() {
            addCriterion("JIGYO_SEGMENT_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDEqualTo(String value) {
            addCriterion("JIGYO_SEGMENT_CD =", value, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDNotEqualTo(String value) {
            addCriterion("JIGYO_SEGMENT_CD <>", value, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDGreaterThan(String value) {
            addCriterion("JIGYO_SEGMENT_CD >", value, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_SEGMENT_CD >=", value, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDLessThan(String value) {
            addCriterion("JIGYO_SEGMENT_CD <", value, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_SEGMENT_CD <=", value, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDLike(String value) {
            addCriterion("JIGYO_SEGMENT_CD like", value, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDNotLike(String value) {
            addCriterion("JIGYO_SEGMENT_CD not like", value, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDIn(List<String> values) {
            addCriterion("JIGYO_SEGMENT_CD in", values, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDNotIn(List<String> values) {
            addCriterion("JIGYO_SEGMENT_CD not in", values, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDBetween(String value1, String value2) {
            addCriterion("JIGYO_SEGMENT_CD between", value1, value2, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_SEGMENT_CD not between", value1, value2, "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMIsNull() {
            addCriterion("JIGYO_SEGMENT_NM is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMIsNotNull() {
            addCriterion("JIGYO_SEGMENT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMEqualTo(String value) {
            addCriterion("JIGYO_SEGMENT_NM =", value, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMNotEqualTo(String value) {
            addCriterion("JIGYO_SEGMENT_NM <>", value, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMGreaterThan(String value) {
            addCriterion("JIGYO_SEGMENT_NM >", value, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_SEGMENT_NM >=", value, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMLessThan(String value) {
            addCriterion("JIGYO_SEGMENT_NM <", value, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_SEGMENT_NM <=", value, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMLike(String value) {
            addCriterion("JIGYO_SEGMENT_NM like", value, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMNotLike(String value) {
            addCriterion("JIGYO_SEGMENT_NM not like", value, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMIn(List<String> values) {
            addCriterion("JIGYO_SEGMENT_NM in", values, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMNotIn(List<String> values) {
            addCriterion("JIGYO_SEGMENT_NM not in", values, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMBetween(String value1, String value2) {
            addCriterion("JIGYO_SEGMENT_NM between", value1, value2, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMNotBetween(String value1, String value2) {
            addCriterion("JIGYO_SEGMENT_NM not between", value1, value2, "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDIsNull() {
            addCriterion("SHOKUSHU_CD is null");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDIsNotNull() {
            addCriterion("SHOKUSHU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDEqualTo(String value) {
            addCriterion("SHOKUSHU_CD =", value, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDNotEqualTo(String value) {
            addCriterion("SHOKUSHU_CD <>", value, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDGreaterThan(String value) {
            addCriterion("SHOKUSHU_CD >", value, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SHOKUSHU_CD >=", value, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDLessThan(String value) {
            addCriterion("SHOKUSHU_CD <", value, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDLessThanOrEqualTo(String value) {
            addCriterion("SHOKUSHU_CD <=", value, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDLike(String value) {
            addCriterion("SHOKUSHU_CD like", value, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDNotLike(String value) {
            addCriterion("SHOKUSHU_CD not like", value, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDIn(List<String> values) {
            addCriterion("SHOKUSHU_CD in", values, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDNotIn(List<String> values) {
            addCriterion("SHOKUSHU_CD not in", values, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDBetween(String value1, String value2) {
            addCriterion("SHOKUSHU_CD between", value1, value2, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDNotBetween(String value1, String value2) {
            addCriterion("SHOKUSHU_CD not between", value1, value2, "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMIsNull() {
            addCriterion("SHOKUSHU_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMIsNotNull() {
            addCriterion("SHOKUSHU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMEqualTo(String value) {
            addCriterion("SHOKUSHU_NM =", value, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMNotEqualTo(String value) {
            addCriterion("SHOKUSHU_NM <>", value, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMGreaterThan(String value) {
            addCriterion("SHOKUSHU_NM >", value, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHOKUSHU_NM >=", value, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMLessThan(String value) {
            addCriterion("SHOKUSHU_NM <", value, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMLessThanOrEqualTo(String value) {
            addCriterion("SHOKUSHU_NM <=", value, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMLike(String value) {
            addCriterion("SHOKUSHU_NM like", value, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMNotLike(String value) {
            addCriterion("SHOKUSHU_NM not like", value, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMIn(List<String> values) {
            addCriterion("SHOKUSHU_NM in", values, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMNotIn(List<String> values) {
            addCriterion("SHOKUSHU_NM not in", values, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMBetween(String value1, String value2) {
            addCriterion("SHOKUSHU_NM between", value1, value2, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMNotBetween(String value1, String value2) {
            addCriterion("SHOKUSHU_NM not between", value1, value2, "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01IsNull() {
            addCriterion("YOBI_KOMOKU_01 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01IsNotNull() {
            addCriterion("YOBI_KOMOKU_01 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 =", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 <>", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_01 >", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 >=", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LessThan(String value) {
            addCriterion("YOBI_KOMOKU_01 <", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 <=", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01Like(String value) {
            addCriterion("YOBI_KOMOKU_01 like", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotLike(String value) {
            addCriterion("YOBI_KOMOKU_01 not like", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01In(List<String> values) {
            addCriterion("YOBI_KOMOKU_01 in", values, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_01 not in", values, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_01 between", value1, value2, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_01 not between", value1, value2, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02IsNull() {
            addCriterion("YOBI_KOMOKU_02 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02IsNotNull() {
            addCriterion("YOBI_KOMOKU_02 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 =", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 <>", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_02 >", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 >=", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LessThan(String value) {
            addCriterion("YOBI_KOMOKU_02 <", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 <=", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02Like(String value) {
            addCriterion("YOBI_KOMOKU_02 like", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotLike(String value) {
            addCriterion("YOBI_KOMOKU_02 not like", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02In(List<String> values) {
            addCriterion("YOBI_KOMOKU_02 in", values, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_02 not in", values, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_02 between", value1, value2, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_02 not between", value1, value2, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03IsNull() {
            addCriterion("YOBI_KOMOKU_03 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03IsNotNull() {
            addCriterion("YOBI_KOMOKU_03 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 =", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 <>", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_03 >", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 >=", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LessThan(String value) {
            addCriterion("YOBI_KOMOKU_03 <", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 <=", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03Like(String value) {
            addCriterion("YOBI_KOMOKU_03 like", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotLike(String value) {
            addCriterion("YOBI_KOMOKU_03 not like", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03In(List<String> values) {
            addCriterion("YOBI_KOMOKU_03 in", values, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_03 not in", values, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_03 between", value1, value2, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_03 not between", value1, value2, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04IsNull() {
            addCriterion("YOBI_KOMOKU_04 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04IsNotNull() {
            addCriterion("YOBI_KOMOKU_04 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 =", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 <>", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_04 >", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 >=", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LessThan(String value) {
            addCriterion("YOBI_KOMOKU_04 <", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 <=", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04Like(String value) {
            addCriterion("YOBI_KOMOKU_04 like", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotLike(String value) {
            addCriterion("YOBI_KOMOKU_04 not like", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04In(List<String> values) {
            addCriterion("YOBI_KOMOKU_04 in", values, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_04 not in", values, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_04 between", value1, value2, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_04 not between", value1, value2, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05IsNull() {
            addCriterion("YOBI_KOMOKU_05 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05IsNotNull() {
            addCriterion("YOBI_KOMOKU_05 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 =", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 <>", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_05 >", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 >=", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LessThan(String value) {
            addCriterion("YOBI_KOMOKU_05 <", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 <=", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05Like(String value) {
            addCriterion("YOBI_KOMOKU_05 like", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotLike(String value) {
            addCriterion("YOBI_KOMOKU_05 not like", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05In(List<String> values) {
            addCriterion("YOBI_KOMOKU_05 in", values, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_05 not in", values, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_05 between", value1, value2, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_05 not between", value1, value2, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06IsNull() {
            addCriterion("YOBI_KOMOKU_06 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06IsNotNull() {
            addCriterion("YOBI_KOMOKU_06 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 =", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 <>", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_06 >", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 >=", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LessThan(String value) {
            addCriterion("YOBI_KOMOKU_06 <", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 <=", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06Like(String value) {
            addCriterion("YOBI_KOMOKU_06 like", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotLike(String value) {
            addCriterion("YOBI_KOMOKU_06 not like", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06In(List<String> values) {
            addCriterion("YOBI_KOMOKU_06 in", values, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_06 not in", values, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_06 between", value1, value2, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_06 not between", value1, value2, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07IsNull() {
            addCriterion("YOBI_KOMOKU_07 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07IsNotNull() {
            addCriterion("YOBI_KOMOKU_07 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 =", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 <>", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_07 >", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 >=", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LessThan(String value) {
            addCriterion("YOBI_KOMOKU_07 <", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 <=", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07Like(String value) {
            addCriterion("YOBI_KOMOKU_07 like", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotLike(String value) {
            addCriterion("YOBI_KOMOKU_07 not like", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07In(List<String> values) {
            addCriterion("YOBI_KOMOKU_07 in", values, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_07 not in", values, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_07 between", value1, value2, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_07 not between", value1, value2, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08IsNull() {
            addCriterion("YOBI_KOMOKU_08 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08IsNotNull() {
            addCriterion("YOBI_KOMOKU_08 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 =", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 <>", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_08 >", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 >=", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LessThan(String value) {
            addCriterion("YOBI_KOMOKU_08 <", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 <=", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08Like(String value) {
            addCriterion("YOBI_KOMOKU_08 like", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotLike(String value) {
            addCriterion("YOBI_KOMOKU_08 not like", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08In(List<String> values) {
            addCriterion("YOBI_KOMOKU_08 in", values, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_08 not in", values, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_08 between", value1, value2, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_08 not between", value1, value2, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09IsNull() {
            addCriterion("YOBI_KOMOKU_09 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09IsNotNull() {
            addCriterion("YOBI_KOMOKU_09 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 =", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 <>", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_09 >", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 >=", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LessThan(String value) {
            addCriterion("YOBI_KOMOKU_09 <", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 <=", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09Like(String value) {
            addCriterion("YOBI_KOMOKU_09 like", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotLike(String value) {
            addCriterion("YOBI_KOMOKU_09 not like", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09In(List<String> values) {
            addCriterion("YOBI_KOMOKU_09 in", values, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_09 not in", values, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_09 between", value1, value2, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_09 not between", value1, value2, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10IsNull() {
            addCriterion("YOBI_KOMOKU_10 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10IsNotNull() {
            addCriterion("YOBI_KOMOKU_10 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 =", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 <>", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_10 >", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 >=", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LessThan(String value) {
            addCriterion("YOBI_KOMOKU_10 <", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 <=", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10Like(String value) {
            addCriterion("YOBI_KOMOKU_10 like", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotLike(String value) {
            addCriterion("YOBI_KOMOKU_10 not like", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10In(List<String> values) {
            addCriterion("YOBI_KOMOKU_10 in", values, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_10 not in", values, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_10 between", value1, value2, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_10 not between", value1, value2, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIsNull() {
            addCriterion("REGST_TMSTMP is null");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIsNotNull() {
            addCriterion("REGST_TMSTMP is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPEqualTo(Date value) {
            addCriterion("REGST_TMSTMP =", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotEqualTo(Date value) {
            addCriterion("REGST_TMSTMP <>", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPGreaterThan(Date value) {
            addCriterion("REGST_TMSTMP >", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPGreaterThanOrEqualTo(Date value) {
            addCriterion("REGST_TMSTMP >=", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPLessThan(Date value) {
            addCriterion("REGST_TMSTMP <", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPLessThanOrEqualTo(Date value) {
            addCriterion("REGST_TMSTMP <=", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIn(List<Date> values) {
            addCriterion("REGST_TMSTMP in", values, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotIn(List<Date> values) {
            addCriterion("REGST_TMSTMP not in", values, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPBetween(Date value1, Date value2) {
            addCriterion("REGST_TMSTMP between", value1, value2, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotBetween(Date value1, Date value2) {
            addCriterion("REGST_TMSTMP not between", value1, value2, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIsNull() {
            addCriterion("REGSTR_CO_CD is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIsNotNull() {
            addCriterion("REGSTR_CO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDEqualTo(String value) {
            addCriterion("REGSTR_CO_CD =", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotEqualTo(String value) {
            addCriterion("REGSTR_CO_CD <>", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDGreaterThan(String value) {
            addCriterion("REGSTR_CO_CD >", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_CO_CD >=", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLessThan(String value) {
            addCriterion("REGSTR_CO_CD <", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_CO_CD <=", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLike(String value) {
            addCriterion("REGSTR_CO_CD like", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotLike(String value) {
            addCriterion("REGSTR_CO_CD not like", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIn(List<String> values) {
            addCriterion("REGSTR_CO_CD in", values, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotIn(List<String> values) {
            addCriterion("REGSTR_CO_CD not in", values, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDBetween(String value1, String value2) {
            addCriterion("REGSTR_CO_CD between", value1, value2, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotBetween(String value1, String value2) {
            addCriterion("REGSTR_CO_CD not between", value1, value2, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIsNull() {
            addCriterion("REGSTR_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIsNotNull() {
            addCriterion("REGSTR_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD =", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <>", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("REGSTR_SOSHIKI_CD >", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD >=", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLessThan(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <=", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLike(String value) {
            addCriterion("REGSTR_SOSHIKI_CD like", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotLike(String value) {
            addCriterion("REGSTR_SOSHIKI_CD not like", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIn(List<String> values) {
            addCriterion("REGSTR_SOSHIKI_CD in", values, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("REGSTR_SOSHIKI_CD not in", values, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("REGSTR_SOSHIKI_CD between", value1, value2, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("REGSTR_SOSHIKI_CD not between", value1, value2, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIsNull() {
            addCriterion("REGSTR_EMP_NO is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIsNotNull() {
            addCriterion("REGSTR_EMP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO =", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO <>", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOGreaterThan(String value) {
            addCriterion("REGSTR_EMP_NO >", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO >=", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLessThan(String value) {
            addCriterion("REGSTR_EMP_NO <", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO <=", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLike(String value) {
            addCriterion("REGSTR_EMP_NO like", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotLike(String value) {
            addCriterion("REGSTR_EMP_NO not like", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIn(List<String> values) {
            addCriterion("REGSTR_EMP_NO in", values, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotIn(List<String> values) {
            addCriterion("REGSTR_EMP_NO not in", values, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOBetween(String value1, String value2) {
            addCriterion("REGSTR_EMP_NO between", value1, value2, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotBetween(String value1, String value2) {
            addCriterion("REGSTR_EMP_NO not between", value1, value2, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIsNull() {
            addCriterion("REGST_GAMEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIsNotNull() {
            addCriterion("REGST_GAMEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID =", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID <>", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDGreaterThan(String value) {
            addCriterion("REGST_GAMEN_ID >", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID >=", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLessThan(String value) {
            addCriterion("REGST_GAMEN_ID <", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLessThanOrEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID <=", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLike(String value) {
            addCriterion("REGST_GAMEN_ID like", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotLike(String value) {
            addCriterion("REGST_GAMEN_ID not like", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIn(List<String> values) {
            addCriterion("REGST_GAMEN_ID in", values, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotIn(List<String> values) {
            addCriterion("REGST_GAMEN_ID not in", values, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDBetween(String value1, String value2) {
            addCriterion("REGST_GAMEN_ID between", value1, value2, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotBetween(String value1, String value2) {
            addCriterion("REGST_GAMEN_ID not between", value1, value2, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIsNull() {
            addCriterion("REGST_PGM_ID is null");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIsNotNull() {
            addCriterion("REGST_PGM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDEqualTo(String value) {
            addCriterion("REGST_PGM_ID =", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotEqualTo(String value) {
            addCriterion("REGST_PGM_ID <>", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDGreaterThan(String value) {
            addCriterion("REGST_PGM_ID >", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REGST_PGM_ID >=", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLessThan(String value) {
            addCriterion("REGST_PGM_ID <", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLessThanOrEqualTo(String value) {
            addCriterion("REGST_PGM_ID <=", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLike(String value) {
            addCriterion("REGST_PGM_ID like", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotLike(String value) {
            addCriterion("REGST_PGM_ID not like", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIn(List<String> values) {
            addCriterion("REGST_PGM_ID in", values, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotIn(List<String> values) {
            addCriterion("REGST_PGM_ID not in", values, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDBetween(String value1, String value2) {
            addCriterion("REGST_PGM_ID between", value1, value2, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotBetween(String value1, String value2) {
            addCriterion("REGST_PGM_ID not between", value1, value2, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIsNull() {
            addCriterion("UPD_TMSTMP is null");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIsNotNull() {
            addCriterion("UPD_TMSTMP is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPEqualTo(Date value) {
            addCriterion("UPD_TMSTMP =", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotEqualTo(Date value) {
            addCriterion("UPD_TMSTMP <>", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPGreaterThan(Date value) {
            addCriterion("UPD_TMSTMP >", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPGreaterThanOrEqualTo(Date value) {
            addCriterion("UPD_TMSTMP >=", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPLessThan(Date value) {
            addCriterion("UPD_TMSTMP <", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPLessThanOrEqualTo(Date value) {
            addCriterion("UPD_TMSTMP <=", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIn(List<Date> values) {
            addCriterion("UPD_TMSTMP in", values, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotIn(List<Date> values) {
            addCriterion("UPD_TMSTMP not in", values, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPBetween(Date value1, Date value2) {
            addCriterion("UPD_TMSTMP between", value1, value2, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotBetween(Date value1, Date value2) {
            addCriterion("UPD_TMSTMP not between", value1, value2, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIsNull() {
            addCriterion("UPDTR_CO_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIsNotNull() {
            addCriterion("UPDTR_CO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDEqualTo(String value) {
            addCriterion("UPDTR_CO_CD =", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotEqualTo(String value) {
            addCriterion("UPDTR_CO_CD <>", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDGreaterThan(String value) {
            addCriterion("UPDTR_CO_CD >", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_CO_CD >=", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLessThan(String value) {
            addCriterion("UPDTR_CO_CD <", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_CO_CD <=", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLike(String value) {
            addCriterion("UPDTR_CO_CD like", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotLike(String value) {
            addCriterion("UPDTR_CO_CD not like", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIn(List<String> values) {
            addCriterion("UPDTR_CO_CD in", values, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotIn(List<String> values) {
            addCriterion("UPDTR_CO_CD not in", values, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDBetween(String value1, String value2) {
            addCriterion("UPDTR_CO_CD between", value1, value2, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotBetween(String value1, String value2) {
            addCriterion("UPDTR_CO_CD not between", value1, value2, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIsNull() {
            addCriterion("UPDTR_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIsNotNull() {
            addCriterion("UPDTR_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD =", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <>", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("UPDTR_SOSHIKI_CD >", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD >=", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLessThan(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <=", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLike(String value) {
            addCriterion("UPDTR_SOSHIKI_CD like", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotLike(String value) {
            addCriterion("UPDTR_SOSHIKI_CD not like", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIn(List<String> values) {
            addCriterion("UPDTR_SOSHIKI_CD in", values, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("UPDTR_SOSHIKI_CD not in", values, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("UPDTR_SOSHIKI_CD between", value1, value2, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("UPDTR_SOSHIKI_CD not between", value1, value2, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIsNull() {
            addCriterion("UPDTR_EMP_NO is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIsNotNull() {
            addCriterion("UPDTR_EMP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO =", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO <>", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOGreaterThan(String value) {
            addCriterion("UPDTR_EMP_NO >", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO >=", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLessThan(String value) {
            addCriterion("UPDTR_EMP_NO <", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO <=", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLike(String value) {
            addCriterion("UPDTR_EMP_NO like", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotLike(String value) {
            addCriterion("UPDTR_EMP_NO not like", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIn(List<String> values) {
            addCriterion("UPDTR_EMP_NO in", values, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotIn(List<String> values) {
            addCriterion("UPDTR_EMP_NO not in", values, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOBetween(String value1, String value2) {
            addCriterion("UPDTR_EMP_NO between", value1, value2, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotBetween(String value1, String value2) {
            addCriterion("UPDTR_EMP_NO not between", value1, value2, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIsNull() {
            addCriterion("UPD_GAMEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIsNotNull() {
            addCriterion("UPD_GAMEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID =", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID <>", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDGreaterThan(String value) {
            addCriterion("UPD_GAMEN_ID >", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID >=", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLessThan(String value) {
            addCriterion("UPD_GAMEN_ID <", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLessThanOrEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID <=", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLike(String value) {
            addCriterion("UPD_GAMEN_ID like", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotLike(String value) {
            addCriterion("UPD_GAMEN_ID not like", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIn(List<String> values) {
            addCriterion("UPD_GAMEN_ID in", values, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotIn(List<String> values) {
            addCriterion("UPD_GAMEN_ID not in", values, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDBetween(String value1, String value2) {
            addCriterion("UPD_GAMEN_ID between", value1, value2, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotBetween(String value1, String value2) {
            addCriterion("UPD_GAMEN_ID not between", value1, value2, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIsNull() {
            addCriterion("UPD_PGM_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIsNotNull() {
            addCriterion("UPD_PGM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDEqualTo(String value) {
            addCriterion("UPD_PGM_ID =", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotEqualTo(String value) {
            addCriterion("UPD_PGM_ID <>", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDGreaterThan(String value) {
            addCriterion("UPD_PGM_ID >", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPD_PGM_ID >=", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLessThan(String value) {
            addCriterion("UPD_PGM_ID <", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLessThanOrEqualTo(String value) {
            addCriterion("UPD_PGM_ID <=", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLike(String value) {
            addCriterion("UPD_PGM_ID like", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotLike(String value) {
            addCriterion("UPD_PGM_ID not like", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIn(List<String> values) {
            addCriterion("UPD_PGM_ID in", values, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotIn(List<String> values) {
            addCriterion("UPD_PGM_ID not in", values, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDBetween(String value1, String value2) {
            addCriterion("UPD_PGM_ID between", value1, value2, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotBetween(String value1, String value2) {
            addCriterion("UPD_PGM_ID not between", value1, value2, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLikeInsensitive(String value) {
            addCriterion("upper(KAISHA_CD) like", value.toUpperCase(), "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NOLikeInsensitive(String value) {
            addCriterion("upper(SHAIN_NO) like", value.toUpperCase(), "SHAIN_NO");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLikeInsensitive(String value) {
            addCriterion("upper(TEKIYO_KAISHI_YMD) like", value.toUpperCase(), "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLikeInsensitive(String value) {
            addCriterion("upper(TEKIYO_SHURYO_YMD) like", value.toUpperCase(), "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andNYUSHA_YMDLikeInsensitive(String value) {
            addCriterion("upper(NYUSHA_YMD) like", value.toUpperCase(), "NYUSHA_YMD");
            return (Criteria) this;
        }

        public Criteria andTAISHOKU_YMDLikeInsensitive(String value) {
            addCriterion("upper(TAISHOKU_YMD) like", value.toUpperCase(), "TAISHOKU_YMD");
            return (Criteria) this;
        }

        public Criteria andSHAIN_NMLikeInsensitive(String value) {
            addCriterion("upper(SHAIN_NM) like", value.toUpperCase(), "SHAIN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAINSEI_NMLikeInsensitive(String value) {
            addCriterion("upper(SHAINSEI_NM) like", value.toUpperCase(), "SHAINSEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIMMEI_NMLikeInsensitive(String value) {
            addCriterion("upper(SHAIMMEI_NM) like", value.toUpperCase(), "SHAIMMEI_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_HKN_NMLikeInsensitive(String value) {
            addCriterion("upper(SHAIN_HKN_NM) like", value.toUpperCase(), "SHAIN_HKN_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_KN_NMLikeInsensitive(String value) {
            addCriterion("upper(SHAIN_KN_NM) like", value.toUpperCase(), "SHAIN_KN_NM");
            return (Criteria) this;
        }

        public Criteria andMIBUN_CDLikeInsensitive(String value) {
            addCriterion("upper(MIBUN_CD) like", value.toUpperCase(), "MIBUN_CD");
            return (Criteria) this;
        }

        public Criteria andMIBUN_NMLikeInsensitive(String value) {
            addCriterion("upper(MIBUN_NM) like", value.toUpperCase(), "MIBUN_NM");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_KBNLikeInsensitive(String value) {
            addCriterion("upper(SEIBETSU_KBN) like", value.toUpperCase(), "SEIBETSU_KBN");
            return (Criteria) this;
        }

        public Criteria andSEIBETSU_NMLikeInsensitive(String value) {
            addCriterion("upper(SEIBETSU_NM) like", value.toUpperCase(), "SEIBETSU_NM");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO_KBNLikeInsensitive(String value) {
            addCriterion("upper(SHAIN_SAIYO_KBN) like", value.toUpperCase(), "SHAIN_SAIYO_KBN");
            return (Criteria) this;
        }

        public Criteria andSHAIN_SAIYO__NMLikeInsensitive(String value) {
            addCriterion("upper(SHAIN_SAIYO__NM) like", value.toUpperCase(), "SHAIN_SAIYO__NM");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_FLGLikeInsensitive(String value) {
            addCriterion("upper(SHAKAI_HOKEN_KANYU_FLG) like", value.toUpperCase(), "SHAKAI_HOKEN_KANYU_FLG");
            return (Criteria) this;
        }

        public Criteria andSHAKAI_HOKEN_KANYU_NMLikeInsensitive(String value) {
            addCriterion("upper(SHAKAI_HOKEN_KANYU_NM) like", value.toUpperCase(), "SHAKAI_HOKEN_KANYU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_CDLikeInsensitive(String value) {
            addCriterion("upper(YAKUSHOKU_CD) like", value.toUpperCase(), "YAKUSHOKU_CD");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_NMLikeInsensitive(String value) {
            addCriterion("upper(YAKUSHOKU_NM) like", value.toUpperCase(), "YAKUSHOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSHOKU_RNMLikeInsensitive(String value) {
            addCriterion("upper(YAKUSHOKU_RNM) like", value.toUpperCase(), "YAKUSHOKU_RNM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_CDLikeInsensitive(String value) {
            addCriterion("upper(SHOKUMU_CD) like", value.toUpperCase(), "SHOKUMU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_NMLikeInsensitive(String value) {
            addCriterion("upper(SHOKUMU_NM) like", value.toUpperCase(), "SHOKUMU_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUMU_RNMLikeInsensitive(String value) {
            addCriterion("upper(SHOKUMU_RNM) like", value.toUpperCase(), "SHOKUMU_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_CDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_SEGMENT_CD) like", value.toUpperCase(), "JIGYO_SEGMENT_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEGMENT_NMLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_SEGMENT_NM) like", value.toUpperCase(), "JIGYO_SEGMENT_NM");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_CDLikeInsensitive(String value) {
            addCriterion("upper(SHOKUSHU_CD) like", value.toUpperCase(), "SHOKUSHU_CD");
            return (Criteria) this;
        }

        public Criteria andSHOKUSHU_NMLikeInsensitive(String value) {
            addCriterion("upper(SHOKUSHU_NM) like", value.toUpperCase(), "SHOKUSHU_NM");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_01) like", value.toUpperCase(), "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_02) like", value.toUpperCase(), "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_03) like", value.toUpperCase(), "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_04) like", value.toUpperCase(), "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_05) like", value.toUpperCase(), "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_06) like", value.toUpperCase(), "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_07) like", value.toUpperCase(), "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_08) like", value.toUpperCase(), "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_09) like", value.toUpperCase(), "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_10) like", value.toUpperCase(), "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_CO_CD) like", value.toUpperCase(), "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_SOSHIKI_CD) like", value.toUpperCase(), "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_EMP_NO) like", value.toUpperCase(), "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLikeInsensitive(String value) {
            addCriterion("upper(REGST_GAMEN_ID) like", value.toUpperCase(), "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLikeInsensitive(String value) {
            addCriterion("upper(REGST_PGM_ID) like", value.toUpperCase(), "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_CO_CD) like", value.toUpperCase(), "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_SOSHIKI_CD) like", value.toUpperCase(), "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_EMP_NO) like", value.toUpperCase(), "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLikeInsensitive(String value) {
            addCriterion("upper(UPD_GAMEN_ID) like", value.toUpperCase(), "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLikeInsensitive(String value) {
            addCriterion("upper(UPD_PGM_ID) like", value.toUpperCase(), "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * C_EIGYO_SHAIN
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * C_EIGYO_SHAIN null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}