package jp.co.alsok.g6.db.entity.com;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class KAcntAlsokExample {
    /**
     * K_ACNT_ALSOK
     */
    protected String orderByClause;

    /**
     * K_ACNT_ALSOK
     */
    protected boolean distinct;

    /**
     * K_ACNT_ALSOK
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public KAcntAlsokExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * K_ACNT_ALSOK null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_ACNT_ALSOKIsNull() {
            addCriterion("LN_ACNT_ALSOK is null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKIsNotNull() {
            addCriterion("LN_ACNT_ALSOK is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKEqualTo(String value) {
            addCriterion("LN_ACNT_ALSOK =", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKNotEqualTo(String value) {
            addCriterion("LN_ACNT_ALSOK <>", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKGreaterThan(String value) {
            addCriterion("LN_ACNT_ALSOK >", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_ALSOK >=", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKLessThan(String value) {
            addCriterion("LN_ACNT_ALSOK <", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKLessThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_ALSOK <=", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKLike(String value) {
            addCriterion("LN_ACNT_ALSOK like", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKNotLike(String value) {
            addCriterion("LN_ACNT_ALSOK not like", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKIn(List<String> values) {
            addCriterion("LN_ACNT_ALSOK in", values, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKNotIn(List<String> values) {
            addCriterion("LN_ACNT_ALSOK not in", values, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKBetween(String value1, String value2) {
            addCriterion("LN_ACNT_ALSOK between", value1, value2, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKNotBetween(String value1, String value2) {
            addCriterion("LN_ACNT_ALSOK not between", value1, value2, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDIsNull() {
            addCriterion("JIGYOU_CD is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDIsNotNull() {
            addCriterion("JIGYOU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDEqualTo(String value) {
            addCriterion("JIGYOU_CD =", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDNotEqualTo(String value) {
            addCriterion("JIGYOU_CD <>", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDGreaterThan(String value) {
            addCriterion("JIGYOU_CD >", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOU_CD >=", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDLessThan(String value) {
            addCriterion("JIGYOU_CD <", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDLessThanOrEqualTo(String value) {
            addCriterion("JIGYOU_CD <=", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDLike(String value) {
            addCriterion("JIGYOU_CD like", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDNotLike(String value) {
            addCriterion("JIGYOU_CD not like", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDIn(List<String> values) {
            addCriterion("JIGYOU_CD in", values, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDNotIn(List<String> values) {
            addCriterion("JIGYOU_CD not in", values, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDBetween(String value1, String value2) {
            addCriterion("JIGYOU_CD between", value1, value2, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDNotBetween(String value1, String value2) {
            addCriterion("JIGYOU_CD not between", value1, value2, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andML_ADDRIsNull() {
            addCriterion("ML_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andML_ADDRIsNotNull() {
            addCriterion("ML_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andML_ADDREqualTo(String value) {
            addCriterion("ML_ADDR =", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRNotEqualTo(String value) {
            addCriterion("ML_ADDR <>", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRGreaterThan(String value) {
            addCriterion("ML_ADDR >", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRGreaterThanOrEqualTo(String value) {
            addCriterion("ML_ADDR >=", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRLessThan(String value) {
            addCriterion("ML_ADDR <", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRLessThanOrEqualTo(String value) {
            addCriterion("ML_ADDR <=", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRLike(String value) {
            addCriterion("ML_ADDR like", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRNotLike(String value) {
            addCriterion("ML_ADDR not like", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRIn(List<String> values) {
            addCriterion("ML_ADDR in", values, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRNotIn(List<String> values) {
            addCriterion("ML_ADDR not in", values, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRBetween(String value1, String value2) {
            addCriterion("ML_ADDR between", value1, value2, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRNotBetween(String value1, String value2) {
            addCriterion("ML_ADDR not between", value1, value2, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andPASSWDIsNull() {
            addCriterion("PASSWD is null");
            return (Criteria) this;
        }

        public Criteria andPASSWDIsNotNull() {
            addCriterion("PASSWD is not null");
            return (Criteria) this;
        }

        public Criteria andPASSWDEqualTo(String value) {
            addCriterion("PASSWD =", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDNotEqualTo(String value) {
            addCriterion("PASSWD <>", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDGreaterThan(String value) {
            addCriterion("PASSWD >", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDGreaterThanOrEqualTo(String value) {
            addCriterion("PASSWD >=", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDLessThan(String value) {
            addCriterion("PASSWD <", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDLessThanOrEqualTo(String value) {
            addCriterion("PASSWD <=", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDLike(String value) {
            addCriterion("PASSWD like", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDNotLike(String value) {
            addCriterion("PASSWD not like", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDIn(List<String> values) {
            addCriterion("PASSWD in", values, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDNotIn(List<String> values) {
            addCriterion("PASSWD not in", values, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDBetween(String value1, String value2) {
            addCriterion("PASSWD between", value1, value2, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDNotBetween(String value1, String value2) {
            addCriterion("PASSWD not between", value1, value2, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIsNull() {
            addCriterion("USER_NM is null");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIsNotNull() {
            addCriterion("USER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUSER_NMEqualTo(String value) {
            addCriterion("USER_NM =", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotEqualTo(String value) {
            addCriterion("USER_NM <>", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMGreaterThan(String value) {
            addCriterion("USER_NM >", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("USER_NM >=", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLessThan(String value) {
            addCriterion("USER_NM <", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLessThanOrEqualTo(String value) {
            addCriterion("USER_NM <=", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLike(String value) {
            addCriterion("USER_NM like", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotLike(String value) {
            addCriterion("USER_NM not like", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIn(List<String> values) {
            addCriterion("USER_NM in", values, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotIn(List<String> values) {
            addCriterion("USER_NM not in", values, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMBetween(String value1, String value2) {
            addCriterion("USER_NM between", value1, value2, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotBetween(String value1, String value2) {
            addCriterion("USER_NM not between", value1, value2, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMIsNull() {
            addCriterion("USER_NUM is null");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMIsNotNull() {
            addCriterion("USER_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMEqualTo(String value) {
            addCriterion("USER_NUM =", value, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMNotEqualTo(String value) {
            addCriterion("USER_NUM <>", value, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMGreaterThan(String value) {
            addCriterion("USER_NUM >", value, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("USER_NUM >=", value, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMLessThan(String value) {
            addCriterion("USER_NUM <", value, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMLessThanOrEqualTo(String value) {
            addCriterion("USER_NUM <=", value, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMLike(String value) {
            addCriterion("USER_NUM like", value, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMNotLike(String value) {
            addCriterion("USER_NUM not like", value, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMIn(List<String> values) {
            addCriterion("USER_NUM in", values, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMNotIn(List<String> values) {
            addCriterion("USER_NUM not in", values, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMBetween(String value1, String value2) {
            addCriterion("USER_NUM between", value1, value2, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMNotBetween(String value1, String value2) {
            addCriterion("USER_NUM not between", value1, value2, "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSIsNull() {
            addCriterion("LOGIN_STS is null");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSIsNotNull() {
            addCriterion("LOGIN_STS is not null");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSEqualTo(String value) {
            addCriterion("LOGIN_STS =", value, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSNotEqualTo(String value) {
            addCriterion("LOGIN_STS <>", value, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSGreaterThan(String value) {
            addCriterion("LOGIN_STS >", value, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSGreaterThanOrEqualTo(String value) {
            addCriterion("LOGIN_STS >=", value, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSLessThan(String value) {
            addCriterion("LOGIN_STS <", value, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSLessThanOrEqualTo(String value) {
            addCriterion("LOGIN_STS <=", value, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSLike(String value) {
            addCriterion("LOGIN_STS like", value, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSNotLike(String value) {
            addCriterion("LOGIN_STS not like", value, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSIn(List<String> values) {
            addCriterion("LOGIN_STS in", values, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSNotIn(List<String> values) {
            addCriterion("LOGIN_STS not in", values, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSBetween(String value1, String value2) {
            addCriterion("LOGIN_STS between", value1, value2, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSNotBetween(String value1, String value2) {
            addCriterion("LOGIN_STS not between", value1, value2, "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBIIsNull() {
            addCriterion("LN_TOGO_KEIBI is null");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBIIsNotNull() {
            addCriterion("LN_TOGO_KEIBI is not null");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBIEqualTo(String value) {
            addCriterion("LN_TOGO_KEIBI =", value, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBINotEqualTo(String value) {
            addCriterion("LN_TOGO_KEIBI <>", value, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBIGreaterThan(String value) {
            addCriterion("LN_TOGO_KEIBI >", value, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBIGreaterThanOrEqualTo(String value) {
            addCriterion("LN_TOGO_KEIBI >=", value, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBILessThan(String value) {
            addCriterion("LN_TOGO_KEIBI <", value, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBILessThanOrEqualTo(String value) {
            addCriterion("LN_TOGO_KEIBI <=", value, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBILike(String value) {
            addCriterion("LN_TOGO_KEIBI like", value, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBINotLike(String value) {
            addCriterion("LN_TOGO_KEIBI not like", value, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBIIn(List<String> values) {
            addCriterion("LN_TOGO_KEIBI in", values, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBINotIn(List<String> values) {
            addCriterion("LN_TOGO_KEIBI not in", values, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBIBetween(String value1, String value2) {
            addCriterion("LN_TOGO_KEIBI between", value1, value2, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBINotBetween(String value1, String value2) {
            addCriterion("LN_TOGO_KEIBI not between", value1, value2, "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNIsNull() {
            addCriterion("ACNT_KBN is null");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNIsNotNull() {
            addCriterion("ACNT_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNEqualTo(String value) {
            addCriterion("ACNT_KBN =", value, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNNotEqualTo(String value) {
            addCriterion("ACNT_KBN <>", value, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNGreaterThan(String value) {
            addCriterion("ACNT_KBN >", value, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("ACNT_KBN >=", value, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNLessThan(String value) {
            addCriterion("ACNT_KBN <", value, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNLessThanOrEqualTo(String value) {
            addCriterion("ACNT_KBN <=", value, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNLike(String value) {
            addCriterion("ACNT_KBN like", value, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNNotLike(String value) {
            addCriterion("ACNT_KBN not like", value, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNIn(List<String> values) {
            addCriterion("ACNT_KBN in", values, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNNotIn(List<String> values) {
            addCriterion("ACNT_KBN not in", values, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNBetween(String value1, String value2) {
            addCriterion("ACNT_KBN between", value1, value2, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNNotBetween(String value1, String value2) {
            addCriterion("ACNT_KBN not between", value1, value2, "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGIsNull() {
            addCriterion("TAIIN_KIND_FLG is null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGIsNotNull() {
            addCriterion("TAIIN_KIND_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGEqualTo(String value) {
            addCriterion("TAIIN_KIND_FLG =", value, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGNotEqualTo(String value) {
            addCriterion("TAIIN_KIND_FLG <>", value, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGGreaterThan(String value) {
            addCriterion("TAIIN_KIND_FLG >", value, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("TAIIN_KIND_FLG >=", value, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGLessThan(String value) {
            addCriterion("TAIIN_KIND_FLG <", value, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGLessThanOrEqualTo(String value) {
            addCriterion("TAIIN_KIND_FLG <=", value, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGLike(String value) {
            addCriterion("TAIIN_KIND_FLG like", value, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGNotLike(String value) {
            addCriterion("TAIIN_KIND_FLG not like", value, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGIn(List<String> values) {
            addCriterion("TAIIN_KIND_FLG in", values, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGNotIn(List<String> values) {
            addCriterion("TAIIN_KIND_FLG not in", values, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGBetween(String value1, String value2) {
            addCriterion("TAIIN_KIND_FLG between", value1, value2, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGNotBetween(String value1, String value2) {
            addCriterion("TAIIN_KIND_FLG not between", value1, value2, "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andID_HANIIsNull() {
            addCriterion("ID_HANI is null");
            return (Criteria) this;
        }

        public Criteria andID_HANIIsNotNull() {
            addCriterion("ID_HANI is not null");
            return (Criteria) this;
        }

        public Criteria andID_HANIEqualTo(String value) {
            addCriterion("ID_HANI =", value, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANINotEqualTo(String value) {
            addCriterion("ID_HANI <>", value, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANIGreaterThan(String value) {
            addCriterion("ID_HANI >", value, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANIGreaterThanOrEqualTo(String value) {
            addCriterion("ID_HANI >=", value, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANILessThan(String value) {
            addCriterion("ID_HANI <", value, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANILessThanOrEqualTo(String value) {
            addCriterion("ID_HANI <=", value, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANILike(String value) {
            addCriterion("ID_HANI like", value, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANINotLike(String value) {
            addCriterion("ID_HANI not like", value, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANIIn(List<String> values) {
            addCriterion("ID_HANI in", values, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANINotIn(List<String> values) {
            addCriterion("ID_HANI not in", values, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANIBetween(String value1, String value2) {
            addCriterion("ID_HANI between", value1, value2, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andID_HANINotBetween(String value1, String value2) {
            addCriterion("ID_HANI not between", value1, value2, "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGIsNull() {
            addCriterion("HYOJI_FLG is null");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGIsNotNull() {
            addCriterion("HYOJI_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGEqualTo(String value) {
            addCriterion("HYOJI_FLG =", value, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGNotEqualTo(String value) {
            addCriterion("HYOJI_FLG <>", value, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGGreaterThan(String value) {
            addCriterion("HYOJI_FLG >", value, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("HYOJI_FLG >=", value, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGLessThan(String value) {
            addCriterion("HYOJI_FLG <", value, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGLessThanOrEqualTo(String value) {
            addCriterion("HYOJI_FLG <=", value, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGLike(String value) {
            addCriterion("HYOJI_FLG like", value, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGNotLike(String value) {
            addCriterion("HYOJI_FLG not like", value, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGIn(List<String> values) {
            addCriterion("HYOJI_FLG in", values, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGNotIn(List<String> values) {
            addCriterion("HYOJI_FLG not in", values, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGBetween(String value1, String value2) {
            addCriterion("HYOJI_FLG between", value1, value2, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGNotBetween(String value1, String value2) {
            addCriterion("HYOJI_FLG not between", value1, value2, "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDIsNull() {
            addCriterion("KENGEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDIsNotNull() {
            addCriterion("KENGEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDEqualTo(String value) {
            addCriterion("KENGEN_ID =", value, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDNotEqualTo(String value) {
            addCriterion("KENGEN_ID <>", value, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDGreaterThan(String value) {
            addCriterion("KENGEN_ID >", value, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("KENGEN_ID >=", value, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDLessThan(String value) {
            addCriterion("KENGEN_ID <", value, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDLessThanOrEqualTo(String value) {
            addCriterion("KENGEN_ID <=", value, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDLike(String value) {
            addCriterion("KENGEN_ID like", value, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDNotLike(String value) {
            addCriterion("KENGEN_ID not like", value, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDIn(List<String> values) {
            addCriterion("KENGEN_ID in", values, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDNotIn(List<String> values) {
            addCriterion("KENGEN_ID not in", values, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDBetween(String value1, String value2) {
            addCriterion("KENGEN_ID between", value1, value2, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDNotBetween(String value1, String value2) {
            addCriterion("KENGEN_ID not between", value1, value2, "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKLikeInsensitive(String value) {
            addCriterion("upper(LN_ACNT_ALSOK) like", value.toUpperCase(), "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDLikeInsensitive(String value) {
            addCriterion("upper(JIGYOU_CD) like", value.toUpperCase(), "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andML_ADDRLikeInsensitive(String value) {
            addCriterion("upper(ML_ADDR) like", value.toUpperCase(), "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andPASSWDLikeInsensitive(String value) {
            addCriterion("upper(PASSWD) like", value.toUpperCase(), "PASSWD");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLikeInsensitive(String value) {
            addCriterion("upper(USER_NM) like", value.toUpperCase(), "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NUMLikeInsensitive(String value) {
            addCriterion("upper(USER_NUM) like", value.toUpperCase(), "USER_NUM");
            return (Criteria) this;
        }

        public Criteria andLOGIN_STSLikeInsensitive(String value) {
            addCriterion("upper(LOGIN_STS) like", value.toUpperCase(), "LOGIN_STS");
            return (Criteria) this;
        }

        public Criteria andLN_TOGO_KEIBILikeInsensitive(String value) {
            addCriterion("upper(LN_TOGO_KEIBI) like", value.toUpperCase(), "LN_TOGO_KEIBI");
            return (Criteria) this;
        }

        public Criteria andACNT_KBNLikeInsensitive(String value) {
            addCriterion("upper(ACNT_KBN) like", value.toUpperCase(), "ACNT_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KIND_FLGLikeInsensitive(String value) {
            addCriterion("upper(TAIIN_KIND_FLG) like", value.toUpperCase(), "TAIIN_KIND_FLG");
            return (Criteria) this;
        }

        public Criteria andID_HANILikeInsensitive(String value) {
            addCriterion("upper(ID_HANI) like", value.toUpperCase(), "ID_HANI");
            return (Criteria) this;
        }

        public Criteria andHYOJI_FLGLikeInsensitive(String value) {
            addCriterion("upper(HYOJI_FLG) like", value.toUpperCase(), "HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andKENGEN_IDLikeInsensitive(String value) {
            addCriterion("upper(KENGEN_ID) like", value.toUpperCase(), "KENGEN_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * K_ACNT_ALSOK
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * K_ACNT_ALSOK null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}