package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HKeibiStsRdDtlRhtbl1 implements Serializable {
    /**
     * LN_警備状態読出詳細履歴1論理番号
     */
    private String LN_KEIBI_STS_DTL_READ1;

    /**
     * LN_警備状態読出履歴論理番号
     */
    private String LN_RD_KB_STS;

    /**
     * サブアドレス
     */
    private String SUB_ADDR;

    /**
     * N0F0状態
     */
    private String n0_STS;

    /**
     * KNKF状態
     */
    private String KN_STS;

    /**
     * DN0DF0状態
     */
    private String DN0_STS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_KEIBI_STS_RD_DTL_RHTBL1
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_警備状態読出詳細履歴1論理番号
     * @return LN_KEIBI_STS_DTL_READ1 LN_警備状態読出詳細履歴1論理番号
     */
    public String getLN_KEIBI_STS_DTL_READ1() {
        return LN_KEIBI_STS_DTL_READ1;
    }

    /**
     * LN_警備状態読出詳細履歴1論理番号
     * @param LN_KEIBI_STS_DTL_READ1 LN_警備状態読出詳細履歴1論理番号
     */
    public void setLN_KEIBI_STS_DTL_READ1(String LN_KEIBI_STS_DTL_READ1) {
        this.LN_KEIBI_STS_DTL_READ1 = LN_KEIBI_STS_DTL_READ1 == null ? null : LN_KEIBI_STS_DTL_READ1.trim();
    }

    /**
     * LN_警備状態読出履歴論理番号
     * @return LN_RD_KB_STS LN_警備状態読出履歴論理番号
     */
    public String getLN_RD_KB_STS() {
        return LN_RD_KB_STS;
    }

    /**
     * LN_警備状態読出履歴論理番号
     * @param LN_RD_KB_STS LN_警備状態読出履歴論理番号
     */
    public void setLN_RD_KB_STS(String LN_RD_KB_STS) {
        this.LN_RD_KB_STS = LN_RD_KB_STS == null ? null : LN_RD_KB_STS.trim();
    }

    /**
     * サブアドレス
     * @return SUB_ADDR サブアドレス
     */
    public String getSUB_ADDR() {
        return SUB_ADDR;
    }

    /**
     * サブアドレス
     * @param SUB_ADDR サブアドレス
     */
    public void setSUB_ADDR(String SUB_ADDR) {
        this.SUB_ADDR = SUB_ADDR == null ? null : SUB_ADDR.trim();
    }

    /**
     * N0F0状態
     * @return N0_STS N0F0状態
     */
    public String getN0_STS() {
        return n0_STS;
    }

    /**
     * N0F0状態
     * @param n0_STS N0F0状態
     */
    public void setN0_STS(String n0_STS) {
        this.n0_STS = n0_STS == null ? null : n0_STS.trim();
    }

    /**
     * KNKF状態
     * @return KN_STS KNKF状態
     */
    public String getKN_STS() {
        return KN_STS;
    }

    /**
     * KNKF状態
     * @param KN_STS KNKF状態
     */
    public void setKN_STS(String KN_STS) {
        this.KN_STS = KN_STS == null ? null : KN_STS.trim();
    }

    /**
     * DN0DF0状態
     * @return DN0_STS DN0DF0状態
     */
    public String getDN0_STS() {
        return DN0_STS;
    }

    /**
     * DN0DF0状態
     * @param DN0_STS DN0DF0状態
     */
    public void setDN0_STS(String DN0_STS) {
        this.DN0_STS = DN0_STS == null ? null : DN0_STS.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}