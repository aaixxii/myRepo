package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CDataPhysicalDeleteDtlKey implements Serializable {
    /**
     * LN_DBデータ物理削除制御論理番号
     */
    private String LN_DATA_PHYSICAL_DELETE;

    /**
     * テーブル連番
     */
    private String DELETE_TARGET_TABLE_NUM;

    /**
     * C_DATA_PHYSICAL_DELETE_DTL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_DBデータ物理削除制御論理番号
     * @return LN_DATA_PHYSICAL_DELETE LN_DBデータ物理削除制御論理番号
     */
    public String getLN_DATA_PHYSICAL_DELETE() {
        return LN_DATA_PHYSICAL_DELETE;
    }

    /**
     * LN_DBデータ物理削除制御論理番号
     * @param LN_DATA_PHYSICAL_DELETE LN_DBデータ物理削除制御論理番号
     */
    public void setLN_DATA_PHYSICAL_DELETE(String LN_DATA_PHYSICAL_DELETE) {
        this.LN_DATA_PHYSICAL_DELETE = LN_DATA_PHYSICAL_DELETE == null ? null : LN_DATA_PHYSICAL_DELETE.trim();
    }

    /**
     * テーブル連番
     * @return DELETE_TARGET_TABLE_NUM テーブル連番
     */
    public String getDELETE_TARGET_TABLE_NUM() {
        return DELETE_TARGET_TABLE_NUM;
    }

    /**
     * テーブル連番
     * @param DELETE_TARGET_TABLE_NUM テーブル連番
     */
    public void setDELETE_TARGET_TABLE_NUM(String DELETE_TARGET_TABLE_NUM) {
        this.DELETE_TARGET_TABLE_NUM = DELETE_TARGET_TABLE_NUM == null ? null : DELETE_TARGET_TABLE_NUM.trim();
    }
}