package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KAutoRmtChkSearch implements Serializable {
    /**
     * 事業所コード
     */
    private String JIGYOU_CD;

    /**
     * 検索条件シリーズ
     */
    private String SEARCH_SERIESE;

    /**
     * 検索条件反応
     */
    private String SEARCH_REACTION_FLG;

    /**
     * 検索条件反応日数
     */
    private String SEARCH_REACTION_DAY;

    /**
     * 検索条件日時FROM年
     */
    private String SEARCH_DATE_FROM_YEAR;

    /**
     * 検索条件日時FROM月
     */
    private String SEARCH_DATE_FROM_MONTH;

    /**
     * 検索条件日時FROM日
     */
    private String SEARCH_DATE_FROM_DAY;

    /**
     * 検索条件日時TO年
     */
    private String SEARCH_DATE_TO_YEAR;

    /**
     * 検索条件日時TO月
     */
    private String SEARCH_DATE_TO_MONTH;

    /**
     * 検索条件日時TO日
     */
    private String SEARCH_DATE_TO_DAY;

    /**
     * 検索条件予約中
     */
    private String SEARCH_RESERVE_FLG;

    /**
     * 検索条件警備先検索機種
     */
    private String SEARCH_KEIBI_MODEL;

    /**
     * 検索条件時刻検索機種
     */
    private String SEARCH_TIME_MODEL;

    /**
     * 選択タブ
     */
    private String SELECT_SEARCH;

    /**
     * 警備先検索済みフラグ
     */
    private String KEIBI_SEARCH_FLG;

    /**
     * 時刻検索済みフラグ
     */
    private String TIME_SEARCH_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * 検索条件警備先
     */
    private String SEARCH_KEIBI;

    /**
     * K_AUTO_RMT_CHK_SEARCH
     */
    private static final long serialVersionUID = 1L;

    /**
     * 事業所コード
     * @return JIGYOU_CD 事業所コード
     */
    public String getJIGYOU_CD() {
        return JIGYOU_CD;
    }

    /**
     * 事業所コード
     * @param JIGYOU_CD 事業所コード
     */
    public void setJIGYOU_CD(String JIGYOU_CD) {
        this.JIGYOU_CD = JIGYOU_CD == null ? null : JIGYOU_CD.trim();
    }

    /**
     * 検索条件シリーズ
     * @return SEARCH_SERIESE 検索条件シリーズ
     */
    public String getSEARCH_SERIESE() {
        return SEARCH_SERIESE;
    }

    /**
     * 検索条件シリーズ
     * @param SEARCH_SERIESE 検索条件シリーズ
     */
    public void setSEARCH_SERIESE(String SEARCH_SERIESE) {
        this.SEARCH_SERIESE = SEARCH_SERIESE == null ? null : SEARCH_SERIESE.trim();
    }

    /**
     * 検索条件反応
     * @return SEARCH_REACTION_FLG 検索条件反応
     */
    public String getSEARCH_REACTION_FLG() {
        return SEARCH_REACTION_FLG;
    }

    /**
     * 検索条件反応
     * @param SEARCH_REACTION_FLG 検索条件反応
     */
    public void setSEARCH_REACTION_FLG(String SEARCH_REACTION_FLG) {
        this.SEARCH_REACTION_FLG = SEARCH_REACTION_FLG == null ? null : SEARCH_REACTION_FLG.trim();
    }

    /**
     * 検索条件反応日数
     * @return SEARCH_REACTION_DAY 検索条件反応日数
     */
    public String getSEARCH_REACTION_DAY() {
        return SEARCH_REACTION_DAY;
    }

    /**
     * 検索条件反応日数
     * @param SEARCH_REACTION_DAY 検索条件反応日数
     */
    public void setSEARCH_REACTION_DAY(String SEARCH_REACTION_DAY) {
        this.SEARCH_REACTION_DAY = SEARCH_REACTION_DAY == null ? null : SEARCH_REACTION_DAY.trim();
    }

    /**
     * 検索条件日時FROM年
     * @return SEARCH_DATE_FROM_YEAR 検索条件日時FROM年
     */
    public String getSEARCH_DATE_FROM_YEAR() {
        return SEARCH_DATE_FROM_YEAR;
    }

    /**
     * 検索条件日時FROM年
     * @param SEARCH_DATE_FROM_YEAR 検索条件日時FROM年
     */
    public void setSEARCH_DATE_FROM_YEAR(String SEARCH_DATE_FROM_YEAR) {
        this.SEARCH_DATE_FROM_YEAR = SEARCH_DATE_FROM_YEAR == null ? null : SEARCH_DATE_FROM_YEAR.trim();
    }

    /**
     * 検索条件日時FROM月
     * @return SEARCH_DATE_FROM_MONTH 検索条件日時FROM月
     */
    public String getSEARCH_DATE_FROM_MONTH() {
        return SEARCH_DATE_FROM_MONTH;
    }

    /**
     * 検索条件日時FROM月
     * @param SEARCH_DATE_FROM_MONTH 検索条件日時FROM月
     */
    public void setSEARCH_DATE_FROM_MONTH(String SEARCH_DATE_FROM_MONTH) {
        this.SEARCH_DATE_FROM_MONTH = SEARCH_DATE_FROM_MONTH == null ? null : SEARCH_DATE_FROM_MONTH.trim();
    }

    /**
     * 検索条件日時FROM日
     * @return SEARCH_DATE_FROM_DAY 検索条件日時FROM日
     */
    public String getSEARCH_DATE_FROM_DAY() {
        return SEARCH_DATE_FROM_DAY;
    }

    /**
     * 検索条件日時FROM日
     * @param SEARCH_DATE_FROM_DAY 検索条件日時FROM日
     */
    public void setSEARCH_DATE_FROM_DAY(String SEARCH_DATE_FROM_DAY) {
        this.SEARCH_DATE_FROM_DAY = SEARCH_DATE_FROM_DAY == null ? null : SEARCH_DATE_FROM_DAY.trim();
    }

    /**
     * 検索条件日時TO年
     * @return SEARCH_DATE_TO_YEAR 検索条件日時TO年
     */
    public String getSEARCH_DATE_TO_YEAR() {
        return SEARCH_DATE_TO_YEAR;
    }

    /**
     * 検索条件日時TO年
     * @param SEARCH_DATE_TO_YEAR 検索条件日時TO年
     */
    public void setSEARCH_DATE_TO_YEAR(String SEARCH_DATE_TO_YEAR) {
        this.SEARCH_DATE_TO_YEAR = SEARCH_DATE_TO_YEAR == null ? null : SEARCH_DATE_TO_YEAR.trim();
    }

    /**
     * 検索条件日時TO月
     * @return SEARCH_DATE_TO_MONTH 検索条件日時TO月
     */
    public String getSEARCH_DATE_TO_MONTH() {
        return SEARCH_DATE_TO_MONTH;
    }

    /**
     * 検索条件日時TO月
     * @param SEARCH_DATE_TO_MONTH 検索条件日時TO月
     */
    public void setSEARCH_DATE_TO_MONTH(String SEARCH_DATE_TO_MONTH) {
        this.SEARCH_DATE_TO_MONTH = SEARCH_DATE_TO_MONTH == null ? null : SEARCH_DATE_TO_MONTH.trim();
    }

    /**
     * 検索条件日時TO日
     * @return SEARCH_DATE_TO_DAY 検索条件日時TO日
     */
    public String getSEARCH_DATE_TO_DAY() {
        return SEARCH_DATE_TO_DAY;
    }

    /**
     * 検索条件日時TO日
     * @param SEARCH_DATE_TO_DAY 検索条件日時TO日
     */
    public void setSEARCH_DATE_TO_DAY(String SEARCH_DATE_TO_DAY) {
        this.SEARCH_DATE_TO_DAY = SEARCH_DATE_TO_DAY == null ? null : SEARCH_DATE_TO_DAY.trim();
    }

    /**
     * 検索条件予約中
     * @return SEARCH_RESERVE_FLG 検索条件予約中
     */
    public String getSEARCH_RESERVE_FLG() {
        return SEARCH_RESERVE_FLG;
    }

    /**
     * 検索条件予約中
     * @param SEARCH_RESERVE_FLG 検索条件予約中
     */
    public void setSEARCH_RESERVE_FLG(String SEARCH_RESERVE_FLG) {
        this.SEARCH_RESERVE_FLG = SEARCH_RESERVE_FLG == null ? null : SEARCH_RESERVE_FLG.trim();
    }

    /**
     * 検索条件警備先検索機種
     * @return SEARCH_KEIBI_MODEL 検索条件警備先検索機種
     */
    public String getSEARCH_KEIBI_MODEL() {
        return SEARCH_KEIBI_MODEL;
    }

    /**
     * 検索条件警備先検索機種
     * @param SEARCH_KEIBI_MODEL 検索条件警備先検索機種
     */
    public void setSEARCH_KEIBI_MODEL(String SEARCH_KEIBI_MODEL) {
        this.SEARCH_KEIBI_MODEL = SEARCH_KEIBI_MODEL == null ? null : SEARCH_KEIBI_MODEL.trim();
    }

    /**
     * 検索条件時刻検索機種
     * @return SEARCH_TIME_MODEL 検索条件時刻検索機種
     */
    public String getSEARCH_TIME_MODEL() {
        return SEARCH_TIME_MODEL;
    }

    /**
     * 検索条件時刻検索機種
     * @param SEARCH_TIME_MODEL 検索条件時刻検索機種
     */
    public void setSEARCH_TIME_MODEL(String SEARCH_TIME_MODEL) {
        this.SEARCH_TIME_MODEL = SEARCH_TIME_MODEL == null ? null : SEARCH_TIME_MODEL.trim();
    }

    /**
     * 選択タブ
     * @return SELECT_SEARCH 選択タブ
     */
    public String getSELECT_SEARCH() {
        return SELECT_SEARCH;
    }

    /**
     * 選択タブ
     * @param SELECT_SEARCH 選択タブ
     */
    public void setSELECT_SEARCH(String SELECT_SEARCH) {
        this.SELECT_SEARCH = SELECT_SEARCH == null ? null : SELECT_SEARCH.trim();
    }

    /**
     * 警備先検索済みフラグ
     * @return KEIBI_SEARCH_FLG 警備先検索済みフラグ
     */
    public String getKEIBI_SEARCH_FLG() {
        return KEIBI_SEARCH_FLG;
    }

    /**
     * 警備先検索済みフラグ
     * @param KEIBI_SEARCH_FLG 警備先検索済みフラグ
     */
    public void setKEIBI_SEARCH_FLG(String KEIBI_SEARCH_FLG) {
        this.KEIBI_SEARCH_FLG = KEIBI_SEARCH_FLG == null ? null : KEIBI_SEARCH_FLG.trim();
    }

    /**
     * 時刻検索済みフラグ
     * @return TIME_SEARCH_FLG 時刻検索済みフラグ
     */
    public String getTIME_SEARCH_FLG() {
        return TIME_SEARCH_FLG;
    }

    /**
     * 時刻検索済みフラグ
     * @param TIME_SEARCH_FLG 時刻検索済みフラグ
     */
    public void setTIME_SEARCH_FLG(String TIME_SEARCH_FLG) {
        this.TIME_SEARCH_FLG = TIME_SEARCH_FLG == null ? null : TIME_SEARCH_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * 検索条件警備先
     * @return SEARCH_KEIBI 検索条件警備先
     */
    public String getSEARCH_KEIBI() {
        return SEARCH_KEIBI;
    }

    /**
     * 検索条件警備先
     * @param SEARCH_KEIBI 検索条件警備先
     */
    public void setSEARCH_KEIBI(String SEARCH_KEIBI) {
        this.SEARCH_KEIBI = SEARCH_KEIBI == null ? null : SEARCH_KEIBI.trim();
    }
}