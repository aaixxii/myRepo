package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EQueEmpSig implements Serializable {
    /**
     * LN_空室信号キュー論理番号
     */
    private String LN_QUE_EMP_SIG;

    /**
     * 受信日時
     */
    private Date RCV_TS;

    /**
     * シリアル番号
     */
    private String SERIAL_NUM;

    /**
     * 実行コマンド
     */
    private String EXEC_CMD;

    /**
     * 状態
     */
    private String STS;

    /**
     * LN_予約画面登録論理番号
     */
    private String LN_GAMEN_TOUROKU_RESV;

    /**
     * コントローラー信号フラグ
     */
    private String CTRL_SIG_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * SOAP電文
     */
    private String SOAP_MSG;

    /**
     * E_QUE_EMP_SIG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_空室信号キュー論理番号
     * @return LN_QUE_EMP_SIG LN_空室信号キュー論理番号
     */
    public String getLN_QUE_EMP_SIG() {
        return LN_QUE_EMP_SIG;
    }

    /**
     * LN_空室信号キュー論理番号
     * @param LN_QUE_EMP_SIG LN_空室信号キュー論理番号
     */
    public void setLN_QUE_EMP_SIG(String LN_QUE_EMP_SIG) {
        this.LN_QUE_EMP_SIG = LN_QUE_EMP_SIG == null ? null : LN_QUE_EMP_SIG.trim();
    }

    /**
     * 受信日時
     * @return RCV_TS 受信日時
     */
    public Date getRCV_TS() {
        return RCV_TS;
    }

    /**
     * 受信日時
     * @param RCV_TS 受信日時
     */
    public void setRCV_TS(Date RCV_TS) {
        this.RCV_TS = RCV_TS;
    }

    /**
     * シリアル番号
     * @return SERIAL_NUM シリアル番号
     */
    public String getSERIAL_NUM() {
        return SERIAL_NUM;
    }

    /**
     * シリアル番号
     * @param SERIAL_NUM シリアル番号
     */
    public void setSERIAL_NUM(String SERIAL_NUM) {
        this.SERIAL_NUM = SERIAL_NUM == null ? null : SERIAL_NUM.trim();
    }

    /**
     * 実行コマンド
     * @return EXEC_CMD 実行コマンド
     */
    public String getEXEC_CMD() {
        return EXEC_CMD;
    }

    /**
     * 実行コマンド
     * @param EXEC_CMD 実行コマンド
     */
    public void setEXEC_CMD(String EXEC_CMD) {
        this.EXEC_CMD = EXEC_CMD == null ? null : EXEC_CMD.trim();
    }

    /**
     * 状態
     * @return STS 状態
     */
    public String getSTS() {
        return STS;
    }

    /**
     * 状態
     * @param STS 状態
     */
    public void setSTS(String STS) {
        this.STS = STS == null ? null : STS.trim();
    }

    /**
     * LN_予約画面登録論理番号
     * @return LN_GAMEN_TOUROKU_RESV LN_予約画面登録論理番号
     */
    public String getLN_GAMEN_TOUROKU_RESV() {
        return LN_GAMEN_TOUROKU_RESV;
    }

    /**
     * LN_予約画面登録論理番号
     * @param LN_GAMEN_TOUROKU_RESV LN_予約画面登録論理番号
     */
    public void setLN_GAMEN_TOUROKU_RESV(String LN_GAMEN_TOUROKU_RESV) {
        this.LN_GAMEN_TOUROKU_RESV = LN_GAMEN_TOUROKU_RESV == null ? null : LN_GAMEN_TOUROKU_RESV.trim();
    }

    /**
     * コントローラー信号フラグ
     * @return CTRL_SIG_FLG コントローラー信号フラグ
     */
    public String getCTRL_SIG_FLG() {
        return CTRL_SIG_FLG;
    }

    /**
     * コントローラー信号フラグ
     * @param CTRL_SIG_FLG コントローラー信号フラグ
     */
    public void setCTRL_SIG_FLG(String CTRL_SIG_FLG) {
        this.CTRL_SIG_FLG = CTRL_SIG_FLG == null ? null : CTRL_SIG_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * SOAP電文
     * @return SOAP_MSG SOAP電文
     */
    public String getSOAP_MSG() {
        return SOAP_MSG;
    }

    /**
     * SOAP電文
     * @param SOAP_MSG SOAP電文
     */
    public void setSOAP_MSG(String SOAP_MSG) {
        this.SOAP_MSG = SOAP_MSG == null ? null : SOAP_MSG.trim();
    }
}