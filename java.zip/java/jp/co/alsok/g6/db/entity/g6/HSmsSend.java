package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HSmsSend implements Serializable {
    /**
     * LN_送信履歴論理番号
     */
    private String LN_SMS_SEND;

    /**
     * アカウント種別
     */
    private String ACNT_KIND;

    /**
     * 種別
     */
    private String KIND;

    /**
     * 送信結果
     */
    private String SENT_RSLT;

    /**
     * 最大リトライ回数
     */
    private String MAX_RETRY_NUM;

    /**
     * リトライ回数
     */
    private String RETRY_NUM;

    /**
     * 送信可能日時
     */
    private Date SEND_ABL_TS;

    /**
     * 送信可能開始時間
     */
    private Date SEND_ABL_FROM_TM;

    /**
     * 送信可能終了時間
     */
    private Date SEND_ABL_TO_TM;

    /**
     * 差出人名称
     */
    private String FROM_NM;

    /**
     * 差出人アドレス
     */
    private String ADDR_FROM;

    /**
     * 宛先アドレス
     */
    private String ADDR_TO;

    /**
     * タイトル
     */
    private String TITLE;

    /**
     * 送信日時
     */
    private Date ML_SENT_TS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * 本文
     */
    private String BODY1;

    /**
     * H_SMS_SEND
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_送信履歴論理番号
     * @return LN_SMS_SEND LN_送信履歴論理番号
     */
    public String getLN_SMS_SEND() {
        return LN_SMS_SEND;
    }

    /**
     * LN_送信履歴論理番号
     * @param LN_SMS_SEND LN_送信履歴論理番号
     */
    public void setLN_SMS_SEND(String LN_SMS_SEND) {
        this.LN_SMS_SEND = LN_SMS_SEND == null ? null : LN_SMS_SEND.trim();
    }

    /**
     * アカウント種別
     * @return ACNT_KIND アカウント種別
     */
    public String getACNT_KIND() {
        return ACNT_KIND;
    }

    /**
     * アカウント種別
     * @param ACNT_KIND アカウント種別
     */
    public void setACNT_KIND(String ACNT_KIND) {
        this.ACNT_KIND = ACNT_KIND == null ? null : ACNT_KIND.trim();
    }

    /**
     * 種別
     * @return KIND 種別
     */
    public String getKIND() {
        return KIND;
    }

    /**
     * 種別
     * @param KIND 種別
     */
    public void setKIND(String KIND) {
        this.KIND = KIND == null ? null : KIND.trim();
    }

    /**
     * 送信結果
     * @return SENT_RSLT 送信結果
     */
    public String getSENT_RSLT() {
        return SENT_RSLT;
    }

    /**
     * 送信結果
     * @param SENT_RSLT 送信結果
     */
    public void setSENT_RSLT(String SENT_RSLT) {
        this.SENT_RSLT = SENT_RSLT == null ? null : SENT_RSLT.trim();
    }

    /**
     * 最大リトライ回数
     * @return MAX_RETRY_NUM 最大リトライ回数
     */
    public String getMAX_RETRY_NUM() {
        return MAX_RETRY_NUM;
    }

    /**
     * 最大リトライ回数
     * @param MAX_RETRY_NUM 最大リトライ回数
     */
    public void setMAX_RETRY_NUM(String MAX_RETRY_NUM) {
        this.MAX_RETRY_NUM = MAX_RETRY_NUM == null ? null : MAX_RETRY_NUM.trim();
    }

    /**
     * リトライ回数
     * @return RETRY_NUM リトライ回数
     */
    public String getRETRY_NUM() {
        return RETRY_NUM;
    }

    /**
     * リトライ回数
     * @param RETRY_NUM リトライ回数
     */
    public void setRETRY_NUM(String RETRY_NUM) {
        this.RETRY_NUM = RETRY_NUM == null ? null : RETRY_NUM.trim();
    }

    /**
     * 送信可能日時
     * @return SEND_ABL_TS 送信可能日時
     */
    public Date getSEND_ABL_TS() {
        return SEND_ABL_TS;
    }

    /**
     * 送信可能日時
     * @param SEND_ABL_TS 送信可能日時
     */
    public void setSEND_ABL_TS(Date SEND_ABL_TS) {
        this.SEND_ABL_TS = SEND_ABL_TS;
    }

    /**
     * 送信可能開始時間
     * @return SEND_ABL_FROM_TM 送信可能開始時間
     */
    public Date getSEND_ABL_FROM_TM() {
        return SEND_ABL_FROM_TM;
    }

    /**
     * 送信可能開始時間
     * @param SEND_ABL_FROM_TM 送信可能開始時間
     */
    public void setSEND_ABL_FROM_TM(Date SEND_ABL_FROM_TM) {
        this.SEND_ABL_FROM_TM = SEND_ABL_FROM_TM;
    }

    /**
     * 送信可能終了時間
     * @return SEND_ABL_TO_TM 送信可能終了時間
     */
    public Date getSEND_ABL_TO_TM() {
        return SEND_ABL_TO_TM;
    }

    /**
     * 送信可能終了時間
     * @param SEND_ABL_TO_TM 送信可能終了時間
     */
    public void setSEND_ABL_TO_TM(Date SEND_ABL_TO_TM) {
        this.SEND_ABL_TO_TM = SEND_ABL_TO_TM;
    }

    /**
     * 差出人名称
     * @return FROM_NM 差出人名称
     */
    public String getFROM_NM() {
        return FROM_NM;
    }

    /**
     * 差出人名称
     * @param FROM_NM 差出人名称
     */
    public void setFROM_NM(String FROM_NM) {
        this.FROM_NM = FROM_NM == null ? null : FROM_NM.trim();
    }

    /**
     * 差出人アドレス
     * @return ADDR_FROM 差出人アドレス
     */
    public String getADDR_FROM() {
        return ADDR_FROM;
    }

    /**
     * 差出人アドレス
     * @param ADDR_FROM 差出人アドレス
     */
    public void setADDR_FROM(String ADDR_FROM) {
        this.ADDR_FROM = ADDR_FROM == null ? null : ADDR_FROM.trim();
    }

    /**
     * 宛先アドレス
     * @return ADDR_TO 宛先アドレス
     */
    public String getADDR_TO() {
        return ADDR_TO;
    }

    /**
     * 宛先アドレス
     * @param ADDR_TO 宛先アドレス
     */
    public void setADDR_TO(String ADDR_TO) {
        this.ADDR_TO = ADDR_TO == null ? null : ADDR_TO.trim();
    }

    /**
     * タイトル
     * @return TITLE タイトル
     */
    public String getTITLE() {
        return TITLE;
    }

    /**
     * タイトル
     * @param TITLE タイトル
     */
    public void setTITLE(String TITLE) {
        this.TITLE = TITLE == null ? null : TITLE.trim();
    }

    /**
     * 送信日時
     * @return ML_SENT_TS 送信日時
     */
    public Date getML_SENT_TS() {
        return ML_SENT_TS;
    }

    /**
     * 送信日時
     * @param ML_SENT_TS 送信日時
     */
    public void setML_SENT_TS(Date ML_SENT_TS) {
        this.ML_SENT_TS = ML_SENT_TS;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * 本文
     * @return BODY1 本文
     */
    public String getBODY1() {
        return BODY1;
    }

    /**
     * 本文
     * @param BODY1 本文
     */
    public void setBODY1(String BODY1) {
        this.BODY1 = BODY1 == null ? null : BODY1.trim();
    }
}