package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CQueSmsTrigExample {
    /**
     * C_QUE_SMS_TRIG
     */
    protected String orderByClause;

    /**
     * C_QUE_SMS_TRIG
     */
    protected boolean distinct;

    /**
     * C_QUE_SMS_TRIG
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public CQueSmsTrigExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * C_QUE_SMS_TRIG null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_SMS_TRIGIsNull() {
            addCriterion("LN_SMS_TRIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGIsNotNull() {
            addCriterion("LN_SMS_TRIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGEqualTo(String value) {
            addCriterion("LN_SMS_TRIG =", value, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGNotEqualTo(String value) {
            addCriterion("LN_SMS_TRIG <>", value, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGGreaterThan(String value) {
            addCriterion("LN_SMS_TRIG >", value, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_SMS_TRIG >=", value, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGLessThan(String value) {
            addCriterion("LN_SMS_TRIG <", value, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGLessThanOrEqualTo(String value) {
            addCriterion("LN_SMS_TRIG <=", value, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGLike(String value) {
            addCriterion("LN_SMS_TRIG like", value, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGNotLike(String value) {
            addCriterion("LN_SMS_TRIG not like", value, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGIn(List<String> values) {
            addCriterion("LN_SMS_TRIG in", values, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGNotIn(List<String> values) {
            addCriterion("LN_SMS_TRIG not in", values, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGBetween(String value1, String value2) {
            addCriterion("LN_SMS_TRIG between", value1, value2, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGNotBetween(String value1, String value2) {
            addCriterion("LN_SMS_TRIG not between", value1, value2, "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andKINDIsNull() {
            addCriterion("KIND is null");
            return (Criteria) this;
        }

        public Criteria andKINDIsNotNull() {
            addCriterion("KIND is not null");
            return (Criteria) this;
        }

        public Criteria andKINDEqualTo(String value) {
            addCriterion("KIND =", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotEqualTo(String value) {
            addCriterion("KIND <>", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThan(String value) {
            addCriterion("KIND >", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThanOrEqualTo(String value) {
            addCriterion("KIND >=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThan(String value) {
            addCriterion("KIND <", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThanOrEqualTo(String value) {
            addCriterion("KIND <=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLike(String value) {
            addCriterion("KIND like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotLike(String value) {
            addCriterion("KIND not like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDIn(List<String> values) {
            addCriterion("KIND in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotIn(List<String> values) {
            addCriterion("KIND not in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDBetween(String value1, String value2) {
            addCriterion("KIND between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotBetween(String value1, String value2) {
            addCriterion("KIND not between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andSTSIsNull() {
            addCriterion("STS is null");
            return (Criteria) this;
        }

        public Criteria andSTSIsNotNull() {
            addCriterion("STS is not null");
            return (Criteria) this;
        }

        public Criteria andSTSEqualTo(String value) {
            addCriterion("STS =", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotEqualTo(String value) {
            addCriterion("STS <>", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSGreaterThan(String value) {
            addCriterion("STS >", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSGreaterThanOrEqualTo(String value) {
            addCriterion("STS >=", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLessThan(String value) {
            addCriterion("STS <", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLessThanOrEqualTo(String value) {
            addCriterion("STS <=", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLike(String value) {
            addCriterion("STS like", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotLike(String value) {
            addCriterion("STS not like", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSIn(List<String> values) {
            addCriterion("STS in", values, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotIn(List<String> values) {
            addCriterion("STS not in", values, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSBetween(String value1, String value2) {
            addCriterion("STS between", value1, value2, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotBetween(String value1, String value2) {
            addCriterion("STS not between", value1, value2, "STS");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIsNull() {
            addCriterion("LN_KB_INF is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIsNotNull() {
            addCriterion("LN_KB_INF is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFEqualTo(String value) {
            addCriterion("LN_KB_INF =", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotEqualTo(String value) {
            addCriterion("LN_KB_INF <>", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFGreaterThan(String value) {
            addCriterion("LN_KB_INF >", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF >=", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLessThan(String value) {
            addCriterion("LN_KB_INF <", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF <=", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLike(String value) {
            addCriterion("LN_KB_INF like", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotLike(String value) {
            addCriterion("LN_KB_INF not like", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIn(List<String> values) {
            addCriterion("LN_KB_INF in", values, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotIn(List<String> values) {
            addCriterion("LN_KB_INF not in", values, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFBetween(String value1, String value2) {
            addCriterion("LN_KB_INF between", value1, value2, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF not between", value1, value2, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIsNull() {
            addCriterion("SEND_ABL_TS is null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIsNotNull() {
            addCriterion("SEND_ABL_TS is not null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSEqualTo(Date value) {
            addCriterion("SEND_ABL_TS =", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotEqualTo(Date value) {
            addCriterion("SEND_ABL_TS <>", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSGreaterThan(Date value) {
            addCriterion("SEND_ABL_TS >", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("SEND_ABL_TS >=", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSLessThan(Date value) {
            addCriterion("SEND_ABL_TS <", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSLessThanOrEqualTo(Date value) {
            addCriterion("SEND_ABL_TS <=", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIn(List<Date> values) {
            addCriterion("SEND_ABL_TS in", values, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotIn(List<Date> values) {
            addCriterion("SEND_ABL_TS not in", values, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSBetween(Date value1, Date value2) {
            addCriterion("SEND_ABL_TS between", value1, value2, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotBetween(Date value1, Date value2) {
            addCriterion("SEND_ABL_TS not between", value1, value2, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNull() {
            addCriterion("LN_KB_CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNotNull() {
            addCriterion("LN_KB_CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUEqualTo(String value) {
            addCriterion("LN_KB_CHIKU =", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <>", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThan(String value) {
            addCriterion("LN_KB_CHIKU >", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU >=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThan(String value) {
            addCriterion("LN_KB_CHIKU <", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULike(String value) {
            addCriterion("LN_KB_CHIKU like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotLike(String value) {
            addCriterion("LN_KB_CHIKU not like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIn(List<String> values) {
            addCriterion("LN_KB_CHIKU in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotIn(List<String> values) {
            addCriterion("LN_KB_CHIKU not in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU not between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGIsNull() {
            addCriterion("LN_TENANT_MNG is null");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGIsNotNull() {
            addCriterion("LN_TENANT_MNG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGEqualTo(String value) {
            addCriterion("LN_TENANT_MNG =", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGNotEqualTo(String value) {
            addCriterion("LN_TENANT_MNG <>", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGGreaterThan(String value) {
            addCriterion("LN_TENANT_MNG >", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_TENANT_MNG >=", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGLessThan(String value) {
            addCriterion("LN_TENANT_MNG <", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGLessThanOrEqualTo(String value) {
            addCriterion("LN_TENANT_MNG <=", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGLike(String value) {
            addCriterion("LN_TENANT_MNG like", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGNotLike(String value) {
            addCriterion("LN_TENANT_MNG not like", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGIn(List<String> values) {
            addCriterion("LN_TENANT_MNG in", values, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGNotIn(List<String> values) {
            addCriterion("LN_TENANT_MNG not in", values, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGBetween(String value1, String value2) {
            addCriterion("LN_TENANT_MNG between", value1, value2, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGNotBetween(String value1, String value2) {
            addCriterion("LN_TENANT_MNG not between", value1, value2, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMIsNull() {
            addCriterion("KEIBI_NM is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMIsNotNull() {
            addCriterion("KEIBI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMEqualTo(String value) {
            addCriterion("KEIBI_NM =", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMNotEqualTo(String value) {
            addCriterion("KEIBI_NM <>", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMGreaterThan(String value) {
            addCriterion("KEIBI_NM >", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM >=", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMLessThan(String value) {
            addCriterion("KEIBI_NM <", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMLessThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM <=", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMLike(String value) {
            addCriterion("KEIBI_NM like", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMNotLike(String value) {
            addCriterion("KEIBI_NM not like", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMIn(List<String> values) {
            addCriterion("KEIBI_NM in", values, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMNotIn(List<String> values) {
            addCriterion("KEIBI_NM not in", values, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMBetween(String value1, String value2) {
            addCriterion("KEIBI_NM between", value1, value2, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMNotBetween(String value1, String value2) {
            addCriterion("KEIBI_NM not between", value1, value2, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMIsNull() {
            addCriterion("SIG_DTL_NM is null");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMIsNotNull() {
            addCriterion("SIG_DTL_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMEqualTo(String value) {
            addCriterion("SIG_DTL_NM =", value, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMNotEqualTo(String value) {
            addCriterion("SIG_DTL_NM <>", value, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMGreaterThan(String value) {
            addCriterion("SIG_DTL_NM >", value, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SIG_DTL_NM >=", value, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMLessThan(String value) {
            addCriterion("SIG_DTL_NM <", value, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMLessThanOrEqualTo(String value) {
            addCriterion("SIG_DTL_NM <=", value, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMLike(String value) {
            addCriterion("SIG_DTL_NM like", value, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMNotLike(String value) {
            addCriterion("SIG_DTL_NM not like", value, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMIn(List<String> values) {
            addCriterion("SIG_DTL_NM in", values, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMNotIn(List<String> values) {
            addCriterion("SIG_DTL_NM not in", values, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMBetween(String value1, String value2) {
            addCriterion("SIG_DTL_NM between", value1, value2, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMNotBetween(String value1, String value2) {
            addCriterion("SIG_DTL_NM not between", value1, value2, "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIsNull() {
            addCriterion("SIG_HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIsNotNull() {
            addCriterion("SIG_HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSEqualTo(Date value) {
            addCriterion("SIG_HASSEI_TS =", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotEqualTo(Date value) {
            addCriterion("SIG_HASSEI_TS <>", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSGreaterThan(Date value) {
            addCriterion("SIG_HASSEI_TS >", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("SIG_HASSEI_TS >=", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSLessThan(Date value) {
            addCriterion("SIG_HASSEI_TS <", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSLessThanOrEqualTo(Date value) {
            addCriterion("SIG_HASSEI_TS <=", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIn(List<Date> values) {
            addCriterion("SIG_HASSEI_TS in", values, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotIn(List<Date> values) {
            addCriterion("SIG_HASSEI_TS not in", values, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSBetween(Date value1, Date value2) {
            addCriterion("SIG_HASSEI_TS between", value1, value2, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotBetween(Date value1, Date value2) {
            addCriterion("SIG_HASSEI_TS not between", value1, value2, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMIsNull() {
            addCriterion("SD_KOBETU_NM is null");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMIsNotNull() {
            addCriterion("SD_KOBETU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMEqualTo(String value) {
            addCriterion("SD_KOBETU_NM =", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMNotEqualTo(String value) {
            addCriterion("SD_KOBETU_NM <>", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMGreaterThan(String value) {
            addCriterion("SD_KOBETU_NM >", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SD_KOBETU_NM >=", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMLessThan(String value) {
            addCriterion("SD_KOBETU_NM <", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMLessThanOrEqualTo(String value) {
            addCriterion("SD_KOBETU_NM <=", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMLike(String value) {
            addCriterion("SD_KOBETU_NM like", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMNotLike(String value) {
            addCriterion("SD_KOBETU_NM not like", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMIn(List<String> values) {
            addCriterion("SD_KOBETU_NM in", values, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMNotIn(List<String> values) {
            addCriterion("SD_KOBETU_NM not in", values, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMBetween(String value1, String value2) {
            addCriterion("SD_KOBETU_NM between", value1, value2, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMNotBetween(String value1, String value2) {
            addCriterion("SD_KOBETU_NM not between", value1, value2, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIsNull() {
            addCriterion("DEV_NM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIsNotNull() {
            addCriterion("DEV_NM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_NMEqualTo(String value) {
            addCriterion("DEV_NM =", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotEqualTo(String value) {
            addCriterion("DEV_NM <>", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMGreaterThan(String value) {
            addCriterion("DEV_NM >", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_NM >=", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLessThan(String value) {
            addCriterion("DEV_NM <", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLessThanOrEqualTo(String value) {
            addCriterion("DEV_NM <=", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLike(String value) {
            addCriterion("DEV_NM like", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotLike(String value) {
            addCriterion("DEV_NM not like", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIn(List<String> values) {
            addCriterion("DEV_NM in", values, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotIn(List<String> values) {
            addCriterion("DEV_NM not in", values, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMBetween(String value1, String value2) {
            addCriterion("DEV_NM between", value1, value2, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotBetween(String value1, String value2) {
            addCriterion("DEV_NM not between", value1, value2, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERIsNull() {
            addCriterion("OPERATION_USER is null");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERIsNotNull() {
            addCriterion("OPERATION_USER is not null");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USEREqualTo(String value) {
            addCriterion("OPERATION_USER =", value, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERNotEqualTo(String value) {
            addCriterion("OPERATION_USER <>", value, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERGreaterThan(String value) {
            addCriterion("OPERATION_USER >", value, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERGreaterThanOrEqualTo(String value) {
            addCriterion("OPERATION_USER >=", value, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERLessThan(String value) {
            addCriterion("OPERATION_USER <", value, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERLessThanOrEqualTo(String value) {
            addCriterion("OPERATION_USER <=", value, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERLike(String value) {
            addCriterion("OPERATION_USER like", value, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERNotLike(String value) {
            addCriterion("OPERATION_USER not like", value, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERIn(List<String> values) {
            addCriterion("OPERATION_USER in", values, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERNotIn(List<String> values) {
            addCriterion("OPERATION_USER not in", values, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERBetween(String value1, String value2) {
            addCriterion("OPERATION_USER between", value1, value2, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERNotBetween(String value1, String value2) {
            addCriterion("OPERATION_USER not between", value1, value2, "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andRM_KINDIsNull() {
            addCriterion("RM_KIND is null");
            return (Criteria) this;
        }

        public Criteria andRM_KINDIsNotNull() {
            addCriterion("RM_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andRM_KINDEqualTo(String value) {
            addCriterion("RM_KIND =", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDNotEqualTo(String value) {
            addCriterion("RM_KIND <>", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDGreaterThan(String value) {
            addCriterion("RM_KIND >", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("RM_KIND >=", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDLessThan(String value) {
            addCriterion("RM_KIND <", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDLessThanOrEqualTo(String value) {
            addCriterion("RM_KIND <=", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDLike(String value) {
            addCriterion("RM_KIND like", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDNotLike(String value) {
            addCriterion("RM_KIND not like", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDIn(List<String> values) {
            addCriterion("RM_KIND in", values, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDNotIn(List<String> values) {
            addCriterion("RM_KIND not in", values, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDBetween(String value1, String value2) {
            addCriterion("RM_KIND between", value1, value2, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDNotBetween(String value1, String value2) {
            addCriterion("RM_KIND not between", value1, value2, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTIsNull() {
            addCriterion("WATCH_TGT is null");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTIsNotNull() {
            addCriterion("WATCH_TGT is not null");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTEqualTo(String value) {
            addCriterion("WATCH_TGT =", value, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTNotEqualTo(String value) {
            addCriterion("WATCH_TGT <>", value, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTGreaterThan(String value) {
            addCriterion("WATCH_TGT >", value, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTGreaterThanOrEqualTo(String value) {
            addCriterion("WATCH_TGT >=", value, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTLessThan(String value) {
            addCriterion("WATCH_TGT <", value, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTLessThanOrEqualTo(String value) {
            addCriterion("WATCH_TGT <=", value, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTLike(String value) {
            addCriterion("WATCH_TGT like", value, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTNotLike(String value) {
            addCriterion("WATCH_TGT not like", value, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTIn(List<String> values) {
            addCriterion("WATCH_TGT in", values, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTNotIn(List<String> values) {
            addCriterion("WATCH_TGT not in", values, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTBetween(String value1, String value2) {
            addCriterion("WATCH_TGT between", value1, value2, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTNotBetween(String value1, String value2) {
            addCriterion("WATCH_TGT not between", value1, value2, "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMIsNull() {
            addCriterion("JIGYOU_NM is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMIsNotNull() {
            addCriterion("JIGYOU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMEqualTo(String value) {
            addCriterion("JIGYOU_NM =", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMNotEqualTo(String value) {
            addCriterion("JIGYOU_NM <>", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMGreaterThan(String value) {
            addCriterion("JIGYOU_NM >", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOU_NM >=", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMLessThan(String value) {
            addCriterion("JIGYOU_NM <", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMLessThanOrEqualTo(String value) {
            addCriterion("JIGYOU_NM <=", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMLike(String value) {
            addCriterion("JIGYOU_NM like", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMNotLike(String value) {
            addCriterion("JIGYOU_NM not like", value, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMIn(List<String> values) {
            addCriterion("JIGYOU_NM in", values, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMNotIn(List<String> values) {
            addCriterion("JIGYOU_NM not in", values, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMBetween(String value1, String value2) {
            addCriterion("JIGYOU_NM between", value1, value2, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMNotBetween(String value1, String value2) {
            addCriterion("JIGYOU_NM not between", value1, value2, "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNull() {
            addCriterion("DENKEI is null");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNotNull() {
            addCriterion("DENKEI is not null");
            return (Criteria) this;
        }

        public Criteria andDENKEIEqualTo(String value) {
            addCriterion("DENKEI =", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotEqualTo(String value) {
            addCriterion("DENKEI <>", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThan(String value) {
            addCriterion("DENKEI >", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThanOrEqualTo(String value) {
            addCriterion("DENKEI >=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThan(String value) {
            addCriterion("DENKEI <", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThanOrEqualTo(String value) {
            addCriterion("DENKEI <=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILike(String value) {
            addCriterion("DENKEI like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotLike(String value) {
            addCriterion("DENKEI not like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIIn(List<String> values) {
            addCriterion("DENKEI in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotIn(List<String> values) {
            addCriterion("DENKEI not in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIBetween(String value1, String value2) {
            addCriterion("DENKEI between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotBetween(String value1, String value2) {
            addCriterion("DENKEI not between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICEIsNull() {
            addCriterion("LN_ALSOK_NOTICE is null");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICEIsNotNull() {
            addCriterion("LN_ALSOK_NOTICE is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICEEqualTo(String value) {
            addCriterion("LN_ALSOK_NOTICE =", value, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICENotEqualTo(String value) {
            addCriterion("LN_ALSOK_NOTICE <>", value, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICEGreaterThan(String value) {
            addCriterion("LN_ALSOK_NOTICE >", value, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICEGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ALSOK_NOTICE >=", value, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICELessThan(String value) {
            addCriterion("LN_ALSOK_NOTICE <", value, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICELessThanOrEqualTo(String value) {
            addCriterion("LN_ALSOK_NOTICE <=", value, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICELike(String value) {
            addCriterion("LN_ALSOK_NOTICE like", value, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICENotLike(String value) {
            addCriterion("LN_ALSOK_NOTICE not like", value, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICEIn(List<String> values) {
            addCriterion("LN_ALSOK_NOTICE in", values, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICENotIn(List<String> values) {
            addCriterion("LN_ALSOK_NOTICE not in", values, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICEBetween(String value1, String value2) {
            addCriterion("LN_ALSOK_NOTICE between", value1, value2, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICENotBetween(String value1, String value2) {
            addCriterion("LN_ALSOK_NOTICE not between", value1, value2, "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDIsNull() {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND is null");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDIsNotNull() {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDEqualTo(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND =", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDNotEqualTo(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND <>", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDGreaterThan(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND >", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND >=", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDLessThan(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND <", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDLessThanOrEqualTo(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND <=", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDLike(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND like", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDNotLike(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND not like", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDIn(List<String> values) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND in", values, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDNotIn(List<String> values) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND not in", values, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDBetween(String value1, String value2) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND between", value1, value2, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDNotBetween(String value1, String value2) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND not between", value1, value2, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNull() {
            addCriterion("LN_ACNT_USER_COMMON is null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNotNull() {
            addCriterion("LN_ACNT_USER_COMMON is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON =", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <>", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON >", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON >=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON <", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON not like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON not in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON not between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTIsNull() {
            addCriterion("LN_SEND_TGT is null");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTIsNotNull() {
            addCriterion("LN_SEND_TGT is not null");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTEqualTo(String value) {
            addCriterion("LN_SEND_TGT =", value, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTNotEqualTo(String value) {
            addCriterion("LN_SEND_TGT <>", value, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTGreaterThan(String value) {
            addCriterion("LN_SEND_TGT >", value, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTGreaterThanOrEqualTo(String value) {
            addCriterion("LN_SEND_TGT >=", value, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTLessThan(String value) {
            addCriterion("LN_SEND_TGT <", value, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTLessThanOrEqualTo(String value) {
            addCriterion("LN_SEND_TGT <=", value, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTLike(String value) {
            addCriterion("LN_SEND_TGT like", value, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTNotLike(String value) {
            addCriterion("LN_SEND_TGT not like", value, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTIn(List<String> values) {
            addCriterion("LN_SEND_TGT in", values, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTNotIn(List<String> values) {
            addCriterion("LN_SEND_TGT not in", values, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTBetween(String value1, String value2) {
            addCriterion("LN_SEND_TGT between", value1, value2, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTNotBetween(String value1, String value2) {
            addCriterion("LN_SEND_TGT not between", value1, value2, "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOIsNull() {
            addCriterion("FILE_NM_TO is null");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOIsNotNull() {
            addCriterion("FILE_NM_TO is not null");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOEqualTo(String value) {
            addCriterion("FILE_NM_TO =", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TONotEqualTo(String value) {
            addCriterion("FILE_NM_TO <>", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOGreaterThan(String value) {
            addCriterion("FILE_NM_TO >", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOGreaterThanOrEqualTo(String value) {
            addCriterion("FILE_NM_TO >=", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOLessThan(String value) {
            addCriterion("FILE_NM_TO <", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOLessThanOrEqualTo(String value) {
            addCriterion("FILE_NM_TO <=", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOLike(String value) {
            addCriterion("FILE_NM_TO like", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TONotLike(String value) {
            addCriterion("FILE_NM_TO not like", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOIn(List<String> values) {
            addCriterion("FILE_NM_TO in", values, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TONotIn(List<String> values) {
            addCriterion("FILE_NM_TO not in", values, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOBetween(String value1, String value2) {
            addCriterion("FILE_NM_TO between", value1, value2, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TONotBetween(String value1, String value2) {
            addCriterion("FILE_NM_TO not between", value1, value2, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOIsNull() {
            addCriterion("GET_KIND_TO is null");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOIsNotNull() {
            addCriterion("GET_KIND_TO is not null");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOEqualTo(String value) {
            addCriterion("GET_KIND_TO =", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TONotEqualTo(String value) {
            addCriterion("GET_KIND_TO <>", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOGreaterThan(String value) {
            addCriterion("GET_KIND_TO >", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOGreaterThanOrEqualTo(String value) {
            addCriterion("GET_KIND_TO >=", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOLessThan(String value) {
            addCriterion("GET_KIND_TO <", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOLessThanOrEqualTo(String value) {
            addCriterion("GET_KIND_TO <=", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOLike(String value) {
            addCriterion("GET_KIND_TO like", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TONotLike(String value) {
            addCriterion("GET_KIND_TO not like", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOIn(List<String> values) {
            addCriterion("GET_KIND_TO in", values, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TONotIn(List<String> values) {
            addCriterion("GET_KIND_TO not in", values, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOBetween(String value1, String value2) {
            addCriterion("GET_KIND_TO between", value1, value2, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TONotBetween(String value1, String value2) {
            addCriterion("GET_KIND_TO not between", value1, value2, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_SMS_TRIGLikeInsensitive(String value) {
            addCriterion("upper(LN_SMS_TRIG) like", value.toUpperCase(), "LN_SMS_TRIG");
            return (Criteria) this;
        }

        public Criteria andKINDLikeInsensitive(String value) {
            addCriterion("upper(KIND) like", value.toUpperCase(), "KIND");
            return (Criteria) this;
        }

        public Criteria andSTSLikeInsensitive(String value) {
            addCriterion("upper(STS) like", value.toUpperCase(), "STS");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF) like", value.toUpperCase(), "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULikeInsensitive(String value) {
            addCriterion("upper(LN_KB_CHIKU) like", value.toUpperCase(), "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGLikeInsensitive(String value) {
            addCriterion("upper(LN_TENANT_MNG) like", value.toUpperCase(), "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMLikeInsensitive(String value) {
            addCriterion("upper(KEIBI_NM) like", value.toUpperCase(), "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_DTL_NMLikeInsensitive(String value) {
            addCriterion("upper(SIG_DTL_NM) like", value.toUpperCase(), "SIG_DTL_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMLikeInsensitive(String value) {
            addCriterion("upper(SD_KOBETU_NM) like", value.toUpperCase(), "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLikeInsensitive(String value) {
            addCriterion("upper(DEV_NM) like", value.toUpperCase(), "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andOPERATION_USERLikeInsensitive(String value) {
            addCriterion("upper(OPERATION_USER) like", value.toUpperCase(), "OPERATION_USER");
            return (Criteria) this;
        }

        public Criteria andRM_KINDLikeInsensitive(String value) {
            addCriterion("upper(RM_KIND) like", value.toUpperCase(), "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andWATCH_TGTLikeInsensitive(String value) {
            addCriterion("upper(WATCH_TGT) like", value.toUpperCase(), "WATCH_TGT");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_NMLikeInsensitive(String value) {
            addCriterion("upper(JIGYOU_NM) like", value.toUpperCase(), "JIGYOU_NM");
            return (Criteria) this;
        }

        public Criteria andDENKEILikeInsensitive(String value) {
            addCriterion("upper(DENKEI) like", value.toUpperCase(), "DENKEI");
            return (Criteria) this;
        }

        public Criteria andLN_ALSOK_NOTICELikeInsensitive(String value) {
            addCriterion("upper(LN_ALSOK_NOTICE) like", value.toUpperCase(), "LN_ALSOK_NOTICE");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDLikeInsensitive(String value) {
            addCriterion("upper(ALSOK_NOTICE_SEND_SVC_KIND) like", value.toUpperCase(), "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLikeInsensitive(String value) {
            addCriterion("upper(LN_ACNT_USER_COMMON) like", value.toUpperCase(), "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_SEND_TGTLikeInsensitive(String value) {
            addCriterion("upper(LN_SEND_TGT) like", value.toUpperCase(), "LN_SEND_TGT");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOLikeInsensitive(String value) {
            addCriterion("upper(FILE_NM_TO) like", value.toUpperCase(), "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOLikeInsensitive(String value) {
            addCriterion("upper(GET_KIND_TO) like", value.toUpperCase(), "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * C_QUE_SMS_TRIG
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * C_QUE_SMS_TRIG null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}