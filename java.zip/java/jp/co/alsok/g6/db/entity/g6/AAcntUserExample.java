package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AAcntUserExample {
    /**
     * A_ACNT_USER
     */
    protected String orderByClause;

    /**
     * A_ACNT_USER
     */
    protected boolean distinct;

    /**
     * A_ACNT_USER
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public AAcntUserExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * A_ACNT_USER null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_ACNT_USER_COMMONIsNull() {
            addCriterion("LN_ACNT_USER_COMMON is null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNotNull() {
            addCriterion("LN_ACNT_USER_COMMON is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON =", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <>", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON >", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON >=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON <", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON not like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON not in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON not between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGIsNull() {
            addCriterion("KNRN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGIsNotNull() {
            addCriterion("KNRN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGEqualTo(String value) {
            addCriterion("KNRN_FLG =", value, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGNotEqualTo(String value) {
            addCriterion("KNRN_FLG <>", value, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGGreaterThan(String value) {
            addCriterion("KNRN_FLG >", value, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("KNRN_FLG >=", value, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGLessThan(String value) {
            addCriterion("KNRN_FLG <", value, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGLessThanOrEqualTo(String value) {
            addCriterion("KNRN_FLG <=", value, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGLike(String value) {
            addCriterion("KNRN_FLG like", value, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGNotLike(String value) {
            addCriterion("KNRN_FLG not like", value, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGIn(List<String> values) {
            addCriterion("KNRN_FLG in", values, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGNotIn(List<String> values) {
            addCriterion("KNRN_FLG not in", values, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGBetween(String value1, String value2) {
            addCriterion("KNRN_FLG between", value1, value2, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGNotBetween(String value1, String value2) {
            addCriterion("KNRN_FLG not between", value1, value2, "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGIsNull() {
            addCriterion("CARD_FLG is null");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGIsNotNull() {
            addCriterion("CARD_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGEqualTo(String value) {
            addCriterion("CARD_FLG =", value, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGNotEqualTo(String value) {
            addCriterion("CARD_FLG <>", value, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGGreaterThan(String value) {
            addCriterion("CARD_FLG >", value, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("CARD_FLG >=", value, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGLessThan(String value) {
            addCriterion("CARD_FLG <", value, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGLessThanOrEqualTo(String value) {
            addCriterion("CARD_FLG <=", value, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGLike(String value) {
            addCriterion("CARD_FLG like", value, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGNotLike(String value) {
            addCriterion("CARD_FLG not like", value, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGIn(List<String> values) {
            addCriterion("CARD_FLG in", values, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGNotIn(List<String> values) {
            addCriterion("CARD_FLG not in", values, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGBetween(String value1, String value2) {
            addCriterion("CARD_FLG between", value1, value2, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGNotBetween(String value1, String value2) {
            addCriterion("CARD_FLG not between", value1, value2, "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andML_STSIsNull() {
            addCriterion("ML_STS is null");
            return (Criteria) this;
        }

        public Criteria andML_STSIsNotNull() {
            addCriterion("ML_STS is not null");
            return (Criteria) this;
        }

        public Criteria andML_STSEqualTo(String value) {
            addCriterion("ML_STS =", value, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSNotEqualTo(String value) {
            addCriterion("ML_STS <>", value, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSGreaterThan(String value) {
            addCriterion("ML_STS >", value, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSGreaterThanOrEqualTo(String value) {
            addCriterion("ML_STS >=", value, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSLessThan(String value) {
            addCriterion("ML_STS <", value, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSLessThanOrEqualTo(String value) {
            addCriterion("ML_STS <=", value, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSLike(String value) {
            addCriterion("ML_STS like", value, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSNotLike(String value) {
            addCriterion("ML_STS not like", value, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSIn(List<String> values) {
            addCriterion("ML_STS in", values, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSNotIn(List<String> values) {
            addCriterion("ML_STS not in", values, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSBetween(String value1, String value2) {
            addCriterion("ML_STS between", value1, value2, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_STSNotBetween(String value1, String value2) {
            addCriterion("ML_STS not between", value1, value2, "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGIsNull() {
            addCriterion("ML_SEND_FLG is null");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGIsNotNull() {
            addCriterion("ML_SEND_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGEqualTo(String value) {
            addCriterion("ML_SEND_FLG =", value, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGNotEqualTo(String value) {
            addCriterion("ML_SEND_FLG <>", value, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGGreaterThan(String value) {
            addCriterion("ML_SEND_FLG >", value, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("ML_SEND_FLG >=", value, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGLessThan(String value) {
            addCriterion("ML_SEND_FLG <", value, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGLessThanOrEqualTo(String value) {
            addCriterion("ML_SEND_FLG <=", value, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGLike(String value) {
            addCriterion("ML_SEND_FLG like", value, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGNotLike(String value) {
            addCriterion("ML_SEND_FLG not like", value, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGIn(List<String> values) {
            addCriterion("ML_SEND_FLG in", values, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGNotIn(List<String> values) {
            addCriterion("ML_SEND_FLG not in", values, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGBetween(String value1, String value2) {
            addCriterion("ML_SEND_FLG between", value1, value2, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGNotBetween(String value1, String value2) {
            addCriterion("ML_SEND_FLG not between", value1, value2, "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDIsNull() {
            addCriterion("ML_ERR_CD is null");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDIsNotNull() {
            addCriterion("ML_ERR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDEqualTo(String value) {
            addCriterion("ML_ERR_CD =", value, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDNotEqualTo(String value) {
            addCriterion("ML_ERR_CD <>", value, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDGreaterThan(String value) {
            addCriterion("ML_ERR_CD >", value, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("ML_ERR_CD >=", value, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDLessThan(String value) {
            addCriterion("ML_ERR_CD <", value, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDLessThanOrEqualTo(String value) {
            addCriterion("ML_ERR_CD <=", value, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDLike(String value) {
            addCriterion("ML_ERR_CD like", value, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDNotLike(String value) {
            addCriterion("ML_ERR_CD not like", value, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDIn(List<String> values) {
            addCriterion("ML_ERR_CD in", values, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDNotIn(List<String> values) {
            addCriterion("ML_ERR_CD not in", values, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDBetween(String value1, String value2) {
            addCriterion("ML_ERR_CD between", value1, value2, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDNotBetween(String value1, String value2) {
            addCriterion("ML_ERR_CD not between", value1, value2, "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSIsNull() {
            addCriterion("ML_SEND_STS is null");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSIsNotNull() {
            addCriterion("ML_SEND_STS is not null");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSEqualTo(String value) {
            addCriterion("ML_SEND_STS =", value, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSNotEqualTo(String value) {
            addCriterion("ML_SEND_STS <>", value, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSGreaterThan(String value) {
            addCriterion("ML_SEND_STS >", value, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSGreaterThanOrEqualTo(String value) {
            addCriterion("ML_SEND_STS >=", value, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSLessThan(String value) {
            addCriterion("ML_SEND_STS <", value, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSLessThanOrEqualTo(String value) {
            addCriterion("ML_SEND_STS <=", value, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSLike(String value) {
            addCriterion("ML_SEND_STS like", value, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSNotLike(String value) {
            addCriterion("ML_SEND_STS not like", value, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSIn(List<String> values) {
            addCriterion("ML_SEND_STS in", values, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSNotIn(List<String> values) {
            addCriterion("ML_SEND_STS not in", values, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSBetween(String value1, String value2) {
            addCriterion("ML_SEND_STS between", value1, value2, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSNotBetween(String value1, String value2) {
            addCriterion("ML_SEND_STS not between", value1, value2, "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUIsNull() {
            addCriterion("ML_ADDR_TOUROKU is null");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUIsNotNull() {
            addCriterion("ML_ADDR_TOUROKU is not null");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUEqualTo(String value) {
            addCriterion("ML_ADDR_TOUROKU =", value, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUNotEqualTo(String value) {
            addCriterion("ML_ADDR_TOUROKU <>", value, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUGreaterThan(String value) {
            addCriterion("ML_ADDR_TOUROKU >", value, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUGreaterThanOrEqualTo(String value) {
            addCriterion("ML_ADDR_TOUROKU >=", value, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKULessThan(String value) {
            addCriterion("ML_ADDR_TOUROKU <", value, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKULessThanOrEqualTo(String value) {
            addCriterion("ML_ADDR_TOUROKU <=", value, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKULike(String value) {
            addCriterion("ML_ADDR_TOUROKU like", value, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUNotLike(String value) {
            addCriterion("ML_ADDR_TOUROKU not like", value, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUIn(List<String> values) {
            addCriterion("ML_ADDR_TOUROKU in", values, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUNotIn(List<String> values) {
            addCriterion("ML_ADDR_TOUROKU not in", values, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUBetween(String value1, String value2) {
            addCriterion("ML_ADDR_TOUROKU between", value1, value2, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKUNotBetween(String value1, String value2) {
            addCriterion("ML_ADDR_TOUROKU not between", value1, value2, "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUIsNull() {
            addCriterion("TOUROKU_BIKOU is null");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUIsNotNull() {
            addCriterion("TOUROKU_BIKOU is not null");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUEqualTo(String value) {
            addCriterion("TOUROKU_BIKOU =", value, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUNotEqualTo(String value) {
            addCriterion("TOUROKU_BIKOU <>", value, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUGreaterThan(String value) {
            addCriterion("TOUROKU_BIKOU >", value, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUGreaterThanOrEqualTo(String value) {
            addCriterion("TOUROKU_BIKOU >=", value, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOULessThan(String value) {
            addCriterion("TOUROKU_BIKOU <", value, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOULessThanOrEqualTo(String value) {
            addCriterion("TOUROKU_BIKOU <=", value, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOULike(String value) {
            addCriterion("TOUROKU_BIKOU like", value, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUNotLike(String value) {
            addCriterion("TOUROKU_BIKOU not like", value, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUIn(List<String> values) {
            addCriterion("TOUROKU_BIKOU in", values, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUNotIn(List<String> values) {
            addCriterion("TOUROKU_BIKOU not in", values, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUBetween(String value1, String value2) {
            addCriterion("TOUROKU_BIKOU between", value1, value2, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOUNotBetween(String value1, String value2) {
            addCriterion("TOUROKU_BIKOU not between", value1, value2, "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUIsNull() {
            addCriterion("ALSOK_BIKOU is null");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUIsNotNull() {
            addCriterion("ALSOK_BIKOU is not null");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUEqualTo(String value) {
            addCriterion("ALSOK_BIKOU =", value, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUNotEqualTo(String value) {
            addCriterion("ALSOK_BIKOU <>", value, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUGreaterThan(String value) {
            addCriterion("ALSOK_BIKOU >", value, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUGreaterThanOrEqualTo(String value) {
            addCriterion("ALSOK_BIKOU >=", value, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOULessThan(String value) {
            addCriterion("ALSOK_BIKOU <", value, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOULessThanOrEqualTo(String value) {
            addCriterion("ALSOK_BIKOU <=", value, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOULike(String value) {
            addCriterion("ALSOK_BIKOU like", value, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUNotLike(String value) {
            addCriterion("ALSOK_BIKOU not like", value, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUIn(List<String> values) {
            addCriterion("ALSOK_BIKOU in", values, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUNotIn(List<String> values) {
            addCriterion("ALSOK_BIKOU not in", values, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUBetween(String value1, String value2) {
            addCriterion("ALSOK_BIKOU between", value1, value2, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOUNotBetween(String value1, String value2) {
            addCriterion("ALSOK_BIKOU not between", value1, value2, "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSIsNull() {
            addCriterion("CHECK_STS is null");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSIsNotNull() {
            addCriterion("CHECK_STS is not null");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSEqualTo(String value) {
            addCriterion("CHECK_STS =", value, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSNotEqualTo(String value) {
            addCriterion("CHECK_STS <>", value, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSGreaterThan(String value) {
            addCriterion("CHECK_STS >", value, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSGreaterThanOrEqualTo(String value) {
            addCriterion("CHECK_STS >=", value, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSLessThan(String value) {
            addCriterion("CHECK_STS <", value, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSLessThanOrEqualTo(String value) {
            addCriterion("CHECK_STS <=", value, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSLike(String value) {
            addCriterion("CHECK_STS like", value, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSNotLike(String value) {
            addCriterion("CHECK_STS not like", value, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSIn(List<String> values) {
            addCriterion("CHECK_STS in", values, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSNotIn(List<String> values) {
            addCriterion("CHECK_STS not in", values, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSBetween(String value1, String value2) {
            addCriterion("CHECK_STS between", value1, value2, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSNotBetween(String value1, String value2) {
            addCriterion("CHECK_STS not between", value1, value2, "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSIsNull() {
            addCriterion("LAST_LOGIN_TS is null");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSIsNotNull() {
            addCriterion("LAST_LOGIN_TS is not null");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSEqualTo(Date value) {
            addCriterion("LAST_LOGIN_TS =", value, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSNotEqualTo(Date value) {
            addCriterion("LAST_LOGIN_TS <>", value, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSGreaterThan(Date value) {
            addCriterion("LAST_LOGIN_TS >", value, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("LAST_LOGIN_TS >=", value, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSLessThan(Date value) {
            addCriterion("LAST_LOGIN_TS <", value, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSLessThanOrEqualTo(Date value) {
            addCriterion("LAST_LOGIN_TS <=", value, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSIn(List<Date> values) {
            addCriterion("LAST_LOGIN_TS in", values, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSNotIn(List<Date> values) {
            addCriterion("LAST_LOGIN_TS not in", values, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSBetween(Date value1, Date value2) {
            addCriterion("LAST_LOGIN_TS between", value1, value2, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andLAST_LOGIN_TSNotBetween(Date value1, Date value2) {
            addCriterion("LAST_LOGIN_TS not between", value1, value2, "LAST_LOGIN_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSIsNull() {
            addCriterion("STS_UPD_TS is null");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSIsNotNull() {
            addCriterion("STS_UPD_TS is not null");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSEqualTo(Date value) {
            addCriterion("STS_UPD_TS =", value, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSNotEqualTo(Date value) {
            addCriterion("STS_UPD_TS <>", value, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSGreaterThan(Date value) {
            addCriterion("STS_UPD_TS >", value, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("STS_UPD_TS >=", value, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSLessThan(Date value) {
            addCriterion("STS_UPD_TS <", value, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSLessThanOrEqualTo(Date value) {
            addCriterion("STS_UPD_TS <=", value, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSIn(List<Date> values) {
            addCriterion("STS_UPD_TS in", values, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSNotIn(List<Date> values) {
            addCriterion("STS_UPD_TS not in", values, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSBetween(Date value1, Date value2) {
            addCriterion("STS_UPD_TS between", value1, value2, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTS_UPD_TSNotBetween(Date value1, Date value2) {
            addCriterion("STS_UPD_TS not between", value1, value2, "STS_UPD_TS");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGIsNull() {
            addCriterion("WEB_ETURAN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGIsNotNull() {
            addCriterion("WEB_ETURAN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGEqualTo(String value) {
            addCriterion("WEB_ETURAN_FLG =", value, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGNotEqualTo(String value) {
            addCriterion("WEB_ETURAN_FLG <>", value, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGGreaterThan(String value) {
            addCriterion("WEB_ETURAN_FLG >", value, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("WEB_ETURAN_FLG >=", value, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGLessThan(String value) {
            addCriterion("WEB_ETURAN_FLG <", value, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGLessThanOrEqualTo(String value) {
            addCriterion("WEB_ETURAN_FLG <=", value, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGLike(String value) {
            addCriterion("WEB_ETURAN_FLG like", value, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGNotLike(String value) {
            addCriterion("WEB_ETURAN_FLG not like", value, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGIn(List<String> values) {
            addCriterion("WEB_ETURAN_FLG in", values, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGNotIn(List<String> values) {
            addCriterion("WEB_ETURAN_FLG not in", values, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGBetween(String value1, String value2) {
            addCriterion("WEB_ETURAN_FLG between", value1, value2, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGNotBetween(String value1, String value2) {
            addCriterion("WEB_ETURAN_FLG not between", value1, value2, "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLikeInsensitive(String value) {
            addCriterion("upper(LN_ACNT_USER_COMMON) like", value.toUpperCase(), "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andKNRN_FLGLikeInsensitive(String value) {
            addCriterion("upper(KNRN_FLG) like", value.toUpperCase(), "KNRN_FLG");
            return (Criteria) this;
        }

        public Criteria andCARD_FLGLikeInsensitive(String value) {
            addCriterion("upper(CARD_FLG) like", value.toUpperCase(), "CARD_FLG");
            return (Criteria) this;
        }

        public Criteria andML_STSLikeInsensitive(String value) {
            addCriterion("upper(ML_STS) like", value.toUpperCase(), "ML_STS");
            return (Criteria) this;
        }

        public Criteria andML_SEND_FLGLikeInsensitive(String value) {
            addCriterion("upper(ML_SEND_FLG) like", value.toUpperCase(), "ML_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andML_ERR_CDLikeInsensitive(String value) {
            addCriterion("upper(ML_ERR_CD) like", value.toUpperCase(), "ML_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andML_SEND_STSLikeInsensitive(String value) {
            addCriterion("upper(ML_SEND_STS) like", value.toUpperCase(), "ML_SEND_STS");
            return (Criteria) this;
        }

        public Criteria andML_ADDR_TOUROKULikeInsensitive(String value) {
            addCriterion("upper(ML_ADDR_TOUROKU) like", value.toUpperCase(), "ML_ADDR_TOUROKU");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_BIKOULikeInsensitive(String value) {
            addCriterion("upper(TOUROKU_BIKOU) like", value.toUpperCase(), "TOUROKU_BIKOU");
            return (Criteria) this;
        }

        public Criteria andALSOK_BIKOULikeInsensitive(String value) {
            addCriterion("upper(ALSOK_BIKOU) like", value.toUpperCase(), "ALSOK_BIKOU");
            return (Criteria) this;
        }

        public Criteria andCHECK_STSLikeInsensitive(String value) {
            addCriterion("upper(CHECK_STS) like", value.toUpperCase(), "CHECK_STS");
            return (Criteria) this;
        }

        public Criteria andWEB_ETURAN_FLGLikeInsensitive(String value) {
            addCriterion("upper(WEB_ETURAN_FLG) like", value.toUpperCase(), "WEB_ETURAN_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * A_ACNT_USER
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * A_ACNT_USER null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}