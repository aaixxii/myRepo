package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EKbInf implements Serializable {
    /**
     * LN_警備情報論理番号
     */
    private String LN_KB_INF;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * 信号受信日時
     */
    private Date SIG_RCV_TS;

    /**
     * 信号発生日時
     */
    private Date SIG_HASSEI_TS;

    /**
     * ＧＷ受信日時
     */
    private String GW_RCV_TS;

    /**
     * ＧＷ確認送信元ＩＰアドレス
     */
    private String GW_RCV_IP_ADDR;

    /**
     * ＧＷホスト名
     */
    private String GW_HOST_NM;

    /**
     * ＧＷＩＰアドレス種別
     */
    private String GW_IP_KIND;

    /**
     * ９電文バージョン
     */
    private String CMD_VER_9;

    /**
     * ９トランザクション番号
     */
    private String TR_NUM_9;

    /**
     * ９発生時刻
     */
    private String GENERATION_TS_9;

    /**
     * ９送信機ID
     */
    private String TRANSMITTER_9_ID;

    /**
     * ９電計番号
     */
    private String DENKEI_9;

    /**
     * ９号機番号
     */
    private String GOUKI_9;

    /**
     * ９サブアドレス
     */
    private String SUB_ADDR_9;

    /**
     * ９回線種別
     */
    private String LINE_KIND_9;

    /**
     * ９コマンドシーケンス番号
     */
    private String CMD_SEQ_NUM_9;

    /**
     * 警備情報インデックス番号
     */
    private String k_INDEX_NUM;

    /**
     * 型式
     */
    private String MODEL_TYPE;

    /**
     * ＦＷバージョン
     */
    private String VER_FW;

    /**
     * 定時発信間隔
     */
    private String c0_MODE;

    /**
     * メインN0F0状態フラグ
     */
    private String n0_STS_MAIN_FLG;

    /**
     * メインDN0DF0状態フラグ
     */
    private String DN0_STS_MAIN_FLG;

    /**
     * メインKNKF状態フラグ
     */
    private String KN_STS_MAIN_FLG;

    /**
     * サブN0F0状態フラグ
     */
    private String n0_STS_SUB_ADDR_FLG;

    /**
     * サブDN0DF0状態フラグ
     */
    private String DN0_STS_SUB_ADDR_FLG;

    /**
     * サブKNKF状態フラグ
     */
    private String KN_STS_SUB_ADDR_FLG;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * 装置名称
     */
    private String DEV_NM;

    /**
     * リモート種別
     */
    private String RM_KIND;

    /**
     * 信号種別1
     */
    private String SIG_KIND_1;

    /**
     * 信号種別2
     */
    private String SIG_KIND_2;

    /**
     * 信号
     */
    private String SIG_CODE;

    /**
     * カードフォーマットID
     */
    private String CARD_FRMT_ID;

    /**
     * カード固定ID
     */
    private String CARD_KOTEI_ID;

    /**
     * カード可変ID
     */
    private String CARD_KAHEN_ID;

    /**
     * 画像連動フラグ
     */
    private String VIDEO_LINK_FLG;

    /**
     * 画像蓄積装置番号
     */
    private String VIDEO_DEV_NUM;

    /**
     * カメラ番号
     */
    private String CAMERA_NO;

    /**
     * 画像ファイル名
     */
    private String VIDEO_FILE_NAME;

    /**
     * フレームレート
     */
    private String FRAME_RATE;

    /**
     * 画像記録時間
     */
    private String VIDEO_RECORD_TIME;

    /**
     * 画像記録枚数
     */
    private String VIDEO_RECORD_COUNT;

    /**
     * 撮像開始時間
     */
    private String IMAGE_START_TIME;

    /**
     * 撮像枚数
     */
    private String IMAGE_COUNT;

    /**
     * ﾏｲｸ・ｲﾝﾀｰﾎﾝ連動フラグ
     */
    private String MIC_INTERPHONE_LINK_FLG;

    /**
     * 音声蓄積装置番号
     */
    private String VOICE_DEV_NUM;

    /**
     * インターホン番号
     */
    private String INTERPHONE_NO;

    /**
     * マイク番号
     */
    private String MIC_NO;

    /**
     * スピーカ番号
     */
    private String SPEAKER_NO;

    /**
     * 音声ファイル名
     */
    private String VOICE_FILE_NAME;

    /**
     * 音声記録時間
     */
    private String VOICE_RECORD_TIME;

    /**
     * GC送信フラグ
     */
    private String GC_SEND_FLG;

    /**
     * 信号名称
     */
    private String SIG_NM;

    /**
     * LN_警備信号キュー論理番号
     */
    private String LN_QUE_KB_SIG;

    /**
     * リモメン中フラグ
     */
    private String RM_FLG;

    /**
     * 監視対象外警報設定有無
     */
    private String EXCEPT_SIG_FLG;

    /**
     * 画像論理番号
     */
    private String IMG_NUM;

    /**
     * LN_画像論理番号（画像用）
     */
    private String LN_IMG_NUM_P;

    /**
     * LN_画像論理番号（音声用）
     */
    private String LN_IMG_NUM_V;

    /**
     * 画像取得状態
     */
    private String IMG_GET_STS;

    /**
     * 外部情報提供フラグ
     */
    private String OUT_REPORT_HYOJI_FLG;

    /**
     * 真報判断フラグ
     */
    private String SINPO_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_KB_INF
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_警備情報論理番号
     * @return LN_KB_INF LN_警備情報論理番号
     */
    public String getLN_KB_INF() {
        return LN_KB_INF;
    }

    /**
     * LN_警備情報論理番号
     * @param LN_KB_INF LN_警備情報論理番号
     */
    public void setLN_KB_INF(String LN_KB_INF) {
        this.LN_KB_INF = LN_KB_INF == null ? null : LN_KB_INF.trim();
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * 信号受信日時
     * @return SIG_RCV_TS 信号受信日時
     */
    public Date getSIG_RCV_TS() {
        return SIG_RCV_TS;
    }

    /**
     * 信号受信日時
     * @param SIG_RCV_TS 信号受信日時
     */
    public void setSIG_RCV_TS(Date SIG_RCV_TS) {
        this.SIG_RCV_TS = SIG_RCV_TS;
    }

    /**
     * 信号発生日時
     * @return SIG_HASSEI_TS 信号発生日時
     */
    public Date getSIG_HASSEI_TS() {
        return SIG_HASSEI_TS;
    }

    /**
     * 信号発生日時
     * @param SIG_HASSEI_TS 信号発生日時
     */
    public void setSIG_HASSEI_TS(Date SIG_HASSEI_TS) {
        this.SIG_HASSEI_TS = SIG_HASSEI_TS;
    }

    /**
     * ＧＷ受信日時
     * @return GW_RCV_TS ＧＷ受信日時
     */
    public String getGW_RCV_TS() {
        return GW_RCV_TS;
    }

    /**
     * ＧＷ受信日時
     * @param GW_RCV_TS ＧＷ受信日時
     */
    public void setGW_RCV_TS(String GW_RCV_TS) {
        this.GW_RCV_TS = GW_RCV_TS == null ? null : GW_RCV_TS.trim();
    }

    /**
     * ＧＷ確認送信元ＩＰアドレス
     * @return GW_RCV_IP_ADDR ＧＷ確認送信元ＩＰアドレス
     */
    public String getGW_RCV_IP_ADDR() {
        return GW_RCV_IP_ADDR;
    }

    /**
     * ＧＷ確認送信元ＩＰアドレス
     * @param GW_RCV_IP_ADDR ＧＷ確認送信元ＩＰアドレス
     */
    public void setGW_RCV_IP_ADDR(String GW_RCV_IP_ADDR) {
        this.GW_RCV_IP_ADDR = GW_RCV_IP_ADDR == null ? null : GW_RCV_IP_ADDR.trim();
    }

    /**
     * ＧＷホスト名
     * @return GW_HOST_NM ＧＷホスト名
     */
    public String getGW_HOST_NM() {
        return GW_HOST_NM;
    }

    /**
     * ＧＷホスト名
     * @param GW_HOST_NM ＧＷホスト名
     */
    public void setGW_HOST_NM(String GW_HOST_NM) {
        this.GW_HOST_NM = GW_HOST_NM == null ? null : GW_HOST_NM.trim();
    }

    /**
     * ＧＷＩＰアドレス種別
     * @return GW_IP_KIND ＧＷＩＰアドレス種別
     */
    public String getGW_IP_KIND() {
        return GW_IP_KIND;
    }

    /**
     * ＧＷＩＰアドレス種別
     * @param GW_IP_KIND ＧＷＩＰアドレス種別
     */
    public void setGW_IP_KIND(String GW_IP_KIND) {
        this.GW_IP_KIND = GW_IP_KIND == null ? null : GW_IP_KIND.trim();
    }

    /**
     * ９電文バージョン
     * @return CMD_VER_9 ９電文バージョン
     */
    public String getCMD_VER_9() {
        return CMD_VER_9;
    }

    /**
     * ９電文バージョン
     * @param CMD_VER_9 ９電文バージョン
     */
    public void setCMD_VER_9(String CMD_VER_9) {
        this.CMD_VER_9 = CMD_VER_9 == null ? null : CMD_VER_9.trim();
    }

    /**
     * ９トランザクション番号
     * @return TR_NUM_9 ９トランザクション番号
     */
    public String getTR_NUM_9() {
        return TR_NUM_9;
    }

    /**
     * ９トランザクション番号
     * @param TR_NUM_9 ９トランザクション番号
     */
    public void setTR_NUM_9(String TR_NUM_9) {
        this.TR_NUM_9 = TR_NUM_9 == null ? null : TR_NUM_9.trim();
    }

    /**
     * ９発生時刻
     * @return GENERATION_TS_9 ９発生時刻
     */
    public String getGENERATION_TS_9() {
        return GENERATION_TS_9;
    }

    /**
     * ９発生時刻
     * @param GENERATION_TS_9 ９発生時刻
     */
    public void setGENERATION_TS_9(String GENERATION_TS_9) {
        this.GENERATION_TS_9 = GENERATION_TS_9 == null ? null : GENERATION_TS_9.trim();
    }

    /**
     * ９送信機ID
     * @return TRANSMITTER_9_ID ９送信機ID
     */
    public String getTRANSMITTER_9_ID() {
        return TRANSMITTER_9_ID;
    }

    /**
     * ９送信機ID
     * @param TRANSMITTER_9_ID ９送信機ID
     */
    public void setTRANSMITTER_9_ID(String TRANSMITTER_9_ID) {
        this.TRANSMITTER_9_ID = TRANSMITTER_9_ID == null ? null : TRANSMITTER_9_ID.trim();
    }

    /**
     * ９電計番号
     * @return DENKEI_9 ９電計番号
     */
    public String getDENKEI_9() {
        return DENKEI_9;
    }

    /**
     * ９電計番号
     * @param DENKEI_9 ９電計番号
     */
    public void setDENKEI_9(String DENKEI_9) {
        this.DENKEI_9 = DENKEI_9 == null ? null : DENKEI_9.trim();
    }

    /**
     * ９号機番号
     * @return GOUKI_9 ９号機番号
     */
    public String getGOUKI_9() {
        return GOUKI_9;
    }

    /**
     * ９号機番号
     * @param GOUKI_9 ９号機番号
     */
    public void setGOUKI_9(String GOUKI_9) {
        this.GOUKI_9 = GOUKI_9 == null ? null : GOUKI_9.trim();
    }

    /**
     * ９サブアドレス
     * @return SUB_ADDR_9 ９サブアドレス
     */
    public String getSUB_ADDR_9() {
        return SUB_ADDR_9;
    }

    /**
     * ９サブアドレス
     * @param SUB_ADDR_9 ９サブアドレス
     */
    public void setSUB_ADDR_9(String SUB_ADDR_9) {
        this.SUB_ADDR_9 = SUB_ADDR_9 == null ? null : SUB_ADDR_9.trim();
    }

    /**
     * ９回線種別
     * @return LINE_KIND_9 ９回線種別
     */
    public String getLINE_KIND_9() {
        return LINE_KIND_9;
    }

    /**
     * ９回線種別
     * @param LINE_KIND_9 ９回線種別
     */
    public void setLINE_KIND_9(String LINE_KIND_9) {
        this.LINE_KIND_9 = LINE_KIND_9 == null ? null : LINE_KIND_9.trim();
    }

    /**
     * ９コマンドシーケンス番号
     * @return CMD_SEQ_NUM_9 ９コマンドシーケンス番号
     */
    public String getCMD_SEQ_NUM_9() {
        return CMD_SEQ_NUM_9;
    }

    /**
     * ９コマンドシーケンス番号
     * @param CMD_SEQ_NUM_9 ９コマンドシーケンス番号
     */
    public void setCMD_SEQ_NUM_9(String CMD_SEQ_NUM_9) {
        this.CMD_SEQ_NUM_9 = CMD_SEQ_NUM_9 == null ? null : CMD_SEQ_NUM_9.trim();
    }

    /**
     * 警備情報インデックス番号
     * @return K_INDEX_NUM 警備情報インデックス番号
     */
    public String getK_INDEX_NUM() {
        return k_INDEX_NUM;
    }

    /**
     * 警備情報インデックス番号
     * @param k_INDEX_NUM 警備情報インデックス番号
     */
    public void setK_INDEX_NUM(String k_INDEX_NUM) {
        this.k_INDEX_NUM = k_INDEX_NUM == null ? null : k_INDEX_NUM.trim();
    }

    /**
     * 型式
     * @return MODEL_TYPE 型式
     */
    public String getMODEL_TYPE() {
        return MODEL_TYPE;
    }

    /**
     * 型式
     * @param MODEL_TYPE 型式
     */
    public void setMODEL_TYPE(String MODEL_TYPE) {
        this.MODEL_TYPE = MODEL_TYPE == null ? null : MODEL_TYPE.trim();
    }

    /**
     * ＦＷバージョン
     * @return VER_FW ＦＷバージョン
     */
    public String getVER_FW() {
        return VER_FW;
    }

    /**
     * ＦＷバージョン
     * @param VER_FW ＦＷバージョン
     */
    public void setVER_FW(String VER_FW) {
        this.VER_FW = VER_FW == null ? null : VER_FW.trim();
    }

    /**
     * 定時発信間隔
     * @return C0_MODE 定時発信間隔
     */
    public String getC0_MODE() {
        return c0_MODE;
    }

    /**
     * 定時発信間隔
     * @param c0_MODE 定時発信間隔
     */
    public void setC0_MODE(String c0_MODE) {
        this.c0_MODE = c0_MODE == null ? null : c0_MODE.trim();
    }

    /**
     * メインN0F0状態フラグ
     * @return N0_STS_MAIN_FLG メインN0F0状態フラグ
     */
    public String getN0_STS_MAIN_FLG() {
        return n0_STS_MAIN_FLG;
    }

    /**
     * メインN0F0状態フラグ
     * @param n0_STS_MAIN_FLG メインN0F0状態フラグ
     */
    public void setN0_STS_MAIN_FLG(String n0_STS_MAIN_FLG) {
        this.n0_STS_MAIN_FLG = n0_STS_MAIN_FLG == null ? null : n0_STS_MAIN_FLG.trim();
    }

    /**
     * メインDN0DF0状態フラグ
     * @return DN0_STS_MAIN_FLG メインDN0DF0状態フラグ
     */
    public String getDN0_STS_MAIN_FLG() {
        return DN0_STS_MAIN_FLG;
    }

    /**
     * メインDN0DF0状態フラグ
     * @param DN0_STS_MAIN_FLG メインDN0DF0状態フラグ
     */
    public void setDN0_STS_MAIN_FLG(String DN0_STS_MAIN_FLG) {
        this.DN0_STS_MAIN_FLG = DN0_STS_MAIN_FLG == null ? null : DN0_STS_MAIN_FLG.trim();
    }

    /**
     * メインKNKF状態フラグ
     * @return KN_STS_MAIN_FLG メインKNKF状態フラグ
     */
    public String getKN_STS_MAIN_FLG() {
        return KN_STS_MAIN_FLG;
    }

    /**
     * メインKNKF状態フラグ
     * @param KN_STS_MAIN_FLG メインKNKF状態フラグ
     */
    public void setKN_STS_MAIN_FLG(String KN_STS_MAIN_FLG) {
        this.KN_STS_MAIN_FLG = KN_STS_MAIN_FLG == null ? null : KN_STS_MAIN_FLG.trim();
    }

    /**
     * サブN0F0状態フラグ
     * @return N0_STS_SUB_ADDR_FLG サブN0F0状態フラグ
     */
    public String getN0_STS_SUB_ADDR_FLG() {
        return n0_STS_SUB_ADDR_FLG;
    }

    /**
     * サブN0F0状態フラグ
     * @param n0_STS_SUB_ADDR_FLG サブN0F0状態フラグ
     */
    public void setN0_STS_SUB_ADDR_FLG(String n0_STS_SUB_ADDR_FLG) {
        this.n0_STS_SUB_ADDR_FLG = n0_STS_SUB_ADDR_FLG == null ? null : n0_STS_SUB_ADDR_FLG.trim();
    }

    /**
     * サブDN0DF0状態フラグ
     * @return DN0_STS_SUB_ADDR_FLG サブDN0DF0状態フラグ
     */
    public String getDN0_STS_SUB_ADDR_FLG() {
        return DN0_STS_SUB_ADDR_FLG;
    }

    /**
     * サブDN0DF0状態フラグ
     * @param DN0_STS_SUB_ADDR_FLG サブDN0DF0状態フラグ
     */
    public void setDN0_STS_SUB_ADDR_FLG(String DN0_STS_SUB_ADDR_FLG) {
        this.DN0_STS_SUB_ADDR_FLG = DN0_STS_SUB_ADDR_FLG == null ? null : DN0_STS_SUB_ADDR_FLG.trim();
    }

    /**
     * サブKNKF状態フラグ
     * @return KN_STS_SUB_ADDR_FLG サブKNKF状態フラグ
     */
    public String getKN_STS_SUB_ADDR_FLG() {
        return KN_STS_SUB_ADDR_FLG;
    }

    /**
     * サブKNKF状態フラグ
     * @param KN_STS_SUB_ADDR_FLG サブKNKF状態フラグ
     */
    public void setKN_STS_SUB_ADDR_FLG(String KN_STS_SUB_ADDR_FLG) {
        this.KN_STS_SUB_ADDR_FLG = KN_STS_SUB_ADDR_FLG == null ? null : KN_STS_SUB_ADDR_FLG.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * 装置名称
     * @return DEV_NM 装置名称
     */
    public String getDEV_NM() {
        return DEV_NM;
    }

    /**
     * 装置名称
     * @param DEV_NM 装置名称
     */
    public void setDEV_NM(String DEV_NM) {
        this.DEV_NM = DEV_NM == null ? null : DEV_NM.trim();
    }

    /**
     * リモート種別
     * @return RM_KIND リモート種別
     */
    public String getRM_KIND() {
        return RM_KIND;
    }

    /**
     * リモート種別
     * @param RM_KIND リモート種別
     */
    public void setRM_KIND(String RM_KIND) {
        this.RM_KIND = RM_KIND == null ? null : RM_KIND.trim();
    }

    /**
     * 信号種別1
     * @return SIG_KIND_1 信号種別1
     */
    public String getSIG_KIND_1() {
        return SIG_KIND_1;
    }

    /**
     * 信号種別1
     * @param SIG_KIND_1 信号種別1
     */
    public void setSIG_KIND_1(String SIG_KIND_1) {
        this.SIG_KIND_1 = SIG_KIND_1 == null ? null : SIG_KIND_1.trim();
    }

    /**
     * 信号種別2
     * @return SIG_KIND_2 信号種別2
     */
    public String getSIG_KIND_2() {
        return SIG_KIND_2;
    }

    /**
     * 信号種別2
     * @param SIG_KIND_2 信号種別2
     */
    public void setSIG_KIND_2(String SIG_KIND_2) {
        this.SIG_KIND_2 = SIG_KIND_2 == null ? null : SIG_KIND_2.trim();
    }

    /**
     * 信号
     * @return SIG_CODE 信号
     */
    public String getSIG_CODE() {
        return SIG_CODE;
    }

    /**
     * 信号
     * @param SIG_CODE 信号
     */
    public void setSIG_CODE(String SIG_CODE) {
        this.SIG_CODE = SIG_CODE == null ? null : SIG_CODE.trim();
    }

    /**
     * カードフォーマットID
     * @return CARD_FRMT_ID カードフォーマットID
     */
    public String getCARD_FRMT_ID() {
        return CARD_FRMT_ID;
    }

    /**
     * カードフォーマットID
     * @param CARD_FRMT_ID カードフォーマットID
     */
    public void setCARD_FRMT_ID(String CARD_FRMT_ID) {
        this.CARD_FRMT_ID = CARD_FRMT_ID == null ? null : CARD_FRMT_ID.trim();
    }

    /**
     * カード固定ID
     * @return CARD_KOTEI_ID カード固定ID
     */
    public String getCARD_KOTEI_ID() {
        return CARD_KOTEI_ID;
    }

    /**
     * カード固定ID
     * @param CARD_KOTEI_ID カード固定ID
     */
    public void setCARD_KOTEI_ID(String CARD_KOTEI_ID) {
        this.CARD_KOTEI_ID = CARD_KOTEI_ID == null ? null : CARD_KOTEI_ID.trim();
    }

    /**
     * カード可変ID
     * @return CARD_KAHEN_ID カード可変ID
     */
    public String getCARD_KAHEN_ID() {
        return CARD_KAHEN_ID;
    }

    /**
     * カード可変ID
     * @param CARD_KAHEN_ID カード可変ID
     */
    public void setCARD_KAHEN_ID(String CARD_KAHEN_ID) {
        this.CARD_KAHEN_ID = CARD_KAHEN_ID == null ? null : CARD_KAHEN_ID.trim();
    }

    /**
     * 画像連動フラグ
     * @return VIDEO_LINK_FLG 画像連動フラグ
     */
    public String getVIDEO_LINK_FLG() {
        return VIDEO_LINK_FLG;
    }

    /**
     * 画像連動フラグ
     * @param VIDEO_LINK_FLG 画像連動フラグ
     */
    public void setVIDEO_LINK_FLG(String VIDEO_LINK_FLG) {
        this.VIDEO_LINK_FLG = VIDEO_LINK_FLG == null ? null : VIDEO_LINK_FLG.trim();
    }

    /**
     * 画像蓄積装置番号
     * @return VIDEO_DEV_NUM 画像蓄積装置番号
     */
    public String getVIDEO_DEV_NUM() {
        return VIDEO_DEV_NUM;
    }

    /**
     * 画像蓄積装置番号
     * @param VIDEO_DEV_NUM 画像蓄積装置番号
     */
    public void setVIDEO_DEV_NUM(String VIDEO_DEV_NUM) {
        this.VIDEO_DEV_NUM = VIDEO_DEV_NUM == null ? null : VIDEO_DEV_NUM.trim();
    }

    /**
     * カメラ番号
     * @return CAMERA_NO カメラ番号
     */
    public String getCAMERA_NO() {
        return CAMERA_NO;
    }

    /**
     * カメラ番号
     * @param CAMERA_NO カメラ番号
     */
    public void setCAMERA_NO(String CAMERA_NO) {
        this.CAMERA_NO = CAMERA_NO == null ? null : CAMERA_NO.trim();
    }

    /**
     * 画像ファイル名
     * @return VIDEO_FILE_NAME 画像ファイル名
     */
    public String getVIDEO_FILE_NAME() {
        return VIDEO_FILE_NAME;
    }

    /**
     * 画像ファイル名
     * @param VIDEO_FILE_NAME 画像ファイル名
     */
    public void setVIDEO_FILE_NAME(String VIDEO_FILE_NAME) {
        this.VIDEO_FILE_NAME = VIDEO_FILE_NAME == null ? null : VIDEO_FILE_NAME.trim();
    }

    /**
     * フレームレート
     * @return FRAME_RATE フレームレート
     */
    public String getFRAME_RATE() {
        return FRAME_RATE;
    }

    /**
     * フレームレート
     * @param FRAME_RATE フレームレート
     */
    public void setFRAME_RATE(String FRAME_RATE) {
        this.FRAME_RATE = FRAME_RATE == null ? null : FRAME_RATE.trim();
    }

    /**
     * 画像記録時間
     * @return VIDEO_RECORD_TIME 画像記録時間
     */
    public String getVIDEO_RECORD_TIME() {
        return VIDEO_RECORD_TIME;
    }

    /**
     * 画像記録時間
     * @param VIDEO_RECORD_TIME 画像記録時間
     */
    public void setVIDEO_RECORD_TIME(String VIDEO_RECORD_TIME) {
        this.VIDEO_RECORD_TIME = VIDEO_RECORD_TIME == null ? null : VIDEO_RECORD_TIME.trim();
    }

    /**
     * 画像記録枚数
     * @return VIDEO_RECORD_COUNT 画像記録枚数
     */
    public String getVIDEO_RECORD_COUNT() {
        return VIDEO_RECORD_COUNT;
    }

    /**
     * 画像記録枚数
     * @param VIDEO_RECORD_COUNT 画像記録枚数
     */
    public void setVIDEO_RECORD_COUNT(String VIDEO_RECORD_COUNT) {
        this.VIDEO_RECORD_COUNT = VIDEO_RECORD_COUNT == null ? null : VIDEO_RECORD_COUNT.trim();
    }

    /**
     * 撮像開始時間
     * @return IMAGE_START_TIME 撮像開始時間
     */
    public String getIMAGE_START_TIME() {
        return IMAGE_START_TIME;
    }

    /**
     * 撮像開始時間
     * @param IMAGE_START_TIME 撮像開始時間
     */
    public void setIMAGE_START_TIME(String IMAGE_START_TIME) {
        this.IMAGE_START_TIME = IMAGE_START_TIME == null ? null : IMAGE_START_TIME.trim();
    }

    /**
     * 撮像枚数
     * @return IMAGE_COUNT 撮像枚数
     */
    public String getIMAGE_COUNT() {
        return IMAGE_COUNT;
    }

    /**
     * 撮像枚数
     * @param IMAGE_COUNT 撮像枚数
     */
    public void setIMAGE_COUNT(String IMAGE_COUNT) {
        this.IMAGE_COUNT = IMAGE_COUNT == null ? null : IMAGE_COUNT.trim();
    }

    /**
     * ﾏｲｸ・ｲﾝﾀｰﾎﾝ連動フラグ
     * @return MIC_INTERPHONE_LINK_FLG ﾏｲｸ・ｲﾝﾀｰﾎﾝ連動フラグ
     */
    public String getMIC_INTERPHONE_LINK_FLG() {
        return MIC_INTERPHONE_LINK_FLG;
    }

    /**
     * ﾏｲｸ・ｲﾝﾀｰﾎﾝ連動フラグ
     * @param MIC_INTERPHONE_LINK_FLG ﾏｲｸ・ｲﾝﾀｰﾎﾝ連動フラグ
     */
    public void setMIC_INTERPHONE_LINK_FLG(String MIC_INTERPHONE_LINK_FLG) {
        this.MIC_INTERPHONE_LINK_FLG = MIC_INTERPHONE_LINK_FLG == null ? null : MIC_INTERPHONE_LINK_FLG.trim();
    }

    /**
     * 音声蓄積装置番号
     * @return VOICE_DEV_NUM 音声蓄積装置番号
     */
    public String getVOICE_DEV_NUM() {
        return VOICE_DEV_NUM;
    }

    /**
     * 音声蓄積装置番号
     * @param VOICE_DEV_NUM 音声蓄積装置番号
     */
    public void setVOICE_DEV_NUM(String VOICE_DEV_NUM) {
        this.VOICE_DEV_NUM = VOICE_DEV_NUM == null ? null : VOICE_DEV_NUM.trim();
    }

    /**
     * インターホン番号
     * @return INTERPHONE_NO インターホン番号
     */
    public String getINTERPHONE_NO() {
        return INTERPHONE_NO;
    }

    /**
     * インターホン番号
     * @param INTERPHONE_NO インターホン番号
     */
    public void setINTERPHONE_NO(String INTERPHONE_NO) {
        this.INTERPHONE_NO = INTERPHONE_NO == null ? null : INTERPHONE_NO.trim();
    }

    /**
     * マイク番号
     * @return MIC_NO マイク番号
     */
    public String getMIC_NO() {
        return MIC_NO;
    }

    /**
     * マイク番号
     * @param MIC_NO マイク番号
     */
    public void setMIC_NO(String MIC_NO) {
        this.MIC_NO = MIC_NO == null ? null : MIC_NO.trim();
    }

    /**
     * スピーカ番号
     * @return SPEAKER_NO スピーカ番号
     */
    public String getSPEAKER_NO() {
        return SPEAKER_NO;
    }

    /**
     * スピーカ番号
     * @param SPEAKER_NO スピーカ番号
     */
    public void setSPEAKER_NO(String SPEAKER_NO) {
        this.SPEAKER_NO = SPEAKER_NO == null ? null : SPEAKER_NO.trim();
    }

    /**
     * 音声ファイル名
     * @return VOICE_FILE_NAME 音声ファイル名
     */
    public String getVOICE_FILE_NAME() {
        return VOICE_FILE_NAME;
    }

    /**
     * 音声ファイル名
     * @param VOICE_FILE_NAME 音声ファイル名
     */
    public void setVOICE_FILE_NAME(String VOICE_FILE_NAME) {
        this.VOICE_FILE_NAME = VOICE_FILE_NAME == null ? null : VOICE_FILE_NAME.trim();
    }

    /**
     * 音声記録時間
     * @return VOICE_RECORD_TIME 音声記録時間
     */
    public String getVOICE_RECORD_TIME() {
        return VOICE_RECORD_TIME;
    }

    /**
     * 音声記録時間
     * @param VOICE_RECORD_TIME 音声記録時間
     */
    public void setVOICE_RECORD_TIME(String VOICE_RECORD_TIME) {
        this.VOICE_RECORD_TIME = VOICE_RECORD_TIME == null ? null : VOICE_RECORD_TIME.trim();
    }

    /**
     * GC送信フラグ
     * @return GC_SEND_FLG GC送信フラグ
     */
    public String getGC_SEND_FLG() {
        return GC_SEND_FLG;
    }

    /**
     * GC送信フラグ
     * @param GC_SEND_FLG GC送信フラグ
     */
    public void setGC_SEND_FLG(String GC_SEND_FLG) {
        this.GC_SEND_FLG = GC_SEND_FLG == null ? null : GC_SEND_FLG.trim();
    }

    /**
     * 信号名称
     * @return SIG_NM 信号名称
     */
    public String getSIG_NM() {
        return SIG_NM;
    }

    /**
     * 信号名称
     * @param SIG_NM 信号名称
     */
    public void setSIG_NM(String SIG_NM) {
        this.SIG_NM = SIG_NM == null ? null : SIG_NM.trim();
    }

    /**
     * LN_警備信号キュー論理番号
     * @return LN_QUE_KB_SIG LN_警備信号キュー論理番号
     */
    public String getLN_QUE_KB_SIG() {
        return LN_QUE_KB_SIG;
    }

    /**
     * LN_警備信号キュー論理番号
     * @param LN_QUE_KB_SIG LN_警備信号キュー論理番号
     */
    public void setLN_QUE_KB_SIG(String LN_QUE_KB_SIG) {
        this.LN_QUE_KB_SIG = LN_QUE_KB_SIG == null ? null : LN_QUE_KB_SIG.trim();
    }

    /**
     * リモメン中フラグ
     * @return RM_FLG リモメン中フラグ
     */
    public String getRM_FLG() {
        return RM_FLG;
    }

    /**
     * リモメン中フラグ
     * @param RM_FLG リモメン中フラグ
     */
    public void setRM_FLG(String RM_FLG) {
        this.RM_FLG = RM_FLG == null ? null : RM_FLG.trim();
    }

    /**
     * 監視対象外警報設定有無
     * @return EXCEPT_SIG_FLG 監視対象外警報設定有無
     */
    public String getEXCEPT_SIG_FLG() {
        return EXCEPT_SIG_FLG;
    }

    /**
     * 監視対象外警報設定有無
     * @param EXCEPT_SIG_FLG 監視対象外警報設定有無
     */
    public void setEXCEPT_SIG_FLG(String EXCEPT_SIG_FLG) {
        this.EXCEPT_SIG_FLG = EXCEPT_SIG_FLG == null ? null : EXCEPT_SIG_FLG.trim();
    }

    /**
     * 画像論理番号
     * @return IMG_NUM 画像論理番号
     */
    public String getIMG_NUM() {
        return IMG_NUM;
    }

    /**
     * 画像論理番号
     * @param IMG_NUM 画像論理番号
     */
    public void setIMG_NUM(String IMG_NUM) {
        this.IMG_NUM = IMG_NUM == null ? null : IMG_NUM.trim();
    }

    /**
     * LN_画像論理番号（画像用）
     * @return LN_IMG_NUM_P LN_画像論理番号（画像用）
     */
    public String getLN_IMG_NUM_P() {
        return LN_IMG_NUM_P;
    }

    /**
     * LN_画像論理番号（画像用）
     * @param LN_IMG_NUM_P LN_画像論理番号（画像用）
     */
    public void setLN_IMG_NUM_P(String LN_IMG_NUM_P) {
        this.LN_IMG_NUM_P = LN_IMG_NUM_P == null ? null : LN_IMG_NUM_P.trim();
    }

    /**
     * LN_画像論理番号（音声用）
     * @return LN_IMG_NUM_V LN_画像論理番号（音声用）
     */
    public String getLN_IMG_NUM_V() {
        return LN_IMG_NUM_V;
    }

    /**
     * LN_画像論理番号（音声用）
     * @param LN_IMG_NUM_V LN_画像論理番号（音声用）
     */
    public void setLN_IMG_NUM_V(String LN_IMG_NUM_V) {
        this.LN_IMG_NUM_V = LN_IMG_NUM_V == null ? null : LN_IMG_NUM_V.trim();
    }

    /**
     * 画像取得状態
     * @return IMG_GET_STS 画像取得状態
     */
    public String getIMG_GET_STS() {
        return IMG_GET_STS;
    }

    /**
     * 画像取得状態
     * @param IMG_GET_STS 画像取得状態
     */
    public void setIMG_GET_STS(String IMG_GET_STS) {
        this.IMG_GET_STS = IMG_GET_STS == null ? null : IMG_GET_STS.trim();
    }

    /**
     * 外部情報提供フラグ
     * @return OUT_REPORT_HYOJI_FLG 外部情報提供フラグ
     */
    public String getOUT_REPORT_HYOJI_FLG() {
        return OUT_REPORT_HYOJI_FLG;
    }

    /**
     * 外部情報提供フラグ
     * @param OUT_REPORT_HYOJI_FLG 外部情報提供フラグ
     */
    public void setOUT_REPORT_HYOJI_FLG(String OUT_REPORT_HYOJI_FLG) {
        this.OUT_REPORT_HYOJI_FLG = OUT_REPORT_HYOJI_FLG == null ? null : OUT_REPORT_HYOJI_FLG.trim();
    }

    /**
     * 真報判断フラグ
     * @return SINPO_FLG 真報判断フラグ
     */
    public String getSINPO_FLG() {
        return SINPO_FLG;
    }

    /**
     * 真報判断フラグ
     * @param SINPO_FLG 真報判断フラグ
     */
    public void setSINPO_FLG(String SINPO_FLG) {
        this.SINPO_FLG = SINPO_FLG == null ? null : SINPO_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}