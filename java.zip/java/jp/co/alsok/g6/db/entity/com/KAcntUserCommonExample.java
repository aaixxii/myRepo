package jp.co.alsok.g6.db.entity.com;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class KAcntUserCommonExample {
    /**
     * K_ACNT_USER_COMMON
     */
    protected String orderByClause;

    /**
     * K_ACNT_USER_COMMON
     */
    protected boolean distinct;

    /**
     * K_ACNT_USER_COMMON
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public KAcntUserCommonExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * K_ACNT_USER_COMMON null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_ACNT_USER_COMMONIsNull() {
            addCriterion("LN_ACNT_USER_COMMON is null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNotNull() {
            addCriterion("LN_ACNT_USER_COMMON is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON =", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <>", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON >", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON >=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON <", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON not like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON not in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON not between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andACNT_IDIsNull() {
            addCriterion("ACNT_ID is null");
            return (Criteria) this;
        }

        public Criteria andACNT_IDIsNotNull() {
            addCriterion("ACNT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andACNT_IDEqualTo(String value) {
            addCriterion("ACNT_ID =", value, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDNotEqualTo(String value) {
            addCriterion("ACNT_ID <>", value, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDGreaterThan(String value) {
            addCriterion("ACNT_ID >", value, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ACNT_ID >=", value, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDLessThan(String value) {
            addCriterion("ACNT_ID <", value, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDLessThanOrEqualTo(String value) {
            addCriterion("ACNT_ID <=", value, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDLike(String value) {
            addCriterion("ACNT_ID like", value, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDNotLike(String value) {
            addCriterion("ACNT_ID not like", value, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDIn(List<String> values) {
            addCriterion("ACNT_ID in", values, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDNotIn(List<String> values) {
            addCriterion("ACNT_ID not in", values, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDBetween(String value1, String value2) {
            addCriterion("ACNT_ID between", value1, value2, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andACNT_IDNotBetween(String value1, String value2) {
            addCriterion("ACNT_ID not between", value1, value2, "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andML_ADDRIsNull() {
            addCriterion("ML_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andML_ADDRIsNotNull() {
            addCriterion("ML_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andML_ADDREqualTo(String value) {
            addCriterion("ML_ADDR =", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRNotEqualTo(String value) {
            addCriterion("ML_ADDR <>", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRGreaterThan(String value) {
            addCriterion("ML_ADDR >", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRGreaterThanOrEqualTo(String value) {
            addCriterion("ML_ADDR >=", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRLessThan(String value) {
            addCriterion("ML_ADDR <", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRLessThanOrEqualTo(String value) {
            addCriterion("ML_ADDR <=", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRLike(String value) {
            addCriterion("ML_ADDR like", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRNotLike(String value) {
            addCriterion("ML_ADDR not like", value, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRIn(List<String> values) {
            addCriterion("ML_ADDR in", values, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRNotIn(List<String> values) {
            addCriterion("ML_ADDR not in", values, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRBetween(String value1, String value2) {
            addCriterion("ML_ADDR between", value1, value2, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andML_ADDRNotBetween(String value1, String value2) {
            addCriterion("ML_ADDR not between", value1, value2, "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andPASSWDIsNull() {
            addCriterion("PASSWD is null");
            return (Criteria) this;
        }

        public Criteria andPASSWDIsNotNull() {
            addCriterion("PASSWD is not null");
            return (Criteria) this;
        }

        public Criteria andPASSWDEqualTo(String value) {
            addCriterion("PASSWD =", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDNotEqualTo(String value) {
            addCriterion("PASSWD <>", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDGreaterThan(String value) {
            addCriterion("PASSWD >", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDGreaterThanOrEqualTo(String value) {
            addCriterion("PASSWD >=", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDLessThan(String value) {
            addCriterion("PASSWD <", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDLessThanOrEqualTo(String value) {
            addCriterion("PASSWD <=", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDLike(String value) {
            addCriterion("PASSWD like", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDNotLike(String value) {
            addCriterion("PASSWD not like", value, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDIn(List<String> values) {
            addCriterion("PASSWD in", values, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDNotIn(List<String> values) {
            addCriterion("PASSWD not in", values, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDBetween(String value1, String value2) {
            addCriterion("PASSWD between", value1, value2, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andPASSWDNotBetween(String value1, String value2) {
            addCriterion("PASSWD not between", value1, value2, "PASSWD");
            return (Criteria) this;
        }

        public Criteria andACNT_NMIsNull() {
            addCriterion("ACNT_NM is null");
            return (Criteria) this;
        }

        public Criteria andACNT_NMIsNotNull() {
            addCriterion("ACNT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andACNT_NMEqualTo(String value) {
            addCriterion("ACNT_NM =", value, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMNotEqualTo(String value) {
            addCriterion("ACNT_NM <>", value, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMGreaterThan(String value) {
            addCriterion("ACNT_NM >", value, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ACNT_NM >=", value, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMLessThan(String value) {
            addCriterion("ACNT_NM <", value, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMLessThanOrEqualTo(String value) {
            addCriterion("ACNT_NM <=", value, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMLike(String value) {
            addCriterion("ACNT_NM like", value, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMNotLike(String value) {
            addCriterion("ACNT_NM not like", value, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMIn(List<String> values) {
            addCriterion("ACNT_NM in", values, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMNotIn(List<String> values) {
            addCriterion("ACNT_NM not in", values, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMBetween(String value1, String value2) {
            addCriterion("ACNT_NM between", value1, value2, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NMNotBetween(String value1, String value2) {
            addCriterion("ACNT_NM not between", value1, value2, "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANAIsNull() {
            addCriterion("ACNT_NM_KANA is null");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANAIsNotNull() {
            addCriterion("ACNT_NM_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANAEqualTo(String value) {
            addCriterion("ACNT_NM_KANA =", value, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANANotEqualTo(String value) {
            addCriterion("ACNT_NM_KANA <>", value, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANAGreaterThan(String value) {
            addCriterion("ACNT_NM_KANA >", value, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("ACNT_NM_KANA >=", value, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANALessThan(String value) {
            addCriterion("ACNT_NM_KANA <", value, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANALessThanOrEqualTo(String value) {
            addCriterion("ACNT_NM_KANA <=", value, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANALike(String value) {
            addCriterion("ACNT_NM_KANA like", value, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANANotLike(String value) {
            addCriterion("ACNT_NM_KANA not like", value, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANAIn(List<String> values) {
            addCriterion("ACNT_NM_KANA in", values, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANANotIn(List<String> values) {
            addCriterion("ACNT_NM_KANA not in", values, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANABetween(String value1, String value2) {
            addCriterion("ACNT_NM_KANA between", value1, value2, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANANotBetween(String value1, String value2) {
            addCriterion("ACNT_NM_KANA not between", value1, value2, "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDIsNull() {
            addCriterion("SYAIN_CD is null");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDIsNotNull() {
            addCriterion("SYAIN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDEqualTo(String value) {
            addCriterion("SYAIN_CD =", value, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDNotEqualTo(String value) {
            addCriterion("SYAIN_CD <>", value, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDGreaterThan(String value) {
            addCriterion("SYAIN_CD >", value, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SYAIN_CD >=", value, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDLessThan(String value) {
            addCriterion("SYAIN_CD <", value, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDLessThanOrEqualTo(String value) {
            addCriterion("SYAIN_CD <=", value, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDLike(String value) {
            addCriterion("SYAIN_CD like", value, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDNotLike(String value) {
            addCriterion("SYAIN_CD not like", value, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDIn(List<String> values) {
            addCriterion("SYAIN_CD in", values, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDNotIn(List<String> values) {
            addCriterion("SYAIN_CD not in", values, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDBetween(String value1, String value2) {
            addCriterion("SYAIN_CD between", value1, value2, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDNotBetween(String value1, String value2) {
            addCriterion("SYAIN_CD not between", value1, value2, "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMIsNull() {
            addCriterion("BUSYO_NM is null");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMIsNotNull() {
            addCriterion("BUSYO_NM is not null");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMEqualTo(String value) {
            addCriterion("BUSYO_NM =", value, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMNotEqualTo(String value) {
            addCriterion("BUSYO_NM <>", value, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMGreaterThan(String value) {
            addCriterion("BUSYO_NM >", value, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMGreaterThanOrEqualTo(String value) {
            addCriterion("BUSYO_NM >=", value, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMLessThan(String value) {
            addCriterion("BUSYO_NM <", value, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMLessThanOrEqualTo(String value) {
            addCriterion("BUSYO_NM <=", value, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMLike(String value) {
            addCriterion("BUSYO_NM like", value, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMNotLike(String value) {
            addCriterion("BUSYO_NM not like", value, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMIn(List<String> values) {
            addCriterion("BUSYO_NM in", values, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMNotIn(List<String> values) {
            addCriterion("BUSYO_NM not in", values, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMBetween(String value1, String value2) {
            addCriterion("BUSYO_NM between", value1, value2, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMNotBetween(String value1, String value2) {
            addCriterion("BUSYO_NM not between", value1, value2, "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANAIsNull() {
            addCriterion("BUSYO_NM_KANA is null");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANAIsNotNull() {
            addCriterion("BUSYO_NM_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANAEqualTo(String value) {
            addCriterion("BUSYO_NM_KANA =", value, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANANotEqualTo(String value) {
            addCriterion("BUSYO_NM_KANA <>", value, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANAGreaterThan(String value) {
            addCriterion("BUSYO_NM_KANA >", value, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("BUSYO_NM_KANA >=", value, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANALessThan(String value) {
            addCriterion("BUSYO_NM_KANA <", value, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANALessThanOrEqualTo(String value) {
            addCriterion("BUSYO_NM_KANA <=", value, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANALike(String value) {
            addCriterion("BUSYO_NM_KANA like", value, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANANotLike(String value) {
            addCriterion("BUSYO_NM_KANA not like", value, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANAIn(List<String> values) {
            addCriterion("BUSYO_NM_KANA in", values, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANANotIn(List<String> values) {
            addCriterion("BUSYO_NM_KANA not in", values, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANABetween(String value1, String value2) {
            addCriterion("BUSYO_NM_KANA between", value1, value2, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANANotBetween(String value1, String value2) {
            addCriterion("BUSYO_NM_KANA not between", value1, value2, "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMIsNull() {
            addCriterion("YAKUSYOKU_NM is null");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMIsNotNull() {
            addCriterion("YAKUSYOKU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMEqualTo(String value) {
            addCriterion("YAKUSYOKU_NM =", value, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMNotEqualTo(String value) {
            addCriterion("YAKUSYOKU_NM <>", value, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMGreaterThan(String value) {
            addCriterion("YAKUSYOKU_NM >", value, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("YAKUSYOKU_NM >=", value, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMLessThan(String value) {
            addCriterion("YAKUSYOKU_NM <", value, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMLessThanOrEqualTo(String value) {
            addCriterion("YAKUSYOKU_NM <=", value, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMLike(String value) {
            addCriterion("YAKUSYOKU_NM like", value, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMNotLike(String value) {
            addCriterion("YAKUSYOKU_NM not like", value, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMIn(List<String> values) {
            addCriterion("YAKUSYOKU_NM in", values, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMNotIn(List<String> values) {
            addCriterion("YAKUSYOKU_NM not in", values, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMBetween(String value1, String value2) {
            addCriterion("YAKUSYOKU_NM between", value1, value2, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMNotBetween(String value1, String value2) {
            addCriterion("YAKUSYOKU_NM not between", value1, value2, "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANAIsNull() {
            addCriterion("YAKUSYOKU_KANA is null");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANAIsNotNull() {
            addCriterion("YAKUSYOKU_KANA is not null");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANAEqualTo(String value) {
            addCriterion("YAKUSYOKU_KANA =", value, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANANotEqualTo(String value) {
            addCriterion("YAKUSYOKU_KANA <>", value, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANAGreaterThan(String value) {
            addCriterion("YAKUSYOKU_KANA >", value, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANAGreaterThanOrEqualTo(String value) {
            addCriterion("YAKUSYOKU_KANA >=", value, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANALessThan(String value) {
            addCriterion("YAKUSYOKU_KANA <", value, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANALessThanOrEqualTo(String value) {
            addCriterion("YAKUSYOKU_KANA <=", value, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANALike(String value) {
            addCriterion("YAKUSYOKU_KANA like", value, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANANotLike(String value) {
            addCriterion("YAKUSYOKU_KANA not like", value, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANAIn(List<String> values) {
            addCriterion("YAKUSYOKU_KANA in", values, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANANotIn(List<String> values) {
            addCriterion("YAKUSYOKU_KANA not in", values, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANABetween(String value1, String value2) {
            addCriterion("YAKUSYOKU_KANA between", value1, value2, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANANotBetween(String value1, String value2) {
            addCriterion("YAKUSYOKU_KANA not between", value1, value2, "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNIsNull() {
            addCriterion("ACNT_USER_KBN is null");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNIsNotNull() {
            addCriterion("ACNT_USER_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNEqualTo(String value) {
            addCriterion("ACNT_USER_KBN =", value, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNNotEqualTo(String value) {
            addCriterion("ACNT_USER_KBN <>", value, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNGreaterThan(String value) {
            addCriterion("ACNT_USER_KBN >", value, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("ACNT_USER_KBN >=", value, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNLessThan(String value) {
            addCriterion("ACNT_USER_KBN <", value, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNLessThanOrEqualTo(String value) {
            addCriterion("ACNT_USER_KBN <=", value, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNLike(String value) {
            addCriterion("ACNT_USER_KBN like", value, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNNotLike(String value) {
            addCriterion("ACNT_USER_KBN not like", value, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNIn(List<String> values) {
            addCriterion("ACNT_USER_KBN in", values, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNNotIn(List<String> values) {
            addCriterion("ACNT_USER_KBN not in", values, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNBetween(String value1, String value2) {
            addCriterion("ACNT_USER_KBN between", value1, value2, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNNotBetween(String value1, String value2) {
            addCriterion("ACNT_USER_KBN not between", value1, value2, "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1IsNull() {
            addCriterion("TEL_NUM_1 is null");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1IsNotNull() {
            addCriterion("TEL_NUM_1 is not null");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1EqualTo(String value) {
            addCriterion("TEL_NUM_1 =", value, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1NotEqualTo(String value) {
            addCriterion("TEL_NUM_1 <>", value, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1GreaterThan(String value) {
            addCriterion("TEL_NUM_1 >", value, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1GreaterThanOrEqualTo(String value) {
            addCriterion("TEL_NUM_1 >=", value, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1LessThan(String value) {
            addCriterion("TEL_NUM_1 <", value, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1LessThanOrEqualTo(String value) {
            addCriterion("TEL_NUM_1 <=", value, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1Like(String value) {
            addCriterion("TEL_NUM_1 like", value, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1NotLike(String value) {
            addCriterion("TEL_NUM_1 not like", value, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1In(List<String> values) {
            addCriterion("TEL_NUM_1 in", values, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1NotIn(List<String> values) {
            addCriterion("TEL_NUM_1 not in", values, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1Between(String value1, String value2) {
            addCriterion("TEL_NUM_1 between", value1, value2, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1NotBetween(String value1, String value2) {
            addCriterion("TEL_NUM_1 not between", value1, value2, "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2IsNull() {
            addCriterion("TEL_NUM_2 is null");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2IsNotNull() {
            addCriterion("TEL_NUM_2 is not null");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2EqualTo(String value) {
            addCriterion("TEL_NUM_2 =", value, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2NotEqualTo(String value) {
            addCriterion("TEL_NUM_2 <>", value, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2GreaterThan(String value) {
            addCriterion("TEL_NUM_2 >", value, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2GreaterThanOrEqualTo(String value) {
            addCriterion("TEL_NUM_2 >=", value, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2LessThan(String value) {
            addCriterion("TEL_NUM_2 <", value, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2LessThanOrEqualTo(String value) {
            addCriterion("TEL_NUM_2 <=", value, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2Like(String value) {
            addCriterion("TEL_NUM_2 like", value, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2NotLike(String value) {
            addCriterion("TEL_NUM_2 not like", value, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2In(List<String> values) {
            addCriterion("TEL_NUM_2 in", values, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2NotIn(List<String> values) {
            addCriterion("TEL_NUM_2 not in", values, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2Between(String value1, String value2) {
            addCriterion("TEL_NUM_2 between", value1, value2, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2NotBetween(String value1, String value2) {
            addCriterion("TEL_NUM_2 not between", value1, value2, "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASEIsNull() {
            addCriterion("JIGYOU_TOIAWASE is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASEIsNotNull() {
            addCriterion("JIGYOU_TOIAWASE is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASEEqualTo(String value) {
            addCriterion("JIGYOU_TOIAWASE =", value, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASENotEqualTo(String value) {
            addCriterion("JIGYOU_TOIAWASE <>", value, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASEGreaterThan(String value) {
            addCriterion("JIGYOU_TOIAWASE >", value, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASEGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOU_TOIAWASE >=", value, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASELessThan(String value) {
            addCriterion("JIGYOU_TOIAWASE <", value, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASELessThanOrEqualTo(String value) {
            addCriterion("JIGYOU_TOIAWASE <=", value, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASELike(String value) {
            addCriterion("JIGYOU_TOIAWASE like", value, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASENotLike(String value) {
            addCriterion("JIGYOU_TOIAWASE not like", value, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASEIn(List<String> values) {
            addCriterion("JIGYOU_TOIAWASE in", values, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASENotIn(List<String> values) {
            addCriterion("JIGYOU_TOIAWASE not in", values, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASEBetween(String value1, String value2) {
            addCriterion("JIGYOU_TOIAWASE between", value1, value2, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASENotBetween(String value1, String value2) {
            addCriterion("JIGYOU_TOIAWASE not between", value1, value2, "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASEIsNull() {
            addCriterion("TEL_NUM_TOIAWASE is null");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASEIsNotNull() {
            addCriterion("TEL_NUM_TOIAWASE is not null");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASEEqualTo(String value) {
            addCriterion("TEL_NUM_TOIAWASE =", value, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASENotEqualTo(String value) {
            addCriterion("TEL_NUM_TOIAWASE <>", value, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASEGreaterThan(String value) {
            addCriterion("TEL_NUM_TOIAWASE >", value, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASEGreaterThanOrEqualTo(String value) {
            addCriterion("TEL_NUM_TOIAWASE >=", value, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASELessThan(String value) {
            addCriterion("TEL_NUM_TOIAWASE <", value, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASELessThanOrEqualTo(String value) {
            addCriterion("TEL_NUM_TOIAWASE <=", value, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASELike(String value) {
            addCriterion("TEL_NUM_TOIAWASE like", value, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASENotLike(String value) {
            addCriterion("TEL_NUM_TOIAWASE not like", value, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASEIn(List<String> values) {
            addCriterion("TEL_NUM_TOIAWASE in", values, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASENotIn(List<String> values) {
            addCriterion("TEL_NUM_TOIAWASE not in", values, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASEBetween(String value1, String value2) {
            addCriterion("TEL_NUM_TOIAWASE between", value1, value2, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASENotBetween(String value1, String value2) {
            addCriterion("TEL_NUM_TOIAWASE not between", value1, value2, "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1IsNull() {
            addCriterion("QUESTION_1 is null");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1IsNotNull() {
            addCriterion("QUESTION_1 is not null");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1EqualTo(String value) {
            addCriterion("QUESTION_1 =", value, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1NotEqualTo(String value) {
            addCriterion("QUESTION_1 <>", value, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1GreaterThan(String value) {
            addCriterion("QUESTION_1 >", value, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1GreaterThanOrEqualTo(String value) {
            addCriterion("QUESTION_1 >=", value, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1LessThan(String value) {
            addCriterion("QUESTION_1 <", value, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1LessThanOrEqualTo(String value) {
            addCriterion("QUESTION_1 <=", value, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1Like(String value) {
            addCriterion("QUESTION_1 like", value, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1NotLike(String value) {
            addCriterion("QUESTION_1 not like", value, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1In(List<String> values) {
            addCriterion("QUESTION_1 in", values, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1NotIn(List<String> values) {
            addCriterion("QUESTION_1 not in", values, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1Between(String value1, String value2) {
            addCriterion("QUESTION_1 between", value1, value2, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1NotBetween(String value1, String value2) {
            addCriterion("QUESTION_1 not between", value1, value2, "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1IsNull() {
            addCriterion("ANSWER_1 is null");
            return (Criteria) this;
        }

        public Criteria andANSWER_1IsNotNull() {
            addCriterion("ANSWER_1 is not null");
            return (Criteria) this;
        }

        public Criteria andANSWER_1EqualTo(String value) {
            addCriterion("ANSWER_1 =", value, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1NotEqualTo(String value) {
            addCriterion("ANSWER_1 <>", value, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1GreaterThan(String value) {
            addCriterion("ANSWER_1 >", value, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1GreaterThanOrEqualTo(String value) {
            addCriterion("ANSWER_1 >=", value, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1LessThan(String value) {
            addCriterion("ANSWER_1 <", value, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1LessThanOrEqualTo(String value) {
            addCriterion("ANSWER_1 <=", value, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1Like(String value) {
            addCriterion("ANSWER_1 like", value, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1NotLike(String value) {
            addCriterion("ANSWER_1 not like", value, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1In(List<String> values) {
            addCriterion("ANSWER_1 in", values, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1NotIn(List<String> values) {
            addCriterion("ANSWER_1 not in", values, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1Between(String value1, String value2) {
            addCriterion("ANSWER_1 between", value1, value2, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1NotBetween(String value1, String value2) {
            addCriterion("ANSWER_1 not between", value1, value2, "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2IsNull() {
            addCriterion("QUESTION_2 is null");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2IsNotNull() {
            addCriterion("QUESTION_2 is not null");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2EqualTo(String value) {
            addCriterion("QUESTION_2 =", value, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2NotEqualTo(String value) {
            addCriterion("QUESTION_2 <>", value, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2GreaterThan(String value) {
            addCriterion("QUESTION_2 >", value, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2GreaterThanOrEqualTo(String value) {
            addCriterion("QUESTION_2 >=", value, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2LessThan(String value) {
            addCriterion("QUESTION_2 <", value, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2LessThanOrEqualTo(String value) {
            addCriterion("QUESTION_2 <=", value, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2Like(String value) {
            addCriterion("QUESTION_2 like", value, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2NotLike(String value) {
            addCriterion("QUESTION_2 not like", value, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2In(List<String> values) {
            addCriterion("QUESTION_2 in", values, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2NotIn(List<String> values) {
            addCriterion("QUESTION_2 not in", values, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2Between(String value1, String value2) {
            addCriterion("QUESTION_2 between", value1, value2, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2NotBetween(String value1, String value2) {
            addCriterion("QUESTION_2 not between", value1, value2, "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2IsNull() {
            addCriterion("ANSWER_2 is null");
            return (Criteria) this;
        }

        public Criteria andANSWER_2IsNotNull() {
            addCriterion("ANSWER_2 is not null");
            return (Criteria) this;
        }

        public Criteria andANSWER_2EqualTo(String value) {
            addCriterion("ANSWER_2 =", value, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2NotEqualTo(String value) {
            addCriterion("ANSWER_2 <>", value, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2GreaterThan(String value) {
            addCriterion("ANSWER_2 >", value, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2GreaterThanOrEqualTo(String value) {
            addCriterion("ANSWER_2 >=", value, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2LessThan(String value) {
            addCriterion("ANSWER_2 <", value, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2LessThanOrEqualTo(String value) {
            addCriterion("ANSWER_2 <=", value, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2Like(String value) {
            addCriterion("ANSWER_2 like", value, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2NotLike(String value) {
            addCriterion("ANSWER_2 not like", value, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2In(List<String> values) {
            addCriterion("ANSWER_2 in", values, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2NotIn(List<String> values) {
            addCriterion("ANSWER_2 not in", values, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2Between(String value1, String value2) {
            addCriterion("ANSWER_2 between", value1, value2, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2NotBetween(String value1, String value2) {
            addCriterion("ANSWER_2 not between", value1, value2, "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3IsNull() {
            addCriterion("QUESTION_3 is null");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3IsNotNull() {
            addCriterion("QUESTION_3 is not null");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3EqualTo(String value) {
            addCriterion("QUESTION_3 =", value, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3NotEqualTo(String value) {
            addCriterion("QUESTION_3 <>", value, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3GreaterThan(String value) {
            addCriterion("QUESTION_3 >", value, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3GreaterThanOrEqualTo(String value) {
            addCriterion("QUESTION_3 >=", value, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3LessThan(String value) {
            addCriterion("QUESTION_3 <", value, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3LessThanOrEqualTo(String value) {
            addCriterion("QUESTION_3 <=", value, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3Like(String value) {
            addCriterion("QUESTION_3 like", value, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3NotLike(String value) {
            addCriterion("QUESTION_3 not like", value, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3In(List<String> values) {
            addCriterion("QUESTION_3 in", values, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3NotIn(List<String> values) {
            addCriterion("QUESTION_3 not in", values, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3Between(String value1, String value2) {
            addCriterion("QUESTION_3 between", value1, value2, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3NotBetween(String value1, String value2) {
            addCriterion("QUESTION_3 not between", value1, value2, "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3IsNull() {
            addCriterion("ANSWER_3 is null");
            return (Criteria) this;
        }

        public Criteria andANSWER_3IsNotNull() {
            addCriterion("ANSWER_3 is not null");
            return (Criteria) this;
        }

        public Criteria andANSWER_3EqualTo(String value) {
            addCriterion("ANSWER_3 =", value, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3NotEqualTo(String value) {
            addCriterion("ANSWER_3 <>", value, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3GreaterThan(String value) {
            addCriterion("ANSWER_3 >", value, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3GreaterThanOrEqualTo(String value) {
            addCriterion("ANSWER_3 >=", value, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3LessThan(String value) {
            addCriterion("ANSWER_3 <", value, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3LessThanOrEqualTo(String value) {
            addCriterion("ANSWER_3 <=", value, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3Like(String value) {
            addCriterion("ANSWER_3 like", value, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3NotLike(String value) {
            addCriterion("ANSWER_3 not like", value, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3In(List<String> values) {
            addCriterion("ANSWER_3 in", values, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3NotIn(List<String> values) {
            addCriterion("ANSWER_3 not in", values, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3Between(String value1, String value2) {
            addCriterion("ANSWER_3 between", value1, value2, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3NotBetween(String value1, String value2) {
            addCriterion("ANSWER_3 not between", value1, value2, "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLikeInsensitive(String value) {
            addCriterion("upper(LN_ACNT_USER_COMMON) like", value.toUpperCase(), "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andACNT_IDLikeInsensitive(String value) {
            addCriterion("upper(ACNT_ID) like", value.toUpperCase(), "ACNT_ID");
            return (Criteria) this;
        }

        public Criteria andML_ADDRLikeInsensitive(String value) {
            addCriterion("upper(ML_ADDR) like", value.toUpperCase(), "ML_ADDR");
            return (Criteria) this;
        }

        public Criteria andPASSWDLikeInsensitive(String value) {
            addCriterion("upper(PASSWD) like", value.toUpperCase(), "PASSWD");
            return (Criteria) this;
        }

        public Criteria andACNT_NMLikeInsensitive(String value) {
            addCriterion("upper(ACNT_NM) like", value.toUpperCase(), "ACNT_NM");
            return (Criteria) this;
        }

        public Criteria andACNT_NM_KANALikeInsensitive(String value) {
            addCriterion("upper(ACNT_NM_KANA) like", value.toUpperCase(), "ACNT_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andSYAIN_CDLikeInsensitive(String value) {
            addCriterion("upper(SYAIN_CD) like", value.toUpperCase(), "SYAIN_CD");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NMLikeInsensitive(String value) {
            addCriterion("upper(BUSYO_NM) like", value.toUpperCase(), "BUSYO_NM");
            return (Criteria) this;
        }

        public Criteria andBUSYO_NM_KANALikeInsensitive(String value) {
            addCriterion("upper(BUSYO_NM_KANA) like", value.toUpperCase(), "BUSYO_NM_KANA");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_NMLikeInsensitive(String value) {
            addCriterion("upper(YAKUSYOKU_NM) like", value.toUpperCase(), "YAKUSYOKU_NM");
            return (Criteria) this;
        }

        public Criteria andYAKUSYOKU_KANALikeInsensitive(String value) {
            addCriterion("upper(YAKUSYOKU_KANA) like", value.toUpperCase(), "YAKUSYOKU_KANA");
            return (Criteria) this;
        }

        public Criteria andACNT_USER_KBNLikeInsensitive(String value) {
            addCriterion("upper(ACNT_USER_KBN) like", value.toUpperCase(), "ACNT_USER_KBN");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_1LikeInsensitive(String value) {
            addCriterion("upper(TEL_NUM_1) like", value.toUpperCase(), "TEL_NUM_1");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_2LikeInsensitive(String value) {
            addCriterion("upper(TEL_NUM_2) like", value.toUpperCase(), "TEL_NUM_2");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_TOIAWASELikeInsensitive(String value) {
            addCriterion("upper(JIGYOU_TOIAWASE) like", value.toUpperCase(), "JIGYOU_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andTEL_NUM_TOIAWASELikeInsensitive(String value) {
            addCriterion("upper(TEL_NUM_TOIAWASE) like", value.toUpperCase(), "TEL_NUM_TOIAWASE");
            return (Criteria) this;
        }

        public Criteria andQUESTION_1LikeInsensitive(String value) {
            addCriterion("upper(QUESTION_1) like", value.toUpperCase(), "QUESTION_1");
            return (Criteria) this;
        }

        public Criteria andANSWER_1LikeInsensitive(String value) {
            addCriterion("upper(ANSWER_1) like", value.toUpperCase(), "ANSWER_1");
            return (Criteria) this;
        }

        public Criteria andQUESTION_2LikeInsensitive(String value) {
            addCriterion("upper(QUESTION_2) like", value.toUpperCase(), "QUESTION_2");
            return (Criteria) this;
        }

        public Criteria andANSWER_2LikeInsensitive(String value) {
            addCriterion("upper(ANSWER_2) like", value.toUpperCase(), "ANSWER_2");
            return (Criteria) this;
        }

        public Criteria andQUESTION_3LikeInsensitive(String value) {
            addCriterion("upper(QUESTION_3) like", value.toUpperCase(), "QUESTION_3");
            return (Criteria) this;
        }

        public Criteria andANSWER_3LikeInsensitive(String value) {
            addCriterion("upper(ANSWER_3) like", value.toUpperCase(), "ANSWER_3");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * K_ACNT_USER_COMMON
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * K_ACNT_USER_COMMON null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}