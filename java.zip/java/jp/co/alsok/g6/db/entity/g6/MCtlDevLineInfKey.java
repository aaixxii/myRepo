package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MCtlDevLineInfKey implements Serializable {
    /**
     * LN_制御装置論理番号
     */
    private String LN_CTL_DEV;

    /**
     * 回線フラグ
     */
    private String LINE_FLG;

    /**
     * M_CTL_DEV_LINE_INF
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_制御装置論理番号
     * @return LN_CTL_DEV LN_制御装置論理番号
     */
    public String getLN_CTL_DEV() {
        return LN_CTL_DEV;
    }

    /**
     * LN_制御装置論理番号
     * @param LN_CTL_DEV LN_制御装置論理番号
     */
    public void setLN_CTL_DEV(String LN_CTL_DEV) {
        this.LN_CTL_DEV = LN_CTL_DEV == null ? null : LN_CTL_DEV.trim();
    }

    /**
     * 回線フラグ
     * @return LINE_FLG 回線フラグ
     */
    public String getLINE_FLG() {
        return LINE_FLG;
    }

    /**
     * 回線フラグ
     * @param LINE_FLG 回線フラグ
     */
    public void setLINE_FLG(String LINE_FLG) {
        this.LINE_FLG = LINE_FLG == null ? null : LINE_FLG.trim();
    }
}