package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CQueSendSms implements Serializable {
    /**
     * LN_SMS配信論理番号
     */
    private String LN_QUE_SEND_SMS;

    /**
     * LN_SMS配信トリガ論理番号
     */
    private String LN_QUE_SMS_TRIG;

    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * 種別
     */
    private String KIND;

    /**
     * 状態
     */
    private String STS;

    /**
     * 優先度
     */
    private String PRIORITY;

    /**
     * リトライ回数
     */
    private String RETRY_NUM;

    /**
     * 差出人名称
     */
    private String FROM_NM;

    /**
     * 差出人アドレス
     */
    private String ADDR_FROM;

    /**
     * 宛先アドレス
     */
    private String ADDR_TO;

    /**
     * タイトル
     */
    private String TITLE;

    /**
     * 送信可能日時
     */
    private Date SEND_ABL_TS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * 本文1
     */
    private String BODY1;

    /**
     * C_QUE_SEND_SMS
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_SMS配信論理番号
     * @return LN_QUE_SEND_SMS LN_SMS配信論理番号
     */
    public String getLN_QUE_SEND_SMS() {
        return LN_QUE_SEND_SMS;
    }

    /**
     * LN_SMS配信論理番号
     * @param LN_QUE_SEND_SMS LN_SMS配信論理番号
     */
    public void setLN_QUE_SEND_SMS(String LN_QUE_SEND_SMS) {
        this.LN_QUE_SEND_SMS = LN_QUE_SEND_SMS == null ? null : LN_QUE_SEND_SMS.trim();
    }

    /**
     * LN_SMS配信トリガ論理番号
     * @return LN_QUE_SMS_TRIG LN_SMS配信トリガ論理番号
     */
    public String getLN_QUE_SMS_TRIG() {
        return LN_QUE_SMS_TRIG;
    }

    /**
     * LN_SMS配信トリガ論理番号
     * @param LN_QUE_SMS_TRIG LN_SMS配信トリガ論理番号
     */
    public void setLN_QUE_SMS_TRIG(String LN_QUE_SMS_TRIG) {
        this.LN_QUE_SMS_TRIG = LN_QUE_SMS_TRIG == null ? null : LN_QUE_SMS_TRIG.trim();
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * 種別
     * @return KIND 種別
     */
    public String getKIND() {
        return KIND;
    }

    /**
     * 種別
     * @param KIND 種別
     */
    public void setKIND(String KIND) {
        this.KIND = KIND == null ? null : KIND.trim();
    }

    /**
     * 状態
     * @return STS 状態
     */
    public String getSTS() {
        return STS;
    }

    /**
     * 状態
     * @param STS 状態
     */
    public void setSTS(String STS) {
        this.STS = STS == null ? null : STS.trim();
    }

    /**
     * 優先度
     * @return PRIORITY 優先度
     */
    public String getPRIORITY() {
        return PRIORITY;
    }

    /**
     * 優先度
     * @param PRIORITY 優先度
     */
    public void setPRIORITY(String PRIORITY) {
        this.PRIORITY = PRIORITY == null ? null : PRIORITY.trim();
    }

    /**
     * リトライ回数
     * @return RETRY_NUM リトライ回数
     */
    public String getRETRY_NUM() {
        return RETRY_NUM;
    }

    /**
     * リトライ回数
     * @param RETRY_NUM リトライ回数
     */
    public void setRETRY_NUM(String RETRY_NUM) {
        this.RETRY_NUM = RETRY_NUM == null ? null : RETRY_NUM.trim();
    }

    /**
     * 差出人名称
     * @return FROM_NM 差出人名称
     */
    public String getFROM_NM() {
        return FROM_NM;
    }

    /**
     * 差出人名称
     * @param FROM_NM 差出人名称
     */
    public void setFROM_NM(String FROM_NM) {
        this.FROM_NM = FROM_NM == null ? null : FROM_NM.trim();
    }

    /**
     * 差出人アドレス
     * @return ADDR_FROM 差出人アドレス
     */
    public String getADDR_FROM() {
        return ADDR_FROM;
    }

    /**
     * 差出人アドレス
     * @param ADDR_FROM 差出人アドレス
     */
    public void setADDR_FROM(String ADDR_FROM) {
        this.ADDR_FROM = ADDR_FROM == null ? null : ADDR_FROM.trim();
    }

    /**
     * 宛先アドレス
     * @return ADDR_TO 宛先アドレス
     */
    public String getADDR_TO() {
        return ADDR_TO;
    }

    /**
     * 宛先アドレス
     * @param ADDR_TO 宛先アドレス
     */
    public void setADDR_TO(String ADDR_TO) {
        this.ADDR_TO = ADDR_TO == null ? null : ADDR_TO.trim();
    }

    /**
     * タイトル
     * @return TITLE タイトル
     */
    public String getTITLE() {
        return TITLE;
    }

    /**
     * タイトル
     * @param TITLE タイトル
     */
    public void setTITLE(String TITLE) {
        this.TITLE = TITLE == null ? null : TITLE.trim();
    }

    /**
     * 送信可能日時
     * @return SEND_ABL_TS 送信可能日時
     */
    public Date getSEND_ABL_TS() {
        return SEND_ABL_TS;
    }

    /**
     * 送信可能日時
     * @param SEND_ABL_TS 送信可能日時
     */
    public void setSEND_ABL_TS(Date SEND_ABL_TS) {
        this.SEND_ABL_TS = SEND_ABL_TS;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * 本文1
     * @return BODY1 本文1
     */
    public String getBODY1() {
        return BODY1;
    }

    /**
     * 本文1
     * @param BODY1 本文1
     */
    public void setBODY1(String BODY1) {
        this.BODY1 = BODY1 == null ? null : BODY1.trim();
    }
}