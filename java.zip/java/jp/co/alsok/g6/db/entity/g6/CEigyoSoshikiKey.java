package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CEigyoSoshikiKey implements Serializable {
    /**
     * 会社コード
     */
    private String KAISHA_CD;

    /**
     * 組織コード
     */
    private String SOSHIKI_CD;

    /**
     * C_EIGYO_SOSHIKI
     */
    private static final long serialVersionUID = 1L;

    /**
     * 会社コード
     * @return KAISHA_CD 会社コード
     */
    public String getKAISHA_CD() {
        return KAISHA_CD;
    }

    /**
     * 会社コード
     * @param KAISHA_CD 会社コード
     */
    public void setKAISHA_CD(String KAISHA_CD) {
        this.KAISHA_CD = KAISHA_CD == null ? null : KAISHA_CD.trim();
    }

    /**
     * 組織コード
     * @return SOSHIKI_CD 組織コード
     */
    public String getSOSHIKI_CD() {
        return SOSHIKI_CD;
    }

    /**
     * 組織コード
     * @param SOSHIKI_CD 組織コード
     */
    public void setSOSHIKI_CD(String SOSHIKI_CD) {
        this.SOSHIKI_CD = SOSHIKI_CD == null ? null : SOSHIKI_CD.trim();
    }
}