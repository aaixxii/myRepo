package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class IOpeAuthMng implements Serializable {
    /**
     * LN_操作権限管理論理番号
     */
    private String LN_OPE_AUTH_MNG;

    /**
     * LN_設置機器論理番号(親)
     */
    private String LN_DEV_PAR;

    /**
     * LN_ALSOKアカウント論理番号
     */
    private String LN_ACNT_ALSOK;

    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * I_OPE_AUTH_MNG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_操作権限管理論理番号
     * @return LN_OPE_AUTH_MNG LN_操作権限管理論理番号
     */
    public String getLN_OPE_AUTH_MNG() {
        return LN_OPE_AUTH_MNG;
    }

    /**
     * LN_操作権限管理論理番号
     * @param LN_OPE_AUTH_MNG LN_操作権限管理論理番号
     */
    public void setLN_OPE_AUTH_MNG(String LN_OPE_AUTH_MNG) {
        this.LN_OPE_AUTH_MNG = LN_OPE_AUTH_MNG == null ? null : LN_OPE_AUTH_MNG.trim();
    }

    /**
     * LN_設置機器論理番号(親)
     * @return LN_DEV_PAR LN_設置機器論理番号(親)
     */
    public String getLN_DEV_PAR() {
        return LN_DEV_PAR;
    }

    /**
     * LN_設置機器論理番号(親)
     * @param LN_DEV_PAR LN_設置機器論理番号(親)
     */
    public void setLN_DEV_PAR(String LN_DEV_PAR) {
        this.LN_DEV_PAR = LN_DEV_PAR == null ? null : LN_DEV_PAR.trim();
    }

    /**
     * LN_ALSOKアカウント論理番号
     * @return LN_ACNT_ALSOK LN_ALSOKアカウント論理番号
     */
    public String getLN_ACNT_ALSOK() {
        return LN_ACNT_ALSOK;
    }

    /**
     * LN_ALSOKアカウント論理番号
     * @param LN_ACNT_ALSOK LN_ALSOKアカウント論理番号
     */
    public void setLN_ACNT_ALSOK(String LN_ACNT_ALSOK) {
        this.LN_ACNT_ALSOK = LN_ACNT_ALSOK == null ? null : LN_ACNT_ALSOK.trim();
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}