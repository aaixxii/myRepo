package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CStanDrawKey implements Serializable {
    /**
     * ファイル送信識別キー
     */
    private String RENKEI_FILE_SHKBTS_KEY;

    /**
     * ファイル送信識別連番
     */
    private String RENKEI_FILE_SHKBTS_SN;

    /**
     * C_STAN_DRAW
     */
    private static final long serialVersionUID = 1L;

    /**
     * ファイル送信識別キー
     * @return RENKEI_FILE_SHKBTS_KEY ファイル送信識別キー
     */
    public String getRENKEI_FILE_SHKBTS_KEY() {
        return RENKEI_FILE_SHKBTS_KEY;
    }

    /**
     * ファイル送信識別キー
     * @param RENKEI_FILE_SHKBTS_KEY ファイル送信識別キー
     */
    public void setRENKEI_FILE_SHKBTS_KEY(String RENKEI_FILE_SHKBTS_KEY) {
        this.RENKEI_FILE_SHKBTS_KEY = RENKEI_FILE_SHKBTS_KEY == null ? null : RENKEI_FILE_SHKBTS_KEY.trim();
    }

    /**
     * ファイル送信識別連番
     * @return RENKEI_FILE_SHKBTS_SN ファイル送信識別連番
     */
    public String getRENKEI_FILE_SHKBTS_SN() {
        return RENKEI_FILE_SHKBTS_SN;
    }

    /**
     * ファイル送信識別連番
     * @param RENKEI_FILE_SHKBTS_SN ファイル送信識別連番
     */
    public void setRENKEI_FILE_SHKBTS_SN(String RENKEI_FILE_SHKBTS_SN) {
        this.RENKEI_FILE_SHKBTS_SN = RENKEI_FILE_SHKBTS_SN == null ? null : RENKEI_FILE_SHKBTS_SN.trim();
    }
}