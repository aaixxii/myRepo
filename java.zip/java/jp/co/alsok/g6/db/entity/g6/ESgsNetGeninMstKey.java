package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class ESgsNetGeninMstKey implements Serializable {
    /**
     * SGS原因コード
     */
    private String SGS_GENIN_CD;

    /**
     * NET原因コード
     */
    private String NET_GENIN_CD;

    /**
     * E_SGS_NET_GENIN_MST
     */
    private static final long serialVersionUID = 1L;

    /**
     * SGS原因コード
     * @return SGS_GENIN_CD SGS原因コード
     */
    public String getSGS_GENIN_CD() {
        return SGS_GENIN_CD;
    }

    /**
     * SGS原因コード
     * @param SGS_GENIN_CD SGS原因コード
     */
    public void setSGS_GENIN_CD(String SGS_GENIN_CD) {
        this.SGS_GENIN_CD = SGS_GENIN_CD == null ? null : SGS_GENIN_CD.trim();
    }

    /**
     * NET原因コード
     * @return NET_GENIN_CD NET原因コード
     */
    public String getNET_GENIN_CD() {
        return NET_GENIN_CD;
    }

    /**
     * NET原因コード
     * @param NET_GENIN_CD NET原因コード
     */
    public void setNET_GENIN_CD(String NET_GENIN_CD) {
        this.NET_GENIN_CD = NET_GENIN_CD == null ? null : NET_GENIN_CD.trim();
    }
}