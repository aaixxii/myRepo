package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KGc implements Serializable {
    /**
     * GCコード
     */
    private String GC_CD;

    /**
     * GC名称
     */
    private String GC_NM;

    /**
     * GC電話番号
     */
    private String GC_TEL_NUM;

    /**
     * 上位GCコード
     */
    private String UPPER_GC_CD;

    /**
     * 同期有効フラグ
     */
    private String SYNC_ABL_FLG;

    /**
     * IPアドレス
     */
    private String IP_ADDR;

    /**
     * 業務コード
     */
    private String GYOUMU_CD;

    /**
     * DB名称
     */
    private String DB_NM;

    /**
     * DBユーザー
     */
    private String DB_USER;

    /**
     * DBパスワード
     */
    private String DB_PASSWD;

    /**
     * GCTバージョン
     */
    private String GCT_VER;

    /**
     * 最大接続数
     */
    private String MAX_ACTIVE;

    /**
     * 保持最大数
     */
    private String MAX_IDLE;

    /**
     * 最大待機時間
     */
    private String MAX_WAIT_TM;

    /**
     * SD連携フラグ
     */
    private String SD_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_GC
     */
    private static final long serialVersionUID = 1L;

    /**
     * GCコード
     * @return GC_CD GCコード
     */
    public String getGC_CD() {
        return GC_CD;
    }

    /**
     * GCコード
     * @param GC_CD GCコード
     */
    public void setGC_CD(String GC_CD) {
        this.GC_CD = GC_CD == null ? null : GC_CD.trim();
    }

    /**
     * GC名称
     * @return GC_NM GC名称
     */
    public String getGC_NM() {
        return GC_NM;
    }

    /**
     * GC名称
     * @param GC_NM GC名称
     */
    public void setGC_NM(String GC_NM) {
        this.GC_NM = GC_NM == null ? null : GC_NM.trim();
    }

    /**
     * GC電話番号
     * @return GC_TEL_NUM GC電話番号
     */
    public String getGC_TEL_NUM() {
        return GC_TEL_NUM;
    }

    /**
     * GC電話番号
     * @param GC_TEL_NUM GC電話番号
     */
    public void setGC_TEL_NUM(String GC_TEL_NUM) {
        this.GC_TEL_NUM = GC_TEL_NUM == null ? null : GC_TEL_NUM.trim();
    }

    /**
     * 上位GCコード
     * @return UPPER_GC_CD 上位GCコード
     */
    public String getUPPER_GC_CD() {
        return UPPER_GC_CD;
    }

    /**
     * 上位GCコード
     * @param UPPER_GC_CD 上位GCコード
     */
    public void setUPPER_GC_CD(String UPPER_GC_CD) {
        this.UPPER_GC_CD = UPPER_GC_CD == null ? null : UPPER_GC_CD.trim();
    }

    /**
     * 同期有効フラグ
     * @return SYNC_ABL_FLG 同期有効フラグ
     */
    public String getSYNC_ABL_FLG() {
        return SYNC_ABL_FLG;
    }

    /**
     * 同期有効フラグ
     * @param SYNC_ABL_FLG 同期有効フラグ
     */
    public void setSYNC_ABL_FLG(String SYNC_ABL_FLG) {
        this.SYNC_ABL_FLG = SYNC_ABL_FLG == null ? null : SYNC_ABL_FLG.trim();
    }

    /**
     * IPアドレス
     * @return IP_ADDR IPアドレス
     */
    public String getIP_ADDR() {
        return IP_ADDR;
    }

    /**
     * IPアドレス
     * @param IP_ADDR IPアドレス
     */
    public void setIP_ADDR(String IP_ADDR) {
        this.IP_ADDR = IP_ADDR == null ? null : IP_ADDR.trim();
    }

    /**
     * 業務コード
     * @return GYOUMU_CD 業務コード
     */
    public String getGYOUMU_CD() {
        return GYOUMU_CD;
    }

    /**
     * 業務コード
     * @param GYOUMU_CD 業務コード
     */
    public void setGYOUMU_CD(String GYOUMU_CD) {
        this.GYOUMU_CD = GYOUMU_CD == null ? null : GYOUMU_CD.trim();
    }

    /**
     * DB名称
     * @return DB_NM DB名称
     */
    public String getDB_NM() {
        return DB_NM;
    }

    /**
     * DB名称
     * @param DB_NM DB名称
     */
    public void setDB_NM(String DB_NM) {
        this.DB_NM = DB_NM == null ? null : DB_NM.trim();
    }

    /**
     * DBユーザー
     * @return DB_USER DBユーザー
     */
    public String getDB_USER() {
        return DB_USER;
    }

    /**
     * DBユーザー
     * @param DB_USER DBユーザー
     */
    public void setDB_USER(String DB_USER) {
        this.DB_USER = DB_USER == null ? null : DB_USER.trim();
    }

    /**
     * DBパスワード
     * @return DB_PASSWD DBパスワード
     */
    public String getDB_PASSWD() {
        return DB_PASSWD;
    }

    /**
     * DBパスワード
     * @param DB_PASSWD DBパスワード
     */
    public void setDB_PASSWD(String DB_PASSWD) {
        this.DB_PASSWD = DB_PASSWD == null ? null : DB_PASSWD.trim();
    }

    /**
     * GCTバージョン
     * @return GCT_VER GCTバージョン
     */
    public String getGCT_VER() {
        return GCT_VER;
    }

    /**
     * GCTバージョン
     * @param GCT_VER GCTバージョン
     */
    public void setGCT_VER(String GCT_VER) {
        this.GCT_VER = GCT_VER == null ? null : GCT_VER.trim();
    }

    /**
     * 最大接続数
     * @return MAX_ACTIVE 最大接続数
     */
    public String getMAX_ACTIVE() {
        return MAX_ACTIVE;
    }

    /**
     * 最大接続数
     * @param MAX_ACTIVE 最大接続数
     */
    public void setMAX_ACTIVE(String MAX_ACTIVE) {
        this.MAX_ACTIVE = MAX_ACTIVE == null ? null : MAX_ACTIVE.trim();
    }

    /**
     * 保持最大数
     * @return MAX_IDLE 保持最大数
     */
    public String getMAX_IDLE() {
        return MAX_IDLE;
    }

    /**
     * 保持最大数
     * @param MAX_IDLE 保持最大数
     */
    public void setMAX_IDLE(String MAX_IDLE) {
        this.MAX_IDLE = MAX_IDLE == null ? null : MAX_IDLE.trim();
    }

    /**
     * 最大待機時間
     * @return MAX_WAIT_TM 最大待機時間
     */
    public String getMAX_WAIT_TM() {
        return MAX_WAIT_TM;
    }

    /**
     * 最大待機時間
     * @param MAX_WAIT_TM 最大待機時間
     */
    public void setMAX_WAIT_TM(String MAX_WAIT_TM) {
        this.MAX_WAIT_TM = MAX_WAIT_TM == null ? null : MAX_WAIT_TM.trim();
    }

    /**
     * SD連携フラグ
     * @return SD_FLG SD連携フラグ
     */
    public String getSD_FLG() {
        return SD_FLG;
    }

    /**
     * SD連携フラグ
     * @param SD_FLG SD連携フラグ
     */
    public void setSD_FLG(String SD_FLG) {
        this.SD_FLG = SD_FLG == null ? null : SD_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}