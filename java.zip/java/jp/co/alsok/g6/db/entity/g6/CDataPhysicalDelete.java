package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CDataPhysicalDelete implements Serializable {
    /**
     * LN_DBデータ物理削除制御論理番号
     */
    private String LN_DATA_PHYSICAL_DELETE;

    /**
     * 削除対象グループID
     */
    private String DELETE_TARGET_GROUP_ID;

    /**
     * 削除対象サーバ
     */
    private String DELETE_TARGET_SERVER;

    /**
     * 削除対象グループ順番
     */
    private String DELETE_TARGET_GROUP_ORDER;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_DATA_PHYSICAL_DELETE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_DBデータ物理削除制御論理番号
     * @return LN_DATA_PHYSICAL_DELETE LN_DBデータ物理削除制御論理番号
     */
    public String getLN_DATA_PHYSICAL_DELETE() {
        return LN_DATA_PHYSICAL_DELETE;
    }

    /**
     * LN_DBデータ物理削除制御論理番号
     * @param LN_DATA_PHYSICAL_DELETE LN_DBデータ物理削除制御論理番号
     */
    public void setLN_DATA_PHYSICAL_DELETE(String LN_DATA_PHYSICAL_DELETE) {
        this.LN_DATA_PHYSICAL_DELETE = LN_DATA_PHYSICAL_DELETE == null ? null : LN_DATA_PHYSICAL_DELETE.trim();
    }

    /**
     * 削除対象グループID
     * @return DELETE_TARGET_GROUP_ID 削除対象グループID
     */
    public String getDELETE_TARGET_GROUP_ID() {
        return DELETE_TARGET_GROUP_ID;
    }

    /**
     * 削除対象グループID
     * @param DELETE_TARGET_GROUP_ID 削除対象グループID
     */
    public void setDELETE_TARGET_GROUP_ID(String DELETE_TARGET_GROUP_ID) {
        this.DELETE_TARGET_GROUP_ID = DELETE_TARGET_GROUP_ID == null ? null : DELETE_TARGET_GROUP_ID.trim();
    }

    /**
     * 削除対象サーバ
     * @return DELETE_TARGET_SERVER 削除対象サーバ
     */
    public String getDELETE_TARGET_SERVER() {
        return DELETE_TARGET_SERVER;
    }

    /**
     * 削除対象サーバ
     * @param DELETE_TARGET_SERVER 削除対象サーバ
     */
    public void setDELETE_TARGET_SERVER(String DELETE_TARGET_SERVER) {
        this.DELETE_TARGET_SERVER = DELETE_TARGET_SERVER == null ? null : DELETE_TARGET_SERVER.trim();
    }

    /**
     * 削除対象グループ順番
     * @return DELETE_TARGET_GROUP_ORDER 削除対象グループ順番
     */
    public String getDELETE_TARGET_GROUP_ORDER() {
        return DELETE_TARGET_GROUP_ORDER;
    }

    /**
     * 削除対象グループ順番
     * @param DELETE_TARGET_GROUP_ORDER 削除対象グループ順番
     */
    public void setDELETE_TARGET_GROUP_ORDER(String DELETE_TARGET_GROUP_ORDER) {
        this.DELETE_TARGET_GROUP_ORDER = DELETE_TARGET_GROUP_ORDER == null ? null : DELETE_TARGET_GROUP_ORDER.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}