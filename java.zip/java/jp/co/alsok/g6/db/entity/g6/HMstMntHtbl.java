package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HMstMntHtbl implements Serializable {
    /**
     * LN_マスターメンテナンス論理番号
     */
    private String LN_MST_MNT;

    /**
     * 検索キー１
     */
    private String KEY1;

    /**
     * 検索キー２
     */
    private String KEY2;

    /**
     * 画面ID
     */
    private String DISP_ID;

    /**
     * 理由ID
     */
    private String REASON_ID;

    /**
     * 内容
     */
    private String MST_MNT_NAIYOU;

    /**
     * 処理ID
     */
    private String ID_PROCESS_ID;

    /**
     * 処理区分
     */
    private String PROCESS_KBN;

    /**
     * システム区分
     */
    private String SYS_KBN;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_MST_MNT_HTBL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_マスターメンテナンス論理番号
     * @return LN_MST_MNT LN_マスターメンテナンス論理番号
     */
    public String getLN_MST_MNT() {
        return LN_MST_MNT;
    }

    /**
     * LN_マスターメンテナンス論理番号
     * @param LN_MST_MNT LN_マスターメンテナンス論理番号
     */
    public void setLN_MST_MNT(String LN_MST_MNT) {
        this.LN_MST_MNT = LN_MST_MNT == null ? null : LN_MST_MNT.trim();
    }

    /**
     * 検索キー１
     * @return KEY1 検索キー１
     */
    public String getKEY1() {
        return KEY1;
    }

    /**
     * 検索キー１
     * @param KEY1 検索キー１
     */
    public void setKEY1(String KEY1) {
        this.KEY1 = KEY1 == null ? null : KEY1.trim();
    }

    /**
     * 検索キー２
     * @return KEY2 検索キー２
     */
    public String getKEY2() {
        return KEY2;
    }

    /**
     * 検索キー２
     * @param KEY2 検索キー２
     */
    public void setKEY2(String KEY2) {
        this.KEY2 = KEY2 == null ? null : KEY2.trim();
    }

    /**
     * 画面ID
     * @return DISP_ID 画面ID
     */
    public String getDISP_ID() {
        return DISP_ID;
    }

    /**
     * 画面ID
     * @param DISP_ID 画面ID
     */
    public void setDISP_ID(String DISP_ID) {
        this.DISP_ID = DISP_ID == null ? null : DISP_ID.trim();
    }

    /**
     * 理由ID
     * @return REASON_ID 理由ID
     */
    public String getREASON_ID() {
        return REASON_ID;
    }

    /**
     * 理由ID
     * @param REASON_ID 理由ID
     */
    public void setREASON_ID(String REASON_ID) {
        this.REASON_ID = REASON_ID == null ? null : REASON_ID.trim();
    }

    /**
     * 内容
     * @return MST_MNT_NAIYOU 内容
     */
    public String getMST_MNT_NAIYOU() {
        return MST_MNT_NAIYOU;
    }

    /**
     * 内容
     * @param MST_MNT_NAIYOU 内容
     */
    public void setMST_MNT_NAIYOU(String MST_MNT_NAIYOU) {
        this.MST_MNT_NAIYOU = MST_MNT_NAIYOU == null ? null : MST_MNT_NAIYOU.trim();
    }

    /**
     * 処理ID
     * @return ID_PROCESS_ID 処理ID
     */
    public String getID_PROCESS_ID() {
        return ID_PROCESS_ID;
    }

    /**
     * 処理ID
     * @param ID_PROCESS_ID 処理ID
     */
    public void setID_PROCESS_ID(String ID_PROCESS_ID) {
        this.ID_PROCESS_ID = ID_PROCESS_ID == null ? null : ID_PROCESS_ID.trim();
    }

    /**
     * 処理区分
     * @return PROCESS_KBN 処理区分
     */
    public String getPROCESS_KBN() {
        return PROCESS_KBN;
    }

    /**
     * 処理区分
     * @param PROCESS_KBN 処理区分
     */
    public void setPROCESS_KBN(String PROCESS_KBN) {
        this.PROCESS_KBN = PROCESS_KBN == null ? null : PROCESS_KBN.trim();
    }

    /**
     * システム区分
     * @return SYS_KBN システム区分
     */
    public String getSYS_KBN() {
        return SYS_KBN;
    }

    /**
     * システム区分
     * @param SYS_KBN システム区分
     */
    public void setSYS_KBN(String SYS_KBN) {
        this.SYS_KBN = SYS_KBN == null ? null : SYS_KBN.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}