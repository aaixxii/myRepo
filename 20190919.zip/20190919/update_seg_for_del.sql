CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_seg_for_del`(
 IN p_biometrics_id bigint(38),
 IN p_container_id int(8),
 IN p_biometric_data_len int(16), 
 out o_seg_id bigint(38),
 out o_seg_ver bigint(38)
 
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN/*[cr_debug.3 5]*/
DECLARE cr_stack_depth INTEGER DEFAULT cr_debug.ENTER_MODULE2('update_seg_for_del', 'AIMDB', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_biometrics_id', p_biometrics_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_container_id', p_container_id, 'int(8)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_biometric_data_len', p_biometric_data_len, 'int(16)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
begin_lab:BEGIN
DECLARE cr_stack_depth_handler INTEGER/*[cr_debug.1]*/;
 DECLARE l_segmet_id bigint(38);
 DECLARE l_segment_ver bigint(38);
 DECLARE l_seg_binary_len_comp int(16); 
 DECLARE l_seg_rec_count  bigint(38);
 DECLARE l_seg_revision bigint(38);
 DECLARE del_count int;
 DECLARE l_effect_count int;
 DECLARE t_error INTEGER DEFAULT 0;  
 DECLARE not_found INTEGER DEFAULT 0; 
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('update_seg_for_del_Handler', 'update_seg_for_del', 'AIMDB', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_segmet_id', l_segmet_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_segment_ver', l_segment_ver, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_binary_len_comp', l_seg_binary_len_comp, 'int(16)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_rec_count', l_seg_rec_count, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_revision', l_seg_revision, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('del_count', del_count, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_effect_count', l_effect_count, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('not_found', not_found, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_biometrics_id', p_biometrics_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_container_id', p_container_id, 'int(8)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_biometric_data_len', p_biometric_data_len, 'int(16)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(20, 20, 44, 58, cr_stack_depth)/*[cr_debug.2]*/;
SET t_error=1;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth - 1)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END;  
  DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN/*[cr_debug.3 5]*/
SET cr_stack_depth_handler = cr_stack_depth/*[cr_debug.2]*/;
SET cr_stack_depth = cr_debug.ENTER_HANDLER('update_seg_for_del_Handler', 'update_seg_for_del', 'AIMDB', 7, 100636)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_segmet_id', l_segmet_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_segment_ver', l_segment_ver, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_binary_len_comp', l_seg_binary_len_comp, 'int(16)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_rec_count', l_seg_rec_count, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_revision', l_seg_revision, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('del_count', del_count, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_effect_count', l_effect_count, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('not_found', not_found, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_biometrics_id', p_biometrics_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_container_id', p_container_id, 'int(8)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('p_biometric_data_len', p_biometric_data_len, 'int(16)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(21, 21, 41, 57, cr_stack_depth)/*[cr_debug.2]*/;
SET not_found=1;
CALL cr_debug.UPDATE_WATCH3('not_found', not_found, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.LEAVE_MODULE(cr_stack_depth - 1)/*[cr_debug.1]*/;
/*[cr_debug.4 4]*/END; 
  CALL cr_debug.UPDATE_WATCH3('l_segmet_id', l_segmet_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_segment_ver', l_segment_ver, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_binary_len_comp', l_seg_binary_len_comp, 'int(16)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_rec_count', l_seg_rec_count, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_revision', l_seg_revision, 'bigint(38)', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('del_count', del_count, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('l_effect_count', l_effect_count, 'int', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.UPDATE_WATCH3('not_found', not_found, 'INTEGER', cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(10, 10, 10, 15, cr_stack_depth)/*[cr_debug.2]*/;
CALL cr_debug.TRACE(22, 22, 2, 22, cr_stack_depth)/*[cr_debug.2]*/;
SET  @@autocommit=0;
CALL cr_debug.UPDATE_WATCH3('@@autocommit', @@autocommit, '', cr_stack_depth)/*[cr_debug.1]*/;
      CALL cr_debug.TRACE(23, 24, 6, 45, cr_stack_depth)/*[cr_debug.2]*/;
DELETE FROM PERSON_BIOMETRICS       
      WHERE BIOMETRICS_ID =  p_biometrics_id;
CALL cr_debug.UPDATE_SYSTEM_CALLS(103)/*[cr_debug.1]*/;
      CALL cr_debug.TRACE(25, 25, 6, 40, cr_stack_depth)/*[cr_debug.2]*/;
SELECT cr_debug.get_ROW_COUNT() INTO del_count;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('del_count', del_count, '', cr_stack_depth)/*[cr_debug.1]*/;   
      CALL cr_debug.TRACE(26, 30, 6, 10, cr_stack_depth)/*[cr_debug.2]*/;
if del_count <=> 0 THEN        
         CALL cr_debug.TRACE(27, 27, 9, 27, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_id = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, '', cr_stack_depth)/*[cr_debug.1]*/;
         CALL cr_debug.TRACE(28, 28, 9, 28, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_ver = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, '', cr_stack_depth)/*[cr_debug.1]*/;
        CALL cr_debug.TRACE(29, 29, 8, 24, cr_stack_depth)/*[cr_debug.2]*/;
LEAVE begin_lab;
	  end if;        
      
  CALL cr_debug.TRACE(32, 36, 2, 59, cr_stack_depth)/*[cr_debug.2]*/;
SELECT SEGMENT_ID,VERSION, BINARY_LENGTH_COMPACTED,RECORD_COUNT,REVISION
  INTO l_segmet_id,l_segment_ver,l_seg_binary_len_comp,l_seg_rec_count,l_seg_revision
  FROM SEGMENTS
  WHERE  CONTAINER_ID =p_container_id
  AND  p_biometrics_id BETWEEN BIO_ID_START AND BIO_ID_END;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_segmet_id', l_segmet_id, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_segment_ver', l_segment_ver, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_binary_len_comp', l_seg_binary_len_comp, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_rec_count', l_seg_rec_count, '', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_revision', l_seg_revision, '', cr_stack_depth)/*[cr_debug.1]*/;
  CALL cr_debug.TRACE(37, 41, 2, 9, cr_stack_depth)/*[cr_debug.2]*/;
IF not_found<=>1 THEN  
	 CALL cr_debug.TRACE(38, 38, 2, 20, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_id = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, '', cr_stack_depth)/*[cr_debug.1]*/;
	 CALL cr_debug.TRACE(39, 39, 2, 21, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_ver = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, '', cr_stack_depth)/*[cr_debug.1]*/;
     CALL cr_debug.TRACE(40, 40, 5, 21, cr_stack_depth)/*[cr_debug.2]*/;
LEAVE begin_lab;
  END IF;   
CALL cr_debug.TRACE(42, 47, 0, 32, cr_stack_depth)/*[cr_debug.2]*/;
UPDATE SEGMENTS s
SET BINARY_LENGTH_COMPACTED = l_seg_binary_len_comp - p_biometric_data_len -54,  
	RECORD_COUNT = l_seg_rec_count -1,
	VERSION = l_segment_ver + 1,
	REVISION = l_seg_revision + 1     
WHERE  SEGMENT_ID = l_segmet_id;
CALL cr_debug.UPDATE_SYSTEM_CALLS(104)/*[cr_debug.1]*/;
   CALL cr_debug.TRACE(48, 52, 3, 10, cr_stack_depth)/*[cr_debug.2]*/;
IF t_error <=> 1 THEN  
 	 CALL cr_debug.TRACE(49, 49, 3, 21, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_id = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, '', cr_stack_depth)/*[cr_debug.1]*/;
	 CALL cr_debug.TRACE(50, 50, 2, 21, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_ver = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, '', cr_stack_depth)/*[cr_debug.1]*/;
      CALL cr_debug.TRACE(51, 51, 6, 22, cr_stack_depth)/*[cr_debug.2]*/;
LEAVE begin_lab;
   END IF;
  CALL cr_debug.TRACE(53, 53, 2, 41, cr_stack_depth)/*[cr_debug.2]*/;
SELECT cr_debug.get_ROW_COUNT() INTO l_effect_count;
CALL cr_debug.UPDATE_SYSTEM_CALLS(101)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_effect_count', l_effect_count, '', cr_stack_depth)/*[cr_debug.1]*/;
  CALL cr_debug.TRACE(54, 58, 2, 11, cr_stack_depth)/*[cr_debug.2]*/;
IF l_effect_count = 0 THEN      
	  CALL cr_debug.TRACE(55, 55, 3, 21, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_id = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, '', cr_stack_depth)/*[cr_debug.1]*/;
	  CALL cr_debug.TRACE(56, 56, 3, 22, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_ver = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, '', cr_stack_depth)/*[cr_debug.1]*/;      
      CALL cr_debug.TRACE(57, 57, 6, 22, cr_stack_depth)/*[cr_debug.2]*/;
LEAVE begin_lab;
    END IF;     
CALL cr_debug.TRACE(59, 60, 0, 55, cr_stack_depth)/*[cr_debug.2]*/;
INSERT INTO SEGMENT_CHANGE_LOG(SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE,BIOMETRICS_ID)            
VALUES(l_segmet_id,l_segment_ver+1,1, p_biometrics_id);
CALL cr_debug.UPDATE_SYSTEM_CALLS(102)/*[cr_debug.1]*/; 
  CALL cr_debug.TRACE(61, 69, 2, 9, cr_stack_depth)/*[cr_debug.2]*/;
IF t_error = 1 THEN 
 	 CALL cr_debug.TRACE(62, 62, 3, 21, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_id = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, '', cr_stack_depth)/*[cr_debug.1]*/;
	 CALL cr_debug.TRACE(63, 63, 2, 21, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_ver = -1;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, '', cr_stack_depth)/*[cr_debug.1]*/;    
     CALL cr_debug.TRACE(64, 64, 5, 14, cr_stack_depth)/*[cr_debug.2]*/;
ROLLBACK;
CALL cr_debug.UPDATE_WATCH3('l_segmet_id', l_segmet_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_segment_ver', l_segment_ver, 'bigint(38)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_binary_len_comp', l_seg_binary_len_comp, 'int(16)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_rec_count', l_seg_rec_count, 'bigint(38)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_seg_revision', l_seg_revision, 'bigint(38)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('del_count', del_count, 'int', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('l_effect_count', l_effect_count, 'int', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('t_error', t_error, 'INTEGER', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('not_found', not_found, 'INTEGER', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('p_biometrics_id', p_biometrics_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('p_container_id', p_container_id, 'int(8)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('p_biometric_data_len', p_biometric_data_len, 'int(16)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, 'bigint(38)', cr_stack_depth)/*[cr_debug.1]*/;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, 'bigint(38)', cr_stack_depth)/*[cr_debug.1]*/;
ELSE   
	CALL cr_debug.TRACE(66, 66, 1, 28, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_id = l_segmet_id;
CALL cr_debug.UPDATE_WATCH3('o_seg_id', o_seg_id, '', cr_stack_depth)/*[cr_debug.1]*/;
	CALL cr_debug.TRACE(67, 67, 1, 35, cr_stack_depth)/*[cr_debug.2]*/;
SET o_seg_ver = l_segment_ver + 1;
CALL cr_debug.UPDATE_WATCH3('o_seg_ver', o_seg_ver, '', cr_stack_depth)/*[cr_debug.1]*/;
    CALL cr_debug.TRACE(68, 68, 4, 11, cr_stack_depth)/*[cr_debug.2]*/;
COMMIT;
  END IF;
CALL cr_debug.TRACE(70, 70, 0, 3, cr_stack_depth)/*[cr_debug.2]*/;
END;/*[cr_debug.3 1]*/

CALL cr_debug.LEAVE_MODULE(cr_stack_depth - 1)/*[cr_debug.1]*/;
/*[cr_debug.4 3]*/END