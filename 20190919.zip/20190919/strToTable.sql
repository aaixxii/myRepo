CREATE DEFINER=`aimuser`@`%` PROCEDURE `strToTable`(
IN p_candidate_containers varchar(1024),
IN tab_name varchar(30),
OUT v_err int)
mylab:
  BEGIN
    DECLARE v_id int;
    DECLARE v_idx int DEFAULT 999;
    DECLARE v_tmp_str varchar(20);
    DECLARE t_error integer DEFAULT 0;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    SET @delSql = CONCAT('DROP TEMPORARY TABLE IF EXISTS ', tab_name);
    PREPARE stmt1 FROM @delSql;
    EXECUTE stmt1;
    DEALLOCATE PREPARE stmt1;
    SET @createSql = CONCAT('create TEMPORARY table ', tab_name, '(id int) engine=memory');
    PREPARE stmt2 FROM @createSql;
    EXECUTE stmt2;
    DEALLOCATE PREPARE stmt2;
    WHILE v_idx > 0 DO
      SET v_idx = INSTR(p_candidate_containers, ',');
      IF v_idx <= 0 THEN
        SET @insertSql = CONCAT('insert into ', tab_name, '(id)  values(', CAST(p_candidate_containers AS UNSIGNED), ')');
        PREPARE stmt3 FROM @insertSql;
        EXECUTE stmt3;
        DEALLOCATE PREPARE stmt3; 
        SET v_err = t_error;        
        LEAVE mylab;
      END IF;
      SET v_tmp_str = SUBSTR(p_candidate_containers, 1, v_idx - 1); 
      SET @insertSql2 =  CONCAT('insert into ',tab_name, '(id)  values (', CAST(v_tmp_str AS UNSIGNED), ')');
      PREPARE stmt5 FROM @insertSql2;
      EXECUTE stmt5;
      DEALLOCATE PREPARE stmt5;
      SET p_candidate_containers = SUBSTR(p_candidate_containers, v_idx + 1, LENGTH(p_candidate_containers));
    END WHILE;
  -- select count(id) into v_count from arr_container_ids;
  END