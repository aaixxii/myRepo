package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.jdbc.support.nativejdbc.CommonsDbcpNativeJdbcExtractor;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;

/**
 * DeleteBiometricsProcedure
 * 
 * @author liuyq
 * 
 */
public class DeleteBiometricsProcedure extends StoredProcedure {

	private static final String SQL = "delete_biometrics";	
	private String externalId;
	private Integer eventId;
	private String containerIds;

	/**
	 * DeleteBiometricsProcedure
	 * 
	 * @param dataSource
	 *            DataSource instance
	 */
	public DeleteBiometricsProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		// AbstractSqlTypeValue uses native Connection
		getJdbcTemplate().setNativeJdbcExtractor(
				new CommonsDbcpNativeJdbcExtractor());
				// We must set SqlOutParameter FIRST!
		declareParameter(new SqlParameter("p_external_id", Types.VARCHAR));
		declareParameter(new SqlParameter("p_event_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_container_ids", Types.VARCHAR));
		declareParameter(new SqlOutParameter("p_seg_ids", Types.VARCHAR));				
		declareParameter(new SqlOutParameter("p_seg_versions", Types.VARCHAR));				
		declareParameter(new SqlOutParameter("p_template_ids", Types.VARCHAR));
		declareParameter(new SqlOutParameter("l_deleted_record_count",
				Types.INTEGER));
				
		compile();
	}

	/**
	 * call MATCH_MANAGER_API.delete_biometrics and returns
	 * l_deleted_record_count.
	 * 
	 * @throws SQLException
	 */
	public Long executeDeletion(Map<Long, List<SegSyncInfos>> syncMap)
			throws SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_external_id", getExternalId());
		map.put("p_event_id", getEventId());
		if (Objects.isNull(containerIds)) {
			map.put("p_container_ids", null);
		} else {
			map.put("p_container_ids", containerIds); 
		}
		Map<String, Object> resultMap = execute(map);
		int count = (Integer) resultMap.get("l_deleted_record_count");
		if (count < 1) {
			return Long.valueOf(count);
		}

		String array1 = (String) resultMap.get("p_seg_ids");
		array1 = array1.substring(0, array1.length() -1);
		String[] strSegIds = array1.split(",");
	//int[] array = Arrays.asList(strSegIds).stream().mapToInt(Integer::parseInt).toArray();
		long[] segIds = Arrays.asList(strSegIds).stream().mapToLong(Long::parseLong).toArray();
		String array2 = (String) resultMap.get("p_seg_versions");
		array2 = array2.substring(0, array2.length() -1);
		String[] strSegVers = array2.split(",");
		long[] segVersions = Arrays.asList(strSegVers).stream().mapToLong(Long::parseLong).toArray();
		String array3 = (String) resultMap.get("p_template_ids");
		array3 = array3.substring(0, array3.length() -1);
		String[] strBioIds = array3.split(",");
		long[] templateIds = Arrays.asList(strBioIds).stream().mapToLong(Long::parseLong).toArray();	

		for (int index = 0; index < segIds.length; index++) {
			long segId = segIds[index];
			long segVersion = segVersions[index];
			long templateId = templateIds[index];

			if (!syncMap.containsKey(segId)) {
				syncMap.put(segId, new ArrayList<SegSyncInfos>());
			}
			syncMap.get(segId)
					.add(new SegSyncInfos(segId, segVersion, templateId,
							SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE));
		}
		return Long.valueOf(count);
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public String getContainerIds() {
		return containerIds;
	}

	public void setContainerIds(String containerIds) {
		this.containerIds = containerIds;
	}	

}
