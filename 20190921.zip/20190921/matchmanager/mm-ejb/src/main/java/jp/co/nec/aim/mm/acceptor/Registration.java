package jp.co.nec.aim.mm.acceptor;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentSyncRequest;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResponse;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResult;
import jp.co.nec.aim.message.proto.ManageService.PBCheckExternalIdResultDetail;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.CommitDao;
import jp.co.nec.aim.mm.dao.RUCDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.DataManagerEntity;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.UnreachableCodeException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.procedure.AddBiometricsProcedure;
import jp.co.nec.aim.mm.procedure.DeleteBiometricsProcedure;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;
import jp.co.nec.aim.mm.segment.sync.SegUpdatesManager;
import jp.co.nec.aim.mm.segment.sync.SyncThreadExecutor;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.OpLockHelper;
import jp.co.nec.aim.mm.util.PBStateUtil;
import jp.co.nec.aim.mm.util.RecordChecker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

/**
 * Registration Main work flow
 * 
 * @author liuyq
 */
public class Registration {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(Registration.class);
	private DataSource dataSource; // DataSource instance
	private NamedParameterJdbcTemplate namedParamJdbcTemplate;
	private SegUpdatesManager segUpdate; // SegUpdatesManager instance
	private UnitDao unitDao; // unit DAO
	private RUCDao rucDao; // RUC DAO
	private CommitDao commitDao; // commit DAO
	private SystemConfigDao configDao; // SystemConfig Dao

	/** MU_SEGMENT_UPDATE_URL **/
	private static final String MU_SEGMENT_UPDATE_URL = "matchunit/SegmentUpdateJob";
	private static final String DM_SEGMENT_UPDATE_URL = "datamanager/SegmentUpdateJob";

	/** SQL **/
	private static final String COUNT_SQL = "select count(biometrics_id) num, event_id, container_id, corrupted_flag "
			+ "from person_biometrics where external_id=:externalId group by event_id, container_id, corrupted_flag order by event_id, container_id";
	private static final String COUNT_SQL_IN_CONTAINER_IDS = "select count(biometrics_id) num, event_id, "
			+ "container_id, corrupted_flag from person_biometrics where external_id=:externalId and container_id in (:containerIds) "
			+ "group by event_id, container_id, corrupted_flag order by event_id, container_id";
	private static final String COUNT_SQL_IN_EVENT_IDS = "select count(biometrics_id) num, event_id, "
			+ "container_id, corrupted_flag from person_biometrics where external_id=:externalId and event_id in (:eventIds) "
			+ "group by event_id, container_id, corrupted_flag order by event_id, container_id";
	private static final String COUNT_SQL_IN_BOTH_IDS = "select count(biometrics_id) num, event_id, "
			+ "container_id, corrupted_flag from person_biometrics where external_id=:externalId "
			+ "and event_id in (:eventIds) and container_id in (:containerIds)"
			+ "group by event_id, container_id, corrupted_flag order by event_id, container_id";

	/**
	 * Registration default constructor
	 */
	public Registration() {
	}

	/**
	 * Registration constructor
	 * 
	 * @param dataSource
	 *            DataSource instance
	 * @param em
	 *            EntityManager instance
	 */
	public Registration(DataSource dataSource, EntityManager em) {
		this.dataSource = dataSource;
		this.segUpdate = new SegUpdatesManager(em, dataSource);
		this.unitDao = new UnitDao(em);
		this.rucDao = new RUCDao(dataSource);
		this.commitDao = new CommitDao(dataSource);
		this.configDao = new SystemConfigDao(em);
		namedParamJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	/**
	 * insert the template and sync data
	 * 
	 * @param eventId
	 *            eventId optional
	 * @param externalId
	 *            externalId required
	 * @param syncRequests
	 *            SyncRequest list
	 */
	public void insert(int eventId, String externalId,
			List<SyncRequest> syncRequests) {
		// insert the Template into the target container
		Map<Long, List<SegSyncInfos>> syncMap = insertTemplate(eventId,
				externalId, syncRequests);

		// If the new segment was generated, send the event to SLB
		// SLB will wake up specified MU and DM, MU and DM will sync
		// the Data immediately.
		// if segment was only updated, we will push the different of
		// the updated segment.
		pushOrCallSlb(syncMap);
	}

	/**
	 * update the template and sync data
	 * 
	 * @param eventId
	 *            eventId
	 * @param externalId
	 *            externalId
	 * @param containerIds
	 *            containerId list
	 * @param syncRequests
	 *            SyncRequest list
	 */
	public void update(Integer eventId, String externalId,
			List<Integer> containerIds, List<SyncRequest> syncRequests) {
		// first delete the template
		Map<Long, List<SegSyncInfos>> delMap = Maps.newHashMap();
		deleteTemplate(eventId, externalId, containerIds, delMap);

		// second insert the template
		Map<Long, List<SegSyncInfos>> insertMap = insertTemplate(eventId,
				externalId, syncRequests);

		// push segment different information into MU DM
		pushOrCallSlb(merger(delMap, insertMap));
	}

	/**
	 * Prepare the segment sync info map for push
	 * 
	 * @param delMap
	 * @param insertMap
	 * @return Map instance
	 */
	private Map<Long, List<SegSyncInfos>> merger(
			Map<Long, List<SegSyncInfos>> delMap,
			Map<Long, List<SegSyncInfos>> insertMap) {
		final Map<Long, List<SegSyncInfos>> resultMap = Maps.newHashMap();
		if (CollectionsUtil.isEmpty(insertMap)) {
			return resultMap;
		}

		final Set<Long> segmentIds = Sets.newHashSet();
		segmentIds.addAll(delMap.keySet());
		segmentIds.addAll(insertMap.keySet());

		for (final Long segId : segmentIds) {
			if (!resultMap.containsKey(segId)) {
				resultMap.put(segId, new ArrayList<SegSyncInfos>());
			}

			List<SegSyncInfos> list = resultMap.get(segId);
			if (delMap.containsKey(segId)) {
				list.addAll(delMap.get(segId));
			}

			if (insertMap.containsKey(segId)) {
				list.addAll(insertMap.get(segId));
			}
		}
		return resultMap;
	}

	/**
	 * delete the template and sync data
	 * 
	 * @param eventId
	 *            eventId
	 * @param externalId
	 *            externalId
	 * @param containerIds
	 *            containerId list
	 */
	public int delete(Integer eventId, String externalId,
			List<Integer> containerIds) {
		Map<Long, List<SegSyncInfos>> delMap = Maps.newHashMap();
		int count = deleteTemplate(eventId, externalId, containerIds, delMap);
		if (count > 0) {
			pushOrCallSlb(delMap);
		} else {
			log.info("Skip push the segment diff or"
					+ " call slb when delete result is zero.");
		}
		return count;
	}

	/**
	 * deleteTemplate
	 * 
	 * @param externalId
	 *            externalId
	 * @param eventId
	 *            eventId
	 * @param containerIds
	 *            delete containerId list
	 */
	private int deleteTemplate(Integer eventId, String externalId,
			List<Integer> containerIds, Map<Long, List<SegSyncInfos>> syncMap) {
		
		for (OpLockHelper op = new OpLockHelper("delete", dataSource); op.hasNext(); op.next()) {
				
			try {
				log.debug("delete("
						+ externalId
						+ ", "
						+ eventId
						+ ", "
						+ (containerIds == null ? "null" : containerIds
								.toString()) + ")");

				DeleteBiometricsProcedure procedure = new DeleteBiometricsProcedure(
						dataSource);
				procedure.setExternalId(externalId);
				procedure.setEventId(eventId);
				List<String>  StrIds = containerIds.stream().map(String::valueOf).collect(Collectors.toList());			
				procedure.setContainerIds(String.join(",", StrIds));				
				int count = procedure.executeDeletion(syncMap).intValue();
				log.debug("Called. numRecordsDeleted = " + count);
				return count;
			} catch (DataAccessException e) {
				op.checkException(new SQLException(e), AimError.SYNC_DB);
			} catch (SQLException e) {
				op.checkException(e, AimError.SYNC_DB);
			}
		}
		throw new UnreachableCodeException();
	}

	/**
	 * insert Template with externalId, eventId and SyncRequest list
	 * 
	 * @param eventId
	 *            eventId
	 * @param externalId
	 *            externalId
	 * @param syncRequests
	 *            SyncRequest list
	 */
	private Map<Long, List<SegSyncInfos>> insertTemplate(int eventId,
			String externalId, List<SyncRequest> syncRequests) {
		// sort syncRequests list order by container id
		sortByContainerId(syncRequests);

		final Map<Long, List<SegSyncInfos>> groupBySeg = Maps.newHashMap();

		// Confirm is new segment generated
		boolean isNewSeg = false;
		// loop each SyncRequest and do insert operation
		for (final SyncRequest request : syncRequests) {
			RecordChecker.checkRecord(request.getRecord());
			// container id required
			final Integer containerId = request.getContainerId();

			// insert the each template with each specified request
			SegSyncInfos syncInfos = insertEachTemplate(externalId, eventId,
					containerId, request.getRecord());

			// if new segment was created, ASYNC call SLB directly
			if (!syncInfos.isUpdateSegment()) {
				// new segment was created
				if (log.isDebugEnabled()) {
					log.debug("New Segment({}) is created..",
							syncInfos.getSegmentId());
				}
				// once new segment was created,
				// call SLB and skip do push operation
				isNewSeg = true;
				continue;
			}

			if (!isNewSeg) {
				// No new segment was created, only update exist.
				// Must group by segment id due to each segment
				// push destination is different
				Long segId = syncInfos.getSegmentId();
				if (!groupBySeg.containsKey(segId)) {
					groupBySeg.put(segId, new ArrayList<SegSyncInfos>());
				}
				groupBySeg.get(segId).add(syncInfos);
			}
		}
		return isNewSeg ? null : groupBySeg;
	}

	/**
	 * insert one Template
	 * 
	 * @param externalId
	 *            externalId
	 * @param eventId
	 *            eventId
	 * @param containerId
	 *            containerId
	 * @param record
	 *            Record include template binary
	 */
	private SegSyncInfos insertEachTemplate(String externalId, int eventId,
			int containerId, Record record) {
		log.debug("insert(" + externalId + ", " + eventId + ") -> containerId "
				+ containerId);
		for (OpLockHelper op = new OpLockHelper("insert", dataSource); op
				.hasNext(); op.next()) {
			try {
				AddBiometricsProcedure procedure = new AddBiometricsProcedure(
						dataSource);
				procedure.setExternalId(externalId);
				procedure.setEventId(eventId);
				procedure.setContainerId(containerId);
				procedure.setBiometricsData(record.getBinary());
				return procedure.execute();
			} catch (DataAccessException e) {
				op.checkException(new SQLException(e), AimError.SYNC_DB);
			}
		}
		throw new UnreachableCodeException();
	}

	/**
	 * pushOrCallSlb
	 * 
	 * @param isSegCreated
	 */
	private void pushOrCallSlb(final Map<Long, List<SegSyncInfos>> syncMap) {
		// new segment created
		if (CollectionsUtil.isEmpty(syncMap)) {
			log.info("New Segment was created, need to call slb, "
					+ "SLB will wakeUp the DM MU, DM MU will fetch the data..");

			// Insert RUC count before call SLB
			rucDao.increaseRUC();

			// Commit before call SLB
			commitDao.commit();

			// ASYNC CALL SLB
			asyncCallSlb();
		} else {
			// no segment was created
			log.info("No Segment was created, call SegmentUpdateManager "
					+ "and ready to push the segment diff..");

			// Commit before push the different
			commitDao.commit();

			// Create muMap due to one MU may related to MULTIP
			// segment, we expect that only one push operation is enough
			// key -> muId
			Map<Long, Set<PBSegmentSyncInfo>> muMap = Maps.newHashMap();
			// key -> dmId
			Map<Long, Set<PBSegmentSyncInfo>> dmMap = Maps.newHashMap();
			// Push group by segment id one by one
			for (final Long segId : syncMap.keySet()) {
				final List<SegSyncInfos> syncInfos = syncMap.get(segId);

				Set<Long> muIds = Sets.newTreeSet(); // MU id set
				Set<Long> dmIds = Sets.newTreeSet(); // DM id set

				PBSegmentSyncInfo muSyncInfo = segUpdate.getSegmentUpdates(
						ComponentType.MATCH_UNIT, segId, syncInfos, muIds);
				PBSegmentSyncInfo dmSyncInfo = segUpdate.getSegmentUpdates(
						ComponentType.DATA_MANAGER, segId, syncInfos, dmIds);

				if (muSyncInfo != null) {
					for (Long muId : muIds) {
						if (!muMap.containsKey(muId)) {
							muMap.put(muId, new HashSet<PBSegmentSyncInfo>());
						}
						muMap.get(muId).add(muSyncInfo);
					}
				}

				if (dmSyncInfo != null) {
					for (Long dmId : dmIds) {
						if (!dmMap.containsKey(dmId)) {
							dmMap.put(dmId, new HashSet<PBSegmentSyncInfo>());
						}
						dmMap.get(dmId).add(dmSyncInfo);
					}
				}
			}

			if (log.isDebugEnabled()) {
				log.debug("Ready to async push data to DM and MU using mutip-thread..");
			}

			try {
				final SyncThreadExecutor executor = SyncThreadExecutor
						.getInstance();
				asyncPostMU(muMap, executor);
				asyncPostDM(dmMap, executor);
			} catch (Exception ex) {
				final String error = "Exception occurred when sync data to MU DM..";
				log.error(error, ex);
				throw new AimRuntimeException(error, ex);
			} finally {
				// finally
			}
		}
	}

	/**
	 * push segment different information to MU
	 * 
	 * @param muMap
	 * @param executor
	 */
	private void asyncPostMU(Map<Long, Set<PBSegmentSyncInfo>> muMap,
			final SyncThreadExecutor executor) {
		if (CollectionsUtil.isEmpty(muMap)) {
			log.warn("Nothing to push any segment diffs to MU..");
			return;
		}

		log.info("Push async data to MU, task number: {}.", muMap.size());

		final int retryCount = configDao
				.getMMPropertyInt(MMConfigProperty.MU_POST_COUNT);
		for (final Long muId : muMap.keySet()) {
			final PBSegmentSyncRequest.Builder bodyBuilder = PBSegmentSyncRequest
					.newBuilder().addAllSegmentUpdates(muMap.get(muId));

			final MatchUnitEntity mu = unitDao.findMU(muId);
			if (mu == null || mu.getState() != UnitState.WORKING) {
				log.warn(
						"Could not find MU with mu id: {}, or MU is not in working state.",
						muId);
				continue;
			}

			// Asynchronous add push MU task
			executor.execute(new Runnable() {
				@Override
				public void run() {
					try {
						String contactUrl = mu.getContactUrl();
						if (contactUrl.endsWith("/")) {
							contactUrl += MU_SEGMENT_UPDATE_URL;
						} else {
							contactUrl += "/" + MU_SEGMENT_UPDATE_URL;
						}
						HttpPoster.post(contactUrl, bodyBuilder.build()
								.toByteArray(), retryCount);
					} catch (Exception e) {
						log.error(
								"IOException occurred while sync data to mu..",
								e);
					}
				}
			});
		}
	}

	/**
	 * push segment different information to DM
	 * 
	 * @param dmMap
	 * @param executor
	 */
	private void asyncPostDM(Map<Long, Set<PBSegmentSyncInfo>> dmMap,
			final SyncThreadExecutor executor) {
		if (CollectionsUtil.isEmpty(dmMap)) {
			log.warn("Nothing to push any segment diffs to DM..");
			return;
		}

		log.info("Push async data to DM, task number: {}.", dmMap.size());

		final int retryCount = configDao
				.getMMPropertyInt(MMConfigProperty.DM_POST_COUNT);
		// Loop each DM and push segment different information Asynchronously
		for (final Long dmId : dmMap.keySet()) {
			final PBSegmentSyncRequest.Builder bodyBuilder = PBSegmentSyncRequest
					.newBuilder().addAllSegmentUpdates(dmMap.get(dmId));

			final DataManagerEntity dm = unitDao.findDM(dmId);
			if (dm == null || dm.getState() != UnitState.WORKING) {
				log.warn(
						"Could not find DM with dm id: {}, or DM is not in working state.",
						dmId);
				continue;
			}

			// Asynchronous add push DM task
			executor.execute(new Runnable() {
				@Override
				public void run() {
					try {
						String contactUrl = dm.getContactUrl();
						if (contactUrl.endsWith("/")) {
							contactUrl += DM_SEGMENT_UPDATE_URL;
						} else {
							contactUrl += "/" + DM_SEGMENT_UPDATE_URL;
						}
						HttpPoster.post(contactUrl, bodyBuilder.build()
								.toByteArray(), retryCount);
					} catch (Exception e) {
						log.error(
								"IOException occurred while sync data to dm..",
								e);
					}
				}
			});
		}
	}

	/**
	 * Selects PERSON_BIOMETRICS and returns the result as CheckResults Object
	 * 
	 * @param externalId
	 *            EXTERNAL_ID in PERSON_BIOMETRICS
	 * @param eventIds
	 *            List of EVNET_ID in PERSON_BIOMETRICS
	 * @param containerIds
	 *            List of CONTAINER_ID in PERSON_BIOMETRICS
	 * @return CheckResults Object
	 */
	public PBCheckExternalIdResponse createCheckResults(String externalId,
			List<Integer> eventIds, List<Integer> containerIds) {
		PBCheckExternalIdResponse.Builder b = PBCheckExternalIdResponse
				.newBuilder();

		b.setExternalId(externalId);
		List<Map<String, Object>> mapList = null;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("externalId", externalId);
		if (CollectionsUtil.isEmpty(eventIds)) {
			if (CollectionsUtil.isEmpty(containerIds)) {
				mapList = namedParamJdbcTemplate.queryForList(COUNT_SQL, map);
			} else {
				// evenId is null, containerId is exists
				map.put("containerIds", containerIds);
				mapList = namedParamJdbcTemplate.queryForList(
						COUNT_SQL_IN_CONTAINER_IDS, map);
			}
		} else {
			if (CollectionsUtil.isEmpty(containerIds)) {
				map.put("eventIds", eventIds);
				mapList = namedParamJdbcTemplate.queryForList(
						COUNT_SQL_IN_EVENT_IDS, map);
			} else {
				// all exists
				map.put("eventIds", eventIds);
				map.put("containerIds", containerIds);
				mapList = namedParamJdbcTemplate.queryForList(
						COUNT_SQL_IN_BOTH_IDS, map);
			}
		}
		addResult(b, mapList);
		b.setServiceState(PBStateUtil.creatSuccessState());
		return b.build();
	}

	/**
	 * Add CheckResult object to CheckResults
	 * 
	 * @param b
	 *            PBCheckExternalIdResponse Builder
	 * @param mapList
	 *            mapList
	 */
	private void addResult(PBCheckExternalIdResponse.Builder b,
			List<Map<String, Object>> mapList) {
		for (final Map<String, Object> map : mapList) {
			int num = ((BigDecimal) map.get("NUM")).intValue();
			int eventId = ((BigDecimal) map.get("EVENT_ID")).intValue();
			int containerId = ((BigDecimal) map.get("CONTAINER_ID")).intValue();
			int corruptedFlag = ((BigDecimal) map.get("CORRUPTED_FLAG"))
					.intValue();

			List<PBCheckExternalIdResult.Builder> checkResultList = b
					.getCheckResultBuilderList();
			PBCheckExternalIdResult.Builder checkResult = findResult(
					checkResultList, eventId);
			if (checkResult == null) {
				b.addCheckResult(PBCheckExternalIdResult.newBuilder()
						.setEventId(eventId));
				checkResult = b
						.getCheckResultBuilder(b.getCheckResultCount() - 1);
			}

			List<PBCheckExternalIdResultDetail.Builder> containerResultList = checkResult
					.getContainerResultBuilderList();
			PBCheckExternalIdResultDetail.Builder containerResult = findContainerResult(
					containerResultList, containerId);
			if (containerResult == null) {
				checkResult.addContainerResult(PBCheckExternalIdResultDetail
						.newBuilder().setContainerId(containerId)
						.setNumOfCorrupted(0).setNumOfValid(0));
				containerResult = checkResult
						.getContainerResultBuilder(checkResult
								.getContainerResultCount() - 1);
			}
			if (corruptedFlag == 0) {
				containerResult.setNumOfValid(num);
			} else {
				containerResult.setNumOfCorrupted(num);
			}
		}
	}

	/**
	 * findContainerResult
	 * 
	 * @param containerResultLists
	 * @param binId
	 * @return
	 */
	private PBCheckExternalIdResultDetail.Builder findContainerResult(
			List<PBCheckExternalIdResultDetail.Builder> containerResultLists,
			int binId) {
		for (PBCheckExternalIdResultDetail.Builder result : containerResultLists) {
			if (result.getContainerId() == binId) {
				return result;
			}
		}
		return null;
	}

	/**
	 * findResult
	 * 
	 * @param checkResultList
	 * @param eventId
	 * @return
	 */
	private PBCheckExternalIdResult.Builder findResult(
			List<PBCheckExternalIdResult.Builder> checkResultList, int eventId) {
		for (PBCheckExternalIdResult.Builder result : checkResultList) {
			if (result.getEventId() == eventId) {
				return result;
			}
		}
		return null;
	}

	/**
	 * sort the SyncRequest list order by ContainerId asc
	 * 
	 * @param syncRequests
	 */
	private void sortByContainerId(List<SyncRequest> syncRequests) {
		Collections.sort(syncRequests, new Comparator<SyncRequest>() {
			@Override
			public int compare(SyncRequest o1, SyncRequest o2) {
				return o1.getContainerId().compareTo(o2.getContainerId());
			}
		});
	}

	/**
	 * Sync call SLB using JmsSender utility
	 */
	private void asyncCallSlb() {
		JmsSender.getInstance().sendToSLB(NotifierEnum.Registration,
				"New Segment was created.");
	}
}
