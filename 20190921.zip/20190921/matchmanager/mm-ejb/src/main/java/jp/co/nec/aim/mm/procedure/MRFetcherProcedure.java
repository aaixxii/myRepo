package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * MRFetcherProcedure
 * 
 * @author liuyq
 * 
 */
public class MRFetcherProcedure extends StoredProcedure {

	/** sql **/
	private static final String SQL = "MATCH_MANAGER_API.GET_NEXT_MR_POSITION";

	/**
	 * MRFetcherProcedure constructor
	 * 
	 * @param dataSource
	 */
	public MRFetcherProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
//		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
//				new CursorMapper()));
		compile();
	}

	/**
	 * execute
	 * 
	 * @return MapReducerEntity instance
	 */
	public MapReducerEntity execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> resultMap = execute(map);
		@SuppressWarnings("unchecked")
		List<MapReducerEntity> list = (List<MapReducerEntity>) resultMap
				.get("p_refcursor");
		if (CollectionsUtil.isEmpty(list)) {
			return null;
		} else {
			return CollectionsUtil.getFirst(list);
		}
	}

	/**
	 * CursorMapper
	 * 
	 * @author liuyq
	 * 
	 */
	private class CursorMapper implements RowMapper<MapReducerEntity> {
		@Override
		public MapReducerEntity mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			long mrId = rs.getLong("MR_ID");
			if (mrId <= 0) {
				return null;
			}
			String contactUrl = rs.getString("CONTACT_URL");
			return new MapReducerEntity(mrId, contactUrl);
		}
	}

}
