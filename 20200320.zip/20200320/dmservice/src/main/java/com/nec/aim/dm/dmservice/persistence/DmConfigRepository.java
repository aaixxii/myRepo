package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;

public interface DmConfigRepository {
	
	public int getRedundancy() throws SQLException;
	public int getMaxSegmentRecord() throws SQLException;

}
