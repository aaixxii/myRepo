package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.NodeStorage;

@Repository
public class NodeStorageRepositoryImpl implements NodeStorageRepository{
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	private static final String sqlAll = "select * from node_storage";
	private static final String sqlById = "select * from node_storage where storage_id=? and dm_storage_id=?";
	//private static final String sqlByRedundancy = "select storage_id,dm_storage_id,url from node_storage where status=0 or status=1 and space>=? order by space DESC limit ?";
	private static final String sqlByRedundancy = "select * from node_storage where status=1 and space>0 order by space DESC limit ?";
	private static final String setMailFlagSql = "update node_storage  set mail_flag ='signal' where  storage_id =? and dm_storage_id=?";
	private static final String getNodeStorageBySegIdSql = "select n.*  from node_storage n, segment_loading s where n.storage_id = s.storage_id and s.segment_id=?";		

	@Override
	public List<NodeStorage> findAll()  throws SQLException {		
		return jdbcTemplate.query(sqlAll,  nodeRowMapper);
	}

	@Override
	public NodeStorage findById(Long id, String dmStrorageId)  throws SQLException{		
		return jdbcTemplate.queryForObject(sqlById, new Object[] {id, dmStrorageId}, nodeRowMapper);
	}
	
	RowMapper<NodeStorage> nodeRowMapper = (rs, rowNum) -> {
	    NodeStorage node = new NodeStorage();
	    node.setStorageId(rs.getInt("storage_id"));
	    node.setDmStorageid(rs.getString("dm_storage_id"));
	    node.setUrl(rs.getString("url"));
	    node.setDiskSize(rs.getInt("disk_size"));
	    node.setSpace(rs.getInt("space"));
	    node.setStatus(rs.getInt("status"));
	    node.setUpdateTs(rs.getTimestamp("update_ts"));
	    return node;
	};

	@Override
	public List<NodeStorage>  findNeedNodeByRedundancy(int redundancy)  throws SQLException {		
		return jdbcTemplate.query(sqlByRedundancy,  new Object[] {redundancy}, nodeRowMapper)	;
	}

	@Override
	public void setSignalMailFlag(int storageId, String dmSstorageId) {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(setMailFlagSql, new Object[] {storageId, dmSstorageId});
	}
	
	@Override
	public List<NodeStorage> getNodeStorgeBySegmentId(Long segmentId) throws SQLException {		
		List<NodeStorage> results = jdbcTemplate.query(getNodeStorageBySegIdSql, new Object[] {segmentId}, nodeRowMapper);
		return results;
	}	
}
