package com.nec.biomatcher.web.controller.biomanager;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.base.MoreObjects;
import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.nec.biomatcher.comp.admin.BioAdminService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerConnectionInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerGroupInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerType;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.core.framework.cache.FunctionalCacheService;
import com.nec.biomatcher.core.framework.common.DateUtil;
import com.nec.biomatcher.core.framework.common.StringUtil;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.spec.transfer.model.KeyValuePair;
import com.nec.biomatcher.spec.transfer.model.TemplateType;
import com.nec.biomatcher.web.controller.common.BaseController;

@Controller
@RequestMapping(value = "/secured/admin/biomanager")
public class BioManagerAdminController extends BaseController {

    private static final Logger logger = Logger.getLogger(BioManagerAdminController.class);

    private BioParameterService bioParameterService = SpringServiceManager.getBean("bioParameterService");
    private BioAdminService bioAdminService = SpringServiceManager.getBean("bioAdminService");
    private BioMatcherConfigService bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
    private BioMatchManagerService bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");
    private BioSearchControllerManager bioSearchControllerManager = SpringServiceManager.getBean("bioSearchControllerManager");
    private FunctionalCacheService functionalCacheService = SpringServiceManager.getBean("functionalCacheService");

    private enum ServerGroupColumnOrder {
        GROUP_ID, COMPONENT_TYPE, DESCRIPTION;
    }

    private enum ServerInfoColumnOrder {
        SERVER_ID, SERVER_HOST, SERVER_TYPE, COMPONENT_TYPE, SERVER_STATE, MAX_JOB_COUNT, SERVER_GROUP_ID, SUB_SYSTEM_GROUP_ID
    }

    private enum ServerConnInfoColumnOrder {
        SERVER_ID, COMPONENT_TYPE, CONNECTION_TYPE, PROTOCOL_TYPE, CONNECTION_URL
    }

    private enum MatcherBinInfoColumnOrder {
        BIN_ID, TEMPLATE_TYPE, MAX_EVENT_COUNT, EVENT_DATA_SIZE, TEMPLATE_DATA_SIZE, DESCRIPTION
    }

    private enum MatcherSegmentInfoColumnOrder {
        SEGMENT_ID, BIN_ID, SEGMENT_VERSION, START_BIO_ID, END_BIO_ID, CURRENT_BIOMETRIC_ID, ASSIGNED_SEARCH_NODES, UPDATE_DATETIME
    }

    private enum MatcherNodeSegmentInfoColumnOrder {
        MATCHER_NODE_ID, SEGMENT_ID, SEGMENT_VERSION, ASSIGNED_FLAG, UPDATE_DATETIME
    }

    @ModelAttribute("componentTypeList")
    public List<KeyValuePair<String, String>> getComponentTypeList() {
        return functionalCacheService.getUnCheckedCachedValue(() -> {
            List<KeyValuePair<String, String>> componentTypeList = new ArrayList<>();

            for (BioComponentType bioComponentType : BioComponentType.values()) {
                if (BioComponentType.DM.equals(bioComponentType)) {
                    continue;
                }
                componentTypeList.add(new KeyValuePair<String, String>(bioComponentType.name(), bioComponentType.getDescription()));
            }

            return componentTypeList;
        });
    }

    @ModelAttribute("serverTypeList")
    public List<KeyValuePair<String, String>> getServerTypeList() {
        return functionalCacheService.getUnCheckedCachedValue(() -> {
            List<KeyValuePair<String, String>> serverTypeList = new ArrayList<>();

            for (BioServerType bioServerType : BioServerType.values()) {
                serverTypeList.add(new KeyValuePair<String, String>(bioServerType.name(), bioServerType.getDescription()));
            }

            return serverTypeList;
        });
    }

    @ModelAttribute("connectionTypeList")
    public List<KeyValuePair<String, String>> getConnectionTypeList() {
        return functionalCacheService.getUnCheckedCachedValue(() -> {
            List<KeyValuePair<String, String>> connectionTypeList = new ArrayList<>();

            for (BioConnectionType bioConnectionType : BioConnectionType.values()) {
                connectionTypeList.add(new KeyValuePair<String, String>(bioConnectionType.name(), bioConnectionType.name()));
            }

            return connectionTypeList;
        });
    }

    @ModelAttribute("protocolTypeList")
    public List<KeyValuePair<String, String>> getProtocolTypeList() {
        return functionalCacheService.getUnCheckedCachedValue(() -> {
            List<KeyValuePair<String, String>> protocolTypeList = new ArrayList<>();

            for (BioProtocolType bioProtocolType : BioProtocolType.values()) {
                protocolTypeList.add(new KeyValuePair<String, String>(bioProtocolType.name(), bioProtocolType.name()));
            }

            return protocolTypeList;
        });
    }

    @ModelAttribute("templateTypeList")
    public List<KeyValuePair<String, String>> getTemplateTypeList() {

        return functionalCacheService.getUnCheckedCachedValue(() -> {
            List<KeyValuePair<String, String>> templateTypeList = new ArrayList<>();

            for (TemplateType templateType : TemplateType.values()) {
                templateTypeList.add(new KeyValuePair<String, String>(templateType.name(), StringUtils.leftPad("" + templateType.getTemplateTypeCode(), 2, " ") + " - " + templateType.getDescription()));
            }

            return templateTypeList;
        });
    }

    @ModelAttribute("serverStateList")
    public List<KeyValuePair<String, String>> getServerStateList() {
        return functionalCacheService.getUnCheckedCachedValue(() -> {
            List<KeyValuePair<String, String>> serverStateList = new ArrayList<>();

            for (BioServerState bioServerState : BioServerState.values()) {
                serverStateList.add(new KeyValuePair<String, String>(bioServerState.name(), bioServerState.getDescription()));
            }

            return serverStateList;
        });
    }

    @ModelAttribute("serverGroupList")
    public List<BioServerGroupInfo> getServerGroupInfoList() {
        try {
            return bioMatcherConfigService.getServerGroupInfoList();
        } catch (Throwable th) {
            logger.error("Error while getServerGroupInfoList: " + th.getMessage(), th);
            return Collections.emptyList();
        }
    }

    @ModelAttribute("serverInfoList")
    public List<BioServerInfo> getServeInfoList() {
        try {
            return bioMatcherConfigService.getServerInfoList();
        } catch (Throwable th) {
            logger.error("Error while getServerInfoList: " + th.getMessage(), th);
            return Collections.emptyList();
        }
    }

    @ModelAttribute("searchNodeInfoList")
    public List<BioServerInfo> getSearchNodeInfoList() {
        try {
            return bioMatcherConfigService.getServerInfoListByComponentType(BioComponentType.SN);
        } catch (Throwable th) {
            logger.error("Error while getMatcherNodeInfoList: " + th.getMessage(), th);
            return Collections.emptyList();
        }
    }

    @ModelAttribute("matcherBinInfoList")
    public List<BioMatcherBinInfo> getMatcherBinInfoList() {
        try {
            return bioMatcherConfigService.getMatcherBinInfoList();
        } catch (Throwable th) {
            logger.error("Error while getMatcherBinInfoList: " + th.getMessage(), th);
            return Collections.emptyList();
        }
    }

    @ModelAttribute("segmentIdEntryList")
    public Set<Entry<Integer, Integer>> getSegmentIdEntryList() {
        try {
            return bioMatcherConfigService.getSegmentIdBinIdMap().entrySet();
        } catch (Throwable th) {
            logger.error("Error while getSegmentIdEntryList: " + th.getMessage(), th);
            return Collections.emptySet();
        }
    }

    @RequestMapping(value = "/getServerGroupListIndex", method = RequestMethod.GET)
    public ModelAndView getServerGroupListIndex(HttpServletRequest request) {
        logger.debug("In BioManagerAdminController.getServerGroupListIndex");
        return new ModelAndView("servergroup.list");
    }

    @RequestMapping(value = "/getServerGroupList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getServerGroupList(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.getServerGroupList: " + new Date());
        List<BioServerGroupInfo> serverGroupInfoList = null;
        try {
            serverGroupInfoList = bioMatcherConfigService.getServerGroupInfoList();
        } catch (Throwable th) {
            serverGroupInfoList = Collections.emptyList();
            logger.error("Error in getServerGroupInfoList: " + th.getMessage(), th);
        }

        JsonArray jsonServerGroupArray = new JsonArray();
        if (CollectionUtils.isNotEmpty(serverGroupInfoList)) {
            for (BioServerGroupInfo bioServerGroupInfo : serverGroupInfoList) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(ServerGroupColumnOrder.GROUP_ID.name(), StringUtils.trimToEmpty(bioServerGroupInfo.getGroupId()));
                jsonObject.addProperty(ServerGroupColumnOrder.COMPONENT_TYPE.name(), bioServerGroupInfo.getComponentType().name());
                jsonObject.addProperty(ServerGroupColumnOrder.DESCRIPTION.name(), StringUtils.trimToEmpty(bioServerGroupInfo.getDescription()));
                jsonServerGroupArray.add(jsonObject);
            }
        }
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonServerGroupArray);
        logger.info("Total ServerGroup Records : " + serverGroupInfoList.size());
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getServerInfoListIndex", method = RequestMethod.GET)
    public ModelAndView getServerInfoListIndex(HttpServletRequest request) {
        logger.debug("In BioManagerAdminController.getServerInfoListIndex");
        return new ModelAndView("serverinfo.list");
    }

    @RequestMapping(value = "/getServerInfoList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getServerInfoList(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.getServerInfoList: " + new Date());
        List<BioServerInfo> serverInfoList = null;
        try {
            serverInfoList = bioMatcherConfigService.getServerInfoList();
        } catch (Throwable th) {
            serverInfoList = Collections.emptyList();
            logger.error("Error in getServerInfoList: " + th.getMessage(), th);
        }

        JsonArray jsonServerArray = new JsonArray();
        if (CollectionUtils.isNotEmpty(serverInfoList)) {
            for (BioServerInfo bioServerInfo : serverInfoList) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(ServerInfoColumnOrder.SERVER_ID.name(), StringUtils.trimToEmpty(bioServerInfo.getServerId()));
                jsonObject.addProperty(ServerInfoColumnOrder.SERVER_HOST.name(), bioServerInfo.getServerHost());
                jsonObject.addProperty(ServerInfoColumnOrder.SERVER_TYPE.name(), StringUtils.trimToEmpty(bioServerInfo.getServerType().name()));
                jsonObject.addProperty(ServerInfoColumnOrder.COMPONENT_TYPE.name(), StringUtils.trimToEmpty(bioServerInfo.getComponentType().name()));
                jsonObject.addProperty(ServerInfoColumnOrder.SERVER_STATE.name(), bioServerInfo.getServerState().name());
                jsonObject.addProperty(ServerInfoColumnOrder.MAX_JOB_COUNT.name(), MoreObjects.firstNonNull(bioServerInfo.getMaxJobCount(), new Integer(0)));
                jsonObject.addProperty(ServerInfoColumnOrder.SERVER_GROUP_ID.name(), bioServerInfo.getServerGroupId());
                jsonObject.addProperty(ServerInfoColumnOrder.SUB_SYSTEM_GROUP_ID.name(), StringUtils.trimToEmpty(bioServerInfo.getSubSystemGroupId()));
                jsonServerArray.add(jsonObject);
            }
        }
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonServerArray);
        logger.info("Total ServerInfo Records : " + serverInfoList.size());
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getServerConnectionInfoListIndex", method = RequestMethod.GET)
    public ModelAndView getServerConnectionInfoListIndex(HttpServletRequest request) {
        logger.debug("In BioManagerAdminController.getServerConnectionInfoListIndex");
        return new ModelAndView("serverconninfo.list");
    }

    @RequestMapping(value = "/getServerConnectionInfoList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getServerConnectionInfoList(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.getServerConnectionInfoList: " + new Date());
        List<BioServerConnectionInfo> serverConnectionInfoList = null;
        try {
            serverConnectionInfoList = bioMatcherConfigService.getServerConnectionInfoList();
        } catch (Throwable th) {
            serverConnectionInfoList = Collections.emptyList();
            logger.error("Error in getServerConnectionInfoList: " + th.getMessage(), th);
        }

        JsonArray jsonServerArray = new JsonArray();
        if (CollectionUtils.isNotEmpty(serverConnectionInfoList)) {
            for (BioServerConnectionInfo bioServerConnectionInfo : serverConnectionInfoList) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(ServerConnInfoColumnOrder.SERVER_ID.name(), StringUtils.trimToEmpty(bioServerConnectionInfo.getServerId()));
                jsonObject.addProperty(ServerConnInfoColumnOrder.COMPONENT_TYPE.name(), StringUtils.trimToEmpty(bioServerConnectionInfo.getComponentType().name()));
                jsonObject.addProperty(ServerConnInfoColumnOrder.CONNECTION_TYPE.name(), StringUtils.trimToEmpty(bioServerConnectionInfo.getConnectionType().name()));
                jsonObject.addProperty(ServerConnInfoColumnOrder.PROTOCOL_TYPE.name(), bioServerConnectionInfo.getProtocolType().name());
                jsonObject.addProperty(ServerConnInfoColumnOrder.CONNECTION_URL.name(), bioServerConnectionInfo.getConnectionUrl());
                jsonServerArray.add(jsonObject);
            }
        }
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonServerArray);
        logger.info("Total ServerConnectionInfo Records : " + serverConnectionInfoList.size());
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getMatcherBinListIndex", method = RequestMethod.GET)
    public ModelAndView getMatcherBinListIndex(HttpServletRequest request) {
        logger.debug("In BioManagerAdminController.getMatcherBinListIndex");
        return new ModelAndView("matcherbin.list");
    }

    @RequestMapping(value = "/getMatcherBinList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getMatcherBinList(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.getMatcherBinList: " + new Date());
        List<BioMatcherBinInfo> bioMatcherBinInfoList = Collections.emptyList();
        Map<Integer, MeghaTemplateParser> binIdMeghaTemplateParserMap = new HashMap<>();
        try {
            bioMatcherBinInfoList = bioMatcherConfigService.getMatcherBinInfoList();
            binIdMeghaTemplateParserMap = bioMatcherConfigService.getBinIdMeghaTemplateParserMap();
        } catch (Throwable th) {
            bioMatcherBinInfoList = Collections.emptyList();
            logger.error("Error in getServerInfoList: " + th.getMessage(), th);
        }

        JsonArray jsonServerArray = new JsonArray();
        if (CollectionUtils.isNotEmpty(bioMatcherBinInfoList)) {
            for (BioMatcherBinInfo bioMatcherBinInfo : bioMatcherBinInfoList) {
                MeghaTemplateParser meghaTemplateParser = binIdMeghaTemplateParserMap.get(bioMatcherBinInfo.getBinId());

                // BIN_ID, TEMPLATE_TYPE, MAX_EVENT_COUNT, EVENT_DATA_SIZE, TEMPLATE_DATA_SIZE, DESCRIPTION
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(MatcherBinInfoColumnOrder.BIN_ID.name(), bioMatcherBinInfo.getBinId());
                jsonObject.addProperty(MatcherBinInfoColumnOrder.TEMPLATE_TYPE.name(), bioMatcherBinInfo.getTemplateType());

                if (meghaTemplateParser != null) {
                    jsonObject.addProperty(MatcherBinInfoColumnOrder.MAX_EVENT_COUNT.name(), meghaTemplateParser.getMaxEventCount());
                    jsonObject.addProperty(MatcherBinInfoColumnOrder.EVENT_DATA_SIZE.name(), meghaTemplateParser.getEventDataSize());
                    jsonObject.addProperty(MatcherBinInfoColumnOrder.TEMPLATE_DATA_SIZE.name(), meghaTemplateParser.getTemplateDataSize());
                    jsonObject.addProperty(MatcherBinInfoColumnOrder.DESCRIPTION.name(), meghaTemplateParser.getTemplateType().getDescription());
                } else {
                    jsonObject.addProperty(MatcherBinInfoColumnOrder.MAX_EVENT_COUNT.name(), -1);
                    jsonObject.addProperty(MatcherBinInfoColumnOrder.EVENT_DATA_SIZE.name(), -1);
                    jsonObject.addProperty(MatcherBinInfoColumnOrder.TEMPLATE_DATA_SIZE.name(), -1);
                    jsonObject.addProperty(MatcherBinInfoColumnOrder.DESCRIPTION.name(), "Configuration Error!");
                }

                jsonServerArray.add(jsonObject);
            }
        }
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonServerArray);
        logger.info("Total BioMatcherBinInfo Records : " + bioMatcherBinInfoList.size());
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getMatcherSegmentListIndex", method = RequestMethod.GET)
    public ModelAndView getMatcherSegmentListIndex(HttpServletRequest request) {
        logger.debug("In BioManagerAdminController.getMatcherSegmentListIndex");
        return new ModelAndView("matchersegment.list");
    }

    @RequestMapping(value = "/getMatcherSegmentList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getMatcherSegmentList(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.getMatcherSegmentList: " + new Date());
        List<BioMatcherSegmentInfo> bioMatcherSegmentInfoList = null;
        try {
            bioMatcherSegmentInfoList = bioMatchManagerService.getMatcherSegmentInfoList();
        } catch (Throwable th) {
            bioMatcherSegmentInfoList = Collections.emptyList();
            logger.error("Error in getMatcherSegmentInfoList: " + th.getMessage(), th);
        }

        Map<Integer, BiometricIdInfo> segmentIdBiometricIdInfoMap = null;

        JsonArray jsonServerArray = new JsonArray();
        if (CollectionUtils.isNotEmpty(bioMatcherSegmentInfoList)) {
            for (BioMatcherSegmentInfo bioMatcherSegmentInfo : bioMatcherSegmentInfoList) {
                Long startBiometricId = null;
                Long endBiometricId = null;
                Long currentBiometricId = null;

                String assignedSearchNodeIds = "";
                try {
                    if (segmentIdBiometricIdInfoMap == null) {
                        segmentIdBiometricIdInfoMap = bioMatcherConfigService.getSegmentIdBiometricIdInfoMap();
                    }

                    BiometricIdInfo biometricIdInfo = segmentIdBiometricIdInfoMap.get(bioMatcherSegmentInfo.getSegmentId());
                    if (biometricIdInfo != null) {
                        startBiometricId = Math.max(1L, biometricIdInfo.getStartBiometricId());
                        endBiometricId = biometricIdInfo.getEndBiometricId();
                        currentBiometricId = biometricIdInfo.getCurrentBiometricId();
                    }

                    Set<String> assignedSearchNodeIdSet = bioMatcherConfigService.getAssignedSearchNodeIdListBySegmentId(bioMatcherSegmentInfo.getSegmentId());
                    if (CollectionUtils.isNotEmpty(assignedSearchNodeIdSet)) {
                        assignedSearchNodeIds = StringUtils.join(assignedSearchNodeIdSet, ",");
                    }
                } catch (Throwable th) {
                    logger.error("Error while getBiometricIdInfo for segmentId: " + bioMatcherSegmentInfo.getSegmentId());
                }

                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(MatcherSegmentInfoColumnOrder.SEGMENT_ID.name(), bioMatcherSegmentInfo.getSegmentId());
                jsonObject.addProperty(MatcherSegmentInfoColumnOrder.BIN_ID.name(), bioMatcherSegmentInfo.getBinId());
                jsonObject.addProperty(MatcherSegmentInfoColumnOrder.SEGMENT_VERSION.name(), bioMatcherSegmentInfo.getSegmentVersion());
                jsonObject.addProperty(MatcherSegmentInfoColumnOrder.START_BIO_ID.name(), startBiometricId != null ? startBiometricId.toString() : "");
                jsonObject.addProperty(MatcherSegmentInfoColumnOrder.END_BIO_ID.name(), endBiometricId != null ? endBiometricId.toString() : "");
                jsonObject.addProperty(MatcherSegmentInfoColumnOrder.CURRENT_BIOMETRIC_ID.name(), currentBiometricId != null ? currentBiometricId.toString() : "");
                jsonObject.addProperty(MatcherSegmentInfoColumnOrder.ASSIGNED_SEARCH_NODES.name(), assignedSearchNodeIds);
                jsonObject.addProperty(MatcherSegmentInfoColumnOrder.UPDATE_DATETIME.name(), bioMatcherSegmentInfo.getUpdateDateTime() != null ? DateUtil.parseDate(bioMatcherSegmentInfo.getUpdateDateTime(), DateUtil.FORMAT_YYYY_MM_DD_HH_MM_SS) : "");

                jsonServerArray.add(jsonObject);
            }
        }
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonServerArray);
        logger.info("Total BioMatcherSegmentInfo Records : " + bioMatcherSegmentInfoList.size());
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getMatcherNodeSegmentListIndex", method = RequestMethod.GET)
    public ModelAndView getMatcherNodeSegmentListIndex(HttpServletRequest request) {
        logger.debug("In BioManagerAdminController.getMatcherNodeSegmentListIndex");
        return new ModelAndView("matchernodesegment.list");
    }

    @RequestMapping(value = "/getMatcherNodeSegmentList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getMatcherNodeSegmentList(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.getMatcherNodeSegmentList: " + new Date());
        List<BioMatcherNodeSegmentInfo> bioMatcherNodeSegmentInfoList = null;
        try {
            bioMatcherNodeSegmentInfoList = bioMatchManagerService.getMatcherNodeSegmentInfoList();
        } catch (Throwable th) {
            bioMatcherNodeSegmentInfoList = Collections.emptyList();
            logger.error("Error in getMatcherNodeSegmentInfoList: " + th.getMessage(), th);
        }

        JsonArray jsonServerArray = new JsonArray();
        if (CollectionUtils.isNotEmpty(bioMatcherNodeSegmentInfoList)) {
            for (BioMatcherNodeSegmentInfo bioMatcherNodeSegmentInfo : bioMatcherNodeSegmentInfoList) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(MatcherNodeSegmentInfoColumnOrder.MATCHER_NODE_ID.name(), bioMatcherNodeSegmentInfo.getMatcherNodeId());
                jsonObject.addProperty(MatcherNodeSegmentInfoColumnOrder.SEGMENT_ID.name(), bioMatcherNodeSegmentInfo.getSegmentId());
                jsonObject.addProperty(MatcherNodeSegmentInfoColumnOrder.SEGMENT_VERSION.name(), bioMatcherNodeSegmentInfo.getSegmentVersion());
                jsonObject.addProperty(MatcherNodeSegmentInfoColumnOrder.ASSIGNED_FLAG.name(), bioMatcherNodeSegmentInfo.getAssignedFlag());
                jsonObject.addProperty(MatcherNodeSegmentInfoColumnOrder.UPDATE_DATETIME.name(), bioMatcherNodeSegmentInfo.getUpdateDateTime() != null ? DateUtil.parseDate(bioMatcherNodeSegmentInfo.getUpdateDateTime(), DateUtil.FORMAT_YYYY_MM_DD_HH_MM_SS) : "");

                jsonServerArray.add(jsonObject);
            }
        }
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonServerArray);
        logger.info("Total BioMatcherNodeSegmentInfo Records : " + bioMatcherNodeSegmentInfoList.size());
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getReSegmentationListIndex", method = RequestMethod.GET)
    public ModelAndView getReSegmentListIndex(HttpServletRequest request) {
        logger.debug("In BioManagerAdminController.getReSegmentationListIndex");
        return new ModelAndView("resegmentation.list");
    }

    @RequestMapping(value = "/getReSegmentationList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getReSegmentationList(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.getReSegmentationList: " + new Date());

        if (bioSearchControllerManager.getSearchControllerId() == null) {
            return new ResponseEntity<>("Re-Segmentation can be only done from Search Controller server", HttpStatus.BAD_REQUEST);
        }

        final com.hazelcast.core.IMap<Integer, String> createFullSegmentFileRequestMap = bioSearchControllerManager.getCreateFullSegmentFileRequestMap();
        JsonArray jsonServerArray = new JsonArray();
        try {

            TreeMap<Integer, Integer> segmentIdBinIdMap = new TreeMap<Integer, Integer>(bioMatcherConfigService.getSegmentIdBinIdMap());

            for (Integer segmentId : segmentIdBinIdMap.keySet()) {
                Integer binId = segmentIdBinIdMap.get(segmentId);

                Long segmentVersion = 0L;
                try {
                    BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatchManagerService.getMatcherSegmentInfo(segmentId);
                    segmentVersion = bioMatcherSegmentInfo.getSegmentVersion();
                } catch (Throwable th) {
                    logger.error("Error in getMatcherSegmentInfo for segmentId: " + segmentId + " : " + th.getMessage(), th);
                }

                String status = createFullSegmentFileRequestMap.get(segmentId);
                if (status == null) {
                    status = "";
                }

                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("SEGMENT_ID", segmentId);
                jsonObject.addProperty("BIN_ID", binId);
                jsonObject.addProperty("SEGMENT_VERSION", segmentVersion);
                jsonObject.addProperty("STATUS", status);
                jsonServerArray.add(jsonObject);
            }
        } catch (Throwable th) {
            logger.error("Error in getReSegmentationList: " + th.getMessage(), th);
            return new ResponseEntity<>("Error during getReSegmentationList: " + th.getMessage(), HttpStatus.BAD_REQUEST);
        }

        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonServerArray);
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/submitReSegmentRequest", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> submitReSegmentRequest(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.submitReSegmentRequest: segmentId: " + request.getParameter("segmentId"));

        if (bioSearchControllerManager.getSearchControllerId() == null) {
            return new ResponseEntity<>("Re-Segmentation can be only done from Search Controller server", HttpStatus.BAD_REQUEST);
        }

        Integer segmentId = StringUtil.stringToInt(request.getParameter("segmentId"));
        if (segmentId == null) {
            return new ResponseEntity<>("Invalid Segment Id", HttpStatus.BAD_REQUEST);
        }

        try {
            BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatcherConfigService.getSegmentIdMatcherSegmentInfoMap().get(segmentId);
            if (bioMatcherSegmentInfo == null) {
                return new ResponseEntity<>("Matcher Segment not found for segmentId : " + segmentId, HttpStatus.BAD_REQUEST);
            }

            bioSearchControllerManager.submitReSegmentationRequest(segmentId);

            return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
        } catch (Throwable th) {
            logger.error("Error in submitReSegmentRequest for segmentId: " + segmentId + " : " + th.getMessage(), th);
            return new ResponseEntity<>("Error during submitReSegmentRequest for segmentId: " + segmentId + " : " + th.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @RequestMapping(value = "/submitReSegmentBinRequest", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> submitReSegmentBinRequest(HttpServletRequest request) {
        logger.info("In BioManagerAdminController.submitReSegmentBinRequest: binId: " + request.getParameter("binId"));

        if (bioSearchControllerManager.getSearchControllerId() == null) {
            return new ResponseEntity<>("Re-Segmentation can be only done from Search Controller server", HttpStatus.BAD_REQUEST);
        }

        Integer binId = StringUtil.stringToInt(request.getParameter("binId"));
        if (binId == null) {
            return new ResponseEntity<>("Invalid Bin Id", HttpStatus.BAD_REQUEST);
        }

        try {
            List<BioMatcherSegmentInfo> matcherSegmentInfoList = bioMatchManagerService.getMatcherSegmentInfoListByBinId(binId);
            for (BioMatcherSegmentInfo bioMatcherSegmentInfo : matcherSegmentInfoList) {
                if (bioMatcherSegmentInfo.getSegmentVersion() != null && bioMatcherSegmentInfo.getSegmentVersion() > 0) {
                    bioSearchControllerManager.submitReSegmentationRequest(bioMatcherSegmentInfo.getSegmentId());
                } else {
                    logger.info("In submitReSegmentBinRequest: No data in segment for segmentId: " + bioMatcherSegmentInfo.getSegmentId() + ", currentSegmentVersion: " + bioMatcherSegmentInfo.getSegmentVersion());
                }
            }

            return new ResponseEntity<String>("SUCCESS", HttpStatus.OK);
        } catch (Throwable th) {
            logger.error("Error in submitReSegmentBinRequest for binId: " + binId + " : " + th.getMessage(), th);
            return new ResponseEntity<>("Error during submitReSegmentBinRequest for binId: " + binId + " : " + th.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @RequestMapping(value = "/saveServerGroupInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> saveServerGroupInfo(HttpServletRequest request, BioServerGroupInfo bioServerGroupInfo) {
        try {
            bioMatcherConfigService.saveServerGroupInfo(bioServerGroupInfo);
            return new ResponseEntity<>(this.getMessage("messages.common.save.success", new Object[] { "Server Group", bioServerGroupInfo.getGroupId() }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in saveServerGroupInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.save.failed", new Object[] { "Server Group", bioServerGroupInfo.getGroupId() }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/deleteServerGroup", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> deleteServerGroup(HttpServletRequest request) {
        String groupId = request.getParameter("groupId");
        try {
            bioMatcherConfigService.deleteServerGroupInfo(groupId);
            return new ResponseEntity<>(this.getMessage("messages.common.delete.success", new Object[] { "Server Group", groupId }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in deleteServerGroup: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.delete.failed", new Object[] { "Server Group", groupId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/importServerInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> importServerInfo(MultipartHttpServletRequest request, HttpServletResponse response) {

        try {
            BioComponentType componentType = BioComponentType.valueOf(request.getParameter("componentType"));
            BioServerType serverType = BioServerType.valueOf(request.getParameter("serverType"));
            BioServerState serverState = BioServerState.valueOf(request.getParameter("serverState"));
            String serverGroupId = request.getParameter("serverGroupId");
            String subSystemGroupId = request.getParameter("subSystemGroupId");
            Integer maxJobCount = StringUtil.stringToInt(request.getParameter("maxJobCount"));

            Set<String> serverHostList = new HashSet<>();
            MultipartFile multipartFile = request.getFile("serverListFile");
            try (InputStream stream = multipartFile.getInputStream(); BufferedReader br = new BufferedReader(new InputStreamReader(stream))) {
                String serverHost = null;
                while ((serverHost = br.readLine()) != null) {
                    serverHostList.add(serverHost);
                }
            }

            List<BioServerInfo> bioServerInfoList = bioMatcherConfigService.getServerInfoListByComponentType(componentType);
            Set<String> currentServerIdSet = bioServerInfoList.stream().map(serverInfo -> serverInfo.getServerId()).collect(Collectors.toSet());

            int maxIdIndex = 0;
            for (String serverHost : serverHostList) {
                BioServerInfo bioServerInfo = new BioServerInfo();
                bioServerInfo.setServerHost(serverHost);
                bioServerInfo.setComponentType(componentType);
                bioServerInfo.setServerState(serverState);
                bioServerInfo.setServerType(serverType);
                bioServerInfo.setServerGroupId(serverGroupId);
                bioServerInfo.setSubSystemGroupId(subSystemGroupId);
                bioServerInfo.setCreateDateTime(new Date());
                bioServerInfo.setUpdateDateTime(new Date());
                bioServerInfo.setMaxJobCount(maxJobCount);

                while (maxIdIndex < Integer.MAX_VALUE) {
                    int nextIndex = ++maxIdIndex;
                    String serverId = componentType.name() + StringUtils.leftPad("" + nextIndex, 4, "0");
                    if (currentServerIdSet.contains(serverId)) {
                        continue;
                    }
                    bioServerInfo.setServerId(serverId);
                    currentServerIdSet.add(serverId);
                    break;
                }
                bioMatcherConfigService.saveServerInfo(bioServerInfo);
            }
            return new ResponseEntity<>("Imported Servers successfully", HttpStatus.OK);
        } catch (Throwable th) {
            logger.error("Error in importServerInfo: " + th.getMessage(), th);
            return new ResponseEntity<>("Error in importServerInfo: " + th.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/saveServerInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> saveServerInfo(HttpServletRequest request, BioServerInfo bioServerInfo) {
        try {
            bioMatcherConfigService.saveServerInfo(bioServerInfo);
            return new ResponseEntity<>(this.getMessage("messages.common.save.success", new Object[] { "Server", bioServerInfo.getServerId() }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in saveServerInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.save.failed", new Object[] { "Server", bioServerInfo.getServerId() }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/deleteServerInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> deleteServerInfo(HttpServletRequest request) {
        String serverId = request.getParameter("serverId");
        try {
            bioMatcherConfigService.deleteServerInfo(serverId);
            return new ResponseEntity<>(this.getMessage("messages.common.delete.success", new Object[] { "Server", serverId }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in deleteServerInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.delete.failed", new Object[] { "Server", serverId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/saveServerConnectionInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> saveServerConnectionInfo(HttpServletRequest request, BioServerConnectionInfo bioServerConnectionInfo) {
        try {
            bioMatcherConfigService.saveServerConnectionInfo(bioServerConnectionInfo);
            return new ResponseEntity<>(this.getMessage("messages.common.save.success", new Object[] { "Connection", bioServerConnectionInfo.getServerId() }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in saveServerConnectionInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.save.failed", new Object[] { "Connection", bioServerConnectionInfo.getServerId() }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/deleteServerConnectionInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> deleteServerConnectionInfo(HttpServletRequest request) {
        String serverId = request.getParameter("serverId");
        String componentType = request.getParameter("componentType");
        String connectionType = request.getParameter("connectionType");
        try {
            bioMatcherConfigService.deleteServerConnectionInfo(serverId, BioComponentType.valueOf(componentType), BioConnectionType.valueOf(connectionType));
            return new ResponseEntity<>(this.getMessage("messages.common.delete.success", new Object[] { "Connection", serverId }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in deleteServerConnectionInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.delete.failed", new Object[] { "Connection", serverId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/saveMatcherBinInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> saveMatcherBinInfo(HttpServletRequest request, BioMatcherBinInfo bioMatcherBinInfo) {
        try {
            bioMatcherConfigService.saveMatcherBinInfo(bioMatcherBinInfo);
            return new ResponseEntity<>(this.getMessage("messages.common.save.success", new Object[] { "Bin", bioMatcherBinInfo.getBinId() }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in saveMatcherBinInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.save.failed", new Object[] { "Bin", bioMatcherBinInfo.getBinId() }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/deleteMatcherBinInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> deleteMatcherBinInfo(HttpServletRequest request) {
        Integer binId = Ints.tryParse(request.getParameter("binId"));
        try {
            bioMatcherConfigService.deleteMatcherBinInfo(binId);
            return new ResponseEntity<>(this.getMessage("messages.common.delete.success", new Object[] { "Bin", binId }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in deleteMatcherBinInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.delete.failed", new Object[] { "Bin", binId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/autoCreateAndAssignSegments", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> autoCreateAndAssignSegments(HttpServletRequest request) {
        Integer binId = StringUtil.stringToInt(request.getParameter("binId"));
        Long totalRecords = StringUtil.stringToLong(request.getParameter("totalRecords"));
        Long maxRecordsPerSegment = StringUtil.stringToLong(request.getParameter("maxRecordsPerSegment"));
        Integer snRamSize = StringUtil.stringToInt(request.getParameter("snRamSize"));
        Integer segmentRedundancy = StringUtil.stringToInt(request.getParameter("segmentRedundancy"));
        String assignedSearchNodes[] = request.getParameterValues("assignedSearchNodes");

        try {
            bioMatcherConfigService.autoCreateAndAssignSegments(binId, totalRecords, maxRecordsPerSegment, snRamSize, segmentRedundancy, assignedSearchNodes);

            return new ResponseEntity<>("Assigned successfully", HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in autoCreateSegments: " + th.getMessage(), th);
            return new ResponseEntity<>("Error during autoCreateAndAssignSegments for binId: " + binId + " : " + th.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/saveMatcherSegmentInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> saveMatcherSegmentInfo(HttpServletRequest request) {
        Integer segmentId = Ints.tryParse(request.getParameter("segmentId"));
        Integer binId = Ints.tryParse(request.getParameter("binId"));
        Long startBiometricId = Longs.tryParse(request.getParameter("startBiometricId"));
        Long endBiometricId = Longs.tryParse(request.getParameter("endBiometricId"));
        String assignedSearchNodes = StringUtils.join(request.getParameterValues("assignedSearchNodes"), ",");

        try {
            bioMatcherConfigService.saveMatcherSegmentInfo(segmentId, binId, startBiometricId, endBiometricId, assignedSearchNodes);
            return new ResponseEntity<>(this.getMessage("messages.common.save.success", new Object[] { "Segment", segmentId }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in saveMatcherSegmentInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.save.failed", new Object[] { "Segment", segmentId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/deleteMatcherSegmentInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> deleteMatcherSegmentInfo(HttpServletRequest request) {
        Integer segmentId = Ints.tryParse(request.getParameter("segmentId"));
        try {
            bioMatcherConfigService.deleteMatcherSegmentInfo(segmentId);
            return new ResponseEntity<>(this.getMessage("messages.common.delete.success", new Object[] { "Segment", segmentId }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in deleteMatcherSegmentInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.delete.failed", new Object[] { "Segment", segmentId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/updateMatcherNodeSegmentInfo", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> updateMatcherNodeSegmentInfo(HttpServletRequest request) {
        String matcherNodeIdSegmentId = request.getParameter("pk");
        String matcherNodeId = StringUtils.trimToNull(StringUtils.substringBefore(matcherNodeIdSegmentId, "&"));
        Integer segmentId = Ints.tryParse(StringUtils.trimToNull(StringUtils.substringAfter(matcherNodeIdSegmentId, "&")));
        String updatedColName = StringUtils.trimToNull(request.getParameter("name"));
        String updatedColValue = StringUtils.trimToNull(request.getParameter("value"));

        if (matcherNodeId == null || segmentId == null || updatedColName == null || updatedColValue == null) {
            logger.error("Invalid input in updateMatcherNodeSegmentInfo");
            return new ResponseEntity<>(this.getMessage("errors.common.update.failed", new Object[] { "Segment", segmentId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }

        try {
            if (updatedColName.equals("assignedFlag")) {
                bioMatcherConfigService.saveMatcherNodeSegmentInfo(matcherNodeId, segmentId, Boolean.valueOf(updatedColValue), null);
            } else if (updatedColName.equals("segmentVersion") && Longs.tryParse(updatedColValue) != null) {
                BioMatcherNodeSegmentInfo bioMatcherNodeSegmentInfo = bioMatchManagerService.getMatcherNodeSegmentInfo(matcherNodeId, segmentId);
                bioMatcherConfigService.saveMatcherNodeSegmentInfo(matcherNodeId, segmentId, bioMatcherNodeSegmentInfo.getAssignedFlag(), Longs.tryParse(updatedColValue));
            }

            return new ResponseEntity<>(this.getMessage("messages.common.update.success", new Object[] { "Segment", segmentId }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in updateMatcherNodeSegmentInfo: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.common.update.failed", new Object[] { "Segment", segmentId }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
