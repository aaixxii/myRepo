package com.nec.biomatcher.web.modules.common;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.context.ServletContextAware;

import com.nec.biomatcher.core.framework.web.session.UserSession;

public abstract class BaseAction implements ServletContextAware {
	public final static String MODE_EDIT = "edit";

	public final static String MODE_ADD = "add";

	public final static String HOME = "home";

	protected Logger logger = Logger.getLogger(this.getClass().getName());

	private static final long serialVersionUID = 1L;

	protected Map<String, Object> application;

	protected Map<String, Object> session;

	protected HttpServletRequest request;

	protected HttpServletResponse response;

	protected ServletContext servletContext;

	private boolean requireValidation;

	private String functionId;

	public final String GENERIC_ERROR_PAGE = "IDSERVER_GENERIC_ERROR_PAGE";

	public UserSession getUserSession(HttpServletRequest request) {
		return (UserSession) request.getSession().getAttribute(UserSession.attributeName);
	}

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	/**
	 * @return the functionId
	 */
	public String getFunctionId() {
		return functionId;
	}

	/**
	 * @param functionId
	 *            the functionId to set
	 */
	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	/**
	 * @return the requireValidation
	 */
	public boolean isRequireValidation() {
		return requireValidation;
	}

	/**
	 * @param requireValidation
	 *            the requireValidation to set
	 */
	public void setRequireValidation(boolean requireValidation) {
		this.requireValidation = requireValidation;
	}

	/**
	 * @return the servletContext
	 */
	public ServletContext getServletContext() {
		return servletContext;
	}

	/**
	 * @param servletContext
	 *            the servletContext to set
	 */
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public Map getSession() {
		return session;
	}

	/**
	 * @param session
	 *            the session to set
	 */
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	/**
	 * @return the application
	 */
	public Map getApplication() {
		return application;
	}

	/**
	 * @param application
	 *            the application to set
	 */
	public void setApplication(Map<String, Object> application) {
		this.application = application;
	}

	protected String getSessionId() {
		return getRequest().getSession().getId();
	}

	/**
	 * @return the response
	 */
	public HttpServletResponse getResponse() {
		return response;
	}

	public HttpServletRequest getRequest() {
		return request;
	}

	public void preparePageRequest(List resultList, Integer totalRecords, Integer pageSize) {
		if (resultList != null) {
			this.getRequest().setAttribute("resultArr", resultList);
			this.getRequest().setAttribute("totalRecords", totalRecords);
			this.getRequest().setAttribute("pageSize", pageSize);
		}
	}
}
