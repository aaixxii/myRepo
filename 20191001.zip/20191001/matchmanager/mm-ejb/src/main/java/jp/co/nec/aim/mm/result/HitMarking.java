package jp.co.nec.aim.mm.result;

import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HitMarking {
	private static Logger log = LoggerFactory.getLogger(HitMarking.class);

	public static void markHits(PBInquiryJobResult.Builder finalResults,
			DynamicThresholdParams params) {
		int iCandidateCount = finalResults.getCandidateList()
				.getCandidateCount();
		if (0 < iCandidateCount) {
			DynamicThresholdNew dynth = new DynamicThresholdNew(
					iCandidateCount, params);
			for (int i = 0; i < iCandidateCount; ++i) {
				// set each score
				dynth.dynthScoreList.dynthRecords[i].fusionScore = finalResults
						.getCandidateList().getCandidate(i).getFusionScore();
			}

			// perform decision method
			dynth.perform();

			// mark the hits.
			for (int i = 0; i < iCandidateCount; ++i) {
				if (dynth.dynthScoreList.dynthRecords[i].hitFlag == 1) {
					finalResults.getCandidateListBuilder()
							.getCandidateBuilder(i).setHitFlag(true);
				}
			}
		} else {
			log.debug("No candidates found for job " + finalResults.getJobId()
					+ ", skipping dynamic thresholding logic.");
		}
	}
}
