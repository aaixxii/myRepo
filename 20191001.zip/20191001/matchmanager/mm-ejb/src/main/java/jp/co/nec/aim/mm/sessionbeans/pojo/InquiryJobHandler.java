package jp.co.nec.aim.mm.sessionbeans.pojo;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.mm.aggregator.Aggregator;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.AggregatorDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
public class InquiryJobHandler {
	private static Logger log = LoggerFactory
			.getLogger(InquiryJobHandler.class);
	private EntityManager manager;
	private InquiryJobDao inquiryJobDao;
	private SystemConfigDao systemConfigDao;
	private AggregatorDao aggregatorDao;
	private Aggregator aggregator;

	/**
	 * Constructor is called by Java EE Container.
	 */
	public InquiryJobHandler(EntityManager entityManager,
			DataSource dataSource, Aggregator aggregator) {
		this.manager = entityManager;
		inquiryJobDao = new InquiryJobDao(entityManager);
		systemConfigDao = new SystemConfigDao(manager);
		aggregatorDao = new AggregatorDao(dataSource);
		this.aggregator = aggregator;
	}

	/**
	 * processForceQuitJob
	 * 
	 * @param containerJobId
	 * @param errCode
	 * @param errReason
	 * @param errTime
	 */
	public void failInquiryJob(long containerJobId, String errCode,
			String errReason, PBBusinessMessage result, String errTime) {
		manager.flush();		
		PBServiceState.Builder serviceBuilder = PBServiceState.newBuilder();
		serviceBuilder.setState(ServiceStateType.SERVICE_STATE_ROLLBACK)
				.setReason(
						PBServiceStateReason.newBuilder().setCode(errCode)
								.setDescription(errReason).setTime(errTime));
		
		failInquiryJob(containerJobId, null, serviceBuilder.build(), result.toByteArray(), false);
				
	}

	/**
	 * processForceQuitJob
	 * 
	 * @param containerJobId
	 * @param segmentId
	 * @param errCode
	 * @param errReason
	 * @param errTime
	 * @param bErr
	 *            ： false->ROLLBACK and TIMEOUT ERROR.true->ERROR
	 */
	public void failInquiryJob(long containerJobId, Long segmentId,
			PBServiceState serviceState, byte[] bJobResult, boolean bErr) {
		ContainerJobEntity containerJob = inquiryJobDao
				.getContainerJob(containerJobId);
		/* containerJob is null */
		if (null == containerJob) {
			// containerJob is removed.
			log.warn("Container_Job_ID:{} is already removed", new Long(
					containerJobId));
			return;
		}
		manager.refresh(containerJob);
		/* plan Id is null */
		if (null == containerJob.getPlanId()) {
			// containerJob is already retry.
			log.warn("Container_Job_ID:{} is already retryed", new Long(
					containerJobId));
			return;
		}
		/* get SystemConfig's MAX_JOB_FAILURES */
		int maxJobfailure = systemConfigDao
				.getMMPropertyInt(MMConfigProperty.MAX_JOB_FAILURES);

		JobQueueEntity jobQueue = inquiryJobDao.getJobQueue(containerJobId);
		if (true == bErr || jobQueue.getFailureCount() >= maxJobfailure - 1) {
			long jobId = aggregatorDao.failJobResult(serviceState, bJobResult,
					containerJobId, segmentId);

			if (0 < jobId) {
				log.info("Ready to Aggregate the failed top"
						+ " level job: {} asynchronously..",
						jobQueue.getJobId());
				aggregator.doAggregation(jobQueue.getJobId());
			} else if (jobId == -1) {
				log.warn(
						"Unaggregated JOB_QUEUE record( id={} ) was not found",
						jobId);
			} else if (jobId == -2) {
				log.warn(
						"Couldn't lock TopLevelJob ID:{} of CONTAINER_JOB_ID:{} "
								+ "due to Resource is busy, skip do Aggregate the failed top "
								+ "level job.", containerJobId,
						jobQueue.getJobId());
			} else {
				log.warn("failInquiryJob returned Job_Id:" + jobId
						+ "  for CONTAINER_JOB_ID:" + containerJobId
						+ " It's not supported");
			}
		} else {
			// send JMS TO PLANNER
			if (retryJob(jobQueue.getJobId())) {
				/* send Jms to IdentifyPlanner */
				JmsSender.getInstance().sendToInquiryJobPlanner(
						NotifierEnum.InquiryJobHandler,
						"send msg to IdentifyPlanner");// TODO queueName msg
			}
		}
	}

	/**
	 * retryJob
	 * 
	 * @param topLevelJobId
	 * @return
	 */
	private boolean retryJob(long topLevelJobId) {
		long result = aggregatorDao.retryJob(topLevelJobId);
		if (result >= 0) {
			if (log.isDebugEnabled()) {
				log.debug(
						"JOB_ID:{} was failed and send Message to IdentifyPlanner",
						topLevelJobId);
			}
			return true;
		}
		if (log.isDebugEnabled()) {
			log.debug(
					"JOB_ID:{} was failed, but do not send Message to IdentifyPlanner",
					topLevelJobId);
		}
		return false;
	}

	/**
	 * check the top level Job is necessary to aggregation
	 * 
	 * @param jobId
	 *            top level job id
	 */
	public void checkJob(long jobId) {
		long numUnfinishedJobs = inquiryJobDao.countUnfinishedForJob(jobId);
		if (numUnfinishedJobs == 0) {
			aggregator.doAggregation(jobId);
		} else {
			if (log.isDebugEnabled()) {
				log.debug("Top level job " + jobId + " still has "
						+ numUnfinishedJobs
						+ " container jobs to process, not aggregating yet...");
			}
		}
	}

}
