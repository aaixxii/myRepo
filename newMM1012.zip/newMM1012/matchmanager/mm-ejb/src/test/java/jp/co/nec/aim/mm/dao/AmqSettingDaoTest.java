/**this is file AmqSettingDaoTest.java
 * @author xia
   @date 2020/07/18
 */
package jp.co.nec.aim.mm.dao;


import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.mm.entities.RqSettingEntity;

/**
 * @author xia
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class AmqSettingDaoTest {
	
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	
	@Resource
	private JdbcTemplate jdbcTemplate;
	
	private AmqSettingDao amqDao;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		amqDao = new AmqSettingDao(entityManager);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	
	@Test
	public void testFindAmqSetting() {
		RqSettingEntity setting = amqDao.findAmqSetting("extReqSetting");
		Assert.assertNotNull(setting);
		Assert.assertEquals("extReqSetting", setting.getId());		
	}
	
	@Test
	public void testFindAllAmqSetting() {
		List<RqSettingEntity> result = amqDao.findAllAmqSetting();	
		Assert.assertNotNull(result);
		Assert.assertEquals(6, result.size());
	}

	@Test
	public void testUpdateMasterNode() {
		Timestamp newTs = new Timestamp(System.currentTimeMillis());		
		int updated = amqDao.updateMasterNode("newNodeMaster", newTs, "extReqSetting");
		Assert.assertEquals(1, updated);
		System.out.print("OKOK");
	}
	
	@Test
	public void testUpdateMqEntity() {	
		Timestamp newTs = new Timestamp(System.currentTimeMillis());		
		RqSettingEntity setting = amqDao.findAmqSetting("extReqSetting");
		setting.setMasterNode("newNode");
		setting.setTs(newTs);
		RqSettingEntity last = amqDao.updateMqEntity(setting);
		Assert.assertEquals("newNode", last.getMasterNode());
		Assert.assertEquals(newTs, last.getTs());
		jdbcTemplate.execute("commit");
	}
}
