package jp.co.nec.aim.mm.sessionbeans;

import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.ReferenceCountDao;
import jp.co.nec.aim.mm.exception.UiDaiValidatorException;
import jp.co.nec.aim.mm.util.XmlUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class GetReferenceCountBean {

	private static final Logger log = LoggerFactory.getLogger(GetReferenceCountBean.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private ReferenceCountDao referenceCountDao;

	@PostConstruct
	public void init() {
		referenceCountDao = new ReferenceCountDao(dataSource);
	}

	public String getRefCnt(String req) {
		String res = null;
		try {
			String rootElement = XmlUtil.getRootElement(req);
			String reqId = XmlUtil.getRequestId(req);
			String cmd = XmlUtil.getXmlCmd(req);
			try {
				// Check request
				AcceptorValidator.checkGetRefCntRequest(rootElement, reqId, cmd);
				// Get reference count
				Long refCnt = referenceCountDao.getRefCnt();
				if (refCnt == null) {
					log.warn("The value of the obtained reference count was null.");
					res = createFailResponse(reqId, "1");
				} else {
					res = createSuccesResponse(reqId, refCnt.toString());
				}
			} catch (UiDaiValidatorException e) {
				log.error("An unexpected exception has occurred when check requestXml.", e);
				res = createFailResponse(reqId, e.getUidCode());
			} catch (SQLException e) {
				log.error("An unexpected exception has occurred when db access.", e);
				res = createFailResponse(reqId, "1");
			}
		} catch (IOException e) {
			log.error("An unexpected exception has occurred when create responseXml.", e);
		} catch (Exception e) {
			log.error("An unexpected exception has occurred.", e);
		}
		return res;
	}

	private String createSuccesResponse(String reqId, String refCnt) throws IOException {
		return createResponse(reqId, "1", "0", refCnt);
	}

	private String createFailResponse(String reqId, String failureReason) throws IOException {
		return createResponse(reqId, "2", failureReason, "0");
	}

	private String createResponse(String reqId, String value, String failureReason, String refCnt) throws IOException {
		Map<String, String> attributes = new LinkedHashMap<String, String>();
		attributes.put("value", value);
		attributes.put("failureReason", failureReason);
		attributes.put("count", refCnt);
		return XmlUtil.dom4jCreateResponseXml(reqId, attributes);
	}

}
