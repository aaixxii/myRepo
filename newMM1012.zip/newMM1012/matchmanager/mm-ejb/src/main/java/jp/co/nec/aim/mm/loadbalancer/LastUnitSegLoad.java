package jp.co.nec.aim.mm.loadbalancer;

import java.util.List;

public class LastUnitSegLoad {
	private List<Long> unitIds;
	private List<Long> segmentIds;
	private long redundancy;

	public List<Long> getUnitIds() {
		return unitIds;
	}

	public void setUnitIds(List<Long> unitIds) {
		this.unitIds = unitIds;
	}

	public List<Long> getSegmentIds() {
		return segmentIds;
	}

	public void setSegmentIds(List<Long> segmentIds) {
		this.segmentIds = segmentIds;
	}

	public long getRedundancy() {
		return redundancy;
	}

	public void setRedundancy(long redundancy) {
		this.redundancy = redundancy;
	}

}
