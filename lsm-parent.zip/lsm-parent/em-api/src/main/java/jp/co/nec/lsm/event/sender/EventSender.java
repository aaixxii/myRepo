package jp.co.nec.lsm.event.sender;

import jp.co.nec.lsm.event.Event;

/**
 * @author liuyq <br>
 */
public interface EventSender {
	public void convertAndSend(Event message);
}
