package jp.co.nec.lsm.event.sender;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.exception.EventRuntimeException;
import jp.co.nec.lsm.tm.common.util.SafeCloseUtil;

/**
 * @author liuyq <br>
 */
public abstract class AbstractEventSender implements EventSender {
	/** ConnectionFactory **/
	protected ConnectionFactory jmsConnectionFactory;
	/** event queue **/
	protected Queue queue;
	/** event queue name **/
	protected String queueName;

	/**
	 * Send event message
	 */
	@Override
	public void convertAndSend(Event message) {
		// build ConnectionFactory And Queue is necessary
		buildConnectionFactoryAndQueue();
		
		Connection connect = null;
		Session session = null;
		MessageProducer producer = null;
		try {
			connect = jmsConnectionFactory.createConnection();
			session = connect.createSession(false, Session.DUPS_OK_ACKNOWLEDGE);
			producer = session.createProducer(queue);
			// create a JMS message and send it
			ObjectMessage objMsg = session.createObjectMessage(message);
			// set message selector
			String messageSelector = message.getMessageSelector();
			objMsg.setStringProperty("messageReceiver", messageSelector);

			producer.send(objMsg);
		} catch (JMSException e) {
			String errorMessage = "JMSException while queueing HTTP JMS Message";
			throw new EventRuntimeException(errorMessage, e);
		} finally {
			SafeCloseUtil.close(producer);
			SafeCloseUtil.close(session);
			SafeCloseUtil.close(connect);
		}
	}

	/**
	 * build ConnectionFactory And Queue
	 */
	protected abstract void buildConnectionFactoryAndQueue();
}
