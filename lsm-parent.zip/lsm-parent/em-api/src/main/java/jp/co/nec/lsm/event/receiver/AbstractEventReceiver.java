package jp.co.nec.lsm.event.receiver;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.exception.EventRuntimeException;
import jp.co.nec.lsm.event.log.EventLogBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 *         AbstractEventReceiver
 */
public abstract class AbstractEventReceiver implements MessageListener {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AbstractEventReceiver.class);

	@Override
	public void onMessage(Message message) {
		printLogMessage("start public function onMessage()..");
		try {
			if (message instanceof ObjectMessage) {
				ObjectMessage objMsg = (ObjectMessage) message;
				Event event = (Event) objMsg.getObject();
				// if Re deliver message warn the message
				if (message.getJMSRedelivered()) {
					log
							.warn(
									"This MDB message of (Batch Job: {} Event: {}) was redelivered.",
									event.getBatchJobId(), event.getClass()
											.getSimpleName());
				}
				// out Put Event Log
				outPutEventLog(event);
				// dispatch Event
				dispatchEvent(event);
			} else {
				log
						.error("This MDB message was not instance of ObjectMessage; ignoring.");

			}

			printLogMessage("end public function onMessage()..");
		} catch (JMSException e) {
			String errorMessage = "JMS Exception while Listener message.errorMessage:"
					+ e.getMessage();
			log.error(errorMessage);
			throw new EventRuntimeException(errorMessage, e);
		}
	}

	/**
	 * OutPut event Log
	 * 
	 * @param event
	 */
	private void outPutEventLog(Event event) {
		if (log.isInfoEnabled()) {
			String eventName = event.getClass().getSimpleName();
			long batchJobId = event.getBatchJobId();
			String[] trackMessage = event.getTraceMessage();
			EventLogBuilder.eventOutput(eventName, batchJobId, trackMessage);
		}
	}

	/**
	 * Dispatcher event
	 * 
	 * @param event
	 */
	protected abstract void dispatchEvent(Event event);

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
