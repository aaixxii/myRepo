package jp.co.nec.lsm.tma.listener;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tm.common.util.Version;
import jp.co.nec.lsm.tma.service.sessionbean.AggregationSystemDownManagerBean;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class ShutDownManagerListenerTest {
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplate;
	@Resource
	ShutDownManagerListener shutDownManager;

	@Resource
	AggregationSystemDownManagerBean SystemDownManagerBean;

	/**
	 * initialize
	 */
	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private void setMockMethod() {
		new MockUp<ServiceLocator>() {
			@SuppressWarnings({ "unchecked" })
			@Mock
			public <T> T getLookUpJndiObject(String jndiName, Class<T> clazz) {
				return (T) SystemDownManagerBean;
			}
		};

		new MockUp<Version>() {
			@Mock
			public String readVersion(String warFile, String groupId,
					String artifactId) {
				return "1.0";
			}
		};
	}

	@Test
	public void testShutDown() {
		setMockMethod();

		jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");
		String sql = "select * from TRANSACTION_MANAGERS";

		shutDownManager.contextDestroyed(null);

		List<Map<String, Object>> dbData = jdbcTemplate.queryForList(sql);
		assertEquals(1, dbData.size());
		Map<String, Object> tmeMap = dbData.get(0);

		assertEquals(TmState.EXITED.toString(), tmeMap.get("STATE").toString());
	}
}
