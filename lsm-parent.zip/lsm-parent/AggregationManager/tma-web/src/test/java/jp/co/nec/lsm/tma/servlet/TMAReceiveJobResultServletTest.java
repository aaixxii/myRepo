package jp.co.nec.lsm.tma.servlet;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockServletConfig;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.service.pojo.IdentifySyncAggregationServiceBean;
import jp.co.nec.lsm.tma.sessionbean.api.BatchSegmentJobMapInitializerRemote;
import jp.co.nec.lsm.tma.util.TMASwitchUtil;
import jp.co.nec.lsm.tma.util.UtilCreateData;
import junit.framework.Assert;
import mockit.Mock;
import mockit.MockUp;

/**
 * @author dongqk <br>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class TMAReceiveJobResultServletTest {

	private BatchSegmentJobManager queueManager;
	@Resource
	private BatchSegmentJobMapInitializerRemote batchSegmentJobMapInitializerBean;

	private final static long bJobIdStart = 10000;
	private final static long bJobCount = 5;
	private final static int jobIdStart = 1;
	private final static int jobCount = 1000;
	private final static int segmentIdStart = 1000;
	private final static int segmentCount = 20;
	private final static int segmentEachCount = 5;
	private final static int maxCandidate = 10;

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
		BatchSegmentJobMap batchSegmentJobMap = null;
		for (long i = bJobIdStart; i < bJobIdStart + bJobCount; i++) {
			// create BatchSegmentJobMap data
			batchSegmentJobMap = UtilCreateData.createBatchSegmentJobMapData(i,
					jobIdStart, jobCount, maxCandidate, segmentIdStart,
					segmentCount);
			batchSegmentJobMapInitializerBean
					.receiveBatchJobAndInitSpace(batchSegmentJobMap);
		}

		Assert.assertEquals(queueManager.getIdentifyResults().size(), bJobCount);
		Assert.assertEquals(queueManager.getBatchSegmentJobMaps().size(),
				bJobCount);
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	@Test
	public void testDoPostHttpServletRequestHttpServletResponse() {
		try {
			// create IdentifyResult data first
			IdentifyResult identifyResult = UtilCreateData
					.createIdentifyResultData(bJobIdStart, jobIdStart,
							jobCount, maxCandidate, segmentIdStart,
							segmentEachCount, maxCandidate);
			byte[] data = TMASwitchUtil.switchIdentifyResult(identifyResult)
					.toByteArray();

			MockServletConfig config = new MockServletConfig();
			TMAReceiveJobResultServlet servlet = new TMAReceiveJobResultServlet();
			servlet.init(config);

			MockHttpServletRequest req = new MockHttpServletRequest();
			req.setContent(data);
			MockHttpServletResponse resp = new MockHttpServletResponse();
			servlet.doPost(req, resp);

			// test first
			identifyResult = queueManager.getIdentifyResult(bJobIdStart);

			Assert.assertEquals(segmentCount - segmentEachCount, identifyResult
					.getSegmentIds().size());
			Assert.assertEquals(jobCount, identifyResult.getSearchJobResults()
					.size());

			Assert.assertEquals(maxCandidate, identifyResult
					.getSearchJobResults().get(jobIdStart).getMaxCandidate());
			Assert.assertEquals(maxCandidate + 1, identifyResult
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.size());

			// create IdentifyResult data second
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart + segmentEachCount, segmentEachCount,
					maxCandidate);
			data = TMASwitchUtil.switchIdentifyResult(identifyResult)
					.toByteArray();

			req.setContent(data);
			servlet.doPost(req, resp);

			// test second
			identifyResult = queueManager.getIdentifyResult(bJobIdStart);

			Assert.assertEquals(segmentCount - 2 * segmentEachCount,
					identifyResult.getSegmentIds().size());
			Assert.assertEquals(jobCount, identifyResult.getSearchJobResults()
					.size());

			Assert.assertEquals(maxCandidate, identifyResult
					.getSearchJobResults().get(jobIdStart).getMaxCandidate());
			Assert.assertEquals(maxCandidate + 1, identifyResult
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.size());
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testEmptyRequest() throws ServletException, IOException {
		TMAReceiveJobResultServlet servlet = new TMAReceiveJobResultServlet();

		MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent(new byte[] {});
		MockHttpServletResponse resp = new MockHttpServletResponse();
		servlet.doPost(req, resp);
	}

	@Test
	public void testEmptyRequestGet() throws ServletException, IOException {
		TMAReceiveJobResultServlet servlet = new TMAReceiveJobResultServlet();

		MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent(new byte[] {});
		MockHttpServletResponse resp = new MockHttpServletResponse();
		servlet.doGet(req, resp);
	}

	/**
	 * 
	 */
	private void setMockMethod() {
		new MockUp<IdentifySyncAggregationServiceBean>() {
			@Mock
			public void mergeIdentifyResult(
					IdentifyJobResultRequest resultRequest) throws Exception {
				throw new Exception();
			}
		};
	}

	@Test
	public void testDeserializeIdentifyResultRequestError()
			throws ServletException, IOException {
		TMAReceiveJobResultServlet servlet = new TMAReceiveJobResultServlet();

		MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent(new byte[] { 0, 1 });
		MockHttpServletResponse resp = new MockHttpServletResponse();
		servlet.doPost(req, resp);
		Assert.assertEquals(resp.getStatus(),
				HttpServletResponse.SC_BAD_REQUEST);
		Assert.assertTrue(resp.getContentAsString().contains(
				"parse IdentifyResultRequest from USC error"));
	}

	@Test
	public void testMergeIdentifyResultException() throws ServletException,
			IOException {
		setMockMethod();

		// create IdentifyResult data first
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(bJobIdStart, jobIdStart, jobCount,
						maxCandidate, segmentIdStart, segmentEachCount,
						maxCandidate);
		byte[] data = TMASwitchUtil.switchIdentifyResult(identifyResult)
				.toByteArray();
		TMAReceiveJobResultServlet servlet = new TMAReceiveJobResultServlet();

		MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent(data);
		MockHttpServletResponse resp = new MockHttpServletResponse();
		servlet.doPost(req, resp);
		Assert.assertEquals(resp.getStatus(),
				HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		Assert.assertTrue(resp.getContentAsString().contains(
				"merge IdentifyResultRequest from USC error"));
	}
}
