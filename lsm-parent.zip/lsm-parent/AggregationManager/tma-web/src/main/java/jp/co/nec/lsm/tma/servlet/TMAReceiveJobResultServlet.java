package jp.co.nec.lsm.tma.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServletRequestUtil;
import jp.co.nec.lsm.tma.service.pojo.IdentifySyncAggregationServiceBean;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *         Receive IdentifyResult from MU and call the function of
 *         mergeIdentifyResult
 * 
 */
public class TMAReceiveJobResultServlet extends AbstractTMServlet {

	private static Logger log = LoggerFactory
			.getLogger(TMAReceiveJobResultServlet.class);
	private static final long serialVersionUID = 5428295285121996231L;

	private IdentifySyncAggregationServiceBean aggregator;

	/**
	 * 
	 */
	@Override
	public void init() throws ServletException {
		aggregator = new IdentifySyncAggregationServiceBean();
	}

	/**
	 * Receive IdentifyResult from MU and call the function of
	 * mergeIdentifyResult
	 * 
	 * @param request
	 * @param response
	 */
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		printLogMessage("start ReceiveJobResultServlet service()...");

		if (ServletRequestUtil.isRequestContextSizeEmpty(request)) {
			log.warn("Received an empty POST request");
			return;
		}

		StopWatch t = new StopWatch();
		t.start();

		// receive IdentifyResultRequest from MU
		IdentifyJobResultRequest resultRequest = deserializeIdentifyResultRequest(
				request, response);
		if (null == resultRequest) {
			return;
		}

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.deliveryJobInfoOutput(
					LogConstants.COMPONENT_TMA_RECEIVER_JOB_SERVLET,
					LogConstants.DETAIL_USC_ID, String.valueOf(resultRequest
							.getGmvId()), LogConstants.DETAIL_BATCH_JOB_ID,
					String.valueOf(resultRequest.getBatchJobId()),
					LogConstants.DETAIL_REQUEST_SEGMENT_INFO,
					getSegmentSummary(resultRequest.getSegmentIdList())));
		}

		// call the function mergeIdentifyResult
		try {
			aggregator.mergeIdentifyResult(resultRequest);
		} catch (Exception e) {
			writeErrorToResponse(request, response,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"merge IdentifyResultRequest from USC error", e);
			return;
		}

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_TMA_RECEIVER_JOB_SERVLET,
				LogConstants.FUNCTION_DO_POST, t.getTime());

		printLogMessage("end ReceiveJobResultServlet service()...");
	}

	/**
	 * Receive and deserialize IdentifyResultRequest from USC
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	private IdentifyJobResultRequest deserializeIdentifyResultRequest(
			HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		StopWatch t = new StopWatch();
		t.start();
		IdentifyJobResultRequest resultRequest = null;
		try {
			// receive and deserialize IdentifyResultRequest from USC
			resultRequest = IdentifyJobResultRequest.parseFrom(request.getInputStream());
		} catch (Exception e) {
			writeErrorToResponse(request, response,
					HttpServletResponse.SC_BAD_REQUEST,
					"parse IdentifyResultRequest from USC error", e);
		}
		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_TMA_RECEIVER_JOB_SERVLET,
				LogConstants.FUNCTION_DESERIALIZE_IDENTIFY_RESULT_REQUEST,
				t.getTime());
		return resultRequest;
	}

	/**
	 * get segment summary
	 * 
	 * @param segmentIdList
	 * @return
	 */
	private String getSegmentSummary(List<Long> segmentIdList) {
		if (null == segmentIdList) {
			return "";
		}

		StringBuilder segInfo = new StringBuilder();
		segInfo.append("[");
		for (int i = 0, size = segmentIdList.size(); i < size; i++) {
			segInfo.append("{");
			segInfo.append(segmentIdList.get(i));
			segInfo.append("},");
		}
		segInfo.setCharAt(segInfo.length() - 1, ']');
		return segInfo.toString();
	}

	/**
	 * 
	 */
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
