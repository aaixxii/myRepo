package jp.co.nec.lsm.tma.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.service.sessionbean.AggregationInitializationLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *         TMAInitializationServlet
 */
public class TMAInitializationServlet extends AbstractTMServlet {

	private static Logger log = LoggerFactory
			.getLogger(TMAInitializationServlet.class);
	private static final long serialVersionUID = 240324080833505099L;

	private AggregationInitializationLocal initializationLocal;

	/**
	 * Initialization
	 */
	public void init() throws ServletException {
		printLogMessage("start public function init(), get the instance of a InitializationBean class ...");

		initializationLocal = ServiceLocator.getLookUpJndiObject(
				JNDIConstants.TMA_BEAN_INITIALIZATION,
				AggregationInitializationLocal.class);
		initializationLocal.initializeAggregation();

		printLogMessage("end public function init(), get the instance of a InitializationBean class ...");

	}

	/**
	 * 
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// nothing to do
	}

	/**
	 * 
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doPost(req, res);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
