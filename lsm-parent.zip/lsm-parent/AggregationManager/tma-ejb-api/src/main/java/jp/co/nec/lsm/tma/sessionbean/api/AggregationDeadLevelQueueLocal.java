package jp.co.nec.lsm.tma.sessionbean.api;

public interface AggregationDeadLevelQueueLocal {
	public void receiveEventFromDLQ(long batchJobId);
}
