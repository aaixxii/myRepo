package jp.co.nec.lsm.tma.sessionbean.api;

public interface AggregationHeartbeatStarterLocal {
	public void startTimer(int pollDuraton);
}
