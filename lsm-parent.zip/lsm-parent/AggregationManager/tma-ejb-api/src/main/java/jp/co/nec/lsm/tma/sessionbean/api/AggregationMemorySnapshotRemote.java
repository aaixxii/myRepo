package jp.co.nec.lsm.tma.sessionbean.api;

import java.util.Map;

import javax.ejb.Remote;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;

@Remote
public interface AggregationMemorySnapshotRemote {
	public Map<Long, BatchSegmentJobMap> getBatchSegmentJobMap(Long batchJobId);

	public Map<Long, IdentifyResultRequest> getIdentifyResultRequest();
}
