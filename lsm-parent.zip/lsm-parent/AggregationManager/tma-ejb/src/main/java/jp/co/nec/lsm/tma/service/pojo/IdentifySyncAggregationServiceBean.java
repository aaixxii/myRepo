package jp.co.nec.lsm.tma.service.pojo;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.core.merger.TopLevelInfoMerger;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *         receive and processing BatchSegmentJobMap from TMI<br>
 *         processing the transmitted data from USC
 * 
 */
public class IdentifySyncAggregationServiceBean {

	private static Logger log = LoggerFactory
			.getLogger(IdentifySyncAggregationServiceBean.class);

	public IdentifySyncAggregationServiceBean() {
	}

	/**
	 * Processing the transmitted data from USC.<br>
	 * 1. Verify the data from USC is valid.<br>
	 * 2. Verify the data whether is the requirements of the query data for the
	 * TMI.<br>
	 * 3. merge Candidate with the local Candidate.<br>
	 * 4. set BatchSegmentJobStatus to DONE which BatchSegementJob has been
	 * merged.<br>
	 * 5. Verify BatchJob had been done, if had done, notify
	 * IdentifyBatchJobResultServiceBean<br>
	 * 
	 * @param resultRequest
	 *            the data from USC
	 */
	public void mergeIdentifyResult(IdentifyJobResultRequest resultRequest) {
		if (log.isDebugEnabled()) {
			printLogMessage("start public function mergeIdentifyResult()...");
		}

		StopWatch t = new StopWatch();
		t.start();

		BatchSegmentJobManager queueManager = BatchSegmentJobManager
				.getInstance();

		// 1. Verify the data from USC is valid.
		if (null == resultRequest) {
			log.error("error IdentifyResultRequest from USC is null...");
			throw new AggregationRuntimeException(
					"error IdentifyResultRequest from USC is null...");
		}

		final long batchJobId = resultRequest.getBatchJobId();

		// 2. Verify the data whether is the requirements of the query data for
		// the TMI.
		IdentifyResult identifyResult = queueManager
				.getIdentifyResult(batchJobId);

		if (null == queueManager.getBatchSegmentJobMap(batchJobId)
				|| null == identifyResult) {
			log.error("For the same BatchJobId: {}, "
					+ "TMI doesn't send BatchSegmentJobMap to TMA, "
					+ "but USC send IdentifyResult...",
					new Object[] { batchJobId });
			return;
		}

		// set Status to RUNNING
		queueManager.setBatchJobStatus(batchJobId, BatchJobMapStatus.RUNNING);

		if (queueManager.hasBSJAlreadyReceived(batchJobId,
				resultRequest.getSegmentIdList())) {
			log.warn("warn this IdentifyResultRequest from USC had already received...");
			return;
		}

		identifyResult.addReadCount(resultRequest.getReadCount());

		// 3. merge data with the local data.
		TopLevelInfoMerger.mergeTopLevel(identifyResult, resultRequest);

		// 4. set BatchSegmentJobStatus to DONE which BatchSegementJob has
		// been merged
		queueManager.setBatchSegmentJobStatusDone(batchJobId,
				resultRequest.getSegmentIdList());

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_SYNC_AGGREGATION_SERVICE_BEAN,
				LogConstants.FUNCTION_MERGE_IDENTIFYRESULT, t.getTime(),
				LogConstants.KEY_BATCH_JOB_ID, new Long(batchJobId).toString());

		if (log.isDebugEnabled()) {
			printLogMessage("end public function mergeIdentifyResult()...");
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
