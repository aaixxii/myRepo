package jp.co.nec.lsm.tma.db.dao;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;

/**
 * @author dongqk <br>
 *
 */
@Local
public interface AggregationTransactionManagerDaoLocal {

	public void setStartupTime();
	public TransactionManagerEntity createOrLookup();
	
	public void changeTMAToExit();

}
