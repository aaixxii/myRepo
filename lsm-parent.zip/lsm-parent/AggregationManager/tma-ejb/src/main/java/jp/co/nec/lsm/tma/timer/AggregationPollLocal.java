package jp.co.nec.lsm.tma.timer;

import javax.ejb.Local;

/**
 * @author liuyq <br>
 *
 */
@Local
public interface AggregationPollLocal {
	/**
	 * here check the batch segment job timeout if timeout raise a timeout event
	 * to notify TMI to re delivery this batch segment job
	 */
	public void poll();
}
