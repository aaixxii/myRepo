package jp.co.nec.lsm.tma.db.dao;

import javax.ejb.Local;

/**
 * @author dongqk <br>
 *
 */
@Local
public interface AggregationSystemConfigDaoLocal {

	public void writeAllMissingProperties();

	public Integer getTMaBatchJobReRunLimit();

	public Long getTMaBatchJobTimeout();
	
	public String getPostToTransformerUrl();
	
	public String getTmiIpAddress();
	
	public String getTmaIpAddress();
	
	public String getTMAWebPort();
	
	public Integer getTransformerPostTimeout();
	
	public int getHeartbeatPollingDuration();
}
