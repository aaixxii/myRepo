package jp.co.nec.lsm.tma.core.score;

import java.util.List;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.communication.ReSendable;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *         According to the BatchJobId and JobId, get each Job Object, merge
 *         ScaledScore, For IdentifyResult returned each USC, first, find the
 *         corresponding batchJob, and then merge data from job1 to jobn, if the
 *         score is higher than now, insert, otherwise give up .
 * 
 */
public final class TopLevelCandidateMerger {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(TopLevelCandidateMerger.class);

	/**
	 * valid Params Error, if error, return false, else true
	 * 
	 * @param topLevelJobResultFromUSC
	 * @param topLeveLJobResult
	 * @param candidatesSize
	 * @param candidatesFromUSCSize
	 * @return
	 */
	public final static boolean isValidParams(
			IdentifyJobResultRequestProto.IdentifyJobResult topLevelJobResultFromUSC,
			IdentifyJobResult topLeveLJobResult, int candidatesSize,
			int candidatesFromUSCSize) {

		// tMI prepare has error
		if (topLeveLJobResult.getReturnCode() == ReturnCode.JobFailed) {
			return false;
		}

		// tMI has no error, but the result from uSC has error
		// necessary to get reSendable flag and save it to memory job
		if (topLevelJobResultFromUSC.getReturnCode() == ReturnCode.JobFailed
				&& topLeveLJobResult.getReturnCode() != ReturnCode.JobFailed) {
			topLeveLJobResult.setReturnCode(ReturnCode.JobFailed);
			topLeveLJobResult.setErrorCode(String
					.valueOf(topLevelJobResultFromUSC.getErrorCode()));
			topLeveLJobResult.setErrorMessage(topLevelJobResultFromUSC
					.getErrorMessage());

			// while the job from uSC is error
			// first check uSC send the flag or not
			// if the uSC send, save the result
			// otherwise, warning out the log
			if (topLevelJobResultFromUSC.hasResendable()) {
				if (topLevelJobResultFromUSC.getResendable())
					topLeveLJobResult.setResendable(ReSendable.YES);
				else
					topLeveLJobResult.setResendable(ReSendable.NO);
			} else {
				topLeveLJobResult.setResendable(ReSendable.YES);
				log.warn("uSC does not send ReSendable flag to aggregation "
						+ "while the job is failed..");
			}

			topLeveLJobResult.getCandidates().clear();
			return false;
		}

		if (topLeveLJobResult.getMaxCandidate() <= 0) {
			return false;
		}

		if (candidatesSize <= 1) {
			return false;
		}

		return true;
	}

	/**
	 * merge TopLevelJob Candidates
	 * 
	 * @param candidates
	 *            candidates from tma queue
	 * @param candidatesSize
	 * @param candidateListFromUSC
	 *            candidates from USC
	 * @param candidateListFromUSCSize
	 */
	public final static void mergeTopLevelCandidate(Object[] candidates,
			int candidatesSize, List<Candidate> candidateListFromUSC,
			int candidateListFromUSCSize) {

		// the last one in the queue > the first one in the IdentifyResult from
		// USC
		if (candidateListFromUSCSize > 0
				&& ((Candidate) candidates[candidatesSize - 1])
						.getScaledScore() >= candidateListFromUSC.get(0)
						.getScaledScore()) {
			return;
		}

		int i = 0; // outside of the loop, reduce loop times
		for (int j = 0; j < candidateListFromUSCSize; j++) {
			for (; i < candidatesSize; i++) {
				if (candidateListFromUSC.get(j).getReferenceId()
						.equals(((Candidate) candidates[i]).getReferenceId())) {
					break;
				}
				if (candidateListFromUSC.get(j).getScaledScore() > ((Candidate) candidates[i])
						.getScaledScore()) {
					System.arraycopy(candidates, i, candidates, i + 1,
							candidatesSize - i - 1);
					candidates[i] = candidateListFromUSC.get(j);
					break;
				}
			}
		}
	}
}
