package jp.co.nec.lsm.tma.timer;

public interface AggregationHeartbeatPollLocal {

	public void poll();
}
