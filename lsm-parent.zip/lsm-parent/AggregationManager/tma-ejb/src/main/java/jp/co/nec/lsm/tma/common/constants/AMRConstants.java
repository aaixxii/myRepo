package jp.co.nec.lsm.tma.common.constants;

public class AMRConstants {
	public static final String AMR = "amr";
	public static final String AMR_READ = "read";
	public static final String AMR_MFM_1 = "mfm-1";
	public static final String AMR_MFM_2 = "mfm-2";
	public static final String AMR_FACE = "face";
	public static final String AMR_IRIS_LEFT = "iris-left";
	public static final String AMR_IRIS_RIGHT = "iris-right";
	public static final String AMR_FINGER = "finger";
	public static final String AMR_PASSED_FIRST = "passed-first";
	public static final String AMR_PASSED_SECOND = "passed-second";
	public static final String AMR_PASSED_THIRD = "passed-third";
}
