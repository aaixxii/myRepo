package jp.co.nec.lsm.tma.service.sessionbean;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tma.common.util.AggregationEventBus;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.db.dao.AggregationSystemConfigDaoLocal;
import jp.co.nec.lsm.tma.sessionbean.api.AggregationDeadLevelQueueLocal;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationDeadLevelQueueService implements
		AggregationDeadLevelQueueLocal {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AggregationDeadLevelQueueService.class);

	private IdentifyResult identifyResult;
	BatchSegmentJobManager queueManager = BatchSegmentJobManager.getInstance();
	BatchSegmentJobMap batchSegmentJobMap;

	@EJB
	private AggregationSystemConfigDaoLocal systemConfigDao;

	public AggregationDeadLevelQueueService() {
	}

	@Override
	public void receiveEventFromDLQ(long batchJobID) {

		printLogMessage("start public function receiveEventFromDLQ()...");
		StopWatch t = new StopWatch();
		t.start();
		if (log.isInfoEnabled()) {
			log.info("receive event from dead letter queue, remove this "
					+ "batch job {} from memory.", batchJobID);
		}

		try {
			checkBatchJob(batchJobID);
		} catch (Exception ex) {
			log.error("exception occurred while do checkBatchJob"
					+ "(handle dead letter queue)..", ex);
		}

		try {
			reSendResultsToTr(batchJobID);
		} catch (Exception ex) {
			log.error("exception occurred while do reSendResultsToTr"
					+ "(handle dead letter queue)..", ex);
		}

		try {
			sendBatchJobMapToTMI(batchJobID);
		} catch (Exception ex) {
			log.error("exception occurred while do sendBatchJobMapToTMI"
					+ "(handle dead letter queue)..", ex);
		}

		try {
			lastProcess(batchJobID);
		} catch (Exception ex) {
			log.error("exception occurred while do lastProcess"
					+ "(handle dead letter queue)..", ex);
			queueManager.remove(batchJobID);
		}

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_AGGREGATION_DEADLEVELQUEUE_SERVICE,
				LogConstants.FUNCTION_RECEIV_FROM_DLQ, t.getTime(),
				LogConstants.KEY_BATCH_JOB_ID, new Long(batchJobID).toString());

		printLogMessage("end public function receiveEventFromDLQ()...");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

	public void checkBatchJob(long batchJobId) {
		printLogMessage("Check status of batchjob(" + batchJobId + ")...");
		// Find in IdentifyResultMap has disposed of BatchJob
		if (batchJobId < 0) {
			String incorrectMsg = "received batchJobId:" + batchJobId
					+ "is minus!";
			if (log.isErrorEnabled()) {
				log.equals(incorrectMsg);
				return;
			}
		}
		identifyResult = queueManager.getIdentifyResult(batchJobId);
		if (null == identifyResult
				|| identifyResult.getSearchJobResults().size() <= 0) {
			String message = "error according to the batchJobId, doesnot find IdentifyResult from TMA queue...";
			log.error(message);
			queueManager.setBatchSegmentJobMapStatusDone(batchJobId,
					BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR);
		} else {
			// Find in BatchSegmentJobMap has disposed of BatchJob
			batchSegmentJobMap = queueManager.getBatchSegmentJobMap(batchJobId);
			if (null == batchSegmentJobMap) {
				String message = "error according to the batchJobId, doesnot find BatchSegmentJobMap from TMA queue...";
				log.error(message);
				queueManager
						.setBatchSegmentJobMapStatusDone(
								batchJobId,
								BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR);
			} else {
				if (!(BatchJobMapStatus.TMA_WORKING_DONE == queueManager
						.getBatchSegmentJobMapStatus(batchJobId))) {
					queueManager
							.setBatchSegmentJobMapStatusDone(
									batchJobId,
									BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR);
				} else {
					queueManager.setOverMaxCandidatesTrue(batchJobId);
				}
			}
		}
	}

	public void reSendResultsToTr(long batchJobId) {
		if (BatchJobMapStatus.TMA_WORKING_DONE == queueManager
				.getBatchSegmentJobMapStatus(batchJobId)) {
			String endPoint = systemConfigDao.getPostToTransformerUrl();
			Integer timeout = systemConfigDao.getTransformerPostTimeout();

			// send IdentifyResponse Object to Transformer
			boolean isSendTransformerSuccess = true;
			try {
				isSendTransformerSuccess = AggregationEventBus
						.sendIdentifyResponseToTransformer(identifyResult,
								endPoint, timeout);
			} catch (Exception ex) {
				isSendTransformerSuccess = false;
			}

			if (isSendTransformerSuccess) {
				queueManager.setBatchSegmentJobMapStatusDone(batchJobId,
						BatchJobMapStatus.NOTIFY_TRANSFORMER_DONE);
			} else {
				String message = "BatchJobId: " + batchJobId
						+ ", send IdentifyResponse to Transformer error.";
				log.error(message);
				queueManager
						.setBatchSegmentJobMapStatusDone(
								batchJobId,
								BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR);
			}
		} else {
			String message = "BatchJobId: " + batchJobId
					+ ", status is not yet working done!";
			log.error(message);
			queueManager.setBatchSegmentJobMapStatusDone(batchJobId,
					BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR);
		}

	}

	public void sendBatchJobMapToTMI(long batchJobId) {

		if ((BatchJobMapStatus.NOTIFY_TRANSFORMER_DONE == queueManager
				.getBatchSegmentJobMapStatus(batchJobId))
				|| (BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR == queueManager
						.getBatchSegmentJobMapStatus(batchJobId))) {

			String tmiIpAddress = systemConfigDao.getTmiIpAddress();			
			boolean isSendTMISuccess = AggregationEventBus
					.sendBatchSegmentJobMapToTMI(batchSegmentJobMap,
							tmiIpAddress);
			if (isSendTMISuccess) {
				// set Status to NOTIFY_TMI_DONE
				queueManager.setBatchSegmentJobMapStatusDone(batchJobId,
						BatchJobMapStatus.NOTIFY_TMI_DONE);
			} else {
				String message = "BatchJobId: "
						+ batchJobId
						+ ", send BatchSegmentJobMap to TMI error, when this BatchSegmentJobMap has been done.";
				log.error(message);
				// Setting batchjobStatus toNOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR
				queueManager
						.setBatchSegmentJobMapStatusDone(
								batchJobId,
								BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR);
			}
		}
	}

	public void lastProcess(long batchJobId) {
		String tmiIpAddress = systemConfigDao.getTmiIpAddress();
		BatchJobMapStatus currentStatus = queueManager
				.getBatchSegmentJobMapStatus(batchJobId);
		if (BatchJobMapStatus.NOTIFY_SEND_RESULTS_TO_TRANSFORMER_ERROR == currentStatus) {
			AggregationEventBus.notifyIdentifyBatchjobSendFailed(batchJobId,
					tmiIpAddress);
		}
		queueManager.remove(batchJobId);
	}
}
