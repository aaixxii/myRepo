package jp.co.nec.lsm.tma.timer;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tma.db.dao.AggregationTransactionManagerDaoLocal;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationHeartbeatPollBean implements AggregationHeartbeatPollLocal {

	@EJB
	AggregationTransactionManagerDaoLocal dao;

	private static Logger log = LoggerFactory
	.getLogger(AggregationHeartbeatPollBean.class);
	
	@Override
	public void poll() {
		printLogMessage("poll() is called.");

		StopWatch t = new StopWatch();
		t.start();
		
		dao.createOrLookup();
		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_AGGREGATION_HEARTBEAT_POLL_BEAN,
				LogConstants.FUNCTION_POLL, t.getTime());
	}
	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
