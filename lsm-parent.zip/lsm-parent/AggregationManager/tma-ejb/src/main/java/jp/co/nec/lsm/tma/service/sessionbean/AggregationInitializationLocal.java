package jp.co.nec.lsm.tma.service.sessionbean;

import javax.ejb.Local;

/**
 * @author dongqk <br>
 *
 */
@Local
public interface AggregationInitializationLocal {

	/**
	 * initialize Aggregation
	 * start timer, sendEnter to TMI
	 */
	public void initializeAggregation();

}
