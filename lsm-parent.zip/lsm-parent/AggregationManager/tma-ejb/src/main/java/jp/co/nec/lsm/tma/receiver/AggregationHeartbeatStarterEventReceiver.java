package jp.co.nec.lsm.tma.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.identify.IdentifyStartHeartbeatTimerEvent;
import jp.co.nec.lsm.event.receiver.AbstractEventReceiver;
import jp.co.nec.lsm.tm.common.constants.DeployName;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.sessionbean.api.AggregationHeartbeatStarterLocal;
import jp.co.nec.lsm.tma.timer.AggregationHeartbeatStarterBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.AGGREGATION_QUEUE),
		@ActivationConfigProperty(propertyName = "messageSelector", propertyValue = "messageReceiver = 'AggregationHeartbeatStarterBean'") })
public class AggregationHeartbeatStarterEventReceiver extends
		AbstractEventReceiver implements MessageListener {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationHeartbeatStarterEventReceiver.class);

	@Override
	protected void dispatchEvent(Event event) {
		// look up the service session bean
		if (!(event instanceof IdentifyStartHeartbeatTimerEvent)) {
			log
					.error("event is not a IdentifyStartHeartbeatTimerEvent instance.");
			return;
		}

		String jndiName = DeployName.AGGREGATION_EARFILE + JNDIConstants.SPLIT
				+ AggregationHeartbeatStarterBean.class.getSimpleName()
				+ JNDIConstants.LOCAL;
		AggregationHeartbeatStarterLocal timerService = ServiceLocator
				.getLookUpJndiObject(jndiName,
						AggregationHeartbeatStarterLocal.class);
		IdentifyStartHeartbeatTimerEvent timeEvent = (IdentifyStartHeartbeatTimerEvent)event;
		int pollDuraton = timeEvent.getPollDuraton();
		// do service session bean
		timerService.startTimer(pollDuraton);
	}

}
