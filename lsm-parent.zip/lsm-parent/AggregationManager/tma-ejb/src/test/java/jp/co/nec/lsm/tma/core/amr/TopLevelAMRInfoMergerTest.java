package jp.co.nec.lsm.tma.core.amr;

import java.util.HashMap;
import java.util.Map;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tm.common.communication.ReSendable;
import jp.co.nec.lsm.tma.common.util.TMASwitchUtil;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.AMRState;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import junit.framework.Assert;

import org.junit.Test;

public class TopLevelAMRInfoMergerTest {

	@Test
	public void testMergeTopLevelAMRInfo() {
		final int topLevelJobCount = 100;

		Map<Integer, AMRState> jobAmrInfoMap = new HashMap<Integer, AMRState>();
		for (int i = 0; i < topLevelJobCount; i++) {
			jobAmrInfoMap.put(i, new AMRState());
		}

		final int[] mergeScores = { 9990, 8888, 7770, 6666, 5550, 4440, 3330,
				2220, 1110, 0 };
		IdentifyResult identifyResult = UtilCreateData
				.createIdentifyResultData(1212L, 1, 100, mergeScores, 10, 10,
						ReturnCode.JobSuccess, ReSendable.EMPTY);
		IdentifyJobResultRequest request = TMASwitchUtil
				.switchIdentifyResult(identifyResult);

		final int mergerCount = 10;
		for (int i = 0; i < mergerCount; i++) {

			for (int j = 0; j < topLevelJobCount; j++)
				TopLevelAMRInfoMerger.mergeTopLevelAMRInfo(
						jobAmrInfoMap.get(j), request.getIdentifyJobResult(j)
								.getAmrInfo());
		}

		// assert
		for (int i = 0; i < topLevelJobCount; i++) {
			AMRState state = jobAmrInfoMap.get(i);
			Assert.assertEquals(String.valueOf(i * mergerCount),
					state.getFaceActualCount());
			Assert.assertEquals(String.valueOf(i * mergerCount),
					state.getFingerActualCount());
			Assert.assertEquals(String.valueOf(i * mergerCount),
					state.getIris_leftActualCount());
			Assert.assertEquals(String.valueOf(i * mergerCount * 2),
					state.getIris_rightActualCount());
			Assert.assertEquals(String.valueOf(0), state.getMfm_1ActualCount());

			Assert.assertEquals(String.valueOf(0), state.getMfm_2ActualCount());
			Assert.assertEquals(String.valueOf(0), state.getReadActualCount());

			Assert.assertEquals(String.valueOf(i * mergerCount),
					state.getPassedFActualCount());

			Assert.assertEquals(String.valueOf(i * mergerCount * 2),
					state.getPassedSActualCount());
			Assert.assertEquals(String.valueOf(i * mergerCount * 3),
					state.getPassedTActualCount());

		}

		// identifyResultRequest.get

	}
}
