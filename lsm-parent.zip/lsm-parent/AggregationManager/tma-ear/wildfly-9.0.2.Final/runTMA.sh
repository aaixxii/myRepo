#!/bin/sh
PWD=`pwd`

function remove {
        clear
        echo ======================================
        echo
        echo "rm -rf server/default/data/*"
        echo "rm -rf server/default/tmp/*"
        echo "rm -rf server/default/work/*"
        echo "delete the server/default/data directory"
        echo "that directory contains the persisted"
        echo "database contents used by HSQLDB."
        echo "So deleting the directory will"
        echo "remove all of the messages. "
        rm -rf server/default/data/*
        rm -rf server/default/tmp/*
        rm -rf server/default/work/*
    echo
        echo ======================================
}

remove

nohup bin/run.sh -b 0.0.0.0 > nohup.out &
echo "$PWD is starting ....."
#tail -F nohup.out