package jp.co.nec.lsm.tme.sessionbeans.api;

import javax.ejb.Local;

/**
 * @author mozj <br>
 * 
 */
@Local
public interface EnrollResponseServiceLocal {
	public void doResponse(long batchJobId);
}
