package jp.co.nec.lsm.tme.sessionbeans.api;

public interface EnrollHeartbeatStarterLocal {
	public void startTimer(int pollDuraton);
}
