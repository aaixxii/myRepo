package jp.co.nec.lsm.tme.sessionbeans.api;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;

/**
 * @author liuj
 */
@Local
public interface TemplateManagerLocal {
	void insertTemplates(long batchJobId);

	DeleteResultRequest deleteTemplate(Long batchJobId, String referenceId);
}
