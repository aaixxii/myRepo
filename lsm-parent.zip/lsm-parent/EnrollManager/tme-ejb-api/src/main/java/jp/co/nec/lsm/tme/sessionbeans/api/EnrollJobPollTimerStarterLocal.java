package jp.co.nec.lsm.tme.sessionbeans.api;

import javax.ejb.Local;

/**
 * @author mozj <br>
 * 
 */
@Local
public interface EnrollJobPollTimerStarterLocal {
	public void startTimer();

}
