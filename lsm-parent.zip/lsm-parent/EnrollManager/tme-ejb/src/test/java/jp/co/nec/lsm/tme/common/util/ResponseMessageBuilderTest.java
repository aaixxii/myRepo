package jp.co.nec.lsm.tme.common.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponseAttribute;
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;

public class ResponseMessageBuilderTest {
	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 */
	@Test
	public void testCreateBusinessMessageByRequest_JobFailed() {
		new EnrollConstants();
		// CPBRequest
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%018d", 15546)
				+ String.format("%018d", 164));
		request.setEnrollmentId("QueueManager_" + String.format("%023d", 564));
		request.setRequestType(E_REQUESET_TYPE.INSERT);

		CPBBusinessMessage businessMessage = ResponseMessageBuilder
				.createBusinessMessageByRequest(request.build(),
						ReturnCode.JobFailed, "errorCode", "errorMessage", "Y");
		assertEquals(String.format("%018d", 15546)
				+ String.format("%018d", 164), businessMessage.getRequest()
				.getRequestId());
		assertEquals(E_REQUESET_TYPE.INSERT, businessMessage.getRequest()
				.getRequestType());
		assertEquals("QueueManager_" + String.format("%023d", 564),
				businessMessage.getRequest().getEnrollmentId());

		assertEquals("errorCode", businessMessage.getResponse().getStatus());
		assertEquals("Y", businessMessage.getResponse().getResendable());
		assertEquals("errorMessage", businessMessage.getResponse()
				.getErrorMessage());

		assertEquals(1, businessMessage.getResponse()
				.getResponseAttributesList().size());
		assertEquals("createdTimestamp", businessMessage.getResponse()
				.getResponseAttributesList().get(0).getAttributeName());
		assertNotNull(businessMessage.getResponse().getResponseAttributesList()
				.get(0).getAttributeValue());
	}

	/**
	 * 
	 */
	@Test
	public void testCreateBusinessMessageByRequest_JobSuccess() {
		// CPBRequest
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%018d", 15546)
				+ String.format("%018d", 164));
		request.setEnrollmentId("QueueManager_" + String.format("%023d", 564));
		request.setRequestType(E_REQUESET_TYPE.INSERT);

		CPBBusinessMessage businessMessage = ResponseMessageBuilder
				.createBusinessMessageByRequest(request.build(),
						ReturnCode.JobSuccess, "errorCode", "errorMessage", "Y");
		assertEquals(String.format("%018d", 15546)
				+ String.format("%018d", 164), businessMessage.getRequest()
				.getRequestId());
		assertEquals(E_REQUESET_TYPE.INSERT, businessMessage.getRequest()
				.getRequestType());
		assertEquals("QueueManager_" + String.format("%023d", 564),
				businessMessage.getRequest().getEnrollmentId());

		assertEquals("0", businessMessage.getResponse().getStatus());
		assertEquals("", businessMessage.getResponse().getResendable());
		assertEquals("", businessMessage.getResponse().getErrorMessage());

		assertEquals(1, businessMessage.getResponse()
				.getResponseAttributesList().size());
		assertEquals("createdTimestamp", businessMessage.getResponse()
				.getResponseAttributesList().get(0).getAttributeName());
		assertNotNull(businessMessage.getResponse().getResponseAttributesList()
				.get(0).getAttributeValue());
	}

	/**
	 * 
	 */
	@Test
	public void testRebuildCPBResponse_New() {

		CPBResponse response = ResponseMessageBuilder.rebuildCPBResponse(null,
				ReturnCode.JobSuccess, "errorCode", "errorMessage", "Y");

		assertEquals("0", response.getStatus());
		assertEquals("", response.getResendable());
		assertEquals("", response.getErrorMessage());

		assertEquals(1, response.getResponseAttributesList().size());
		assertEquals("createdTimestamp", response.getResponseAttributesList()
				.get(0).getAttributeName());
		assertNotNull(response.getResponseAttributesList().get(0)
				.getAttributeValue());
	}

	/**
	 * 
	 */
	@Test
	public void testRebuildCPBResponse_Rebuild_NoAttribute() {

		CPBResponse.Builder responseBuilder = CPBResponse.newBuilder();
		responseBuilder.setStatus("");

		CPBResponse response = ResponseMessageBuilder.rebuildCPBResponse(null,
				ReturnCode.JobFailed, "errorCode", "errorMessage", "Y");

		assertEquals("errorCode", response.getStatus());
		assertEquals("Y", response.getResendable());
		assertEquals("errorMessage", response.getErrorMessage());

		assertEquals(1, response.getResponseAttributesList().size());
		assertEquals("createdTimestamp", response.getResponseAttributesList()
				.get(0).getAttributeName());
		assertNotNull(response.getResponseAttributesList().get(0)
				.getAttributeValue());
	}

	/**
	 * 
	 */
	@Test
	public void testRebuildCPBResponse_Rebuild_HasAttribute() {

		CPBResponse.Builder responseBuilder = CPBResponse.newBuilder();
		responseBuilder.setStatus("");
		CPBResponseAttribute.Builder responseAttribute = CPBResponseAttribute
				.newBuilder();
		responseAttribute.setAttributeName("createdTimestamp");
		responseAttribute.setAttributeValue("DateUtil.getCurrentDate()");
		responseBuilder.addResponseAttributes(responseAttribute);

		CPBResponse response = ResponseMessageBuilder.rebuildCPBResponse(
				responseBuilder.build(), ReturnCode.JobFailed, "errorCode",
				"errorMessage", "Y");

		assertEquals("errorCode", response.getStatus());
		assertEquals("Y", response.getResendable());
		assertEquals("errorMessage", response.getErrorMessage());

		assertEquals(1, response.getResponseAttributesList().size());
		assertEquals("createdTimestamp", response.getResponseAttributesList()
				.get(0).getAttributeName());
		assertEquals("DateUtil.getCurrentDate()", response
				.getResponseAttributesList().get(0).getAttributeValue());
	}
}
