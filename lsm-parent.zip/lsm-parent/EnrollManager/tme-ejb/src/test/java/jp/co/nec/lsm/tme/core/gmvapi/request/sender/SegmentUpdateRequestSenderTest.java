package jp.co.nec.lsm.tme.core.gmvapi.request.sender;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.lsm.proto.segment.SegmentUpdateRequestProto.SegmentUpdateRequest;
import jp.co.nec.lsm.proto.segment.SegmentUpdateResponseProto.SegmentUpdateResponse;
import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class SegmentUpdateRequestSenderTest {
	int port = 13187;

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	@Test
	public void testSendRequest() {
		// prepare data for test
		String url = "http://127.0.0.1:" + port;
		SegmentUpdateRequest segmentUpdateRequst = prepareSegmentPosition();

		setMock(segmentUpdateRequst.toByteArray(), true);
		// call sendRequest
		SegmentUpdateRequestSender sender = new SegmentUpdateRequestSender();
		SegmentUpdateResponse segmentUpdateResponse = sender.sendRequest(123,
				url, segmentUpdateRequst);

		// assert result
		assertNotNull(segmentUpdateResponse);
		assertEquals(120, segmentUpdateResponse.getGmvId());
		assertEquals(segmentUpdateRequst.getRecordCount(),
				segmentUpdateResponse.getRecordCount());
		assertEquals(segmentUpdateRequst.getSegmentId(), segmentUpdateResponse
				.getSegmentId());
		assertEquals(segmentUpdateRequst.getVersionTo(), segmentUpdateResponse
				.getVersion());

	}

	@Test
	public void testSendRequest_InvalidProtocolBufferException() {
		setMock(null, false);
		// prepare data for test
		String url = "http://127.0.0.1:" + port;
		SegmentUpdateRequest segmentUpdateRequst = prepareSegmentPosition();

		// call sendRequest
		SegmentUpdateRequestSender sender = new SegmentUpdateRequestSender();
		SegmentUpdateResponse segmentUpdateResponse = sender.sendRequest(123,
				url, segmentUpdateRequst);

		// assert result
		assertNull(segmentUpdateResponse);
	}

	@Test
	public void testSendRequest_Exception() {
		setMock(null, true);
		// prepare data for test
		String url = "http://127.0.0.1:" + port;
		SegmentUpdateRequest segmentUpdateRequst = prepareSegmentPosition();

		// call sendRequest
		SegmentUpdateRequestSender sender = new SegmentUpdateRequestSender();
		SegmentUpdateResponse segmentUpdateResponse = sender.sendRequest(12346,
				url, segmentUpdateRequst);

		// assert result
		assertNull(segmentUpdateResponse);
	}

	/**
	 * prepare SegmentPosition
	 * 
	 * @param segPos
	 * @throws IOException
	 * @throws HttpException
	 */
	private SegmentUpdateRequest prepareSegmentPosition() {
		// create a new Segment Update Request
		SegmentUpdateRequest.Builder segUpdReq = SegmentUpdateRequest
				.newBuilder();
		// set Segment Update Request information
		segUpdReq.setSegmentId(1);
		segUpdReq.setMaxSegmentSize(1);
		segUpdReq.setVersionFrom(0);
		segUpdReq.setVersionTo(0);
		segUpdReq.addAllDeleteIdList(new ArrayList<String>());

		// get Reference Id list
		List<String> referenceIds = new ArrayList<String>();
		referenceIds.add("test reference id");
		// set Person Biometrics templates
		byte[] template = { 1, 2, 3, 4, 5, 6 };
		segUpdReq.setRecordCount(referenceIds.size());
		segUpdReq.setTemplate(ByteString.copyFrom(template));

		return segUpdReq.build();
	}

	private void setMock(final byte[] data, final boolean bFlag) {
		new MockUp<HttpRequestSender>() {
			@Mock
			private HttpResponse sendHttpRequest(HttpMethod httpMethod,
					String url, Long batchJobId)
					throws InvalidProtocolBufferException {

				if (batchJobId == 12346) {
					throw new RuntimeException("");
				}

				HttpResponse resp = new HttpResponse();

				if (bFlag) {
					SegmentUpdateRequest up = SegmentUpdateRequest
							.parseFrom(data);

					SegmentUpdateResponse.Builder sur = SegmentUpdateResponse
							.newBuilder();
					sur.setGmvId(120);
					sur.setRecordCount(up.getRecordCount());
					sur.setSegmentId(up.getSegmentId());
					sur.setVersion(up.getVersionTo());
					byte[] body = sur.build().toByteArray();

					resp.setHttpResponseBody(body);
				} else {
					resp.setHttpResponseBody(new byte[] { 1, 2, 3, 4, 5, 6 });
				}

				return resp;
			}
		};
	}
}
