package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entityhelpers.EnrollJobQueueHelper;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollJobQueueHelperTest {
	@PersistenceContext(unitName = "tme-ngi")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue;

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJob]<br/>
	 * 1 - prepare EnrollBatchJobQueue/EnrollJobQueue/persistBatchJob For test<br/>
	 * 2 - call getAllExtractJobInfo, to get All ExtractJobInfo<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	@Ignore
	public void testgetAllExtractJobInfo() {

		EnrollJobQueueHelper jobQueueHelper = new EnrollJobQueueHelper(
				entityManager);
		String sql = "select * FROM ENROLL_JOB_QUEUE where BATCHJOB_ID=3 order by JOB_INDEX";

		// 1 - prepare EnrollBatchJobQueue/EnrollJobQueue/persistBatchJob For
		// test
		prepareEnrollBatchJobQueue();
		preparepersistBatchJob();

		// 2 - call getAllExtractJobInfo, to get All ExtractJobInfo
		List<EnrollJobQueueEntity> enrollJobList = jobQueueHelper
				.getAllExtractJobInfo(3);

		// 3 - assert concerning information
		assertEquals(8, enrollJobList.size());
		JdbcTemplate template = new JdbcTemplate(dataSource);
		template.execute(sql);
		List<Map<String, Object>> list = template.queryForList(sql);
		assertEquals(8, list.size());
		for (int i = 1; i <= list.size(); i++) {
			Map<String, Object> map = list.get(i - 1);

			assertEquals(ReturnCode.JobSuccess.ordinal(), Integer.parseInt(map
					.get("RETURN_CODE").toString()));
			assertEquals(i, Integer.parseInt(map.get("JOB_INDEX").toString()));
			assertEquals(i + 11, Integer.parseInt(map.get("REQUEST_ID")
					.toString().trim()));
			byte[] data = (byte[]) map.get("REQUEST");
			byte[] data2 = new byte[] { (byte) i, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
			for (int j = 0; j < data.length; j++) {
				assertEquals(data2[j], data[j]);
			}
			assertEquals(3, Integer.parseInt(map.get("BATCHJOB_ID").toString()));
			assertEquals("abcd" + String.valueOf(i), map.get("REFERENCE_ID")
					.toString().trim());

		}

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJob]<br/>
	 * 1 - prepare EnrollBatchJobQueue/EnrollJobQueue/persistBatchJob For test<br/>
	 * 2 - call mergeBatchJob, to update EnrollJobQueueEntity information<br/>
	 * 3 - query database to get data<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	@Ignore
	public void testmergeBatchJob() {

		// 1 - prepare EnrollBatchJobQueue/EnrollJobQueue
		prepareEnrollBatchJobQueue();
		prepareEnrollJobQueue();

		EnrollJobQueueHelper jobQueueHelper = new EnrollJobQueueHelper(
				entityManager);
		String sql = "select * FROM ENROLL_JOB_QUEUE where BATCHJOB_ID=3";
		// 2 - call mergeBatchJob, to update EnrollJobQueueEntity information
		List<EnrollJobQueueEntity> enrollJobList = preparemergeBatchJob();
		jobQueueHelper.mergeBatchJob(enrollJobList);

		// 3 - query database to get data
		JdbcTemplate template = new JdbcTemplate(dataSource);
		template.execute(sql);
		List<Map<String, Object>> list = template.queryForList(sql);
		// 4 - assert concerning information
		assertEquals(3, list.size());
		for (int i = 1; i <= list.size(); i++) {
			Map<String, Object> map = list.get(i - 1);

			assertEquals(ReturnCode.JobSuccess.ordinal(), Integer.parseInt(map
					.get("RETURN_CODE").toString()));
			assertEquals("__Error_" + String.valueOf(i), map.get("ERROR_CODE")
					.toString());
			assertEquals("ErrorMessage_" + String.valueOf(i), map.get(
					"ERROR_MESSAGE").toString());
			assertEquals(i, Integer.parseInt(map.get("JOB_INDEX").toString()));
			assertEquals(i + 11, Integer.parseInt(map.get("REQUEST_ID")
					.toString().trim()));
			byte[] data = (byte[]) map.get("REQUEST");
			byte[] data2 = new byte[] { (byte) i, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
			for (int j = 0; j < data.length; j++) {
				assertEquals(data2[j], data[j]);
			}

			byte[] dataRes = (byte[]) map.get("RESPONSE");
			byte[] dataRes2 = new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, (byte) i };
			for (int j = 0; j < data.length; j++) {
				assertEquals(dataRes2[j], dataRes[j]);
			}
			assertEquals(3, Integer.parseInt(map.get("BATCHJOB_ID").toString()));
			assertEquals("abcd" + String.valueOf(i), map.get("REFERENCE_ID")
					.toString().trim());

		}
	}

	/**
	 * prepare data for persistBatchJob
	 * 
	 * @return
	 */
	private List<EnrollJobQueueEntity> preparepersistBatchJob() {
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		List<EnrollJobQueueEntity> enrollJobQueueEntityList = new ArrayList<EnrollJobQueueEntity>();
		for (int id = 1; id <= 8; id++) {
			EnrollJobQueueEntity enrollJobQueueEntity = new EnrollJobQueueEntity();
			enrollJobQueueEntity.setBatchJobId(3L);
			enrollJobQueueEntity.setJobIndex(id);
			enrollJobQueueEntity.setReferenceId("abcd" + String.valueOf(id));
			enrollJobQueueEntity.setRequestId(String.valueOf(11 + id));
			enrollJobQueueEntity.setReturnCode(ReturnCode.JobSuccess);
			enrollJobQueueEntity.setRequest(new byte[] { (byte) id, 1, 2, 3, 4,
					5, 6, 7, 8, 9 });
			enrollJobQueueEntityList.add(enrollJobQueueEntity);
		}

		EnrollJobQueueHelper jobQueueHelper = new EnrollJobQueueHelper(
				entityManager);
		jobQueueHelper.persistExtractJobs(enrollJobQueueEntityList);
		return enrollJobQueueEntityList;
	}

	/**
	 * prepare data for mergeBatchJob
	 * 
	 * @return
	 */
	private List<EnrollJobQueueEntity> preparemergeBatchJob() {
		// prepareSegments();
		List<EnrollJobQueueEntity> enrollJobQueueEntityList = new ArrayList<EnrollJobQueueEntity>();
		for (int id = 1; id <= 3; id++) {
			EnrollJobQueueEntity enrollJobQueueEntity = new EnrollJobQueueEntity();
			enrollJobQueueEntity.setBatchJobId(3L);

			enrollJobQueueEntity.setJobIndex(id);
			enrollJobQueueEntity.setErrorCode("__Error_" + String.valueOf(id));
			enrollJobQueueEntity.setErrorMessage("ErrorMessage_"
					+ String.valueOf(id));
			enrollJobQueueEntity.setReferenceId("abcd" + String.valueOf(id));
			enrollJobQueueEntity.setRequestId(String.valueOf(11 + id));

			enrollJobQueueEntity.setReturnCode(ReturnCode.JobSuccess);
			enrollJobQueueEntity.setRequest(new byte[] { (byte) id, 1, 2, 3, 4,
					5, 6, 7, 8, 9 });
			enrollJobQueueEntity.setResponse(new byte[] { 0, 1, 2, 3, 4, 5, 6,
					7, 8, (byte) id });
			enrollJobQueueEntityList.add(enrollJobQueueEntity);
		}
		return enrollJobQueueEntityList;
	}

	/**
	 * prepare data for method EnrollJobQueue
	 */
	private void prepareEnrollJobQueue() {
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		String enrollJobQueueSql = "insert into ENROLL_JOB_QUEUE (BATCHJOB_ID, JOB_INDEX, REQUEST_ID,"
				+ "REFERENCE_ID,RETURN_CODE, ERROR_CODE, ERROR_MESSAGE, REQUEST, RESPONSE, RESENDABLE)"
				+ " values(:BATCHJOB_ID,  :JOB_INDEX, :REQUEST_ID,"
				+ ":REFERENCE_ID, :RETURN_CODE, :ERROR_CODE, :ERROR_MESSAGE, '0', '0', 0)";
		{
			// insert into ENROLL_JOB_QUEUE, JOB_INDEX=1
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("JOB_INDEX", new Integer(1));
			argMap.put("REQUEST_ID", new Long(22));
			argMap.put("REFERENCE_ID", new String("abcd12"));
			argMap.put("RETURN_CODE", new Integer(ReturnCode.JobSuccess
					.ordinal()));
			argMap.put("ERROR_CODE", new Integer(11 % 3).toString());
			argMap.put("ERROR_MESSAGE", new Integer(11).toString());
			jdbcTemplate.update(enrollJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_JOB_QUEUE, JOB_INDEX=2
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("JOB_INDEX", new Integer(2));
			argMap.put("REQUEST_ID", new Long(10));
			argMap.put("REFERENCE_ID", new String("abcd13"));
			argMap.put("RETURN_CODE", ReturnCode.JobSuccess.ordinal());
			argMap.put("ERROR_CODE", new Integer(12 % 3).toString());
			argMap.put("ERROR_MESSAGE", new Integer(12).toString());
			jdbcTemplate.update(enrollJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_JOB_QUEUE, BATCHJOB_ID=5
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("JOB_INDEX", new Integer(3));
			argMap.put("REQUEST_ID", new Long(10));
			argMap.put("REFERENCE_ID", new String("abcd14"));
			argMap.put("RETURN_CODE", ReturnCode.JobSuccess.ordinal());
			argMap.put("ERROR_CODE", new Integer(13 % 3).toString());
			argMap.put("ERROR_MESSAGE", new Integer(13).toString());
			jdbcTemplate.update(enrollJobQueueSql, argMap);
		}
	}

	/**
	 * prepare data for EnrollBatchJobQueues
	 */
	private void prepareEnrollBatchJobQueue() {
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
		String EnrollBatchJobQueueSql = "insert into ENROLL_BATCH_JOB_QUEUE ("
				+ "BATCHJOB_ID,BATCHJOB_STATUS,START_TS, ENQUEUE_TS)"
				+ " values(:BATCHJOB_ID,  :BATCHJOB_STATUS,:START_TS, :ENQUEUE_TS)";
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=3
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(3));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.QUEUED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=31
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(31));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.SYNCHRONIZED.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}
		{
			// insert into ENROLL_BATCH_JOB_QUEUE, BATCHJOB_ID=15
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("BATCHJOB_ID", new Long(15));
			argMap.put("BATCHJOB_STATUS", new Integer(
					EnrollBatchJobStatus.EXTRACTING.getIntValues()));
			argMap.put("ENQUEUE_TS", DateUtil.getCurrentDate());
			argMap.put("START_TS", DateUtil.getCurrentDate());
			jdbcTemplate.update(EnrollBatchJobQueueSql, argMap);
		}

	}
}
