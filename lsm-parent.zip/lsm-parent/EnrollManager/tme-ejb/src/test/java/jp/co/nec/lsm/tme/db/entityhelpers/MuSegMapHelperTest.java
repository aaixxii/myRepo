package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.junit.Ignore;
import org.junit.Test;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentPK;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MuSegMapHelper;

public class MuSegMapHelperTest extends AbstractHelperTest {

	/**
	 * 
	 * Test Case<br/>
	 * Test [testDeleteMuSegMap]<br/>
	 * 1 - prepare MuSegments For test<br/>
	 * 2 - prepare EnrollMuSegmentPK For test<br/>
	 * 3 - call find, to get concerning data<br/>
	 * 4 - assert concerning information<br/>
	 * 5 - call deleteMuSegMap, to delete concerning data<br/>
	 */

	
	@Test
	@Ignore
	public void testDeleteMuSegMap() {
		// 1 - prepare MuSegments For test
		prepareMuSegments();
		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 2 - prepare EnrollMuSegmentPK For test
		MuSegmentPK pk1 = new MuSegmentPK();
		pk1.setMuId(1L);
		pk1.setSegmentId(1L);

		// 3 - call find, to get concerning data
		MuSegmentEntity muSegMap = entityManager.find(MuSegmentEntity.class,
				pk1);

		// 4 - assert concerning information
		assertEquals(1L, muSegMap.getMuId());

		// 5 - call deleteMuSegMap, to delete concerning data
		helper.deleteMuSegMap();
		// 4 - assert concerning information
		assertEquals(
				3,
				jdbcTemplate
						.queryForInt("select count(*) from mu_segments where mu_id in (1,2) and segment_id in (1,2)"));
		assertEquals(4, jdbcTemplate
				.queryForInt("select count(*) from mu_segments"));
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testDeleteMuSegMap_4Mus4Segs]<br/>
	 * 1 - delete segments table in database to clear disturbing<br/>
	 * 2 - prepare matchunit/MuSegments For test<br/>
	 * 3 - call deleteMuSegMap, to delete concerning data<br/>
	 * 4 - assert concerning information<br/>
	 */

	@SuppressWarnings("deprecation")
	@Test
	public void testDeleteMuSegMap_4Mus4Segs() {
		// 1 - delete segments table in database to clear disturbing
		jdbcTemplate.execute("delete FROM mu_segments");
		jdbcTemplate.execute("delete FROM segments");
		jdbcTemplate.execute("delete FROM match_units");

		// 2 - prepare matchunit/MuSegments For test
		startMu(1, 1);
		startMu(3, 1);
		startMu(5, 1);
		startMu(7, 1);
		stopMu(5);
		prepareSegments(4, 1);
		setMuSegments(1L, 1L);
		setMuSegments(5L, 1L);
		setMuSegments(3L, 2L);
		setMuSegments(7L, 2L);
		setMuSegments(1L, 3L);
		setMuSegments(3L, 3L);
		setMuSegments(5L, 4L);
		setMuSegments(7L, 4L);
		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 3 - call deleteMuSegMap, to delete concerning data
		assertEquals(8, jdbcTemplate
				.queryForInt("select count(*) from mu_segments"));

		// 5 - call deleteMuSegMap, to delete concerning data
		helper.deleteMuSegMap();

		// 3 - call deleteMuSegMap, to delete concerning data
		assertEquals(0, jdbcTemplate
				.queryForInt("select count(*) from mu_segments"));
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testDeleteMuSegMapforDM_DMRedundancy2]<br/>
	 * 1 - prepare matchunit/MuSegments For test<br/>
	 * 2 - call deleteMuSegMapOfDM, to delete concerning data<br/>
	 * 3 - query database to get data<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testDeleteMuSegMapforDM_DMRedundancy2() {
		int binId = 3;

		// delete segments table in database to clear disturbing
		jdbcTemplate.execute("delete FROM mu_segments");
		jdbcTemplate.execute("delete FROM segments");
		jdbcTemplate.execute("delete FROM match_units");

		// 1 - prepare matchunit/MuSegments For test
		startMu(1, binId);
		startMu(2, binId);
		startDM(3, binId);
		startDM(4, binId);
		prepareSegments(6, 1);
		for (long id = 1; id <= 3; id++) {
			setMuSegments(1, id);
		}
		for (long id = 4; id <= 6; id++) {
			setMuSegments(2, id);
		}
		for (long id = 1; id <= 6; id++) {
			setMuSegments(3, id);
			setMuSegments(4, id);
		}

		assertEquals(18, jdbcTemplate
				.queryForObject("select count(*) from mu_segments", Integer.class).intValue());
		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 2 - call deleteMuSegMapOfDM, to delete concerning data
		helper.deleteMuSegMapOfDM();

		// 3 - query database to get data
		List<Map<String, Object>> mapList = jdbcTemplate
				.queryForList("select MU_ID, segment_id from mu_segments");

		// 4 - assert concerning information
		assertEquals(6, mapList.size());
		for (Map<String, Object> map : mapList) {
			BigDecimal bd = (BigDecimal) map.get("MU_ID");
			assertTrue(bd.longValue() == 1L || bd.longValue() == 2L);
		}
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testDeleteMuSegMapforDM_DMRedundancy1]<br/>
	 * 1 - prepare match unit/MuSegments For test<br/>
	 * 2 - call deleteMuSegMapOfDM, to delete concerning data<br/>
	 * 3 - query database to get data<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testDeleteMuSegMapforDM_DMRedundancy1() {
		int binId3 = 3;
		int binId5 = 5;

		// delete segments table in database to clear disturbing
		jdbcTemplate.execute("delete FROM mu_segments");
		jdbcTemplate.execute("delete FROM segments");
		jdbcTemplate.execute("delete FROM match_units");

		// 1 - prepare matchunit/MuSegments For test
		startMu(1, binId3);
		startMu(2, binId3);
		startDM(3, binId3);
		startDM(4, binId5);
		prepareSegments(12, 1);
		for (long id = 1; id <= 3; id++) {
			setMuSegments(1, id);
		}
		for (long id = 4; id <= 6; id++) {
			setMuSegments(2, id);
		}
		for (long id = 1; id <= 6; id++) {
			setMuSegments(3, id);
		}
		for (long id = 7; id <= 12; id++) {
			setMuSegments(4, id);
		}

		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 2 - call deleteMuSegMapOfDM, to delete concerning data
		helper.deleteMuSegMapOfDM();

		// 3 - query database to get data
		List<Map<String, Object>> mapList = jdbcTemplate
				.queryForList("select MU_ID, segment_id from mu_segments");

		// 4 - assert concerning information
		assertEquals(6, mapList.size());
		for (Map<String, Object> map : mapList) {
			BigDecimal bd = (BigDecimal) map.get("MU_ID");
			assertTrue(bd.longValue() == 1L || bd.longValue() == 2L
					|| bd.longValue() == 4L);
		}
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testFindMuSegMapOfMU]<br/>
	 * 1 - prepare MuSegments For test<br/>
	 * 2 - query database to get data<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testFindMuSegMapOfMU() {
		// 1 - prepare MuSegments For test
		prepareMuSegments();
		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 2 - query database to get data
		List<MuSegmentEntity> muSegMaps = helper.findMuSegMapOfMU();

		// 3 - assert concerning information
		assertEquals(6, muSegMaps.size());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testFindMuSegMap]<br/>
	 * 1 - prepare MuSegments For test<br/>
	 * 2 - query database to get data<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testFindMuSegMap() {
		// 1 - prepare MuSegments For test
		prepareMuSegments();
		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 2 - query database to get data
		MuSegmentEntity map1 = helper.findMuSegMap(1L, 1L);

		// 3 - assert concerning information
		assertEquals(1L, map1.getMuId());
		assertEquals(1L, map1.getSegmentId());

		// 2 - query database to get data
		MuSegmentEntity map2 = helper.findMuSegMap(1L, 2L);

		// 3 - assert concerning information
		assertEquals(2L, map2.getSegmentId());

		// 2 - query database to get data
		MuSegmentEntity map3 = helper.findMuSegMap(5L, 5L);

		// 3 - assert concerning information
		assertEquals(5L, map3.getMuId());
		assertEquals(5L, map3.getSegmentId());

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testFindMusInMuSegMap]<br/>
	 * 1 - prepare MuSegments For test<br/>
	 * 2 - query database to get data<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testFindMusInMuSegMap() {

		// 1 - prepare MuSegments For test
		prepareMuSegments();
		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 2 - query database to get data
		List<MatchUnitEntity> mus = helper.findUscInMuSegMap();

		// 2 - query database to get data
		assertEquals(2, mus.size());
		assertTrue(ArrayUtils.contains(new long[] { 3L, 4L }, mus.get(0)
				.getId()));
		assertTrue(ArrayUtils.contains(new long[] { 3L, 4L }, mus.get(1)
				.getId()));

		// 2 - query database to get data
		List<MatchUnitEntity> mus2 = helper.findUscInMuSegMap();

		// 3 - assert concerning information
		assertEquals(2, mus2.size());
		assertEquals(3L, mus2.get(0).getId());

		// 2 - query database to get data
		List<MatchUnitEntity> mus3 = helper.findUscInMuSegMap();

		// 3 - assert concerning information
		assertEquals(2, mus3.size());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testFindMusInMuSegMap]<br/>
	 * 1 - prepare MuSegments For test<br/>
	 * 2 - query database to get data<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testFindWorkingUnitInMuSegMap() {

		// 1 - prepare MuSegments For test
		prepareMuSegments();
		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 2 - query database to get data
		List<MatchUnitEntity> mus = helper
				.findWorkingUnitInMuSegMapByUnitType(ComponentType.USC);

		// 2 - query database to get data
		assertEquals(2, mus.size());
		assertEquals(3L, mus.get(0).getId());
		assertEquals(4L, mus.get(1).getId());

		// 2 - query database to get data
		List<MatchUnitEntity> mus2 = helper
				.findWorkingUnitInMuSegMapByUnitType(ComponentType.DM);

		// 3 - assert concerning information
		assertEquals(3, mus2.size());
		assertEquals(1L, mus2.get(0).getId());
		assertEquals(2L, mus2.get(1).getId());
		assertEquals(5L, mus2.get(2).getId());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJob]<br/>
	 * 1 - prepare MuSegmentsFor2MUs1Seg For test<br/>
	 * 2 - call findMuSegMapOfMU, to query database to get data<br/>
	 * 3 - assert concerning information<br/>
	 */
	@Test
	public void testFindMusInMuSegMap_2MUs1Seg() {
		// delete segments table in database to clear disturbing
		jdbcTemplate.execute("delete FROM segments");
		jdbcTemplate.execute("delete FROM mu_segments");
		jdbcTemplate.execute("delete FROM match_units");

		// 1 - prepare MuSegmentsFor2MUs1Seg For test
		prepareMuSegmentsFor2MUs1Seg();

		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		// 2 - call findMuSegMapOfMU, to query database to get data
		List<MuSegmentEntity> maps = helper.findMuSegMapOfMU();

		// 3 - assert concerning information
		assertEquals(1, maps.size());
	}

	@Test
	public void testFindUnitBySegId_DM() {
		prepareMuSegments();

		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		List<MatchUnitEntity> dmList = helper.findUnitBySegId(ComponentType.DM,
				2);

		assertEquals(2, dmList.size());

		assertTrue(ArrayUtils.contains(new long[] { 1L, 2L }, dmList.get(0)
				.getId()));
		assertTrue(ArrayUtils.contains(new long[] { 1L, 2L }, dmList.get(1)
				.getId()));

	}

	@Test
	public void testFindUnitBySegId_USC() {
		prepareMuSegments();

		MuSegMapHelper helper = new MuSegMapHelper(entityManager);

		List<MatchUnitEntity> dmList = helper.findUnitBySegId(
				ComponentType.USC, 5);

		assertEquals(2, dmList.size());

		assertTrue(ArrayUtils.contains(new long[] { 3L, 4L }, dmList.get(0)
				.getId()));
		assertTrue(ArrayUtils.contains(new long[] { 3L, 4L }, dmList.get(1)
				.getId()));
	}

	/**
	 * prepare data for MuSegmentsFor2MUs1Seg testing
	 * 
	 */
	private void prepareMuSegmentsFor2MUs1Seg() {
		changeRedundancy(1);
		prepareSegments(1, 1);
		startMu(1, 1);
		startMu(2, 1);
		{
			String sql = "update match_units set balanced_flag=1 where mu_id=?";
			jdbcTemplate.update(sql, new Object[] { new Long(1) });
			jdbcTemplate.update(sql, new Object[] { new Long(2) });
		}
		{
			jdbcTemplate
					.execute("insert into mu_segments (mu_id, segment_id, rank) values(1, 1, 1)");
		}
		// jdbcTemplate.execute("commit");
	}

	/**
	 * Set WORKING MUs(MU_ID=1,2,5), SEGMENTS(ID=1,2,5) to BIN_ID=1,5.
	 * 
	 */
	private void prepareMuSegments() {
		// insert into match_units, mu_id=1,2,3,4,5
		// mu_id=3,4 are DataManager
		jdbcTemplate.execute("delete FROM mu_segments");
		jdbcTemplate.execute("delete FROM segments");
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, CONTACT_URL, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(1, 1, 'CONTACT_URL1', 'WORKING', 0, 1, 1, 1)");
		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, CONTACT_URL, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(2, 2, 'CONTACT_URL2', 'WORKING', 0, 1, 2, 1)");

		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, CONTACT_URL, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(3, 3, 'CONTACT_URL3', 'WORKING', 2, 1, 3, 1)");
		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, CONTACT_URL, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(4, 4, 'CONTACT_URL4', 'WORKING', 2, 1, 4, 1)");

		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, CONTACT_URL, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(5, 5, 'CONTACT_URL5', 'WORKING', 0, 1, 5, 1)");

		jdbcTemplate.execute("delete FROM segments");

		String segmentsSql = "insert into segments (SEGMENT_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(:SEGMENT_ID,  :BIO_ID_START,:BIO_ID_END,"
				+ ":BINARY_LENGTH_COMPACTED, :RECORD_COUNT, :VERSION, :GENERATION, :BINARY_LENGTH_UNCOMPACTED)";
		{
			// insert into segments, SEGMENT_ID=1
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(1));
			// argMap.put("SEGMENT_SET_ID", new Long(1));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}
		{
			// insert into segments, SEGMENT_ID=2
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(2));
			// argMap.put("SEGMENT_SET_ID", new Long(1));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}
		{
			Map<String, Object> argMap = new HashMap<String, Object>();
			argMap.put("SEGMENT_ID", new Long(5));
			// argMap.put("SEGMENT_SET_ID", new Long(5));
			argMap.put("BIO_ID_START", new Long(1));
			argMap.put("BIO_ID_END", new Long(10));
			argMap.put("BINARY_LENGTH_COMPACTED", new Long(10));
			argMap.put("RECORD_COUNT", new Long(10));
			argMap.put("VERSION", new Long(1));
			argMap.put("GENERATION", new Long(1));
			argMap.put("BINARY_LENGTH_UNCOMPACTED", new Long(100));
			jdbcTemplate.update(segmentsSql, argMap);
		}

		jdbcTemplate
				.update(
						"insert into mu_segments (mu_id, SEGMENT_ID, rank, assigned_ts) values(1, 1, 1, ?)",
						new Object[] { DateUtil.getCurrentDate() },
						new int[] { Types.TIMESTAMP });
		jdbcTemplate
				.update(
						"insert into mu_segments (mu_id,  SEGMENT_ID,rank, assigned_ts) values(1, 2, 1, ?)",
						new Object[] { DateUtil.getCurrentDate() },
						new int[] { Types.TIMESTAMP });
		jdbcTemplate
				.update(
						"insert into mu_segments (mu_id, SEGMENT_ID, rank, assigned_ts) values(2, 2, 1, ?)",
						new Object[] { DateUtil.getCurrentDate() },
						new int[] { Types.TIMESTAMP });
		jdbcTemplate
				.update(
						"insert into mu_segments (mu_id, SEGMENT_ID, rank, assigned_ts) values(5, 5, 1, ?)",
						new Object[] { DateUtil.getCurrentDate() },
						new int[] { Types.TIMESTAMP });
		{
			// mu_segments for DM.
			String sql = "insert into mu_segments (mu_id, SEGMENT_ID, rank, assigned_ts) values(?, ?, 1, ?)";
			for (int muId = 3; muId <= 4; muId++) {
				for (int segId = 1; segId <= 2; segId++) {
					jdbcTemplate.update(sql, new Object[] { new Long(muId),
							new Long(segId), DateUtil.getCurrentDate() },
							new int[] { Types.BIGINT, Types.BIGINT,
									Types.TIMESTAMP });
				}
				int segId = 5;
				jdbcTemplate
						.update(sql, new Object[] { new Long(muId),
								new Long(segId), DateUtil.getCurrentDate() },
								new int[] { Types.BIGINT, Types.BIGINT,
										Types.TIMESTAMP });
			}
		}

	}
}