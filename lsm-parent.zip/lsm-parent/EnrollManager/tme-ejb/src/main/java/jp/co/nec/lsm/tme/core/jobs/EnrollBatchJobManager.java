package jp.co.nec.lsm.tme.core.jobs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDaoLocal;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShot;
import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShotDetail;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author zhulk <br>
 *         This class of used to manage EnrollQueue.
 * 
 */
public class EnrollBatchJobManager {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(EnrollBatchJobManager.class);

	private static EnrollBatchJobManager enrollQueueManager;
	private final static String br = System.getProperty("line.separator");;

	public synchronized static EnrollBatchJobManager getInstance() {
		if (enrollQueueManager == null) {
			enrollQueueManager = new EnrollBatchJobManager();
		}
		return enrollQueueManager;
	}

	private ConcurrentLinkedQueue<LocalEnrollBatchJob> batchJobQueue;

	private EnrollBatchJobManager() {
		batchJobQueue = new ConcurrentLinkedQueue<LocalEnrollBatchJob>();
	}
	
	public void clearAll() {
		batchJobQueue.clear();
	}

	/**
	 * get local enroll queue instance
	 * 
	 * @return local enroll queue instance
	 */
	public ConcurrentLinkedQueue<LocalEnrollBatchJob> getEnrollLinkQueue() {
		printLogMessage("called public function getEnrollLinkQueue()..");

		return batchJobQueue;
	}

	/**
	 * add an enroll Batch Job into local enroll queue.
	 */
	public void addEnrollBatchJob(LocalEnrollBatchJob enrollBatchJob) {
		printLogMessage("start public function addEnrollBatchJob()..");
		synchronized (batchJobQueue) {
			batchJobQueue.add(enrollBatchJob);
		}
		printLogMessage("end public function addEnrollBatchJob()..");

	}

	/**
	 * get Enroll Batch Job By batchJob Id
	 * 
	 * @param batchJobId
	 *            Enroll Batch Job Id
	 * @return Enroll Batch Job
	 */
	public LocalEnrollBatchJob getEnrollBatchJobById(long batchJobId) {
		printLogMessage("start public function getEnrollBatchJobById().");

		Iterator<LocalEnrollBatchJob> iterator = batchJobQueue.iterator();

		// loop the enroll local queue to get the enroll batch job.
		printLogMessage("get the enroll batch job by batchJobId " + batchJobId);

		while (iterator.hasNext()) {
			LocalEnrollBatchJob batchJob = iterator.next();
			if (batchJobId == batchJob.getBatchJobId()) {
				return batchJob;
			}
		}

		printLogMessage("end public function getEnrollBatchJobById().");

		return null;
	}

	/**
	 * get Not Synchronized Enroll Batch Job List
	 * 
	 * @return Enroll Batch Job List
	 */
	public List<LocalEnrollBatchJob> getNotSynchronizedEnrollBatchJobs() {
		printLogMessage("start public function getNotSynchronizedEnrollBatchJobs().");

		Iterator<LocalEnrollBatchJob> iterator = batchJobQueue.iterator();

		// loop the enroll local queue to get the enroll batch job.
		List<LocalEnrollBatchJob> unSynchedEnrollBatchJobs = new ArrayList<LocalEnrollBatchJob>();
		while (iterator.hasNext()) {
			LocalEnrollBatchJob batchJob = iterator.next();
			if (batchJob.isBatchJobStatus(EnrollBatchJobStatus.REGISTERED)) {
				unSynchedEnrollBatchJobs.add(batchJob);
			}
		}
		if (unSynchedEnrollBatchJobs.isEmpty()) {
			return unSynchedEnrollBatchJobs;
		}

		LocalEnrollBatchJob[] arrays = new LocalEnrollBatchJob[unSynchedEnrollBatchJobs
				.size()];
		Arrays.sort(unSynchedEnrollBatchJobs.toArray(arrays),
				new Comparator<LocalEnrollBatchJob>() {
					@Override
					public int compare(final LocalEnrollBatchJob entry1,
							final LocalEnrollBatchJob entry2) {
						return compareOrderBySegmentIdAndVersion(entry1, entry2);
					}
				});

		unSynchedEnrollBatchJobs = Arrays.asList(arrays);

		printLogMessage("Not synchronized enroll batch jobs count: "
				+ unSynchedEnrollBatchJobs.size());

		printLogMessage("end public function getNotSynchronizedEnrollBatchJobs().");

		return unSynchedEnrollBatchJobs;
	}

	/**
	 * 
	 * @param entry1
	 * @param entry2
	 * @return
	 */
	private int compareOrderBySegmentIdAndVersion(LocalEnrollBatchJob entry1,
			LocalEnrollBatchJob entry2) {
		if (entry1 == null || entry1.getSegmentPosition() == null
				|| entry1.getSegmentPosition().isEmpty()) {
			return -1;
		}
		if (entry2 == null || entry2.getSegmentPosition() == null
				|| entry2.getSegmentPosition().isEmpty()) {
			return 1;
		}
		SegmentPosition segPos = entry1.getSegmentPosition().get(0);
		SegmentPosition segPosInList = entry2.getSegmentPosition().get(0);
		if (segPos.getSegmentId() == segPosInList.getSegmentId()
				&& segPos.getVersion() < segPosInList.getVersion()) {
			return -1;
		} else if (segPos.getSegmentId() < segPosInList.getSegmentId()) {
			return -1;
		}
		return 1;
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	public LocalEnrollBatchJob getCompleteBatchJob(long batchJobId) {
		printLogMessage("start public function GetCompleteBatchJob()..");

		LocalEnrollBatchJob batchJob = getEnrollBatchJobById(batchJobId);
		// mantis 499 Need null check when retrying update batch job
		if (batchJob == null) {
			return null;
		}

		if (!batchJob.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTED)) {
			log.warn("the batch job {} is not EXTRACTED...", batchJobId);
			return null;
		}

		printLogMessage("end public function GetCompleteBatchJob()..");

		return batchJob;
	}

	/**
	 * 
	 * @param batchJob
	 * @return
	 */
	public boolean deleteCompleteBatchJob(LocalEnrollBatchJob batchJob) {
		printLogMessage("start public function DeleteCompleteBatchJob()..");
		synchronized (batchJobQueue) {
			if (!batchJob.isBatchJobStatus(EnrollBatchJobStatus.RETURNED)) {
				log.warn("the batch job {} is not RETURNED...", batchJob
						.getBatchJobId());
				return false;
			}

			boolean bResult = batchJobQueue.remove(batchJob);

			printLogMessage("start public function DeleteCompleteBatchJob()..");

			return bResult;
		}
	}

	/**
	 * reportTransitionState
	 * 
	 * @return String
	 */
	public static String reportTransitionState(
			EnrollSystemConfigDaoLocal systemConfigDao) {
		printLogMessage("start public function reportTransitionState()..");
		EnrollBatchJobManager enrollJobManager = EnrollBatchJobManager
				.getInstance();
		StringBuilder sb = new StringBuilder();

		sb.append(reportTransitionStateHead(enrollJobManager, systemConfigDao));
		sb.append(br);
		sb.append(createBatchJobDetail(enrollJobManager));

		printLogMessage("end public function reportTransitionState()..");
		return sb.toString();
	}

	/**
	 * create Batch Job Summary of batchJob
	 * 
	 * @param batchJob
	 * @return
	 */
	private static String createBatchJobDetail(
			EnrollBatchJobManager enrollJobManager) {
		StringBuilder sb = new StringBuilder();
		// get enrollLinkQueue iterator
		Iterator<LocalEnrollBatchJob> iterator = enrollJobManager
				.getEnrollLinkQueue().iterator();

		// check iterator is null or empty
		if (iterator == null || !iterator.hasNext()) {
			printLogMessage("enrollLinkQueue instance is null or empty");
			return sb.toString();
		}

		int queuedCount = 0;
		int extractingCount = 0;
		int extractedCount = 0;
		int registeredCount = 0;
		int rynchronizedCount = 0;
		int returnedCount = 0;

		// do loop until find a instance match batchJobId
		while (iterator.hasNext()) {
			LocalEnrollBatchJob batchJob = iterator.next();
			if (batchJob == null) {
				printLogMessage("this BatchIdentifyQueue instance is null");
				continue;
			}
			switch (batchJob.getBatchJobStatus().ordinal()) {
			case 0:
				queuedCount++;
				break;
			case 1:
				extractingCount++;
				break;
			case 2:
				extractedCount++;
				break;
			case 3:
				registeredCount++;
				break;
			case 4:
				rynchronizedCount++;
				break;
			case 5:
				returnedCount++;
				break;
			}
			addHeader(sb, br);

			sb.append("batch job id:");
			sb.append(batchJob.getBatchJobId());
			sb.append(br);
			sb.append("batch job status:");
			sb.append(batchJob.getBatchJobStatus().name());
			sb.append(br);
			sb.append("batch extract job count:");
			sb.append(batchJob.getExtractJobCount());
			sb.append(br);
			sb.append("batch assigned extract job count:");
			sb.append(batchJob.getAssignedExtractJobCount());
			sb.append(br);

			addFooter(sb, br);
		}
		StringBuilder sbSimpleSummary = createBatchJobSimple(queuedCount,
				extractingCount, extractedCount, registeredCount,
				rynchronizedCount, returnedCount);
		sbSimpleSummary.append(sb);
		return sbSimpleSummary.toString();
	}

	/**
	 * create simple Summary of batchJob
	 * 
	 * @param batchJob
	 * @return
	 */
	private static StringBuilder createBatchJobSimple(int queuedCount,
			int extractingCount, int extractedCount, int registeredCount,
			int rynchronizedCount, int returnedCount) {
		StringBuilder sbSimpleSummary = new StringBuilder();
		sbSimpleSummary.append("All BatchJobs status summary:");
		addHeader(sbSimpleSummary, br);
		sbSimpleSummary.append("QUEUED job's number:");
		sbSimpleSummary.append(queuedCount);
		sbSimpleSummary.append(br);
		sbSimpleSummary.append("EXTRACTING job's number:");
		sbSimpleSummary.append(extractingCount);
		sbSimpleSummary.append(br);
		sbSimpleSummary.append("EXTRACTED job's number:");
		sbSimpleSummary.append(extractedCount);
		sbSimpleSummary.append(br);
		sbSimpleSummary.append("REGISTERED job's number:");
		sbSimpleSummary.append(registeredCount);
		sbSimpleSummary.append(br);
		sbSimpleSummary.append("SYNCHRONIZED job's number:");
		sbSimpleSummary.append(rynchronizedCount);
		sbSimpleSummary.append(br);
		sbSimpleSummary.append("RETURNED job's number:");
		sbSimpleSummary.append(returnedCount);
		sbSimpleSummary.append(br);
		addFooter(sbSimpleSummary, br);
		sbSimpleSummary.append(br);
		sbSimpleSummary.append("Each batch job summary:");
		return sbSimpleSummary;

	}

	/**
	 * 
	 * @return
	 */
	private static String reportTransitionStateHead(
			EnrollBatchJobManager enrollJobManager,
			EnrollSystemConfigDaoLocal systemConfigDao) {
		EnrollBatchJobGetterTimer jobGetter = EnrollBatchJobGetterTimer
				.getInstance();

		StringBuilder sb = new StringBuilder();
		sb.append("TME Server summary");
		sb.append(br);
		sb.append(br);
		sb.append("BootMode:");
		addHeader(sb, br);

		sb.append("Mode=");
		sb.append(jobGetter.getTransitionState().name());
		sb.append(br);

		sb.append("backlogs=");
		sb.append(enrollJobManager.getNotCompletedBatchJobCount());
		sb.append(br);
		sb.append("SLB status:");
		sb.append(systemConfigDao.getSlbEnabled() ? "start" : "stop");
		sb.append(br);
		addFooter(sb, br);
		return sb.toString();
	}

	/**
	 * create header
	 * 
	 * @param sb
	 *            ,br
	 * @return
	 */
	private static void addHeader(StringBuilder sb, String br) {
		sb.append(br);
		sb.append(EnrollConstants.SUMMARY_SPLIT);
		sb.append(br);
	}

	/**
	 * create footer
	 * 
	 * @param sb
	 *            ,br
	 * @return
	 */
	private static void addFooter(StringBuilder sb, String br) {
		sb.append(EnrollConstants.SUMMARY_SPLIT);
		sb.append(br);
	}

	/**
	 * get enrollinkQueue Summary
	 * 
	 * @return Summary Information
	 */
	public String getSummary() {
		printLogMessage("start public function getSummary()..");

		StringBuffer stringBuffer = new StringBuffer();
		// get enrollLinkQueue iterator
		Iterator<LocalEnrollBatchJob> iterator = batchJobQueue.iterator();

		// do loop until find a instance match batchJobId
		while (iterator.hasNext()) {
			LocalEnrollBatchJob ebj = iterator.next();
			if (ebj == null) {
				printLogMessage("this BatchIdentifyQueue instance is null");

				continue;
			}

			stringBuffer.append("\n");
			stringBuffer
					.append("======================================================");
			stringBuffer.append("\n");

			stringBuffer.append(ebj.getSummary());

			stringBuffer
					.append("======================================================");
			stringBuffer.append("\n");
		}

		printLogMessage("end public function getSummary()..");

		return stringBuffer.toString();
	}

	public EnrollBatchJobSnapShot GetBatchJobSnapShot() {
		EnrollBatchJobManager enrollJobManager = EnrollBatchJobManager
				.getInstance();
		// get enrollLinkQueue iterator
		Iterator<LocalEnrollBatchJob> iterator = enrollJobManager
				.getEnrollLinkQueue().iterator();

		Date now = DateUtil.getCurrentDate();
		List<EnrollBatchJobSnapShotDetail> detailList = null;
		detailList = new ArrayList<EnrollBatchJobSnapShotDetail>();

		int queuedCount = 0;
		int extractingCount = 0;
		int extractedCount = 0;
		int registeredCount = 0;
		int synchronizedCount = 0;
		@SuppressWarnings("unused")
		int returnedCount = 0;

		// check iterator is null or empty
		if (iterator == null || !iterator.hasNext()) {
			printLogMessage("enrollLinkQueue instance is null or empty");
		} else {
			// do loop until find a instance match batchJobId
			while (iterator.hasNext()) {
				LocalEnrollBatchJob batchJob = iterator.next();
				if (batchJob == null) {
					printLogMessage("this BatchIdentifyQueue instance is null");
					continue;
				}

				EnrollBatchJobSnapShotDetail detail = new EnrollBatchJobSnapShotDetail();

				switch (batchJob.getBatchJobStatus().ordinal()) {
				case 0:
					queuedCount++;
					break;
				case 1:
					extractingCount++;
					break;
				case 2:
					extractedCount++;
					break;
				case 3:
					registeredCount++;
					break;
				case 4:
					synchronizedCount++;
					break;
				case 5:
					returnedCount++;
					break;
				}

				detail.setBatchJobId(batchJob.getBatchJobId());
				detail.setJobCount(batchJob.getExtractJobCount());
				detail.setExtractingJobCount(batchJob.getExtractingJobCount());
				detail.setExtractedJobCount(batchJob
						.getCompletedExtractJobCount());
				detail.setHoldingTime(now.getTime()
						- batchJob.getEnqueueTS().getTime());
				detail.setStatus(batchJob.getBatchJobStatus());
				detail.setTemplatesCount(batchJob.getSuccessExtractJobCount());
				detail.setSyncingGMV(batchJob.getSyncGmv());

				detailList.add(detail);
			}
		}

		EnrollBatchJobSnapShot snapShot = new EnrollBatchJobSnapShot();
		snapShot.setOutPutDate(now);
		snapShot.setTransformerCount(queuedCount);
		snapShot.setExtractorCount(extractingCount);
		snapShot.setDataSerCount(extractedCount);
		snapShot.setSyncSerCount(registeredCount);
		snapShot.setResponseCount(synchronizedCount);

		EnrollBatchJobSnapShotDetail[] arrays = new EnrollBatchJobSnapShotDetail[detailList
				.size()];
		Arrays.sort(detailList.toArray(arrays),
				new Comparator<EnrollBatchJobSnapShotDetail>() {
					@Override
					public int compare(
							final EnrollBatchJobSnapShotDetail entry1,
							final EnrollBatchJobSnapShotDetail entry2) {
						if (entry1 == null) {
							return 1;
						}
						if (entry2 == null) {
							return -1;
						}
						long segPos = entry1.getBatchJobId();
						long segPosInList = entry2.getBatchJobId();
						if (segPos < segPosInList) {
							return 1;
						}
						return -1;
					}
				});

		snapShot.setDetailList(Arrays.asList(arrays));
		return snapShot;
	}

	public int getNotCompletedBatchJobCount() {
		printLogMessage("start public function getNotCompletedBatchJobCount().");
		int notCompeletedBjb = batchJobQueue.size();
		return notCompeletedBjb;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
