package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.Local;

import jp.co.nec.lsm.tme.snapshot.EnrollBatchJobSnapShot;

/**
 * 
 * @author mozj
 *
 */
@Local
public interface EnrollBatchJobsSnapshotsLocal {
	public EnrollBatchJobSnapShot GetBatchJobSnapShot(String limitCount);
}
