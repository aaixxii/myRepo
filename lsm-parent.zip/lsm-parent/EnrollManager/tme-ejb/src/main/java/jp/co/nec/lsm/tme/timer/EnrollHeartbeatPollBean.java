package jp.co.nec.lsm.tme.timer;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tme.db.dao.EnrollTransactionManagerDao;
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollHeartbeatPollBean  {

	@EJB
	EnrollTransactionManagerDao dao;

	private static Logger log = LoggerFactory
	.getLogger(EnrollHeartbeatPollBean.class);
	
	
	public void poll() {
		printLogMessage("poll() is called.");

		StopWatch t = new StopWatch();
		t.start();
		
		dao.createOrLookup();
		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_ENROLL_HEARTBEAT_POLL_BEAN,
				LogConstants.FUNCTION_POLL, t.getTime());
	}
	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
