package jp.co.nec.lsm.tme.db.dao;

import javax.ejb.Local;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollSystemConfigDaoLocal {

	/**
	 * write All Missing Properties into DB
	 */
	public void writeAllMissingProperties();

	public Integer getMaxExtractjobFailure();

	public Integer getHeartBeatTimeOut();

	public Integer getExtractJobTimeOut();

	public Integer getMinUSCRedundancy();

	public Integer getDefaultUSCRedundancy();

	public Integer getMaxUSCRedundancy();

	public Long getMaxSegmentSize();

	public String getDMPushURL();

	public int getMinUscForSlb();

	public boolean getSlbEnabled();

	public int getHighLevelEnrollBatchJobs();

	public int getLowLevelEnrollBatchJobs();

	public int getIntervalForEnrollHighLevel();

	public int getIntervalForEnrollLowLevel();

	public int getIntervalForEnrollNormal();

	public String getBatchJobFromTransformerUrl();

	public String getPostToTransformerUrl();

	public String getJobCountToTransformer();

	public String getBatchJobCountToTransformer();

	public String getTurnAroundTime();

	public String getTMEIpAddress();

	public String getTmeBatchJobReceiverUrl();

	public boolean getEnrollServiceEnabled();

	public String getTMEWebPort();

	public int getTemplateSize();

	public int getHeartbeatPollingDuration();

	public String getSegmentDeleteSyn();
}
